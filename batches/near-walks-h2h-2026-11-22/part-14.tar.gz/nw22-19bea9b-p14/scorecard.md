# Doctrine scorecard: nw22-19bea9b-p14

### Scorecard: nw22-19bea9b-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | - | 0 | 7 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 2 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 8 | - | 0 | 2 | 0 | 0 | 0 | 790 |
| L0307 | 1 | 1 | Opponent | yes | 1 | - | 0 | 2 | 2 | 0 | 0 | 0 |
| L0323 | 5 | 1 | Mine | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 790 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 257 |
| **Average** | | | Mine | 67% | 4.0 | 5.0 | 0.3 | 4.0 | 0.3 | 0.0 | 0.0 | 583.3 |
| **Average** | | | Opponent | 67% | 1.5 | 3.0 | 3.0 | 2.0 | 0.7 | 0.0 | 0.0 | 85.7 |

### KPIs: nw22-19bea9b-p14

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 21% (3 of 14) | 0% (0 of 15) | 10% (3 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 28% (10 of 36) | 17% (1 of 6) | 26% (11 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (10 of 31) | 50% (1 of 2) | 33% (11 of 33) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (1 of 1) | - | 100% (1 of 1) |
| Points that never fought | lower | 66% (3903 of 5897) | 81% (4867 of 5999) | 74% (8770 of 11896) |
|   infantry points that never fought | lower | 75% (1084 of 1437) | 100% (938 of 938) | 85% (2022 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 55% (11 of 20) | 60% (25 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (2 of 4); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2532 of 4484) | 55% (2559 of 4648) | 56% (5091 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (62%) | 0.0 (0%) | 5.3 (52%) |
| MARCHED: its unit marched | 1.7 (19%) | 0.3 (20%) | 2.0 (19%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.3 (15%) | 1.3 (80%) | 2.7 (26%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.7 | 3.7 | 0.3 | 0.3 |
| not cast | 0.0 | 2.3 | 10.3 | 1.7 | 7.7 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (22%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 5.3 (52%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.0 (19%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (29%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 2.7 (26%) | 1.3 (80%) | 2.7 (35%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (43%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 80% (4 of 5) | - | 80% (4 of 5) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 50% (2 of 4) | - | 50% (2 of 4) |
| none of these (no charge, no fight, no charge escaped) | 50% (2 of 4) | - | 50% (2 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (47 of 59) | 59% (73 of 124) | 66% (120 of 183) |
|   cavalry | - | 68% (13 of 19) | 68% (13 of 19) |
|   character | - | 0% (0 of 22) | 0% (0 of 22) |
|   chariot | 56% (10 of 18) | 83% (5 of 6) | 62% (15 of 24) |
|   infantry | - | 81% (48 of 59) | 81% (48 of 59) |
|   war machine | 90% (37 of 41) | 39% (7 of 18) | 75% (44 of 59) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (17%) | 1.7 (10%) | 2.3 (11%) |
| CHARGED: it charged | 0.3 (8%) | 3.0 (18%) | 3.3 (16%) |
| IN COMBAT: it fought this turn or the last | 0.3 (8%) | 0.3 (2%) | 0.7 (3%) |
| MOVED: a war machine that moved | 0.7 (17%) | 2.0 (12%) | 2.7 (13%) |
| NO TARGET IN RANGE | 0.7 (17%) | 7.7 (45%) | 8.3 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (33%) | 1.3 (8%) | 2.7 (13%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.7 | 87% | 3.2 pts | 16 pts |
| chariot | 5.0 | 4.0 | 53% | 20.6 pts | 103 pts |
| infantry | 19.0 | 4.7 | 77% | 4.2 pts | 79 pts |
| war machine | 15.3 | 14.0 | 70% | 13.7 pts | 210 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 5.0 | 2.7 |
| Charges that made contact a game | 0.3 | 2.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.50 declared, 0.20 contact (30 units) | 0.32 declared, 0.14 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (4 of 4) | 0% (0 of 2) | - | 67% (4 of 6) |
| Character on its own | 50% (1 of 2) | - | 60% (3 of 5) | 57% (4 of 7) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 78% (7 of 9) | 100% (2 of 2) | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (2 of 2); on the table 100% | 33% (4 of 12) | 28% | 33% (2 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | - | 25% (6 of 24) | 84% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Empire of Man | 1 | - | 17% (1 of 6) | 100% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (3 of 3); on the table 100% | - | 72% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | - | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 9% (1 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 71% (37 of 52) | 77% (27 of 35) |
| Strategy | Joined characters whose unit fought | 67% (4 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 29% (2 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 4.0 | 2.0 |
| Movement | Points that never moved of their own | 583.3 | 85.7 |
| Movement | Fights charged into per game | 0.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +66 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 3, net +81 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.3 | 22.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | 24% (16 of 67) |
| Shooting | Points destroyed by shooting units | 126.7 | 65.0 |
| Shooting | War machine shots | 13.0 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (9 of 39) | 86% (6 of 7) |
| Shooting | Points destroyed by war machines | 23.3 | 103.3 |
| Magic | Magic missiles cast | 2.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (3 of 7) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.0 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 117.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 5.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 230.7 | 225.3 |
| Combat | Points run down | 0.0 | 36.7 |
| Combat | Net points per charged fight, damage counted | +66 | +41 |
| Combat | Net per 100 charger points, damage counted | +21.3 | +11.6 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +66 | +8 |
| Combat | Net points per supported fight / lone fight | - / +66 | - / +8 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 4 of 6 |
| Game | Points lost | 555.0 | 490.7 |
| Game | VP from objectives | 390.0 | 860.0 |
| Game | Lone holders (player turns) | 4.0 | 1.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -470 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1046
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.3 | +165.4 | 0.0 | 157.7 | 31.0 | +208.6 | 0.0 | 166.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +88.7 | 0.0 | 60.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -167.7 | 0.0 | 143.7 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 253.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 12.0 | +259.4 | 464.0 | 36.7 | 2.3 | +99.5 | 516.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -66.7 | 31.7 | 0.0 |
| CAST JOB | 1.3 | +39.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +52.8 | 48.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +44.0 | 0.0 | 44.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +25.4 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.0 | +20.2 | 0.0 | 287.3 |
| CHARGE LOSSES | 19.3 | -534.7 | 0.0 | 426.0 | 20.3 | -877.2 | 0.0 | 492.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 22.0 | 0.0 | 2.7 | +0.0 | 269.0 | 273.7 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.0 | +0.0 | 0.0 | 144.7 | 13.3 | +0.0 | 0.0 | 24.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 143.7 |
| CONVEYANCE SEARCH | 1.3 | +289.5 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.3 | -522.6 | 0.0 | 327.7 | 3.7 | -95.6 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.2 | 0.0 | 143.7 |
| DEPLOY BY FIGURES | 8.7 | -2.7 | 0.0 | 0.0 | 8.0 | -36.7 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +2.3 | 28.0 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +4.2 | 22.0 | 0.0 | 4.0 | +38.6 | 332.7 | 273.7 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 4.3 | +2.4 | 332.7 | 417.3 |
| FALLS SHORT | 11.3 | +137.8 | 0.0 | 100.7 | 15.7 | +142.9 | 0.0 | 246.0 |
| FEATURE BUFFS | 6.0 | +82.5 | 0.0 | 54.0 | 2.7 | +33.2 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.7 | +152.8 | 135.0 | 287.3 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 28.3 | 0.0 |
| FIVE ACTION | 92.0 | +3929.9 | 1458.0 | 1187.3 | 117.3 | +8875.7 | 2919.7 | 1142.7 |
| FLANK NOT WEIGHED | 13.7 | +0.0 | 0.0 | 125.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +220.4 | 0.0 | 0.0 | 0.7 | +101.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +12.1 | 22.0 | 0.0 | 5.0 | +399.2 | 360.7 | 417.3 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 108.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -4.5 | 0.0 | 0.0 | 1.0 | -0.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -18.9 | 31.7 | 143.7 |
| GOAL WALK | 10.0 | +725.4 | 0.0 | 88.7 | 20.7 | +2875.1 | 0.0 | 51.3 |
| GUN FIGURES | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 3.0 | +136.4 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | - | - | - | - | 1.0 | -0.4 | 63.3 | 143.7 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 310.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 34.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 219.3 | 7.7 | +0.0 | 0.0 | 253.3 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 54.0 | - | - | - | - |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -44.0 | 0.0 | 56.7 | 5.3 | -116.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 63.3 | 5.3 | +0.0 | 0.0 | 90.7 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.3 | +1350.0 | 0.0 | 700.7 | 67.0 | +1647.8 | 0.0 | 677.3 |
| HIS SHOTS BY HIS RUN | 38.0 | +485.9 | 0.0 | 544.3 | 40.7 | +511.2 | 0.0 | 584.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +5.9 | 0.0 | 287.3 |
| HOLD ODDS | 21.0 | +0.0 | 0.0 | 220.7 | 26.0 | +0.0 | 0.0 | 121.7 |
| HOLDER ASSIGNMENT | 8.7 | +740.6 | 0.0 | 83.3 | 16.7 | +1286.5 | 0.0 | 73.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -12.1 | 22.0 | 0.0 | 4.7 | -183.3 | 360.7 | 417.3 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +20.4 | 0.0 | 0.0 |
| IDLE COST | 8.0 | -69.6 | 0.0 | 34.7 | 14.0 | -193.6 | 0.0 | 117.0 |
| KEEP FALLS | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 56.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +61.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 143.7 | 103.3 | 2.7 | +0.0 | 110.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +0.7 | 90.3 | 208.7 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 2.0 | +9.7 | 0.0 | 22.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | -10.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +114.6 | 0.0 | 27.0 | 3.3 | +44.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.9 | 0.0 | 0.0 | 2.3 | +241.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +145.5 | 0.0 | 27.0 | 0.3 | +15.6 | 0.0 | 126.7 |
| MISSILES NEXT TURN | 5.0 | +95.0 | 0.0 | 27.0 | 0.7 | +15.5 | 0.0 | 126.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +209.7 | 0.0 | 60.7 | 3.3 | +269.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEAR WALKS ONLY | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +365.6 | 0.0 | 60.7 | 11.3 | +442.3 | 0.0 | 49.7 |
| NEXT CHARGE BY LIST | 2.0 | +116.9 | 0.0 | 60.7 | 3.3 | +246.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.3 | +0.9 | 0.0 | 0.0 | 5.7 | +136.0 | 309.0 | 482.3 |
| NO DOUBLE ROUNDS | - | - | - | - | 4.7 | -164.0 | 360.7 | 417.3 |
| NO LATE CUT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -191.7 | 0.0 | 54.0 | 4.7 | -77.6 | 103.3 | 24.0 |
| OGRE LOADER SECOND SHOT | 5.0 | +25.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +76.9 | 0.0 | 143.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 1.7 | -10.4 | 0.0 | 17.3 | 7.0 | -157.1 | 0.0 | 93.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +226.4 | 0.0 | 287.3 |
| ONE OBJECTIVE FORMULA | 6.3 | +211.9 | 0.0 | 55.0 | 7.3 | +160.6 | 0.0 | 24.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -12.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +19.3 | 0.0 | 65.0 |
| OPENS UP IN FULL | - | - | - | - | 4.0 | +79.9 | 272.3 | 417.3 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +4.9 | 63.7 | 65.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +5.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.0 | +977.3 | 589.3 | 809.7 | 53.0 | +854.4 | 1156.3 | 854.7 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +36.9 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -225.2 | 0.0 | 60.7 | 8.0 | -189.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 60.7 | - | - | - | - |
| QUARTER ODDS | 16.3 | +1108.5 | 209.3 | 63.3 | 21.3 | +2496.9 | 68.3 | 90.7 |
| RANDOM MOVE BY FIGURES | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +14.4 | 0.0 | 44.0 |
| REDIRECT COUNTER | 5.0 | +91.8 | 0.0 | 55.3 | 2.0 | +50.1 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +23.7 | 0.0 | 90.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +53.9 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -8.8 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +79.0 | 0.0 | 70.0 |
| RISK BY ARC | 0.3 | -1.7 | 22.0 | 0.0 | 4.0 | +45.8 | 360.7 | 352.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -28.3 | 146.7 | 352.3 |
| RUN DOWN | - | - | - | - | 3.7 | -8.4 | 183.3 | 417.3 |
| SCOUT BY DROPS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.2 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -134.4 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 1.0 | +74.8 | 148.7 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.7 | -271.8 | 0.0 | 187.3 |
| SET UP BY THE SET | - | - | - | - | 4.3 | +139.6 | 0.0 | 331.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +15.4 | 0.0 | 22.0 |
| SET-UP ANY TARGET | 0.3 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.3 | +0.0 | 0.0 | 243.3 | 13.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +14.8 | 0.0 | 0.0 | 0.7 | +4.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -18.5 | 77.3 | 0.0 |
| SHOT RISK POINTS | 28.3 | -134.5 | 0.0 | 422.0 | 31.0 | -298.1 | 0.0 | 677.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +850.2 | 0.0 | 243.3 | 28.3 | +489.3 | 0.0 | 117.7 |
| SPELL SETS UP CHARGE | 0.3 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 91.3 | 7.7 | +0.0 | 0.0 | 93.7 |
| STANDS FOR A REASON | 0.7 | +0.0 | 48.0 | 0.0 | 7.3 | +0.0 | 516.7 | 0.0 |
| STANDS STILL | 49.7 | +0.0 | 1436.0 | 827.3 | 48.3 | +0.0 | 2559.0 | 0.0 |
| STAY WORTH | 32.7 | -285.1 | 1134.7 | 346.7 | 40.0 | +400.7 | 2211.7 | 117.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +170.9 | 38.3 | 273.7 |
| STRONG ENOUGH TO HOLD | 0.7 | -3.2 | 0.0 | 56.7 | 0.3 | -2.3 | 0.0 | 0.0 |
| SUPPORT ADDS | 11.7 | +918.1 | 0.0 | 95.3 | 1.7 | +43.4 | 0.0 | 23.3 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 27.0 | 65.0 |
| SUPPORT WORKED OUT | 11.7 | +918.1 | 0.0 | 95.3 | 1.7 | +43.4 | 0.0 | 23.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 2.3 | +197.9 | 118.3 | 208.7 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 28.3 | 75.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 23.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 557.0 | 54.0 | +0.0 | 0.0 | 362.7 |
| TIED UP BY THE SUM | 0.3 | +26.0 | 22.0 | 0.0 | 2.0 | +187.4 | 140.7 | 130.0 |
| TIME ON OUR SIDE | 22.0 | +256.7 | 0.0 | 577.3 | 23.3 | +185.2 | 56.7 | 48.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 2.0 | +0.0 | 253.3 | 206.7 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +11.2 | 63.3 | 143.7 |
| WHOLE FIGHT DANGER | 3.7 | -293.2 | 0.0 | 98.0 | 3.7 | -118.4 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 5.0 | +1231.6 | 482.3 | 169.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +38.7 | 0.0 | 0.0 | 1.7 | +43.9 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 145 | 145 | 99 | 33.00 | +1567 | +15.8 |
| HIS SHOT LIST | 346 | 337 | 71 | 23.67 | +726 | +10.2 |
| HOLDER ASSIGNMENT | 76 | 76 | 68 | 22.67 | +3373 | +49.6 |
| DEPLOY BY FIGURES | 50 | 50 | 35 | 11.67 | +596 | +17.0 |
| HIS SHOTS BY HIS RUN | 236 | 225 | 34 | 11.33 | +538 | +15.8 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -808 | -28.9 |
| GOAL WALK | 92 | 91 | 27 | 9.00 | +1474 | +54.6 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +67 | +3.2 |
| FIVE ACTION | 628 | 611 | 19 | 6.33 | +935 | +49.2 |
| SHOT RISK POINTS | 178 | 167 | 19 | 6.33 | +180 | +9.5 |
| PROMISE BY ITS OWN SUM | 45 | 45 | 17 | 5.67 | -1244 | -73.2 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 136 | 118 | 16 | 5.33 | +28 | +1.8 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 26 | 24 | 15 | 5.00 | +48 | +3.2 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +76 | +5.1 |
| SUPPORT ADDS | 40 | 37 | 15 | 5.00 | +643 | +42.8 |
| SUPPORT WORKED OUT | 40 | 37 | 15 | 5.00 | +643 | +42.8 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 43 | 43 | 10 | 3.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 15 | 10 | 3.33 | +237 | +23.7 |
| CHARGE LOSSES | 119 | 111 | 9 | 3.00 | +263 | +29.2 |
| NO CHAFF EDGES | 18 | 15 | 9 | 3.00 | +253 | +28.1 |
| QUARTER ODDS | 113 | 110 | 9 | 3.00 | +424 | +47.1 |
| NEXT CHARGE BY LIST | 16 | 13 | 7 | 2.33 | +187 | +26.7 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 16 | 12 | 6 | 2.00 | +445 | +74.2 |
| MEETS IN TIME | 17 | 17 | 6 | 2.00 | +366 | +61.0 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +237 | +39.5 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +619 | +123.7 |
| STAY WORTH | 218 | 193 | 5 | 1.67 | +18 | +3.7 |
| CHARGE NOW FIRST | 9 | 9 | 4 | 1.33 | -124 | -30.9 |
| COVER ONCE | 39 | 19 | 4 | 1.33 | +171 | +42.7 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +966 | +241.4 |
| IDLE COST | 66 | 34 | 4 | 1.33 | +47 | +11.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +184 | +46.0 |
| MISSILES IN THE MOVE | 13 | 8 | 4 | 1.33 | +143 | +35.8 |
| ONE OBJECTIVE FORMULA | 41 | 33 | 4 | 1.33 | +151 | +37.8 |
| REDIRECT COUNTER | 21 | 14 | 4 | 1.33 | +58 | +14.6 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 13 | 13 | 4 | 1.33 | +100 | +25.0 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +160 | +40.1 |
| FALLS SHORT | 81 | 64 | 3 | 1.00 | +16 | +5.4 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| OPENS UP IN FULL | 12 | 9 | 3 | 1.00 | +32 | +10.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +224 | +74.8 |
| SHOTS IN THE MOVE | 135 | 91 | 3 | 1.00 | +593 | +197.8 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +112 | +37.3 |
| TIED UP BY THE SUM | 7 | 4 | 3 | 1.00 | +32 | +10.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +0 | +0.2 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +67 | +33.3 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +76 | +38.1 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 26 | 26 | 2 | 0.67 | +24 | +12.0 |
| FIGHT TO THE END | 5 | 3 | 2 | 0.67 | +91 | +45.6 |
| GUN MASK | 9 | 9 | 2 | 0.67 | +188 | +94.0 |
| HIS MOVE AND SHOT | 27 | 26 | 2 | 0.67 | +7 | +3.7 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +8 | +3.8 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +91 | +45.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +16 | +7.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +605 | +302.5 |
| RISK BY ARC | 13 | 9 | 2 | 0.67 | +24 | +11.9 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 28 | 28 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -7 | -3.3 |
| THE FIGHT MOVES | 7 | 5 | 2 | 0.67 | +335 | +167.6 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -200 | -200.3 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 1 | 0.33 | +51 | +50.7 |
| EXACT ROUND | 13 | 10 | 1 | 0.33 | +8 | +8.3 |
| HUNT IN PAIRS | 1 | 1 | 1 | 0.33 | +61 | +61.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +59 | +58.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +34 | +34.0 |
| MISSILES NEXT TURN | 17 | 13 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 56 | 54 | 1 | 0.33 | +62 | +62.3 |
| NO DOUBLE ROUNDS | 14 | 10 | 1 | 0.33 | +150 | +150.4 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +51 | +50.7 |
| ONE FIGHT FORMULA | 26 | 11 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -38 | -37.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +8 | +8.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -12 | -11.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +111 | +110.7 |
| RANDOM MOVE BY FIGURES | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +35 | +35.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 1 | 0.33 | +2 | +1.5 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 27 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 15 | 15 | 1 | 0.33 | +0 | +0.1 |
| BACKS UP THE FIGHT | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 79 | 79 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 11 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 141 | 141 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | not checked | - | - | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 9 | 0 | 0.00 | - | - |
| SCOUT BY DROPS | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 92 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 40 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 24 | 0 | 0.00 | - | - |
| STANDS STILL | 294 | 289 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 22 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 294 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 12 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.00 | 30.2 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 2.33 | 73.2 |
| ARMY TABLE | rule | 1.67 | 1.67 | 50.4 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 30.9 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 9.4 |
| SUPPORT NARROWED | rule | - | 0.67 | 3.3 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 200.3 |
| CHAFF PASSED | rule | - | 0.33 | 1.1 |
| FALLBACK | gate | - | 0.33 | 38.9 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.33 | 1.6 |
| NO REASON | gate | - | 0.33 | 4.6 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 37.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 11.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 10.7 |

### Plans: nw22-19bea9b-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 42 | 22 | 52% |
| Mine | move | 25.7 | 90% | 1275 | 0 | 0% |
| Mine | shoot | 14.0 | 60% | 794 | 955 | 120% |
| Opponent | charge | 3.7 | 45% | 684 | 237 | 35% |
| Opponent | join | 0.3 | 100% | 0 | 0 | - |
| Opponent | move | 38.7 | 95% | 2925 | 0 | 0% |
| Opponent | shoot | 10.0 | 60% | 439 | 617 | 141% |
| Opponent | support | 0.3 | 100% | 12 | 0 | 0% |

### Battle groups: nw22-19bea9b-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.0 | 20% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 62 (7) | 62 | 0 | 11 | 43% | 2.0 | 0 (1) | 82 (4) | 0 (1) | 0 (1) | 70 (5) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 0 (5) | 0 | 0 | 58 | 100% | - | - | 0 (1) | 0 (4) | 0 (3) | 0 (2) |
| Mine | Hammer | 9 | 36 (9) | 19 | 18 | 36 | 22% | 2.0 | 0 (1) | 41 (6) | 43 (2) | 46 (5) | 22 (4) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 8 | 6 (8) | 6 | 0 | 19 | 0% | 1.0 | 9 (5) | 0 (2) | 0 (1) | 15 (3) | 0 (5) |
| Mine | Wizard | 5 | 72 (5) | 72 | 0 | 0 | 40% | 4.7 | 0 (3) | 34 (1) | 331 (1) | 0 (2) | 118 (3) |
| Opponent | Chaff | 5 | 26 (5) | 0 | 26 | 40 | 20% | 1.0 | 62 (2) | 0 (2) | 0 (1) | 26 (5) | - |
| Opponent | Character | 8 | 24 (8) | 24 | 0 | 44 | 62% | 2.3 | 46 (3) | 0 (3) | 21 (2) | 27 (5) | 19 (3) |
| Opponent | Clean-up | 3 | 24 (3) | 0 | 24 | 28 | 100% | - | 33 (2) | 0 (1) | - | 33 (2) | 0 (1) |
| Opponent | Fast Hammer | 7 | 23 (7) | 21 | 2 | 14 | 86% | 2.0 | 0 (3) | 39 (4) | - | 36 (3) | 12 (4) |
| Opponent | Holder | 10 | 80 (10) | 25 | 55 | 10 | 0% | 1.6 | 34 (3) | 32 (3) | 172 (4) | 51 (5) | 121 (5) |
| Opponent | Shooter | 1 | 106 (1) | 0 | 106 | 0 | 0% | 3.0 | - | 106 (1) | - | - | 106 (1) |
| Opponent | War machine | 3 | 83 (3) | 83 | 0 | 0 | 0% | 1.0 | 83 (3) | - | - | 0 (2) | 248 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: nw22-19bea9b-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 2 | 366 | 33 | 0.5 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| **Mine** | all armies | 3 | 268 | 22 | 0.3 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| Opponent | Empire of Man | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 2 | 98 | 338 | 3.0 | 1.0 | 113 | 104 | +8 | 4 of 6 | 3 of 6 | - | +8 |
| **Opponent** | all armies | 3 | 168 | 225 | 2.0 | 1.0 | 113 | 104 | +8 | 4 of 6 | 3 of 6 | - | +8 |

### Effective charges: nw22-19bea9b-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net +0) | 0 | 0 | 1 (net +170) | 0 | 1 (net +81) | 3 | 0% (0 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | All fights | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Opponent | Long shot (under 50%) | 1 | 431 | 272 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 431 | 170 | +170 | 234 | 0 | +234 | +54.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 81 | +81 | 124 | 0 | +124 | +63.3 |
| Opponent | No odds | 3 | 355 | 285 | -67 | 172 | 209 | -37 | -10.4 |
| Opponent | All fights | 6 | 354 | 230 | +8 | 145 | 104 | +41 | +11.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p14 | move | 19 | 3 (16%) | 2 (11%) | 1 (5%) | 15 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

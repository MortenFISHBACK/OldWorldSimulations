# Doctrine scorecard: ss-mine-06f55ce-p3

### Scorecard: ss-mine-06f55ce-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0126 | 6 | 1 | Opponent | no | 16 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 10 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 255 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 9 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 731 |
| L0516 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 1258 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 108 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | 6 | 2 | 3 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0709 | 1 | 1 | Opponent | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 3 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 5 | 6 | 2 | 1 | 0 | 0 | 0 | 717 |
| L0831 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 723 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 2 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 1 | 0 | 0 | 564 |
| L1030 | 4 | 1 | Mine | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 2 | 4 | 2 | 1 | 1 | 0 | 0 | 475 |
| L1232 | 2 | 1 | Mine | - | - | 6 | 1 | 0 | 1 | 0 | 0 | 503 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 6 | 2 | 2 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | yes | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 1 | - | 0 | 3 | 2 | 0 | 0 | 250 |
| L1422 | 6 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 376 |
| L1633 | 1 | 1 | Mine | yes | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 2 | 1 | 6 | 3 | 0 | 0 | 0 | 163 |
| L1731 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 322 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 3 | 4 | 0 | 1 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 2 | 0 | 0 | 461 |
| L1932 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 6 | 1 | 5 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 2 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 208 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 414 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 3 | 1 | 5 | 1 | 3 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 11 | 4 | 3 | 0 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 28% | 3.3 | 2.9 | 2.7 | 0.8 | 0.4 | 0.0 | 0.0 | 309.1 |
| **Average** | | | Opponent | 19% | 3.8 | 2.5 | 2.8 | 1.9 | 0.6 | 0.0 | 0.0 | 183.5 |

### KPIs: ss-mine-06f55ce-p3

Rules off - Opponent only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (41 of 178) | 8% (14 of 167) | 16% (55 of 345) |
| Winner chose to follow up after the loser gave ground |  | 98% (64 of 65); on the table 98% | 98% (48 of 49); on the table 100% | 98% (112 of 114); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (10 of 12); on the table 83% | 75% (15 of 20); on the table 80% | 78% (25 of 32); on the table 81% |
| Winner chose to pursue after the loser fled |  | 78% (14 of 18); on the table 78% | 64% (25 of 39); on the table 69% | 68% (39 of 57); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 93% (88 of 95); on the table 93% | 81% (88 of 108); on the table 85% | 87% (176 of 203); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 31% (106 of 342) | 38% (72 of 192) | 33% (178 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (106 of 229) | 48% (72 of 149) | 47% (178 of 378) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 29% (7 of 24) | 47% (25 of 53) | 42% (32 of 77) |
| Points that never fought | lower | 32% (22306 of 68801) | 40% (28840 of 71990) | 36% (51146 of 140791) |
|   infantry points that never fought | lower | 33% (4732 of 14174) | 59% (8377 of 14220) | 46% (13109 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (155 of 272) | 59% (167 of 285) | 58% (322 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.8 uses a game | 88% (21 of 24); 2.2 uses a game | 90% (44 of 49); 2.0 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.4 uses a game | 17% (1 of 6); 0.1 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 70% (14 of 20); 0.4 uses a game | 36% (5 of 14); 0.1 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31489 of 59391) | 51% (32714 of 64043) | 52% (64203 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (23%) | 1.1 (32%) | 2.6 (26%) |
| MARCHED: its unit marched | 1.4 (21%) | 0.8 (23%) | 2.2 (22%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.9 (13%) | 0.6 (18%) | 1.4 (15%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (5%) | 0.2 (3%) |
| GONE: slain | 2.1 (32%) | 0.4 (13%) | 2.5 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (5%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.1 | 1.8 | 4.9 | 0.8 | 1.1 |
| not cast | 4.2 | 1.5 | 4.3 | 9.9 | 2.4 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 0.9 (62%) | 0.3 (7%) | 2.6 (26%) | 0.4 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (22%) | 0.5 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.0 (2%) | 0.5 (11%) | 1.4 (15%) | 0.3 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.0 (0%) | 0.3 (8%) | 0.2 (3%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (31%) | 0.3 (19%) | 1.3 (31%) | 2.5 (26%) | 0.4 (16%) | 2.4 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.2 (5%) | 0.4 (4%) | 0.2 (8%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (6%) | 0.0 (1%) | 0.1 (1%) | 0.5 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (51%) | 0.2 (11%) | 1.5 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.6 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 66% (25 of 38) | 68% (13 of 19) | 67% (38 of 57) |
| the unit moved after it | 64% (16 of 25) | 62% (8 of 13) | 63% (24 of 38) |
| it charged on its next turn | 8% (2 of 25) | 8% (1 of 13) | 8% (3 of 38) |
| the enemy charged it first | 12% (3 of 25) | 8% (1 of 13) | 11% (4 of 38) |
| it fought by the end of its next turn | 4% (1 of 25) | 0% (0 of 13) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 36% (9 of 25) | 23% (3 of 13) | 32% (12 of 38) |
| none of these (no charge, no fight, no charge escaped) | 40% (10 of 25) | 62% (8 of 13) | 47% (18 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (481 of 756) | 62% (389 of 624) | 63% (870 of 1380) |
|   cavalry | 51% (32 of 63) | 66% (77 of 116) | 61% (109 of 179) |
|   character | 57% (51 of 90) | 29% (37 of 128) | 40% (88 of 218) |
|   chariot | 48% (46 of 96) | 72% (21 of 29) | 54% (67 of 125) |
|   infantry | 54% (120 of 221) | 71% (185 of 262) | 63% (305 of 483) |
|   monster | 42% (13 of 31) | 20% (1 of 5) | 39% (14 of 36) |
|   war machine | 86% (219 of 255) | 81% (68 of 84) | 85% (287 of 339) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (29%) | 1.7 (26%) | 3.9 (27%) |
| CHARGED: it charged | 1.2 (16%) | 1.5 (23%) | 2.8 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.4 (6%) | 1.1 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.2 (16%) | 1.0 (15%) | 2.2 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.3 (5%) | 0.6 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 1.2 (18%) | 2.5 (17%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (3%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.2 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.1 | 82% | 6.6 pts | 31 pts |
| character | 3.0 | 0.8 | 81% | 6.5 pts | 20 pts |
| chariot | 1.9 | 1.5 | 57% | 23.2 pts | 43 pts |
| infantry | 13.3 | 3.8 | 79% | 8.2 pts | 109 pts |
| monster | 0.4 | 0.1 | 81% | 11.1 pts | 5 pts |
| war machine | 8.3 | 7.4 | 62% | 26.0 pts | 217 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.1 | 4.7 |
| Charges that made contact a game | 3.1 | 3.8 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.52 contact (27 units) | 0.75 declared, 0.55 contact (20 units) | 0.70 declared, 0.53 contact (47 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.50 contact (4 units) | 0.78 declared, 0.67 contact (9 units) | 0.77 declared, 0.62 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.44 contact (219 units) | 0.61 declared, 0.45 contact (269 units) | 0.60 declared, 0.44 contact (488 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (40 of 77) | 47% (7 of 15) | 60% (6 of 10) | 52% (53 of 102) |
| Character in a unit | 82% (27 of 33) | 71% (12 of 17) | 50% (3 of 6) | 75% (42 of 56) |
| Character on its own | 84% (37 of 44) | 44% (17 of 39) | 29% (20 of 69) | 49% (74 of 152) |
| Chariot | 73% (8 of 11) | 67% (8 of 12) | - | 70% (16 of 23) |
| Infantry | 64% (45 of 70) | 48% (20 of 42) | 20% (1 of 5) | 56% (66 of 117) |
| Monster | 47% (16 of 34) | 86% (6 of 7) | - | 54% (22 of 41) |
| Monstrous | 80% (8 of 10) | 73% (8 of 11) | - | 76% (16 of 21) |
| War Machines | 74% (32 of 43) | 50% (1 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 24% (23 of 96) | 39% | 73% (16 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (10 of 10); on the table 100% | 47% (17 of 36) | 40% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 57% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 69% (9 of 13); on the table 85% | 53% (16 of 30) | 36% | 66% (39 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 82% (14 of 17); on the table 82% | 35% (67 of 192) | 52% | 53% (39 of 74) | 78% (14 of 18); 5.6 uses a game | 25% (1 of 4); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 91% (10 of 11); on the table 91% | 36% (15 of 42) | 37% | 59% (32 of 54) | 100% (9 of 9); 5.1 uses a game | 42% (5 of 12); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 67% (4 of 6); on the table 67% | - | 44% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 4% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 15% | 43% (3 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (10 of 10); on the table 100% | 17% (2 of 12) | 7% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 66% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 90% (19 of 21); on the table 90% | 17% (1 of 6) | 30% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (20 of 22); on the table 91% | 33% (18 of 54) | 29% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 81% (43 of 53); on the table 85% | 43% (13 of 30) | 26% | 54% (52 of 96) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 81% (13 of 16); on the table 81% | 8% (1 of 12) | 38% | 68% (42 of 62) | 91% (10 of 11); 5.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ss-mine-06f55ce-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (38) | 41% (34) | 45% (72) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.69 | 1.42 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.08 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.44 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.19 | 1.06 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.64 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.06 | 5.53 | 10.58 |

### Quality by phase: ss-mine-06f55ce-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 57% (73 of 127) | 49% (77 of 156) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (161 of 381) | 56% (142 of 253) |
| Strategy | Close-in objectives charged next turn | 12% (21 of 175) | 16% (41 of 254) |
| Strategy | Support requests answered (helper made contact too) | 22% (2 of 9) | 57% (12 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (5 of 8) | 86% (6 of 7) |
| Strategy | Joined characters whose unit fought | 51% (19 of 37) | 48% (21 of 44) |
| Strategy | Lone characters that fought | 70% (69 of 98) | 74% (67 of 90) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 0.8 | 1.9 |
| Movement | Points that never moved of their own | 309.1 | 183.5 |
| Movement | Fights charged into per game | 2.9 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 96, net +19 | 14 of 98, net +157 |
| Movement | Charges with odds: sweet spot (55-75%) | 25 of 96, net +82 | 17 of 98, net +84 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 96, net +74 | 10 of 98, net +101 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 96, net +61 | 33 of 98, net +148 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (122 of 285) | 48% (182 of 383) |
| Shooting | Points destroyed by shooting units | 52.2 | 40.1 |
| Shooting | War machine shots | 6.1 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (121 of 219) | 41% (33 of 81) |
| Shooting | Points destroyed by war machines | 74.8 | 38.8 |
| Magic | Magic missiles cast | 2.1 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (27 of 74) | 36% (18 of 50) |
| Magic | Wounds caused by magic missiles | 3.5 | 2.2 |
| Magic | Wounds caused by other spells | 0.8 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 103.3 | 88.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.2 / 0.4 / 0.2 | 2.0 / 0.2 / 0.4 / 0.3 |
| Combat | Points destroyed in combat | 283.0 | 409.9 |
| Combat | Points run down | 33.0 | 133.7 |
| Combat | Net points per charged fight, damage counted | +51 | +112 |
| Combat | Net per 100 charger points, damage counted | +19.7 | +39.9 |
| Combat | First round won (charged fights) | 72% | 79% |
| Combat | Net points per charged fight | +54 | +121 |
| Combat | Net points per supported fight / lone fight | +162 / +43 | +155 / +115 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 104 | 44 of 112 |
| Game | Points lost | 838.8 | 643.1 |
| Game | VP from objectives | 508.1 | 576.1 |
| Game | Lone holders (player turns) | 3.3 | 3.8 |

- Mine won / drew / lost: 10 / 9 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -264 VP
- The side that went first won 12 of 27 games with a winner
- Points traded per game (both sides' losses): 1482
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-mine-06f55ce-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.3 | -111.5 | 144.0 | 123.8 | 3.9 | -118.4 | 144.1 | 58.1 |
| ALREADY CARRIED | 0.1 | +0.0 | 10.3 | 2.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 19.0 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.6 | +3.0 | 0.0 | 43.0 | 0.6 | +3.8 | 0.0 | 16.3 |
| BEST FACING | 0.5 | +4.5 | 0.0 | 22.4 | 0.4 | +14.0 | 0.0 | 38.4 |
| BEST FIRST | 1.2 | +53.9 | 45.8 | 45.7 | 1.0 | +75.1 | 48.9 | 39.0 |
| BEST OVERALL | 0.3 | +24.0 | 0.0 | 26.4 | 0.2 | +13.6 | 0.0 | 0.0 |
| BEST PREY | 0.7 | +35.7 | 5.1 | 34.6 | 0.7 | +29.4 | 17.6 | 12.3 |
| BEST PRIZE | - | - | - | - | 0.0 | -3.5 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -0.7 | 0.0 | 42.1 | 0.2 | -0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +7.3 | 0.0 | 0.0 | 0.4 | +8.5 | 0.0 | 4.8 |
| BLOWS WHERE AIMED | 0.2 | -16.6 | 9.4 | 20.8 | 0.3 | -38.1 | 66.7 | 3.1 |
| BOMBING RUN | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 48.8 | 21.9 | 0.1 | +0.0 | 12.1 | 3.5 |
| CANNON PLANNED TARGET | 5.4 | +212.7 | 360.4 | 115.0 | 1.5 | +80.0 | 119.2 | 38.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 2.5 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -6.3 | 9.3 | 10.6 | 0.2 | -0.1 | 43.3 | 0.0 |
| CAST JOB | 1.1 | +46.7 | 107.4 | 39.8 | 0.8 | +25.0 | 27.4 | 22.8 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +8.6 | 0.0 | 10.3 | 0.0 | +0.2 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 40.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.9 | +37.0 | 0.0 | 21.9 | 1.5 | +79.6 | 0.0 | 42.0 |
| CHAFF PASSED | 0.1 | -0.3 | 0.0 | 0.0 | 0.3 | -1.8 | 16.2 | 3.7 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 152.7 | 92.4 | 2.4 | +0.0 | 322.9 | 52.3 |
| CHARGE NOW WEIGHED | 0.3 | -46.0 | 21.7 | 5.4 | 0.5 | -76.8 | 57.6 | 3.0 |
| CHARGER SLAIN LOST | 0.3 | -13.4 | 44.5 | 6.4 | 0.7 | -13.2 | 99.7 | 15.4 |
| CHARIOT WIZARD CAREFUL | 0.0 | -2.1 | 0.0 | 11.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 17.1 | 0.0 | 0.1 | +0.0 | 7.7 | 3.7 |
| CHEAPEST HOLDER | 0.9 | -15.8 | 58.1 | 23.4 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 3.0 | 62.8 | 0.4 | +0.0 | 54.9 | 43.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +48.1 | 41.9 | 50.8 | 0.3 | +29.8 | 0.0 | 0.0 |
| COVER ONCE | 7.9 | -527.7 | 0.0 | 186.4 | 7.0 | -525.9 | 0.0 | 225.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 7.4 | 7.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +15.7 | 5.4 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +6.1 | 7.7 | 10.6 | 0.3 | +3.5 | 37.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +1.0 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +108.0 | 0.0 | 113.9 | 1.1 | +101.2 | 0.0 | 59.7 |
| FALLBACK BY WORTH | 3.1 | +20.7 | 0.0 | 57.6 | 5.1 | +50.9 | 0.0 | 55.3 |
| FALLS SHORT | 7.1 | +123.4 | 0.0 | 129.7 | - | - | - | - |
| FIGHT LIFT | 0.1 | +2.0 | 26.2 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.9 | 0.0 | 11.2 | 0.0 | +0.0 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 255.4 | 5.4 | +0.0 | 0.0 | 175.7 |
| FOCUS FIRE | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +0.5 | 1.7 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +151.0 | 0.0 | 50.2 | 1.1 | +154.9 | 0.0 | 11.1 |
| FRIENDS SHOTS CHECKED | 0.2 | +2.6 | 0.0 | 1.7 | 0.2 | +19.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.2 | 5.0 | 3.2 | 0.1 | -0.9 | 13.5 | 3.2 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.1 | 3.2 | 0.0 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.9 | +0.0 | 0.0 | 4.9 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 37.3 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 10.1 | 19.0 | 0.4 | +0.0 | 77.8 | 2.6 |
| HILL BY ITS CHANCE | 0.3 | -28.7 | 0.0 | 0.0 | 0.5 | -69.4 | 0.0 | 2.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.8 | -135.6 | 400.1 | 192.3 | 8.7 | -196.3 | 545.8 | 170.7 |
| HORN WORTH | - | - | - | - | 0.1 | +2.5 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.2 | +12.4 | 0.0 | 1.4 | 0.1 | +3.1 | 8.9 | 4.9 |
| HUNT DROPPED | 0.2 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 10.6 | 5.8 |
| HUNT IN PAIRS | 0.4 | +13.5 | 0.0 | 44.3 | 0.7 | +38.4 | 0.0 | 16.2 |
| HUNT KEPT | 0.1 | +4.9 | 4.6 | 3.0 | 0.0 | +0.4 | 5.4 | 2.9 |
| HUNT RESULT | 0.2 | +18.2 | 4.6 | 3.0 | 0.2 | +36.0 | 21.1 | 8.7 |
| HUNT THE GUNS | 0.2 | +86.3 | 11.1 | 0.0 | 0.3 | +73.4 | 27.6 | 5.2 |
| IDLE COST | 3.7 | -55.1 | 0.0 | 53.5 | 19.2 | -348.4 | 0.0 | 228.4 |
| INVITES THE FIGHT | 1.1 | +7.6 | 53.0 | 42.1 | 0.7 | +6.0 | 36.8 | 16.5 |
| JOINT CHARGE PLAN | 0.1 | +6.0 | 1.7 | 1.4 | 0.2 | +5.0 | 0.0 | 3.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.0 | -1.4 | 10.3 | 0.0 |
| KEEP FALLS | 0.2 | +3.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 108.4 | 69.5 | 2.3 | +68.3 | 302.1 | 24.6 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +69.4 | 98.7 | 48.5 | 1.8 | +78.3 | 153.8 | 21.4 |
| KILLS COUNT NEXT TURN | 4.8 | +155.3 | 197.7 | 149.2 | 7.1 | +288.2 | 266.9 | 148.7 |
| LONE CHARACTER SAFE SPOT | 0.6 | +38.4 | 14.9 | 12.2 | 0.4 | +16.2 | 8.7 | 35.1 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 4.5 | 4.3 | 0.3 | +0.0 | 1.7 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +3.8 | 29.6 | 19.3 | 0.5 | +3.0 | 62.1 | 0.0 |
| LOST CHARGE | 2.7 | -37.7 | 89.1 | 107.9 | 2.8 | -37.4 | 68.2 | 51.1 |
| LURE BY WHAT IT DRAWS | 0.2 | -22.5 | 0.0 | 7.6 | 0.2 | -25.7 | 0.0 | 16.1 |
| MAKE SURE TOGETHER | 1.0 | +132.5 | 27.1 | 34.3 | 1.0 | +86.8 | 52.8 | 4.8 |
| MANOEUVRE | 0.1 | +1.5 | 0.0 | 6.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +6.2 | 0.0 | 6.1 | - | - | - | - |
| MARCH CHECK | 0.6 | +27.8 | 0.0 | 41.6 | 0.7 | +30.8 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +7.7 | 2.0 | 0.0 | 0.3 | +15.7 | 14.4 | 5.6 |
| MARCH OVER CASTS | 0.6 | +54.7 | 0.0 | 26.8 | 0.3 | +25.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.6 | +85.3 | 0.0 | 179.5 | 7.1 | +111.4 | 0.0 | 126.5 |
| MISSILES IN THE MOVE | 4.2 | +156.2 | 0.0 | 229.5 | 4.5 | +74.6 | 0.0 | 74.3 |
| MISSILES NEXT TURN | 5.3 | +105.8 | 0.0 | 245.1 | 5.1 | +57.0 | 0.0 | 63.3 |
| MODEL FACING | 0.1 | +31.3 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 9.3 | 13.9 | 0.2 | +0.0 | 20.7 | 0.0 |
| MOVE AND CAST | 0.6 | +30.0 | 0.0 | 5.7 | 0.7 | +25.3 | 0.0 | 26.0 |
| MOVE SPELL IN RANGE | 0.2 | +6.9 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -17.4 | 6.6 | 65.8 | 0.1 | -1.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 10.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +285.0 | 157.0 | 90.8 | 4.8 | +374.9 | 202.9 | 127.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.9 | +570.1 | 0.0 | 194.6 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.0 | +3.7 | 0.0 | 0.0 |
| NO FORCED ADVANCE | 2.0 | +0.0 | 0.0 | 2.8 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -3.7 | 20.5 | 0.0 | 0.3 | -11.3 | 32.9 | 1.1 |
| NOT TURNED | 5.1 | +61.8 | 0.0 | 202.5 | 5.5 | +52.2 | 0.0 | 94.7 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 32.1 | 0.8 | -0.8 | 0.0 | 6.5 |
| OFF BEST | 12.5 | -438.5 | 1.9 | 323.6 | 15.6 | -733.0 | 0.0 | 311.3 |
| ONE FIGHT FORMULA | 7.5 | -143.0 | 36.5 | 263.8 | 8.7 | -197.7 | 36.8 | 176.3 |
| ONE OBJECTIVE FORMULA | 2.4 | -60.5 | 0.0 | 75.9 | 2.2 | -128.2 | 0.0 | 26.1 |
| OPENS A LANE | 0.2 | +2.4 | 29.4 | 0.0 | 0.1 | +0.7 | 0.0 | 4.6 |
| OPENS UP | 0.2 | +19.3 | 8.9 | 12.1 | 0.1 | +7.2 | 5.1 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +7.1 | 23.8 | 6.0 | 0.5 | +11.5 | 57.3 | 28.1 |
| PATHS CROSS | 1.9 | +115.3 | 0.0 | 30.6 | 2.3 | +185.9 | 0.0 | 29.1 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -3.6 | 0.0 | 8.6 | 0.1 | -2.1 | 0.0 | 7.6 |
| PLAN RESULT | 35.3 | +1269.6 | 1310.6 | 1187.1 | 37.4 | +1316.6 | 1674.6 | 869.4 |
| PURSUES BIG PREY | 0.2 | -11.8 | 0.0 | 0.0 | 0.1 | -7.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +6.5 | 0.0 | 0.0 | 1.5 | +19.5 | 0.0 | 61.1 |
| RANDOM MOVER NO PROMISE | 0.2 | -17.5 | 6.6 | 0.0 | 0.4 | -26.7 | 11.7 | 31.7 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -9.6 | 0.0 | 10.0 | 1.2 | -42.7 | 0.0 | 25.8 |
| REDIRECT COUNTER | 1.6 | +118.5 | 0.0 | 33.1 | 3.8 | +290.5 | 0.0 | 68.6 |
| REDIRECT WEIGHED | 0.2 | +7.0 | 10.9 | 0.0 | 0.4 | +0.6 | 6.3 | 12.5 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 10.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +15.4 | 0.0 | 20.7 | 1.0 | +29.3 | 0.0 | 20.4 |
| RESTRAINS TO SHOOT | 0.1 | +5.1 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +75.4 | 179.4 | 91.5 | 2.4 | +71.5 | 319.9 | 47.4 |
| RISK ONCE | 4.3 | +141.8 | 21.4 | 230.4 | 4.8 | +278.7 | 53.0 | 314.0 |
| SAFE SURE CHARGE | 0.1 | -0.7 | 0.8 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.1 | +67.5 | 0.0 | 24.1 | 0.6 | +43.0 | 0.0 | 17.6 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -5.9 | 0.0 | 5.1 | 0.2 | -12.5 | 0.0 | 1.8 |
| SEARCH SPOT | 2.2 | +73.2 | 0.0 | 61.6 | 2.4 | +121.3 | 0.0 | 52.5 |
| SECOND HUNTER | 0.1 | -3.5 | 0.0 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +45.3 | 0.0 | 51.0 | 0.2 | +65.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.1 | +143.0 | 55.1 | 34.3 | 2.0 | +173.4 | 86.2 | 24.1 |
| SET-UP ANY TARGET | 0.3 | +35.3 | 21.1 | 30.4 | 0.1 | +16.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +6.5 | 0.0 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +63.5 | 100.1 | 26.1 | 1.2 | +33.5 | 50.2 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.4 | +0.0 | 83.4 | 14.0 | 0.1 | +0.0 | 29.0 | 3.5 |
| SHOTS IN THE MOVE | 13.4 | +621.2 | 0.0 | 295.0 | 10.3 | +402.9 | 0.0 | 169.6 |
| SPELL SETS UP CHARGE | 0.4 | +68.5 | 21.1 | 30.4 | 0.2 | +35.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +22.7 | 84.6 | 70.2 | 2.3 | +31.5 | 52.6 | 54.9 |
| SPELLS IN THE FIGHT | 0.5 | -7.5 | 60.9 | 30.6 | 0.6 | -4.2 | 137.5 | 0.0 |
| STABLE ROLE | 9.9 | +0.0 | 377.0 | 156.6 | 8.6 | +0.0 | 333.9 | 119.1 |
| STANDS TO CAST | 0.1 | +2.0 | 0.0 | 13.9 | - | - | - | - |
| STOPS | 0.1 | +3.8 | 15.7 | 1.5 | 0.2 | +8.3 | 24.1 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +21.7 | 0.0 | 22.7 | 0.6 | +31.3 | 0.0 | 10.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.4 | -66.8 | 364.6 | 159.7 | 6.3 | -57.5 | 388.5 | 85.0 |
| SUPPORTS | 4.2 | +68.6 | 215.9 | 68.8 | 4.4 | +60.9 | 155.1 | 53.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.1 | 3.3 | 15.1 | 0.1 | -4.2 | 9.4 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.4 | 3.3 | 19.3 | 0.9 | -17.8 | 0.0 | 9.2 |
| THROUGH LINE OF FIRE | 0.1 | +3.0 | 0.0 | 0.0 | 0.1 | +13.2 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 16.6 | +292.1 | 0.0 | 339.3 | - | - | - | - |
| TURN WORTH | 0.4 | -20.5 | 34.5 | 4.5 | 0.3 | -20.3 | 26.8 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +2.5 | 5.9 | 1.2 | 0.7 | +6.1 | 30.7 | 18.1 |
| WAIT AFTER COSTS | 6.3 | -322.1 | 262.2 | 163.2 | 7.5 | -355.6 | 306.2 | 150.0 |
| WALKS TO THE FIGHT | 1.4 | +15.0 | 32.7 | 0.0 | 0.9 | +4.7 | 48.4 | 4.8 |
| WAR ENGINE CHARGES | 0.1 | +14.4 | 4.5 | 0.0 | 0.0 | +1.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 48.2 | 36.9 | 0.2 | +0.0 | 11.6 | 0.0 |
| WEARS DOWN | 0.9 | +41.1 | 68.6 | 39.2 | 1.2 | +44.5 | 205.4 | 26.6 |
| WHO HITS BACK | 0.2 | +13.1 | 0.0 | 15.0 | 0.3 | +22.5 | 0.0 | 11.0 |
| WHOLE FIGHT | 0.2 | +9.6 | 17.9 | 12.2 | 0.3 | +23.0 | 75.5 | 4.1 |
| WHOLE FIGHT GAIN | 0.2 | +11.5 | 29.5 | 0.0 | 0.5 | +31.7 | 71.1 | 2.4 |
| WIDER SPREAD | 2.4 | -5.9 | 185.2 | 65.6 | 2.9 | -7.8 | 400.7 | 29.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 11.0 | 0.0 |

### Rule changes: ss-mine-06f55ce-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1010 | 1010 | 1010 | 28.06 | -42173 | -41.8 |
| SEARCH SPOT | 163 | 163 | 159 | 4.42 | +7004 | +44.1 |
| PATHS CROSS | 154 | 154 | 154 | 4.28 | +10844 | +70.4 |
| MOVE TO CHARGE | 292 | 292 | 152 | 4.22 | +10104 | +66.5 |
| KILLS COUNT NEXT TURN | 430 | 430 | 136 | 3.78 | +3949 | +29.0 |
| SUPPORTS | 313 | 313 | 123 | 3.42 | +1690 | +13.7 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +7531 | +64.4 |
| NEARER NOT NEEDED | 356 | 254 | 107 | 2.97 | +3031 | +28.3 |
| TIME ON OUR SIDE | 598 | 415 | 93 | 2.58 | +153 | +1.6 |
| COVER ONCE | 537 | 301 | 85 | 2.36 | +871 | +10.2 |
| WAIT AFTER COSTS | 496 | 496 | 85 | 2.36 | +1383 | +16.3 |
| SHOTS IN THE MOVE | 855 | 587 | 80 | 2.22 | +3392 | +42.4 |
| FOLLOW UP WEIGHED | 79 | 79 | 79 | 2.19 | +11013 | +139.4 |
| BEST FIRST | 78 | 78 | 78 | 2.17 | +4643 | +59.5 |
| NO FORCED ADVANCE | 72 | 72 | 72 | 2.00 | +773 | +10.7 |
| FALLBACK BY WORTH | 293 | 293 | 67 | 1.86 | +2575 | +38.4 |
| RISK ONCE | 330 | 237 | 65 | 1.81 | +3918 | +60.3 |
| ARTILLERY RE-ROLL WEIGHED | 63 | 63 | 63 | 1.75 | +0 | +0.0 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +3977 | +64.2 |
| ADVANCE WORTH | 331 | 331 | 59 | 1.64 | +1643 | +27.9 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MISSILES IN THE MOVE | 313 | 214 | 55 | 1.53 | +1286 | +23.4 |
| REDIRECT COUNTER | 193 | 101 | 55 | 1.53 | +3525 | +64.1 |
| ONE FIGHT FORMULA | 584 | 359 | 51 | 1.42 | +186 | +3.6 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1610 | +32.9 |
| CHAFF IN THE MOVE | 84 | 81 | 48 | 1.33 | +1527 | +31.8 |
| RISK BY ARC | 181 | 174 | 46 | 1.28 | +1051 | +22.8 |
| MOVE AND CAST | 45 | 45 | 45 | 1.25 | +1992 | +44.3 |
| MARCH CHECK | 46 | 45 | 44 | 1.22 | +2085 | +47.4 |
| CHARGE NOW FIRST | 164 | 164 | 42 | 1.17 | -1437 | -34.2 |
| CANNON PLANNED TARGET | 246 | 246 | 41 | 1.14 | -975 | -23.8 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| KILLS COUNT | 123 | 121 | 38 | 1.06 | +1826 | +48.0 |
| MAX FOR POSITIONING | 457 | 291 | 37 | 1.03 | +191 | +5.2 |
| SET UP TOGETHER | 114 | 99 | 37 | 1.03 | +3090 | +83.5 |
| CAST JOB | 70 | 70 | 36 | 1.00 | +867 | +24.1 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +1908 | +54.5 |
| HARD STAY DROPPED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOOTS FROM THE BEST SPOT | 80 | 80 | 33 | 0.92 | +1121 | +34.0 |
| RANDOM MOVE BY FIGURES | 77 | 77 | 32 | 0.89 | +939 | +29.3 |
| BEST FACING | 31 | 31 | 31 | 0.86 | +665 | +21.5 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +566 | +19.5 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +4093 | +141.1 |
| COMBAT PIVOT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| HONEST WORTH | 592 | 587 | 27 | 0.75 | +149 | +5.5 |
| FALLS SHORT | 257 | 146 | 25 | 0.69 | +16 | +0.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| WALKS TO THE FIGHT | 84 | 84 | 25 | 0.69 | +189 | +7.6 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +1164 | +48.5 |
| KEEPS ITS TARGET | 136 | 135 | 21 | 0.58 | +336 | +16.0 |
| SHOT REPLANNED | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| INVITES THE FIGHT | 65 | 65 | 20 | 0.56 | +138 | +6.9 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +725 | +36.2 |
| MISSILES NEXT TURN | 374 | 253 | 19 | 0.53 | +104 | +5.5 |
| IDLE COST | 824 | 484 | 18 | 0.50 | +158 | +8.8 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| BEST OVERALL | 17 | 17 | 17 | 0.47 | +1352 | +79.5 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -38 | -2.2 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +145 | +8.5 |
| MANOEUVRE | 16 | 16 | 16 | 0.44 | +561 | +35.0 |
| WAR ENGINE JOBS | 35 | 35 | 16 | 0.44 | -521 | -32.6 |
| BEST PREY | 52 | 52 | 15 | 0.42 | +250 | +16.7 |
| HUNT IN PAIRS | 39 | 27 | 15 | 0.42 | +413 | +27.5 |
| MAKE SURE TOGETHER | 70 | 48 | 15 | 0.42 | +1953 | +130.2 |
| PIVOT GUARDS FLANK | 15 | 15 | 15 | 0.42 | -207 | -13.8 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +808 | +57.7 |
| LOST CHARGE | 197 | 197 | 14 | 0.39 | +300 | +21.5 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -76 | -5.8 |
| WHOLE FIGHT GAIN | 23 | 23 | 12 | 0.33 | +363 | +30.2 |
| WEARS DOWN | 78 | 76 | 11 | 0.31 | +514 | +46.8 |
| SUPPORT NARROWED | 456 | 456 | 10 | 0.28 | -103 | -10.3 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -264 | -26.4 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.28 | +583 | +58.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -709 | -78.7 |
| KEEP FALLS | 8 | 8 | 8 | 0.22 | +226 | +28.2 |
| REFUSING RETIRES | 21 | 21 | 8 | 0.22 | -2 | -0.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OPENS UP | 13 | 12 | 7 | 0.19 | +312 | +44.6 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SURE REACH TOGETHER | 44 | 36 | 6 | 0.17 | +54 | +9.1 |
| WHOLE FIGHT | 18 | 17 | 6 | 0.17 | +298 | +49.7 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 5 | 0.14 | -496 | -99.3 |
| ONE OBJECTIVE FORMULA | 165 | 76 | 5 | 0.14 | +94 | +18.9 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 0.11 | +97 | +24.3 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +35 | +8.7 |
| HUNT ADVANCE | 12 | 12 | 4 | 0.11 | +180 | +45.1 |
| OVERRUNS AWAY | 33 | 33 | 4 | 0.11 | +69 | +17.3 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +22 | +5.5 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +205 | +51.2 |
| WAR ENGINE CHARGES | 6 | 6 | 4 | 0.11 | +310 | +77.5 |
| BACKUP TARGETS | 46 | 24 | 3 | 0.08 | +2 | +0.7 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CARRIES OUT SET-UP | 11 | 11 | 3 | 0.08 | -230 | -76.8 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +90 | +30.2 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +1126 | +375.2 |
| STOPS | 11 | 11 | 3 | 0.08 | +166 | +55.5 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +54 | +27.1 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| DEFENSIVE FLOOR | 6 | 6 | 2 | 0.06 | +75 | +37.5 |
| EDGE GIVE GROUND | 14 | 14 | 2 | 0.06 | +58 | +28.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +52 | +25.9 |
| LONG SHOT | 37 | 37 | 2 | 0.06 | +10 | +4.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +221 | +110.7 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +322 | +160.9 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -24 | -11.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -61 | -30.5 |
| TWO OR MORE ARRIVE | 38 | 31 | 2 | 0.06 | +23 | +11.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -125 | -124.8 |
| BLOWS WHERE AIMED | 19 | 16 | 1 | 0.03 | +3 | +2.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +36 | +35.8 |
| HILL BY ITS CHANCE | 28 | 28 | 1 | 0.03 | +30 | +29.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +292 | +291.9 |
| OPENS A LANE | 12 | 7 | 1 | 0.03 | +3 | +2.8 |
| SPELLS IN THE FIGHT | 37 | 37 | 1 | 0.03 | +27 | +26.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 38 | 37 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 31 | 31 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 11 | 11 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 372 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 12 | 12 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 34 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 381 | 381 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2618 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 61 | 61 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 131 | not checked | - | - | - | - |
| STABLE ROLE | 667 | 665 | 0 | 0.00 | - | - |
| TURN WORTH | 25 | 23 | 0 | 0.00 | - | - |
| WIDER SPREAD | 193 | 185 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ss-mine-06f55ce-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 11.08 | 13.89 | 43.1 |
| FALLBACK | gate | 0.56 | 0.67 | 40.9 |
| CHARGE NOW FIRST | rule | 0.61 | 0.56 | 34.2 |
| TURN GATE | gate | 0.50 | 0.61 | 21.5 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.11 | 59.1 |
| WAR ENGINE JOBS | rule | 0.28 | 0.17 | 32.6 |
| PIVOT GUARDS FLANK | rule | 0.28 | 0.14 | 13.8 |
| CHAFF PASSED | rule | 0.08 | 0.22 | 6.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.14 | 26.4 |
| PURSUES BIG PREY | rule | 0.17 | 0.08 | 78.7 |
| SUPPORT NARROWED | rule | 0.22 | 0.03 | 11.4 |
| AFTERMATH BAND | gate | 0.06 | 0.17 | 3.3 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 9.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 42.7 |
| PATHS CROSS | rule | 0.08 | 0.08 | 22.1 |
| NEARER NOT NEEDED | rule | 0.14 | - | 16.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 37.9 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.08 | 124.1 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.03 | 76.8 |
| CHARGE NOW WEIGHED | rule | - | 0.08 | 31.2 |
| FACES THE THREAT | rule | 0.08 | - | 11.0 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 2.3 |
| NO REASON | gate | 0.08 | - | 48.9 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 8.1 |
| SUPPORT REQUEST | gate | 0.03 | 0.06 | 54.3 |
| MARCH ODDS | rule | 0.03 | 0.03 | 6.4 |
| SAFE SURE CHARGE | rule | 0.06 | - | 11.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 10.8 |
| STANDS TO CAST | rule | 0.06 | - | 30.5 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 15.9 |
| BEST PRIZE | rule | - | 0.03 | 124.8 |
| BLOCKED WHEEL | rule | 0.03 | - | 2.1 |
| LONG SHOT | rule | - | 0.03 | 4.5 |
| REFUSING RETIRES | rule | - | 0.03 | 0.7 |
| WHO HITS BACK | rule | - | 0.03 | 4.9 |

### Plans: ss-mine-06f55ce-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 7.3 | 13% | 164 | 176 | 107% |
| Mine | charge | 3.0 | 62% | 207 | 232 | 112% |
| Mine | close in | 4.9 | 27% | 328 | 148 | 45% |
| Mine | hold | 5.9 | 33% | 331 | 0 | 0% |
| Mine | join | 0.5 | 100% | 13 | 0 | 0% |
| Mine | shoot | 8.8 | 64% | 291 | 714 | 246% |
| Mine | support | 4.9 | 90% | 48 | 0 | 0% |
| Opponent | advance | 10.6 | 18% | 199 | 257 | 129% |
| Opponent | charge | 3.5 | 69% | 306 | 463 | 151% |
| Opponent | close in | 7.1 | 21% | 394 | 200 | 51% |
| Opponent | hold | 4.0 | 34% | 289 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 29 | 0 | 0% |
| Opponent | shoot | 5.8 | 53% | 194 | 398 | 205% |
| Opponent | support | 5.9 | 87% | 44 | 0 | 0% |

### Packages: hunt the guns, ss-mine-06f55ce-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 0 | 25% | 25% | 0% | 2.5 | 389 | 82 | 25% | 47 |
| Opponent | 0.3 | 10 | 1 | 44% | 56% | 0% | 2.0 | 278 | 144 | 56% | 73 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 20% | 20% | 0% | 3.0 | 386 | 48 | 20% | 14 |
| Chaos Dwarfs | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 427 | 418 | 100% | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 115 |
| Empire of Man | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 375 | 0 | 0% | 150 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 0% | 33% | 0% | 2.0 | 239 | 71 | 33% | 56 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 198 | 162 | 100% | 9 |
| Warriors of Chaos | 0.3 | 3 | 1 | 100% | 100% | 0% | 2.0 | 366 | 338 | 100% | 68 |
| Wood Elf Realms | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 286 | 81 | 33% | 10 |

### Battle groups: ss-mine-06f55ce-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 35% | 70% | 5% | 0% | 21% | 0% | 0% | 79% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 25% | 79% | 18% | 33% | 14% | 4% | 18% | 61% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-mine-06f55ce-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 129 (1) | 129 | 0 | 0 | 0% | 3.0 | - | 129 (1) | - | 129 (1) | - |
| Mine | Chaff | 34 | 85 (34) | 32 | 52 | 48 | 35% | 2.6 | 101 (21) | 0 (4) | 71 (9) | 96 (24) | 61 (10) |
| Mine | Character | 118 | 39 (118) | 39 | 0 | 45 | 20% | 2.3 | 57 (40) | 36 (54) | 5 (5) | 49 (54) | 36 (45) |
| Mine | Clean-up | 18 | 56 (18) | 23 | 34 | 56 | 17% | 3.1 | 25 (3) | 63 (13) | 52 (2) | 80 (12) | 21 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 35 (44) | 17 | 18 | 50 | 23% | 2.9 | 26 (22) | 32 (14) | 65 (8) | 38 (30) | 31 (14) |
| Mine | Fragile | 3 | 19 (3) | 19 | 0 | 33 | 33% | 4.5 | 19 (3) | - | - | 0 (1) | 29 (2) |
| Mine | Hammer | 52 | 44 (52) | 23 | 20 | 33 | 10% | 2.8 | 35 (14) | 43 (35) | 87 (3) | 34 (36) | 62 (16) |
| Mine | Holder | 25 | 30 (25) | 13 | 17 | 35 | 24% | 3.7 | 17 (9) | 36 (9) | 38 (6) | 55 (13) | 0 (11) |
| Mine | Shooter | 37 | 82 (37) | 55 | 27 | 56 | 3% | 1.9 | 37 (6) | 84 (29) | 184 (2) | 83 (22) | 82 (15) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 42 | 0% | 2.8 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |
| Mine | War machine | 52 | 40 (52) | 40 | 0 | 54 | 2% | 1.1 | 50 (13) | 38 (36) | 23 (3) | 22 (13) | 47 (39) |
| Mine | Wizard | 17 | 14 (17) | 14 | 0 | 54 | 6% | 2.4 | 13 (6) | 24 (8) | 0 (1) | 25 (8) | 9 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 30 (68) | 8 | 23 | 57 | 44% | 2.7 | 41 (29) | 40 (11) | 17 (28) | 31 (48) | 30 (20) |
| Opponent | Character | 102 | 60 (102) | 60 | 0 | 29 | 16% | 2.5 | 41 (37) | 76 (54) | 81 (3) | 61 (55) | 64 (39) |
| Opponent | Clean-up | 11 | 85 (11) | 23 | 63 | 41 | 64% | 2.8 | 0 (4) | 106 (6) | 288 (1) | 71 (6) | 99 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 39 (60) | 27 | 12 | 32 | 28% | 2.7 | 30 (30) | 44 (20) | 56 (10) | 47 (28) | 30 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.5 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 47 (50) | 38 | 9 | 35 | 32% | 2.7 | 20 (17) | 49 (30) | 148 (3) | 50 (30) | 41 (20) |
| Opponent | Holder | 40 | 70 (40) | 21 | 49 | 33 | 32% | 2.7 | 58 (9) | 73 (22) | 80 (9) | 72 (30) | 65 (10) |
| Opponent | Shooter | 27 | 60 (27) | 35 | 25 | 41 | 7% | 1.1 | 56 (6) | 55 (19) | 159 (2) | 87 (16) | 25 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 50% | 5.5 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 82 (17) | 82 | 0 | 42 | 6% | 1.5 | 0 (3) | 123 (10) | 39 (4) | 0 (3) | 96 (14) |
| Opponent | Wizard | 32 | 7 (32) | 7 | 0 | 35 | 19% | 2.5 | 14 (15) | 3 (10) | 0 (2) | 12 (16) | 0 (11) |

### Charged fights: ss-mine-06f55ce-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 25 | 0.5 | 2.0 | 50 | 0 | +50 | 0 of 2 | 2 of 2 | +50 | - |
| Mine | Chaos Dwarfs | 4 | 198 | 498 | 3.5 | 1.2 | 142 | 20 | +122 | 5 of 14 | 12 of 14 | +248 | +101 |
| Mine | Dwarfen Mountain Holds | 3 | 280 | 177 | 2.0 | 1.5 | 89 | 58 | +30 | 0 of 6 | 4 of 6 | +226 | -67 |
| Mine | Empire of Man | 5 | 510 | 71 | 1.6 | 1.1 | 44 | 57 | -13 | 4 of 8 | 4 of 8 | +0 | -14 |
| Mine | Grand Cathay | 5 | 473 | 298 | 3.0 | 1.1 | 99 | 0 | +99 | 3 of 15 | 15 of 15 | +173 | +94 |
| Mine | High Elf Realms | 4 | 275 | 340 | 3.0 | 1.0 | 114 | 65 | +48 | 4 of 12 | 10 of 12 | - | +48 |
| Mine | Kingdom of Bretonnia | 1 | 38 | 884 | 4.0 | 1.2 | 221 | 118 | +103 | 0 of 4 | 2 of 4 | +334 | +26 |
| Mine | Lizardmen | 1 | 144 | 170 | 2.0 | 1.0 | 85 | 70 | +14 | 1 of 2 | 1 of 2 | - | +14 |
| Mine | Ogre Kingdoms | 1 | 427 | 260 | 6.0 | 1.0 | 43 | 6 | +38 | 2 of 6 | 3 of 6 | - | +38 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 200 | 5.0 | 1.0 | 40 | 0 | +40 | 3 of 5 | 3 of 5 | - | +40 |
| Mine | Skaven | 1 | 38 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 436 | 6.0 | 1.1 | 73 | 0 | +73 | 4 of 12 | 7 of 12 | +66 | +73 |
| Mine | Vampire Counts | 2 | 0 | 322 | 5.0 | 1.0 | 64 | 105 | -40 | 2 of 10 | 7 of 10 | - | -40 |
| Mine | Warriors of Chaos | 2 | 0 | 438 | 3.5 | 1.0 | 125 | 78 | +48 | 2 of 7 | 4 of 7 | - | +48 |
| **Mine** | all armies | 36 | 230 | 270 | 2.9 | 1.1 | 94 | 39 | +54 | 30 of 104 | 75 of 104 | +162 | +43 |
| Opponent | Empire of Man | 1 | 618 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 236 | 335 | 1.7 | 1.4 | 201 | 0 | +201 | 1 of 5 | 4 of 5 | +952 | +13 |
| Opponent | High Elf Realms | 3 | 315 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Kingdom of Bretonnia | 2 | 362 | 200 | 1.5 | 1.0 | 133 | 0 | +133 | 1 of 3 | 2 of 3 | - | +133 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 720 | 4.0 | 1.2 | 180 | 0 | +180 | 1 of 4 | 3 of 4 | +199 | +174 |
| Opponent | Skaven | 1 | 615 | 0 | 2.0 | 1.0 | 0 | 18 | -18 | 1 of 2 | 0 of 2 | - | -18 |
| Opponent | Tomb Kings of Khemri | 4 | 151 | 604 | 5.0 | 1.1 | 121 | 23 | +98 | 9 of 20 | 17 of 20 | +177 | +94 |
| Opponent | Vampire Counts | 6 | 68 | 678 | 3.2 | 1.5 | 214 | 51 | +163 | 10 of 19 | 14 of 19 | +120 | +193 |
| Opponent | Warriors of Chaos | 9 | 42 | 698 | 4.2 | 1.2 | 165 | 26 | +139 | 16 of 38 | 34 of 38 | +74 | +151 |
| Opponent | Wood Elf Realms | 6 | 168 | 262 | 3.3 | 1.1 | 78 | 21 | +57 | 5 of 20 | 14 of 20 | +60 | +57 |
| **Opponent** | all armies | 36 | 167 | 457 | 3.1 | 1.2 | 147 | 26 | +121 | 44 of 112 | 89 of 112 | +155 | +115 |

### Effective charges: ss-mine-06f55ce-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 1 (net +60) | 1 (net +40) | 0 | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 14 | 0 | 0 | 5 (net +154) | 5 (net +75) | 1 (net +162) | 2 (net +116) | 1 | 38% (5 of 13) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 0 | 1 (net -60) | 0 | 4 (net +61) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 8 | 3 (net -88) | 0 | 0 | 0 | 1 (net +0) | 4 (net +41) | 0 | 0% (0 of 8) |
| Mine | Grand Cathay | 15 | 0 | 2 (net +394) | 2 (net +0) | 5 (net +28) | 1 (net +72) | 4 (net +68) | 1 | 14% (2 of 14) |
| Mine | High Elf Realms | 12 | 1 (net -115) | 2 (net -91) | 0 | 2 (net +61) | 3 (net +80) | 3 (net +171) | 1 | 0% (0 of 11) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +334) | 0 | 3 (net +26) | 0 | 0 | 0 | 0 | 75% (3 of 4) |
| Mine | Lizardmen | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 2 (net +58) | 1 (net +0) | 0 | 2 (net +72) | 1 | 40% (2 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 12 | 1 (net +60) | 0 | 7 (net +72) | 3 (net +80) | 0 | 1 (net +66) | 0 | 58% (7 of 12) |
| Mine | Vampire Counts | 10 | 0 | 1 (net -407) | 4 (net +61) | 1 (net -529) | 1 (net +80) | 3 (net +69) | 0 | 40% (4 of 10) |
| Mine | Warriors of Chaos | 7 | 2 (net +95) | 0 | 2 (net +171) | 0 | 0 | 3 (net -66) | 0 | 29% (2 of 7) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +0) | 3 (net +335) | 1 (net +0) | 0 | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +231) | 0 | 0 | 2 (net +84) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 3 (net +240) | 1 | 0% (0 of 3) |
| Opponent | Skaven | 2 | 1 (net -35) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 20 | 2 (net +22) | 0 | 2 (net +82) | 2 (net +133) | 3 (net +190) | 9 (net +76) | 2 | 11% (2 of 18) |
| Opponent | Vampire Counts | 19 | 5 (net +224) | 0 | 6 (net +131) | 3 (net +306) | 3 (net +12) | 2 (net +114) | 0 | 32% (6 of 19) |
| Opponent | Warriors of Chaos | 38 | 3 (net +316) | 0 | 6 (net +32) | 10 (net +89) | 2 (net +173) | 16 (net +181) | 1 | 16% (6 of 37) |
| Opponent | Wood Elf Realms | 20 | 2 (net -55) | 1 (net +0) | 2 (net +138) | 2 (net +58) | 1 (net +60) | 2 (net +173) | 10 | 20% (2 of 10) |

### Charged fights, damage counted: ss-mine-06f55ce-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 257 | 269 | +19 | 119 | 65 | +54 | +21.0 |
| Mine | 50-54% | 5 | 363 | 316 | +40 | 292 | 257 | +35 | +9.6 |
| Mine | Effective (55-75%) | 25 | 229 | 221 | +82 | 140 | 44 | +97 | +42.1 |
| Mine | 76-89% | 20 | 268 | 147 | +17 | 73 | 73 | -0 | -0.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 245 | 167 | +61 | 110 | 67 | +43 | +17.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 386 | 81 | +74 | 76 | 9 | +67 | +17.4 |
| Mine | No odds | 8 | 211 | 196 | +73 | 95 | 36 | +59 | +27.9 |
| Mine | All fights | 104 | 261 | 190 | +54 | 116 | 65 | +51 | +19.7 |
| Opponent | Long shot (under 50%) | 14 | 231 | 247 | +157 | 256 | 124 | +132 | +57.0 |
| Opponent | 50-54% | 1 | 109 | 116 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 17 | 295 | 234 | +84 | 147 | 77 | +70 | +23.9 |
| Opponent | 76-89% | 23 | 362 | 175 | +146 | 177 | 48 | +130 | +35.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 287 | 205 | +148 | 181 | 34 | +146 | +51.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 437 | 88 | +101 | 116 | 9 | +107 | +24.5 |
| Opponent | No odds | 14 | 63 | 206 | +49 | 80 | 38 | +42 | +66.5 |
| Opponent | All fights | 112 | 280 | 197 | +121 | 164 | 53 | +112 | +39.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-mine-06f55ce-p3 | move | 369 | 76 (21%) | 61 (17%) | 56 (15%) | 237 (64%) |
| ss-mine-06f55ce-p3 | objective | 429 | 61 (14%) | 49 (11%) | 50 (12%) | 318 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

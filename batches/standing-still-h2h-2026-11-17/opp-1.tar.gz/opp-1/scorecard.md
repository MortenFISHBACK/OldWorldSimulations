# Doctrine scorecard: ss-opp-06f55ce-p1

### Scorecard: ss-opp-06f55ce-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 6 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 5 | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 3 | 7 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | yes | 8 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0135 | 3 | 1 | Opponent | yes | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 1 | 3 | 0 | 0 | 0 | 274 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 6 | 4 | 3 | 2 | 0 | 0 | 0 | 110 |
| L0319 | 1 | 1 | Mine | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 2 | 0 | 0 | 226 |
| L0405 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 6 | 6 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 5 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 1416 |
| L0508 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 596 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 984 |
| L0628 | 4 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 111 |
| L0717 | 3 | 1 | Mine | no | 4 | 2 | 3 | 1 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 7 | 1 | 2 | 0 | 2 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 2 | 3 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 9 | 2 | 4 | 1 | 0 | 0 | 0 | 317 |
| L0930 | 6 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 584 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 1 | - | 1 | 4 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 1 | 0 | 1 | 0 | 0 | 526 |
| L1131 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 0 | 0 | 0 | 479 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 4 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 4 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 3 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 13 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 4 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 3 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 7 | 2 | 3 | 1 | 1 | 0 | 0 | 647 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 3 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 2 | 0 | 0 | 456 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | - | 3 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | yes | 2 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 2 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 38% | 3.0 | 2.5 | 2.1 | 1.4 | 0.2 | 0.0 | 0.0 | 315.8 |
| **Average** | | | Opponent | 21% | 2.2 | 2.7 | 2.4 | 2.1 | 0.6 | 0.0 | 0.0 | 145.2 |

### KPIs: ss-opp-06f55ce-p1

Rules off - Mine only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (46 of 174) | 3% (5 of 170) | 15% (51 of 344) |
| Winner chose to follow up after the loser gave ground |  | 99% (70 of 71); on the table 100% | 95% (42 of 44); on the table 95% | 97% (112 of 115); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 88% (15 of 17); on the table 88% | 89% (24 of 27); on the table 89% |
| Winner chose to pursue after the loser fled |  | 75% (18 of 24); on the table 79% | 79% (37 of 47); on the table 83% | 77% (55 of 71); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 92% (97 of 105); on the table 94% | 87% (94 of 108); on the table 89% | 90% (191 of 213); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 28% (93 of 330) | 33% (69 of 210) | 30% (162 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (93 of 260) | 41% (69 of 169) | 38% (162 of 429) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (20 of 30) | 48% (20 of 42) | 56% (40 of 72) |
| Points that never fought | lower | 42% (29822 of 71484) | 46% (33363 of 71889) | 44% (63185 of 143373) |
|   infantry points that never fought | lower | 53% (8912 of 16863) | 65% (8628 of 13348) | 58% (17540 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (148 of 279) | 64% (189 of 295) | 59% (337 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.2 uses a game | 75% (15 of 20); 1.4 uses a game | 86% (36 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.7 uses a game | 0% (0 of 8); 0.0 uses a game | 42% (10 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28893 of 59666) | 59% (36748 of 62699) | 54% (65641 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.2 (48%) | 1.7 (43%) | 4.9 (46%) |
| MARCHED: its unit marched | 1.0 (16%) | 0.5 (12%) | 1.5 (14%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.4 (11%) | 1.6 (16%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.4 (6%) | 0.7 (18%) | 1.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.4 | 1.3 | 4.5 | 0.6 | 1.3 |
| not cast | 3.6 | 3.0 | 3.4 | 10.5 | 1.7 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.2 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (47%) | 0.3 (9%) | 4.9 (46%) | 0.6 (35%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (14%) | 0.1 (6%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (3%) | 0.2 (7%) | 1.6 (16%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.3 (10%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (15%) | 0.6 (20%) | 0.4 (13%) | 1.1 (11%) | 0.1 (3%) | 2.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.3 (9%) | 0.3 (8%) | 0.3 (3%) | 0.0 (0%) | 1.1 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.1 (1%) | 0.6 (34%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (69%) | 0.3 (9%) | 1.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 65% (26 of 40) | 73% (8 of 11) | 67% (34 of 51) |
| the unit moved after it | 62% (16 of 26) | 88% (7 of 8) | 68% (23 of 34) |
| it charged on its next turn | 4% (1 of 26) | 0% (0 of 8) | 3% (1 of 34) |
| the enemy charged it first | 4% (1 of 26) | 12% (1 of 8) | 6% (2 of 34) |
| it fought by the end of its next turn | 0% (0 of 26) | 12% (1 of 8) | 3% (1 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (5 of 26) | 12% (1 of 8) | 18% (6 of 34) |
| none of these (no charge, no fight, no charge escaped) | 73% (19 of 26) | 75% (6 of 8) | 74% (25 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (598 of 929) | 61% (366 of 602) | 63% (964 of 1531) |
|   cavalry | 63% (47 of 75) | 72% (80 of 111) | 68% (127 of 186) |
|   character | 54% (67 of 123) | 39% (44 of 114) | 47% (111 of 237) |
|   chariot | 52% (51 of 98) | 60% (26 of 43) | 55% (77 of 141) |
|   infantry | 57% (175 of 308) | 60% (148 of 246) | 58% (323 of 554) |
|   monster | 67% (28 of 42) | 45% (13 of 29) | 58% (41 of 71) |
|   war machine | 81% (230 of 283) | 93% (55 of 59) | 83% (285 of 342) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (28%) | 1.5 (23%) | 4.1 (26%) |
| CHARGED: it charged | 1.1 (12%) | 1.3 (19%) | 2.4 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.5 (8%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.8 (19%) | 1.4 (22%) | 3.2 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.5 (7%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (18%) | 0.8 (12%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.3 (4%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.5 (6%) | 0.1 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.1 | 83% | 3.7 pts | 19 pts |
| character | 3.6 | 1.1 | 79% | 5.1 pts | 18 pts |
| chariot | 2.2 | 1.8 | 53% | 19.1 pts | 41 pts |
| infantry | 13.1 | 4.8 | 75% | 8.4 pts | 110 pts |
| monster | 1.3 | 0.2 | 89% | 3.9 pts | 5 pts |
| war machine | 7.9 | 6.8 | 62% | 27.2 pts | 215 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.3 | 4.7 |
| Charges that made contact a game | 3.0 | 3.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.95 declared, 0.82 contact (22 units) | 0.15 declared, 0.08 contact (13 units) | 0.66 declared, 0.54 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.60 contact (5 units) | 1.78 declared, 1.11 contact (9 units) | 1.43 declared, 0.93 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.36 contact (246 units) | 0.64 declared, 0.44 contact (274 units) | 0.57 declared, 0.40 contact (520 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (39 of 70) | 57% (12 of 21) | 25% (2 of 8) | 54% (53 of 99) |
| Character in a unit | 86% (36 of 42) | 68% (17 of 25) | 67% (2 of 3) | 79% (55 of 70) |
| Character on its own | 84% (38 of 45) | 63% (22 of 35) | 35% (22 of 63) | 57% (82 of 143) |
| Chariot | 50% (8 of 16) | 60% (6 of 10) | - | 54% (14 of 26) |
| Infantry | 58% (52 of 89) | 36% (13 of 36) | 0% (0 of 2) | 51% (65 of 127) |
| Monster | 59% (19 of 32) | 60% (6 of 10) | - | 60% (25 of 42) |
| Monstrous | 55% (6 of 11) | 71% (10 of 14) | - | 64% (16 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 93% (14 of 15); on the table 93% | 30% (41 of 138) | 52% | 58% (19 of 33) | 100% (9 of 9); 6.7 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 73% (8 of 11); on the table 73% | 21% (5 of 24) | 36% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (11 of 11); on the table 100% | - | 61% | 61% (25 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 83% | 42% (15 of 36) | 46% | 58% (37 of 64) | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 96% (22 of 23); on the table 96% | 28% (30 of 108) | 54% | 32% (14 of 44) | 100% (12 of 12); 7.8 uses a game | 100% (1 of 1); 0.4 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 93% (13 of 14); on the table 93% | 20% (6 of 30) | 44% | 55% (27 of 49) | 100% (5 of 5); 3.0 uses a game | 22% (4 of 18); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (6 of 6); on the table 100% | - | 39% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (13 of 13); on the table 100% | - | 19% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 75% (6 of 8); on the table 100% | 17% (2 of 12) | 75% | 76% (16 of 21) | 33% (1 of 3); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (2 of 2); on the table 100% | 17% (6 of 36) | 32% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 83% (10 of 12); on the table 83% | 40% (12 of 30) | 33% | 71% (24 of 34) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 86% (19 of 22); on the table 91% | 0% (0 of 12) | 33% | 37% (11 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 82% (23 of 28); on the table 86% | 43% (23 of 54) | 45% | 56% (28 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 94% (15 of 16); on the table 94% | 33% (10 of 30) | 40% | 80% (59 of 74) | 100% (4 of 4); 1.6 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 95% (19 of 20); on the table 95% | 40% (12 of 30) | 39% | 56% (37 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ss-opp-06f55ce-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (36) | 47% (30) | 47% (66) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.56 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.44 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.44 | 3.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 1.17 | 2.08 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.75 | 5.25 | 10.00 |

### Quality by phase: ss-opp-06f55ce-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (64 of 120) | 44% (77 of 177) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (208 of 434) | 56% (110 of 196) |
| Strategy | Close-in objectives charged next turn | 11% (20 of 176) | 14% (31 of 222) |
| Strategy | Support requests answered (helper made contact too) | 75% (9 of 12) | 44% (11 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 80% (8 of 10) |
| Strategy | Joined characters whose unit fought | 33% (18 of 55) | 33% (16 of 49) |
| Strategy | Lone characters that fought | 81% (74 of 91) | 71% (62 of 87) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.4 | 2.1 |
| Movement | Points that never moved of their own | 315.8 | 145.2 |
| Movement | Fights charged into per game | 2.5 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 82, net -68 | 14 of 92, net +210 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 82, net +117 | 24 of 92, net +94 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 82, net +42 | 9 of 92, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 82, net +86 | 27 of 92, net +148 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (190 of 397) | 43% (152 of 351) |
| Shooting | Points destroyed by shooting units | 93.2 | 45.1 |
| Shooting | War machine shots | 6.4 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (115 of 230) | 38% (21 of 55) |
| Shooting | Points destroyed by war machines | 86.1 | 15.8 |
| Magic | Magic missiles cast | 1.6 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (23 of 58) | 36% (17 of 47) |
| Magic | Wounds caused by magic missiles | 5.1 | 2.4 |
| Magic | Wounds caused by other spells | 1.4 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 111.5 | 18.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.4 / 0.6 / 0.3 | 1.6 / 0.4 / 0.1 / 0.2 |
| Combat | Points destroyed in combat | 328.2 | 318.3 |
| Combat | Points run down | 56.0 | 146.3 |
| Combat | Net points per charged fight, damage counted | +75 | +102 |
| Combat | Net per 100 charger points, damage counted | +24.1 | +36.8 |
| Combat | First round won (charged fights) | 69% | 70% |
| Combat | Net points per charged fight | +78 | +107 |
| Combat | Net points per supported fight / lone fight | +147 / +64 | +149 / +98 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 91 | 53 of 109 |
| Game | Points lost | 646.9 | 738.9 |
| Game | VP from objectives | 653.1 | 587.2 |
| Game | Lone holders (player turns) | 3.0 | 2.2 |

- Mine won / drew / lost: 16 / 5 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +123 VP
- The side that went first won 14 of 31 games with a winner
- Points traded per game (both sides' losses): 1386
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-opp-06f55ce-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.3 | -165.2 | 218.8 | 114.0 | 4.8 | -157.0 | 119.2 | 132.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 10.4 | 0.5 | +0.0 | 0.0 | 8.1 |
| BACKUP TARGETS | 0.6 | +2.5 | 0.0 | 12.3 | 0.7 | +3.4 | 0.0 | 26.4 |
| BEST FACING | 0.3 | +13.9 | 0.0 | 10.6 | 0.2 | +9.1 | 0.0 | 46.5 |
| BEST FIRST | 1.2 | +53.4 | 32.4 | 14.4 | 0.6 | +21.2 | 2.3 | 36.4 |
| BEST OVERALL | 0.3 | +23.4 | 0.0 | 4.9 | 0.3 | +8.3 | 0.0 | 11.8 |
| BEST PREY | 0.6 | +24.3 | 13.7 | 6.4 | 0.8 | +49.7 | 6.4 | 26.9 |
| BEST PRIZE | - | - | - | - | 0.2 | -3.3 | 12.3 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.6 | 0.0 | 15.0 | 0.2 | -1.5 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 13.8 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +6.6 | 0.0 | 1.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -19.1 | 40.2 | 19.8 | 0.3 | -61.5 | 40.4 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 3.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 126.8 | 8.1 | 0.0 | +0.0 | 3.3 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +131.1 | 414.1 | 64.6 | 1.3 | +25.2 | 40.2 | 28.5 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 7.8 | - | - | - | - |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 27.4 | 2.6 |
| CAST JOB | 0.9 | +34.8 | 104.1 | 30.4 | 0.5 | +7.0 | 19.6 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +31.7 | 32.6 | 8.9 | 0.1 | +2.2 | 1.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 11.2 | 0.2 | +0.0 | 0.0 | 37.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 6.6 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +45.9 | 0.0 | 27.1 | 1.6 | +92.1 | 0.0 | 47.8 |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 3.8 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 152.2 | 77.7 | 3.1 | +0.0 | 364.6 | 67.7 |
| CHARGE NOW WEIGHED | 0.4 | -31.4 | 11.5 | 0.9 | 0.4 | -30.6 | 25.4 | 43.7 |
| CHARGER SLAIN LOST | 0.3 | -6.0 | 11.9 | 5.1 | 0.5 | -14.5 | 50.9 | 19.5 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.7 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 10.2 | 1.8 |
| CHEAPEST HOLDER | - | - | - | - | 1.6 | -48.5 | 48.8 | 24.8 |
| COMBAT PIVOT | 0.6 | +0.0 | 21.4 | 28.8 | 0.7 | +0.0 | 59.8 | 37.2 |
| CONVEYANCE SEARCH | 0.6 | +166.2 | 6.5 | 11.2 | 0.2 | +25.3 | 24.2 | 31.8 |
| COVER ONCE | 7.9 | -663.5 | 0.0 | 176.2 | 5.6 | -423.8 | 0.0 | 153.7 |
| DEFENSIVE ARMY | 0.6 | +0.0 | 57.0 | 2.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +2.0 | 0.0 | 0.0 | 0.0 | +3.0 | 0.0 | 3.5 |
| EDGE GIVE GROUND | 0.1 | +1.1 | 14.0 | 0.0 | 0.2 | +10.7 | 28.3 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +173.7 | 0.0 | 103.5 | 1.4 | +124.2 | 0.0 | 117.5 |
| FALLBACK BY WORTH | 4.4 | +54.2 | 0.0 | 89.2 | 3.7 | +32.3 | 0.0 | 61.9 |
| FALLS SHORT | - | - | - | - | 15.6 | +224.8 | 0.0 | 255.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.8 | 0.0 | 6.3 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 129.4 | 4.8 | +0.0 | 0.0 | 162.6 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.2 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +119.4 | 0.0 | 29.8 | 0.8 | +89.1 | 0.0 | 12.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +24.4 | 0.0 | 7.8 | 0.2 | +9.5 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -2.7 | 24.8 | 12.3 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 3.5 | 0.0 |
| GROUND FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 0.7 | +0.0 | 0.0 | 3.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 3.5 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 29.4 | 8.6 | 0.5 | +0.0 | 38.6 | 18.5 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.6 | -136.8 | 368.8 | 180.3 | 9.9 | -209.1 | 501.0 | 233.2 |
| HUNT ADVANCE | 0.0 | +0.2 | 3.5 | 0.0 | 0.2 | +12.8 | 4.6 | 8.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.6 | +29.2 | 0.0 | 5.4 | 0.4 | +33.9 | 0.0 | 16.9 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.9 | 2.6 | 1.9 |
| HUNT RESULT | 0.0 | +10.7 | 0.0 | 0.0 | 0.2 | +5.3 | 4.6 | 5.2 |
| HUNT THE GUNS | 0.0 | +12.5 | 3.5 | 0.0 | 0.2 | +67.3 | 7.2 | 6.1 |
| IDLE COST | 15.5 | -266.8 | 0.0 | 220.7 | 7.6 | -113.1 | 0.0 | 181.3 |
| INVITES THE FIGHT | 1.5 | +12.7 | 81.9 | 52.9 | 1.1 | +7.2 | 60.2 | 33.7 |
| JOINT CHARGE PLAN | 0.2 | +24.7 | 0.0 | 22.8 | 0.4 | +28.1 | 21.3 | 0.8 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.2 | 0.0 | 8.6 | 0.2 | -2.6 | 37.2 | 1.8 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.2 | +0.8 | 1.8 | 5.4 |
| KEEPS ITS TARGET | 1.6 | +46.7 | 98.8 | 39.4 | 2.1 | +61.7 | 203.8 | 49.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +66.1 | 94.9 | 36.4 | 2.1 | +99.5 | 164.2 | 48.8 |
| KILLS COUNT NEXT TURN | 4.9 | +210.3 | 180.6 | 84.4 | 5.8 | +225.6 | 187.5 | 172.6 |
| LONE CHARACTER SAFE SPOT | 0.6 | +16.1 | 19.0 | 3.8 | 0.4 | +14.6 | 4.9 | 21.8 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -2.6 | 30.8 | 18.4 | 0.4 | +2.8 | 12.0 | 0.0 |
| LOST CHARGE | 2.8 | -42.0 | 119.8 | 63.9 | 2.6 | -45.4 | 36.7 | 161.8 |
| LURE BY WHAT IT DRAWS | 0.2 | -26.9 | 0.0 | 11.5 | 0.2 | -32.9 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.6 | +77.4 | 3.8 | 12.3 | 1.3 | +105.4 | 45.1 | 29.9 |
| MANOEUVRE | 0.2 | +2.0 | 0.0 | 0.9 | 0.1 | +0.7 | 0.0 | 4.4 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +23.2 | 0.0 | 15.0 | 0.7 | +37.5 | 0.0 | 4.4 |
| MARCH ODDS | 0.2 | +17.8 | 7.9 | 10.6 | 0.1 | +6.5 | 1.5 | 5.4 |
| MARCH OVER CASTS | 0.6 | +35.4 | 0.0 | 5.5 | 0.2 | +35.5 | 0.0 | 13.1 |
| MAX FOR POSITIONING | 5.8 | +115.9 | 0.0 | 132.7 | 6.0 | +83.9 | 0.0 | 149.1 |
| MISSILES IN THE MOVE | 4.3 | +163.9 | 0.0 | 119.5 | 3.9 | +52.6 | 0.0 | 77.2 |
| MISSILES NEXT TURN | 5.2 | +110.4 | 0.0 | 131.2 | 4.3 | +43.5 | 0.0 | 90.3 |
| MODEL FACING | 0.3 | +104.4 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.5 |
| MOVE AND CAST | 0.4 | +18.4 | 0.0 | 15.0 | 0.2 | +11.0 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.2 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -77.0 | 0.0 | 0.0 | 0.1 | -7.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 37.2 |
| MOVE TO CHARGE | 3.2 | +344.7 | 84.6 | 72.8 | 5.1 | +441.2 | 187.0 | 136.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 11.0 | +659.1 | 0.0 | 107.8 |
| NEEDED THERE | 0.0 | +0.0 | 3.2 | 0.0 | 0.0 | +4.1 | 3.1 | 0.0 |
| NO FORCED ADVANCE | - | - | - | - | 2.8 | +0.0 | 0.0 | 21.4 |
| NO RALLY LEFT | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -9.5 | 41.7 | 0.0 | 0.4 | -15.9 | 33.3 | 5.2 |
| NOT TURNED | 4.8 | +98.4 | 0.0 | 150.5 | 5.2 | +71.4 | 0.0 | 99.6 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 32.6 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.9 | -712.7 | 11.1 | 289.9 | 14.1 | -581.4 | 11.9 | 280.9 |
| ONE FIGHT FORMULA | 8.4 | -161.3 | 73.1 | 246.5 | 7.0 | -131.3 | 55.6 | 249.9 |
| ONE OBJECTIVE FORMULA | 2.9 | -53.7 | 0.0 | 58.4 | 2.1 | -59.8 | 0.0 | 44.6 |
| OPENS A LANE | 0.1 | +0.3 | 0.8 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +21.8 | 21.1 | 10.6 | 0.2 | +14.5 | 10.9 | 5.4 |
| OVERRUN THREAT | 0.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +6.7 | 7.2 | 10.9 | 0.6 | +6.9 | 49.1 | 7.1 |
| PATHS CROSS | 2.1 | +145.0 | 0.0 | 27.8 | 2.4 | +82.0 | 0.0 | 31.3 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.8 | 0.0 | 4.7 | 0.1 | -1.0 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +1476.0 | 1359.8 | 860.4 | 36.7 | +998.4 | 1068.4 | 909.9 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -10.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.2 | +13.8 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.8 | +11.7 | 0.0 | 26.7 | 1.2 | +8.6 | 0.0 | 35.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -9.1 | 0.0 | 0.0 | 0.1 | -6.2 | 3.4 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -6.4 | 0.0 | 17.6 | 1.2 | -33.3 | 0.0 | 35.8 |
| REDIRECT COUNTER | 1.6 | +98.0 | 0.0 | 34.0 | 3.8 | +338.8 | 0.0 | 64.8 |
| REDIRECT WEIGHED | 0.2 | +3.5 | 7.3 | 1.4 | 0.4 | +3.8 | 7.5 | 7.4 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 3.2 |
| RESERVE FALL BACK | 0.6 | +16.4 | 0.0 | 1.8 | 0.6 | +22.8 | 0.0 | 13.1 |
| RESTRAINS TO SHOOT | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +9.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +92.9 | 196.8 | 94.2 | 2.8 | +79.2 | 254.6 | 74.3 |
| RISK ONCE | 2.1 | +48.0 | 29.6 | 85.5 | 4.5 | +310.4 | 42.1 | 310.3 |
| SAFER THAN THE JOB | 0.9 | +49.9 | 0.0 | 19.1 | 1.2 | +60.7 | 0.0 | 9.7 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -11.4 | 0.0 | 1.1 | 0.5 | -31.5 | 0.0 | 6.4 |
| SEARCH SPOT | 2.1 | +71.2 | 0.0 | 38.6 | 2.4 | +95.0 | 0.0 | 22.4 |
| SELF MOVE SPELL | 0.2 | +14.8 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.0 | +138.5 | 8.5 | 17.5 | 2.1 | +184.8 | 77.2 | 51.7 |
| SET-UP ANY TARGET | 0.2 | +12.1 | 6.5 | 11.2 | 0.1 | +16.2 | 24.2 | 24.2 |
| SET-UP MISSED | 0.0 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +67.6 | 148.8 | 13.7 | 1.2 | +25.4 | 17.7 | 13.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 197.3 | 3.5 | 0.2 | +0.0 | 20.2 | 1.7 |
| SHOTS IN THE MOVE | 14.8 | +550.2 | 0.0 | 188.0 | 9.2 | +200.8 | 0.0 | 149.4 |
| SPELL SETS UP CHARGE | 0.3 | +106.2 | 6.5 | 11.2 | 0.1 | +32.3 | 24.2 | 24.2 |
| SPELL WORTH | 1.2 | +22.1 | 85.2 | 77.5 | 1.7 | +40.0 | 66.5 | 66.5 |
| SPELLS IN THE FIGHT | 0.5 | +0.1 | 52.7 | 12.2 | 0.4 | -10.4 | 50.3 | 20.8 |
| STABLE ROLE | 11.8 | +0.0 | 556.9 | 159.0 | 11.7 | +0.0 | 221.5 | 173.6 |
| STANDS TO CAST | 0.1 | +2.3 | 0.0 | 15.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +1.2 | 5.3 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +18.1 | 0.0 | 1.9 | 0.2 | +8.1 | 0.0 | 5.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 1.2 | - | - | - | - |
| SUPPORT NARROWED | 5.6 | -61.5 | 370.8 | 53.0 | 7.4 | -59.5 | 382.3 | 91.5 |
| SUPPORTS | 4.1 | +66.4 | 234.6 | 27.8 | 5.1 | +61.4 | 177.4 | 32.7 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -4.7 | 10.2 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -3.0 | 0.0 | 1.8 | 0.9 | +23.8 | 1.8 | 28.4 |
| THROUGH LINE OF FIRE | 0.5 | +22.2 | 0.0 | 18.6 | 0.3 | +9.3 | 0.0 | 14.1 |
| TIME ON OUR SIDE | - | - | - | - | 8.8 | +141.1 | 0.0 | 67.5 |
| TURN WORTH | 0.4 | -21.2 | 28.7 | 3.1 | 0.2 | -12.9 | 22.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +1.5 | 4.7 | 0.0 | 0.6 | +2.7 | 10.4 | 2.4 |
| WAIT AFTER COSTS | 6.9 | -342.6 | 268.4 | 173.9 | 7.9 | -448.3 | 288.1 | 223.7 |
| WALKS TO THE FIGHT | 1.5 | +11.1 | 57.4 | 27.7 | 1.0 | +10.0 | 29.2 | 26.3 |
| WAR ENGINE CHARGES | 0.1 | +7.1 | 13.7 | 0.0 | 0.1 | +2.7 | 5.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 67.5 | 16.8 | 0.4 | +0.0 | 10.0 | 8.1 |
| WEARS DOWN | 1.2 | +50.6 | 85.4 | 66.5 | 1.4 | +39.8 | 153.2 | 34.8 |
| WHO HITS BACK | 0.4 | +33.2 | 0.0 | 13.5 | 0.2 | +20.6 | 0.0 | 8.8 |
| WHOLE FIGHT | 0.2 | +7.7 | 33.8 | 3.1 | 0.3 | +27.5 | 49.8 | 5.2 |
| WHOLE FIGHT GAIN | 0.4 | +17.3 | 41.6 | 9.8 | 0.6 | +23.6 | 53.1 | 7.0 |
| WIDER SPREAD | 2.2 | -6.5 | 179.2 | 78.1 | 3.3 | -10.6 | 252.8 | 48.7 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: ss-opp-06f55ce-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1117 | 1117 | 1117 | 31.03 | -46594 | -41.7 |
| PATHS CROSS | 163 | 163 | 163 | 4.53 | +8172 | +50.1 |
| SEARCH SPOT | 163 | 163 | 160 | 4.44 | +5985 | +37.4 |
| MOVE TO CHARGE | 298 | 298 | 158 | 4.39 | +11746 | +74.3 |
| SUPPORTS | 328 | 328 | 132 | 3.67 | +1742 | +13.2 |
| NEARER NOT NEEDED | 397 | 261 | 126 | 3.50 | +3195 | +25.4 |
| FACES THE THREAT | 122 | 122 | 122 | 3.39 | +10724 | +87.9 |
| KILLS COUNT NEXT TURN | 386 | 386 | 121 | 3.36 | +3668 | +30.3 |
| NO FORCED ADVANCE | 102 | 102 | 102 | 2.83 | +985 | +9.7 |
| WAIT AFTER COSTS | 534 | 534 | 96 | 2.67 | +1510 | +15.7 |
| SHOTS IN THE MOVE | 863 | 587 | 79 | 2.19 | +1932 | +24.5 |
| SAFER THAN THE JOB | 75 | 75 | 75 | 2.08 | +3982 | +53.1 |
| RISK ONCE | 238 | 186 | 70 | 1.94 | +3744 | +53.5 |
| COVER ONCE | 486 | 248 | 68 | 1.89 | +805 | +11.8 |
| FOLLOW UP WEIGHED | 67 | 67 | 67 | 1.86 | +7505 | +112.0 |
| FALLBACK BY WORTH | 289 | 289 | 66 | 1.83 | +3115 | +47.2 |
| FALLS SHORT | 562 | 337 | 65 | 1.81 | +305 | +4.7 |
| BEST FIRST | 64 | 64 | 64 | 1.78 | +2689 | +42.0 |
| CHAFF IN THE MOVE | 89 | 87 | 61 | 1.69 | +2247 | +36.8 |
| ADVANCE WORTH | 363 | 363 | 60 | 1.67 | +1170 | +19.5 |
| SET UP TOGETHER | 111 | 103 | 58 | 1.61 | +4818 | +83.1 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| ONE FIGHT FORMULA | 555 | 338 | 56 | 1.56 | +191 | +3.4 |
| REDIRECT COUNTER | 193 | 107 | 54 | 1.50 | +5283 | +97.8 |
| CANNON PLANNED TARGET | 236 | 236 | 52 | 1.44 | -279 | -5.4 |
| TIME ON OUR SIDE | 317 | 208 | 52 | 1.44 | +124 | +2.4 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| COMBAT PIVOT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MISSILES IN THE MOVE | 295 | 180 | 44 | 1.22 | +1015 | +23.1 |
| RISK BY ARC | 180 | 174 | 43 | 1.19 | +1411 | +32.8 |
| SHOOTS FROM THE BEST SPOT | 103 | 103 | 42 | 1.17 | +1559 | +37.1 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +1410 | +34.4 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 40 | 1.11 | +730 | +18.3 |
| INVITES THE FIGHT | 93 | 93 | 38 | 1.06 | +248 | +6.5 |
| WALKS TO THE FIGHT | 90 | 90 | 38 | 1.06 | +220 | +5.8 |
| MARCH CHECK | 40 | 39 | 37 | 1.03 | +2058 | +55.6 |
| SHOT REPLANNED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| IDLE COST | 832 | 493 | 35 | 0.97 | +419 | +12.0 |
| MAX FOR POSITIONING | 423 | 262 | 35 | 0.97 | +67 | +1.9 |
| CHARGE NOW FIRST | 179 | 179 | 34 | 0.94 | -1513 | -44.5 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| HONEST WORTH | 630 | 628 | 32 | 0.89 | +280 | +8.7 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +2316 | +79.9 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1134 | +40.5 |
| KILLS COUNT | 121 | 119 | 27 | 0.75 | +1141 | +42.3 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| HARD STAY DROPPED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| MAKE SURE TOGETHER | 68 | 56 | 25 | 0.69 | +1913 | +76.5 |
| BEST OVERALL | 24 | 24 | 24 | 0.67 | +1140 | +47.5 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| STOPS SHORT OF THE FLANK | 23 | 23 | 23 | 0.64 | +943 | +41.0 |
| BEST FACING | 21 | 21 | 21 | 0.58 | +830 | +39.5 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +1060 | +50.5 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +213 | +10.1 |
| CAST JOB | 51 | 51 | 20 | 0.56 | +331 | +16.5 |
| WAR ENGINE JOBS | 40 | 40 | 20 | 0.56 | -1324 | -66.2 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1396 | +69.8 |
| BEST PREY | 50 | 50 | 15 | 0.42 | +590 | +39.4 |
| BLOCKED WHEEL | 14 | 14 | 14 | 0.39 | +237 | +16.9 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| LOST CHARGE | 193 | 193 | 14 | 0.39 | +504 | +36.0 |
| CASTING BLOCK | 23 | 23 | 13 | 0.36 | +486 | +37.3 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1220 | +93.9 |
| OPENS UP | 21 | 21 | 13 | 0.36 | +325 | +25.0 |
| WHOLE FIGHT GAIN | 35 | 29 | 13 | 0.36 | +388 | +29.9 |
| KEEPS ITS TARGET | 130 | 130 | 12 | 0.33 | +250 | +20.9 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +3759 | +313.2 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -75 | -6.8 |
| MARCH ODDS | 11 | 11 | 11 | 0.31 | +67 | +6.1 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -10 | -1.0 |
| JOINT CHARGE PLAN | 23 | 23 | 10 | 0.28 | +903 | +90.3 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -102 | -10.2 |
| HUNT IN PAIRS | 36 | 24 | 9 | 0.25 | +524 | +58.2 |
| MISSILES NEXT TURN | 342 | 201 | 9 | 0.25 | +57 | +6.4 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -349 | -43.6 |
| REFUSING RETIRES | 25 | 25 | 8 | 0.22 | -2 | -0.3 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +375 | +46.8 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 471 | 471 | 8 | 0.22 | -123 | -15.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SURE REACH TOGETHER | 53 | 42 | 7 | 0.19 | +112 | +16.0 |
| WEARS DOWN | 93 | 92 | 7 | 0.19 | +279 | +39.9 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +212 | +35.4 |
| BACKUP TARGETS | 45 | 20 | 5 | 0.14 | +9 | +1.7 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -169 | -33.7 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 4 | 0.11 | +96 | +24.1 |
| ONE OBJECTIVE FORMULA | 180 | 82 | 4 | 0.11 | +240 | +60.1 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -372 | -93.0 |
| DEFENSIVE ARMY | 25 | 25 | 3 | 0.08 | -116 | -38.8 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +38 | +12.7 |
| HUNT ADVANCE | 8 | 8 | 3 | 0.08 | +82 | +27.2 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -15 | -4.9 |
| WHOLE FIGHT | 20 | 19 | 3 | 0.08 | +196 | +65.2 |
| WIDER SPREAD | 199 | 192 | 3 | 0.08 | +2 | +0.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| EDGE GIVE GROUND | 12 | 12 | 2 | 0.06 | +128 | +64.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +64 | +32.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +43 | +21.3 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +9 | +4.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 32 | 32 | 2 | 0.06 | +20 | +9.8 |
| SPELLS IN THE FIGHT | 33 | 32 | 2 | 0.06 | +7 | +3.5 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +182 | +91.2 |
| STOPS | 2 | 2 | 2 | 0.06 | +29 | +14.6 |
| BLOWS WHERE AIMED | 21 | 19 | 1 | 0.03 | +71 | +71.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +35 | +35.1 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -21 | -21.3 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +10 | +10.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +74 | +74.4 |
| REDIRECT BY WHAT IT STOPS | 65 | 65 | 1 | 0.03 | +50 | +50.2 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +52 | +52.2 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -18 | -17.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 29 | 25 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 57 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 338 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 28 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 11 | 8 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 34 | not checked | - | - | - | - |
| LONG SHOT | 29 | 28 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 17 | 17 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 360 | 360 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 2 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2714 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 26 | 26 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 105 | not checked | - | - | - | - |
| STABLE ROLE | 846 | 843 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 22 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 24 | 22 | 0 | 0.00 | - | - |

### Off best figure: ss-opp-06f55ce-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.28 | 12.47 | 41.4 |
| FALLBACK | gate | 0.75 | 0.72 | 58.0 |
| CHARGE NOW FIRST | rule | 0.28 | 0.67 | 44.5 |
| TURN GATE | gate | 0.25 | 0.44 | 35.8 |
| WAR ENGINE JOBS | rule | 0.39 | 0.17 | 66.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.17 | 20.2 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.06 | 36.9 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 10.2 |
| PATHS CROSS | rule | 0.08 | 0.17 | 16.1 |
| BEST PRIZE | rule | - | 0.22 | 43.6 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.14 | 9.8 |
| SUPPORT NARROWED | rule | 0.03 | 0.19 | 15.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.14 | 40.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.08 | 83.1 |
| FIGHT ORDER BAND | gate | 0.14 | 0.03 | 2.7 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 94.4 |
| FACES THE THREAT | rule | 0.06 | 0.06 | 9.5 |
| PURSUES BIG PREY | rule | - | 0.11 | 93.0 |
| REDIRECT WEIGHED | rule | - | 0.11 | 50.0 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.11 | 42.0 |
| AFTERMATH BAND | gate | 0.06 | 0.03 | 2.9 |
| DEFENSIVE ARMY | rule | 0.08 | - | 38.8 |
| NEARER NOT NEEDED | rule | - | 0.08 | 3.4 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 10.1 |
| CHAFF PASSED | rule | 0.03 | 0.03 | 4.5 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.8 |
| NO REASON | gate | - | 0.06 | 59.7 |
| RULE SWITCHED OFF | gate | 0.06 | - | 16.5 |
| STANDS TO CAST | rule | 0.06 | - | 7.6 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 21.3 |
| MOVE AND CAST | rule | 0.03 | - | 1.8 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 9.7 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 1.9 |
| WHO HITS BACK | rule | 0.03 | - | 1.3 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 17.9 |

### Plans: ss-opp-06f55ce-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.7 | 19% | 184 | 290 | 158% |
| Mine | charge | 2.8 | 55% | 259 | 214 | 83% |
| Mine | close in | 4.9 | 29% | 347 | 178 | 51% |
| Mine | hold | 5.6 | 40% | 333 | 0 | 0% |
| Mine | join | 0.7 | 96% | 21 | 0 | 0% |
| Mine | shoot | 10.1 | 66% | 329 | 794 | 241% |
| Mine | support | 4.9 | 89% | 53 | 0 | 0% |
| Opponent | advance | 7.7 | 21% | 146 | 201 | 138% |
| Opponent | charge | 4.3 | 63% | 380 | 433 | 114% |
| Opponent | close in | 6.1 | 23% | 444 | 168 | 38% |
| Opponent | hold | 6.3 | 23% | 333 | 0 | 0% |
| Opponent | join | 1.3 | 94% | 66 | 0 | 0% |
| Opponent | shoot | 4.4 | 52% | 91 | 196 | 216% |
| Opponent | support | 6.6 | 91% | 59 | 0 | 0% |

### Packages: hunt the guns, ss-opp-06f55ce-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 450 | 385 | 100% | 16 |
| Opponent | 0.2 | 6 | 0 | 17% | 17% | 0% | 3.0 | 404 | 32 | 17% | 102 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 450 | 385 | 100% | 93 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 108 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 320 | 0 | 0% | 128 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 257 | 192 | 100% | 56 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 598 | 0 | 0% | 41 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 56 |

### Battle groups: ss-opp-06f55ce-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 33% | 63% | 16% | 33% | 19% | 0% | 0% | 81% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 18% | 83% | 17% | 50% | 15% | 0% | 10% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-opp-06f55ce-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 19 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Chaff | 37 | 44 (37) | 25 | 19 | 56 | 43% | 2.3 | 57 (16) | 20 (9) | 45 (12) | 64 (24) | 13 (13) |
| Mine | Character | 123 | 47 (123) | 47 | 0 | 34 | 19% | 2.3 | 62 (35) | 46 (61) | 18 (12) | 61 (63) | 36 (45) |
| Mine | Clean-up | 24 | 55 (24) | 13 | 43 | 24 | 38% | 3.7 | 53 (9) | 57 (11) | 63 (4) | 81 (14) | 26 (10) |
| Mine | Fast | 4 | 61 (4) | 61 | 0 | 34 | 0% | 1.5 | 114 (1) | 0 (2) | 0 (1) | 61 (4) | - |
| Mine | Fast Hammer | 41 | 36 (41) | 17 | 19 | 42 | 37% | 3.2 | 45 (18) | 30 (12) | 27 (11) | 47 (28) | 17 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 38 (58) | 26 | 12 | 44 | 17% | 2.6 | 16 (10) | 46 (38) | 25 (10) | 50 (34) | 24 (24) |
| Mine | Holder | 25 | 77 (25) | 4 | 73 | 21 | 52% | 3.1 | 107 (7) | 70 (13) | 47 (5) | 100 (10) | 61 (15) |
| Mine | Shooter | 44 | 112 (44) | 38 | 73 | 34 | 2% | 1.8 | 11 (5) | 131 (31) | 132 (7) | 115 (24) | 109 (19) |
| Mine | Support | 5 | 19 (5) | 19 | 0 | 14 | 40% | 2.0 | 66 (2) | 0 (2) | - | 22 (4) | - |
| Mine | War machine | 56 | 56 (56) | 56 | 0 | 33 | 5% | 1.2 | 83 (13) | 36 (37) | 124 (6) | 24 (11) | 64 (45) |
| Mine | Wizard | 23 | 70 (23) | 70 | 0 | 23 | 26% | 2.3 | 0 (8) | 189 (10) | 0 (3) | 97 (5) | 62 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 45 (66) | 17 | 27 | 49 | 50% | 2.7 | 77 (28) | 19 (16) | 26 (22) | 60 (48) | 3 (18) |
| Opponent | Character | 114 | 47 (114) | 47 | 0 | 35 | 28% | 2.6 | 77 (40) | 36 (54) | 0 (6) | 50 (66) | 57 (34) |
| Opponent | Clean-up | 16 | 56 (16) | 40 | 16 | 33 | 38% | 4.0 | 89 (5) | 12 (8) | 84 (3) | 87 (8) | 33 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 46 (58) | 28 | 19 | 53 | 38% | 2.5 | 51 (25) | 29 (19) | 59 (14) | 35 (42) | 77 (16) |
| Opponent | Fragile | 10 | 43 (10) | 43 | 0 | 55 | 30% | 2.4 | 48 (3) | 72 (4) | 0 (3) | 57 (7) | 0 (3) |
| Opponent | Hammer | 65 | 30 (65) | 21 | 9 | 38 | 26% | 2.5 | 32 (16) | 29 (42) | 26 (7) | 33 (40) | 23 (25) |
| Opponent | Holder | 40 | 65 (40) | 20 | 45 | 26 | 42% | 3.0 | 7 (12) | 102 (20) | 41 (8) | 100 (18) | 38 (22) |
| Opponent | Shooter | 30 | 57 (30) | 19 | 38 | 46 | 0% | 1.3 | 23 (7) | 74 (18) | 30 (5) | 44 (16) | 75 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 40 (13) | 40 | 0 | 58 | 0% | 1.0 | 12 (5) | 20 (5) | 133 (3) | 38 (3) | 41 (10) |
| Opponent | Wizard | 22 | 17 (22) | 17 | 0 | 36 | 9% | 2.2 | 23 (12) | 0 (4) | 0 (3) | 20 (11) | 6 (8) |

### Charged fights: ss-opp-06f55ce-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 230 | 0 | 0.4 | 1.5 | 0 | 26 | -26 | 0 of 2 | 1 of 2 | +0 | -52 |
| Mine | Chaos Dwarfs | 3 | 264 | 179 | 4.3 | 1.2 | 41 | 32 | +9 | 6 of 13 | 8 of 13 | -155 | +39 |
| Mine | Dwarfen Mountain Holds | 4 | 431 | 116 | 1.5 | 1.2 | 78 | 0 | +78 | 4 of 6 | 3 of 6 | +0 | +93 |
| Mine | Empire of Man | 5 | 525 | 72 | 1.6 | 1.1 | 45 | 35 | +10 | 1 of 8 | 6 of 8 | +0 | +11 |
| Mine | Grand Cathay | 4 | 734 | 517 | 2.2 | 1.3 | 230 | 33 | +197 | 5 of 9 | 7 of 9 | +556 | +94 |
| Mine | High Elf Realms | 4 | 249 | 560 | 3.2 | 1.2 | 172 | 64 | +108 | 6 of 13 | 9 of 13 | +188 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 938 | 5.0 | 1.8 | 188 | 0 | +188 | 4 of 5 | 4 of 5 | +432 | +25 |
| Mine | Lizardmen | 1 | 66 | 325 | 5.0 | 1.0 | 65 | 28 | +37 | 2 of 5 | 3 of 5 | - | +37 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 66 | 3.0 | 1.0 | 22 | 37 | -15 | 2 of 3 | 1 of 3 | - | -15 |
| Mine | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 57 | 1108 | 6.5 | 1.2 | 170 | 25 | +145 | 3 of 13 | 10 of 13 | +57 | +172 |
| Mine | Vampire Counts | 2 | 0 | 85 | 3.5 | 1.1 | 24 | 0 | +24 | 3 of 7 | 6 of 7 | +0 | +28 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 5.0 | 1.0 | 18 | 0 | +18 | 2 of 5 | 3 of 5 | - | +18 |
| **Mine** | all armies | 36 | 291 | 265 | 2.5 | 1.2 | 105 | 27 | +78 | 38 of 91 | 63 of 91 | +147 | +64 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 3.0 | 1.3 | 43 | 0 | +43 | 0 of 3 | 2 of 3 | +65 | +32 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 65 | 289 | 1.0 | 2.0 | 289 | 0 | +289 | 1 of 1 | 1 of 1 | +289 | - |
| Opponent | Grand Cathay | 1 | 400 | 673 | 4.0 | 1.8 | 168 | 95 | +74 | 3 of 4 | 4 of 4 | -3 | +150 |
| Opponent | High Elf Realms | 2 | 125 | 114 | 2.0 | 1.0 | 57 | 0 | +57 | 3 of 4 | 4 of 4 | - | +57 |
| Opponent | Lizardmen | 1 | 0 | 1623 | 6.0 | 1.5 | 270 | 0 | +270 | 3 of 6 | 6 of 6 | +358 | +183 |
| Opponent | Ogre Kingdoms | 2 | 137 | 65 | 2.0 | 1.0 | 32 | 8 | +24 | 0 of 4 | 4 of 4 | - | +24 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 530 | 4.0 | 1.0 | 133 | 121 | +12 | 5 of 8 | 4 of 8 | - | +12 |
| Opponent | Skaven | 2 | 84 | 0 | 1.0 | 1.5 | 0 | 20 | -20 | 0 of 2 | 1 of 2 | -41 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 203 | 722 | 4.2 | 1.2 | 170 | 63 | +107 | 9 of 17 | 8 of 17 | +101 | +108 |
| Opponent | Vampire Counts | 6 | 20 | 581 | 4.0 | 1.2 | 145 | 34 | +112 | 11 of 24 | 17 of 24 | +128 | +108 |
| Opponent | Warriors of Chaos | 7 | 18 | 192 | 1.3 | 1.1 | 150 | 40 | +110 | 6 of 9 | 4 of 9 | +292 | +87 |
| Opponent | Wood Elf Realms | 6 | 106 | 618 | 4.3 | 1.2 | 143 | 9 | +133 | 12 of 26 | 20 of 26 | +115 | +136 |
| **Opponent** | all armies | 36 | 79 | 432 | 3.0 | 1.2 | 143 | 36 | +107 | 53 of 109 | 76 of 109 | +149 | +98 |

### Effective charges: ss-opp-06f55ce-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 1 (net -52) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 13 | 2 (net +0) | 0 | 4 (net -78) | 2 (net +175) | 0 | 5 (net +15) | 0 | 31% (4 of 13) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +0) | 0 | 2 (net +177) | 1 (net +111) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 8 | 2 (net -140) | 0 | 0 | 2 (net +42) | 2 (net +0) | 2 (net +139) | 0 | 0% (0 of 8) |
| Mine | Grand Cathay | 9 | 1 (net +0) | 0 | 4 (net +288) | 1 (net +470) | 1 (net +60) | 1 (net +0) | 1 | 50% (4 of 8) |
| Mine | High Elf Realms | 13 | 2 (net -298) | 0 | 1 (net -123) | 5 (net +225) | 0 | 4 (net +208) | 1 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 0 | 1 (net +609) | 1 (net +254) | 0 | 2 (net +38) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 5 | 0 | 0 | 0 | 1 (net +70) | 1 (net +0) | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 1 (net +66) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +0) | 0 | 2 (net +176) | 1 (net +286) | 4 (net +68) | 3 (net +242) | 2 | 18% (2 of 11) |
| Mine | Vampire Counts | 7 | 1 (net +0) | 0 | 0 | 3 (net +57) | 1 (net +0) | 2 (net +0) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 5 | 1 (net +0) | 0 | 2 (net +0) | 0 | 1 (net +91) | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 2 (net +32) | 0 | 0 | 1 (net +65) | 0 | 67% (2 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +289) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 2 (net +244) | 1 (net +0) | 0 | 1 (net -194) | 0 | 50% (2 of 4) |
| Opponent | High Elf Realms | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 2 (net +114) | 0 | 25% (1 of 4) |
| Opponent | Lizardmen | 6 | 1 (net +380) | 0 | 1 (net +526) | 1 (net +358) | 1 (net +189) | 0 | 2 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -34) | 1 (net +0) | 2 (net +65) | 0 | 0 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 1 (net +442) | 0 | 0 | 0 | 7 | 100% (1 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 1 (net -41) | 0 | 1 (net +0) | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 17 | 2 (net +572) | 1 (net -540) | 4 (net +46) | 5 (net +145) | 1 (net +83) | 4 (net +56) | 0 | 24% (4 of 17) |
| Opponent | Vampire Counts | 24 | 2 (net +72) | 0 | 6 (net -26) | 5 (net +90) | 2 (net +128) | 6 (net +315) | 3 | 29% (6 of 21) |
| Opponent | Warriors of Chaos | 9 | 2 (net +302) | 0 | 2 (net +82) | 2 (net +168) | 0 | 1 (net +125) | 2 | 29% (2 of 7) |
| Opponent | Wood Elf Realms | 26 | 6 (net +111) | 0 | 3 (net +203) | 2 (net +106) | 2 (net -54) | 10 (net +138) | 3 | 13% (3 of 23) |

### Charged fights, damage counted: ss-opp-06f55ce-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 301 | 239 | -68 | 5 | 71 | -66 | -22.0 |
| Mine | Effective (55-75%) | 18 | 317 | 220 | +117 | 215 | 85 | +130 | +41.0 |
| Mine | 76-89% | 18 | 292 | 186 | +159 | 192 | 26 | +166 | +56.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 248 | 188 | +86 | 111 | 32 | +79 | +31.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 495 | 99 | +42 | 56 | 41 | +15 | +3.0 |
| Mine | No odds | 9 | 301 | 177 | +65 | 93 | 51 | +41 | +13.7 |
| Mine | All fights | 91 | 310 | 190 | +78 | 124 | 50 | +75 | +24.1 |
| Opponent | Long shot (under 50%) | 14 | 321 | 291 | +210 | 233 | 36 | +197 | +61.4 |
| Opponent | 50-54% | 1 | 440 | 405 | -540 | 0 | 540 | -540 | -122.7 |
| Opponent | Effective (55-75%) | 24 | 239 | 189 | +94 | 140 | 66 | +74 | +31.0 |
| Opponent | 76-89% | 17 | 250 | 189 | +122 | 165 | 43 | +122 | +48.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 297 | 184 | +148 | 199 | 49 | +150 | +50.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 426 | 107 | +61 | 90 | 14 | +76 | +17.8 |
| Opponent | No odds | 17 | 201 | 221 | +22 | 111 | 92 | +19 | +9.3 |
| Opponent | All fights | 109 | 277 | 201 | +107 | 160 | 59 | +102 | +36.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-opp-06f55ce-p1 | move | 343 | 82 (24%) | 69 (20%) | 44 (13%) | 217 (63%) |
| ss-opp-06f55ce-p1 | objective | 398 | 51 (13%) | 36 (9%) | 63 (16%) | 284 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: ss-mine-06f55ce-p2

### Scorecard: ss-mine-06f55ce-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | 5 | 1 | 3 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 335 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 1 | 7 | 0 | 0 | 0 | 52 |
| L0206 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 4 | 2 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | yes | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 16 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 828 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1092 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 9 | 3 | 0 | 0 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1078 |
| L0616 | 4 | 1 | Opponent | no | 2 | 4 | 1 | 1 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 993 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | no | 5 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 2 | 3 | 1 | 3 | 0 | 0 | 0 | 819 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 1252 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 15 | 5 | 2 | 1 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 827 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 4 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | yes | 2 | 4 | 0 | 0 | 0 | 0 | 0 | 427 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 5 | 0 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 4 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 177 |
| L1435 | 1 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 60 |
| L1531 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 4 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 5 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 161 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 1057 |
| L2029 | 1 | 1 | Opponent | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 2 | 2 | 0 | 0 | 0 | 210 |
| L2131 | 1 | 1 | Opponent | no | 4 | 4 | 2 | 1 | 2 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 400 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 11 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 125 |
| L2735 | 5 | 1 | Mine | no | - | 5 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 33% | 3.1 | 2.9 | 2.1 | 1.2 | 0.1 | 0.0 | 0.0 | 373.1 |
| **Average** | | | Opponent | 27% | 3.3 | 2.5 | 2.1 | 1.7 | 0.5 | 0.0 | 0.0 | 196.7 |

### KPIs: ss-mine-06f55ce-p2

Rules off - Opponent only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (43 of 176) | 18% (32 of 177) | 21% (75 of 353) |
| Winner chose to follow up after the loser gave ground |  | 97% (60 of 62); on the table 97% | 98% (63 of 64); on the table 98% | 98% (123 of 126); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 100% | 93% (13 of 14); on the table 100% | 91% (21 of 23); on the table 100% |
| Winner chose to pursue after the loser fled |  | 58% (14 of 24); on the table 71% | 76% (16 of 21); on the table 76% | 67% (30 of 45); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 86% (82 of 95); on the table 91% | 93% (92 of 99); on the table 94% | 90% (174 of 194); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 36% (122 of 342) | 37% (57 of 156) | 36% (179 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (122 of 244) | 50% (57 of 113) | 50% (179 of 357) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (12 of 21) | 62% (30 of 48) | 61% (42 of 69) |
| Points that never fought | lower | 42% (30317 of 71583) | 45% (32061 of 71989) | 43% (62378 of 143572) |
|   infantry points that never fought | lower | 51% (8384 of 16324) | 69% (9724 of 14029) | 60% (18108 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (159 of 284) | 60% (177 of 297) | 58% (336 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.8 uses a game | 67% (12 of 18); 1.1 uses a game | 79% (30 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (10 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30761 of 60231) | 55% (34988 of 63281) | 53% (65749 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (32%) | 0.6 (23%) | 2.6 (29%) |
| MARCHED: its unit marched | 0.9 (15%) | 0.3 (12%) | 1.2 (14%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.4 (16%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.2 (7%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) |
| GONE: slain | 0.9 (15%) | 0.5 (18%) | 1.4 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.2 (8%) | 0.6 (7%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.3 | 1.1 | 5.0 | 0.4 | 1.6 |
| not cast | 3.7 | 3.6 | 3.9 | 8.9 | 2.0 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (43%) | 0.3 (7%) | 2.6 (29%) | 0.6 (32%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (14%) | 0.2 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.3 (9%) | 0.5 (12%) | 1.8 (20%) | 0.4 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.4 (11%) | 0.4 (10%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.2 (7%) | 0.1 (2%) | 0.1 (2%) | 0.1 (3%) | 0.6 (3%) |
| GONE: slain | 0.4 (10%) | 0.6 (15%) | 0.5 (13%) | 1.4 (16%) | 0.2 (8%) | 2.4 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (12%) | 0.2 (6%) | 0.3 (9%) | 0.6 (7%) | 0.1 (7%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (3%) | 0.1 (3%) | 0.2 (3%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (5%) | 0.0 (0%) | 0.1 (1%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (64%) | 0.1 (2%) | 1.6 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 80% (12 of 15) | 54% (13 of 24) | 64% (25 of 39) |
| the unit moved after it | 92% (11 of 12) | 46% (6 of 13) | 68% (17 of 25) |
| it charged on its next turn | 0% (0 of 12) | 0% (0 of 13) | 0% (0 of 25) |
| the enemy charged it first | 8% (1 of 12) | 8% (1 of 13) | 8% (2 of 25) |
| it fought by the end of its next turn | 0% (0 of 12) | 8% (1 of 13) | 4% (1 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 12) | 0% (0 of 13) | 0% (0 of 25) |
| none of these (no charge, no fight, no charge escaped) | 92% (11 of 12) | 92% (12 of 13) | 92% (23 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (578 of 871) | 57% (450 of 792) | 62% (1028 of 1663) |
|   cavalry | 62% (49 of 79) | 64% (102 of 160) | 63% (151 of 239) |
|   character | 57% (59 of 103) | 29% (28 of 97) | 44% (87 of 200) |
|   chariot | 54% (61 of 113) | 55% (27 of 49) | 54% (88 of 162) |
|   infantry | 59% (143 of 243) | 56% (175 of 314) | 57% (318 of 557) |
|   monster | 50% (27 of 54) | 68% (25 of 37) | 57% (52 of 91) |
|   war machine | 86% (239 of 279) | 69% (93 of 135) | 80% (332 of 414) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (24%) | 2.2 (23%) | 4.2 (24%) |
| CHARGED: it charged | 0.9 (11%) | 1.5 (16%) | 2.4 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.6 (6%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.7 (21%) | 1.9 (20%) | 3.6 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (8%) | 0.4 (5%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 1.9 (20%) | 3.3 (19%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (3%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.5 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.6 | 1.3 | 84% | 4.2 pts | 28 pts |
| character | 2.6 | 0.7 | 80% | 7.1 pts | 19 pts |
| chariot | 2.4 | 1.2 | 72% | 9.4 pts | 23 pts |
| infantry | 12.3 | 5.2 | 71% | 9.7 pts | 120 pts |
| monster | 1.8 | 0.6 | 78% | 9.5 pts | 17 pts |
| war machine | 9.2 | 6.7 | 64% | 20.8 pts | 192 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.6 | 4.7 |
| Charges that made contact a game | 3.0 | 4.4 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.68 declared, 0.60 contact (25 units) | 0.85 declared, 0.46 contact (13 units) | 0.74 declared, 0.55 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.38 declared, 0.38 contact (8 units) | 1.15 declared, 1.08 contact (13 units) | 0.86 declared, 0.81 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.37 contact (243 units) | 0.61 declared, 0.47 contact (291 units) | 0.55 declared, 0.42 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (40 of 73) | 61% (11 of 18) | 58% (7 of 12) | 56% (58 of 103) |
| Character in a unit | 78% (25 of 32) | 67% (12 of 18) | 67% (2 of 3) | 74% (39 of 53) |
| Character on its own | 82% (33 of 40) | 56% (20 of 36) | 32% (20 of 63) | 53% (73 of 139) |
| Chariot | 71% (12 of 17) | 38% (5 of 13) | - | 57% (17 of 30) |
| Infantry | 51% (48 of 94) | 50% (17 of 34) | 33% (1 of 3) | 50% (66 of 131) |
| Monster | 45% (13 of 29) | 78% (7 of 9) | - | 53% (20 of 38) |
| Monstrous | 57% (8 of 14) | 64% (9 of 14) | - | 61% (17 of 28) |
| War Machines | 77% (44 of 57) | 100% (2 of 2) | - | 78% (46 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (6 of 6); on the table 100% | 21% (21 of 102) | 44% | 50% (11 of 22) | 83% (5 of 6); 4.8 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 78% (14 of 18); on the table 83% | 50% (18 of 36) | 57% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (9 of 9); on the table 100% | - | 77% | 78% (42 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 92% (22 of 24); on the table 96% | 35% (17 of 48) | 44% | 63% (48 of 76) | 0.0 uses a game | 50% (1 of 2); 0.6 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 93% (13 of 14); on the table 93% | 38% (53 of 138) | 41% | 43% (23 of 54) | 79% (11 of 14); 6.2 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 67% (8 of 12); on the table 75% | 28% (5 of 18) | 17% | 36% (12 of 33) | 100% (3 of 3); 2.5 uses a game | 57% (8 of 14); 3.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 89% (8 of 9); on the table 89% | - | 59% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 13% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (8 of 8); on the table 100% | 0% (0 of 18) | 40% | 71% (20 of 28) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 67% (8 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 88% (7 of 8); on the table 100% | 28% (5 of 18) | 47% | 52% (13 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 92% (12 of 13); on the table 92% | - | 46% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 95% (20 of 21); on the table 100% | 42% (28 of 66) | 32% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 93% (13 of 14); on the table 93% | 56% (10 of 18) | 36% | 64% (47 of 73) | 100% (2 of 2); 1.1 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 87% (27 of 31); on the table 87% | 58% (14 of 24) | 53% | 60% (47 of 78) | 43% (3 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ss-mine-06f55ce-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (36) | 37% (26) | 43% (62) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.42 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.17 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.28 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 0.97 | 2.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.58 | 0.67 | 2.25 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.64 | 5.44 | 11.08 |

### Quality by phase: ss-mine-06f55ce-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 59% (65 of 110) | 54% (102 of 189) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (151 of 411) | 50% (127 of 256) |
| Strategy | Close-in objectives charged next turn | 15% (22 of 145) | 20% (48 of 244) |
| Strategy | Support requests answered (helper made contact too) | 75% (6 of 8) | 55% (18 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 71% (5 of 7) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 71% (5 of 7) | 36% (4 of 11) |
| Strategy | Joined characters whose unit fought | 27% (15 of 55) | 19% (6 of 31) |
| Strategy | Lone characters that fought | 69% (62 of 90) | 66% (61 of 92) |
| Movement | Charges halted short of contact | 0.2 | 0.0 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 373.1 | 196.7 |
| Movement | Fights charged into per game | 2.6 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 83, net -29 | 24 of 115, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 83, net +163 | 24 of 115, net +78 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 83, net +59 | 6 of 115, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 83, net +106 | 28 of 115, net +64 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (150 of 374) | 41% (162 of 392) |
| Shooting | Points destroyed by shooting units | 126.0 | 39.6 |
| Shooting | War machine shots | 6.6 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (147 of 239) | 58% (54 of 93) |
| Shooting | Points destroyed by war machines | 41.2 | 43.1 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (22 of 77) | 37% (15 of 41) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.9 |
| Magic | Wounds caused by other spells | 1.7 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 48.6 | 40.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.3 / 0.7 / 0.1 | 2.3 / 0.3 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 298.9 | 325.1 |
| Combat | Points run down | 66.3 | 56.9 |
| Combat | Net points per charged fight, damage counted | +88 | +69 |
| Combat | Net per 100 charger points, damage counted | +30.9 | +24.3 |
| Combat | First round won (charged fights) | 82% | 72% |
| Combat | Net points per charged fight | +89 | +73 |
| Combat | Net points per supported fight / lone fight | +56 / +93 | +169 / +41 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 95 | 52 of 122 |
| Game | Points lost | 671.1 | 766.3 |
| Game | VP from objectives | 526.7 | 643.9 |
| Game | Lone holders (player turns) | 3.1 | 3.3 |

- Mine won / drew / lost: 13 / 7 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -10 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1437
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ss-mine-06f55ce-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 6.4 | -201.3 | 253.1 | 159.9 | 4.2 | -116.0 | 83.5 | 66.0 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +5.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 25.0 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.8 | +2.7 | 0.0 | 24.0 | 0.6 | +5.1 | 0.0 | 14.0 |
| BEST FACING | 0.4 | +14.1 | 0.0 | 14.4 | 0.2 | +6.4 | 0.0 | 1.8 |
| BEST FIRST | 1.1 | +56.6 | 25.0 | 39.1 | 1.3 | +64.4 | 29.2 | 31.3 |
| BEST OVERALL | 0.6 | +23.6 | 0.0 | 2.9 | 0.3 | +19.7 | 0.0 | 18.4 |
| BEST PREY | 0.8 | +49.5 | 46.6 | 11.8 | 0.5 | +18.3 | 23.8 | 11.7 |
| BEST PRIZE | 0.0 | +1.9 | 3.5 | 0.0 | 0.0 | -0.3 | 5.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 25.1 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 26.5 | 0.0 |
| BLOCKED WHEEL | 0.2 | -1.0 | 0.0 | 0.0 | 0.5 | +10.8 | 0.0 | 22.3 |
| BLOWS WHERE AIMED | 0.1 | -5.5 | 13.1 | 7.9 | 0.3 | -32.1 | 49.8 | 38.7 |
| BOMBING RUN | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 188.2 | 9.7 | 0.2 | +0.0 | 2.4 | 2.8 |
| CANNON PLANNED TARGET | 5.1 | +147.8 | 490.8 | 81.5 | 1.9 | +64.8 | 107.1 | 14.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 2.4 | 0.2 | -2.9 | 54.7 | 0.0 |
| CAST JOB | 0.8 | +15.8 | 24.2 | 27.6 | 0.3 | +6.2 | 9.2 | 19.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +33.0 | 21.6 | 0.0 | 0.3 | +14.6 | 5.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +1.0 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.9 | +41.9 | 0.0 | 23.7 | 1.6 | +75.1 | 0.0 | 38.1 |
| CHAFF PASSED | 0.2 | -0.9 | 0.0 | 0.0 | 0.2 | -0.1 | 8.9 | 2.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 207.6 | 69.8 | 2.9 | +0.0 | 320.8 | 146.8 |
| CHARGE NOW WEIGHED | 0.2 | -11.2 | 12.8 | 4.2 | 0.6 | -26.4 | 12.0 | 10.8 |
| CHARGER SLAIN LOST | 0.4 | -12.5 | 71.8 | 15.0 | 0.6 | -9.3 | 48.2 | 29.2 |
| CHEAP HELPER | 0.1 | +0.0 | 9.4 | 0.0 | 0.2 | +0.0 | 18.1 | 3.8 |
| CHEAPEST HOLDER | 1.6 | -54.5 | 90.1 | 37.5 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 42.7 | 6.8 | 0.4 | +0.0 | 9.4 | 17.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.1 | +13.5 | 0.0 | 0.0 | 0.6 | +44.9 | 28.5 | 34.7 |
| COVER ONCE | 9.2 | -650.6 | 0.0 | 177.4 | 6.7 | -432.9 | 0.0 | 155.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 10.8 | 2.9 | 0.1 | +0.0 | 8.3 | 2.9 |
| EDGE GIVE GROUND | 0.2 | +15.8 | 27.2 | 0.0 | 0.4 | +6.0 | 42.8 | 27.3 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +119.3 | 0.0 | 78.6 | 1.0 | +59.9 | 0.0 | 44.2 |
| FALLBACK BY WORTH | 2.9 | +38.8 | 0.0 | 33.6 | 5.2 | +55.7 | 0.0 | 113.6 |
| FALLS SHORT | 8.1 | +127.5 | 0.0 | 153.5 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 165.1 | 4.8 | +0.0 | 0.0 | 160.3 |
| FOCUS FIRE | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +1.6 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +124.4 | 0.0 | 28.6 | 1.2 | +136.4 | 0.0 | 48.8 |
| FRIENDS SHOTS CHECKED | 0.3 | +21.6 | 0.0 | 0.0 | 0.4 | +26.1 | 0.0 | 2.5 |
| GIVES UP | 0.1 | -0.2 | 15.4 | 0.0 | 0.1 | -0.7 | 18.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 11.0 | 1.2 |
| HARD STAY DROPPED | 0.9 | +0.0 | 0.0 | 21.2 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 13.1 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 46.1 | 16.2 | 0.3 | +0.0 | 22.9 | 24.7 |
| HILL BY ITS CHANCE | 0.4 | -50.3 | 0.0 | 6.1 | 0.7 | -49.0 | 0.0 | 4.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -107.8 | 350.1 | 150.2 | 10.6 | -203.7 | 808.8 | 338.3 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.2 | 0.0 | 0.0 | 0.2 | +1.8 | 6.5 | 1.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.8 | 0.2 | +0.0 | 3.1 | 1.8 |
| HUNT IN PAIRS | 0.4 | +32.5 | 0.0 | 0.0 | 0.5 | +27.7 | 0.0 | 10.8 |
| HUNT KEPT | 0.1 | +0.5 | 10.8 | 0.0 | 0.1 | +9.6 | 18.3 | 0.0 |
| HUNT RESULT | 0.1 | +5.9 | 5.3 | 4.8 | 0.4 | +65.6 | 14.2 | 6.3 |
| HUNT THE GUNS | 0.1 | +30.5 | 0.0 | 1.4 | 0.4 | +135.5 | 24.6 | 10.2 |
| IDLE COST | 4.0 | -47.6 | 0.0 | 68.3 | 19.2 | -298.1 | 0.0 | 219.2 |
| INVITES THE FIGHT | 1.4 | +8.5 | 65.7 | 49.9 | 0.6 | +3.9 | 12.7 | 13.6 |
| JOINT CHARGE PLAN | 0.1 | +3.2 | 0.0 | 0.0 | 0.2 | +4.3 | 16.0 | 0.9 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.9 | 10.3 | 13.8 |
| KEEP FALLS | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.1 | 1.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 150.8 | 60.8 | 2.5 | +75.8 | 271.3 | 84.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.4 | +60.3 | 112.9 | 51.6 | 2.1 | +87.8 | 191.5 | 91.9 |
| KILLS COUNT NEXT TURN | 4.6 | +161.5 | 224.3 | 108.7 | 6.6 | +261.6 | 336.0 | 192.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +5.1 | 0.0 | 15.0 | 0.2 | +10.9 | 6.1 | 14.2 |
| LONE WIZARD HOLDS BACK | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 3.2 | 21.2 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.1 | 51.7 | 3.5 | 0.6 | +2.8 | 58.3 | 6.6 |
| LOST CHARGE | 2.4 | -35.4 | 85.7 | 110.2 | 2.2 | -33.8 | 70.5 | 94.6 |
| LURE BY WHAT IT DRAWS | 0.0 | -8.0 | 0.0 | 1.5 | 0.1 | -11.5 | 0.0 | 7.6 |
| MAKE SURE TOGETHER | 0.2 | +11.2 | 14.8 | 3.8 | 0.7 | +52.9 | 14.9 | 21.7 |
| MANOEUVRE | 0.3 | +9.5 | 0.0 | 1.5 | 0.2 | +3.0 | 0.0 | 11.6 |
| MARCH AT ESCAPER | 0.1 | +0.3 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +15.8 | 0.0 | 4.5 | 0.4 | +5.4 | 0.0 | 10.6 |
| MARCH ODDS | 0.3 | +19.3 | 8.2 | 0.0 | 0.2 | +17.7 | 3.6 | 15.0 |
| MARCH OVER CASTS | 0.4 | +18.5 | 0.0 | 2.4 | 0.1 | +14.2 | 0.0 | 16.4 |
| MAX FOR POSITIONING | 5.5 | +73.4 | 0.0 | 143.1 | 6.2 | +75.2 | 0.0 | 141.1 |
| MISSILES IN THE MOVE | 4.5 | +112.0 | 0.0 | 114.1 | 3.0 | +54.8 | 0.0 | 65.4 |
| MISSILES NEXT TURN | 5.0 | +69.6 | 0.0 | 116.5 | 3.2 | +35.6 | 0.0 | 80.9 |
| MODEL FACING | 0.3 | +73.2 | 0.0 | 3.3 | 0.3 | +94.6 | 0.0 | 5.0 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +18.6 | 0.0 | 2.2 | 0.3 | +6.4 | 0.0 | 18.0 |
| MOVE SPELL IN RANGE | 0.1 | +6.9 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.0 | 3.2 | 2.6 | 0.2 | -1.8 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +140.1 | 80.8 | 68.0 | 5.1 | +291.0 | 230.8 | 166.9 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.2 | +579.0 | 0.0 | 180.5 | - | - | - | - |
| NO FORCED ADVANCE | 1.5 | +0.0 | 0.0 | 8.6 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +3.7 | 0.0 | 1.0 | 0.1 | +2.0 | 0.0 | 4.0 |
| NOT NEEDED | 0.1 | -3.5 | 15.1 | 0.0 | 0.3 | -13.1 | 35.0 | 9.2 |
| NOT TURNED | 5.6 | +31.1 | 0.0 | 136.4 | 5.4 | +62.8 | 0.0 | 126.6 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 17.4 | 0.7 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 13.8 | -442.5 | 0.0 | 307.4 | 17.1 | -836.3 | 36.4 | 278.5 |
| ONE FIGHT FORMULA | 8.3 | -112.0 | 52.2 | 178.4 | 8.3 | -170.1 | 9.2 | 281.4 |
| ONE OBJECTIVE FORMULA | 2.2 | -75.9 | 0.0 | 45.1 | 2.2 | -175.7 | 0.0 | 46.7 |
| OPENS A LANE | 0.1 | +1.6 | 13.2 | 0.0 | 0.2 | +1.1 | 28.1 | 1.7 |
| OPENS UP | 0.1 | +7.0 | 4.4 | 0.0 | 0.2 | +10.7 | 13.1 | 0.0 |
| OVERRUNS AWAY | 0.3 | +14.7 | 36.2 | 16.4 | 0.4 | +4.8 | 45.2 | 35.8 |
| PATHS CROSS | 2.1 | +82.7 | 0.0 | 12.1 | 3.1 | +168.4 | 0.0 | 95.4 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.3 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.6 | 0.0 | 2.7 | - | - | - | - |
| PLAN RESULT | 37.1 | +1518.8 | 1587.6 | 958.4 | 41.0 | +1200.0 | 1676.2 | 1078.0 |
| PURSUES BIG PREY | 0.0 | -4.3 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.7 | 0.0 | 3.4 | 0.1 | +12.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +5.1 | 0.0 | 14.6 | 1.3 | +23.4 | 0.0 | 42.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.1 | 0.0 | 0.0 | 0.1 | -7.5 | 5.3 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -12.7 | 0.0 | 20.9 | 1.2 | -37.1 | 0.0 | 25.6 |
| REDIRECT COUNTER | 2.2 | +151.5 | 0.0 | 58.9 | 3.7 | +314.7 | 0.0 | 56.1 |
| REDIRECT WEIGHED | 0.1 | +2.5 | 2.6 | 1.4 | 0.2 | +0.5 | 0.0 | 16.5 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 19.5 |
| RESERVE FALL BACK | 0.3 | +11.9 | 0.0 | 2.0 | 1.1 | +22.3 | 0.0 | 22.3 |
| RESTRAINS TO SHOOT | 0.1 | +2.8 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.9 | +57.9 | 199.6 | 73.8 | 3.1 | +94.9 | 308.3 | 140.6 |
| RISK ONCE | 5.1 | +113.1 | 23.0 | 136.1 | 3.6 | +196.6 | 29.5 | 250.0 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.7 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.6 | +65.4 | 0.0 | 42.7 | 0.7 | +44.2 | 0.0 | 12.0 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 3.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 3.8 |
| SCREEN BY WHAT IT SAVES | 0.4 | -11.6 | 0.0 | 1.2 | 0.5 | -36.8 | 0.0 | 7.1 |
| SEARCH SPOT | 2.2 | +83.1 | 0.0 | 17.6 | 2.6 | +91.0 | 0.0 | 78.2 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 1.4 | 0.1 | -0.7 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.3 | +9.4 | 0.0 | 21.9 | - | - | - | - |
| SET UP TOGETHER | 0.2 | +11.2 | 14.8 | 3.8 | 1.9 | +149.1 | 104.1 | 57.2 |
| SET-UP ANY TARGET | 0.1 | +13.4 | 0.0 | 0.0 | 0.1 | +8.6 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +9.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.3 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.9 | +71.1 | 112.1 | 6.4 | 1.1 | +44.4 | 18.2 | 10.5 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 204.9 | 18.9 | 0.3 | +0.0 | 17.5 | 2.2 |
| SHOTS IN THE MOVE | 14.9 | +645.5 | 0.0 | 215.2 | 12.0 | +362.9 | 0.0 | 168.6 |
| SPELL SETS UP CHARGE | 0.1 | +23.1 | 0.0 | 0.0 | 0.2 | +16.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +27.0 | 75.0 | 77.2 | 1.8 | +24.8 | 69.9 | 67.7 |
| SPELLS IN THE FIGHT | 0.5 | +5.5 | 74.2 | 21.9 | 0.7 | -17.6 | 98.9 | 19.7 |
| STABLE ROLE | 11.8 | +0.0 | 412.7 | 147.8 | 11.8 | +0.0 | 403.7 | 205.4 |
| STANDS TO CAST | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.0 | +1.0 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| STOPS | 0.1 | +1.6 | 5.4 | 1.4 | 0.3 | +19.7 | 31.8 | 8.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +18.9 | 0.0 | 0.0 | 0.2 | +6.7 | 0.0 | 36.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 7.1 | -69.0 | 373.4 | 97.6 | 8.5 | -69.4 | 545.5 | 93.2 |
| SUPPORTS | 5.5 | +72.7 | 229.5 | 65.8 | 5.8 | +69.4 | 278.9 | 51.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.6 | 4.4 | 0.0 | 0.2 | -2.7 | 15.4 | 10.2 |
| SURE REACH TOGETHER | 0.4 | -2.0 | 8.2 | 0.0 | 0.8 | +0.7 | 23.3 | 7.8 |
| THROUGH LINE OF FIRE | 0.2 | +3.5 | 0.0 | 13.9 | 0.4 | +18.4 | 0.0 | 1.9 |
| TIME ON OUR SIDE | 17.1 | +304.1 | 0.0 | 174.9 | - | - | - | - |
| TURN WORTH | 0.3 | -21.3 | 19.5 | 0.0 | 0.2 | -10.7 | 15.3 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.4 | 6.5 | 0.0 | 0.2 | +2.1 | 16.7 | 10.0 |
| WAIT AFTER COSTS | 6.1 | -283.9 | 193.8 | 144.2 | 8.4 | -360.7 | 392.1 | 217.8 |
| WALKS TO THE FIGHT | 1.6 | +14.6 | 29.9 | 13.2 | 1.5 | +8.5 | 41.8 | 13.8 |
| WAR ENGINE CHARGES | 0.1 | +4.3 | 21.6 | 0.0 | 0.0 | +1.4 | 3.9 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 29.1 | 6.0 | 0.6 | +0.0 | 32.5 | 23.6 |
| WEARS DOWN | 0.9 | +46.2 | 137.4 | 13.2 | 1.7 | +59.4 | 228.4 | 59.2 |
| WHO HITS BACK | 0.2 | +12.6 | 0.0 | 27.8 | 0.1 | +10.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +8.2 | 28.7 | 0.0 | 0.4 | -2.1 | 82.1 | 1.4 |
| WHOLE FIGHT GAIN | 0.1 | +10.7 | 19.3 | 5.6 | 0.5 | +30.7 | 35.4 | 14.1 |
| WIDER SPREAD | 2.0 | -7.9 | 202.0 | 42.3 | 3.8 | -5.5 | 409.1 | 122.8 |

### Rule changes: ss-mine-06f55ce-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1113 | 1113 | 1113 | 30.92 | -46036 | -41.4 |
| PATHS CROSS | 186 | 186 | 186 | 5.17 | +9039 | +48.6 |
| SEARCH SPOT | 171 | 171 | 167 | 4.64 | +6269 | +37.5 |
| SUPPORTS | 406 | 406 | 160 | 4.44 | +1723 | +10.8 |
| MOVE TO CHARGE | 276 | 276 | 129 | 3.58 | +4179 | +32.4 |
| KILLS COUNT NEXT TURN | 402 | 402 | 127 | 3.53 | +4258 | +33.5 |
| SHOTS IN THE MOVE | 967 | 668 | 113 | 3.14 | +3643 | +32.2 |
| TIME ON OUR SIDE | 615 | 413 | 111 | 3.08 | +394 | +3.5 |
| NEARER NOT NEEDED | 368 | 251 | 108 | 3.00 | +2291 | +21.2 |
| FACES THE THREAT | 100 | 100 | 100 | 2.78 | +6453 | +64.5 |
| BEST FIRST | 84 | 84 | 84 | 2.33 | +4357 | +51.9 |
| WAIT AFTER COSTS | 520 | 520 | 82 | 2.28 | +1611 | +19.6 |
| SAFER THAN THE JOB | 81 | 81 | 81 | 2.25 | +3946 | +48.7 |
| COVER ONCE | 573 | 349 | 80 | 2.22 | +1112 | +13.9 |
| RISK ONCE | 314 | 244 | 77 | 2.14 | +2546 | +33.1 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +9390 | +125.2 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| FALLBACK BY WORTH | 293 | 293 | 67 | 1.86 | +3400 | +50.7 |
| CHAFF IN THE MOVE | 88 | 87 | 57 | 1.58 | +1798 | +31.5 |
| MISSILES IN THE MOVE | 271 | 176 | 56 | 1.56 | +861 | +15.4 |
| NO FORCED ADVANCE | 54 | 54 | 54 | 1.50 | +516 | +9.5 |
| RESERVE FALL BACK | 53 | 53 | 53 | 1.47 | +1232 | +23.2 |
| ADVANCE WORTH | 380 | 380 | 52 | 1.44 | +633 | +12.2 |
| SHOOTS FROM THE BEST SPOT | 106 | 106 | 48 | 1.33 | +1414 | +29.5 |
| WALKS TO THE FIGHT | 110 | 110 | 43 | 1.19 | +222 | +5.2 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CANNON PLANNED TARGET | 254 | 254 | 42 | 1.17 | -579 | -13.8 |
| ONE FIGHT FORMULA | 596 | 379 | 42 | 1.17 | +103 | +2.5 |
| RANDOM MOVE BY FIGURES | 69 | 69 | 42 | 1.17 | +1027 | +24.5 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 182 | 176 | 39 | 1.08 | +944 | +24.2 |
| SET UP TOGETHER | 79 | 64 | 39 | 1.08 | +2251 | +57.7 |
| SHOT REPLANNED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| FALLS SHORT | 290 | 160 | 37 | 1.03 | +40 | +1.1 |
| REDIRECT COUNTER | 215 | 95 | 37 | 1.03 | +3336 | +90.2 |
| MAX FOR POSITIONING | 422 | 268 | 36 | 1.00 | +123 | +3.4 |
| CHARGE NOW FIRST | 176 | 176 | 35 | 0.97 | -1535 | -43.9 |
| COMBAT PIVOT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| HONEST WORTH | 636 | 631 | 35 | 0.97 | +177 | +5.1 |
| BEST OVERALL | 33 | 33 | 33 | 0.92 | +1559 | +47.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| HARD STAY DROPPED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 30 | 30 | 30 | 0.83 | +912 | +30.4 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +2296 | +79.2 |
| KILLS COUNT | 126 | 125 | 28 | 0.78 | +973 | +34.7 |
| MOVE AND CAST | 28 | 28 | 28 | 0.78 | +903 | +32.3 |
| FRIENDS SHOTS CHECKED | 26 | 26 | 26 | 0.72 | +1718 | +66.1 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| THROUGH LINE OF FIRE | 25 | 25 | 25 | 0.69 | +787 | +31.5 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +738 | +30.7 |
| IDLE COST | 838 | 513 | 24 | 0.67 | +366 | +15.3 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +351 | +15.3 |
| INVITES THE FIGHT | 75 | 75 | 23 | 0.64 | +178 | +7.7 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +6041 | +262.6 |
| KEEPS ITS TARGET | 144 | 143 | 22 | 0.61 | +349 | +15.8 |
| CASTING BLOCK | 28 | 28 | 21 | 0.58 | +654 | +31.1 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.56 | +921 | +46.1 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -37 | -2.1 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +314 | +18.5 |
| WAR ENGINE JOBS | 42 | 42 | 17 | 0.47 | -912 | -53.6 |
| CAST JOB | 41 | 41 | 16 | 0.44 | +232 | +14.5 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MAKE SURE TOGETHER | 34 | 23 | 16 | 0.44 | +770 | +48.1 |
| WHOLE FIGHT GAIN | 23 | 23 | 16 | 0.44 | +672 | +42.0 |
| BEST PREY | 47 | 47 | 15 | 0.42 | +347 | +23.2 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WEARS DOWN | 93 | 89 | 15 | 0.42 | +553 | +36.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.36 | +582 | +44.8 |
| HUNT IN PAIRS | 31 | 20 | 12 | 0.33 | +874 | +72.9 |
| MANOEUVRE | 18 | 18 | 12 | 0.33 | +450 | +37.5 |
| SUPPORT NARROWED | 561 | 561 | 12 | 0.33 | -231 | -19.3 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +576 | +52.4 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -299 | -29.9 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | +4 | +0.6 |
| OPENS UP | 11 | 11 | 7 | 0.19 | +225 | +32.1 |
| RAIDS THE BAGGAGE NEXT TURN | 9 | 9 | 7 | 0.19 | +229 | +32.7 |
| REFUSING RETIRES | 15 | 15 | 7 | 0.19 | -2 | -0.3 |
| MISSILES NEXT TURN | 298 | 187 | 6 | 0.17 | +17 | +2.8 |
| NO RALLY LEFT | 6 | 6 | 6 | 0.17 | +69 | +11.5 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +214 | +35.7 |
| DEFENSIVE ARMY | 10 | 10 | 5 | 0.14 | -181 | -36.2 |
| LOST CHARGE | 164 | 161 | 5 | 0.14 | +218 | +43.6 |
| OVERRUNS AWAY | 27 | 27 | 5 | 0.14 | +93 | +18.6 |
| BACKUP TARGETS | 53 | 34 | 4 | 0.11 | +2 | +0.4 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +321 | +80.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 24 | 24 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| WHOLE FIGHT | 18 | 17 | 4 | 0.11 | +131 | +32.8 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +75 | +25.0 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -60 | -20.0 |
| EDGE GIVE GROUND | 23 | 22 | 3 | 0.08 | +221 | +73.6 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +105 | +35.0 |
| JOINT CHARGE PLAN | 9 | 9 | 3 | 0.08 | +109 | +36.5 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.08 | -93 | -30.9 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +46 | +15.4 |
| WIDER SPREAD | 207 | 200 | 3 | 0.08 | +11 | +3.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -15 | -7.3 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 5 | 2 | 2 | 0.06 | +36 | +18.1 |
| ONE OBJECTIVE FORMULA | 160 | 70 | 2 | 0.06 | +1 | +0.4 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -173 | -86.7 |
| STOPS | 15 | 15 | 2 | 0.06 | +66 | +33.0 |
| SURE REACH TOGETHER | 42 | 31 | 2 | 0.06 | +8 | +3.9 |
| TWO OR MORE ARRIVE | 11 | 11 | 2 | 0.06 | +14 | +6.9 |
| BLOWS WHERE AIMED | 15 | 13 | 1 | 0.03 | +7 | +6.6 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -106 | -105.8 |
| HILL BY ITS CHANCE | 41 | 41 | 1 | 0.03 | +65 | +64.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| HUNT ADVANCE | 10 | 10 | 1 | 0.03 | +9 | +9.3 |
| LONG SHOT | 38 | 38 | 1 | 0.03 | +38 | +38.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +48 | +48.1 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -25 | -25.1 |
| SPELLS IN THE FIGHT | 42 | 41 | 1 | 0.03 | +21 | +20.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +4 | +4.3 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.03 | +61 | +60.8 |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 44 | 44 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 38 | 37 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 57 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 369 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 9 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 14 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 399 | 399 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 43 | not checked | - | - | - | - |
| OPENS A LANE | 12 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 2810 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 61 | 61 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 32 | 32 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 11 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 849 | 848 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: ss-mine-06f55ce-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.22 | 15.42 | 43.2 |
| TURN GATE | gate | 0.83 | 0.53 | 23.2 |
| FALLBACK | gate | 0.47 | 0.64 | 26.2 |
| CHARGE NOW FIRST | rule | 0.39 | 0.58 | 43.9 |
| WAR ENGINE JOBS | rule | 0.28 | 0.19 | 53.6 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.11 | 56.0 |
| SUPPORT NARROWED | rule | 0.14 | 0.19 | 19.3 |
| PATHS CROSS | rule | 0.19 | 0.08 | 23.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.17 | 29.9 |
| AFTERMATH BAND | gate | 0.08 | 0.11 | 3.1 |
| SUPPORT REQUEST | gate | - | 0.19 | 50.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 74.6 |
| CHAFF PASSED | rule | 0.11 | 0.03 | 7.4 |
| DEFENSIVE ARMY | rule | 0.06 | 0.08 | 36.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 2.0 |
| NEARER NOT NEEDED | rule | 0.14 | - | 15.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 40.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 26.4 |
| CATCH ODDS | rule | 0.06 | 0.03 | 20.0 |
| PIVOT GUARDS FLANK | rule | 0.08 | - | 30.9 |
| BEST PRIZE | rule | 0.03 | 0.03 | 7.3 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.03 | 6.8 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 23.4 |
| MARCH ODDS | rule | 0.06 | - | 4.5 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 86.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 6.8 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 3.0 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 105.8 |
| NO REASON | gate | 0.03 | - | 19.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.9 |
| SAFE SURE CHARGE | rule | - | 0.03 | 25.1 |

### Plans: ss-mine-06f55ce-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 8.5 | 20% | 194 | 277 | 143% |
| Mine | charge | 2.4 | 65% | 211 | 239 | 114% |
| Mine | close in | 4.0 | 25% | 190 | 123 | 65% |
| Mine | hold | 6.0 | 23% | 373 | 0 | 0% |
| Mine | join | 0.7 | 100% | 27 | 0 | 0% |
| Mine | shoot | 9.2 | 67% | 266 | 880 | 331% |
| Mine | support | 6.3 | 90% | 56 | 0 | 0% |
| Opponent | advance | 11.1 | 13% | 122 | 235 | 192% |
| Opponent | charge | 4.6 | 66% | 354 | 489 | 138% |
| Opponent | close in | 6.8 | 27% | 419 | 171 | 41% |
| Opponent | hold | 4.7 | 38% | 374 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 40 | 0 | 0% |
| Opponent | shoot | 5.5 | 57% | 176 | 305 | 173% |
| Opponent | support | 7.3 | 91% | 56 | 0 | 0% |

### Packages: hunt the guns, ss-mine-06f55ce-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 4.0 | 219 | 43 | 20% | 31 |
| Opponent | 0.4 | 15 | 1 | 36% | 43% | 0% | 2.7 | 342 | 169 | 29% | 62 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 122 | 0 | 0% | 66 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 420 | 0 | 0% | 49 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 134 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 0 |
| Kingdom of Bretonnia | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 123 | 0 | 0% | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 60% | 60% | 0% | 3.3 | 432 | 230 | 20% | 58 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Tomb Kings of Khemri | 1.2 | 6 | 1 | 20% | 20% | 0% | 2.0 | 221 | 90 | 20% | 14 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 463 | 378 | 100% | 5 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 55 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 50% | 0% | 2.0 | 333 | 191 | 50% | 0 |

### Battle groups: ss-mine-06f55ce-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 32% | 69% | 12% | 67% | 22% | 0% | 22% | 57% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 17% | 74% | 9% | 0% | 5% | 0% | 5% | 90% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-mine-06f55ce-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 20% | 2.5 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 90 (34) | 57 | 34 | 59 | 47% | 2.6 | 76 (19) | 222 (7) | 11 (8) | 127 (23) | 9 (11) |
| Mine | Character | 123 | 44 (123) | 44 | 0 | 28 | 25% | 2.5 | 58 (43) | 43 (54) | 8 (13) | 63 (53) | 32 (57) |
| Mine | Clean-up | 21 | 61 (21) | 30 | 31 | 32 | 57% | 3.1 | 98 (5) | 43 (13) | 47 (3) | 100 (13) | 21 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 50 (48) | 25 | 25 | 51 | 23% | 3.1 | 50 (23) | 54 (16) | 39 (9) | 55 (29) | 42 (19) |
| Mine | Fragile | 5 | 114 (5) | 114 | 0 | 40 | 0% | 1.8 | - | 0 (3) | 285 (2) | 114 (5) | - |
| Mine | Hammer | 57 | 41 (57) | 30 | 11 | 34 | 19% | 2.6 | 35 (18) | 37 (29) | 68 (10) | 41 (38) | 42 (19) |
| Mine | Holder | 28 | 55 (28) | 17 | 38 | 34 | 39% | 3.1 | 41 (10) | 57 (11) | 76 (7) | 60 (17) | 48 (11) |
| Mine | Shooter | 41 | 107 (41) | 53 | 54 | 49 | 5% | 1.6 | 126 (5) | 112 (30) | 75 (6) | 145 (25) | 48 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 31 (59) | 31 | 0 | 42 | 3% | 1.1 | 0 (10) | 37 (37) | 35 (12) | 47 (10) | 28 (49) |
| Mine | Wizard | 22 | 6 (22) | 6 | 0 | 21 | 18% | 2.7 | 1 (8) | 28 (6) | 0 (5) | 9 (7) | 5 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 0% | 5.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Chaff | 76 | 50 (76) | 21 | 29 | 48 | 42% | 2.6 | 65 (32) | 38 (19) | 42 (25) | 60 (54) | 27 (22) |
| Opponent | Character | 97 | 43 (97) | 43 | 0 | 41 | 26% | 2.4 | 48 (41) | 49 (39) | 4 (6) | 43 (59) | 51 (27) |
| Opponent | Clean-up | 19 | 34 (19) | 23 | 11 | 57 | 32% | 2.8 | 39 (9) | 27 (10) | - | 40 (14) | 17 (5) |
| Opponent | Early | 2 | 83 (2) | 83 | 0 | 50 | 0% | 5.0 | - | 83 (2) | - | 0 (1) | 167 (1) |
| Opponent | Fast Hammer | 48 | 39 (48) | 29 | 9 | 46 | 17% | 2.6 | 37 (22) | 36 (16) | 48 (10) | 33 (28) | 48 (20) |
| Opponent | Fragile | 5 | 66 (5) | 66 | 0 | 61 | 60% | 2.5 | - | 108 (3) | 0 (1) | 102 (3) | 0 (1) |
| Opponent | Hammer | 70 | 33 (70) | 27 | 6 | 43 | 31% | 2.8 | 39 (17) | 31 (42) | 32 (11) | 45 (43) | 13 (27) |
| Opponent | Holder | 35 | 93 (35) | 15 | 79 | 27 | 31% | 3.0 | 106 (8) | 113 (20) | 19 (7) | 136 (20) | 35 (15) |
| Opponent | Shooter | 33 | 78 (33) | 19 | 58 | 20 | 3% | 1.6 | 80 (8) | 92 (19) | 25 (6) | 108 (22) | 30 (11) |
| Opponent | Support | 3 | 16 (3) | 16 | 0 | 25 | 67% | 5.0 | 0 (1) | 31 (2) | - | 0 (1) | 31 (2) |
| Opponent | War machine | 24 | 40 (24) | 40 | 0 | 18 | 8% | 1.5 | 22 (6) | 50 (14) | 30 (4) | 123 (3) | 28 (21) |
| Opponent | Wizard | 26 | 5 (26) | 5 | 0 | 49 | 4% | 1.5 | 0 (9) | 18 (7) | 0 (6) | 14 (7) | 0 (15) |

### Charged fights: ss-mine-06f55ce-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 66 | 96 | 1.5 | 1.2 | 64 | 14 | +50 | 1 of 6 | 5 of 6 | +55 | +49 |
| Mine | Chaos Dwarfs | 4 | 181 | 432 | 2.8 | 1.0 | 157 | 0 | +157 | 3 of 11 | 10 of 11 | - | +157 |
| Mine | Dwarfen Mountain Holds | 4 | 496 | 130 | 1.5 | 1.5 | 87 | 10 | +77 | 1 of 6 | 5 of 6 | +62 | +92 |
| Mine | Empire of Man | 5 | 365 | 187 | 1.8 | 1.0 | 104 | 21 | +83 | 3 of 9 | 6 of 9 | - | +83 |
| Mine | Grand Cathay | 4 | 342 | 192 | 2.8 | 1.3 | 70 | 37 | +33 | 2 of 11 | 10 of 11 | +37 | +32 |
| Mine | High Elf Realms | 4 | 185 | 589 | 3.5 | 1.2 | 168 | 24 | +144 | 6 of 14 | 11 of 14 | +46 | +160 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 991 | 5.0 | 1.0 | 198 | 0 | +198 | 1 of 5 | 5 of 5 | - | +198 |
| Mine | Lizardmen | 1 | 45 | 423 | 4.0 | 1.0 | 106 | 0 | +106 | 2 of 4 | 2 of 4 | - | +106 |
| Mine | Ogre Kingdoms | 1 | 125 | 475 | 5.0 | 1.0 | 95 | 7 | +88 | 2 of 5 | 4 of 4 | - | +88 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 349 | 7.0 | 1.1 | 50 | 24 | +26 | 1 of 7 | 6 of 7 | +45 | +22 |
| Mine | Skaven | 2 | 283 | 0 | 2.5 | 1.0 | 0 | 42 | -42 | 1 of 5 | 3 of 5 | - | -42 |
| Mine | Tomb Kings of Khemri | 1 | 125 | 936 | 5.0 | 1.2 | 187 | 0 | +187 | 1 of 5 | 5 of 5 | +125 | +203 |
| Mine | Vampire Counts | 3 | 0 | 180 | 1.7 | 1.0 | 108 | 0 | +108 | 0 of 5 | 4 of 5 | - | +108 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 229 | -229 | 0 of 2 | 1 of 2 | - | -229 |
| **Mine** | all armies | 36 | 216 | 289 | 2.6 | 1.1 | 110 | 21 | +89 | 24 of 95 | 77 of 94 | +56 | +93 |
| Opponent | Dwarfen Mountain Holds | 2 | 186 | 65 | 2.0 | 1.8 | 32 | 0 | +32 | 1 of 4 | 2 of 4 | +43 | +0 |
| Opponent | Empire of Man | 2 | 670 | 88 | 4.0 | 1.1 | 22 | 30 | -8 | 5 of 8 | 6 of 8 | +0 | -9 |
| Opponent | Grand Cathay | 2 | 452 | 316 | 2.5 | 1.4 | 126 | 0 | +126 | 3 of 5 | 5 of 5 | +188 | +85 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 183 | 1.0 | 1.0 | 183 | 0 | +183 | 1 of 1 | 1 of 1 | - | +183 |
| Opponent | Ogre Kingdoms | 3 | 0 | 381 | 5.3 | 1.1 | 71 | 10 | +61 | 5 of 16 | 7 of 16 | +369 | +41 |
| Opponent | Skaven | 1 | 189 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 209 | 736 | 3.8 | 1.5 | 196 | 46 | +150 | 8 of 15 | 13 of 15 | +356 | +13 |
| Opponent | Vampire Counts | 6 | 15 | 608 | 3.7 | 1.2 | 166 | 54 | +111 | 9 of 22 | 18 of 22 | +308 | +54 |
| Opponent | Warriors of Chaos | 8 | 8 | 296 | 2.5 | 1.2 | 119 | 55 | +63 | 9 of 20 | 13 of 20 | +93 | +54 |
| Opponent | Wood Elf Realms | 7 | 67 | 338 | 4.4 | 1.3 | 76 | 43 | +34 | 11 of 31 | 23 of 31 | +7 | +41 |
| **Opponent** | all armies | 36 | 123 | 378 | 3.4 | 1.3 | 111 | 39 | +73 | 52 of 122 | 88 of 122 | +169 | +41 |

### Effective charges: ss-mine-06f55ce-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 3 (net +8) | 0 | 0 | 3 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 11 | 2 (net +0) | 1 (net +540) | 0 | 4 (net +256) | 1 (net +60) | 3 (net +35) | 0 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 1 (net +137) | 1 (net +135) | 0 | 3 (net +63) | 1 | 20% (1 of 5) |
| Mine | Empire of Man | 9 | 0 | 0 | 4 (net +188) | 3 (net -15) | 1 (net +40) | 0 | 1 | 50% (4 of 8) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 1 (net +110) | 3 (net +77) | 2 (net +30) | 4 (net -10) | 0 | 9% (1 of 11) |
| Mine | High Elf Realms | 14 | 1 (net +0) | 1 (net +195) | 2 (net +246) | 3 (net +156) | 5 (net +31) | 1 (net +702) | 1 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +350) | 0 | 0 | 3 (net +97) | 0 | 40% (2 of 5) |
| Mine | Lizardmen | 4 | 2 (net +116) | 0 | 0 | 1 (net +0) | 1 (net +190) | 0 | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 2 (net +22) | 2 (net +188) | 1 (net +20) | 0 | 0 | 40% (2 of 5) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +45) | 0 | 1 (net +54) | 1 (net +190) | 4 | 33% (1 of 3) |
| Mine | Skaven | 5 | 2 (net -105) | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 0 | 2 (net +120) | 3 (net +232) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 5 | 0 | 0 | 1 (net +0) | 2 (net +165) | 0 | 1 (net +85) | 1 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 2 | 1 (net -285) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 4 | 3 (net +22) | 0 | 0 | 1 (net +65) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | Empire of Man | 8 | 0 | 0 | 2 (net +0) | 1 (net +0) | 0 | 4 (net -16) | 1 | 29% (2 of 7) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +138) | 3 (net +165) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 1 (net +183) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Ogre Kingdoms | 16 | 7 (net +105) | 1 (net -40) | 2 (net +0) | 1 (net +150) | 0 | 2 (net +22) | 3 | 15% (2 of 13) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net -246) | 0 | 4 (net +202) | 6 (net +222) | 1 (net +177) | 1 (net +367) | 1 | 29% (4 of 14) |
| Opponent | Vampire Counts | 22 | 3 (net +77) | 2 (net -358) | 5 (net +139) | 3 (net +289) | 4 (net +102) | 4 (net +240) | 1 | 24% (5 of 21) |
| Opponent | Warriors of Chaos | 20 | 5 (net +43) | 1 (net +563) | 3 (net +22) | 5 (net +144) | 1 (net +35) | 5 (net -67) | 0 | 15% (3 of 20) |
| Opponent | Wood Elf Realms | 31 | 4 (net +118) | 2 (net -166) | 6 (net -4) | 7 (net +15) | 0 | 11 (net +74) | 1 | 20% (6 of 30) |

### Charged fights, damage counted: ss-mine-06f55ce-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 273 | 260 | -29 | 61 | 103 | -43 | -15.6 |
| Mine | 50-54% | 2 | 212 | 318 | +368 | 368 | 0 | +368 | +172.9 |
| Mine | Effective (55-75%) | 14 | 296 | 228 | +163 | 163 | 11 | +152 | +51.3 |
| Mine | 76-89% | 23 | 249 | 172 | +111 | 147 | 35 | +112 | +44.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 233 | 158 | +106 | 136 | 31 | +105 | +45.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 421 | 86 | +59 | 84 | 21 | +64 | +15.1 |
| Mine | No odds | 12 | 286 | 92 | +10 | 61 | 45 | +16 | +5.7 |
| Mine | All fights | 95 | 284 | 166 | +89 | 123 | 35 | +88 | +30.9 |
| Opponent | Long shot (under 50%) | 24 | 183 | 236 | +51 | 111 | 63 | +49 | +26.6 |
| Opponent | 50-54% | 6 | 312 | 280 | -87 | 208 | 235 | -27 | -8.7 |
| Opponent | Effective (55-75%) | 24 | 350 | 246 | +78 | 163 | 89 | +74 | +21.1 |
| Opponent | 76-89% | 27 | 364 | 182 | +138 | 177 | 45 | +132 | +36.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 224 | 145 | +64 | 103 | 51 | +53 | +23.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 470 | 119 | +104 | 104 | 6 | +98 | +20.8 |
| Opponent | No odds | 7 | 140 | 120 | +22 | 30 | 29 | +1 | +0.4 |
| Opponent | All fights | 122 | 283 | 195 | +73 | 134 | 65 | +69 | +24.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-mine-06f55ce-p2 | move | 371 | 100 (27%) | 77 (21%) | 43 (12%) | 228 (61%) |
| ss-mine-06f55ce-p2 | objective | 389 | 70 (18%) | 55 (14%) | 41 (11%) | 278 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: ss-opp-06f55ce-p2

### Scorecard: ss-opp-06f55ce-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 12 | 2 | 2 | 0 | 0 | 0 | 0 | 110 |
| L0307 | 1 | 1 | Mine | yes | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 6 | 2 | 2 | 0 | 0 | 0 | 760 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | 5 | 1 | 1 | 0 | 0 | 0 | 492 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 6 | 0 | 4 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 966 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 2 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 819 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1338 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 2 | 0 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 19 | 2 | 2 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 1177 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 9 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | yes | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 311 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 4 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 5 | 1 | 2 | 1 | 1 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 1 | 0 | 0 | 147 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 77 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 486 |
| L1927 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 4 | - | 0 | 3 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 2 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 6 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 9 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 125 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 6 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 30% | 2.2 | 2.8 | 2.0 | 1.3 | 0.1 | 0.0 | 0.0 | 338.9 |
| **Average** | | | Opponent | 27% | 3.9 | 2.5 | 2.2 | 1.6 | 0.4 | 0.0 | 0.0 | 173.1 |

### KPIs: ss-opp-06f55ce-p2

Rules off - Mine only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 173) | 17% (29 of 173) | 19% (67 of 346) |
| Winner chose to follow up after the loser gave ground |  | 97% (64 of 66); on the table 97% | 94% (45 of 48); on the table 94% | 96% (109 of 114); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (4 of 5); on the table 80% | 94% (15 of 16); on the table 100% | 90% (19 of 21); on the table 95% |
| Winner chose to pursue after the loser fled |  | 74% (25 of 34); on the table 82% | 84% (21 of 25); on the table 92% | 78% (46 of 59); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 89% (93 of 105); on the table 91% | 91% (81 of 89); on the table 94% | 90% (174 of 194); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 35% (120 of 342) | 42% (66 of 156) | 37% (186 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (120 of 254) | 49% (60 of 123) | 48% (180 of 377) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 45% (9 of 20) | 48% (25 of 52) | 47% (34 of 72) |
| Points that never fought | lower | 39% (27796 of 71583) | 46% (33092 of 71989) | 42% (60888 of 143572) |
|   infantry points that never fought | lower | 50% (8152 of 16324) | 61% (8585 of 14029) | 55% (16737 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (167 of 284) | 57% (168 of 297) | 58% (335 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.5 uses a game | 83% (15 of 18); 1.3 uses a game | 89% (34 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 72% (13 of 18); 0.6 uses a game | 0% (0 of 2); 0.0 uses a game | 65% (13 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32775 of 60231) | 51% (32051 of 63281) | 52% (64826 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (28%) | 0.8 (32%) | 2.6 (29%) |
| MARCHED: its unit marched | 1.4 (23%) | 0.4 (17%) | 1.8 (21%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (7%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.3 (22%) | 0.3 (11%) | 1.6 (19%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (13%) | 0.5 (19%) | 1.3 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (9%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.6 | 1.4 | 1.0 | 5.2 | 0.5 | 1.3 |
| not cast | 4.2 | 3.6 | 4.0 | 8.7 | 1.8 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (47%) | 0.3 (7%) | 2.6 (29%) | 0.5 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (21%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.2 (5%) | 0.5 (13%) | 1.6 (19%) | 0.1 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (9%) | 0.3 (9%) | 0.4 (9%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (2%) | 0.1 (1%) |
| GONE: slain | 0.8 (18%) | 0.6 (17%) | 0.6 (15%) | 1.3 (15%) | 0.1 (3%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (12%) | 0.4 (11%) | 0.1 (3%) | 0.2 (3%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.6 (35%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (55%) | 0.2 (5%) | 1.9 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.1 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 69% (11 of 16) | 74% (17 of 23) | 72% (28 of 39) |
| the unit moved after it | 73% (8 of 11) | 47% (8 of 17) | 57% (16 of 28) |
| it charged on its next turn | 0% (0 of 11) | 6% (1 of 17) | 4% (1 of 28) |
| the enemy charged it first | 18% (2 of 11) | 12% (2 of 17) | 14% (4 of 28) |
| it fought by the end of its next turn | 9% (1 of 11) | 12% (2 of 17) | 11% (3 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (3 of 11) | 6% (1 of 17) | 14% (4 of 28) |
| none of these (no charge, no fight, no charge escaped) | 55% (6 of 11) | 71% (12 of 17) | 64% (18 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (553 of 841) | 57% (438 of 771) | 61% (991 of 1612) |
|   cavalry | 64% (44 of 69) | 58% (101 of 173) | 60% (145 of 242) |
|   character | 50% (52 of 103) | 32% (34 of 106) | 41% (86 of 209) |
|   chariot | 53% (53 of 100) | 47% (20 of 43) | 51% (73 of 143) |
|   infantry | 59% (145 of 245) | 58% (168 of 290) | 59% (313 of 535) |
|   monster | 48% (22 of 46) | 56% (20 of 36) | 51% (42 of 82) |
|   war machine | 85% (237 of 278) | 77% (95 of 123) | 83% (332 of 401) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (28%) | 2.2 (24%) | 4.4 (26%) |
| CHARGED: it charged | 1.1 (13%) | 1.9 (21%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.3 (4%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.3 (17%) | 1.9 (21%) | 3.2 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.4 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 1.2 (14%) | 2.6 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (4%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.5 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.4 | 83% | 3.9 pts | 24 pts |
| character | 2.5 | 0.9 | 73% | 10.8 pts | 27 pts |
| chariot | 2.0 | 0.9 | 75% | 10.1 pts | 21 pts |
| infantry | 12.2 | 5.2 | 71% | 9.5 pts | 115 pts |
| monster | 1.5 | 0.4 | 79% | 9.0 pts | 13 pts |
| war machine | 9.2 | 6.6 | 64% | 22.6 pts | 208 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.4 | 4.8 |
| Charges that made contact a game | 2.9 | 3.6 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.72 declared, 0.60 contact (25 units) | 0.58 declared, 0.42 contact (12 units) | 0.68 declared, 0.54 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.12 declared, 0.88 contact (8 units) | 1.00 declared, 0.50 contact (10 units) | 1.06 declared, 0.67 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.34 contact (248 units) | 0.60 declared, 0.40 contact (294 units) | 0.55 declared, 0.37 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (43 of 73) | 50% (9 of 18) | 33% (4 of 12) | 54% (56 of 103) |
| Character in a unit | 83% (24 of 29) | 78% (14 of 18) | 100% (5 of 5) | 83% (43 of 52) |
| Character on its own | 86% (37 of 43) | 56% (20 of 36) | 28% (17 of 61) | 53% (74 of 140) |
| Chariot | 65% (11 of 17) | 62% (8 of 13) | - | 63% (19 of 30) |
| Infantry | 49% (46 of 94) | 62% (21 of 34) | 33% (1 of 3) | 52% (68 of 131) |
| Monster | 45% (13 of 29) | 56% (5 of 9) | - | 47% (18 of 38) |
| Monstrous | 71% (10 of 14) | 57% (8 of 14) | - | 64% (18 of 28) |
| War Machines | 67% (38 of 57) | 50% (1 of 2) | - | 66% (39 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (14 of 14); on the table 100% | 38% (39 of 102) | 27% | 55% (12 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 0.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 85% (11 of 13); on the table 85% | 44% (16 of 36) | 44% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (8 of 8); on the table 100% | - | 64% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 93% (13 of 14); on the table 93% | 38% (18 of 48) | 43% | 66% (50 of 76) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 82% (18 of 22); on the table 91% | 39% (54 of 138) | 55% | 46% (25 of 54) | 100% (14 of 14); 6.5 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 88% (15 of 17); on the table 88% | 11% (2 of 18) | 24% | 48% (16 of 33) | 100% (3 of 3); 2.8 uses a game | 71% (10 of 14); 4.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 75% (3 of 4); on the table 75% | - | 51% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 75% (3 of 4); on the table 75% | - | 26% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (11 of 11); on the table 100% | 0% (0 of 18) | 40% | 71% (20 of 28) | 100% (4 of 4); 3.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 25% (3 of 12) | 12% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 83% (5 of 6); on the table 100% | 17% (3 of 18) | 44% | 52% (13 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 92% (11 of 12); on the table 92% | - | 47% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 94% (34 of 36); on the table 94% | 44% (29 of 66) | 37% | 59% (32 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 88% (15 of 17); on the table 100% | 50% (9 of 18) | 46% | 56% (41 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 81% (13 of 16); on the table 88% | 54% (13 of 24) | 36% | 67% (52 of 78) | 57% (4 of 7); 2.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ss-opp-06f55ce-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (32) | 48% (31) | 45% (63) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.50 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.22 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.28 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.22 | 1.25 | 3.47 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 1.06 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.36 | 5.47 | 10.83 |

### Quality by phase: ss-opp-06f55ce-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 51% (69 of 135) | 44% (86 of 194) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (152 of 379) | 53% (134 of 254) |
| Strategy | Close-in objectives charged next turn | 14% (23 of 161) | 16% (36 of 224) |
| Strategy | Support requests answered (helper made contact too) | 76% (13 of 17) | 31% (11 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 64% (7 of 11) |
| Strategy | Joined characters whose unit fought | 40% (20 of 50) | 22% (8 of 36) |
| Strategy | Lone characters that fought | 73% (69 of 95) | 67% (58 of 87) |
| Movement | Charges halted short of contact | 0.3 | 0.2 |
| Movement | Idle units | 1.3 | 1.6 |
| Movement | Points that never moved of their own | 338.9 | 173.1 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 83, net -76 | 33 of 103, net +62 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 83, net +34 | 21 of 103, net +172 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 83, net +142 | 3 of 103, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 of 83, net +110 | 22 of 103, net +25 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (136 of 332) | 49% (185 of 379) |
| Shooting | Points destroyed by shooting units | 85.9 | 29.9 |
| Shooting | War machine shots | 6.6 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (141 of 237) | 42% (40 of 95) |
| Shooting | Points destroyed by war machines | 92.7 | 44.9 |
| Magic | Magic missiles cast | 1.9 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (22 of 69) | 40% (17 of 42) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.9 |
| Magic | Wounds caused by other spells | 0.9 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 48.6 | 28.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.5 / 0.1 | 1.8 / 0.3 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 254.2 | 408.1 |
| Combat | Points run down | 129.1 | 97.2 |
| Combat | Net points per charged fight, damage counted | +62 | +98 |
| Combat | Net per 100 charger points, damage counted | +21.7 | +42.1 |
| Combat | First round won (charged fights) | 71% | 63% |
| Combat | Net points per charged fight | +60 | +94 |
| Combat | Net points per supported fight / lone fight | +111 / +52 | +42 / +101 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 92 | 43 of 115 |
| Game | Points lost | 769.2 | 662.7 |
| Game | VP from objectives | 535.0 | 667.8 |
| Game | Lone holders (player turns) | 2.2 | 3.9 |

- Mine won / drew / lost: 9 / 11 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -244 VP
- The side that went first won 13 of 25 games with a winner
- Points traded per game (both sides' losses): 1432
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-opp-06f55ce-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.1 | -143.6 | 178.7 | 97.8 | 4.5 | -146.2 | 155.9 | 162.9 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 36.4 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.7 | +3.8 | 0.0 | 13.8 | 0.5 | +2.4 | 0.0 | 3.5 |
| BEST FACING | 0.5 | +22.1 | 0.0 | 12.1 | 0.2 | +4.3 | 0.0 | 23.8 |
| BEST FIRST | 1.4 | +65.7 | 21.4 | 38.6 | 0.7 | +23.8 | 20.6 | 31.8 |
| BEST OVERALL | 0.5 | +40.0 | 0.0 | 5.1 | 0.3 | +16.6 | 0.0 | 14.7 |
| BEST PREY | 0.8 | +45.6 | 32.1 | 31.6 | 0.8 | +27.4 | 8.3 | 51.8 |
| BEST PRIZE | 0.0 | +2.1 | 0.0 | 0.0 | 0.1 | -7.7 | 11.1 | 19.3 |
| BIG CHARACTER SAFETY | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 16.6 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 5.5 | 0.0 |
| BLOCKED WHEEL | 0.4 | +4.7 | 0.0 | 7.4 | 0.3 | +2.8 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -11.2 | 30.8 | 5.7 | 0.4 | -68.8 | 43.4 | 11.4 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 139.0 | 15.6 | 0.1 | +0.0 | 0.0 | 4.6 |
| CANNON PLANNED TARGET | 4.9 | +173.4 | 349.0 | 96.7 | 1.9 | +68.4 | 96.4 | 31.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 5.2 | 5.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.2 | 9.6 | 10.6 | 0.2 | +0.0 | 34.1 | 12.1 |
| CAST JOB | 0.9 | +21.9 | 70.4 | 13.2 | 0.6 | +15.9 | 68.1 | 14.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +18.9 | 24.1 | 0.0 | 0.3 | +18.9 | 16.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 11.1 | 0.5 | +0.0 | 0.0 | 29.3 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.8 | +45.9 | 0.0 | 20.8 | 1.4 | +68.1 | 0.0 | 19.5 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 2.9 | 0.3 | -1.0 | 0.0 | 6.4 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 219.5 | 59.6 | 2.6 | +0.0 | 250.0 | 124.9 |
| CHARGE NOW WEIGHED | 0.5 | -33.6 | 11.4 | 22.1 | 0.2 | -22.8 | 21.0 | 25.8 |
| CHARGER SLAIN LOST | 0.5 | -16.8 | 95.8 | 9.1 | 0.5 | -9.4 | 70.5 | 12.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 15.0 | 0.0 | +0.0 | 10.6 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 15.3 | 1.7 | 0.2 | +0.0 | 14.7 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 1.1 | -45.4 | 41.5 | 23.6 |
| COMBAT PIVOT | 0.3 | +0.0 | 19.4 | 31.2 | 0.5 | +0.0 | 9.4 | 14.9 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +24.2 | 11.1 | 11.1 | 0.5 | +43.6 | 7.6 | 41.7 |
| COVER ONCE | 7.7 | -548.7 | 0.0 | 179.2 | 6.8 | -475.4 | 0.0 | 155.8 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 5.1 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +0.9 | 0.0 | 8.7 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +4.1 | 12.4 | 0.0 | 0.5 | +5.6 | 61.7 | 0.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +164.2 | 0.0 | 61.9 | 1.2 | +81.6 | 0.0 | 58.2 |
| FALLBACK BY WORTH | 4.5 | +61.5 | 0.0 | 92.4 | 3.7 | +25.2 | 0.0 | 46.6 |
| FALLS SHORT | - | - | - | - | 14.3 | +212.1 | 0.0 | 198.3 |
| FIGHT LIFT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.1 | 0.0 | 2.2 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 102.5 | 4.8 | +0.0 | 0.0 | 172.8 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +100.5 | 0.0 | 39.2 | 0.8 | +106.1 | 0.0 | 18.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.1 | 0.0 | 13.1 | 0.1 | +4.0 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.2 | 14.2 | 0.0 | 0.1 | -0.4 | 7.1 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.4 | 10.5 | 0.0 | 0.1 | -3.7 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | - | - | - | - | 0.8 | +0.0 | 0.0 | 22.2 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 25.4 | 0.0 | 0.1 | +0.0 | 12.3 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 27.3 | 13.8 | 0.4 | +0.0 | 44.7 | 0.0 |
| HILL BY ITS CHANCE | 0.4 | -50.1 | 0.0 | 0.0 | 0.6 | -77.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.5 | -131.8 | 404.0 | 104.6 | 9.8 | -226.5 | 643.6 | 238.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 5.4 | 0.0 | 0.4 | +6.2 | 3.5 | 3.9 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 3.5 | 5.0 |
| HUNT IN PAIRS | 0.4 | +19.5 | 0.0 | 10.2 | 0.5 | +31.0 | 0.0 | 28.8 |
| HUNT KEPT | 0.0 | +0.5 | 5.4 | 0.0 | 0.2 | +8.1 | 17.2 | 4.8 |
| HUNT RESULT | 0.0 | +6.1 | 0.0 | 0.0 | 0.4 | +37.6 | 11.5 | 9.0 |
| HUNT THE GUNS | 0.0 | +6.5 | 5.4 | 0.0 | 0.4 | +121.9 | 18.1 | 0.0 |
| IDLE COST | 14.8 | -237.8 | 0.0 | 175.1 | 8.7 | -111.4 | 0.0 | 175.5 |
| INVITES THE FIGHT | 1.2 | +8.1 | 24.6 | 28.8 | 0.6 | +4.6 | 45.9 | 35.8 |
| JOINT CHARGE PLAN | 0.1 | +0.8 | 6.6 | 3.1 | 0.1 | +26.7 | 18.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.7 | 0.0 | 0.0 | 0.2 | -5.9 | 56.9 | 24.6 |
| KEEP FALLS | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 1.4 | 0.1 | +0.3 | 1.0 | 5.4 |
| KEEPS ITS TARGET | 1.5 | +45.8 | 115.0 | 30.5 | 2.5 | +75.0 | 215.3 | 68.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +77.6 | 153.7 | 28.6 | 2.1 | +92.3 | 182.7 | 67.3 |
| KILLS COUNT NEXT TURN | 4.6 | +169.5 | 178.8 | 75.2 | 5.8 | +254.6 | 342.2 | 147.9 |
| LONE CHARACTER SAFE SPOT | 0.2 | +10.7 | 2.9 | 1.2 | 0.2 | +10.0 | 0.0 | 4.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 8.1 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -3.5 | 38.9 | 13.6 | 0.7 | -2.1 | 38.5 | 13.9 |
| LOST CHARGE | 2.4 | -33.9 | 69.9 | 59.4 | 1.9 | -33.4 | 97.5 | 65.7 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.7 | 0.0 | 1.2 | 0.2 | -22.2 | 0.0 | 6.3 |
| MAKE SURE TOGETHER | 0.4 | +32.0 | 6.6 | 11.7 | 0.7 | +56.9 | 26.8 | 19.9 |
| MANOEUVRE | 0.3 | +8.1 | 0.0 | 0.0 | 0.3 | +3.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.7 | 0.0 | 4.5 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +13.4 | 0.0 | 15.6 | 0.6 | +21.2 | 0.0 | 10.6 |
| MARCH ODDS | 0.2 | +14.2 | 4.6 | 10.2 | 0.1 | +8.3 | 7.4 | 0.0 |
| MARCH OVER CASTS | 0.5 | +45.6 | 0.0 | 23.1 | 0.3 | +32.7 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 5.4 | +81.1 | 0.0 | 131.2 | 5.8 | +84.4 | 0.0 | 114.7 |
| MISSILES IN THE MOVE | 4.0 | +104.9 | 0.0 | 111.5 | 3.4 | +72.6 | 0.0 | 60.4 |
| MISSILES NEXT TURN | 4.6 | +73.1 | 0.0 | 138.5 | 3.7 | +44.7 | 0.0 | 86.4 |
| MODEL FACING | 0.3 | +71.6 | 0.0 | 3.3 | 0.3 | +120.9 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 30.8 | 0.0 |
| MOVE AND CAST | 0.1 | +5.6 | 0.0 | 13.3 | 0.2 | +7.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -15.0 | 3.4 | 42.1 | 0.2 | -6.2 | 0.0 | 21.7 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.9 | +143.9 | 122.2 | 45.8 | 4.7 | +364.2 | 247.8 | 110.7 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | - | - | - | - | 10.2 | +609.5 | 0.0 | 166.2 |
| NEEDED THERE | 0.1 | +0.2 | 6.9 | 0.0 | 0.0 | +4.1 | 0.0 | 0.0 |
| NO FORCED ADVANCE | - | - | - | - | 3.2 | +0.0 | 0.0 | 27.2 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +6.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.4 | -14.8 | 51.1 | 0.0 | 0.3 | -11.9 | 31.9 | 2.8 |
| NOT TURNED | 5.4 | +85.3 | 0.0 | 117.8 | 5.5 | +34.2 | 0.0 | 163.5 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 27.2 | 0.7 | -0.6 | 0.0 | 11.2 |
| OFF BEST | 16.1 | -664.3 | 1.7 | 293.6 | 14.9 | -551.7 | 16.7 | 260.8 |
| ONE FIGHT FORMULA | 8.5 | -131.6 | 15.8 | 178.0 | 7.3 | -158.7 | 44.3 | 207.6 |
| ONE OBJECTIVE FORMULA | 2.4 | -136.2 | 0.0 | 33.1 | 2.8 | -121.2 | 0.0 | 34.5 |
| OPENS A LANE | 0.1 | +0.3 | 4.9 | 3.5 | 0.1 | +0.2 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +9.7 | 6.2 | 0.0 | 0.2 | +21.2 | 6.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.7 | 45.9 | 9.2 | 0.5 | +7.6 | 46.3 | 13.7 |
| PATHS CROSS | 1.9 | +97.3 | 0.0 | 25.3 | 2.2 | +99.8 | 0.0 | 54.7 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -1.1 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +1517.9 | 1314.7 | 1015.3 | 38.8 | +1152.2 | 1244.9 | 820.4 |
| PURSUES BIG PREY | 0.1 | -9.1 | 0.0 | 0.0 | 0.1 | -6.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +13.8 | 0.0 | 18.6 | 1.4 | +20.0 | 0.0 | 38.6 |
| RANDOM MOVER NO PROMISE | 0.2 | -8.4 | 0.0 | 4.7 | 0.2 | -6.8 | 4.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -7.8 | 0.0 | 16.7 | 1.0 | -33.2 | 0.0 | 11.6 |
| REDIRECT COUNTER | 2.2 | +117.5 | 0.0 | 41.3 | 3.4 | +266.0 | 0.0 | 40.4 |
| REDIRECT WEIGHED | 0.1 | +5.2 | 3.5 | 0.0 | 0.4 | -0.6 | 8.2 | 5.4 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 26.2 |
| RESERVE FALL BACK | 0.2 | +6.5 | 0.0 | 2.2 | 1.0 | +18.6 | 0.0 | 29.2 |
| RESTRAINS TO SHOOT | 0.1 | +2.7 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +83.4 | 223.5 | 71.3 | 2.9 | +60.0 | 245.3 | 95.1 |
| RISK ONCE | 4.3 | +130.3 | 47.4 | 151.5 | 2.7 | +165.5 | 15.2 | 185.2 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.8 | +32.5 | 0.0 | 24.8 | 1.1 | +73.6 | 0.0 | 24.5 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -18.8 | 0.0 | 2.8 | 0.4 | -35.3 | 0.0 | 3.3 |
| SEARCH SPOT | 1.8 | +86.2 | 0.0 | 28.1 | 3.1 | +91.6 | 0.0 | 40.6 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.7 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.2 | +0.4 | 0.0 | 21.9 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +36.4 | 13.3 | 14.7 | 1.8 | +125.0 | 66.1 | 69.7 |
| SET-UP ANY TARGET | 0.2 | +23.0 | 11.1 | 11.1 | 0.2 | +28.5 | 3.2 | 18.9 |
| SET-UP MISSED | - | - | - | - | 0.0 | +4.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.2 | 0.0 | 1.5 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +71.1 | 53.9 | 18.5 | 0.7 | +22.3 | 8.8 | 23.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 156.4 | 13.0 | 0.2 | +0.0 | 38.7 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +588.0 | 0.0 | 273.8 | 11.7 | +320.0 | 0.0 | 180.2 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +34.7 | 11.1 | 11.1 | 0.2 | +41.8 | 3.2 | 26.5 |
| SPELL WORTH | 0.7 | +13.2 | 65.4 | 52.4 | 1.5 | +26.3 | 58.4 | 58.4 |
| SPELLS IN THE FIGHT | 0.6 | +4.6 | 72.4 | 40.8 | 0.7 | -12.6 | 97.9 | 6.5 |
| STABLE ROLE | 10.7 | +0.0 | 362.4 | 124.6 | 11.7 | +0.0 | 427.1 | 128.2 |
| STANDS TO CAST | 0.1 | +0.5 | 0.0 | 2.2 | - | - | - | - |
| STAY WEIGHED | 0.0 | +9.0 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.5 | 5.4 | 0.0 | 0.2 | +14.1 | 31.8 | 0.9 |
| STOPS SHORT OF THE FLANK | 0.4 | +14.7 | 0.0 | 0.0 | 0.2 | +11.3 | 0.0 | 3.5 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.1 | -54.4 | 420.1 | 106.3 | 8.1 | -71.4 | 385.2 | 78.4 |
| SUPPORTS | 4.1 | +59.6 | 232.4 | 63.5 | 5.9 | +73.7 | 192.5 | 33.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.6 | 10.5 | 0.0 | 0.1 | -3.6 | 12.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.2 | 13.3 | 0.0 | 0.8 | +9.0 | 29.1 | 18.8 |
| THROUGH LINE OF FIRE | 0.2 | +5.2 | 0.0 | 0.0 | 0.2 | +10.6 | 0.0 | 12.0 |
| TIME ON OUR SIDE | - | - | - | - | 11.1 | +179.4 | 0.0 | 102.8 |
| TURN WORTH | 0.4 | -26.5 | 33.6 | 9.4 | 0.1 | -5.4 | 7.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +1.8 | 0.0 | 3.1 | 0.4 | +4.0 | 2.4 | 10.2 |
| WAIT AFTER COSTS | 5.9 | -275.8 | 193.8 | 75.6 | 7.6 | -377.1 | 445.0 | 170.1 |
| WALKS TO THE FIGHT | 1.3 | +11.5 | 34.5 | 7.4 | 1.3 | +7.3 | 67.8 | 23.5 |
| WAR ENGINE CHARGES | 0.1 | +16.8 | 17.2 | 0.0 | 0.1 | +4.2 | 10.2 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 16.9 | 16.8 | 0.5 | +0.0 | 25.4 | 5.1 |
| WEARS DOWN | 1.1 | +45.5 | 92.8 | 32.3 | 1.8 | +50.3 | 175.2 | 81.3 |
| WHO HITS BACK | 0.2 | +27.2 | 0.0 | 32.2 | 0.1 | +7.8 | 0.0 | 22.4 |
| WHOLE FIGHT | 0.2 | +11.2 | 36.4 | 8.6 | 0.3 | +16.6 | 48.3 | 2.8 |
| WHOLE FIGHT GAIN | 0.4 | +37.5 | 72.1 | 12.9 | 0.7 | +45.2 | 62.3 | 12.9 |
| WIDER SPREAD | 2.4 | -8.4 | 231.8 | 71.3 | 3.5 | -4.0 | 315.9 | 75.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 1.2 | 13.9 |

### Rule changes: ss-opp-06f55ce-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1116 | 1116 | 1116 | 31.00 | -43775 | -39.2 |
| SEARCH SPOT | 177 | 177 | 173 | 4.81 | +6400 | +37.0 |
| MOVE TO CHARGE | 275 | 275 | 156 | 4.33 | +7196 | +46.1 |
| SUPPORTS | 359 | 359 | 152 | 4.22 | +1692 | +11.1 |
| PATHS CROSS | 149 | 149 | 149 | 4.14 | +7096 | +47.6 |
| KILLS COUNT NEXT TURN | 376 | 376 | 126 | 3.50 | +4690 | +37.2 |
| FACES THE THREAT | 125 | 125 | 125 | 3.47 | +8848 | +70.8 |
| NO FORCED ADVANCE | 114 | 114 | 114 | 3.17 | +1574 | +13.8 |
| NEARER NOT NEEDED | 369 | 253 | 108 | 3.00 | +1748 | +16.2 |
| SHOTS IN THE MOVE | 913 | 602 | 89 | 2.47 | +2262 | +25.4 |
| WAIT AFTER COSTS | 484 | 484 | 89 | 2.47 | +1604 | +18.0 |
| COVER ONCE | 524 | 322 | 80 | 2.22 | +1199 | +15.0 |
| BEST FIRST | 77 | 77 | 77 | 2.14 | +3220 | +41.8 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +3818 | +57.0 |
| FALLBACK BY WORTH | 296 | 296 | 63 | 1.75 | +3119 | +49.5 |
| FOLLOW UP WEIGHED | 63 | 63 | 63 | 1.75 | +7437 | +118.0 |
| TIME ON OUR SIDE | 399 | 251 | 62 | 1.72 | +184 | +3.0 |
| ADVANCE WORTH | 345 | 345 | 58 | 1.61 | +1010 | +17.4 |
| FALLS SHORT | 515 | 324 | 58 | 1.61 | +92 | +1.6 |
| REDIRECT COUNTER | 201 | 109 | 58 | 1.61 | +3265 | +56.3 |
| ARTILLERY RE-ROLL WEIGHED | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| MISSILES IN THE MOVE | 265 | 171 | 48 | 1.33 | +1046 | +21.8 |
| CANNON PLANNED TARGET | 247 | 247 | 44 | 1.22 | -713 | -16.2 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +903 | +20.5 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK ONCE | 254 | 177 | 41 | 1.14 | +1337 | +32.6 |
| CHAFF IN THE MOVE | 81 | 78 | 40 | 1.11 | +1051 | +26.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 183 | 176 | 40 | 1.11 | +1046 | +26.2 |
| HONEST WORTH | 623 | 619 | 38 | 1.06 | +314 | +8.3 |
| ONE FIGHT FORMULA | 570 | 356 | 38 | 1.06 | +151 | +4.0 |
| WALKS TO THE FIGHT | 93 | 93 | 38 | 1.06 | +210 | +5.5 |
| MARCH CHECK | 37 | 35 | 35 | 0.97 | +1387 | +39.6 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 34 | 0.94 | +1218 | +35.8 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| MAX FOR POSITIONING | 402 | 270 | 32 | 0.89 | +77 | +2.4 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 32 | 0.89 | +1403 | +43.9 |
| CHARGE NOW FIRST | 164 | 164 | 31 | 0.86 | -871 | -28.1 |
| BEST OVERALL | 30 | 30 | 30 | 0.83 | +2037 | +67.9 |
| HARD STAY DROPPED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| SHOT REPLANNED | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 27 | 27 | 27 | 0.75 | +1378 | +51.0 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +272 | +10.5 |
| KILLS COUNT | 133 | 130 | 26 | 0.72 | +1060 | +40.8 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +952 | +38.1 |
| KEEPS ITS TARGET | 145 | 145 | 25 | 0.69 | +506 | +20.2 |
| SET UP TOGETHER | 85 | 66 | 25 | 0.69 | +1532 | +61.3 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| MODEL FACING | 22 | 22 | 22 | 0.61 | +6931 | +315.0 |
| STOPS SHORT OF THE FLANK | 22 | 22 | 22 | 0.61 | +934 | +42.4 |
| INVITES THE FIGHT | 68 | 68 | 21 | 0.58 | +144 | +6.9 |
| WHOLE FIGHT GAIN | 38 | 36 | 21 | 0.58 | +761 | +36.2 |
| IDLE COST | 844 | 512 | 20 | 0.56 | +232 | +11.6 |
| BEST PREY | 56 | 56 | 19 | 0.53 | +691 | +36.4 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -41 | -2.2 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +640 | +33.7 |
| WEARS DOWN | 104 | 102 | 19 | 0.53 | +828 | +43.6 |
| CAST JOB | 53 | 53 | 18 | 0.50 | +530 | +29.4 |
| WAR ENGINE JOBS | 45 | 45 | 17 | 0.47 | -488 | -28.7 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTING BLOCK | 27 | 27 | 15 | 0.42 | +584 | +39.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MANOEUVRE | 21 | 21 | 15 | 0.42 | +421 | +28.1 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +570 | +38.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1121 | +80.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +581 | +44.7 |
| MOVE AND CAST | 12 | 12 | 12 | 0.33 | +465 | +38.7 |
| HUNT IN PAIRS | 34 | 25 | 10 | 0.28 | +485 | +48.5 |
| LOST CHARGE | 153 | 152 | 10 | 0.28 | +244 | +24.4 |
| REFUSING RETIRES | 18 | 18 | 10 | 0.28 | -5 | -0.5 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +77 | +8.6 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -298 | -33.2 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -560 | -70.1 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MAKE SURE TOGETHER | 40 | 18 | 7 | 0.19 | +268 | +38.2 |
| OPENS UP | 11 | 11 | 7 | 0.19 | +435 | +62.2 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | +8 | +1.3 |
| MISSILES NEXT TURN | 300 | 179 | 6 | 0.17 | +21 | +3.5 |
| OVERRUNS AWAY | 29 | 28 | 6 | 0.17 | +96 | +16.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +232 | +38.7 |
| WHOLE FIGHT | 18 | 18 | 6 | 0.17 | +232 | +38.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -302 | -60.4 |
| SUPPORT NARROWED | 511 | 511 | 5 | 0.14 | -66 | -13.1 |
| DEFENSIVE ARMY | 7 | 7 | 4 | 0.11 | -105 | -26.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +227 | +56.8 |
| WAR ENGINE CHARGES | 7 | 7 | 4 | 0.11 | +185 | +46.1 |
| WIDER SPREAD | 214 | 206 | 4 | 0.11 | +29 | +7.2 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +299 | +99.6 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 3 | 0.08 | +0 | +0.0 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +335 | +111.7 |
| STOPS | 10 | 10 | 3 | 0.08 | +66 | +22.0 |
| SURE REACH TOGETHER | 40 | 31 | 3 | 0.08 | +1 | +0.3 |
| BACKUP TARGETS | 42 | 20 | 2 | 0.06 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 23 | 22 | 2 | 0.06 | +15 | +7.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +43 | +21.6 |
| HUNT ADVANCE | 14 | 14 | 2 | 0.06 | +17 | +8.3 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +281 | +140.4 |
| ONE OBJECTIVE FORMULA | 187 | 92 | 2 | 0.06 | +3 | +1.7 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +113 | +56.3 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.06 | -48 | -24.0 |
| REDIRECT BY WHAT IT STOPS | 52 | 52 | 2 | 0.06 | +110 | +55.0 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -12 | -5.9 |
| TWO OR MORE ARRIVE | 17 | 11 | 2 | 0.06 | +15 | +7.3 |
| CARRIES OUT SET-UP | 13 | 13 | 1 | 0.03 | -6 | -5.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -1 | -0.7 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -44 | -44.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +3 | +2.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| KEEPS ITS PREY | 7 | 7 | 1 | 0.03 | +4 | +3.7 |
| MOVE SPELL IN RANGE | 5 | 4 | 1 | 0.03 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +157 | +156.6 |
| OPENS A LANE | 7 | 4 | 1 | 0.03 | +5 | +4.7 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -15 | -15.3 |
| SPELLS IN THE FIGHT | 45 | 45 | 1 | 0.03 | +36 | +36.2 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -27 | -27.4 |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 25 | 22 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 35 | 32 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 40 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 372 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 24 | 23 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 39 | 39 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 10 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LONG SHOT | 42 | 40 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 4 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 390 | 390 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 47 | not checked | - | - | - | - |
| PLAN RESULT | 2702 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 26 | 26 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 79 | not checked | - | - | - | - |
| STABLE ROLE | 806 | 802 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |

### Off best figure: ss-opp-06f55ce-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.47 | 13.11 | 39.8 |
| FALLBACK | gate | 0.86 | 0.56 | 41.8 |
| TURN GATE | gate | 0.44 | 0.53 | 28.5 |
| CHARGE NOW FIRST | rule | 0.28 | 0.53 | 30.0 |
| WAR ENGINE JOBS | rule | 0.31 | 0.17 | 28.7 |
| AFTERMATH BAND | gate | 0.08 | 0.31 | 3.3 |
| CANNON PLANNED TARGET | rule | 0.19 | 0.11 | 77.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.25 | 86.2 |
| CHAFF PASSED | rule | 0.11 | 0.14 | 4.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.14 | 33.2 |
| PATHS CROSS | rule | 0.11 | 0.11 | 30.7 |
| PURSUES BIG PREY | rule | 0.11 | 0.11 | 70.1 |
| NEARER NOT NEEDED | rule | - | 0.19 | 7.9 |
| BEST PRIZE | rule | 0.03 | 0.11 | 60.4 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 2.7 |
| DEFENSIVE ARMY | rule | - | 0.11 | 26.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 16.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.08 | 33.2 |
| BLOCKED WHEEL | rule | 0.08 | - | 29.9 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 17.2 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | 0.03 | 3.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.03 | 10.8 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 34.2 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.03 | 5.6 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.03 | 24.0 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 13.0 |
| REFUSING RETIRES | rule | 0.06 | - | 1.0 |
| STANDS TO CAST | rule | 0.06 | - | 5.9 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 5.9 |
| CATCH ODDS | rule | 0.03 | - | 0.7 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 44.5 |
| FACES THE THREAT | rule | - | 0.03 | 10.4 |
| MARCH ODDS | rule | - | 0.03 | 6.3 |
| NO REASON | gate | - | 0.03 | 14.2 |
| SAFE SURE CHARGE | rule | - | 0.03 | 15.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.8 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 27.4 |

### Plans: ss-opp-06f55ce-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.1 | 13% | 164 | 220 | 134% |
| Mine | charge | 3.1 | 61% | 241 | 296 | 122% |
| Mine | close in | 4.5 | 30% | 219 | 156 | 71% |
| Mine | hold | 5.6 | 26% | 396 | 0 | 0% |
| Mine | join | 0.6 | 91% | 19 | 0 | 0% |
| Mine | shoot | 8.6 | 63% | 274 | 847 | 309% |
| Mine | support | 4.8 | 88% | 44 | 0 | 0% |
| Opponent | advance | 8.2 | 17% | 124 | 228 | 183% |
| Opponent | charge | 4.7 | 57% | 374 | 428 | 114% |
| Opponent | close in | 6.2 | 29% | 460 | 181 | 39% |
| Opponent | hold | 6.1 | 34% | 402 | 0 | 0% |
| Opponent | join | 1.2 | 95% | 55 | 0 | 0% |
| Opponent | shoot | 5.2 | 59% | 167 | 316 | 189% |
| Opponent | support | 7.3 | 94% | 60 | 0 | 0% |

### Packages: hunt the guns, ss-opp-06f55ce-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 56 |
| Opponent | 0.4 | 13 | 0 | 31% | 31% | 0% | 2.5 | 338 | 104 | 15% | 124 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 258 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 244 | 0 | 0% | 40 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 514 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 75% | 75% | 0% | 2.7 | 512 | 238 | 25% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Tomb Kings of Khemri | 0.8 | 4 | 0 | 25% | 25% | 0% | 2.0 | 215 | 100 | 25% | 53 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 331 | 0 | 0% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 206 | 0 | 0% | 75 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 350 | 0 | 0% | 71 |

### Battle groups: ss-opp-06f55ce-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 25% | 45% | 0% | - | 30% | 0% | 35% | 35% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 17% | 90% | 20% | 25% | 6% | 12% | 12% | 69% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-opp-06f55ce-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 0 | 20% | 3.2 | 0 (3) | 0 (2) | - | - | 0 (5) |
| Mine | Chaff | 34 | 68 (34) | 21 | 47 | 57 | 38% | 2.8 | 95 (19) | 81 (7) | 5 (8) | 96 (23) | 5 (11) |
| Mine | Character | 123 | 42 (123) | 41 | 1 | 36 | 21% | 2.5 | 45 (40) | 44 (54) | 33 (14) | 43 (53) | 45 (55) |
| Mine | Clean-up | 21 | 35 (21) | 10 | 24 | 37 | 48% | 3.0 | 26 (5) | 34 (13) | 63 (3) | 51 (13) | 18 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 55 (48) | 26 | 28 | 52 | 23% | 2.6 | 47 (23) | 87 (16) | 22 (9) | 48 (29) | 65 (19) |
| Mine | Fragile | 5 | 63 (5) | 63 | 0 | 40 | 0% | 2.4 | - | 105 (3) | 0 (2) | 63 (5) | - |
| Mine | Hammer | 57 | 48 (57) | 34 | 14 | 37 | 21% | 2.2 | 16 (18) | 58 (29) | 79 (10) | 40 (38) | 61 (19) |
| Mine | Holder | 28 | 40 (28) | 3 | 37 | 33 | 43% | 3.6 | 23 (11) | 69 (8) | 37 (8) | 56 (20) | 7 (7) |
| Mine | Shooter | 41 | 65 (41) | 17 | 49 | 53 | 5% | 1.5 | 118 (5) | 65 (30) | 35 (6) | 91 (25) | 25 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 34 | 50% | 4.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 62 (59) | 62 | 0 | 53 | 2% | 1.2 | 18 (10) | 70 (37) | 69 (12) | 63 (10) | 62 (49) |
| Mine | Wizard | 22 | 4 (22) | 4 | 0 | 34 | 5% | 2.7 | 2 (7) | 12 (7) | 0 (4) | 11 (7) | 0 (11) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Chaff | 76 | 57 (76) | 27 | 30 | 40 | 43% | 2.4 | 42 (32) | 61 (19) | 74 (25) | 79 (54) | 7 (22) |
| Opponent | Character | 97 | 54 (97) | 53 | 1 | 29 | 28% | 2.6 | 63 (40) | 57 (40) | 28 (7) | 55 (57) | 63 (30) |
| Opponent | Clean-up | 19 | 58 (19) | 55 | 3 | 45 | 32% | 3.0 | 83 (9) | 16 (10) | - | 71 (14) | 17 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Fast Hammer | 48 | 45 (48) | 33 | 12 | 41 | 29% | 2.3 | 38 (22) | 31 (16) | 88 (10) | 40 (28) | 53 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 60% | 2.0 | - | 0 (3) | 0 (2) | 0 (3) | 0 (2) |
| Opponent | Hammer | 70 | 41 (70) | 35 | 6 | 47 | 24% | 2.9 | 16 (17) | 47 (42) | 46 (11) | 50 (43) | 28 (27) |
| Opponent | Holder | 35 | 104 (35) | 4 | 100 | 9 | 40% | 3.1 | 103 (5) | 111 (24) | 65 (6) | 136 (21) | 54 (14) |
| Opponent | Shooter | 33 | 64 (33) | 13 | 51 | 38 | 0% | 1.7 | 21 (8) | 81 (19) | 54 (6) | 94 (22) | 17 (11) |
| Opponent | Support | 3 | 106 (3) | 106 | 0 | 0 | 67% | 5.0 | 0 (1) | 422 (1) | 0 (1) | 0 (2) | 422 (1) |
| Opponent | War machine | 24 | 71 (24) | 71 | 0 | 36 | 4% | 1.6 | 14 (6) | 105 (14) | 33 (4) | 38 (3) | 76 (21) |
| Opponent | Wizard | 26 | 0 (26) | 0 | 0 | 37 | 8% | 1.8 | 0 (9) | 0 (6) | 0 (6) | 0 (7) | 0 (14) |

### Charged fights: ss-opp-06f55ce-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 173 | 243 | 1.5 | 1.2 | 162 | 9 | +153 | 3 of 6 | 5 of 5 | +120 | +160 |
| Mine | Chaos Dwarfs | 4 | 170 | 422 | 3.0 | 1.2 | 141 | 33 | +107 | 8 of 12 | 8 of 12 | +516 | +70 |
| Mine | Dwarfen Mountain Holds | 4 | 588 | 0 | 1.2 | 1.0 | 0 | 95 | -95 | 2 of 5 | 1 of 5 | - | -95 |
| Mine | Empire of Man | 5 | 363 | 0 | 0.8 | 1.0 | 0 | 95 | -95 | 2 of 4 | 3 of 4 | - | -95 |
| Mine | Grand Cathay | 4 | 423 | 122 | 2.8 | 1.1 | 44 | 0 | +44 | 5 of 11 | 9 of 11 | +329 | +16 |
| Mine | High Elf Realms | 4 | 94 | 454 | 4.0 | 1.1 | 113 | 9 | +104 | 3 of 16 | 15 of 16 | +125 | +103 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1074 | 5.0 | 1.2 | 215 | 55 | +159 | 2 of 5 | 3 of 5 | -277 | +268 |
| Mine | Lizardmen | 1 | 45 | 539 | 5.0 | 1.2 | 108 | 137 | -29 | 3 of 5 | 2 of 5 | +120 | -66 |
| Mine | Ogre Kingdoms | 1 | 186 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | +0 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 295 | 5.0 | 1.4 | 59 | 11 | +48 | 2 of 5 | 3 of 5 | +118 | +2 |
| Mine | Skaven | 2 | 160 | 0 | 1.0 | 1.0 | 0 | 306 | -306 | 1 of 2 | 1 of 2 | - | -306 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 515 | 5.0 | 1.2 | 103 | 11 | +92 | 0 of 5 | 5 of 5 | +125 | +84 |
| Mine | Vampire Counts | 3 | 0 | 260 | 3.3 | 1.3 | 78 | 30 | +48 | 1 of 10 | 7 of 10 | +20 | +55 |
| Mine | Warriors of Chaos | 1 | 19 | 1078 | 4.0 | 1.0 | 270 | 71 | +198 | 1 of 4 | 2 of 4 | - | +198 |
| **Mine** | all armies | 36 | 227 | 257 | 2.6 | 1.2 | 100 | 40 | +60 | 33 of 92 | 65 of 91 | +111 | +52 |
| Opponent | Dwarfen Mountain Holds | 2 | 296 | 115 | 4.0 | 1.4 | 29 | 41 | -12 | 2 of 8 | 4 of 8 | +49 | -49 |
| Opponent | Empire of Man | 2 | 558 | 0 | 1.0 | 1.0 | 0 | 263 | -263 | 1 of 2 | 1 of 2 | - | -263 |
| Opponent | Grand Cathay | 2 | 427 | 714 | 3.5 | 1.3 | 204 | 0 | +204 | 5 of 7 | 6 of 7 | +324 | +156 |
| Opponent | Kingdom of Bretonnia | 1 | 280 | 95 | 3.0 | 1.0 | 32 | 0 | +32 | 2 of 3 | 2 of 3 | - | +32 |
| Opponent | Ogre Kingdoms | 3 | 0 | 504 | 5.0 | 1.1 | 101 | 48 | +53 | 3 of 15 | 9 of 15 | -2 | +61 |
| Opponent | Skaven | 1 | 281 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 48 | 577 | 3.2 | 1.1 | 178 | 121 | +57 | 6 of 13 | 7 of 13 | -772 | +126 |
| Opponent | Vampire Counts | 6 | 0 | 503 | 3.0 | 1.1 | 168 | 6 | +162 | 8 of 18 | 12 of 18 | +164 | +162 |
| Opponent | Warriors of Chaos | 8 | 8 | 235 | 2.0 | 1.1 | 117 | 18 | +100 | 6 of 16 | 11 of 16 | +0 | +106 |
| Opponent | Wood Elf Realms | 7 | 49 | 667 | 4.7 | 1.1 | 142 | 25 | +117 | 10 of 33 | 21 of 33 | +83 | +120 |
| **Opponent** | all armies | 36 | 103 | 420 | 3.2 | 1.1 | 132 | 38 | +94 | 43 of 115 | 73 of 115 | +42 | +101 |

### Effective charges: ss-opp-06f55ce-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 1 (net +0) | 2 (net +88) | 0 | 2 (net +280) | 1 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 12 | 2 (net -62) | 0 | 3 (net -26) | 4 (net +233) | 1 (net +516) | 1 (net +45) | 1 | 27% (3 of 11) |
| Mine | Dwarfen Mountain Holds | 5 | 4 (net -119) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 4 | 0 | 0 | 0 | 2 (net -190) | 0 | 2 (net +0) | 0 | 0% (0 of 4) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 2 (net +0) | 4 (net +82) | 0 | 4 (net +40) | 0 | 18% (2 of 11) |
| Mine | High Elf Realms | 16 | 0 | 1 (net -143) | 4 (net +242) | 3 (net +100) | 4 (net +78) | 2 (net +117) | 2 | 29% (4 of 14) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 1 (net +375) | 3 (net +141) | 1 (net +0) | 0 | 0 | 0 | 60% (3 of 5) |
| Mine | Lizardmen | 5 | 2 (net +116) | 0 | 1 (net -684) | 2 (net +153) | 0 | 0 | 0 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 1 (net +60) | 1 (net +190) | 2 | 33% (1 of 3) |
| Mine | Skaven | 2 | 1 (net -612) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +70) | 0 | 0 | 1 (net +140) | 1 (net +125) | 1 (net +125) | 1 | 0% (0 of 4) |
| Mine | Vampire Counts | 10 | 1 (net +0) | 0 | 1 (net -45) | 4 (net +38) | 1 (net +125) | 2 (net +62) | 1 | 11% (1 of 9) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 1 (net -51) | 1 (net +190) | 0 | 2 (net +327) | 0 | 25% (1 of 4) |
| Opponent | Dwarfen Mountain Holds | 8 | 4 (net -82) | 0 | 2 (net +42) | 1 (net +65) | 0 | 1 (net +81) | 0 | 25% (2 of 8) |
| Opponent | Empire of Man | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net -526) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 7 | 0 | 0 | 4 (net +252) | 2 (net +84) | 0 | 1 (net +252) | 0 | 57% (4 of 7) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Opponent | Ogre Kingdoms | 15 | 5 (net +101) | 0 | 4 (net +59) | 2 (net +84) | 0 | 1 (net +193) | 3 | 33% (4 of 12) |
| Opponent | Tomb Kings of Khemri | 13 | 4 (net -192) | 0 | 2 (net +351) | 3 (net +155) | 0 | 1 (net +81) | 3 | 20% (2 of 10) |
| Opponent | Vampire Counts | 18 | 6 (net +66) | 1 (net +185) | 5 (net +237) | 3 (net +257) | 1 (net +72) | 2 (net +152) | 0 | 28% (5 of 18) |
| Opponent | Warriors of Chaos | 16 | 4 (net +0) | 2 (net +198) | 0 | 2 (net +166) | 2 (net +48) | 5 (net +47) | 1 | 0% (0 of 15) |
| Opponent | Wood Elf Realms | 33 | 9 (net +250) | 0 | 3 (net +130) | 8 (net +139) | 0 | 9 (net -8) | 4 | 10% (3 of 29) |

### Charged fights, damage counted: ss-opp-06f55ce-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 171 | 337 | -76 | 51 | 128 | -77 | -45.0 |
| Mine | 50-54% | 2 | 209 | 195 | +116 | 206 | 72 | +134 | +64.4 |
| Mine | Effective (55-75%) | 17 | 267 | 257 | +34 | 140 | 97 | +43 | +16.0 |
| Mine | 76-89% | 25 | 311 | 200 | +86 | 133 | 39 | +94 | +30.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 231 | 147 | +110 | 123 | 13 | +110 | +47.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 535 | 106 | +142 | 146 | 19 | +126 | +23.6 |
| Mine | No odds | 9 | 334 | 160 | +28 | 42 | 17 | +25 | +7.5 |
| Mine | All fights | 92 | 288 | 205 | +60 | 115 | 53 | +62 | +21.7 |
| Opponent | Long shot (under 50%) | 33 | 185 | 239 | +62 | 148 | 89 | +58 | +31.4 |
| Opponent | 50-54% | 3 | 293 | 215 | +193 | 270 | 22 | +248 | +84.7 |
| Opponent | Effective (55-75%) | 21 | 240 | 191 | +172 | 202 | 38 | +164 | +68.5 |
| Opponent | 76-89% | 21 | 250 | 171 | +147 | 172 | 21 | +152 | +60.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 265 | 149 | +25 | 110 | 66 | +44 | +16.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 362 | 56 | +56 | 56 | 2 | +53 | +14.7 |
| Opponent | No odds | 12 | 229 | 192 | +64 | 108 | 32 | +76 | +33.0 |
| Opponent | All fights | 115 | 234 | 190 | +94 | 152 | 53 | +98 | +42.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-opp-06f55ce-p2 | move | 355 | 85 (24%) | 60 (17%) | 47 (13%) | 223 (63%) |
| ss-opp-06f55ce-p2 | objective | 385 | 59 (15%) | 46 (12%) | 45 (12%) | 281 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

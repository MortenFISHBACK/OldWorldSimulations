# Doctrine scorecard: ss-opp-06f55ce-p3

### Scorecard: ss-opp-06f55ce-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 14 | 2 | 0 | 4 | 1 | 0 | 0 | 60 |
| L0210 | 6 | 1 | Mine | yes | 6 | - | 0 | 5 | 0 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | yes | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 251 |
| L0226 | 4 | 1 | Opponent | no | 11 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 0 | 1 | 0 | 0 | 0 | 598 |
| L0327 | 3 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 11 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 0 | 0 | 0 | 468 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 593 |
| L0516 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 0 | 0 | 0 | 798 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 4 | 6 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 830 |
| L0725 | 5 | 1 | Mine | no | - | 6 | 1 | 3 | 0 | 0 | 0 | 800 |
| L0725 | 5 | 1 | Opponent | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 717 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 717 |
| L0831 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 5 | 0 | 0 | 365 |
| L0922 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 945 |
| L0922 | 4 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 4 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 414 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 9 | 3 | 3 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 60 |
| L1422 | 6 | 1 | Mine | no | 9 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 3 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 2 | 2 | 4 | 0 | 0 | 0 | 250 |
| L1633 | 1 | 1 | Mine | no | 8 | 4 | 4 | 2 | 0 | 0 | 0 | 100 |
| L1633 | 1 | 1 | Opponent | yes | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 184 |
| L1731 | 3 | 1 | Opponent | yes | 6 | 2 | 5 | 1 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 4 | 4 | 2 | 0 | 2 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 3 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 637 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 5 | 2 | 0 | 0 | 0 | 233 |
| L2033 | 5 | 1 | Mine | no | - | 3 | 0 | 4 | 2 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 4 | 1 | 5 | 0 | 0 | 0 | 19 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 8 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 1 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 162 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 5 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 1 | 0 | 0 | 549 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 5 | 2 | 3 | 2 | 2 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 0 | 0 | 0 | 549 |
| **Average** | | | Mine | 31% | 3.6 | 3.1 | 2.6 | 1.1 | 0.4 | 0.0 | 0.0 | 341.6 |
| **Average** | | | Opponent | 31% | 3.3 | 2.4 | 2.4 | 2.0 | 0.6 | 0.0 | 0.0 | 205.4 |

### KPIs: ss-opp-06f55ce-p3

Rules off - Mine only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (39 of 170) | 7% (11 of 169) | 15% (50 of 339) |
| Winner chose to follow up after the loser gave ground |  | 98% (46 of 47); on the table 98% | 100% (59 of 59); on the table 100% | 99% (105 of 106); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (8 of 12); on the table 67% | 93% (14 of 15); on the table 93% | 81% (22 of 27); on the table 81% |
| Winner chose to pursue after the loser fled |  | 50% (10 of 20); on the table 50% | 82% (27 of 33); on the table 82% | 70% (37 of 53); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 81% (64 of 79); on the table 81% | 93% (100 of 107); on the table 93% | 88% (164 of 186); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 29% (100 of 342) | 35% (68 of 192) | 31% (168 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (100 of 226) | 45% (68 of 151) | 45% (168 of 377) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (9 of 18) | 49% (32 of 65) | 49% (41 of 83) |
| Points that never fought | lower | 41% (28113 of 68801) | 40% (28512 of 71990) | 40% (56625 of 140791) |
|   infantry points that never fought | lower | 50% (7054 of 14174) | 53% (7554 of 14220) | 51% (14608 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (152 of 272) | 59% (169 of 285) | 58% (321 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.9 uses a game | 88% (21 of 24); 2.0 uses a game | 92% (45 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 30% (6 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30359 of 59391) | 52% (33037 of 64043) | 51% (63396 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (15%) | 1.2 (34%) | 2.2 (21%) |
| MARCHED: its unit marched | 1.9 (28%) | 0.9 (27%) | 2.8 (28%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.1 (17%) | 0.6 (18%) | 1.8 (17%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.1 (2%) | 0.2 (2%) |
| FLEEING: fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.4 (21%) | 0.4 (13%) | 1.8 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.1 (2%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.1 | 1.1 | 2.4 | 4.7 | 0.8 | 1.4 |
| not cast | 3.8 | 1.5 | 3.8 | 10.2 | 2.5 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (47%) | 0.4 (9%) | 2.2 (21%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.8 (28%) | 0.6 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (6%) | 0.2 (6%) | 1.8 (17%) | 0.3 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (4%) | 0.3 (8%) | 0.2 (2%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.2 (11%) | 0.0 (1%) | 0.3 (3%) | 0.0 (1%) | 0.7 (4%) |
| GONE: slain | 0.8 (22%) | 0.2 (17%) | 1.3 (35%) | 1.8 (18%) | 0.4 (15%) | 2.6 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (2%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (2%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (6%) | 0.0 (1%) | 0.1 (1%) | 0.7 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (57%) | 0.1 (8%) | 1.4 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.4 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.8 a game | 1.2 a game |
| stood (cast and not dispelled) | 63% (29 of 46) | 71% (17 of 24) | 66% (46 of 70) |
| the unit moved after it | 90% (26 of 29) | 59% (10 of 17) | 78% (36 of 46) |
| it charged on its next turn | 3% (1 of 29) | 6% (1 of 17) | 4% (2 of 46) |
| the enemy charged it first | 21% (6 of 29) | 12% (2 of 17) | 17% (8 of 46) |
| it fought by the end of its next turn | 7% (2 of 29) | 0% (0 of 17) | 4% (2 of 46) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (6 of 29) | 12% (2 of 17) | 17% (8 of 46) |
| none of these (no charge, no fight, no charge escaped) | 55% (16 of 29) | 71% (12 of 17) | 61% (28 of 46) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (488 of 751) | 60% (372 of 618) | 63% (860 of 1369) |
|   cavalry | 59% (36 of 61) | 58% (59 of 101) | 59% (95 of 162) |
|   character | 50% (49 of 98) | 27% (33 of 122) | 37% (82 of 220) |
|   chariot | 57% (55 of 96) | 46% (13 of 28) | 55% (68 of 124) |
|   infantry | 54% (100 of 186) | 67% (178 of 264) | 62% (278 of 450) |
|   monster | 48% (19 of 40) | 83% (5 of 6) | 52% (24 of 46) |
|   war machine | 85% (229 of 270) | 87% (84 of 97) | 85% (313 of 367) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (28%) | 1.6 (23%) | 3.6 (26%) |
| CHARGED: it charged | 1.0 (14%) | 1.4 (21%) | 2.4 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (7%) | 1.2 (9%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (15%) | 1.2 (18%) | 2.3 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.4 (7%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (18%) | 1.3 (19%) | 2.6 (18%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (6%) | 0.2 (3%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 0.8 | 85% | 4.9 pts | 20 pts |
| character | 2.8 | 0.7 | 82% | 5.3 pts | 15 pts |
| chariot | 1.9 | 0.9 | 72% | 12.4 pts | 23 pts |
| infantry | 11.9 | 4.4 | 76% | 8.6 pts | 103 pts |
| monster | 0.8 | 0.2 | 81% | 7.7 pts | 6 pts |
| war machine | 9.2 | 7.7 | 63% | 25.2 pts | 232 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.6 | 4.7 |
| Charges that made contact a game | 2.7 | 4.0 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.62 contact (26 units) | 0.59 declared, 0.35 contact (17 units) | 0.72 declared, 0.51 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.25 contact (4 units) | 1.00 declared, 0.78 contact (9 units) | 0.92 declared, 0.62 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.36 contact (224 units) | 0.70 declared, 0.50 contact (262 units) | 0.60 declared, 0.44 contact (486 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (46 of 77) | 60% (9 of 15) | 50% (5 of 10) | 59% (60 of 102) |
| Character in a unit | 85% (28 of 33) | 75% (12 of 16) | 50% (2 of 4) | 79% (42 of 53) |
| Character on its own | 73% (32 of 44) | 60% (24 of 40) | 21% (15 of 71) | 46% (71 of 155) |
| Chariot | 91% (10 of 11) | 83% (10 of 12) | - | 87% (20 of 23) |
| Infantry | 54% (38 of 70) | 50% (21 of 42) | 40% (2 of 5) | 52% (61 of 117) |
| Monster | 53% (18 of 34) | 57% (4 of 7) | - | 54% (22 of 41) |
| Monstrous | 90% (9 of 10) | 45% (5 of 11) | - | 67% (14 of 21) |
| War Machines | 67% (29 of 43) | 100% (2 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 86% (6 of 7); on the table 86% | 36% (35 of 96) | 52% | 64% (14 of 22) | 83% (5 of 6); 4.0 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (3 of 3); on the table 100% | 44% (16 of 36) | 59% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 40% (2 of 5); on the table 40% | - | 62% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (3 of 3); on the table 100% | 57% (17 of 30) | 49% | 61% (36 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 94% (17 of 18); on the table 94% | 30% (57 of 192) | 49% | 59% (44 of 74) | 94% (17 of 18); 5.8 uses a game | 25% (1 of 4); 0.1 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 62% (15 of 24); on the table 62% | 31% (13 of 42) | 35% | 50% (27 of 54) | 89% (8 of 9); 3.6 uses a game | 25% (3 of 12); 0.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 75% (3 of 4); on the table 75% | - | 43% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 0% | 14% (1 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 6% | 57% (4 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (10 of 10); on the table 100% | 17% (2 of 12) | 12% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 50% (1 of 2); on the table 50% | 17% (2 of 12) | 68% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (11 of 11); on the table 100% | 67% (4 of 6) | 30% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (25 of 26); on the table 96% | 26% (14 of 54) | 38% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 89% (42 of 47); on the table 89% | 20% (6 of 30) | 26% | 53% (51 of 96) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (15 of 15); on the table 100% | 8% (1 of 12) | 45% | 74% (46 of 62) | 91% (10 of 11); 6.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ss-opp-06f55ce-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 39% (30) | 49% (35) | 44% (65) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.44 | 0.94 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.36 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.33 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.64 | 3.64 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 1.33 | 2.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.81 | 4.97 | 9.78 |

### Quality by phase: ss-opp-06f55ce-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 59% (73 of 124) | 51% (83 of 164) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (170 of 388) | 49% (130 of 263) |
| Strategy | Close-in objectives charged next turn | 17% (34 of 196) | 13% (31 of 240) |
| Strategy | Support requests answered (helper made contact too) | 27% (3 of 11) | 41% (11 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (4 of 9) | 50% (5 of 10) |
| Strategy | Joined characters whose unit fought | 34% (13 of 38) | 27% (12 of 44) |
| Strategy | Lone characters that fought | 76% (74 of 97) | 77% (69 of 90) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 2.0 |
| Movement | Points that never moved of their own | 341.6 | 205.4 |
| Movement | Fights charged into per game | 2.7 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 89, net +60 | 21 of 99, net +114 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 89, net +79 | 13 of 99, net +196 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 89, net +23 | 17 of 99, net +62 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 89, net +60 | 20 of 99, net +61 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.8 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (135 of 281) | 50% (171 of 340) |
| Shooting | Points destroyed by shooting units | 62.9 | 45.7 |
| Shooting | War machine shots | 6.4 | 2.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (135 of 229) | 38% (39 of 102) |
| Shooting | Points destroyed by war machines | 72.1 | 27.8 |
| Magic | Magic missiles cast | 1.9 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (31 of 69) | 40% (20 of 50) |
| Magic | Wounds caused by magic missiles | 3.7 | 2.3 |
| Magic | Wounds caused by other spells | 1.3 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 76.2 | 35.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.2 / 0.4 / 0.1 | 2.3 / 0.3 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 302.0 | 385.2 |
| Combat | Points run down | 66.2 | 129.9 |
| Combat | Net points per charged fight, damage counted | +67 | +96 |
| Combat | Net per 100 charger points, damage counted | +24.3 | +31.4 |
| Combat | First round won (charged fights) | 78% | 77% |
| Combat | Net points per charged fight | +67 | +91 |
| Combat | Net points per supported fight / lone fight | +162 / +61 | +112 / +86 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 96 | 49 of 116 |
| Game | Points lost | 755.4 | 636.2 |
| Game | VP from objectives | 478.6 | 569.7 |
| Game | Lone holders (player turns) | 3.6 | 3.3 |

- Mine won / drew / lost: 10 / 7 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -293 VP
- The side that went first won 15 of 29 games with a winner
- Points traded per game (both sides' losses): 1392
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-opp-06f55ce-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.1 | -162.9 | 144.1 | 136.1 | 3.7 | -117.5 | 120.4 | 71.7 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 28.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +4.6 | 0.0 | 26.9 | 0.6 | +4.1 | 0.0 | 17.9 |
| BEST FACING | 0.5 | +10.5 | 0.0 | 15.8 | 0.3 | +1.7 | 0.0 | 12.2 |
| BEST FIRST | 1.5 | +43.2 | 18.9 | 18.0 | 0.6 | +46.7 | 4.9 | 13.3 |
| BEST OVERALL | 0.3 | +13.3 | 0.0 | 11.1 | 0.3 | +10.4 | 0.0 | 8.4 |
| BEST PREY | 0.3 | +14.6 | 3.8 | 2.4 | 0.7 | +19.7 | 15.1 | 13.1 |
| BEST PRIZE | 0.0 | +1.1 | 3.1 | 0.0 | 0.1 | -2.6 | 1.8 | 5.3 |
| BIG CHARACTER SAFETY | 0.2 | -0.7 | 0.0 | 0.0 | 0.2 | -1.4 | 0.0 | 10.2 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +9.2 | 0.0 | 0.0 | 0.1 | +4.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -25.8 | 39.9 | 18.5 | 0.4 | -78.4 | 52.0 | 0.0 |
| BOMBING RUN | 0.1 | +1.2 | 11.2 | 1.7 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 72.1 | 11.9 | 0.2 | +0.0 | 19.9 | 6.5 |
| CANNON PLANNED TARGET | 5.6 | +165.5 | 389.8 | 80.0 | 1.9 | +96.6 | 129.3 | 6.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -1.3 | 41.9 | 19.1 | 0.2 | -2.3 | 29.0 | 7.0 |
| CAST JOB | 1.2 | +25.4 | 49.3 | 12.6 | 0.9 | +29.2 | 61.1 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +41.2 | 13.3 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 51.4 | 0.5 | +0.0 | 0.0 | 6.5 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +51.5 | 0.0 | 22.1 | 1.5 | +83.1 | 0.0 | 24.8 |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 12.5 | 0.2 | -0.6 | 0.0 | 10.6 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 252.8 | 90.8 | 2.4 | +0.0 | 216.6 | 91.8 |
| CHARGE NOW WEIGHED | 0.6 | -44.5 | 7.5 | 2.4 | 0.4 | -46.6 | 13.8 | 21.2 |
| CHARGER SLAIN LOST | 0.4 | -23.2 | 37.5 | 14.6 | 0.5 | -11.6 | 48.9 | 20.4 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.6 | 10.9 | 0.0 | 0.1 | +0.0 | 0.0 | 11.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.3 | 0.0 | 0.1 | +0.0 | 0.0 | 3.2 |
| CHEAPEST HOLDER | - | - | - | - | 1.5 | -56.9 | 110.3 | 37.1 |
| COMBAT PIVOT | 0.7 | +0.0 | 9.2 | 59.6 | 0.4 | +0.0 | 42.6 | 13.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +90.4 | 31.4 | 23.8 | 0.4 | +41.4 | 17.6 | 5.3 |
| COVER ONCE | 8.5 | -634.3 | 0.0 | 217.2 | 6.1 | -457.2 | 0.0 | 202.6 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.6 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +5.1 | 9.9 | 0.0 | 0.2 | +1.9 | 11.2 | 2.5 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +142.9 | 0.0 | 72.8 | 1.6 | +103.0 | 0.0 | 62.0 |
| FALLBACK BY WORTH | 4.5 | +43.7 | 0.0 | 31.5 | 3.0 | +24.0 | 0.0 | 64.8 |
| FALLS SHORT | - | - | - | - | 12.6 | +171.8 | 0.0 | 153.1 |
| FIGHT LIFT | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | 0.0 | +2.1 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 117.5 | 4.8 | +0.0 | 0.0 | 157.1 |
| FOCUS FIRE | 0.0 | +0.9 | 1.8 | 0.0 | 0.0 | +0.9 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +109.8 | 0.0 | 46.3 | 1.0 | +115.9 | 0.0 | 21.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.4 | 0.0 | 29.7 | 0.1 | +8.4 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.8 | 7.1 | 0.0 | 0.1 | -0.9 | 5.2 | 2.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -0.3 | 4.5 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 1.1 | +0.0 | 0.0 | 5.2 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 13.6 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 20.8 | 12.1 | 0.4 | +0.0 | 35.1 | 2.7 |
| HILL BY ITS CHANCE | 0.2 | -13.5 | 0.0 | 6.8 | 0.2 | -21.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.6 | -150.6 | 443.4 | 269.0 | 8.9 | -214.6 | 419.0 | 224.9 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +7.0 | 0.0 | 6.2 | 0.2 | +6.9 | 9.0 | 3.2 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.7 |
| HUNT IN PAIRS | 0.3 | +15.5 | 0.0 | 0.0 | 1.0 | +49.7 | 0.0 | 30.1 |
| HUNT KEPT | 0.2 | +4.9 | 0.0 | 2.4 | 0.1 | +2.6 | 5.4 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +23.1 | 0.0 | 6.7 |
| HUNT THE GUNS | 0.1 | +40.6 | 0.0 | 3.8 | 0.3 | +70.3 | 17.8 | 7.2 |
| IDLE COST | 16.1 | -274.0 | 0.0 | 149.5 | 8.1 | -119.7 | 0.0 | 155.9 |
| INVITES THE FIGHT | 1.3 | +10.1 | 42.4 | 71.9 | 0.6 | +3.1 | 40.7 | 28.2 |
| JOINT CHARGE PLAN | 0.0 | +0.3 | 0.0 | 0.0 | 0.3 | +13.6 | 15.4 | 10.9 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -13.4 | 32.6 | 0.0 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 6.8 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.1 | 2.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.0 | +60.8 | 162.5 | 67.9 | 1.8 | +53.3 | 97.0 | 15.4 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +76.9 | 122.3 | 46.5 | 1.9 | +91.1 | 158.7 | 71.3 |
| KILLS COUNT NEXT TURN | 5.0 | +154.4 | 211.0 | 80.2 | 7.2 | +211.4 | 190.9 | 181.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +10.4 | 7.7 | 3.2 | 0.2 | +7.4 | 13.9 | 10.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 5.4 | 0.5 | +0.0 | 8.8 | 19.4 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -4.9 | 30.4 | 6.3 | 0.2 | +0.2 | 5.2 | 8.7 |
| LOST CHARGE | 2.9 | -38.3 | 77.6 | 122.2 | 2.6 | -35.7 | 109.5 | 70.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -11.8 | 0.0 | 5.8 | 0.3 | -16.9 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 0.8 | +82.3 | 48.8 | 26.8 | 1.1 | +88.0 | 57.0 | 41.8 |
| MANOEUVRE | 0.4 | +11.4 | 0.0 | 10.2 | 0.2 | +5.0 | 0.0 | 4.2 |
| MARCH AT ESCAPER | 0.3 | +1.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +21.7 | 0.0 | 12.7 | 0.6 | +31.3 | 0.0 | 10.9 |
| MARCH ODDS | 0.2 | +13.0 | 20.6 | 0.0 | 0.2 | +9.1 | 6.4 | 0.0 |
| MARCH OVER CASTS | 0.6 | +36.8 | 0.0 | 21.5 | 0.4 | +45.9 | 0.0 | 10.2 |
| MAX FOR POSITIONING | 6.9 | +106.1 | 0.0 | 106.5 | 6.7 | +96.1 | 0.0 | 147.4 |
| MISSILES IN THE MOVE | 3.9 | +131.0 | 0.0 | 89.2 | 4.3 | +79.8 | 0.0 | 54.7 |
| MISSILES NEXT TURN | 5.3 | +112.2 | 0.0 | 145.3 | 5.0 | +55.0 | 0.0 | 78.8 |
| MODEL FACING | 0.1 | +4.1 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 0.0 | 27.5 | 0.2 | +0.0 | 28.2 | 0.0 |
| MOVE AND CAST | 0.3 | +8.7 | 0.0 | 10.2 | 0.5 | +5.8 | 0.0 | 5.3 |
| MOVE SPELL IN RANGE | 0.3 | +12.3 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -16.0 | 0.0 | 51.0 | 0.0 | -0.4 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 1.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.6 | +260.0 | 143.1 | 100.1 | 5.0 | +397.2 | 183.6 | 132.2 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 10.0 | +551.8 | 0.0 | 69.4 |
| NEEDED THERE | 0.0 | +14.7 | 2.8 | 0.0 | 0.1 | +18.3 | 15.0 | 0.0 |
| NO FORCED ADVANCE | - | - | - | - | 3.7 | +0.0 | 0.0 | 42.6 |
| NO RALLY LEFT | 0.0 | +0.0 | 0.0 | 8.0 | 0.1 | +0.4 | 0.0 | 4.3 |
| NOT NEEDED | 0.2 | -6.7 | 13.7 | 0.0 | 0.2 | -9.6 | 18.9 | 6.8 |
| NOT TURNED | 4.8 | +66.0 | 0.0 | 85.1 | 5.0 | +36.9 | 0.0 | 137.7 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 27.2 | 0.8 | -1.0 | 0.0 | 11.0 |
| OFF BEST | 16.0 | -763.5 | 8.2 | 282.1 | 13.8 | -576.4 | 11.0 | 262.9 |
| ONE FIGHT FORMULA | 9.1 | -153.3 | 33.3 | 222.7 | 7.0 | -161.4 | 24.6 | 177.7 |
| ONE OBJECTIVE FORMULA | 2.2 | -76.1 | 0.0 | 60.6 | 1.9 | -81.6 | 0.0 | 26.6 |
| OPENS A LANE | - | - | - | - | 0.2 | +0.7 | 5.3 | 0.0 |
| OPENS UP | 0.1 | +9.7 | 9.6 | 0.0 | 0.1 | +10.0 | 1.7 | 0.0 |
| OVERRUNS AWAY | 0.5 | +8.6 | 38.6 | 9.7 | 0.5 | +10.2 | 32.0 | 38.6 |
| PATHS CROSS | 1.8 | +86.4 | 0.0 | 17.7 | 2.4 | +140.9 | 0.0 | 20.1 |
| PERIAPT WORTH | 0.0 | +1.1 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 5.6 | 0.0 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 37.1 | +1384.0 | 1266.6 | 1016.5 | 35.0 | +1006.4 | 1164.1 | 821.8 |
| PURSUES BIG PREY | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -6.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +6.6 | 0.0 | 0.0 | 0.1 | +5.4 | 0.0 | 1.1 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | 0.1 | +7.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +4.6 | 0.0 | 15.3 | 1.8 | +47.0 | 0.0 | 70.6 |
| RANDOM MOVER NO PROMISE | 0.2 | -15.0 | 6.6 | 0.0 | 0.2 | -12.5 | 3.5 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -6.2 | 0.0 | 13.8 | 1.1 | -17.9 | 0.0 | 20.2 |
| REDIRECT COUNTER | 2.1 | +96.4 | 0.0 | 32.1 | 3.8 | +398.8 | 0.0 | 49.2 |
| REDIRECT WEIGHED | 0.1 | +1.4 | 3.8 | 1.7 | 0.4 | +2.2 | 10.6 | 5.4 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +5.9 | 0.0 | 1.8 | 0.8 | +38.2 | 0.0 | 15.9 |
| RESTRAINS TO SHOOT | 0.1 | +5.0 | 0.0 | 8.7 | 0.0 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +107.7 | 202.6 | 100.5 | 2.5 | +59.5 | 195.1 | 117.7 |
| RISK ONCE | 4.3 | +169.9 | 34.9 | 143.2 | 5.2 | +261.6 | 89.1 | 270.2 |
| SAFE SURE CHARGE | 0.0 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.0 | +51.7 | 0.0 | 20.8 | 1.3 | +95.8 | 0.0 | 10.9 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.2 | 0.0 | 0.9 | 0.3 | -28.1 | 0.0 | 0.5 |
| SEARCH SPOT | 2.0 | +92.9 | 0.0 | 16.4 | 2.1 | +71.6 | 0.0 | 33.1 |
| SELF MOVE SPELL | 0.4 | +75.5 | 0.0 | 40.1 | 0.2 | +29.6 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.2 | +110.6 | 56.4 | 26.8 | 2.2 | +170.0 | 96.3 | 71.6 |
| SET-UP ANY TARGET | 0.3 | +46.9 | 21.1 | 21.1 | 0.2 | +52.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +33.0 | 0.0 | 10.6 | 0.0 | +4.7 | 8.2 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +46.6 | 75.2 | 26.8 | 1.0 | +16.8 | 23.2 | 5.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 90.6 | 17.5 | 0.3 | +0.0 | 94.9 | 3.6 |
| SHOTS IN THE MOVE | 13.5 | +643.7 | 0.0 | 245.8 | 10.2 | +403.7 | 0.0 | 92.4 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +108.6 | 31.4 | 23.8 | 0.2 | +52.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +16.3 | 50.2 | 69.9 | 2.7 | +37.8 | 16.5 | 10.6 |
| SPELLS IN THE FIGHT | 0.5 | +2.7 | 50.6 | 42.6 | 0.6 | -16.7 | 50.3 | 36.1 |
| STABLE ROLE | 11.3 | +0.0 | 355.4 | 215.7 | 9.0 | +0.0 | 222.9 | 194.1 |
| STANDS TO CAST | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +2.1 | 14.2 | 4.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +13.2 | 0.0 | 23.1 | 0.3 | +15.2 | 0.0 | 3.2 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.9 | -69.5 | 324.5 | 105.8 | 6.7 | -55.5 | 353.9 | 113.8 |
| SUPPORTS | 4.1 | +72.6 | 182.8 | 71.6 | 4.6 | +62.0 | 179.2 | 52.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.7 | 7.4 | 15.1 | 0.1 | -4.2 | 4.9 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +5.3 | 5.0 | 6.0 | 0.8 | -7.1 | 0.0 | 3.2 |
| THROUGH LINE OF FIRE | 0.5 | +14.7 | 0.0 | 5.2 | 0.2 | +10.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 10.8 | +197.5 | 0.0 | 121.8 |
| TURN WORTH | 0.2 | -11.7 | 18.4 | 5.4 | 0.3 | -21.2 | 18.6 | 3.8 |
| TWO OR MORE ARRIVE | 0.4 | +4.0 | 18.4 | 11.4 | 0.9 | +4.9 | 37.2 | 22.1 |
| WAIT AFTER COSTS | 7.4 | -342.9 | 275.4 | 222.1 | 7.5 | -342.6 | 266.0 | 175.4 |
| WALKS TO THE FIGHT | 1.8 | +16.1 | 42.1 | 40.5 | 1.0 | +4.8 | 29.3 | 1.4 |
| WAR ENGINE CHARGES | 0.1 | +6.0 | 0.0 | 8.6 | 0.0 | +1.4 | 2.4 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 33.7 | 7.5 | 0.3 | +0.0 | 7.6 | 3.8 |
| WEARS DOWN | 1.0 | +47.2 | 73.1 | 78.7 | 1.4 | +55.6 | 112.8 | 60.7 |
| WHO HITS BACK | 0.1 | +11.1 | 0.0 | 0.0 | 0.1 | +17.8 | 0.0 | 7.0 |
| WHOLE FIGHT | 0.2 | +12.9 | 59.8 | 0.0 | 0.2 | -19.2 | 49.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +13.7 | 10.1 | 1.7 | 0.6 | +41.3 | 59.4 | 24.2 |
| WIDER SPREAD | 2.2 | -5.6 | 217.7 | 67.5 | 2.8 | -7.9 | 226.4 | 83.5 |

### Rule changes: ss-opp-06f55ce-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1073 | 1073 | 1073 | 29.81 | -48236 | -45.0 |
| MOVE TO CHARGE | 309 | 309 | 180 | 5.00 | +8811 | +48.9 |
| PATHS CROSS | 153 | 153 | 153 | 4.25 | +8181 | +53.5 |
| SEARCH SPOT | 148 | 148 | 144 | 4.00 | +5922 | +41.1 |
| NO FORCED ADVANCE | 132 | 132 | 132 | 3.67 | +1339 | +10.1 |
| FACES THE THREAT | 131 | 131 | 131 | 3.64 | +8853 | +67.6 |
| KILLS COUNT NEXT TURN | 439 | 439 | 131 | 3.64 | +3291 | +25.1 |
| SUPPORTS | 316 | 316 | 124 | 3.44 | +1816 | +14.6 |
| NEARER NOT NEEDED | 360 | 251 | 113 | 3.14 | +2153 | +19.1 |
| COVER ONCE | 525 | 294 | 99 | 2.75 | +1165 | +11.8 |
| WAIT AFTER COSTS | 535 | 535 | 94 | 2.61 | +1700 | +18.1 |
| SAFER THAN THE JOB | 84 | 84 | 84 | 2.33 | +5309 | +63.2 |
| SHOTS IN THE MOVE | 856 | 606 | 83 | 2.31 | +2265 | +27.3 |
| RISK ONCE | 343 | 264 | 81 | 2.25 | +3484 | +43.0 |
| TIME ON OUR SIDE | 387 | 241 | 79 | 2.19 | +163 | +2.1 |
| BEST FIRST | 76 | 76 | 76 | 2.11 | +3237 | +42.6 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 63 | 63 | 63 | 1.75 | +8127 | +129.0 |
| FALLS SHORT | 453 | 294 | 62 | 1.72 | +154 | +2.5 |
| FALLBACK BY WORTH | 269 | 269 | 59 | 1.64 | +2436 | +41.3 |
| ADVANCE WORTH | 315 | 315 | 58 | 1.61 | +976 | +16.8 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| SET UP TOGETHER | 122 | 109 | 52 | 1.44 | +3900 | +75.0 |
| CANNON PLANNED TARGET | 269 | 269 | 51 | 1.42 | -715 | -14.0 |
| REDIRECT COUNTER | 211 | 97 | 50 | 1.39 | +4137 | +82.7 |
| CHAFF IN THE MOVE | 90 | 80 | 48 | 1.33 | +1451 | +30.2 |
| ONE FIGHT FORMULA | 582 | 336 | 47 | 1.31 | +190 | +4.1 |
| MISSILES IN THE MOVE | 296 | 180 | 46 | 1.28 | +726 | +15.8 |
| KILLS COUNT | 128 | 127 | 45 | 1.25 | +1556 | +34.6 |
| RISK BY ARC | 179 | 175 | 45 | 1.25 | +1003 | +22.3 |
| COMBAT PIVOT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 41 | 1.14 | +1858 | +45.3 |
| CHARGE NOW FIRST | 176 | 176 | 39 | 1.08 | -1757 | -45.0 |
| HARD STAY DROPPED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MARCH CHECK | 43 | 40 | 38 | 1.06 | +2168 | +57.1 |
| MAX FOR POSITIONING | 492 | 291 | 38 | 1.06 | +198 | +5.2 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +3039 | +82.1 |
| WALKS TO THE FIGHT | 100 | 100 | 37 | 1.03 | +213 | +5.7 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RESERVE FALL BACK | 35 | 35 | 35 | 0.97 | +1588 | +45.4 |
| CAST JOB | 75 | 75 | 34 | 0.94 | +809 | +23.8 |
| HONEST WORTH | 630 | 627 | 33 | 0.92 | +227 | +6.9 |
| IDLE COST | 869 | 492 | 33 | 0.92 | +476 | +14.4 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 73 | 73 | 31 | 0.86 | +835 | +26.9 |
| BEST FACING | 30 | 30 | 30 | 0.83 | +438 | +14.6 |
| KEEPS ITS TARGET | 137 | 135 | 28 | 0.78 | +525 | +18.8 |
| MOVE AND CAST | 28 | 28 | 28 | 0.78 | +522 | +18.7 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +1021 | +36.5 |
| MAKE SURE TOGETHER | 69 | 51 | 27 | 0.75 | +1962 | +72.7 |
| INVITES THE FIGHT | 69 | 69 | 25 | 0.69 | +155 | +6.2 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BEST OVERALL | 24 | 24 | 24 | 0.67 | +852 | +35.5 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +910 | +37.9 |
| HUNT IN PAIRS | 46 | 29 | 19 | 0.53 | +919 | +48.4 |
| LOST CHARGE | 197 | 195 | 18 | 0.50 | +486 | +27.0 |
| MANOEUVRE | 22 | 22 | 18 | 0.50 | +617 | +34.3 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +768 | +45.2 |
| WAR ENGINE JOBS | 35 | 35 | 17 | 0.47 | -956 | -56.2 |
| WHOLE FIGHT GAIN | 30 | 28 | 17 | 0.47 | +420 | +24.7 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +482 | +30.1 |
| MARCH ODDS | 18 | 18 | 16 | 0.44 | +168 | +10.5 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -76 | -5.4 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -21 | -1.5 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +785 | +65.4 |
| MISSILES NEXT TURN | 370 | 210 | 12 | 0.33 | +40 | +3.3 |
| WEARS DOWN | 86 | 83 | 12 | 0.33 | +430 | +35.9 |
| CASTING BLOCK | 14 | 14 | 10 | 0.28 | +355 | +35.5 |
| WHO HITS BACK | 10 | 10 | 10 | 0.28 | +789 | +78.9 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 451 | 451 | 9 | 0.25 | -146 | -16.2 |
| OVERRUNS AWAY | 34 | 33 | 8 | 0.22 | +210 | +26.3 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -212 | -26.5 |
| BEST PREY | 34 | 34 | 7 | 0.19 | +164 | +23.4 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 7 | 0.19 | -333 | -47.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +180 | +30.0 |
| OPENS UP | 9 | 9 | 6 | 0.17 | +321 | +53.5 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -47 | -7.8 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +197 | +32.8 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 5 | 0.14 | +125 | +25.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| WHOLE FIGHT | 17 | 17 | 5 | 0.14 | +130 | +26.0 |
| WIDER SPREAD | 180 | 172 | 5 | 0.14 | +19 | +3.8 |
| BACKUP TARGETS | 47 | 22 | 4 | 0.11 | +3 | +0.8 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -242 | -60.4 |
| REFUSING RETIRES | 21 | 21 | 4 | 0.11 | -1 | -0.3 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -96 | -31.8 |
| EDGE GIVE GROUND | 10 | 10 | 3 | 0.08 | +50 | +16.6 |
| HUNT ADVANCE | 12 | 12 | 3 | 0.08 | +84 | +28.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +1 | +0.4 |
| ONE OBJECTIVE FORMULA | 147 | 66 | 3 | 0.08 | +92 | +30.5 |
| REDIRECT BY WHAT IT STOPS | 64 | 64 | 3 | 0.08 | +160 | +53.2 |
| SPELLS IN THE FIGHT | 41 | 37 | 3 | 0.08 | +58 | +19.4 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +3 | +1.1 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +72 | +24.1 |
| SURE REACH TOGETHER | 47 | 32 | 3 | 0.08 | +17 | +5.6 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +43 | +21.6 |
| CARRIES OUT SET-UP | 13 | 13 | 2 | 0.06 | -128 | -64.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +90 | +45.1 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +64 | +31.8 |
| JOINT CHARGE PLAN | 12 | 12 | 2 | 0.06 | +102 | +51.2 |
| MODEL FACING | 2 | 2 | 2 | 0.06 | +148 | +74.2 |
| MOVE SPELL IN RANGE | 12 | 5 | 2 | 0.06 | +48 | +24.1 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +140 | +70.2 |
| RAIDS THE BAGGAGE | 3 | 3 | 2 | 0.06 | +182 | +90.8 |
| BLOWS WHERE AIMED | 26 | 25 | 1 | 0.03 | +35 | +35.1 |
| CHARGER SLAIN LOST | 34 | 30 | 1 | 0.03 | +34 | +33.5 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 7 | 4 | 1 | 0.03 | +3 | +3.2 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | +63 | +62.6 |
| STOPS | 10 | 10 | 1 | 0.03 | +5 | +5.0 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +40 | +40.2 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 50 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 53 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 348 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 15 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| LONG SHOT | 17 | 17 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 13 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 21 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 30 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 352 | 352 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| PLAN RESULT | 2596 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 16 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 30 | not checked | - | - | - | - |
| SPELL WORTH | 138 | not checked | - | - | - | - |
| STABLE ROLE | 732 | 730 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 45 | 34 | 0 | 0.00 | - | - |

### Off best figure: ss-opp-06f55ce-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.78 | 11.89 | 46.2 |
| FALLBACK | gate | 0.53 | 0.67 | 44.9 |
| TURN GATE | gate | 0.44 | 0.67 | 29.1 |
| CHARGE NOW FIRST | rule | 0.56 | 0.50 | 46.2 |
| WAR ENGINE JOBS | rule | 0.31 | 0.14 | 59.7 |
| PATHS CROSS | rule | 0.08 | 0.22 | 21.9 |
| SUPPORT NARROWED | rule | 0.03 | 0.22 | 16.2 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 11.2 |
| CANNON PLANNED TARGET | rule | 0.08 | 0.14 | 91.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 70.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.14 | 26.5 |
| FIGHT ORDER BAND | gate | 0.03 | 0.17 | 2.1 |
| NEARER NOT NEEDED | rule | - | 0.19 | 11.4 |
| CHAFF PASSED | rule | 0.03 | 0.14 | 3.5 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.03 | 7.8 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.08 | 66.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.11 | 9.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 37.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.08 | 15.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 60.4 |
| RULE SWITCHED OFF | gate | 0.11 | - | 22.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 25.7 |
| BEST PRIZE | rule | 0.03 | 0.06 | 31.8 |
| AFTERMATH BAND | gate | 0.03 | 0.03 | 3.9 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 64.2 |
| FACES THE THREAT | rule | - | 0.06 | 13.7 |
| NO REASON | gate | - | 0.06 | 8.4 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 10.4 |
| MARCH ODDS | rule | 0.03 | - | 2.9 |
| MOVE AND CAST | rule | - | 0.03 | 7.2 |
| REDIRECT WEIGHED | rule | - | 0.03 | 17.3 |
| SAFER THAN THE JOB | rule | 0.03 | - | 15.5 |
| STANDS TO CAST | rule | 0.03 | - | 14.0 |

### Plans: ss-opp-06f55ce-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.6 | 14% | 130 | 269 | 206% |
| Mine | charge | 2.8 | 59% | 236 | 255 | 108% |
| Mine | close in | 5.4 | 25% | 293 | 155 | 53% |
| Mine | hold | 4.9 | 37% | 292 | 0 | 0% |
| Mine | join | 0.4 | 100% | 17 | 0 | 0% |
| Mine | shoot | 9.1 | 63% | 244 | 706 | 290% |
| Mine | support | 4.9 | 88% | 58 | 0 | 0% |
| Opponent | advance | 7.0 | 16% | 128 | 149 | 117% |
| Opponent | charge | 3.8 | 57% | 292 | 365 | 125% |
| Opponent | close in | 6.6 | 23% | 371 | 191 | 51% |
| Opponent | hold | 5.1 | 23% | 292 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 26 | 0 | 0% |
| Opponent | shoot | 5.8 | 47% | 141 | 302 | 215% |
| Opponent | support | 6.1 | 92% | 61 | 0 | 0% |

### Packages: hunt the guns, ss-opp-06f55ce-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 0% | 0% | 0% | - | 396 | 0 | 0% | 28 |
| Opponent | 0.3 | 10 | 0 | 30% | 40% | 0% | 2.2 | 253 | 83 | 40% | 78 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 0% | 0% | 0% | - | 448 | 0 | 0% | 90 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 292 | 0 | 0% | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 69 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 162 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 44 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 112 | 55 | 50% | 21 |
| Warriors of Chaos | 0.5 | 5 | 0 | 20% | 40% | 0% | 2.0 | 276 | 100 | 40% | 67 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 3.0 | 271 | 112 | 50% | 60 |

### Battle groups: ss-opp-06f55ce-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 31% | 87% | 35% | 12% | 13% | 0% | 7% | 80% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 22% | 57% | 20% | 17% | 8% | 0% | 21% | 67% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-opp-06f55ce-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 67 (34) | 24 | 43 | 45 | 38% | 2.8 | 55 (21) | 0 (4) | 123 (9) | 100 (24) | 0 (10) |
| Mine | Character | 118 | 42 (118) | 42 | 0 | 39 | 18% | 2.4 | 41 (38) | 51 (53) | 33 (8) | 47 (57) | 43 (42) |
| Mine | Clean-up | 18 | 50 (18) | 15 | 35 | 41 | 39% | 3.0 | 69 (3) | 42 (13) | 105 (2) | 60 (12) | 35 (6) |
| Mine | Fast | 1 | 190 (1) | 190 | 0 | 100 | 100% | - | - | 190 (1) | - | 190 (1) | - |
| Mine | Fast Hammer | 44 | 33 (44) | 14 | 19 | 39 | 27% | 3.1 | 40 (22) | 29 (14) | 21 (8) | 31 (30) | 36 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 3.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 27 (52) | 16 | 10 | 43 | 19% | 2.5 | 13 (14) | 34 (35) | 0 (3) | 30 (36) | 21 (16) |
| Mine | Holder | 25 | 54 (25) | 6 | 48 | 14 | 60% | 2.6 | 41 (7) | 63 (12) | 54 (5) | 90 (12) | 19 (12) |
| Mine | Shooter | 37 | 61 (37) | 45 | 15 | 66 | 8% | 1.8 | 41 (6) | 71 (28) | 0 (3) | 65 (23) | 53 (14) |
| Mine | Support | 4 | 99 (4) | 99 | 0 | 19 | 25% | 2.0 | - | 99 (4) | - | - | 99 (4) |
| Mine | War machine | 52 | 43 (52) | 43 | 0 | 38 | 2% | 1.0 | 33 (13) | 40 (36) | 133 (3) | 27 (13) | 49 (39) |
| Mine | Wizard | 17 | 15 (17) | 15 | 0 | 56 | 18% | 1.9 | 61 (4) | 0 (8) | 0 (2) | 0 (9) | 54 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 34 (68) | 10 | 23 | 46 | 50% | 2.9 | 48 (29) | 32 (11) | 23 (28) | 42 (48) | 15 (20) |
| Opponent | Character | 102 | 51 (102) | 51 | 0 | 27 | 25% | 2.1 | 38 (40) | 67 (50) | 28 (7) | 50 (58) | 56 (39) |
| Opponent | Clean-up | 11 | 58 (11) | 15 | 43 | 39 | 36% | 2.9 | 46 (4) | 60 (6) | 93 (1) | 46 (6) | 68 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 33 (60) | 19 | 13 | 45 | 40% | 2.6 | 41 (30) | 15 (20) | 41 (10) | 37 (28) | 28 (32) |
| Opponent | Fragile | 3 | 62 (3) | 62 | 0 | 33 | 0% | 3.7 | - | 0 (2) | 185 (1) | 92 (2) | 0 (1) |
| Opponent | Hammer | 50 | 48 (50) | 34 | 13 | 43 | 26% | 3.0 | 18 (17) | 62 (30) | 6 (3) | 51 (30) | 43 (20) |
| Opponent | Holder | 40 | 73 (40) | 20 | 53 | 24 | 30% | 2.8 | 49 (9) | 75 (20) | 90 (11) | 71 (28) | 76 (12) |
| Opponent | Shooter | 27 | 61 (27) | 40 | 21 | 35 | 7% | 1.2 | 161 (6) | 29 (19) | 72 (2) | 91 (16) | 23 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 25% | 4.7 | - | 0 (3) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 49 (17) | 49 | 0 | 11 | 0% | 1.4 | 0 (3) | 50 (10) | 72 (4) | 0 (3) | 57 (14) |
| Opponent | Wizard | 32 | 23 (32) | 23 | 0 | 30 | 16% | 2.2 | 12 (15) | 39 (10) | 36 (4) | 39 (16) | 0 (13) |

### Charged fights: ss-opp-06f55ce-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 120 | 11 | 0.8 | 1.3 | 15 | 0 | +15 | 0 of 3 | 3 of 3 | +45 | +0 |
| Mine | Chaos Dwarfs | 4 | 172 | 210 | 1.8 | 1.0 | 120 | 44 | +76 | 4 of 7 | 5 of 7 | - | +76 |
| Mine | Dwarfen Mountain Holds | 3 | 468 | 103 | 1.7 | 1.0 | 62 | 12 | +50 | 0 of 5 | 4 of 5 | - | +50 |
| Mine | Empire of Man | 5 | 394 | 100 | 1.0 | 1.0 | 100 | 0 | +100 | 3 of 5 | 5 of 5 | - | +100 |
| Mine | Grand Cathay | 5 | 404 | 93 | 3.8 | 1.1 | 25 | 56 | -32 | 6 of 19 | 14 of 19 | +0 | -34 |
| Mine | High Elf Realms | 4 | 106 | 437 | 4.2 | 1.1 | 103 | 10 | +92 | 7 of 17 | 14 of 17 | +300 | +65 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 821 | 5.0 | 1.0 | 164 | 55 | +109 | 0 of 5 | 4 of 5 | - | +109 |
| Mine | Lizardmen | 1 | 116 | 625 | 4.0 | 1.0 | 156 | 0 | +156 | 0 of 4 | 2 of 4 | - | +156 |
| Mine | Ogre Kingdoms | 1 | 0 | 195 | 2.0 | 1.0 | 98 | 114 | -16 | 2 of 2 | 1 of 2 | - | -16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 367 | 3.0 | 1.0 | 122 | 18 | +104 | 0 of 3 | 3 of 3 | - | +104 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 130 | 752 | 7.5 | 1.2 | 100 | 42 | +58 | 5 of 15 | 11 of 15 | +162 | +42 |
| Mine | Vampire Counts | 2 | 112 | 482 | 3.0 | 1.0 | 160 | 0 | +160 | 3 of 6 | 5 of 6 | - | +160 |
| Mine | Warriors of Chaos | 2 | 0 | 492 | 2.5 | 1.0 | 197 | 23 | +173 | 2 of 5 | 4 of 5 | - | +173 |
| **Mine** | all armies | 36 | 211 | 260 | 2.7 | 1.1 | 98 | 31 | +67 | 32 of 96 | 75 of 96 | +162 | +61 |
| Opponent | Empire of Man | 1 | 569 | 288 | 1.0 | 1.0 | 288 | 0 | +288 | 1 of 1 | 1 of 1 | - | +288 |
| Opponent | Grand Cathay | 3 | 365 | 339 | 2.0 | 1.2 | 170 | 22 | +147 | 2 of 6 | 6 of 6 | +597 | +57 |
| Opponent | High Elf Realms | 3 | 415 | 246 | 2.0 | 1.0 | 123 | 0 | +123 | 4 of 6 | 5 of 6 | - | +123 |
| Opponent | Kingdom of Bretonnia | 2 | 130 | 168 | 3.5 | 1.1 | 48 | 70 | -22 | 5 of 7 | 4 of 7 | -277 | +20 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 720 | 6.0 | 1.8 | 120 | 0 | +120 | 2 of 6 | 5 of 6 | +180 | +0 |
| Opponent | Skaven | 1 | 180 | 301 | 3.0 | 1.0 | 100 | 136 | -35 | 1 of 3 | 2 of 3 | - | -35 |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 500 | 3.5 | 1.1 | 143 | 28 | +115 | 8 of 14 | 8 of 14 | +183 | +104 |
| Opponent | Vampire Counts | 6 | 0 | 664 | 4.0 | 1.3 | 166 | 22 | +144 | 7 of 24 | 20 of 24 | +170 | +136 |
| Opponent | Warriors of Chaos | 9 | 4 | 617 | 4.2 | 1.1 | 146 | 63 | +83 | 17 of 38 | 28 of 38 | -51 | +103 |
| Opponent | Wood Elf Realms | 6 | 90 | 137 | 1.8 | 1.2 | 75 | 77 | -2 | 2 of 11 | 10 of 11 | +93 | -23 |
| **Opponent** | all armies | 36 | 109 | 438 | 3.2 | 1.2 | 136 | 45 | +91 | 49 of 116 | 89 of 116 | +112 | +86 |

### Effective charges: ss-opp-06f55ce-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 3 (net +15) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 7 | 1 (net +0) | 0 | 1 (net +465) | 2 (net +188) | 0 | 3 (net -103) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 2 (net +19) | 0 | 3 (net +71) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net +0) | 1 (net +254) | 1 (net +144) | 2 (net +52) | 0 | 20% (1 of 5) |
| Mine | Grand Cathay | 19 | 2 (net +0) | 3 (net -213) | 2 (net -217) | 3 (net +0) | 3 (net +24) | 5 (net +79) | 1 | 11% (2 of 18) |
| Mine | High Elf Realms | 17 | 2 (net +0) | 0 | 4 (net +130) | 3 (net +200) | 5 (net +41) | 1 (net +79) | 2 | 27% (4 of 15) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +114) | 0 | 0 | 3 (net +105) | 0 | 0 | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +116) | 2 (net +157) | 0 | 1 (net +195) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net -33) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +137) | 2 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 15 | 2 (net -30) | 0 | 4 (net +156) | 3 (net +62) | 3 (net -49) | 2 (net +70) | 1 | 29% (4 of 14) |
| Mine | Vampire Counts | 6 | 0 | 0 | 2 (net +0) | 3 (net +321) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Mine | Warriors of Chaos | 5 | 2 (net +246) | 0 | 0 | 0 | 0 | 3 (net +125) | 0 | 0% (0 of 5) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +288) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 1 (net +355) | 2 (net +298) | 2 (net +32) | 1 (net -135) | 0 | 17% (1 of 6) |
| Opponent | High Elf Realms | 6 | 1 (net +265) | 0 | 1 (net +0) | 1 (net +339) | 0 | 2 (net +0) | 1 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 7 | 3 (net +40) | 0 | 0 | 2 (net -138) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 7) |
| Opponent | Orc & Goblin Tribes | 6 | 1 (net +395) | 0 | 0 | 0 | 2 (net +63) | 1 (net +199) | 2 | 0% (0 of 4) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net -106) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 14 | 3 (net +114) | 0 | 1 (net +271) | 3 (net +48) | 2 (net +48) | 4 (net +146) | 1 | 8% (1 of 13) |
| Opponent | Vampire Counts | 24 | 7 (net +152) | 2 (net +58) | 1 (net +0) | 6 (net +262) | 4 (net +84) | 2 (net +0) | 2 | 5% (1 of 22) |
| Opponent | Warriors of Chaos | 38 | 4 (net +131) | 1 (net +0) | 7 (net +234) | 11 (net +50) | 3 (net +81) | 7 (net +60) | 5 | 21% (7 of 33) |
| Opponent | Wood Elf Realms | 11 | 2 (net -155) | 0 | 1 (net +0) | 0 | 2 (net +93) | 1 (net +264) | 5 | 17% (1 of 6) |

### Charged fights, damage counted: ss-opp-06f55ce-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 181 | 281 | +60 | 114 | 111 | +3 | +1.6 |
| Mine | 50-54% | 3 | 291 | 291 | -213 | 101 | 213 | -112 | -38.4 |
| Mine | Effective (55-75%) | 16 | 240 | 254 | +79 | 191 | 128 | +64 | +26.6 |
| Mine | 76-89% | 25 | 311 | 162 | +124 | 140 | 13 | +127 | +40.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 232 | 169 | +60 | 118 | 31 | +87 | +37.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 397 | 82 | +23 | 73 | 65 | +7 | +1.9 |
| Mine | No odds | 7 | 296 | 121 | +66 | 93 | 21 | +72 | +24.3 |
| Mine | All fights | 96 | 275 | 184 | +67 | 128 | 61 | +67 | +24.3 |
| Opponent | Long shot (under 50%) | 21 | 300 | 270 | +114 | 227 | 109 | +118 | +39.3 |
| Opponent | 50-54% | 3 | 159 | 127 | +38 | 38 | 8 | +30 | +19.1 |
| Opponent | Effective (55-75%) | 13 | 276 | 252 | +196 | 329 | 114 | +215 | +78.0 |
| Opponent | 76-89% | 25 | 314 | 213 | +117 | 172 | 53 | +119 | +37.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 291 | 188 | +61 | 124 | 59 | +65 | +22.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 450 | 102 | +62 | 73 | 2 | +71 | +15.7 |
| Opponent | No odds | 17 | 216 | 202 | +17 | 83 | 66 | +17 | +7.7 |
| Opponent | All fights | 116 | 305 | 203 | +91 | 160 | 64 | +96 | +31.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-opp-06f55ce-p3 | move | 333 | 74 (22%) | 56 (17%) | 50 (15%) | 209 (63%) |
| ss-opp-06f55ce-p3 | objective | 436 | 64 (15%) | 46 (11%) | 56 (13%) | 316 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: ss-opp-06f55ce-p4

### Scorecard: ss-opp-06f55ce-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 13 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 2 | 2 | 6 | 3 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 2 | 0 | 1 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 985 |
| L0315 | 3 | 1 | Opponent | yes | 20 | 2 | 2 | 0 | 2 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 9 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 6 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 0 | 3 | 0 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 1140 |
| L0624 | 6 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 1197 |
| L0624 | 6 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | - | 0 | 2 | 1 | 0 | 0 | 779 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | yes | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 679 |
| L0835 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 492 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 6 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 4 | 0 | 3 | 0 | 0 | 0 | 500 |
| L1126 | 4 | 1 | Mine | no | 3 | 6 | 0 | 0 | 0 | 0 | 0 | 956 |
| L1126 | 4 | 1 | Opponent | no | 11 | 3 | 5 | 2 | 1 | 0 | 0 | 357 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 0 | 0 | 0 | 617 |
| L1314 | 6 | 1 | Mine | no | 2 | 5 | 1 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 8 | 2 | 1 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 4 | 1 | 1 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | no | - | 1 | 2 | 3 | 1 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 50 |
| L1523 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 305 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 5 | 2 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 147 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | - | 3 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 2 | 2 | 0 | 0 | 0 | 250 |
| L2021 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 1 | 3 | 0 | 0 | 0 | 200 |
| L2123 | 5 | 1 | Mine | no | - | - | 3 | 4 | 1 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 2 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | - | 1 | 2 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 7 | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 4 | 6 | 4 | 2 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 5 | 0 | 0 | 0 | 160 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 9 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 36% | 1.6 | 3.2 | 2.6 | 1.1 | 0.2 | 0.0 | 0.0 | 339.6 |
| **Average** | | | Opponent | 36% | 4.0 | 2.2 | 2.8 | 2.2 | 0.5 | 0.0 | 0.0 | 159.1 |

### KPIs: ss-opp-06f55ce-p4

Rules off - Mine only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (40 of 174) | 1% (1 of 181) | 12% (41 of 355) |
| Winner chose to follow up after the loser gave ground |  | 100% (55 of 55); on the table 100% | 100% (52 of 52); on the table 100% | 100% (107 of 107); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 100% | 96% (22 of 23); on the table 96% | 93% (28 of 30); on the table 97% |
| Winner chose to pursue after the loser fled |  | 81% (21 of 26); on the table 85% | 81% (21 of 26); on the table 81% | 81% (42 of 52); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 93% (82 of 88); on the table 95% | 94% (95 of 101); on the table 94% | 94% (177 of 189); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 30% (82 of 269) | 34% (58 of 173) | 32% (140 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (82 of 193) | 48% (58 of 120) | 45% (140 of 313) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (30 of 46) | 64% (39 of 61) | 64% (69 of 107) |
| Points that never fought | lower | 39% (26354 of 67942) | 36% (26096 of 71984) | 37% (52450 of 139926) |
|   infantry points that never fought | lower | 41% (6365 of 15347) | 57% (7884 of 13804) | 49% (14249 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (175 of 270) | 56% (156 of 280) | 60% (331 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.4 uses a game | 89% (8 of 9); 0.7 uses a game | 87% (27 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.3 uses a game | 45% (9 of 20); 0.3 uses a game | 44% (16 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 68% (13 of 19); 0.4 uses a game | 60% (9 of 15); 0.2 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (34936 of 57750) | 47% (30089 of 63347) | 54% (65025 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (31%) | 1.0 (31%) | 2.6 (31%) |
| MARCHED: its unit marched | 1.2 (24%) | 0.3 (9%) | 1.5 (18%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 0.9 (17%) | 0.5 (17%) | 1.4 (17%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (3%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.8 (16%) | 0.9 (29%) | 1.8 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.0 (0%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.4 | 1.8 | 3.9 | 0.4 | 1.9 |
| not cast | 3.1 | 2.6 | 3.0 | 8.4 | 1.6 | 21.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (45%) | 0.2 (6%) | 2.6 (31%) | 0.5 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (18%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (4%) | 0.5 (18%) | 1.4 (17%) | 0.3 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.2 (6%) | 0.3 (9%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 1.4 (47%) | 0.5 (20%) | 0.7 (23%) | 1.8 (21%) | 0.1 (9%) | 4.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (9%) | 0.1 (4%) | 0.4 (4%) | 0.1 (5%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (9%) | 0.0 (1%) | 0.1 (1%) | 0.2 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (39%) | 0.1 (3%) | 1.2 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.8 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 66% (31 of 47) | 57% (8 of 14) | 64% (39 of 61) |
| the unit moved after it | 71% (22 of 31) | 75% (6 of 8) | 72% (28 of 39) |
| it charged on its next turn | 10% (3 of 31) | 12% (1 of 8) | 10% (4 of 39) |
| the enemy charged it first | 23% (7 of 31) | 0% (0 of 8) | 18% (7 of 39) |
| it fought by the end of its next turn | 16% (5 of 31) | 12% (1 of 8) | 15% (6 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (9 of 31) | 0% (0 of 8) | 23% (9 of 39) |
| none of these (no charge, no fight, no charge escaped) | 42% (13 of 31) | 75% (6 of 8) | 49% (19 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (577 of 872) | 53% (282 of 537) | 61% (859 of 1409) |
|   cavalry | 56% (45 of 81) | 65% (75 of 116) | 61% (120 of 197) |
|   character | 52% (53 of 101) | 19% (24 of 126) | 34% (77 of 227) |
|   chariot | 61% (69 of 113) | 65% (20 of 31) | 62% (89 of 144) |
|   infantry | 63% (164 of 259) | 62% (131 of 210) | 63% (295 of 469) |
|   monster | 54% (25 of 46) | 28% (7 of 25) | 45% (32 of 71) |
|   war machine | 81% (221 of 272) | 86% (25 of 29) | 82% (246 of 301) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (20%) | 1.4 (20%) | 3.0 (20%) |
| CHARGED: it charged | 1.0 (12%) | 1.7 (24%) | 2.7 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.2 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.6 (8%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.2 (27%) | 1.4 (20%) | 3.7 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.4 (6%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (13%) | 1.2 (17%) | 2.2 (15%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.1 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.5 | 80% | 4.9 pts | 27 pts |
| character | 2.3 | 0.6 | 80% | 5.9 pts | 14 pts |
| chariot | 2.5 | 1.3 | 71% | 12.6 pts | 32 pts |
| infantry | 12.2 | 5.0 | 72% | 10.0 pts | 122 pts |
| monster | 0.9 | 0.2 | 79% | 3.9 pts | 4 pts |
| war machine | 6.8 | 5.8 | 68% | 33.6 pts | 230 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.4 | 5.2 |
| Charges that made contact a game | 2.7 | 4.5 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.47 declared, 0.35 contact (17 units) | 0.47 declared, 0.29 contact (17 units) | 0.47 declared, 0.32 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.44 declared, 0.44 contact (9 units) | 1.73 declared, 1.36 contact (11 units) | 1.15 declared, 0.95 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.35 contact (248 units) | 0.69 declared, 0.48 contact (298 units) | 0.61 declared, 0.42 contact (546 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (48 of 81) | 50% (8 of 16) | 50% (3 of 6) | 57% (59 of 103) |
| Character in a unit | 85% (23 of 27) | 87% (13 of 15) | 100% (1 of 1) | 86% (37 of 43) |
| Character on its own | 84% (32 of 38) | 63% (17 of 27) | 29% (22 of 77) | 50% (71 of 142) |
| Chariot | 73% (11 of 15) | 67% (8 of 12) | - | 70% (19 of 27) |
| Infantry | 59% (49 of 83) | 44% (11 of 25) | 50% (3 of 6) | 55% (63 of 114) |
| Monster | 65% (22 of 34) | 71% (10 of 14) | - | 67% (32 of 48) |
| Monstrous | 43% (6 of 14) | 57% (8 of 14) | - | 50% (14 of 28) |
| War Machines | 79% (34 of 43) | 100% (2 of 2) | - | 80% (36 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 100% | 30% (31 of 102) | 24% | 82% (18 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 87% (20 of 23); on the table 91% | 33% (8 of 24) | 20% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 73% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (7 of 9); on the table 78% | 61% (11 of 18) | 61% | 74% (46 of 62) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (12 of 12); on the table 100% | 31% (26 of 84) | 41% | 57% (21 of 37) | 89% (8 of 9); 5.8 uses a game | 100% (2 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 90% (19 of 21); on the table 90% | 17% (6 of 36) | 29% | 51% (36 of 70) | 100% (7 of 7); 2.0 uses a game | 40% (12 of 30); 1.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 49% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (15 of 15); on the table 100% | 83% (5 of 6) | 38% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 29% | 93% (13 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (15 of 15); on the table 100% | 26% (11 of 42) | 14% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 100% (13 of 13); on the table 100% | 32% (13 of 40) | 35% | 78% (35 of 45) | 67% (2 of 3); 1.3 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 93% (14 of 15); on the table 93% | 33% (2 of 6) | 24% | 25% (5 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (15 of 15); on the table 100% | 32% (19 of 60) | 37% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (16 of 16); on the table 100% | 33% (4 of 12) | 46% | 61% (44 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 86% (18 of 21); on the table 86% | 33% (2 of 6) | 38% | 59% (33 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (ss-opp-06f55ce-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 37% (35) | 50% (31) | 42% (66) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.53 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.11 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.39 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 0.94 | 2.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.94 | 1.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.06 | 5.58 | 11.64 |

### Quality by phase: ss-opp-06f55ce-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 43% (57 of 134) | 38% (76 of 199) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (183 of 417) | 41% (75 of 182) |
| Strategy | Close-in objectives charged next turn | 11% (19 of 171) | 14% (28 of 206) |
| Strategy | Support requests answered (helper made contact too) | 42% (5 of 12) | 43% (15 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (7 of 16) | 100% (5 of 5) |
| Strategy | Joined characters whose unit fought | 49% (19 of 39) | 39% (11 of 28) |
| Strategy | Lone characters that fought | 68% (57 of 84) | 77% (68 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 2.2 |
| Movement | Points that never moved of their own | 339.6 | 159.1 |
| Movement | Fights charged into per game | 2.7 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 18 of 85, net +40 | 28 of 110, net +34 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 85, net +22 | 21 of 110, net +79 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 85, net +75 | 8 of 110, net +101 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 of 85, net +86 | 25 of 110, net +107 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 8.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (172 of 391) | 40% (123 of 305) |
| Shooting | Points destroyed by shooting units | 79.5 | 23.8 |
| Shooting | War machine shots | 6.1 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (137 of 221) | 12% (3 of 25) |
| Shooting | Points destroyed by war machines | 96.5 | 9.7 |
| Magic | Magic missiles cast | 1.4 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (19 of 49) | 22% (8 of 37) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.1 |
| Magic | Wounds caused by other spells | 1.7 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 70.1 | 46.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.8 / 0.2 | 1.7 / 0.4 / 0.5 / 0.0 |
| Combat | Points destroyed in combat | 284.6 | 487.4 |
| Combat | Points run down | 95.1 | 94.4 |
| Combat | Net points per charged fight, damage counted | +60 | +84 |
| Combat | Net per 100 charger points, damage counted | +24.5 | +28.4 |
| Combat | First round won (charged fights) | 68% | 68% |
| Combat | Net points per charged fight | +51 | +91 |
| Combat | Net points per supported fight / lone fight | +31 / +52 | +175 / +76 |
| Combat | Charged fights on a top-3 enemy unit | 37 of 97 | 61 of 136 |
| Game | Points lost | 763.3 | 698.3 |
| Game | VP from objectives | 508.1 | 552.2 |
| Game | Lone holders (player turns) | 1.6 | 4.0 |

- Mine won / drew / lost: 13 / 5 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -118 VP
- The side that went first won 18 of 31 games with a winner
- Points traded per game (both sides' losses): 1462
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-opp-06f55ce-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.8 | -129.4 | 134.5 | 135.8 | 3.6 | -145.0 | 79.9 | 61.6 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 33.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.4 | +1.8 | 0.0 | 20.2 | 0.7 | +6.3 | 0.0 | 5.4 |
| BEST FACING | 0.4 | +14.6 | 0.0 | 8.2 | 0.3 | +15.9 | 0.0 | 13.9 |
| BEST FIRST | 1.3 | +61.2 | 31.4 | 29.8 | 0.8 | +38.2 | 1.2 | 36.0 |
| BEST OVERALL | 0.3 | +21.2 | 0.0 | 0.0 | 0.2 | +5.1 | 0.0 | 9.6 |
| BEST PREY | 0.5 | +28.0 | 19.2 | 0.0 | 0.5 | +21.0 | 3.5 | 0.0 |
| BEST PRIZE | 0.1 | -3.1 | 2.3 | 0.0 | 0.1 | -4.3 | 6.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 15.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +6.8 | 0.0 | 5.1 | 0.2 | +1.9 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -19.1 | 41.2 | 2.5 | 0.2 | -20.5 | 37.0 | 8.5 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 101.2 | 11.1 | 0.0 | +0.0 | 10.6 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +166.3 | 311.6 | 94.2 | 0.6 | +27.1 | 38.3 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 20.6 | 0.0 | 0.1 | -8.9 | 19.8 | 13.1 |
| CAST JOB | 0.7 | +17.4 | 41.6 | 9.3 | 0.5 | +14.9 | 27.2 | 23.8 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 9.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +42.1 | 45.3 | 8.9 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 43.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +63.8 | 0.0 | 20.7 | 2.2 | +132.5 | 0.0 | 33.6 |
| CHAFF PASSED | 0.2 | -0.9 | 3.8 | 7.6 | 0.2 | -0.5 | 0.0 | 3.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | -0.1 | 6.5 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.2 | +0.0 | 189.0 | 72.0 | 2.7 | +0.0 | 297.0 | 63.9 |
| CHARGE NOW WEIGHED | 0.5 | -28.5 | 27.9 | 9.4 | 0.4 | -31.5 | 1.0 | 4.0 |
| CHARGER SLAIN LOST | 0.4 | -4.9 | 36.1 | 10.5 | 0.7 | -27.9 | 104.4 | 32.8 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 6.5 | 0.0 | 0.1 | +0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 4.2 | 0.2 | +0.0 | 1.7 | 6.2 |
| CHEAPEST HOLDER | - | - | - | - | 1.6 | -75.9 | 76.4 | 9.6 |
| COMBAT PIVOT | 0.4 | +0.0 | 5.4 | 54.2 | 0.7 | +0.0 | 72.2 | 15.3 |
| CONVEYANCE SEARCH | 0.8 | +71.6 | 31.9 | 52.4 | 0.3 | +31.7 | 0.0 | 7.6 |
| COVER ONCE | 7.6 | -385.6 | 0.0 | 216.0 | 6.0 | -402.4 | 0.0 | 108.0 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 2.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +0.3 | 8.8 | 0.0 | 0.2 | +2.6 | 23.5 | 5.2 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +133.9 | 0.0 | 61.3 | 0.9 | +47.7 | 0.0 | 34.1 |
| FALLBACK BY WORTH | 4.7 | +31.1 | 0.0 | 54.5 | 3.8 | +28.2 | 0.0 | 28.0 |
| FALLS SHORT | - | - | - | - | 14.8 | +221.6 | 0.0 | 242.0 |
| FIGHT LIFT | 0.1 | +2.1 | 13.1 | 9.9 | 0.0 | +0.1 | 0.0 | 11.0 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 132.4 | 5.1 | +0.0 | 0.0 | 68.9 |
| FOCUS FIRE | 0.0 | +0.6 | 1.8 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +119.8 | 0.0 | 38.2 | 1.1 | +127.2 | 0.0 | 31.4 |
| FRIENDS SHOTS CHECKED | 0.1 | +1.9 | 0.0 | 0.0 | 0.2 | +12.2 | 0.0 | 0.8 |
| GIVES UP | 0.1 | -0.5 | 4.9 | 0.0 | 0.1 | -3.7 | 14.2 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 20.5 | 0.0 |
| GROUND FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 0.7 | +0.0 | 0.0 | 14.9 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.8 |
| HELPER UNSEEN | 0.4 | +0.0 | 39.3 | 14.2 | 0.4 | +0.0 | 44.1 | 23.0 |
| HILL BY ITS CHANCE | 0.6 | -58.9 | 0.0 | 3.1 | 0.6 | -55.7 | 0.0 | 19.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.8 | -136.7 | 467.7 | 135.2 | 8.6 | -223.3 | 519.7 | 126.2 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +4.2 | 6.9 | 1.7 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.7 |
| HUNT IN PAIRS | 0.5 | +7.9 | 0.0 | 5.7 | 0.2 | +14.7 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.0 | 24.7 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +68.1 | 0.0 | 1.7 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +111.4 | 61.4 | 1.7 |
| IDLE COST | 17.3 | -277.4 | 0.0 | 172.1 | 9.2 | -133.5 | 0.0 | 166.2 |
| INVITES THE FIGHT | 1.2 | +7.9 | 33.6 | 69.5 | 0.7 | +5.3 | 9.7 | 10.1 |
| JOINT CHARGE PLAN | 0.2 | +5.3 | 15.0 | 8.0 | 0.1 | +3.8 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -2.7 | 9.5 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.1 | 4.4 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +41.7 | 141.9 | 21.2 | 1.4 | +40.8 | 100.1 | 11.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +60.7 | 75.2 | 53.6 | 1.9 | +94.8 | 171.0 | 33.1 |
| KILLS COUNT NEXT TURN | 5.1 | +173.4 | 279.0 | 83.8 | 5.2 | +171.6 | 108.4 | 84.7 |
| LONE CHARACTER SAFE SPOT | 0.3 | +13.6 | 0.0 | 13.8 | 0.1 | +9.8 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.7 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +3.2 | 18.8 | 4.8 | 0.6 | -0.9 | 19.3 | 10.2 |
| LOST CHARGE | 2.8 | -32.4 | 181.9 | 72.1 | 1.7 | -22.4 | 62.5 | 25.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -12.8 | 0.0 | 0.0 | 0.1 | -13.4 | 0.0 | 4.7 |
| MAKE SURE TOGETHER | 0.8 | +64.5 | 67.5 | 17.6 | 0.6 | +66.8 | 0.0 | 3.1 |
| MANOEUVRE | 0.2 | +13.3 | 0.0 | 10.3 | 0.2 | +1.7 | 0.0 | 10.2 |
| MARCH AT ESCAPER | 0.1 | +0.9 | 0.0 | 6.6 | 0.1 | +0.2 | 0.0 | 5.4 |
| MARCH CHECK | 0.3 | +4.8 | 0.0 | 0.0 | 0.4 | +16.5 | 0.0 | 10.8 |
| MARCH ODDS | 0.4 | +33.8 | 23.9 | 5.7 | 0.1 | +7.1 | 0.0 | 17.4 |
| MARCH OVER CASTS | 0.6 | +36.9 | 0.0 | 11.1 | 0.2 | +24.3 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 6.3 | +100.7 | 0.0 | 124.2 | 5.4 | +55.5 | 0.0 | 128.1 |
| MISSILES IN THE MOVE | 3.8 | +131.1 | 0.0 | 102.9 | 2.3 | +40.7 | 0.0 | 146.8 |
| MISSILES NEXT TURN | 4.5 | +84.5 | 0.0 | 114.0 | 2.7 | +24.6 | 0.0 | 141.3 |
| MODEL FACING | 0.3 | +50.9 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 17.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +3.9 | 0.0 | 24.6 | 0.4 | +15.5 | 0.0 | 57.2 |
| MOVE SPELL IN RANGE | 0.2 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -25.3 | 21.1 | 20.4 | 0.1 | -4.8 | 5.3 | 15.2 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 12.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.2 | +180.6 | 218.4 | 69.2 | 3.9 | +261.2 | 96.7 | 37.1 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 9.7 | +567.2 | 0.0 | 90.0 |
| NEEDED THERE | 0.0 | +1.3 | 0.0 | 0.0 | 0.1 | +23.4 | 14.6 | 0.0 |
| NO FORCED ADVANCE | - | - | - | - | 3.6 | +0.0 | 0.0 | 62.4 |
| NO RALLY LEFT | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -7.4 | 9.6 | 0.0 | 0.3 | -13.1 | 28.6 | 1.2 |
| NOT TURNED | 6.1 | +48.7 | 0.0 | 114.8 | 5.6 | +38.3 | 0.0 | 56.5 |
| NOT WORTH A CAST | 0.4 | -0.4 | 0.0 | 20.4 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -651.7 | 12.5 | 275.2 | 13.7 | -553.5 | 28.4 | 216.8 |
| ONE FIGHT FORMULA | 8.8 | -147.5 | 18.8 | 227.4 | 6.6 | -145.5 | 9.7 | 102.0 |
| ONE OBJECTIVE FORMULA | 2.5 | -139.5 | 0.0 | 22.7 | 2.1 | -112.7 | 0.0 | 22.6 |
| OPENS A LANE | 0.1 | +0.2 | 9.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +16.9 | 10.1 | 0.0 | 0.4 | +40.4 | 20.9 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +13.4 | 60.8 | 24.4 | 0.4 | +9.9 | 67.2 | 15.1 |
| PATHS CROSS | 2.2 | +154.8 | 0.0 | 23.1 | 2.9 | +131.8 | 0.0 | 27.8 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -3.8 | 0.0 | 0.0 | 0.1 | -3.5 | 0.0 | 1.5 |
| PLAN RESULT | 38.9 | +1623.2 | 1595.4 | 962.6 | 35.7 | +1000.8 | 1087.4 | 787.8 |
| PURSUES BIG PREY | 0.1 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.7 | 0.0 | 0.0 | 0.1 | +11.5 | 0.0 | 4.4 |
| RANDOM MOVE BY FIGURES | 1.3 | +15.9 | 0.0 | 12.8 | 1.7 | +38.8 | 0.0 | 70.7 |
| RANDOM MOVER NO PROMISE | 0.3 | -17.4 | 19.0 | 0.0 | 0.2 | -7.4 | 2.5 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.9 | -19.5 | 0.0 | 18.2 | 2.1 | -44.2 | 0.0 | 28.1 |
| REDIRECT COUNTER | 2.8 | +154.4 | 0.0 | 32.9 | 4.3 | +295.5 | 0.0 | 61.8 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 3.1 | 0.7 | +21.1 | 33.0 | 34.4 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 16.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +18.8 | 0.0 | 16.3 | 0.7 | +26.9 | 0.0 | 19.9 |
| RESTRAINS TO SHOOT | 0.1 | +2.4 | 0.0 | 4.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +70.3 | 196.4 | 80.0 | 3.1 | +68.5 | 359.5 | 63.4 |
| RISK ONCE | 2.1 | +22.4 | 20.2 | 109.7 | 2.9 | +108.1 | 39.5 | 148.1 |
| SAFE SURE CHARGE | 0.1 | -2.2 | 5.9 | 0.0 | 0.0 | -0.4 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +64.8 | 0.0 | 21.2 | 0.9 | +51.4 | 0.0 | 19.2 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -10.6 | 0.0 | 2.5 | 0.5 | -33.5 | 0.0 | 0.8 |
| SEARCH SPOT | 2.8 | +100.5 | 0.0 | 29.5 | 2.5 | +90.5 | 0.0 | 16.7 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.9 | 33.3 | 0.0 |
| SELF MOVE SPELL | 0.2 | +10.5 | 0.0 | 0.0 | 0.4 | +8.3 | 0.0 | 49.1 |
| SET UP TOGETHER | 1.0 | +82.0 | 67.5 | 39.2 | 1.4 | +105.3 | 6.2 | 20.3 |
| SET-UP ANY TARGET | 0.4 | +66.0 | 2.4 | 22.8 | 0.1 | +19.3 | 0.0 | 7.6 |
| SET-UP MISSED | 0.1 | +5.7 | 2.5 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +43.6 | 78.8 | 20.6 | 1.2 | +43.3 | 47.4 | 42.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.5 | +0.0 | 93.8 | 21.9 | 0.1 | +0.0 | 7.3 | 0.0 |
| SHOTS IN THE MOVE | 15.1 | +572.6 | 0.0 | 339.5 | 7.2 | +167.6 | 0.0 | 99.1 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL OFF EDGE | - | - | - | - | 0.1 | +1.9 | 2.6 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +84.5 | 2.4 | 22.8 | 0.2 | +45.9 | 0.0 | 7.6 |
| SPELL WORTH | 1.3 | +23.2 | 101.5 | 107.6 | 2.2 | +34.9 | 86.3 | 97.3 |
| SPELLS IN THE FIGHT | 0.6 | -3.7 | 47.5 | 11.2 | 1.0 | -13.6 | 166.7 | 18.1 |
| STABLE ROLE | 11.2 | +0.0 | 426.4 | 178.5 | 10.5 | +0.0 | 297.0 | 134.7 |
| STAY WEIGHED | 0.1 | +5.6 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.2 | +3.3 | 74.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +29.5 | 0.0 | 13.1 | 0.3 | +5.1 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.6 | -65.8 | 328.0 | 85.7 | 7.7 | -60.5 | 382.7 | 101.2 |
| SUPPORTS | 4.9 | +75.9 | 226.4 | 60.6 | 5.4 | +62.4 | 164.1 | 30.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.9 | 13.6 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | +0.3 | 0.0 | 17.6 | 0.7 | -0.7 | 0.0 | 9.4 |
| THROUGH LINE OF FIRE | 0.3 | +14.3 | 0.0 | 20.8 | 0.1 | +1.4 | 0.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 8.6 | +128.7 | 0.0 | 72.1 |
| TURN WORTH | 0.3 | -19.7 | 25.9 | 13.1 | 0.1 | -13.1 | 7.5 | 3.0 |
| TWO OR MORE ARRIVE | 0.3 | +0.9 | 60.0 | 7.7 | 0.5 | +4.2 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.5 | -281.1 | 287.0 | 172.4 | 6.1 | -282.3 | 145.2 | 67.6 |
| WALKS TO THE FIGHT | 1.8 | +10.9 | 11.8 | 34.8 | 0.5 | +4.9 | 31.5 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +16.9 | 14.3 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 31.5 | 20.7 | 0.2 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 1.2 | +38.9 | 117.3 | 19.9 | 1.4 | +54.6 | 169.9 | 42.1 |
| WHO HITS BACK | 0.2 | +11.8 | 0.0 | 0.0 | 0.4 | +28.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.5 | +26.8 | 51.1 | 7.2 | 0.4 | +36.6 | 95.9 | 0.8 |
| WHOLE FIGHT GAIN | 0.2 | +12.9 | 16.9 | 0.8 | 0.9 | +72.9 | 58.7 | 10.4 |
| WIDER SPREAD | 2.6 | -7.2 | 215.6 | 67.4 | 3.8 | -5.2 | 401.5 | 57.4 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 3.5 | 0.0 |

### Rule changes: ss-opp-06f55ce-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1077 | 1077 | 1077 | 29.92 | -43387 | -40.3 |
| PATHS CROSS | 184 | 184 | 184 | 5.11 | +10319 | +56.1 |
| SEARCH SPOT | 191 | 191 | 184 | 5.11 | +6878 | +37.4 |
| MOVE TO CHARGE | 256 | 256 | 149 | 4.14 | +6165 | +41.4 |
| SUPPORTS | 371 | 371 | 149 | 4.14 | +1668 | +11.2 |
| NO FORCED ADVANCE | 130 | 130 | 130 | 3.61 | +2205 | +17.0 |
| KILLS COUNT NEXT TURN | 368 | 368 | 122 | 3.39 | +3247 | +26.6 |
| NEARER NOT NEEDED | 350 | 239 | 110 | 3.06 | +2143 | +19.5 |
| FACES THE THREAT | 98 | 98 | 98 | 2.72 | +6536 | +66.7 |
| CHAFF IN THE MOVE | 114 | 114 | 79 | 2.19 | +2615 | +33.1 |
| BEST FIRST | 76 | 76 | 76 | 2.11 | +3580 | +47.1 |
| COVER ONCE | 491 | 262 | 74 | 2.06 | +1176 | +15.9 |
| WAIT AFTER COSTS | 451 | 451 | 74 | 2.06 | +1207 | +16.3 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +8891 | +125.2 |
| SHOTS IN THE MOVE | 803 | 539 | 70 | 1.94 | +2018 | +28.8 |
| RANDOM MOVE BY FIGURES | 107 | 107 | 69 | 1.92 | +1970 | +28.5 |
| SAFER THAN THE JOB | 68 | 68 | 68 | 1.89 | +4185 | +61.5 |
| REDIRECT COUNTER | 254 | 137 | 66 | 1.83 | +4953 | +75.0 |
| FALLBACK BY WORTH | 304 | 304 | 63 | 1.75 | +2137 | +33.9 |
| FALLS SHORT | 534 | 331 | 59 | 1.64 | +153 | +2.6 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ONE FIGHT FORMULA | 552 | 325 | 50 | 1.39 | +180 | +3.6 |
| SHOOTS FROM THE BEST SPOT | 105 | 105 | 50 | 1.39 | +976 | +19.5 |
| TIME ON OUR SIDE | 308 | 207 | 50 | 1.39 | +95 | +1.9 |
| ARTILLERY RE-ROLL WEIGHED | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| ADVANCE WORTH | 338 | 338 | 47 | 1.31 | +597 | +12.7 |
| SET UP TOGETHER | 89 | 74 | 44 | 1.22 | +2577 | +58.6 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW FIRST | 178 | 178 | 42 | 1.17 | -2887 | -68.7 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +1644 | +40.1 |
| RISK BY ARC | 197 | 189 | 41 | 1.14 | +1199 | +29.3 |
| MISSILES IN THE MOVE | 220 | 149 | 40 | 1.11 | +948 | +23.7 |
| HONEST WORTH | 592 | 584 | 38 | 1.06 | +323 | +8.5 |
| IDLE COST | 954 | 557 | 38 | 1.06 | +496 | +13.1 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +2090 | +63.3 |
| REDIRECT WEIGHED | 33 | 33 | 33 | 0.92 | +1440 | +43.6 |
| RISK ONCE | 182 | 123 | 31 | 0.86 | +1506 | +48.6 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1245 | +41.5 |
| KILLS COUNT | 114 | 110 | 29 | 0.81 | +1444 | +49.8 |
| MAX FOR POSITIONING | 420 | 271 | 29 | 0.81 | +57 | +2.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| WALKS TO THE FIGHT | 82 | 82 | 28 | 0.78 | +131 | +4.7 |
| INVITES THE FIGHT | 69 | 69 | 26 | 0.72 | +132 | +5.1 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +1097 | +43.9 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +312 | +12.5 |
| HARD STAY DROPPED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| MARCH CHECK | 24 | 24 | 24 | 0.67 | +1265 | +52.7 |
| CANNON PLANNED TARGET | 201 | 201 | 23 | 0.64 | -218 | -9.5 |
| CAST JOB | 41 | 41 | 23 | 0.64 | +426 | +18.5 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +698 | +31.7 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +840 | +42.0 |
| WHOLE FIGHT GAIN | 41 | 35 | 20 | 0.56 | +452 | +22.6 |
| MAKE SURE TOGETHER | 49 | 35 | 19 | 0.53 | +1618 | +85.2 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +339 | +17.8 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| WEARS DOWN | 92 | 89 | 18 | 0.50 | +702 | +39.0 |
| BEST OVERALL | 17 | 17 | 17 | 0.47 | +947 | +55.7 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +565 | +33.2 |
| WAR ENGINE JOBS | 33 | 33 | 17 | 0.47 | -688 | -40.5 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -52 | -3.2 |
| KEEPS ITS TARGET | 99 | 98 | 16 | 0.44 | +272 | +17.0 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -0 | -0.0 |
| MANOEUVRE | 16 | 16 | 15 | 0.42 | +538 | +35.8 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SUPPORT NARROWED | 514 | 514 | 14 | 0.39 | -130 | -9.3 |
| OPENS UP | 23 | 23 | 13 | 0.36 | +843 | +64.8 |
| BEST PREY | 36 | 36 | 12 | 0.33 | +360 | +30.0 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +508 | +42.3 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +1834 | +166.7 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.31 | -263 | -23.9 |
| WHOLE FIGHT | 30 | 30 | 10 | 0.28 | +565 | +56.5 |
| WIDER SPREAD | 230 | 221 | 10 | 0.28 | +32 | +3.2 |
| CASTING BLOCK | 14 | 14 | 9 | 0.25 | +933 | +103.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 258 | 168 | 9 | 0.25 | +7 | +0.7 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 162 | 161 | 8 | 0.22 | +181 | +22.6 |
| RAIDS THE BAGGAGE NEXT TURN | 9 | 9 | 8 | 0.22 | +367 | +45.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -705 | -117.4 |
| NEEDED THERE | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SAFE SURE CHARGE | 5 | 5 | 5 | 0.14 | +153 | +30.6 |
| BACKUP TARGETS | 39 | 12 | 4 | 0.11 | +16 | +4.1 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +131 | +32.9 |
| LONG SHOT | 37 | 35 | 4 | 0.11 | +28 | +7.0 |
| OVERRUNS AWAY | 39 | 38 | 4 | 0.11 | +122 | +30.6 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +273 | +68.2 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +109 | +27.2 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +210 | +52.5 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -104 | -25.9 |
| WAR ENGINE CHARGES | 4 | 4 | 4 | 0.11 | +509 | +127.1 |
| CARRIES OUT SET-UP | 8 | 8 | 3 | 0.08 | -320 | -106.7 |
| HUNT IN PAIRS | 27 | 16 | 3 | 0.08 | +48 | +16.1 |
| JOINT CHARGE PLAN | 10 | 10 | 3 | 0.08 | +90 | +30.1 |
| ONE OBJECTIVE FORMULA | 166 | 65 | 3 | 0.08 | +203 | +67.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CHARGER SLAIN LOST | 41 | 40 | 2 | 0.06 | +71 | +35.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +6 | +2.8 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -62 | -31.1 |
| REDIRECT BY WHAT IT STOPS | 105 | 105 | 2 | 0.06 | +10 | +5.1 |
| REFUSING RETIRES | 13 | 13 | 2 | 0.06 | -1 | -0.5 |
| SPELLS IN THE FIGHT | 56 | 56 | 2 | 0.06 | +17 | +8.7 |
| SURE REACH TOGETHER | 38 | 26 | 2 | 0.06 | +4 | +2.1 |
| TWO OR MORE ARRIVE | 28 | 27 | 2 | 0.06 | +15 | +7.3 |
| BLOWS WHERE AIMED | 17 | 15 | 1 | 0.03 | +17 | +17.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| EDGE GIVE GROUND | 10 | 9 | 1 | 0.03 | +6 | +6.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +78 | +77.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +20 | +20.3 |
| HUNT ADVANCE | 7 | 7 | 1 | 0.03 | +29 | +29.1 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 6 | 6 | 1 | 0.03 | -119 | -119.3 |
| MOVE SPELL IN RANGE | 7 | 4 | 1 | 0.03 | +4 | +4.1 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -182 | -181.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 11 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 57 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 398 | not checked | - | - | - | - |
| GIVES UP | 5 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 26 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 43 | 43 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 27 | 27 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 26 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 419 | 419 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 27 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2683 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 125 | not checked | - | - | - | - |
| STABLE ROLE | 784 | 781 | 0 | 0.00 | - | - |
| STOPS | 6 | 6 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: ss-opp-06f55ce-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.64 | 11.72 | 40.0 |
| FALLBACK | gate | 0.56 | 0.94 | 54.7 |
| CHARGE NOW FIRST | rule | 0.42 | 0.75 | 68.7 |
| TURN GATE | gate | 0.64 | 0.53 | 36.0 |
| WAR ENGINE JOBS | rule | 0.33 | 0.14 | 40.5 |
| SUPPORT NARROWED | rule | 0.08 | 0.31 | 9.3 |
| PATHS CROSS | rule | 0.06 | 0.25 | 30.9 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.14 | 23.9 |
| AFTERMATH BAND | gate | 0.11 | 0.14 | 2.7 |
| CHAFF PASSED | rule | 0.17 | 0.08 | 5.7 |
| FIGHT ORDER BAND | gate | 0.14 | 0.11 | 1.8 |
| SUPPORT REQUEST | gate | 0.08 | 0.17 | 85.9 |
| BEST PRIZE | rule | 0.06 | 0.11 | 117.4 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 5.7 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.06 | 22.4 |
| SAFE SURE CHARGE | rule | 0.08 | 0.03 | 13.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 2.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | - | 25.9 |
| CANNON PLANNED TARGET | rule | 0.08 | - | 75.3 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 106.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 31.1 |
| BLOCKED WHEEL | rule | 0.06 | - | 15.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 43.4 |
| MARCH ODDS | rule | 0.06 | - | 3.4 |
| NEARER NOT NEEDED | rule | - | 0.06 | 4.1 |
| PURSUES BIG PREY | rule | 0.06 | - | 31.1 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 11.4 |
| WHO HITS BACK | rule | 0.03 | 0.03 | 4.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 119.3 |
| NO REASON | gate | - | 0.03 | 1.6 |
| REDIRECT WEIGHED | rule | - | 0.03 | 348.5 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 3.6 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 181.8 |

### Plans: ss-opp-06f55ce-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.9 | 16% | 153 | 239 | 156% |
| Mine | charge | 3.1 | 60% | 210 | 273 | 130% |
| Mine | close in | 4.8 | 25% | 224 | 192 | 85% |
| Mine | hold | 5.1 | 32% | 267 | 0 | 0% |
| Mine | join | 0.6 | 85% | 12 | 0 | 0% |
| Mine | shoot | 9.6 | 66% | 392 | 919 | 234% |
| Mine | support | 5.7 | 95% | 61 | 0 | 0% |
| Opponent | advance | 6.7 | 11% | 90 | 90 | 101% |
| Opponent | charge | 4.7 | 57% | 432 | 481 | 111% |
| Opponent | close in | 5.7 | 20% | 308 | 158 | 51% |
| Opponent | hold | 6.4 | 27% | 385 | 0 | 0% |
| Opponent | join | 0.7 | 88% | 28 | 0 | 0% |
| Opponent | shoot | 3.9 | 66% | 96 | 271 | 284% |
| Opponent | support | 7.6 | 91% | 44 | 0 | 0% |

### Packages: hunt the guns, ss-opp-06f55ce-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Opponent | 0.3 | 11 | 0 | 45% | 55% | 0% | 2.5 | 365 | 223 | 45% | 115 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 3 | 0 | 0% | 0% | 0% | - | 157 | 0 | 0% | 133 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 392 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 250 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 25% | 50% | 0% | 3.0 | 354 | 104 | 25% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 223 | 174 | 100% | 0 |
| Wood Elf Realms | 0.5 | 3 | 0 | 100% | 100% | 0% | 2.3 | 635 | 620 | 100% | 0 |

### Battle groups: ss-opp-06f55ce-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.8 | 36% | 58% | 8% | 33% | 18% | 0% | 6% | 76% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 22% | 85% | 12% | 25% | 33% | 0% | 20% | 47% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-opp-06f55ce-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 105 (4) | 105 | 0 | 21 | 25% | 2.0 | - | 105 (4) | - | 170 (3) | 0 (1) |
| Mine | Chaff | 34 | 29 (34) | 22 | 7 | 56 | 26% | 2.8 | 18 (14) | 0 (7) | 54 (13) | 16 (22) | 54 (12) |
| Mine | Character | 106 | 38 (106) | 38 | 0 | 44 | 20% | 2.3 | 39 (31) | 46 (55) | 0 (5) | 47 (47) | 37 (44) |
| Mine | Clean-up | 22 | 54 (22) | 28 | 26 | 38 | 32% | 3.3 | 0 (2) | 65 (16) | 48 (4) | 65 (10) | 49 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast | 4 | 127 (4) | 127 | 0 | 73 | 25% | 3.0 | 0 (2) | 254 (2) | - | 113 (3) | 166 (1) |
| Mine | Fast Hammer | 41 | 41 (41) | 28 | 13 | 54 | 22% | 2.6 | 40 (27) | 47 (9) | 33 (5) | 61 (25) | 10 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 25% | 1.7 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Mine | Hammer | 65 | 31 (65) | 20 | 11 | 31 | 22% | 2.3 | 26 (13) | 35 (45) | 13 (7) | 36 (40) | 25 (25) |
| Mine | Holder | 31 | 85 (31) | 11 | 75 | 30 | 29% | 3.0 | 35 (8) | 135 (19) | 0 (4) | 121 (21) | 26 (10) |
| Mine | Shooter | 34 | 55 (34) | 30 | 25 | 56 | 0% | 1.7 | 27 (8) | 78 (21) | 0 (5) | 38 (25) | 109 (9) |
| Mine | Support | 1 | 42 (1) | 42 | 0 | 0 | 0% | 6.0 | - | 42 (1) | - | - | 42 (1) |
| Mine | War machine | 56 | 61 (56) | 61 | 0 | 51 | 5% | 1.3 | 81 (16) | 48 (30) | 59 (10) | 96 (9) | 54 (47) |
| Mine | Wizard | 17 | 33 (17) | 33 | 0 | 14 | 6% | 2.2 | 0 (5) | 54 (9) | 0 (1) | 7 (7) | 54 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 75 | 55 (75) | 20 | 35 | 55 | 45% | 2.7 | 83 (31) | 45 (17) | 32 (27) | 66 (56) | 16 (19) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 29 | 26% | 2.2 | 61 (43) | 55 (40) | 114 (6) | 63 (50) | 62 (39) |
| Opponent | Clean-up | 11 | 55 (11) | 28 | 27 | 36 | 45% | 2.5 | 53 (3) | 30 (6) | 138 (2) | 19 (6) | 75 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 55 (60) | 31 | 24 | 39 | 30% | 2.7 | 45 (26) | 50 (25) | 108 (9) | 68 (39) | 31 (21) |
| Opponent | Fragile | 17 | 11 (17) | 11 | 0 | 67 | 24% | 2.1 | 42 (5) | 0 (8) | 0 (4) | 13 (14) | 0 (3) |
| Opponent | Hammer | 65 | 46 (65) | 29 | 17 | 35 | 35% | 3.3 | 47 (20) | 43 (38) | 77 (7) | 58 (41) | 27 (24) |
| Opponent | Holder | 29 | 18 (29) | 4 | 15 | 31 | 52% | 4.5 | 2 (12) | 30 (11) | 26 (5) | 20 (14) | 18 (14) |
| Opponent | Shooter | 33 | 80 (33) | 28 | 52 | 38 | 0% | 1.6 | 61 (9) | 89 (21) | 74 (3) | 76 (18) | 84 (15) |
| Opponent | Support | 6 | 16 (6) | 16 | 0 | 18 | 33% | 3.8 | 24 (4) | 0 (1) | - | 24 (4) | 0 (1) |
| Opponent | War machine | 6 | 73 (6) | 73 | 0 | 40 | 17% | 1.0 | 60 (3) | 91 (3) | - | 60 (3) | 91 (3) |
| Opponent | Wizard | 19 | 2 (19) | 2 | 0 | 75 | 21% | 1.9 | 0 (9) | 0 (1) | 0 (2) | 0 (7) | 0 (5) |

### Charged fights: ss-opp-06f55ce-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 328 | 146 | 2.0 | 1.1 | 73 | 11 | +62 | 3 of 8 | 5 of 8 | +0 | +71 |
| Mine | Chaos Dwarfs | 4 | 230 | 195 | 4.2 | 1.1 | 46 | 56 | -10 | 8 of 17 | 10 of 17 | -580 | +26 |
| Mine | Dwarfen Mountain Holds | 3 | 545 | 168 | 2.0 | 1.0 | 84 | 0 | +84 | 3 of 6 | 3 of 6 | - | +84 |
| Mine | Empire of Man | 5 | 400 | 111 | 0.8 | 1.0 | 138 | 21 | +117 | 1 of 4 | 4 of 4 | - | +117 |
| Mine | Grand Cathay | 4 | 306 | 273 | 2.2 | 1.1 | 121 | 0 | +121 | 3 of 9 | 8 of 9 | +287 | +101 |
| Mine | High Elf Realms | 4 | 94 | 429 | 2.8 | 1.0 | 156 | 75 | +81 | 2 of 11 | 9 of 11 | - | +81 |
| Mine | Kingdom of Bretonnia | 1 | 795 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | - | +0 |
| Mine | Lizardmen | 1 | 55 | 1730 | 5.0 | 1.4 | 346 | 47 | +299 | 3 of 5 | 3 of 5 | +224 | +350 |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 2 of 4 | 0 of 3 | - | -17 |
| Mine | Skaven | 2 | 72 | 101 | 2.5 | 1.0 | 40 | 18 | +22 | 1 of 5 | 4 of 5 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 198 | 636 | 4.0 | 1.0 | 159 | 41 | +118 | 3 of 8 | 5 of 8 | - | +118 |
| Mine | Vampire Counts | 2 | 0 | 146 | 3.5 | 1.0 | 42 | 117 | -76 | 2 of 7 | 4 of 7 | - | -76 |
| Mine | Warriors of Chaos | 2 | 0 | 148 | 5.0 | 1.0 | 30 | 55 | -26 | 4 of 10 | 8 of 10 | - | -26 |
| **Mine** | all armies | 36 | 246 | 251 | 2.7 | 1.1 | 93 | 42 | +51 | 37 of 97 | 65 of 96 | +31 | +52 |
| Opponent | Empire of Man | 1 | 350 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 152 | 803 | 4.4 | 1.2 | 182 | 45 | +137 | 14 of 22 | 14 of 22 | +378 | +66 |
| Opponent | Lizardmen | 2 | 0 | 568 | 3.5 | 1.0 | 162 | 20 | +142 | 3 of 7 | 6 of 7 | - | +142 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 361 | 4.3 | 1.1 | 83 | 39 | +44 | 2 of 13 | 9 of 13 | +185 | +32 |
| Opponent | Skaven | 4 | 187 | 0 | 2.2 | 1.1 | 0 | 102 | -102 | 5 of 9 | 3 of 9 | -65 | -107 |
| Opponent | Tomb Kings of Khemri | 2 | 132 | 830 | 4.5 | 1.4 | 184 | 48 | +137 | 5 of 9 | 7 of 9 | +228 | +91 |
| Opponent | Vampire Counts | 6 | 28 | 635 | 4.5 | 1.1 | 141 | 9 | +132 | 16 of 27 | 20 of 27 | +117 | +135 |
| Opponent | Warriors of Chaos | 7 | 57 | 285 | 2.7 | 1.1 | 105 | 9 | +96 | 8 of 19 | 10 of 19 | +306 | +72 |
| Opponent | Wood Elf Realms | 6 | 32 | 526 | 5.0 | 1.2 | 105 | 34 | +71 | 8 of 30 | 23 of 30 | -20 | +90 |
| **Opponent** | all armies | 36 | 80 | 468 | 3.8 | 1.2 | 124 | 33 | +91 | 61 of 136 | 92 of 136 | +175 | +76 |

### Effective charges: ss-opp-06f55ce-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net +151) | 0 | 0 | 1 (net +0) | 0 | 4 (net +108) | 2 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 17 | 3 (net -22) | 2 (net -94) | 3 (net +135) | 4 (net -146) | 0 | 5 (net +53) | 0 | 18% (3 of 17) |
| Mine | Dwarfen Mountain Holds | 6 | 3 (net +148) | 0 | 2 (net +30) | 0 | 0 | 0 | 1 | 40% (2 of 5) |
| Mine | Empire of Man | 4 | 1 (net +176) | 0 | 1 (net +170) | 1 (net +122) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 9 | 1 (net +0) | 0 | 2 (net +144) | 1 (net +750) | 1 (net +0) | 4 (net +14) | 0 | 22% (2 of 9) |
| Mine | High Elf Realms | 11 | 1 (net +663) | 0 | 1 (net -482) | 2 (net +186) | 2 (net +92) | 3 (net +87) | 2 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Lizardmen | 5 | 2 (net +106) | 0 | 0 | 1 (net +235) | 0 | 2 (net +524) | 0 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 | 0% (0 of 1) |
| Mine | Skaven | 5 | 0 | 0 | 0 | 2 (net +35) | 0 | 3 (net +13) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +492) | 0 | 2 (net -78) | 2 (net +132) | 1 (net +60) | 1 (net +170) | 1 | 29% (2 of 7) |
| Mine | Vampire Counts | 7 | 4 (net -205) | 0 | 1 (net +0) | 0 | 0 | 2 (net +146) | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 10 | 1 (net -524) | 0 | 1 (net +0) | 1 (net +91) | 2 (net +102) | 4 (net +0) | 1 | 11% (1 of 9) |
| Opponent | High Elf Realms | 22 | 2 (net -127) | 0 | 6 (net +28) | 4 (net +372) | 2 (net +88) | 3 (net +345) | 5 | 35% (6 of 17) |
| Opponent | Lizardmen | 7 | 1 (net +0) | 0 | 0 | 3 (net +221) | 0 | 2 (net +236) | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 13 | 2 (net -175) | 0 | 0 | 1 (net +234) | 2 (net +206) | 2 (net +0) | 6 | 0% (0 of 7) |
| Opponent | Skaven | 9 | 3 (net -92) | 1 (net -41) | 2 (net -201) | 0 | 0 | 2 (net -56) | 1 | 25% (2 of 8) |
| Opponent | Tomb Kings of Khemri | 9 | 3 (net +30) | 0 | 3 (net +284) | 0 | 1 (net +112) | 1 (net +0) | 1 | 38% (3 of 8) |
| Opponent | Vampire Counts | 27 | 5 (net +159) | 1 (net +128) | 3 (net +9) | 8 (net +106) | 3 (net +35) | 3 (net +283) | 4 | 13% (3 of 23) |
| Opponent | Warriors of Chaos | 19 | 6 (net +28) | 1 (net +526) | 3 (net +148) | 5 (net +70) | 0 | 2 (net +0) | 2 | 18% (3 of 17) |
| Opponent | Wood Elf Realms | 30 | 6 (net +132) | 0 | 4 (net +142) | 4 (net +19) | 0 | 10 (net +43) | 6 | 17% (4 of 24) |

### Charged fights, damage counted: ss-opp-06f55ce-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 18 | 199 | 272 | +40 | 162 | 113 | +49 | +24.6 |
| Mine | 50-54% | 2 | 395 | 405 | -94 | 0 | 117 | -117 | -29.5 |
| Mine | Effective (55-75%) | 13 | 284 | 233 | +22 | 126 | 105 | +21 | +7.4 |
| Mine | 76-89% | 16 | 278 | 176 | +83 | 137 | 53 | +85 | +30.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 232 | 156 | +86 | 116 | 14 | +103 | +44.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 417 | 72 | +75 | 75 | 0 | +75 | +17.9 |
| Mine | No odds | 12 | 143 | 238 | -15 | 56 | 57 | -1 | -0.4 |
| Mine | All fights | 97 | 244 | 201 | +51 | 117 | 57 | +60 | +24.5 |
| Opponent | Long shot (under 50%) | 28 | 196 | 270 | +34 | 126 | 109 | +17 | +8.9 |
| Opponent | 50-54% | 3 | 552 | 189 | +204 | 239 | 33 | +206 | +37.4 |
| Opponent | Effective (55-75%) | 21 | 334 | 296 | +79 | 154 | 117 | +37 | +10.9 |
| Opponent | 76-89% | 25 | 287 | 163 | +146 | 156 | 2 | +154 | +53.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 273 | 185 | +107 | 153 | 41 | +112 | +40.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 484 | 88 | +101 | 106 | 16 | +90 | +18.5 |
| Opponent | No odds | 26 | 312 | 162 | +79 | 115 | 31 | +84 | +26.9 |
| Opponent | All fights | 136 | 295 | 206 | +91 | 140 | 56 | +84 | +28.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-opp-06f55ce-p4 | move | 328 | 69 (21%) | 43 (13%) | 45 (14%) | 214 (65%) |
| ss-opp-06f55ce-p4 | objective | 377 | 47 (12%) | 31 (8%) | 50 (13%) | 280 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

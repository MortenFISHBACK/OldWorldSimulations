# Doctrine scorecard: ss-mine-06f55ce-p1

### Scorecard: ss-mine-06f55ce-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 8 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 7 | 2 | 6 | 2 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 516 |
| L0135 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 234 |
| L0235 | 1 | 1 | Mine | no | 6 | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 5 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 8 | 3 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 1 | 0 | 0 | 532 |
| L0508 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 1408 |
| L0508 | 4 | 1 | Opponent | no | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 1 | 3 | 1 | 1 | 1 | 0 | 0 | 111 |
| L0717 | 3 | 1 | Mine | yes | 7 | 2 | 3 | 0 | 1 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 8 | 1 | 4 | 0 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 6 | 4 | 3 | 2 | 0 | 0 | 0 | 334 |
| L0823 | 1 | 1 | Mine | no | 4 | 2 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 2 | 0 | 0 | 130 |
| L0913 | 1 | 1 | Mine | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 785 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 479 |
| L0930 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | 4 | 3 | 5 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 598 |
| L1131 | 3 | 1 | Opponent | no | 7 | 3 | 2 | 1 | 2 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 2 | 0 | 0 | 0 | 205 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 2 | 1 | 0 | 0 | 156 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 9 | 3 | 3 | 1 | 2 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 7 | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | yes | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 2 | 2 | 0 | 0 | 0 | 274 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 7 | 0 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 1 | - | 0 | 3 | 1 | 0 | 0 | 612 |
| L2025 | 3 | 1 | Opponent | no | 15 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 9 | 3 | 1 | 3 | 0 | 0 | 0 | 145 |
| L2127 | 3 | 1 | Opponent | no | 4 | 4 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 2 | 0 | 0 | 0 | 0 | 661 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 2 | 3 | 2 | 2 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 2.9 | 2.7 | 2.2 | 1.3 | 0.2 | 0.0 | 0.0 | 300.9 |
| **Average** | | | Opponent | 18% | 3.6 | 2.6 | 2.6 | 1.7 | 0.3 | 0.0 | 0.0 | 200.8 |

### KPIs: ss-mine-06f55ce-p1

Rules off - Opponent only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 174) | 1% (2 of 172) | 16% (55 of 346) |
| Winner chose to follow up after the loser gave ground |  | 100% (41 of 41); on the table 100% | 94% (46 of 49); on the table 96% | 97% (87 of 90); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 95% (20 of 21); on the table 95% | 93% (14 of 15); on the table 93% | 94% (34 of 36); on the table 94% |
| Winner chose to pursue after the loser fled |  | 71% (22 of 31); on the table 74% | 79% (30 of 38); on the table 82% | 75% (52 of 69); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 89% (83 of 93); on the table 90% | 88% (90 of 102); on the table 90% | 89% (173 of 195); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 37% (123 of 330) | 32% (68 of 210) | 35% (191 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (117 of 242) | 41% (62 of 153) | 45% (179 of 395) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 79% (30 of 38) | 43% (26 of 60) | 57% (56 of 98) |
| Points that never fought | lower | 42% (30378 of 71484) | 38% (27653 of 71889) | 40% (58031 of 143373) |
|   infantry points that never fought | lower | 50% (8391 of 16863) | 65% (8637 of 13348) | 56% (17028 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (153 of 279) | 57% (168 of 295) | 56% (321 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.0 uses a game | 75% (15 of 20); 1.2 uses a game | 86% (36 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 75% (9 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29944 of 59666) | 52% (32784 of 62699) | 51% (62728 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (35%) | 1.4 (35%) | 3.4 (35%) |
| MARCHED: its unit marched | 0.9 (16%) | 0.6 (15%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.4 (8%) | 0.1 (1%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 0.9 (16%) | 0.6 (14%) | 1.5 (15%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.4 (11%) | 0.5 (5%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (1%) | 0.3 (3%) |
| GONE: slain | 1.1 (18%) | 0.6 (16%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (4%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.6 | 5.3 | 0.6 | 1.2 |
| not cast | 3.8 | 2.8 | 3.1 | 9.7 | 1.8 | 22.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (48%) | 0.3 (9%) | 3.4 (35%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.2 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (3%) | 0.4 (13%) | 1.5 (15%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.3 (11%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.0 (1%) | 0.3 (3%) | 0.1 (6%) | 0.6 (3%) |
| GONE: slain | 0.8 (21%) | 0.5 (19%) | 0.9 (29%) | 1.7 (17%) | 0.1 (6%) | 3.1 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (8%) | 0.2 (6%) | 0.2 (2%) | 0.0 (2%) | 1.1 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (7%) | 0.0 (1%) | 0.0 (0%) | 0.5 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (66%) | 0.2 (7%) | 0.9 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.8 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 70% (28 of 40) | 67% (14 of 21) | 69% (42 of 61) |
| the unit moved after it | 64% (18 of 28) | 79% (11 of 14) | 69% (29 of 42) |
| it charged on its next turn | 4% (1 of 28) | 7% (1 of 14) | 5% (2 of 42) |
| the enemy charged it first | 18% (5 of 28) | 14% (2 of 14) | 17% (7 of 42) |
| it fought by the end of its next turn | 11% (3 of 28) | 7% (1 of 14) | 10% (4 of 42) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (7 of 28) | 0% (0 of 14) | 17% (7 of 42) |
| none of these (no charge, no fight, no charge escaped) | 57% (16 of 28) | 79% (11 of 14) | 64% (27 of 42) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (601 of 910) | 59% (367 of 623) | 63% (968 of 1533) |
|   cavalry | 62% (45 of 72) | 62% (76 of 122) | 62% (121 of 194) |
|   character | 59% (70 of 118) | 35% (45 of 128) | 47% (115 of 246) |
|   chariot | 44% (41 of 94) | 67% (26 of 39) | 50% (67 of 133) |
|   infantry | 59% (183 of 312) | 60% (143 of 238) | 59% (326 of 550) |
|   monster | 70% (23 of 33) | 67% (18 of 27) | 68% (41 of 60) |
|   war machine | 85% (239 of 281) | 86% (59 of 69) | 85% (298 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (29%) | 1.5 (21%) | 4.0 (26%) |
| CHARGED: it charged | 0.7 (8%) | 1.5 (21%) | 2.2 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.3 (5%) | 0.9 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.7 (20%) | 1.6 (23%) | 3.3 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.5 (7%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (21%) | 1.1 (16%) | 2.9 (19%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.1 | 82% | 4.5 pts | 22 pts |
| character | 3.6 | 1.1 | 77% | 8.8 pts | 31 pts |
| chariot | 1.9 | 1.4 | 53% | 16.7 pts | 32 pts |
| infantry | 12.9 | 4.0 | 77% | 8.1 pts | 105 pts |
| monster | 1.3 | 0.4 | 83% | 2.5 pts | 3 pts |
| war machine | 8.3 | 5.9 | 64% | 23.2 pts | 192 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.4 | 4.6 |
| Charges that made contact a game | 2.9 | 3.6 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.82 declared, 0.55 contact (22 units) | 0.36 declared, 0.36 contact (14 units) | 0.64 declared, 0.47 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.25 contact (4 units) | 1.25 declared, 0.88 contact (8 units) | 1.00 declared, 0.67 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.37 contact (253 units) | 0.63 declared, 0.42 contact (285 units) | 0.55 declared, 0.39 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 46% (32 of 70) | 52% (11 of 21) | 50% (4 of 8) | 47% (47 of 99) |
| Character in a unit | 80% (28 of 35) | 65% (13 of 20) | 60% (3 of 5) | 73% (44 of 60) |
| Character on its own | 85% (44 of 52) | 62% (25 of 40) | 30% (18 of 61) | 57% (87 of 153) |
| Chariot | 62% (10 of 16) | 40% (4 of 10) | - | 54% (14 of 26) |
| Infantry | 53% (47 of 89) | 33% (12 of 36) | 50% (1 of 2) | 47% (60 of 127) |
| Monster | 50% (16 of 32) | 60% (6 of 10) | - | 52% (22 of 42) |
| Monstrous | 73% (8 of 11) | 79% (11 of 14) | - | 76% (19 of 25) |
| War Machines | 66% (27 of 41) | 100% (1 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 88% (15 of 17); on the table 88% | 41% (57 of 138) | 41% | 33% (11 of 33) | 100% (9 of 9); 5.2 uses a game | 100% (3 of 3); 1.7 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (9 of 9); on the table 100% | 54% (13 of 24) | 52% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (1 of 1); on the table 100% | - | 68% | 63% (26 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (12 of 15); on the table 80% | 47% (17 of 36) | 48% | 55% (35 of 64) | 0.0 uses a game | 100% (2 of 2); 1.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 88% (7 of 8); on the table 88% | 24% (26 of 108) | 33% | 52% (23 of 44) | 100% (12 of 12); 7.8 uses a game | 100% (1 of 1); 0.2 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 81% (13 of 16); on the table 88% | 30% (9 of 30) | 50% | 51% (25 of 49) | 100% (5 of 5); 3.3 uses a game | 33% (6 of 18); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (7 of 7); on the table 100% | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 50% (1 of 2); on the table 50% | - | 19% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 58% | 81% (17 of 21) | 33% (1 of 3); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 6% (2 of 36) | 9% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (9 of 9); on the table 100% | 53% (16 of 30) | 35% | 56% (19 of 34) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 81% (26 of 32); on the table 84% | 8% (1 of 12) | 39% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (25 of 28); on the table 93% | 43% (23 of 54) | 44% | 66% (33 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 93% (14 of 15); on the table 93% | 47% (14 of 30) | 29% | 62% (46 of 74) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 92% (22 of 24); on the table 92% | 37% (11 of 30) | 32% | 56% (37 of 66) | 33% (2 of 6); 0.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (ss-mine-06f55ce-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (36) | 44% (29) | 47% (65) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.56 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.17 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.25 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.64 | 1.03 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.22 | 0.97 | 2.19 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.72 | 5.22 | 10.94 |

### Quality by phase: ss-mine-06f55ce-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 57% (69 of 122) | 50% (79 of 159) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (215 of 452) | 50% (115 of 231) |
| Strategy | Close-in objectives charged next turn | 11% (17 of 153) | 15% (37 of 252) |
| Strategy | Support requests answered (helper made contact too) | 42% (5 of 12) | 50% (16 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 30% (6 of 20) | 25% (3 of 12) |
| Strategy | Joined characters whose unit fought | 35% (18 of 52) | 50% (19 of 38) |
| Strategy | Lone characters that fought | 73% (69 of 94) | 71% (70 of 98) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 300.9 | 200.8 |
| Movement | Fights charged into per game | 2.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 22 of 87, net +47 | 13 of 91, net -31 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 87, net +164 | 23 of 91, net +90 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 87, net -43 | 6 of 91, net +166 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 87, net +92 | 18 of 91, net +169 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (180 of 392) | 41% (140 of 343) |
| Shooting | Points destroyed by shooting units | 72.9 | 37.9 |
| Shooting | War machine shots | 6.6 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (115 of 239) | 46% (27 of 59) |
| Shooting | Points destroyed by war machines | 70.8 | 15.3 |
| Magic | Magic missiles cast | 2.0 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (20 of 71) | 29% (12 of 42) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.0 |
| Magic | Wounds caused by other spells | 1.1 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 80.6 | 37.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.6 / 0.3 / 0.2 | 1.7 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 320.4 | 299.3 |
| Combat | Points run down | 59.8 | 168.4 |
| Combat | Net points per charged fight, damage counted | +68 | +102 |
| Combat | Net per 100 charger points, damage counted | +27.2 | +36.3 |
| Combat | First round won (charged fights) | 66% | 78% |
| Combat | Net points per charged fight | +74 | +102 |
| Combat | Net points per supported fight / lone fight | +87 / +72 | +164 / +86 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 96 | 53 of 106 |
| Game | Points lost | 705.2 | 730.3 |
| Game | VP from objectives | 593.9 | 661.1 |
| Game | Lone holders (player turns) | 2.9 | 3.6 |

- Mine won / drew / lost: 15 / 4 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -30 VP
- The side that went first won 13 of 32 games with a winner
- Points traded per game (both sides' losses): 1436
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-mine-06f55ce-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 3.5 |
| ADVANCE WORTH | 5.9 | -187.8 | 109.4 | 106.0 | 4.9 | -168.5 | 160.3 | 55.6 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 6.1 | 0.4 | +0.0 | 0.0 | 5.3 |
| BACKUP TARGETS | 0.4 | +1.8 | 0.0 | 0.0 | 0.6 | +3.2 | 0.0 | 14.9 |
| BEST FACING | 0.5 | +16.4 | 0.0 | 5.2 | 0.2 | +2.8 | 0.0 | 3.5 |
| BEST FIRST | 1.2 | +56.8 | 12.3 | 36.3 | 1.1 | +55.8 | 12.9 | 13.1 |
| BEST OVERALL | 0.3 | +14.8 | 0.0 | 5.2 | 0.2 | +16.7 | 0.0 | 6.9 |
| BEST PREY | 0.6 | +26.2 | 20.6 | 4.7 | 0.8 | +45.4 | 10.4 | 28.8 |
| BEST PRIZE | 0.1 | +2.5 | 2.6 | 0.0 | 0.1 | -2.2 | 3.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -0.6 | 0.0 | 0.0 | 0.2 | -2.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | +2.8 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -30.1 | 18.0 | 11.7 | 0.4 | -27.6 | 48.3 | 16.2 |
| BOMBING RUN | 0.1 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 100.4 | 20.0 | 0.2 | +0.0 | 16.5 | 2.6 |
| CANNON PLANNED TARGET | 5.1 | +144.6 | 309.9 | 62.9 | 1.4 | +25.0 | 53.9 | 15.8 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 2.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.4 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 12.8 | 0.0 | 0.1 | +0.0 | 9.6 | 11.8 |
| CAST JOB | 1.2 | +41.0 | 66.0 | 0.0 | 0.4 | +4.0 | 3.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +59.2 | 24.9 | 10.9 | 0.4 | +10.5 | 13.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 25.0 | 0.4 | +0.0 | 0.0 | 20.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +73.7 | 0.0 | 28.4 | 1.9 | +89.5 | 0.0 | 45.4 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 9.4 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 190.6 | 66.1 | 2.6 | +0.0 | 245.5 | 99.1 |
| CHARGE NOW WEIGHED | 0.2 | -19.8 | 14.9 | 8.0 | 0.6 | -20.7 | 32.4 | 15.9 |
| CHARGER SLAIN LOST | 0.5 | -18.8 | 27.0 | 51.9 | 0.6 | -17.6 | 56.7 | 21.1 |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.2 | 0.0 | 0.0 | 0.1 | -2.1 | 16.1 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 13.9 | 0.0 | 0.1 | +0.0 | 0.0 | 1.6 |
| CHEAPEST HOLDER | 1.5 | -53.5 | 38.3 | 22.4 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 16.4 | 16.9 | 0.2 | +0.0 | 16.9 | 13.5 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 2.1 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +59.3 | 11.3 | 24.6 | 0.4 | +85.1 | 22.9 | 28.3 |
| COVER ONCE | 8.1 | -698.9 | 0.0 | 209.7 | 5.8 | -437.6 | 0.0 | 131.1 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 52.9 | 2.1 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.4 | 6.7 | 0.0 | 0.1 | +5.7 | 6.8 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +111.5 | 0.0 | 55.6 | 1.0 | +40.5 | 0.0 | 29.3 |
| FALLBACK BY WORTH | 2.6 | +20.5 | 0.0 | 30.9 | 5.1 | +34.5 | 0.0 | 71.4 |
| FALLS SHORT | 5.1 | +87.8 | 0.0 | 65.4 | - | - | - | - |
| FIGHT LIFT | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.6 | 8.2 | 3.2 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 150.9 | 4.5 | +0.0 | 0.0 | 98.1 |
| FOCUS FIRE | 0.1 | +2.0 | 3.5 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +133.3 | 0.0 | 18.4 | 0.7 | +90.3 | 0.0 | 42.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.6 | 0.0 | 4.8 | 0.2 | +8.3 | 0.0 | 21.5 |
| GIVES UP | 0.1 | -0.3 | 10.9 | 4.0 | 0.1 | -0.9 | 2.3 | 12.3 |
| GIVES UP ITS SCREEN | 0.1 | -0.1 | 3.1 | 1.5 | 0.1 | -1.1 | 0.0 | 3.6 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 34.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 11.4 | 21.4 | 0.4 | +0.0 | 21.1 | 7.4 |
| HILL BY ITS CHANCE | 0.2 | -28.2 | 0.0 | 8.0 | 0.1 | -10.0 | 0.0 | 1.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.0 | -118.8 | 361.4 | 186.9 | 9.2 | -180.3 | 468.5 | 214.8 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +7.1 | 9.2 | 6.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 9.2 | 0.0 |
| HUNT IN PAIRS | 0.4 | +23.8 | 0.0 | 5.4 | 0.5 | +39.4 | 0.0 | 11.4 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +0.0 | 13.8 | 3.2 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +57.8 | 9.2 | 6.1 |
| IDLE COST | 3.9 | -50.0 | 0.0 | 69.7 | 18.1 | -270.5 | 0.0 | 208.0 |
| INVITES THE FIGHT | 1.2 | +9.0 | 28.3 | 41.3 | 1.1 | +5.5 | 46.8 | 13.9 |
| JOINT CHARGE PLAN | 0.1 | +9.4 | 0.0 | 4.2 | 0.3 | +21.3 | 9.5 | 5.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.6 | 6.2 | 0.0 | 0.2 | -13.6 | 41.9 | 18.1 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +34.2 | 75.8 | 49.2 | 2.1 | +63.3 | 125.1 | 57.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +60.9 | 75.3 | 38.1 | 1.6 | +95.5 | 136.1 | 36.0 |
| KILLS COUNT NEXT TURN | 4.3 | +162.1 | 104.7 | 104.2 | 6.9 | +240.4 | 220.4 | 156.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +9.6 | 2.1 | 0.0 | 0.3 | +4.9 | 21.7 | 11.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 5.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -0.9 | 26.9 | 4.2 | 0.4 | -0.9 | 18.6 | 4.3 |
| LOST CHARGE | 2.8 | -39.2 | 73.0 | 80.6 | 2.5 | -39.4 | 55.8 | 66.9 |
| LURE BY WHAT IT DRAWS | 0.3 | -29.3 | 0.0 | 7.0 | 0.2 | -26.5 | 0.0 | 14.4 |
| MAKE SURE TOGETHER | 0.5 | +18.2 | 19.6 | 14.6 | 1.2 | +112.5 | 19.0 | 47.5 |
| MANOEUVRE | 0.1 | +0.4 | 0.0 | 0.0 | 0.2 | +3.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +17.2 | 0.0 | 15.7 | 0.3 | +8.1 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +13.0 | 7.2 | 0.0 | 0.3 | +29.7 | 0.0 | 1.7 |
| MARCH OVER CASTS | 0.6 | +33.6 | 0.0 | 16.2 | 0.3 | +14.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +83.8 | 0.0 | 110.5 | 7.3 | +92.0 | 0.0 | 117.6 |
| MISSILES IN THE MOVE | 4.5 | +173.4 | 0.0 | 59.9 | 3.8 | +45.8 | 0.0 | 35.5 |
| MISSILES NEXT TURN | 5.1 | +126.9 | 0.0 | 110.5 | 4.3 | +38.7 | 0.0 | 35.5 |
| MODEL FACING | 0.2 | +56.4 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +15.9 | 0.0 | 5.9 | 0.3 | +8.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -50.7 | 0.0 | 38.2 | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 1.8 | 0.2 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 2.8 | +184.2 | 83.5 | 93.6 | 5.5 | +380.5 | 185.4 | 146.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.9 | +559.3 | 0.0 | 168.1 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| NO FORCED ADVANCE | 1.8 | +0.0 | 0.0 | 11.8 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.2 | 0.0 | 2.1 |
| NOT NEEDED | 0.2 | -15.9 | 13.4 | 3.1 | 0.2 | -12.8 | 27.7 | 7.9 |
| NOT TURNED | 5.7 | +82.7 | 0.0 | 138.6 | 5.2 | +59.6 | 0.0 | 113.8 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 31.0 | 0.4 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 14.0 | -512.1 | 3.4 | 302.2 | 17.0 | -831.5 | 0.0 | 241.9 |
| ONE FIGHT FORMULA | 7.3 | -131.2 | 20.4 | 193.5 | 8.7 | -175.0 | 38.3 | 190.8 |
| ONE OBJECTIVE FORMULA | 3.2 | -102.5 | 0.0 | 76.3 | 2.0 | -65.3 | 0.0 | 40.5 |
| OPENS A LANE | 0.3 | +1.0 | 26.0 | 0.0 | 0.1 | +1.4 | 4.7 | 2.1 |
| OPENS UP | 0.2 | +17.1 | 13.4 | 0.0 | 0.2 | +10.3 | 6.4 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +14.7 | 37.9 | 42.9 | 0.6 | +15.4 | 35.4 | 17.3 |
| PATHS CROSS | 1.5 | +54.9 | 0.0 | 64.9 | 2.2 | +138.5 | 0.0 | 24.4 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.5 | 0.0 | 1.4 | 0.1 | -0.3 | 0.0 | 0.0 |
| PLAN RESULT | 36.9 | +1273.6 | 1116.5 | 877.9 | 39.0 | +1107.5 | 1249.8 | 888.1 |
| PURSUES BIG PREY | 0.1 | -0.4 | 0.0 | 11.9 | 0.2 | -41.9 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.6 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 2.3 |
| RANDOM MOVE BY FIGURES | 1.1 | +22.7 | 0.0 | 15.3 | 1.7 | +20.7 | 0.0 | 58.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -10.7 | 1.1 | 0.0 | 0.3 | -14.8 | 3.4 | 14.6 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -16.1 | 0.0 | 19.9 | 1.1 | -23.2 | 0.0 | 23.7 |
| REDIRECT COUNTER | 2.1 | +115.7 | 0.0 | 41.7 | 3.8 | +273.3 | 0.0 | 58.1 |
| REDIRECT WEIGHED | 0.2 | +3.5 | 5.2 | 6.5 | 0.4 | +5.1 | 9.9 | 6.6 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 25.2 | 0.5 | +0.0 | 0.0 | 27.2 |
| RESERVE FALL BACK | 0.5 | +13.5 | 0.0 | 5.8 | 0.9 | +33.2 | 0.0 | 8.5 |
| RESTRAINS TO SHOOT | 0.1 | +5.1 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 5.6 |
| RISK BY ARC | 2.2 | +64.2 | 168.5 | 103.4 | 2.7 | +50.9 | 267.2 | 92.2 |
| RISK ONCE | 2.7 | +66.7 | 14.2 | 99.5 | 5.5 | +315.0 | 63.0 | 188.1 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.2 | +60.9 | 0.0 | 35.4 | 1.0 | +55.5 | 0.0 | 33.8 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -11.0 | 0.0 | 0.9 | 0.7 | -37.8 | 0.0 | 7.3 |
| SEARCH SPOT | 1.9 | +73.8 | 0.0 | 25.6 | 2.7 | +115.4 | 0.0 | 23.9 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.7 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.2 | +32.6 | 0.0 | 18.1 | 0.1 | +2.2 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.8 | +72.4 | 19.6 | 20.2 | 2.2 | +225.2 | 53.4 | 61.5 |
| SET-UP ANY TARGET | 0.3 | +60.4 | 3.6 | 5.3 | 0.1 | +12.9 | 22.9 | 20.7 |
| SET-UP MISSED | - | - | - | - | 0.1 | +8.4 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +67.4 | 83.8 | 30.0 | 1.1 | +34.0 | 51.0 | 6.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 6.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 170.6 | 24.8 | 0.1 | +0.0 | 35.7 | 2.6 |
| SHOTS IN THE MOVE | 15.5 | +601.3 | 0.0 | 232.9 | 9.0 | +238.7 | 0.0 | 102.6 |
| SPELL SETS UP CHARGE | 0.3 | +60.4 | 3.6 | 5.3 | 0.2 | +59.6 | 22.9 | 20.7 |
| SPELL WORTH | 1.1 | +20.1 | 48.8 | 66.8 | 1.8 | +49.3 | 56.1 | 69.1 |
| SPELLS IN THE FIGHT | 0.4 | -0.1 | 70.5 | 39.3 | 0.6 | -8.5 | 60.4 | 29.1 |
| STABLE ROLE | 11.5 | +0.0 | 427.8 | 181.1 | 10.9 | +0.0 | 321.8 | 229.2 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 10.9 | 0.0 | +1.0 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.2 | +15.8 | 0.0 | 16.4 | 0.4 | +19.0 | 0.0 | 7.1 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 1.2 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 5.2 | -55.2 | 307.7 | 120.5 | 7.9 | -59.3 | 383.0 | 104.1 |
| SUPPORTS | 3.8 | +58.9 | 195.4 | 55.6 | 5.6 | +59.3 | 197.9 | 44.0 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -1.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | -6.4 | 24.7 | 7.8 | 0.9 | +5.4 | 31.1 | 31.1 |
| THROUGH LINE OF FIRE | 0.3 | +13.6 | 0.0 | 0.0 | 0.3 | +14.8 | 0.0 | 13.9 |
| TIME ON OUR SIDE | 18.9 | +337.8 | 0.0 | 297.0 | - | - | - | - |
| TURN WORTH | 0.2 | -10.3 | 5.5 | 3.1 | 0.2 | -14.4 | 16.9 | 5.1 |
| TWO OR MORE ARRIVE | 0.2 | +0.6 | 0.0 | 4.6 | 0.6 | +5.5 | 53.4 | 13.1 |
| WAIT AFTER COSTS | 6.2 | -276.1 | 179.1 | 160.4 | 8.6 | -431.7 | 300.0 | 183.2 |
| WALKS TO THE FIGHT | 1.7 | +14.9 | 40.1 | 25.5 | 0.9 | +7.2 | 38.2 | 8.6 |
| WAR ENGINE CHARGES | - | - | - | - | 0.0 | +0.5 | 2.4 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 42.1 | 12.1 | 0.4 | +0.0 | 1.4 | 16.4 |
| WEARS DOWN | 1.2 | +72.0 | 124.5 | 46.1 | 1.3 | +47.6 | 171.8 | 48.9 |
| WHO HITS BACK | 0.1 | +7.5 | 0.0 | 0.0 | 0.3 | +14.0 | 0.0 | 13.4 |
| WHOLE FIGHT | 0.1 | +13.1 | 48.8 | 0.0 | 0.3 | +19.7 | 58.0 | 1.4 |
| WHOLE FIGHT GAIN | 0.2 | +26.0 | 14.1 | 8.0 | 0.7 | +84.0 | 100.0 | 20.2 |
| WIDER SPREAD | 2.2 | -6.9 | 191.7 | 92.9 | 2.9 | -3.7 | 272.7 | 73.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 5.4 | - | - | - | - |

### Rule changes: ss-mine-06f55ce-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1115 | 1115 | 1115 | 30.97 | -48368 | -43.4 |
| SEARCH SPOT | 166 | 166 | 161 | 4.47 | +6812 | +42.3 |
| MOVE TO CHARGE | 301 | 301 | 148 | 4.11 | +6935 | +46.9 |
| SUPPORTS | 335 | 335 | 143 | 3.97 | +1360 | +9.5 |
| KILLS COUNT NEXT TURN | 401 | 401 | 133 | 3.69 | +4026 | +30.3 |
| PATHS CROSS | 133 | 133 | 133 | 3.69 | +6961 | +52.3 |
| TIME ON OUR SIDE | 682 | 455 | 117 | 3.25 | +256 | +2.2 |
| NEARER NOT NEEDED | 391 | 273 | 112 | 3.11 | +2023 | +18.1 |
| WAIT AFTER COSTS | 531 | 531 | 107 | 2.97 | +2089 | +19.5 |
| FACES THE THREAT | 96 | 96 | 96 | 2.67 | +5470 | +57.0 |
| RISK ONCE | 294 | 222 | 87 | 2.42 | +2289 | +26.3 |
| SHOTS IN THE MOVE | 884 | 589 | 84 | 2.33 | +4178 | +49.7 |
| BEST FIRST | 80 | 80 | 80 | 2.22 | +4054 | +50.7 |
| SAFER THAN THE JOB | 79 | 79 | 79 | 2.19 | +4190 | +53.0 |
| COVER ONCE | 501 | 267 | 73 | 2.03 | +1133 | +15.5 |
| ADVANCE WORTH | 389 | 389 | 65 | 1.81 | +1524 | +23.4 |
| CHAFF IN THE MOVE | 114 | 110 | 64 | 1.78 | +2116 | +33.1 |
| NO FORCED ADVANCE | 64 | 64 | 64 | 1.78 | +804 | +12.6 |
| FOLLOW UP WEIGHED | 60 | 60 | 60 | 1.67 | +8050 | +134.2 |
| REDIRECT COUNTER | 210 | 107 | 60 | 1.67 | +4884 | +81.4 |
| SET UP TOGETHER | 109 | 99 | 59 | 1.64 | +4764 | +80.7 |
| ONE FIGHT FORMULA | 576 | 329 | 58 | 1.61 | +310 | +5.3 |
| ARTILLERY RE-ROLL WEIGHED | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 98 | 98 | 56 | 1.56 | +1564 | +27.9 |
| FALLBACK BY WORTH | 277 | 277 | 54 | 1.50 | +1979 | +36.6 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +1680 | +32.9 |
| CANNON PLANNED TARGET | 233 | 233 | 49 | 1.36 | -461 | -9.4 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MISSILES IN THE MOVE | 297 | 181 | 39 | 1.08 | +559 | +14.3 |
| SHOOTS FROM THE BEST SPOT | 98 | 98 | 38 | 1.06 | +1075 | +28.3 |
| HARD STAY DROPPED | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 176 | 176 | 35 | 0.97 | -2107 | -60.2 |
| INVITES THE FIGHT | 83 | 83 | 35 | 0.97 | +188 | +5.4 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| MAX FOR POSITIONING | 441 | 265 | 34 | 0.94 | +154 | +4.5 |
| WALKS TO THE FIGHT | 91 | 91 | 34 | 0.94 | +226 | +6.7 |
| RISK BY ARC | 175 | 172 | 33 | 0.92 | +1044 | +31.6 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 32 | 31 | 31 | 0.86 | +1318 | +42.5 |
| CHARGE NOW WEIGHED | 30 | 30 | 30 | 0.83 | +1397 | +46.6 |
| HONEST WORTH | 583 | 581 | 28 | 0.78 | +194 | +6.9 |
| IDLE COST | 793 | 450 | 28 | 0.78 | +177 | +6.3 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +693 | +27.7 |
| CAST JOB | 57 | 57 | 25 | 0.69 | +458 | +18.3 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +859 | +35.8 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| FALLS SHORT | 185 | 109 | 23 | 0.64 | +69 | +3.0 |
| KILLS COUNT | 102 | 102 | 23 | 0.64 | +857 | +37.3 |
| MAKE SURE TOGETHER | 63 | 39 | 23 | 0.64 | +1701 | +74.0 |
| STOPS SHORT OF THE FLANK | 23 | 23 | 23 | 0.64 | +1252 | +54.5 |
| CASTING BLOCK | 30 | 30 | 21 | 0.58 | +1158 | +55.1 |
| KEEPS ITS TARGET | 117 | 117 | 21 | 0.58 | +353 | +16.8 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +1021 | +48.6 |
| BIG CHARACTER SAFETY | 20 | 20 | 20 | 0.56 | -100 | -5.0 |
| WHOLE FIGHT GAIN | 35 | 35 | 20 | 0.56 | +1663 | +83.2 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +711 | +37.4 |
| BEST OVERALL | 18 | 18 | 18 | 0.50 | +1135 | +63.1 |
| BEST PREY | 50 | 50 | 18 | 0.50 | +696 | +38.7 |
| LOST CHARGE | 190 | 190 | 17 | 0.47 | +747 | +44.0 |
| WAR ENGINE JOBS | 36 | 36 | 17 | 0.47 | -1041 | -61.2 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +220 | +13.8 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +681 | +45.4 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +596 | +39.7 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BLOCKED WHEEL | 13 | 13 | 13 | 0.36 | +83 | +6.4 |
| PURSUES BIG PREY | 13 | 13 | 13 | 0.36 | -1522 | -117.1 |
| REFUSING RETIRES | 29 | 29 | 13 | 0.36 | -4 | -0.3 |
| WEARS DOWN | 91 | 89 | 12 | 0.33 | +778 | +64.8 |
| MISSILES NEXT TURN | 339 | 201 | 11 | 0.31 | +38 | +3.4 |
| HUNT IN PAIRS | 34 | 17 | 9 | 0.25 | +594 | +66.0 |
| OPENS UP | 13 | 13 | 9 | 0.25 | +410 | +45.6 |
| SURE REACH TOGETHER | 59 | 45 | 9 | 0.25 | +68 | +7.5 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -4 | -0.5 |
| MANOEUVRE | 10 | 10 | 8 | 0.22 | +135 | +16.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +2030 | +290.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| ONE OBJECTIVE FORMULA | 185 | 85 | 7 | 0.19 | +179 | +25.6 |
| SUPPORT NARROWED | 474 | 474 | 7 | 0.19 | -100 | -14.3 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -142 | -23.7 |
| OVERRUNS AWAY | 41 | 40 | 6 | 0.17 | +327 | +54.6 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +268 | +44.8 |
| CONTINUE AHEAD WEIGHED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +57 | +11.4 |
| WHOLE FIGHT | 16 | 16 | 5 | 0.14 | +384 | +76.8 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -30 | -7.5 |
| DEFENSIVE ARMY | 10 | 10 | 3 | 0.08 | -84 | -28.1 |
| EDGE GIVE GROUND | 5 | 5 | 3 | 0.08 | +120 | +40.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +146 | +48.8 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +105 | +34.9 |
| SPELLS IN THE FIGHT | 38 | 37 | 3 | 0.08 | +9 | +3.2 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -66 | -22.2 |
| WIDER SPREAD | 184 | 181 | 3 | 0.08 | +27 | +8.9 |
| BACKUP TARGETS | 36 | 16 | 2 | 0.06 | +1 | +0.7 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +296 | +148.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +85 | +42.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +23 | +11.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +73 | +36.7 |
| HUNT ADVANCE | 5 | 5 | 2 | 0.06 | +44 | +22.1 |
| JOINT CHARGE PLAN | 16 | 16 | 2 | 0.06 | +152 | +76.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PURSUES ON | 2 | 2 | 2 | 0.06 | +23 | +11.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +5 | +2.3 |
| BLOWS WHERE AIMED | 24 | 23 | 1 | 0.03 | +18 | +18.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | -3 | -2.7 |
| LONG SHOT | 31 | 31 | 1 | 0.03 | +1 | +1.4 |
| MOVE SPELL IN RANGE | 8 | 6 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +2 | +1.9 |
| OPENS A LANE | 13 | 5 | 1 | 0.03 | +14 | +13.5 |
| REDIRECT BY WHAT IT STOPS | 68 | 68 | 1 | 0.03 | +32 | +32.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -13 | -13.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +12 | +12.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 31 | 28 | 1 | 0.03 | +2 | +1.8 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +13 | +12.6 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -113 | -113.2 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 41 | 41 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 360 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 6 | 6 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 26 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 11 | 11 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 10 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 19 | 19 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 394 | 394 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2732 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 31 | 31 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 106 | not checked | - | - | - | - |
| STABLE ROLE | 805 | 804 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: ss-mine-06f55ce-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.61 | 15.64 | 44.0 |
| TURN GATE | gate | 0.72 | 0.42 | 36.2 |
| FALLBACK | gate | 0.33 | 0.69 | 40.8 |
| CHARGE NOW FIRST | rule | 0.56 | 0.42 | 60.2 |
| WAR ENGINE JOBS | rule | 0.31 | 0.14 | 65.0 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.06 | 55.7 |
| PURSUES BIG PREY | rule | 0.08 | 0.25 | 140.3 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.17 | 10.9 |
| NEARER NOT NEEDED | rule | 0.19 | - | 45.7 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 14.3 |
| PATHS CROSS | rule | 0.17 | - | 21.1 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 2.3 |
| BEST PRIZE | rule | 0.06 | 0.08 | 28.4 |
| FACES THE THREAT | rule | 0.08 | 0.06 | 11.1 |
| SAFER THAN THE JOB | rule | 0.06 | 0.08 | 11.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.08 | 34.3 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 7.5 |
| SUPPORT REQUEST | gate | 0.08 | 0.03 | 88.4 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 8.9 |
| DEFENSIVE ARMY | rule | 0.08 | - | 28.1 |
| NO REASON | gate | 0.08 | - | 17.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.06 | 22.2 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 1.6 |
| MOVE AND CAST | rule | 0.06 | - | 17.7 |
| REDIRECT WEIGHED | rule | 0.06 | - | 31.0 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.7 |
| RULE SWITCHED OFF | gate | - | 0.06 | 8.7 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 9.8 |
| BLOCKED WHEEL | rule | 0.03 | - | 24.0 |
| CHAFF PASSED | rule | - | 0.03 | 3.1 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 2.7 |
| SAFE SURE CHARGE | rule | - | 0.03 | 13.3 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 9.1 |
| WHO HITS BACK | rule | - | 0.03 | 2.9 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 113.2 |

### Plans: ss-mine-06f55ce-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 7.5 | 15% | 186 | 162 | 87% |
| Mine | charge | 2.8 | 66% | 264 | 253 | 96% |
| Mine | close in | 4.2 | 27% | 225 | 164 | 73% |
| Mine | hold | 6.5 | 29% | 343 | 0 | 0% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | shoot | 10.2 | 57% | 353 | 695 | 197% |
| Mine | support | 5.0 | 88% | 65 | 0 | 0% |
| Opponent | advance | 10.2 | 16% | 133 | 223 | 167% |
| Opponent | charge | 3.9 | 62% | 349 | 445 | 128% |
| Opponent | close in | 7.0 | 24% | 474 | 162 | 34% |
| Opponent | hold | 4.5 | 46% | 297 | 0 | 0% |
| Opponent | join | 1.3 | 96% | 61 | 0 | 0% |
| Opponent | shoot | 5.0 | 60% | 86 | 277 | 322% |
| Opponent | support | 7.1 | 93% | 63 | 0 | 0% |

### Packages: hunt the guns, ss-mine-06f55ce-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Opponent | 0.2 | 6 | 1 | 0% | 0% | 0% | - | 365 | 0 | 0% | 83 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 131 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 246 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.6 | 5 | 1 | 0% | 0% | 0% | - | 374 | 0 | 0% | 106 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 24 |

### Battle groups: ss-mine-06f55ce-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 40% | 47% | 7% | 0% | 14% | 0% | 14% | 64% | 7% |
| Opponent | REDIRECT COUNTER | 3.8 | 21% | 79% | 18% | 40% | 30% | 4% | 4% | 57% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-mine-06f55ce-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 19 | 67% | 6.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Mine | Chaff | 37 | 33 (37) | 19 | 14 | 59 | 41% | 2.5 | 28 (16) | 5 (9) | 59 (12) | 51 (24) | 6 (13) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 34 | 15% | 2.4 | 72 (34) | 51 (55) | 35 (12) | 59 (58) | 55 (43) |
| Mine | Clean-up | 24 | 41 (24) | 14 | 27 | 14 | 42% | 3.0 | 45 (9) | 46 (11) | 0 (4) | 63 (14) | 15 (10) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 47 | 0% | 1.8 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 41 | 29 (41) | 10 | 20 | 51 | 22% | 2.7 | 24 (18) | 37 (12) | 32 (11) | 35 (28) | 19 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 40 (58) | 25 | 15 | 47 | 16% | 2.5 | 41 (10) | 38 (38) | 44 (10) | 41 (34) | 38 (24) |
| Mine | Holder | 25 | 74 (25) | 5 | 69 | 36 | 64% | 2.0 | 159 (6) | 40 (12) | 68 (5) | 100 (10) | 63 (13) |
| Mine | Shooter | 44 | 89 (44) | 24 | 65 | 33 | 7% | 1.6 | 51 (5) | 95 (32) | 102 (7) | 121 (25) | 49 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 20% | 2.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | War machine | 56 | 46 (56) | 46 | 0 | 32 | 7% | 1.2 | 63 (13) | 47 (37) | 0 (6) | 26 (11) | 51 (45) |
| Mine | Wizard | 23 | 24 (23) | 24 | 0 | 48 | 17% | 2.3 | 48 (6) | 0 (10) | 72 (3) | 109 (4) | 3 (15) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 66 (66) | 20 | 46 | 47 | 45% | 2.8 | 92 (28) | 26 (16) | 66 (22) | 71 (48) | 53 (18) |
| Opponent | Character | 114 | 47 (114) | 46 | 1 | 36 | 22% | 2.4 | 58 (42) | 51 (52) | 0 (6) | 55 (67) | 47 (33) |
| Opponent | Clean-up | 16 | 36 (16) | 35 | 1 | 54 | 50% | 3.4 | 73 (5) | 16 (8) | 13 (3) | 69 (8) | 11 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 59 (58) | 36 | 23 | 42 | 33% | 2.6 | 78 (25) | 18 (19) | 69 (14) | 49 (42) | 85 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 73 | 30% | 1.6 | 0 (3) | 0 (3) | 0 (4) | 0 (9) | 0 (1) |
| Opponent | Hammer | 65 | 28 (65) | 25 | 3 | 54 | 20% | 2.6 | 52 (16) | 20 (42) | 33 (7) | 30 (40) | 24 (25) |
| Opponent | Holder | 40 | 83 (40) | 14 | 70 | 17 | 40% | 3.2 | 26 (12) | 126 (20) | 52 (8) | 119 (20) | 49 (20) |
| Opponent | Shooter | 30 | 82 (30) | 26 | 55 | 28 | 0% | 1.5 | 96 (7) | 84 (18) | 52 (5) | 80 (16) | 84 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 38 (13) | 38 | 0 | 35 | 0% | 1.1 | 12 (5) | 51 (5) | 57 (3) | 58 (3) | 32 (10) |
| Opponent | Wizard | 22 | 5 (22) | 5 | 0 | 24 | 9% | 2.2 | 4 (13) | 7 (4) | 0 (4) | 6 (12) | 0 (9) |

### Charged fights: ss-mine-06f55ce-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 179 | 123 | 1.8 | 1.2 | 69 | 12 | +57 | 0 of 9 | 7 of 9 | +134 | +35 |
| Mine | Chaos Dwarfs | 3 | 128 | 697 | 3.7 | 1.0 | 190 | 0 | +190 | 6 of 11 | 8 of 10 | - | +190 |
| Mine | Dwarfen Mountain Holds | 4 | 405 | 43 | 0.8 | 1.3 | 57 | 0 | +57 | 1 of 3 | 3 of 3 | +0 | +86 |
| Mine | Empire of Man | 5 | 419 | 94 | 2.0 | 1.0 | 47 | 57 | -10 | 2 of 10 | 6 of 10 | - | -10 |
| Mine | Grand Cathay | 4 | 389 | 342 | 2.5 | 1.2 | 137 | 50 | +87 | 6 of 10 | 5 of 10 | +416 | +5 |
| Mine | High Elf Realms | 4 | 243 | 499 | 3.5 | 1.1 | 143 | 36 | +107 | 6 of 14 | 8 of 14 | +0 | +115 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 522 | 4.0 | 1.2 | 130 | 0 | +130 | 3 of 4 | 2 of 4 | +0 | +174 |
| Mine | Lizardmen | 1 | 0 | 126 | 3.0 | 1.0 | 42 | 47 | -5 | 1 of 3 | 2 of 3 | - | -5 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 2.0 | 1.0 | 33 | 17 | +16 | 1 of 2 | 0 of 2 | - | +16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 55 | -55 | 2 of 2 | 0 of 2 | - | -55 |
| Mine | Skaven | 2 | 130 | 150 | 2.0 | 1.2 | 75 | 0 | +75 | 1 of 4 | 4 of 4 | +0 | +100 |
| Mine | Tomb Kings of Khemri | 2 | 114 | 1027 | 7.0 | 1.0 | 147 | 32 | +115 | 2 of 14 | 11 of 14 | - | +115 |
| Mine | Vampire Counts | 2 | 0 | 220 | 4.0 | 1.2 | 55 | 91 | -36 | 1 of 8 | 6 of 8 | -116 | -9 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 36 | 224 | 284 | 2.7 | 1.1 | 106 | 33 | +74 | 33 of 96 | 63 of 95 | +87 | +72 |
| Opponent | Beastmen Brayherds | 1 | 55 | 485 | 3.0 | 1.0 | 162 | 88 | +73 | 3 of 3 | 1 of 3 | - | +73 |
| Opponent | Dwarfen Mountain Holds | 1 | 422 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 255 | 612 | 2.0 | 1.5 | 306 | 0 | +306 | 2 of 2 | 2 of 2 | +185 | +427 |
| Opponent | Grand Cathay | 1 | 520 | 281 | 3.0 | 1.7 | 94 | 126 | -33 | 2 of 3 | 3 of 3 | -49 | +0 |
| Opponent | High Elf Realms | 2 | 198 | 116 | 3.5 | 1.3 | 33 | 0 | +33 | 4 of 7 | 7 of 7 | +0 | +39 |
| Opponent | Lizardmen | 1 | 281 | 299 | 3.0 | 1.0 | 100 | 0 | +100 | 2 of 3 | 3 of 3 | - | +100 |
| Opponent | Ogre Kingdoms | 2 | 26 | 58 | 4.0 | 1.1 | 14 | 68 | -54 | 2 of 8 | 4 of 8 | +0 | -61 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 646 | 3.0 | 1.2 | 215 | 0 | +215 | 3 of 6 | 6 of 6 | +364 | +185 |
| Opponent | Skaven | 2 | 302 | 102 | 1.0 | 1.0 | 102 | 32 | +70 | 1 of 2 | 1 of 2 | - | +70 |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 1168 | 5.0 | 1.3 | 234 | 13 | +220 | 9 of 20 | 17 of 20 | +128 | +260 |
| Opponent | Vampire Counts | 6 | 0 | 288 | 3.0 | 1.1 | 96 | 18 | +78 | 7 of 18 | 12 of 18 | +66 | +80 |
| Opponent | Warriors of Chaos | 7 | 0 | 227 | 2.0 | 1.1 | 114 | 73 | +41 | 8 of 14 | 10 of 14 | +0 | +44 |
| Opponent | Wood Elf Realms | 6 | 110 | 507 | 3.3 | 1.4 | 152 | 43 | +109 | 10 of 20 | 17 of 20 | +323 | -6 |
| **Opponent** | all armies | 36 | 90 | 404 | 2.9 | 1.2 | 137 | 35 | +102 | 53 of 106 | 83 of 106 | +164 | +86 |

### Effective charges: ss-mine-06f55ce-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net -52) | 0 | 2 (net +120) | 2 (net +134) | 0 | 3 (net +37) | 0 | 22% (2 of 9) |
| Mine | Chaos Dwarfs | 11 | 1 (net +677) | 0 | 2 (net +216) | 3 (net +110) | 0 | 5 (net +130) | 0 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 0 | 1 (net +111) | 0 | 1 (net +60) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 10 | 4 (net -115) | 0 | 0 | 3 (net +55) | 1 (net +0) | 1 (net +195) | 1 | 0% (0 of 9) |
| Mine | Grand Cathay | 10 | 2 (net -250) | 0 | 4 (net +98) | 3 (net +277) | 0 | 1 (net +144) | 0 | 40% (4 of 10) |
| Mine | High Elf Realms | 14 | 3 (net +83) | 0 | 2 (net +362) | 3 (net +105) | 1 (net +0) | 2 (net +0) | 3 | 18% (2 of 11) |
| Mine | Kingdom of Bretonnia | 4 | 3 (net +89) | 0 | 0 | 0 | 0 | 1 (net +254) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 2 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +66) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Skaven | 4 | 3 (net +100) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 14 | 1 (net +813) | 0 | 1 (net +116) | 9 (net +49) | 0 | 3 (net +80) | 0 | 7% (1 of 14) |
| Mine | Vampire Counts | 8 | 1 (net -211) | 1 (net +0) | 0 | 5 (net +31) | 1 (net -233) | 0 | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 3 | 1 (net -85) | 0 | 1 (net -85) | 1 (net +390) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 2 (net +306) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 2 (net -142) | 0 | 1 (net +186) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 7 | 0 | 0 | 1 (net +233) | 3 (net +0) | 0 | 2 (net +0) | 1 | 17% (1 of 6) |
| Opponent | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +110) | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 1 (net +85) | 1 (net +0) | 1 (net +30) | 1 (net +0) | 0 | 2 (net -92) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +364) | 0 | 1 (net +529) | 4 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 1 (net -65) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 20 | 1 (net +405) | 2 (net +328) | 5 (net +164) | 4 (net +402) | 3 (net +110) | 4 (net +127) | 1 | 26% (5 of 19) |
| Opponent | Vampire Counts | 18 | 4 (net -70) | 0 | 4 (net +32) | 6 (net +122) | 0 | 1 (net +729) | 3 | 27% (4 of 15) |
| Opponent | Warriors of Chaos | 14 | 2 (net -117) | 1 (net -116) | 5 (net +37) | 2 (net +156) | 0 | 3 (net +141) | 1 | 38% (5 of 13) |
| Opponent | Wood Elf Realms | 20 | 3 (net -78) | 0 | 6 (net +127) | 4 (net +14) | 2 (net +280) | 4 (net +212) | 1 | 32% (6 of 19) |

### Charged fights, damage counted: ss-mine-06f55ce-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 22 | 214 | 193 | +47 | 154 | 82 | +73 | +34.0 |
| Mine | 50-54% | 1 | 401 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 12 | 261 | 258 | +164 | 169 | 43 | +126 | +48.1 |
| Mine | 76-89% | 30 | 243 | 142 | +87 | 114 | 37 | +77 | +31.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 244 | 185 | +92 | 109 | 29 | +80 | +32.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 497 | 113 | -43 | 15 | 113 | -98 | -19.6 |
| Mine | No odds | 9 | 241 | 198 | -1 | 89 | 77 | +11 | +4.7 |
| Mine | All fights | 96 | 251 | 181 | +74 | 121 | 53 | +68 | +27.2 |
| Opponent | Long shot (under 50%) | 13 | 160 | 322 | -31 | 111 | 149 | -37 | -23.4 |
| Opponent | 50-54% | 4 | 248 | 276 | +135 | 164 | 55 | +109 | +44.2 |
| Opponent | Effective (55-75%) | 23 | 287 | 223 | +90 | 121 | 47 | +74 | +25.8 |
| Opponent | 76-89% | 27 | 309 | 181 | +140 | 189 | 39 | +151 | +48.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 310 | 204 | +169 | 239 | 50 | +189 | +61.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 494 | 118 | +166 | 192 | 29 | +163 | +33.0 |
| Opponent | No odds | 15 | 207 | 200 | +53 | 103 | 58 | +45 | +21.7 |
| Opponent | All fights | 106 | 280 | 214 | +102 | 160 | 59 | +102 | +36.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-mine-06f55ce-p1 | move | 382 | 83 (22%) | 56 (15%) | 45 (12%) | 254 (66%) |
| ss-mine-06f55ce-p1 | objective | 405 | 54 (13%) | 37 (9%) | 51 (13%) | 300 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

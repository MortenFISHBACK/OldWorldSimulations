# Doctrine scorecard: ss-mine-06f55ce-p4

### Scorecard: ss-mine-06f55ce-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 10 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 9 | 1 | 3 | 2 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | yes | 5 | 4 | 2 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 1 | - | 1 | 2 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 6 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 7 | 4 | 2 | 0 | 0 | 0 | 0 | 900 |
| L0315 | 3 | 1 | Opponent | yes | 13 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 12 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 49 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 1647 |
| L0520 | 4 | 1 | Opponent | no | 0 | 5 | 3 | 5 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 4 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 828 |
| L0624 | 6 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 5 | 2 | 1 | 2 | 0 | 0 | 564 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 5 | 1 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0819 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 717 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 596 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 0 | 2 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 500 |
| L1126 | 4 | 1 | Mine | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L1126 | 4 | 1 | Opponent | no | 1 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 3 | 1 | 0 | 0 | 650 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 17 | 2 | 4 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | no | - | 5 | 1 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 1 | 4 | 3 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 176 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 70 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 2 | - | 3 | 4 | 0 | 0 | 0 | 787 |
| L1719 | 3 | 1 | Mine | yes | 3 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 5 | 2 | 6 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 1 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 8 | - | 1 | 1 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 11 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 39% | 3.7 | 2.8 | 2.7 | 1.1 | 0.2 | 0.0 | 0.0 | 319.7 |
| **Average** | | | Opponent | 39% | 3.3 | 2.4 | 2.7 | 2.1 | 0.4 | 0.0 | 0.0 | 113.4 |

### KPIs: ss-mine-06f55ce-p4

Rules off - Opponent only: FALLS SHORT, TIME ON OUR SIDE, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (39 of 174) | 1% (2 of 179) | 12% (41 of 353) |
| Winner chose to follow up after the loser gave ground |  | 95% (53 of 56); on the table 95% | 98% (40 of 41); on the table 98% | 96% (93 of 97); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (12 of 12); on the table 100% | 100% (18 of 18); on the table 100% | 100% (30 of 30); on the table 100% |
| Winner chose to pursue after the loser fled |  | 76% (22 of 29); on the table 83% | 79% (22 of 28); on the table 86% | 77% (44 of 57); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 90% (87 of 97); on the table 92% | 92% (80 of 87); on the table 94% | 91% (167 of 184); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 34% (91 of 267) | 35% (61 of 174) | 34% (152 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (91 of 197) | 48% (61 of 127) | 47% (152 of 324) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (21 of 36) | 66% (37 of 56) | 63% (58 of 92) |
| Points that never fought | lower | 36% (24578 of 67942) | 37% (26532 of 71984) | 37% (51110 of 139926) |
|   infantry points that never fought | lower | 48% (7302 of 15347) | 57% (7896 of 13804) | 52% (15198 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (157 of 270) | 59% (166 of 280) | 59% (323 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.8 uses a game | 78% (7 of 9); 0.6 uses a game | 84% (26 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.2 uses a game | 50% (10 of 20); 0.4 uses a game | 42% (15 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 60% (9 of 15); 0.2 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (29752 of 57750) | 53% (33588 of 63347) | 52% (63340 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (31%) | 0.9 (30%) | 2.4 (30%) |
| MARCHED: its unit marched | 1.2 (25%) | 0.4 (12%) | 1.6 (20%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.3 (10%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 1.0 (21%) | 0.7 (23%) | 1.8 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (4%) | 0.2 (3%) |
| GONE: slain | 0.7 (14%) | 0.5 (15%) | 1.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.4 | 2.1 | 4.2 | 0.3 | 2.6 |
| not cast | 2.9 | 2.5 | 2.8 | 8.0 | 1.7 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (48%) | 0.2 (7%) | 2.4 (30%) | 0.6 (32%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (20%) | 0.4 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (8%) | 0.5 (17%) | 1.8 (22%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.3 (10%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.1 (4%) | 0.0 (0%) | 0.2 (3%) | 0.0 (2%) | 0.6 (3%) |
| GONE: slain | 0.6 (22%) | 0.3 (13%) | 0.4 (14%) | 1.2 (15%) | 0.0 (0%) | 2.6 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (2%) | 0.2 (6%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.4 (23%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (57%) | 0.2 (7%) | 1.2 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 60% (28 of 47) | 71% (10 of 14) | 62% (38 of 61) |
| the unit moved after it | 89% (25 of 28) | 70% (7 of 10) | 84% (32 of 38) |
| it charged on its next turn | 11% (3 of 28) | 10% (1 of 10) | 11% (4 of 38) |
| the enemy charged it first | 18% (5 of 28) | 0% (0 of 10) | 13% (5 of 38) |
| it fought by the end of its next turn | 7% (2 of 28) | 10% (1 of 10) | 8% (3 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (6 of 28) | 0% (0 of 10) | 16% (6 of 38) |
| none of these (no charge, no fight, no charge escaped) | 50% (14 of 28) | 80% (8 of 10) | 58% (22 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (584 of 888) | 53% (289 of 547) | 61% (873 of 1435) |
|   cavalry | 59% (54 of 91) | 72% (83 of 115) | 67% (137 of 206) |
|   character | 49% (49 of 101) | 16% (21 of 131) | 30% (70 of 232) |
|   chariot | 47% (50 of 106) | 72% (13 of 18) | 51% (63 of 124) |
|   infantry | 67% (179 of 269) | 60% (138 of 231) | 63% (317 of 500) |
|   monster | 57% (29 of 51) | 23% (5 of 22) | 47% (34 of 73) |
|   war machine | 83% (223 of 270) | 97% (29 of 30) | 84% (252 of 300) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (20%) | 1.6 (22%) | 3.3 (21%) |
| CHARGED: it charged | 1.3 (15%) | 1.6 (23%) | 2.9 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.4 (6%) | 1.2 (7%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.2 (26%) | 1.4 (20%) | 3.6 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (7%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.4 (20%) | 2.9 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.4 | 84% | 4.6 pts | 29 pts |
| character | 2.1 | 0.8 | 77% | 6.5 pts | 13 pts |
| chariot | 1.8 | 0.8 | 73% | 10.7 pts | 19 pts |
| infantry | 13.1 | 5.3 | 72% | 9.6 pts | 126 pts |
| monster | 1.1 | 0.1 | 89% | 4.6 pts | 5 pts |
| war machine | 7.0 | 5.2 | 69% | 30.1 pts | 211 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.1 | 5.1 |
| Charges that made contact a game | 2.9 | 4.4 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.65 contact (17 units) | 0.88 declared, 0.56 contact (16 units) | 0.82 declared, 0.61 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.89 declared, 0.44 contact (9 units) | 1.64 declared, 1.27 contact (11 units) | 1.30 declared, 0.90 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.36 contact (246 units) | 0.62 declared, 0.45 contact (301 units) | 0.57 declared, 0.41 contact (547 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (46 of 81) | 44% (7 of 16) | 50% (3 of 6) | 54% (56 of 103) |
| Character in a unit | 82% (28 of 34) | 79% (15 of 19) | 100% (1 of 1) | 81% (44 of 54) |
| Character on its own | 94% (29 of 31) | 39% (9 of 23) | 32% (25 of 77) | 48% (63 of 131) |
| Chariot | 67% (10 of 15) | 67% (8 of 12) | - | 67% (18 of 27) |
| Infantry | 55% (46 of 83) | 40% (10 of 25) | 50% (3 of 6) | 52% (59 of 114) |
| Monster | 59% (20 of 34) | 79% (11 of 14) | - | 65% (31 of 48) |
| Monstrous | 57% (8 of 14) | 64% (9 of 14) | - | 61% (17 of 28) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 78% (7 of 9); on the table 78% | 34% (35 of 102) | 12% | 59% (13 of 22) | 83% (5 of 6); 4.2 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (20 of 24); on the table 92% | 50% (12 of 24) | 26% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 65% | 56% (15 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 83% | 72% (13 of 18) | 45% | 69% (43 of 62) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (9 of 9); on the table 100% | 31% (26 of 84) | 48% | 46% (17 of 37) | 100% (9 of 9); 7.2 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 92% (23 of 25); on the table 92% | 8% (3 of 36) | 31% | 43% (30 of 70) | 100% (7 of 7); 3.1 uses a game | 40% (12 of 30); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 50% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (12 of 12); on the table 100% | 100% (6 of 6) | 36% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 75% | 17% (1 of 6) | 65% | 79% (11 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 88% (7 of 8); on the table 88% | 33% (14 of 42) | 9% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 100% (5 of 5); on the table 100% | 37% (15 of 41) | 52% | 82% (37 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 50% (3 of 6); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 94% (15 of 16); on the table 100% | 0% (0 of 6) | 40% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (15 of 17); on the table 88% | 36% (21 of 58) | 28% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (24 of 24); on the table 100% | 25% (3 of 12) | 33% | 64% (46 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 87% (13 of 15); on the table 93% | 50% (3 of 6) | 39% | 66% (37 of 56) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (ss-mine-06f55ce-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (40) | 60% (41) | 49% (81) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.83 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.17 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.53 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.56 | 1.14 | 2.69 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.39 | 0.39 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.81 | 6.11 | 11.92 |

### Quality by phase: ss-mine-06f55ce-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 42% (63 of 151) | 42% (79 of 186) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (186 of 403) | 39% (73 of 186) |
| Strategy | Close-in objectives charged next turn | 17% (27 of 162) | 13% (31 of 234) |
| Strategy | Support requests answered (helper made contact too) | 53% (9 of 17) | 41% (12 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 27% (3 of 11) | 33% (2 of 6) |
| Strategy | Joined characters whose unit fought | 62% (28 of 45) | 38% (13 of 34) |
| Strategy | Lone characters that fought | 82% (64 of 78) | 77% (63 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 2.1 |
| Movement | Points that never moved of their own | 319.7 | 113.4 |
| Movement | Fights charged into per game | 2.8 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 91, net -16 | 22 of 121, net +14 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 91, net +47 | 31 of 121, net +79 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 91, net +64 | 16 of 121, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 91, net +56 | 16 of 121, net +225 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.2 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (191 of 402) | 42% (131 of 312) |
| Shooting | Points destroyed by shooting units | 103.0 | 24.7 |
| Shooting | War machine shots | 6.2 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (140 of 223) | 34% (10 of 29) |
| Shooting | Points destroyed by war machines | 68.7 | 15.4 |
| Magic | Magic missiles cast | 1.7 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 13% (8 of 60) | 26% (10 of 38) |
| Magic | Wounds caused by magic missiles | 4.2 | 0.6 |
| Magic | Wounds caused by other spells | 1.1 | 1.9 |
| Magic | Points destroyed by magic (all spells) | 72.2 | 17.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 0.7 / 0.2 | 1.9 / 0.4 / 0.9 / 0.0 |
| Combat | Points destroyed in combat | 229.9 | 415.3 |
| Combat | Points run down | 145.9 | 68.6 |
| Combat | Net points per charged fight, damage counted | +47 | +75 |
| Combat | Net per 100 charger points, damage counted | +17.4 | +23.7 |
| Combat | First round won (charged fights) | 76% | 67% |
| Combat | Net points per charged fight | +43 | +73 |
| Combat | Net points per supported fight / lone fight | -20 / +48 | +133 / +60 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 99 | 63 of 131 |
| Game | Points lost | 679.3 | 688.2 |
| Game | VP from objectives | 562.8 | 491.1 |
| Game | Lone holders (player turns) | 3.7 | 3.3 |

- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +68 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1368
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ss-mine-06f55ce-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.5 | -107.4 | 152.5 | 110.9 | 5.1 | -161.6 | 94.7 | 77.7 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 19.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.5 | +1.6 | 0.0 | 21.9 | 0.8 | +4.4 | 0.0 | 16.2 |
| BEST FACING | 0.4 | +8.1 | 0.0 | 0.0 | 0.2 | +5.0 | 0.0 | 27.6 |
| BEST FIRST | 0.8 | +22.9 | 20.5 | 39.8 | 0.9 | +36.2 | 26.1 | 18.3 |
| BEST OVERALL | 0.2 | +10.1 | 0.0 | 2.9 | 0.2 | +6.5 | 0.0 | 29.2 |
| BEST PREY | 0.6 | +44.5 | 28.8 | 20.4 | 0.4 | +27.3 | 5.3 | 9.8 |
| BEST PRIZE | 0.1 | -2.7 | 3.1 | 0.0 | 0.0 | -8.3 | 0.0 | 12.3 |
| BIG CHARACTER SAFETY | 0.1 | +0.1 | 0.0 | 15.0 | 0.2 | -0.6 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.1 | +0.5 | 0.0 | 0.0 | 0.6 | +9.6 | 0.0 | 8.1 |
| BLOWS WHERE AIMED | 0.2 | -21.2 | 33.5 | 6.2 | 0.2 | -59.4 | 15.7 | 21.2 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.1 | +0.0 | 0.0 | 8.2 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 102.8 | 10.7 | 0.1 | +0.0 | 21.1 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +178.6 | 256.6 | 140.8 | 0.8 | +45.5 | 67.2 | 0.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.1 |
| CARRIES OUT SET-UP | 0.1 | -0.1 | 41.9 | 0.0 | 0.1 | -3.8 | 11.6 | 0.0 |
| CAST JOB | 0.9 | +27.2 | 37.4 | 21.9 | 0.6 | +7.5 | 0.0 | 6.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 9.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +18.7 | 3.4 | 0.0 | 0.1 | +2.5 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 7.1 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.1 | +57.7 | 0.0 | 26.9 | 1.9 | +109.5 | 0.0 | 55.8 |
| CHAFF PASSED | 0.2 | +0.0 | 9.5 | 2.2 | 0.1 | -0.2 | 6.2 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 266.3 | 61.9 | 2.9 | +0.0 | 314.0 | 58.4 |
| CHARGE NOW WEIGHED | 0.4 | -17.0 | 6.8 | 5.7 | 0.6 | -24.2 | 1.1 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -8.7 | 35.8 | 2.2 | 0.6 | -14.6 | 61.9 | 10.5 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 3.5 | 1.7 | 0.1 | +0.0 | 0.0 | 5.6 |
| CHEAPEST HOLDER | 1.1 | -60.2 | 26.5 | 22.3 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 47.4 | 46.1 | 0.4 | +0.0 | 27.7 | 20.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.8 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +64.8 | 15.2 | 34.4 | 0.3 | +59.5 | 0.0 | 0.0 |
| COVER ONCE | 8.2 | -440.4 | 0.0 | 199.7 | 6.1 | -403.4 | 0.0 | 127.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 1.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.1 | 4.2 | 0.0 | 0.1 | +8.9 | 31.4 | 9.6 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +72.0 | 0.0 | 8.8 | 1.1 | +70.9 | 0.0 | 73.3 |
| FALLBACK BY WORTH | 3.8 | +21.4 | 0.0 | 53.0 | 6.6 | +62.8 | 0.0 | 43.0 |
| FALLS SHORT | 5.9 | +87.4 | 0.0 | 99.9 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.7 | 4.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.2 | +1.9 | 2.9 | 15.8 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 133.1 | 5.2 | +0.0 | 0.0 | 137.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.6 | 1.7 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +105.9 | 0.0 | 26.9 | 1.1 | +140.7 | 0.0 | 32.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +6.7 | 0.0 | 17.1 | 0.2 | +6.4 | 0.0 | 7.4 |
| GIVES UP | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 8.6 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.5 | 4.2 |
| HELPER UNSEEN | 0.3 | +0.0 | 48.2 | 0.0 | 0.6 | +0.0 | 13.7 | 26.5 |
| HILL BY ITS CHANCE | 0.4 | -68.5 | 0.0 | 5.8 | 0.4 | -38.4 | 0.0 | 9.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.9 | -141.0 | 425.8 | 101.8 | 9.8 | -235.0 | 609.6 | 162.2 |
| HUNT ADVANCE | 0.0 | +0.1 | 5.4 | 0.0 | 0.1 | +2.3 | 2.4 | 3.2 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.2 | +4.6 | 0.0 | 0.0 | 0.5 | +30.2 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.1 | 5.4 | 0.0 | 0.1 | +0.1 | 4.7 | 0.0 |
| HUNT RESULT | 0.0 | +5.7 | 0.0 | 0.0 | 0.2 | +24.5 | 3.5 | 3.2 |
| HUNT THE GUNS | 0.0 | +6.0 | 5.4 | 0.0 | 0.2 | +52.8 | 12.6 | 3.2 |
| IDLE COST | 3.1 | -38.3 | 0.0 | 63.1 | 20.8 | -342.7 | 0.0 | 172.0 |
| INVITES THE FIGHT | 0.9 | +5.0 | 27.9 | 17.2 | 1.1 | +9.3 | 24.7 | 39.3 |
| JOINT CHARGE PLAN | 0.2 | +6.8 | 0.0 | 1.4 | 0.1 | +2.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.9 | 1.0 | 0.0 | 0.1 | -5.6 | 8.0 | 5.2 |
| KEEP FALLS | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.0 | 3.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.8 | 133.4 | 34.3 | 2.0 | +60.0 | 168.9 | 43.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +54.8 | 72.0 | 64.1 | 2.3 | +127.4 | 229.7 | 69.8 |
| KILLS COUNT NEXT TURN | 4.8 | +169.7 | 204.4 | 99.2 | 6.2 | +274.3 | 170.7 | 104.4 |
| LONE CHARACTER SAFE SPOT | 0.2 | +2.5 | 5.7 | 14.3 | 0.1 | +14.0 | 0.0 | 8.6 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 1.7 | 21.4 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +3.6 | 15.2 | 9.9 | 0.6 | +0.8 | 27.9 | 16.2 |
| LOST CHARGE | 2.4 | -38.4 | 62.4 | 23.2 | 1.8 | -31.4 | 52.2 | 80.2 |
| LURE BY WHAT IT DRAWS | 0.3 | -38.1 | 0.0 | 4.6 | 0.2 | -23.3 | 0.0 | 5.9 |
| MAKE SURE TOGETHER | 0.9 | +60.1 | 0.0 | 12.5 | 0.4 | +36.4 | 0.0 | 4.5 |
| MANOEUVRE | 0.4 | +7.1 | 0.0 | 16.3 | 0.1 | +1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 20.4 |
| MARCH CHECK | 0.6 | +15.7 | 0.0 | 0.0 | 0.3 | +22.6 | 0.0 | 14.9 |
| MARCH ODDS | 0.4 | +30.6 | 7.2 | 0.0 | 0.2 | +11.1 | 13.6 | 9.5 |
| MARCH OVER CASTS | 0.5 | +15.7 | 0.0 | 0.0 | 0.2 | +22.3 | 0.0 | 16.5 |
| MAX FOR POSITIONING | 6.0 | +101.7 | 0.0 | 135.9 | 6.4 | +84.2 | 0.0 | 111.6 |
| MISSILES IN THE MOVE | 4.2 | +141.4 | 0.0 | 103.6 | 2.0 | +27.9 | 0.0 | 35.2 |
| MISSILES NEXT TURN | 4.9 | +98.8 | 0.0 | 104.5 | 2.9 | +28.9 | 0.0 | 77.8 |
| MODEL FACING | 0.2 | +36.8 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +16.0 | 0.0 | 7.0 | 0.2 | +8.3 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.4 | +8.7 | 0.0 | 17.6 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -37.4 | 10.1 | 10.6 | 0.1 | -3.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 9.6 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.3 | +153.9 | 112.9 | 50.0 | 4.6 | +320.2 | 190.0 | 73.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.8 | +544.3 | 0.0 | 103.6 | - | - | - | - |
| NEEDED THERE | 0.0 | +5.7 | 1.2 | 0.0 | - | - | - | - |
| NO FORCED ADVANCE | 1.7 | +0.0 | 0.0 | 9.2 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +11.0 | 0.0 | 2.4 | - | - | - | - |
| NOT NEEDED | 0.3 | -10.9 | 37.3 | 0.0 | 0.2 | -6.7 | 41.8 | 0.0 |
| NOT TURNED | 5.8 | +29.9 | 0.0 | 122.6 | 6.1 | +78.0 | 0.0 | 110.5 |
| NOT WORTH A CAST | 0.7 | -0.6 | 0.0 | 10.6 | 0.4 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 13.4 | -466.7 | 25.3 | 185.3 | 15.6 | -685.1 | 0.0 | 248.6 |
| ONE FIGHT FORMULA | 7.4 | -126.7 | 24.4 | 163.4 | 8.6 | -178.2 | 20.8 | 217.6 |
| ONE OBJECTIVE FORMULA | 2.2 | -82.2 | 0.0 | 20.0 | 2.2 | -137.8 | 0.0 | 45.5 |
| OPENS A LANE | 0.1 | +1.0 | 7.8 | 4.6 | - | - | - | - |
| OPENS UP | 0.4 | +28.8 | 24.8 | 0.0 | 0.2 | +12.0 | 11.8 | 12.3 |
| OVERRUNS AWAY | 0.7 | +32.4 | 53.8 | 8.3 | 0.4 | +13.1 | 30.8 | 28.5 |
| PATHS CROSS | 2.3 | +92.4 | 0.0 | 61.1 | 3.3 | +217.5 | 0.0 | 23.0 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 16.6 | 0.1 | -1.6 | 0.0 | 4.2 |
| PLAN RESULT | 38.0 | +1335.5 | 1455.5 | 975.9 | 39.0 | +1093.3 | 1083.4 | 1030.1 |
| PURSUES BIG PREY | 0.1 | -7.5 | 0.0 | 0.0 | 0.1 | -8.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +18.2 | 0.0 | 42.6 | 1.6 | +25.0 | 0.0 | 76.1 |
| RANDOM MOVER NO PROMISE | 0.3 | -17.5 | 21.7 | 14.2 | 0.1 | -7.1 | 0.0 | 15.3 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -8.4 | 0.0 | 22.3 | 1.7 | -50.2 | 0.0 | 43.3 |
| REDIRECT COUNTER | 2.6 | +147.1 | 0.0 | 31.2 | 4.1 | +269.9 | 0.0 | 59.3 |
| REDIRECT WEIGHED | 0.2 | +1.4 | 6.2 | 2.2 | 0.1 | +4.8 | 10.8 | 4.8 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 10.7 | 0.2 | +0.0 | 0.0 | 15.0 |
| RESERVE FALL BACK | 0.6 | +15.1 | 0.0 | 7.1 | 0.6 | +18.0 | 0.0 | 14.8 |
| RESTRAINS TO SHOOT | 0.1 | +5.3 | 0.0 | 9.8 | 0.0 | +0.5 | 0.0 | 3.5 |
| RISK BY ARC | 2.8 | +100.7 | 245.7 | 49.1 | 2.9 | +58.5 | 264.8 | 116.8 |
| RISK ONCE | 2.0 | +39.4 | 15.8 | 102.7 | 4.2 | +132.5 | 48.4 | 236.9 |
| SAFE SURE CHARGE | 0.0 | -1.0 | 0.0 | 0.0 | 0.1 | -3.8 | 1.1 | 0.0 |
| SAFER THAN THE JOB | 1.4 | +90.0 | 0.0 | 29.7 | 0.4 | +14.6 | 0.0 | 7.4 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.6 | 0.0 | 0.0 | 0.4 | -21.7 | 0.0 | 5.3 |
| SEARCH SPOT | 2.2 | +62.1 | 0.0 | 18.1 | 2.9 | +111.2 | 0.0 | 32.4 |
| SELF MOVE SPELL | 0.2 | +35.5 | 0.0 | 0.0 | 0.6 | +21.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.1 | +70.1 | 0.0 | 12.5 | 1.0 | +90.8 | 0.0 | 4.5 |
| SET-UP ANY TARGET | 0.5 | +75.1 | 10.6 | 22.2 | 0.1 | +29.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +10.2 | 4.7 | 7.1 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.2 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +53.0 | 84.6 | 31.8 | 1.2 | +40.6 | 69.1 | 5.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 111.7 | 4.6 | 0.2 | +0.0 | 26.2 | 0.0 |
| SHOTS IN THE MOVE | 15.1 | +534.3 | 0.0 | 275.6 | 7.3 | +191.4 | 0.0 | 88.3 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.6 | 0.0 | 0.0 |
| SPELL OFF EDGE | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.5 | +75.1 | 10.6 | 22.2 | 0.2 | +59.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +22.7 | 98.1 | 86.5 | 2.4 | +44.1 | 97.2 | 97.2 |
| SPELLS IN THE FIGHT | 0.6 | -5.1 | 77.1 | 34.8 | 1.0 | -9.8 | 129.0 | 49.2 |
| STABLE ROLE | 11.4 | +0.0 | 342.1 | 227.3 | 10.4 | +0.0 | 275.8 | 134.8 |
| STANDS TO CAST | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +2.4 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.2 | 5.4 | 0.0 | 0.1 | +4.2 | 12.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +20.1 | 0.0 | 21.8 | 0.2 | +3.3 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 16.4 |
| SUPPORT NARROWED | 6.6 | -63.0 | 354.4 | 125.2 | 7.5 | -68.5 | 328.9 | 90.8 |
| SUPPORTS | 4.6 | +73.6 | 191.1 | 96.7 | 5.4 | +70.8 | 124.4 | 38.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.4 | 3.5 | 0.0 | 0.1 | -1.2 | 15.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +4.6 | 0.0 | 13.6 | 0.8 | -0.7 | 0.0 | 11.9 |
| THROUGH LINE OF FIRE | 0.2 | +7.9 | 0.0 | 0.0 | 0.2 | +12.8 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 21.2 | +368.8 | 0.0 | 273.1 | - | - | - | - |
| TURN WORTH | 0.2 | -17.1 | 17.9 | 12.8 | 0.2 | -16.0 | 30.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.0 | -228.2 | 209.2 | 90.9 | 7.8 | -410.9 | 279.1 | 132.3 |
| WALKS TO THE FIGHT | 1.5 | +9.9 | 36.9 | 15.9 | 1.0 | +5.9 | 19.4 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +10.8 | 8.6 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 34.5 | 12.6 | 0.1 | +0.0 | 5.8 | 0.0 |
| WEARS DOWN | 1.1 | +42.6 | 151.7 | 17.3 | 1.4 | +50.6 | 90.1 | 59.9 |
| WHO HITS BACK | 0.4 | +28.0 | 0.0 | 7.6 | 0.3 | +14.0 | 0.0 | 16.9 |
| WHOLE FIGHT | 0.3 | +17.7 | 30.9 | 4.7 | 0.4 | -12.0 | 70.0 | 6.7 |
| WHOLE FIGHT GAIN | 0.3 | +17.6 | 16.6 | 3.3 | 0.7 | +44.0 | 43.5 | 8.1 |
| WIDER SPREAD | 2.7 | -8.0 | 278.2 | 65.9 | 3.5 | -9.0 | 325.0 | 79.0 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.8 | 0.0 | - | - | - | - |

### Rule changes: ss-mine-06f55ce-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1044 | 1044 | 1044 | 29.00 | -41468 | -39.7 |
| PATHS CROSS | 203 | 203 | 203 | 5.64 | +11157 | +55.0 |
| SEARCH SPOT | 183 | 183 | 175 | 4.86 | +6283 | +35.9 |
| MOVE TO CHARGE | 285 | 284 | 163 | 4.53 | +6811 | +41.8 |
| SUPPORTS | 362 | 362 | 160 | 4.44 | +2045 | +12.8 |
| KILLS COUNT NEXT TURN | 396 | 395 | 151 | 4.19 | +5255 | +34.8 |
| NEARER NOT NEEDED | 388 | 281 | 135 | 3.75 | +2512 | +18.6 |
| TIME ON OUR SIDE | 763 | 499 | 124 | 3.44 | +364 | +2.9 |
| FACES THE THREAT | 97 | 97 | 97 | 2.69 | +5146 | +53.1 |
| SHOTS IN THE MOVE | 805 | 572 | 94 | 2.61 | +2004 | +21.3 |
| COVER ONCE | 514 | 303 | 88 | 2.44 | +1079 | +12.3 |
| WAIT AFTER COSTS | 498 | 497 | 85 | 2.36 | +1438 | +16.9 |
| FALLBACK BY WORTH | 371 | 371 | 76 | 2.11 | +3029 | +39.9 |
| CHAFF IN THE MOVE | 107 | 103 | 69 | 1.92 | +2194 | +31.8 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +8877 | +128.7 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +3767 | +58.9 |
| ADVANCE WORTH | 381 | 381 | 61 | 1.69 | +1689 | +27.7 |
| NO FORCED ADVANCE | 60 | 60 | 60 | 1.67 | +798 | +13.3 |
| BEST FIRST | 59 | 59 | 59 | 1.64 | +2127 | +36.1 |
| RANDOM MOVE BY FIGURES | 92 | 92 | 58 | 1.61 | +1555 | +26.8 |
| REDIRECT COUNTER | 242 | 126 | 58 | 1.61 | +4059 | +70.0 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHARGE NOW FIRST | 203 | 203 | 49 | 1.36 | -2302 | -47.0 |
| ONE FIGHT FORMULA | 575 | 343 | 44 | 1.22 | +150 | +3.4 |
| MISSILES IN THE MOVE | 224 | 146 | 43 | 1.19 | +907 | +21.1 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1192 | +27.7 |
| RISK BY ARC | 204 | 199 | 43 | 1.19 | +1254 | +29.2 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 96 | 96 | 42 | 1.17 | +1307 | +31.1 |
| HONEST WORTH | 637 | 633 | 39 | 1.08 | +512 | +13.1 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| KILLS COUNT | 147 | 143 | 38 | 1.06 | +1890 | +49.7 |
| HARD STAY DROPPED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +1328 | +36.9 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| WALKS TO THE FIGHT | 90 | 90 | 35 | 0.97 | +133 | +3.8 |
| SET UP TOGETHER | 75 | 64 | 34 | 0.94 | +2349 | +69.1 |
| RISK ONCE | 223 | 178 | 31 | 0.86 | +684 | +22.1 |
| FALLS SHORT | 213 | 143 | 30 | 0.83 | +235 | +7.8 |
| MARCH CHECK | 34 | 33 | 30 | 0.83 | +1025 | +34.2 |
| CANNON PLANNED TARGET | 201 | 201 | 29 | 0.81 | +106 | +3.7 |
| MAX FOR POSITIONING | 447 | 281 | 29 | 0.81 | +90 | +3.1 |
| IDLE COST | 862 | 511 | 28 | 0.78 | +283 | +10.1 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +365 | +13.5 |
| KEEPS ITS TARGET | 127 | 125 | 26 | 0.72 | +478 | +18.4 |
| WHO HITS BACK | 25 | 25 | 25 | 0.69 | +890 | +35.6 |
| INVITES THE FIGHT | 74 | 74 | 24 | 0.67 | +106 | +4.4 |
| STOPS SHORT OF THE FLANK | 23 | 23 | 23 | 0.64 | +843 | +36.7 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +384 | +17.4 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BEST FACING | 20 | 20 | 20 | 0.56 | +474 | +23.7 |
| CAST JOB | 52 | 52 | 19 | 0.53 | +342 | +18.0 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +472 | +24.9 |
| WHOLE FIGHT GAIN | 35 | 34 | 19 | 0.53 | +566 | +29.8 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +878 | +48.8 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WAR ENGINE JOBS | 30 | 30 | 17 | 0.47 | -477 | -28.1 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +744 | +46.5 |
| MANOEUVRE | 18 | 18 | 15 | 0.42 | +316 | +21.1 |
| BEST OVERALL | 14 | 14 | 14 | 0.39 | +595 | +42.5 |
| WEARS DOWN | 89 | 87 | 14 | 0.39 | +601 | +42.9 |
| BEST PREY | 39 | 39 | 13 | 0.36 | +408 | +31.4 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -7 | -0.5 |
| MAKE SURE TOGETHER | 46 | 30 | 13 | 0.36 | +887 | +68.2 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -20 | -1.6 |
| REDIRECT WEIGHED | 12 | 12 | 12 | 0.33 | +1129 | +94.1 |
| OPENS UP | 20 | 20 | 11 | 0.31 | +501 | +45.6 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MISSILES NEXT TURN | 279 | 186 | 10 | 0.28 | +34 | +3.4 |
| OVERRUNS AWAY | 41 | 41 | 10 | 0.28 | +257 | +25.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 508 | 508 | 9 | 0.25 | -149 | -16.6 |
| CASTING BLOCK | 12 | 12 | 8 | 0.22 | +400 | +50.0 |
| FIRE AND FLEE | 8 | 8 | 8 | 0.22 | +68 | +8.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -91 | -11.4 |
| WHOLE FIGHT | 28 | 28 | 8 | 0.22 | +306 | +38.2 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +1324 | +189.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| HUNT IN PAIRS | 28 | 16 | 6 | 0.17 | +377 | +62.8 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +269 | +44.8 |
| REFUSING RETIRES | 17 | 17 | 6 | 0.17 | -4 | -0.7 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +212 | +35.2 |
| SURE REACH TOGETHER | 53 | 43 | 6 | 0.17 | +22 | +3.7 |
| LOST CHARGE | 150 | 150 | 5 | 0.14 | +124 | +24.8 |
| ONE OBJECTIVE FORMULA | 161 | 71 | 5 | 0.14 | +102 | +20.4 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -564 | -112.7 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -95 | -19.0 |
| WIDER SPREAD | 223 | 213 | 5 | 0.14 | +23 | +4.6 |
| BACKUP TARGETS | 46 | 24 | 4 | 0.11 | +22 | +5.6 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| DEFENSIVE ARMY | 7 | 7 | 4 | 0.11 | -135 | -33.8 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +34 | +8.6 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +134 | +33.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -396 | -131.8 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +1 | +0.2 |
| JOINT CHARGE PLAN | 9 | 9 | 3 | 0.08 | +136 | +45.3 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +324 | +108.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +278 | +92.6 |
| SAFE SURE CHARGE | 3 | 3 | 3 | 0.08 | -172 | -57.4 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -142 | -70.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 56 | 51 | 2 | 0.06 | +21 | +10.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 7 | 7 | 1 | 0.03 | +47 | +47.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +31 | +31.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +21 | +20.8 |
| HUNT ADVANCE | 6 | 6 | 1 | 0.03 | +29 | +29.1 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 1 | 0.03 | -113 | -112.7 |
| LONG SHOT | 43 | 42 | 1 | 0.03 | +5 | +5.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -25 | -25.0 |
| WAR ENGINE CHARGES | 6 | 6 | 1 | 0.03 | +51 | +50.9 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -42 | -41.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 18 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 32 | 29 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 38 | 38 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 43 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 381 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 33 | 30 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 32 | 32 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 13 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 20 | 20 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 29 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 429 | 429 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2770 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 87 | 87 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 26 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| STABLE ROLE | 784 | 783 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 21 | 20 | 0 | 0.00 | - | - |

### Off best figure: ss-mine-06f55ce-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 11.53 | 13.50 | 40.3 |
| FALLBACK | gate | 0.75 | 1.06 | 43.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.69 | 47.0 |
| TURN GATE | gate | 0.61 | 0.42 | 36.4 |
| PATHS CROSS | rule | 0.39 | 0.25 | 17.7 |
| WAR ENGINE JOBS | rule | 0.42 | 0.06 | 28.1 |
| AFTERMATH BAND | gate | 0.17 | 0.17 | 2.0 |
| SUPPORT REQUEST | gate | 0.14 | 0.19 | 51.1 |
| SUPPORT NARROWED | rule | 0.08 | 0.17 | 16.6 |
| FIGHT ORDER BAND | gate | 0.08 | 0.14 | 1.8 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 11.4 |
| NEARER NOT NEEDED | rule | 0.19 | - | 4.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 5.1 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.06 | 48.6 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 20.9 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 112.7 |
| DEFENSIVE ARMY | rule | 0.11 | - | 33.8 |
| REFUSING RETIRES | rule | 0.06 | 0.06 | 0.9 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 3.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 23.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 52.7 |
| BEST PRIZE | rule | 0.06 | 0.03 | 131.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 42.1 |
| SAFE SURE CHARGE | rule | 0.03 | 0.06 | 57.4 |
| BLOCKED WHEEL | rule | - | 0.06 | 2.8 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 70.9 |
| CHAFF PASSED | rule | - | 0.06 | 3.5 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 7.8 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.6 |
| MARCH ODDS | rule | 0.03 | 0.03 | 16.1 |
| NO REASON | gate | 0.06 | - | 5.0 |
| WHO HITS BACK | rule | 0.03 | 0.03 | 2.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 112.7 |
| REDIRECT WEIGHED | rule | 0.03 | - | 15.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 46.4 |
| STANDS TO CAST | rule | 0.03 | - | 25.0 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 24.3 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 41.6 |

### Plans: ss-mine-06f55ce-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 8.0 | 16% | 152 | 220 | 144% |
| Mine | charge | 3.5 | 56% | 221 | 294 | 133% |
| Mine | close in | 4.5 | 32% | 195 | 133 | 68% |
| Mine | hold | 6.4 | 30% | 358 | 0 | 0% |
| Mine | join | 0.5 | 89% | 11 | 0 | 0% |
| Mine | shoot | 9.6 | 62% | 339 | 689 | 203% |
| Mine | support | 5.5 | 90% | 54 | 0 | 0% |
| Opponent | advance | 11.7 | 12% | 167 | 231 | 138% |
| Opponent | charge | 4.5 | 60% | 353 | 473 | 134% |
| Opponent | close in | 6.4 | 24% | 356 | 207 | 58% |
| Opponent | hold | 4.2 | 24% | 306 | 0 | 0% |
| Opponent | join | 0.5 | 89% | 22 | 0 | 0% |
| Opponent | shoot | 4.1 | 55% | 78 | 191 | 247% |
| Opponent | support | 7.4 | 87% | 55 | 0 | 0% |

### Packages: hunt the guns, ss-mine-06f55ce-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 100% | 0% | 3.0 | 216 | 206 | 100% | 11 |
| Opponent | 0.2 | 7 | 0 | 57% | 57% | 0% | 2.5 | 271 | 126 | 57% | 78 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 4.0 | 109 | 91 | 100% | 94 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 3.0 | 216 | 206 | 100% | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 60% | 60% | 0% | 2.0 | 341 | 158 | 60% | 50 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 85 | 0 | 0% | 55 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ss-mine-06f55ce-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.6 | 37% | 57% | 23% | 38% | 22% | 0% | 4% | 63% | 11% |
| Opponent | REDIRECT COUNTER | 4.1 | 30% | 82% | 23% | 10% | 15% | 3% | 6% | 74% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ss-mine-06f55ce-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | - | 0 (4) | - | - | 0 (4) |
| Mine | Chaff | 34 | 69 (34) | 49 | 20 | 45 | 24% | 3.0 | 33 (14) | 0 (7) | 134 (13) | 68 (22) | 70 (12) |
| Mine | Character | 106 | 47 (106) | 47 | 0 | 33 | 11% | 2.6 | 39 (34) | 57 (54) | 15 (6) | 36 (47) | 60 (47) |
| Mine | Clean-up | 22 | 55 (22) | 8 | 47 | 36 | 41% | 3.4 | 0 (2) | 69 (16) | 38 (4) | 69 (10) | 47 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 65 (4) | 65 | 0 | 46 | 0% | 3.0 | 0 (2) | 131 (2) | - | 0 (3) | 243 (1) |
| Mine | Fast Hammer | 41 | 63 (41) | 40 | 23 | 32 | 24% | 2.6 | 57 (27) | 92 (9) | 39 (5) | 67 (25) | 56 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 2.3 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Mine | Hammer | 65 | 34 (65) | 20 | 13 | 37 | 18% | 2.4 | 41 (13) | 33 (45) | 22 (7) | 34 (40) | 33 (25) |
| Mine | Holder | 31 | 57 (31) | 9 | 48 | 21 | 29% | 2.8 | 29 (6) | 75 (19) | 35 (6) | 72 (16) | 43 (15) |
| Mine | Shooter | 34 | 73 (34) | 38 | 35 | 43 | 0% | 1.5 | 54 (8) | 93 (21) | 20 (5) | 83 (25) | 39 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 41 (56) | 41 | 0 | 63 | 4% | 1.3 | 59 (16) | 39 (30) | 12 (10) | 81 (9) | 34 (47) |
| Mine | Wizard | 17 | 6 (17) | 6 | 0 | 25 | 12% | 2.4 | 12 (6) | 5 (9) | 0 (1) | 16 (8) | 0 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 42 (75) | 22 | 20 | 53 | 39% | 2.8 | 46 (31) | 45 (17) | 36 (27) | 43 (56) | 39 (19) |
| Opponent | Character | 97 | 46 (97) | 46 | 0 | 30 | 23% | 2.5 | 44 (46) | 36 (39) | 129 (6) | 50 (52) | 44 (39) |
| Opponent | Clean-up | 11 | 67 (11) | 25 | 42 | 19 | 36% | 2.7 | 49 (3) | 54 (6) | 124 (2) | 43 (6) | 80 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 41 (60) | 21 | 20 | 40 | 30% | 3.0 | 41 (26) | 42 (25) | 44 (9) | 42 (39) | 41 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 61 | 12% | 2.7 | 0 (4) | 0 (9) | 0 (4) | 0 (14) | 0 (3) |
| Opponent | Hammer | 65 | 35 (65) | 21 | 13 | 48 | 35% | 3.2 | 24 (20) | 38 (38) | 38 (7) | 38 (41) | 30 (24) |
| Opponent | Holder | 29 | 41 (29) | 21 | 20 | 18 | 59% | 3.6 | 47 (11) | 39 (12) | 32 (6) | 57 (15) | 23 (14) |
| Opponent | Shooter | 33 | 61 (33) | 21 | 40 | 42 | 0% | 1.5 | 64 (9) | 61 (21) | 46 (3) | 69 (18) | 53 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 52 | 17% | 3.4 | 0 (3) | 0 (3) | - | 0 (2) | 0 (4) |
| Opponent | War machine | 6 | 60 (6) | 60 | 0 | 21 | 17% | 1.0 | 86 (3) | 22 (3) | - | 86 (3) | 22 (3) |
| Opponent | Wizard | 19 | 17 (19) | 17 | 0 | 28 | 16% | 1.8 | 30 (11) | 0 (3) | 0 (2) | 24 (10) | 9 (6) |

### Charged fights: ss-mine-06f55ce-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 182 | 81 | 1.2 | 1.2 | 65 | 51 | +14 | 0 of 5 | 3 of 5 | +151 | -20 |
| Mine | Chaos Dwarfs | 4 | 166 | 528 | 4.2 | 1.0 | 124 | 7 | +118 | 5 of 17 | 15 of 17 | - | +118 |
| Mine | Dwarfen Mountain Holds | 3 | 459 | 0 | 0.3 | 3.0 | 0 | 756 | -756 | 1 of 1 | 1 of 1 | -756 | - |
| Mine | Empire of Man | 5 | 390 | 30 | 1.2 | 1.0 | 25 | 152 | -127 | 2 of 6 | 3 of 6 | - | -127 |
| Mine | Grand Cathay | 4 | 251 | 162 | 2.5 | 1.2 | 65 | 0 | +65 | 3 of 10 | 9 of 10 | +0 | +81 |
| Mine | High Elf Realms | 4 | 248 | 110 | 2.0 | 1.2 | 55 | 14 | +40 | 1 of 8 | 7 of 8 | +162 | -0 |
| Mine | Kingdom of Bretonnia | 1 | 485 | 777 | 5.0 | 1.0 | 155 | 0 | +155 | 2 of 5 | 4 of 5 | - | +155 |
| Mine | Lizardmen | 1 | 398 | 950 | 5.0 | 1.0 | 190 | 81 | +109 | 3 of 5 | 4 of 5 | - | +109 |
| Mine | Ogre Kingdoms | 2 | 28 | 134 | 4.5 | 1.0 | 30 | 10 | +20 | 2 of 9 | 7 of 9 | - | +20 |
| Mine | Skaven | 2 | 211 | 33 | 2.0 | 1.0 | 16 | 36 | -20 | 1 of 4 | 4 of 4 | - | -20 |
| Mine | Tomb Kings of Khemri | 2 | 200 | 606 | 5.0 | 1.1 | 121 | 20 | +102 | 5 of 10 | 8 of 10 | +116 | +100 |
| Mine | Vampire Counts | 2 | 152 | 132 | 2.5 | 1.2 | 53 | 120 | -67 | 2 of 5 | 2 of 5 | +0 | -84 |
| Mine | Warriors of Chaos | 2 | 0 | 644 | 7.0 | 1.0 | 92 | 50 | +42 | 6 of 14 | 8 of 14 | - | +42 |
| **Mine** | all armies | 36 | 244 | 236 | 2.8 | 1.1 | 86 | 43 | +43 | 33 of 99 | 75 of 99 | -20 | +48 |
| Opponent | Empire of Man | 1 | 555 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 222 | 717 | 5.0 | 1.2 | 143 | 20 | +123 | 15 of 25 | 17 of 25 | +126 | +123 |
| Opponent | Lizardmen | 2 | 0 | 146 | 1.5 | 1.0 | 98 | 47 | +51 | 2 of 3 | 1 of 3 | - | +51 |
| Opponent | Orc & Goblin Tribes | 3 | 78 | 23 | 2.7 | 1.0 | 9 | 32 | -24 | 3 of 8 | 5 of 7 | - | -24 |
| Opponent | Skaven | 4 | 0 | 72 | 3.0 | 1.0 | 24 | 120 | -96 | 7 of 12 | 7 of 12 | - | -96 |
| Opponent | Tomb Kings of Khemri | 2 | 52 | 588 | 4.0 | 1.4 | 147 | 0 | +147 | 2 of 8 | 7 of 8 | +261 | +79 |
| Opponent | Vampire Counts | 6 | 0 | 624 | 4.5 | 1.3 | 139 | 36 | +103 | 19 of 27 | 17 of 27 | +101 | +103 |
| Opponent | Warriors of Chaos | 7 | 0 | 245 | 2.9 | 1.1 | 86 | 10 | +76 | 10 of 20 | 13 of 20 | +288 | +64 |
| Opponent | Wood Elf Realms | 6 | 13 | 404 | 4.7 | 1.2 | 86 | 7 | +80 | 5 of 28 | 20 of 28 | +98 | +74 |
| **Opponent** | all armies | 36 | 58 | 369 | 3.6 | 1.2 | 101 | 28 | +73 | 63 of 131 | 87 of 130 | +133 | +60 |

### Effective charges: ss-mine-06f55ce-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net -42) | 0 | 1 (net +0) | 1 (net +151) | 0 | 1 (net +3) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 17 | 1 (net +500) | 1 (net +0) | 3 (net +42) | 2 (net +117) | 2 (net +15) | 8 (net +139) | 0 | 18% (3 of 17) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -756) | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 6 | 2 (net -206) | 0 | 0 | 2 (net -252) | 0 | 2 (net +76) | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 10 | 1 (net +210) | 0 | 1 (net +175) | 5 (net +13) | 2 (net +20) | 1 (net +160) | 0 | 10% (1 of 10) |
| Mine | High Elf Realms | 8 | 1 (net +0) | 0 | 0 | 1 (net -115) | 3 (net +128) | 2 (net +27) | 1 | 0% (0 of 7) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 1 (net +92) | 0 | 1 (net +145) | 0 | 2 (net +270) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 5 | 2 (net -202) | 0 | 0 | 2 (net +245) | 0 | 0 | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 9 | 0 | 1 (net +55) | 2 (net +51) | 3 (net +0) | 0 | 2 (net +55) | 1 | 25% (2 of 8) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net -20) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +0) | 0 | 3 (net +156) | 4 (net +95) | 1 (net +54) | 0 | 1 | 33% (3 of 9) |
| Mine | Vampire Counts | 5 | 0 | 0 | 2 (net -300) | 1 (net +0) | 0 | 1 (net +105) | 1 | 50% (2 of 4) |
| Mine | Warriors of Chaos | 14 | 1 (net +0) | 0 | 5 (net +105) | 4 (net -4) | 0 | 1 (net +0) | 3 | 45% (5 of 11) |
| Opponent | High Elf Realms | 25 | 4 (net +131) | 0 | 8 (net +38) | 8 (net +186) | 3 (net +105) | 1 (net +280) | 1 | 33% (8 of 24) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +293) | 1 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0 | 5 | 0% (0 of 3) |
| Opponent | Skaven | 12 | 1 (net +0) | 3 (net -301) | 1 (net +0) | 3 (net -167) | 1 (net +0) | 3 (net +83) | 0 | 8% (1 of 12) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 0 | 3 (net +101) | 3 (net +250) | 1 (net +0) | 1 (net +126) | 0 | 38% (3 of 8) |
| Opponent | Vampire Counts | 27 | 7 (net -27) | 0 | 7 (net +136) | 4 (net +226) | 6 (net +54) | 3 (net +258) | 0 | 26% (7 of 27) |
| Opponent | Warriors of Chaos | 20 | 5 (net +3) | 2 (net +42) | 4 (net +92) | 4 (net +44) | 3 (net +65) | 1 (net +674) | 1 | 21% (4 of 19) |
| Opponent | Wood Elf Realms | 28 | 5 (net -11) | 1 (net +0) | 7 (net +75) | 5 (net +76) | 2 (net +72) | 6 (net +201) | 2 | 27% (7 of 26) |

### Charged fights, damage counted: ss-mine-06f55ce-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 200 | 265 | -16 | 88 | 91 | -3 | -1.3 |
| Mine | 50-54% | 3 | 217 | 182 | +49 | 49 | 3 | +46 | +21.3 |
| Mine | Effective (55-75%) | 17 | 288 | 237 | +47 | 116 | 56 | +59 | +20.7 |
| Mine | 76-89% | 26 | 301 | 201 | +32 | 120 | 89 | +31 | +10.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 184 | 161 | +56 | 133 | 59 | +74 | +40.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 401 | 86 | +64 | 66 | 50 | +16 | +4.0 |
| Mine | No odds | 8 | 371 | 156 | +91 | 110 | 19 | +91 | +24.4 |
| Mine | All fights | 99 | 268 | 191 | +43 | 111 | 65 | +47 | +17.4 |
| Opponent | Long shot (under 50%) | 22 | 240 | 308 | +14 | 99 | 97 | +2 | +0.7 |
| Opponent | 50-54% | 7 | 139 | 221 | -117 | 16 | 149 | -134 | -96.4 |
| Opponent | Effective (55-75%) | 31 | 351 | 221 | +79 | 112 | 41 | +71 | +20.1 |
| Opponent | 76-89% | 29 | 311 | 210 | +110 | 162 | 37 | +126 | +40.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 342 | 183 | +225 | 225 | 5 | +220 | +64.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 464 | 91 | +61 | 75 | 11 | +64 | +13.8 |
| Opponent | No odds | 10 | 215 | 151 | -12 | 71 | 43 | +28 | +13.2 |
| Opponent | All fights | 131 | 314 | 207 | +73 | 122 | 47 | +75 | +23.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ss-mine-06f55ce-p4 | move | 376 | 86 (23%) | 59 (16%) | 51 (14%) | 239 (64%) |
| ss-mine-06f55ce-p4 | objective | 396 | 58 (15%) | 43 (11%) | 52 (13%) | 286 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

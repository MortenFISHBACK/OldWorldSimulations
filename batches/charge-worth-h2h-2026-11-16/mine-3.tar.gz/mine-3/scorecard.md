# Doctrine scorecard: cw-h2h-mine-3cc170f-p3

### Scorecard: cw-h2h-mine-3cc170f-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 13 | 4 | 1 | 1 | 1 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 1 | 4 | 1 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 9 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 0 | 4 | 0 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 4 | 1 | 0 | 0 | 0 | 565 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 3 | 2 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | yes | 10 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 763 |
| L0516 | 6 | 1 | Opponent | no | 8 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | 6 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 681 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 5 | 1 | 0 | 0 | 0 | 0 | 617 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 664 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 4 | 1 | 0 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 10 | 2 | 4 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | 3 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 498 |
| L1216 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1327 | 1 | 1 | Opponent | no | 6 | 1 | 3 | 2 | 3 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 72 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 3 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 0 | 6 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 144 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 2 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 50 |
| L2433 | 3 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 287 |
| L2832 | 6 | 1 | Opponent | yes | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 31% | 2.5 | 2.9 | 2.6 | 0.7 | 0.4 | 0.0 | 0.0 | 322.6 |
| **Average** | | | Opponent | 28% | 3.0 | 2.3 | 3.1 | 1.5 | 0.4 | 0.0 | 0.0 | 147.0 |

### KPIs: cw-h2h-mine-3cc170f-p3

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (39 of 171) | 13% (23 of 173) | 18% (62 of 344) |
| Winner chose to follow up after the loser gave ground |  | 99% (77 of 78); on the table 99% | 100% (47 of 47); on the table 100% | 99% (124 of 125); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (10 of 12); on the table 92% | 86% (12 of 14); on the table 86% | 85% (22 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 88% (15 of 17); on the table 94% | 59% (20 of 34); on the table 71% | 69% (35 of 51); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 95% (102 of 107); on the table 97% | 83% (79 of 95); on the table 87% | 90% (181 of 202); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 26% (89 of 342) | 32% (62 of 192) | 28% (151 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (89 of 202) | 44% (62 of 141) | 44% (151 of 343) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (8 of 16) | 51% (29 of 57) | 51% (37 of 73) |
| Points that never fought | lower | 36% (24959 of 68801) | 36% (26235 of 71990) | 36% (51194 of 140791) |
|   infantry points that never fought | lower | 43% (6077 of 14174) | 57% (8124 of 14220) | 50% (14201 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (150 of 272) | 58% (164 of 285) | 56% (314 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.8 uses a game | 83% (20 of 24); 2.1 uses a game | 88% (43 of 49); 2.0 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 50% (3 of 6); 0.1 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (8 of 20); 0.2 uses a game | 43% (6 of 14); 0.2 uses a game | 41% (14 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30374 of 59391) | 50% (31979 of 64043) | 51% (62353 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (16%) | 1.0 (28%) | 2.1 (20%) |
| MARCHED: its unit marched | 1.5 (21%) | 0.9 (24%) | 2.3 (22%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (5%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 2.3 (33%) | 0.9 (24%) | 3.2 (30%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.2 (5%) | 0.2 (2%) |
| GONE: slain | 1.3 (18%) | 0.4 (10%) | 1.6 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.2 | 1.9 | 4.2 | 0.7 | 2.0 |
| not cast | 4.1 | 1.4 | 4.3 | 10.6 | 2.6 | 18.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.8 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 0.8 (54%) | 0.4 (9%) | 2.1 (20%) | 0.3 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (22%) | 0.4 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.2 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (10%) | 0.2 (14%) | 1.0 (23%) | 3.2 (30%) | 0.6 (24%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.2 (30%) | 0.2 (14%) | 1.2 (29%) | 1.6 (15%) | 0.6 (22%) | 3.4 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (2%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.4 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (43%) | 0.2 (12%) | 1.2 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.9 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 63% (26 of 41) | 67% (12 of 18) | 64% (38 of 59) |
| the unit moved after it | 81% (21 of 26) | 58% (7 of 12) | 74% (28 of 38) |
| it charged on its next turn | 4% (1 of 26) | 17% (2 of 12) | 8% (3 of 38) |
| the enemy charged it first | 4% (1 of 26) | 25% (3 of 12) | 11% (4 of 38) |
| it fought by the end of its next turn | 4% (1 of 26) | 8% (1 of 12) | 5% (2 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (5 of 26) | 33% (4 of 12) | 24% (9 of 38) |
| none of these (no charge, no fight, no charge escaped) | 73% (19 of 26) | 25% (3 of 12) | 58% (22 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (496 of 777) | 56% (370 of 656) | 60% (866 of 1433) |
|   cavalry | 67% (37 of 55) | 57% (69 of 121) | 60% (106 of 176) |
|   character | 55% (59 of 107) | 26% (34 of 129) | 39% (93 of 236) |
|   chariot | 47% (43 of 91) | 55% (16 of 29) | 49% (59 of 120) |
|   infantry | 54% (111 of 207) | 64% (178 of 280) | 59% (289 of 487) |
|   monster | 40% (14 of 35) | 20% (1 of 5) | 38% (15 of 40) |
|   war machine | 82% (232 of 282) | 78% (72 of 92) | 81% (304 of 374) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (29%) | 1.5 (19%) | 3.8 (24%) |
| CHARGED: it charged | 1.0 (12%) | 1.6 (20%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (7%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.0 (13%) | 1.9 (23%) | 2.9 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (6%) | 0.5 (6%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (19%) | 1.5 (19%) | 3.0 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (5%) | 0.2 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.1 | 78% | 6.5 pts | 31 pts |
| character | 3.2 | 0.5 | 89% | 3.1 pts | 10 pts |
| chariot | 1.6 | 0.8 | 68% | 11.3 pts | 19 pts |
| infantry | 13.1 | 4.2 | 76% | 9.2 pts | 120 pts |
| monster | 0.5 | 0.1 | 82% | 5.4 pts | 3 pts |
| war machine | 8.8 | 7.9 | 59% | 25.4 pts | 222 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.9 | 5.1 |
| Charges that made contact a game | 3.0 | 3.9 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.23 declared, 1.09 contact (22 units) | 1.11 declared, 0.84 contact (19 units) | 1.17 declared, 0.98 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.00 contact (4 units) | 1.56 declared, 1.11 contact (9 units) | 1.15 declared, 0.77 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.38 contact (224 units) | 0.67 declared, 0.43 contact (266 units) | 0.62 declared, 0.40 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (40 of 77) | 67% (10 of 15) | 30% (3 of 10) | 52% (53 of 102) |
| Character in a unit | 83% (34 of 41) | 67% (8 of 12) | 80% (4 of 5) | 79% (46 of 58) |
| Character on its own | 75% (27 of 36) | 55% (24 of 44) | 27% (19 of 70) | 47% (70 of 150) |
| Chariot | 91% (10 of 11) | 83% (10 of 12) | - | 87% (20 of 23) |
| Infantry | 53% (37 of 70) | 36% (15 of 42) | 20% (1 of 5) | 45% (53 of 117) |
| Monster | 59% (20 of 34) | 57% (4 of 7) | - | 59% (24 of 41) |
| Monstrous | 70% (7 of 10) | 82% (9 of 11) | - | 76% (16 of 21) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (19 of 19); on the table 100% | 32% (31 of 96) | 31% | 50% (11 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (3 of 4); on the table 75% | 36% (13 of 36) | 36% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 62% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 90% (9 of 10); on the table 90% | 47% (14 of 30) | 54% | 63% (37 of 59) | 0.0 uses a game | 50% (1 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 84% (16 of 19); on the table 95% | 23% (45 of 192) | 44% | 53% (39 of 74) | 78% (14 of 18); 5.2 uses a game | 25% (1 of 4); 0.1 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 7 | 94% (16 of 17); on the table 94% | 24% (10 of 42) | 32% | 48% (26 of 54) | 100% (9 of 9); 4.1 uses a game | 50% (6 of 12); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 80% (4 of 5); on the table 80% | - | 39% | 44% (8 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 55% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 100% | 0% (0 of 6) | 54% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (8 of 8); on the table 100% | 8% (1 of 12) | 3% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 67% (4 of 6); on the table 83% | 25% (3 of 12) | 56% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 89% (16 of 18); on the table 94% | 17% (1 of 6) | 29% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (20 of 21); on the table 95% | 30% (16 of 54) | 20% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 84% (41 of 49); on the table 86% | 40% (12 of 30) | 34% | 52% (50 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (14 of 14); on the table 100% | 17% (2 of 12) | 35% | 68% (42 of 62) | 82% (9 of 11); 5.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-mine-3cc170f-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (42) | 45% (34) | 47% (76) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.56 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.19 | 0.53 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.42 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.06 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.69 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.47 | 4.89 | 10.36 |

### Quality by phase: cw-h2h-mine-3cc170f-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 55% (69 of 125) | 45% (87 of 194) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (174 of 361) | 51% (113 of 220) |
| Strategy | Close-in objectives charged next turn | 19% (29 of 155) | 19% (40 of 214) |
| Strategy | Support requests answered (helper made contact too) | 36% (5 of 14) | 36% (8 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 45% (17 of 38) | 34% (15 of 44) |
| Strategy | Lone characters that fought | 73% (71 of 97) | 77% (69 of 90) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 0.7 | 1.5 |
| Movement | Points that never moved of their own | 322.6 | 147.0 |
| Movement | Fights charged into per game | 2.8 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 91, net -50 | 22 of 103, net +2 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 91, net +76 | 12 of 103, net +62 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 91, net +98 | 8 of 103, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 91, net +72 | 37 of 103, net +196 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (117 of 286) | 47% (166 of 352) |
| Shooting | Points destroyed by shooting units | 42.5 | 40.8 |
| Shooting | War machine shots | 6.4 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (122 of 232) | 36% (30 of 83) |
| Shooting | Points destroyed by war machines | 90.8 | 13.1 |
| Magic | Magic missiles cast | 1.6 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (17 of 58) | 32% (13 of 40) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.9 |
| Magic | Wounds caused by other spells | 2.3 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 65.0 | 60.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.6 / 0.1 | 1.9 / 0.3 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 341.2 | 427.1 |
| Combat | Points run down | 84.5 | 134.9 |
| Combat | Net points per charged fight, damage counted | +52 | +86 |
| Combat | Net per 100 charger points, damage counted | +18.8 | +28.1 |
| Combat | First round won (charged fights) | 78% | 69% |
| Combat | Net points per charged fight | +49 | +86 |
| Combat | Net points per supported fight / lone fight | +85 / +45 | +112 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 99 | 59 of 120 |
| Game | Points lost | 793.3 | 656.7 |
| Game | VP from objectives | 489.2 | 557.2 |
| Game | Lone holders (player turns) | 2.5 | 3.0 |

- Mine won / drew / lost: 11 / 10 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -213 VP
- The side that went first won 11 of 26 games with a winner
- Points traded per game (both sides' losses): 1450
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cw-h2h-mine-3cc170f-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 33.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +12.0 | 0.0 | 42.2 | 0.8 | +9.3 | 0.0 | 18.7 |
| BEST FACING | 0.6 | +21.9 | 0.0 | 17.2 | 0.6 | +27.6 | 0.0 | 10.0 |
| BEST FIRST | 4.0 | +198.1 | 116.7 | 117.9 | 3.5 | +178.0 | 153.2 | 56.8 |
| BEST OVERALL | 0.7 | +57.1 | 0.0 | 20.3 | 0.3 | +35.7 | 0.0 | 5.2 |
| BEST PREY | 0.6 | +32.9 | 14.2 | 11.8 | 0.7 | +44.1 | 36.7 | 2.9 |
| BEST PRIZE | 0.1 | -0.2 | 0.8 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | -0.9 | 0.0 | 10.6 | 0.1 | -0.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 14.1 | 0.0 | 0.1 | +0.0 | 2.6 | 0.0 |
| BLOCKED WHEEL | 0.6 | +9.6 | 0.0 | 15.9 | 0.3 | +11.5 | 0.0 | 2.9 |
| BLOWS WHERE AIMED | 0.2 | -15.0 | 3.3 | 5.4 | - | - | - | - |
| BOMBING RUN | 0.0 | +0.6 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 94.8 | 3.6 | 0.2 | +0.0 | 22.4 | 0.0 |
| CANNON PLANNED TARGET | 5.5 | +130.7 | 460.2 | 72.4 | 1.4 | +65.5 | 78.6 | 15.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -9.3 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 28.9 | 2.9 | 0.2 | -2.5 | 31.3 | 3.2 |
| CAST JOB | 0.9 | +32.6 | 63.0 | 12.3 | 0.6 | +21.1 | 33.4 | 22.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +36.4 | 15.6 | 26.8 | 0.1 | +3.4 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 35.4 | 0.4 | +0.0 | 0.0 | 16.4 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.1 | -0.6 | 21.0 | 1.8 |
| CHARGE BAND | 0.2 | +0.0 | 65.3 | 13.7 | - | - | - | - |
| CHARGE NOW FIRST | 1.9 | +0.0 | 147.4 | 35.1 | 3.4 | +0.0 | 349.2 | 88.6 |
| CHARGE NOW WEIGHED | 0.6 | -90.0 | 27.1 | 34.3 | 0.4 | -26.2 | 19.4 | 31.1 |
| CHARGER SLAIN LOST | 0.4 | -15.6 | 52.1 | 18.2 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 1.9 | 0.0 | 0.2 | +0.0 | 8.4 | 3.6 |
| COMBAT PIVOT | 0.4 | +0.0 | 5.5 | 49.4 | 0.6 | +0.0 | 45.6 | 42.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +92.2 | 43.8 | 33.1 | 0.4 | +70.2 | 0.0 | 11.8 |
| COUNTER-CHARGE COVER | 8.8 | +662.7 | 0.0 | 204.1 | 6.7 | +571.8 | 0.0 | 150.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 20.2 | 0.0 | 0.2 | +0.0 | 17.1 | 13.1 |
| DEFENSIVE FLOOR | 0.1 | +5.7 | 11.1 | 1.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +0.9 | 4.6 | 0.0 | 0.2 | +2.1 | 14.6 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +111.9 | 0.0 | 50.8 | 1.1 | +76.5 | 0.0 | 37.1 |
| FALLBACK BY WORTH | 4.6 | +66.1 | 0.0 | 64.7 | 5.1 | +60.7 | 0.0 | 25.0 |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 1.7 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 201.2 | 4.7 | +0.0 | 0.0 | 130.8 |
| FOCUS FIRE | 0.0 | +0.9 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.4 | +185.4 | 0.0 | 56.7 | 1.1 | +166.5 | 0.0 | 36.9 |
| FRIENDS SHOTS CHECKED | 0.1 | +7.5 | 0.0 | 0.0 | 0.2 | +7.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.4 | 2.8 | 0.0 | 0.1 | -2.1 | 0.0 | 9.1 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -0.3 | 6.2 | 1.2 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 16.5 | 6.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 7.1 | 1.1 | 0.3 | +0.0 | 6.0 | 7.5 |
| HILL BY ITS CHANCE | 0.2 | -28.8 | 0.0 | 1.8 | 0.4 | -46.8 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -134.9 | 415.9 | 183.5 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +14.1 | 22.9 | 3.8 | 0.2 | +5.8 | 6.9 | 2.9 |
| HUNT DROPPED | 0.1 | +0.0 | 9.2 | 5.4 | 0.1 | +0.0 | 3.5 | 2.9 |
| HUNT IN PAIRS | 0.3 | +12.5 | 0.0 | 5.4 | 0.6 | +16.6 | 0.0 | 16.2 |
| HUNT KEPT | 0.2 | +4.6 | 9.2 | 0.0 | 0.1 | +3.2 | 6.9 | 2.9 |
| HUNT RESULT | 0.3 | +21.6 | 39.2 | 5.4 | 0.1 | +3.7 | 3.5 | 4.4 |
| HUNT THE GUNS | 0.3 | +116.9 | 43.8 | 8.4 | 0.1 | +47.5 | 0.0 | 2.9 |
| INVITES THE FIGHT | 1.6 | +36.5 | 61.0 | 22.1 | 1.2 | +18.8 | 22.6 | 8.9 |
| JOINT CHARGE PLAN | 0.1 | +5.0 | 9.3 | 12.1 | 0.2 | +5.9 | 9.5 | 6.4 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +1.6 | 0.0 | 7.5 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 147.1 | 52.2 | 2.4 | +72.5 | 264.3 | 37.8 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +81.6 | 119.2 | 25.1 | 2.5 | +126.6 | 175.9 | 39.1 |
| KILLS COUNT NEXT TURN | 5.6 | +193.2 | 242.2 | 162.7 | 7.0 | +222.6 | 246.0 | 108.9 |
| LONE CHARACTER SAFE SPOT | 0.5 | +27.8 | 21.4 | 31.2 | 0.4 | +15.7 | 14.1 | 29.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 2.9 | 0.0 | 0.3 | +0.0 | 0.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +3.2 | 14.2 | 9.2 | 0.3 | +1.7 | 24.6 | 9.9 |
| LOST CHARGE | 2.8 | -44.8 | 127.2 | 101.8 | 2.6 | -29.9 | 108.1 | 75.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.4 | 0.0 | 4.2 | - | - | - | - |
| MAKE SURE TOGETHER | 0.9 | +142.5 | 23.8 | 56.4 | 0.8 | +46.2 | 33.8 | 6.4 |
| MANOEUVRE | 0.1 | +1.9 | 0.0 | 0.0 | 0.2 | +2.5 | 0.0 | 4.2 |
| MARCH AT ESCAPER | 0.2 | +1.9 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +25.6 | 0.0 | 47.9 | 0.8 | +36.6 | 0.0 | 23.3 |
| MARCH ODDS | 0.2 | +11.4 | 9.9 | 0.0 | 0.3 | +15.1 | 4.7 | 3.0 |
| MARCH OVER CASTS | 0.4 | +15.8 | 0.0 | 30.0 | 0.4 | +33.6 | 0.0 | 16.8 |
| MAX FOR POSITIONING | 4.5 | +158.1 | 0.0 | 93.6 | 4.0 | +146.3 | 0.0 | 95.6 |
| MISSILES IN THE MOVE | 3.8 | +135.3 | 0.0 | 120.0 | 3.9 | +82.2 | 0.0 | 90.1 |
| MISSILES NEXT TURN | 5.0 | +92.7 | 0.0 | 157.4 | 5.1 | +60.9 | 0.0 | 110.1 |
| MODEL FACING | 0.1 | +12.2 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 14.8 | 16.1 | 0.2 | +0.0 | 7.6 | 0.0 |
| MOVE AND CAST | 0.4 | +21.9 | 0.0 | 6.9 | 0.4 | +27.2 | 0.0 | 11.5 |
| MOVE SPELL IN RANGE | 0.2 | +9.0 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -36.5 | 0.0 | 97.5 | 0.1 | -3.5 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 24.4 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.1 | +268.6 | 173.6 | 95.6 | 4.9 | +450.6 | 190.7 | 85.2 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +16.0 | 8.6 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -4.0 | 15.4 | 0.0 | 0.4 | -33.4 | 53.6 | 5.2 |
| NOT TURNED | 5.5 | +62.1 | 0.0 | 154.1 | 4.9 | +74.6 | 0.0 | 123.3 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 21.1 | 0.8 | -0.9 | 0.0 | 11.0 |
| OFF BEST | 15.4 | -776.9 | 11.6 | 297.6 | 14.4 | -915.9 | 7.6 | 271.6 |
| OPENS A LANE | 0.1 | +0.1 | 1.5 | 0.0 | 0.1 | +0.2 | 3.6 | 0.0 |
| OPENS UP | 0.2 | +17.8 | 10.4 | 0.0 | 0.1 | +12.2 | 9.8 | 0.0 |
| OVERRUNS AWAY | 0.4 | +4.0 | 51.9 | 9.1 | 0.7 | +5.7 | 105.4 | 26.6 |
| PATHS CROSS | 2.1 | +123.9 | 0.0 | 31.7 | 2.6 | +181.2 | 0.0 | 46.0 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -6.3 | 0.0 | 5.4 |
| PLAN RESULT | 36.2 | +1233.8 | 1435.0 | 1024.8 | 37.1 | +1378.8 | 1471.7 | 872.8 |
| PURSUES BIG PREY | 0.1 | -8.2 | 0.0 | 0.0 | 0.1 | -8.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +4.9 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.4 | +8.3 | 0.0 | 14.2 | 1.6 | +18.0 | 0.0 | 49.4 |
| RANDOM MOVER NO PROMISE | 0.0 | -1.2 | 0.0 | 4.7 | 0.4 | -25.1 | 13.0 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +7.2 | 0.0 | 3.6 | 0.5 | -12.7 | 0.0 | 2.5 |
| REDIRECT COUNTER | 2.1 | +108.6 | 0.0 | 46.1 | 3.4 | +257.4 | 0.0 | 50.1 |
| REDIRECT WEIGHED | 0.3 | +1.6 | 5.3 | 8.8 | 0.5 | +11.2 | 9.6 | 4.9 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.4 | +10.4 | 0.0 | 11.7 | 0.9 | +34.4 | 0.0 | 14.5 |
| RESTRAINS TO SHOOT | 0.1 | +5.3 | 0.0 | 6.3 | 0.0 | +2.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +65.0 | 183.6 | 47.3 | 3.2 | +83.6 | 263.8 | 93.0 |
| SAFER THAN THE JOB | 0.9 | +71.8 | 0.0 | 30.9 | 0.7 | +63.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +0.5 | 0.0 | 0.9 | 0.1 | -6.9 | 0.0 | 1.1 |
| SEARCH SPOT | 2.5 | +110.9 | 0.0 | 67.2 | 2.4 | +123.4 | 0.0 | 23.1 |
| SECOND HUNTER | 0.1 | -1.2 | 19.6 | 1.7 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +76.3 | 0.0 | 40.1 | 0.1 | +21.9 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.2 | +156.1 | 65.2 | 68.4 | 1.5 | +155.4 | 48.1 | 15.6 |
| SET-UP ANY TARGET | 0.3 | +45.9 | 21.1 | 21.1 | 0.2 | +32.0 | 0.0 | 6.5 |
| SET-UP MISSED | 0.1 | +6.5 | 12.1 | 0.0 | 0.1 | +16.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +44.2 | 7.3 | 5.2 | 0.7 | +28.8 | 54.3 | 6.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 120.8 | 20.0 | 0.2 | +0.0 | 87.4 | 1.8 |
| SHOTS IN THE MOVE | 13.3 | +506.6 | 0.0 | 249.7 | 9.4 | +371.1 | 0.0 | 122.6 |
| SPELL SETS UP CHARGE | 0.5 | +90.7 | 43.8 | 33.1 | 0.2 | +32.0 | 0.0 | 6.5 |
| SPELL WORTH | 1.2 | +21.9 | 62.7 | 72.4 | 2.4 | +33.8 | 76.6 | 66.3 |
| SPELLS IN THE FIGHT | 0.7 | -8.0 | 81.3 | 29.6 | - | - | - | - |
| STABLE ROLE | 10.2 | +0.0 | 350.6 | 175.2 | 8.6 | +0.0 | 356.1 | 99.6 |
| STANDS TO CAST | 0.1 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +2.0 | 30.0 | 4.6 | 0.1 | +1.7 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +25.8 | 0.0 | 21.6 | 0.2 | +21.1 | 0.0 | 1.7 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.6 |
| SUPPORT NARROWED | 5.3 | -44.1 | 262.6 | 103.6 | 6.2 | -36.9 | 386.1 | 106.2 |
| SUPPORTS | 3.7 | +52.2 | 149.8 | 61.0 | 3.7 | +42.1 | 195.4 | 52.1 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -7.6 | 23.0 | 15.1 | 0.1 | -1.4 | 6.3 | 3.8 |
| SURE REACH TOGETHER | 0.5 | +2.9 | 7.9 | 25.4 | 0.5 | +1.0 | 0.0 | 4.0 |
| THROUGH LINE OF FIRE | 0.4 | +12.2 | 0.0 | 20.5 | 0.3 | +18.8 | 0.0 | 0.5 |
| TURN WORTH | 0.3 | -20.0 | 17.4 | 0.0 | 0.4 | -35.7 | 26.5 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +4.1 | 13.9 | 5.7 | 0.5 | +4.6 | 28.5 | 5.2 |
| WAIT AFTER COSTS | 6.7 | -351.1 | 280.2 | 146.7 | 7.5 | -421.0 | 247.9 | 119.7 |
| WALKS TO THE FIGHT | 1.4 | +21.3 | 13.8 | 16.1 | 1.0 | +17.4 | 22.3 | 9.3 |
| WAR ENGINE CHARGES | 0.1 | +10.4 | 0.0 | 17.2 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 43.1 | 15.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.0 | +45.8 | 86.8 | 53.4 | 1.3 | +54.3 | 165.7 | 72.6 |
| WHO HITS BACK | 0.3 | +15.6 | 0.0 | 0.0 | 0.2 | +19.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +14.9 | 16.7 | 26.0 | 0.6 | +26.0 | 75.4 | 11.8 |
| WHOLE FIGHT GAIN | 0.2 | +16.4 | 24.1 | 4.2 | 0.4 | +33.9 | 46.8 | 11.8 |
| WIDER SPREAD | 2.4 | -6.4 | 186.2 | 70.8 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 1.7 | 0.0 | 0.1 | +0.0 | 8.7 | 1.9 |

### Rule changes: cw-h2h-mine-3cc170f-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1074 | 1074 | 1074 | 29.83 | -60939 | -56.7 |
| BEST FIRST | 268 | 268 | 268 | 7.44 | +13538 | +50.5 |
| SEARCH SPOT | 177 | 177 | 177 | 4.92 | +8435 | +47.7 |
| PATHS CROSS | 170 | 170 | 170 | 4.72 | +10983 | +64.6 |
| MOVE TO CHARGE | 287 | 287 | 161 | 4.47 | +12254 | +76.1 |
| KILLS COUNT NEXT TURN | 455 | 455 | 128 | 3.56 | +3221 | +25.2 |
| COUNTER-CHARGE COVER | 557 | 292 | 122 | 3.39 | +6632 | +54.4 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +6785 | +68.5 |
| FOLLOW UP WEIGHED | 90 | 90 | 90 | 2.50 | +12667 | +140.7 |
| FALLBACK BY WORTH | 347 | 347 | 88 | 2.44 | +4565 | +51.9 |
| SUPPORTS | 266 | 266 | 88 | 2.44 | +763 | +8.7 |
| ARTILLERY RE-ROLL WEIGHED | 77 | 77 | 77 | 2.14 | +0 | +0.0 |
| WAIT AFTER COSTS | 511 | 511 | 70 | 1.94 | +1494 | +21.3 |
| SHOTS IN THE MOVE | 818 | 539 | 63 | 1.75 | +3176 | +50.4 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +4855 | +83.7 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MAX FOR POSITIONING | 307 | 172 | 53 | 1.47 | +539 | +10.2 |
| WALKS TO THE FIGHT | 86 | 86 | 48 | 1.33 | +621 | +12.9 |
| MISSILES IN THE MOVE | 278 | 157 | 47 | 1.31 | +1185 | +25.2 |
| CANNON PLANNED TARGET | 250 | 250 | 46 | 1.28 | -369 | -8.0 |
| RESERVE FALL BACK | 46 | 46 | 46 | 1.28 | +1612 | +35.0 |
| CHARGE NOW FIRST | 188 | 188 | 43 | 1.19 | -4070 | -94.6 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +1781 | +42.4 |
| MARCH CHECK | 54 | 49 | 42 | 1.17 | +2793 | +66.5 |
| REDIRECT COUNTER | 197 | 109 | 42 | 1.17 | +2521 | +60.0 |
| SET UP TOGETHER | 97 | 86 | 41 | 1.14 | +3382 | +82.5 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +3123 | +82.2 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 73 | 73 | 37 | 1.03 | +949 | +25.6 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +3340 | +92.8 |
| CAST JOB | 54 | 54 | 36 | 1.00 | +901 | +25.0 |
| KILLS COUNT | 148 | 145 | 36 | 1.00 | +1303 | +36.2 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| BLOCKED WHEEL | 32 | 32 | 32 | 0.89 | +759 | +23.7 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| RISK BY ARC | 190 | 185 | 31 | 0.86 | +799 | +25.8 |
| REDIRECT WEIGHED | 30 | 30 | 30 | 0.83 | +1209 | +40.3 |
| KEEPS ITS TARGET | 151 | 149 | 28 | 0.78 | +532 | +19.0 |
| MOVE AND CAST | 28 | 28 | 28 | 0.78 | +1768 | +63.1 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1116 | +39.9 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1687 | +62.5 |
| SHOOTS FROM THE BEST SPOT | 48 | 48 | 26 | 0.72 | +1050 | +40.4 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| INVITES THE FIGHT | 101 | 101 | 23 | 0.64 | +343 | +14.9 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +837 | +44.0 |
| MAKE SURE TOGETHER | 61 | 46 | 18 | 0.50 | +1192 | +66.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| MARCH ODDS | 17 | 17 | 16 | 0.44 | +293 | +18.3 |
| CASTING BLOCK | 16 | 16 | 15 | 0.42 | +647 | +43.2 |
| LOST CHARGE | 196 | 196 | 15 | 0.42 | +221 | +14.7 |
| BEST PREY | 49 | 49 | 14 | 0.39 | +473 | +33.8 |
| HONEST WORTH | 278 | 275 | 14 | 0.39 | +193 | +13.8 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -27 | -2.1 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -45 | -3.8 |
| WEARS DOWN | 83 | 81 | 12 | 0.33 | +526 | +43.8 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +550 | +50.0 |
| MANOEUVRE | 11 | 11 | 10 | 0.28 | +159 | +15.9 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -324 | -32.4 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT | 34 | 33 | 9 | 0.25 | +398 | +44.3 |
| OPENS UP | 12 | 12 | 8 | 0.22 | +554 | +69.2 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -257 | -32.1 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -605 | -75.6 |
| WAR ENGINE JOBS | 26 | 26 | 8 | 0.22 | -346 | -43.3 |
| CHARGE BAND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| WHOLE FIGHT GAIN | 20 | 18 | 7 | 0.19 | +546 | +78.0 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +196 | +32.7 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +194 | +38.8 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 5 | 0.14 | -384 | -76.9 |
| MISSILES NEXT TURN | 362 | 198 | 5 | 0.14 | +5 | +0.9 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +267 | +53.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BACKUP TARGETS | 66 | 29 | 4 | 0.11 | +18 | +4.5 |
| HUNT IN PAIRS | 32 | 18 | 4 | 0.11 | +95 | +23.8 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +88 | +21.9 |
| SUPPORT NARROWED | 412 | 412 | 4 | 0.11 | -47 | -11.7 |
| CARRIES OUT COUNTER | 6 | 6 | 3 | 0.08 | -291 | -97.0 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 12 | 12 | 3 | 0.08 | +24 | +8.0 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +440 | +146.8 |
| OVERRUNS AWAY | 39 | 38 | 3 | 0.08 | +44 | +14.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -66 | -33.2 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -229 | -114.4 |
| DEFENSIVE ARMY | 13 | 13 | 2 | 0.06 | -118 | -58.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +74 | +37.0 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +46 | +23.2 |
| MOVE SPELL IN RANGE | 9 | 8 | 2 | 0.06 | +12 | +6.2 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 24 | 24 | 2 | 0.06 | +308 | +153.8 |
| SPELLS IN THE FIGHT | 26 | 23 | 2 | 0.06 | +29 | +14.4 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +28 | +14.0 |
| SURE REACH TOGETHER | 35 | 26 | 2 | 0.06 | +6 | +2.9 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +114 | +56.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +22 | +22.1 |
| CARRIES OUT SET-UP | 12 | 12 | 1 | 0.03 | -92 | -91.7 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.8 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +141 | +141.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +11 | +10.8 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 24 | 24 | 1 | 0.03 | +20 | +20.4 |
| OPENS A LANE | 5 | 2 | 1 | 0.03 | +2 | +1.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +154 | +153.8 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.03 | -1 | -0.6 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 1 | 0.03 | +3 | +3.4 |
| STOPS | 6 | 6 | 1 | 0.03 | +24 | +24.3 |
| TWO OR MORE ARRIVE | 31 | 31 | 1 | 0.03 | +1 | +0.8 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 14 | 11 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 376 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 15 | 15 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 17 | 17 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 16 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 31 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 373 | 373 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| PLAN RESULT | 2636 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| STABLE ROLE | 677 | 677 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |
| WIDER SPREAD | 87 | 81 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-mine-3cc170f-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.47 | 12.97 | 58.2 |
| FALLBACK | gate | 0.72 | 0.69 | 51.2 |
| CHARGE NOW FIRST | rule | 0.50 | 0.67 | 96.9 |
| TURN GATE | gate | 0.61 | 0.39 | 34.5 |
| PATHS CROSS | rule | 0.17 | 0.14 | 38.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.22 | 0.06 | 32.4 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.03 | 77.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.06 | 60.0 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 32.1 |
| PURSUES BIG PREY | rule | 0.08 | 0.14 | 75.6 |
| SUPPORT REQUEST | gate | 0.14 | 0.08 | 99.5 |
| WAR ENGINE JOBS | rule | 0.17 | 0.06 | 43.3 |
| AFTERMATH BAND | gate | 0.08 | 0.11 | 2.1 |
| CHAFF PASSED | rule | 0.08 | 0.11 | 3.9 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 78.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 63.6 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 2.4 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.11 | 76.9 |
| SUPPORT NARROWED | rule | 0.03 | 0.08 | 11.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.03 | 18.4 |
| BLOCKED WHEEL | rule | - | 0.08 | 21.2 |
| MARCH ODDS | rule | 0.06 | 0.03 | 15.1 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 4.1 |
| BEST PRIZE | rule | 0.06 | - | 33.2 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 166.5 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 114.4 |
| DEFENSIVE ARMY | rule | - | 0.06 | 58.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 11.2 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 91.7 |
| CATCH ODDS | rule | 0.03 | - | 1.8 |
| REDIRECT WEIGHED | rule | 0.03 | - | 23.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |
| RULE SWITCHED OFF | gate | - | 0.03 | 2.8 |
| STANDS TO CAST | rule | 0.03 | - | 8.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 32.9 |
| WHO HITS BACK | rule | - | 0.03 | 3.7 |

### Plans: cw-h2h-mine-3cc170f-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 18% | 437 | 263 | 60% |
| Mine | charge | 2.8 | 61% | 250 | 234 | 94% |
| Mine | close in | 4.3 | 33% | 311 | 145 | 47% |
| Mine | hold | 4.3 | 32% | 261 | 0 | 0% |
| Mine | join | 0.4 | 100% | 11 | 0 | 0% |
| Mine | shoot | 8.6 | 59% | 240 | 591 | 246% |
| Mine | support | 4.0 | 90% | 47 | 0 | 0% |
| Opponent | advance | 12.7 | 16% | 384 | 312 | 81% |
| Opponent | charge | 4.5 | 53% | 552 | 430 | 78% |
| Opponent | close in | 5.9 | 29% | 470 | 174 | 37% |
| Opponent | hold | 3.6 | 31% | 259 | 0 | 0% |
| Opponent | join | 1.0 | 92% | 40 | 0 | 0% |
| Opponent | shoot | 5.2 | 62% | 171 | 462 | 270% |
| Opponent | support | 4.2 | 85% | 33 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-mine-3cc170f-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 11 | 0 | 0% | 27% | 0% | 2.7 | 383 | 71 | 18% | 17 |
| Opponent | 0.1 | 5 | 0 | 20% | 20% | 20% | 5.0 | 342 | 27 | 0% | 100 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.8 | 7 | 0 | 0% | 43% | 0% | 2.7 | 359 | 111 | 29% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Dwarfen Mountain Holds | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 551 | 0 | 0% | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 375 | 0 | 0% | 65 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 165 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 249 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 220 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 100% | - | 441 | 9 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 5.0 | 363 | 62 | 0% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 0% | 0% | - | 271 | 0 | 0% | 144 |

### Battle groups: cw-h2h-mine-3cc170f-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.8 | 25% | 51% | 19% | 60% | 34% | 15% | 11% | 40% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 28% | 71% | 29% | 17% | 20% | 7% | 7% | 60% | 7% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 21% | 59% | 25% | 38% | 29% | 11% | 11% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 29% | 83% | 23% | 12% | 22% | 4% | 11% | 59% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-mine-3cc170f-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 133 (1) | 133 | 0 | 0 | 0% | 5.0 | - | 133 (1) | - | 133 (1) | - |
| Mine | Chaff | 34 | 45 (34) | 23 | 22 | 73 | 18% | 3.2 | 65 (21) | 6 (4) | 6 (9) | 66 (24) | 0 (10) |
| Mine | Character | 118 | 47 (118) | 47 | 0 | 40 | 20% | 2.2 | 67 (38) | 45 (51) | 21 (9) | 60 (56) | 42 (42) |
| Mine | Clean-up | 20 | 53 (20) | 24 | 29 | 35 | 30% | 2.9 | 36 (5) | 59 (13) | 94 (2) | 63 (14) | 32 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 30 (44) | 16 | 14 | 49 | 27% | 3.0 | 19 (22) | 38 (14) | 44 (8) | 40 (30) | 13 (14) |
| Mine | Fragile | 3 | 5 (3) | 5 | 0 | 100 | 33% | 5.5 | 5 (3) | - | - | 15 (1) | 0 (2) |
| Mine | Hammer | 50 | 28 (50) | 21 | 8 | 53 | 16% | 2.5 | 13 (12) | 30 (35) | 57 (3) | 38 (34) | 10 (16) |
| Mine | Holder | 25 | 69 (25) | 13 | 56 | 14 | 48% | 3.3 | 62 (7) | 64 (13) | 101 (5) | 108 (13) | 27 (12) |
| Mine | Shooter | 37 | 47 (37) | 27 | 20 | 49 | 11% | 1.8 | 32 (6) | 54 (28) | 7 (3) | 43 (23) | 53 (14) |
| Mine | Support | 4 | 80 (4) | 80 | 0 | 0 | 25% | 2.0 | 0 (1) | 139 (3) | - | 0 (1) | 139 (3) |
| Mine | War machine | 52 | 55 (52) | 55 | 0 | 34 | 2% | 1.1 | 58 (13) | 59 (36) | 0 (3) | 54 (13) | 56 (39) |
| Mine | Wizard | 17 | 11 (17) | 11 | 0 | 54 | 18% | 2.1 | 14 (4) | 0 (6) | 80 (1) | 21 (6) | 12 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 40 (68) | 19 | 22 | 60 | 35% | 2.8 | 51 (29) | 36 (11) | 34 (28) | 40 (48) | 41 (20) |
| Opponent | Character | 101 | 62 (101) | 62 | 0 | 30 | 21% | 2.1 | 45 (37) | 86 (50) | 0 (5) | 61 (54) | 73 (38) |
| Opponent | Clean-up | 9 | 44 (9) | 11 | 34 | 42 | 56% | 3.2 | 0 (3) | 47 (5) | 167 (1) | 43 (5) | 45 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 41 (60) | 23 | 18 | 35 | 23% | 2.6 | 32 (30) | 37 (20) | 78 (10) | 43 (28) | 38 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 43 (50) | 31 | 11 | 39 | 26% | 3.2 | 22 (17) | 49 (30) | 60 (3) | 51 (30) | 29 (20) |
| Opponent | Holder | 42 | 77 (42) | 12 | 65 | 23 | 40% | 2.8 | 14 (9) | 119 (22) | 49 (10) | 97 (27) | 49 (14) |
| Opponent | Shooter | 27 | 70 (27) | 48 | 22 | 41 | 0% | 1.1 | 62 (6) | 70 (19) | 101 (2) | 93 (16) | 40 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 33 | 75% | 5.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 17 | 30 (17) | 30 | 0 | 36 | 0% | 1.4 | 74 (3) | 9 (10) | 51 (4) | 0 (3) | 35 (14) |
| Opponent | Wizard | 33 | 25 (33) | 25 | 0 | 26 | 18% | 2.3 | 0 (13) | 69 (12) | 0 (2) | 8 (14) | 56 (13) |

### Charged fights: cw-h2h-mine-3cc170f-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 114 | 77 | 1.0 | 1.0 | 77 | 8 | +69 | 0 of 4 | 3 of 4 | - | +69 |
| Mine | Chaos Dwarfs | 4 | 78 | 160 | 2.2 | 1.0 | 71 | 47 | +25 | 4 of 9 | 7 of 9 | - | +25 |
| Mine | Dwarfen Mountain Holds | 3 | 485 | 35 | 1.7 | 1.2 | 21 | 71 | -50 | 1 of 5 | 2 of 5 | -293 | +11 |
| Mine | Empire of Man | 5 | 362 | 60 | 1.2 | 1.0 | 50 | 13 | +38 | 2 of 6 | 4 of 6 | - | +38 |
| Mine | Grand Cathay | 5 | 384 | 324 | 4.0 | 1.1 | 81 | 0 | +81 | 3 of 20 | 19 of 20 | +110 | +76 |
| Mine | High Elf Realms | 4 | 136 | 333 | 2.8 | 1.5 | 121 | 23 | +98 | 4 of 11 | 8 of 11 | +187 | +64 |
| Mine | Kingdom of Bretonnia | 1 | 505 | 234 | 2.0 | 1.0 | 117 | 0 | +117 | 0 of 2 | 1 of 2 | - | +117 |
| Mine | Lizardmen | 1 | 0 | 314 | 3.0 | 1.0 | 105 | 28 | +77 | 0 of 3 | 3 of 3 | - | +77 |
| Mine | Ogre Kingdoms | 1 | 116 | 264 | 3.0 | 1.0 | 88 | 13 | +75 | 0 of 3 | 3 of 3 | - | +75 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 137 | 5.0 | 1.0 | 27 | 33 | -6 | 3 of 5 | 3 of 5 | - | -6 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.5 | 10 | 32 | -23 | 0 of 2 | 1 of 2 | +19 | -65 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 420 | 4.5 | 1.0 | 93 | 0 | +93 | 3 of 9 | 8 of 9 | - | +93 |
| Mine | Vampire Counts | 2 | 0 | 289 | 4.5 | 1.1 | 64 | 99 | -35 | 4 of 9 | 7 of 9 | +236 | -68 |
| Mine | Warriors of Chaos | 2 | 10 | 692 | 5.5 | 1.1 | 126 | 75 | +50 | 2 of 11 | 8 of 11 | +0 | +55 |
| **Mine** | all armies | 36 | 198 | 224 | 2.8 | 1.1 | 82 | 32 | +49 | 26 of 99 | 77 of 99 | +85 | +45 |
| Opponent | Empire of Man | 1 | 490 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 239 | 532 | 3.7 | 1.4 | 145 | 31 | +114 | 4 of 11 | 10 of 11 | +154 | +99 |
| Opponent | High Elf Realms | 3 | 600 | 366 | 3.7 | 1.0 | 100 | 32 | +68 | 7 of 11 | 8 of 11 | - | +68 |
| Opponent | Kingdom of Bretonnia | 2 | 32 | 578 | 3.5 | 1.1 | 165 | 40 | +125 | 5 of 7 | 5 of 7 | +434 | +74 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 176 | 3.0 | 1.0 | 59 | 18 | +40 | 1 of 3 | 2 of 3 | - | +40 |
| Opponent | Skaven | 1 | 105 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 127 | 736 | 3.5 | 1.0 | 210 | 14 | +196 | 11 of 14 | 9 of 14 | - | +196 |
| Opponent | Vampire Counts | 6 | 14 | 524 | 4.3 | 1.2 | 121 | 45 | +76 | 12 of 26 | 17 of 26 | +306 | +34 |
| Opponent | Warriors of Chaos | 9 | 0 | 464 | 2.9 | 1.2 | 161 | 75 | +86 | 14 of 26 | 18 of 26 | -109 | +133 |
| Opponent | Wood Elf Realms | 6 | 58 | 258 | 3.3 | 1.1 | 77 | 62 | +15 | 5 of 20 | 12 of 20 | +0 | +16 |
| **Opponent** | all armies | 36 | 114 | 440 | 3.3 | 1.1 | 132 | 47 | +86 | 59 of 120 | 83 of 120 | +112 | +82 |

### Effective charges: cw-h2h-mine-3cc170f-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +15) | 0 | 0 | 1 (net +162) | 0 | 1 (net +40) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 9 | 1 (net +0) | 0 | 0 | 4 (net +4) | 0 | 3 (net +15) | 1 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 1 (net +104) | 0 | 2 (net -176) | 0 | 1 (net +0) | 1 | 0% (0 of 4) |
| Mine | Empire of Man | 6 | 1 (net +0) | 0 | 0 | 1 (net -32) | 0 | 4 (net +64) | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 20 | 0 | 2 (net +142) | 7 (net +67) | 2 (net +36) | 5 (net +77) | 3 (net +78) | 1 | 37% (7 of 19) |
| Mine | High Elf Realms | 11 | 1 (net -115) | 0 | 2 (net +258) | 2 (net +0) | 3 (net +187) | 2 (net +58) | 1 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 1 (net +234) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +144) | 1 (net +170) | 1 (net -83) | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 3 | 1 (net -40) | 0 | 0 | 0 | 0 | 1 (net +144) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +68) | 2 | 0% (0 of 3) |
| Mine | Skaven | 2 | 1 (net -65) | 0 | 0 | 0 | 1 (net +19) | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 2 (net +195) | 4 (net +62) | 2 (net +68) | 1 (net +66) | 0 | 22% (2 of 9) |
| Mine | Vampire Counts | 9 | 1 (net -60) | 1 (net +0) | 2 (net -164) | 1 (net -500) | 1 (net +0) | 3 (net +193) | 0 | 22% (2 of 9) |
| Mine | Warriors of Chaos | 11 | 2 (net -143) | 0 | 4 (net +60) | 1 (net +258) | 0 | 4 (net +85) | 0 | 36% (4 of 11) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 11 | 1 (net -205) | 0 | 1 (net +170) | 5 (net +107) | 3 (net +53) | 1 (net +597) | 0 | 9% (1 of 11) |
| Opponent | High Elf Realms | 11 | 1 (net +0) | 2 (net +0) | 2 (net -174) | 1 (net +421) | 1 (net +125) | 3 (net +172) | 1 | 20% (2 of 10) |
| Opponent | Kingdom of Bretonnia | 7 | 3 (net +37) | 0 | 0 | 2 (net +82) | 0 | 2 (net +301) | 0 | 0% (0 of 7) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +176) | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 14 | 4 (net +20) | 0 | 0 | 2 (net +0) | 0 | 5 (net +312) | 3 | 0% (0 of 11) |
| Opponent | Vampire Counts | 26 | 7 (net +85) | 1 (net +95) | 5 (net -8) | 6 (net +3) | 3 (net +94) | 3 (net +286) | 1 | 20% (5 of 25) |
| Opponent | Warriors of Chaos | 26 | 4 (net -206) | 1 (net +0) | 2 (net +450) | 3 (net +0) | 0 | 14 (net +178) | 2 | 8% (2 of 24) |
| Opponent | Wood Elf Realms | 20 | 2 (net +146) | 0 | 2 (net +32) | 1 (net +0) | 1 (net -236) | 6 (net +74) | 8 | 17% (2 of 12) |

### Charged fights, damage counted: cw-h2h-mine-3cc170f-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 123 | 244 | -50 | 16 | 83 | -68 | -55.1 |
| Mine | 50-54% | 4 | 166 | 210 | +97 | 126 | 35 | +91 | +54.7 |
| Mine | Effective (55-75%) | 17 | 299 | 227 | +76 | 133 | 47 | +86 | +28.7 |
| Mine | 76-89% | 20 | 286 | 165 | +12 | 93 | 71 | +23 | +7.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 226 | 153 | +72 | 121 | 44 | +77 | +34.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 476 | 87 | +98 | 106 | 1 | +105 | +22.0 |
| Mine | No odds | 8 | 284 | 196 | +44 | 72 | 47 | +25 | +8.9 |
| Mine | All fights | 99 | 274 | 175 | +49 | 100 | 48 | +52 | +18.8 |
| Opponent | Long shot (under 50%) | 22 | 237 | 251 | +2 | 120 | 124 | -3 | -1.4 |
| Opponent | 50-54% | 4 | 292 | 272 | +24 | 25 | 42 | -17 | -5.7 |
| Opponent | Effective (55-75%) | 12 | 317 | 290 | +62 | 164 | 86 | +78 | +24.6 |
| Opponent | 76-89% | 20 | 332 | 256 | +57 | 104 | 40 | +65 | +19.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 341 | 213 | +196 | 239 | 42 | +197 | +57.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 513 | 90 | +42 | 74 | 35 | +38 | +7.4 |
| Opponent | No odds | 17 | 202 | 212 | +38 | 113 | 71 | +42 | +20.8 |
| Opponent | All fights | 120 | 308 | 228 | +86 | 151 | 65 | +86 | +28.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-mine-3cc170f-p3 | move | 436 | 105 (24%) | 76 (17%) | 50 (11%) | 281 (64%) |
| cw-h2h-mine-3cc170f-p3 | objective | 369 | 68 (18%) | 49 (13%) | 50 (14%) | 251 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

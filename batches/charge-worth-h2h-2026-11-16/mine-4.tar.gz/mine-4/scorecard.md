# Doctrine scorecard: cw-h2h-mine-3cc170f-p4

### Scorecard: cw-h2h-mine-3cc170f-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 10 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 3 | 4 | 1 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 98 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 720 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 4 | 0 | 0 | 2 | 0 | 0 | 452 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 1 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | no | 8 | 3 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 715 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 6 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 3 | 4 | 5 | 0 | 1 | 0 | 0 | 49 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 4 | 0 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | yes | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 427 |
| L1126 | 4 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 2 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 0 | 5 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 4 | 5 | 1 | 1 | 0 | 0 | 245 |
| L1621 | 1 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 307 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 420 |
| L1719 | 3 | 1 | Mine | yes | 2 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 1 | 2 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 3 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 185 |
| L2331 | 3 | 1 | Opponent | yes | 2 | - | 2 | 2 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 1.7 | 2.7 | 2.2 | 0.9 | 0.3 | 0.0 | 0.0 | 294.2 |
| **Average** | | | Opponent | 39% | 2.5 | 2.2 | 3.2 | 1.9 | 0.5 | 0.0 | 0.0 | 92.2 |

### KPIs: cw-h2h-mine-3cc170f-p4

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (43 of 173) | 1% (2 of 190) | 12% (45 of 363) |
| Winner chose to follow up after the loser gave ground |  | 98% (54 of 55); on the table 98% | 100% (66 of 66); on the table 100% | 99% (120 of 121); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (11 of 11); on the table 100% | 82% (9 of 11); on the table 82% | 91% (20 of 22); on the table 91% |
| Winner chose to pursue after the loser fled |  | 78% (21 of 27); on the table 81% | 78% (25 of 32); on the table 84% | 78% (46 of 59); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 92% (86 of 93); on the table 94% | 92% (100 of 109); on the table 94% | 92% (186 of 202); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 36% (94 of 262) | 33% (58 of 177) | 35% (152 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (88 of 186) | 46% (58 of 126) | 47% (146 of 312) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (21 of 40) | 52% (32 of 62) | 52% (53 of 102) |
| Points that never fought | lower | 32% (21663 of 67942) | 33% (23493 of 71984) | 32% (45156 of 139926) |
|   infantry points that never fought | lower | 37% (5701 of 15347) | 51% (7012 of 13804) | 44% (12713 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (158 of 270) | 56% (158 of 280) | 57% (316 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.7 uses a game | 89% (8 of 9); 0.6 uses a game | 87% (27 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.5 uses a game | 45% (9 of 20); 0.3 uses a game | 53% (19 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 73% (11 of 15); 0.3 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (30715 of 57750) | 48% (30264 of 63347) | 50% (60979 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (23%) | 0.8 (25%) | 1.9 (24%) |
| MARCHED: its unit marched | 1.3 (29%) | 0.5 (14%) | 1.8 (23%) |
| CHARGED: its unit charged | 0.2 (5%) | 0.2 (8%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 1.3 (28%) | 0.4 (13%) | 1.7 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) |
| FLEEING: fleeing | 0.2 (4%) | 0.2 (7%) | 0.4 (5%) |
| GONE: slain | 0.5 (10%) | 0.8 (24%) | 1.2 (16%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.2 | 2.1 | 4.2 | 0.3 | 2.3 |
| not cast | 3.0 | 2.7 | 2.8 | 8.0 | 1.7 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (46%) | 0.2 (9%) | 1.9 (24%) | 0.5 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (23%) | 0.5 (28%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.2 (6%) | 0.6 (21%) | 1.7 (22%) | 0.4 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.1 (3%) | 0.2 (9%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (8%) | 0.1 (4%) | 0.0 (0%) | 0.4 (5%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.7 (22%) | 0.5 (20%) | 0.6 (22%) | 1.2 (16%) | 0.1 (3%) | 3.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.0 (1%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (9%) | 0.0 (1%) | 0.1 (1%) | 0.2 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (51%) | 0.2 (9%) | 0.9 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.8 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 61% (30 of 49) | 50% (6 of 12) | 59% (36 of 61) |
| the unit moved after it | 80% (24 of 30) | 83% (5 of 6) | 81% (29 of 36) |
| it charged on its next turn | 0% (0 of 30) | 0% (0 of 6) | 0% (0 of 36) |
| the enemy charged it first | 27% (8 of 30) | 17% (1 of 6) | 25% (9 of 36) |
| it fought by the end of its next turn | 33% (10 of 30) | 17% (1 of 6) | 31% (11 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (7 of 30) | 17% (1 of 6) | 22% (8 of 36) |
| none of these (no charge, no fight, no charge escaped) | 47% (14 of 30) | 50% (3 of 6) | 47% (17 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (580 of 884) | 50% (271 of 543) | 60% (851 of 1427) |
|   cavalry | 65% (50 of 77) | 68% (83 of 122) | 67% (133 of 199) |
|   character | 44% (44 of 101) | 15% (19 of 131) | 27% (63 of 232) |
|   chariot | 50% (52 of 105) | 58% (14 of 24) | 51% (66 of 129) |
|   infantry | 62% (168 of 269) | 60% (128 of 214) | 61% (296 of 483) |
|   monster | 50% (23 of 46) | 19% (5 of 26) | 39% (28 of 72) |
|   war machine | 85% (243 of 286) | 85% (22 of 26) | 85% (265 of 312) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (22%) | 1.4 (19%) | 3.3 (20%) |
| CHARGED: it charged | 0.9 (11%) | 1.7 (22%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.4 (6%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (22%) | 1.7 (22%) | 3.6 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (7%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.6 (21%) | 3.1 (20%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (2%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.7 | 77% | 6.4 pts | 38 pts |
| character | 2.0 | 0.8 | 74% | 10.9 pts | 22 pts |
| chariot | 1.8 | 0.8 | 71% | 11.6 pts | 21 pts |
| infantry | 11.7 | 3.9 | 75% | 10.1 pts | 119 pts |
| monster | 0.9 | 0.1 | 97% | 1.1 pts | 1 pts |
| war machine | 7.4 | 6.2 | 61% | 29.0 pts | 213 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 6.8 | 5.2 |
| Charges that made contact a game | 2.9 | 5.0 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.65 contact (17 units) | 0.38 declared, 0.19 contact (16 units) | 0.55 declared, 0.42 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.70 declared, 0.60 contact (10 units) | 1.17 declared, 0.58 contact (12 units) | 0.95 declared, 0.59 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.35 contact (248 units) | 0.75 declared, 0.58 contact (297 units) | 0.62 declared, 0.48 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (43 of 81) | 38% (6 of 16) | 67% (4 of 6) | 51% (53 of 103) |
| Character in a unit | 72% (21 of 29) | 78% (14 of 18) | 100% (1 of 1) | 75% (36 of 48) |
| Character on its own | 89% (32 of 36) | 46% (11 of 24) | 23% (18 of 77) | 45% (61 of 137) |
| Chariot | 80% (12 of 15) | 67% (8 of 12) | - | 74% (20 of 27) |
| Infantry | 64% (53 of 83) | 40% (10 of 25) | 50% (3 of 6) | 58% (66 of 114) |
| Monster | 65% (22 of 34) | 79% (11 of 14) | - | 69% (33 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 60% (26 of 43) | 100% (2 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (14 of 14); on the table 100% | 35% (36 of 102) | 13% | 50% (11 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 89% (17 of 19); on the table 89% | 54% (13 of 24) | 29% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 86% (6 of 7); on the table 86% | - | 67% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 88% | 61% (11 of 18) | 44% | 65% (40 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (10 of 10); on the table 100% | 29% (24 of 84) | 34% | 38% (14 of 37) | 100% (9 of 9); 7.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 96% (26 of 27); on the table 100% | 28% (10 of 36) | 25% | 51% (36 of 70) | 100% (7 of 7); 2.9 uses a game | 50% (15 of 30); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 44% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 93% (13 of 14); on the table 93% | 83% (5 of 6) | 29% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 83% (5 of 6); on the table 100% | 83% (5 of 6) | 43% | 100% (14 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 92% (12 of 13); on the table 100% | 19% (8 of 42) | 16% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (8 of 8); on the table 100% | 30% (12 of 40) | 37% | 76% (34 of 45) | 100% (3 of 3); 0.7 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 91% (10 of 11); on the table 91% | 0% (0 of 6) | 30% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 86% (24 of 28); on the table 86% | 42% (24 of 57) | 23% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 95% (20 of 21); on the table 95% | 33% (4 of 12) | 30% | 65% (47 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 87% (13 of 15); on the table 87% | 0% (0 of 6) | 41% | 57% (32 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-mine-3cc170f-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (53) | 52% (34) | 49% (87) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.58 | 1.58 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.14 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.39 | 1.03 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.14 | 1.53 | 3.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.78 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.64 | 6.11 | 11.75 |

### Quality by phase: cw-h2h-mine-3cc170f-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 49% (66 of 135) | 49% (109 of 221) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (197 of 418) | 38% (60 of 157) |
| Strategy | Close-in objectives charged next turn | 13% (18 of 137) | 17% (37 of 214) |
| Strategy | Support requests answered (helper made contact too) | 57% (12 of 21) | 42% (13 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 74% (26 of 35) | 35% (12 of 34) |
| Strategy | Lone characters that fought | 76% (67 of 88) | 84% (69 of 82) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 0.9 | 1.9 |
| Movement | Points that never moved of their own | 294.2 | 92.2 |
| Movement | Fights charged into per game | 2.6 | 4.4 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 84, net +4 | 30 of 134, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 84, net +53 | 20 of 134, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 84, net +98 | 8 of 134, net +59 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 84, net +139 | 45 of 134, net +139 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (167 of 368) | 50% (149 of 297) |
| Shooting | Points destroyed by shooting units | 82.1 | 52.7 |
| Shooting | War machine shots | 6.8 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (135 of 243) | 14% (3 of 22) |
| Shooting | Points destroyed by war machines | 109.8 | 6.5 |
| Magic | Magic missiles cast | 1.8 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (18 of 63) | 32% (13 of 41) |
| Magic | Wounds caused by magic missiles | 4.9 | 1.3 |
| Magic | Wounds caused by other spells | 1.8 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 77.3 | 11.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.4 / 0.9 / 0.1 | 1.6 / 0.3 / 0.6 / 0.0 |
| Combat | Points destroyed in combat | 245.6 | 422.5 |
| Combat | Points run down | 87.2 | 144.3 |
| Combat | Net points per charged fight, damage counted | +69 | +77 |
| Combat | Net per 100 charger points, damage counted | +22.8 | +26.5 |
| Combat | First round won (charged fights) | 77% | 61% |
| Combat | Net points per charged fight | +53 | +83 |
| Combat | Net points per supported fight / lone fight | +120 / +40 | +156 / +75 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 93 | 81 of 158 |
| Game | Points lost | 813.7 | 713.2 |
| Game | VP from objectives | 471.7 | 555.3 |
| Game | Lone holders (player turns) | 1.7 | 2.5 |

- Mine won / drew / lost: 14 / 9 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -172 VP
- The side that went first won 14 of 27 games with a winner
- Points traded per game (both sides' losses): 1527
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cw-h2h-mine-3cc170f-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 33.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +6.8 | 0.0 | 53.3 | 1.1 | +12.9 | 0.0 | 8.5 |
| BEST FACING | 0.9 | +34.9 | 0.0 | 79.1 | 0.7 | +35.5 | 0.0 | 18.4 |
| BEST FIRST | 4.1 | +128.6 | 159.6 | 111.8 | 4.2 | +170.4 | 146.6 | 114.4 |
| BEST OVERALL | 0.8 | +82.1 | 0.0 | 38.5 | 0.7 | +34.6 | 0.0 | 24.7 |
| BEST PREY | 0.7 | +49.9 | 1.8 | 40.3 | 0.9 | +59.6 | 18.9 | 4.7 |
| BEST PRIZE | 0.1 | -1.4 | 0.0 | 3.9 | 0.0 | -0.9 | 0.0 | 5.4 |
| BIG CHARACTER SAFETY | 0.3 | -1.3 | 0.0 | 13.9 | 0.2 | -0.2 | 0.0 | 25.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 13.9 | 0.1 | +0.0 | 13.9 | 0.0 |
| BLOCKED WHEEL | 0.3 | +4.5 | 0.0 | 3.4 | 0.7 | +4.7 | 0.0 | 1.2 |
| BLOWS WHERE AIMED | 0.2 | -42.8 | 26.2 | 3.9 | - | - | - | - |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.5 | 0.1 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 172.8 | 26.7 | 0.0 | +0.0 | 1.7 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +248.7 | 503.3 | 91.8 | 0.6 | +31.0 | 45.3 | 10.8 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 4.2 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.0 | 15.0 | 0.0 | 0.1 | -1.1 | 5.9 | 0.0 |
| CAST JOB | 0.8 | +46.3 | 83.7 | 0.0 | 0.5 | +8.6 | 21.7 | 16.7 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +33.7 | 20.1 | 9.6 | 0.0 | +1.5 | 5.1 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 27.5 | 0.3 | +0.0 | 0.0 | 22.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.1 | 7.9 | 3.2 | 0.2 | -1.0 | 3.2 | 10.2 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.1 | +4.2 | 0.0 | 0.0 |
| CHARGE BAND | 0.2 | +0.0 | 5.3 | 4.6 | - | - | - | - |
| CHARGE NOW FIRST | 2.5 | +0.0 | 214.9 | 92.1 | 3.3 | +0.0 | 318.9 | 57.1 |
| CHARGE NOW WEIGHED | 0.5 | -40.1 | 38.1 | 22.1 | 0.5 | -34.6 | 42.2 | 15.9 |
| CHARGER SLAIN LOST | 0.7 | -20.4 | 101.1 | 27.5 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.8 | 13.9 | 13.9 | 0.2 | -1.4 | 6.6 | 37.2 |
| CHEAP HELPER | 0.1 | +0.0 | 15.0 | 3.2 | 0.1 | +0.0 | 2.1 | 1.2 |
| COMBAT PIVOT | 0.8 | +0.0 | 47.7 | 70.7 | 0.6 | +0.0 | 17.7 | 34.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.9 | 3.2 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +127.4 | 41.1 | 36.8 | 0.2 | +37.1 | 13.9 | 13.9 |
| COUNTER-CHARGE COVER | 8.7 | +676.2 | 0.0 | 273.5 | 8.1 | +779.7 | 0.0 | 208.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 23.4 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +9.1 | 2.4 | 4.8 |
| EDGE GIVE GROUND | 0.2 | +0.4 | 30.1 | 1.5 | 0.3 | +29.3 | 65.0 | 3.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +164.8 | 0.0 | 108.8 | 1.5 | +119.9 | 0.0 | 64.5 |
| FALLBACK BY WORTH | 4.7 | +61.3 | 0.0 | 109.9 | 6.1 | +67.0 | 0.0 | 73.3 |
| FIGHT LIFT | 0.2 | +2.4 | 15.6 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 241.4 | 6.0 | +0.0 | 0.0 | 171.7 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.2 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +114.1 | 0.0 | 17.8 | 1.2 | +140.6 | 0.0 | 24.4 |
| FRIENDS SHOTS CHECKED | 0.4 | +22.7 | 0.0 | 24.1 | 0.1 | +10.6 | 0.0 | 2.5 |
| GIVES UP | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -3.1 | 10.1 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.6 | 4.2 | 2.5 |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 6.1 | 0.1 | +1.8 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 4.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 3.9 | 1.9 | 0.5 | +0.0 | 13.1 | 10.1 |
| HILL BY ITS CHANCE | 0.6 | -57.2 | 0.0 | 5.8 | 0.5 | -47.4 | 0.0 | 5.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.3 | -137.1 | 372.4 | 188.9 | - | - | - | - |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | 0.2 | +4.2 | 4.6 | 6.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.3 | +12.6 | 0.0 | 20.5 | 0.4 | +18.4 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.1 | 13.9 | 1.5 | 0.0 | +0.0 | 2.4 | 0.0 |
| HUNT RESULT | 0.1 | +27.5 | 0.0 | 0.0 | 0.2 | +11.7 | 9.2 | 6.9 |
| HUNT THE GUNS | 0.1 | +50.8 | 26.9 | 3.9 | 0.2 | +81.2 | 6.9 | 6.9 |
| INVITES THE FIGHT | 1.9 | +31.8 | 89.7 | 61.5 | 1.1 | +14.5 | 37.6 | 3.3 |
| JOINT CHARGE PLAN | 0.1 | +1.8 | 15.0 | 5.2 | 0.1 | +13.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +4.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.1 | +0.1 | 1.2 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.4 | +41.7 | 117.6 | 38.7 | 1.9 | +56.7 | 203.5 | 23.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +39.6 | 103.2 | 60.9 | 2.2 | +130.4 | 220.5 | 22.6 |
| KILLS COUNT NEXT TURN | 4.9 | +143.7 | 136.5 | 151.4 | 6.9 | +262.7 | 262.3 | 92.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +2.0 | 0.0 | 2.5 | 0.3 | +10.1 | 0.0 | 38.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 3.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +3.4 | 8.6 | 16.7 | 0.6 | +1.5 | 29.9 | 12.7 |
| LOST CHARGE | 3.0 | -44.7 | 136.8 | 100.7 | 1.7 | -25.8 | 37.0 | 48.9 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +61.0 | 39.4 | 19.8 | 0.7 | +98.7 | 6.5 | 35.4 |
| MANOEUVRE | 0.2 | +8.8 | 0.0 | 2.4 | 0.1 | +6.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +39.4 | 0.0 | 4.5 | 0.2 | +21.0 | 0.0 | 28.1 |
| MARCH ODDS | 0.2 | +13.5 | 24.8 | 0.0 | 0.2 | +17.0 | 5.1 | 15.0 |
| MARCH OVER CASTS | 0.6 | +25.0 | 0.0 | 24.6 | 0.4 | +40.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +178.9 | 0.0 | 141.7 | 5.5 | +205.0 | 0.0 | 153.8 |
| MISSILES IN THE MOVE | 4.1 | +159.1 | 0.0 | 114.4 | 2.1 | +29.3 | 0.0 | 115.2 |
| MISSILES NEXT TURN | 4.9 | +96.0 | 0.0 | 119.2 | 2.8 | +24.0 | 0.0 | 115.2 |
| MODEL FACING | 0.2 | +36.5 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.6 | +24.5 | 0.0 | 9.6 | 0.1 | +3.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -55.5 | 22.6 | 12.9 | 0.1 | -13.6 | 16.6 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 25.9 | 0.1 | +0.0 | 0.0 | 13.9 |
| MOVE TO CHARGE | 2.8 | +154.9 | 83.4 | 75.6 | 4.2 | +404.0 | 204.8 | 99.8 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +15.6 | 6.7 | 10.6 | 0.2 | +19.1 | 17.7 | 0.0 |
| NO RALLY LEFT | 0.1 | +10.0 | 0.0 | 13.4 | 0.0 | +0.3 | 0.0 | 1.8 |
| NOT NEEDED | 0.2 | -5.6 | 18.2 | 1.8 | 0.4 | -15.8 | 36.7 | 0.0 |
| NOT TURNED | 5.6 | +136.1 | 0.0 | 189.0 | 6.1 | +76.1 | 0.0 | 107.2 |
| NOT WORTH A CAST | 0.6 | -17.6 | 0.0 | 21.1 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -728.7 | 31.7 | 394.0 | 13.9 | -808.4 | 9.1 | 229.6 |
| OPENS A LANE | 0.1 | +0.4 | 25.1 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +20.2 | 21.4 | 5.4 | 0.3 | +29.6 | 10.6 | 13.9 |
| OVERRUNS AWAY | 0.5 | +24.0 | 39.4 | 18.5 | 0.5 | +5.3 | 34.9 | 22.0 |
| PATHS CROSS | 2.1 | +131.4 | 0.0 | 44.9 | 3.2 | +297.5 | 0.0 | 31.9 |
| PERIAPT WORTH | 0.1 | +7.0 | 0.0 | 15.0 | 0.1 | +6.1 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.4 | 0.0 | 10.2 | 0.2 | -9.9 | 0.0 | 0.0 |
| PLAN RESULT | 38.2 | +1709.1 | 1507.6 | 1138.3 | 39.4 | +1254.3 | 1469.7 | 1022.6 |
| PURSUES BIG PREY | 0.1 | -5.0 | 0.0 | 0.0 | 0.1 | -4.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.9 | 0.0 | 2.2 | 0.2 | +19.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +27.5 | 0.0 | 17.5 | 1.7 | +23.6 | 0.0 | 68.2 |
| RANDOM MOVER NO PROMISE | 0.5 | -20.0 | 5.9 | 9.4 | 0.3 | -22.6 | 2.4 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +7.7 | 0.0 | 2.5 | 0.5 | -8.4 | 0.0 | 8.1 |
| REDIRECT COUNTER | 2.7 | +191.6 | 0.0 | 34.2 | 4.1 | +291.3 | 0.0 | 66.7 |
| REDIRECT WEIGHED | 0.1 | +1.1 | 2.0 | 0.0 | 0.4 | +11.3 | 10.6 | 16.7 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| RESERVE FALL BACK | 0.5 | +18.7 | 0.0 | 4.9 | 0.6 | +23.8 | 0.0 | 3.0 |
| RESTRAINS TO SHOOT | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +95.9 | 267.8 | 112.6 | 3.1 | +76.3 | 231.4 | 96.4 |
| SAFER THAN THE JOB | 1.0 | +75.8 | 0.0 | 17.0 | 0.8 | +44.3 | 0.0 | 46.6 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -12.7 | 0.0 | 0.0 | 0.2 | -7.7 | 0.0 | 0.0 |
| SEARCH SPOT | 2.6 | +99.8 | 0.0 | 44.5 | 3.5 | +156.6 | 0.0 | 43.9 |
| SELF MOVE SPELL | 0.2 | +55.3 | 0.0 | 0.0 | 0.4 | +27.2 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +85.1 | 45.6 | 35.6 | 1.4 | +129.8 | 31.6 | 40.4 |
| SET-UP ANY TARGET | 0.6 | +68.1 | 26.4 | 25.6 | 0.1 | +5.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +11.8 | 0.0 | 9.3 | 0.1 | +9.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +38.6 | 65.0 | 19.9 | 0.6 | +12.2 | 34.7 | 11.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 212.8 | 15.6 | 0.2 | +0.0 | 31.6 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +700.0 | 0.0 | 315.9 | 7.2 | +178.4 | 0.0 | 126.7 |
| SPELL CATCH ODDS | 0.1 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +108.8 | 26.4 | 25.6 | 0.1 | +14.6 | 13.9 | 13.9 |
| SPELL WORTH | 1.5 | +22.4 | 84.3 | 68.8 | 1.9 | +33.6 | 112.6 | 109.9 |
| SPELLS IN THE FIGHT | 1.0 | -14.0 | 174.7 | 43.7 | - | - | - | - |
| STABLE ROLE | 11.2 | +0.0 | 418.2 | 278.6 | 10.5 | +0.0 | 379.8 | 140.3 |
| STANDS TO CAST | 0.1 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.9 | 40.8 | 5.4 | 0.1 | +0.2 | 2.4 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +40.6 | 0.0 | 25.0 | 0.5 | +11.2 | 0.0 | 29.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 14.6 |
| SUPPORT NARROWED | 5.8 | -54.7 | 328.8 | 142.5 | 9.0 | -52.1 | 466.0 | 129.7 |
| SUPPORTS | 4.0 | +66.5 | 169.5 | 85.1 | 5.8 | +55.2 | 238.5 | 91.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.5 | 5.3 | 0.0 | 0.1 | -1.8 | 8.5 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +0.2 | 0.0 | 16.0 | 0.5 | -7.5 | 10.1 | 4.6 |
| THROUGH LINE OF FIRE | 0.3 | +16.8 | 0.0 | 15.0 | 0.2 | +6.1 | 0.0 | 1.9 |
| TURN WORTH | 0.3 | -21.6 | 29.3 | 9.3 | 0.5 | -51.8 | 36.6 | 18.0 |
| TWO OR MORE ARRIVE | 0.4 | +1.4 | 34.7 | 5.2 | 0.4 | +2.6 | 4.8 | 1.8 |
| WAIT AFTER COSTS | 6.3 | -297.8 | 221.5 | 179.3 | 7.2 | -381.9 | 358.6 | 133.2 |
| WALKS TO THE FIGHT | 1.2 | +18.2 | 19.6 | 30.7 | 1.1 | +23.8 | 42.2 | 6.4 |
| WAR ENGINE CHARGES | 0.1 | +9.2 | 5.4 | 5.1 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 54.5 | 27.5 | 0.2 | +0.0 | 5.2 | 12.1 |
| WEARS DOWN | 1.4 | +60.6 | 99.8 | 54.6 | 1.6 | +66.2 | 85.8 | 47.9 |
| WHO HITS BACK | 0.4 | +34.7 | 0.0 | 8.6 | 0.4 | +13.4 | 0.0 | 18.1 |
| WHOLE FIGHT | 0.5 | +18.6 | 30.0 | 23.4 | 0.7 | +11.8 | 68.6 | 8.4 |
| WHOLE FIGHT GAIN | 0.4 | +17.9 | 35.0 | 12.3 | 0.9 | +58.2 | 40.9 | 14.5 |
| WIDER SPREAD | 2.9 | -8.6 | 293.2 | 120.4 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 1.7 | 0.0 | - | - | - | - |

### Rule changes: cw-h2h-mine-3cc170f-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1063 | 1063 | 1063 | 29.53 | -55338 | -52.1 |
| BEST FIRST | 297 | 297 | 297 | 8.25 | +10763 | +36.2 |
| SEARCH SPOT | 221 | 221 | 216 | 6.00 | +9239 | +42.8 |
| PATHS CROSS | 190 | 190 | 190 | 5.28 | +15438 | +81.3 |
| COUNTER-CHARGE COVER | 603 | 331 | 151 | 4.19 | +9811 | +65.0 |
| SUPPORTS | 353 | 353 | 147 | 4.08 | +1411 | +9.6 |
| MOVE TO CHARGE | 250 | 250 | 145 | 4.03 | +7629 | +52.6 |
| FACES THE THREAT | 132 | 132 | 132 | 3.67 | +10248 | +77.6 |
| KILLS COUNT NEXT TURN | 428 | 428 | 132 | 3.67 | +3232 | +24.5 |
| FALLBACK BY WORTH | 388 | 388 | 94 | 2.61 | +4618 | +49.1 |
| SHOTS IN THE MOVE | 812 | 569 | 72 | 2.00 | +2289 | +31.8 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +9167 | +132.9 |
| WAIT AFTER COSTS | 486 | 486 | 67 | 1.86 | +1286 | +19.2 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +4324 | +68.6 |
| BEST FACING | 59 | 59 | 59 | 1.64 | +2536 | +43.0 |
| REDIRECT COUNTER | 244 | 149 | 56 | 1.56 | +4146 | +74.0 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 102 | 102 | 53 | 1.47 | +1842 | +34.8 |
| COMBAT PIVOT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| BEST OVERALL | 51 | 51 | 51 | 1.42 | +4201 | +82.4 |
| CHARGE NOW FIRST | 209 | 209 | 50 | 1.39 | -2882 | -57.6 |
| WALKS TO THE FIGHT | 83 | 83 | 50 | 1.39 | +594 | +11.9 |
| ARTILLERY RE-ROLL WEIGHED | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| MAX FOR POSITIONING | 378 | 208 | 49 | 1.36 | +569 | +11.6 |
| SHOT REPLANNED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +1531 | +37.3 |
| STOPS SHORT OF THE FLANK | 40 | 40 | 40 | 1.11 | +1864 | +46.6 |
| RISK BY ARC | 206 | 196 | 39 | 1.08 | +1068 | +27.4 |
| BLOCKED WHEEL | 36 | 36 | 36 | 1.00 | +329 | +9.1 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2556 | +71.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 63 | 63 | 34 | 0.94 | +633 | +18.6 |
| CANNON PLANNED TARGET | 211 | 211 | 30 | 0.83 | -672 | -22.4 |
| CAST JOB | 46 | 46 | 30 | 0.83 | +652 | +21.7 |
| MARCH CHECK | 34 | 32 | 29 | 0.81 | +1723 | +59.4 |
| MISSILES IN THE MOVE | 225 | 133 | 29 | 0.81 | +980 | +33.8 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| SET UP TOGETHER | 84 | 64 | 28 | 0.78 | +2829 | +101.0 |
| KILLS COUNT | 123 | 119 | 27 | 0.75 | +1498 | +55.5 |
| WHO HITS BACK | 26 | 26 | 26 | 0.72 | +967 | +37.2 |
| INVITES THE FIGHT | 108 | 108 | 24 | 0.67 | +224 | +9.3 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +993 | +41.4 |
| KEEPS ITS TARGET | 118 | 117 | 23 | 0.64 | +392 | +17.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 45 | 38 | 20 | 0.56 | +701 | +35.1 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.53 | +826 | +43.5 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1201 | +66.7 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +1047 | +58.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -53 | -3.1 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| BEST PREY | 57 | 57 | 16 | 0.44 | +889 | +55.6 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -40 | -2.6 |
| MARCH ODDS | 16 | 16 | 15 | 0.42 | +268 | +17.9 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 108 | 102 | 14 | 0.39 | +270 | +19.3 |
| MANOEUVRE | 14 | 14 | 13 | 0.36 | +534 | +41.1 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -476 | -39.7 |
| SUPPORT NARROWED | 534 | 534 | 11 | 0.31 | -146 | -13.3 |
| WAR ENGINE JOBS | 27 | 27 | 11 | 0.31 | -371 | -33.7 |
| HONEST WORTH | 264 | 260 | 10 | 0.28 | +98 | +9.8 |
| MAKE SURE TOGETHER | 47 | 27 | 10 | 0.28 | +2128 | +212.8 |
| WHOLE FIGHT | 43 | 42 | 10 | 0.28 | +519 | +51.9 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +1312 | +145.8 |
| NEEDED THERE | 10 | 10 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 21 | 21 | 9 | 0.25 | +444 | +49.3 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 8 | 0.22 | +572 | +71.5 |
| MISSILES NEXT TURN | 280 | 158 | 8 | 0.22 | +11 | +1.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -347 | -49.6 |
| RAIDS THE BAGGAGE NEXT TURN | 9 | 9 | 7 | 0.19 | +388 | +55.4 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -229 | -32.7 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| CHARGE BAND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +68 | +11.4 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +324 | +64.9 |
| LONG SHOT | 31 | 30 | 5 | 0.14 | +112 | +22.4 |
| OVERRUNS AWAY | 34 | 34 | 5 | 0.14 | +92 | +18.4 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +471 | +94.3 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +258 | +51.5 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| LOST CHARGE | 170 | 168 | 4 | 0.11 | +36 | +9.0 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +300 | +75.0 |
| SURE REACH TOGETHER | 25 | 20 | 4 | 0.11 | +52 | +13.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -82 | -27.3 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +44 | +14.5 |
| HUNT ADVANCE | 7 | 7 | 3 | 0.08 | +81 | +27.1 |
| REDIRECT BY WHAT IT STOPS | 27 | 27 | 3 | 0.08 | +262 | +87.2 |
| SPELLS IN THE FIGHT | 36 | 32 | 3 | 0.08 | +88 | +29.3 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -14 | -4.7 |
| WAR ENGINE CHARGES | 4 | 4 | 3 | 0.08 | +260 | +86.6 |
| BACKUP TARGETS | 78 | 35 | 2 | 0.06 | +4 | +2.0 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -75 | -37.5 |
| EDGE GIVE GROUND | 17 | 17 | 2 | 0.06 | +387 | +193.5 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +56 | +27.9 |
| HUNT IN PAIRS | 28 | 15 | 2 | 0.06 | +20 | +9.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.06 | -138 | -69.0 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.06 | -1 | -0.3 |
| WIDER SPREAD | 105 | 97 | 2 | 0.06 | +5 | +2.3 |
| BLOWS WHERE AIMED | 9 | 8 | 1 | 0.03 | +127 | +127.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +15 | +14.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 5 | 5 | 1 | 0.03 | -3 | -2.8 |
| JOINT CHARGE PLAN | 8 | 8 | 1 | 0.03 | +163 | +163.2 |
| OPENS A LANE | 5 | 4 | 1 | 0.03 | +4 | +3.7 |
| TWO OR MORE ARRIVE | 26 | 24 | 1 | 0.03 | +2 | +2.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 24 | 21 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 11 | 11 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 40 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 432 | not checked | - | - | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | not checked | - | - | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 38 | 38 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 35 | 35 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 423 | 423 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| PLAN RESULT | 2794 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 123 | not checked | - | - | - | - |
| STABLE ROLE | 780 | 776 | 0 | 0.00 | - | - |
| STOPS | 6 | 6 | 0 | 0.00 | - | - |
| TURN WORTH | 31 | 31 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-mine-3cc170f-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.81 | 12.22 | 53.3 |
| FALLBACK | gate | 0.89 | 0.58 | 59.0 |
| CHARGE NOW FIRST | rule | 0.69 | 0.67 | 58.8 |
| TURN GATE | gate | 0.36 | 0.58 | 24.9 |
| SUPPORT REQUEST | gate | 0.22 | 0.19 | 75.2 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.22 | 39.7 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 76.5 |
| SUPPORT NARROWED | rule | 0.11 | 0.19 | 13.3 |
| WAR ENGINE JOBS | rule | 0.25 | 0.03 | 37.1 |
| AFTERMATH BAND | gate | 0.19 | 0.06 | 2.4 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.08 | 8.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.14 | 34.6 |
| PURSUES BIG PREY | rule | 0.08 | 0.11 | 49.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.06 | 32.7 |
| CHAFF PASSED | rule | 0.03 | 0.14 | 6.5 |
| PATHS CROSS | rule | 0.11 | 0.06 | 22.6 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 38.5 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 2.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 40.6 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 5.2 |
| BEST PRIZE | rule | 0.06 | 0.03 | 27.3 |
| FACES THE THREAT | rule | 0.08 | - | 10.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 37.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 69.0 |
| LONG SHOT | rule | - | 0.06 | 3.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 11.2 |
| STANDS TO CAST | rule | 0.06 | - | 7.9 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 20.4 |
| MARCH ODDS | rule | - | 0.03 | 4.5 |
| NO REASON | gate | 0.03 | - | 15.7 |
| REDIRECT WEIGHED | rule | - | 0.03 | 31.9 |
| RULE SWITCHED OFF | gate | - | 0.03 | 7.6 |

### Plans: cw-h2h-mine-3cc170f-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 14% | 317 | 315 | 99% |
| Mine | charge | 3.2 | 58% | 222 | 324 | 146% |
| Mine | close in | 3.8 | 27% | 205 | 100 | 49% |
| Mine | hold | 4.6 | 34% | 296 | 0 | 0% |
| Mine | join | 0.7 | 96% | 13 | 0 | 0% |
| Mine | shoot | 10.1 | 65% | 389 | 970 | 249% |
| Mine | support | 4.2 | 91% | 46 | 0 | 0% |
| Opponent | advance | 13.4 | 17% | 320 | 380 | 119% |
| Opponent | charge | 5.2 | 50% | 579 | 468 | 81% |
| Opponent | close in | 5.9 | 27% | 470 | 177 | 38% |
| Opponent | hold | 4.4 | 30% | 293 | 0 | 0% |
| Opponent | join | 0.5 | 95% | 23 | 0 | 0% |
| Opponent | shoot | 3.6 | 57% | 70 | 235 | 333% |
| Opponent | support | 6.3 | 87% | 38 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-mine-3cc170f-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 50% | 50% | 0% | 2.5 | 457 | 248 | 50% | 25 |
| Opponent | 0.2 | 8 | 0 | 12% | 25% | 0% | 2.5 | 365 | 53 | 25% | 127 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 50% | 0% | 3.0 | 569 | 260 | 50% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 481 | 470 | 100% | 78 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 133 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 104 | 91 | 100% | 69 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 135 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Tomb Kings of Khemri | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 380 | 0 | 0% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 0% | 33% | 0% | 2.0 | 360 | 110 | 33% | 155 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 429 | 0 | 0% | 113 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 121 |

### Battle groups: cw-h2h-mine-3cc170f-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 30% | 47% | 6% | 17% | 36% | 12% | 9% | 42% | 0% |
| Mine | REDIRECT COUNTER | 2.7 | 37% | 56% | 3% | 0% | 40% | 3% | 3% | 46% | 9% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 17% | 71% | 12% | 17% | 33% | 12% | 7% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 18% | 69% | 23% | 33% | 35% | 0% | 10% | 50% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-mine-3cc170f-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.5 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 28 (34) | 14 | 15 | 62 | 35% | 2.1 | 52 (14) | 0 (7) | 20 (13) | 24 (22) | 37 (12) |
| Mine | Character | 106 | 38 (106) | 38 | 0 | 35 | 13% | 2.3 | 58 (29) | 35 (56) | 7 (6) | 34 (45) | 48 (46) |
| Mine | Clean-up | 22 | 74 (22) | 40 | 34 | 49 | 23% | 3.2 | 16 (2) | 97 (16) | 32 (4) | 123 (10) | 48 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Fast | 4 | 55 (4) | 55 | 0 | 73 | 25% | 3.0 | 0 (2) | 111 (2) | - | 0 (3) | 206 (1) |
| Mine | Fast Hammer | 40 | 60 (40) | 38 | 22 | 60 | 18% | 2.5 | 64 (26) | 77 (9) | 7 (5) | 68 (25) | 48 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 28 (65) | 16 | 12 | 52 | 15% | 2.5 | 20 (13) | 32 (45) | 10 (7) | 29 (40) | 27 (25) |
| Mine | Holder | 31 | 61 (31) | 9 | 52 | 30 | 16% | 3.5 | 13 (7) | 98 (18) | 24 (6) | 87 (19) | 26 (12) |
| Mine | Shooter | 35 | 67 (35) | 34 | 33 | 42 | 3% | 1.6 | 40 (9) | 68 (21) | 118 (5) | 65 (25) | 73 (10) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 56 | 67 (56) | 67 | 0 | 43 | 4% | 1.3 | 68 (16) | 46 (30) | 128 (10) | 56 (9) | 69 (47) |
| Mine | Wizard | 17 | 1 (17) | 1 | 0 | 61 | 12% | 2.1 | 0 (3) | 4 (7) | 0 (1) | 0 (5) | 4 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 23 (75) | 10 | 14 | 50 | 40% | 2.8 | 30 (31) | 14 (17) | 24 (27) | 28 (56) | 7 (19) |
| Opponent | Character | 97 | 58 (97) | 58 | 0 | 32 | 23% | 2.5 | 73 (45) | 50 (39) | 42 (6) | 63 (50) | 59 (40) |
| Opponent | Clean-up | 11 | 80 (11) | 41 | 38 | 21 | 27% | 2.2 | 34 (3) | 83 (6) | 100 (2) | 57 (6) | 93 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 39 (60) | 22 | 17 | 45 | 20% | 2.8 | 41 (26) | 37 (25) | 39 (9) | 44 (39) | 31 (21) |
| Opponent | Fragile | 17 | 14 (17) | 14 | 0 | 79 | 12% | 2.3 | 36 (4) | 0 (8) | 25 (4) | 18 (13) | 0 (3) |
| Opponent | Hammer | 65 | 48 (65) | 35 | 13 | 32 | 31% | 3.3 | 14 (20) | 61 (38) | 32 (7) | 63 (41) | 27 (24) |
| Opponent | Holder | 29 | 26 (29) | 1 | 24 | 44 | 48% | 3.7 | 0 (12) | 51 (12) | 0 (4) | 35 (17) | 13 (11) |
| Opponent | Shooter | 33 | 69 (33) | 24 | 45 | 42 | 3% | 1.3 | 32 (9) | 81 (21) | 101 (3) | 56 (18) | 83 (15) |
| Opponent | Support | 6 | 18 (6) | 18 | 0 | 82 | 17% | 3.4 | 0 (3) | 56 (2) | 0 (1) | 102 (1) | 0 (5) |
| Opponent | War machine | 6 | 137 (6) | 137 | 0 | 69 | 0% | 1.2 | 61 (3) | 245 (3) | - | 61 (3) | 245 (3) |
| Opponent | Wizard | 19 | 14 (19) | 14 | 0 | 33 | 11% | 1.8 | 23 (11) | 10 (3) | 0 (2) | 12 (8) | 25 (8) |

### Charged fights: cw-h2h-mine-3cc170f-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 236 | 137 | 2.2 | 1.3 | 61 | 40 | +21 | 3 of 9 | 5 of 9 | -13 | +38 |
| Mine | Chaos Dwarfs | 4 | 163 | 46 | 2.5 | 1.2 | 18 | 62 | -44 | 7 of 10 | 8 of 10 | +92 | -78 |
| Mine | Dwarfen Mountain Holds | 3 | 586 | 0 | 0.7 | 1.0 | 0 | 116 | -116 | 2 of 2 | 1 of 2 | - | -116 |
| Mine | Empire of Man | 5 | 608 | 35 | 1.0 | 1.4 | 35 | 112 | -77 | 2 of 5 | 3 of 5 | +0 | -96 |
| Mine | Grand Cathay | 4 | 358 | 401 | 3.2 | 1.3 | 123 | 0 | +123 | 4 of 13 | 12 of 13 | +235 | +90 |
| Mine | High Elf Realms | 4 | 247 | 476 | 3.2 | 1.2 | 146 | 57 | +90 | 4 of 13 | 11 of 13 | +223 | +50 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 1522 | 5.0 | 1.2 | 304 | 0 | +304 | 3 of 5 | 5 of 5 | +145 | +344 |
| Mine | Lizardmen | 1 | 0 | 1136 | 6.0 | 1.0 | 189 | 91 | +98 | 3 of 6 | 5 of 6 | - | +98 |
| Mine | Ogre Kingdoms | 2 | 51 | 0 | 2.0 | 1.0 | 0 | 69 | -69 | 2 of 4 | 2 of 4 | - | -69 |
| Mine | Skaven | 2 | 358 | 53 | 1.5 | 1.0 | 35 | 0 | +35 | 1 of 3 | 3 of 3 | - | +35 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 372 | 3.5 | 1.3 | 106 | 46 | +60 | 1 of 7 | 4 of 7 | +125 | +34 |
| Mine | Vampire Counts | 2 | 0 | 214 | 3.0 | 1.0 | 71 | 7 | +64 | 1 of 6 | 5 of 6 | - | +64 |
| Mine | Warriors of Chaos | 2 | 0 | 246 | 5.0 | 1.1 | 49 | 17 | +32 | 1 of 10 | 8 of 10 | +0 | +36 |
| **Mine** | all armies | 36 | 269 | 246 | 2.6 | 1.2 | 95 | 42 | +53 | 34 of 93 | 72 of 93 | +120 | +40 |
| Opponent | Empire of Man | 1 | 460 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 171 | 513 | 5.0 | 1.1 | 103 | 48 | +54 | 16 of 25 | 12 of 25 | +112 | +46 |
| Opponent | Lizardmen | 2 | 0 | 706 | 4.5 | 1.0 | 157 | 37 | +120 | 6 of 9 | 8 of 9 | - | +120 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 731 | 4.3 | 1.0 | 169 | 8 | +161 | 3 of 13 | 12 of 13 | - | +161 |
| Opponent | Skaven | 4 | 0 | 71 | 1.8 | 1.1 | 40 | 38 | +2 | 3 of 7 | 4 of 7 | -269 | +47 |
| Opponent | Tomb Kings of Khemri | 2 | 133 | 819 | 4.0 | 1.1 | 205 | 0 | +205 | 2 of 8 | 8 of 8 | +540 | +157 |
| Opponent | Vampire Counts | 6 | 40 | 659 | 6.3 | 1.2 | 104 | 7 | +97 | 22 of 38 | 24 of 38 | +263 | +72 |
| Opponent | Warriors of Chaos | 7 | 27 | 355 | 4.3 | 1.1 | 83 | 31 | +52 | 17 of 30 | 14 of 30 | -98 | +63 |
| Opponent | Wood Elf Realms | 6 | 88 | 358 | 4.5 | 1.1 | 80 | 16 | +64 | 11 of 27 | 15 of 27 | +195 | +41 |
| **Opponent** | all armies | 36 | 70 | 463 | 4.4 | 1.1 | 106 | 22 | +83 | 81 of 158 | 97 of 158 | +156 | +75 |

### Effective charges: cw-h2h-mine-3cc170f-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net -85) | 0 | 2 (net +50) | 1 (net +98) | 1 (net +123) | 2 (net -68) | 2 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 10 | 4 (net +0) | 0 | 2 (net -170) | 2 (net -94) | 1 (net +185) | 0 | 1 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 1 (net -233) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 5 | 1 (net -371) | 0 | 2 (net -94) | 0 | 1 (net +0) | 1 (net +177) | 0 | 40% (2 of 5) |
| Mine | Grand Cathay | 13 | 1 (net +0) | 0 | 2 (net +270) | 3 (net +231) | 2 (net +150) | 3 (net +0) | 2 | 18% (2 of 11) |
| Mine | High Elf Realms | 13 | 1 (net +663) | 0 | 5 (net +101) | 3 (net -83) | 2 (net +36) | 2 (net +88) | 0 | 38% (5 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 2 (net +286) | 1 (net +145) | 2 (net +402) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 6 | 1 (net +15) | 1 (net -405) | 0 | 2 (net +0) | 0 | 1 (net +980) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 3 (net -62) | 0 | 0 | 1 | 0% (0 of 3) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +35) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net -130) | 0 | 2 (net +116) | 2 (net -4) | 1 (net +250) | 1 (net +75) | 0 | 29% (2 of 7) |
| Mine | Vampire Counts | 6 | 1 (net -40) | 1 (net +115) | 2 (net +80) | 1 (net +107) | 0 | 1 (net +45) | 0 | 33% (2 of 6) |
| Mine | Warriors of Chaos | 10 | 2 (net +0) | 0 | 2 (net +0) | 2 (net +103) | 2 (net +0) | 0 | 2 | 25% (2 of 8) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 25 | 5 (net -4) | 0 | 4 (net +152) | 3 (net +63) | 2 (net +46) | 6 (net +170) | 5 | 20% (4 of 20) |
| Opponent | Lizardmen | 9 | 2 (net +130) | 0 | 2 (net +155) | 4 (net +100) | 0 | 1 (net +112) | 0 | 22% (2 of 9) |
| Opponent | Orc & Goblin Tribes | 13 | 0 | 0 | 0 | 0 | 1 (net +83) | 3 (net +312) | 9 | 0% (0 of 4) |
| Opponent | Skaven | 7 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 5 (net +3) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 0 | 1 (net +0) | 5 (net +234) | 2 | 0% (0 of 6) |
| Opponent | Vampire Counts | 38 | 10 (net +20) | 0 | 7 (net +105) | 9 (net +189) | 1 (net +151) | 9 (net +84) | 2 | 19% (7 of 36) |
| Opponent | Warriors of Chaos | 30 | 5 (net +17) | 1 (net +0) | 3 (net -41) | 4 (net +50) | 1 (net +110) | 10 (net +92) | 6 | 12% (3 of 24) |
| Opponent | Wood Elf Realms | 27 | 7 (net +2) | 2 (net -82) | 3 (net +41) | 7 (net +55) | 2 (net +20) | 6 (net +221) | 0 | 11% (3 of 27) |

### Charged fights, damage counted: cw-h2h-mine-3cc170f-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 270 | 341 | +4 | 112 | 86 | +27 | +9.9 |
| Mine | 50-54% | 2 | 254 | 229 | -145 | 58 | 202 | -145 | -57.0 |
| Mine | Effective (55-75%) | 19 | 342 | 252 | +53 | 137 | 50 | +87 | +25.5 |
| Mine | 76-89% | 22 | 286 | 201 | +37 | 130 | 92 | +38 | +13.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 213 | 190 | +139 | 172 | 10 | +162 | +76.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 548 | 111 | +98 | 111 | 6 | +105 | +19.1 |
| Mine | No odds | 9 | 200 | 163 | +10 | 62 | 48 | +14 | +6.8 |
| Mine | All fights | 93 | 304 | 217 | +53 | 126 | 56 | +69 | +22.8 |
| Opponent | Long shot (under 50%) | 30 | 219 | 254 | +18 | 66 | 58 | +8 | +3.7 |
| Opponent | 50-54% | 3 | 213 | 358 | -55 | 54 | 110 | -56 | -26.4 |
| Opponent | Effective (55-75%) | 20 | 255 | 202 | +83 | 112 | 44 | +68 | +26.6 |
| Opponent | 76-89% | 28 | 340 | 225 | +103 | 139 | 27 | +111 | +32.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 323 | 231 | +139 | 172 | 44 | +128 | +39.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 374 | 95 | +59 | 76 | 21 | +55 | +14.8 |
| Opponent | No odds | 24 | 269 | 201 | +62 | 111 | 54 | +57 | +21.2 |
| Opponent | All fights | 158 | 290 | 222 | +83 | 122 | 45 | +77 | +26.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-mine-3cc170f-p4 | move | 456 | 86 (19%) | 65 (14%) | 57 (12%) | 313 (69%) |
| cw-h2h-mine-3cc170f-p4 | objective | 351 | 55 (16%) | 42 (12%) | 43 (12%) | 253 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

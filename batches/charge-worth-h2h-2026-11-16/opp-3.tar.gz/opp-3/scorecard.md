# Doctrine scorecard: cw-h2h-opp-3cc170f-p3

### Scorecard: cw-h2h-opp-3cc170f-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | 3 | 2 | 1 | 0 | 0 | 0 | 65 |
| L0126 | 6 | 1 | Opponent | no | 7 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 9 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | no | - | 3 | 1 | 2 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 770 |
| L0327 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 10 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 2 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 1 | - | 0 | 3 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 781 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 1 | 0 | 0 | 479 |
| L1030 | 4 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 10 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 498 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 475 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 10 | 4 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 190 |
| L1422 | 6 | 1 | Mine | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 242 |
| L1519 | 1 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 641 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | 2 | 0 | 6 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 2 | 1 | 8 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 6 | 4 | 2 | 1 | 2 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 6 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 144 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 1 | 0 | 0 | 127 |
| L2832 | 6 | 1 | Opponent | no | 3 | 1 | 3 | 3 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 2 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 3.4 | 2.7 | 2.4 | 1.0 | 0.3 | 0.0 | 0.0 | 271.8 |
| **Average** | | | Opponent | 19% | 2.4 | 2.2 | 2.6 | 2.0 | 0.6 | 0.0 | 0.0 | 159.9 |

### KPIs: cw-h2h-opp-3cc170f-p3

Rules off - Mine only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (39 of 170) | 11% (19 of 176) | 17% (58 of 346) |
| Winner chose to follow up after the loser gave ground |  | 100% (63 of 63); on the table 100% | 100% (39 of 39); on the table 100% | 100% (102 of 102); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (8 of 8); on the table 100% | 85% (11 of 13); on the table 85% | 90% (19 of 21); on the table 90% |
| Winner chose to pursue after the loser fled |  | 90% (18 of 20); on the table 95% | 87% (26 of 30); on the table 87% | 88% (44 of 50); on the table 90% |
| Winner chose to follow up or pursue (all three) |  | 98% (89 of 91); on the table 99% | 93% (76 of 82); on the table 93% | 95% (165 of 173); on the table 96% |
| Magic missiles tried each own turn | 50%+ | 31% (105 of 342) | 43% (82 of 192) | 35% (187 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (105 of 219) | 53% (82 of 156) | 50% (187 of 375) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (12 of 20) | 48% (29 of 60) | 51% (41 of 80) |
| Points that never fought | lower | 40% (27589 of 68801) | 41% (29689 of 71990) | 41% (57278 of 140791) |
|   infantry points that never fought | lower | 48% (6776 of 14174) | 60% (8510 of 14220) | 54% (15286 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (158 of 272) | 60% (171 of 285) | 59% (329 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.5 uses a game | 83% (20 of 24); 2.1 uses a game | 90% (44 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.4 uses a game | 50% (3 of 6); 0.1 uses a game | 45% (9 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (31895 of 59391) | 52% (33523 of 64043) | 53% (65418 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.9 (14%) | 1.2 (39%) | 2.1 (22%) |
| MARCHED: its unit marched | 1.7 (25%) | 0.6 (20%) | 2.3 (24%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.5 (22%) | 0.4 (15%) | 1.9 (20%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.7 (25%) | 0.4 (12%) | 2.0 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.2 | 1.1 | 2.2 | 5.2 | 0.9 | 1.7 |
| not cast | 3.6 | 1.4 | 4.0 | 9.6 | 2.4 | 18.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (46%) | 0.2 (6%) | 2.1 (22%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (24%) | 0.5 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.1 (8%) | 0.6 (16%) | 1.9 (20%) | 0.4 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (4%) | 0.4 (10%) | 0.3 (3%) | 0.2 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (2%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.7 (20%) | 0.2 (17%) | 1.0 (24%) | 2.0 (21%) | 0.4 (17%) | 2.8 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (2%) | 0.1 (3%) | 0.4 (4%) | 0.1 (5%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (8%) | 0.0 (0%) | 0.1 (1%) | 0.6 (23%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (57%) | 0.2 (13%) | 1.4 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 64% (28 of 44) | 70% (16 of 23) | 66% (44 of 67) |
| the unit moved after it | 61% (17 of 28) | 81% (13 of 16) | 68% (30 of 44) |
| it charged on its next turn | 0% (0 of 28) | 12% (2 of 16) | 5% (2 of 44) |
| the enemy charged it first | 0% (0 of 28) | 6% (1 of 16) | 2% (1 of 44) |
| it fought by the end of its next turn | 0% (0 of 28) | 0% (0 of 16) | 0% (0 of 44) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (6 of 28) | 25% (4 of 16) | 23% (10 of 44) |
| none of these (no charge, no fight, no charge escaped) | 79% (22 of 28) | 56% (9 of 16) | 70% (31 of 44) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (507 of 778) | 61% (389 of 640) | 63% (896 of 1418) |
|   cavalry | 64% (45 of 70) | 65% (80 of 123) | 65% (125 of 193) |
|   character | 61% (62 of 101) | 30% (41 of 135) | 44% (103 of 236) |
|   chariot | 48% (45 of 93) | 61% (19 of 31) | 52% (64 of 124) |
|   infantry | 53% (111 of 209) | 69% (184 of 265) | 62% (295 of 474) |
|   monster | 23% (7 of 31) | 100% (3 of 3) | 29% (10 of 34) |
|   war machine | 86% (237 of 274) | 75% (62 of 83) | 84% (299 of 357) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (34%) | 1.5 (22%) | 4.1 (28%) |
| CHARGED: it charged | 1.0 (13%) | 1.6 (23%) | 2.6 (18%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.5 (7%) | 1.1 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (14%) | 0.6 (9%) | 1.7 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.8 (11%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (16%) | 1.5 (22%) | 2.7 (19%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.2 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.2 | 83% | 5.8 pts | 30 pts |
| character | 3.3 | 0.9 | 80% | 6.6 pts | 22 pts |
| chariot | 1.8 | 0.8 | 75% | 17.7 pts | 31 pts |
| infantry | 12.6 | 4.5 | 74% | 10.1 pts | 128 pts |
| monster | 0.3 | 0.0 | 91% | 1.9 pts | 1 pts |
| war machine | 8.8 | 8.4 | 61% | 26.0 pts | 227 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.1 | 4.4 |
| Charges that made contact a game | 2.7 | 3.8 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.62 contact (24 units) | 0.75 declared, 0.56 contact (16 units) | 0.70 declared, 0.60 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 0.25 contact (4 units) | 1.00 declared, 0.86 contact (7 units) | 1.09 declared, 0.64 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.36 contact (224 units) | 0.61 declared, 0.45 contact (268 units) | 0.57 declared, 0.41 contact (492 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (41 of 77) | 53% (8 of 15) | 40% (4 of 10) | 52% (53 of 102) |
| Character in a unit | 86% (37 of 43) | 73% (11 of 15) | 50% (3 of 6) | 80% (51 of 64) |
| Character on its own | 79% (27 of 34) | 54% (22 of 41) | 29% (20 of 69) | 48% (69 of 144) |
| Chariot | 73% (8 of 11) | 100% (12 of 12) | - | 87% (20 of 23) |
| Infantry | 64% (45 of 70) | 45% (19 of 42) | 20% (1 of 5) | 56% (65 of 117) |
| Monster | 71% (24 of 34) | 71% (5 of 7) | - | 71% (29 of 41) |
| Monstrous | 70% (7 of 10) | 45% (5 of 11) | - | 57% (12 of 21) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 89% | 31% (30 of 96) | 26% | 73% (16 of 22) | 100% (6 of 6); 3.8 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (15 of 15); on the table 100% | 50% (18 of 36) | 49% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 74% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (8 of 8); on the table 100% | 57% (17 of 30) | 58% | 64% (38 of 59) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 100% (30 of 30); on the table 100% | 37% (71 of 192) | 42% | 47% (35 of 74) | 83% (15 of 18); 4.4 uses a game | 75% (3 of 4); 0.6 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 91% (10 of 11); on the table 100% | 26% (11 of 42) | 33% | 59% (32 of 54) | 100% (9 of 9); 2.9 uses a game | 33% (4 of 12); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (6 of 6); on the table 100% | - | 40% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 30% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 16% | 29% (2 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (4 of 4); on the table 100% | 8% (1 of 12) | 2% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 78% (7 of 9); on the table 78% | 25% (3 of 12) | 74% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (14 of 14); on the table 100% | 0% (0 of 6) | 37% | 58% (15 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (22 of 22); on the table 100% | 33% (18 of 54) | 31% | 54% (25 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 88% (22 of 25); on the table 88% | 43% (13 of 30) | 35% | 65% (62 of 96) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 91% (10 of 11); on the table 91% | 8% (1 of 12) | 53% | 66% (41 of 62) | 82% (9 of 11); 7.0 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-opp-3cc170f-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (40) | 42% (30) | 44% (70) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.53 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.17 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.36 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 1.03 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 1.00 | 1.81 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.64 | 4.86 | 11.50 |

### Quality by phase: cw-h2h-opp-3cc170f-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (65 of 125) | 45% (69 of 152) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (174 of 376) | 45% (113 of 249) |
| Strategy | Close-in objectives charged next turn | 8% (13 of 155) | 14% (30 of 215) |
| Strategy | Support requests answered (helper made contact too) | 44% (7 of 16) | 42% (11 of 26) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 55% (6 of 11) | 55% (6 of 11) |
| Strategy | Joined characters whose unit fought | 40% (19 of 48) | 41% (19 of 46) |
| Strategy | Lone characters that fought | 76% (66 of 87) | 77% (68 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 271.8 | 159.9 |
| Movement | Fights charged into per game | 2.5 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 83, net +18 | 18 of 95, net +34 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 83, net +177 | 18 of 95, net +43 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 83, net +152 | 7 of 95, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 83, net +60 | 22 of 95, net +125 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.2 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (141 of 296) | 46% (180 of 389) |
| Shooting | Points destroyed by shooting units | 88.8 | 59.8 |
| Shooting | War machine shots | 6.6 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (124 of 237) | 42% (33 of 78) |
| Shooting | Points destroyed by war machines | 59.9 | 6.7 |
| Magic | Magic missiles cast | 1.8 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (22 of 66) | 39% (21 of 54) |
| Magic | Wounds caused by magic missiles | 3.2 | 2.7 |
| Magic | Wounds caused by other spells | 1.6 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 36.9 | 67.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.3 / 0.8 / 0.1 | 2.2 / 0.3 / 0.2 / 0.5 |
| Combat | Points destroyed in combat | 300.1 | 336.7 |
| Combat | Points run down | 67.4 | 112.7 |
| Combat | Net points per charged fight, damage counted | +83 | +91 |
| Combat | Net per 100 charger points, damage counted | +27.2 | +32.3 |
| Combat | First round won (charged fights) | 80% | 75% |
| Combat | Net points per charged fight | +82 | +91 |
| Combat | Net points per supported fight / lone fight | +90 / +81 | +185 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 91 | 44 of 115 |
| Game | Points lost | 697.0 | 581.5 |
| Game | VP from objectives | 478.3 | 593.1 |
| Game | Lone holders (player turns) | 3.4 | 2.4 |

- Mine won / drew / lost: 9 / 12 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -256 VP
- The side that went first won 13 of 24 games with a winner
- Points traded per game (both sides' losses): 1279
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cw-h2h-opp-3cc170f-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 10.3 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 40.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.3 | 0.0 | 31.1 | 0.7 | +6.0 | 0.0 | 18.1 |
| BEST FACING | 0.6 | +31.7 | 0.0 | 9.9 | 0.7 | +21.4 | 0.0 | 25.6 |
| BEST FIRST | 4.7 | +207.9 | 259.2 | 59.8 | 3.9 | +180.6 | 116.1 | 54.5 |
| BEST OVERALL | 0.6 | +34.7 | 0.0 | 13.6 | 0.6 | +33.5 | 0.0 | 14.9 |
| BEST PREY | 0.7 | +30.6 | 15.0 | 4.0 | 1.0 | +56.4 | 12.2 | 13.2 |
| BEST PRIZE | - | - | - | - | 0.1 | -10.3 | 1.2 | 11.0 |
| BIG CHARACTER SAFETY | 0.1 | -1.0 | 0.0 | 13.1 | 0.2 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.8 | 5.2 | 0.1 | +0.0 | 5.4 | 0.0 |
| BLOCKED WHEEL | 0.2 | +2.8 | 0.0 | 10.6 | 0.4 | +9.8 | 0.0 | 7.9 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -42.4 | 67.5 | 0.0 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 79.2 | 3.5 | 0.1 | +0.0 | 31.7 | 2.8 |
| CANNON PLANNED TARGET | 5.8 | +171.3 | 385.0 | 91.4 | 1.4 | +42.0 | 57.3 | 20.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | -0.9 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -5.7 | 20.6 | 6.0 | 0.2 | -0.6 | 48.2 | 19.8 |
| CAST JOB | 0.8 | +26.5 | 50.3 | 11.5 | 0.8 | +18.4 | 22.6 | 28.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +15.4 | 13.6 | 8.9 | 0.1 | +3.4 | 11.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 59.9 | 0.5 | +0.0 | 0.0 | 14.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.7 | 0.0 | 8.4 | 0.2 | -0.3 | 0.0 | 0.0 |
| CHARGE BAND | - | - | - | - | 0.1 | +0.0 | 18.3 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 219.0 | 84.2 | 2.2 | +0.0 | 221.1 | 39.7 |
| CHARGE NOW WEIGHED | 0.3 | -13.7 | 3.9 | 27.3 | 0.6 | -56.8 | 24.5 | 43.5 |
| CHARGER SLAIN LOST | - | - | - | - | 0.9 | -11.3 | 54.0 | 41.0 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -3.2 | 16.1 | 26.0 |
| CHEAP HELPER | 0.1 | +0.0 | 4.5 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 51.3 | 31.7 | 0.4 | +0.0 | 16.9 | 14.2 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 1.2 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +77.6 | 29.8 | 39.7 | 0.6 | +43.1 | 7.4 | 20.6 |
| COUNTER-CHARGE COVER | 10.4 | +853.2 | 0.0 | 199.9 | 7.8 | +704.0 | 0.0 | 118.2 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 15.0 | 2.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.5 | 16.4 | 1.4 | 0.3 | +7.0 | 34.6 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +134.9 | 0.0 | 48.0 | 1.0 | +73.7 | 0.0 | 25.6 |
| FALLBACK BY WORTH | 5.0 | +96.1 | 0.0 | 118.7 | 6.0 | +67.7 | 0.0 | 27.8 |
| FIGHT LIFT | 0.1 | +0.4 | 0.8 | 0.0 | 0.0 | +1.4 | 7.3 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 208.4 | 4.6 | +0.0 | 0.0 | 100.7 |
| FOCUS FIRE | - | - | - | - | 0.1 | +2.0 | 1.2 | 1.7 |
| FOLLOW UP WEIGHED | 1.3 | +207.7 | 0.0 | 61.3 | 0.8 | +93.1 | 0.0 | 22.5 |
| FRIENDS SHOTS CHECKED | 0.3 | +23.6 | 0.0 | 25.5 | 0.2 | +35.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 10.7 | 0.0 | 0.0 | -1.3 | 13.9 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 7.0 | 3.9 | 0.1 | +0.0 | 4.6 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 36.1 | 9.1 | 0.4 | +0.0 | 15.2 | 9.9 |
| HILL BY ITS CHANCE | 0.2 | -17.8 | 0.0 | 1.8 | 0.4 | -45.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 7.9 | -199.0 | 448.3 | 106.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +10.3 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +19.0 | 0.0 | 5.4 | 0.8 | +52.5 | 0.0 | 26.7 |
| HUNT KEPT | 0.1 | +6.3 | 0.0 | 1.5 | 0.0 | +1.1 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +27.6 | 12.1 | 0.8 |
| HUNT THE GUNS | 0.1 | +45.0 | 0.0 | 0.0 | 0.2 | +77.1 | 10.6 | 0.8 |
| INVITES THE FIGHT | 1.5 | +32.6 | 62.5 | 7.2 | 0.9 | +25.2 | 72.8 | 13.3 |
| JOINT CHARGE PLAN | 0.2 | +19.0 | 0.0 | 0.0 | 0.4 | +14.3 | 16.7 | 9.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.9 | 0.0 | 3.2 |
| KEEP FALLS | 0.2 | +2.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 109.5 | 15.0 | 1.5 | +45.8 | 152.8 | 27.3 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +65.2 | 150.9 | 33.8 | 1.8 | +76.6 | 162.8 | 29.9 |
| KILLS COUNT NEXT TURN | 5.3 | +211.1 | 101.2 | 173.8 | 7.6 | +260.2 | 271.5 | 87.9 |
| LONE CHARACTER SAFE SPOT | 0.5 | +21.2 | 7.9 | 29.6 | 0.3 | +11.4 | 12.3 | 18.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 10.7 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -2.9 | 33.4 | 8.7 | 0.4 | -2.5 | 29.8 | 7.8 |
| LOST CHARGE | 2.7 | -50.9 | 84.2 | 84.3 | 2.2 | -29.4 | 55.4 | 40.6 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.7 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +85.5 | 7.1 | 45.7 | 1.0 | +77.1 | 68.8 | 45.6 |
| MANOEUVRE | 0.4 | +26.1 | 0.0 | 5.1 | 0.1 | +7.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.3 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +64.0 | 0.0 | 7.2 | 0.8 | +31.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +12.1 | 0.0 | 0.0 | 0.2 | +10.9 | 10.6 | 5.7 |
| MARCH OVER CASTS | 0.6 | +63.8 | 0.0 | 0.0 | 0.4 | +26.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +196.4 | 0.0 | 122.8 | 4.4 | +185.6 | 0.0 | 99.3 |
| MISSILES IN THE MOVE | 3.8 | +116.6 | 0.0 | 116.2 | 4.3 | +90.3 | 0.0 | 94.3 |
| MISSILES NEXT TURN | 5.2 | +90.0 | 0.0 | 131.7 | 5.2 | +61.5 | 0.0 | 65.1 |
| MODEL FACING | 0.1 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.5 | +0.0 | 54.4 | 10.2 | 0.2 | +0.0 | 19.3 | 0.0 |
| MOVE AND CAST | 0.3 | +24.8 | 0.0 | 5.4 | 0.8 | +40.9 | 0.0 | 16.6 |
| MOVE SPELL IN RANGE | 0.3 | +12.3 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.0 | 0.0 | 32.9 | 0.1 | -2.1 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 6.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.4 | +254.0 | 74.7 | 143.4 | 4.4 | +355.7 | 185.2 | 72.6 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +15.0 | 3.6 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -8.3 | 9.9 | 0.0 | 0.2 | -7.2 | 11.8 | 0.0 |
| NOT TURNED | 6.6 | +112.4 | 0.0 | 173.4 | 4.9 | +52.5 | 0.0 | 89.4 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 31.0 | 0.9 | -1.0 | 0.0 | 16.2 |
| OFF BEST | 16.1 | -844.8 | 0.0 | 293.2 | 14.7 | -890.5 | 8.9 | 231.0 |
| OPENS A LANE | 0.1 | +0.5 | 15.2 | 0.0 | 0.3 | +4.3 | 36.3 | 12.2 |
| OPENS UP | 0.3 | +33.0 | 18.0 | 18.0 | 0.1 | +4.6 | 2.7 | 0.0 |
| OVERRUNS AWAY | 0.4 | +11.3 | 48.9 | 26.0 | 0.3 | +0.9 | 29.6 | 4.6 |
| PATHS CROSS | 2.0 | +166.2 | 0.0 | 17.4 | 2.5 | +174.5 | 0.0 | 24.9 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.6 | 0.0 | 10.2 | 0.1 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 36.1 | +1256.0 | 1160.4 | 962.8 | 38.3 | +1382.3 | 1543.7 | 812.5 |
| PURSUES BIG PREY | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -5.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 3.4 | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +6.6 | 0.0 | 14.2 | 1.7 | +18.5 | 0.0 | 58.9 |
| RANDOM MOVER NO PROMISE | 0.0 | -3.5 | 0.0 | 0.0 | 0.6 | -26.7 | 19.2 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -6.1 | 0.0 | 5.2 | 0.8 | -19.0 | 0.0 | 5.9 |
| REDIRECT COUNTER | 2.2 | +153.4 | 0.0 | 37.5 | 3.7 | +279.6 | 0.0 | 53.8 |
| REDIRECT WEIGHED | 0.4 | +4.6 | 4.9 | 5.4 | 0.3 | +5.9 | 17.2 | 7.0 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 10.7 |
| RESERVE FALL BACK | 0.5 | +15.7 | 0.0 | 0.0 | 1.5 | +50.3 | 0.0 | 4.1 |
| RESTRAINS TO SHOOT | 0.1 | +2.6 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +80.8 | 222.4 | 77.9 | 2.5 | +78.7 | 203.4 | 51.9 |
| SAFER THAN THE JOB | 0.8 | +64.4 | 0.0 | 12.4 | 1.0 | +54.5 | 0.0 | 1.5 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -0.4 | 0.0 | 0.0 | 0.2 | -12.8 | 0.0 | 2.3 |
| SEARCH SPOT | 2.2 | +127.2 | 0.0 | 45.4 | 2.3 | +88.6 | 0.0 | 21.6 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +90.2 | 0.0 | 40.1 | 0.1 | +32.9 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.2 | +133.6 | 14.7 | 55.2 | 2.1 | +164.3 | 68.8 | 85.2 |
| SET-UP ANY TARGET | 0.6 | +152.6 | 19.3 | 8.8 | 0.2 | +22.5 | 0.0 | 6.5 |
| SET-UP MISSED | 0.1 | +7.2 | 0.0 | 0.0 | 0.0 | +4.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +46.1 | 40.6 | 9.2 | 1.0 | +31.4 | 55.8 | 26.7 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.2 | +0.0 | 46.4 | 0.0 | 0.4 | +0.0 | 60.7 | 4.6 |
| SHOTS IN THE MOVE | 14.0 | +684.1 | 0.0 | 191.1 | 10.3 | +374.7 | 0.0 | 101.6 |
| SPELL SETS UP CHARGE | 0.7 | +179.2 | 29.8 | 19.3 | 0.2 | +22.5 | 0.0 | 6.5 |
| SPELL WORTH | 1.4 | +16.5 | 50.7 | 40.1 | 2.4 | +35.1 | 55.5 | 48.2 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.5 | -7.7 | 74.1 | 18.2 |
| STABLE ROLE | 10.1 | +0.0 | 286.2 | 196.8 | 8.9 | +0.0 | 300.5 | 101.0 |
| STAY WEIGHED | 0.1 | +0.3 | 0.0 | 1.5 | 0.0 | +5.2 | 0.0 | 0.0 |
| STOPS | 0.1 | +3.3 | 0.0 | 1.5 | 0.1 | +3.1 | 10.6 | 0.8 |
| STOPS SHORT OF THE FLANK | 0.6 | +29.4 | 0.0 | 26.5 | 0.4 | +23.6 | 0.0 | 4.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.2 | -42.4 | 252.1 | 105.4 | 6.4 | -56.8 | 316.9 | 60.4 |
| SUPPORTS | 3.3 | +49.2 | 98.4 | 59.4 | 4.6 | +60.4 | 140.8 | 34.7 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.9 | 3.8 | 0.0 | 0.1 | -1.6 | 6.3 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -0.0 | 0.0 | 16.3 | 0.6 | +0.2 | 15.6 | 26.7 |
| THROUGH LINE OF FIRE | 0.4 | +11.1 | 0.0 | 12.9 | 0.5 | +30.6 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -45.9 | 47.3 | 18.0 | 0.2 | -14.4 | 19.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +2.5 | 0.0 | 1.2 | 0.8 | +6.8 | 13.9 | 33.3 |
| WAIT AFTER COSTS | 6.8 | -305.9 | 158.9 | 208.3 | 6.6 | -357.6 | 316.1 | 94.4 |
| WALKS TO THE FIGHT | 1.8 | +41.3 | 15.9 | 50.6 | 0.7 | +6.7 | 23.6 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +12.3 | 4.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 54.3 | 17.2 | 0.2 | +0.0 | 7.6 | 0.0 |
| WEARS DOWN | 1.1 | +42.8 | 82.1 | 38.2 | 1.1 | +49.2 | 108.8 | 37.1 |
| WHO HITS BACK | 0.2 | +24.0 | 0.0 | 0.0 | 0.2 | +9.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +9.1 | 22.7 | 12.0 | 0.4 | +25.2 | 28.9 | 4.1 |
| WHOLE FIGHT GAIN | 0.3 | +34.9 | 24.4 | 3.9 | 0.6 | +43.7 | 36.0 | 6.9 |
| WIDER SPREAD | - | - | - | - | 3.0 | -9.7 | 273.1 | 17.3 |

### Rule changes: cw-h2h-opp-3cc170f-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1108 | 1108 | 1108 | 30.78 | -62469 | -56.4 |
| BEST FIRST | 308 | 308 | 308 | 8.56 | +13988 | +45.4 |
| COUNTER-CHARGE COVER | 652 | 364 | 166 | 4.61 | +10514 | +63.3 |
| PATHS CROSS | 164 | 164 | 164 | 4.56 | +12264 | +74.8 |
| SEARCH SPOT | 160 | 160 | 160 | 4.44 | +7768 | +48.5 |
| MOVE TO CHARGE | 284 | 284 | 141 | 3.92 | +8142 | +57.7 |
| KILLS COUNT NEXT TURN | 465 | 465 | 133 | 3.69 | +3784 | +28.5 |
| SUPPORTS | 282 | 282 | 103 | 2.86 | +1119 | +10.9 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +7510 | +75.9 |
| SHOTS IN THE MOVE | 876 | 591 | 89 | 2.47 | +3835 | +43.1 |
| FALLBACK BY WORTH | 396 | 396 | 88 | 2.44 | +5893 | +67.0 |
| FOLLOW UP WEIGHED | 78 | 78 | 78 | 2.17 | +10827 | +138.8 |
| ARTILLERY RE-ROLL WEIGHED | 77 | 77 | 77 | 2.14 | +0 | +0.0 |
| RESERVE FALL BACK | 74 | 74 | 74 | 2.06 | +2375 | +32.1 |
| SAFER THAN THE JOB | 65 | 65 | 65 | 1.81 | +4281 | +65.9 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| REDIRECT COUNTER | 215 | 114 | 56 | 1.56 | +4437 | +79.2 |
| WAIT AFTER COSTS | 483 | 483 | 50 | 1.39 | +716 | +14.3 |
| CANNON PLANNED TARGET | 260 | 260 | 48 | 1.33 | -800 | -16.7 |
| SET UP TOGETHER | 119 | 103 | 48 | 1.33 | +2822 | +58.8 |
| BEST FACING | 47 | 47 | 47 | 1.31 | +1910 | +40.6 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +2453 | +58.4 |
| MARCH CHECK | 53 | 50 | 42 | 1.17 | +3270 | +77.9 |
| MOVE AND CAST | 42 | 42 | 42 | 1.17 | +2363 | +56.3 |
| RISK BY ARC | 178 | 172 | 42 | 1.17 | +1268 | +30.2 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 41 | 1.14 | +902 | +22.0 |
| WALKS TO THE FIGHT | 89 | 89 | 40 | 1.11 | +616 | +15.4 |
| CHARGE NOW FIRST | 172 | 172 | 39 | 1.08 | -1586 | -40.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 36 | 36 | 36 | 1.00 | +1906 | +53.0 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MAX FOR POSITIONING | 348 | 178 | 35 | 0.97 | +371 | +10.6 |
| CHARGE NOW WEIGHED | 34 | 34 | 34 | 0.94 | +1548 | +45.5 |
| MISSILES IN THE MOVE | 294 | 171 | 34 | 0.94 | +472 | +13.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOOTS FROM THE BEST SPOT | 63 | 63 | 33 | 0.92 | +1340 | +40.6 |
| CAST JOB | 59 | 59 | 32 | 0.89 | +576 | +18.0 |
| KILLS COUNT | 120 | 117 | 31 | 0.86 | +1284 | +41.4 |
| THROUGH LINE OF FIRE | 30 | 30 | 30 | 0.83 | +1500 | +50.0 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +649 | +26.0 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| INVITES THE FIGHT | 87 | 87 | 24 | 0.67 | +382 | +15.9 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +454 | +19.7 |
| FRIENDS SHOTS CHECKED | 21 | 21 | 21 | 0.58 | +2112 | +100.6 |
| SHOT REPLANNED | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BEST PREY | 60 | 60 | 20 | 0.56 | +693 | +34.7 |
| MAKE SURE TOGETHER | 62 | 43 | 20 | 0.56 | +1452 | +72.6 |
| KEEPS ITS TARGET | 106 | 102 | 18 | 0.50 | +262 | +14.6 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WAR ENGINE JOBS | 36 | 36 | 18 | 0.50 | -641 | -35.6 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +1215 | +71.5 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -36 | -2.3 |
| HONEST WORTH | 285 | 282 | 15 | 0.42 | +93 | +6.2 |
| WHOLE FIGHT GAIN | 33 | 32 | 15 | 0.42 | +863 | +57.5 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MARCH ODDS | 13 | 13 | 13 | 0.36 | +162 | +12.5 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -72 | -6.0 |
| WEARS DOWN | 82 | 79 | 12 | 0.33 | +375 | +31.2 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +757 | +63.1 |
| LOST CHARGE | 175 | 173 | 11 | 0.31 | +368 | +33.5 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 8 | 0.22 | +240 | +30.0 |
| OPENS UP | 13 | 12 | 8 | 0.22 | +433 | +54.1 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| HUNT IN PAIRS | 40 | 24 | 7 | 0.19 | +468 | +66.9 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +231 | +33.0 |
| MISSILES NEXT TURN | 377 | 207 | 7 | 0.19 | +38 | +5.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| SUPPORT NARROWED | 416 | 416 | 6 | 0.17 | -21 | -3.6 |
| WHOLE FIGHT | 20 | 18 | 6 | 0.17 | +261 | +43.5 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -29 | -5.7 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -227 | -45.3 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CARRIES OUT SET-UP | 11 | 11 | 4 | 0.11 | -229 | -57.2 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +108 | +26.9 |
| SURE REACH TOGETHER | 38 | 27 | 4 | 0.11 | +43 | +10.7 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -370 | -123.5 |
| CHARGE BAND | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +71 | +23.7 |
| JOINT CHARGE PLAN | 20 | 20 | 3 | 0.08 | +125 | +41.7 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +962 | +320.8 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 37 | 37 | 3 | 0.08 | +67 | +22.4 |
| REFUSING RETIRES | 6 | 6 | 3 | 0.08 | -1 | -0.4 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +178 | +59.3 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +201 | +67.0 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -91 | -30.4 |
| TWO OR MORE ARRIVE | 39 | 34 | 3 | 0.08 | +9 | +2.8 |
| BACKUP TARGETS | 65 | 29 | 2 | 0.06 | +3 | +1.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| DEFENSIVE ARMY | 10 | 10 | 2 | 0.06 | -76 | -38.2 |
| HUNT ADVANCE | 9 | 9 | 2 | 0.06 | +111 | +55.4 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 2 | 0.06 | -247 | -123.3 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +32 | +15.9 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +109 | +54.4 |
| RAIDS THE BAGGAGE | 3 | 3 | 2 | 0.06 | +309 | +154.3 |
| WIDER SPREAD | 109 | 102 | 2 | 0.06 | +7 | +3.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -34 | -33.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -7 | -7.2 |
| CHARGER SLAIN LOST | 31 | 27 | 1 | 0.03 | +35 | +35.0 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -48 | -48.2 |
| EDGE GIVE GROUND | 17 | 17 | 1 | 0.03 | +10 | +9.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HILL BY ITS CHANCE | 23 | 23 | 1 | 0.03 | +9 | +9.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 23 | 22 | 1 | 0.03 | -44 | -44.5 |
| OPENS A LANE | 12 | 10 | 1 | 0.03 | +3 | +2.7 |
| OVERRUNS AWAY | 25 | 25 | 1 | 0.03 | +19 | +19.1 |
| SPELLS IN THE FIGHT | 17 | 15 | 1 | 0.03 | +0 | +0.2 |
| STOPS | 8 | 8 | 1 | 0.03 | +28 | +28.3 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 11 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 23 | 23 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 49 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 55 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 417 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 35 | 35 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 26 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 414 | 414 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| PLAN RESULT | 2681 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 32 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 35 | not checked | - | - | - | - |
| SPELL WORTH | 138 | not checked | - | - | - | - |
| STABLE ROLE | 686 | 685 | 0 | 0.00 | - | - |
| TURN WORTH | 27 | 25 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-opp-3cc170f-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.72 | 13.00 | 58.2 |
| FALLBACK | gate | 0.81 | 0.69 | 46.2 |
| TURN GATE | gate | 1.08 | 0.39 | 51.8 |
| CHARGE NOW FIRST | rule | 0.56 | 0.50 | 41.7 |
| WAR ENGINE JOBS | rule | 0.42 | 0.08 | 35.6 |
| CANNON PLANNED TARGET | rule | 0.19 | 0.19 | 74.0 |
| AFTERMATH BAND | gate | 0.14 | 0.19 | 3.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.14 | 70.8 |
| PATHS CROSS | rule | 0.11 | 0.14 | 45.2 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.14 | 15.2 |
| SUPPORT REQUEST | gate | 0.03 | 0.17 | 53.2 |
| CHAFF PASSED | rule | 0.08 | 0.08 | 5.9 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 146.6 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.08 | 5.7 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 21.6 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.06 | 57.2 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 60.1 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 5.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 14.8 |
| BEST PRIZE | rule | - | 0.08 | 123.5 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.5 |
| SAFER THAN THE JOB | rule | - | 0.08 | 11.9 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 19.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.06 | 30.4 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 2.3 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 38.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 123.3 |
| MARCH ODDS | rule | - | 0.06 | 16.7 |
| NO REASON | gate | - | 0.06 | 22.9 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 33.9 |
| CATCH ODDS | rule | - | 0.03 | 7.2 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 48.2 |
| FACES THE THREAT | rule | 0.03 | - | 11.7 |
| FALLBACK BY WORTH | rule | - | 0.03 | 2.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.3 |
| LONG SHOT | rule | 0.03 | - | 44.5 |
| REDIRECT WEIGHED | rule | - | 0.03 | 25.7 |
| REFUSING RETIRES | rule | - | 0.03 | 0.8 |
| RULE SWITCHED OFF | gate | 0.03 | - | 4.3 |

### Plans: cw-h2h-opp-3cc170f-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 18% | 419 | 328 | 78% |
| Mine | charge | 2.9 | 60% | 348 | 246 | 71% |
| Mine | close in | 4.3 | 19% | 354 | 108 | 30% |
| Mine | hold | 4.3 | 34% | 262 | 0 | 0% |
| Mine | join | 0.5 | 95% | 15 | 0 | 0% |
| Mine | shoot | 8.9 | 59% | 272 | 575 | 212% |
| Mine | support | 3.5 | 89% | 34 | 0 | 0% |
| Opponent | advance | 12.9 | 17% | 365 | 429 | 118% |
| Opponent | charge | 3.9 | 61% | 344 | 368 | 107% |
| Opponent | close in | 5.9 | 21% | 331 | 187 | 56% |
| Opponent | hold | 3.7 | 28% | 262 | 0 | 0% |
| Opponent | join | 0.7 | 96% | 24 | 0 | 0% |
| Opponent | shoot | 5.9 | 57% | 177 | 400 | 226% |
| Opponent | support | 5.3 | 90% | 54 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-opp-3cc170f-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 405 | 0 | 0% | 14 |
| Opponent | 0.2 | 8 | 0 | 38% | 38% | 0% | 2.0 | 347 | 124 | 38% | 61 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 405 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| High Elf Realms | 0.3 | 2 | 0 | 100% | 100% | 0% | 2.0 | 466 | 391 | 100% | 25 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 298 | 71 | 33% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 447 | 0 | 0% | 50 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 251 | 0 | 0% | 6 |

### Battle groups: cw-h2h-opp-3cc170f-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.4 | 23% | 44% | 8% | 29% | 29% | 9% | 13% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 30% | 79% | 4% | 0% | 17% | 4% | 4% | 70% | 4% |
| Opponent | COUNTER-CHARGE COVER | 7.8 | 18% | 66% | 16% | 25% | 31% | 10% | 5% | 55% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 23% | 77% | 16% | 20% | 19% | 0% | 4% | 77% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-opp-3cc170f-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 55 (34) | 20 | 35 | 57 | 35% | 2.7 | 54 (21) | 0 (4) | 77 (9) | 62 (24) | 42 (10) |
| Mine | Character | 119 | 36 (119) | 36 | 0 | 36 | 16% | 2.5 | 53 (37) | 29 (60) | 47 (7) | 43 (60) | 34 (44) |
| Mine | Clean-up | 18 | 74 (18) | 39 | 35 | 39 | 39% | 2.2 | 42 (3) | 65 (13) | 264 (2) | 107 (12) | 24 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 35 (44) | 14 | 21 | 46 | 23% | 2.9 | 34 (22) | 29 (14) | 50 (8) | 37 (30) | 31 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 4.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 32 (52) | 18 | 15 | 37 | 17% | 2.8 | 20 (14) | 37 (35) | 35 (3) | 38 (36) | 21 (16) |
| Mine | Holder | 25 | 56 (25) | 15 | 42 | 24 | 48% | 3.4 | 114 (6) | 37 (14) | 74 (4) | 76 (14) | 31 (10) |
| Mine | Shooter | 37 | 60 (37) | 42 | 18 | 38 | 0% | 1.7 | 8 (6) | 69 (28) | 72 (3) | 51 (23) | 77 (14) |
| Mine | Support | 4 | 195 (4) | 195 | 0 | 0 | 25% | 2.0 | 0 (1) | 337 (3) | - | - | 195 (4) |
| Mine | War machine | 52 | 33 (52) | 33 | 0 | 34 | 2% | 1.1 | 42 (13) | 33 (36) | 0 (3) | 4 (13) | 44 (39) |
| Mine | Wizard | 16 | 0 (16) | 0 | 0 | 26 | 19% | 2.2 | 0 (5) | 0 (6) | 0 (2) | 0 (7) | 0 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 46 (68) | 13 | 33 | 40 | 40% | 2.9 | 34 (29) | 83 (11) | 38 (28) | 58 (48) | 19 (20) |
| Opponent | Character | 102 | 55 (102) | 55 | 0 | 25 | 15% | 2.2 | 63 (38) | 57 (54) | 13 (5) | 60 (55) | 55 (42) |
| Opponent | Clean-up | 12 | 52 (12) | 4 | 48 | 49 | 42% | 3.9 | 0 (4) | 72 (7) | 74 (1) | 12 (6) | 80 (6) |
| Opponent | Fast | 1 | 75 (1) | 75 | 0 | 100 | 0% | 3.0 | - | 75 (1) | - | 75 (1) | - |
| Opponent | Fast Hammer | 59 | 35 (59) | 22 | 13 | 34 | 32% | 2.7 | 35 (29) | 34 (20) | 36 (10) | 40 (27) | 30 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 27 (47) | 21 | 6 | 38 | 34% | 3.0 | 21 (16) | 29 (28) | 42 (3) | 36 (29) | 13 (18) |
| Opponent | Holder | 40 | 70 (40) | 9 | 61 | 31 | 40% | 2.4 | 43 (8) | 120 (19) | 10 (12) | 81 (29) | 51 (10) |
| Opponent | Shooter | 30 | 47 (30) | 27 | 21 | 25 | 3% | 1.1 | 25 (8) | 46 (20) | 212 (2) | 35 (18) | 65 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 50% | 5.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 26 (17) | 26 | 0 | 36 | 6% | 1.4 | 0 (3) | 0 (10) | 94 (4) | 0 (3) | 30 (14) |
| Opponent | Wizard | 32 | 11 (32) | 11 | 0 | 35 | 19% | 2.3 | 11 (15) | 14 (8) | 0 (2) | 16 (15) | 0 (10) |

### Charged fights: cw-h2h-opp-3cc170f-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 55 | 243 | 2.0 | 1.2 | 121 | 6 | +115 | 1 of 8 | 6 of 8 | +81 | +126 |
| Mine | Chaos Dwarfs | 4 | 77 | 249 | 2.8 | 1.0 | 91 | 28 | +62 | 5 of 11 | 11 of 11 | - | +62 |
| Mine | Dwarfen Mountain Holds | 3 | 503 | 0 | 2.0 | 1.3 | 0 | 21 | -21 | 0 of 6 | 3 of 6 | +0 | -31 |
| Mine | Empire of Man | 5 | 382 | 84 | 1.4 | 1.1 | 60 | 0 | +60 | 2 of 7 | 7 of 7 | +0 | +70 |
| Mine | Grand Cathay | 5 | 228 | 487 | 3.6 | 1.1 | 135 | 11 | +124 | 5 of 18 | 15 of 18 | +272 | +105 |
| Mine | High Elf Realms | 4 | 220 | 210 | 3.0 | 1.1 | 70 | 0 | +70 | 3 of 12 | 9 of 12 | +365 | +43 |
| Mine | Kingdom of Bretonnia | 1 | 38 | 532 | 3.0 | 1.7 | 177 | 92 | +85 | 0 of 3 | 2 of 3 | -277 | +266 |
| Mine | Lizardmen | 1 | 0 | 421 | 3.0 | 1.7 | 140 | 47 | +93 | 2 of 3 | 3 of 3 | +110 | +85 |
| Mine | Ogre Kingdoms | 1 | 481 | 0 | 2.0 | 1.0 | 0 | 114 | -114 | 1 of 2 | 1 of 2 | - | -114 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 444 | 3.0 | 1.0 | 148 | 0 | +148 | 1 of 3 | 3 of 3 | - | +148 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 98 | 414 | 5.5 | 1.0 | 75 | 0 | +75 | 4 of 11 | 7 of 11 | - | +75 |
| Mine | Vampire Counts | 2 | 0 | 446 | 1.5 | 1.0 | 298 | 0 | +298 | 1 of 3 | 3 of 3 | - | +298 |
| Mine | Warriors of Chaos | 2 | 0 | 15 | 1.5 | 1.0 | 10 | 0 | +10 | 0 of 3 | 2 of 2 | - | +10 |
| **Mine** | all armies | 36 | 186 | 245 | 2.5 | 1.1 | 97 | 15 | +82 | 25 of 91 | 72 of 90 | +90 | +81 |
| Opponent | Empire of Man | 1 | 679 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 250 | 414 | 2.7 | 1.2 | 155 | 0 | +155 | 4 of 8 | 6 of 8 | +364 | +86 |
| Opponent | High Elf Realms | 3 | 248 | 98 | 2.7 | 1.0 | 37 | 140 | -103 | 3 of 8 | 6 of 8 | - | -103 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 192 | 1.5 | 1.0 | 128 | 27 | +102 | 2 of 3 | 2 of 3 | - | +102 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 435 | 6.0 | 1.2 | 72 | 42 | +30 | 2 of 6 | 4 of 6 | +176 | +1 |
| Opponent | Skaven | 1 | 320 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 80 | 724 | 4.0 | 1.1 | 181 | 12 | +169 | 8 of 16 | 11 of 16 | +95 | +174 |
| Opponent | Vampire Counts | 6 | 121 | 514 | 4.2 | 1.2 | 123 | 7 | +116 | 9 of 25 | 20 of 25 | +151 | +105 |
| Opponent | Warriors of Chaos | 9 | 22 | 496 | 3.6 | 1.1 | 140 | 30 | +109 | 11 of 32 | 25 of 32 | +170 | +100 |
| Opponent | Wood Elf Realms | 6 | 179 | 198 | 2.8 | 1.0 | 70 | 42 | +28 | 5 of 17 | 11 of 16 | - | +28 |
| **Opponent** | all armies | 36 | 134 | 389 | 3.2 | 1.1 | 122 | 31 | +91 | 44 of 115 | 85 of 114 | +185 | +78 |

### Effective charges: cw-h2h-opp-3cc170f-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 3 (net +83) | 0 | 0 | 1 (net +162) | 0 | 3 (net +149) | 1 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 11 | 0 | 0 | 2 (net +78) | 4 (net +48) | 0 | 3 (net +0) | 2 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +0) | 1 (net -65) | 0 | 1 (net -60) | 0 | 2 (net +0) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 4 (net +105) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 18 | 1 (net -205) | 1 (net +386) | 5 (net +225) | 3 (net +50) | 2 (net +168) | 5 (net +61) | 1 | 29% (5 of 17) |
| Mine | High Elf Realms | 12 | 0 | 0 | 2 (net +28) | 1 (net +0) | 5 (net +96) | 2 (net +118) | 2 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +190) | 0 | 0 | 1 (net -277) | 1 (net +342) | 0 | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 1 (net +170) | 1 (net +110) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net -228) | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +137) | 2 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +0) | 0 | 0 | 6 (net +44) | 3 (net +188) | 0 | 0 | 0% (0 of 11) |
| Mine | Vampire Counts | 3 | 0 | 0 | 1 (net +608) | 1 (net +285) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Warriors of Chaos | 3 | 2 (net +0) | 1 (net +30) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 8 | 1 (net +0) | 0 | 2 (net +364) | 1 (net +85) | 0 | 2 (net +28) | 2 | 33% (2 of 6) |
| Opponent | High Elf Realms | 8 | 1 (net -347) | 1 (net +0) | 2 (net -238) | 2 (net +65) | 0 | 1 (net -177) | 1 | 29% (2 of 7) |
| Opponent | Kingdom of Bretonnia | 3 | 2 (net +68) | 0 | 0 | 1 (net +168) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +199) | 1 (net +176) | 0 | 4 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 16 | 2 (net +280) | 0 | 2 (net +132) | 6 (net +213) | 1 (net +95) | 3 (net +76) | 2 | 14% (2 of 14) |
| Opponent | Vampire Counts | 25 | 4 (net +78) | 0 | 8 (net +96) | 5 (net +213) | 3 (net +116) | 3 (net +75) | 2 | 35% (8 of 23) |
| Opponent | Warriors of Chaos | 32 | 6 (net -8) | 2 (net +0) | 2 (net -201) | 8 (net +231) | 2 (net +0) | 10 (net +221) | 2 | 7% (2 of 30) |
| Opponent | Wood Elf Realms | 17 | 2 (net +0) | 0 | 2 (net -55) | 3 (net +170) | 0 | 3 (net +68) | 7 | 20% (2 of 10) |

### Charged fights, damage counted: cw-h2h-opp-3cc170f-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 230 | 248 | +18 | 85 | 62 | +23 | +10.2 |
| Mine | 50-54% | 3 | 104 | 157 | +117 | 156 | 24 | +132 | +127.4 |
| Mine | Effective (55-75%) | 11 | 317 | 252 | +177 | 218 | 82 | +137 | +43.1 |
| Mine | 76-89% | 22 | 300 | 163 | +40 | 70 | 24 | +46 | +15.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 258 | 164 | +60 | 88 | 24 | +65 | +25.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 493 | 105 | +152 | 184 | 17 | +168 | +34.0 |
| Mine | No odds | 8 | 338 | 121 | +114 | 121 | 9 | +112 | +33.2 |
| Mine | All fights | 91 | 304 | 175 | +82 | 117 | 34 | +83 | +27.2 |
| Opponent | Long shot (under 50%) | 18 | 231 | 256 | +34 | 119 | 88 | +31 | +13.6 |
| Opponent | 50-54% | 3 | 399 | 371 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 18 | 382 | 233 | +43 | 155 | 123 | +32 | +8.4 |
| Opponent | 76-89% | 27 | 275 | 211 | +196 | 231 | 31 | +200 | +72.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 267 | 164 | +125 | 148 | 29 | +119 | +44.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 529 | 134 | +88 | 104 | 9 | +95 | +18.0 |
| Opponent | No odds | 20 | 154 | 166 | +22 | 88 | 58 | +30 | +19.8 |
| Opponent | All fights | 115 | 281 | 204 | +91 | 147 | 56 | +91 | +32.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-opp-3cc170f-p3 | move | 427 | 69 (16%) | 49 (11%) | 65 (15%) | 293 (69%) |
| cw-h2h-opp-3cc170f-p3 | objective | 370 | 43 (12%) | 31 (8%) | 61 (16%) | 266 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

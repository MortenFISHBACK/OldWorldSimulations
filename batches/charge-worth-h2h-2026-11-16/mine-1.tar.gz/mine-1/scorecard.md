# Doctrine scorecard: cw-h2h-mine-3cc170f-p1

### Scorecard: cw-h2h-mine-3cc170f-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 21 | 3 | 2 | 1 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 2 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 3 | 4 | 2 | 1 | 0 | 0 | 0 | 77 |
| L0118 | 4 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 6 | 3 | 4 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 5 | 4 | 1 | 0 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 3 | - | 0 | 3 | 2 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 2 | 3 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 2 | 1 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 2 | 1 | 3 | 2 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 5 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 679 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 501 |
| L1021 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 4 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 3 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 1 | 5 | 2 | 3 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | yes | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 300 |
| L1431 | 3 | 1 | Opponent | no | 3 | - | 4 | 2 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 260 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 4 | 1 | 0 | 0 | 0 | 68 |
| L1723 | 1 | 1 | Mine | no | 0 | 1 | 3 | 0 | 3 | 0 | 0 | 72 |
| L1723 | 1 | 1 | Opponent | yes | 2 | 2 | 6 | 1 | 3 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 1 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 3 | 3 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | 4 | 1 | 4 | 0 | 0 | 0 | 512 |
| L2127 | 3 | 1 | Opponent | no | 7 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 6 | 0 | 2 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 5 | 2 | 4 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 2.6 | 2.6 | 2.3 | 1.0 | 0.2 | 0.0 | 0.0 | 275.3 |
| **Average** | | | Opponent | 9% | 2.4 | 2.4 | 2.8 | 1.7 | 0.6 | 0.0 | 0.0 | 167.7 |

### KPIs: cw-h2h-mine-3cc170f-p1

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 177) | 3% (6 of 173) | 17% (59 of 350) |
| Winner chose to follow up after the loser gave ground |  | 97% (69 of 71); on the table 97% | 98% (44 of 45); on the table 98% | 97% (113 of 116); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 100% (20 of 20); on the table 100% | 96% (25 of 26); on the table 96% |
| Winner chose to pursue after the loser fled |  | 62% (24 of 39); on the table 69% | 82% (27 of 33); on the table 85% | 71% (51 of 72); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 84% (98 of 116); on the table 87% | 93% (91 of 98); on the table 94% | 88% (189 of 214); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 35% (114 of 330) | 26% (54 of 210) | 31% (168 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (114 of 241) | 41% (54 of 133) | 45% (168 of 374) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 76% (22 of 29) | 65% (36 of 55) | 69% (58 of 84) |
| Points that never fought | lower | 36% (25989 of 71484) | 34% (24524 of 71889) | 35% (50513 of 143373) |
|   infantry points that never fought | lower | 44% (7348 of 16863) | 55% (7298 of 13348) | 48% (14646 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (144 of 279) | 58% (172 of 295) | 55% (316 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.7 uses a game | 75% (15 of 20); 1.2 uses a game | 83% (35 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.8 uses a game | 25% (2 of 8); 0.1 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (26517 of 59666) | 54% (33852 of 62699) | 49% (60369 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (39%) | 1.1 (26%) | 3.5 (34%) |
| MARCHED: its unit marched | 0.8 (12%) | 0.4 (10%) | 1.2 (12%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.1 (3%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.7 (28%) | 0.6 (13%) | 2.2 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (10%) | 0.4 (4%) |
| GONE: slain | 0.6 (10%) | 1.4 (31%) | 1.9 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (5%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 1.1 | 4.7 | 0.5 | 2.0 |
| not cast | 4.0 | 3.3 | 3.6 | 10.3 | 1.8 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.3 (40%) | 0.3 (8%) | 3.5 (34%) | 0.5 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (12%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | 0.5 (16%) | 0.6 (18%) | 2.2 (22%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (10%) | 0.5 (14%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.1 (26%) | 0.5 (14%) | 0.6 (16%) | 1.9 (19%) | 0.1 (8%) | 3.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (1%) | 0.1 (4%) | 0.4 (4%) | 0.0 (0%) | 1.4 (6%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.1 (1%) | 0.3 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (52%) | 0.4 (11%) | 1.4 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.8 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.2 a game | 0.7 a game |
| stood (cast and not dispelled) | 63% (22 of 35) | 44% (4 of 9) | 59% (26 of 44) |
| the unit moved after it | 73% (16 of 22) | 75% (3 of 4) | 73% (19 of 26) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 4) | 0% (0 of 26) |
| the enemy charged it first | 23% (5 of 22) | 25% (1 of 4) | 23% (6 of 26) |
| it fought by the end of its next turn | 14% (3 of 22) | 25% (1 of 4) | 15% (4 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (5 of 22) | 50% (2 of 4) | 27% (7 of 26) |
| none of these (no charge, no fight, no charge escaped) | 55% (12 of 22) | 25% (1 of 4) | 50% (13 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (564 of 908) | 60% (365 of 606) | 61% (929 of 1514) |
|   cavalry | 60% (44 of 73) | 67% (89 of 132) | 65% (133 of 205) |
|   character | 53% (62 of 116) | 30% (32 of 106) | 42% (94 of 222) |
|   chariot | 38% (35 of 91) | 72% (34 of 47) | 50% (69 of 138) |
|   infantry | 58% (175 of 302) | 61% (141 of 231) | 59% (316 of 533) |
|   monster | 68% (25 of 37) | 32% (7 of 22) | 54% (32 of 59) |
|   war machine | 77% (223 of 289) | 91% (62 of 68) | 80% (285 of 357) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (24%) | 1.5 (22%) | 3.8 (23%) |
| CHARGED: it charged | 1.2 (12%) | 1.4 (22%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (9%) | 0.4 (7%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.5 (22%) | 3.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.4 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.1 (22%) | 0.9 (14%) | 3.1 (19%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (4%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.1 (2%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.3 | 81% | 4.8 pts | 25 pts |
| character | 3.1 | 1.0 | 77% | 7.7 pts | 24 pts |
| chariot | 1.9 | 1.1 | 70% | 10.1 pts | 19 pts |
| infantry | 12.8 | 4.6 | 74% | 9.6 pts | 122 pts |
| monster | 1.1 | 0.4 | 76% | 11.6 pts | 12 pts |
| war machine | 7.9 | 5.9 | 63% | 21.2 pts | 168 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 6.1 | 5.3 |
| Charges that made contact a game | 3.5 | 4.1 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.81 contact (21 units) | 0.46 declared, 0.31 contact (13 units) | 0.79 declared, 0.62 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.62 declared, 0.38 contact (8 units) | 1.11 declared, 0.89 contact (9 units) | 0.88 declared, 0.65 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.43 contact (247 units) | 0.73 declared, 0.49 contact (277 units) | 0.65 declared, 0.46 contact (524 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (37 of 70) | 48% (10 of 21) | 38% (3 of 8) | 51% (50 of 99) |
| Character in a unit | 88% (28 of 32) | 62% (15 of 24) | 67% (2 of 3) | 76% (45 of 59) |
| Character on its own | 78% (43 of 55) | 44% (16 of 36) | 29% (18 of 63) | 50% (77 of 154) |
| Chariot | 56% (9 of 16) | 50% (5 of 10) | - | 54% (14 of 26) |
| Infantry | 55% (49 of 89) | 33% (12 of 36) | 50% (1 of 2) | 49% (62 of 127) |
| Monster | 56% (18 of 32) | 70% (7 of 10) | - | 60% (25 of 42) |
| Monstrous | 73% (8 of 11) | 36% (5 of 14) | - | 52% (13 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 83% (19 of 23); on the table 83% | 38% (53 of 138) | 21% | 52% (17 of 33) | 100% (9 of 9); 5.5 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 92% (11 of 12); on the table 92% | 42% (10 of 24) | 27% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 92% (11 of 12); on the table 92% | - | 66% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 76% (13 of 17); on the table 88% | 39% (14 of 36) | 62% | 58% (37 of 64) | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 93% (14 of 15); on the table 100% | 28% (30 of 108) | 46% | 32% (14 of 44) | 92% (11 of 12); 5.8 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 80% (12 of 15); on the table 80% | 27% (8 of 30) | 28% | 55% (27 of 49) | 100% (5 of 5); 2.7 uses a game | 50% (9 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 48% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (7 of 7); on the table 100% | - | 22% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 71% (5 of 7); on the table 86% | 17% (2 of 12) | 37% | 67% (14 of 21) | 67% (2 of 3); 1.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 11% (4 of 36) | 4% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (10 of 10); on the table 100% | 30% (9 of 30) | 26% | 53% (18 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 80% (16 of 20); on the table 80% | 17% (2 of 12) | 26% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 90% (19 of 21); on the table 90% | 33% (18 of 54) | 33% | 70% (35 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 92% (23 of 25); on the table 92% | 27% (8 of 30) | 34% | 64% (47 of 74) | 100% (4 of 4); 1.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (19 of 19); on the table 100% | 33% (10 of 30) | 35% | 55% (36 of 66) | 33% (2 of 6); 1.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-mine-3cc170f-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (36) | 45% (35) | 46% (71) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.53 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.22 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.33 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.64 | 1.19 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.64 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.81 | 4.92 | 9.72 |

### Quality by phase: cw-h2h-mine-3cc170f-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 56% (74 of 131) | 44% (82 of 188) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (181 of 378) | 64% (131 of 204) |
| Strategy | Close-in objectives charged next turn | 14% (21 of 151) | 14% (28 of 196) |
| Strategy | Support requests answered (helper made contact too) | 71% (12 of 17) | 44% (14 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 71% (5 of 7) | 50% (6 of 12) |
| Strategy | Joined characters whose unit fought | 47% (27 of 57) | 47% (16 of 34) |
| Strategy | Lone characters that fought | 79% (70 of 89) | 78% (80 of 102) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 275.3 | 167.7 |
| Movement | Fights charged into per game | 2.8 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 86, net +172 | 19 of 103, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 86, net +68 | 20 of 103, net +94 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 86, net +71 | 5 of 103, net +44 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 86, net +91 | 27 of 103, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (144 of 368) | 39% (132 of 338) |
| Shooting | Points destroyed by shooting units | 88.7 | 47.3 |
| Shooting | War machine shots | 6.2 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (104 of 223) | 40% (25 of 62) |
| Shooting | Points destroyed by war machines | 89.2 | 19.8 |
| Magic | Magic missiles cast | 2.1 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (23 of 75) | 45% (14 of 31) |
| Magic | Wounds caused by magic missiles | 5.7 | 1.2 |
| Magic | Wounds caused by other spells | 2.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 107.8 | 33.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.2 / 1.1 / 0.2 | 1.2 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 383.4 | 300.6 |
| Combat | Points run down | 118.6 | 120.7 |
| Combat | Net points per charged fight, damage counted | +86 | +54 |
| Combat | Net per 100 charger points, damage counted | +28.3 | +20.6 |
| Combat | First round won (charged fights) | 75% | 58% |
| Combat | Net points per charged fight | +86 | +63 |
| Combat | Net points per supported fight / lone fight | +163 / +61 | +180 / +39 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 100 | 55 of 122 |
| Game | Points lost | 639.7 | 845.5 |
| Game | VP from objectives | 663.1 | 577.2 |
| Game | Lone holders (player turns) | 2.6 | 2.4 |

- Mine won / drew / lost: 20 / 5 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +369 VP
- The side that went first won 14 of 31 games with a winner
- Points traded per game (both sides' losses): 1485
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cw-h2h-mine-3cc170f-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 5.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +9.5 | 0.0 | 28.7 | 1.1 | +11.3 | 0.0 | 82.9 |
| BEST FACING | 0.9 | +29.9 | 0.0 | 47.1 | 0.6 | +20.0 | 0.0 | 22.7 |
| BEST FIRST | 4.5 | +185.3 | 247.8 | 79.6 | 3.6 | +205.4 | 133.2 | 81.2 |
| BEST OVERALL | 0.7 | +34.3 | 0.0 | 11.4 | 0.4 | +31.3 | 0.0 | 31.1 |
| BEST PREY | 0.7 | +39.3 | 29.8 | 29.7 | 0.8 | +33.3 | 12.9 | 16.7 |
| BEST PRIZE | 0.1 | +0.5 | 6.7 | 2.4 | 0.1 | +5.7 | 5.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.3 | 0.0 | 0.0 | 0.1 | -0.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 12.1 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| BLOCKED WHEEL | 0.2 | +1.0 | 0.0 | 0.0 | 0.4 | +9.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -28.4 | 32.8 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 83.2 | 13.3 | 0.2 | +0.0 | 39.1 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +142.0 | 377.8 | 54.4 | 1.6 | +46.9 | 61.8 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 9.5 | 0.0 | 0.1 | -4.9 | 0.0 | 15.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 8.4 | 0.0 | 0.2 | -1.0 | 28.3 | 0.0 |
| CAST JOB | 0.7 | +20.1 | 27.3 | 12.3 | 0.3 | +6.5 | 17.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +53.9 | 17.2 | 9.6 | 0.1 | +0.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 11.2 | 0.1 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.7 | 0.0 | 5.6 | 0.1 | -0.5 | 0.0 | 3.8 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 28.7 | 11.1 | - | - | - | - |
| CHARGE NOW FIRST | 2.2 | +0.0 | 237.8 | 56.5 | 2.8 | +0.0 | 194.8 | 91.4 |
| CHARGE NOW WEIGHED | 0.6 | -41.8 | 12.6 | 17.4 | 0.5 | -46.3 | 25.2 | 18.2 |
| CHARGER SLAIN LOST | 0.6 | -16.5 | 69.6 | 20.5 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.9 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.8 | 4.6 |
| COMBAT PIVOT | 0.5 | +0.0 | 47.3 | 22.2 | 0.5 | +0.0 | 5.4 | 69.9 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +158.1 | 17.6 | 33.6 | 0.2 | +48.7 | 13.3 | 21.3 |
| COUNTER-CHARGE COVER | 9.5 | +854.3 | 0.0 | 232.2 | 7.1 | +689.5 | 0.0 | 221.6 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 30.8 | 2.8 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +8.6 | 24.8 | 1.5 | 0.1 | +3.5 | 4.6 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.2 | 7.2 | 0.0 | 0.2 | +17.8 | 20.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +4.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +101.9 | 0.0 | 70.0 | 1.2 | +106.8 | 0.0 | 55.9 |
| FALLBACK BY WORTH | 4.8 | +48.9 | 0.0 | 71.6 | 5.4 | +69.6 | 0.0 | 54.7 |
| FIGHT LIFT | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 143.7 | 5.0 | +0.0 | 0.0 | 154.4 |
| FOCUS FIRE | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +147.2 | 0.0 | 21.2 | 0.8 | +109.4 | 0.0 | 28.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +16.5 | 0.0 | 14.3 | 0.1 | +4.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -3.0 | 19.1 | 0.0 | 0.1 | -1.5 | 36.2 | 9.2 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 15.0 | 2.9 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 9.5 | 0.0 | 0.1 | +0.0 | 15.0 | 1.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 35.1 | 10.3 | 0.4 | +0.0 | 7.4 | 21.3 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -15.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -122.3 | 431.1 | 94.8 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 4.8 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.2 |
| HUNT IN PAIRS | 0.5 | +19.2 | 0.0 | 15.4 | 0.4 | +33.2 | 0.0 | 17.5 |
| HUNT KEPT | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 1.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.9 |
| HUNT THE GUNS | 0.0 | +10.7 | 0.0 | 0.0 | 0.2 | +91.6 | 0.0 | 12.5 |
| INVITES THE FIGHT | 1.6 | +35.6 | 86.2 | 29.3 | 1.8 | +34.4 | 78.3 | 34.4 |
| JOINT CHARGE PLAN | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +11.7 | 17.8 | 4.2 |
| JOINT KNOWS CHALLENGE | 0.1 | -4.7 | 24.6 | 1.5 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 6.1 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.1 | 4.2 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +40.8 | 135.2 | 12.0 | 1.7 | +51.7 | 91.4 | 51.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +74.8 | 145.0 | 17.0 | 1.9 | +80.5 | 137.4 | 75.1 |
| KILLS COUNT NEXT TURN | 4.3 | +143.2 | 181.4 | 81.4 | 5.8 | +277.1 | 183.6 | 178.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +23.9 | 9.6 | 2.0 | 0.4 | +8.1 | 0.0 | 32.7 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -4.5 | 29.3 | 6.2 | 0.4 | -1.5 | 15.9 | 4.4 |
| LOST CHARGE | 2.9 | -43.2 | 114.9 | 81.6 | 2.8 | -43.6 | 32.2 | 72.8 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -6.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +30.3 | 2.2 | 21.9 | 0.6 | +104.8 | 76.8 | 2.4 |
| MANOEUVRE | 0.3 | +10.6 | 0.0 | 4.9 | 0.2 | +4.4 | 0.0 | 4.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.4 | 0.0 | 4.4 |
| MARCH CHECK | 0.7 | +33.3 | 0.0 | 0.0 | 0.6 | +58.4 | 0.0 | 11.6 |
| MARCH ODDS | 0.2 | +12.5 | 5.7 | 21.7 | 0.2 | +19.8 | 10.1 | 0.0 |
| MARCH OVER CASTS | 0.4 | +28.6 | 0.0 | 0.0 | 0.3 | +17.0 | 0.0 | 36.5 |
| MAX FOR POSITIONING | 4.9 | +175.1 | 0.0 | 114.2 | 4.9 | +189.1 | 0.0 | 201.7 |
| MISSILES IN THE MOVE | 4.1 | +174.1 | 0.0 | 85.6 | 3.2 | +60.8 | 0.0 | 71.9 |
| MISSILES NEXT TURN | 4.7 | +109.9 | 0.0 | 85.9 | 3.9 | +38.7 | 0.0 | 126.5 |
| MODEL FACING | 0.4 | +90.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 11.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +15.4 | 0.0 | 0.0 | 0.2 | +2.6 | 0.0 | 6.2 |
| MOVE SPELL IN RANGE | 0.2 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -36.9 | 0.0 | 3.6 | 0.2 | -7.0 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.8 | +252.9 | 133.4 | 32.9 | 4.4 | +354.4 | 160.7 | 184.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +12.4 | 3.1 | 0.0 | 0.1 | +8.6 | 14.4 | 11.1 |
| NO RALLY LEFT | 0.1 | +4.9 | 0.0 | 10.2 | - | - | - | - |
| NOT NEEDED | 0.2 | -8.1 | 21.4 | 1.2 | 0.4 | -18.9 | 71.1 | 5.8 |
| NOT TURNED | 4.8 | +54.3 | 0.0 | 131.0 | 4.9 | +51.6 | 0.0 | 148.0 |
| NOT WORTH A CAST | 0.9 | -0.9 | 0.0 | 34.7 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -911.8 | 0.0 | 274.4 | 14.6 | -886.3 | 6.5 | 322.2 |
| OPENS A LANE | 0.2 | +0.3 | 28.8 | 10.2 | 0.1 | +0.4 | 11.5 | 1.8 |
| OPENS UP | 0.1 | +1.2 | 2.9 | 10.6 | 0.2 | +22.5 | 8.3 | 7.9 |
| OVERRUNS AWAY | 0.4 | +7.9 | 20.7 | 16.5 | 0.5 | +4.4 | 44.9 | 15.4 |
| PATHS CROSS | 2.2 | +118.1 | 0.0 | 46.8 | 2.4 | +189.7 | 0.0 | 90.0 |
| PERIAPT WORTH | 0.1 | +2.9 | 0.0 | 0.0 | 0.1 | +3.8 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -4.5 | 0.0 | 11.8 |
| PLAN RESULT | 37.3 | +1721.3 | 1747.5 | 816.0 | 37.3 | +1078.1 | 1391.1 | 1022.4 |
| PURSUES BIG PREY | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | -20.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +11.5 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.8 | +10.0 | 0.0 | 20.0 | 1.5 | +35.6 | 0.0 | 50.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.1 | 0.0 | 4.7 | 0.3 | -10.3 | 3.1 | 19.3 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.1 | 0.0 | 3.4 | 0.4 | +2.6 | 0.0 | 2.3 |
| REDIRECT COUNTER | 2.0 | +136.0 | 0.0 | 42.8 | 3.8 | +326.0 | 0.0 | 47.2 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +5.7 | 5.8 | 5.1 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 11.9 | - | - | - | - |
| RESERVE FALL BACK | 0.4 | +7.1 | 0.0 | 11.2 | 0.8 | +46.2 | 0.0 | 12.4 |
| RESTRAINS TO SHOOT | 0.1 | +2.9 | 0.0 | 11.1 | 0.1 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +134.2 | 197.6 | 46.6 | 2.9 | +98.9 | 230.4 | 96.7 |
| SAFER THAN THE JOB | 1.1 | +69.7 | 0.0 | 22.7 | 0.6 | +36.1 | 0.0 | 24.3 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.3 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 1.7 |
| SEARCH SPOT | 1.9 | +90.9 | 0.0 | 34.0 | 3.0 | +161.6 | 0.0 | 38.0 |
| SELF MOVE SPELL | 0.2 | +22.3 | 0.0 | 18.1 | 0.1 | -0.2 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.9 | +87.6 | 2.2 | 21.9 | 1.3 | +169.6 | 95.2 | 22.7 |
| SET-UP ANY TARGET | 0.2 | +29.1 | 0.0 | 11.2 | 0.1 | +6.6 | 0.0 | 7.6 |
| SET-UP MISSED | 0.1 | +3.8 | 7.3 | 0.0 | 0.0 | +2.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +67.0 | 76.5 | 9.1 | 0.8 | +18.4 | 15.8 | 25.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 104.1 | 10.9 | 0.4 | +0.0 | 74.1 | 10.0 |
| SHOTS IN THE MOVE | 14.2 | +511.9 | 0.0 | 210.9 | 9.4 | +237.9 | 0.0 | 89.8 |
| SPELL CATCH ODDS | 0.1 | -1.1 | 6.5 | 11.2 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +113.8 | 11.1 | 22.4 | 0.1 | +23.3 | 8.9 | 13.7 |
| SPELL WORTH | 1.2 | +22.8 | 89.6 | 88.1 | 1.4 | +30.6 | 99.9 | 96.9 |
| SPELLS IN THE FIGHT | 0.5 | +6.6 | 86.8 | 14.8 | - | - | - | - |
| STABLE ROLE | 11.8 | +0.0 | 451.3 | 135.6 | 10.4 | +0.0 | 266.3 | 198.9 |
| STOPS | - | - | - | - | 0.1 | +1.9 | 0.0 | 7.7 |
| STOPS SHORT OF THE FLANK | 0.6 | +31.5 | 0.0 | 22.8 | 0.4 | +17.9 | 0.0 | 12.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 4.8 | -43.9 | 346.6 | 76.3 | 7.7 | -52.0 | 402.4 | 145.1 |
| SUPPORTS | 3.0 | +46.7 | 146.3 | 56.2 | 4.8 | +53.6 | 206.6 | 59.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.3 | 8.2 | 0.0 | 0.1 | -2.4 | 8.3 | 0.0 |
| SURE REACH TOGETHER | 0.8 | +1.2 | 0.0 | 5.2 | 0.7 | +12.8 | 6.1 | 43.6 |
| THROUGH LINE OF FIRE | 0.7 | +22.1 | 0.0 | 20.0 | 0.2 | +9.3 | 0.0 | 10.2 |
| TURN WORTH | 0.3 | -17.1 | 25.3 | 4.7 | 0.4 | -28.8 | 30.3 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.2 | 2.2 | 0.0 | 0.3 | +1.0 | 41.8 | 7.2 |
| WAIT AFTER COSTS | 6.4 | -337.3 | 278.3 | 78.8 | 7.9 | -428.8 | 270.6 | 237.3 |
| WALKS TO THE FIGHT | 1.5 | +34.0 | 37.1 | 10.3 | 1.0 | +37.1 | 25.4 | 3.5 |
| WAR ENGINE CHARGES | 0.1 | +10.4 | 6.5 | 8.6 | 0.1 | +1.4 | 3.1 | 5.1 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 21.6 | 13.9 | 0.4 | +0.0 | 7.9 | 0.0 |
| WEARS DOWN | 1.1 | +45.8 | 146.8 | 17.1 | 1.8 | +56.2 | 187.8 | 46.3 |
| WHO HITS BACK | 0.3 | +24.6 | 0.0 | 19.2 | 0.2 | +20.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +30.9 | 60.4 | 1.5 | 0.6 | +20.4 | 51.9 | 4.4 |
| WHOLE FIGHT GAIN | 0.4 | +32.5 | 43.6 | 12.2 | 0.6 | +42.4 | 71.9 | 10.9 |
| WIDER SPREAD | 2.4 | -8.3 | 274.1 | 54.3 | - | - | - | - |

### Rule changes: cw-h2h-mine-3cc170f-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1115 | 1115 | 1115 | 30.97 | -64732 | -58.1 |
| BEST FIRST | 293 | 293 | 293 | 8.14 | +14065 | +48.0 |
| SEARCH SPOT | 174 | 174 | 172 | 4.78 | +9099 | +52.9 |
| PATHS CROSS | 166 | 166 | 166 | 4.61 | +11082 | +66.8 |
| COUNTER-CHARGE COVER | 597 | 313 | 161 | 4.47 | +11451 | +71.1 |
| MOVE TO CHARGE | 262 | 262 | 140 | 3.89 | +8954 | +64.0 |
| KILLS COUNT NEXT TURN | 363 | 363 | 115 | 3.19 | +4393 | +38.2 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +7515 | +73.7 |
| SUPPORTS | 282 | 282 | 91 | 2.53 | +1118 | +12.3 |
| FALLBACK BY WORTH | 368 | 368 | 80 | 2.22 | +4266 | +53.3 |
| WALKS TO THE FIGHT | 90 | 90 | 65 | 1.81 | +1190 | +18.3 |
| SHOTS IN THE MOVE | 849 | 567 | 64 | 1.78 | +1117 | +17.5 |
| FOLLOW UP WEIGHED | 62 | 62 | 62 | 1.72 | +9237 | +149.0 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +3807 | +61.4 |
| WAIT AFTER COSTS | 514 | 514 | 59 | 1.64 | +1071 | +18.1 |
| RANDOM MOVE BY FIGURES | 84 | 84 | 58 | 1.61 | +1639 | +28.3 |
| ARTILLERY RE-ROLL WEIGHED | 53 | 53 | 53 | 1.47 | +0 | +0.0 |
| CANNON PLANNED TARGET | 229 | 229 | 53 | 1.47 | -210 | -4.0 |
| BEST FACING | 52 | 52 | 52 | 1.44 | +1797 | +34.6 |
| REDIRECT COUNTER | 210 | 110 | 52 | 1.44 | +4201 | +80.8 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RISK BY ARC | 193 | 187 | 48 | 1.33 | +1915 | +39.9 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| CHARGE NOW FIRST | 181 | 181 | 46 | 1.28 | -3994 | -86.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KILLS COUNT | 133 | 132 | 44 | 1.22 | +1689 | +38.4 |
| MARCH CHECK | 45 | 44 | 43 | 1.19 | +3327 | +77.4 |
| SHOT REPLANNED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| RESERVE FALL BACK | 42 | 42 | 42 | 1.17 | +1919 | +45.7 |
| MAX FOR POSITIONING | 353 | 182 | 40 | 1.11 | +503 | +12.6 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +2730 | +70.0 |
| STOPS SHORT OF THE FLANK | 39 | 39 | 39 | 1.08 | +1778 | +45.6 |
| BEST OVERALL | 37 | 37 | 37 | 1.03 | +2360 | +63.8 |
| SHOOTS FROM THE BEST SPOT | 67 | 67 | 36 | 1.00 | +1002 | +27.8 |
| COMBAT PIVOT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SET UP TOGETHER | 82 | 66 | 34 | 0.94 | +4852 | +142.7 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +1132 | +36.5 |
| INVITES THE FIGHT | 121 | 121 | 28 | 0.78 | +615 | +22.0 |
| MISSILES IN THE MOVE | 265 | 150 | 27 | 0.75 | +690 | +25.6 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| BLOCKED WHEEL | 20 | 20 | 20 | 0.56 | +372 | +18.6 |
| KEEPS ITS TARGET | 111 | 109 | 20 | 0.56 | +286 | +14.3 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +648 | +36.0 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +541 | +31.8 |
| WHOLE FIGHT GAIN | 37 | 35 | 17 | 0.47 | +643 | +37.8 |
| CAST JOB | 36 | 36 | 16 | 0.44 | +403 | +25.2 |
| WEARS DOWN | 103 | 99 | 16 | 0.44 | +488 | +30.5 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1331 | +83.2 |
| BEST PREY | 54 | 54 | 15 | 0.42 | +654 | +43.6 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MAKE SURE TOGETHER | 39 | 32 | 14 | 0.39 | +2562 | +183.0 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +91 | +6.5 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +768 | +59.1 |
| MODEL FACING | 13 | 13 | 13 | 0.36 | +3264 | +251.1 |
| HONEST WORTH | 257 | 257 | 12 | 0.33 | +124 | +10.3 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 10 | 0.28 | +973 | +97.3 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -43 | -4.3 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.28 | +79 | +7.9 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.25 | -38 | -4.2 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -694 | -77.2 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 202 | 201 | 8 | 0.22 | +250 | +31.3 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -194 | -24.2 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 448 | 448 | 8 | 0.22 | -66 | -8.2 |
| WHOLE FIGHT | 31 | 30 | 8 | 0.22 | +1175 | +146.9 |
| HUNT IN PAIRS | 32 | 19 | 7 | 0.19 | +216 | +30.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -88 | -17.6 |
| CHARGE BAND | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 5 | 0.14 | +118 | +23.5 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +240 | +48.0 |
| SPELLS IN THE FIGHT | 17 | 17 | 5 | 0.14 | +146 | +29.2 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -168 | -33.5 |
| WAR ENGINE JOBS | 29 | 29 | 5 | 0.14 | -176 | -35.3 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +67 | +16.7 |
| NEEDED THERE | 6 | 6 | 4 | 0.11 | +0 | +0.0 |
| OPENS UP | 8 | 8 | 4 | 0.11 | +410 | +102.4 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +239 | +59.9 |
| HUNT ADVANCE | 5 | 5 | 3 | 0.08 | +99 | +33.0 |
| JOINT CHARGE PLAN | 7 | 7 | 3 | 0.08 | +108 | +35.9 |
| MISSILES NEXT TURN | 311 | 174 | 3 | 0.08 | +6 | +2.0 |
| SURE REACH TOGETHER | 51 | 32 | 3 | 0.08 | +12 | +4.0 |
| BACKUP TARGETS | 69 | 31 | 2 | 0.06 | +6 | +3.2 |
| BLOWS WHERE AIMED | 5 | 5 | 2 | 0.06 | +45 | +22.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -34 | -17.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| DEFENSIVE ARMY | 17 | 17 | 2 | 0.06 | -39 | -19.6 |
| DEFENSIVE FLOOR | 6 | 6 | 2 | 0.06 | +253 | +126.7 |
| EDGE GIVE GROUND | 11 | 11 | 2 | 0.06 | +339 | +169.6 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +162 | +81.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +51 | +25.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +57 | +28.6 |
| REFUSING RETIRES | 8 | 8 | 2 | 0.06 | -0 | -0.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -176 | -176.5 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -30 | -29.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +8 | +7.9 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 1 | 0.03 | -45 | -45.1 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +96 | +96.0 |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 1 | 0.03 | +68 | +67.5 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 1 | 0.03 | +17 | +16.9 |
| TURN WORTH | 26 | 26 | 1 | 0.03 | +3 | +2.8 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.03 | +204 | +203.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 21 | 19 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 369 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 31 | not checked | - | - | - | - |
| LONG SHOT | 33 | 32 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 350 | 350 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 34 | 33 | 0 | 0.00 | - | - |
| PLAN RESULT | 2687 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 13 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 796 | 792 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 19 | 18 | 0 | 0.00 | - | - |
| WIDER SPREAD | 86 | 84 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-mine-3cc170f-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.44 | 12.92 | 61.0 |
| FALLBACK | gate | 0.64 | 0.67 | 22.3 |
| CHARGE NOW FIRST | rule | 0.47 | 0.81 | 86.8 |
| TURN GATE | gate | 0.50 | 0.33 | 48.4 |
| FIGHT ORDER BAND | gate | 0.31 | 0.25 | 1.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.17 | 89.6 |
| PATHS CROSS | rule | 0.22 | 0.06 | 35.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.11 | 80.0 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.11 | 50.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.19 | 39.1 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 24.2 |
| PURSUES BIG PREY | rule | 0.11 | 0.11 | 144.0 |
| SUPPORT NARROWED | rule | 0.14 | 0.08 | 8.2 |
| AFTERMATH BAND | gate | 0.17 | - | 2.6 |
| BEST PRIZE | rule | 0.08 | 0.06 | 17.6 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.06 | 8.9 |
| SUPPORT REQUEST | gate | 0.03 | 0.11 | 49.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.08 | 33.5 |
| WAR ENGINE JOBS | rule | 0.08 | 0.06 | 35.3 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 9.1 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 11.5 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 14.2 |
| MARCH ODDS | rule | - | 0.08 | 20.2 |
| BLOCKED WHEEL | rule | - | 0.06 | 29.2 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 17.2 |
| DEFENSIVE ARMY | rule | 0.06 | - | 19.6 |
| REDIRECT WEIGHED | rule | - | 0.06 | 22.2 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 176.5 |
| CATCH ODDS | rule | - | 0.03 | 29.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 0.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 45.1 |
| MOVE AND CAST | rule | - | 0.03 | 32.2 |
| SAFER THAN THE JOB | rule | - | 0.03 | 8.1 |

### Plans: cw-h2h-mine-3cc170f-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 19% | 484 | 443 | 92% |
| Mine | charge | 3.2 | 62% | 287 | 365 | 127% |
| Mine | close in | 4.2 | 33% | 233 | 177 | 76% |
| Mine | hold | 5.1 | 37% | 294 | 0 | 0% |
| Mine | join | 0.6 | 96% | 22 | 0 | 0% |
| Mine | shoot | 9.1 | 63% | 354 | 736 | 208% |
| Mine | support | 3.2 | 88% | 32 | 0 | 0% |
| Opponent | advance | 12.0 | 19% | 398 | 330 | 83% |
| Opponent | charge | 4.8 | 50% | 453 | 373 | 82% |
| Opponent | close in | 5.4 | 24% | 478 | 135 | 28% |
| Opponent | hold | 4.0 | 38% | 249 | 0 | 0% |
| Opponent | join | 1.1 | 89% | 40 | 0 | 0% |
| Opponent | shoot | 4.7 | 57% | 110 | 244 | 222% |
| Opponent | support | 5.2 | 92% | 48 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-mine-3cc170f-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 17 |
| Opponent | 0.2 | 7 | 1 | 17% | 0% | 0% | - | 459 | 0 | 0% | 94 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 126 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 150 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 246 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 255 | 0 | 0% | 44 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 0% | 0% | - | 516 | 0 | 0% | 61 |
| Warriors of Chaos | 0.4 | 3 | 1 | 0% | 0% | 0% | - | 570 | 0 | 0% | 60 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 24 |

### Battle groups: cw-h2h-mine-3cc170f-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.5 | 30% | 50% | 14% | 36% | 43% | 8% | 8% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 50% | 0% | - | 12% | 0% | 25% | 58% | 4% |
| Opponent | COUNTER-CHARGE COVER | 7.1 | 18% | 62% | 29% | 31% | 44% | 6% | 6% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 19% | 85% | 12% | 0% | 43% | 0% | 0% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-mine-3cc170f-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 56 (3) | 56 | 0 | 81 | 33% | 3.0 | 101 (2) | 0 (1) | - | 151 (1) | 0 (2) |
| Mine | Chaff | 37 | 31 (37) | 21 | 10 | 63 | 46% | 2.2 | 24 (16) | 27 (9) | 42 (12) | 21 (24) | 47 (13) |
| Mine | Character | 123 | 62 (123) | 62 | 0 | 26 | 17% | 2.5 | 94 (35) | 56 (62) | 27 (10) | 96 (58) | 37 (49) |
| Mine | Clean-up | 26 | 64 (26) | 23 | 41 | 25 | 42% | 2.4 | 59 (10) | 82 (12) | 8 (4) | 90 (14) | 37 (12) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 34 | 25% | 1.3 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 39 | 36 (39) | 23 | 13 | 51 | 21% | 2.8 | 40 (17) | 24 (11) | 38 (11) | 43 (28) | 20 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 57 | 51 (57) | 33 | 18 | 41 | 11% | 2.5 | 66 (10) | 54 (37) | 24 (10) | 68 (34) | 30 (23) |
| Mine | Holder | 25 | 89 (25) | 13 | 75 | 42 | 40% | 2.9 | 64 (8) | 123 (12) | 41 (4) | 109 (12) | 75 (12) |
| Mine | Shooter | 45 | 88 (45) | 22 | 66 | 35 | 4% | 1.7 | 38 (6) | 96 (32) | 115 (7) | 128 (25) | 40 (20) |
| Mine | Support | 5 | 28 (5) | 28 | 0 | 0 | 60% | 3.5 | 181 (1) | 0 (4) | - | 0 (1) | 49 (4) |
| Mine | War machine | 56 | 51 (56) | 51 | 0 | 27 | 5% | 1.3 | 78 (13) | 38 (37) | 80 (6) | 60 (11) | 49 (45) |
| Mine | Wizard | 23 | 29 (23) | 29 | 0 | 29 | 9% | 2.5 | 34 (6) | 32 (10) | 42 (2) | 58 (3) | 27 (15) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 49 (66) | 5 | 44 | 49 | 33% | 2.6 | 67 (28) | 35 (16) | 39 (22) | 67 (48) | 0 (18) |
| Opponent | Character | 114 | 50 (114) | 50 | 0 | 44 | 18% | 2.4 | 75 (37) | 43 (55) | 0 (5) | 54 (64) | 57 (33) |
| Opponent | Clean-up | 17 | 27 (17) | 17 | 11 | 56 | 35% | 3.0 | 11 (5) | 28 (9) | 52 (3) | 32 (9) | 23 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 39 (58) | 23 | 16 | 56 | 29% | 2.4 | 38 (25) | 43 (19) | 35 (14) | 45 (42) | 23 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 47 | 40% | 3.7 | 0 (3) | 0 (3) | 0 (4) | 0 (8) | 0 (2) |
| Opponent | Hammer | 64 | 31 (64) | 21 | 9 | 53 | 19% | 2.7 | 14 (16) | 36 (41) | 25 (7) | 29 (39) | 33 (25) |
| Opponent | Holder | 40 | 60 (40) | 9 | 51 | 28 | 35% | 3.5 | 11 (10) | 90 (17) | 63 (11) | 85 (21) | 36 (17) |
| Opponent | Shooter | 30 | 89 (30) | 32 | 57 | 32 | 7% | 1.3 | 110 (7) | 92 (18) | 44 (5) | 110 (16) | 60 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 43 (13) | 43 | 0 | 18 | 0% | 1.2 | 0 (5) | 65 (5) | 77 (3) | 101 (3) | 26 (10) |
| Opponent | Wizard | 22 | 3 (22) | 3 | 0 | 47 | 9% | 2.0 | 3 (11) | 0 (2) | 0 (3) | 3 (8) | 0 (8) |

### Charged fights: cw-h2h-mine-3cc170f-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 202 | 144 | 2.2 | 1.1 | 65 | 5 | +61 | 3 of 11 | 9 of 11 | +40 | +63 |
| Mine | Chaos Dwarfs | 3 | 22 | 711 | 3.3 | 1.3 | 213 | 31 | +182 | 6 of 10 | 7 of 10 | +340 | +115 |
| Mine | Dwarfen Mountain Holds | 4 | 414 | 10 | 1.0 | 1.2 | 10 | 0 | +10 | 2 of 4 | 2 of 4 | +0 | +14 |
| Mine | Empire of Man | 5 | 561 | 141 | 2.0 | 1.2 | 70 | 0 | +70 | 3 of 10 | 9 of 10 | +158 | +48 |
| Mine | Grand Cathay | 4 | 928 | 576 | 3.2 | 1.2 | 177 | 16 | +162 | 5 of 13 | 9 of 13 | +142 | +165 |
| Mine | High Elf Realms | 4 | 98 | 395 | 2.8 | 1.5 | 144 | 25 | +119 | 5 of 11 | 7 of 11 | +83 | +139 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 750 | 4.0 | 1.5 | 188 | 0 | +188 | 2 of 4 | 4 of 4 | +204 | +172 |
| Mine | Lizardmen | 1 | 136 | 457 | 4.0 | 1.0 | 114 | 35 | +79 | 1 of 4 | 3 of 4 | - | +79 |
| Mine | Ogre Kingdoms | 1 | 0 | 202 | 2.0 | 1.5 | 101 | 62 | +39 | 0 of 2 | 1 of 2 | +12 | +66 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 331 | 3.0 | 1.3 | 110 | 417 | -306 | 2 of 3 | 2 of 3 | +265 | -592 |
| Mine | Skaven | 2 | 258 | 0 | 1.5 | 1.3 | 0 | 65 | -65 | 3 of 3 | 1 of 3 | -195 | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1057 | 4.5 | 1.3 | 235 | 120 | +115 | 3 of 9 | 7 of 9 | +435 | -45 |
| Mine | Vampire Counts | 2 | 0 | 334 | 5.5 | 1.4 | 61 | 8 | +53 | 3 of 11 | 9 of 11 | +57 | +51 |
| Mine | Warriors of Chaos | 1 | 0 | 331 | 5.0 | 1.2 | 66 | 0 | +66 | 1 of 5 | 5 of 5 | +115 | +54 |
| **Mine** | all armies | 36 | 286 | 343 | 2.8 | 1.3 | 123 | 37 | +86 | 39 of 100 | 75 of 100 | +163 | +61 |
| Opponent | Beastmen Brayherds | 1 | 55 | 195 | 5.0 | 1.2 | 39 | 250 | -211 | 3 of 5 | 0 of 5 | +0 | -263 |
| Opponent | Dwarfen Mountain Holds | 1 | 375 | 236 | 3.0 | 1.3 | 79 | 0 | +79 | 0 of 3 | 3 of 3 | +112 | +62 |
| Opponent | Empire of Man | 1 | 399 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 355 | 381 | 4.0 | 1.0 | 95 | 0 | +95 | 3 of 4 | 2 of 4 | - | +95 |
| Opponent | High Elf Realms | 2 | 114 | 743 | 3.0 | 1.3 | 248 | 0 | +248 | 3 of 6 | 3 of 6 | +352 | +196 |
| Opponent | Lizardmen | 1 | 380 | 266 | 3.0 | 2.0 | 89 | 0 | +89 | 2 of 3 | 2 of 3 | +94 | +77 |
| Opponent | Ogre Kingdoms | 2 | 111 | 138 | 3.5 | 1.1 | 40 | 10 | +30 | 1 of 7 | 2 of 7 | +0 | +35 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 661 | 4.5 | 1.2 | 147 | 135 | +12 | 5 of 9 | 7 of 9 | +30 | +7 |
| Opponent | Skaven | 2 | 32 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 84 | 653 | 3.2 | 1.2 | 201 | 67 | +134 | 7 of 13 | 8 of 13 | +493 | +69 |
| Opponent | Vampire Counts | 6 | 22 | 476 | 4.2 | 1.3 | 114 | 34 | +81 | 13 of 25 | 14 of 25 | +354 | -6 |
| Opponent | Warriors of Chaos | 7 | 0 | 354 | 2.9 | 1.0 | 124 | 22 | +102 | 7 of 20 | 12 of 20 | - | +102 |
| Opponent | Wood Elf Realms | 6 | 167 | 199 | 4.0 | 1.2 | 50 | 39 | +11 | 8 of 24 | 17 of 24 | -101 | +33 |
| **Opponent** | all armies | 36 | 100 | 370 | 3.4 | 1.2 | 109 | 46 | +63 | 55 of 122 | 71 of 122 | +180 | +39 |

### Effective charges: cw-h2h-mine-3cc170f-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 11 | 0 | 0 | 0 | 2 (net +82) | 0 | 4 (net +16) | 5 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 10 | 1 (net +623) | 0 | 1 (net +0) | 1 (net +732) | 1 (net +0) | 6 (net +78) | 0 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 2 (net +20) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 10 | 0 | 0 | 2 (net +98) | 4 (net +79) | 2 (net +42) | 2 (net +54) | 0 | 20% (2 of 10) |
| Mine | Grand Cathay | 13 | 1 (net +432) | 0 | 3 (net +104) | 7 (net +194) | 0 | 2 (net +0) | 0 | 23% (3 of 13) |
| Mine | High Elf Realms | 11 | 1 (net +571) | 0 | 1 (net +0) | 4 (net +0) | 1 (net -151) | 2 (net +358) | 2 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +268) | 0 | 0 | 1 (net +75) | 1 (net +68) | 1 (net +339) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +90) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +265) | 0 | 1 (net +66) | 0 | 1 | 50% (1 of 2) |
| Mine | Skaven | 3 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 1 (net -195) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 9 | 2 (net +58) | 0 | 2 (net -72) | 1 (net +170) | 1 (net +432) | 3 (net +153) | 0 | 22% (2 of 9) |
| Mine | Vampire Counts | 11 | 3 (net +18) | 1 (net -45) | 2 (net +85) | 2 (net +58) | 0 | 3 (net +95) | 0 | 18% (2 of 11) |
| Mine | Warriors of Chaos | 5 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +108) | 1 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 5 | 2 (net +0) | 1 (net +65) | 0 | 0 | 0 | 2 (net -559) | 0 | 0% (0 of 5) |
| Opponent | Dwarfen Mountain Holds | 3 | 1 (net +124) | 0 | 1 (net +0) | 0 | 0 | 1 (net +112) | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 4 | 2 (net +48) | 0 | 0 | 2 (net +143) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 6 | 2 (net +0) | 0 | 0 | 2 (net +206) | 0 | 2 (net +536) | 0 | 0% (0 of 6) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +0) | 0 | 1 (net +189) | 0 | 1 | 50% (1 of 2) |
| Opponent | Ogre Kingdoms | 7 | 1 (net -34) | 0 | 1 (net +30) | 0 | 2 (net +32) | 1 (net +130) | 2 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 9 | 1 (net +115) | 1 (net +177) | 1 (net -55) | 1 (net +165) | 0 | 2 (net +263) | 3 | 17% (1 of 6) |
| Opponent | Skaven | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 1 (net -136) | 1 (net -735) | 5 (net +187) | 2 (net +134) | 0 | 4 (net +352) | 0 | 38% (5 of 13) |
| Opponent | Vampire Counts | 25 | 5 (net -29) | 1 (net +0) | 4 (net +305) | 7 (net +47) | 1 (net -94) | 5 (net +100) | 2 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 20 | 2 (net +556) | 1 (net +143) | 2 (net -168) | 3 (net +117) | 0 | 7 (net +86) | 5 | 13% (2 of 15) |
| Opponent | Wood Elf Realms | 24 | 2 (net +0) | 0 | 5 (net +17) | 8 (net -67) | 1 (net +60) | 2 (net -102) | 6 | 28% (5 of 18) |

### Charged fights, damage counted: cw-h2h-mine-3cc170f-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 216 | 289 | +172 | 255 | 88 | +167 | +77.6 |
| Mine | 50-54% | 2 | 242 | 248 | -22 | 0 | 50 | -50 | -20.8 |
| Mine | Effective (55-75%) | 13 | 298 | 184 | +68 | 94 | 26 | +67 | +22.6 |
| Mine | 76-89% | 25 | 309 | 216 | +119 | 151 | 31 | +119 | +38.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 263 | 186 | +91 | 137 | 33 | +104 | +39.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 503 | 99 | +71 | 113 | 67 | +47 | +9.3 |
| Mine | No odds | 14 | 356 | 171 | -16 | 121 | 145 | -25 | -6.9 |
| Mine | All fights | 100 | 303 | 199 | +86 | 142 | 57 | +86 | +28.3 |
| Opponent | Long shot (under 50%) | 19 | 221 | 252 | +60 | 96 | 76 | +20 | +9.1 |
| Opponent | 50-54% | 6 | 215 | 263 | -58 | 81 | 124 | -44 | -20.3 |
| Opponent | Effective (55-75%) | 20 | 255 | 213 | +94 | 140 | 69 | +71 | +28.0 |
| Opponent | 76-89% | 26 | 259 | 204 | +49 | 132 | 79 | +53 | +20.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 308 | 248 | +112 | 210 | 98 | +112 | +36.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 461 | 94 | +44 | 88 | 56 | +32 | +6.9 |
| Opponent | No odds | 19 | 218 | 183 | +27 | 86 | 60 | +25 | +11.6 |
| Opponent | All fights | 122 | 263 | 218 | +63 | 134 | 79 | +54 | +20.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-mine-3cc170f-p1 | move | 452 | 92 (20%) | 65 (14%) | 75 (17%) | 285 (63%) |
| cw-h2h-mine-3cc170f-p1 | objective | 347 | 49 (14%) | 33 (10%) | 61 (18%) | 237 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

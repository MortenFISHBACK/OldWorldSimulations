# Doctrine scorecard: cw-h2h-mine-3cc170f-p2

### Scorecard: cw-h2h-mine-3cc170f-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 55 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 4 | - | 0 | 5 | 1 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | 5 | 1 | 0 | 0 | 0 | 0 | 868 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 3 | 2 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1127 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | yes | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | - | 2 | 0 | 1 | 0 | 0 | 307 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 993 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 0 | 5 | 1 | 4 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 190 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 17 | 2 | 4 | 3 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 745 |
| L0934 | 4 | 1 | Opponent | yes | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 140 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 1 | 1 | 3 | 2 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 617 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 7 | 4 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 140 |
| L2735 | 5 | 1 | Mine | no | - | 4 | 2 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 1.8 | 2.6 | 2.1 | 1.3 | 0.2 | 0.0 | 0.0 | 299.5 |
| **Average** | | | Opponent | 30% | 3.1 | 2.5 | 3.1 | 1.4 | 0.2 | 0.0 | 0.0 | 183.9 |

### KPIs: cw-h2h-mine-3cc170f-p2

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 173) | 15% (27 of 185) | 21% (75 of 358) |
| Winner chose to follow up after the loser gave ground |  | 97% (68 of 70); on the table 97% | 95% (52 of 55); on the table 95% | 96% (120 of 125); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 83% (10 of 12); on the table 100% | 88% (21 of 24); on the table 96% |
| Winner chose to pursue after the loser fled |  | 86% (25 of 29); on the table 90% | 71% (30 of 42); on the table 71% | 77% (55 of 71); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 94% (104 of 111); on the table 95% | 84% (92 of 109); on the table 86% | 89% (196 of 220); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 34% (115 of 342) | 39% (61 of 156) | 35% (176 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (115 of 216) | 54% (61 of 113) | 53% (176 of 329) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 73% (24 of 33) | 55% (32 of 58) | 62% (56 of 91) |
| Points that never fought | lower | 36% (25463 of 71583) | 41% (29261 of 71989) | 38% (54724 of 143572) |
|   infantry points that never fought | lower | 45% (7316 of 16324) | 57% (7998 of 14029) | 50% (15314 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (158 of 284) | 58% (171 of 297) | 57% (329 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.6 uses a game | 78% (14 of 18); 1.4 uses a game | 87% (33 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.7 uses a game | 50% (1 of 2); 0.0 uses a game | 55% (11 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 14% (1 of 7); 0.0 uses a game | 52% (14 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30992 of 60231) | 52% (33072 of 63281) | 52% (64064 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (18%) | 0.5 (19%) | 1.6 (18%) |
| MARCHED: its unit marched | 1.3 (20%) | 0.4 (17%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (27%) | 0.6 (22%) | 2.3 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (9%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 1.2 (19%) | 0.5 (19%) | 1.7 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.1 (3%) | 0.6 (7%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.8 | 1.2 | 4.9 | 0.4 | 2.1 |
| not cast | 3.6 | 3.2 | 3.8 | 8.9 | 1.9 | 19.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.6 (50%) | 0.2 (6%) | 1.6 (18%) | 0.5 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.3 (10%) | 0.5 (14%) | 2.3 (26%) | 0.5 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.4 (11%) | 0.2 (7%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.9 (24%) | 0.4 (14%) | 0.9 (25%) | 1.7 (19%) | 0.2 (9%) | 3.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.2 (7%) | 0.3 (7%) | 0.6 (7%) | 0.0 (0%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.2 (10%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (50%) | 0.1 (3%) | 1.5 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.7 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 67% (12 of 18) | 57% (13 of 23) | 61% (25 of 41) |
| the unit moved after it | 75% (9 of 12) | 46% (6 of 13) | 60% (15 of 25) |
| it charged on its next turn | 17% (2 of 12) | 23% (3 of 13) | 20% (5 of 25) |
| the enemy charged it first | 17% (2 of 12) | 8% (1 of 13) | 12% (3 of 25) |
| it fought by the end of its next turn | 8% (1 of 12) | 0% (0 of 13) | 4% (1 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (3 of 12) | 8% (1 of 13) | 16% (4 of 25) |
| none of these (no charge, no fight, no charge escaped) | 50% (6 of 12) | 62% (8 of 13) | 56% (14 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (524 of 877) | 54% (424 of 791) | 57% (948 of 1668) |
|   cavalry | 53% (46 of 87) | 62% (109 of 176) | 59% (155 of 263) |
|   character | 46% (49 of 107) | 19% (21 of 108) | 33% (70 of 215) |
|   chariot | 53% (57 of 108) | 60% (24 of 40) | 55% (81 of 148) |
|   infantry | 49% (125 of 254) | 52% (155 of 297) | 51% (280 of 551) |
|   monster | 47% (22 of 47) | 45% (18 of 40) | 46% (40 of 87) |
|   war machine | 82% (225 of 274) | 75% (97 of 130) | 80% (322 of 404) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (27%) | 2.4 (24%) | 5.0 (25%) |
| CHARGED: it charged | 1.2 (13%) | 2.2 (21%) | 3.4 (17%) |
| FLEEING: it fled or was fleeing | 0.4 (4%) | 0.1 (1%) | 0.5 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.5 (5%) | 1.3 (7%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 1.3 (13%) | 1.7 (17%) | 3.0 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (10%) | 0.7 (7%) | 1.7 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (19%) | 1.7 (17%) | 3.5 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.4 (4%) | 0.6 (3%) |
| OTHER BAR | 0.4 (4%) | 0.4 (4%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.8 | 1.8 | 80% | 4.8 pts | 33 pts |
| character | 2.0 | 0.8 | 71% | 11.7 pts | 24 pts |
| chariot | 2.3 | 1.2 | 74% | 10.7 pts | 24 pts |
| infantry | 11.0 | 3.8 | 74% | 8.5 pts | 93 pts |
| monster | 1.2 | 0.2 | 87% | 1.4 pts | 2 pts |
| war machine | 8.9 | 6.8 | 65% | 23.1 pts | 207 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.5 | 5.4 |
| Charges that made contact a game | 3.0 | 4.4 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.52 contact (25 units) | 1.15 declared, 0.85 contact (13 units) | 0.89 declared, 0.63 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.40 declared, 0.40 contact (5 units) | 1.23 declared, 0.85 contact (13 units) | 1.00 declared, 0.72 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.38 contact (248 units) | 0.69 declared, 0.46 contact (293 units) | 0.62 declared, 0.42 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (36 of 73) | 61% (11 of 18) | 67% (8 of 12) | 53% (55 of 103) |
| Character in a unit | 81% (26 of 32) | 61% (11 of 18) | 100% (4 of 4) | 76% (41 of 54) |
| Character on its own | 80% (32 of 40) | 44% (16 of 36) | 26% (16 of 62) | 46% (64 of 138) |
| Chariot | 59% (10 of 17) | 69% (9 of 13) | - | 63% (19 of 30) |
| Infantry | 54% (51 of 94) | 56% (19 of 34) | 0% (0 of 3) | 53% (70 of 131) |
| Monster | 55% (16 of 29) | 67% (6 of 9) | - | 58% (22 of 38) |
| Monstrous | 36% (5 of 14) | 64% (9 of 14) | - | 50% (14 of 28) |
| War Machines | 75% (43 of 57) | 50% (1 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (17 of 17); on the table 100% | 33% (34 of 102) | 39% | 59% (13 of 22) | 100% (6 of 6); 4.0 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (15 of 15); on the table 100% | 33% (12 of 36) | 51% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (13 of 13); on the table 100% | - | 56% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 100% (10 of 10); on the table 100% | 31% (15 of 48) | 40% | 59% (45 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 86% (25 of 29); on the table 90% | 36% (49 of 138) | 40% | 39% (21 of 54) | 93% (13 of 14); 7.7 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 93% (13 of 14); on the table 93% | 22% (4 of 18) | 43% | 48% (16 of 33) | 100% (3 of 3); 1.8 uses a game | 50% (7 of 14); 4.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 83% (5 of 6); on the table 83% | - | 55% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 39% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (8 of 8); on the table 100% | 0% (0 of 18) | 28% | 71% (20 of 28) | 75% (3 of 4); 1.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 100% (9 of 9); on the table 100% | 50% (9 of 18) | 19% | 64% (16 of 25) | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 92% (12 of 13); on the table 92% | - | 37% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 78% (21 of 27); on the table 81% | 47% (31 of 66) | 29% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 77% (23 of 30); on the table 80% | 50% (9 of 18) | 32% | 56% (41 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 84% (21 of 25); on the table 84% | 46% (11 of 24) | 44% | 64% (50 of 78) | 57% (4 of 7); 2.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-mine-3cc170f-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (48) | 46% (27) | 49% (75) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.44 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.31 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.39 | 3.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.22 | 0.89 | 2.11 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.44 | 5.25 | 11.69 |

### Quality by phase: cw-h2h-mine-3cc170f-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 47% (59 of 126) | 47% (113 of 241) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (139 of 320) | 52% (114 of 221) |
| Strategy | Close-in objectives charged next turn | 13% (16 of 126) | 17% (38 of 230) |
| Strategy | Support requests answered (helper made contact too) | 58% (7 of 12) | 47% (14 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 27% (4 of 15) | 38% (6 of 16) |
| Strategy | Joined characters whose unit fought | 59% (29 of 49) | 22% (8 of 37) |
| Strategy | Lone characters that fought | 76% (73 of 96) | 77% (66 of 86) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.3 | 1.4 |
| Movement | Points that never moved of their own | 299.5 | 183.9 |
| Movement | Fights charged into per game | 2.7 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 82, net +73 | 23 of 129, net +116 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 82, net +51 | 20 of 129, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 82, net +89 | 12 of 129, net +123 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 82, net +76 | 41 of 129, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 10.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (122 of 326) | 46% (166 of 363) |
| Shooting | Points destroyed by shooting units | 78.2 | 43.1 |
| Shooting | War machine shots | 6.2 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (135 of 225) | 55% (53 of 97) |
| Shooting | Points destroyed by war machines | 56.5 | 32.8 |
| Magic | Magic missiles cast | 2.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (21 of 74) | 36% (15 of 42) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.3 |
| Magic | Wounds caused by other spells | 1.2 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 58.9 | 7.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.8 / 0.1 | 2.0 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 300.7 | 420.6 |
| Combat | Points run down | 38.1 | 88.1 |
| Combat | Net points per charged fight, damage counted | +77 | +106 |
| Combat | Net per 100 charger points, damage counted | +29.7 | +38.9 |
| Combat | First round won (charged fights) | 75% | 68% |
| Combat | Net points per charged fight | +70 | +107 |
| Combat | Net points per supported fight / lone fight | +97 / +67 | +153 / +99 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 96 | 52 of 136 |
| Game | Points lost | 778.2 | 656.0 |
| Game | VP from objectives | 493.3 | 653.6 |
| Game | Lone holders (player turns) | 1.8 | 3.1 |

- Mine won / drew / lost: 11 / 8 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -293 VP
- The side that went first won 16 of 28 games with a winner
- Points traded per game (both sides' losses): 1434
- Games not ended: 0; findings 1, warnings 1

### Opponent rules: cw-h2h-mine-3cc170f-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 6.1 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 22.5 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.1 | +7.7 | 0.0 | 9.6 | 1.1 | +12.1 | 0.0 | 8.9 |
| BEST FACING | 0.9 | +43.5 | 0.0 | 50.6 | 0.7 | +33.4 | 0.0 | 25.7 |
| BEST FIRST | 4.1 | +163.8 | 117.6 | 108.8 | 4.5 | +211.3 | 106.0 | 39.0 |
| BEST OVERALL | 0.9 | +72.6 | 0.0 | 50.1 | 0.4 | +20.4 | 0.0 | 25.9 |
| BEST PREY | 0.8 | +47.4 | 22.9 | 2.9 | 1.0 | +66.5 | 52.4 | 18.3 |
| BEST PRIZE | 0.1 | -3.4 | 2.8 | 0.0 | 0.1 | +6.0 | 1.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +3.3 | 0.0 | 0.0 | 0.6 | +0.9 | 0.0 | 33.1 |
| BLOWS WHERE AIMED | 0.2 | -7.1 | 10.4 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.1 | +1.5 | 16.9 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 52.1 | 8.9 | 0.1 | +0.0 | 7.5 | 3.5 |
| CANNON PLANNED TARGET | 4.6 | +136.7 | 273.7 | 97.8 | 2.0 | +63.6 | 76.6 | 6.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.8 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -2.4 | 13.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.4 | 0.0 | 2.9 | 0.2 | -0.6 | 30.0 | 12.1 |
| CAST JOB | 0.5 | +13.7 | 10.5 | 7.1 | 0.2 | +5.2 | 7.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +34.7 | 14.1 | 0.0 | 0.1 | +4.2 | 1.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 18.1 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| CHARGE BAND | 0.2 | +0.0 | 15.2 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.0 | +0.0 | 150.4 | 32.6 | 3.6 | +0.0 | 447.9 | 88.2 |
| CHARGE NOW WEIGHED | 0.5 | -28.8 | 9.3 | 4.2 | 0.5 | -26.7 | 16.0 | 24.9 |
| CHARGER SLAIN LOST | 0.6 | -15.4 | 31.8 | 27.9 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 5.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.3 | +0.0 | 31.4 | 4.2 |
| COMBAT PIVOT | 0.2 | +0.0 | 5.2 | 28.8 | 0.6 | +0.0 | 83.2 | 50.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.2 | +63.1 | 0.0 | 0.0 | 0.6 | +71.5 | 30.2 | 43.0 |
| COUNTER-CHARGE COVER | 11.3 | +1015.2 | 0.0 | 245.9 | 7.2 | +673.3 | 0.0 | 153.4 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 1.1 | 0.0 | 0.2 | +0.0 | 0.0 | 2.9 |
| EDGE GIVE GROUND | 0.3 | +8.9 | 24.1 | 0.0 | 0.4 | +3.8 | 46.2 | 0.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +162.8 | 0.0 | 91.1 | 1.4 | +104.4 | 0.0 | 29.5 |
| FALLBACK BY WORTH | 4.8 | +58.7 | 0.0 | 54.1 | 5.4 | +80.1 | 0.0 | 48.7 |
| FIRE AND FLEE | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 3.1 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 176.7 | 4.6 | +0.0 | 0.0 | 110.7 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +122.4 | 0.0 | 26.8 | 1.1 | +167.7 | 0.0 | 20.6 |
| FRIENDS SHOTS CHECKED | 0.5 | +27.8 | 0.0 | 23.0 | 0.1 | +10.6 | 0.0 | 7.2 |
| GIVES UP | 0.1 | -1.0 | 3.5 | 0.0 | 0.1 | -2.0 | 6.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.9 | 0.0 | 2.5 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 14.0 | 14.1 |
| HELPER UNSEEN | 0.3 | +0.0 | 18.8 | 7.8 | 0.5 | +0.0 | 56.8 | 25.5 |
| HILL BY ITS CHANCE | 0.3 | -22.8 | 0.0 | 4.2 | 0.6 | -54.0 | 0.0 | 6.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.9 | -117.3 | 226.9 | 101.1 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.9 | 5.6 | 2.4 | 0.4 | +3.3 | 21.8 | 1.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 7.8 | 6.9 |
| HUNT IN PAIRS | 0.3 | +27.4 | 0.0 | 0.0 | 0.5 | +27.6 | 0.0 | 23.4 |
| HUNT KEPT | 0.0 | +2.9 | 2.8 | 2.4 | 0.2 | +8.7 | 15.7 | 2.9 |
| HUNT RESULT | 0.1 | +17.6 | 0.0 | 6.5 | 0.4 | +29.3 | 12.4 | 7.9 |
| HUNT THE GUNS | 0.1 | +34.5 | 11.0 | 2.4 | 0.4 | +104.7 | 19.9 | 0.0 |
| INVITES THE FIGHT | 2.2 | +34.7 | 57.6 | 38.2 | 0.9 | +19.2 | 28.9 | 3.5 |
| JOINT CHARGE PLAN | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +8.0 | 8.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.6 | 4.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 102.4 | 30.4 | 2.1 | +63.3 | 231.0 | 63.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.5 | +73.7 | 85.1 | 12.7 | 2.9 | +145.5 | 278.8 | 66.7 |
| KILLS COUNT NEXT TURN | 5.1 | +159.7 | 124.2 | 111.2 | 7.2 | +295.6 | 241.1 | 196.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +34.8 | 0.0 | 15.0 | 0.2 | +6.9 | 0.0 | 6.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 10.9 | 0.0 | 0.3 | +0.0 | 1.5 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.6 | 29.9 | 0.0 | 1.0 | -3.1 | 66.9 | 24.6 |
| LOST CHARGE | 2.7 | -47.7 | 65.1 | 80.0 | 2.3 | -44.3 | 101.5 | 73.2 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.6 | 0.0 | 3.1 | - | - | - | - |
| MAKE SURE TOGETHER | 0.4 | +11.4 | 3.2 | 11.2 | 0.8 | +66.4 | 0.0 | 36.1 |
| MANOEUVRE | 0.2 | +16.1 | 0.0 | 10.7 | 0.2 | +3.7 | 0.0 | 19.5 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +16.5 | 0.0 | 2.4 | 0.4 | +10.6 | 0.0 | 13.5 |
| MARCH ODDS | 0.3 | +22.0 | 6.8 | 0.0 | 0.2 | +33.5 | 5.9 | 0.0 |
| MARCH OVER CASTS | 0.7 | +42.6 | 0.0 | 11.1 | 0.4 | +29.4 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 5.5 | +187.7 | 0.0 | 115.7 | 4.7 | +179.0 | 0.0 | 124.9 |
| MISSILES IN THE MOVE | 3.6 | +94.8 | 0.0 | 101.7 | 3.1 | +50.3 | 0.0 | 64.3 |
| MISSILES NEXT TURN | 4.2 | +62.0 | 0.0 | 117.3 | 3.6 | +41.7 | 0.0 | 81.6 |
| MODEL FACING | 0.3 | +49.1 | 0.0 | 0.0 | 0.2 | +65.5 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +15.8 | 0.0 | 2.4 | 0.3 | +15.9 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.1 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -15.0 | 0.0 | 9.9 | 0.2 | -7.9 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.4 | +117.1 | 61.3 | 36.4 | 5.1 | +342.3 | 197.2 | 168.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +3.7 | 1.4 | 0.0 | 0.1 | +8.9 | 3.2 | 5.4 |
| NOT NEEDED | 0.3 | -12.0 | 31.8 | 9.4 | 0.4 | -26.1 | 38.2 | 8.4 |
| NOT TURNED | 6.4 | +80.2 | 0.0 | 119.2 | 5.2 | +79.0 | 0.0 | 78.5 |
| NOT WORTH A CAST | 0.5 | -0.2 | 0.0 | 0.0 | 0.6 | -0.4 | 0.0 | 11.2 |
| OFF BEST | 15.2 | -763.4 | 0.0 | 316.0 | 15.5 | -904.8 | 20.7 | 205.8 |
| OPENS A LANE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.1 | +7.9 | 8.1 | 0.0 | 0.5 | +45.1 | 29.2 | 0.0 |
| OVERRUN THREAT | 0.0 | +4.8 | 0.0 | 10.6 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +6.1 | 28.6 | 5.6 | 0.7 | +12.4 | 85.1 | 23.3 |
| PATHS CROSS | 2.1 | +162.9 | 0.0 | 12.2 | 2.9 | +211.6 | 0.0 | 74.2 |
| PERIAPT WORTH | 0.1 | +5.2 | 0.0 | 15.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.9 | 0.0 | 17.7 | 0.2 | -8.0 | 0.0 | 8.8 |
| PLAN RESULT | 36.9 | +1175.5 | 1163.6 | 1023.1 | 41.0 | +1328.8 | 1520.4 | 868.9 |
| PURSUES BIG PREY | 0.0 | -2.9 | 0.0 | 0.0 | 0.2 | -6.1 | 0.0 | 13.6 |
| PURSUES ON | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +14.9 | 0.0 | 24.4 | 1.6 | +36.9 | 0.0 | 28.1 |
| RANDOM MOVER NO PROMISE | 0.2 | -12.4 | 3.5 | 5.8 | 0.3 | -19.9 | 10.7 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.7 | 0.0 | 1.0 | 0.3 | -2.8 | 0.0 | 6.0 |
| REDIRECT COUNTER | 2.5 | +205.9 | 0.0 | 50.1 | 4.2 | +373.9 | 0.0 | 62.7 |
| REDIRECT WEIGHED | 0.3 | +4.5 | 0.0 | 6.0 | 0.4 | +0.6 | 1.4 | 0.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 6.4 | - | - | - | - |
| RESERVE FALL BACK | 0.4 | +9.4 | 0.0 | 0.0 | 1.2 | +29.9 | 0.0 | 17.7 |
| RESTRAINS TO SHOOT | 0.1 | +3.9 | 0.0 | 17.0 | 0.1 | +1.2 | 0.0 | 7.0 |
| RISK BY ARC | 2.1 | +75.7 | 144.1 | 43.8 | 4.1 | +105.4 | 480.4 | 98.6 |
| SAFER THAN THE JOB | 1.2 | +65.1 | 0.0 | 22.9 | 0.9 | +72.7 | 0.0 | 67.4 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.5 | 0.0 | 1.2 | 0.4 | -19.9 | 0.0 | 4.8 |
| SEARCH SPOT | 2.9 | +154.5 | 0.0 | 32.7 | 2.8 | +139.9 | 0.0 | 11.7 |
| SECOND HUNTER | 0.0 | -0.5 | 2.8 | 1.4 | 0.1 | -0.6 | 6.9 | 0.0 |
| SELF MOVE SPELL | 0.2 | +7.6 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +21.4 | 3.2 | 21.8 | 1.7 | +137.0 | 32.1 | 48.8 |
| SET-UP ANY TARGET | 0.1 | +27.4 | 0.0 | 0.0 | 0.1 | +13.1 | 4.4 | 18.9 |
| SET-UP MISSED | - | - | - | - | 0.1 | +6.6 | 5.7 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +36.8 | 42.9 | 3.6 | 0.7 | +29.7 | 14.0 | 10.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.2 | +0.0 | 64.7 | 3.1 | 0.1 | +0.0 | 21.2 | 2.0 |
| SHOTS IN THE MOVE | 12.9 | +546.8 | 0.0 | 243.8 | 11.2 | +342.3 | 0.0 | 148.3 |
| SPELL CATCH ODDS | 0.1 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +67.0 | 0.0 | 0.0 | 0.2 | +43.6 | 4.4 | 18.9 |
| SPELL WORTH | 0.8 | +19.9 | 91.9 | 87.5 | 1.8 | +37.2 | 45.9 | 45.9 |
| SPELLS IN THE FIGHT | 0.6 | -3.8 | 43.3 | 19.6 | - | - | - | - |
| STABLE ROLE | 10.9 | +0.0 | 402.1 | 172.0 | 11.9 | +0.0 | 425.0 | 162.2 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +5.1 | 0.0 | 0.0 |
| STOPS | 0.1 | +3.2 | 8.2 | 2.4 | 0.1 | +12.4 | 13.8 | 0.9 |
| STOPS SHORT OF THE FLANK | 0.6 | +36.3 | 0.0 | 9.4 | 0.3 | +10.2 | 0.0 | 38.5 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 7.2 | -68.5 | 413.5 | 123.9 | 8.3 | -54.5 | 450.2 | 116.7 |
| SUPPORTS | 5.1 | +71.5 | 268.1 | 70.7 | 4.8 | +59.9 | 146.2 | 48.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.1 | 14.2 | 0.0 | 0.1 | -10.9 | 8.9 | 14.2 |
| SURE REACH TOGETHER | 0.5 | +6.3 | 5.7 | 4.9 | 0.7 | +9.9 | 0.0 | 12.4 |
| THROUGH LINE OF FIRE | 0.2 | +8.3 | 0.0 | 0.0 | 0.1 | -0.7 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -13.4 | 15.6 | 6.1 | 0.6 | -42.0 | 57.1 | 8.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.6 | 0.0 | 2.9 | 0.4 | +2.7 | 8.0 | 3.8 |
| WAIT AFTER COSTS | 6.1 | -263.1 | 121.1 | 99.0 | 8.1 | -386.8 | 293.8 | 204.6 |
| WALKS TO THE FIGHT | 1.2 | +25.0 | 3.4 | 24.3 | 1.5 | +36.2 | 31.6 | 32.8 |
| WAR ENGINE CHARGES | 0.1 | +7.5 | 0.0 | 4.2 | 0.1 | +0.6 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 23.1 | 31.2 | 0.2 | +0.0 | 15.1 | 15.4 |
| WEARS DOWN | 1.2 | +49.8 | 79.4 | 31.8 | 1.8 | +53.6 | 259.0 | 53.7 |
| WHO HITS BACK | 0.3 | +25.7 | 0.0 | 16.8 | 0.2 | +20.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +9.9 | 27.0 | 0.0 | 0.6 | +31.3 | 88.1 | 6.4 |
| WHOLE FIGHT GAIN | 0.3 | +14.2 | 18.1 | 4.2 | 0.8 | +55.9 | 103.9 | 21.9 |
| WIDER SPREAD | 2.2 | -8.1 | 153.2 | 57.2 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 2.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: cw-h2h-mine-3cc170f-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1105 | 1105 | 1105 | 30.69 | -60052 | -54.3 |
| BEST FIRST | 309 | 309 | 309 | 8.58 | +13504 | +43.7 |
| SEARCH SPOT | 206 | 206 | 203 | 5.64 | +10664 | +52.5 |
| PATHS CROSS | 179 | 179 | 179 | 4.97 | +13482 | +75.3 |
| COUNTER-CHARGE COVER | 666 | 387 | 168 | 4.67 | +10683 | +63.6 |
| SUPPORTS | 357 | 357 | 144 | 4.00 | +1610 | +11.2 |
| MOVE TO CHARGE | 270 | 270 | 136 | 3.78 | +5352 | +39.4 |
| KILLS COUNT NEXT TURN | 445 | 445 | 135 | 3.75 | +3519 | +26.1 |
| FACES THE THREAT | 120 | 120 | 120 | 3.33 | +9619 | +80.2 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +10442 | +137.4 |
| SAFER THAN THE JOB | 76 | 76 | 76 | 2.11 | +4960 | +65.3 |
| FALLBACK BY WORTH | 368 | 368 | 75 | 2.08 | +4996 | +66.6 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SHOTS IN THE MOVE | 868 | 572 | 61 | 1.69 | +2085 | +34.2 |
| WAIT AFTER COSTS | 511 | 511 | 60 | 1.67 | +1384 | +23.1 |
| WALKS TO THE FIGHT | 99 | 99 | 58 | 1.61 | +947 | +16.3 |
| BEST FACING | 56 | 56 | 56 | 1.56 | +2769 | +49.4 |
| RANDOM MOVE BY FIGURES | 91 | 91 | 56 | 1.56 | +1865 | +33.3 |
| RESERVE FALL BACK | 55 | 55 | 55 | 1.53 | +1416 | +25.8 |
| REDIRECT COUNTER | 240 | 137 | 52 | 1.44 | +5028 | +96.7 |
| MAX FOR POSITIONING | 367 | 224 | 51 | 1.42 | +716 | +14.0 |
| ARTILLERY RE-ROLL WEIGHED | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| BEST OVERALL | 46 | 46 | 46 | 1.28 | +3345 | +72.7 |
| CANNON PLANNED TARGET | 236 | 236 | 45 | 1.25 | -637 | -14.2 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK BY ARC | 226 | 220 | 42 | 1.17 | +1637 | +39.0 |
| CHARGE NOW FIRST | 199 | 199 | 40 | 1.11 | -2579 | -64.5 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KILLS COUNT | 159 | 157 | 37 | 1.03 | +1345 | +36.3 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2708 | +75.2 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +153 | +4.5 |
| SET UP TOGETHER | 87 | 69 | 34 | 0.94 | +2041 | +60.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1671 | +53.9 |
| SHOOTS FROM THE BEST SPOT | 60 | 60 | 29 | 0.81 | +863 | +29.8 |
| MARCH CHECK | 32 | 31 | 27 | 0.75 | +888 | +32.9 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +601 | +26.1 |
| WEARS DOWN | 106 | 103 | 23 | 0.64 | +1006 | +43.7 |
| INVITES THE FIGHT | 113 | 113 | 22 | 0.61 | +247 | +11.2 |
| FRIENDS SHOTS CHECKED | 21 | 21 | 21 | 0.58 | +1383 | +65.9 |
| KEEPS ITS TARGET | 127 | 125 | 21 | 0.58 | +397 | +18.9 |
| MISSILES IN THE MOVE | 241 | 143 | 21 | 0.58 | +331 | +15.8 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -15 | -0.8 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +4122 | +206.1 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +692 | +36.4 |
| MOVE AND CAST | 19 | 19 | 19 | 0.53 | +1141 | +60.0 |
| BEST PREY | 67 | 67 | 17 | 0.47 | +948 | +55.7 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1005 | +59.1 |
| WHOLE FIGHT GAIN | 39 | 34 | 17 | 0.47 | +824 | +48.5 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTING BLOCK | 18 | 18 | 15 | 0.42 | +736 | +49.1 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MANOEUVRE | 17 | 17 | 15 | 0.42 | +713 | +47.5 |
| CAST JOB | 25 | 25 | 14 | 0.39 | +257 | +18.3 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SHOT REPLANNED | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HONEST WORTH | 249 | 248 | 13 | 0.36 | +148 | +11.4 |
| PIVOT GUARDS FLANK | 13 | 13 | 13 | 0.36 | -393 | -30.2 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 13 | 13 | 13 | 0.36 | +276 | +21.3 |
| MAKE SURE TOGETHER | 45 | 25 | 12 | 0.33 | +602 | +50.1 |
| OPENS UP | 23 | 23 | 12 | 0.33 | +884 | +73.6 |
| SUPPORT NARROWED | 559 | 559 | 12 | 0.33 | -119 | -9.9 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -18 | -1.8 |
| LOST CHARGE | 181 | 181 | 10 | 0.28 | +218 | +21.8 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -322 | -35.8 |
| SURE REACH TOGETHER | 42 | 29 | 9 | 0.25 | +108 | +12.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +183 | +22.9 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -467 | -58.4 |
| WHOLE FIGHT | 26 | 26 | 8 | 0.22 | +456 | +57.0 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -306 | -43.8 |
| CHARGE BAND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| HUNT IN PAIRS | 31 | 19 | 6 | 0.17 | +376 | +62.6 |
| MISSILES NEXT TURN | 281 | 159 | 6 | 0.17 | +8 | +1.3 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +56 | +11.1 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| OVERRUNS AWAY | 39 | 38 | 5 | 0.14 | +114 | +22.8 |
| WAR ENGINE JOBS | 34 | 34 | 5 | 0.14 | -511 | -102.1 |
| HUNT ADVANCE | 17 | 17 | 4 | 0.11 | +20 | +4.9 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +54 | +18.0 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -249 | -83.0 |
| DEFENSIVE ARMY | 17 | 17 | 3 | 0.08 | -152 | -50.6 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +351 | +117.1 |
| LONG SHOT | 54 | 54 | 3 | 0.08 | +64 | +21.3 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +240 | +80.1 |
| SPELLS IN THE FIGHT | 22 | 22 | 3 | 0.08 | +18 | +5.8 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +184 | +61.2 |
| BACKUP TARGETS | 81 | 41 | 2 | 0.06 | +62 | +30.8 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -70 | -35.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +111 | +55.5 |
| REFUSING RETIRES | 6 | 6 | 2 | 0.06 | -1 | -0.4 |
| STOPS | 7 | 7 | 2 | 0.06 | +100 | +49.9 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -86 | -85.6 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -33 | -32.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 23 | 23 | 1 | 0.03 | +0 | +0.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +2 | +2.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +62 | +62.3 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 1 | 0.03 | -2 | -2.3 |
| MOVE SPELL IN RANGE | 4 | 3 | 1 | 0.03 | +1 | +1.1 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +6 | +5.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +165 | +164.9 |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 1 | 0.03 | +8 | +8.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -0 | -0.2 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +176 | +175.9 |
| WIDER SPREAD | 81 | 80 | 1 | 0.03 | +2 | +1.9 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -42 | -41.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 7 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 20 | 20 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 394 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 26 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 33 | 33 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 18 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 14 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 28 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 421 | 421 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2805 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 821 | 819 | 0 | 0.00 | - | - |
| TURN WORTH | 30 | 29 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 19 | 13 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-mine-3cc170f-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.50 | 13.94 | 55.2 |
| FALLBACK | gate | 0.69 | 0.72 | 54.9 |
| CHARGE NOW FIRST | rule | 0.39 | 0.72 | 64.5 |
| TURN GATE | gate | 0.67 | 0.42 | 44.3 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.14 | 49.6 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.19 | 30.2 |
| SUPPORT NARROWED | rule | 0.08 | 0.22 | 10.8 |
| CHAFF PASSED | rule | 0.06 | 0.19 | 1.6 |
| PURSUES BIG PREY | rule | 0.03 | 0.22 | 35.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.11 | 58.4 |
| AFTERMATH BAND | gate | 0.08 | 0.11 | 3.4 |
| BEST PRIZE | rule | 0.14 | 0.06 | 43.8 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 39.8 |
| PATHS CROSS | rule | 0.08 | 0.11 | 24.9 |
| BLOCKED WHEEL | rule | 0.03 | 0.14 | 35.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.11 | 66.7 |
| SUPPORT REQUEST | gate | - | 0.14 | 83.1 |
| WAR ENGINE JOBS | rule | 0.08 | 0.06 | 102.1 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 10.5 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 83.0 |
| DEFENSIVE ARMY | rule | 0.03 | 0.06 | 50.6 |
| FIGHT ORDER BAND | gate | 0.08 | - | 2.9 |
| NO REASON | gate | 0.08 | - | 16.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 7.0 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 35.0 |
| SAFER THAN THE JOB | rule | 0.06 | - | 13.5 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 24.8 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 85.6 |
| CATCH ODDS | rule | - | 0.03 | 32.7 |
| FACES THE THREAT | rule | 0.03 | - | 9.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 2.3 |
| LONG SHOT | rule | - | 0.03 | 0.7 |
| MARCH ODDS | rule | - | 0.03 | 17.4 |
| RULE SWITCHED OFF | gate | - | 0.03 | 56.5 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 5.8 |
| WHO HITS BACK | rule | - | 0.03 | 2.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 41.8 |

### Plans: cw-h2h-mine-3cc170f-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 16% | 499 | 305 | 61% |
| Mine | charge | 3.0 | 56% | 251 | 238 | 95% |
| Mine | close in | 3.4 | 23% | 151 | 70 | 46% |
| Mine | hold | 4.2 | 31% | 264 | 0 | 0% |
| Mine | join | 0.6 | 100% | 20 | 0 | 0% |
| Mine | shoot | 7.6 | 61% | 218 | 562 | 258% |
| Mine | support | 5.2 | 89% | 49 | 0 | 0% |
| Opponent | advance | 13.1 | 15% | 392 | 350 | 89% |
| Opponent | charge | 5.9 | 55% | 621 | 573 | 92% |
| Opponent | close in | 6.4 | 26% | 520 | 147 | 28% |
| Opponent | hold | 4.5 | 41% | 342 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 40 | 0 | 0% |
| Opponent | shoot | 5.0 | 52% | 156 | 259 | 166% |
| Opponent | support | 5.2 | 90% | 44 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-mine-3cc170f-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 40% | 60% | 0% | 2.3 | 248 | 127 | 40% | 33 |
| Opponent | 0.4 | 13 | 0 | 8% | 38% | 0% | 2.4 | 290 | 81 | 31% | 78 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 100% | 0% | 2.5 | 298 | 213 | 50% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 280 | 0 | 0% | 70 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| High Elf Realms | 0.5 | 2 | 0 | 50% | 50% | 0% | 2.0 | 224 | 104 | 50% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.8 | 3 | 0 | 33% | 33% | 0% | 4.0 | 488 | 133 | 0% | 176 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.0 | 5 | 0 | 0% | 40% | 0% | 2.0 | 114 | 38 | 40% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 416 | 0 | 0% | 28 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 452 | 0 | 0% | 109 |
| Wood Elf Realms | 0.4 | 3 | 0 | 0% | 67% | 0% | 2.0 | 262 | 155 | 67% | 0 |

### Battle groups: cw-h2h-mine-3cc170f-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.3 | 21% | 52% | 10% | 44% | 33% | 14% | 9% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 29% | 50% | 8% | 0% | 17% | 0% | 12% | 71% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 24% | 72% | 20% | 42% | 22% | 10% | 14% | 53% | 0% |
| Opponent | REDIRECT COUNTER | 4.2 | 25% | 68% | 21% | 12% | 23% | 7% | 20% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-mine-3cc170f-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 27 (5) | 27 | 0 | 0 | 20% | 2.5 | 56 (2) | 0 (3) | - | 41 (3) | 0 (2) |
| Mine | Chaff | 36 | 89 (36) | 50 | 39 | 56 | 33% | 3.0 | 89 (20) | 216 (7) | 4 (9) | 121 (25) | 5 (11) |
| Mine | Character | 123 | 43 (123) | 42 | 1 | 33 | 17% | 2.5 | 44 (37) | 47 (54) | 67 (12) | 63 (51) | 32 (52) |
| Mine | Clean-up | 20 | 53 (20) | 20 | 32 | 43 | 40% | 2.7 | 15 (5) | 42 (12) | 199 (3) | 112 (12) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 53 (46) | 40 | 13 | 62 | 28% | 2.7 | 29 (22) | 112 (16) | 23 (8) | 41 (27) | 69 (19) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 31 (57) | 18 | 13 | 39 | 26% | 2.4 | 17 (18) | 29 (29) | 61 (10) | 24 (38) | 41 (19) |
| Mine | Holder | 29 | 34 (29) | 0 | 34 | 33 | 34% | 3.1 | 26 (11) | 43 (11) | 30 (7) | 34 (22) | 34 (7) |
| Mine | Shooter | 41 | 70 (41) | 26 | 44 | 49 | 2% | 1.6 | 106 (5) | 61 (30) | 89 (6) | 95 (25) | 31 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Mine | War machine | 59 | 39 (59) | 39 | 0 | 52 | 3% | 1.2 | 24 (10) | 38 (37) | 55 (12) | 22 (10) | 42 (49) |
| Mine | Wizard | 22 | 3 (22) | 3 | 0 | 58 | 14% | 2.3 | 8 (7) | 0 (6) | 0 (5) | 0 (5) | 4 (13) |
| Opponent | Blocker | 2 | 99 (2) | 99 | 0 | 0 | 50% | 4.0 | - | 99 (2) | - | 99 (2) | - |
| Opponent | Chaff | 76 | 66 (76) | 27 | 39 | 48 | 33% | 2.6 | 57 (31) | 79 (20) | 64 (25) | 83 (54) | 27 (22) |
| Opponent | Character | 94 | 59 (94) | 59 | 0 | 26 | 28% | 2.6 | 72 (41) | 55 (37) | 28 (6) | 57 (57) | 72 (27) |
| Opponent | Clean-up | 21 | 28 (21) | 11 | 17 | 54 | 33% | 2.7 | 17 (9) | 40 (12) | - | 39 (15) | 6 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 48 | 48 (48) | 39 | 9 | 34 | 25% | 2.3 | 60 (22) | 26 (16) | 63 (10) | 45 (28) | 53 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 65 | 40% | 2.3 | - | 0 (3) | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Hammer | 68 | 28 (68) | 23 | 5 | 43 | 24% | 2.8 | 59 (17) | 20 (40) | 26 (11) | 35 (42) | 19 (26) |
| Opponent | Holder | 35 | 82 (35) | 10 | 72 | 26 | 29% | 3.4 | 38 (6) | 94 (23) | 66 (6) | 100 (20) | 58 (15) |
| Opponent | Shooter | 33 | 76 (33) | 14 | 62 | 31 | 3% | 1.8 | 31 (8) | 107 (19) | 23 (6) | 111 (22) | 21 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 50 | 33% | 5.5 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 24 | 42 (24) | 42 | 0 | 20 | 4% | 1.7 | 22 (6) | 45 (14) | 56 (4) | 0 (3) | 48 (21) |
| Opponent | Wizard | 29 | 14 (29) | 14 | 0 | 57 | 7% | 1.4 | 0 (10) | 38 (7) | 5 (8) | 26 (13) | 0 (12) |

### Charged fights: cw-h2h-mine-3cc170f-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 180 | 130 | 1.0 | 1.0 | 130 | 13 | +117 | 0 of 4 | 4 of 4 | - | +117 |
| Mine | Chaos Dwarfs | 4 | 231 | 499 | 2.2 | 1.1 | 222 | 0 | +222 | 5 of 9 | 7 of 9 | +416 | +198 |
| Mine | Dwarfen Mountain Holds | 4 | 660 | 74 | 3.0 | 1.2 | 25 | 9 | +16 | 2 of 12 | 6 of 12 | +0 | +19 |
| Mine | Empire of Man | 5 | 340 | 171 | 2.0 | 1.2 | 86 | 26 | +59 | 5 of 10 | 7 of 10 | +231 | +16 |
| Mine | Grand Cathay | 4 | 148 | 269 | 2.5 | 1.0 | 108 | 0 | +108 | 1 of 10 | 8 of 10 | - | +108 |
| Mine | High Elf Realms | 4 | 71 | 347 | 3.8 | 1.0 | 93 | 0 | +93 | 3 of 15 | 14 of 15 | - | +93 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 497 | 6.0 | 1.2 | 83 | 0 | +83 | 2 of 6 | 5 of 6 | +122 | +75 |
| Mine | Lizardmen | 1 | 0 | 375 | 5.0 | 1.0 | 75 | 0 | +75 | 2 of 5 | 4 of 5 | - | +75 |
| Mine | Ogre Kingdoms | 1 | 0 | 125 | 4.0 | 1.0 | 31 | 8 | +23 | 0 of 4 | 3 of 4 | - | +23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 3.0 | 1.3 | 78 | 0 | +78 | 1 of 3 | 2 of 3 | +45 | +95 |
| Mine | Skaven | 2 | 58 | 0 | 1.0 | 1.0 | 0 | 124 | -124 | 0 of 2 | 1 of 2 | - | -124 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 807 | 7.0 | 1.1 | 115 | 17 | +98 | 1 of 7 | 7 of 7 | +432 | +42 |
| Mine | Vampire Counts | 3 | 0 | 68 | 2.7 | 1.5 | 26 | 142 | -116 | 3 of 8 | 4 of 8 | -136 | -104 |
| Mine | Warriors of Chaos | 1 | 0 | 334 | 1.0 | 1.0 | 334 | 0 | +334 | 0 of 1 | 0 of 1 | - | +334 |
| **Mine** | all armies | 36 | 194 | 242 | 2.7 | 1.1 | 91 | 20 | +70 | 25 of 96 | 72 of 96 | +97 | +67 |
| Opponent | Dwarfen Mountain Holds | 2 | 137 | 112 | 3.0 | 1.2 | 37 | 10 | +27 | 1 of 6 | 1 of 6 | -60 | +45 |
| Opponent | Empire of Man | 2 | 252 | 168 | 2.0 | 1.2 | 84 | 60 | +24 | 1 of 4 | 4 of 4 | +0 | +32 |
| Opponent | Grand Cathay | 2 | 241 | 770 | 3.5 | 1.7 | 220 | 29 | +191 | 4 of 7 | 7 of 7 | +254 | +144 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| Opponent | Ogre Kingdoms | 3 | 42 | 430 | 3.7 | 1.1 | 117 | 7 | +110 | 4 of 11 | 6 of 11 | +292 | +92 |
| Opponent | Skaven | 1 | 125 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 78 | 888 | 4.8 | 1.1 | 187 | 71 | +116 | 8 of 19 | 12 of 19 | +162 | +114 |
| Opponent | Vampire Counts | 6 | 0 | 716 | 5.0 | 1.2 | 143 | 47 | +97 | 14 of 30 | 21 of 30 | -30 | +122 |
| Opponent | Warriors of Chaos | 8 | 22 | 332 | 2.5 | 1.2 | 133 | 6 | +127 | 8 of 20 | 16 of 20 | +280 | +89 |
| Opponent | Wood Elf Realms | 7 | 126 | 710 | 5.3 | 1.1 | 134 | 27 | +108 | 12 of 37 | 24 of 37 | +262 | +94 |
| **Opponent** | all armies | 36 | 83 | 527 | 3.8 | 1.2 | 140 | 33 | +107 | 52 of 136 | 93 of 136 | +153 | +99 |

### Effective charges: cw-h2h-mine-3cc170f-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 1 (net +100) | 0 | 1 (net +365) | 0 | 2 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 9 | 2 (net +442) | 0 | 0 | 3 (net +76) | 2 (net +74) | 1 (net +416) | 1 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 12 | 3 (net +0) | 1 (net +107) | 2 (net +40) | 0 | 0 | 5 (net +1) | 1 | 18% (2 of 11) |
| Mine | Empire of Man | 10 | 1 (net +350) | 0 | 4 (net +16) | 2 (net +32) | 1 (net +112) | 2 (net +0) | 0 | 40% (4 of 10) |
| Mine | Grand Cathay | 10 | 1 (net +185) | 0 | 1 (net +185) | 1 (net +110) | 2 (net +20) | 2 (net +278) | 3 | 14% (1 of 7) |
| Mine | High Elf Realms | 15 | 0 | 1 (net +195) | 3 (net +141) | 3 (net +39) | 2 (net +30) | 5 (net +82) | 1 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 6 | 0 | 0 | 2 (net +164) | 2 (net +0) | 0 | 2 (net +85) | 0 | 33% (2 of 6) |
| Mine | Lizardmen | 5 | 1 (net +0) | 0 | 0 | 2 (net +162) | 1 (net +0) | 0 | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +62) | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 1 | 50% (1 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -124) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net -122) | 1 (net +125) | 3 (net +144) | 1 (net +125) | 1 | 17% (1 of 6) |
| Mine | Vampire Counts | 8 | 3 (net -205) | 0 | 2 (net -260) | 1 (net +205) | 1 (net +0) | 0 | 1 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1 (net +334) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 6 | 1 (net +0) | 1 (net -60) | 1 (net +81) | 2 (net +71) | 0 | 1 (net +0) | 0 | 17% (1 of 6) |
| Opponent | Empire of Man | 4 | 0 | 0 | 0 | 2 (net +48) | 2 (net +0) | 0 | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 7 | 1 (net +407) | 0 | 1 (net +214) | 2 (net +180) | 1 (net +0) | 2 (net +177) | 0 | 14% (1 of 7) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +105) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 11 | 3 (net +110) | 0 | 1 (net +143) | 2 (net +168) | 0 | 3 (net +94) | 2 | 11% (1 of 9) |
| Opponent | Tomb Kings of Khemri | 19 | 4 (net -87) | 0 | 4 (net +258) | 5 (net +65) | 1 (net +162) | 5 (net +208) | 0 | 21% (4 of 19) |
| Opponent | Vampire Counts | 30 | 7 (net +81) | 0 | 5 (net -65) | 5 (net +98) | 2 (net +148) | 10 (net +173) | 1 | 17% (5 of 29) |
| Opponent | Warriors of Chaos | 20 | 1 (net +73) | 1 (net +407) | 4 (net +29) | 4 (net +82) | 1 (net +328) | 8 (net +176) | 1 | 21% (4 of 19) |
| Opponent | Wood Elf Realms | 37 | 6 (net +274) | 2 (net +106) | 4 (net +102) | 6 (net +79) | 5 (net +139) | 11 (net +80) | 3 | 12% (4 of 34) |

### Charged fights, damage counted: cw-h2h-mine-3cc170f-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 216 | 264 | +73 | 162 | 92 | +70 | +32.5 |
| Mine | 50-54% | 2 | 88 | 151 | +151 | 151 | 0 | +151 | +172.6 |
| Mine | Effective (55-75%) | 18 | 241 | 222 | +51 | 135 | 76 | +59 | +24.6 |
| Mine | 76-89% | 15 | 350 | 205 | +78 | 124 | 40 | +84 | +24.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 192 | 157 | +76 | 107 | 21 | +86 | +44.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 394 | 83 | +89 | 108 | 21 | +87 | +22.1 |
| Mine | No odds | 14 | 220 | 122 | +46 | 86 | 26 | +60 | +27.1 |
| Mine | All fights | 96 | 258 | 174 | +70 | 119 | 43 | +77 | +29.7 |
| Opponent | Long shot (under 50%) | 23 | 224 | 289 | +116 | 180 | 84 | +96 | +43.0 |
| Opponent | 50-54% | 4 | 208 | 202 | +140 | 207 | 40 | +167 | +80.1 |
| Opponent | Effective (55-75%) | 20 | 279 | 252 | +83 | 178 | 88 | +90 | +32.2 |
| Opponent | 76-89% | 29 | 248 | 180 | +88 | 110 | 22 | +88 | +35.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 265 | 184 | +142 | 179 | 41 | +138 | +51.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 503 | 103 | +123 | 144 | 24 | +119 | +23.7 |
| Opponent | No odds | 7 | 197 | 202 | -27 | 125 | 110 | +15 | +7.8 |
| Opponent | All fights | 136 | 272 | 205 | +107 | 159 | 53 | +106 | +38.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-mine-3cc170f-p2 | move | 453 | 89 (20%) | 62 (14%) | 64 (14%) | 300 (66%) |
| cw-h2h-mine-3cc170f-p2 | objective | 356 | 54 (15%) | 41 (12%) | 46 (13%) | 256 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

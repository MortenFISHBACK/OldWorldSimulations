# Doctrine scorecard: cw-h2h-opp-3cc170f-p1

### Scorecard: cw-h2h-opp-3cc170f-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 18 | 5 | 1 | 0 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 2 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 2 | 2 | 0 | 4 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 5 | 2 | 0 | 2 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 5 | 2 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 3 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 3 | - | 0 | 2 | 0 | 0 | 0 | 1104 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 5 | 3 | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 3 | 6 | 1 | 3 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 901 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 926 |
| L0612 | 6 | 1 | Opponent | no | 5 | 4 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 1252 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 462 |
| L0717 | 3 | 1 | Mine | yes | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 3 | 4 | 3 | 0 | 2 | 0 | 0 | 135 |
| L0733 | 1 | 1 | Mine | no | 3 | 3 | 3 | 2 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 5 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 10 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 935 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 9 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 3 | 4 | 0 | 4 | 0 | 0 | 0 | 420 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 3 | 0 | 1 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 14 | 2 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | yes | 8 | 2 | 5 | 1 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 1 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 5 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 54 |
| L1625 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 2 | 0 | 0 | 282 |
| L1723 | 1 | 1 | Opponent | yes | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 4 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | no | 11 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 6 | - | 0 | 1 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 787 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 371 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 4 | 0 | 4 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 2 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | - | 0 | 0 | 1 | 0 | 0 | 207 |
| L2934 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 26% | 3.6 | 2.8 | 2.5 | 1.1 | 0.2 | 0.0 | 0.0 | 314.5 |
| **Average** | | | Opponent | 18% | 2.8 | 2.6 | 2.6 | 1.8 | 0.4 | 0.0 | 0.0 | 174.4 |

### KPIs: cw-h2h-opp-3cc170f-p1

Rules off - Mine only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 173) | 3% (5 of 183) | 15% (53 of 356) |
| Winner chose to follow up after the loser gave ground |  | 93% (69 of 74); on the table 97% | 97% (60 of 62); on the table 97% | 95% (129 of 136); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 71% (10 of 14); on the table 79% | 93% (14 of 15); on the table 93% | 83% (24 of 29); on the table 86% |
| Winner chose to pursue after the loser fled |  | 60% (25 of 42); on the table 71% | 96% (45 of 47); on the table 96% | 79% (70 of 89); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 80% (104 of 130); on the table 87% | 96% (119 of 124); on the table 96% | 88% (223 of 254); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 37% (123 of 330) | 30% (62 of 210) | 34% (185 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (123 of 231) | 42% (62 of 146) | 49% (185 of 377) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (14 of 27) | 54% (30 of 56) | 53% (44 of 83) |
| Points that never fought | lower | 39% (28156 of 71484) | 43% (30758 of 71889) | 41% (58914 of 143373) |
|   infantry points that never fought | lower | 45% (7537 of 16863) | 57% (7660 of 13348) | 50% (15197 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (144 of 279) | 60% (177 of 295) | 56% (321 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.3 uses a game | 80% (16 of 20); 1.8 uses a game | 88% (37 of 42); 2.0 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.8 uses a game | 25% (2 of 8); 0.1 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 42% (5 of 12); 0.1 uses a game | 48% (15 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (27357 of 59666) | 53% (33376 of 62699) | 50% (60733 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (36%) | 1.4 (34%) | 3.5 (35%) |
| MARCHED: its unit marched | 0.7 (12%) | 0.4 (9%) | 1.1 (11%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.7 (29%) | 0.9 (21%) | 2.5 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.8 (13%) | 0.7 (16%) | 1.4 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.1 (3%) | 0.4 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.5 | 1.3 | 5.1 | 0.4 | 2.7 |
| not cast | 3.9 | 2.8 | 3.4 | 9.9 | 1.9 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (38%) | 0.3 (10%) | 3.5 (35%) | 0.3 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (11%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.3 (11%) | 0.5 (15%) | 2.5 (26%) | 0.6 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (12%) | 0.4 (13%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.8 (20%) | 0.4 (15%) | 0.4 (13%) | 1.4 (14%) | 0.2 (10%) | 2.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (4%) | 0.2 (7%) | 0.4 (5%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) | 0.1 (1%) | 0.5 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (58%) | 0.3 (10%) | 1.3 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 68% (23 of 34) | 62% (8 of 13) | 66% (31 of 47) |
| the unit moved after it | 65% (15 of 23) | 25% (2 of 8) | 55% (17 of 31) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 8) | 0% (0 of 31) |
| the enemy charged it first | 9% (2 of 23) | 12% (1 of 8) | 10% (3 of 31) |
| it fought by the end of its next turn | 9% (2 of 23) | 25% (2 of 8) | 13% (4 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (5 of 23) | 12% (1 of 8) | 19% (6 of 31) |
| none of these (no charge, no fight, no charge escaped) | 70% (16 of 23) | 62% (5 of 8) | 68% (21 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (556 of 908) | 60% (346 of 576) | 61% (902 of 1484) |
|   cavalry | 55% (46 of 84) | 73% (89 of 122) | 66% (135 of 206) |
|   character | 43% (42 of 97) | 36% (39 of 107) | 40% (81 of 204) |
|   chariot | 45% (42 of 94) | 67% (24 of 36) | 51% (66 of 130) |
|   infantry | 57% (178 of 310) | 57% (130 of 227) | 57% (308 of 537) |
|   monster | 62% (21 of 34) | 37% (10 of 27) | 51% (31 of 61) |
|   war machine | 79% (227 of 289) | 95% (54 of 57) | 81% (281 of 346) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (28%) | 1.4 (23%) | 4.2 (26%) |
| CHARGED: it charged | 1.1 (11%) | 1.3 (20%) | 2.4 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (9%) | 0.5 (7%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.8 (18%) | 1.6 (25%) | 3.3 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.5 (8%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (18%) | 0.8 (12%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (2%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.1 | 81% | 4.6 pts | 25 pts |
| character | 2.6 | 0.6 | 79% | 6.5 pts | 17 pts |
| chariot | 1.9 | 0.9 | 72% | 10.0 pts | 19 pts |
| infantry | 12.4 | 4.4 | 75% | 8.3 pts | 104 pts |
| monster | 0.9 | 0.4 | 74% | 5.9 pts | 6 pts |
| war machine | 7.8 | 5.4 | 64% | 22.6 pts | 177 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 5.5 | 5.1 |
| Charges that made contact a game | 3.6 | 3.6 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 0.91 contact (22 units) | 0.57 declared, 0.50 contact (14 units) | 0.92 declared, 0.75 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.14 declared, 0.86 contact (7 units) | 1.29 declared, 1.00 contact (7 units) | 1.21 declared, 0.93 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.42 contact (249 units) | 0.65 declared, 0.42 contact (277 units) | 0.61 declared, 0.42 contact (526 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (40 of 70) | 52% (11 of 21) | 38% (3 of 8) | 55% (54 of 99) |
| Character in a unit | 80% (28 of 35) | 74% (17 of 23) | 50% (2 of 4) | 76% (47 of 62) |
| Character on its own | 87% (45 of 52) | 43% (16 of 37) | 24% (15 of 62) | 50% (76 of 151) |
| Chariot | 44% (7 of 16) | 60% (6 of 10) | - | 50% (13 of 26) |
| Infantry | 56% (50 of 89) | 28% (10 of 36) | 50% (1 of 2) | 48% (61 of 127) |
| Monster | 59% (19 of 32) | 90% (9 of 10) | - | 67% (28 of 42) |
| Monstrous | 73% (8 of 11) | 57% (8 of 14) | - | 64% (16 of 25) |
| War Machines | 61% (25 of 41) | 100% (1 of 1) | - | 62% (26 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 70% (7 of 10); on the table 80% | 43% (60 of 138) | 47% | 52% (17 of 33) | 100% (9 of 9); 5.2 uses a game | 100% (3 of 3); 1.7 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 71% (10 of 14); on the table 86% | 17% (4 of 24) | 34% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 97% (33 of 34); on the table 97% | - | 51% | 66% (27 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 54% (7 of 13); on the table 62% | 47% (17 of 36) | 68% | 55% (35 of 64) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 89% (16 of 18); on the table 89% | 31% (33 of 108) | 41% | 36% (16 of 44) | 100% (12 of 12); 10.2 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 72% (13 of 18); on the table 83% | 23% (7 of 30) | 39% | 51% (25 of 49) | 100% (5 of 5); 3.8 uses a game | 44% (8 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 37% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 24% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (12 of 12); on the table 100% | 8% (1 of 12) | 61% | 62% (13 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (15 of 15); on the table 100% | 14% (5 of 36) | 10% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (12 of 12); on the table 100% | 47% (14 of 30) | 33% | 62% (21 of 34) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 86% (36 of 42); on the table 90% | 0% (0 of 12) | 32% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (28 of 32); on the table 91% | 31% (17 of 54) | 31% | 54% (27 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 100% (13 of 13); on the table 100% | 47% (14 of 30) | 37% | 70% (52 of 74) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (14 of 14); on the table 100% | 43% (13 of 30) | 50% | 59% (39 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-opp-3cc170f-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (46) | 45% (35) | 52% (81) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.64 | 1.39 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.11 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.47 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 1.47 | 3.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.78 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 5.14 | 10.72 |

### Quality by phase: cw-h2h-opp-3cc170f-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 55% (85 of 155) | 41% (69 of 170) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (195 of 378) | 53% (101 of 191) |
| Strategy | Close-in objectives charged next turn | 16% (22 of 141) | 15% (33 of 219) |
| Strategy | Support requests answered (helper made contact too) | 42% (8 of 19) | 53% (17 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 80% (4 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (6 of 15) | 75% (9 of 12) |
| Strategy | Joined characters whose unit fought | 43% (24 of 56) | 35% (14 of 40) |
| Strategy | Lone characters that fought | 76% (68 of 90) | 74% (71 of 96) |
| Movement | Charges halted short of contact | 0.3 | 0.2 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 314.5 | 174.4 |
| Movement | Fights charged into per game | 3.2 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 99, net +51 | 15 of 100, net +23 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 99, net +81 | 21 of 100, net +59 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 99, net +42 | 6 of 100, net +154 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 of 99, net +134 | 29 of 100, net +126 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (140 of 359) | 47% (157 of 335) |
| Shooting | Points destroyed by shooting units | 83.2 | 19.3 |
| Shooting | War machine shots | 6.3 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (105 of 227) | 35% (19 of 54) |
| Shooting | Points destroyed by war machines | 83.3 | 37.1 |
| Magic | Magic missiles cast | 2.4 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (23 of 88) | 56% (19 of 34) |
| Magic | Wounds caused by magic missiles | 5.3 | 2.2 |
| Magic | Wounds caused by other spells | 1.9 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 73.6 | 27.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.9 / 0.2 | 1.6 / 0.4 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 365.8 | 361.6 |
| Combat | Points run down | 93.3 | 102.7 |
| Combat | Net points per charged fight, damage counted | +81 | +77 |
| Combat | Net per 100 charger points, damage counted | +27.8 | +31.1 |
| Combat | First round won (charged fights) | 72% | 70% |
| Combat | Net points per charged fight | +76 | +78 |
| Combat | Net points per supported fight / lone fight | +169 / +63 | +100 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 49 of 115 | 48 of 111 |
| Game | Points lost | 644.7 | 789.8 |
| Game | VP from objectives | 648.9 | 600.3 |
| Game | Lone holders (player turns) | 3.6 | 2.8 |

- Mine won / drew / lost: 22 / 2 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +199 VP
- The side that went first won 15 of 34 games with a winner
- Points traded per game (both sides' losses): 1434
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cw-h2h-opp-3cc170f-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 1.8 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 16.4 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.6 | +6.1 | 0.0 | 15.6 | 1.1 | +12.4 | 0.0 | 57.6 |
| BEST FACING | 0.8 | +36.7 | 0.0 | 43.6 | 0.7 | +52.6 | 0.0 | 38.9 |
| BEST FIRST | 4.1 | +194.7 | 200.9 | 55.3 | 4.1 | +167.0 | 93.3 | 33.3 |
| BEST OVERALL | 0.6 | +70.2 | 0.0 | 17.5 | 0.8 | +47.4 | 0.0 | 49.8 |
| BEST PREY | 0.9 | +40.6 | 22.7 | 31.5 | 0.9 | +30.3 | 17.0 | 16.6 |
| BEST PRIZE | 0.1 | +4.9 | 7.2 | 1.4 | 0.1 | -1.0 | 2.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -0.9 | 0.0 | 26.2 | 0.2 | +0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.0 | +0.0 | 11.2 | 0.0 |
| BLOCKED WHEEL | 0.2 | +2.8 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 4.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -21.2 | 19.5 | 6.3 |
| BOMBING RUN | 0.1 | +1.7 | 8.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 56.7 | 2.6 | 0.2 | +0.0 | 26.1 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +151.6 | 296.3 | 39.9 | 1.2 | +34.2 | 98.9 | 12.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 6.3 | 0.0 | 0.1 | -1.2 | 11.9 | 16.6 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 11.3 | 0.0 | 0.1 | +0.0 | 4.9 | 0.0 |
| CAST JOB | 0.6 | +37.7 | 41.7 | 26.0 | 0.3 | +4.3 | 1.5 | 6.5 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +39.7 | 22.5 | 0.0 | 0.1 | +3.8 | 1.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -0.7 | 0.0 | 3.7 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE BAND | - | - | - | - | 0.2 | +0.0 | 26.8 | 0.0 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 237.1 | 104.0 | 2.5 | +0.0 | 239.9 | 66.3 |
| CHARGE NOW WEIGHED | 0.5 | -33.3 | 23.1 | 50.2 | 0.4 | -79.2 | 3.5 | 16.2 |
| CHARGER SLAIN LOST | - | - | - | - | 0.6 | -20.9 | 48.8 | 21.9 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.0 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 13.6 | 1.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 30.1 | 28.7 | 0.3 | +0.0 | 0.0 | 5.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +47.2 | 0.0 | 11.2 | 0.3 | +40.8 | 11.1 | 33.9 |
| COUNTER-CHARGE COVER | 9.3 | +743.4 | 0.0 | 203.7 | 7.2 | +700.0 | 0.0 | 203.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 35.8 | 3.9 | 0.1 | +0.0 | 16.1 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +5.4 | 0.0 | 3.5 |
| EDGE GIVE GROUND | 0.2 | +7.5 | 24.6 | 5.4 | 0.0 | +0.1 | 1.8 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +148.8 | 0.0 | 55.6 | 1.5 | +127.2 | 0.0 | 59.6 |
| FALLBACK BY WORTH | 5.2 | +73.6 | 0.0 | 70.3 | 5.4 | +67.5 | 0.0 | 63.7 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 2.9 | 0.0 | +0.2 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 187.0 | 5.4 | +0.0 | 0.0 | 183.2 |
| FOCUS FIRE | 0.1 | +3.7 | 5.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.2 | +189.2 | 0.0 | 40.4 | 0.9 | +172.5 | 0.0 | 56.5 |
| FRIENDS SHOTS CHECKED | 0.4 | +32.0 | 0.0 | 18.1 | 0.1 | +7.7 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.1 | 4.4 | 3.5 | 0.2 | -1.4 | 9.4 | 20.2 |
| GIVES UP ITS SCREEN | 0.1 | -0.9 | 3.1 | 1.8 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 8.0 | 0.0 | 0.1 | +0.0 | 6.5 | 3.8 |
| HELPER UNSEEN | 0.2 | +0.0 | 26.4 | 9.7 | 0.4 | +0.0 | 24.9 | 1.2 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -17.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 9.8 | -190.0 | 456.5 | 242.1 |
| HUNT ADVANCE | 0.0 | +0.0 | 5.3 | 0.0 | 0.1 | +9.0 | 0.0 | 7.6 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.5 |
| HUNT IN PAIRS | 0.5 | +42.3 | 0.0 | 22.4 | 0.6 | +37.5 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.0 | 5.3 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.0 | +5.5 | 0.0 | 0.0 | 0.2 | +6.9 | 0.0 | 4.8 |
| HUNT THE GUNS | 0.1 | +18.0 | 5.3 | 0.0 | 0.2 | +76.6 | 6.5 | 7.6 |
| INVITES THE FIGHT | 1.9 | +44.2 | 98.4 | 39.4 | 1.6 | +21.8 | 30.6 | 18.6 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +25.0 | 6.5 | 0.8 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -11.4 | 23.6 | 17.8 |
| KEEP FALLS | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.2 | 4.4 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 105.5 | 47.8 | 2.0 | +60.0 | 135.9 | 50.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +85.4 | 163.3 | 50.4 | 1.6 | +61.7 | 138.9 | 24.3 |
| KILLS COUNT NEXT TURN | 4.6 | +154.7 | 145.9 | 109.0 | 6.8 | +260.9 | 202.7 | 229.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +5.8 | 0.0 | 0.0 | 0.4 | +6.7 | 0.0 | 8.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 4.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -1.5 | 19.9 | 2.5 | 0.4 | +4.9 | 7.8 | 8.4 |
| LOST CHARGE | 2.8 | -47.8 | 148.3 | 105.9 | 3.2 | -42.7 | 71.5 | 83.7 |
| LURE BY WHAT IT DRAWS | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -10.4 | 0.0 | 6.2 |
| MAKE SURE TOGETHER | 0.4 | +41.8 | 0.0 | 10.6 | 1.1 | +42.4 | 0.0 | 67.1 |
| MANOEUVRE | 0.2 | +7.3 | 0.0 | 9.0 | 0.2 | +9.6 | 0.0 | 8.9 |
| MARCH AT ESCAPER | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +30.3 | 0.0 | 6.8 | 0.6 | +48.8 | 0.0 | 16.0 |
| MARCH ODDS | 0.1 | +10.6 | 9.4 | 10.2 | 0.3 | +26.2 | 5.8 | 0.0 |
| MARCH OVER CASTS | 0.3 | +18.7 | 0.0 | 11.1 | 0.3 | +25.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +207.3 | 0.0 | 123.8 | 4.9 | +181.9 | 0.0 | 102.3 |
| MISSILES IN THE MOVE | 4.6 | +210.0 | 0.0 | 112.5 | 3.8 | +58.9 | 0.0 | 86.8 |
| MISSILES NEXT TURN | 5.1 | +121.3 | 0.0 | 137.6 | 4.2 | +41.7 | 0.0 | 112.9 |
| MODEL FACING | 0.2 | +82.2 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.7 |
| MOVE AND CAST | 0.3 | +18.6 | 0.0 | 10.2 | 0.3 | +25.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -83.9 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +202.8 | 76.8 | 49.0 | 5.0 | +432.5 | 125.5 | 155.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +1.5 | 3.5 | 13.9 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -19.3 | 45.7 | 10.6 | 0.2 | -9.2 | 28.3 | 1.8 |
| NOT TURNED | 5.6 | +120.0 | 0.0 | 130.4 | 5.1 | +83.8 | 0.0 | 115.6 |
| NOT WORTH A CAST | 0.9 | -0.8 | 0.0 | 11.2 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 14.8 | -765.7 | 0.0 | 216.8 | 15.9 | -843.7 | 13.3 | 368.5 |
| OPENS A LANE | 0.2 | +2.1 | 13.8 | 0.0 | 0.1 | +0.4 | 3.1 | 0.0 |
| OPENS UP | 0.2 | +23.0 | 14.1 | 0.0 | 0.2 | +9.7 | 8.7 | 9.9 |
| OVERRUNS AWAY | 0.6 | +13.8 | 53.5 | 25.8 | 0.6 | +7.9 | 57.3 | 13.0 |
| PATHS CROSS | 2.1 | +131.7 | 0.0 | 43.1 | 2.5 | +196.6 | 0.0 | 65.4 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -3.6 | 0.0 | 4.5 |
| PLAN RESULT | 37.4 | +1316.4 | 1253.2 | 872.6 | 38.1 | +1080.4 | 1017.8 | 1005.3 |
| PURSUES BIG PREY | 0.1 | -2.1 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +8.8 | 0.0 | 34.3 | 1.6 | +22.9 | 0.0 | 68.5 |
| RANDOM MOVER NO PROMISE | 0.1 | -8.5 | 8.9 | 0.0 | 0.4 | -11.7 | 0.0 | 14.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +1.8 | 0.0 | 0.8 | 0.4 | -7.8 | 0.0 | 3.1 |
| REDIRECT COUNTER | 1.9 | +135.5 | 0.0 | 34.6 | 4.4 | +368.0 | 0.0 | 59.0 |
| REDIRECT WEIGHED | 0.2 | +9.4 | 6.2 | 1.4 | 0.2 | +2.8 | 7.6 | 3.5 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +11.4 | 0.0 | 5.4 | 0.9 | +40.5 | 0.0 | 21.8 |
| RESTRAINS TO SHOOT | 0.2 | +8.2 | 0.0 | 5.8 | 0.1 | +3.3 | 0.0 | 8.2 |
| RISK BY ARC | 2.9 | +100.4 | 215.7 | 91.2 | 2.8 | +73.4 | 215.0 | 103.9 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.7 | 5.8 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +64.5 | 0.0 | 32.8 | 0.8 | +31.5 | 0.0 | 19.1 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -6.9 | 0.0 | 1.2 | 0.2 | -5.6 | 0.0 | 1.7 |
| SEARCH SPOT | 2.6 | +116.7 | 0.0 | 43.9 | 2.8 | +142.1 | 0.0 | 29.3 |
| SELF MOVE SPELL | 0.2 | +30.1 | 0.0 | 18.1 | 0.2 | +1.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.8 | +93.0 | 0.0 | 16.4 | 2.4 | +228.7 | 12.9 | 76.7 |
| SET-UP ANY TARGET | 0.3 | +25.5 | 0.0 | 0.0 | 0.1 | +13.2 | 11.1 | 18.7 |
| SET-UP MISSED | 0.1 | +8.2 | 0.0 | 0.0 | 0.0 | +4.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +37.7 | 45.7 | 18.1 | 0.9 | +43.9 | 57.2 | 16.5 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.8 | +0.0 | 111.8 | 6.7 | 0.1 | +0.0 | 26.8 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +549.2 | 0.0 | 190.5 | 8.7 | +195.4 | 0.0 | 191.7 |
| SPELL SETS UP CHARGE | 0.3 | +27.3 | 0.0 | 0.0 | 0.2 | +68.9 | 11.1 | 18.7 |
| SPELL WORTH | 1.2 | +17.0 | 101.1 | 84.6 | 1.6 | +48.7 | 101.9 | 98.9 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.6 | -11.7 | 50.1 | 39.8 |
| STABLE ROLE | 12.1 | +0.0 | 412.2 | 187.9 | 11.0 | +0.0 | 244.1 | 191.2 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +1.3 | 3.2 | 0.0 |
| STAY WEIGHED | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.2 | 5.3 | 0.0 | 0.1 | +2.2 | 6.5 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +29.6 | 0.0 | 17.9 | 0.4 | +28.8 | 0.0 | 17.7 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.9 | -33.6 | 270.8 | 112.0 | 7.1 | -53.5 | 289.1 | 133.2 |
| SUPPORTS | 2.8 | +38.1 | 91.3 | 51.8 | 4.8 | +54.7 | 140.6 | 90.6 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.5 | 2.0 | 0.0 | 0.1 | -2.9 | 7.6 | 13.9 |
| SURE REACH TOGETHER | 0.7 | +2.5 | 1.9 | 21.6 | 0.6 | +2.4 | 5.1 | 19.7 |
| THROUGH LINE OF FIRE | 0.4 | +20.0 | 0.0 | 5.9 | 0.3 | +16.8 | 0.0 | 20.6 |
| TURN WORTH | 0.5 | -30.8 | 35.9 | 5.5 | 0.1 | -5.2 | 16.5 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.9 | 0.0 | 2.9 | 0.7 | +9.0 | 6.5 | 20.1 |
| WAIT AFTER COSTS | 6.8 | -312.1 | 238.5 | 139.1 | 8.7 | -462.4 | 209.8 | 198.0 |
| WALKS TO THE FIGHT | 2.1 | +53.1 | 44.5 | 21.6 | 1.2 | +23.3 | 18.1 | 12.1 |
| WAR ENGINE CHARGES | 0.1 | +6.1 | 0.0 | 1.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 22.2 | 12.8 | 0.4 | +0.0 | 0.0 | 7.2 |
| WEARS DOWN | 1.2 | +65.6 | 97.6 | 45.9 | 1.6 | +43.1 | 84.7 | 58.5 |
| WHO HITS BACK | 0.1 | +22.9 | 0.0 | 0.0 | 0.2 | +30.1 | 0.0 | 13.3 |
| WHOLE FIGHT | 0.5 | +30.0 | 52.6 | 1.8 | 0.5 | +23.6 | 71.6 | 31.4 |
| WHOLE FIGHT GAIN | 0.4 | +34.4 | 41.5 | 7.0 | 0.6 | +37.6 | 58.2 | 12.9 |
| WIDER SPREAD | - | - | - | - | 3.0 | -7.0 | 205.5 | 107.1 |

### Rule changes: cw-h2h-opp-3cc170f-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1108 | 1108 | 1108 | 30.78 | -57939 | -52.3 |
| BEST FIRST | 294 | 294 | 294 | 8.17 | +13021 | +44.3 |
| SEARCH SPOT | 195 | 195 | 194 | 5.39 | +9355 | +48.2 |
| COUNTER-CHARGE COVER | 594 | 327 | 165 | 4.58 | +10558 | +64.0 |
| PATHS CROSS | 165 | 165 | 165 | 4.58 | +11821 | +71.6 |
| MOVE TO CHARGE | 272 | 272 | 147 | 4.08 | +8903 | +60.6 |
| FACES THE THREAT | 115 | 115 | 115 | 3.19 | +9935 | +86.4 |
| KILLS COUNT NEXT TURN | 411 | 411 | 114 | 3.17 | +3913 | +34.3 |
| FALLBACK BY WORTH | 383 | 383 | 93 | 2.58 | +5078 | +54.6 |
| SUPPORTS | 274 | 274 | 88 | 2.44 | +925 | +10.5 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +13021 | +169.1 |
| WAIT AFTER COSTS | 558 | 558 | 73 | 2.03 | +1204 | +16.5 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +3458 | +51.6 |
| SHOTS IN THE MOVE | 841 | 567 | 66 | 1.83 | +1789 | +27.1 |
| WALKS TO THE FIGHT | 117 | 117 | 65 | 1.81 | +1166 | +17.9 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| BEST FACING | 55 | 55 | 55 | 1.53 | +3217 | +58.5 |
| BEST OVERALL | 52 | 52 | 52 | 1.44 | +4233 | +81.4 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| REDIRECT COUNTER | 227 | 130 | 51 | 1.42 | +4559 | +89.4 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1869 | +38.1 |
| SET UP TOGETHER | 117 | 97 | 49 | 1.36 | +5374 | +109.7 |
| MAX FOR POSITIONING | 358 | 201 | 48 | 1.33 | +766 | +16.0 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| MARCH CHECK | 46 | 46 | 46 | 1.28 | +3323 | +72.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 44 | 1.22 | +1141 | +25.9 |
| SHOOTS FROM THE BEST SPOT | 74 | 74 | 41 | 1.14 | +1552 | +37.8 |
| CANNON PLANNED TARGET | 220 | 220 | 40 | 1.11 | -89 | -2.2 |
| RISK BY ARC | 203 | 196 | 39 | 1.08 | +1236 | +31.7 |
| STOPS SHORT OF THE FLANK | 37 | 37 | 37 | 1.03 | +2104 | +56.9 |
| INVITES THE FIGHT | 129 | 129 | 35 | 0.97 | +536 | +15.3 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| MISSILES IN THE MOVE | 301 | 169 | 34 | 0.94 | +844 | +24.8 |
| CHARGE NOW FIRST | 191 | 191 | 33 | 0.92 | -2236 | -67.7 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +2845 | +86.2 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +1328 | +49.2 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| KEEPS ITS TARGET | 125 | 124 | 24 | 0.67 | +386 | +16.1 |
| KILLS COUNT | 127 | 123 | 24 | 0.67 | +708 | +29.5 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| CAST JOB | 34 | 34 | 22 | 0.61 | +720 | +32.7 |
| FRIENDS SHOTS CHECKED | 20 | 20 | 20 | 0.56 | +1429 | +71.5 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +1585 | +79.3 |
| BLOCKED WHEEL | 19 | 19 | 19 | 0.53 | +527 | +27.7 |
| WAR ENGINE JOBS | 37 | 37 | 19 | 0.53 | -2272 | -119.6 |
| BIG CHARACTER SAFETY | 18 | 18 | 18 | 0.50 | -30 | -1.6 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +610 | +35.9 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +526 | +30.9 |
| WEARS DOWN | 99 | 97 | 16 | 0.44 | +687 | +42.9 |
| HONEST WORTH | 353 | 350 | 15 | 0.42 | +148 | +9.9 |
| MAKE SURE TOGETHER | 54 | 34 | 15 | 0.42 | +651 | +43.4 |
| MARCH ODDS | 15 | 15 | 15 | 0.42 | -47 | -3.1 |
| BEST PREY | 66 | 66 | 14 | 0.39 | +454 | +32.4 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HUNT IN PAIRS | 38 | 27 | 14 | 0.39 | +684 | +48.8 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -26 | -2.0 |
| RESTRAINS TO SHOOT | 13 | 13 | 13 | 0.36 | +415 | +32.0 |
| CASTING BLOCK | 18 | 18 | 12 | 0.33 | +462 | +38.5 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +1248 | +104.0 |
| WHOLE FIGHT | 37 | 36 | 11 | 0.31 | +513 | +46.6 |
| WHOLE FIGHT GAIN | 36 | 32 | 11 | 0.31 | +489 | +44.4 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2960 | +370.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -159 | -19.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| CHARGE BAND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| LOST CHARGE | 216 | 216 | 7 | 0.19 | +109 | +15.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| MISSILES NEXT TURN | 334 | 187 | 6 | 0.17 | +22 | +3.6 |
| OPENS UP | 14 | 14 | 6 | 0.17 | +232 | +38.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -76 | -15.2 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| OVERRUNS AWAY | 43 | 41 | 5 | 0.14 | +100 | +19.9 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -122 | -24.3 |
| BACKUP TARGETS | 63 | 25 | 4 | 0.11 | +26 | +6.5 |
| JOINT CHARGE PLAN | 12 | 12 | 4 | 0.11 | +196 | +49.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -99 | -24.7 |
| SURE REACH TOGETHER | 48 | 37 | 4 | 0.11 | +34 | +8.5 |
| HUNT ADVANCE | 6 | 6 | 3 | 0.08 | +158 | +52.8 |
| REFUSING RETIRES | 9 | 9 | 3 | 0.08 | -0 | -0.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -50 | -24.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +115 | +57.6 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +9 | +4.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +132 | +65.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 29 | 28 | 2 | 0.06 | +52 | +25.8 |
| MOVE SPELL IN RANGE | 4 | 2 | 2 | 0.06 | +6 | +3.2 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +3 | +1.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +180 | +90.2 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +16 | +7.8 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +25 | +12.3 |
| SUPPORT NARROWED | 432 | 432 | 2 | 0.06 | -34 | -17.2 |
| WIDER SPREAD | 108 | 101 | 2 | 0.06 | +6 | +2.8 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -44 | -43.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -246 | -245.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +106 | +106.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +37 | +36.9 |
| KEEPS ITS PREY | 2 | 2 | 1 | 0.03 | +6 | +6.5 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 9 | 8 | 1 | 0.03 | +19 | +18.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +174 | +173.8 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +2 | +2.0 |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 1 | 0.03 | +18 | +17.7 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -111 | -111.1 |
| STOPS | 4 | 4 | 1 | 0.03 | +15 | +15.0 |
| TWO OR MORE ARRIVE | 31 | 27 | 1 | 0.03 | +6 | +5.7 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +130 | +129.5 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 21 | 19 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 9 | 9 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 396 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 15 | 15 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 386 | 386 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 47 | not checked | - | - | - | - |
| PLAN RESULT | 2719 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 103 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 23 | 20 | 0 | 0.00 | - | - |
| STABLE ROLE | 833 | 831 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 21 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-opp-3cc170f-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.47 | 14.28 | 53.2 |
| FALLBACK | gate | 0.56 | 0.64 | 37.1 |
| CHARGE NOW FIRST | rule | 0.53 | 0.39 | 67.7 |
| TURN GATE | gate | 0.47 | 0.44 | 38.6 |
| WAR ENGINE JOBS | rule | 0.36 | 0.17 | 119.6 |
| PATHS CROSS | rule | 0.19 | 0.11 | 41.5 |
| SUPPORT REQUEST | gate | 0.14 | 0.14 | 83.6 |
| BIG CHARACTER SAFETY | rule | 0.19 | 0.06 | 8.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.17 | 66.4 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.17 | 19.9 |
| CHAFF PASSED | rule | - | 0.19 | 3.7 |
| AFTERMATH BAND | gate | 0.03 | 0.11 | 2.9 |
| BEST PRIZE | rule | 0.08 | 0.06 | 15.2 |
| NO REASON | gate | - | 0.14 | 22.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.11 | 24.3 |
| CANNON PLANNED TARGET | rule | 0.08 | 0.03 | 75.2 |
| MARCH ODDS | rule | - | 0.11 | 64.3 |
| PURSUES BIG PREY | rule | 0.08 | 0.03 | 24.7 |
| SAFER THAN THE JOB | rule | 0.08 | 0.03 | 4.3 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 10.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 135.8 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 4.7 |
| THROUGH LINE OF FIRE | rule | - | 0.08 | 12.7 |
| CATCH ODDS | rule | - | 0.06 | 24.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 76.3 |
| FIGHT ORDER BAND | gate | 0.06 | - | 3.6 |
| REDIRECT WEIGHED | rule | 0.06 | - | 10.8 |
| SUPPORT NARROWED | rule | 0.03 | 0.03 | 17.2 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 43.5 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 245.5 |
| FACES THE THREAT | rule | 0.03 | - | 18.2 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 0.7 |
| SAFE SURE CHARGE | rule | - | 0.03 | 111.1 |

### Plans: cw-h2h-opp-3cc170f-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 22% | 532 | 361 | 68% |
| Mine | charge | 3.6 | 60% | 428 | 287 | 67% |
| Mine | close in | 3.9 | 28% | 252 | 126 | 50% |
| Mine | hold | 5.2 | 37% | 349 | 0 | 0% |
| Mine | join | 0.6 | 100% | 19 | 0 | 0% |
| Mine | shoot | 8.8 | 57% | 335 | 541 | 162% |
| Mine | support | 3.0 | 83% | 29 | 0 | 0% |
| Opponent | advance | 12.9 | 12% | 374 | 274 | 73% |
| Opponent | charge | 4.0 | 57% | 329 | 376 | 114% |
| Opponent | close in | 6.0 | 21% | 448 | 126 | 28% |
| Opponent | hold | 4.1 | 44% | 273 | 0 | 0% |
| Opponent | join | 1.1 | 95% | 57 | 0 | 0% |
| Opponent | shoot | 4.6 | 63% | 122 | 304 | 250% |
| Opponent | support | 5.4 | 90% | 37 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-opp-3cc170f-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 100% | 100% | 0% | 3.0 | 206 | 200 | 100% | 34 |
| Opponent | 0.2 | 7 | 0 | 14% | 14% | 0% | 2.0 | 394 | 35 | 14% | 96 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 193 |
| Dwarfen Mountain Holds | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 103 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 85 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 206 | 200 | 100% | 133 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 104 | 0 | 0% | 195 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 569 | 0 | 0% | 22 |
| Warriors of Chaos | 0.5 | 4 | 0 | 25% | 25% | 0% | 2.0 | 439 | 62 | 25% | 23 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 112 |

### Battle groups: cw-h2h-opp-3cc170f-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.3 | 23% | 55% | 7% | 40% | 30% | 15% | 7% | 48% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 38% | 62% | 4% | 100% | 12% | 4% | 12% | 68% | 4% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 22% | 70% | 18% | 10% | 41% | 7% | 20% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 24% | 84% | 21% | 12% | 13% | 3% | 17% | 60% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-opp-3cc170f-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 19 | 33% | 5.5 | 0 (1) | 49 (2) | - | 73 (1) | 0 (2) |
| Mine | Chaff | 36 | 40 (36) | 21 | 19 | 53 | 36% | 2.2 | 23 (15) | 53 (9) | 47 (12) | 43 (23) | 35 (13) |
| Mine | Character | 123 | 54 (123) | 54 | 0 | 36 | 19% | 2.5 | 55 (35) | 66 (62) | 7 (10) | 63 (62) | 52 (45) |
| Mine | Clean-up | 24 | 71 (24) | 26 | 46 | 24 | 38% | 3.6 | 85 (9) | 72 (11) | 0 (4) | 139 (13) | 6 (11) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 47 | 0% | 1.5 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 42 | 31 (42) | 20 | 11 | 49 | 40% | 2.3 | 37 (19) | 40 (12) | 14 (11) | 42 (29) | 11 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 0% | 1.4 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 57 | 48 (57) | 30 | 18 | 34 | 14% | 2.6 | 65 (10) | 44 (37) | 50 (10) | 60 (34) | 35 (23) |
| Mine | Holder | 26 | 94 (26) | 6 | 88 | 25 | 31% | 4.1 | 112 (8) | 76 (16) | 168 (2) | 84 (12) | 102 (14) |
| Mine | Shooter | 44 | 109 (44) | 44 | 65 | 39 | 5% | 1.7 | 0 (5) | 158 (31) | 36 (7) | 135 (24) | 85 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 20% | 2.8 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |
| Mine | War machine | 56 | 52 (56) | 52 | 0 | 22 | 7% | 1.2 | 54 (13) | 57 (37) | 19 (6) | 23 (11) | 60 (45) |
| Mine | Wizard | 23 | 35 (23) | 35 | 0 | 37 | 9% | 2.6 | 24 (4) | 75 (11) | 0 (2) | 125 (3) | 23 (14) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 51 (68) | 17 | 34 | 44 | 40% | 2.9 | 100 (29) | 10 (17) | 24 (22) | 64 (50) | 11 (18) |
| Opponent | Character | 113 | 41 (113) | 41 | 0 | 35 | 23% | 2.8 | 60 (37) | 36 (52) | 20 (7) | 42 (61) | 51 (35) |
| Opponent | Clean-up | 17 | 35 (17) | 23 | 12 | 47 | 41% | 3.1 | 0 (5) | 58 (9) | 37 (3) | 53 (9) | 18 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 53 | 54 (53) | 35 | 19 | 54 | 38% | 2.7 | 65 (22) | 47 (17) | 41 (14) | 57 (38) | 47 (15) |
| Opponent | Fragile | 10 | 40 (10) | 40 | 0 | 83 | 20% | 1.9 | 224 (1) | 48 (4) | 0 (3) | 31 (6) | 117 (2) |
| Opponent | Hammer | 64 | 33 (64) | 26 | 8 | 45 | 25% | 2.3 | 13 (16) | 42 (41) | 16 (7) | 36 (39) | 29 (25) |
| Opponent | Holder | 40 | 56 (40) | 4 | 52 | 31 | 50% | 3.5 | 17 (9) | 83 (19) | 40 (11) | 97 (22) | 12 (17) |
| Opponent | Shooter | 32 | 44 (32) | 8 | 36 | 64 | 0% | 1.3 | 22 (8) | 50 (19) | 51 (5) | 48 (17) | 39 (15) |
| Opponent | Support | 2 | 85 (2) | 85 | 0 | 50 | 0% | 5.0 | 0 (1) | 170 (1) | - | - | 85 (2) |
| Opponent | War machine | 13 | 84 (13) | 84 | 0 | 42 | 15% | 1.1 | 117 (5) | 36 (5) | 118 (3) | 38 (3) | 97 (10) |
| Opponent | Wizard | 24 | 10 (24) | 10 | 0 | 34 | 12% | 1.7 | 5 (12) | 24 (7) | 0 (2) | 18 (11) | 0 (10) |

### Charged fights: cw-h2h-opp-3cc170f-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 161 | 90 | 1.6 | 1.0 | 56 | 0 | +56 | 1 of 8 | 7 of 8 | - | +56 |
| Mine | Chaos Dwarfs | 3 | 215 | 1026 | 4.3 | 1.2 | 237 | 0 | +237 | 8 of 13 | 9 of 13 | +144 | +254 |
| Mine | Dwarfen Mountain Holds | 4 | 362 | 130 | 2.2 | 1.3 | 58 | 48 | +10 | 5 of 9 | 7 of 9 | +54 | -12 |
| Mine | Empire of Man | 5 | 551 | 153 | 1.8 | 1.3 | 85 | 85 | +1 | 3 of 9 | 4 of 8 | +70 | -34 |
| Mine | Grand Cathay | 4 | 468 | 437 | 4.5 | 1.0 | 97 | 33 | +64 | 13 of 18 | 7 of 18 | - | +64 |
| Mine | High Elf Realms | 4 | 139 | 516 | 4.0 | 1.1 | 129 | 10 | +119 | 7 of 16 | 14 of 16 | +708 | +80 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 329 | 4.0 | 1.0 | 82 | 0 | +82 | 2 of 4 | 4 of 4 | - | +82 |
| Mine | Lizardmen | 1 | 70 | 120 | 3.0 | 1.0 | 40 | 237 | -197 | 1 of 3 | 1 of 3 | - | -197 |
| Mine | Ogre Kingdoms | 1 | 70 | 132 | 3.0 | 1.0 | 44 | 0 | +44 | 0 of 3 | 3 of 3 | - | +44 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 626 | 6.0 | 1.2 | 104 | 73 | +32 | 3 of 6 | 5 of 6 | +265 | -15 |
| Mine | Skaven | 2 | 93 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 120 | 515 | 5.0 | 1.2 | 103 | 94 | +9 | 3 of 10 | 7 of 10 | +62 | -5 |
| Mine | Vampire Counts | 2 | 0 | 976 | 5.5 | 1.2 | 178 | 42 | +135 | 2 of 11 | 9 of 11 | +304 | +98 |
| Mine | Warriors of Chaos | 1 | 0 | 475 | 5.0 | 1.0 | 95 | 6 | +89 | 1 of 5 | 5 of 5 | - | +89 |
| **Mine** | all armies | 36 | 240 | 369 | 3.2 | 1.1 | 116 | 39 | +76 | 49 of 115 | 82 of 114 | +169 | +63 |
| Opponent | Beastmen Brayherds | 1 | 0 | 65 | 3.0 | 1.3 | 22 | 102 | -81 | 1 of 3 | 1 of 3 | -255 | +6 |
| Opponent | Dwarfen Mountain Holds | 1 | 580 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 160 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 588 | 233 | 3.0 | 2.0 | 78 | 0 | +78 | 3 of 3 | 1 of 3 | +116 | +0 |
| Opponent | High Elf Realms | 2 | 177 | 184 | 2.5 | 1.0 | 74 | 0 | +74 | 3 of 5 | 3 of 5 | - | +74 |
| Opponent | Lizardmen | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 62 | -62 | 2 of 3 | 2 of 3 | - | -62 |
| Opponent | Ogre Kingdoms | 2 | 52 | 164 | 2.0 | 1.5 | 82 | 132 | -50 | 1 of 4 | 4 of 4 | -184 | +84 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 400 | 5.0 | 1.0 | 80 | 22 | +58 | 6 of 10 | 6 of 10 | - | +58 |
| Opponent | Skaven | 2 | 158 | 184 | 0.5 | 2.0 | 369 | 210 | +159 | 1 of 1 | 1 of 1 | +159 | - |
| Opponent | Tomb Kings of Khemri | 4 | 28 | 738 | 4.2 | 1.3 | 174 | 34 | +140 | 7 of 17 | 14 of 17 | +289 | +94 |
| Opponent | Vampire Counts | 6 | 79 | 550 | 5.7 | 1.1 | 97 | 18 | +79 | 14 of 34 | 24 of 34 | +139 | +69 |
| Opponent | Warriors of Chaos | 7 | 0 | 229 | 1.9 | 1.0 | 123 | 0 | +123 | 4 of 13 | 9 of 13 | - | +123 |
| Opponent | Wood Elf Realms | 6 | 54 | 247 | 2.7 | 1.2 | 93 | 14 | +78 | 4 of 16 | 12 of 16 | +64 | +82 |
| **Opponent** | all armies | 36 | 84 | 320 | 3.1 | 1.2 | 104 | 26 | +78 | 48 of 111 | 78 of 111 | +100 | +73 |

### Effective charges: cw-h2h-opp-3cc170f-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 0 | 0 | 0 | 2 (net +79) | 0 | 1 (net +0) | 5 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 13 | 1 (net +0) | 0 | 2 (net +272) | 0 | 2 (net +190) | 8 (net +269) | 0 | 15% (2 of 13) |
| Mine | Dwarfen Mountain Holds | 9 | 2 (net +81) | 0 | 1 (net +0) | 1 (net +111) | 0 | 5 (net -37) | 0 | 11% (1 of 9) |
| Mine | Empire of Man | 9 | 1 (net -176) | 1 (net -281) | 1 (net +83) | 1 (net -110) | 1 (net +83) | 4 (net +102) | 0 | 11% (1 of 9) |
| Mine | Grand Cathay | 18 | 3 (net +121) | 0 | 7 (net +28) | 3 (net +115) | 2 (net +60) | 2 (net +88) | 1 | 41% (7 of 17) |
| Mine | High Elf Realms | 16 | 1 (net -162) | 0 | 4 (net +126) | 1 (net +0) | 1 (net +0) | 7 (net +178) | 2 | 29% (4 of 14) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +110) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +120) | 1 (net -571) | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 1 (net +66) | 0 | 1 (net +66) | 0 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +265) | 0 | 0 | 1 (net +235) | 4 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 2 (net +13) | 2 (net -164) | 2 (net +62) | 2 (net +70) | 2 | 25% (2 of 8) |
| Mine | Vampire Counts | 11 | 2 (net +202) | 1 (net +170) | 0 | 1 (net +0) | 2 (net +130) | 5 (net +131) | 0 | 0% (0 of 11) |
| Mine | Warriors of Chaos | 5 | 1 (net -30) | 0 | 0 | 1 (net +115) | 1 (net +109) | 1 (net +160) | 1 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 2 (net +6) | 1 (net -255) | 0 | 0 | 0 | 67% (2 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 2 (net +0) | 1 (net +233) | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 5 | 0 | 1 (net +369) | 0 | 2 (net +0) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 1 (net -185) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -399) | 0 | 0 | 2 (net +84) | 1 | 33% (1 of 3) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 0 | 2 (net +157) | 1 (net +0) | 0 | 2 (net +174) | 5 | 40% (2 of 5) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +159) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 17 | 0 | 2 (net +244) | 5 (net +32) | 2 (net +88) | 1 (net +332) | 6 (net +162) | 1 | 31% (5 of 16) |
| Opponent | Vampire Counts | 34 | 8 (net -6) | 2 (net +65) | 7 (net +110) | 7 (net +43) | 3 (net +92) | 6 (net +200) | 1 | 21% (7 of 33) |
| Opponent | Warriors of Chaos | 13 | 2 (net +224) | 0 | 1 (net +267) | 2 (net +111) | 0 | 7 (net +75) | 1 | 8% (1 of 12) |
| Opponent | Wood Elf Realms | 16 | 4 (net -12) | 0 | 2 (net +61) | 4 (net +134) | 1 (net +84) | 4 (net +109) | 1 | 13% (2 of 15) |

### Charged fights, damage counted: cw-h2h-opp-3cc170f-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 261 | 228 | +51 | 182 | 115 | +67 | +25.8 |
| Mine | 50-54% | 2 | 218 | 172 | -56 | 85 | 140 | -56 | -25.5 |
| Mine | Effective (55-75%) | 20 | 256 | 241 | +81 | 109 | 43 | +66 | +25.8 |
| Mine | 76-89% | 14 | 221 | 205 | +34 | 86 | 52 | +34 | +15.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 | 265 | 189 | +134 | 178 | 22 | +156 | +58.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 465 | 111 | +42 | 101 | 56 | +44 | +9.5 |
| Mine | No odds | 16 | 371 | 156 | +20 | 81 | 70 | +10 | +2.7 |
| Mine | All fights | 115 | 293 | 191 | +76 | 132 | 50 | +81 | +27.8 |
| Opponent | Long shot (under 50%) | 15 | 165 | 278 | +23 | 70 | 47 | +23 | +14.0 |
| Opponent | 50-54% | 5 | 292 | 262 | +197 | 197 | 39 | +158 | +54.2 |
| Opponent | Effective (55-75%) | 21 | 240 | 218 | +59 | 122 | 77 | +45 | +18.7 |
| Opponent | 76-89% | 24 | 239 | 190 | +40 | 119 | 59 | +60 | +25.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 287 | 193 | +126 | 137 | 18 | +118 | +41.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 546 | 124 | +154 | 170 | 8 | +162 | +29.7 |
| Opponent | No odds | 11 | 112 | 171 | +48 | 81 | 25 | +57 | +50.8 |
| Opponent | All fights | 111 | 248 | 206 | +78 | 120 | 43 | +77 | +31.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-opp-3cc170f-p1 | move | 471 | 116 (25%) | 86 (18%) | 62 (13%) | 293 (62%) |
| cw-h2h-opp-3cc170f-p1 | objective | 360 | 55 (15%) | 43 (12%) | 55 (15%) | 250 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

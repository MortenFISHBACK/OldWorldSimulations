# Doctrine scorecard: cw-h2h-opp-3cc170f-p4

### Scorecard: cw-h2h-opp-3cc170f-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 7 | 1 | 8 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 1 | 3 | 2 | 3 | 0 | 0 | 0 | 222 |
| L0214 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 6 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 184 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 686 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 6 | 1 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 1 | - | 2 | 2 | 0 | 0 | 0 | 893 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 2 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 2 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 0 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 492 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 5 | 0 | 2 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 98 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 1 | 0 | 0 | 583 |
| L1126 | 4 | 1 | Mine | no | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 5 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 0 | 4 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | yes | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 795 |
| L1719 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 647 |
| L1819 | 1 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 0 | 5 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | no | - | - | 1 | 4 | 0 | 0 | 0 | 345 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 6 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 3 | 3 | 0 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 7 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 36% | 1.6 | 2.7 | 2.8 | 1.2 | 0.3 | 0.0 | 0.0 | 266.0 |
| **Average** | | | Opponent | 39% | 2.5 | 2.4 | 2.6 | 2.1 | 0.5 | 0.0 | 0.0 | 123.6 |

### KPIs: cw-h2h-opp-3cc170f-p4

Rules off - Mine only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (44 of 169) | 1% (1 of 177) | 13% (45 of 346) |
| Winner chose to follow up after the loser gave ground |  | 100% (63 of 63); on the table 100% | 98% (47 of 48); on the table 98% | 99% (110 of 111); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 81% (13 of 16); on the table 94% | 93% (13 of 14); on the table 93% | 87% (26 of 30); on the table 93% |
| Winner chose to pursue after the loser fled |  | 78% (25 of 32); on the table 84% | 89% (25 of 28); on the table 89% | 83% (50 of 60); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 91% (101 of 111); on the table 95% | 94% (85 of 90); on the table 94% | 93% (186 of 201); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 33% (87 of 266) | 40% (69 of 174) | 35% (156 of 440) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (87 of 180) | 52% (69 of 133) | 50% (156 of 313) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (26 of 44) | 55% (43 of 78) | 57% (69 of 122) |
| Points that never fought | lower | 36% (24440 of 67942) | 37% (26906 of 71984) | 37% (51346 of 139926) |
|   infantry points that never fought | lower | 49% (7457 of 15347) | 56% (7773 of 13804) | 52% (15230 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (161 of 270) | 55% (154 of 280) | 57% (315 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.5 uses a game | 89% (8 of 9); 0.7 uses a game | 90% (28 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.2 uses a game | 30% (6 of 20); 0.3 uses a game | 33% (12 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 74% (14 of 19); 0.4 uses a game | 67% (10 of 15); 0.3 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (31347 of 57750) | 49% (31320 of 63347) | 52% (62667 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (23%) | 0.8 (29%) | 2.0 (25%) |
| MARCHED: its unit marched | 1.3 (26%) | 0.4 (15%) | 1.7 (22%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (8%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.4 (28%) | 0.5 (18%) | 1.9 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.7 (15%) | 0.5 (16%) | 1.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (4%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.3 | 1.9 | 4.3 | 0.4 | 2.2 |
| not cast | 2.8 | 2.5 | 2.9 | 7.9 | 1.6 | 20.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (44%) | 0.2 (8%) | 2.0 (25%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (22%) | 0.4 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.4 (17%) | 0.7 (25%) | 1.9 (24%) | 0.4 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.1 (4%) | 0.2 (8%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.4 (2%) |
| GONE: slain | 0.6 (21%) | 0.5 (20%) | 0.5 (17%) | 1.2 (15%) | 0.1 (7%) | 2.5 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.1 (3%) | 0.0 (1%) | 0.2 (3%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) | 0.1 (1%) | 0.2 (15%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (59%) | 0.0 (1%) | 1.2 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.6 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 66% (27 of 41) | 46% (6 of 13) | 61% (33 of 54) |
| the unit moved after it | 74% (20 of 27) | 83% (5 of 6) | 76% (25 of 33) |
| it charged on its next turn | 15% (4 of 27) | 0% (0 of 6) | 12% (4 of 33) |
| the enemy charged it first | 22% (6 of 27) | 33% (2 of 6) | 24% (8 of 33) |
| it fought by the end of its next turn | 11% (3 of 27) | 33% (2 of 6) | 15% (5 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (3 of 27) | 17% (1 of 6) | 12% (4 of 33) |
| none of these (no charge, no fight, no charge escaped) | 52% (14 of 27) | 50% (3 of 6) | 52% (17 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (605 of 922) | 56% (294 of 529) | 62% (899 of 1451) |
|   cavalry | 54% (46 of 85) | 71% (77 of 108) | 64% (123 of 193) |
|   character | 44% (49 of 111) | 18% (21 of 118) | 31% (70 of 229) |
|   chariot | 50% (54 of 107) | 58% (15 of 26) | 52% (69 of 133) |
|   infantry | 66% (183 of 277) | 67% (152 of 228) | 66% (335 of 505) |
|   monster | 44% (21 of 48) | 37% (11 of 30) | 41% (32 of 78) |
|   war machine | 86% (252 of 294) | 95% (18 of 19) | 86% (270 of 313) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 1.6 (24%) | 3.9 (25%) |
| CHARGED: it charged | 1.3 (15%) | 1.7 (26%) | 3.0 (19%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.5 (7%) | 1.5 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.5 (17%) | 1.0 (15%) | 2.5 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.3 (4%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 1.4 (21%) | 2.7 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.3 | 80% | 3.7 pts | 21 pts |
| character | 2.2 | 0.8 | 77% | 9.8 pts | 21 pts |
| chariot | 2.0 | 1.4 | 70% | 16.9 pts | 33 pts |
| infantry | 13.7 | 5.2 | 73% | 9.6 pts | 131 pts |
| monster | 0.9 | 0.1 | 88% | 3.1 pts | 3 pts |
| war machine | 7.5 | 6.9 | 63% | 30.9 pts | 231 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 6.1 | 5.3 |
| Charges that made contact a game | 3.5 | 4.1 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.06 declared, 1.00 contact (17 units) | 0.67 declared, 0.47 contact (15 units) | 0.88 declared, 0.75 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.88 declared, 0.50 contact (8 units) | 1.17 declared, 0.92 contact (12 units) | 1.05 declared, 0.75 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.42 contact (251 units) | 0.67 declared, 0.45 contact (291 units) | 0.61 declared, 0.43 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (48 of 81) | 62% (10 of 16) | 33% (2 of 6) | 58% (60 of 103) |
| Character in a unit | 90% (28 of 31) | 77% (10 of 13) | 100% (1 of 1) | 87% (39 of 45) |
| Character on its own | 71% (24 of 34) | 48% (14 of 29) | 35% (27 of 77) | 46% (65 of 140) |
| Chariot | 67% (10 of 15) | 58% (7 of 12) | - | 63% (17 of 27) |
| Infantry | 49% (41 of 83) | 44% (11 of 25) | 33% (2 of 6) | 47% (54 of 114) |
| Monster | 71% (24 of 34) | 43% (6 of 14) | - | 62% (30 of 48) |
| Monstrous | 86% (12 of 14) | 57% (8 of 14) | - | 71% (20 of 28) |
| War Machines | 67% (29 of 43) | 50% (1 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 85% (11 of 13); on the table 85% | 38% (39 of 102) | 27% | 59% (13 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (21 of 21); on the table 100% | 42% (10 of 24) | 20% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (6 of 6); on the table 100% | - | 71% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 64% (7 of 11); on the table 73% | 56% (10 of 18) | 60% | 68% (42 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 89% (8 of 9); on the table 89% | 30% (25 of 84) | 36% | 46% (17 of 37) | 100% (9 of 9); 6.8 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 9 | 100% (28 of 28); on the table 100% | 17% (6 of 35) | 43% | 51% (36 of 70) | 100% (7 of 7); 2.6 uses a game | 27% (8 of 30); 1.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 19% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 91% (10 of 11); on the table 100% | 83% (5 of 6) | 26% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 78% (7 of 9); on the table 89% | 0% (0 of 6) | 21% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 91% (10 of 11); on the table 91% | 43% (18 of 42) | 31% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 100% (5 of 5); on the table 100% | 32% (13 of 40) | 43% | 62% (28 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 91% (10 of 11); on the table 100% | 0% (0 of 6) | 19% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (25 of 26); on the table 96% | 41% (24 of 59) | 32% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 96% (26 of 27); on the table 96% | 25% (3 of 12) | 30% | 58% (42 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 92% (11 of 12); on the table 92% | 50% (3 of 6) | 44% | 64% (36 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-opp-3cc170f-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (44) | 52% (42) | 54% (86) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.75 | 1.42 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.22 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.39 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 1.33 | 2.92 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.03 | 0.89 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.33 | 5.97 | 11.31 |

### Quality by phase: cw-h2h-opp-3cc170f-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 50% (83 of 167) | 37% (72 of 193) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (183 of 375) | 41% (67 of 164) |
| Strategy | Close-in objectives charged next turn | 11% (17 of 157) | 13% (26 of 207) |
| Strategy | Support requests answered (helper made contact too) | 53% (9 of 17) | 42% (17 of 40) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (5 of 11) | 33% (2 of 6) |
| Strategy | Joined characters whose unit fought | 41% (15 of 37) | 35% (11 of 31) |
| Strategy | Lone characters that fought | 74% (64 of 86) | 75% (64 of 85) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 2.1 |
| Movement | Points that never moved of their own | 266.0 | 123.6 |
| Movement | Fights charged into per game | 3.2 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 111, net +66 | 15 of 105, net +31 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 111, net -86 | 30 of 105, net +90 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 111, net +143 | 7 of 105, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 111, net +39 | 28 of 105, net +73 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (163 of 387) | 46% (152 of 329) |
| Shooting | Points destroyed by shooting units | 125.1 | 42.0 |
| Shooting | War machine shots | 7.0 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (130 of 252) | 6% (1 of 18) |
| Shooting | Points destroyed by war machines | 76.9 | 19.4 |
| Magic | Magic missiles cast | 1.5 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (20 of 53) | 20% (9 of 45) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.7 |
| Magic | Wounds caused by other spells | 1.2 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 72.8 | 27.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 0.7 / 0.2 | 1.9 / 0.3 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 382.6 | 404.0 |
| Combat | Points run down | 65.2 | 116.4 |
| Combat | Net points per charged fight, damage counted | +52 | +88 |
| Combat | Net per 100 charger points, damage counted | +19.1 | +27.4 |
| Combat | First round won (charged fights) | 71% | 72% |
| Combat | Net points per charged fight | +53 | +81 |
| Combat | Net points per supported fight / lone fight | +65 / +52 | +91 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 117 | 60 of 114 |
| Game | Points lost | 760.2 | 761.0 |
| Game | VP from objectives | 530.6 | 532.2 |
| Game | Lone holders (player turns) | 1.6 | 2.5 |

- Mine won / drew / lost: 15 / 10 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) -19 VP
- The side that went first won 15 of 26 games with a winner
- Points traded per game (both sides' losses): 1521
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cw-h2h-opp-3cc170f-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 13.9 | 0.3 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.0 | +4.8 | 0.0 | 41.0 | 1.3 | +10.9 | 0.0 | 8.6 |
| BEST FACING | 0.4 | +22.6 | 0.0 | 37.4 | 0.6 | +30.7 | 0.0 | 22.2 |
| BEST FIRST | 3.5 | +144.8 | 157.9 | 77.8 | 3.8 | +136.0 | 104.6 | 76.8 |
| BEST OVERALL | 0.4 | +36.0 | 0.0 | 8.5 | 0.9 | +46.7 | 0.0 | 31.2 |
| BEST PREY | 0.9 | +63.0 | 61.3 | 17.3 | 1.2 | +39.3 | 20.0 | 27.9 |
| BEST PRIZE | - | - | - | - | 0.1 | -2.0 | 9.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.4 | 0.0 | 22.8 | 0.3 | +0.0 | 0.0 | 16.6 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | +3.5 | 0.0 | 5.2 | 0.6 | +10.7 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -51.7 | 9.9 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 13.1 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 121.4 | 22.2 | 0.1 | +0.0 | 4.6 | 3.5 |
| CANNON PLANNED TARGET | 5.3 | +206.6 | 559.4 | 79.4 | 0.5 | +25.4 | 25.1 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 3.2 | 5.1 | 0.1 | +0.0 | 11.6 | 0.0 |
| CAST JOB | 0.7 | +37.7 | 71.3 | 4.7 | 0.6 | +10.5 | 21.4 | 26.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +32.1 | 47.2 | 0.0 | 0.1 | +4.7 | 6.5 | 10.9 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 25.1 | 0.4 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.7 | 6.7 | 1.8 | 0.1 | -0.2 | 0.0 | 22.1 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.3 | 9.9 | 0.0 |
| CHARGE BAND | - | - | - | - | 0.1 | +0.0 | 0.0 | 16.4 |
| CHARGE NOW FIRST | 2.9 | +0.0 | 298.6 | 134.6 | 2.6 | +0.0 | 224.6 | 60.5 |
| CHARGE NOW WEIGHED | 0.4 | -39.3 | 3.8 | 24.9 | 0.6 | -57.4 | 16.5 | 20.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.8 | -31.1 | 107.6 | 37.8 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 4.7 | 0.0 | 0.2 | -0.5 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 7.2 | 3.0 | 0.1 | +0.0 | 12.3 | 5.8 |
| COMBAT PIVOT | 0.5 | +0.0 | 33.3 | 54.0 | 0.5 | +0.0 | 51.0 | 35.3 |
| CONVEYANCE SEARCH | 0.8 | +107.7 | 2.5 | 11.2 | 0.2 | +24.9 | 23.1 | 18.7 |
| COUNTER-CHARGE COVER | 8.7 | +595.8 | 0.0 | 225.5 | 7.8 | +700.5 | 0.0 | 202.4 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 105.2 | 3.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +2.3 | 7.9 | 1.4 | 0.1 | +6.8 | 19.7 | 3.2 |
| EDGE GIVE GROUND | 0.1 | +0.8 | 3.9 | 2.2 | 0.3 | +12.9 | 36.1 | 3.8 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +143.8 | 0.0 | 104.3 | 1.3 | +115.2 | 0.0 | 49.7 |
| FALLBACK BY WORTH | 5.1 | +72.6 | 0.0 | 89.5 | 6.3 | +44.7 | 0.0 | 87.5 |
| FIGHT LIFT | 0.1 | +2.3 | 21.9 | 9.9 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.3 | 0.0 | 4.6 | 0.0 | +0.3 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 180.0 | 5.6 | +0.0 | 0.0 | 138.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.5 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +197.4 | 0.0 | 55.0 | 1.0 | +170.9 | 0.0 | 46.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +17.8 | 0.0 | 0.0 | 0.1 | +9.5 | 0.0 | 9.6 |
| GIVES UP | 0.0 | -0.6 | 15.0 | 0.0 | 0.1 | -2.9 | 20.1 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.9 | 4.9 | 0.0 |
| GROUND FLIERS | 0.1 | +3.3 | 0.0 | 6.1 | 0.1 | +1.9 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 4.6 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 38.9 | 22.1 | 0.4 | +0.0 | 83.4 | 5.7 |
| HILL BY ITS CHANCE | 0.6 | -53.7 | 0.0 | 5.1 | 0.5 | -55.1 | 0.0 | 8.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 8.0 | -195.1 | 504.7 | 167.0 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +2.5 | 9.7 | 3.2 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 2.4 | 0.0 |
| HUNT IN PAIRS | 0.1 | +8.3 | 0.0 | 0.0 | 0.6 | +35.3 | 0.0 | 13.1 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.9 | 20.0 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +18.7 | 6.9 | 4.5 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +66.7 | 14.7 | 4.5 |
| INVITES THE FIGHT | 2.0 | +33.3 | 93.7 | 26.1 | 1.4 | +19.8 | 37.2 | 21.9 |
| JOINT CHARGE PLAN | 0.1 | +1.9 | 0.0 | 0.0 | 0.1 | +9.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.1 | 7.8 | 4.5 |
| KEEP FALLS | 0.2 | +2.4 | 0.0 | 6.6 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.9 | +56.7 | 158.0 | 76.4 | 1.9 | +56.7 | 172.9 | 17.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.1 | +64.7 | 170.2 | 61.5 | 1.8 | +105.4 | 170.4 | 44.7 |
| KILLS COUNT NEXT TURN | 5.8 | +182.5 | 205.2 | 167.6 | 7.0 | +229.6 | 249.9 | 199.6 |
| LONE CHARACTER SAFE SPOT | 0.3 | +8.1 | 0.0 | 2.5 | 0.1 | +4.2 | 2.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 3.7 | 18.4 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +1.3 | 56.9 | 0.0 | 0.6 | +2.6 | 51.5 | 6.1 |
| LOST CHARGE | 3.0 | -40.2 | 106.4 | 117.3 | 1.9 | -29.6 | 54.2 | 56.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -9.0 | 0.0 | 3.8 | 0.1 | -6.3 | 0.0 | 9.4 |
| MAKE SURE TOGETHER | 0.6 | +43.5 | 4.7 | 27.1 | 0.6 | +84.0 | 12.8 | 9.7 |
| MANOEUVRE | 0.2 | +4.0 | 0.0 | 3.2 | 0.2 | +6.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.8 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +27.0 | 0.0 | 2.2 | 0.3 | +6.1 | 0.0 | 16.2 |
| MARCH ODDS | 0.3 | +16.5 | 19.2 | 4.6 | 0.3 | +17.4 | 12.2 | 15.0 |
| MARCH OVER CASTS | 0.6 | +76.1 | 0.0 | 20.3 | 0.2 | +19.8 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 4.7 | +151.4 | 0.0 | 113.8 | 4.7 | +177.6 | 0.0 | 107.9 |
| MISSILES IN THE MOVE | 3.6 | +141.3 | 0.0 | 108.2 | 2.4 | +42.9 | 0.0 | 103.1 |
| MISSILES NEXT TURN | 4.7 | +96.5 | 0.0 | 147.1 | 3.0 | +28.3 | 0.0 | 107.1 |
| MODEL FACING | 0.2 | +60.6 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 22.0 | 0.0 | 0.1 | +0.0 | 5.2 | 0.0 |
| MOVE AND CAST | 0.4 | +10.3 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 23.0 |
| MOVE SPELL IN RANGE | 0.4 | +8.2 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.6 | -29.1 | 23.3 | 2.6 | 0.2 | -9.0 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 38.3 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.6 | +214.5 | 156.4 | 99.8 | 3.5 | +210.5 | 153.0 | 94.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.8 | 0.0 | 3.4 | 0.1 | +9.1 | 21.3 | 5.2 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +7.6 | 0.0 | 0.0 |
| NOT NEEDED | 0.4 | -14.5 | 28.4 | 1.7 | 0.3 | -16.8 | 35.5 | 3.8 |
| NOT TURNED | 5.3 | +105.4 | 0.0 | 151.3 | 6.0 | +110.6 | 0.0 | 135.2 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -744.3 | 28.1 | 336.6 | 15.2 | -856.2 | 15.9 | 312.0 |
| OPENS A LANE | 0.2 | +0.3 | 22.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +24.4 | 23.1 | 16.6 | 0.2 | +28.6 | 15.7 | 0.0 |
| OVERRUN THREAT | 0.0 | +3.2 | 0.0 | 6.5 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +19.1 | 37.6 | 22.5 | 0.5 | +5.7 | 43.9 | 18.2 |
| PATHS CROSS | 2.5 | +199.9 | 0.0 | 48.1 | 3.1 | +243.3 | 0.0 | 67.1 |
| PERIAPT WORTH | 0.1 | +6.3 | 0.0 | 15.0 | 0.1 | +4.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 1.4 | 0.0 | -0.1 | 0.0 | 1.5 |
| PLAN RESULT | 39.2 | +1628.3 | 1802.8 | 1068.2 | 38.8 | +1280.2 | 1529.2 | 1143.8 |
| PURSUES BIG PREY | - | - | - | - | 0.2 | -10.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +14.8 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +27.2 | 0.0 | 18.6 | 2.2 | +30.3 | 0.0 | 47.8 |
| RANDOM MOVER NO PROMISE | 0.5 | -29.8 | 10.8 | 4.7 | 0.3 | -12.8 | 8.2 | 9.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.5 | 0.0 | 1.0 | 0.6 | -13.8 | 0.0 | 11.2 |
| REDIRECT COUNTER | 2.0 | +108.4 | 0.0 | 19.4 | 3.3 | +229.1 | 0.0 | 57.6 |
| REDIRECT WEIGHED | 0.1 | +1.8 | 4.9 | 0.0 | 0.3 | +11.8 | 17.5 | 8.2 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +12.6 | 0.0 | 4.8 | 0.6 | +21.0 | 0.0 | 1.8 |
| RESTRAINS TO SHOOT | 0.1 | +4.2 | 0.0 | 5.1 | 0.1 | +4.1 | 0.0 | 3.4 |
| RISK BY ARC | 3.2 | +104.4 | 292.2 | 110.6 | 3.0 | +63.4 | 227.1 | 102.8 |
| SAFE SURE CHARGE | 0.0 | -1.8 | 3.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.0 | +83.1 | 0.0 | 6.0 | 0.9 | +38.1 | 0.0 | 30.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.0 | 0.0 | 0.0 | 0.3 | -18.4 | 0.0 | 3.1 |
| SEARCH SPOT | 2.5 | +127.5 | 0.0 | 46.1 | 3.1 | +129.7 | 0.0 | 42.9 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 3.9 | 0.0 |
| SELF MOVE SPELL | 0.2 | +38.6 | 0.0 | 0.0 | 0.5 | +20.6 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.9 | +63.3 | 17.1 | 31.6 | 1.1 | +115.2 | 38.7 | 13.3 |
| SET-UP ANY TARGET | 0.5 | +52.6 | 2.5 | 0.0 | 0.1 | +23.2 | 11.1 | 11.1 |
| SET-UP MISSED | 0.1 | +16.1 | 0.0 | 11.2 | 0.1 | +21.1 | 16.6 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +15.5 | 36.2 | 5.2 | 0.6 | +27.9 | 4.9 | 1.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.7 | +0.0 | 180.1 | 14.1 | 0.3 | +0.0 | 28.6 | 28.4 |
| SHOTS IN THE MOVE | 14.7 | +637.6 | 0.0 | 267.6 | 7.2 | +218.6 | 0.0 | 144.1 |
| SPELL CATCH ODDS | 0.1 | -0.6 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +80.9 | 2.5 | 0.0 | 0.1 | +23.2 | 11.1 | 11.1 |
| SPELL WORTH | 1.4 | +25.0 | 106.8 | 101.8 | 2.4 | +39.7 | 115.9 | 118.6 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.9 | -16.8 | 49.2 | 43.7 |
| STABLE ROLE | 11.1 | +0.0 | 362.3 | 230.9 | 9.9 | +0.0 | 332.9 | 151.2 |
| STANDS TO CAST | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.2 | +14.0 | 0.0 | 1.8 | - | - | - | - |
| STOPS | - | - | - | - | 0.2 | +3.8 | 17.6 | 2.5 |
| STOPS SHORT OF THE FLANK | 0.5 | +26.9 | 0.0 | 34.0 | 0.4 | +14.5 | 0.0 | 11.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 6.3 | -45.9 | 404.6 | 143.1 | 7.8 | -54.3 | 377.5 | 97.0 |
| SUPPORTS | 3.9 | +58.7 | 190.0 | 58.1 | 5.4 | +55.6 | 193.8 | 55.3 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.5 | 7.2 | 0.0 | 0.1 | -4.6 | 5.5 | 11.7 |
| SURE REACH TOGETHER | 0.2 | -0.9 | 0.0 | 17.0 | 0.6 | -0.5 | 5.2 | 6.4 |
| THROUGH LINE OF FIRE | 0.3 | +10.6 | 0.0 | 6.3 | 0.3 | +30.1 | 0.0 | 3.2 |
| TURN WORTH | 0.6 | -51.1 | 42.8 | 25.2 | 0.1 | -8.3 | 5.3 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +1.3 | 17.1 | 0.0 | 0.4 | +2.4 | 5.2 | 1.8 |
| WAIT AFTER COSTS | 7.5 | -304.8 | 276.8 | 147.3 | 6.6 | -303.2 | 276.0 | 144.3 |
| WALKS TO THE FIGHT | 1.7 | +28.0 | 36.1 | 10.4 | 0.5 | +10.2 | 16.1 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +13.1 | 3.0 | 5.1 | 0.0 | +0.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 36.8 | 5.1 | 0.1 | +0.0 | 7.3 | 4.0 |
| WEARS DOWN | 1.4 | +62.6 | 137.5 | 51.6 | 1.5 | +55.0 | 108.1 | 37.8 |
| WHO HITS BACK | 0.2 | +22.6 | 0.0 | 12.1 | 0.2 | +20.0 | 0.0 | 11.1 |
| WHOLE FIGHT | 0.5 | +16.3 | 70.6 | 14.0 | 0.6 | +13.2 | 88.5 | 9.5 |
| WHOLE FIGHT GAIN | 0.2 | +26.9 | 15.3 | 6.8 | 0.9 | +58.3 | 74.8 | 24.6 |
| WIDER SPREAD | - | - | - | - | 3.5 | -7.5 | 358.0 | 96.5 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 1.8 | 0.0 |

### Rule changes: cw-h2h-opp-3cc170f-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1106 | 1106 | 1106 | 30.72 | -57616 | -52.1 |
| BEST FIRST | 262 | 262 | 262 | 7.28 | +10111 | +38.6 |
| PATHS CROSS | 202 | 202 | 202 | 5.61 | +15955 | +79.0 |
| SEARCH SPOT | 202 | 202 | 196 | 5.44 | +9282 | +47.4 |
| COUNTER-CHARGE COVER | 594 | 316 | 149 | 4.14 | +9092 | +61.0 |
| MOVE TO CHARGE | 254 | 254 | 128 | 3.56 | +5130 | +40.1 |
| KILLS COUNT NEXT TURN | 459 | 459 | 125 | 3.47 | +3596 | +28.8 |
| SUPPORTS | 333 | 333 | 110 | 3.06 | +1456 | +13.2 |
| FACES THE THREAT | 105 | 105 | 105 | 2.92 | +9322 | +88.8 |
| FOLLOW UP WEIGHED | 81 | 81 | 81 | 2.25 | +13258 | +163.7 |
| FALLBACK BY WORTH | 410 | 410 | 78 | 2.17 | +4223 | +54.1 |
| RANDOM MOVE BY FIGURES | 122 | 122 | 69 | 1.92 | +2069 | +30.0 |
| SAFER THAN THE JOB | 69 | 69 | 69 | 1.92 | +4365 | +63.3 |
| ARTILLERY RE-ROLL WEIGHED | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| SHOTS IN THE MOVE | 789 | 499 | 58 | 1.61 | +1868 | +32.2 |
| WAIT AFTER COSTS | 506 | 506 | 57 | 1.58 | +921 | +16.2 |
| ADVANCE LANE KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| MAX FOR POSITIONING | 338 | 196 | 52 | 1.44 | +735 | +14.1 |
| WALKS TO THE FIGHT | 79 | 79 | 51 | 1.42 | +500 | +9.8 |
| BEST OVERALL | 46 | 46 | 46 | 1.28 | +2980 | +64.8 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW FIRST | 196 | 196 | 40 | 1.11 | -2367 | -59.2 |
| KILLS COUNT | 140 | 139 | 40 | 1.11 | +1792 | +44.8 |
| RISK BY ARC | 221 | 214 | 40 | 1.11 | +1182 | +29.5 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +508 | +13.0 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| SHOT REPLANNED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| BEST FACING | 36 | 36 | 36 | 1.00 | +1917 | +53.3 |
| REDIRECT COUNTER | 192 | 116 | 36 | 1.00 | +3096 | +86.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +3381 | +96.6 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RESERVE FALL BACK | 35 | 35 | 35 | 0.97 | +1208 | +34.5 |
| SET UP TOGETHER | 71 | 67 | 34 | 0.94 | +2838 | +83.5 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1492 | +43.9 |
| CANNON PLANNED TARGET | 208 | 208 | 33 | 0.92 | -228 | -6.9 |
| CAST JOB | 45 | 45 | 29 | 0.81 | +923 | +31.8 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| KEEPS ITS TARGET | 136 | 136 | 27 | 0.75 | +429 | +15.9 |
| INVITES THE FIGHT | 122 | 122 | 26 | 0.72 | +282 | +10.9 |
| MARCH CHECK | 33 | 32 | 25 | 0.69 | +1144 | +45.8 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +797 | +33.2 |
| SHOOTS FROM THE BEST SPOT | 46 | 46 | 23 | 0.64 | +616 | +26.8 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +377 | +17.1 |
| WHOLE FIGHT GAIN | 38 | 36 | 22 | 0.61 | +1215 | +55.2 |
| MISSILES IN THE MOVE | 214 | 124 | 21 | 0.58 | +405 | +19.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +1464 | +73.2 |
| BEST PREY | 74 | 74 | 19 | 0.53 | +912 | +48.0 |
| MAKE SURE TOGETHER | 42 | 36 | 19 | 0.53 | +2145 | +112.9 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1133 | +70.8 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | +17 | +1.1 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +624 | +44.6 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +982 | +75.5 |
| MANOEUVRE | 15 | 15 | 13 | 0.36 | +392 | +30.2 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -30 | -2.5 |
| SUPPORT NARROWED | 506 | 506 | 12 | 0.33 | -176 | -14.6 |
| HONEST WORTH | 287 | 287 | 11 | 0.31 | +126 | +11.5 |
| WAR ENGINE JOBS | 28 | 28 | 11 | 0.31 | -202 | -18.4 |
| CASTING BLOCK | 14 | 14 | 10 | 0.28 | +584 | +58.4 |
| WEARS DOWN | 107 | 104 | 10 | 0.28 | +345 | +34.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 177 | 176 | 9 | 0.25 | +189 | +21.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BACKUP TARGETS | 82 | 42 | 8 | 0.22 | +60 | +7.5 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2183 | +272.9 |
| OPENS UP | 17 | 17 | 8 | 0.22 | +798 | +99.7 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +298 | +37.2 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -363 | -45.4 |
| WHOLE FIGHT | 39 | 38 | 8 | 0.22 | +342 | +42.7 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +180 | +25.8 |
| MISSILES NEXT TURN | 278 | 154 | 7 | 0.19 | +22 | +3.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -379 | -54.2 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +337 | +56.2 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +505 | +84.2 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| LONG SHOT | 45 | 43 | 5 | 0.14 | +56 | +11.2 |
| OVERRUNS AWAY | 37 | 37 | 5 | 0.14 | +172 | +34.4 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +401 | +80.1 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -55 | -11.1 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -116 | -28.9 |
| WIDER SPREAD | 126 | 123 | 4 | 0.11 | +36 | +8.9 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +1 | +0.2 |
| CHARGE BAND | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| DEFENSIVE FLOOR | 8 | 8 | 3 | 0.08 | +40 | +13.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +25 | +8.2 |
| HUNT IN PAIRS | 26 | 12 | 3 | 0.08 | +175 | +58.2 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| SURE REACH TOGETHER | 32 | 26 | 3 | 0.08 | +23 | +7.7 |
| WAR ENGINE CHARGES | 5 | 5 | 3 | 0.08 | +292 | +97.4 |
| JOINT CHARGE PLAN | 9 | 9 | 2 | 0.06 | +244 | +122.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 2 | 0.06 | -177 | -88.7 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +207 | +103.5 |
| REFUSING RETIRES | 8 | 8 | 2 | 0.06 | -1 | -0.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +36 | +35.9 |
| DEFENSIVE ARMY | 13 | 13 | 1 | 0.03 | -3 | -3.1 |
| EDGE GIVE GROUND | 14 | 14 | 1 | 0.03 | +7 | +6.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +24 | +24.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +19 | +19.4 |
| HUNT ADVANCE | 6 | 6 | 1 | 0.03 | +18 | +18.3 |
| REDIRECT BY WHAT IT STOPS | 30 | 30 | 1 | 0.03 | +17 | +17.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -88 | -87.9 |
| SPELLS IN THE FIGHT | 32 | 31 | 1 | 0.03 | +65 | +64.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +38 | +38.5 |
| STOPS | 6 | 6 | 1 | 0.03 | +10 | +9.5 |
| TWO OR MORE ARRIVE | 27 | 27 | 1 | 0.03 | +2 | +2.1 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 30 | 27 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 10 | 10 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 393 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 39 | 39 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 25 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 407 | 407 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 2 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2810 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 135 | not checked | - | - | - | - |
| STABLE ROLE | 753 | 753 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-opp-3cc170f-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.64 | 13.47 | 53.6 |
| FALLBACK | gate | 0.67 | 0.75 | 49.0 |
| CHARGE NOW FIRST | rule | 0.56 | 0.56 | 59.2 |
| TURN GATE | gate | 0.56 | 0.39 | 36.8 |
| FIGHT ORDER BAND | gate | 0.22 | 0.14 | 2.2 |
| SUPPORT REQUEST | gate | 0.14 | 0.22 | 58.6 |
| SUPPORT NARROWED | rule | 0.11 | 0.22 | 14.7 |
| WAR ENGINE JOBS | rule | 0.31 | - | 18.4 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 40.3 |
| PATHS CROSS | rule | 0.17 | 0.08 | 8.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.14 | 45.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.03 | 51.0 |
| PURSUES BIG PREY | rule | - | 0.19 | 54.2 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.14 | 6.9 |
| AFTERMATH BAND | gate | 0.06 | 0.08 | 2.3 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 5.9 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.03 | 11.1 |
| BEST PRIZE | rule | - | 0.11 | 28.9 |
| BLOCKED WHEEL | rule | 0.08 | 0.03 | 7.9 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.08 | 49.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 7.7 |
| RULE SWITCHED OFF | gate | 0.08 | - | 73.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 97.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 88.7 |
| NO REASON | gate | - | 0.06 | 4.4 |
| DEFENSIVE ARMY | rule | 0.03 | - | 3.1 |
| FACES THE THREAT | rule | - | 0.03 | 3.7 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.3 |
| MARCH ODDS | rule | - | 0.03 | 4.6 |
| MOVE AND CAST | rule | - | 0.03 | 19.6 |
| SAFE SURE CHARGE | rule | 0.03 | - | 87.9 |
| SAFER THAN THE JOB | rule | - | 0.03 | 6.9 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 12.2 |

### Plans: cw-h2h-opp-3cc170f-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.5 | 17% | 408 | 302 | 74% |
| Mine | charge | 3.8 | 56% | 309 | 317 | 103% |
| Mine | close in | 4.4 | 24% | 272 | 127 | 47% |
| Mine | hold | 4.9 | 33% | 294 | 0 | 0% |
| Mine | join | 0.6 | 95% | 10 | 0 | 0% |
| Mine | shoot | 9.0 | 60% | 404 | 882 | 218% |
| Mine | support | 4.1 | 89% | 46 | 0 | 0% |
| Opponent | advance | 13.2 | 16% | 368 | 405 | 110% |
| Opponent | charge | 4.8 | 56% | 416 | 524 | 126% |
| Opponent | close in | 5.7 | 22% | 337 | 129 | 38% |
| Opponent | hold | 4.3 | 28% | 293 | 0 | 0% |
| Opponent | join | 0.7 | 96% | 32 | 0 | 0% |
| Opponent | shoot | 3.8 | 57% | 82 | 228 | 278% |
| Opponent | support | 6.2 | 92% | 41 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-opp-3cc170f-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |
| Opponent | 0.2 | 9 | 1 | 38% | 38% | 0% | 2.7 | 269 | 84 | 38% | 117 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 205 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.4 | 4 | 0 | 50% | 50% | 0% | 2.5 | 182 | 96 | 50% | 25 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 1 | 33% | 33% | 0% | 3.0 | 445 | 97 | 33% | 121 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 85 | 0 | 0% | 34 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 289 |

### Battle groups: cw-h2h-opp-3cc170f-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 26% | 41% | 5% | 0% | 32% | 9% | 21% | 38% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 31% | 68% | 18% | 25% | 22% | 6% | 22% | 50% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.8 | 20% | 75% | 16% | 22% | 24% | 9% | 24% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 24% | 69% | 31% | 11% | 20% | 0% | 15% | 60% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-opp-3cc170f-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 171 (4) | 171 | 0 | 38 | 0% | 2.5 | - | 171 (4) | - | - | 171 (4) |
| Mine | Chaff | 34 | 42 (34) | 26 | 16 | 64 | 35% | 2.1 | 48 (14) | 0 (5) | 52 (15) | 38 (20) | 49 (14) |
| Mine | Character | 106 | 47 (106) | 47 | 0 | 36 | 16% | 2.3 | 54 (31) | 46 (53) | 70 (6) | 60 (44) | 42 (46) |
| Mine | Clean-up | 23 | 81 (23) | 49 | 32 | 57 | 26% | 2.6 | 0 (2) | 85 (17) | 107 (4) | 50 (11) | 100 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 55 (4) | 55 | 0 | 100 | 0% | 3.2 | 111 (2) | 0 (2) | - | 76 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 63 (41) | 34 | 29 | 42 | 20% | 2.7 | 49 (27) | 97 (9) | 71 (5) | 83 (25) | 33 (16) |
| Mine | Fragile | 4 | 27 (4) | 27 | 0 | 100 | 50% | 2.0 | 100 (1) | 0 (2) | - | 0 (1) | 50 (2) |
| Mine | Hammer | 64 | 30 (64) | 21 | 9 | 44 | 22% | 2.6 | 56 (13) | 28 (44) | 0 (7) | 33 (39) | 27 (25) |
| Mine | Holder | 31 | 109 (31) | 34 | 75 | 28 | 29% | 2.7 | 65 (7) | 185 (15) | 30 (8) | 143 (20) | 68 (10) |
| Mine | Shooter | 34 | 75 (34) | 39 | 36 | 40 | 3% | 1.5 | 54 (8) | 90 (21) | 47 (5) | 87 (25) | 36 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 56 | 62 (56) | 62 | 0 | 39 | 4% | 1.3 | 51 (16) | 66 (30) | 69 (10) | 48 (9) | 64 (47) |
| Mine | Wizard | 17 | 8 (17) | 8 | 0 | 50 | 6% | 2.6 | 0 (4) | 18 (8) | 0 (1) | 0 (6) | 20 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 43 (77) | 21 | 22 | 63 | 42% | 2.5 | 54 (32) | 64 (18) | 14 (27) | 50 (58) | 17 (19) |
| Opponent | Character | 97 | 57 (97) | 57 | 0 | 37 | 21% | 2.3 | 73 (44) | 47 (39) | 37 (7) | 58 (53) | 60 (37) |
| Opponent | Clean-up | 12 | 69 (12) | 16 | 53 | 41 | 25% | 3.2 | 15 (4) | 86 (5) | 77 (3) | 24 (7) | 99 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 52 (54) | 36 | 16 | 48 | 33% | 2.8 | 41 (22) | 45 (24) | 122 (8) | 48 (33) | 58 (21) |
| Opponent | Fragile | 17 | 11 (17) | 11 | 0 | 54 | 24% | 2.2 | 0 (4) | 16 (8) | 10 (5) | 13 (14) | 0 (3) |
| Opponent | Hammer | 65 | 38 (65) | 22 | 15 | 35 | 34% | 3.2 | 8 (20) | 50 (38) | 15 (7) | 46 (41) | 26 (24) |
| Opponent | Holder | 30 | 43 (30) | 10 | 32 | 25 | 57% | 3.9 | 37 (9) | 49 (15) | 28 (6) | 62 (16) | 20 (14) |
| Opponent | Shooter | 34 | 67 (34) | 29 | 38 | 41 | 0% | 1.5 | 41 (10) | 81 (21) | 64 (3) | 79 (19) | 53 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 48 | 50% | 2.0 | 0 (5) | - | - | 0 (1) | 0 (4) |
| Opponent | War machine | 6 | 94 (6) | 94 | 0 | 61 | 17% | 1.0 | 117 (3) | 61 (3) | - | 117 (3) | 61 (3) |
| Opponent | Wizard | 20 | 13 (20) | 13 | 0 | 34 | 10% | 2.3 | 17 (12) | 0 (2) | 0 (3) | 15 (11) | 0 (6) |

### Charged fights: cw-h2h-opp-3cc170f-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 135 | 164 | 2.2 | 1.2 | 73 | 21 | +52 | 1 of 9 | 6 of 9 | +34 | +57 |
| Mine | Chaos Dwarfs | 4 | 133 | 493 | 3.0 | 1.2 | 164 | 0 | +164 | 6 of 12 | 10 of 12 | +207 | +150 |
| Mine | Dwarfen Mountain Holds | 3 | 675 | 20 | 1.7 | 1.0 | 12 | 45 | -33 | 2 of 5 | 1 of 5 | - | -33 |
| Mine | Empire of Man | 5 | 735 | 149 | 2.0 | 1.2 | 74 | 129 | -54 | 5 of 10 | 4 of 10 | -514 | -3 |
| Mine | Grand Cathay | 4 | 316 | 534 | 4.0 | 1.2 | 133 | 0 | +133 | 3 of 16 | 15 of 16 | +158 | +128 |
| Mine | High Elf Realms | 4 | 282 | 409 | 3.8 | 1.0 | 109 | 0 | +109 | 5 of 15 | 12 of 15 | - | +109 |
| Mine | Kingdom of Bretonnia | 1 | 177 | 640 | 5.0 | 1.6 | 128 | 0 | +128 | 2 of 5 | 4 of 5 | +248 | +48 |
| Mine | Lizardmen | 1 | 0 | 813 | 4.0 | 1.0 | 203 | 0 | +203 | 2 of 4 | 4 of 4 | - | +203 |
| Mine | Ogre Kingdoms | 2 | 51 | 28 | 4.0 | 1.2 | 7 | 210 | -203 | 4 of 8 | 4 of 8 | -150 | -220 |
| Mine | Skaven | 2 | 88 | 106 | 1.5 | 1.0 | 70 | 0 | +70 | 0 of 3 | 3 of 3 | - | +70 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 546 | 4.0 | 1.0 | 137 | 144 | -7 | 3 of 8 | 2 of 8 | - | -7 |
| Mine | Vampire Counts | 2 | 51 | 370 | 5.0 | 1.0 | 74 | 37 | +37 | 2 of 10 | 8 of 10 | - | +37 |
| Mine | Warriors of Chaos | 2 | 86 | 528 | 6.0 | 1.0 | 88 | 58 | +30 | 3 of 12 | 10 of 12 | - | +30 |
| **Mine** | all armies | 36 | 275 | 328 | 3.2 | 1.1 | 101 | 48 | +53 | 38 of 117 | 83 of 117 | +65 | +52 |
| Opponent | Empire of Man | 1 | 675 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 208 | 619 | 2.8 | 1.2 | 221 | 46 | +175 | 8 of 14 | 9 of 14 | +78 | +201 |
| Opponent | Lizardmen | 2 | 0 | 786 | 2.5 | 1.4 | 314 | 10 | +305 | 3 of 5 | 5 of 5 | +156 | +342 |
| Opponent | Orc & Goblin Tribes | 3 | 11 | 131 | 3.3 | 1.2 | 39 | 35 | +4 | 3 of 10 | 7 of 10 | +117 | -24 |
| Opponent | Skaven | 4 | 89 | 82 | 1.5 | 1.2 | 55 | 37 | +18 | 1 of 6 | 4 of 6 | -222 | +66 |
| Opponent | Tomb Kings of Khemri | 2 | 55 | 1034 | 4.5 | 1.6 | 230 | 51 | +179 | 2 of 9 | 7 of 9 | +252 | +120 |
| Opponent | Vampire Counts | 6 | 100 | 335 | 4.5 | 1.1 | 74 | 41 | +33 | 21 of 27 | 20 of 27 | +120 | +18 |
| Opponent | Warriors of Chaos | 7 | 0 | 384 | 3.1 | 1.1 | 122 | 59 | +63 | 12 of 22 | 15 of 22 | +88 | +60 |
| Opponent | Wood Elf Realms | 6 | 66 | 292 | 3.5 | 1.4 | 83 | 23 | +60 | 10 of 21 | 15 of 21 | +18 | +81 |
| **Opponent** | all armies | 36 | 89 | 386 | 3.2 | 1.2 | 122 | 41 | +81 | 60 of 114 | 82 of 114 | +91 | +79 |

### Effective charges: cw-h2h-opp-3cc170f-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 3 (net +78) | 0 | 0 | 4 (net +80) | 0 | 2 (net -42) | 0 | 0% (0 of 9) |
| Mine | Chaos Dwarfs | 12 | 2 (net +308) | 1 (net +109) | 0 | 2 (net +202) | 1 (net +107) | 6 (net +123) | 0 | 0% (0 of 12) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 1 (net -95) | 2 (net +30) | 0 | 1 (net -128) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 10 | 2 (net -308) | 0 | 3 (net -171) | 3 (net +196) | 0 | 2 (net +0) | 0 | 30% (3 of 10) |
| Mine | Grand Cathay | 16 | 0 | 1 (net +0) | 0 | 5 (net +231) | 3 (net +119) | 7 (net +89) | 0 | 0% (0 of 16) |
| Mine | High Elf Realms | 15 | 3 (net +78) | 0 | 1 (net +70) | 4 (net +163) | 3 (net +206) | 4 (net +16) | 0 | 7% (1 of 15) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 0 | 0 | 0 | 2 (net +248) | 2 (net +72) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +393) | 1 (net +255) | 0 | 1 (net +110) | 1 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 8 | 0 | 0 | 2 (net -65) | 1 (net +0) | 0 | 2 (net -150) | 3 | 40% (2 of 5) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +70) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 2 (net +243) | 0 | 3 (net -258) | 3 (net +77) | 0 | 0 | 0 | 38% (3 of 8) |
| Mine | Vampire Counts | 10 | 1 (net +0) | 0 | 2 (net -164) | 4 (net +174) | 1 (net +0) | 2 (net +0) | 0 | 20% (2 of 10) |
| Mine | Warriors of Chaos | 12 | 1 (net +107) | 0 | 3 (net -1) | 1 (net +0) | 2 (net +68) | 3 (net +0) | 2 | 30% (3 of 10) |
| Opponent | High Elf Realms | 14 | 0 | 1 (net +0) | 4 (net +184) | 3 (net +232) | 1 (net +91) | 4 (net +191) | 1 | 31% (4 of 13) |
| Opponent | Lizardmen | 5 | 0 | 0 | 2 (net +295) | 3 (net +311) | 0 | 0 | 0 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 10 | 1 (net -350) | 1 (net +77) | 1 (net +0) | 2 (net +117) | 0 | 3 (net +28) | 2 | 12% (1 of 8) |
| Opponent | Skaven | 6 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 4 (net +27) | 0 | 0% (0 of 6) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +572) | 0 | 1 (net -155) | 3 (net +119) | 1 (net +145) | 3 (net +230) | 0 | 11% (1 of 9) |
| Opponent | Vampire Counts | 27 | 4 (net -119) | 0 | 12 (net +72) | 6 (net +20) | 1 (net +0) | 3 (net +129) | 1 | 46% (12 of 26) |
| Opponent | Warriors of Chaos | 22 | 3 (net +161) | 0 | 4 (net -39) | 1 (net +420) | 2 (net +55) | 7 (net -3) | 5 | 24% (4 of 17) |
| Opponent | Wood Elf Realms | 21 | 6 (net +40) | 1 (net +137) | 6 (net +135) | 2 (net -33) | 2 (net +54) | 4 (net +8) | 0 | 29% (6 of 21) |

### Charged fights, damage counted: cw-h2h-opp-3cc170f-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 229 | 330 | +66 | 125 | 88 | +37 | +16.0 |
| Mine | 50-54% | 2 | 369 | 337 | +54 | 179 | 34 | +145 | +39.3 |
| Mine | Effective (55-75%) | 16 | 278 | 272 | -86 | 104 | 184 | -80 | -28.8 |
| Mine | 76-89% | 30 | 255 | 206 | +145 | 175 | 35 | +140 | +54.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 214 | 147 | +39 | 78 | 25 | +53 | +24.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 524 | 98 | +143 | 143 | 25 | +118 | +22.5 |
| Mine | No odds | 6 | 224 | 274 | -170 | 28 | 198 | -170 | -75.9 |
| Mine | All fights | 117 | 270 | 209 | +53 | 119 | 67 | +52 | +19.1 |
| Opponent | Long shot (under 50%) | 15 | 239 | 339 | +31 | 145 | 84 | +61 | +25.7 |
| Opponent | 50-54% | 4 | 227 | 196 | +54 | 80 | 67 | +13 | +5.9 |
| Opponent | Effective (55-75%) | 30 | 321 | 247 | +90 | 186 | 80 | +105 | +32.8 |
| Opponent | 76-89% | 21 | 344 | 239 | +128 | 149 | 22 | +127 | +36.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 280 | 178 | +73 | 129 | 53 | +76 | +27.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 608 | 124 | +65 | 75 | 11 | +64 | +10.6 |
| Opponent | No odds | 9 | 342 | 194 | +80 | 135 | 64 | +71 | +20.7 |
| Opponent | All fights | 114 | 320 | 227 | +81 | 145 | 57 | +88 | +27.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-opp-3cc170f-p4 | move | 443 | 98 (22%) | 69 (16%) | 56 (13%) | 289 (65%) |
| cw-h2h-opp-3cc170f-p4 | objective | 364 | 43 (12%) | 33 (9%) | 52 (14%) | 269 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

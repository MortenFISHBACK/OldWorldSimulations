# Doctrine scorecard: cw-h2h-opp-3cc170f-p2

### Scorecard: cw-h2h-opp-3cc170f-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 1 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 2 | 5 | 3 | 0 | 0 | 0 | 251 |
| L0222 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 2 | 2 | 1 | 2 | 0 | 0 | 295 |
| L0323 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 8 | 3 | 0 | 0 | 0 | 0 | 0 | 1075 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1257 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0616 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 769 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 1 | 0 | 2 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 717 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 479 |
| L0918 | 6 | 1 | Opponent | no | 15 | 2 | 2 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 868 |
| L0934 | 4 | 1 | Opponent | yes | 1 | 2 | 8 | 3 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 0 | 0 | 0 | 459 |
| L1135 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 5 | 3 | 2 | 1 | 0 | 0 | 234 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 2 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 5 | 1 | 5 | 1 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 1 | 2 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 1.6 | 2.7 | 2.6 | 1.1 | 0.2 | 0.0 | 0.0 | 291.6 |
| **Average** | | | Opponent | 30% | 3.2 | 2.4 | 2.6 | 1.5 | 0.4 | 0.0 | 0.0 | 177.3 |

### KPIs: cw-h2h-opp-3cc170f-p2

Rules off - Mine only: CHARGE BAND, HONEST WORTH, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (46 of 178) | 12% (21 of 177) | 19% (67 of 355) |
| Winner chose to follow up after the loser gave ground |  | 98% (91 of 93); on the table 98% | 98% (58 of 59); on the table 98% | 98% (149 of 152); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (13 of 14); on the table 93% | 86% (18 of 21); on the table 86% | 89% (31 of 35); on the table 89% |
| Winner chose to pursue after the loser fled |  | 76% (19 of 25); on the table 84% | 83% (29 of 35); on the table 83% | 80% (48 of 60); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 93% (123 of 132); on the table 95% | 91% (105 of 115); on the table 91% | 92% (228 of 247); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% (114 of 342) | 33% (51 of 156) | 33% (165 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (114 of 238) | 48% (51 of 106) | 48% (165 of 344) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 48% (13 of 27) | 63% (34 of 54) | 58% (47 of 81) |
| Points that never fought | lower | 34% (24367 of 71583) | 37% (26433 of 71989) | 35% (50800 of 143572) |
|   infantry points that never fought | lower | 45% (7276 of 16324) | 50% (7029 of 14029) | 47% (14305 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (170 of 284) | 57% (168 of 297) | 58% (338 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 100% (20 of 20); 1.6 uses a game | 78% (14 of 18); 1.4 uses a game | 89% (34 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 72% (13 of 18); 0.7 uses a game | 50% (1 of 2); 0.1 uses a game | 70% (14 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32795 of 60231) | 52% (32805 of 63281) | 53% (65600 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (28%) | 0.8 (26%) | 2.5 (27%) |
| MARCHED: its unit marched | 1.1 (17%) | 0.5 (16%) | 1.5 (17%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.6 (21%) | 2.2 (24%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| FLEEING: fleeing | 0.2 (3%) | 0.1 (3%) | 0.2 (3%) |
| GONE: slain | 0.7 (11%) | 0.5 (16%) | 1.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.2 (8%) | 0.6 (7%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.7 | 1.3 | 4.6 | 0.4 | 2.4 |
| not cast | 3.5 | 3.2 | 3.7 | 9.2 | 1.9 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (51%) | 0.3 (8%) | 2.5 (27%) | 0.4 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (17%) | 0.3 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (9%) | 0.5 (14%) | 2.2 (24%) | 0.4 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (11%) | 0.2 (8%) | 0.4 (10%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.1 (3%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.5 (3%) |
| GONE: slain | 0.6 (17%) | 0.6 (18%) | 0.8 (20%) | 1.2 (13%) | 0.5 (28%) | 2.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.1 (3%) | 0.2 (7%) | 0.6 (7%) | 0.1 (4%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (6%) | 0.0 (1%) | 0.1 (1%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (50%) | 0.1 (3%) | 1.3 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 54% (14 of 26) | 56% (14 of 25) | 55% (28 of 51) |
| the unit moved after it | 71% (10 of 14) | 50% (7 of 14) | 61% (17 of 28) |
| it charged on its next turn | 7% (1 of 14) | 7% (1 of 14) | 7% (2 of 28) |
| the enemy charged it first | 0% (0 of 14) | 21% (3 of 14) | 11% (3 of 28) |
| it fought by the end of its next turn | 0% (0 of 14) | 21% (3 of 14) | 11% (3 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (4 of 14) | 7% (1 of 14) | 18% (5 of 28) |
| none of these (no charge, no fight, no charge escaped) | 64% (9 of 14) | 64% (9 of 14) | 64% (18 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (558 of 874) | 54% (441 of 814) | 59% (999 of 1688) |
|   cavalry | 65% (45 of 69) | 62% (106 of 172) | 63% (151 of 241) |
|   character | 50% (55 of 109) | 33% (36 of 110) | 42% (91 of 219) |
|   chariot | 45% (46 of 103) | 75% (36 of 48) | 54% (82 of 151) |
|   infantry | 55% (145 of 265) | 50% (157 of 315) | 52% (302 of 580) |
|   monster | 52% (27 of 52) | 46% (16 of 35) | 49% (43 of 87) |
|   war machine | 87% (240 of 276) | 67% (90 of 134) | 80% (330 of 410) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 2.2 (21%) | 4.6 (24%) |
| CHARGED: it charged | 1.3 (15%) | 1.8 (17%) | 3.1 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.8 (8%) | 1.8 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.4 (16%) | 1.9 (18%) | 3.3 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.4 (4%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 2.1 (21%) | 3.5 (18%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |
| OTHER BAR | 0.2 (3%) | 0.6 (6%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.5 | 82% | 4.4 pts | 28 pts |
| character | 2.8 | 0.9 | 78% | 9.1 pts | 25 pts |
| chariot | 2.3 | 1.2 | 67% | 11.7 pts | 27 pts |
| infantry | 11.3 | 4.7 | 72% | 8.7 pts | 99 pts |
| monster | 1.6 | 0.5 | 85% | 4.6 pts | 8 pts |
| war machine | 9.2 | 7.0 | 61% | 23.6 pts | 217 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 6.2 | 5.5 |
| Charges that made contact a game | 3.8 | 4.2 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.65 contact (26 units) | 0.55 declared, 0.55 contact (11 units) | 0.73 declared, 0.62 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.50 contact (8 units) | 1.17 declared, 1.00 contact (12 units) | 1.00 declared, 0.80 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.47 contact (243 units) | 0.72 declared, 0.48 contact (281 units) | 0.66 declared, 0.48 contact (524 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (46 of 73) | 56% (10 of 18) | 42% (5 of 12) | 59% (61 of 103) |
| Character in a unit | 91% (32 of 35) | 75% (12 of 16) | 50% (1 of 2) | 85% (45 of 53) |
| Character on its own | 65% (24 of 37) | 58% (22 of 38) | 30% (19 of 64) | 47% (65 of 139) |
| Chariot | 71% (12 of 17) | 77% (10 of 13) | - | 73% (22 of 30) |
| Infantry | 52% (49 of 94) | 50% (17 of 34) | 33% (1 of 3) | 51% (67 of 131) |
| Monster | 41% (12 of 29) | 67% (6 of 9) | - | 47% (18 of 38) |
| Monstrous | 57% (8 of 14) | 57% (8 of 14) | - | 57% (16 of 28) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 95% (20 of 21); on the table 95% | 25% (26 of 102) | 38% | 59% (13 of 22) | 100% (6 of 6); 3.0 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 93% (14 of 15); on the table 93% | 39% (14 of 36) | 36% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 96% (23 of 24); on the table 96% | - | 59% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 92% (12 of 13); on the table 100% | 35% (17 of 48) | 54% | 63% (48 of 76) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 96% (22 of 23); on the table 96% | 38% (52 of 138) | 41% | 44% (24 of 54) | 93% (13 of 14); 7.8 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 82% (9 of 11); on the table 82% | 17% (3 of 18) | 13% | 58% (19 of 33) | 100% (3 of 3); 2.2 uses a game | 64% (9 of 14); 4.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (7 of 7); on the table 100% | - | 33% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (8 of 8); on the table 100% | - | 35% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (13 of 13); on the table 100% | 0% (0 of 18) | 28% | 79% (22 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 8% (1 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 92% (12 of 13); on the table 92% | 56% (10 of 18) | 39% | 60% (15 of 25) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 86% (12 of 14); on the table 86% | - | 28% | 32% (8 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 91% (29 of 32); on the table 94% | 39% (26 of 66) | 27% | 59% (32 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (25 of 28); on the table 89% | 50% (9 of 18) | 24% | 52% (38 of 73) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 86% (18 of 21); on the table 86% | 29% (7 of 24) | 42% | 65% (51 of 78) | 57% (4 of 7); 2.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cw-h2h-opp-3cc170f-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (43) | 51% (39) | 52% (82) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.78 | 1.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.14 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.69 | 0.50 | 1.19 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.08 | 1.31 | 3.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 1.28 | 2.22 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.06 | 4.97 | 11.03 |

### Quality by phase: cw-h2h-opp-3cc170f-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 57% (81 of 141) | 48% (95 of 196) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (158 of 351) | 53% (109 of 206) |
| Strategy | Close-in objectives charged next turn | 9% (11 of 126) | 18% (45 of 256) |
| Strategy | Support requests answered (helper made contact too) | 67% (12 of 18) | 44% (16 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 69% (9 of 13) | 80% (12 of 15) |
| Strategy | Joined characters whose unit fought | 33% (18 of 54) | 40% (14 of 35) |
| Strategy | Lone characters that fought | 80% (73 of 91) | 75% (66 of 88) |
| Movement | Charges halted short of contact | 0.0 | 0.4 |
| Movement | Idle units | 1.1 | 1.5 |
| Movement | Points that never moved of their own | 291.6 | 177.3 |
| Movement | Fights charged into per game | 3.3 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 108, net +29 | 22 of 106, net +124 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 108, net +58 | 24 of 106, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 108, net +70 | 6 of 106, net +148 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 108, net +100 | 23 of 106, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (158 of 348) | 46% (178 of 388) |
| Shooting | Points destroyed by shooting units | 99.4 | 39.0 |
| Shooting | War machine shots | 6.7 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (127 of 240) | 42% (38 of 90) |
| Shooting | Points destroyed by war machines | 80.8 | 35.2 |
| Magic | Magic missiles cast | 2.1 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (26 of 75) | 44% (15 of 34) |
| Magic | Wounds caused by magic missiles | 2.6 | 2.0 |
| Magic | Wounds caused by other spells | 2.5 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 65.2 | 28.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 1.0 / 0.1 | 2.0 / 0.4 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 362.9 | 388.4 |
| Combat | Points run down | 40.0 | 69.8 |
| Combat | Net points per charged fight, damage counted | +85 | +106 |
| Combat | Net per 100 charger points, damage counted | +33.4 | +38.6 |
| Combat | First round won (charged fights) | 75% | 75% |
| Combat | Net points per charged fight | +70 | +99 |
| Combat | Net points per supported fight / lone fight | +75 / +69 | +200 / +75 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 119 | 51 of 126 |
| Game | Points lost | 764.0 | 717.0 |
| Game | VP from objectives | 511.7 | 677.2 |
| Game | Lone holders (player turns) | 1.6 | 3.2 |

- Mine won / drew / lost: 13 / 4 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -174 VP
- The side that went first won 19 of 32 games with a winner
- Points traded per game (both sides' losses): 1481
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: cw-h2h-opp-3cc170f-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.2 | 0.0 | 2.4 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 31.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.7 | 0.0 | 13.3 | 0.7 | +6.2 | 0.0 | 16.4 |
| BEST FACING | 0.9 | +34.2 | 0.0 | 46.7 | 0.6 | +14.9 | 0.0 | 0.0 |
| BEST FIRST | 5.4 | +228.5 | 198.4 | 84.7 | 4.5 | +179.4 | 178.0 | 85.2 |
| BEST OVERALL | 0.8 | +53.4 | 0.0 | 47.1 | 0.8 | +50.7 | 0.0 | 20.3 |
| BEST PREY | 0.9 | +32.7 | 19.7 | 8.4 | 0.9 | +27.4 | 35.6 | 10.6 |
| BEST PRIZE | - | - | - | - | 0.2 | -6.7 | 16.5 | 7.7 |
| BIG CHARACTER SAFETY | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 13.9 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 10.2 | 0.1 | +0.0 | 0.0 | 12.1 |
| BLOCKED WHEEL | 0.3 | +3.0 | 0.0 | 0.0 | 0.6 | +8.3 | 0.0 | 23.4 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -40.4 | 61.8 | 7.1 |
| BOMBING RUN | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 161.2 | 7.2 | 0.2 | +0.0 | 20.7 | 2.9 |
| CANNON PLANNED TARGET | 5.2 | +227.0 | 448.7 | 117.9 | 1.9 | +79.8 | 74.1 | 21.8 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT COUNTER | 0.0 | -1.3 | 0.0 | 0.0 | 0.1 | +0.0 | 19.6 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 19.4 | 1.2 |
| CAST JOB | 0.5 | +8.8 | 23.1 | 8.1 | 0.2 | +7.7 | 35.4 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +14.3 | 12.8 | 0.0 | 0.2 | +12.2 | 24.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 34.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 6.5 | 0.3 | -1.0 | 0.0 | 5.5 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.5 | 7.2 | 0.0 |
| CHARGE BAND | - | - | - | - | 0.3 | +0.0 | 24.8 | 12.9 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 228.2 | 99.2 | 2.7 | +0.0 | 257.5 | 95.1 |
| CHARGE NOW WEIGHED | 0.6 | -29.1 | 27.1 | 11.6 | 0.7 | -76.9 | 15.6 | 49.4 |
| CHARGER SLAIN LOST | - | - | - | - | 0.6 | -14.5 | 63.8 | 24.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 11.8 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 17.6 | 31.9 | 0.7 | +0.0 | 36.4 | 24.1 |
| CONVEYANCE SEARCH | 0.5 | +49.2 | 5.3 | 2.6 | 0.6 | +95.6 | 49.6 | 74.9 |
| COUNTER-CHARGE COVER | 10.8 | +916.5 | 0.0 | 171.2 | 6.4 | +572.6 | 0.0 | 190.8 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 37.2 | 12.8 | 0.2 | +0.0 | 15.8 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +0.4 | 7.2 | 11.0 | 0.4 | +6.3 | 44.0 | 25.9 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +146.8 | 0.0 | 66.0 | 1.3 | +95.8 | 0.0 | 39.2 |
| FALLBACK BY WORTH | 4.4 | +42.3 | 0.0 | 44.1 | 5.4 | +80.2 | 0.0 | 44.9 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 149.1 | 4.8 | +0.0 | 0.0 | 154.8 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +192.9 | 0.0 | 41.0 | 1.1 | +128.3 | 0.0 | 14.6 |
| FRIENDS SHOTS CHECKED | 0.5 | +27.2 | 0.0 | 0.0 | 0.2 | +14.6 | 0.0 | 9.7 |
| GIVES UP | - | - | - | - | 0.1 | -1.4 | 18.5 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 10.2 | 0.0 | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 16.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 34.5 | 16.1 | 0.4 | +0.0 | 33.8 | 10.6 |
| HILL BY ITS CHANCE | 0.4 | -36.3 | 0.0 | 8.5 | 0.6 | -51.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 10.4 | -219.4 | 574.8 | 338.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +0.9 | 0.0 | 1.4 | 0.2 | +4.8 | 0.0 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.4 | 0.2 | +0.0 | 0.0 | 1.9 |
| HUNT IN PAIRS | 0.3 | +11.8 | 0.0 | 27.5 | 0.7 | +76.8 | 0.0 | 64.1 |
| HUNT KEPT | 0.2 | +0.8 | 5.4 | 8.8 | 0.1 | +4.7 | 9.2 | 0.0 |
| HUNT RESULT | 0.1 | +12.6 | 5.4 | 2.4 | 0.3 | +49.5 | 0.0 | 2.9 |
| HUNT THE GUNS | 0.1 | +37.6 | 12.1 | 0.0 | 0.3 | +117.5 | 17.2 | 2.9 |
| INVITES THE FIGHT | 1.6 | +30.3 | 77.0 | 5.2 | 1.0 | +14.8 | 39.3 | 8.4 |
| JOINT CHARGE PLAN | 0.0 | +0.1 | 0.0 | 2.4 | 0.2 | +15.4 | 0.0 | 18.5 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.9 | 0.0 | 1.8 |
| KEEP FALLS | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +1.3 | 3.3 | 14.4 | - | - | - | - |
| KEEPS ITS TARGET | 1.4 | +40.8 | 76.5 | 60.5 | 2.6 | +78.3 | 174.0 | 122.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +74.5 | 122.6 | 40.1 | 2.4 | +101.9 | 179.2 | 52.1 |
| KILLS COUNT NEXT TURN | 4.6 | +158.2 | 114.0 | 114.8 | 7.5 | +264.8 | 302.7 | 194.6 |
| LONE CHARACTER SAFE SPOT | 0.3 | +20.5 | 8.8 | 16.1 | 0.3 | +10.4 | 0.0 | 4.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 11.2 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -2.3 | 22.6 | 8.1 | 0.7 | +2.2 | 27.1 | 17.0 |
| LOST CHARGE | 3.4 | -56.1 | 103.3 | 82.4 | 2.4 | -45.2 | 99.0 | 57.6 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.5 | 0.0 | 0.0 | 0.1 | -8.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +29.1 | 1.8 | 9.8 | 0.8 | +51.0 | 7.4 | 29.0 |
| MANOEUVRE | 0.1 | +2.4 | 0.0 | 4.7 | 0.2 | +4.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +11.4 | 0.0 | 0.0 | 0.4 | +12.8 | 0.0 | 18.0 |
| MARCH ODDS | 0.4 | +36.9 | 17.4 | 0.0 | 0.3 | +16.5 | 17.6 | 18.2 |
| MARCH OVER CASTS | 0.4 | +62.4 | 0.0 | 22.1 | 0.3 | +28.3 | 0.0 | 17.3 |
| MAX FOR POSITIONING | 5.0 | +158.8 | 0.0 | 121.5 | 4.4 | +185.5 | 0.0 | 170.5 |
| MISSILES IN THE MOVE | 4.1 | +110.2 | 0.0 | 73.3 | 3.0 | +56.2 | 0.0 | 138.0 |
| MISSILES NEXT TURN | 4.5 | +73.1 | 0.0 | 92.5 | 3.5 | +48.4 | 0.0 | 145.4 |
| MODEL FACING | 0.2 | +34.2 | 0.0 | 1.7 | 0.4 | +97.4 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 11.3 | 0.0 | 0.3 | +0.0 | 24.1 | 24.1 |
| MOVE AND CAST | 0.3 | +18.0 | 0.0 | 2.4 | 0.2 | +20.6 | 0.0 | 5.4 |
| MOVE SPELL IN RANGE | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -28.7 | 0.0 | 44.7 | 0.2 | -3.7 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 10.2 |
| MOVE TO CHARGE | 2.7 | +126.1 | 77.3 | 63.5 | 5.1 | +397.4 | 149.0 | 231.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +1.4 | 10.4 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -9.1 | 22.3 | 7.1 | 0.4 | -25.4 | 48.2 | 3.6 |
| NOT TURNED | 6.1 | +72.9 | 0.0 | 113.9 | 5.0 | +56.2 | 0.0 | 139.2 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 34.0 | 0.6 | -0.4 | 0.0 | 1.7 |
| OFF BEST | 15.6 | -717.4 | 0.0 | 245.1 | 16.4 | -860.1 | 11.5 | 326.6 |
| OPENS A LANE | 0.2 | +3.7 | 14.7 | 0.0 | 0.0 | +0.1 | 2.7 | 0.0 |
| OPENS UP | 0.1 | +17.5 | 8.4 | 0.0 | 0.1 | +7.9 | 3.1 | 5.4 |
| OVERRUNS AWAY | 0.5 | +6.9 | 58.7 | 10.9 | 0.6 | +10.9 | 58.0 | 35.5 |
| PATHS CROSS | 1.9 | +116.4 | 0.0 | 17.9 | 3.0 | +209.2 | 0.0 | 76.4 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 6.8 | 0.1 | -2.1 | 0.0 | 0.0 |
| PLAN RESULT | 37.3 | +1447.0 | 1527.6 | 1001.7 | 41.1 | +1169.3 | 1351.9 | 949.3 |
| PURSUES BIG PREY | 0.0 | -0.6 | 0.0 | 0.0 | 0.0 | -1.3 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +21.1 | 0.0 | 21.5 | 1.5 | +41.8 | 0.0 | 17.5 |
| RANDOM MOVER NO PROMISE | 0.2 | -20.4 | 2.0 | 5.8 | 0.2 | -10.1 | 13.1 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.6 | 0.0 | 0.8 | 0.2 | -8.2 | 0.0 | 4.9 |
| REDIRECT COUNTER | 1.9 | +124.6 | 0.0 | 56.9 | 3.3 | +240.1 | 0.0 | 61.8 |
| REDIRECT WEIGHED | 0.2 | +6.9 | 4.7 | 0.0 | 0.4 | -5.1 | 21.4 | 11.2 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 24.1 |
| RESERVE FALL BACK | 0.4 | +14.4 | 0.0 | 0.0 | 1.2 | +28.7 | 0.0 | 19.1 |
| RESTRAINS TO SHOOT | 0.1 | +6.4 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +58.8 | 248.9 | 96.9 | 3.5 | +83.1 | 281.0 | 86.4 |
| SAFER THAN THE JOB | 0.9 | +54.3 | 0.0 | 16.9 | 1.3 | +84.3 | 0.0 | 70.6 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.7 | 0.0 | 1.2 | 0.4 | -23.5 | 0.0 | 4.5 |
| SEARCH SPOT | 2.4 | +118.3 | 0.0 | 41.0 | 2.4 | +85.8 | 0.0 | 50.2 |
| SECOND HUNTER | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -0.4 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.1 | +7.0 | 0.0 | 20.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +40.0 | 13.1 | 12.2 | 2.3 | +177.2 | 46.5 | 65.9 |
| SET-UP ANY TARGET | 0.1 | +13.6 | 0.0 | 0.0 | 0.2 | +34.2 | 21.7 | 23.3 |
| SET-UP MISSED | - | - | - | - | 0.1 | +8.0 | 0.0 | 15.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +46.2 | 94.6 | 12.6 | 0.4 | +12.2 | 27.2 | 2.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 165.9 | 11.8 | 0.3 | +0.0 | 31.6 | 2.9 |
| SHOTS IN THE MOVE | 13.6 | +647.1 | 0.0 | 222.8 | 11.4 | +360.7 | 0.0 | 148.6 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +86.4 | 0.0 | 0.0 | 0.2 | +50.3 | 42.2 | 45.6 |
| SPELL WORTH | 1.1 | +30.6 | 36.1 | 23.1 | 1.7 | +29.3 | 85.8 | 93.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.8 | -5.6 | 49.3 | 24.0 |
| STABLE ROLE | 11.4 | +0.0 | 397.2 | 153.6 | 12.4 | +0.0 | 341.4 | 135.9 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.4 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.8 | 12.1 | 3.2 | 0.2 | +11.2 | 26.4 | 2.9 |
| STOPS SHORT OF THE FLANK | 0.5 | +27.6 | 0.0 | 5.1 | 0.3 | +20.5 | 0.0 | 32.1 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 5.8 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.1 | -45.7 | 340.4 | 115.1 | 6.9 | -46.6 | 368.6 | 60.2 |
| SUPPORTS | 4.1 | +45.9 | 176.0 | 57.0 | 4.4 | +47.9 | 184.5 | 25.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.1 | 2.0 | 0.0 | 0.2 | -4.5 | 18.5 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +4.6 | 0.0 | 0.0 | 1.0 | +0.8 | 6.9 | 36.7 |
| THROUGH LINE OF FIRE | 0.2 | +7.0 | 0.0 | 4.6 | 0.3 | +7.9 | 0.0 | 1.9 |
| TURN WORTH | 0.3 | -23.8 | 12.3 | 11.0 | 0.1 | -5.3 | 18.4 | 2.9 |
| TWO OR MORE ARRIVE | 0.2 | +0.9 | 0.0 | 3.8 | 0.4 | +2.3 | 0.0 | 9.0 |
| WAIT AFTER COSTS | 6.1 | -250.1 | 196.2 | 74.9 | 8.2 | -406.6 | 272.4 | 282.3 |
| WALKS TO THE FIGHT | 1.7 | +31.5 | 37.9 | 0.0 | 1.1 | +14.6 | 24.9 | 16.6 |
| WAR ENGINE CHARGES | 0.1 | +16.2 | 0.0 | 10.7 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 62.4 | 5.8 | 0.2 | +0.0 | 10.2 | 14.0 |
| WEARS DOWN | 1.3 | +56.6 | 100.6 | 64.9 | 1.7 | +56.7 | 192.8 | 62.8 |
| WHO HITS BACK | 0.2 | +28.8 | 0.0 | 3.8 | 0.3 | +20.6 | 0.0 | 12.9 |
| WHOLE FIGHT | 0.2 | +4.3 | 49.1 | 1.4 | 0.4 | +9.0 | 57.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +42.5 | 37.4 | 16.2 | 1.0 | +73.6 | 94.6 | 31.8 |
| WIDER SPREAD | - | - | - | - | 3.9 | -7.3 | 349.6 | 59.1 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 5.1 | 0.0 | 0.0 | +0.0 | 0.0 | 13.9 |

### Rule changes: cw-h2h-opp-3cc170f-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1151 | 1151 | 1151 | 31.97 | -56787 | -49.3 |
| BEST FIRST | 355 | 355 | 355 | 9.86 | +14685 | +41.4 |
| PATHS CROSS | 176 | 176 | 176 | 4.89 | +11722 | +66.6 |
| SEARCH SPOT | 173 | 173 | 171 | 4.75 | +7368 | +43.1 |
| COUNTER-CHARGE COVER | 620 | 337 | 150 | 4.17 | +8960 | +59.7 |
| MOVE TO CHARGE | 280 | 279 | 144 | 4.00 | +6982 | +48.5 |
| KILLS COUNT NEXT TURN | 436 | 435 | 141 | 3.92 | +4008 | +28.4 |
| FACES THE THREAT | 122 | 122 | 122 | 3.39 | +8735 | +71.6 |
| SUPPORTS | 306 | 306 | 121 | 3.36 | +1146 | +9.5 |
| FOLLOW UP WEIGHED | 83 | 83 | 83 | 2.31 | +11562 | +139.3 |
| SAFER THAN THE JOB | 80 | 80 | 80 | 2.22 | +4988 | +62.3 |
| FALLBACK BY WORTH | 351 | 351 | 78 | 2.17 | +4407 | +56.5 |
| SHOTS IN THE MOVE | 899 | 570 | 73 | 2.03 | +2510 | +34.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| WAIT AFTER COSTS | 516 | 515 | 66 | 1.83 | +1254 | +19.0 |
| RESERVE FALL BACK | 59 | 59 | 59 | 1.64 | +1554 | +26.3 |
| BEST OVERALL | 58 | 58 | 58 | 1.61 | +3747 | +64.6 |
| WALKS TO THE FIGHT | 100 | 100 | 52 | 1.44 | +717 | +13.8 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| BEST FACING | 51 | 51 | 51 | 1.42 | +1769 | +34.7 |
| CANNON PLANNED TARGET | 257 | 257 | 49 | 1.36 | -347 | -7.1 |
| RANDOM MOVE BY FIGURES | 81 | 81 | 47 | 1.31 | +2262 | +48.1 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +4050 | +90.0 |
| MAX FOR POSITIONING | 339 | 197 | 44 | 1.22 | +357 | +8.1 |
| SET UP TOGETHER | 108 | 95 | 44 | 1.22 | +3075 | +69.9 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| COMBAT PIVOT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KILLS COUNT | 145 | 144 | 39 | 1.08 | +1626 | +41.7 |
| REDIRECT COUNTER | 188 | 96 | 39 | 1.08 | +2193 | +56.2 |
| RISK BY ARC | 212 | 209 | 39 | 1.08 | +1095 | +28.1 |
| MISSILES IN THE MOVE | 253 | 135 | 38 | 1.06 | +722 | +19.0 |
| SHOT REPLANNED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| CHARGE NOW FIRST | 188 | 188 | 34 | 0.94 | -2154 | -63.3 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| MARCH CHECK | 39 | 37 | 33 | 0.92 | +1429 | +43.3 |
| BLOCKED WHEEL | 32 | 32 | 32 | 0.89 | +407 | +12.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 59 | 59 | 31 | 0.86 | +1090 | +35.2 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1733 | +57.8 |
| WHOLE FIGHT GAIN | 51 | 49 | 29 | 0.81 | +1443 | +49.8 |
| FRIENDS SHOTS CHECKED | 27 | 27 | 27 | 0.75 | +1507 | +55.8 |
| MODEL FACING | 25 | 25 | 25 | 0.69 | +4738 | +189.5 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| MARCH ODDS | 25 | 25 | 24 | 0.67 | +362 | +15.1 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +868 | +36.2 |
| BEST PREY | 65 | 65 | 22 | 0.61 | +418 | +19.0 |
| CHAFF PASSED | 21 | 21 | 21 | 0.58 | -48 | -2.3 |
| INVITES THE FIGHT | 94 | 94 | 21 | 0.58 | +336 | +16.0 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +538 | +25.6 |
| KEEPS ITS TARGET | 143 | 142 | 20 | 0.56 | +321 | +16.0 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +1256 | +66.1 |
| HONEST WORTH | 373 | 369 | 17 | 0.47 | +61 | +3.6 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +1389 | +81.7 |
| WEARS DOWN | 108 | 105 | 17 | 0.47 | +600 | +35.3 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CAST JOB | 26 | 26 | 14 | 0.39 | +195 | +13.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| LOST CHARGE | 207 | 206 | 12 | 0.33 | +525 | +43.8 |
| MAKE SURE TOGETHER | 44 | 32 | 12 | 0.33 | +697 | +58.1 |
| CASTING BLOCK | 15 | 15 | 11 | 0.31 | +451 | +41.0 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -70 | -7.0 |
| CHARGE BAND | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| HUNT IN PAIRS | 37 | 18 | 10 | 0.28 | +1196 | +119.7 |
| MANOEUVRE | 11 | 11 | 10 | 0.28 | +235 | +23.5 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -276 | -27.6 |
| WAR ENGINE JOBS | 32 | 32 | 10 | 0.28 | -649 | -64.9 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +280 | +35.0 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -478 | -68.3 |
| OPENS UP | 9 | 9 | 7 | 0.19 | +501 | +71.6 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| MISSILES NEXT TURN | 286 | 156 | 6 | 0.17 | +12 | +1.9 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -120 | -20.1 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +68 | +13.6 |
| SUPPORT NARROWED | 467 | 467 | 5 | 0.14 | -84 | -16.8 |
| DEFENSIVE ARMY | 18 | 18 | 4 | 0.11 | -58 | -14.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +276 | +69.1 |
| BACKUP TARGETS | 62 | 35 | 3 | 0.08 | +32 | +10.6 |
| HUNT ADVANCE | 16 | 16 | 3 | 0.08 | +40 | +13.3 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 38 | 37 | 3 | 0.08 | +34 | +11.4 |
| SURE REACH TOGETHER | 59 | 38 | 3 | 0.08 | +48 | +16.0 |
| WHOLE FIGHT | 21 | 21 | 3 | 0.08 | +312 | +103.9 |
| WIDER SPREAD | 142 | 137 | 3 | 0.08 | +16 | +5.4 |
| BLOWS WHERE AIMED | 13 | 13 | 2 | 0.06 | +206 | +103.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +41 | +20.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -72 | -36.2 |
| JOINT CHARGE PLAN | 10 | 10 | 2 | 0.06 | +72 | +36.2 |
| LONG SHOT | 38 | 37 | 2 | 0.06 | +17 | +8.3 |
| MOVE SPELL IN RANGE | 3 | 3 | 2 | 0.06 | +31 | +15.4 |
| OPENS A LANE | 9 | 8 | 2 | 0.06 | +21 | +10.4 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -70 | -34.9 |
| REFUSING RETIRES | 6 | 6 | 2 | 0.06 | -0 | -0.2 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -69 | -34.3 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +248 | +124.2 |
| CARRIES OUT COUNTER | 5 | 5 | 1 | 0.03 | -47 | -47.0 |
| EDGE GIVE GROUND | 18 | 17 | 1 | 0.03 | +10 | +10.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +13.7 |
| HILL BY ITS CHANCE | 34 | 34 | 1 | 0.03 | +34 | +33.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +143 | +142.6 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | -4 | -4.0 |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 1 | 0.03 | +5 | +5.4 |
| SPELLS IN THE FIGHT | 27 | 26 | 1 | 0.03 | +23 | +23.1 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| STOPS | 9 | 9 | 1 | 0.03 | +21 | +21.3 |
| TWO OR MORE ARRIVE | 21 | 19 | 1 | 0.03 | +10 | +10.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 41 | 41 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 11 | 11 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 22 | 20 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 391 | not checked | - | - | - | - |
| GIVES UP | 5 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 12 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 397 | 397 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| PLAN RESULT | 2822 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 101 | not checked | - | - | - | - |
| STABLE ROLE | 855 | 850 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cw-h2h-opp-3cc170f-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.39 | 14.42 | 51.9 |
| TURN GATE | gate | 0.83 | 0.69 | 31.8 |
| FALLBACK | gate | 0.72 | 0.75 | 35.5 |
| CHARGE NOW FIRST | rule | 0.47 | 0.47 | 63.3 |
| CANNON PLANNED TARGET | rule | 0.19 | 0.19 | 27.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.17 | 40.3 |
| AFTERMATH BAND | gate | 0.22 | 0.06 | 2.2 |
| PATHS CROSS | rule | 0.14 | 0.14 | 33.8 |
| WAR ENGINE JOBS | rule | 0.19 | 0.08 | 64.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.14 | 30.6 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.08 | 43.7 |
| BEST PRIZE | rule | - | 0.19 | 68.3 |
| CHAFF PASSED | rule | 0.11 | 0.08 | 6.8 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.06 | 13.0 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.11 | 20.1 |
| SUPPORT REQUEST | gate | 0.03 | 0.14 | 49.5 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 2.0 |
| NO REASON | gate | - | 0.14 | 4.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | - | 86.8 |
| DEFENSIVE ARMY | rule | 0.08 | 0.03 | 14.5 |
| MARCH ODDS | rule | 0.03 | 0.08 | 9.3 |
| REDIRECT WEIGHED | rule | - | 0.11 | 34.6 |
| SUPPORT NARROWED | rule | 0.08 | 0.03 | 21.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 25.0 |
| FACES THE THREAT | rule | 0.06 | 0.03 | 12.8 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 13.2 |
| CATCH ODDS | rule | - | 0.06 | 36.2 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 34.9 |
| STANDS TO CAST | rule | - | 0.06 | 34.3 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 42.1 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 47.0 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.9 |
| MOVE AND CAST | rule | 0.03 | - | 60.2 |
| PURSUES ON | rule | - | 0.03 | 4.0 |

### Plans: cw-h2h-opp-3cc170f-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.1 | 17% | 511 | 333 | 65% |
| Mine | charge | 3.2 | 64% | 297 | 270 | 91% |
| Mine | close in | 3.5 | 18% | 176 | 74 | 42% |
| Mine | hold | 4.5 | 30% | 313 | 0 | 0% |
| Mine | join | 0.7 | 96% | 22 | 0 | 0% |
| Mine | shoot | 8.2 | 65% | 272 | 770 | 283% |
| Mine | support | 4.2 | 89% | 30 | 0 | 0% |
| Opponent | advance | 13.9 | 17% | 353 | 321 | 91% |
| Opponent | charge | 4.9 | 55% | 397 | 433 | 109% |
| Opponent | close in | 7.0 | 26% | 447 | 149 | 33% |
| Opponent | hold | 4.6 | 39% | 330 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 41 | 0 | 0% |
| Opponent | shoot | 4.8 | 60% | 155 | 266 | 171% |
| Opponent | support | 5.0 | 90% | 37 | 0 | 0% |

### Packages: hunt the guns, cw-h2h-opp-3cc170f-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 40% | 20% | 0% | 2.0 | 270 | 91 | 20% | 39 |
| Opponent | 0.3 | 12 | 1 | 36% | 36% | 0% | 2.5 | 370 | 162 | 36% | 103 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 270 | 0 | 0% | 41 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 460 | 453 | 100% | 67 |
| Empire of Man | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 129 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 434 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 2.0 | 8 | 0 | 50% | 50% | 0% | 2.5 | 397 | 223 | 50% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 250 |
| Tomb Kings of Khemri | 0.8 | 4 | 0 | 0% | 0% | 0% | - | 208 | 0 | 0% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 446 | 0 | 0% | 71 |

### Battle groups: cw-h2h-opp-3cc170f-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.8 | 24% | 43% | 18% | 18% | 27% | 18% | 16% | 39% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 41% | 64% | 14% | 25% | 4% | 0% | 17% | 79% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.4 | 25% | 67% | 12% | 57% | 37% | 8% | 10% | 45% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 69% | 19% | 29% | 7% | 3% | 17% | 52% | 21% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cw-h2h-opp-3cc170f-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 20% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 33 | 104 (33) | 62 | 42 | 62 | 30% | 2.7 | 97 (18) | 237 (7) | 5 (8) | 123 (22) | 63 (11) |
| Mine | Character | 123 | 50 (123) | 49 | 1 | 32 | 19% | 2.5 | 61 (40) | 49 (52) | 22 (14) | 54 (56) | 50 (50) |
| Mine | Clean-up | 21 | 70 (21) | 39 | 31 | 53 | 10% | 3.4 | 57 (5) | 81 (13) | 55 (3) | 97 (13) | 42 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 45 (46) | 23 | 22 | 55 | 24% | 2.9 | 32 (22) | 74 (16) | 38 (8) | 47 (29) | 43 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 34 (57) | 24 | 10 | 40 | 23% | 2.5 | 2 (18) | 46 (29) | 63 (10) | 44 (38) | 19 (19) |
| Mine | Holder | 28 | 65 (28) | 10 | 55 | 29 | 46% | 2.6 | 71 (9) | 103 (9) | 12 (9) | 90 (17) | 29 (10) |
| Mine | Shooter | 44 | 69 (44) | 30 | 40 | 45 | 7% | 1.5 | 61 (7) | 74 (30) | 59 (7) | 89 (26) | 42 (18) |
| Mine | Support | 2 | 78 (2) | 78 | 0 | 0 | 50% | 6.0 | 233 (1) | 0 (1) | - | - | 78 (2) |
| Mine | War machine | 59 | 52 (59) | 52 | 0 | 53 | 2% | 1.2 | 4 (10) | 66 (37) | 40 (12) | 47 (10) | 53 (49) |
| Mine | Wizard | 22 | 8 (22) | 8 | 0 | 42 | 27% | 2.1 | 0 (6) | 39 (6) | 0 (5) | 0 (5) | 14 (12) |
| Opponent | Blocker | 2 | 85 (2) | 85 | 0 | 38 | 0% | 3.5 | 137 (1) | 0 (1) | - | 137 (1) | 0 (1) |
| Opponent | Chaff | 76 | 41 (76) | 20 | 22 | 52 | 42% | 2.5 | 45 (32) | 34 (19) | 43 (25) | 56 (54) | 6 (22) |
| Opponent | Character | 97 | 53 (97) | 53 | 0 | 36 | 22% | 2.4 | 71 (42) | 39 (38) | 61 (9) | 56 (61) | 60 (28) |
| Opponent | Clean-up | 19 | 38 (19) | 31 | 6 | 41 | 26% | 3.0 | 29 (9) | 52 (10) | - | 45 (14) | 16 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 40 (48) | 28 | 12 | 48 | 19% | 2.6 | 34 (22) | 32 (16) | 69 (10) | 36 (28) | 47 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 81 | 20% | 2.2 | - | 0 (3) | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Hammer | 70 | 31 (70) | 25 | 5 | 41 | 17% | 3.2 | 44 (17) | 24 (42) | 47 (11) | 31 (43) | 30 (27) |
| Opponent | Holder | 35 | 90 (35) | 6 | 84 | 23 | 37% | 3.0 | 95 (8) | 87 (21) | 99 (6) | 120 (23) | 25 (12) |
| Opponent | Shooter | 33 | 98 (33) | 13 | 86 | 16 | 3% | 1.8 | 32 (8) | 130 (19) | 70 (6) | 133 (22) | 46 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 49 (24) | 49 | 0 | 20 | 8% | 1.5 | 21 (6) | 56 (14) | 62 (4) | 0 (3) | 57 (21) |
| Opponent | Wizard | 26 | 21 (26) | 21 | 0 | 50 | 8% | 1.4 | 0 (10) | 81 (4) | 32 (5) | 63 (6) | 4 (13) |

### Charged fights: cw-h2h-opp-3cc170f-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 85 | 234 | 2.8 | 1.2 | 85 | 15 | +70 | 1 of 11 | 9 of 11 | +60 | +72 |
| Mine | Chaos Dwarfs | 4 | 227 | 111 | 2.2 | 1.2 | 49 | 0 | +49 | 4 of 9 | 7 of 9 | +0 | +63 |
| Mine | Dwarfen Mountain Holds | 4 | 688 | 204 | 2.2 | 1.4 | 91 | 11 | +80 | 2 of 9 | 7 of 9 | +13 | +114 |
| Mine | Empire of Man | 5 | 566 | 96 | 2.2 | 1.1 | 44 | 65 | -22 | 6 of 11 | 6 of 11 | -124 | -12 |
| Mine | Grand Cathay | 4 | 255 | 469 | 3.2 | 1.1 | 144 | 0 | +144 | 3 of 13 | 12 of 13 | +0 | +156 |
| Mine | High Elf Realms | 4 | 114 | 744 | 5.2 | 1.1 | 142 | 5 | +136 | 9 of 21 | 17 of 21 | +117 | +138 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 525 | 7.0 | 1.0 | 75 | 31 | +44 | 1 of 7 | 6 of 7 | - | +44 |
| Mine | Lizardmen | 1 | 45 | 1039 | 3.0 | 1.3 | 346 | 0 | +346 | 1 of 3 | 3 of 3 | +853 | +93 |
| Mine | Ogre Kingdoms | 1 | 0 | 45 | 4.0 | 1.0 | 11 | 83 | -72 | 1 of 4 | 1 of 3 | - | -72 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 332 | 4.0 | 1.2 | 83 | 14 | +69 | 1 of 4 | 4 of 4 | +45 | +77 |
| Mine | Skaven | 2 | 0 | 248 | 2.5 | 1.0 | 99 | 39 | +60 | 2 of 5 | 4 of 5 | - | +60 |
| Mine | Tomb Kings of Khemri | 1 | 125 | 909 | 7.0 | 1.1 | 130 | 0 | +130 | 1 of 7 | 7 of 7 | +432 | +80 |
| Mine | Vampire Counts | 3 | 121 | 175 | 4.7 | 1.1 | 38 | 96 | -58 | 6 of 14 | 5 of 14 | -196 | -35 |
| Mine | Warriors of Chaos | 1 | 0 | 190 | 1.0 | 1.0 | 190 | 0 | +190 | 0 of 1 | 1 of 1 | - | +190 |
| **Mine** | all armies | 36 | 245 | 322 | 3.3 | 1.1 | 97 | 27 | +70 | 38 of 119 | 89 of 118 | +75 | +69 |
| Opponent | Dwarfen Mountain Holds | 2 | 192 | 70 | 3.0 | 1.0 | 23 | 39 | -16 | 1 of 6 | 4 of 6 | - | -16 |
| Opponent | Empire of Man | 2 | 360 | 46 | 2.5 | 1.2 | 18 | 76 | -58 | 3 of 5 | 3 of 5 | +91 | -95 |
| Opponent | Grand Cathay | 2 | 355 | 533 | 2.5 | 1.6 | 213 | 76 | +137 | 4 of 5 | 4 of 5 | +187 | +104 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 1 of 2 | 2 of 2 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 76 | 278 | 4.7 | 1.3 | 60 | 25 | +35 | 4 of 14 | 10 of 14 | +105 | +16 |
| Opponent | Skaven | 1 | 391 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 64 | 652 | 4.0 | 1.1 | 163 | 103 | +60 | 7 of 16 | 11 of 16 | +290 | +45 |
| Opponent | Vampire Counts | 6 | 30 | 698 | 4.2 | 1.2 | 167 | 29 | +139 | 12 of 25 | 18 of 25 | +95 | +153 |
| Opponent | Warriors of Chaos | 8 | 8 | 364 | 2.4 | 1.4 | 153 | 8 | +145 | 8 of 19 | 15 of 19 | +255 | +80 |
| Opponent | Wood Elf Realms | 7 | 79 | 677 | 4.9 | 1.1 | 139 | 10 | +129 | 11 of 34 | 27 of 34 | +345 | +100 |
| **Opponent** | all armies | 36 | 103 | 464 | 3.5 | 1.2 | 132 | 33 | +99 | 51 of 126 | 94 of 126 | +200 | +75 |

### Effective charges: cw-h2h-opp-3cc170f-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 11 | 1 (net +122) | 0 | 2 (net -32) | 6 (net +13) | 0 | 1 (net +120) | 1 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 9 | 2 (net +0) | 0 | 0 | 2 (net +0) | 1 (net +0) | 4 (net +111) | 0 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 9 | 0 | 0 | 2 (net +21) | 1 (net +0) | 0 | 6 (net +113) | 0 | 22% (2 of 9) |
| Mine | Empire of Man | 11 | 3 (net +35) | 0 | 2 (net -132) | 2 (net +0) | 1 (net +45) | 2 (net -62) | 1 | 20% (2 of 10) |
| Mine | Grand Cathay | 13 | 1 (net +758) | 0 | 1 (net +598) | 3 (net +13) | 3 (net +13) | 5 (net +88) | 0 | 8% (1 of 13) |
| Mine | High Elf Realms | 21 | 1 (net +0) | 1 (net +0) | 4 (net +46) | 3 (net +212) | 3 (net +62) | 7 (net +220) | 2 | 21% (4 of 19) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 1 (net +0) | 3 (net +147) | 1 (net +85) | 2 (net -107) | 0 | 14% (1 of 7) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 2 (net +520) | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 2 (net +139) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 1 (net +270) | 1 (net +0) | 0 | 2 (net +15) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +102) | 0 | 2 (net +278) | 3 (net +37) | 1 | 17% (1 of 6) |
| Mine | Vampire Counts | 14 | 3 (net -214) | 0 | 3 (net -17) | 5 (net -79) | 1 (net +0) | 2 (net +137) | 0 | 21% (3 of 14) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +190) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 6 | 1 (net -128) | 0 | 2 (net -52) | 2 (net +70) | 0 | 0 | 1 | 40% (2 of 5) |
| Opponent | Empire of Man | 5 | 1 (net +0) | 0 | 3 (net -127) | 0 | 1 (net +91) | 0 | 0 | 60% (3 of 5) |
| Opponent | Grand Cathay | 5 | 2 (net +149) | 0 | 2 (net +42) | 1 (net +304) | 0 | 0 | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 14 | 5 (net +91) | 0 | 2 (net -52) | 1 (net +0) | 0 | 3 (net +85) | 3 | 18% (2 of 11) |
| Opponent | Tomb Kings of Khemri | 16 | 4 (net -76) | 0 | 1 (net +310) | 5 (net +37) | 0 | 1 (net +91) | 5 | 9% (1 of 11) |
| Opponent | Vampire Counts | 25 | 3 (net +504) | 2 (net +0) | 4 (net +194) | 9 (net +19) | 3 (net +152) | 2 (net +128) | 2 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 19 | 1 (net +0) | 1 (net +563) | 5 (net +96) | 2 (net +72) | 1 (net +95) | 6 (net +141) | 3 | 31% (5 of 16) |
| Opponent | Wood Elf Realms | 34 | 5 (net +179) | 0 | 5 (net +184) | 8 (net +124) | 1 (net +246) | 10 (net +73) | 5 | 17% (5 of 29) |

### Charged fights, damage counted: cw-h2h-opp-3cc170f-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 248 | 295 | +29 | 124 | 107 | +17 | +6.7 |
| Mine | 50-54% | 1 | 497 | 201 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 19 | 242 | 238 | +58 | 131 | 59 | +73 | +30.1 |
| Mine | 76-89% | 28 | 220 | 183 | +66 | 116 | 33 | +83 | +37.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 242 | 172 | +100 | 142 | 19 | +122 | +50.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 391 | 94 | +70 | 86 | 2 | +84 | +21.5 |
| Mine | No odds | 11 | 246 | 149 | +62 | 117 | 35 | +82 | +33.2 |
| Mine | All fights | 119 | 256 | 187 | +70 | 123 | 37 | +85 | +33.4 |
| Opponent | Long shot (under 50%) | 22 | 275 | 258 | +124 | 212 | 86 | +125 | +45.6 |
| Opponent | 50-54% | 3 | 548 | 266 | +188 | 188 | 0 | +188 | +34.2 |
| Opponent | Effective (55-75%) | 24 | 257 | 210 | +83 | 151 | 61 | +91 | +35.2 |
| Opponent | 76-89% | 28 | 239 | 203 | +69 | 135 | 50 | +84 | +35.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 281 | 165 | +95 | 116 | 22 | +94 | +33.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 548 | 129 | +148 | 182 | 32 | +150 | +27.3 |
| Opponent | No odds | 20 | 217 | 195 | +110 | 159 | 36 | +123 | +56.6 |
| Opponent | All fights | 126 | 275 | 204 | +99 | 155 | 49 | +106 | +38.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cw-h2h-opp-3cc170f-p2 | move | 431 | 97 (23%) | 76 (18%) | 58 (13%) | 276 (64%) |
| cw-h2h-opp-3cc170f-p2 | objective | 382 | 56 (15%) | 38 (10%) | 45 (12%) | 281 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: wfr-a92c160-p45

### Scorecard: wfr-a92c160-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 2 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 6 | 1 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 2 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1727 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 3.0 | 1.5 | 3.5 | 1.0 | 0.0 | 0.0 | 0.0 | 100.0 |
| **Average** | | | Opponent | 0% | 1.0 | 3.0 | 2.0 | 1.5 | 1.5 | 0.0 | 0.0 | 170.0 |

### KPIs: wfr-a92c160-p45

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 14) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 92% (11 of 12); on the table 92% | 67% (2 of 3); on the table 67% | 87% (13 of 15); on the table 87% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 81% (13 of 16); on the table 81% | 75% (3 of 4); on the table 75% | 80% (16 of 20); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 20% (2 of 10) | 20% (2 of 10) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 33% (2 of 6) | 33% (2 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 40% (1620 of 4000) | 40% (1596 of 3999) | 40% (3216 of 7999) |
|   infantry points that never fought | lower | 43% (409 of 959) | 35% (238 of 681) | 39% (647 of 1640) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (7 of 13) | 74% (14 of 19) | 66% (21 of 32) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2056 of 3520) | 59% (2306 of 3884) | 59% (4362 of 7404) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (50%) | 1.3 (50%) |
| GONE: slain | - | 1.3 (50%) | 1.3 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.7 | 1.0 | 0.7 | 2.0 |
| not cast | 4.7 | 0.3 | 1.0 | 2.7 | 14.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (50%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (50%) | 1.7 (12%) |
| STUPIDITY: Stupidity | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (7%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (86%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (31 of 53) | 12% (1 of 8) | 52% (32 of 61) |
|   cavalry | 78% (7 of 9) | 20% (1 of 5) | 57% (8 of 14) |
|   character | 30% (3 of 10) | 0% (0 of 3) | 23% (3 of 13) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 47% (8 of 17) | - | 47% (8 of 17) |
|   war machine | 100% (11 of 11) | - | 100% (11 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (45%) | 0.0 (0%) | 3.3 (34%) |
| CHARGED: it charged | 1.7 (23%) | 1.0 (43%) | 2.7 (28%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 1.7 (23%) | 1.3 (57%) | 3.0 (31%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.3 | 88% | 0.8 pts | 2 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 3.7 | 1.3 | 64% | 14.1 pts | 52 pts |
| war machine | 3.7 | 3.3 | 55% | 27.9 pts | 102 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.3 | 4.2 |
| Charges that made contact a game | 3.0 | 3.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 0.33 declared, 0.33 contact (3 units) | 0.29 declared, 0.29 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.40 contact (20 units) | 0.60 declared, 0.40 contact (20 units) | 0.57 declared, 0.40 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 67% (2 of 3) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 75% (3 of 4) | 100% (2 of 2) | 50% (3 of 6) | 67% (8 of 12) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 67% (4 of 6) | 0% (0 of 3) | - | 44% (4 of 9) |
| Monster | 100% (3 of 3) | - | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 91% (10 of 11); on the table 91% | - | 48% | 43% (3 of 7) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 60% (3 of 5); on the table 60% | - | 33% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 75% (3 of 4); on the table 75% | 33% (2 of 6) | 40% | 74% (14 of 19) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 75% (6) | 80% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 25% (2 of 8) | 54% (7 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (12 of 22) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | - |
| Strategy | Lone characters that fought | 60% (3 of 5) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.5 |
| Movement | Points that never moved of their own | 100.0 | 170.0 |
| Movement | Fights charged into per game | 3.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net -835 | 1 of 3, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +246 | 2 of 3, net +122 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.3 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 0% (0 of 4) |
| Shooting | Points destroyed by shooting units | 38.7 | 0.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (4 of 11) | - |
| Shooting | Points destroyed by war machines | 155.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 2.3 | 1.0 |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.3 / 0.3 / 0.0 | 0.3 / 0.0 / 1.3 / 0.0 |
| Combat | Points destroyed in combat | 285.7 | 248.7 |
| Combat | Points run down | 10.0 | 148.0 |
| Combat | Net points per charged fight, damage counted | +94 | +57 |
| Combat | Net per 100 charger points, damage counted | +23.9 | +32.4 |
| Combat | First round won (charged fights) | 83% | 50% |
| Combat | Net points per charged fight | +4 | +61 |
| Combat | Net points per supported fight / lone fight | - / +4 | +0 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 6 | 2 of 4 |
| Game | Points lost | 550.0 | 706.0 |
| Game | VP from objectives | 835.0 | 530.0 |
| Game | Lone holders (player turns) | 3.0 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +516 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1256
- Games not ended: 1 (L1727-1); findings 2, warnings 0

### Opponent rules: wfr-a92c160-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +45.2 | 0.0 | 0.0 | 0.3 | +116.8 | 0.0 | 0.0 |
| ARMY TABLE | 16.7 | +386.7 | 0.0 | 46.7 | 21.0 | -676.4 | 0.0 | 155.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 1.3 | +7.1 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.7 | +109.8 | 155.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.7 | +11.5 | 195.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +66.9 | 0.0 | 0.0 | 1.3 | +39.7 | 0.0 | 20.0 |
| CHAFF PASSED | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +73.4 | 0.0 | 91.7 | 0.7 | +9.6 | 0.0 | 155.0 |
| CHARGE LOSSES | 5.0 | -323.0 | 0.0 | 176.0 | 16.0 | -1292.8 | 0.0 | 440.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 65.0 | 0.0 | 2.3 | +0.0 | 118.3 | 10.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 176.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 157.0 | 0.7 | +0.0 | 0.0 | 56.7 |
| COVER ONCE | 7.7 | -484.5 | 0.0 | 20.0 | 7.7 | -830.2 | 0.0 | 65.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -23.7 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +7.2 | 121.7 | 157.0 | 3.3 | -0.6 | 60.0 | 10.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.7 |
| FALL BACK GOOD ORDER | 2.3 | +0.5 | 65.0 | 0.0 | 3.3 | +9.2 | 26.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.7 | +272.9 | 0.0 | 258.7 |
| FEATURE BUFFS | 2.3 | +23.0 | 0.0 | 0.0 | 2.7 | +219.4 | 0.0 | 0.0 |
| FIGHT LIFT | 1.0 | +47.8 | 245.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +10.9 | 130.0 | 0.0 | 2.0 | +17.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 73.7 | +5199.6 | 701.7 | 716.3 | 69.3 | +3632.8 | 151.7 | 450.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 88.0 | 10.0 | +0.0 | 0.0 | 96.7 |
| FOLLOW UP WEIGHED | 3.3 | +461.3 | 0.0 | 157.0 | 0.3 | +141.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +304.8 | 186.7 | 157.0 | 4.7 | +186.4 | 151.7 | 10.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 53.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -9.7 | 0.0 | 20.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| GIVES UP | 1.7 | -17.6 | 121.7 | 157.0 | 0.7 | -3.0 | 0.0 | 0.0 |
| GOAL WALK | 10.7 | +869.0 | 0.0 | 0.0 | 7.7 | +579.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 53.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 176.0 | 12.0 | +0.0 | 0.0 | 130.0 |
| HIS CHARGE DENIED | 1.0 | +9.0 | 65.0 | 157.0 | 0.3 | +5.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 1.0 | -19.1 | 0.0 | 0.0 | 6.0 | -96.7 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 32.7 | +5.7 | 188.7 | 0.0 | 36.0 | +10.0 | 589.7 | 0.0 |
| HIS MOVE WHY | 12.0 | +0.0 | 0.0 | 40.0 | 24.7 | +0.0 | 0.0 | 165.0 |
| HIS ONE MOVE | 20.3 | +65.5 | 0.0 | 203.3 | 20.7 | -101.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 65.0 |
| HIS RANDOM MOVE | 13.3 | +0.0 | 0.0 | 249.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 229.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 3.7 | +60.3 | 0.0 | 176.0 | 30.3 | +557.1 | 0.0 | 440.0 |
| HIS SHOTS BY HIS RUN | 9.3 | +166.1 | 0.0 | 53.3 | 38.3 | +1111.1 | 0.0 | 440.0 |
| HIS TURN DENIED | 0.3 | +10.3 | 65.0 | 0.0 | 1.7 | +8.9 | 0.0 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 53.3 | 12.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.3 | +557.0 | 0.0 | 53.3 | 7.0 | +588.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -38.6 | 56.7 | 0.0 | 4.0 | -131.7 | 151.7 | 0.0 |
| HUNT KEPT | 0.3 | +5.5 | 65.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.3 | +81.7 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +92.9 | 65.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 13.3 | -189.4 | 0.0 | 155.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.3 | +70.5 | 0.0 | 10.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 15.7 | +0.0 | 386.7 | 573.7 | 6.0 | +0.0 | 333.0 | 387.3 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +6.0 | 0.0 | 0.0 | 1.3 | +5.3 | 91.7 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | +2.7 | 130.0 | 157.0 | 2.0 | +0.9 | 0.0 | 10.0 |
| MAKE SURE TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | -16.7 | 0.0 | 0.0 | 1.7 | +67.1 | 0.0 | 10.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +14.1 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +178.6 | 0.0 | 0.0 | 0.3 | +41.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +22.1 | 0.0 | 26.7 | 3.3 | +105.3 | 0.0 | 10.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +35.2 | 0.0 | 0.0 | 1.3 | +37.3 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.3 | +29.5 | 0.0 | 0.0 | 2.3 | +20.9 | 0.0 | 65.0 |
| MOVE ORDER | 1.0 | +0.0 | 20.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +416.5 | 0.0 | 203.3 | 8.7 | +671.9 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +369.1 | 0.0 | 114.7 | 5.0 | +199.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +148.9 | 0.0 | 0.0 | 3.3 | +315.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -30.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -206.8 | 186.7 | 157.0 | 3.3 | -116.8 | 151.7 | 10.0 |
| NO LATE CUT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -391.9 | 121.7 | 33.3 | 4.3 | -160.3 | 0.0 | 10.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.7 | -21.8 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 38.7 |
| ONE FIGHT FORMULA | 5.0 | -135.5 | 0.0 | 111.7 | 5.7 | -118.7 | 0.0 | 220.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.3 | +24.6 | 0.0 | 10.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -19.9 | 0.0 | 26.7 | 2.3 | +45.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +0.4 | 20.0 | 65.0 |
| OPENS UP | - | - | - | - | 1.0 | +62.7 | 60.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.4 | 0.0 | 0.0 | 1.0 | +2.4 | 33.3 | 0.0 |
| PATHS CROSS | 0.7 | +10.5 | 0.0 | 0.0 | 0.7 | +7.8 | 0.0 | 0.0 |
| PLAN RESULT | 33.0 | +507.6 | 160.3 | 656.3 | 37.0 | +239.4 | 0.0 | 284.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 13.0 | -325.1 | 0.0 | 183.3 | 9.3 | -211.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -1.2 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -8.3 | 0.0 | 20.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.7 | +1823.5 | 0.0 | 66.7 | 13.0 | +1753.2 | 125.0 | 10.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +104.1 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +17.2 | 0.0 | 20.0 |
| REDIRECT COUNTER | 1.7 | +20.9 | 0.0 | 26.7 | 1.7 | +199.4 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 0.7 | +12.7 | 0.0 | 10.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -70.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 88.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +71.8 | 130.0 | 0.0 | 4.0 | -9.5 | 60.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -30.4 | 0.0 | 0.0 | 2.0 | -24.6 | 60.0 | 0.0 |
| RUN DOWN | 2.3 | -137.2 | 130.0 | 0.0 | 3.7 | -8.3 | 60.0 | 10.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | -42.5 | 0.0 | 0.0 | 1.0 | +49.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +24.8 | 121.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +86.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.3 | -39.4 | 0.0 | 0.0 | 0.3 | -3.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.3 | +1.3 | 0.0 | 0.0 | 1.7 | +6.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 33.3 | 2.3 | +0.0 | 0.0 | 48.7 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +68.8 | 0.0 | 0.0 | 1.3 | +2.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.3 | 65.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 3.0 | -33.6 | 0.0 | 0.0 | 16.7 | -298.3 | 0.0 | 310.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 12.3 | +367.0 | 0.0 | 60.0 | 0.7 | +14.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +113.6 | 333.0 | 0.0 | 1.7 | +4.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | -3.9 | 0.0 | 157.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 91.7 | 9.7 | +0.0 | 0.0 | 75.0 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -4.1 | 26.7 | 10.0 |
| STANDS STILL | 25.3 | +0.0 | 515.0 | 106.7 | 9.3 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 13.7 | -31.0 | 195.0 | 0.0 | 0.3 | +5.0 | 0.0 | 0.0 |
| STOPS | 0.7 | +10.3 | 130.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +194.1 | 0.0 | 53.3 | 4.7 | +558.7 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 65.0 | 0.0 | 1.7 | +0.0 | 0.0 | 20.0 |
| SUPPORT WORKED OUT | 4.3 | +194.1 | 0.0 | 53.3 | 4.7 | +558.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 91.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 88.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 88.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.7 | +0.0 | 0.0 | 279.7 | 32.0 | +0.0 | 0.0 | 268.7 |
| TIED UP BY THE SUM | 1.3 | +137.3 | 121.7 | 0.0 | 1.3 | +220.1 | 26.7 | 0.0 |
| TIME ON OUR SIDE | 37.0 | +468.5 | 65.0 | 462.3 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -1.4 | 0.0 | 0.0 | 0.7 | -11.2 | 0.0 | 10.0 |
| WHO HITS BACK | 0.7 | +35.7 | 0.0 | 0.0 | 0.3 | +90.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -258.9 | 0.0 | 176.0 | 3.0 | -701.7 | 0.0 | 130.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.3 | +44.5 | 0.0 | 10.0 |
| WHOLE FIGHT REACTION | 2.7 | +196.0 | 0.0 | 33.3 | - | - | - | - |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +1.9 | 0.0 | 0.0 | 4.0 | +233.2 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 206 | 206 | 159 | 53.00 | +0 | +0.0 |
| HIS MOVE WHY | 110 | 110 | 74 | 24.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 65 | 65 | 65 | 21.67 | +0 | +0.0 |
| ARMY TABLE | 113 | 113 | 61 | 20.33 | +799 | +13.1 |
| HOLDER ASSIGNMENT | 43 | 43 | 40 | 13.33 | +3261 | +81.5 |
| HIS ONE MOVE | 123 | 114 | 33 | 11.00 | +0 | +0.0 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1657 | -50.2 |
| FIVE ACTION | 429 | 407 | 32 | 10.67 | +997 | +31.2 |
| HIS SHOTS BY HIS RUN | 143 | 136 | 29 | 9.67 | +370 | +12.8 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 29 | 9.67 | -1611 | -55.5 |
| MOVE TO CHARGE COMPUTED | 49 | 38 | 26 | 8.67 | +1013 | +39.0 |
| THE TABLE AGAIN | 32 | 32 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| THE RISK READS HIS RUN | 32 | 32 | 18 | 6.00 | +0 | +0.0 |
| HIS SHOT LIST | 102 | 92 | 15 | 5.00 | +176 | +11.8 |
| QUARTER ODDS | 80 | 72 | 13 | 4.33 | +1470 | +113.0 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 3.67 | +1807 | +164.3 |
| FOUR ROUNDS | 24 | 22 | 10 | 3.33 | +475 | +47.5 |
| GOAL WALK | 55 | 55 | 10 | 3.33 | +413 | +41.3 |
| NEXT CHARGE BY LIST | 20 | 18 | 9 | 3.00 | +517 | +57.5 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +312 | +34.7 |
| SUPPORT ADDS | 27 | 25 | 9 | 3.00 | +446 | +49.6 |
| SUPPORT WORKED OUT | 27 | 25 | 9 | 3.00 | +446 | +49.6 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 8 | 2.67 | +6 | +0.7 |
| SHOT RISK POINTS | 59 | 56 | 8 | 2.67 | +204 | +25.6 |
| WHOLE FIGHT DANGER | 21 | 21 | 8 | 2.67 | +751 | +93.9 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 46 | 32 | 7 | 2.33 | +238 | +34.0 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +212 | +30.2 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| RISK BY ARC | 19 | 18 | 7 | 2.33 | +127 | +18.1 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +2 | +0.4 |
| TIED UP BY THE SUM | 8 | 7 | 6 | 2.00 | +321 | +53.5 |
| TIME ON OUR SIDE | 111 | 90 | 6 | 2.00 | +7 | +1.1 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +249 | +49.8 |
| CHARGE LOSSES | 63 | 62 | 5 | 1.67 | +422 | +84.5 |
| SET UP BY THE SET | 15 | 15 | 5 | 1.67 | +389 | +77.8 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +486 | +121.5 |
| CHAFF IN THE MOVE | 5 | 5 | 4 | 1.33 | +58 | +14.4 |
| IDLE COST | 40 | 33 | 4 | 1.33 | +27 | +6.7 |
| MANOEUVRE | 8 | 8 | 4 | 1.33 | +201 | +50.4 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +55 | +13.7 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -45 | -14.9 |
| MAX FOR POSITIONING | 16 | 12 | 3 | 1.00 | +66 | +22.0 |
| ONE FIGHT FORMULA | 32 | 19 | 3 | 1.00 | +5 | +1.7 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +154 | +51.5 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +242 | +80.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 2 | 0.67 | -8 | -3.9 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 21 | 18 | 2 | 0.67 | +50 | +25.1 |
| HONEST WORTH | 18 | 17 | 2 | 0.67 | +26 | +12.8 |
| NEARER NOT NEEDED | 41 | 38 | 2 | 0.67 | +87 | +43.5 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +2 | +1.1 |
| REDIRECT COUNTER | 10 | 8 | 2 | 0.67 | +335 | +167.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +75 | +37.3 |
| WHOLE FIGHT REACTION | 8 | 8 | 2 | 0.67 | +54 | +26.9 |
| WOUNDS ON THE RANKS | 13 | 13 | 2 | 0.67 | +73 | +36.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| FEATURE BUFFS | 15 | 15 | 1 | 0.33 | +0 | +0.3 |
| FIGHT TO THE END | 11 | 10 | 1 | 0.33 | +5 | +5.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| MISSILES IN THE MOVE | 13 | 9 | 1 | 0.33 | +29 | +28.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE JOINT FIGURE | 4 | 4 | 1 | 0.33 | +14 | +13.9 |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 1 | 0.33 | -4 | -3.6 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +368 | +368.0 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -12 | -12.2 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 42 | 34 | 1 | 0.33 | +8 | +8.3 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 6 | 6 | 1 | 0.33 | -108 | -107.6 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +30 | +29.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 41 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 15 | 14 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 17 | 0 | 0.00 | - | - |
| FALLS SHORT | 53 | 46 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 24 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 16 | 15 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 4 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 35 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 40 | 40 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 32 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 32 | 32 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS TURN RUN | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 71 | 70 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6 | 5 | 0 | 0.00 | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 15 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 20 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 7 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 20 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 210 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 17 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 39 | 22 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 53 | 46 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 104 | 99 | 0 | 0.00 | - | - |
| STOPS | 2 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 197 | not checked | - | - | - | - |
| WAITS AGAIN | 19 | 16 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 4.00 | 55.5 |
| JOB FIRST | gate | 5.00 | 2.33 | 53.2 |
| ARMY TABLE | rule | 2.67 | 2.33 | 60.8 |
| RULE SWITCHED OFF | gate | - | 1.33 | 67.0 |
| AFTERMATH BAND | gate | 0.33 | 0.67 | 3.4 |
| NO REASON | gate | 1.00 | - | 68.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 3.9 |
| JOINT CHARGE NOW | rule | - | 0.67 | 23.9 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 22.4 |
| CHAFF PASSED | rule | 0.33 | - | 0.9 |
| FIGHT ORDER BAND | gate | 0.33 | - | 3.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 14.0 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 3.6 |
| REFUSING RETIRES | rule | - | 0.33 | 12.2 |
| SUPPORT NARROWED | rule | - | 0.33 | 107.6 |
| WHO HITS BACK | rule | 0.33 | - | 2.4 |

### Plans: wfr-a92c160-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 38% | 376 | 215 | 57% |
| Mine | move | 24.3 | 96% | 1537 | 0 | 0% |
| Mine | shoot | 6.0 | 33% | 254 | 293 | 115% |
| Opponent | charge | 3.7 | 36% | 567 | 239 | 42% |
| Opponent | join | 2.7 | 88% | 115 | 0 | 0% |
| Opponent | move | 29.7 | 96% | 1338 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 43 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 13 | 0 | 0% |

### Packages: hunt the guns, wfr-a92c160-p45

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 3.0 | 279 | 245 | 100% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 232 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 0 | 100% | 100% | 0% | 3.0 | 279 | 245 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 232 |

### Battle groups: wfr-a92c160-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 50% | 0% | - | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 225 (2) | 19 | 206 | 50 | 0% | 1.5 | 150 (1) | 300 (1) | - | 150 (1) | 300 (1) |
| Mine | Character | 5 | 36 (5) | 36 | 0 | 41 | 20% | 2.2 | 0 (2) | 86 (2) | 0 (1) | 52 (3) | 0 (2) |
| Mine | Clean-up | 1 | 14 (1) | 0 | 14 | 123 | 0% | 3.0 | 14 (1) | - | - | 14 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 26 (3) | 26 | 0 | 0 | 0% | 2.3 | 26 (3) | - | - | 0 (2) | 170 (1) |
| Mine | Hammer | 1 | 45 (1) | 0 | 45 | 0 | 0% | 4.0 | - | 45 (1) | - | - | 45 (1) |
| Mine | Shooter | 2 | 158 (2) | 38 | 119 | 0 | 0% | 2.0 | 66 (1) | 286 (1) | - | 286 (1) | 66 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 232 (2) | 232 | 0 | 50 | 0% | 1.0 | 232 (2) | - | - | 0 (1) | 465 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Character | 6 | 57 (6) | 57 | 0 | 67 | 17% | 2.4 | 0 (1) | 25 (3) | 201 (1) | 0 (3) | 107 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 3 | 5 (3) | 0 | 5 | 0 | 33% | 4.0 | 0 (1) | 7 (2) | - | 7 (2) | 0 (1) |
| Opponent | Hammer | 5 | 64 (5) | 29 | 35 | 18 | 20% | 4.5 | 99 (3) | 0 (2) | - | 78 (4) | 0 (1) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 29 | 50% | 5.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Wizard | 1 | 31 (1) | 31 | 0 | 100 | 0% | 2.0 | - | - | 31 (1) | 31 (1) | - |

### Charged fights: wfr-a92c160-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 116 | 857 | 4.0 | 1.0 | 214 | 0 | +214 | 3 of 4 | 3 of 4 | - | +214 |
| Mine | Kingdom of Bretonnia | 1 | 465 | 0 | 2.0 | 1.0 | 0 | 418 | -418 | 1 of 2 | 2 of 2 | - | -418 |
| **Mine** | all armies | 2 | 290 | 428 | 3.0 | 1.0 | 143 | 139 | +4 | 4 of 6 | 5 of 6 | - | +4 |
| Opponent | Warriors of Chaos | 2 | 30 | 138 | 2.0 | 1.2 | 69 | 8 | +61 | 2 of 4 | 2 of 4 | +0 | +82 |

### Effective charges: wfr-a92c160-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +492) | 2 | 0% (0 of 2) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net -835) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +122) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: wfr-a92c160-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 371 | 365 | -835 | 274 | 835 | -561 | -151.2 |
| Mine | 76-89% | 1 | 497 | 201 | +0 | 39 | 0 | +39 | +7.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 446 | 203 | +246 | 382 | 58 | +323 | +72.4 |
| Mine | No odds | 2 | 306 | 182 | +182 | 221 | 0 | +221 | +72.3 |
| Mine | All fights | 6 | 396 | 223 | +4 | 253 | 159 | +94 | +23.9 |
| Opponent | Effective (55-75%) | 1 | 232 | 432 | +0 | 96 | 0 | +96 | +41.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 176 | 178 | +122 | 146 | 31 | +114 | +64.8 |
| Opponent | No odds | 1 | 120 | 497 | +0 | 0 | 96 | -96 | -80.0 |
| Opponent | All fights | 4 | 176 | 321 | +61 | 97 | 40 | +57 | +32.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p45 | move | 23 | 1 (4%) | 1 (4%) | 4 (17%) | 18 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

# Doctrine scorecard: wfr-a92c160-p47

### Scorecard: wfr-a92c160-p47

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 7 | 5 | 1 | 5 | 0 | 0 | 0 | 265 |
| L2131 | 1 | 1 | Opponent | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 340 |
| L2235 | 3 | 1 | Mine | no | 4 | 2 | 1 | 0 | 1 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | - | 3 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 5.5 | 3.5 | 1.7 | 2.7 | 0.3 | 0.0 | 0.0 | 112.3 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 3.0 | 3.0 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: wfr-a92c160-p47

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 16) | 0% (0 of 16) | 3% (1 of 32) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 80% (12 of 15); on the table 93% | 78% (14 of 18); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 80% (12 of 15); on the table 93% | 79% (15 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | - | 33% (4 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (4 of 11) | - | 36% (4 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | 69% (9 of 13) | 68% (17 of 25) |
| Points that never fought | lower | 52% (3099 of 5997) | 61% (3651 of 5999) | 56% (6750 of 11996) |
|   infantry points that never fought | lower | 59% (988 of 1675) | 81% (1061 of 1306) | 69% (2049 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (15 of 21) | 68% (21 of 31) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3326 of 4866) | 65% (3853 of 5884) | 67% (7179 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (50%) | - | 1.3 (50%) |
| MARCHED: its unit marched | 0.7 (25%) | - | 0.7 (25%) |
| IN COMBAT: engaged in combat | 0.3 (12%) | - | 0.3 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (12%) | - | 0.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.7 | 1.3 | 1.3 | 3.0 |
| not cast | 4.3 | 6.3 | 0.7 | 2.7 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.7 (89%) | 0.0 (0%) | 1.3 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (92%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 25% (1 of 4) | 25% (1 of 4) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (32 of 50) | 36% (15 of 42) | 51% (47 of 92) |
|   cavalry | 75% (3 of 4) | 48% (10 of 21) | 52% (13 of 25) |
|   character | 0% (0 of 6) | 0% (0 of 9) | 0% (0 of 15) |
|   chariot | 100% (8 of 8) | - | 100% (8 of 8) |
|   infantry | 66% (21 of 32) | 42% (5 of 12) | 59% (26 of 44) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.3 (26%) | 2.3 (16%) |
| CHARGED: it charged | 0.7 (11%) | 1.7 (19%) | 2.3 (16%) |
| IN COMBAT: it fought this turn or the last | 2.7 (44%) | 1.0 (11%) | 3.7 (24%) |
| NO TARGET IN RANGE | 1.3 (22%) | 3.0 (33%) | 4.3 (29%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.3 (4%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (17%) | 0.7 (7%) | 1.7 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 0.3 | 95% | 1.5 pts | 11 pts |
| chariot | 2.7 | 0.3 | 88% | 4.8 pts | 13 pts |
| infantry | 10.3 | 3.3 | 74% | 7.9 pts | 81 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.7 | 3.0 |
| Charges that made contact a game | 2.0 | 2.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 0.50 contact (2 units) | 1.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.18 contact (28 units) | 0.33 declared, 0.29 contact (24 units) | 0.27 declared, 0.23 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | 50% (1 of 2) | 100% (1 of 1) | 80% (4 of 5) |
| Character on its own | 100% (5 of 5) | - | 43% (3 of 7) | 67% (8 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 75% (3 of 4) | - | 73% (11 of 15) |
| Monster | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Monstrous | 0% (0 of 2) | - | - | 0% (0 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 67% (4 of 6) | 33% | 44% (4 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 44% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 77% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 60% (3 of 5); on the table 80% | - | 68% | 89% (17 of 19) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 90% (9 of 10); on the table 100% | - | 47% | 33% (4 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p47, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 40% (2) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: wfr-a92c160-p47

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 67% (6 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (2 of 8) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 3.0 |
| Movement | Points that never moved of their own | 112.3 | 113.3 |
| Movement | Fights charged into per game | 2.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +192 | 2 of 6, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net -65 | 3 of 6, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 6.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (11 of 38) | 68% (13 of 19) |
| Shooting | Points destroyed by shooting units | 38.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 0.7 | 1.0 |
| Magic | Wounds caused by other spells | - | 3.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.7 / 0.0 / 0.3 / 0.0 | 0.0 / 1.7 / 1.7 / 0.0 |
| Combat | Points destroyed in combat | 183.3 | 304.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +31 | +20 |
| Combat | Net per 100 charger points, damage counted | +10.2 | +8.3 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +31 | +39 |
| Combat | Net points per supported fight / lone fight | - / +31 | - / +39 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 2 of 8 |
| Game | Points lost | 350.3 | 318.0 |
| Game | VP from objectives | 840.0 | 646.7 |
| Game | Lone holders (player turns) | 5.5 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +167 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 668
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p47

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +104.9 | 0.0 | 0.0 | 1.0 | +75.7 | 0.0 | 0.0 |
| ARMY TABLE | 23.0 | +27.4 | 0.0 | 272.3 | 20.7 | -16.1 | 0.0 | 76.0 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +1.1 | 0.0 | 24.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.9 | 65.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.6 | 0.0 | 0.0 | 1.3 | +19.3 | 0.0 | 89.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +64.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.7 | -363.9 | 0.0 | 166.7 | 15.7 | -569.9 | 0.0 | 164.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 86.0 | 65.0 | 1.0 | +0.0 | 113.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 136.3 | 8.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +89.6 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -544.6 | 0.0 | 21.7 | 5.0 | -226.9 | 0.0 | 38.7 |
| DENIED BY THE FIGHT | 0.3 | -0.7 | 48.0 | 0.0 | 0.7 | -0.4 | 83.3 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -0.8 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +4.6 | 24.0 | 0.0 |
| EXACT ROUND | 1.3 | +15.3 | 38.0 | 65.0 | 1.3 | -0.4 | 24.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +2.0 | 86.0 | 65.0 | 1.3 | +0.0 | 68.0 | 0.0 |
| FALLS SHORT | 11.0 | +159.8 | 0.0 | 40.0 | 12.0 | +123.4 | 0.0 | 113.0 |
| FEATURE BUFFS | 2.0 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +17.7 | 0.0 | 0.0 | 0.7 | +3.9 | 18.3 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 83.0 | +5838.1 | 127.7 | 590.7 | 88.0 | +6236.6 | 234.7 | 724.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 65.0 |
| FOLLOW UP WEIGHED | 0.3 | +32.5 | 0.0 | 0.0 | 1.0 | +124.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +166.4 | 127.7 | 65.0 | 3.3 | +112.0 | 234.7 | 0.0 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 36.7 | 9.3 | +0.0 | 0.0 | 76.0 |
| FRIEND SHOOTS FIRST | 1.3 | -31.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -4.4 | 41.7 | 0.0 | - | - | - | - |
| GOAL WALK | 4.7 | +266.6 | 0.0 | 65.0 | 14.7 | +1618.3 | 0.0 | 77.3 |
| GUN FIGURES | 1.0 | +1.9 | 77.3 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 24.0 | 2.7 | +0.0 | 0.0 | 38.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 36.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 166.7 | 6.7 | +0.0 | 0.0 | 77.3 |
| HIS CHARGE DENIED | 0.3 | +6.1 | 48.0 | 0.0 | 0.7 | +43.6 | 130.0 | 0.0 |
| HIS CHARGE LIST | 8.0 | +0.0 | 0.0 | 131.7 | 6.0 | +0.0 | 0.0 | 77.3 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 65.0 | 3.7 | +0.0 | 0.0 | 38.7 |
| HIS MOVE AND SHOT | 3.3 | -14.7 | 0.0 | 86.3 | 3.3 | -38.0 | 0.0 | 48.0 |
| HIS MOVE AS HE DECIDES | 41.0 | +11.3 | 356.0 | 0.0 | 40.7 | +12.3 | 407.0 | 0.0 |
| HIS MOVE WHY | 14.3 | +0.0 | 0.0 | 20.0 | 29.0 | +0.0 | 0.0 | 442.7 |
| HIS ONE MOVE | 20.3 | -16.2 | 0.0 | 105.0 | 20.3 | -0.7 | 0.0 | 276.3 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 20.0 | 2.7 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 29.3 | +0.0 | 0.0 | 171.7 | 15.3 | +0.0 | 0.0 | 450.3 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 20.3 | +214.7 | 0.0 | 374.0 | 51.3 | +1276.0 | 0.0 | 724.3 |
| HIS SHOTS BY HIS RUN | 17.3 | +155.6 | 0.0 | 330.7 | 38.0 | +573.4 | 0.0 | 384.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +24.4 | 42.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 36.7 | 11.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.7 | +910.7 | 0.0 | 18.3 | 7.3 | +575.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -67.9 | 127.7 | 0.0 | 2.7 | -65.5 | 169.7 | 0.0 |
| IDLE COST | 5.0 | -94.0 | 0.0 | 0.0 | 11.7 | -122.6 | 0.0 | 181.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +77.5 | 148.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.7 | +0.0 | 0.0 | 350.7 | 6.0 | +0.0 | 131.3 | 106.7 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -6.7 | 65.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.2 | 0.0 | 65.0 | 0.7 | -0.2 | 24.0 | 0.0 |
| MANOEUVRE | 0.7 | -2.8 | 0.0 | 0.0 | 1.7 | +5.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +4.1 | 0.0 | 0.0 | 0.7 | -74.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +3.1 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +31.2 | 0.0 | 0.0 | 2.3 | +21.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +26.2 | 0.0 | 0.0 | 3.0 | +26.5 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -4.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +920.3 | 0.0 | 125.0 | 7.7 | +571.8 | 0.0 | 257.7 |
| NEARER NOT NEEDED | 9.3 | +290.5 | 0.0 | 68.0 | 6.3 | +290.1 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 5.3 | +705.0 | 0.0 | 125.0 | 4.7 | +311.0 | 0.0 | 154.0 |
| NO DOUBLE ROUNDS | 1.7 | -77.1 | 127.7 | 65.0 | 3.0 | -58.9 | 169.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +1.3 | 0.0 | 65.0 |
| NOT WORTH A CAST | 4.0 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -96.2 | 41.7 | 0.0 | 5.7 | -117.3 | 0.0 | 151.7 |
| ONE CHALLENGE TEST | 0.3 | +64.8 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -106.6 | 0.0 | 65.0 | 7.3 | -163.0 | 0.0 | 173.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +22.2 | 83.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.0 | +65.3 | 0.0 | 18.3 | 2.7 | +99.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +20.3 | 38.0 | 0.0 | 0.7 | +33.8 | 38.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +6.3 | 79.7 | 65.0 | 1.3 | +40.3 | 113.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 1.0 | +165.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.0 | +170.6 | 41.7 | 455.3 | 42.0 | +223.0 | 18.3 | 373.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -270.4 | 0.0 | 20.0 | 12.3 | -504.1 | 0.0 | 115.3 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 20.3 | +2305.0 | 48.0 | 0.0 | 23.3 | +2390.9 | 18.3 | 172.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +126.0 | 0.0 | 48.3 | 4.3 | +101.3 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | -24.4 | 0.0 | 92.0 | 0.3 | +9.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +0.0 | 0.0 | 68.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -41.5 | 0.0 | 0.0 | 0.7 | -5.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +31.3 | 0.0 | 48.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -68.2 | 127.7 | 65.0 | 3.0 | +9.9 | 169.7 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -24.9 | 48.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -7.6 | 127.7 | 65.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.6 | 41.7 | 0.0 | 0.3 | +24.6 | 18.3 | 0.0 |
| SET CREDITED ONCE | 1.0 | -12.2 | 0.0 | 0.0 | 1.0 | -13.1 | 0.0 | 161.0 |
| SET UP BY THE SET | 2.7 | -70.0 | 0.0 | 0.0 | 1.7 | +10.5 | 0.0 | 161.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +17.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +27.0 | 0.0 | 43.3 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 7.7 | -117.3 | 0.0 | 234.7 | 20.0 | -200.0 | 0.0 | 286.0 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +221.4 | 0.0 | 112.0 | 5.7 | +45.0 | 0.0 | 76.0 |
| SPELL WORTH | 1.7 | +21.5 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -3.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 68.3 | 9.0 | +0.0 | 0.0 | 48.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 30.7 | +0.0 | 0.0 | 139.3 | 29.3 | +0.0 | 0.0 | 159.3 |
| STAY WORTH | 6.7 | +39.8 | 0.0 | 18.3 | 6.3 | +23.4 | 0.0 | 38.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +2.9 | 18.3 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.7 | +485.5 | 0.0 | 0.0 | 6.3 | +841.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 6.7 | +485.5 | 0.0 | 0.0 | 6.3 | +841.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +3.9 | 0.0 | 65.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -12.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 65.0 | 24.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.0 | +0.0 | 0.0 | 238.7 | 39.7 | +0.0 | 0.0 | 281.7 |
| TIED UP BY THE SUM | 2.0 | +174.4 | 127.7 | 65.0 | 1.3 | +150.5 | 127.3 | 0.0 |
| TIME ON OUR SIDE | 22.3 | +243.4 | 0.0 | 198.7 | 21.3 | +220.3 | 0.0 | 201.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 103.0 |
| WALKS ON ITS ROUTE | 0.7 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.0 | -5.0 | 48.0 | 0.0 |
| WHO HITS BACK | 0.3 | +18.1 | 0.0 | 0.0 | 1.0 | +41.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.0 | -259.6 | 0.0 | 0.0 | 3.0 | -318.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +10.9 | 83.3 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +0.9 | 0.0 | 0.0 | 2.3 | +60.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p47

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 245 | 245 | 174 | 58.00 | +0 | +0.0 |
| ARMY TABLE | 131 | 131 | 93 | 31.00 | +1301 | +14.0 |
| HIS MOVE WHY | 130 | 130 | 90 | 30.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +3151 | +56.3 |
| LEGAL CHARGES ONLY | 50 | 50 | 50 | 16.67 | +0 | +0.0 |
| HIS SHOT LIST | 215 | 203 | 40 | 13.33 | +306 | +7.6 |
| HIS SHOTS BY HIS RUN | 166 | 154 | 37 | 12.33 | +424 | +11.4 |
| HIS ONE MOVE | 122 | 118 | 35 | 11.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -641 | -22.9 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 28 | 9.33 | -2324 | -83.0 |
| FIVE ACTION | 513 | 490 | 26 | 8.67 | +1486 | +57.1 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| MOVE TO CHARGE COMPUTED | 47 | 37 | 22 | 7.33 | +1543 | +70.1 |
| QUARTER ODDS | 131 | 125 | 22 | 7.33 | +2619 | +119.0 |
| NEXT CHARGE BY LIST | 30 | 24 | 18 | 6.00 | +1390 | +77.2 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 17 | 5.67 | +682 | +40.1 |
| GOAL WALK | 58 | 55 | 14 | 4.67 | +898 | +64.1 |
| THE RISK READS HIS RUN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SUPPORT ADDS | 39 | 37 | 13 | 4.33 | +585 | +45.0 |
| SUPPORT WORKED OUT | 39 | 37 | 13 | 4.33 | +585 | +45.0 |
| TIME ON OUR SIDE | 131 | 113 | 13 | 4.33 | +15 | +1.1 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 10 | 9 | 8 | 2.67 | +291 | +36.4 |
| FOUR ROUNDS | 17 | 15 | 7 | 2.33 | +314 | +44.9 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +66 | +13.2 |
| SHOT RISK POINTS | 83 | 75 | 5 | 1.67 | +68 | +13.6 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +542 | +135.5 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +472 | +117.9 |
| IDLE COST | 50 | 29 | 4 | 1.33 | +17 | +4.3 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +509 | +127.3 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 18 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +109 | +27.2 |
| EVASIVE BY THE ODDS | 6 | 6 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +233 | +77.5 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| ONE OBJECTIVE FORMULA | 29 | 18 | 3 | 1.00 | +142 | +47.5 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +112 | +37.4 |
| RISK BY ARC | 16 | 14 | 3 | 1.00 | +27 | +9.1 |
| SET UP BY THE SET | 13 | 12 | 3 | 1.00 | +284 | +94.8 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 3 | 1.00 | +26 | +8.8 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LOSSES | 79 | 72 | 2 | 0.67 | +98 | +49.2 |
| COVER ONCE | 36 | 25 | 2 | 0.67 | +17 | +8.7 |
| EXACT ROUND | 8 | 8 | 2 | 0.67 | +5 | +2.6 |
| FALLS SHORT | 69 | 59 | 2 | 0.67 | +31 | +15.5 |
| FIGHT TO THE END | 5 | 4 | 2 | 0.67 | +40 | +20.1 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +17 | +8.4 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +71 | +35.7 |
| OVERRUNS AWAY | 7 | 6 | 2 | 0.67 | +24 | +11.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +85 | +42.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STAY WORTH | 39 | 34 | 2 | 0.67 | +2 | +1.1 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -2 | -1.0 |
| WHOLE FIGHT DANGER | 21 | 18 | 2 | 0.67 | +138 | +68.9 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 1 | 0.33 | +157 | +157.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +53 | +52.7 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -29 | -28.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 2 | 1 | 0.33 | +3 | +3.4 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +20 | +20.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -15 | -14.6 |
| MAX FOR POSITIONING | 5 | 3 | 1 | 0.33 | +0 | +0.1 |
| MISSILES IN THE MOVE | 19 | 12 | 1 | 0.33 | +5 | +4.6 |
| NEARER NOT NEEDED | 47 | 46 | 1 | 0.33 | +40 | +40.1 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +157 | +157.0 |
| ONE FIGHT FORMULA | 36 | 16 | 1 | 0.33 | +5 | +5.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -2 | -2.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +14 | +13.7 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +8.6 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 43 | 41 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 23 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 43 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 26 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 134 | 125 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 100 | 100 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 13 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 7 | 7 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 51 | 37 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 44 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 180 | 176 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 236 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p47

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.67 | 83.0 |
| JOB FIRST | gate | 3.00 | 4.67 | 25.9 |
| ARMY TABLE | rule | 1.00 | 2.00 | 123.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 12.9 |
| NO REASON | gate | 0.67 | - | 17.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 4.5 |
| AFTERMATH BAND | gate | - | 0.33 | 1.6 |
| CHAFF PASSED | rule | - | 0.33 | 2.6 |
| CHARGE NOW FIRST | rule | 0.33 | - | 28.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 0.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 14.6 |
| REFUSING RETIRES | rule | 0.33 | - | 2.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.7 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 11.1 |

### Plans: wfr-a92c160-p47

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 215 | 137 | 64% |
| Mine | join | 1.3 | 100% | 83 | 0 | 0% |
| Mine | move | 34.3 | 95% | 2016 | 0 | 0% |
| Mine | shoot | 2.0 | 33% | 44 | 34 | 76% |
| Opponent | charge | 3.3 | 80% | 314 | 223 | 71% |
| Opponent | join | 0.7 | 100% | 31 | 0 | 0% |
| Opponent | move | 37.3 | 96% | 2209 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 110 | 0 | 0% |

### Battle groups: wfr-a92c160-p47

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 75% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p47

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 19 (5) | 0 | 19 | 64 | 40% | 1.3 | 23 (4) | 0 (1) | - | 23 (4) | 0 (1) |
| Mine | Character | 9 | 18 (9) | 18 | 0 | 0 | 33% | 2.7 | 12 (7) | 43 (2) | - | 41 (4) | 0 (5) |
| Mine | Clean-up | 2 | 55 (2) | 0 | 55 | 0 | 0% | 4.0 | - | 0 (1) | 95 (1) | 95 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 57 | 25% | 1.7 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 46 (4) | 46 | 0 | 22 | 0% | 1.8 | 0 (1) | 55 (2) | 80 (1) | 62 (3) | 0 (1) |
| Mine | Holder | 7 | 38 (7) | 0 | 38 | 0 | 71% | 3.0 | 66 (4) | 0 (2) | 0 (1) | 41 (6) | 0 (1) |
| Mine | Shooter | 5 | 80 (5) | 39 | 41 | 81 | 20% | 1.0 | 164 (1) | 25 (2) | 97 (2) | 111 (3) | 27 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 15 (9) | 15 | 0 | 17 | 33% | 2.3 | 20 (6) | 0 (2) | 0 (1) | 17 (6) | 12 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 40 (5) | 6 | 34 | 0 | 60% | 1.0 | 53 (3) | - | 18 (2) | 0 (2) | 73 (3) |
| Opponent | Hammer | 10 | 36 (10) | 36 | 0 | 8 | 40% | 3.3 | 27 (4) | 54 (5) | 0 (1) | 43 (4) | 31 (6) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 58 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Shooter | 3 | 25 (3) | 0 | 25 | 31 | 0% | 2.0 | 0 (1) | 40 (2) | - | - | 25 (3) |

### Charged fights: wfr-a92c160-p47

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 144 | 1.0 | 1.0 | 144 | 0 | +144 | 0 of 1 | 1 of 1 | - | +144 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 239 | 3.0 | 1.0 | 80 | 65 | +15 | 0 of 3 | 2 of 3 | - | +15 |
| Mine | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 3 | 39 | 128 | 2.0 | 1.0 | 64 | 32 | +31 | 1 of 6 | 4 of 6 | - | +31 |
| Opponent | Warriors of Chaos | 2 | 0 | 30 | 1.0 | 1.0 | 30 | 98 | -68 | 1 of 2 | 2 of 2 | - | -68 |
| Opponent | Wood Elf Realms | 1 | 72 | 449 | 6.0 | 1.0 | 75 | 0 | +75 | 1 of 6 | 6 of 6 | - | +75 |
| **Opponent** | all armies | 3 | 24 | 170 | 2.7 | 1.0 | 64 | 24 | +39 | 2 of 8 | 8 of 8 | - | +39 |

### Effective charges: wfr-a92c160-p47

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 1 (net +144) | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 1 (net +239) | 1 (net -195) | 1 | 0% (0 of 2) |
| Mine | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 0 | 1 (net +0) | 1 (net +55) | 3 (net +113) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: wfr-a92c160-p47

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 197 | 220 | -65 | 47 | 112 | -65 | -32.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 426 | 129 | +192 | 192 | 0 | +192 | +45.0 |
| Mine | No odds | 1 | 411 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 6 | 309 | 174 | +31 | 87 | 56 | +31 | +10.2 |
| Opponent | 76-89% | 1 | 126 | 55 | +0 | 20 | 42 | -22 | -17.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 242 | 113 | +113 | 113 | 41 | +72 | +29.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 432 | 58 | +58 | 65 | 0 | +65 | +15.2 |
| Opponent | No odds | 2 | 111 | 132 | -70 | 45 | 128 | -82 | -74.3 |
| Opponent | All fights | 8 | 242 | 97 | +39 | 72 | 52 | +20 | +8.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p47 | move | 26 | 2 (8%) | 2 (8%) | 3 (12%) | 21 (81%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

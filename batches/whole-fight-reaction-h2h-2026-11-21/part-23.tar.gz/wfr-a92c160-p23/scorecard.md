# Doctrine scorecard: wfr-a92c160-p23

### Scorecard: wfr-a92c160-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 11 | - | 0 | 3 | 0 | 0 | 0 | 475 |
| L2131 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 340 |
| L2235 | 3 | 1 | Mine | no | 3 | 2 | 0 | 0 | 1 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | - | 3 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 7.0 | 2.0 | 1.0 | 2.0 | 0.3 | 0.0 | 0.0 | 182.3 |
| **Average** | | | Opponent | 0% | 1.0 | 3.0 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 113.3 |

### KPIs: wfr-a92c160-p23

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 16) | 3% (1 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 75% (6 of 8); on the table 88% | 80% (8 of 10); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 100% | 67% (6 of 9); on the table 78% | 67% (8 of 12); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 50% (7 of 14) | 56% (14 of 25) |
| Points that never fought | lower | 59% (3540 of 5997) | 58% (3456 of 5999) | 58% (6996 of 11996) |
|   infantry points that never fought | lower | 73% (1220 of 1675) | 72% (936 of 1306) | 72% (2156 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (14 of 21) | 71% (22 of 31) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 100% (2 of 2); 1.3 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3156 of 4866) | 66% (3870 of 5884) | 65% (7026 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (56%) | - | 1.7 (56%) |
| MARCHED: its unit marched | 1.0 (33%) | - | 1.0 (33%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (11%) | - | 0.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 2.3 | 2.0 | 1.0 | 2.7 |
| not cast | 4.3 | 5.7 | 0.0 | 3.0 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (88%) | - | 1.7 (56%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | - | 1.0 (33%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (12%) | - | 0.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (100%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 20.3 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.0 a game | 1.0 a game |
| stood (cast and not dispelled) | - | 50% (3 of 6) | 50% (3 of 6) |
| the unit moved after it | - | 0% (0 of 3) | 0% (0 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (34 of 45) | 43% (18 of 42) | 60% (52 of 87) |
|   cavalry | 75% (3 of 4) | 52% (11 of 21) | 56% (14 of 25) |
|   character | 0% (0 of 3) | 11% (1 of 9) | 8% (1 of 12) |
|   chariot | 100% (8 of 8) | - | 100% (8 of 8) |
|   infantry | 77% (23 of 30) | 50% (6 of 12) | 69% (29 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (18%) | 2.7 (33%) | 3.3 (29%) |
| CHARGED: it charged | 0.7 (18%) | 2.0 (25%) | 2.7 (23%) |
| IN COMBAT: it fought this turn or the last | 0.7 (18%) | 0.0 (0%) | 0.7 (6%) |
| NO TARGET IN RANGE | 1.3 (36%) | 2.7 (33%) | 4.0 (34%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (9%) | 0.3 (4%) | 0.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 0.3 | 95% | 1.5 pts | 11 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 0.3 | 88% | 4.8 pts | 13 pts |
| infantry | 11.0 | 3.7 | 76% | 9.6 pts | 106 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 4.3 | 3.2 |
| Charges that made contact a game | 1.7 | 3.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 0.50 contact (2 units) | 1.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.18 contact (28 units) | 0.42 declared, 0.38 contact (24 units) | 0.31 declared, 0.27 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | 50% (1 of 2) | 100% (1 of 1) | 80% (4 of 5) |
| Character on its own | 80% (4 of 5) | - | 43% (3 of 7) | 58% (7 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 75% (3 of 4) | - | 73% (11 of 15) |
| Monster | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 67% (2 of 3); on the table 100% | 50% (3 of 6) | 55% | 44% (4 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 44% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 77% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 40% (2 of 5); on the table 60% | - | 61% | 84% (16 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 51% | 50% (6 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 60% (3) | 62% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 60% (3 of 5) | 58% (7 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (3 of 10) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 182.3 | 113.3 |
| Movement | Fights charged into per game | 1.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 9 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 9 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +125 | 4 of 9, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net -65 | 4 of 9, net +49 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.3 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (17 of 43) | 71% (15 of 21) |
| Shooting | Points destroyed by shooting units | 80.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | - |
| Magic | Wounds caused by magic missiles | 0.7 | 1.7 |
| Magic | Wounds caused by other spells | - | 3.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.3 / 0.0 / 0.0 / 0.0 | 0.0 / 1.7 / 1.7 / 0.0 |
| Combat | Points destroyed in combat | 217.3 | 319.7 |
| Combat | Points run down | 48.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +11 | +38 |
| Combat | Net per 100 charger points, damage counted | +3.9 | +14.4 |
| Combat | First round won (charged fights) | 60% | 80% |
| Combat | Net points per charged fight | +11 | +30 |
| Combat | Net points per supported fight / lone fight | - / +11 | - / +30 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 3 of 10 |
| Game | Points lost | 379.0 | 346.0 |
| Game | VP from objectives | 793.3 | 613.3 |
| Game | Lone holders (player turns) | 7.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +97 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 725
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +73.6 | 0.0 | 0.0 |
| ARMY TABLE | 23.7 | -15.7 | 0.0 | 229.0 | 24.0 | +49.7 | 0.0 | 182.0 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +3.3 | 38.7 | 0.0 | 1.3 | +2.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +9.2 | 0.0 | 24.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.9 | 65.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +21.9 | 0.0 | 0.0 | 1.3 | +10.8 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +64.8 | 0.0 | 0.0 | 0.3 | +23.2 | 0.0 | 48.0 |
| CHARACTER GUNS | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -280.8 | 0.0 | 166.7 | 14.3 | -791.5 | 0.0 | 172.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 65.0 | 1.7 | +0.0 | 131.3 | 48.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 136.3 | 7.7 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 2.0 | +121.3 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -644.2 | 0.0 | 18.3 | 5.7 | -211.7 | 0.0 | 38.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.2 | 65.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.0 | +7.9 | 42.3 | 125.7 |
| EXACT ROUND | 1.3 | +15.2 | 41.7 | 65.0 | 1.7 | +2.8 | 60.7 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +1.8 | 0.0 | 65.0 | 1.7 | +0.0 | 68.0 | 48.0 |
| FALLS SHORT | 10.3 | +147.9 | 0.0 | 58.3 | 11.3 | +102.5 | 0.0 | 86.7 |
| FEATURE BUFFS | 1.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +17.7 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 83.0 | +5776.7 | 248.3 | 684.7 | 88.7 | +5909.3 | 271.3 | 844.0 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 41.7 |
| FOLLOW UP WEIGHED | 0.7 | +41.1 | 0.0 | 0.0 | 1.0 | +124.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +147.9 | 41.7 | 65.0 | 4.0 | +141.0 | 271.3 | 48.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 73.3 | 9.0 | +0.0 | 0.0 | 84.0 |
| FRIEND SHOOTS FIRST | 1.0 | -13.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 5.0 | +274.8 | 0.0 | 65.0 | 14.7 | +1618.3 | 0.0 | 77.3 |
| GUN FIGURES | 1.3 | +1.9 | 77.3 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 24.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 73.3 | 5.7 | +0.0 | 0.0 | 84.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 166.7 | 7.0 | +0.0 | 0.0 | 77.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +43.6 | 130.0 | 0.0 |
| HIS CHARGE LIST | 8.0 | +0.0 | 0.0 | 88.3 | 5.3 | +0.0 | 0.0 | 77.3 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 65.0 | 4.0 | +0.0 | 0.0 | 38.7 |
| HIS MOVE AND SHOT | 3.7 | -16.9 | 0.0 | 68.0 | 2.0 | -20.2 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 41.3 | +11.3 | 321.7 | 0.0 | 41.0 | +12.7 | 482.7 | 0.0 |
| HIS MOVE WHY | 14.3 | +0.0 | 0.0 | 20.0 | 27.3 | +0.0 | 0.0 | 367.0 |
| HIS ONE MOVE | 20.0 | -68.4 | 0.0 | 105.0 | 24.3 | +228.1 | 0.0 | 276.7 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 140.3 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 20.0 | 3.0 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 27.7 | +0.0 | 0.0 | 155.7 | 12.7 | +0.0 | 0.0 | 422.7 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 17.0 | +170.0 | 0.0 | 367.3 | 45.3 | +1023.5 | 0.0 | 670.7 |
| HIS SHOTS BY HIS RUN | 15.3 | +165.5 | 0.0 | 367.3 | 41.3 | +795.8 | 0.0 | 536.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +12.6 | 42.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 73.3 | 9.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +863.5 | 0.0 | 36.7 | 6.3 | +456.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -47.8 | 41.7 | 0.0 | 3.3 | -93.2 | 206.3 | 48.0 |
| IDLE COST | 4.7 | -94.4 | 0.0 | 0.0 | 11.7 | -123.1 | 0.0 | 193.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +75.2 | 130.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.3 | +0.0 | 41.7 | 329.0 | 3.0 | +0.0 | 113.0 | 83.3 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -6.7 | 65.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.2 | 0.0 | 65.0 | 0.7 | -0.2 | 42.3 | 0.0 |
| MANOEUVRE | 1.0 | -2.8 | 0.0 | 18.3 | 1.7 | +6.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +119.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -2.0 | 0.0 | 0.0 | 0.3 | +69.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +0.6 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +44.7 | 0.0 | 0.0 | 2.7 | +21.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +29.9 | 0.0 | 0.0 | 3.0 | +23.3 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -6.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +876.5 | 0.0 | 125.0 | 6.7 | +556.6 | 0.0 | 270.7 |
| NEARER NOT NEEDED | 10.0 | +328.4 | 0.0 | 100.0 | 6.3 | +253.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.0 | +741.1 | 0.0 | 125.0 | 4.0 | +310.4 | 0.0 | 154.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -8.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -42.5 | 41.7 | 65.0 | 3.7 | -97.5 | 206.3 | 48.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.3 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -97.9 | 0.0 | 18.3 | 5.0 | -121.7 | 0.0 | 119.3 |
| ONE CHALLENGE TEST | 0.3 | +64.8 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -88.5 | 0.0 | 65.0 | 6.0 | -145.4 | 0.0 | 202.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +22.5 | 65.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | +20.4 | 0.0 | 36.7 | 1.0 | +36.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +45.2 | 56.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +4.2 | 0.0 | 65.0 | 2.0 | +82.8 | 168.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 0.7 | +17.6 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.0 | +166.0 | 41.7 | 531.0 | 42.3 | +275.8 | 0.0 | 477.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -223.4 | 0.0 | 20.0 | 8.7 | -408.0 | 0.0 | 116.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 21.3 | +2211.8 | 209.7 | 0.0 | 25.0 | +2560.6 | 36.7 | 364.0 |
| RANDOM MOVE BY FIGURES | 3.7 | +70.2 | 0.0 | 48.3 | 4.7 | +60.4 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +41.9 | 0.0 | 110.3 | 0.3 | +9.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +0.0 | 0.0 | 68.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -35.5 | 0.0 | 0.0 | 0.7 | -6.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| RESERVE FALL BACK | 0.7 | +31.3 | 0.0 | 48.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.7 | +7.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -43.0 | 0.0 | 65.0 | 3.7 | -48.4 | 206.3 | 48.0 |
| RUN DOWN | 1.0 | -3.2 | 41.7 | 65.0 | 0.3 | +0.0 | 18.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +20.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -13.9 | 0.0 | 18.3 | - | - | - | - |
| SET UP BY THE SET | 2.3 | +46.9 | 0.0 | 18.3 | 1.0 | +2.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +15.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 40.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +44.6 | 0.0 | 43.3 | - | - | - | - |
| SHOT RISK POINTS | 9.3 | -123.5 | 0.0 | 234.7 | 19.0 | -101.9 | 0.0 | 641.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +272.3 | 0.0 | 127.0 | 6.3 | +46.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 1.0 | -3.1 | 18.3 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 86.7 | 9.0 | +0.0 | 0.0 | 137.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -4.2 | 18.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 30.3 | +0.0 | 206.7 | 240.0 | 32.0 | +0.0 | 0.0 | 42.0 |
| STAY WORTH | 7.0 | +25.9 | 84.0 | 55.0 | 6.7 | +21.9 | 0.0 | 42.0 |
| STRIKE BY THE ODDS | 0.3 | +3.2 | 56.7 | 0.0 | - | - | - | - |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.7 | +406.7 | 0.0 | 0.0 | 6.0 | +809.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 18.3 | 0.0 |
| SUPPORT WORKED OUT | 4.7 | +406.7 | 0.0 | 0.0 | 6.0 | +809.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +2.9 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -12.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 65.0 | 24.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.7 | +0.0 | 0.0 | 285.7 | 39.7 | +0.0 | 0.0 | 360.7 |
| TIED UP BY THE SUM | 1.3 | +87.1 | 0.0 | 65.0 | 2.0 | +211.4 | 164.0 | 0.0 |
| TIME ON OUR SIDE | 25.0 | +246.4 | 38.7 | 291.3 | 22.3 | +220.3 | 0.0 | 42.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.0 | -5.0 | 66.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +21.4 | 0.0 | 41.7 |
| WHOLE FIGHT | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.7 | -176.5 | 0.0 | 0.0 | 3.7 | -558.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +10.7 | 65.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +0.7 | 0.0 | 0.0 | 1.7 | +49.6 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 247 | 247 | 175 | 58.33 | +0 | +0.0 |
| ARMY TABLE | 143 | 143 | 98 | 32.67 | +1035 | +10.6 |
| HIS MOVE WHY | 125 | 125 | 85 | 28.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 55 | 55 | 51 | 17.00 | +2531 | +49.6 |
| HIS SHOTS BY HIS RUN | 170 | 162 | 41 | 13.67 | +480 | +11.7 |
| LEGAL CHARGES ONLY | 37 | 37 | 37 | 12.33 | +0 | +0.0 |
| HIS ONE MOVE | 133 | 130 | 35 | 11.67 | +0 | +0.0 |
| HIS SHOT LIST | 187 | 175 | 35 | 11.67 | +275 | +7.9 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -659 | -26.4 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| FIVE ACTION | 515 | 491 | 21 | 7.00 | +1144 | +54.5 |
| PROMISE BY ITS OWN SUM | 51 | 51 | 18 | 6.00 | -1894 | -105.2 |
| THE RISK READS HIS RUN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 38 | 32 | 16 | 5.33 | +1295 | +80.9 |
| GOAL WALK | 59 | 56 | 15 | 5.00 | +712 | +47.5 |
| QUARTER ODDS | 139 | 126 | 15 | 5.00 | +1396 | +93.0 |
| TIME ON OUR SIDE | 142 | 124 | 15 | 5.00 | +3 | +0.2 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 14 | 4.67 | +392 | +28.0 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 27 | 24 | 13 | 4.33 | +1212 | +93.2 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SUPPORT ADDS | 32 | 31 | 9 | 3.00 | +457 | +50.8 |
| SUPPORT WORKED OUT | 32 | 31 | 9 | 3.00 | +457 | +50.8 |
| TIED UP BY THE SUM | 10 | 10 | 9 | 3.00 | +390 | +43.4 |
| FOUR ROUNDS | 18 | 18 | 8 | 2.67 | +346 | +43.2 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOT RISK POINTS | 85 | 77 | 7 | 2.33 | +92 | +13.2 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +98 | +16.4 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 9 | 9 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +498 | +99.5 |
| THE ROW IN ITS ORDER | 21 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 49 | 29 | 4 | 1.33 | +17 | +4.3 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 7 | 7 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +20 | +6.7 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +66 | +22.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +112 | +37.4 |
| RISK BY ARC | 16 | 16 | 3 | 1.00 | +27 | +9.1 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +43 | +14.2 |
| WHOLE FIGHT DANGER | 25 | 21 | 3 | 1.00 | +623 | +207.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +221 | +110.5 |
| CHARGE LOSSES | 80 | 70 | 2 | 0.67 | +444 | +221.9 |
| COVER ONCE | 41 | 24 | 2 | 0.67 | +25 | +12.7 |
| FALLS SHORT | 65 | 56 | 2 | 0.67 | +21 | +10.7 |
| FIGHT TO THE END | 4 | 4 | 2 | 0.67 | +40 | +20.1 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +226 | +112.8 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +359 | +179.5 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +80 | +40.0 |
| OVERRUNS AWAY | 8 | 8 | 2 | 0.67 | +43 | +21.4 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +21 | +10.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -18 | -9.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +64 | +32.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 1 | 0.33 | +157 | +157.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +53 | +52.7 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -6 | -6.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 9 | 9 | 1 | 0.33 | +3 | +2.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +3 | +3.4 |
| MAX FOR POSITIONING | 3 | 3 | 1 | 0.33 | +0 | +0.1 |
| MISSILES IN THE MOVE | 19 | 9 | 1 | 0.33 | +5 | +4.6 |
| NEARER NOT NEEDED | 49 | 47 | 1 | 0.33 | +61 | +61.0 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +157 | +157.0 |
| ONE FIGHT FORMULA | 31 | 11 | 1 | 0.33 | +5 | +5.4 |
| ONE OBJECTIVE FORMULA | 22 | 16 | 1 | 0.33 | +37 | +36.5 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +69 | +69.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -11 | -11.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REDIRECT COUNTER | 7 | 6 | 1 | 0.33 | +18 | +18.3 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -2 | -2.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +60 | +60.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +10 | +9.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -11 | -11.1 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 36 | 35 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 24 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 39 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 121 | 113 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 18 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 87 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 15 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 247 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 10 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 8 | 8 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 55 | 38 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 49 | 47 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 187 | 182 | 0 | 0.00 | - | - |
| STAY WORTH | 41 | 37 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 238 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 3.00 | 105.2 |
| JOB FIRST | gate | 2.00 | 3.33 | 31.1 |
| ARMY TABLE | rule | 1.67 | 2.33 | 102.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 34.3 |
| NO REASON | gate | - | 1.33 | 19.1 |
| RULE SWITCHED OFF | gate | 1.33 | - | 21.1 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 9.1 |
| AFTERMATH BAND | gate | - | 0.33 | 1.6 |
| CHAFF PASSED | rule | - | 0.33 | 2.6 |
| CHARGE NOW FIRST | rule | 0.33 | - | 6.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 11.2 |
| REFUSING RETIRES | rule | 0.33 | - | 2.2 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 11.1 |

### Plans: wfr-a92c160-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 145 | 15 | 11% |
| Mine | join | 1.3 | 100% | 83 | 0 | 0% |
| Mine | move | 34.3 | 93% | 1988 | 0 | 0% |
| Mine | shoot | 2.7 | 62% | 201 | 151 | 75% |
| Opponent | charge | 4.0 | 75% | 406 | 271 | 67% |
| Opponent | join | 0.3 | 100% | 20 | 0 | 0% |
| Opponent | move | 37.7 | 96% | 2333 | 0 | 0% |
| Opponent | shoot | 0.3 | 100% | 34 | 4 | 13% |

### Battle groups: wfr-a92c160-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 67% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 5 | 19 (5) | 0 | 19 | 81 | 20% | 2.2 | 23 (4) | 0 (1) | - | 23 (4) | 0 (1) |
| Mine | Character | 9 | 19 (9) | 19 | 0 | 0 | 44% | 2.2 | 13 (7) | 43 (2) | - | 42 (4) | 0 (5) |
| Mine | Clean-up | 2 | 31 (2) | 0 | 31 | 0 | 50% | 3.0 | - | 0 (1) | 54 (1) | 54 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 57 | 25% | 1.7 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 79 (4) | 79 | 0 | 22 | 0% | 1.8 | 74 (1) | 81 (2) | 80 (1) | 80 (3) | 74 (1) |
| Mine | Holder | 7 | 41 (7) | 0 | 41 | 5 | 57% | 3.7 | 66 (4) | 9 (2) | 0 (1) | 45 (6) | 0 (1) |
| Mine | Shooter | 5 | 70 (5) | 39 | 31 | 78 | 20% | 1.0 | 109 (1) | 25 (2) | 97 (2) | 95 (3) | 27 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 19 (9) | 19 | 0 | 14 | 22% | 2.7 | 23 (6) | 18 (2) | 0 (1) | 25 (6) | 12 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 39 (5) | 13 | 27 | 14 | 60% | 1.0 | 42 (3) | - | 35 (2) | 0 (2) | 72 (3) |
| Opponent | Hammer | 10 | 31 (10) | 31 | 0 | 27 | 30% | 3.4 | 24 (4) | 45 (5) | 0 (1) | 30 (4) | 31 (6) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 29 | 50% | 4.5 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.3 | 0 (1) | 0 (2) | - | - | 0 (3) |

### Charged fights: wfr-a92c160-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 126 | 250 | 3.0 | 1.0 | 83 | 65 | +18 | 0 of 3 | 2 of 3 | - | +18 |
| Mine | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 3 | 81 | 83 | 1.7 | 1.0 | 50 | 39 | +11 | 1 of 5 | 3 of 5 | - | +11 |
| Opponent | Warriors of Chaos | 2 | 0 | 58 | 2.0 | 1.0 | 29 | 78 | -50 | 2 of 4 | 2 of 4 | - | -50 |
| Opponent | Wood Elf Realms | 1 | 72 | 504 | 6.0 | 1.0 | 84 | 0 | +84 | 1 of 6 | 6 of 6 | - | +84 |
| **Opponent** | all armies | 3 | 24 | 206 | 3.3 | 1.0 | 62 | 31 | +30 | 3 of 10 | 8 of 10 | - | +30 |

### Effective charges: wfr-a92c160-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 1 (net +125) | 1 (net -195) | 1 | 0% (0 of 2) |
| Mine | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 2 (net +58) | 1 (net -144) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 0 | 1 (net +55) | 2 (net +55) | 3 (net +113) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: wfr-a92c160-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 197 | 220 | -65 | 47 | 112 | -65 | -32.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 411 | 125 | +125 | 125 | 0 | +125 | +30.4 |
| Mine | No odds | 1 | 411 | 125 | +125 | 125 | 0 | +125 | +30.4 |
| Mine | All fights | 5 | 283 | 182 | +11 | 78 | 67 | +11 | +3.9 |
| Opponent | 76-89% | 1 | 126 | 55 | +55 | 55 | 0 | +55 | +43.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 218 | 195 | +49 | 85 | 36 | +49 | +22.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 390 | 56 | +56 | 56 | 0 | +56 | +14.4 |
| Opponent | No odds | 1 | 120 | 210 | -170 | 175 | 266 | -91 | -75.8 |
| Opponent | All fights | 10 | 268 | 127 | +30 | 79 | 41 | +38 | +14.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p23 | move | 24 | 4 (17%) | 4 (17%) | 5 (21%) | 15 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

# Doctrine scorecard: wfr-a92c160-p24

### Scorecard: wfr-a92c160-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 2 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 4 | 0 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 3 | 0 | 0 | 0 | 19 |
| **Average** | | | Mine | 0% | 1.0 | 3.0 | 2.0 | 3.3 | 0.3 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 1.0 | 2.3 | 3.7 | 2.3 | 0.0 | 0.0 | 0.0 | 6.3 |

### KPIs: wfr-a92c160-p24

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 29% (4 of 14) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (9 of 9); on the table 100% | 100% (12 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 100% (9 of 9); on the table 100% | 100% (14 of 14); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 29% (7 of 24) | 33% (6 of 18) | 31% (13 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (7 of 17) | 40% (6 of 15) | 41% (13 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 43% (2551 of 5999) | 59% (3562 of 6000) | 51% (6113 of 11999) |
|   infantry points that never fought | lower | 42% (330 of 780) | 61% (1167 of 1918) | 55% (1497 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (14 of 18) | 79% (27 of 34) | 79% (41 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 2.3 uses a game | 50% (2 of 4); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3422 of 4808) | 78% (4653 of 5962) | 75% (8075 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (47%) | 1.7 (42%) | 4.3 (45%) |
| MARCHED: its unit marched | 0.3 (6%) | 1.3 (33%) | 1.7 (17%) |
| IN COMBAT: engaged in combat | 1.7 (29%) | 0.0 (0%) | 1.7 (17%) |
| GONE: slain | 0.7 (12%) | 0.0 (0%) | 0.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (25%) | 1.0 (10%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.7 | 4.7 | 4.3 | 0.7 | 1.0 |
| not cast | 3.7 | 1.3 | 1.3 | 9.7 | 5.3 | 23.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 4.3 (45%) | 1.7 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (17%) | 1.0 (19%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 1.7 (17%) | 0.3 (6%) | 0.0 (0%) |
| GONE: slain | 0.7 (18%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.7 (12%) | 1.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (27%) | 1.0 (75%) | 0.0 (0%) | 1.0 (10%) | 0.0 (0%) | 2.0 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (31%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (45%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 3.3 a game | 2.3 a game |
| stood (cast and not dispelled) | 75% (3 of 4) | 60% (6 of 10) | 64% (9 of 14) |
| the unit moved after it | 100% (3 of 3) | 17% (1 of 6) | 44% (4 of 9) |
| it charged on its next turn | 0% (0 of 3) | 0% (0 of 6) | 0% (0 of 9) |
| the enemy charged it first | 0% (0 of 3) | 0% (0 of 6) | 0% (0 of 9) |
| it fought by the end of its next turn | 0% (0 of 3) | 0% (0 of 6) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | 0% (0 of 6) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | 100% (6 of 6) | 100% (9 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 2) | 69% (62 of 90) | 67% (62 of 92) |
|   cavalry | - | 69% (29 of 42) | 69% (29 of 42) |
|   character | 0% (0 of 2) | 68% (13 of 19) | 62% (13 of 21) |
|   infantry | - | 69% (20 of 29) | 69% (20 of 29) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 3.0 (32%) | 3.0 (30%) |
| CHARGED: it charged | 0.3 (50%) | 2.7 (29%) | 3.0 (30%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (7%) | 0.7 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (50%) | 2.7 (29%) | 3.0 (30%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.3 | 1.0 | 91% | 0.9 pts | 10 pts |
| character | 4.3 | 2.0 | 54% | 14.1 pts | 61 pts |
| infantry | 9.3 | 3.0 | 75% | 10.6 pts | 99 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.7 | 4.3 |
| Charges that made contact a game | 3.3 | 3.0 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (4 units) | - | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.00 contact (3 units) | - | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.29 contact (21 units) | 0.45 declared, 0.29 contact (31 units) | 0.40 declared, 0.29 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 73% (8 of 11) | 50% (1 of 2) | 100% (1 of 1) | 71% (10 of 14) |
| Character in a unit | 100% (4 of 4) | 100% (3 of 3) | - | 100% (7 of 7) |
| Character on its own | 100% (1 of 1) | 100% (3 of 3) | 50% (3 of 6) | 70% (7 of 10) |
| Infantry | 83% (10 of 12) | 67% (2 of 3) | - | 80% (12 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 100% (3 of 3); on the table 100% | 29% (7 of 24) | 39% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 50% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 100% (9 of 9); on the table 100% | 33% (6 of 18) | 59% | 79% (27 of 34) | 50% (2 of 4); 2.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | 80% (4) | 54% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 64% (7 of 11) | 67% (6 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 3) | 17% (2 of 12) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 50% (5 of 10) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 2.3 |
| Movement | Points that never moved of their own | 0.0 | 6.3 |
| Movement | Fights charged into per game | 3.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | 2 of 7, net +125 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 7, net +153 | 1 of 7, net +45 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +236 | 1 of 7, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.3 | 21.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 55% (36 of 65) |
| Shooting | Points destroyed by shooting units | 0.0 | 32.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | - | 4.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.3 / 0.7 / 0.3 | 1.7 / 0.7 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 191.0 | 224.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +121 | +29 |
| Combat | Net per 100 charger points, damage counted | +36.5 | +10.7 |
| Combat | First round won (charged fights) | 100% | 78% |
| Combat | Net points per charged fight | +110 | +63 |
| Combat | Net points per supported fight / lone fight | - / +110 | - / +63 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 10 | 3 of 9 |
| Game | Points lost | 289.7 | 492.0 |
| Game | VP from objectives | 693.3 | 676.7 |
| Game | Lone holders (player turns) | 1.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +188 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 782
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 23.3 | +825.1 | 0.0 | 237.0 | 44.0 | +694.6 | 0.0 | 450.7 |
| ASSAILMENT BY POINTS | 1.0 | +5.9 | 0.0 | 126.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +13.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 4.3 | +85.3 | 0.0 | 60.0 | 0.3 | +76.3 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.7 | -0.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +27.5 | 0.0 | 83.3 |
| CHARACTER GUNS | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.7 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 21.7 | -876.2 | 0.0 | 314.7 | 15.7 | -441.9 | 0.0 | 165.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 212.0 | 0.0 | 2.0 | +0.0 | 112.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.7 | +0.0 | 0.0 | 40.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +38.8 | 0.0 | 0.0 | 2.7 | +165.8 | 0.0 | 0.0 |
| COVER ONCE | 9.3 | -612.1 | 0.0 | 209.3 | 12.0 | -464.9 | 0.0 | 211.7 |
| DENIED BY THE FIGHT | 0.7 | -0.8 | 34.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -4.7 | 78.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +33.7 | 94.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | -2.2 | 104.7 | 0.0 | 2.7 | +3.1 | 112.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +6.8 | 282.7 | 0.0 | 2.3 | +0.0 | 35.0 | 0.0 |
| FALLBACK BY WORTH | 1.0 | +4.7 | 0.0 | 15.0 | - | - | - | - |
| FALLS SHORT | 24.7 | +305.3 | 0.0 | 191.7 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +1.3 | 0.0 | 40.0 | 1.3 | +5.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.7 | +21.5 | 128.3 | 0.0 | 1.3 | +19.8 | 20.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 32.7 | 0.0 |
| FIVE ACTION | 89.3 | +5109.4 | 324.3 | 513.7 | 98.3 | +8542.5 | 127.0 | 890.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 189.3 | 5.7 | +0.0 | 0.0 | 75.7 |
| FOLLOW UP WEIGHED | 0.3 | +40.1 | 0.0 | 0.0 | 1.7 | +319.8 | 0.0 | 34.0 |
| FOUR ROUNDS | 3.7 | +235.7 | 324.3 | 0.0 | 3.0 | +277.0 | 112.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 68.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| GOAL WALK | 8.7 | +528.8 | 0.0 | 0.0 | 22.0 | +1976.7 | 0.0 | 76.3 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 36.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.7 | +0.0 | 0.0 | 314.7 | 11.3 | +0.0 | 0.0 | 165.3 |
| HIS CHARGE DENIED | 0.3 | +20.1 | 34.0 | 0.0 | 0.3 | +6.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 12.0 | +0.0 | 0.0 | 278.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 280.7 | 9.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -42.8 | 0.0 | 32.7 | 3.7 | -73.1 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 49.3 | +13.7 | 578.3 | 0.0 | 49.3 | +12.0 | 307.0 | 0.0 |
| HIS MOVE WHY | 35.0 | +0.0 | 0.0 | 107.0 | 14.0 | +0.0 | 0.0 | 148.0 |
| HIS ONE MOVE | 25.7 | -54.1 | 0.0 | 139.0 | 28.0 | -193.3 | 0.0 | 102.7 |
| HIS ONE QUARTER | 9.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 94.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 66.3 | +1273.3 | 0.0 | 200.3 | 21.7 | +312.0 | 0.0 | 332.0 |
| HIS SHOTS BY HIS RUN | 62.7 | +976.4 | 0.0 | 513.7 | 17.3 | +135.8 | 0.0 | 526.0 |
| HIS TURN DENIED | 1.3 | +18.0 | 36.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 100.0 | 13.0 | +0.0 | 0.0 | 157.3 |
| HOLDER ASSIGNMENT | 11.7 | +730.9 | 0.0 | 40.0 | 8.7 | +657.3 | 0.0 | 78.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 3.7 | -153.1 | 324.3 | 0.0 | 2.7 | -109.4 | 112.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +11.9 | 0.0 | 0.0 |
| IDLE COST | 18.3 | -215.0 | 0.0 | 47.7 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | +18.9 | 46.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 157.3 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 104.7 | 118.0 | 11.0 | +0.0 | 355.7 | 127.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +6.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 78.7 | 0.0 | 1.0 | +0.3 | 20.0 | 0.0 |
| MANOEUVRE | 3.0 | -2.5 | 0.0 | 62.0 | 1.3 | -5.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +6.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +1.6 | 0.0 | 0.0 | 2.3 | +93.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +21.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -25.6 | 0.0 | 0.0 | 1.0 | +74.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +45.8 | 0.0 | 62.0 | 3.0 | +51.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +6.6 | 0.0 | 20.0 | 4.3 | +147.0 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 4.3 | +9.3 | 0.0 | 20.0 | 6.0 | +114.1 | 0.0 | 52.7 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 78.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -75.4 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.7 | +831.6 | 0.0 | 124.0 | 8.3 | +971.7 | 0.0 | 68.0 |
| NEARER NOT NEEDED | 9.3 | +359.7 | 0.0 | 32.7 | 8.0 | +360.1 | 0.0 | 125.3 |
| NEXT CHARGE BY LIST | 5.0 | +596.9 | 0.0 | 0.0 | 5.0 | +726.5 | 0.0 | 34.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -145.7 | 287.7 | 0.0 | 2.7 | -92.8 | 97.0 | 0.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -1.4 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -98.0 | 0.0 | 92.0 | 5.0 | -225.9 | 0.0 | 120.0 |
| ONE CHALLENGE TEST | 0.3 | +1.5 | 52.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 41.7 |
| ONE FIGHT FORMULA | 3.3 | -75.5 | 0.0 | 124.0 | 7.0 | -65.2 | 0.0 | 34.0 |
| ONE JOINT FIGURE | 0.3 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.0 | -48.5 | 0.0 | 20.0 | 2.7 | +69.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -73.4 | 0.0 | 34.0 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +15.2 | 15.0 | 0.0 |
| OVERRUNS AWAY | 2.3 | +13.8 | 219.7 | 0.0 | 0.7 | +2.1 | 15.0 | 0.0 |
| PATHS CROSS | 2.3 | +29.7 | 0.0 | 0.0 | 0.7 | -2.9 | 0.0 | 0.0 |
| PLAN RESULT | 47.3 | +281.0 | 20.0 | 452.0 | 45.3 | +198.5 | 69.0 | 613.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.3 | -250.5 | 0.0 | 124.0 | 12.0 | -335.6 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -2.4 | 0.0 | 0.0 | 1.3 | -48.1 | 0.0 | 0.0 |
| QUARTER ODDS | 26.0 | +2311.7 | 104.7 | 0.0 | 26.7 | +3052.4 | 0.0 | 73.3 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -6.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +367.1 | 0.0 | 60.0 | - | - | - | - |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +10.6 | 0.0 | 45.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -58.2 | 0.0 | 0.0 | 4.0 | -59.8 | 0.0 | 68.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +15.6 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | -67.7 | 324.3 | 0.0 | 2.7 | +87.9 | 112.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.0 | -18.8 | 214.7 | 0.0 | - | - | - | - |
| RUN DOWN | 3.0 | -21.2 | 256.3 | 0.0 | 0.3 | -3.6 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -43.9 | 0.0 | 45.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +18.3 | 0.0 | 0.0 | 0.3 | +57.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.7 | -36.8 | 0.0 | 30.0 | 1.3 | -70.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.7 | +27.5 | 0.0 | 30.0 | 1.7 | +109.6 | 0.0 | 34.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +19.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.0 | +0.0 | 0.0 | 15.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +20.7 | 0.0 | 0.0 | 1.7 | +46.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.6 | 15.0 | 0.0 |
| SHOT RISK POINTS | 39.3 | -358.9 | 0.0 | 391.0 | 12.7 | -136.3 | 0.0 | 103.3 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +36.6 | 0.0 | 0.0 | 19.7 | +266.2 | 0.0 | 293.3 |
| SPELL OFF EDGE | - | - | - | - | 0.3 | +20.9 | 32.7 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +19.8 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +1.7 | 0.0 | 0.0 | 2.3 | +18.6 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -8.4 | 20.0 | 0.0 |
| SPOT AS THE GAME MOVES | 14.0 | +0.0 | 0.0 | 240.7 | 13.3 | +0.0 | 0.0 | 81.3 |
| STAND AND SHOOT | 0.3 | -1.0 | 52.7 | 0.0 | - | - | - | - |
| STANDS STILL | 18.0 | +0.0 | 0.0 | 124.0 | 32.3 | +0.0 | 15.0 | 348.7 |
| STAY WORTH | 1.0 | +1.0 | 0.0 | 0.0 | 14.0 | +71.3 | 0.0 | 204.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +3.5 | 40.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 6.3 | +829.1 | 0.0 | 124.0 | 7.0 | +419.8 | 0.0 | 106.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.3 | +829.1 | 0.0 | 124.0 | 7.0 | +419.8 | 0.0 | 106.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -2.4 | 0.0 | 0.0 | 0.7 | -44.5 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 32.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 2.3 | +0.0 | 0.0 | 62.0 | 2.7 | +0.0 | 0.0 | 88.3 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 254.3 | 46.3 | +0.0 | 0.0 | 410.7 |
| TIED UP BY THE SUM | 1.7 | +316.5 | 159.3 | 0.0 | 0.7 | +106.6 | 77.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 47.3 | +525.1 | 0.0 | 492.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 124.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | -1.7 | 15.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -391.1 | 0.0 | 125.3 | 3.7 | -292.6 | 0.0 | 131.3 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +94.5 | 0.0 | 125.3 |
| WOUNDS ON THE RANKS | 4.0 | +49.8 | 0.0 | 20.0 | 1.0 | +103.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 296 | 296 | 219 | 73.00 | +0 | +0.0 |
| ARMY TABLE | 202 | 202 | 127 | 42.33 | +4052 | +31.9 |
| HIS MOVE WHY | 147 | 147 | 106 | 35.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 54 | 18.00 | +3046 | +56.4 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 240 | 224 | 39 | 13.00 | +193 | +4.9 |
| HIS ONE MOVE | 161 | 151 | 36 | 12.00 | +0 | +0.0 |
| HIS SHOT LIST | 264 | 249 | 36 | 12.00 | +252 | +7.0 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -972 | -28.6 |
| FIVE ACTION | 563 | 534 | 32 | 10.67 | +1688 | +52.8 |
| MOVE TO CHARGE COMPUTED | 51 | 41 | 32 | 10.67 | +2214 | +69.2 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| QUARTER ODDS | 158 | 148 | 28 | 9.33 | +2925 | +104.5 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 26 | 8.67 | -1758 | -67.6 |
| MOVE ORDER | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 26 | 24 | 8.00 | +2059 | +85.8 |
| GOAL WALK | 92 | 89 | 23 | 7.67 | +1679 | +73.0 |
| FOUR ROUNDS | 20 | 20 | 16 | 5.33 | +531 | +33.2 |
| SHOT RISK POINTS | 156 | 140 | 14 | 4.67 | +84 | +6.0 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 142 | 105 | 12 | 4.00 | +45 | +3.7 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| PATHS CROSS | 9 | 9 | 9 | 3.00 | +80 | +8.9 |
| CHAFF IN THE MOVE | 14 | 13 | 8 | 2.67 | +19 | +2.4 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +15 | +1.9 |
| SUPPORT ADDS | 40 | 40 | 8 | 2.67 | +295 | +36.9 |
| SUPPORT WORKED OUT | 40 | 40 | 8 | 2.67 | +295 | +36.9 |
| CHARGE LOSSES | 112 | 102 | 7 | 2.33 | +804 | +114.9 |
| IDLE COST | 55 | 41 | 7 | 2.33 | +49 | +7.0 |
| RISK BY ARC | 19 | 19 | 7 | 2.33 | +165 | +23.5 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 2.33 | +298 | +42.5 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1080 | +179.9 |
| MARCH CHECK | 8 | 8 | 6 | 2.00 | +170 | +28.3 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 6 | 2.00 | +26 | +4.3 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -2 | -0.4 |
| COVER ONCE | 64 | 35 | 5 | 1.67 | +60 | +11.9 |
| SET UP BY THE SET | 16 | 13 | 5 | 1.67 | +418 | +83.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 12 | 12 | 4 | 1.33 | -78 | -19.5 |
| MAX FOR POSITIONING | 11 | 10 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 52 | 49 | 4 | 1.33 | +179 | +44.8 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +11 | +2.6 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +18 | +5.9 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +5 | +1.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +82 | +27.5 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +228 | +76.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +34 | +16.8 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +95 | +47.6 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +63 | +31.6 |
| FALLS SHORT | 74 | 64 | 2 | 0.67 | +19 | +9.3 |
| FIGHT TO THE END | 9 | 9 | 2 | 0.67 | +28 | +13.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 19 | 19 | 2 | 0.67 | +52 | +26.1 |
| ONE OBJECTIVE FORMULA | 23 | 15 | 2 | 0.67 | +204 | +102.0 |
| PROMISE READS THE TABLE | 6 | 6 | 2 | 0.67 | +116 | +58.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +47 | +23.4 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| STAY WORTH | 45 | 30 | 2 | 0.67 | +18 | +9.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | -5 | -4.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +46 | +46.5 |
| EXACT ROUND | 13 | 13 | 1 | 0.33 | +4 | +3.7 |
| FALLBACK BY WORTH | 3 | 3 | 1 | 0.33 | +14 | +14.1 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +21 | +21.3 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +36 | +35.8 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +57 | +56.6 |
| MANOEUVRE | 13 | 13 | 1 | 0.33 | +14 | +13.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +20 | +19.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -65 | -65.0 |
| MISSILES IN THE MOVE | 19 | 13 | 1 | 0.33 | +8 | +8.4 |
| NO DOUBLE ROUNDS | 18 | 18 | 1 | 0.33 | +6 | +5.8 |
| ONE FIGHT FORMULA | 31 | 13 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -220 | -220.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| OVERRUNS AWAY | 9 | 9 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 14 | 14 | 1 | 0.33 | +73 | +72.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| SET CREDITED ONCE | 12 | 9 | 1 | 0.33 | +4 | +4.4 |
| SHOTS IN THE MOVE | 61 | 38 | 1 | 0.33 | +8 | +8.4 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -69 | -68.9 |
| THE ROW IN ITS ORDER | 23 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 23 | 23 | 1 | 0.33 | +7 | +6.8 |
| WHOLE FIGHT REACTION | 5 | 5 | 1 | 0.33 | +40 | +40.3 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHARACTER GUNS | 19 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 70 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 16 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 75 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 56 | 53 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 50 | 45 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 48 | 45 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 97 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 15 | 14 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 9 | 8 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 15 | 14 | 0 | 0.00 | - | - |
| PLAN RESULT | 278 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 15 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 18 | 12 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 7 | 7 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 82 | 75 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 151 | 144 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 15 | 14 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.00 | 67.6 |
| JOB FIRST | gate | 3.67 | 4.67 | 33.4 |
| ARMY TABLE | rule | 1.67 | 5.33 | 50.6 |
| RULE SWITCHED OFF | gate | 2.33 | - | 13.9 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 19.5 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 20.9 |
| AFTERMATH BAND | gate | 0.33 | - | 4.7 |
| AFTERMATH WITH FRIENDS | rule | 0.33 | - | 4.7 |
| CHAFF PASSED | rule | - | 0.33 | 2.2 |
| MARCH OF THE TABLE | rule | 0.33 | - | 65.0 |
| NO REASON | gate | - | 0.33 | 33.7 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 220.2 |
| PATHS CROSS | rule | - | 0.33 | 8.9 |
| SUPPORT NARROWED | rule | - | 0.33 | 68.9 |

### Plans: wfr-a92c160-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 56% | 288 | 274 | 95% |
| Mine | join | 5.7 | 100% | 257 | 0 | 0% |
| Mine | move | 37.0 | 95% | 1789 | 0 | 0% |
| Mine | shoot | 0.3 | 100% | 24 | 7 | 29% |
| Mine | support | 1.3 | 100% | 27 | 0 | 0% |
| Opponent | charge | 2.7 | 62% | 254 | 125 | 49% |
| Opponent | move | 39.3 | 94% | 2974 | 0 | 0% |
| Opponent | shoot | 3.3 | 30% | 236 | 74 | 31% |

### Battle groups: wfr-a92c160-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 43% | 33% | 17% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 74 (9) | 0 | 74 | 27 | 56% | 3.5 | 82 (7) | 0 (1) | 88 (1) | 72 (8) | 88 (1) |
| Mine | Character | 10 | 56 (10) | 56 | 0 | 0 | 50% | 3.4 | 10 (6) | 94 (4) | - | 13 (4) | 81 (6) |
| Mine | Clean-up | 1 | 49 (1) | 49 | 0 | 0 | 0% | 2.0 | 49 (1) | - | - | 49 (1) | - |
| Mine | Fast Hammer | 8 | 0 (8) | 0 | 0 | 21 | 62% | 3.0 | 0 (2) | 0 (4) | 0 (2) | 0 (1) | 0 (7) |
| Mine | Hammer | 2 | 112 (2) | 0 | 112 | 46 | 0% | 4.0 | 208 (1) | 0 (1) | - | 208 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 35 | 0% | 1.8 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 10 (7) | 10 | 0 | 12 | 0% | 1.3 | 16 (4) | 0 (1) | 0 (1) | 0 (2) | 15 (4) |
| Opponent | Clean-up | 2 | 166 (2) | 0 | 166 | 0 | 0% | 3.0 | 333 (1) | 0 (1) | - | 333 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 44 (5) | 44 | 0 | 39 | 0% | 1.4 | 0 (2) | 109 (2) | 36 (1) | 0 (2) | 83 (3) |
| Opponent | Hammer | 11 | 11 (11) | 11 | 0 | 33 | 55% | 4.0 | 0 (3) | 22 (6) | 0 (2) | 72 (2) | 0 (9) |
| Opponent | Shooter | 8 | 19 (8) | 8 | 10 | 41 | 0% | 1.1 | 43 (2) | 15 (5) | 0 (1) | 33 (3) | 12 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: wfr-a92c160-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 431 | 4.0 | 1.0 | 108 | 0 | +108 | 0 of 8 | 8 of 8 | - | +108 |
| Mine | Warriors of Chaos | 1 | 0 | 236 | 2.0 | 1.0 | 118 | 0 | +118 | 1 of 2 | 2 of 2 | - | +118 |
| **Mine** | all armies | 3 | 0 | 366 | 3.3 | 1.0 | 110 | 0 | +110 | 1 of 10 | 10 of 10 | - | +110 |
| Opponent | Wood Elf Realms | 3 | 33 | 224 | 3.0 | 1.0 | 75 | 12 | +63 | 3 of 9 | 7 of 9 | - | +63 |

### Effective charges: wfr-a92c160-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 1 (net +0) | 0 | 0 | 1 (net +125) | 4 (net +153) | 0 | 2 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +236) | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 9 | 2 (net +125) | 0 | 0 | 3 (net +64) | 1 (net +45) | 1 (net +186) | 2 | 0% (0 of 7) |

### Charged fights, damage counted: wfr-a92c160-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 114 | +0 | 57 | 0 | +57 | +114.0 |
| Mine | 76-89% | 1 | 254 | 125 | +125 | 125 | 0 | +125 | +49.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 479 | 236 | +236 | 236 | 0 | +236 | +49.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 455 | 118 | +153 | 169 | 8 | +161 | +35.3 |
| Mine | No odds | 3 | 234 | 120 | +42 | 60 | 12 | +48 | +20.5 |
| Mine | All fights | 10 | 331 | 130 | +110 | 127 | 7 | +121 | +36.5 |
| Opponent | Long shot (under 50%) | 2 | 312 | 266 | +125 | 125 | 166 | -41 | -13.2 |
| Opponent | 76-89% | 3 | 112 | 87 | +64 | 64 | 0 | +64 | +57.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 186 | +186 | 186 | 0 | +186 | +37.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 45 | +45 | 45 | 0 | +45 | +9.0 |
| Opponent | No odds | 2 | 254 | 382 | -52 | 95 | 133 | -38 | -14.9 |
| Opponent | All fights | 9 | 274 | 199 | +63 | 96 | 67 | +29 | +10.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p24 | move | 20 | 3 (15%) | 3 (15%) | 3 (15%) | 14 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

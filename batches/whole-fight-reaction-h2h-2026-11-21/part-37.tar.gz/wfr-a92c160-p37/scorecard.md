# Doctrine scorecard: wfr-a92c160-p37

### Scorecard: wfr-a92c160-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 941 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 144 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 5 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 1 | 0 | 0 | 1078 |
| **Average** | | | Mine | 0% | 3.0 | - | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.7 | 1.3 | 1.3 | 0.7 | 0.0 | 0.0 | 721.0 |

### KPIs: wfr-a92c160-p37

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 59% (10 of 17) | 40% (10 of 25) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 47% (42 of 90) | - | 47% (42 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (42 of 88) | - | 48% (42 of 88) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | - | 67% (4 of 6) |
| Points that never fought | lower | 33% (1880 of 5699) | 76% (4533 of 6000) | 55% (6413 of 11699) |
|   infantry points that never fought | lower | 45% (1011 of 2239) | 95% (2011 of 2111) | 69% (3022 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (7 of 16) | 60% (15 of 25) | 54% (22 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 0.0 uses a game | 100% (4 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 30% (1170 of 3916) | 57% (2507 of 4382) | 44% (3677 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 10.3 (65%) | - | 10.3 (65%) |
| MARCHED: its unit marched | 4.0 (25%) | - | 4.0 (25%) |
| IN COMBAT: engaged in combat | 0.7 (4%) | - | 0.7 (4%) |
| STUPIDITY: Stupidity | 1.0 (6%) | - | 1.0 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 7.0 | 14.0 | 1.0 | 1.0 |
| not cast | 2.0 | 3.0 | 3.0 | 16.0 | 1.0 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 0.0 (0%) | 10.3 (65%) | 0.7 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (25%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.7 (4%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 1.0 (6%) | 0.0 (0%) | 0.7 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.3 (11%) | 2.3 (78%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.7 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.3 a game | 0.0 a game | 4.2 a game |
| stood (cast and not dispelled) | 68% (17 of 25) | - | 68% (17 of 25) |
| the unit moved after it | 65% (11 of 17) | - | 65% (11 of 17) |
| it charged on its next turn | 0% (0 of 17) | - | 0% (0 of 17) |
| the enemy charged it first | 6% (1 of 17) | - | 6% (1 of 17) |
| it fought by the end of its next turn | 6% (1 of 17) | - | 6% (1 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 18% (3 of 17) | - | 18% (3 of 17) |
| none of these (no charge, no fight, no charge escaped) | 76% (13 of 17) | - | 76% (13 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 47% (8 of 17) | 63% (120 of 189) | 62% (128 of 206) |
|   cavalry | - | 57% (16 of 28) | 57% (16 of 28) |
|   character | - | 55% (11 of 20) | 55% (11 of 20) |
|   chariot | - | 0% (0 of 1) | 0% (0 of 1) |
|   infantry | 47% (8 of 17) | 63% (43 of 68) | 60% (51 of 85) |
|   monster | - | 80% (8 of 10) | 80% (8 of 10) |
|   war machine | - | 68% (42 of 62) | 68% (42 of 62) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (67%) | 1.0 (4%) | 3.0 (12%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (13%) | 3.0 (12%) |
| NO TARGET IN RANGE | 0.7 (22%) | 10.0 (43%) | 10.7 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (3%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (11%) | 4.0 (17%) | 4.3 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 4.0 (17%) | 4.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 3.7 | 59% | 5.1 pts | 37 pts |
| character | 3.7 | 5.7 | 45% | 23.1 pts | 85 pts |
| infantry | 25.3 | 11.0 | 70% | 4.9 pts | 125 pts |
| monster | 2.7 | 1.0 | 62% | 5.8 pts | 16 pts |
| war machine | 14.0 | 15.3 | 57% | 10.9 pts | 153 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 4.3 | 2.5 |
| Charges that made contact a game | 0.3 | 2.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (20 units) | 0.48 declared, 0.22 contact (27 units) | 0.32 declared, 0.15 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 80% (4 of 5) | 40% (2 of 5) | - | 60% (6 of 10) |
| Character on its own | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) | 50% (2 of 4) |
| Infantry | 29% (2 of 7) | 29% (2 of 7) | - | 29% (4 of 14) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 50% (1 of 2); on the table 50% | 47% (42 of 90) | 33% | 44% (7 of 16) | 100% (4 of 4); 4.3 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (1 of 1); on the table 100% | - | 89% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 48% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (1) | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 31% (4 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 20% (2 of 10) | 46% (40 of 87) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (2 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 79% (11 of 14) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.3 | 1.3 |
| Movement | Points that never moved of their own | 56.7 | 721.0 |
| Movement | Fights charged into per game | 0.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 2 of 4, net -30 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 4, net -60 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 4, net -706 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 27.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (2 of 9) | 51% (41 of 81) |
| Shooting | Points destroyed by shooting units | 0.0 | 251.7 |
| Shooting | War machine shots | - | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 60% (25 of 42) |
| Shooting | Points destroyed by war machines | 0.0 | 45.7 |
| Magic | Magic missiles cast | 6.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (6 of 19) | - |
| Magic | Wounds caused by magic missiles | 9.3 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 226.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 1.0 / 0.7 | 3.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 310.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +5 | -147 |
| Combat | Net per 100 charger points, damage counted | +10.3 | -46.6 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +105 | -206 |
| Combat | Net points per supported fight / lone fight | - / +105 | -383 / -30 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 4 of 4 |
| Game | Points lost | 324.0 | 571.7 |
| Game | VP from objectives | 676.7 | 886.7 |
| Game | Lone holders (player turns) | 3.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -32 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 896
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +204.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.3 | +284.5 | 0.0 | 309.3 | 14.0 | +215.6 | 0.0 | 194.0 |
| BACKUP TARGETS | 1.0 | +2.8 | 0.0 | 17.3 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -6.1 | 21.7 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +2.0 | 10.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 1.7 | +0.0 | 244.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 15.7 | +231.0 | 665.0 | 186.7 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.7 | +264.8 | 374.7 | 272.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.7 | +187.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 2.3 | -0.2 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 0.3 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 7.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.0 | -847.7 | 0.0 | 203.7 | 9.7 | -220.5 | 0.0 | 490.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 35.0 | 17.3 | 1.7 | +0.0 | 151.3 | 85.0 |
| CHARIOT NO STATIC JOB | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 111.3 | 7.0 | +0.0 | 0.0 | 65.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 17.3 | 35.0 |
| CONVEYANCE SEARCH | 6.3 | +800.6 | 157.3 | 0.0 | - | - | - | - |
| COVER ONCE | 5.7 | -222.3 | 0.0 | 121.3 | 5.0 | -134.6 | 0.0 | 170.3 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 90.7 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -12.0 | 43.3 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -184.2 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | -0.6 | 35.0 | 17.3 | 1.0 | +22.3 | 35.7 | 65.0 |
| FALL BACK GOOD ORDER | 0.3 | +2.2 | 35.0 | 17.3 | 2.0 | +0.2 | 173.0 | 20.0 |
| FALLS SHORT | 15.3 | +343.4 | 0.0 | 284.3 | 13.3 | +78.2 | 0.0 | 218.3 |
| FEATURE BUFFS | 17.0 | +416.1 | 0.0 | 185.0 | 1.0 | +3.9 | 0.0 | 24.0 |
| FIGHT TO THE END | 0.3 | +1.4 | 35.0 | 17.3 | 0.3 | +29.1 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 65.7 | +7076.8 | 409.7 | 910.0 | 136.3 | +4899.7 | 2736.7 | 1610.3 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 94.0 | 1.3 | +0.0 | 0.0 | 170.3 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.7 | +6.4 | 35.0 | 17.3 | 4.3 | +297.1 | 191.3 | 310.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -14.8 | 0.0 | 20.0 |
| GIVES UP | - | - | - | - | 1.0 | -21.2 | 40.0 | 170.3 |
| GOAL WALK | 14.7 | +2508.3 | 0.0 | 148.0 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.3 | +28.1 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.0 | +29.2 | 0.0 | 40.0 |
| HARD STAY DROPPED | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 16.7 | +0.0 | 0.0 | 160.3 | 5.3 | +0.0 | 0.0 | 360.7 |
| HIS CHARGE LIST | 16.0 | +0.0 | 0.0 | 212.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 137.0 | 5.7 | +0.0 | 0.0 | 24.0 |
| HIS MOVE AND SHOT | 4.7 | -41.4 | 0.0 | 105.0 | 3.0 | -81.7 | 0.0 | 44.0 |
| HIS MOVE AS HE DECIDES | 45.3 | +16.0 | 802.7 | 0.0 | 32.0 | +8.3 | 440.0 | 0.0 |
| HIS MOVE WHY | 23.3 | +0.0 | 0.0 | 424.3 | 14.7 | +0.0 | 0.0 | 75.0 |
| HIS ONE MOVE | 15.3 | -84.8 | 0.0 | 20.0 | 18.3 | +52.7 | 0.0 | 44.0 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 43.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 74.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 10.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.3 | +1561.9 | 0.0 | 519.0 | 50.3 | +1834.0 | 0.0 | 542.3 |
| HIS SHOTS BY HIS RUN | 45.0 | +1031.3 | 0.0 | 559.0 | 37.3 | +958.3 | 0.0 | 646.7 |
| HIS TURN DENIED | 0.3 | +0.5 | 35.0 | 17.3 | 3.3 | +135.1 | 134.0 | 310.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 42.7 | +0.0 | 0.0 | 351.7 | 16.7 | +0.0 | 0.0 | 242.3 |
| HOLDER ASSIGNMENT | 13.7 | +1482.4 | 0.0 | 243.0 | 11.0 | +1283.2 | 0.0 | 364.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -1.2 | 35.0 | 17.3 | 2.0 | -129.7 | 83.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +324.5 | 0.0 | 235.3 |
| HUNT THE GUNS | 0.3 | +41.0 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 10.3 | -64.6 | 0.0 | 127.0 | 4.7 | -109.4 | 0.0 | 130.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.3 | +333.4 | 21.7 | 290.3 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 170.3 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 447.7 | 220.7 | 4.0 | +0.0 | 352.0 | 94.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.4 | 17.3 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.3 | 35.0 | 17.3 | 1.3 | +1.7 | 39.0 | 35.0 |
| MANOEUVRE | 1.0 | +0.1 | 0.0 | 0.0 | 1.0 | -9.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +9.8 | 0.0 | 66.7 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +123.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +114.4 | 0.0 | 93.7 | - | - | - | - |
| MARCH OVER CASTS | 3.0 | +40.7 | 0.0 | 66.7 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 170.3 |
| MAX FOR POSITIONING | 3.7 | +63.4 | 0.0 | 45.7 | 2.3 | +49.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.7 | +340.4 | 0.0 | 144.7 | - | - | - | - |
| MISSILES NEXT TURN | 9.0 | +324.4 | 0.0 | 144.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 1.0 | -84.3 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.7 | +1554.8 | 0.0 | 40.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.7 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 90.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.3 | +168.5 | 0.0 | 0.0 | 3.3 | +148.6 | 0.0 | 190.3 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.7 | +184.2 | 0.0 | 65.0 | 10.0 | +435.2 | 0.0 | 24.0 |
| NEXT CHARGE BY LIST | 1.3 | +168.5 | 0.0 | 0.0 | 0.7 | +16.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -16.5 | 35.0 | 17.3 | 4.3 | -108.5 | 191.3 | 310.3 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -43.0 | 0.0 | 47.0 | 5.0 | -100.2 | 0.0 | 24.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 65.0 |
| ONE FIGHT FORMULA | 6.7 | -92.4 | 0.0 | 182.0 | 4.7 | -39.1 | 0.0 | 20.0 |
| ONE JOINT FIGURE | - | - | - | - | 2.3 | +102.1 | 17.3 | 290.3 |
| ONE OBJECTIVE FORMULA | 7.7 | -74.9 | 0.0 | 130.7 | 4.0 | -116.8 | 0.0 | 24.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 170.3 |
| OPENS A LANE | - | - | - | - | 2.0 | +2.3 | 96.7 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +93.5 | 61.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +7.5 | 0.0 | 0.0 | 1.7 | +30.7 | 61.7 | 235.3 |
| PATHS CROSS | 0.7 | +97.8 | 0.0 | 66.7 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -30.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 31.0 | +82.1 | 164.0 | 548.0 | 61.3 | +1449.8 | 683.7 | 1084.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | -38.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -18.5 | 0.0 | 170.3 |
| QUARTER ODDS | 6.7 | +966.6 | 120.0 | 43.3 | 12.7 | +813.4 | 260.0 | 215.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +32.5 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 170.3 |
| REDIRECT BY WHAT IT STOPS | 2.0 | -7.7 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +60.0 | 0.0 | 66.7 | 1.0 | +50.4 | 0.0 | 48.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +1.2 | 0.0 | 92.3 | 1.0 | +0.0 | 0.0 | 48.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -6.1 | 21.7 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 170.3 |
| RESERVE FALL BACK | 0.7 | +4.1 | 0.0 | 0.0 | 0.3 | -7.4 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.3 | +13.4 | 21.7 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -12.7 | 35.0 | 17.3 | 4.0 | -71.9 | 191.3 | 310.3 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | +40.9 | 65.0 | 235.3 |
| RUN DOWN | 0.3 | -2.1 | 35.0 | 17.3 | 2.3 | -11.4 | 82.3 | 235.3 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.8 | 0.0 | 21.7 | 0.7 | +14.1 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -2.6 | 0.0 | 10.0 | 5.0 | -488.6 | 0.0 | 68.0 |
| SET UP BY THE SET | 1.0 | +1.6 | 0.0 | 10.0 | 6.0 | +505.6 | 0.0 | 92.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.3 | +0.0 | 0.0 | 21.7 | 28.0 | +0.0 | 0.0 | 261.7 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +1.2 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -13.0 | 90.7 | 55.0 |
| SHOT RISK POINTS | 34.3 | -256.1 | 0.0 | 378.3 | 39.0 | +362.4 | 0.0 | 752.7 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.0 | +61.5 | 0.0 | 108.3 | 48.0 | +966.1 | 0.0 | 480.0 |
| SPELL OFF EDGE | 0.3 | +45.9 | 65.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 10.0 | 6.7 | +0.0 | 0.0 | 154.0 |
| STAND AND SHOOT | 0.7 | -1.8 | 35.0 | 17.3 | 1.0 | -6.9 | 65.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 108.0 | 4.0 | +0.0 | 0.0 | 194.3 |
| STANDS STILL | 15.0 | +0.0 | 374.7 | 343.7 | 90.7 | +0.0 | 2545.3 | 547.3 |
| STAY WORTH | 4.7 | +26.5 | 88.0 | 90.7 | 74.3 | -6.2 | 1596.0 | 575.3 |
| STOPS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +122.9 | 90.7 | 150.0 |
| SUPPORT ADDS | 8.7 | +286.8 | 0.0 | 113.0 | 2.3 | +42.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 8.7 | +286.8 | 0.0 | 113.0 | 2.3 | +42.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | 1.0 | +2.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 66.7 | 2.3 | +0.0 | 0.0 | 20.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -0.3 | 0.0 | 170.3 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 130.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 17.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.0 | +0.0 | 0.0 | 377.0 | 62.0 | +0.0 | 0.0 | 650.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +139.6 | 83.3 | 0.0 |
| TIME ON OUR SIDE | 11.0 | +295.7 | 178.0 | 123.3 | 43.0 | +371.3 | 56.7 | 75.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +119.3 | 0.0 | 65.0 |
| WHO HITS BACK | 0.7 | +34.2 | 0.0 | 17.3 | 0.3 | +33.8 | 0.0 | 35.0 |
| WHOLE FIGHT DANGER | 3.7 | -361.2 | 0.0 | 78.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +5.4 | 0.0 | 170.3 |
| WHOLE FIGHT REACTION | 2.0 | +467.2 | 205.3 | 57.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 9.0 | +741.0 | 0.0 | 0.0 | 1.3 | +4.9 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 232 | 232 | 159 | 53.00 | +0 | +0.0 |
| HIS SHOT LIST | 299 | 286 | 80 | 26.67 | +1326 | +16.6 |
| HIS MOVE WHY | 114 | 114 | 72 | 24.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 74 | 74 | 72 | 24.00 | +3086 | +42.9 |
| ARMY TABLE | 97 | 97 | 67 | 22.33 | +1481 | +22.1 |
| HIS SHOTS BY HIS RUN | 247 | 236 | 66 | 22.00 | +909 | +13.8 |
| SHOT RISK POINTS | 220 | 212 | 53 | 17.67 | +1093 | +20.6 |
| HIS ONE MOVE | 101 | 99 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| LEGAL CHARGES ONLY | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -430 | -16.5 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 162 | 156 | 22 | 7.33 | +145 | +6.6 |
| GOAL WALK | 44 | 43 | 19 | 6.33 | +3546 | +186.7 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| FIVE ACTION | 606 | 593 | 14 | 4.67 | +1006 | +71.8 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4664 | +333.2 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| THE RISK READS HIS RUN | 36 | 36 | 12 | 4.00 | +0 | +0.0 |
| CASTING BLOCK | 14 | 14 | 11 | 3.67 | +89 | +8.1 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| WOUNDS ON THE RANKS | 31 | 31 | 10 | 3.33 | +634 | +63.4 |
| CANNON PLANNED TARGET | 47 | 47 | 9 | 3.00 | -2 | -0.3 |
| FEATURE BUFFS | 54 | 51 | 9 | 3.00 | +86 | +9.6 |
| MOVE TO CHARGE COMPUTED | 14 | 12 | 9 | 3.00 | +523 | +58.1 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 9 | 3.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHAFF PASSED | 7 | 7 | 7 | 2.33 | -1 | -0.1 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +1000 | +142.9 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 2.00 | +39 | +6.5 |
| CHARIOT NO STATIC JOB | 6 | 6 | 6 | 2.00 | -913 | -152.1 |
| FOUR ROUNDS | 15 | 15 | 6 | 2.00 | +184 | +30.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 237 | 230 | 6 | 2.00 | +23 | +3.8 |
| SUPPORT ADDS | 33 | 30 | 6 | 2.00 | +196 | +32.7 |
| SUPPORT WORKED OUT | 33 | 30 | 6 | 2.00 | +196 | +32.7 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 92 | 91 | 5 | 1.67 | +503 | +100.7 |
| FALLS SHORT | 86 | 66 | 5 | 1.67 | +113 | +22.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +369 | +73.9 |
| MAX FOR POSITIONING | 18 | 16 | 5 | 1.67 | +14 | +2.8 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 5 | 1.67 | -115 | -23.1 |
| SET UP BY THE SET | 21 | 20 | 5 | 1.67 | +555 | +111.0 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH CHECK | 7 | 7 | 4 | 1.33 | +193 | +48.3 |
| MISSILES IN THE MOVE | 26 | 16 | 4 | 1.33 | +153 | +38.3 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 6 | 5 | 4 | 1.33 | +295 | +73.8 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +98 | +24.4 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +40 | +10.1 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT COUNTER | 13 | 7 | 3 | 1.00 | +84 | +27.9 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | -10 | -3.3 |
| SHOTS IN THE MOVE | 153 | 134 | 3 | 1.00 | +73 | +24.3 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +368 | +122.5 |
| SURE REACH TOGETHER | 4 | 4 | 3 | 1.00 | +1 | +0.4 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +83 | +27.6 |
| COVER ONCE | 32 | 28 | 2 | 0.67 | +29 | +14.7 |
| IDLE COST | 45 | 31 | 2 | 0.67 | +7 | +3.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| ONE OBJECTIVE FORMULA | 35 | 28 | 2 | 0.67 | +156 | +77.8 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +97 | +48.4 |
| OVERRUNS AWAY | 6 | 6 | 2 | 0.67 | +20 | +9.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +293 | +146.7 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +322 | +161.1 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +44 | +22.2 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +97 | +48.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +614 | +613.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -18 | -18.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +6 | +6.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -45 | -45.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +16.9 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +14 | +13.7 |
| HIS MOVE AND SHOT | 23 | 22 | 1 | 0.33 | +5 | +5.3 |
| HIS TURN DENIED | 11 | 11 | 1 | 0.33 | +9 | +8.6 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +10 | +10.4 |
| MISSILES NEXT TURN | 27 | 18 | 1 | 0.33 | +4 | +4.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 44 | 44 | 1 | 0.33 | +43 | +42.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -91 | -91.4 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -34 | -34.0 |
| QUARTER ODDS | 58 | 55 | 1 | 0.33 | +168 | +168.0 |
| SHOTS AFTER THE MOVES | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 1 | 1 | 1 | 0.33 | +357 | +356.8 |
| WHOLE FIGHT DANGER | 11 | 10 | 1 | 0.33 | +38 | +38.1 |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 22 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 19 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 65 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 55 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 33 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 178 | 172 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | 6 | 0 | 0.00 | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 24 | 24 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 15 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 27 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 7 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS A LANE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 277 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 14 | 14 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 17 | 16 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 94 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 42 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 317 | 312 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 5 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 285 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 4.33 | 17.1 |
| ARMY TABLE | rule | 1.33 | 2.00 | 8.7 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.67 | 13.9 |
| CHARIOT NO STATIC JOB | rule | 2.00 | - | 152.1 |
| PROMISE BY ITS OWN SUM | rule | - | 1.67 | 23.1 |
| NO REASON | gate | 1.00 | - | 10.5 |
| CANNON PLANNED TARGET | rule | - | 0.67 | 1.2 |
| RULE SWITCHED OFF | gate | - | 0.67 | 27.1 |
| BEST PRIZE | rule | - | 0.33 | 18.2 |
| CHAFF PASSED | rule | - | 0.33 | 0.5 |
| CHARGE NOW FIRST | rule | - | 0.33 | 45.4 |
| FALLBACK | gate | 0.33 | - | 2.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 27.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 91.4 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 34.0 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |

### Plans: wfr-a92c160-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 11 | 26 | 230% |
| Mine | move | 27.3 | 90% | 2800 | 0 | 0% |
| Mine | shoot | 2.7 | 38% | 442 | 56 | 13% |
| Mine | support | 0.7 | 100% | 6 | 0 | 0% |
| Opponent | charge | 4.3 | 31% | 746 | 90 | 12% |
| Opponent | move | 34.0 | 96% | 1096 | 0 | 0% |
| Opponent | shoot | 23.0 | 87% | 529 | 1360 | 257% |

### Packages: hunt the guns, wfr-a92c160-p37

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 136 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 136 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: wfr-a92c160-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 75 | 75% | 2.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 36 (15) | 36 | 0 | 8 | 13% | 3.4 | - | 27 (11) | 90 (2) | 33 (7) | 46 (6) |
| Mine | Clean-up | 3 | 67 (3) | 67 | 0 | 67 | 67% | 5.0 | 0 (1) | 101 (2) | - | 67 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 71 (6) | 35 | 35 | 16 | 17% | 4.8 | 0 (1) | 93 (3) | 54 (2) | 49 (4) | 108 (2) |
| Mine | Holder | 5 | 33 (5) | 0 | 33 | 18 | 60% | 5.0 | 23 (2) | 117 (1) | 0 (1) | 46 (1) | 40 (3) |
| Mine | Shooter | 2 | 154 (2) | 0 | 154 | 100 | 0% | 1.0 | - | 308 (1) | 0 (1) | 154 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (3) | 0 (3) | - |
| Opponent | Chaff | 2 | 247 (2) | 38 | 208 | 50 | 0% | 1.5 | 354 (1) | 139 (1) | - | 247 (2) | - |
| Opponent | Character | 8 | 10 (8) | 10 | 0 | 35 | 38% | 2.4 | 63 (1) | 5 (6) | 0 (1) | 19 (4) | 6 (4) |
| Opponent | Clean-up | 6 | 9 (6) | 9 | 0 | 23 | 17% | 2.4 | 0 (1) | 14 (5) | - | 0 (5) | 36 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 11 | 0 | 100 | 50% | 3.0 | 0 (1) | 33 (1) | 0 (2) | 14 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 5.5 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Shooter | 10 | 110 (10) | 21 | 88 | 5 | 0% | 2.2 | 261 (2) | 95 (8) | - | 147 (8) | 8 (2) |
| Opponent | War machine | 12 | 33 (12) | 33 | 0 | 28 | 8% | 1.7 | 27 (10) | - | 61 (2) | 0 (2) | 41 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: wfr-a92c160-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 226 | 35 | 0.3 | 1.0 | 105 | 0 | +105 | 0 of 1 | 1 of 1 | - | +105 |
| Opponent | Dwarfen Mountain Holds | 2 | 418 | 0 | 1.0 | 1.5 | 0 | 60 | -60 | 2 of 2 | 0 of 2 | -60 | -60 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 0 | 2.0 | 1.5 | 0 | 353 | -353 | 2 of 2 | 0 of 2 | -706 | +0 |
| **Opponent** | all armies | 3 | 297 | 0 | 1.3 | 1.5 | 0 | 206 | -206 | 4 of 4 | 0 of 4 | -383 | -30 |

### Effective charges: wfr-a92c160-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 1 (net +105) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net -60) | 0 | 1 (net -60) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net -706) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: wfr-a92c160-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 52 | 105 | +105 | 125 | 120 | +5 | +10.3 |
| Mine | All fights | 1 | 52 | 105 | +105 | 125 | 120 | +5 | +10.3 |
| Opponent | Long shot (under 50%) | 2 | 246 | 297 | -30 | 107 | 92 | +15 | +6.1 |
| Opponent | Effective (55-75%) | 1 | 165 | 836 | -60 | 168 | 80 | +88 | +53.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 606 | 836 | -706 | 0 | 706 | -706 | -116.5 |
| Opponent | All fights | 4 | 316 | 566 | -206 | 96 | 243 | -147 | -46.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p37 | move | 22 | 4 (18%) | 1 (5%) | 2 (9%) | 16 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

# Doctrine scorecard: wfr-a92c160-p20

### Scorecard: wfr-a92c160-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 4 | 0 | 0 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 10 | 4 | 2 | 3 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 1 | 1 | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 10.0 | 2.7 | 3.3 | 1.7 | 0.3 | 0.0 | 0.0 | 87.7 |
| **Average** | | | Opponent | 50% | 1.0 | 3.0 | 2.7 | 1.0 | 0.3 | 0.0 | 0.0 | 123.7 |

### KPIs: wfr-a92c160-p20

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 50% (1 of 2); on the table 50% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 17% (3 of 18) | - | 17% (3 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 30% (3 of 10) | - | 30% (3 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 43% (2581 of 6000) | 44% (2634 of 6000) | 43% (5215 of 12000) |
|   infantry points that never fought | lower | 58% (531 of 923) | 59% (682 of 1159) | 58% (1213 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (13 of 26) | 75% (18 of 24) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 2.0 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 2.0 uses a game | 0.0 uses a game | 29% (4 of 14); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2601 of 5860) | 67% (3453 of 5131) | 55% (6054 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (27%) | - | 1.3 (27%) |
| MARCHED: its unit marched | 1.0 (20%) | - | 1.0 (20%) |
| IN COMBAT: engaged in combat | 0.7 (13%) | - | 0.7 (13%) |
| GONE: slain | 2.0 (40%) | - | 2.0 (40%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 4.3 | 3.0 | 1.0 | 2.0 |
| not cast | 3.3 | 5.7 | 5.0 | 5.0 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (41%) | 0.0 (0%) | 1.3 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (13%) | 0.7 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (50%) | 1.7 (29%) | 1.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (40%) | 1.3 (24%) | 2.3 (47%) | 2.0 (40%) | 7.3 (28%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (10%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 67% (6 of 9) | - | 67% (6 of 9) |
| the unit moved after it | 33% (2 of 6) | - | 33% (2 of 6) |
| it charged on its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| the enemy charged it first | 17% (1 of 6) | - | 17% (1 of 6) |
| it fought by the end of its next turn | 17% (1 of 6) | - | 17% (1 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 83% (5 of 6) | - | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (47 of 83) | 62% (66 of 107) | 59% (113 of 190) |
|   cavalry | 44% (11 of 25) | 71% (17 of 24) | 57% (28 of 49) |
|   character | 14% (3 of 22) | 29% (4 of 14) | 19% (7 of 36) |
|   chariot | - | 67% (8 of 12) | 67% (8 of 12) |
|   infantry | 88% (21 of 24) | 67% (30 of 45) | 74% (51 of 69) |
|   monster | - | 58% (7 of 12) | 58% (7 of 12) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (22%) | 2.0 (15%) | 4.7 (18%) |
| CHARGED: it charged | 2.3 (19%) | 2.0 (15%) | 4.3 (17%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.7 (5%) | 1.3 (5%) |
| NO TARGET IN RANGE | 5.3 (44%) | 3.0 (22%) | 8.3 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.3 (2%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 3.7 (27%) | 4.3 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| STUPIDITY | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 1.3 (10%) | 1.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.7 | 2.3 | 85% | 7.6 pts | 104 pts |
| character | 4.0 | 0.7 | 83% | 1.8 pts | 7 pts |
| chariot | 2.7 | 1.3 | 75% | 31.2 pts | 83 pts |
| infantry | 25.0 | 4.7 | 85% | 7.0 pts | 176 pts |
| monster | 2.3 | 1.3 | 57% | 35.7 pts | 83 pts |
| war machine | 4.0 | 1.7 | 75% | 17.4 pts | 70 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.3 | 4.2 |
| Charges that made contact a game | 3.0 | 2.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.30 contact (23 units) | 0.39 declared, 0.21 contact (33 units) | 0.41 declared, 0.25 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | - | 75% (3 of 4) | 38% (3 of 8) | 50% (6 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 70% (7 of 10) | 0% (0 of 1) | - | 64% (7 of 11) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (4 of 4); on the table 100% | 17% (3 of 18) | 43% | 50% (13 of 26) | 100% (1 of 1); 2.0 uses a game | 29% (4 of 14); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 46% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 40% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 46% | 75% (9 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 50% (2) | 62% (5) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 55% (6 of 11) | 44% (4 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (10 of 27) | 41% (11 of 27) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | 43% (3 of 7) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 1.0 |
| Movement | Points that never moved of their own | 87.7 | 123.7 |
| Movement | Fights charged into per game | 3.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 5, net -195 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 7, net +119 | 1 of 5, net +143 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +336 | 3 of 5, net +283 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.7 | 24.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (13 of 41) | 73% (53 of 73) |
| Shooting | Points destroyed by shooting units | 11.3 | 166.7 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (8 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | - |
| Magic | Wounds caused by magic missiles | 1.0 | 0.3 |
| Magic | Wounds caused by other spells | 3.7 | - |
| Magic | Points destroyed by magic (all spells) | 34.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.3 / 1.0 / 0.0 | 3.0 / 2.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 331.0 | 133.3 |
| Combat | Points run down | 381.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +168 | +102 |
| Combat | Net per 100 charger points, damage counted | +40.0 | +33.6 |
| Combat | First round won (charged fights) | 100% | 57% |
| Combat | Net points per charged fight | +181 | +114 |
| Combat | Net points per supported fight / lone fight | - / +181 | - / +114 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 2 of 7 |
| Game | Points lost | 528.0 | 827.3 |
| Game | VP from objectives | 513.3 | 873.3 |
| Game | Lone holders (player turns) | 10.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -53 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1355
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 25.3 | +536.4 | 0.0 | 95.3 | 33.0 | +276.3 | 0.0 | 558.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +3.6 | 0.0 | 0.0 | 0.3 | +3.8 | 0.0 | 0.0 |
| BEST PRIZE | 0.7 | -63.6 | 117.7 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.7 | +0.1 | 0.0 | 98.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +0.0 | 153.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| CAST JOB | 0.7 | +12.8 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 231.3 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +16.7 | 0.0 | 22.7 |
| CHAFF PASSED | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +45.3 | 0.0 | 98.0 | 1.0 | +55.2 | 0.0 | 83.3 |
| CHARGE LOSSES | 23.3 | -1236.4 | 0.0 | 748.3 | 10.3 | -423.2 | 0.0 | 130.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 193.0 | 0.0 | 2.0 | +0.0 | 183.7 | 65.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 198.0 | 11.0 | +0.0 | 0.0 | 106.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.7 | +506.1 | 300.0 | 300.0 | - | - | - | - |
| COVER ONCE | 15.0 | -804.3 | 0.0 | 531.3 | 9.0 | -824.3 | 0.0 | 242.3 |
| DENIED BY THE FIGHT | 0.3 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.5 | 47.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.3 | +26.2 | 0.0 | 42.0 |
| EXACT ROUND | 2.7 | +19.4 | 264.0 | 0.0 | 1.7 | +36.3 | 228.7 | 143.0 |
| FALL BACK GOOD ORDER | 3.0 | +42.5 | 265.0 | 0.0 | 1.0 | +0.1 | 183.7 | 65.0 |
| FALLS SHORT | 11.3 | +112.2 | 0.0 | 214.3 | 17.7 | +198.0 | 0.0 | 135.3 |
| FEATURE BUFFS | 1.7 | +17.9 | 0.0 | 0.0 | 1.7 | +38.1 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +17.4 | 0.0 | 65.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +4.0 | 0.0 | 38.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 78.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 95.3 | +4786.3 | 847.7 | 1451.3 | 104.3 | +7795.5 | 2179.0 | 2067.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 531.3 | 8.0 | +0.0 | 0.0 | 389.0 |
| FOLLOW UP WEIGHED | 0.7 | +28.2 | 0.0 | 0.0 | 0.3 | +111.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.0 | +168.6 | 379.7 | 0.0 | 3.0 | +131.9 | 279.0 | 143.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 13.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -6.9 | 47.7 | 0.0 |
| GOAL WALK | 5.7 | +350.9 | 0.0 | 95.3 | 8.0 | +452.8 | 0.0 | 65.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +2.5 | 0.0 | 0.0 |
| GUN MASK | 2.7 | +27.2 | 0.0 | 100.7 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 25.7 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 13.3 |
| HIS CHARGE BY HIS RUN | 17.7 | +0.0 | 0.0 | 748.3 | 8.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +55.1 | 47.7 | 78.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 50.3 | 6.7 | +0.0 | 0.0 | 432.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 95.3 | 2.7 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 7.0 | -80.8 | 0.0 | 217.0 | 3.7 | -14.2 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 52.0 | +12.7 | 1306.3 | 0.0 | 42.7 | +10.7 | 844.7 | 0.0 |
| HIS MOVE WHY | 25.7 | +0.0 | 0.0 | 413.3 | 15.3 | +0.0 | 0.0 | 540.0 |
| HIS ONE MOVE | 20.3 | -132.0 | 0.0 | 100.7 | 22.0 | +76.4 | 0.0 | 148.3 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 100.7 | 4.3 | +0.0 | 0.0 | 224.7 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 47.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 66.3 | +3311.5 | 0.0 | 1451.3 | 54.3 | +1614.6 | 0.0 | 1233.0 |
| HIS SHOTS BY HIS RUN | 62.3 | +2141.1 | 0.0 | 1356.0 | 38.3 | +542.3 | 0.0 | 1004.3 |
| HIS TURN DENIED | 1.0 | +170.1 | 13.3 | 0.0 | 0.7 | +7.4 | 133.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.3 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 53.3 |
| HOLDER ASSIGNMENT | 10.7 | +1067.6 | 0.0 | 0.0 | 11.3 | +905.0 | 0.0 | 26.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -179.2 | 379.7 | 0.0 | 3.0 | -118.2 | 279.0 | 143.0 |
| IDLE COST | 7.3 | -94.0 | 0.0 | 214.3 | 11.7 | -147.7 | 0.0 | 152.0 |
| JOINT CHARGE NOW | 0.3 | +0.7 | 22.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | 0.3 | +0.7 | 22.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 79.0 | 99.0 | 9.7 | +0.0 | 317.0 | 162.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +2.3 | 142.3 | 0.0 | 1.3 | +0.1 | 98.0 | 143.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -138.5 | 0.0 | 22.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| MANOEUVRE | 3.3 | +91.4 | 0.0 | 47.7 | 3.3 | +66.0 | 0.0 | 13.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +19.2 | 0.0 | 0.0 | 0.3 | +19.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +34.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +28.4 | 0.0 | 166.7 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +162.2 | 0.0 | 300.0 | 1.0 | +70.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +12.6 | 0.0 | 133.3 | 2.3 | +114.9 | 0.0 | 78.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +41.2 | 0.0 | 133.3 | 2.3 | +48.7 | 0.0 | 231.3 |
| MISSILES NEXT TURN | 5.0 | +28.6 | 0.0 | 433.3 | 3.3 | +81.5 | 0.0 | 231.3 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 166.7 | 2.3 | +0.0 | 65.0 | 38.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.0 | +856.2 | 0.0 | 0.0 | 6.7 | +784.8 | 0.0 | 65.0 |
| NEARER NOT NEEDED | 7.7 | +295.6 | 0.0 | 0.0 | 11.7 | +462.6 | 0.0 | 154.7 |
| NEXT CHARGE BY LIST | 4.3 | +662.9 | 0.0 | 0.0 | 5.0 | +584.9 | 0.0 | 65.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -141.7 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.7 | -64.6 | 357.7 | 0.0 | 2.7 | -134.7 | 279.0 | 143.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +0.0 | 0.0 | 13.3 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 6.0 | -212.8 | 38.0 | 181.0 | 5.0 | -246.4 | 0.0 | 116.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 61.3 |
| ONE FIGHT FORMULA | 7.0 | -150.3 | 0.0 | 214.3 | 4.3 | -98.3 | 0.0 | 65.3 |
| ONE OBJECTIVE FORMULA | 6.0 | +54.8 | 0.0 | 0.0 | 5.3 | -104.0 | 0.0 | 13.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -33.1 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +1.8 | 34.0 | 0.0 | - | - | - | - |
| OPENS UP | 1.0 | +34.7 | 60.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +160.2 | 194.3 | 0.0 | 1.3 | +10.6 | 47.7 | 143.0 |
| PATHS CROSS | 0.3 | +19.6 | 0.0 | 0.0 | 0.7 | +66.7 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +469.5 | 136.7 | 994.0 | 49.0 | +1058.1 | 1017.0 | 1386.3 |
| PROMISE BY ITS OWN SUM | 9.0 | -308.4 | 0.0 | 0.0 | 7.3 | -120.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| QUARTER ODDS | 15.0 | +1277.5 | 137.3 | 100.7 | 17.0 | +1729.2 | 50.3 | 224.7 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.3 | +511.3 | 0.0 | 71.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +0.0 | 0.0 | 82.7 |
| REDIRECT WEIGHED | 0.3 | -33.3 | 41.7 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 4.0 | -250.8 | 0.0 | 0.0 | 3.7 | -108.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | -205.0 | 254.3 | 0.0 | 2.3 | -3.4 | 279.0 | 143.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -29.9 | 153.7 | 0.0 | 1.3 | -13.4 | 145.7 | 143.0 |
| RUN DOWN | 2.7 | -14.6 | 300.3 | 0.0 | 2.7 | -11.5 | 145.7 | 143.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -41.4 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | +1.5 | 0.0 | 0.0 | 1.0 | +20.9 | 0.0 | 78.0 |
| SECOND LOOK | 0.3 | +11.2 | 38.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.7 | -57.7 | 0.0 | 42.0 |
| SET UP BY THE SET | - | - | - | - | 4.7 | +10.1 | 0.0 | 42.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 319.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +17.8 | 0.0 | 0.0 | 1.7 | +47.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 40.3 | -528.6 | 0.0 | 769.7 | 21.0 | -137.6 | 0.0 | 410.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.0 | +313.2 | 0.0 | 232.3 | 25.0 | +1118.5 | 0.0 | 353.3 |
| SPELL WORTH | 1.0 | +22.1 | 266.7 | 266.7 | 1.7 | +20.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +3.7 | 13.3 | 0.0 | 0.7 | -3.8 | 47.7 | 78.0 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 264.7 | 8.7 | +0.0 | 0.0 | 72.0 |
| STAND AND SHOOT | 1.7 | -20.7 | 60.0 | 0.0 | 0.3 | -1.6 | 133.3 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 34.3 | +0.0 | 468.0 | 47.7 | 42.3 | +0.0 | 1900.0 | 1117.7 |
| STAY WORTH | 24.7 | +19.2 | 360.7 | 0.0 | 23.7 | +94.4 | 500.0 | 112.7 |
| SUPPORT ADDS | 7.3 | +676.8 | 0.0 | 50.3 | 5.7 | +400.5 | 0.0 | 125.3 |
| SUPPORT WORKED OUT | 7.3 | +676.8 | 0.0 | 50.3 | 5.7 | +400.5 | 0.0 | 125.3 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +8.8 | 0.0 | 87.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 50.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 145.7 | 6.7 | +0.0 | 0.0 | 66.3 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 57.3 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 95.3 | 6.0 | +0.0 | 0.0 | 66.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 678.0 | 49.7 | +0.0 | 0.0 | 958.7 |
| TIED UP BY THE SUM | 2.0 | +216.6 | 100.7 | 0.0 | 1.3 | +222.8 | 98.0 | 0.0 |
| TIME ON OUR SIDE | 30.3 | +380.1 | 44.0 | 775.3 | 22.3 | +259.3 | 0.0 | 743.7 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 198.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -5.8 | 0.0 | 0.0 | 0.7 | -3.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 2.3 | +0.0 | 666.7 | 0.0 |
| WHO FIGHTS | 0.3 | -1.0 | 13.3 | 0.0 | 0.7 | -7.4 | 0.0 | 65.0 |
| WHO HITS BACK | 1.0 | +55.2 | 0.0 | 0.0 | 0.3 | +215.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -290.1 | 0.0 | 264.7 | 1.0 | -185.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 3.0 | +243.2 | 0.0 | 376.3 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.0 | +60.9 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 284 | 284 | 214 | 71.33 | +0 | +0.0 |
| ARMY TABLE | 175 | 175 | 138 | 46.00 | +2189 | +15.9 |
| HIS SHOT LIST | 362 | 342 | 97 | 32.33 | +1482 | +15.3 |
| HIS MOVE WHY | 123 | 123 | 72 | 24.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 302 | 286 | 65 | 21.67 | +1126 | +17.3 |
| HOLDER ASSIGNMENT | 66 | 66 | 62 | 20.67 | +4014 | +64.7 |
| HIS ONE MOVE | 127 | 125 | 36 | 12.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1377 | -41.7 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| SHOT RISK POINTS | 184 | 173 | 29 | 9.67 | +844 | +29.1 |
| THE RISK READS HIS RUN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 38 | 36 | 19 | 6.33 | +1782 | +93.8 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 96 | 92 | 17 | 5.67 | +1209 | +71.1 |
| FIVE ACTION | 599 | 577 | 16 | 5.33 | +1037 | +64.8 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 16 | 5.33 | -1286 | -80.4 |
| NEXT CHARGE BY LIST | 28 | 28 | 15 | 5.00 | +1535 | +102.4 |
| CHARGE LOSSES | 101 | 95 | 14 | 4.67 | +1623 | +116.0 |
| SUPPORT ADDS | 39 | 37 | 14 | 4.67 | +993 | +70.9 |
| SUPPORT WORKED OUT | 39 | 37 | 14 | 4.67 | +993 | +70.9 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 158 | 134 | 12 | 4.00 | +84 | +7.0 |
| FOUR ROUNDS | 21 | 20 | 10 | 3.33 | +274 | +27.4 |
| GOAL WALK | 41 | 40 | 10 | 3.33 | +268 | +26.8 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| SHOTS IN THE MOVE | 126 | 96 | 8 | 2.67 | +202 | +25.2 |
| TIED UP BY THE SUM | 10 | 10 | 8 | 2.67 | +198 | +24.7 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +301 | +50.2 |
| COVER ONCE | 72 | 47 | 6 | 2.00 | +163 | +27.2 |
| MANOEUVRE | 20 | 20 | 6 | 2.00 | +531 | +88.5 |
| SET UP BY THE SET | 14 | 14 | 6 | 2.00 | +407 | +67.8 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 6 | 2.00 | +59 | +9.8 |
| CHARGE NOW FIRST | 12 | 12 | 5 | 1.67 | -267 | -53.4 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 7 | 7 | 4 | 1.33 | +26 | +6.4 |
| NEARER NOT NEEDED | 58 | 57 | 4 | 1.33 | +151 | +37.9 |
| SHOTS AFTER THE MOVES | 29 | 29 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +790 | +197.4 |
| WHOLE FIGHT DANGER | 14 | 14 | 4 | 1.33 | +254 | +63.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +420 | +140.1 |
| HIS MOVE AND SHOT | 32 | 31 | 3 | 1.00 | +79 | +26.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +115 | +38.2 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -85 | -28.4 |
| MAX FOR POSITIONING | 13 | 12 | 3 | 1.00 | +5 | +1.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +259 | +86.3 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +81 | +26.9 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 1.00 | -29 | -9.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -263 | -131.5 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +22 | +11.2 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 8 | 8 | 2 | 0.67 | +49 | +24.3 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +82 | +40.9 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +187 | +93.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| OPENS UP | 3 | 2 | 2 | 0.67 | +20 | +9.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| WHOLE FIGHT REACTION | 9 | 9 | 2 | 0.67 | +2 | +1.2 |
| CANNON PLANNED TARGET | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 13 | 12 | 1 | 0.33 | +4 | +3.7 |
| FALL BACK GOOD ORDER | 12 | 11 | 1 | 0.33 | +34 | +34.1 |
| FALLS SHORT | 87 | 76 | 1 | 0.33 | +12 | +11.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +12 | +12.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -2.2 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -99 | -99.3 |
| OVERRUNS AWAY | 10 | 10 | 1 | 0.33 | +4 | +3.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -9 | -9.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| RISK BY ARC | 16 | 15 | 1 | 0.33 | +43 | +42.6 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +33 | +33.4 |
| STAY WORTH | 145 | 136 | 1 | 0.33 | +0 | +0.1 |
| SURE REACH TOGETHER | 6 | 6 | 1 | 0.33 | +2 | +2.1 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 52 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 19 | 19 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 74 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 102 | 102 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 20 | 0 | 0.00 | - | - |
| IDLE COST | 57 | 45 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 19 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 9 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 22 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 34 | 29 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 13 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 23 | 23 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 61 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 52 | 46 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 230 | 215 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 17 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 20 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 29 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 24 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.67 | 42.0 |
| ARMY TABLE | rule | 3.33 | 4.33 | 58.0 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 1.67 | 80.4 |
| CHARGE NOW FIRST | rule | 1.33 | 0.33 | 53.4 |
| RULE SWITCHED OFF | gate | 1.33 | - | 58.7 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 35.5 |
| MARCH OF THE TABLE | rule | 1.00 | - | 28.4 |
| WALKS ON ITS ROUTE | rule | 0.33 | 0.67 | 9.6 |
| BEST PRIZE | rule | 0.67 | - | 131.5 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| AFTERMATH BAND | gate | 0.33 | - | 2.2 |
| CHAFF PASSED | rule | 0.33 | - | 0.7 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 2.2 |
| NO REASON | gate | - | 0.33 | 6.2 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 99.3 |
| REDIRECT WEIGHED | rule | 0.33 | - | 9.1 |

### Plans: wfr-a92c160-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 436 | 230 | 53% |
| Mine | move | 33.0 | 94% | 1899 | 0 | 0% |
| Mine | shoot | 7.3 | 59% | 162 | 239 | 147% |
| Opponent | charge | 2.3 | 57% | 319 | 272 | 85% |
| Opponent | move | 38.0 | 92% | 1903 | 0 | 0% |
| Opponent | shoot | 7.7 | 78% | 1104 | 786 | 71% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.3 | 23% | 100% | 0% | - | 0% | 0% | 0% | 67% | 33% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 72 (7) | 72 | 0 | 40 | 0% | 1.6 | 42 (5) | 267 (1) | 0 (1) | 31 (5) | 157 (2) |
| Mine | Clean-up | 1 | 215 (1) | 85 | 130 | 0 | 0% | 2.0 | 215 (1) | - | - | 215 (1) | - |
| Mine | Fast Hammer | 14 | 35 (14) | 8 | 27 | 22 | 57% | 2.5 | 26 (8) | 47 (6) | - | 55 (9) | 0 (5) |
| Mine | Shooter | 4 | 15 (4) | 15 | 0 | 0 | 0% | 1.0 | 14 (3) | 19 (1) | - | 20 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 190 (7) | 0 | 190 | 82 | 14% | 2.3 | - | 287 (4) | 98 (3) | 338 (4) | 86 (3) |
| Opponent | Character | 4 | 53 (4) | 53 | 0 | 14 | 0% | 1.5 | - | 53 (4) | - | 20 (2) | 80 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 70 | 50% | 5.5 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 48 | 25% | 1.3 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Opponent | Hammer | 8 | 42 (8) | 42 | 0 | 54 | 12% | 3.1 | 115 (2) | 20 (3) | 0 (3) | 0 (4) | 71 (4) |
| Opponent | Holder | 3 | 172 (3) | 0 | 172 | 0 | 0% | 2.7 | 250 (2) | - | 0 (1) | 550 (1) | 0 (2) |
| Opponent | Shooter | 4 | 66 (4) | 0 | 66 | 41 | 0% | 2.0 | 0 (1) | 142 (2) | 0 (1) | 121 (2) | 28 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 0% | 2.3 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 46 | 542 | 3.0 | 1.0 | 181 | 0 | +181 | 1 of 9 | 9 of 9 | - | +181 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 848 | 4.0 | 1.0 | 212 | 49 | +163 | 1 of 4 | 3 of 4 | - | +163 |
| Opponent | Wood Elf Realms | 1 | 0 | 143 | 1.0 | 1.0 | 143 | 0 | +143 | 0 of 1 | 1 of 1 | - | +143 |
| **Opponent** | all armies | 3 | 167 | 330 | 2.3 | 1.0 | 142 | 28 | +114 | 2 of 7 | 4 of 7 | - | +114 |

### Effective charges: wfr-a92c160-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 9 | 0 | 0 | 0 | 0 | 5 (net +119) | 2 (net +336) | 2 | 0% (0 of 7) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net -195) | 0 | 0 | 3 (net +283) | 0 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +143) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 489 | 266 | +336 | 336 | 0 | +336 | +68.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 363 | 81 | +119 | 119 | 23 | +96 | +26.5 |
| Mine | No odds | 2 | 494 | 125 | +180 | 180 | 0 | +180 | +36.4 |
| Mine | All fights | 9 | 420 | 132 | +181 | 181 | 13 | +168 | +40.0 |
| Opponent | Effective (55-75%) | 1 | 195 | 230 | -195 | 18 | 195 | -177 | -90.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 434 | 238 | +283 | 289 | 16 | +273 | +62.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 143 | +143 | 214 | 186 | +28 | +5.7 |
| Opponent | No odds | 2 | 62 | 306 | +0 | 25 | 4 | +20 | +32.8 |
| Opponent | All fights | 7 | 303 | 243 | +114 | 164 | 63 | +102 | +33.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p20 | move | 24 | 6 (25%) | 5 (21%) | 2 (8%) | 16 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

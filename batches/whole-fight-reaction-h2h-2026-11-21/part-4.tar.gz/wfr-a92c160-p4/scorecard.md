# Doctrine scorecard: wfr-a92c160-p4

### Scorecard: wfr-a92c160-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 385 |
| L0612 | 6 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 2 | 4 | 0 | 0 | 0 | 246 |
| L0628 | 4 | 1 | Opponent | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | - | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 337.0 |
| **Average** | | | Opponent | 0% | 5.5 | 6.0 | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: wfr-a92c160-p4

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 15) | 50% (15 of 30) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 53% (16 of 30) | 53% (16 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 53% (16 of 30) | 53% (16 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 93% (5557 of 6000) | 76% (4581 of 5998) | 84% (10138 of 11998) |
|   infantry points that never fought | lower | 92% (2049 of 2232) | 100% (694 of 694) | 94% (2743 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 48% (11 of 23) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.7 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 72% (3035 of 4232) | 55% (3171 of 5787) | 62% (6206 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (36%) | 1.7 (36%) |
| MARCHED: its unit marched | - | 2.0 (43%) | 2.0 (43%) |
| CHARGED: its unit charged | - | 0.7 (14%) | 0.7 (14%) |
| STUPIDITY: Stupidity | - | 0.3 (7%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 5.3 | 1.0 | 0.3 |
| not cast | 2.0 | 3.0 | 4.7 | 3.0 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (100%) | 1.7 (36%) | 0.7 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (43%) | 1.0 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.3 (11%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (17%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (94%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (133 of 212) | 81% (13 of 16) | 64% (146 of 228) |
|   cavalry | 45% (9 of 20) | 25% (1 of 4) | 42% (10 of 24) |
|   character | 88% (29 of 33) | - | 88% (29 of 33) |
|   infantry | 45% (25 of 55) | - | 45% (25 of 55) |
|   monster | 58% (7 of 12) | - | 58% (7 of 12) |
|   war machine | 68% (63 of 92) | 100% (12 of 12) | 72% (75 of 104) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (16%) | 0.3 (33%) | 4.7 (17%) |
| CHARGED: it charged | 2.0 (8%) | 0.0 (0%) | 2.0 (7%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 9.7 (37%) | 0.3 (33%) | 10.0 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (6%) | 0.0 (0%) | 1.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.0 (27%) | 0.3 (33%) | 7.3 (27%) |
| SHELTERED: the target was sheltered | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.7 | 80% | 4.2 pts | 14 pts |
| character | 10.7 | 8.7 | 59% | 9.9 pts | 106 pts |
| infantry | 17.3 | 5.7 | 69% | 7.4 pts | 129 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.3 | 16.7 | 67% | 20.9 pts | 530 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.0 | 2.0 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.00 contact (3 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.14 contact (21 units) | 0.38 declared, 0.15 contact (13 units) | 0.32 declared, 0.15 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | 100% (1 of 1) | 50% (1 of 2) | 29% (2 of 7) |
| Character in a unit | 88% (7 of 8) | 75% (3 of 4) | 0% (0 of 1) | 77% (10 of 13) |
| Character on its own | - | 67% (2 of 3) | 100% (2 of 2) | 80% (4 of 5) |
| Infantry | 29% (2 of 7) | 67% (4 of 6) | - | 46% (6 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 93% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 56% (10 of 18) | 90% | 33% (3 of 9) | 100% (3 of 3); 11.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 92% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 47% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 50% (1) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: wfr-a92c160-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (32 of 71) | 53% (10 of 19) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 17% (1 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 337.0 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net -105 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +111 | 2 of 2, net +48 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (37 of 78) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 16.7 | 0.0 |
| Shooting | War machine shots | 21.0 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (42 of 63) | 15% (2 of 13) |
| Shooting | Points destroyed by war machines | 0.0 | 80.0 |
| Magic | Magic missiles cast | - | 4.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 25% (3 of 12) |
| Magic | Wounds caused by magic missiles | - | 2.7 |
| Magic | Wounds caused by other spells | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 40.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.7 / 0.3 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 0.0 | 66.7 |
| Combat | Points run down | 13.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +3 | +67 |
| Combat | Net per 100 charger points, damage counted | +2.7 | +36.7 |
| Combat | First round won (charged fights) | 50% | 50% |
| Combat | Net points per charged fight | +3 | +48 |
| Combat | Net points per supported fight / lone fight | -105 / +111 | - / +48 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 1 of 2 |
| Game | Points lost | 186.7 | 67.3 |
| Game | VP from objectives | 776.7 | 690.0 |
| Game | Lone holders (player turns) | 0.0 | 5.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -7 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 254
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.5 | 0.0 | 20.0 | - | - | - | - |
| ARMY TABLE | 6.7 | +109.9 | 0.0 | 75.0 | 8.3 | +129.9 | 0.0 | 37.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +3.7 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 17.3 | +108.0 | 50.7 | 40.0 | 4.0 | +128.7 | 80.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.3 | +5.7 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -199.3 | 0.0 | 86.7 | 20.3 | -1096.3 | 0.0 | 74.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 31.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 33.3 |
| COVER ONCE | 9.0 | -515.0 | 0.0 | 31.7 | 3.7 | -183.4 | 0.0 | 37.0 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -7.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 40.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -8.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +2.1 | 50.7 | 20.0 | 1.3 | +5.3 | 31.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 37.0 | 20.0 | 1.3 | +0.0 | 31.7 | 16.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 22.0 | +296.4 | 0.0 | 13.7 |
| FEATURE BUFFS | 0.7 | +1.8 | 0.0 | 0.0 | 1.3 | +3.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +1.2 | 50.7 | 20.0 | - | - | - | - |
| FIVE ACTION | 138.7 | +3682.9 | 239.7 | 528.3 | 71.7 | +1968.8 | 171.7 | 151.3 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 53.7 |
| FOUR ROUNDS | 2.0 | +76.6 | 50.7 | 75.0 | 2.0 | +53.6 | 31.7 | 16.7 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -14.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +286.5 | 0.0 | 0.0 | 1.7 | +51.1 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.9 | 37.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.7 | +9.6 | 0.0 | 0.0 | 1.3 | +49.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 31.7 | 10.0 | +0.0 | 0.0 | 74.0 |
| HIS CHARGE LIST | 15.0 | +0.0 | 0.0 | 63.3 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -25.0 | 0.0 | 55.0 | 3.3 | -33.8 | 0.0 | 13.7 |
| HIS MOVE AS HE DECIDES | 34.0 | +8.7 | 97.7 | 0.0 | 38.7 | +15.7 | 135.0 | 0.0 |
| HIS MOVE WHY | 42.3 | +0.0 | 0.0 | 135.0 | - | - | - | - |
| HIS ONE MOVE | 18.7 | +17.2 | 0.0 | 35.0 | 17.0 | -9.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 70.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.7 | +1432.4 | 0.0 | 290.0 | 46.0 | +5409.8 | 0.0 | 101.3 |
| HIS SHOTS BY HIS RUN | 26.7 | +436.6 | 0.0 | 210.0 | 41.3 | +1404.7 | 0.0 | 101.3 |
| HIS TURN DENIED | 0.3 | +0.4 | 0.0 | 35.0 | 0.7 | +32.0 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 16.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +955.5 | 0.0 | 0.0 | 9.7 | +1195.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -7.1 | 13.7 | 0.0 | 1.7 | -47.0 | 31.7 | 0.0 |
| IDLE COST | - | - | - | - | 18.7 | -453.8 | 0.0 | 53.7 |
| JOINT CHARGE NOW | 0.7 | +16.2 | 0.0 | 55.0 | 0.7 | +24.4 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +17.1 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +2.9 | 50.7 | 55.0 | 0.7 | -2.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +73.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +24.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.7 | +212.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 40.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 7.7 | +49.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 10.3 | +54.5 | 0.0 | 0.0 |
| MODEL FACING | 4.7 | +1421.7 | 0.0 | 60.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +146.4 | 0.0 | 0.0 | 2.0 | +105.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +257.2 | 0.0 | 0.0 | 5.0 | +236.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +50.5 | 0.0 | 0.0 | 1.7 | +83.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -22.5 | 50.7 | 55.0 | 1.3 | -19.4 | 31.7 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -100.5 | 0.0 | 20.0 | 3.3 | -114.7 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.3 | +2.6 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +4.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -17.3 | 0.0 | 55.0 | 2.0 | -49.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -107.2 | 0.0 | 0.0 | 4.3 | -31.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +68.6 | 0.0 | 0.0 |
| PLAN RESULT | 60.7 | +822.2 | 212.3 | 293.3 | 32.7 | +86.5 | 51.7 | 134.7 |
| PROMISE BY ITS OWN SUM | 6.0 | -85.9 | 0.0 | 0.0 | 2.3 | -15.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.3 | -9.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.0 | +1042.9 | 37.0 | 145.0 | 1.3 | +400.0 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +10.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +69.4 | 0.0 | 0.0 | 0.7 | +38.1 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +9.2 | 0.0 | 13.7 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -24.7 | 0.0 | 0.0 | 0.3 | -7.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +88.1 | 50.7 | 75.0 | 0.7 | +33.3 | 0.0 | 16.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -4.1 | 31.7 | 16.7 |
| RUN DOWN | 1.3 | -17.4 | 50.7 | 20.0 | 1.0 | -1.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -99.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +11.1 | 0.0 | 0.0 | 0.7 | +13.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.7 | -26.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 25.7 | +0.0 | 0.0 | 60.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +27.0 | 0.0 | 0.0 | 1.7 | +8.1 | 60.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -10.7 | 13.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 25.3 | +748.0 | 0.0 | 255.0 | 26.3 | -252.0 | 0.0 | 64.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 33.0 | +790.6 | 0.0 | 95.0 | 4.3 | +242.3 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +127.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 40.0 | 0.0 |
| STANDS STILL | 103.0 | +0.0 | 189.0 | 318.3 | 17.7 | +0.0 | 140.0 | 0.0 |
| STAY WORTH | 62.3 | +117.6 | 189.0 | 175.0 | 12.7 | +162.0 | 80.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.7 | +5.2 | 0.0 | 35.0 | 0.7 | +9.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 57.7 | +0.0 | 0.0 | 155.0 | 36.0 | +0.0 | 0.0 | 67.3 |
| TIED UP BY THE SUM | 1.0 | +26.5 | 50.7 | 20.0 | 0.3 | +22.0 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 60.7 | +631.8 | 0.0 | 100.0 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.1 | 13.7 | 0.0 | 1.3 | +8.2 | 31.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -94.7 | 0.0 | 31.7 | 0.7 | -21.5 | 0.0 | 37.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +385.3 | 55.0 | 50.7 |
| WOUNDS ON THE RANKS | 1.3 | +19.5 | 0.0 | 0.0 | 3.0 | +363.0 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 218 | 218 | 145 | 48.33 | +0 | +0.0 |
| HIS SHOT LIST | 287 | 285 | 89 | 29.67 | +3241 | +36.4 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3343 | +61.9 |
| HIS MOVE WHY | 127 | 127 | 53 | 17.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 204 | 198 | 52 | 17.33 | +1005 | +19.3 |
| SHOT RISK POINTS | 155 | 153 | 37 | 12.33 | +2056 | +55.6 |
| ARMY TABLE | 45 | 45 | 36 | 12.00 | +789 | +21.9 |
| HIS ONE MOVE | 107 | 105 | 35 | 11.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| TIME ON OUR SIDE | 182 | 171 | 32 | 10.67 | +59 | +1.8 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -646 | -26.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| FIVE ACTION | 631 | 625 | 15 | 5.00 | +272 | +18.1 |
| COVER ONCE | 38 | 35 | 14 | 4.67 | +115 | +8.2 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4265 | +304.7 |
| CHARGE LOSSES | 98 | 96 | 13 | 4.33 | +962 | +74.0 |
| MOVE TO CHARGE COMPUTED | 19 | 17 | 12 | 4.00 | +170 | +14.2 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 56 | 46 | 11 | 3.67 | +466 | +42.3 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +8 | +0.8 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 10 | 3.33 | -305 | -30.5 |
| SHOTS AFTER THE MOVES | 23 | 23 | 10 | 3.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 9 | 3.00 | +46 | +5.2 |
| THE RISK READS HIS RUN | 36 | 36 | 9 | 3.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 64 | 64 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 12 | 12 | 7 | 2.33 | +128 | +18.2 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| GOAL WALK | 16 | 16 | 6 | 2.00 | +584 | +97.4 |
| RISK BY ARC | 8 | 8 | 6 | 2.00 | +120 | +20.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 13 | 13 | 5 | 1.67 | +172 | +34.4 |
| FALLS SHORT | 66 | 60 | 4 | 1.33 | +59 | +14.7 |
| GUN MASK | 12 | 12 | 4 | 1.33 | +73 | +18.2 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +122 | +30.5 |
| NEXT CHARGE BY LIST | 8 | 8 | 4 | 1.33 | +77 | +19.3 |
| STAY WORTH | 225 | 212 | 4 | 1.33 | +13 | +3.3 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +43 | +10.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +138 | +46.0 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +99 | +33.1 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +74 | +24.7 |
| SHOTS IN THE MOVE | 112 | 96 | 3 | 1.00 | +65 | +21.6 |
| WHOLE FIGHT REACTION | 5 | 5 | 3 | 1.00 | +4 | +1.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -73 | -36.5 |
| NEARER NOT NEEDED | 32 | 30 | 2 | 0.67 | +33 | +16.6 |
| QUARTER ODDS | 55 | 54 | 2 | 0.67 | +238 | +118.9 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +19 | +19.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -9 | -8.6 |
| CAST JOB | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -14 | -13.9 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +64 | +63.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +51 | +51.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +206 | +205.7 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +9 | +9.0 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 56 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 72 | 72 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 5 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 89 | 89 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 23 | 19 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 26 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 12 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 28 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 280 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 95 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 24 | 19 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 362 | 359 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 281 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 3.00 | 27.8 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 0.33 | 30.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 24.3 |
| MARCH OF THE TABLE | rule | - | 0.67 | 36.5 |
| BEST PRIZE | rule | - | 0.33 | 8.6 |
| CHARGE NOW FIRST | rule | - | 0.33 | 13.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| NO REASON | gate | - | 0.33 | 5.1 |

### Plans: wfr-a92c160-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 116 | 51 | 44% |
| Mine | join | 1.7 | 100% | 54 | 0 | 0% |
| Mine | move | 37.3 | 99% | 1041 | 0 | 0% |
| Mine | shoot | 20.7 | 53% | 442 | 772 | 174% |
| Opponent | charge | 1.0 | 33% | 55 | 32 | 57% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 25.3 | 97% | 779 | 0 | 0% |
| Opponent | shoot | 4.3 | 46% | 141 | 55 | 39% |
| Opponent | support | 1.0 | 100% | 25 | 0 | 0% |

### Battle groups: wfr-a92c160-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 0 | 38% | 2.6 | 6 (6) | 0 (6) | 0 (1) | 4 (11) | 0 (2) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 10 | 75% | 1.0 | 0 (1) | 0 (1) | 36 (2) | 18 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 53 | 0% | 1.3 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 121 (4) | 0 | 121 | 0 | 50% | 2.0 | 0 (1) | 206 (3) | - | 121 (4) | - |
| Mine | Shooter | 8 | 77 (8) | 3 | 73 | 8 | 12% | 2.4 | 115 (1) | 118 (4) | 9 (3) | 68 (6) | 98 (2) |
| Mine | War machine | 17 | 0 (17) | 0 | 0 | 16 | 12% | 1.4 | 0 (4) | 0 (9) | 0 (4) | 0 (3) | 0 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 100% | - | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 7 (10) | 7 | 0 | 2 | 50% | 3.0 | 6 (3) | 10 (5) | 0 (2) | 8 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 214 (1) | 59 | 155 | 0 | 0% | 3.0 | - | 214 (1) | - | 214 (1) | - |
| Opponent | Fast Hammer | 3 | 23 (3) | 0 | 23 | 0 | 67% | 6.0 | 0 (1) | 76 (1) | 0 (1) | 32 (2) | 0 (1) |
| Opponent | Holder | 6 | 78 (6) | 0 | 78 | 10 | 33% | 4.0 | 18 (1) | 89 (5) | - | 103 (4) | 37 (2) |
| Opponent | War machine | 2 | 73 (2) | 73 | 0 | 0 | 0% | 1.0 | - | 109 (1) | 36 (1) | - | 73 (2) |
| Opponent | Wizard | 2 | 9 (2) | 9 | 0 | 0 | 0% | 3.0 | 0 (1) | 17 (1) | - | 9 (2) | - |

### Charged fights: wfr-a92c160-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 17 | 37 | 0.7 | 1.5 | 56 | 52 | +3 | 1 of 2 | 1 of 2 | -105 | +111 |
| Opponent | Grand Cathay | 1 | 300 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 95 | 1.0 | 1.0 | 95 | 0 | +95 | 0 of 1 | 1 of 1 | - | +95 |
| Opponent | Warriors of Chaos | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 120 | 32 | 0.7 | 1.0 | 48 | 0 | +48 | 1 of 2 | 1 of 2 | - | +48 |

### Effective charges: wfr-a92c160-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net -105) | 0 | 0 | 0 | 0 | 1 (net +111) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 165 | 357 | -105 | 0 | 105 | -105 | -63.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 60 | 111 | +111 | 111 | 0 | +111 | +185.0 |
| Mine | All fights | 2 | 112 | 234 | +3 | 56 | 52 | +3 | +2.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 183 | 139 | +48 | 67 | 0 | +67 | +36.7 |
| Opponent | All fights | 2 | 183 | 139 | +48 | 67 | 0 | +67 | +36.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p4 | move | 11 | 4 (36%) | 1 (9%) | 1 (9%) | 6 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

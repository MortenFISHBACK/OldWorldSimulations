# Doctrine scorecard: wfr-a92c160-p11

### Scorecard: wfr-a92c160-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | no | 3 | - | 1 | 1 | 0 | 0 | 0 | 600 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 254 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 1 | 0 | 0 | 340 |
| L2335 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2335 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 50% | 3.0 | 3.0 | 3.0 | 0.5 | 0.0 | 0.0 | 0.0 | 427.0 |
| **Average** | | | Opponent | 50% | 2.0 | 2.0 | 2.5 | 1.5 | 1.0 | 0.0 | 0.0 | 170.0 |

### KPIs: wfr-a92c160-p11

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 10% (1 of 10) | 0% (0 of 12) | 5% (1 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (2 of 4); on the table 75% | 50% (2 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 75% (6 of 8); on the table 88% | 75% (9 of 12); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | 36% (5 of 14) | 30% (6 of 20) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 17% (1 of 6) | 40% (4 of 10) | 31% (5 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (8 of 13) | 62% (5 of 8) | 62% (13 of 21) |
| Points that never fought | lower | 65% (2601 of 3999) | 57% (2295 of 4000) | 61% (4896 of 7999) |
|   infantry points that never fought | lower | 74% (871 of 1175) | 56% (230 of 410) | 69% (1101 of 1585) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (8 of 14) | 89% (16 of 18) | 75% (24 of 32) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 1.3 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (1507 of 3038) | 84% (2996 of 3546) | 68% (4503 of 6584) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (40%) | 1.7 (62%) | 2.3 (54%) |
| MARCHED: its unit marched | 1.0 (60%) | 0.3 (12%) | 1.3 (31%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (12%) | 0.3 (8%) |
| GONE: slain | 0.0 (0%) | 0.3 (12%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 9.7 | 0.3 | 0.3 | 2.0 | 0.7 | 0.0 |
| not cast | 3.0 | 0.3 | 0.0 | 4.3 | 1.3 | 13.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | - | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | - | 1.3 (31%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | - | 0.3 (8%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.3 (11%) | 0.0 (0%) | - | 0.3 (8%) | 0.3 (25%) | 0.7 (5%) |
| STUPIDITY: Stupidity | 0.3 (11%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 12.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 0% (0 of 1) | 0% (0 of 1) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (40 of 69) | - | 58% (40 of 69) |
|   cavalry | 100% (7 of 7) | - | 100% (7 of 7) |
|   character | 0% (0 of 8) | - | 0% (0 of 8) |
|   chariot | 77% (10 of 13) | - | 77% (10 of 13) |
|   infantry | 56% (23 of 41) | - | 56% (23 of 41) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | - | 0.3 (3%) |
| CHARGED: it charged | 1.7 (17%) | - | 1.7 (17%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | - | 0.3 (3%) |
| NO TARGET IN RANGE | 3.0 (31%) | - | 3.0 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 2.3 (24%) | - | 2.3 (24%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (21%) | - | 2.0 (21%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.3 | 1.0 | 70% | 4.6 pts | 15 pts |
| infantry | 8.3 | 3.0 | 80% | 7.6 pts | 63 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 4.3 | 4.0 |
| Charges that made contact a game | 2.7 | 2.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.00 contact (2 units) | 1.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.34 declared, 0.25 contact (32 units) | 0.44 declared, 0.28 contact (25 units) | 0.39 declared, 0.26 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | 100% (1 of 1) | 0% (0 of 1) | 83% (5 of 6) |
| Character in a unit | 100% (3 of 3) | - | 100% (1 of 1) | 100% (4 of 4) |
| Character on its own | 100% (5 of 5) | - | 50% (2 of 4) | 78% (7 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Monster | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 65% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 50% (1 of 2); on the table 50% | - | 65% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 60% (3 of 5); on the table 80% | 67% (4 of 6) | 67% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 47% | 92% (11 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 67% (4) | 64% (7) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: wfr-a92c160-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 36% (4 of 11) | 36% (4 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (5 of 18) | 17% (1 of 6) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 33% (1 of 3) | 25% (2 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.5 | 1.5 |
| Movement | Points that never moved of their own | 427.0 | 170.0 |
| Movement | Fights charged into per game | 3.5 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +75 | 2 of 4, net +2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | 1 of 4, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 6, net +0 | 0 of 4 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 16% (7 of 44) | - |
| Shooting | Points destroyed by shooting units | 165.3 | 48.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.0 / 0.0 / 0.0 | 2.3 / 0.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 252.0 | 42.3 |
| Combat | Points run down | 38.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +34 | -23 |
| Combat | Net per 100 charger points, damage counted | +14.5 | -32.1 |
| Combat | First round won (charged fights) | 43% | 80% |
| Combat | Net points per charged fight | +52 | -24 |
| Combat | Net points per supported fight / lone fight | - / +52 | +0 / -30 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 1 of 5 |
| Game | Points lost | 158.5 | 684.0 |
| Game | VP from objectives | 895.0 | 540.0 |
| Game | Lone holders (player turns) | 3.0 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +877 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 842
- Games not ended: 1 (L2335-1); findings 2, warnings 0

### Opponent rules: wfr-a92c160-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | +752.0 | 0.0 | 0.0 | 16.7 | +204.7 | 0.0 | 200.7 |
| BACKUP TARGETS | 0.7 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE HANDED OVER | 0.3 | +83.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +6.0 | 96.0 | 77.3 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +10.9 | 0.0 | 0.0 | 2.3 | +32.8 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +118.2 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.3 | -506.2 | 0.0 | 0.0 | 12.0 | -497.2 | 0.0 | 237.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 175.3 | 0.0 | 1.7 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 48.0 | 7.0 | +0.0 | 0.0 | 124.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| COVER ONCE | 5.0 | -260.9 | 0.0 | 0.0 | 6.0 | -284.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +154.6 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +6.6 | 138.3 | 0.0 | 3.0 | +6.3 | 33.3 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.1 | 182.3 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.0 | +39.6 | 0.0 | 0.0 | 17.0 | +139.2 | 0.0 | 122.0 |
| FEATURE BUFFS | 1.3 | +5.5 | 0.0 | 48.0 | 2.0 | +5.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +1.0 | 25.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 87.7 | +6814.1 | 821.0 | 199.7 | 60.0 | +3278.8 | 129.3 | 615.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 15.0 | 6.0 | +0.0 | 0.0 | 38.7 |
| FOLLOW UP WEIGHED | 1.0 | +90.0 | 0.0 | 0.0 | 0.3 | +50.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.7 | +359.0 | 239.0 | 0.0 | 4.0 | +101.3 | 33.3 | 16.7 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 237.3 |
| FRIEND SHOOTS FIRST | 0.7 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.8 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| GOAL WALK | 16.0 | +1972.3 | 0.0 | 0.0 | 5.3 | +323.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 4.0 | +0.0 | 0.0 | 40.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 113.3 |
| HIS CHARGE DENIED | 0.3 | +20.2 | 62.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 40.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | 1.0 | -13.5 | 0.0 | 0.0 | 3.7 | -55.8 | 0.0 | 118.7 |
| HIS MOVE AS HE DECIDES | 34.3 | +11.7 | 441.3 | 0.0 | 37.7 | +15.0 | 57.3 | 0.0 |
| HIS MOVE WHY | 20.0 | +0.0 | 0.0 | 48.3 | 13.7 | +0.0 | 0.0 | 78.7 |
| HIS ONE MOVE | 16.0 | -21.3 | 0.0 | 0.0 | 17.0 | +95.8 | 0.0 | 120.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 62.0 |
| HIS RANDOM MOVE | 13.7 | +0.0 | 0.0 | 48.0 | 11.0 | +0.0 | 0.0 | 290.7 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 48.0 | 3.0 | +0.0 | 0.0 | 164.0 |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 25.0 | +323.9 | 0.0 | 48.0 | 39.7 | +989.1 | 0.0 | 340.7 |
| HIS SHOTS BY HIS RUN | 17.7 | +159.8 | 0.0 | 48.0 | 39.0 | +691.6 | 0.0 | 394.7 |
| HIS TURN DENIED | 0.3 | +2.2 | 0.0 | 0.0 | 0.7 | +1.9 | 0.0 | 0.0 |
| HIS TURN RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 96.0 | 12.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +736.2 | 0.0 | 48.0 | 7.7 | +727.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -109.4 | 239.0 | 0.0 | 3.7 | -84.9 | 33.3 | 0.0 |
| IDLE COST | 3.3 | -55.1 | 0.0 | 0.0 | 12.0 | -114.7 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +47.6 | 0.0 | 16.7 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 211.7 | 24.0 | 2.7 | +0.0 | 0.0 | 127.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | +1.0 | 63.7 | 0.0 | 1.0 | +1.0 | 18.3 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | -2.9 | 0.0 | 20.0 |
| MARCH OVER CASTS | 0.7 | -11.5 | 0.0 | 0.0 | 0.3 | +9.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +10.7 | 0.0 | 0.0 | 1.7 | +12.9 | 0.0 | 38.7 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +29.8 | 0.0 | 0.0 | 3.7 | +74.4 | 0.0 | 140.7 |
| MISSILES NEXT TURN | 3.3 | +34.2 | 0.0 | 0.0 | 5.3 | +50.3 | 0.0 | 102.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +924.1 | 0.0 | 0.0 | 6.3 | +623.1 | 0.0 | 124.0 |
| NEARER NOT NEEDED | 11.0 | +398.6 | 0.0 | 0.0 | 5.3 | +171.4 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 2.7 | +613.8 | 0.0 | 0.0 | 3.3 | +329.3 | 0.0 | 124.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -7.4 | 0.0 | 0.0 | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -132.0 | 138.3 | 0.0 | 2.3 | -152.3 | 33.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -193.3 | 0.0 | 0.0 | 6.3 | -176.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -73.1 | 0.0 | 0.0 | 5.3 | -62.3 | 0.0 | 62.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -35.5 | 0.0 | 24.0 | 2.7 | -45.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +10.9 | 0.0 | 0.0 | 0.7 | +22.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +8.7 | 15.0 | 0.0 |
| PATHS CROSS | 0.3 | +3.9 | 0.0 | 0.0 | 1.0 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 38.0 | +474.3 | 395.3 | 42.3 | 34.0 | +75.7 | 24.0 | 748.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -151.0 | 0.0 | 0.0 | 7.3 | -188.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -35.2 | 0.0 | 0.0 | 0.3 | -31.6 | 0.0 | 0.0 |
| QUARTER ODDS | 18.7 | +1693.1 | 546.0 | 0.0 | 15.7 | +1561.9 | 0.0 | 354.7 |
| RANDOM MOVE BY FIGURES | 4.3 | +258.4 | 0.0 | 48.3 | 2.7 | +21.4 | 0.0 | 113.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1.0 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +124.5 | 0.0 | 42.3 | 2.0 | +92.3 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.0 | +28.2 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -16.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +13.6 | 200.3 | 0.0 | 3.0 | -28.7 | 33.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -27.1 | 38.7 | 0.0 | 1.0 | -1.1 | 0.0 | 16.7 |
| RUN DOWN | 2.0 | -139.8 | 38.7 | 0.0 | 1.3 | -3.6 | 33.3 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -94.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +7.8 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +14.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -8.0 | 0.0 | 0.0 | 2.3 | -51.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | -162.3 | 0.0 | 0.0 | 3.0 | +79.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +32.7 | 86.7 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.7 | -7.4 | 113.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 15.0 | -120.1 | 0.0 | 0.0 | 19.0 | -141.9 | 0.0 | 314.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +294.5 | 0.0 | 24.0 | 1.7 | +23.1 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +19.2 | 0.0 | 0.0 | 3.7 | +5.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 235.0 |
| STAND AND SHOOT | 0.3 | -1.9 | 0.0 | 0.0 | 1.3 | -1.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 34.3 | +0.0 | 582.0 | 151.7 | 18.0 | +0.0 | 96.0 | 117.3 |
| STAY WORTH | 14.0 | +50.9 | 353.3 | 0.0 | 3.7 | +23.8 | 96.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +11.4 | 56.7 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.3 | +283.9 | 0.0 | 0.0 | 1.0 | +53.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 87.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 5.3 | +283.9 | 0.0 | 0.0 | 1.0 | +53.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -72.1 | 0.0 | 0.0 | 0.7 | -45.5 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 38.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 38.7 |
| THE TABLE AGAIN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.0 | +0.0 | 0.0 | 75.7 | 29.0 | +0.0 | 0.0 | 222.7 |
| TIED UP BY THE SUM | 1.7 | +219.5 | 113.3 | 0.0 | 1.3 | +146.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 38.3 | +329.1 | 56.7 | 194.0 | 3.7 | +41.7 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -7.7 | 0.0 | 16.7 |
| WHO FIGHTS | 0.7 | +5.4 | 25.0 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +56.4 | 0.0 | 16.7 |
| WHO HITS BACK | 0.3 | +40.2 | 0.0 | 0.0 | 0.7 | +74.3 | 0.0 | 56.7 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +1.4 | 0.0 | 16.7 |
| WHOLE FIGHT DANGER | 4.7 | -419.1 | 0.0 | 0.0 | 1.7 | -258.0 | 0.0 | 56.7 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +226.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +66.2 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 216 | 216 | 136 | 45.33 | +0 | +0.0 |
| ARMY TABLE | 120 | 120 | 93 | 31.00 | +2551 | +27.4 |
| HIS MOVE WHY | 101 | 101 | 65 | 21.67 | +0 | +0.0 |
| HIS SHOT LIST | 194 | 182 | 48 | 16.00 | +586 | +12.2 |
| HOLDER ASSIGNMENT | 54 | 54 | 48 | 16.00 | +2675 | +55.7 |
| HIS SHOTS BY HIS RUN | 170 | 163 | 33 | 11.00 | +193 | +5.8 |
| FIVE ACTION | 443 | 430 | 31 | 10.33 | +1104 | +35.6 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1111 | -39.7 |
| HIS ONE MOVE | 99 | 97 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| QUARTER ODDS | 103 | 100 | 22 | 7.33 | +1331 | +60.5 |
| THE TABLE AGAIN | 27 | 27 | 22 | 7.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 20 | 6.67 | +68 | +3.4 |
| GOAL WALK | 64 | 63 | 16 | 5.33 | +1219 | +76.2 |
| MOVE TO CHARGE COMPUTED | 31 | 28 | 16 | 5.33 | +1107 | +69.2 |
| THE RISK READS HIS RUN | 27 | 27 | 15 | 5.00 | +0 | +0.0 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 21 | 21 | 13 | 4.33 | +839 | +64.6 |
| FOUR ROUNDS | 23 | 23 | 12 | 4.00 | +480 | +40.0 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 12 | 4.00 | -1018 | -84.8 |
| NEXT CHARGE BY LIST | 18 | 18 | 11 | 3.67 | +1086 | +98.7 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 9 | 9 | 9 | 3.00 | +254 | +28.3 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 126 | 107 | 8 | 2.67 | +20 | +2.5 |
| IDLE COST | 46 | 23 | 7 | 2.33 | +26 | +3.8 |
| SUPPORT ADDS | 19 | 18 | 7 | 2.33 | +263 | +37.6 |
| SUPPORT WORKED OUT | 19 | 18 | 7 | 2.33 | +263 | +37.6 |
| CHARGE LOSSES | 67 | 65 | 6 | 2.00 | +1538 | +256.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| CHAFF IN THE MOVE | 9 | 8 | 5 | 1.67 | +11 | +2.3 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 5 | 1.67 | +10 | +2.0 |
| SHOT RISK POINTS | 102 | 99 | 5 | 1.67 | +29 | +5.7 |
| WHOLE FIGHT DANGER | 19 | 19 | 5 | 1.67 | +274 | +54.8 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +420 | +105.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +134 | +33.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 13 | 13 | 4 | 1.33 | +28 | +7.1 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 33 | 20 | 3 | 1.00 | +81 | +27.1 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +143 | +47.6 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +26 | +8.7 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| SUPPORT NARROWED | 3 | 3 | 3 | 1.00 | -273 | -90.9 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +245 | +81.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +397 | +198.4 |
| EVASIVE BY THE ODDS | 4 | 4 | 2 | 0.67 | +446 | +222.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 7 | 7 | 2 | 0.67 | +8 | +3.8 |
| NO DOUBLE ROUNDS | 16 | 16 | 2 | 0.67 | +63 | +31.6 |
| SHOTS AFTER THE MOVES | 11 | 11 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 53 | 52 | 2 | 0.67 | +8 | +4.1 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +1 | +0.7 |
| THE ROW IN ITS ORDER | 12 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +169 | +84.7 |
| WHOLE FIGHT REACTION | 5 | 5 | 2 | 0.67 | +246 | +123.2 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.33 | +249 | +248.9 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CAST JOB | 6 | 6 | 1 | 0.33 | +1 | +1.1 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| CHARGE NOW FIRST | 12 | 12 | 1 | 0.33 | -2 | -1.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| EXACT ROUND | 16 | 16 | 1 | 0.33 | +0 | +0.3 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +24 | +24.1 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +0 | +0.3 |
| MISSILES IN THE MOVE | 17 | 11 | 1 | 0.33 | +22 | +22.3 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +0 | +0.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +16 | +15.7 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -19 | -19.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +106 | +106.2 |
| RISK BY ARC | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +43 | +43.4 |
| SHOTS IN THE MOVE | 53 | 48 | 1 | 0.33 | +17 | +17.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +34 | +34.2 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE PROMISE ADDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 44 | 42 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 14 | 14 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 63 | 48 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 14 | 13 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 11 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 74 | 72 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 19 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 27 | 27 | 0 | 0.00 | - | - |
| HIS TURN RUN | 28 | 28 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 85 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 22 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 16 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 49 | 46 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 10 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 216 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 15 | 12 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 157 | 154 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 204 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 5.33 | 44.9 |
| ARMY TABLE | rule | 4.00 | 1.67 | 47.0 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 2.67 | 84.8 |
| SUPPORT NARROWED | rule | 1.00 | - | 90.9 |
| NO REASON | gate | - | 0.67 | 14.8 |
| AFTERMATH BAND | gate | 0.33 | - | 3.7 |
| CHARGE NOW FIRST | rule | 0.33 | - | 1.5 |
| FALLBACK | gate | - | 0.33 | 0.7 |
| FOLLOW UP WEIGHED | rule | 0.33 | - | 3.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 28.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 26.6 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 19.2 |

### Plans: wfr-a92c160-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 50% | 529 | 206 | 39% |
| Mine | move | 30.7 | 96% | 2066 | 0 | 0% |
| Mine | shoot | 4.0 | 67% | 238 | 268 | 112% |
| Mine | support | 0.7 | 100% | 15 | 0 | 0% |
| Opponent | charge | 2.7 | 25% | 262 | 52 | 20% |
| Opponent | join | 5.3 | 94% | 252 | 0 | 0% |
| Opponent | move | 23.3 | 93% | 1061 | 0 | 0% |
| Opponent | shoot | 1.7 | 20% | 42 | 24 | 57% |
| Opponent | support | 1.0 | 100% | 12 | 0 | 0% |

### Battle groups: wfr-a92c160-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 33% | 33% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 0% | 1.2 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Mine | Character | 5 | 30 (5) | 30 | 0 | 0 | 20% | 2.8 | 54 (2) | 0 (3) | - | 54 (2) | 0 (3) |
| Mine | Clean-up | 1 | 293 (1) | 0 | 293 | 0 | 0% | 3.0 | - | 293 (1) | - | - | 293 (1) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (2) | - | - | - | 0 (2) |
| Mine | Hammer | 4 | 119 (4) | 106 | 12 | 20 | 25% | 1.3 | 153 (3) | 41 (1) | - | 200 (2) | 64 (2) |
| Mine | Holder | 7 | 104 (7) | 44 | 60 | 0 | 14% | 2.3 | 197 (2) | 70 (5) | - | 279 (2) | 41 (5) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 4 | 154 (4) | 42 | 112 | 75 | 25% | 3.3 | 206 (3) | - | 0 (1) | 206 (3) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 3 | 56% | 4.5 | 0 (2) | 0 (7) | - | 0 (5) | 0 (4) |
| Opponent | Fast Hammer | 4 | 6 (4) | 0 | 6 | 39 | 25% | 4.0 | - | 6 (4) | - | 0 (1) | 8 (3) |
| Opponent | Hammer | 3 | 16 (3) | 16 | 0 | 100 | 0% | 3.7 | - | 16 (3) | - | 21 (2) | 0 (1) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 76 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 376 | 75 | 3.0 | 1.0 | 25 | 0 | +25 | 0 of 3 | 1 of 3 | - | +25 |
| Mine | Tomb Kings of Khemri | 1 | 120 | 286 | 4.0 | 1.0 | 72 | 0 | +72 | 2 of 4 | 2 of 4 | - | +72 |
| **Mine** | all armies | 2 | 248 | 180 | 3.5 | 1.0 | 52 | 0 | +52 | 2 of 7 | 3 of 7 | - | +52 |
| Opponent | Vampire Counts | 1 | 145 | 100 | 4.0 | 1.2 | 25 | 12 | +12 | 0 of 4 | 3 of 4 | +0 | +17 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 170 | -170 | 1 of 1 | 1 of 1 | - | -170 |
| **Opponent** | all armies | 2 | 72 | 50 | 2.5 | 1.2 | 20 | 44 | -24 | 1 of 5 | 4 of 5 | +0 | -30 |

### Effective charges: wfr-a92c160-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 3 | 1 (net +75) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +170) | 0 | 2 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 4 | 2 (net +2) | 0 | 1 (net +0) | 1 (net +45) | 0 | 0 | 0 | 25% (1 of 4) |

### Charged fights, damage counted: wfr-a92c160-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 41 | 75 | +75 | 75 | 37 | +38 | +92.0 |
| Mine | Effective (55-75%) | 1 | 41 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 431 | 201 | +170 | 248 | 96 | +153 | +35.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 318 | 175 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 195 | 201 | +116 | 116 | 65 | +51 | +26.2 |
| Mine | All fights | 7 | 237 | 154 | +52 | 63 | 28 | +34 | +14.5 |
| Opponent | Long shot (under 50%) | 2 | 48 | 74 | +2 | 30 | 25 | +5 | +10.1 |
| Opponent | Effective (55-75%) | 1 | 100 | 92 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 45 | 45 | +45 | 45 | 0 | +45 | +100.0 |
| Opponent | No odds | 1 | 120 | 431 | -170 | 0 | 170 | -170 | -141.7 |
| Opponent | All fights | 5 | 72 | 143 | -24 | 21 | 44 | -23 | -32.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p11 | move | 20 | 5 (25%) | 2 (10%) | 3 (15%) | 12 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

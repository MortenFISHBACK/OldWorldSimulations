# Doctrine scorecard: wfr-a92c160-p26

### Scorecard: wfr-a92c160-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 9 | 0 | 0 | 0 | 285 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 148 |
| L0235 | 1 | 1 | Mine | no | 4 | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 5 | 5 | 1 | 0 | 0 | 0 | 0 | 540 |
| L0319 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.5 | 5.0 | 0.3 | 5.3 | 0.0 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 0.5 | 2.5 | 0.3 | 3.7 | 0.0 | 0.0 | 0.0 | 91.0 |

### KPIs: wfr-a92c160-p26

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (2 of 8) | 0% (0 of 14) | 9% (2 of 22) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 67% (28 of 42) | 17% (4 of 24) | 48% (32 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (28 of 42) | 17% (4 of 24) | 48% (32 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (9 of 12) | - | 75% (9 of 12) |
| Points that never fought | lower | 88% (5125 of 5797) | 81% (4885 of 6000) | 85% (10010 of 11797) |
|   infantry points that never fought | lower | 100% (1374 of 1374) | 85% (717 of 842) | 94% (2091 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 85% (17 of 20) | 52% (14 of 27) | 66% (31 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.7 uses a game | 50% (1 of 2); 1.7 uses a game | 83% (5 of 6); 4.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 80% (3233 of 4039) | 53% (2938 of 5515) | 65% (6171 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (100%) | 0.0 (0%) | 4.7 (41%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (10%) | 0.7 (6%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.3 (65%) | 4.3 (38%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (25%) | 1.7 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 2.0 | 2.7 | 10.7 | 0.0 |
| not cast | 2.0 | 7.3 | 11.3 | 28.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 4.7 (41%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 4.0 (55%) | 4.3 (38%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (15%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 3.3 (45%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.7 a game | 1.3 a game |
| stood (cast and not dispelled) | 83% (5 of 6) | 50% (1 of 2) | 75% (6 of 8) |
| the unit moved after it | 100% (5 of 5) | 0% (0 of 1) | 83% (5 of 6) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (5 of 5) | 100% (1 of 1) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (18 of 30) | 54% (43 of 80) | 55% (61 of 110) |
|   cavalry | - | 61% (11 of 18) | 61% (11 of 18) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | 30% (3 of 10) | 58% (7 of 12) | 45% (10 of 22) |
|   infantry | - | 31% (8 of 26) | 31% (8 of 26) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 75% (15 of 20) | - | 75% (15 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (42%) | 3.0 (24%) | 4.7 (29%) |
| CHARGED: it charged | 0.3 (8%) | 0.3 (3%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.7 (17%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.0 (49%) | 6.0 (37%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (25%) | 1.0 (8%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 1.7 (14%) | 1.7 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.3 | 93% | 0.6 pts | 3 pts |
| character | 2.3 | 1.7 | 43% | 17.7 pts | 41 pts |
| chariot | 3.3 | 2.7 | 50% | 15.3 pts | 51 pts |
| infantry | 2.7 | 1.0 | 75% | 4.4 pts | 12 pts |
| monster | 3.3 | 3.7 | 50% | 14.8 pts | 49 pts |
| war machine | 5.0 | 4.7 | 73% | 29.4 pts | 147 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 2.7 | 1.5 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (25 units) | 0.28 declared, 0.07 contact (29 units) | 0.17 declared, 0.06 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 0% (0 of 1) | - | 25% (1 of 4) |
| Character in a unit | 75% (6 of 8) | 71% (5 of 7) | - | 73% (11 of 15) |
| Character on its own | - | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) |
| Chariot | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |
| Infantry | 60% (3 of 5) | 33% (1 of 3) | - | 50% (4 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | - | 87% (26 of 30) | 99% | 83% (10 of 12) | 100% (4 of 4); 10.0 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 17% (2 of 12) | 69% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 12) | 50% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | - | 67% (4 of 6) | 94% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 0% (0 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (8 of 21) | 47% (7 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 67% (4 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 5.3 | 3.7 |
| Movement | Points that never moved of their own | 275.0 | 91.0 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net +0 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 37% (16 of 43) |
| Shooting | Points destroyed by shooting units | 0.0 | 28.3 |
| Shooting | War machine shots | 5.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (5 of 15) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 4.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 21% (3 of 14) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 12.7 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 41.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 120.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +149 | +262 |
| Combat | Net per 100 charger points, damage counted | +48.0 | +112.0 |
| Combat | First round won (charged fights) | 0% | 100% |
| Combat | Net points per charged fight | +0 | +262 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +262 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 1 of 2 |
| Game | Points lost | 344.0 | 115.0 |
| Game | VP from objectives | 693.3 | 1046.7 |
| Game | Lone holders (player turns) | 4.5 | 0.5 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -504 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 459
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 14.0 | +241.1 | 0.0 | 34.7 | 25.7 | +429.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | +27.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 55.0 | 36.7 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +29.4 | 91.7 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +93.6 | 0.0 | 0.0 | 1.7 | +31.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +83.4 | 0.0 | 0.0 | 1.0 | +0.6 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.0 | -249.5 | 0.0 | 354.0 | 9.3 | -504.2 | 0.0 | 36.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 17.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 17.3 | 9.7 | +0.0 | 0.0 | 18.3 |
| CONVEYANCE SEARCH | 2.0 | +256.3 | 0.0 | 0.0 | 0.7 | +69.4 | 0.0 | 0.0 |
| COVER ONCE | 3.7 | -92.4 | 0.0 | 133.7 | 3.0 | -72.2 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -19.6 | 0.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | -52.9 | 0.0 | 0.0 | 1.3 | +0.7 | 17.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.7 | 0.0 | 0.0 | 1.3 | +12.7 | 17.3 | 0.0 |
| FALLS SHORT | 22.0 | +297.6 | 0.0 | 80.3 | 3.0 | +83.5 | 0.0 | 0.0 |
| FEATURE BUFFS | 13.3 | +573.3 | 0.0 | 60.7 | 1.0 | +24.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 93.0 | +7524.0 | 110.0 | 962.7 | 99.7 | +6024.4 | 187.3 | 110.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 120.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +290.7 | 0.0 | 0.0 | 1.7 | +99.6 | 17.3 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -5.4 | 0.0 | 0.0 |
| GOAL WALK | 7.7 | +850.8 | 0.0 | 0.0 | 11.7 | +961.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +2.6 | 0.0 | 103.3 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 336.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +22.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 69.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 237.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -78.7 | 0.0 | 74.0 | 2.0 | -57.0 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 50.7 | +16.3 | 110.0 | 0.0 | 37.0 | +10.7 | 363.0 | 0.0 |
| HIS MOVE WHY | 25.3 | +0.0 | 0.0 | 289.0 | 23.3 | +0.0 | 0.0 | 0.0 |
| HIS ONE MOVE | 17.0 | +46.1 | 0.0 | 357.7 | 19.3 | +69.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 30.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 21.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 61.0 | +2042.0 | 0.0 | 232.0 | 67.0 | +3329.2 | 0.0 | 110.0 |
| HIS SHOTS BY HIS RUN | 53.0 | +981.3 | 0.0 | 669.3 | 40.3 | +1108.0 | 0.0 | 110.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 36.7 | +0.0 | 0.0 | 121.3 | 19.0 | +0.0 | 0.0 | 73.3 |
| HOLDER ASSIGNMENT | 15.3 | +1706.4 | 0.0 | 30.3 | 14.7 | +1396.7 | 0.0 | 36.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -21.2 | 0.0 | 0.0 | 1.7 | -79.2 | 17.3 | 0.0 |
| IDLE COST | 16.7 | -93.3 | 0.0 | 52.0 | 4.0 | -67.2 | 0.0 | 18.3 |
| KEEP FALLS | 0.7 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 73.3 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 103.3 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | -2.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | -35.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +164.8 | 0.0 | 0.0 | 0.7 | +28.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 1.0 | +45.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -33.8 | 0.0 | 0.0 | 0.7 | +14.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 73.3 |
| MAX FOR POSITIONING | 1.7 | +45.5 | 0.0 | 28.3 | 0.3 | +6.6 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +323.3 | 0.0 | 0.0 | 4.0 | +79.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +273.4 | 0.0 | 0.0 | 4.3 | +62.1 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.0 | -164.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -90.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +844.6 | 0.0 | 237.0 | 2.3 | +139.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.0 | +211.7 | 0.0 | 0.0 | 10.7 | +461.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +453.4 | 0.0 | 133.7 | 1.3 | +73.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -77.0 | 0.0 | 0.0 | 1.3 | -20.7 | 17.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 73.3 |
| OFF BEST | 1.7 | -991.3 | 0.0 | 103.3 | 3.7 | -184.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -32.8 | 0.0 | 131.7 | 2.7 | -57.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.7 | +217.3 | 0.0 | 0.0 | 3.7 | -100.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 73.3 |
| OPENS A LANE | 1.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +3.9 | 0.0 | 17.3 | - | - | - | - |
| PLAN RESULT | 42.7 | +202.1 | 55.0 | 585.7 | 44.0 | +125.2 | 102.3 | 91.7 |
| PROMISE BY ITS OWN SUM | 4.7 | -1600.0 | 0.0 | 206.7 | 4.0 | -163.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.0 | -2.1 | 0.0 | 110.0 | - | - | - | - |
| QUARTER ODDS | 14.7 | +1244.5 | 0.0 | 73.3 | 14.7 | +1636.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +69.1 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 73.3 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +35.4 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | +90.0 | 0.0 | 28.3 | 2.0 | -64.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +33.1 | 0.0 | 28.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -74.5 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| RISK BY ARC | - | - | - | - | 1.0 | -0.6 | 17.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -14.0 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -3.5 | 17.3 | 0.0 |
| SAME TERRAIN AS THE BOARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +17.1 | 0.0 | 0.0 | 1.7 | +34.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +37.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.7 | +0.0 | 0.0 | 110.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +45.3 | 0.0 | 0.0 | 2.7 | +15.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.2 | 0.0 | 36.7 | 0.3 | -5.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 18.3 | 36.7 | - | - | - | - |
| SHOT RISK POINTS | 49.0 | +597.8 | 0.0 | 329.0 | 51.7 | +761.6 | 0.0 | 73.3 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.7 | +117.5 | 0.0 | 250.0 | 17.7 | +388.0 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.3 | +37.0 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 149.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.0 | +0.0 | 110.0 | 534.7 | 45.3 | +0.0 | 170.0 | 0.0 |
| STAY WORTH | 17.0 | +78.0 | 110.0 | 506.7 | 21.3 | +91.1 | 113.3 | 36.7 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.3 | +77.7 | 0.0 | 17.3 | 1.7 | +307.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +77.7 | 0.0 | 17.3 | 1.7 | +307.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 120.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 131.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 17.3 | 3.7 | +0.0 | 0.0 | 36.7 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 17.3 | 2.3 | +0.0 | 0.0 | 36.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 444.7 | 47.3 | +0.0 | 0.0 | 55.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +41.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 9.0 | +154.0 | 0.0 | 237.0 | 65.0 | +511.0 | 0.0 | 36.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 30.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +107.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.3 | +11.8 | 0.0 | 0.0 | 0.7 | +3.1 | 17.3 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -87.0 | 0.0 | 151.0 | 1.3 | -281.5 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.7 | +64.5 | 0.0 | 34.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +394.3 | 0.0 | 0.0 | 2.7 | +224.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 263 | 263 | 182 | 60.67 | +0 | +0.0 |
| HIS SHOT LIST | 384 | 380 | 113 | 37.67 | +1466 | +13.0 |
| SHOT RISK POINTS | 302 | 298 | 101 | 33.67 | +1826 | +18.1 |
| HIS SHOTS BY HIS RUN | 280 | 272 | 88 | 29.33 | +1716 | +19.5 |
| HOLDER ASSIGNMENT | 90 | 90 | 84 | 28.00 | +4611 | +54.9 |
| ARMY TABLE | 119 | 119 | 72 | 24.00 | +1520 | +21.1 |
| HIS MOVE WHY | 146 | 146 | 62 | 20.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| HIS ONE MOVE | 109 | 109 | 36 | 12.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 222 | 199 | 35 | 11.67 | +131 | +3.7 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| FIVE ACTION | 578 | 563 | 18 | 6.00 | +426 | +23.7 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -3527 | -220.4 |
| GOAL WALK | 58 | 55 | 15 | 5.00 | +962 | +64.2 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 12 | 4.00 | -5290 | -440.8 |
| QUARTER ODDS | 88 | 83 | 12 | 4.00 | +1076 | +89.7 |
| WOUNDS ON THE RANKS | 23 | 23 | 11 | 3.67 | +643 | +58.4 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +13 | +1.3 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +207 | +23.0 |
| CHARGE LOSSES | 67 | 66 | 8 | 2.67 | +266 | +33.3 |
| FEATURE BUFFS | 43 | 43 | 8 | 2.67 | +131 | +16.4 |
| STAY WORTH | 115 | 98 | 8 | 2.67 | +27 | +3.4 |
| THE RISK READS HIS RUN | 36 | 36 | 8 | 2.67 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 7 | 2.33 | +133 | +18.9 |
| MOVE TO CHARGE COMPUTED | 13 | 11 | 7 | 2.33 | +2106 | +300.9 |
| SEARCH SPOT | 7 | 7 | 7 | 2.33 | +154 | +22.0 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 75 | 53 | 6 | 2.00 | +131 | +21.9 |
| LEGAL CHARGES ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 6 | 2.00 | +44 | +7.4 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +581 | +116.3 |
| NEXT CHARGE BY LIST | 8 | 7 | 5 | 1.67 | +1106 | +221.1 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +1 | +0.3 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MAX FOR POSITIONING | 6 | 6 | 4 | 1.33 | +31 | +7.8 |
| MISSILES IN THE MOVE | 34 | 21 | 4 | 1.33 | +165 | +41.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 8 | 3 | 1.00 | +23 | +7.6 |
| FOUR ROUNDS | 6 | 6 | 3 | 1.00 | +33 | +10.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -6 | -2.1 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +183 | +61.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 5 | 5 | 2 | 0.67 | +10 | +5.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +20 | +9.8 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MARCH CHECK | 5 | 5 | 2 | 0.67 | +100 | +50.2 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +12 | +5.9 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT COUNTER | 14 | 11 | 2 | 0.67 | +114 | +57.1 |
| SHOT REPLANNED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 13 | 13 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 5 | 5 | 2 | 0.67 | +19 | +9.7 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.2 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.33 | +18 | +18.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +29 | +29.1 |
| ONE OBJECTIVE FORMULA | 37 | 23 | 1 | 0.33 | +19 | +19.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +26 | +26.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 73 | 62 | 1 | 0.33 | +8 | +7.5 |
| SUPPORT ADDS | 12 | 12 | 1 | 0.33 | +4 | +4.3 |
| SUPPORT WORKED OUT | 12 | 12 | 1 | 0.33 | +4 | +4.3 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| THE ROW IN ITS ORDER | 23 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +29 | +29.1 |
| WHOLE FIGHT DANGER | 10 | 10 | 1 | 0.33 | +72 | +72.4 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARGE NOW FIRST | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| COVER ONCE | 20 | 10 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 28 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 5 | 5 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 63 | 62 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 167 | 167 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| IDLE COST | 62 | 48 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 33 | 21 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 6 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 44 | 40 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SAME TERRAIN AS THE BOARD | 1 | not checked | - | - | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 36 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 44 | 36 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 265 | 256 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 0.33 | 4.33 | 54.1 |
| JOB FIRST | gate | 1.33 | 3.33 | 211.5 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 2.00 | 440.8 |
| HOLDER ASSIGNMENT | rule | 0.33 | 2.67 | 30.5 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 2.1 |
| NO REASON | gate | 0.33 | - | 553.0 |
| RULE SWITCHED OFF | gate | - | 0.33 | 13.4 |

### Plans: wfr-a92c160-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 321 | 44 | 14% |
| Mine | move | 35.7 | 94% | 2810 | 0 | 0% |
| Mine | shoot | 6.0 | 61% | 171 | 158 | 93% |
| Mine | support | 0.7 | 50% | 25 | 0 | 0% |
| Opponent | charge | 1.3 | 75% | 118 | 40 | 34% |
| Opponent | move | 39.0 | 97% | 2474 | 0 | 0% |
| Opponent | shoot | 3.7 | 36% | 203 | 85 | 42% |

### Battle groups: wfr-a92c160-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 7 (11) | 7 | 0 | 0 | 45% | 2.0 | - | 0 (6) | 15 (5) | 7 (11) | - |
| Mine | Clean-up | 2 | 226 (2) | 0 | 226 | 49 | 100% | - | 316 (1) | - | 132 (1) | 226 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 63 | 90% | 4.0 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 26 (9) | 0 | 26 | 16 | 56% | 2.8 | 0 (2) | 14 (4) | 83 (3) | 26 (9) | - |
| Mine | Holder | 2 | 60 (2) | 0 | 60 | 0 | 100% | - | 119 (1) | - | 0 (1) | - | 60 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 37 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 15 (8) | 0 | 15 | 28 | 75% | 5.5 | 31 (3) | 0 (4) | 0 (1) | 17 (7) | 0 (1) |
| Opponent | Character | 7 | 12 (7) | 12 | 0 | 0 | 14% | 2.2 | 0 (1) | 21 (5) | 0 (1) | 17 (5) | 0 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 13 (1) | 13 | 0 | 0 | 0% | 4.0 | - | 13 (1) | - | 13 (1) | - |
| Opponent | Hammer | 10 | 71 (10) | 14 | 57 | 6 | 50% | 2.0 | 15 (5) | 127 (4) | 83 (1) | 29 (5) | 101 (5) |
| Opponent | Shooter | 4 | 92 (4) | 0 | 92 | 21 | 0% | 1.8 | 0 (1) | 99 (2) | 150 (1) | 81 (3) | 132 (1) |
| Opponent | Wizard | 2 | 12 (2) | 12 | 0 | 0 | 0% | 4.0 | - | 12 (2) | - | 12 (2) | - |

### Charged fights: wfr-a92c160-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 62 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 42 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 420 | 1.0 | 1.0 | 420 | 0 | +420 | 1 of 1 | 1 of 1 | - | +420 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| **Opponent** | all armies | 3 | 57 | 175 | 0.7 | 1.0 | 262 | 0 | +262 | 1 of 2 | 2 of 2 | - | +262 |

### Effective charges: wfr-a92c160-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: wfr-a92c160-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 310 | 343 | +0 | 237 | 89 | +149 | +48.0 |
| Mine | All fights | 1 | 310 | 343 | +0 | 237 | 89 | +149 | +48.0 |
| Opponent | No odds | 2 | 234 | 181 | +262 | 262 | 0 | +262 | +112.0 |
| Opponent | All fights | 2 | 234 | 181 | +262 | 262 | 0 | +262 | +112.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p26 | move | 15 | 5 (33%) | 1 (7%) | 1 (7%) | 9 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

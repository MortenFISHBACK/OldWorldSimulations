# Doctrine scorecard: wfr-a92c160-p18

### Scorecard: wfr-a92c160-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 125 |
| L0918 | 6 | 1 | Opponent | no | 8 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 503 |
| L0934 | 4 | 1 | Opponent | no | 3 | 3 | 3 | 6 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 12 | 3 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 3.0 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 264.3 |
| **Average** | | | Opponent | 0% | 3.7 | 4.5 | 2.0 | 4.0 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: wfr-a92c160-p18

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (3 of 11) | 0% (0 of 14) | 12% (3 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 35% (17 of 48) | 8% (1 of 12) | 30% (18 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (17 of 45) | 9% (1 of 11) | 32% (18 of 56) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 80% (4826 of 5997) | 73% (4407 of 5998) | 77% (9233 of 11995) |
|   infantry points that never fought | lower | 82% (1298 of 1591) | 90% (1027 of 1147) | 85% (2325 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (23 of 34) | 75% (15 of 20) | 70% (38 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3999 of 5667) | 76% (3954 of 5186) | 73% (7953 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (52%) | 0.0 (0%) | 5.3 (38%) |
| MARCHED: its unit marched | 4.0 (39%) | 1.3 (36%) | 5.3 (38%) |
| IN COMBAT: engaged in combat | 1.0 (10%) | 0.3 (9%) | 1.3 (10%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (18%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (36%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.0 | 6.0 | 0.7 | 1.7 |
| not cast | 2.0 | 4.0 | 14.0 | 3.3 | 14.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (50%) | 5.3 (38%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 5.3 (38%) | 1.7 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (50%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (91 of 128) | 73% (56 of 77) | 72% (147 of 205) |
|   cavalry | - | 58% (7 of 12) | 58% (7 of 12) |
|   character | 100% (9 of 9) | 62% (10 of 16) | 76% (19 of 25) |
|   chariot | 89% (16 of 18) | 92% (11 of 12) | 90% (27 of 30) |
|   infantry | 48% (20 of 42) | 69% (18 of 26) | 56% (38 of 68) |
|   monster | 82% (9 of 11) | 91% (10 of 11) | 86% (19 of 22) |
|   war machine | 77% (37 of 48) | - | 77% (37 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (27%) | 4.3 (62%) | 7.7 (40%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (11%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 3.0 (24%) | 0.7 (10%) | 3.7 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (16%) | 1.3 (19%) | 3.3 (17%) |
| SHELTERED: the target was sheltered | 1.7 (14%) | 0.0 (0%) | 1.7 (9%) |
| OTHER BAR | 0.3 (3%) | 0.3 (5%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.3 | 90% | 0.8 pts | 3 pts |
| character | 6.3 | 1.7 | 74% | 2.8 pts | 18 pts |
| chariot | 9.0 | 6.7 | 63% | 16.8 pts | 151 pts |
| infantry | 13.0 | 5.0 | 77% | 5.2 pts | 68 pts |
| monster | 9.3 | 2.0 | 86% | 5.2 pts | 48 pts |
| war machine | 12.7 | 14.7 | 45% | 26.9 pts | 341 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.7 | 1.3 |
| Charges that made contact a game | 1.0 | 1.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.10 declared, 0.06 contact (31 units) | 0.06 declared, 0.04 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 67% (2 of 3) | 80% (4 of 5) | 75% (6 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 50% (1 of 2) | 100% (5 of 5) | - | 86% (6 of 7) |
| War Machines | 50% (4 of 8) | - | - | 50% (4 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 46% (11 of 24) | 88% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (2 of 2); on the table 100% | 25% (6 of 24) | 65% | 70% (7 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 28% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 95% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 67% (2) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (22 of 65) | 60% (15 of 25) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 22% (2 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 4.0 |
| Movement | Points that never moved of their own | 264.3 | 0.0 |
| Movement | Fights charged into per game | 1.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +60 | 1 of 3, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +0 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 18.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 20% (11 of 54) | 45% (25 of 56) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 12.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (18 of 38) | - |
| Shooting | Points destroyed by war machines | 200.3 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (5 of 12) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 8.7 | 3.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 248.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.3 / 0.3 | 1.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 31.3 | 34.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +43 | +23 |
| Combat | Net per 100 charger points, damage counted | +14.8 | +7.9 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +20 | +18 |
| Combat | Net points per supported fight / lone fight | - / +20 | - / +18 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 1 of 4 |
| Game | Points lost | 179.7 | 447.0 |
| Game | VP from objectives | 466.7 | 733.3 |
| Game | Lone holders (player turns) | 4.0 | 3.7 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +59 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 627
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| ARMY TABLE | 10.3 | +289.1 | 0.0 | 145.0 | 26.7 | +188.4 | 0.0 | 104.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.4 | 0.0 | 199.7 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 199.7 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 66.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.7 | +245.3 | 1317.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.7 | +53.2 | 60.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +24.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +25.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +23.2 | 0.0 | 0.0 | 0.3 | +3.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 19.0 | -634.3 | 0.0 | 145.0 | 21.7 | -979.6 | 0.0 | 718.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 11.3 |
| COVER ONCE | 8.7 | -326.0 | 0.0 | 34.7 | 4.3 | -416.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -15.7 | 69.3 | 199.7 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.1 | 0.0 | 399.3 |
| EXACT ROUND | 0.7 | -1.1 | 20.0 | 0.0 | 0.7 | -7.3 | 34.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 20.0 | 0.0 | 0.7 | +0.0 | 69.3 | 199.7 |
| FALLS SHORT | - | - | - | - | 36.0 | +402.9 | 0.0 | 376.7 |
| FEATURE BUFFS | 0.7 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +0.2 | 34.7 | 0.0 |
| FIVE ACTION | 107.0 | +4910.8 | 3708.7 | 441.3 | 111.3 | +5442.3 | 744.0 | 1359.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 34.7 | 5.3 | +0.0 | 0.0 | 20.0 |
| FOLLOW UP WEIGHED | 0.3 | +21.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +99.3 | 20.0 | 0.0 | 1.3 | +94.5 | 69.3 | 199.7 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 34.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -4.1 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +493.3 | 0.0 | 0.0 | 23.3 | +2235.6 | 0.0 | 97.3 |
| GUN FIGURES | 2.7 | +0.5 | 208.7 | 0.0 | 0.7 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 6.0 | +254.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 34.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 34.7 | 8.0 | +0.0 | 0.0 | 72.7 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 11.3 |
| HIS MOVE AND SHOT | 5.3 | -24.1 | 0.0 | 0.0 | 8.7 | -107.6 | 0.0 | 106.7 |
| HIS MOVE AS HE DECIDES | 54.3 | +15.7 | 853.0 | 0.0 | 37.0 | +10.7 | 324.7 | 0.0 |
| HIS MOVE WHY | 27.7 | +0.0 | 0.0 | 151.3 | 22.7 | +0.0 | 0.0 | 623.0 |
| HIS ONE MOVE | 16.3 | +23.3 | 0.0 | 0.0 | 25.3 | +41.3 | 0.0 | 144.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 60.7 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 11.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.3 | +1230.5 | 0.0 | 296.3 | 84.7 | +6260.2 | 0.0 | 1122.0 |
| HIS SHOTS BY HIS RUN | 38.7 | +733.6 | 0.0 | 255.3 | 68.3 | +1683.6 | 0.0 | 1013.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +54.6 | 69.3 | 199.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 0.0 | 19.0 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.7 | +1185.7 | 0.0 | 0.0 | 14.3 | +1512.6 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -43.1 | 20.0 | 0.0 | 1.3 | -79.5 | 69.3 | 199.7 |
| IDLE COST | - | - | - | - | 24.0 | -353.0 | 0.0 | 149.7 |
| KEEP FALLS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 34.7 | 5.3 | +0.0 | 208.0 | 397.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.3 | 0.0 | 0.0 | 1.0 | +2.5 | 34.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -14.9 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +7.7 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +49.9 | 0.0 | 0.0 | 0.3 | +42.9 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +92.1 | 0.0 | 0.0 | 1.0 | +52.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +9.0 | 0.0 | 0.0 | 0.3 | +29.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.3 | +130.5 | 0.0 | 0.0 | 1.0 | +124.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +13.8 | 0.0 | 0.0 | 2.7 | +33.1 | 0.0 | 22.7 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.7 | +148.2 | 0.0 | 0.0 | 1.7 | +25.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 13.0 | +123.1 | 0.0 | 0.0 | 3.3 | +27.7 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 107.0 | 11.3 |
| MOVE TO CHARGE COMPUTED | 2.7 | +141.2 | 0.0 | 0.0 | 3.3 | +236.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +259.4 | 0.0 | 0.0 | 5.3 | +249.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +72.6 | 0.0 | 0.0 | 2.0 | +116.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -25.2 | 20.0 | 0.0 | 1.3 | -42.2 | 69.3 | 199.7 |
| NO LATE CUT | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.0 | -182.3 | 0.0 | 0.0 | 4.7 | -103.3 | 0.0 | 35.7 |
| OGRE LOADER SECOND SHOT | 3.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 30.3 |
| ONE FIGHT FORMULA | 3.3 | -46.1 | 0.0 | 0.0 | 4.0 | -74.2 | 0.0 | 211.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +21.0 | 0.0 | 0.0 | 5.7 | +23.1 | 0.0 | 0.0 |
| ONE ROUTE | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 199.7 |
| PATHS CROSS | 0.3 | +25.0 | 0.0 | 0.0 | 0.3 | +49.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +1500.2 | 1399.3 | 324.7 | 50.0 | +352.3 | 337.3 | 853.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.0 | -85.4 | 0.0 | 0.0 | 5.7 | -249.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| QUARTER ODDS | 9.3 | +944.7 | 258.7 | 0.0 | 13.3 | +912.0 | 0.0 | 312.0 |
| REAL GROUND | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.3 | +295.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 7.0 | +0.0 | 0.0 | 22.7 |
| REFORMS TO MEET IT | 1.3 | -28.7 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +39.6 | 0.0 | 35.7 |
| RISK BY ARC | 1.0 | +93.7 | 20.0 | 0.0 | 0.7 | -58.9 | 69.3 | 199.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -29.1 | 34.7 | 199.7 |
| RUN DOWN | - | - | - | - | 1.3 | -8.6 | 69.3 | 199.7 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.0 | -299.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 34.7 | 2.0 | +108.1 | 0.0 | 78.0 |
| SECOND LOOK | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.3 | +2.7 | 0.0 | 0.0 | 1.7 | -91.4 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 20.3 | +0.0 | 0.0 | 34.7 | 11.3 | +0.0 | 0.0 | 18.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +308.6 | 193.3 | 0.0 | 4.3 | +162.5 | 302.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -13.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -371.3 | 0.0 | 145.0 | 49.7 | -16.7 | 0.0 | 964.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 31.3 | +1125.6 | 0.0 | 69.3 | 18.3 | +337.5 | 0.0 | 296.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +53.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 121.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.8 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 12.3 | +0.0 | 69.3 | 436.7 |
| STANDS STILL | 56.7 | +0.0 | 3688.7 | 220.7 | 32.3 | +0.0 | 674.7 | 170.3 |
| STAY WORTH | 49.3 | +293.2 | 2643.7 | 110.3 | 28.0 | +295.9 | 372.0 | 388.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 2.0 | +169.9 | 0.0 | 0.0 | 2.0 | +44.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +169.9 | 0.0 | 0.0 | 2.0 | +44.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 34.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 54.3 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 75.7 | 7.3 | +0.0 | 0.0 | 36.3 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 78.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 36.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 220.7 | 55.7 | +0.0 | 0.0 | 574.0 |
| TIED UP BY THE SUM | 0.3 | +47.5 | 20.0 | 0.0 | 0.3 | +53.6 | 34.7 | 199.7 |
| TIME ON OUR SIDE | 51.7 | +684.6 | 37.3 | 372.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 605.3 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +15.4 | 0.0 | 36.3 |
| WHOLE FIGHT DANGER | 2.7 | -209.3 | 0.0 | 0.0 | 0.7 | -98.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 6.7 | +71.8 | 0.0 | 0.0 | 1.0 | +13.5 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 274 | 274 | 195 | 65.00 | +0 | +0.0 |
| HIS SHOT LIST | 375 | 365 | 138 | 46.00 | +3208 | +23.2 |
| HIS MOVE WHY | 151 | 151 | 94 | 31.33 | +0 | +0.0 |
| ARMY TABLE | 111 | 111 | 90 | 30.00 | +1528 | +17.0 |
| HIS SHOTS BY HIS RUN | 321 | 309 | 83 | 27.67 | +1163 | +14.0 |
| HOLDER ASSIGNMENT | 81 | 81 | 75 | 25.00 | +4896 | +65.3 |
| SHOT RISK POINTS | 218 | 209 | 45 | 15.00 | +1544 | +34.3 |
| HIS ONE MOVE | 125 | 122 | 38 | 12.67 | +0 | +0.0 |
| GOAL WALK | 97 | 96 | 36 | 12.00 | +1450 | +40.3 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -857 | -24.5 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 18 | 6.00 | +236 | +13.1 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 155 | 127 | 17 | 5.67 | +102 | +6.0 |
| STAY WORTH | 232 | 208 | 16 | 5.33 | +135 | +8.4 |
| THE RISK READS HIS RUN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 18 | 15 | 14 | 4.67 | +355 | +25.4 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 13 | 4.33 | -1006 | -77.4 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +21 | +2.1 |
| CHARGE LOSSES | 122 | 117 | 9 | 3.00 | +593 | +65.8 |
| FIVE ACTION | 655 | 639 | 9 | 3.00 | +134 | +14.9 |
| GUN MASK | 18 | 18 | 8 | 2.67 | +284 | +35.5 |
| CAST JOB | 11 | 11 | 7 | 2.33 | +20 | +2.9 |
| IDLE COST | 72 | 46 | 7 | 2.33 | +69 | +9.8 |
| NEXT CHARGE BY LIST | 9 | 9 | 7 | 2.33 | +211 | +30.2 |
| SHOTS IN THE MOVE | 149 | 114 | 7 | 2.33 | +123 | +17.5 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MARCH CHECK | 8 | 8 | 6 | 2.00 | +114 | +19.0 |
| SEARCH SPOT | 8 | 8 | 6 | 2.00 | +324 | +54.1 |
| MAX FOR POSITIONING | 16 | 16 | 5 | 1.67 | +23 | +4.5 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 27 | 27 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 23 | 23 | 5 | 1.67 | +28 | +5.6 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +25 | +6.2 |
| COVER ONCE | 39 | 31 | 4 | 1.33 | +27 | +6.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +278 | +69.6 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -114 | -28.6 |
| SUPPORT ADDS | 12 | 10 | 4 | 1.33 | +241 | +60.4 |
| SUPPORT WORKED OUT | 12 | 10 | 4 | 1.33 | +241 | +60.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +79 | +26.4 |
| FALLS SHORT | 108 | 84 | 3 | 1.00 | +6 | +1.8 |
| FOUR ROUNDS | 7 | 6 | 3 | 1.00 | +162 | +54.2 |
| WHOLE FIGHT DANGER | 10 | 10 | 3 | 1.00 | +105 | +34.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +63 | +31.5 |
| HIS MOVE AND SHOT | 42 | 40 | 2 | 0.67 | +19 | +9.5 |
| MISSILES IN THE MOVE | 34 | 24 | 2 | 0.67 | +9 | +4.4 |
| NEARER NOT NEEDED | 32 | 29 | 2 | 0.67 | +18 | +9.2 |
| ONE OBJECTIVE FORMULA | 30 | 25 | 2 | 0.67 | +214 | +107.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +225 | +112.3 |
| REDIRECT COUNTER | 13 | 12 | 2 | 0.67 | +436 | +218.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +119 | +59.4 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +4 | +2.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +104 | +52.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +54 | +26.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +18 | +18.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| CANNON PLANNED TARGET | 32 | 32 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 1 | 1 | 1 | 0.33 | -39 | -38.9 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 2 | 2 | 1 | 0.33 | +0 | +0.4 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +62 | +62.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +48 | +48.0 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +1 | +0.6 |
| MISSILES NEXT TURN | 49 | 31 | 1 | 0.33 | +1 | +1.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -6 | -6.2 |
| QUARTER ODDS | 68 | 63 | 1 | 0.33 | +24 | +24.1 |
| REFORMS TO MEET IT | 5 | 5 | 1 | 0.33 | +10 | +9.8 |
| RISK BY ARC | 5 | 4 | 1 | 0.33 | +6 | +5.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| SET UP TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 72 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 114 | 114 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 31 | 31 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 20 | 20 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 20 | 20 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 20 | 20 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 287 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 20 | 20 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 95 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 37 | 35 | 0 | 0.00 | - | - |
| STANDS STILL | 267 | 256 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 18 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 38 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 28 | not checked | - | - | - | - |
| THE TABLE BINDS | 309 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 20 | 20 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 3.00 | 26.3 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.00 | 77.4 |
| ARMY TABLE | rule | 0.33 | 3.33 | 39.3 |
| HOLDER ASSIGNMENT | rule | 1.67 | 0.33 | 30.8 |
| NO REASON | gate | - | 1.67 | 24.0 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 38.1 |
| RULE SWITCHED OFF | gate | 0.67 | - | 11.7 |
| AFTERMATH BAND | gate | 0.33 | - | 4.8 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 38.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 6.2 |
| SET UP BY THE SET | rule | - | 0.33 | 0.6 |

### Plans: wfr-a92c160-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 26 | 28 | 107% |
| Mine | move | 27.7 | 96% | 1365 | 0 | 0% |
| Mine | shoot | 17.3 | 67% | 787 | 1472 | 187% |
| Opponent | charge | 0.7 | 100% | 35 | 59 | 170% |
| Opponent | move | 41.7 | 94% | 1978 | 0 | 0% |
| Opponent | shoot | 6.3 | 53% | 388 | 294 | 76% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.3 | 8% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 46 (12) | 46 | 0 | 0 | 33% | 2.9 | 6 (5) | 0 (5) | 421 (2) | 90 (7) | 6 (5) |
| Mine | Clean-up | 2 | 100 (2) | 0 | 100 | 0 | 100% | - | - | - | 100 (2) | 100 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 0 | 0% | 3.7 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 2 (7) | 2 | 0 | 14 | 29% | 1.4 | 0 (1) | 5 (3) | 0 (3) | 3 (5) | 0 (2) |
| Mine | Shooter | 6 | 77 (6) | 0 | 77 | 50 | 0% | 2.0 | 0 (1) | 159 (2) | 48 (3) | 92 (5) | 0 (1) |
| Mine | War machine | 8 | 56 (8) | 56 | 0 | 0 | 0% | 1.1 | 86 (1) | 99 (4) | 0 (3) | - | 56 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 124 (11) | 0 | 124 | 32 | 45% | 2.7 | 142 (3) | 117 (1) | 118 (7) | 124 (11) | - |
| Opponent | Character | 6 | 4 (6) | 4 | 0 | 24 | 0% | 2.2 | 0 (2) | 14 (2) | 0 (2) | 10 (2) | 0 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 50% | 1.0 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 6 (10) | 6 | 0 | 23 | 40% | 2.2 | 0 (4) | 11 (4) | 0 (2) | 24 (2) | 0 (8) |
| Opponent | Holder | 1 | 67 (1) | 0 | 67 | 0 | 100% | - | - | 67 (1) | - | - | 67 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: wfr-a92c160-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 674 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 0 | 60 | 3.0 | 1.0 | 20 | 0 | +20 | 0 of 3 | 3 of 3 | - | +20 |
| **Mine** | all armies | 3 | 449 | 20 | 1.0 | 1.0 | 20 | 0 | +20 | 0 of 3 | 3 of 3 | - | +20 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| **Opponent** | all armies | 3 | 0 | 35 | 1.3 | 1.0 | 26 | 8 | +18 | 1 of 4 | 3 of 4 | - | +18 |

### Effective charges: wfr-a92c160-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 1 (net +60) | 1 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 1 (net +104) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 334 | 329 | +0 | 78 | 48 | +31 | +9.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 60 | +60 | 99 | 0 | +99 | +29.6 |
| Mine | No odds | 1 | 205 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 3 | 291 | 150 | +20 | 59 | 16 | +43 | +14.8 |
| Opponent | 76-89% | 2 | 304 | 154 | +52 | 107 | 58 | +49 | +16.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 500 | 162 | +0 | 27 | 0 | +27 | +5.4 |
| Opponent | No odds | 1 | 34 | 189 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 4 | 286 | 165 | +18 | 60 | 38 | +23 | +7.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p18 | move | 14 | 4 (29%) | 4 (29%) | 1 (7%) | 9 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

# Doctrine scorecard: wfr-a92c160-p1

### Scorecard: wfr-a92c160-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 1 | 2 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 2 | - | 2 | 4 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 377 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 6 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 3.7 | - | 0.0 | 1.3 | 0.0 | 0.0 | 0.0 | 144.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.0 | 1.0 | 5.3 | 0.3 | 0.0 | 0.0 | 131.3 |

### KPIs: wfr-a92c160-p1

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 10) | 0% (0 of 15) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 38% (34 of 90) | 46% (11 of 24) | 39% (45 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (34 of 88) | 46% (11 of 24) | 40% (45 of 112) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (5 of 6) | 83% (5 of 6) |
| Points that never fought | lower | 70% (3973 of 5700) | 88% (5179 of 5899) | 79% (9152 of 11599) |
|   infantry points that never fought | lower | 75% (2014 of 2703) | 100% (1219 of 1219) | 82% (3233 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 33% (5 of 15) | 84% (21 of 25) | 65% (26 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.3 uses a game | 75% (3 of 4); 3.7 uses a game | 86% (6 of 7); 4.0 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 1.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 32% (1310 of 4077) | 82% (4016 of 4883) | 59% (5326 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 14.0 (75%) | 3.0 (69%) | 17.0 (74%) |
| MARCHED: its unit marched | 2.3 (12%) | 1.3 (31%) | 3.7 (16%) |
| IN COMBAT: engaged in combat | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 1.3 (7%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 9.0 | 1.7 | 9.0 | 15.0 | 0.7 |
| not cast | 9.0 | 8.3 | 7.0 | 23.0 | 43.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (52%) | 0.7 (10%) | 17.0 (74%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (16%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.7 (7%) | 0.0 (0%) | 0.7 (10%) | 1.3 (6%) | 1.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.7 (85%) | 4.0 (48%) | 5.7 (81%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 40.3 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.3 a game | 2.7 a game | 5.0 a game |
| stood (cast and not dispelled) | 73% (16 of 22) | 75% (6 of 8) | 73% (22 of 30) |
| the unit moved after it | 62% (10 of 16) | 33% (2 of 6) | 55% (12 of 22) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 6) | 0% (0 of 22) |
| the enemy charged it first | 0% (0 of 16) | 0% (0 of 6) | 0% (0 of 22) |
| it fought by the end of its next turn | 0% (0 of 16) | 0% (0 of 6) | 0% (0 of 22) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 6) | 0% (0 of 22) |
| none of these (no charge, no fight, no charge escaped) | 100% (16 of 16) | 100% (6 of 6) | 100% (22 of 22) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (19 of 35) | 50% (30 of 60) | 52% (49 of 95) |
|   cavalry | - | 67% (8 of 12) | 67% (8 of 12) |
|   character | - | 73% (8 of 11) | 73% (8 of 11) |
|   chariot | - | 50% (1 of 2) | 50% (1 of 2) |
|   infantry | 54% (19 of 35) | 25% (6 of 24) | 42% (25 of 59) |
|   monster | - | 64% (7 of 11) | 64% (7 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (56%) | 2.3 (23%) | 5.3 (35%) |
| FLEEING: it fled or was fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.0 (19%) | 6.7 (67%) | 7.7 (50%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 0.7 (7%) | 1.3 (9%) |
| SHELTERED: the target was sheltered | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.7 | 58% | 3.6 pts | 14 pts |
| character | 2.7 | 2.0 | 50% | 6.4 pts | 17 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 8.3 | 1.3 | 88% | 2.0 pts | 17 pts |
| monster | 2.3 | 1.7 | 71% | 5.8 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 1.7 | 0.8 |
| Charges that made contact a game | 0.0 | 1.0 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.16 declared, 0.09 contact (32 units) | 0.11 declared, 0.06 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 60% (3 of 5) | 80% (8 of 10) | - | 73% (11 of 15) |
| Character on its own | - | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 0% (0 of 7) | - | 33% (4 of 12) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (1 of 2); on the table 50% | 41% (44 of 108) | 76% | 48% (10 of 21) | 100% (5 of 5); 5.2 uses a game | 67% (2 of 3); 0.8 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 98% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 70% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 21% (4 of 19) | 38% (8 of 21) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 33% (6 of 18) | 0% (0 of 7) |
| Strategy | Lone characters that fought | - | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.3 | 5.3 |
| Movement | Points that never moved of their own | 144.0 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 2, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (5 of 19) | 68% (21 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 7.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 19% (4 of 21) | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | 23.0 | 7.3 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 369.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.0 / 0.7 / 0.7 / 0.0 | 1.7 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | -9 |
| Combat | Net per 100 charger points, damage counted | - | -12.5 |
| Combat | First round won (charged fights) | - | 33% |
| Combat | Net points per charged fight | - | +7 |
| Combat | Net points per supported fight / lone fight | - / - | - / +7 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 3 |
| Game | Points lost | 105.7 | 479.3 |
| Game | VP from objectives | 880.0 | 736.7 |
| Game | Lone holders (player turns) | 3.7 | 1.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +506 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 585
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 98.3 |
| AFTERMATH IN POINTS | 0.3 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 12.0 | -195.1 | 0.0 | 105.7 | 18.0 | +366.7 | 0.0 | 239.7 |
| CAST JOB | - | - | - | - | 2.0 | +2.6 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 6.3 | +868.0 | 239.3 | 0.0 | 2.7 | +61.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +16.3 | 0.0 | 20.0 |
| CHARGE LOSSES | 16.3 | -301.3 | 0.0 | 21.7 | 11.0 | -405.2 | 0.0 | 406.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.3 | +0.0 | 0.0 | 36.7 | 15.0 | +0.0 | 0.0 | 263.3 |
| CONVEYANCE SEARCH | 7.0 | +878.7 | 0.0 | 0.0 | 2.7 | +84.3 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -59.7 | 0.0 | 0.0 | 4.0 | -169.2 | 0.0 | 83.7 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 198.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +8.4 | 21.7 | 0.0 |
| EXACT ROUND | - | - | - | - | 0.7 | +2.3 | 36.7 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.0 | +0.0 | 18.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.7 | +239.5 | 0.0 | 78.0 |
| FEATURE BUFFS | 14.7 | +621.3 | 0.0 | 91.7 | 0.3 | +12.5 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 57.3 | +8095.1 | 562.7 | 422.7 | 98.3 | +3663.4 | 204.7 | 1067.3 |
| FLANK NOT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 93.7 |
| FOLLOW UP WEIGHED | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 1.3 | +19.0 | 36.7 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 43.3 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 250.7 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -37.0 | 0.0 | 36.7 | 1.7 | -24.0 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 46.0 | +13.0 | 431.7 | 0.0 | 29.3 | +6.3 | 174.7 | 0.0 |
| HIS MOVE WHY | 17.0 | +0.0 | 0.0 | 193.0 | 18.7 | +0.0 | 0.0 | 469.3 |
| HIS ONE MOVE | 13.7 | +11.9 | 0.0 | 47.3 | 18.0 | +14.3 | 0.0 | 83.7 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 73.0 | 7.0 | +0.0 | 0.0 | 167.3 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.0 | +446.2 | 0.0 | 259.3 | 52.0 | +2357.6 | 0.0 | 537.3 |
| HIS SHOTS BY HIS RUN | 35.0 | +287.1 | 0.0 | 296.0 | 39.3 | +1151.7 | 0.0 | 418.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +40.3 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 37.7 | +0.0 | 0.0 | 267.7 | 12.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.3 | +1845.1 | 0.0 | 91.3 | 10.0 | +1091.5 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 0.7 | -4.7 | 36.7 | 0.0 |
| IDLE COST | - | - | - | - | 30.3 | -329.3 | 0.0 | 311.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -11.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 77.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.0 | +0.0 | 11.3 | 165.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +4.7 | 18.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +19.5 | 0.0 | 0.0 | 1.0 | +78.2 | 0.0 | 78.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +15.3 | 0.0 | 0.0 | 0.3 | +79.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | 0.3 | +69.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -35.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +21.9 | 0.0 | 18.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 198.0 |
| MISSILES IN THE MOVE | 9.3 | +788.5 | 0.0 | 0.0 | 7.0 | +123.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.7 | +504.5 | 0.0 | 0.0 | 6.3 | +60.2 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 4.7 | -196.0 | 0.0 | 0.0 | 0.7 | -23.2 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 89.3 |
| MOVE SPELL OUT OF RANGE | 2.0 | -159.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 3.0 | +133.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +383.5 | 0.0 | 21.7 | 3.0 | +160.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 1.3 | +52.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -7.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.3 | -14.3 | 36.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.3 | -7.3 | 0.0 | 0.0 | 2.3 | -2.3 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -91.5 | 0.0 | 25.7 | 0.3 | -0.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -62.1 | 0.0 | 36.7 | 3.0 | -56.4 | 0.0 | 112.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +28.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.3 | +207.0 | 0.0 | 44.0 | 1.7 | -11.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +1.3 | 167.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +22.8 | 36.7 | 0.0 |
| PLAN RESULT | 24.7 | +155.1 | 78.0 | 149.0 | 43.3 | +143.9 | 21.7 | 471.3 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 11.0 | +1481.3 | 167.3 | 181.3 | 21.0 | +1919.2 | 94.7 | 490.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +155.9 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | -11.3 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 73.3 | 2.7 | +0.0 | 0.0 | 22.7 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -30.0 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.0 | +50.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -33.0 | 36.7 | 0.0 |
| RUN DOWN | - | - | - | - | 0.7 | -0.1 | 36.7 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 0.7 | +10.0 | 0.0 | 0.0 | 0.7 | +15.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +38.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 43.3 | 7.7 | +0.0 | 0.0 | 171.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +52.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -2.9 | 18.3 | 0.0 |
| SHOT RISK POINTS | 22.0 | -187.5 | 0.0 | 216.0 | 49.7 | +585.0 | 0.0 | 497.3 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 7.3 | +125.9 | 0.0 | 65.0 | 11.0 | +80.2 | 0.0 | 301.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +38.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +12.8 | 167.3 | 0.0 | 1.7 | +5.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 55.0 | 3.7 | +0.0 | 0.0 | 11.3 |
| STANDS FOR A REASON | - | - | - | - | 13.0 | +0.0 | 36.7 | 0.0 |
| STANDS STILL | 22.3 | +0.0 | 562.7 | 185.0 | 41.0 | +0.0 | 168.0 | 323.3 |
| STAY WORTH | 12.3 | +142.9 | 156.0 | 173.3 | 19.3 | +95.4 | 124.7 | 373.7 |
| SUPPORT ADDS | 6.0 | +178.8 | 0.0 | 51.3 | - | - | - | - |
| SUPPORT WORKED OUT | 6.0 | +178.8 | 0.0 | 51.3 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 25.7 | 1.3 | +0.0 | 0.0 | 83.7 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 25.7 | 2.7 | +0.0 | 0.0 | 106.3 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 27.7 | +0.0 | 0.0 | 211.3 | 47.3 | +0.0 | 0.0 | 538.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 28.3 | +691.7 | 0.0 | 219.0 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -84.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 10.3 | +227.3 | 0.0 | 0.0 | 1.3 | +102.5 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 226 | 226 | 168 | 56.00 | +0 | +0.0 |
| HIS SHOT LIST | 249 | 247 | 77 | 25.67 | +1071 | +13.9 |
| HOLDER ASSIGNMENT | 79 | 79 | 71 | 23.67 | +3188 | +44.9 |
| HIS MOVE WHY | 107 | 107 | 65 | 21.67 | +0 | +0.0 |
| ARMY TABLE | 90 | 90 | 64 | 21.33 | +305 | +4.8 |
| HIS SHOTS BY HIS RUN | 223 | 218 | 64 | 21.33 | +684 | +10.7 |
| SHOT RISK POINTS | 215 | 212 | 44 | 14.67 | +423 | +9.6 |
| HIS ONE MOVE | 95 | 95 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| CASTING BLOCK | 27 | 27 | 26 | 8.67 | +992 | +38.2 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| IDLE COST | 91 | 73 | 18 | 6.00 | +162 | +9.0 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 85 | 73 | 14 | 4.67 | +141 | +10.1 |
| STAY WORTH | 95 | 74 | 13 | 4.33 | +73 | +5.6 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| QUARTER ODDS | 96 | 92 | 10 | 3.33 | +768 | +76.8 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHARGE LOSSES | 82 | 81 | 8 | 2.67 | +452 | +56.5 |
| OFF BEST | 8 | 8 | 8 | 2.67 | -276 | -34.4 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 35 | 35 | 7 | 2.33 | +125 | +17.9 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +2 | +0.4 |
| GOAL WALK | 14 | 14 | 6 | 2.00 | +1220 | +203.2 |
| MOVE TO CHARGE COMPUTED | 9 | 9 | 6 | 2.00 | +244 | +40.7 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 77 | 58 | 5 | 1.67 | +108 | +21.7 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 5 | 1.67 | +468 | +93.6 |
| THE RISK READS HIS RUN | 36 | 36 | 5 | 1.67 | +0 | +0.0 |
| FEATURE BUFFS | 45 | 45 | 4 | 1.33 | +93 | +23.2 |
| MANOEUVRE | 7 | 7 | 4 | 1.33 | +293 | +73.3 |
| MISSILES IN THE MOVE | 49 | 35 | 4 | 1.33 | +305 | +76.3 |
| NEXT CHARGE BY LIST | 4 | 4 | 4 | 1.33 | +113 | +28.2 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +75 | +18.8 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 4 | 1.33 | +11 | +2.7 |
| FIVE ACTION | 467 | 462 | 3 | 1.00 | +260 | +86.6 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +286 | +95.2 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +151 | +50.4 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.67 | +19 | +9.4 |
| COVER ONCE | 18 | 13 | 2 | 0.67 | +3 | +1.7 |
| MAX FOR POSITIONING | 7 | 7 | 2 | 0.67 | +4 | +1.8 |
| MISSILES NEXT TURN | 45 | 33 | 2 | 0.67 | +119 | +59.4 |
| ONE OBJECTIVE FORMULA | 30 | 19 | 2 | 0.67 | +103 | +51.4 |
| REDIRECT COUNTER | 7 | 4 | 2 | 0.67 | +38 | +19.2 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 55 | 34 | 2 | 0.67 | +21 | +10.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +37 | +37.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +35 | +35.3 |
| FOUR ROUNDS | 4 | 4 | 1 | 0.33 | +6 | +5.8 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +40 | +40.2 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -34 | -34.1 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +11 | +10.6 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +68 | +67.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -7 | -6.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 33 | 29 | 1 | 0.33 | +5 | +4.9 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +40 | +40.2 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +32 | +32.3 |
| SET UP BY THE SET | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SUPPORT ADDS | 18 | 17 | 1 | 0.33 | +12 | +12.1 |
| SUPPORT WORKED OUT | 18 | 17 | 1 | 0.33 | +12 | +12.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| WHOLE FIGHT DANGER | 8 | 8 | 1 | 0.33 | +32 | +31.8 |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 51 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 13 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 28 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 4 | 4 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 149 | 148 | 0 | 0.00 | - | - |
| HONEST WORTH | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 20 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 16 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 20 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 204 | trace | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 41 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 27 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 39 | 39 | 0 | 0.00 | - | - |
| STANDS STILL | 190 | 190 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 30 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 25 | not checked | - | - | - | - |
| THE TABLE BINDS | 225 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 2.33 | 1.33 | 93.6 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.33 | 17.3 |
| JOB FIRST | gate | 2.00 | 0.33 | 34.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.1 |
| MARCH OF THE TABLE | rule | 0.33 | - | 6.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 33.4 |

### Plans: wfr-a92c160-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 19.7 | 93% | 2606 | 0 | 0% |
| Mine | shoot | 5.0 | 27% | 764 | 155 | 20% |
| Opponent | charge | 1.0 | 67% | 26 | 63 | 240% |
| Opponent | move | 37.0 | 95% | 1012 | 0 | 0% |
| Opponent | shoot | 5.0 | 40% | 237 | 81 | 34% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: wfr-a92c160-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 37 (18) | 37 | 0 | 0 | 6% | 2.1 | 50 (3) | 44 (12) | 0 (3) | 51 (12) | 11 (6) |
| Mine | Hammer | 6 | 50 (6) | 2 | 49 | 0 | 67% | 3.5 | 75 (1) | 54 (4) | 11 (1) | 54 (4) | 43 (2) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 33 | 100% | - | - | 65 (3) | - | 195 (1) | 0 (2) |
| Mine | Shooter | 6 | 54 (6) | 0 | 54 | 33 | 0% | 1.7 | - | 65 (5) | 0 (1) | 69 (4) | 23 (2) |
| Opponent | Chaff | 6 | 118 (6) | 0 | 118 | 25 | 67% | 3.0 | 0 (3) | 429 (2) | 0 (1) | 118 (6) | - |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 0 | 25% | 1.5 | 0 (4) | 0 (4) | - | 0 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 38 (7) | 18 | 20 | 28 | 57% | 2.0 | 111 (1) | 0 (3) | 25 (3) | 29 (3) | 42 (4) |
| Opponent | Hammer | 13 | 15 (13) | 0 | 15 | 43 | 62% | 2.2 | - | 21 (8) | 0 (5) | 0 (3) | 20 (10) |
| Opponent | Holder | 1 | 36 (1) | 0 | 36 | 0 | 100% | - | - | 36 (1) | - | - | 36 (1) |
| Opponent | Shooter | 3 | 91 (3) | 0 | 91 | 62 | 67% | 1.0 | 236 (1) | 0 (2) | - | 236 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: wfr-a92c160-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 370 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 18 | 18 | 1.0 | 1.0 | 18 | 11 | +7 | 2 of 3 | 1 of 3 | - | +7 |

### Effective charges: wfr-a92c160-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 102 | 836 | +0 | 79 | 128 | -49 | -47.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 55 | +55 | 55 | 0 | +55 | +64.7 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 3 | 74 | 576 | +7 | 45 | 54 | -9 | -12.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p1 | move | 10 | 0 (0%) | 0 (0%) | 1 (10%) | 9 (90%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

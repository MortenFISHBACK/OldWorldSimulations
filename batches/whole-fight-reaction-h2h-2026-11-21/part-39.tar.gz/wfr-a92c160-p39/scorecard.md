# Doctrine scorecard: wfr-a92c160-p39

### Scorecard: wfr-a92c160-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 8 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 719 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 375 |
| L0425 | 5 | 1 | Opponent | no | - | 5 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 503 |
| L0512 | 2 | 1 | Opponent | - | - | 5 | 1 | 0 | 0 | 0 | 0 | 165 |
| **Average** | | | Mine | 50% | 8.0 | 3.0 | 0.7 | 3.3 | 0.0 | 0.0 | 0.0 | 292.7 |
| **Average** | | | Opponent | 0% | 0.0 | 5.0 | 1.0 | 1.7 | 0.0 | 0.0 | 0.0 | 294.7 |

### KPIs: wfr-a92c160-p39

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 0% (0 of 14) | 0% (0 of 24) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 100% | - | 83% (5 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 75% (9 of 12) | 56% (20 of 36) | 60% (29 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 75% (9 of 12) | 61% (20 of 33) | 64% (29 of 45) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 73% (4365 of 5998) | 77% (4600 of 5998) | 75% (8965 of 11996) |
|   infantry points that never fought | lower | 75% (1065 of 1424) | 78% (930 of 1187) | 76% (1995 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 78% (21 of 27) | 72% (36 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3042 of 5120) | 83% (4502 of 5442) | 71% (7544 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (56%) | 3.0 (47%) |
| MARCHED: its unit marched | 1.0 (100%) | 1.3 (25%) | 2.3 (37%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (12%) | 0.7 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (6%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.3 | 1.3 | 1.7 | 9.7 | 0.7 | 0.3 |
| not cast | 3.7 | 4.7 | 4.3 | 6.3 | 1.3 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (86%) | 4.0 (92%) | 3.0 (47%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (37%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (100%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (59 of 96) | 64% (45 of 70) | 63% (104 of 166) |
|   cavalry | 33% (4 of 12) | - | 33% (4 of 12) |
|   character | 90% (19 of 21) | 100% (3 of 3) | 92% (22 of 24) |
|   chariot | 12% (3 of 24) | 50% (2 of 4) | 18% (5 of 28) |
|   infantry | 58% (7 of 12) | 63% (17 of 27) | 62% (24 of 39) |
|   monster | - | 83% (5 of 6) | 83% (5 of 6) |
|   war machine | 96% (26 of 27) | 60% (18 of 30) | 77% (44 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (22%) | 0.3 (4%) | 3.0 (15%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 7.0 (57%) | 1.3 (16%) | 8.3 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (16%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (19%) | 1.0 (12%) | 3.3 (16%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 3.3 (40%) | 3.3 (16%) |
| STUPIDITY | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 8.0 | 1.3 | 83% | 5.3 pts | 43 pts |
| chariot | 1.7 | 3.3 | 60% | 15.4 pts | 26 pts |
| infantry | 11.0 | 1.7 | 85% | 6.5 pts | 71 pts |
| monster | 3.3 | 1.0 | 70% | 20.6 pts | 69 pts |
| war machine | 14.7 | 13.3 | 68% | 32.5 pts | 477 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.7 | 1.5 |
| Charges that made contact a game | 1.3 | 1.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.17 contact (23 units) | 0.24 declared, 0.12 contact (17 units) | 0.20 declared, 0.15 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (4 of 4) | 100% (2 of 2) | - | 100% (6 of 6) |
| Character on its own | 100% (3 of 3) | 40% (2 of 5) | 75% (3 of 4) | 67% (8 of 12) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 58% (7 of 12) | 67% (2 of 3) | - | 60% (9 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 83% (5 of 6); on the table 100% | 75% (9 of 12) | 80% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 58% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 33% (4 of 12) | 68% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 67% (12 of 18) | 73% | 56% (5 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 67% (4 of 6) | 89% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 67% (2) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: wfr-a92c160-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (14 of 41) | 40% (17 of 42) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 56% (5 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.3 | 1.7 |
| Movement | Points that never moved of their own | 292.7 | 294.7 |
| Movement | Fights charged into per game | 1.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +466 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +85 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +265 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (23 of 36) | 78% (21 of 27) |
| Shooting | Points destroyed by shooting units | 15.0 | 46.3 |
| Shooting | War machine shots | 8.7 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (19 of 26) | 33% (6 of 18) |
| Shooting | Points destroyed by war machines | 126.3 | 21.7 |
| Magic | Magic missiles cast | 2.0 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 60% (6 of 10) |
| Magic | Wounds caused by magic missiles | 6.0 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 76.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 1.3 / 0.3 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 214.0 | 63.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +223 | +88 |
| Combat | Net per 100 charger points, damage counted | +78.4 | +35.6 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +223 | +63 |
| Combat | Net points per supported fight / lone fight | - / +223 | - / +63 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 1 of 3 |
| Game | Points lost | 208.0 | 489.7 |
| Game | VP from objectives | 720.0 | 543.3 |
| Game | Lone holders (player turns) | 8.0 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +449 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 698
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +14.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.3 | +37.9 | 0.0 | 0.0 | 15.7 | +339.7 | 0.0 | 55.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.7 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.0 | +98.9 | 126.3 | 63.3 | 6.0 | +512.9 | 253.3 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.3 | +183.9 | 346.0 | 0.0 | 4.0 | +40.6 | 156.0 | 126.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +14.5 | 0.0 | 21.7 | 0.7 | +4.9 | 0.0 | 30.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +6.8 | 0.0 | 0.0 | 0.7 | +6.7 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -2.4 | 63.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.0 | -758.7 | 0.0 | 185.3 | 15.3 | -643.3 | 0.0 | 505.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.0 | 0.0 | 0.3 | +0.0 | 31.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 25.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 88.3 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +267.0 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -375.9 | 0.0 | 108.3 | 5.0 | -516.1 | 0.0 | 84.7 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +0.7 | 25.0 | 0.0 | 1.0 | -17.6 | 63.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 63.0 | 0.0 | 1.0 | +0.0 | 31.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.0 | +100.9 | 0.0 | 92.7 | 18.0 | +138.1 | 0.0 | 741.3 |
| FIGHT TO THE END | 0.7 | +18.7 | 63.0 | 0.0 | 0.7 | +18.8 | 0.0 | 0.0 |
| FIVE ACTION | 106.3 | +4799.4 | 1192.0 | 508.7 | 95.3 | +5002.9 | 726.0 | 1100.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 76.7 | 4.3 | +0.0 | 0.0 | 88.0 |
| FOLLOW UP WEIGHED | 1.0 | +182.7 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +89.2 | 88.0 | 0.0 | 1.7 | +217.2 | 63.3 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.5 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -12.2 | 0.0 | 0.0 |
| GOAL WALK | 11.7 | +941.2 | 0.0 | 0.0 | 5.3 | +182.2 | 0.0 | 169.3 |
| GUN FIGURES | 0.7 | +1.9 | 15.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +32.7 | 0.0 | 0.0 | 1.0 | +59.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 75.3 | 11.0 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -28.8 | 0.0 | 0.0 | 1.0 | -6.6 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 39.7 | +13.3 | 528.3 | 0.0 | 43.3 | +14.7 | 289.3 | 0.0 |
| HIS MOVE WHY | 16.0 | +0.0 | 0.0 | 92.7 | 28.0 | +0.0 | 0.0 | 502.0 |
| HIS ONE MOVE | 20.7 | -6.4 | 0.0 | 0.0 | 16.7 | -65.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.7 | +3858.2 | 0.0 | 382.0 | 53.0 | +4289.3 | 0.0 | 844.0 |
| HIS SHOTS BY HIS RUN | 32.7 | +688.1 | 0.0 | 382.0 | 29.0 | +581.2 | 0.0 | 505.3 |
| HIS TURN DENIED | 1.0 | +28.3 | 63.0 | 0.0 | 0.7 | +16.6 | 31.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +702.5 | 0.0 | 0.0 | 7.0 | +593.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -38.2 | 88.0 | 0.0 | 1.7 | -111.5 | 63.3 | 0.0 |
| HUNT IN PAIRS | 1.3 | +112.5 | 0.0 | 0.0 | 0.7 | +114.3 | 0.0 | 0.0 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 92.7 | 14.3 | -233.4 | 0.0 | 462.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 176.7 | 0.0 | 1.0 | +0.0 | 0.0 | 151.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.5 | 63.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -3.3 | 63.0 | 0.0 | 1.7 | -13.7 | 63.3 | 0.0 |
| MANOEUVRE | 2.3 | -31.6 | 0.0 | 0.0 | 3.3 | -30.8 | 0.0 | 63.0 |
| MARCH BY THE SUM | 0.7 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +46.0 | 0.0 | 0.0 | 2.7 | +185.9 | 0.0 | 63.0 |
| MARCH OF THE TABLE | 0.3 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -44.7 | 0.0 | 0.0 | 0.7 | +53.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +36.8 | 0.0 | 0.0 | 3.0 | +174.0 | 0.0 | 25.0 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +132.4 | 0.0 | 0.0 | 9.7 | +121.7 | 0.0 | 63.0 |
| MISSILES NEXT TURN | 3.3 | +87.8 | 0.0 | 0.0 | 11.3 | +128.6 | 0.0 | 189.3 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 4.0 | +154.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -8.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.3 | +236.9 | 0.0 | 0.0 | 2.3 | +182.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.7 | +431.2 | 0.0 | 0.0 | 10.3 | +448.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +181.7 | 0.0 | 0.0 | - | - | - | - |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -68.4 | 88.0 | 0.0 | 1.3 | -31.8 | 63.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +10.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -103.7 | 0.0 | 31.7 | 2.7 | -71.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -72.6 | 0.0 | 0.0 | 3.3 | -69.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | -127.8 | 0.0 | 0.0 | 3.7 | -64.1 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 1.0 | +13.3 | 43.3 | 0.0 |
| OPENS UP | 0.3 | +29.5 | 25.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +36.0 | 0.0 | 0.0 | 1.0 | +3.6 | 0.0 | 0.0 |
| PLAN RESULT | 47.0 | +482.9 | 341.0 | 416.0 | 43.3 | +665.3 | 270.7 | 528.3 |
| PROMISE BY ITS OWN SUM | 5.7 | -137.0 | 0.0 | 0.0 | 5.0 | -163.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -1.5 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.7 | 39.0 | 0.0 |
| QUARTER ODDS | 20.3 | +2182.5 | 63.0 | 0.0 | 15.3 | +850.2 | 0.0 | 0.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | -0.2 | 0.0 | 21.7 | 1.3 | +137.7 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +28.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -8.2 | 88.0 | 0.0 | 1.3 | -47.2 | 31.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -10.8 | 0.0 | 0.0 |
| RUN DOWN | 0.3 | -0.3 | 63.0 | 0.0 | 0.7 | -1.8 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -19.6 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +54.1 | 25.0 | 0.0 | 0.3 | +8.5 | 31.7 | 0.0 |
| SET UP BY THE SET | 0.3 | -45.6 | 0.0 | 0.0 | 0.7 | -58.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 63.3 | 13.7 | +0.0 | 0.0 | 78.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +86.8 | 0.0 | 0.0 | 2.7 | +20.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 25.3 | +523.7 | 0.0 | 382.0 | 27.3 | -123.1 | 0.0 | 674.7 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +424.4 | 0.0 | 101.0 | 18.0 | +1208.2 | 0.0 | 63.0 |
| SPELL WORTH | - | - | - | - | 2.0 | +52.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +6.2 | 63.3 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 46.3 | 6.7 | +0.0 | 0.0 | 109.7 |
| STAND AND SHOOT | 0.3 | -3.0 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 60.3 | +0.0 | 1104.0 | 294.7 | 46.3 | +0.0 | 662.7 | 631.3 |
| STAY WORTH | 32.3 | -4.7 | 598.7 | 37.7 | 30.7 | -93.4 | 662.7 | 126.0 |
| SUPPORT ADDS | 2.0 | +66.9 | 0.0 | 0.0 | 2.7 | +503.1 | 0.0 | 25.0 |
| SUPPORT WORKED OUT | 2.0 | +66.9 | 0.0 | 0.0 | 2.7 | +503.1 | 0.0 | 25.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 25.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 46.3 | 3.0 | +0.0 | 0.0 | 25.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 46.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 254.3 | 44.3 | +0.0 | 0.0 | 565.0 |
| TIED UP BY THE SUM | 0.3 | +32.1 | 25.0 | 0.0 | 0.3 | +46.1 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 44.3 | +432.1 | 505.3 | 173.7 | 14.7 | +165.9 | 0.0 | 63.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +109.0 | 0.0 | 0.0 | 0.7 | +11.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -70.6 | 0.0 | 0.0 | 0.3 | -87.9 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.3 | +262.6 | 0.0 | 63.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.7 | +94.1 | 0.0 | 0.0 | 1.3 | +9.4 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 249 | 249 | 165 | 55.00 | +0 | +0.0 |
| HIS MOVE WHY | 132 | 132 | 89 | 29.67 | +0 | +0.0 |
| ARMY TABLE | 102 | 102 | 76 | 25.33 | +1552 | +20.4 |
| HIS SHOT LIST | 308 | 292 | 72 | 24.00 | +1953 | +27.1 |
| HOLDER ASSIGNMENT | 44 | 44 | 42 | 14.00 | +2832 | +67.4 |
| HIS ONE MOVE | 112 | 109 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 185 | 177 | 37 | 12.33 | +511 | +13.8 |
| SHOT RISK POINTS | 158 | 153 | 26 | 8.67 | +1040 | +40.0 |
| TIME ON OUR SIDE | 177 | 168 | 25 | 8.33 | +74 | +3.0 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -525 | -27.6 |
| CAST JOB | 22 | 22 | 17 | 5.67 | +183 | +10.8 |
| CHARGE LOSSES | 82 | 77 | 14 | 4.67 | +552 | +39.4 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| FIVE ACTION | 605 | 582 | 12 | 4.00 | +275 | +22.9 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 12 | 4.00 | -902 | -75.1 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| QUARTER ODDS | 107 | 98 | 11 | 3.67 | +1221 | +111.0 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| GOAL WALK | 51 | 51 | 9 | 3.00 | +512 | +56.9 |
| MARCH CHECK | 11 | 11 | 9 | 3.00 | +298 | +33.1 |
| THE RISK READS HIS RUN | 36 | 36 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 35 | 31 | 8 | 2.67 | +168 | +21.0 |
| IDLE COST | 59 | 51 | 8 | 2.67 | +46 | +5.8 |
| MOVE TO CHARGE COMPUTED | 17 | 11 | 8 | 2.67 | +349 | +43.6 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 6 | 2.00 | +57 | +9.5 |
| STAY WORTH | 189 | 178 | 6 | 2.00 | +29 | +4.8 |
| SUPPORT ADDS | 14 | 14 | 6 | 2.00 | +294 | +49.0 |
| SUPPORT WORKED OUT | 14 | 14 | 6 | 2.00 | +294 | +49.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 7 | 5 | 1.67 | +218 | +43.6 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 5 | 1.67 | +46 | +9.2 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +119 | +29.7 |
| SHOTS IN THE MOVE | 102 | 87 | 4 | 1.33 | +277 | +69.2 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +43 | +14.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +40 | +13.5 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +548 | +182.7 |
| GUN MASK | 5 | 4 | 3 | 1.00 | +100 | +33.4 |
| MAX FOR POSITIONING | 16 | 16 | 3 | 1.00 | +16 | +5.4 |
| NEARER NOT NEEDED | 60 | 60 | 3 | 1.00 | +106 | +35.3 |
| NEXT CHARGE BY LIST | 6 | 5 | 3 | 1.00 | +253 | +84.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +192 | +64.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +42 | +21.0 |
| CANNON PLANNED TARGET | 42 | 42 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -196 | -97.8 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 4 | 2 | 0.67 | +43 | +21.3 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MANOEUVRE | 17 | 17 | 2 | 0.67 | +9 | +4.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +60 | +29.8 |
| MISSILES IN THE MOVE | 38 | 30 | 2 | 0.67 | +160 | +80.0 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +188 | +94.0 |
| SET UP BY THE SET | 3 | 3 | 2 | 0.67 | -11 | -5.5 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -58 | -58.3 |
| FALLS SHORT | 75 | 72 | 1 | 0.33 | +26 | +25.6 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +2 | +2.0 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +74 | +74.2 |
| HONEST WORTH | 9 | 7 | 1 | 0.33 | +7 | +7.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -22 | -22.1 |
| ONE OBJECTIVE FORMULA | 18 | 14 | 1 | 0.33 | +55 | +54.9 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -1.9 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -0 | -0.4 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +84 | +84.2 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +6 | +5.5 |
| SHOTS AFTER THE MOVES | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +6 | +5.9 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 13 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 44 | 42 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| EXACT ROUND | 4 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 28 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 58 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 9 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 59 | 59 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 44 | 37 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 17 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | not checked | - | - | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 7 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 86 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 320 | 309 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 290 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 2.33 | 30.4 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 2.00 | 75.1 |
| ARMY TABLE | rule | 2.00 | 1.33 | 68.2 |
| NO REASON | gate | 1.33 | - | 20.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 9.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 97.8 |
| SET UP BY THE SET | rule | - | 0.67 | 5.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 58.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 22.1 |
| PATHS CROSS | rule | - | 0.33 | 6.7 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 1.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 20.0 |

### Plans: wfr-a92c160-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 113 | 123 | 109% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 33.7 | 96% | 1872 | 0 | 0% |
| Mine | shoot | 11.7 | 40% | 413 | 360 | 87% |
| Opponent | charge | 1.3 | 25% | 65 | 37 | 57% |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 28.0 | 98% | 700 | 0 | 0% |
| Opponent | shoot | 11.7 | 69% | 648 | 629 | 97% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 26 (11) | 26 | 0 | 9 | 18% | 2.3 | 26 (8) | 28 (3) | - | 36 (8) | 0 (3) |
| Mine | Clean-up | 6 | 146 (6) | 72 | 74 | 0 | 83% | 5.0 | 0 (3) | 167 (2) | 563 (1) | 178 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 67% | 3.0 | 12 (2) | 0 (4) | - | 4 (5) | 0 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 50 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 63 (2) | 0 | 63 | 0 | 0% | 2.0 | 126 (1) | 0 (1) | - | 63 (2) | - |
| Mine | War machine | 5 | 80 (5) | 80 | 0 | 40 | 0% | 1.2 | 199 (2) | 0 (1) | 0 (2) | - | 80 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 50% | 4.5 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 11 (9) | 11 | 0 | 12 | 56% | 3.8 | 0 (3) | 20 (5) | 0 (1) | 13 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 100 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 38 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 155 (3) | 43 | 112 | 0 | 33% | 4.5 | - | 163 (2) | 137 (1) | 229 (2) | 0 (1) |
| Opponent | Shooter | 3 | 150 (3) | 45 | 106 | 0 | 0% | 1.0 | - | 317 (1) | 67 (2) | 159 (2) | 134 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 9 (5) | 9 | 0 | 0 | 0% | 1.4 | - | - | 9 (5) | - | 9 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 66 | 20% | 3.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |

### Charged fights: wfr-a92c160-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 446 | 2.0 | 1.0 | 223 | 0 | +223 | 1 of 4 | 4 of 4 | - | +223 |
| Mine | Dwarfen Mountain Holds | 1 | 379 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 226 | 297 | 1.3 | 1.0 | 223 | 0 | +223 | 1 of 4 | 4 of 4 | - | +223 |
| Opponent | Empire of Man | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 295 | 190 | 3.0 | 1.0 | 63 | 0 | +63 | 1 of 3 | 2 of 3 | - | +63 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 145 | 63 | 1.0 | 1.0 | 63 | 0 | +63 | 1 of 3 | 2 of 3 | - | +63 |

### Effective charges: wfr-a92c160-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 1 (net +466) | 0 | 0 | 0 | 1 (net +85) | 1 (net +265) | 1 | 0% (0 of 3) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 1 (net +95) | 0 | 0 | 2 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 189 | +466 | 466 | 9 | +457 | +380.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 265 | +265 | 265 | 0 | +265 | +78.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 68 | +85 | 95 | 0 | +95 | +27.9 |
| Mine | No odds | 1 | 339 | 75 | +75 | 75 | 0 | +75 | +22.1 |
| Mine | All fights | 4 | 284 | 149 | +223 | 225 | 2 | +223 | +78.4 |
| Opponent | 76-89% | 1 | 205 | 95 | +95 | 95 | 0 | +95 | +46.3 |
| Opponent | No odds | 2 | 270 | 167 | +48 | 85 | 0 | +85 | +31.5 |
| Opponent | All fights | 3 | 248 | 143 | +63 | 88 | 0 | +88 | +35.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p39 | move | 10 | 2 (20%) | 2 (20%) | 1 (10%) | 7 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

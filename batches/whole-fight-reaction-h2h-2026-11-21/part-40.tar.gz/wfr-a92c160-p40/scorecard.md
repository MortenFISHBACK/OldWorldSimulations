# Doctrine scorecard: wfr-a92c160-p40

### Scorecard: wfr-a92c160-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 702 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 3 | 5 | 0 | 0 | 0 | 698 |
| L0616 | 4 | 1 | Opponent | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 3 | 1 | 0 | 0 | 0 | 471 |
| L0632 | 2 | 1 | Opponent | - | - | 4 | 0 | 5 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 0.0 | 5.0 | 2.0 | 3.0 | 0.0 | 0.0 | 0.0 | 623.7 |
| **Average** | | | Opponent | 0% | 6.0 | 4.0 | 0.0 | 2.3 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: wfr-a92c160-p40

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 11) | 54% (13 of 24) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (10 of 12) | 83% (10 of 12) |
| Points that never fought | lower | 95% (5715 of 6000) | 89% (5366 of 5999) | 92% (11081 of 11999) |
|   infantry points that never fought | lower | 100% (2232 of 2232) | 85% (613 of 720) | 96% (2845 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (21 of 27) | 81% (17 of 21) | 79% (38 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 76% (3208 of 4232) | 81% (4371 of 5415) | 79% (7579 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (67%) | 1.3 (67%) |
| MARCHED: its unit marched | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 0.0 | 0.0 | 0.0 |
| not cast | 2.7 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (125 of 192) | 54% (19 of 35) | 63% (144 of 227) |
|   cavalry | 56% (10 of 18) | 62% (8 of 13) | 58% (18 of 31) |
|   character | 65% (13 of 20) | 0% (0 of 5) | 52% (13 of 25) |
|   infantry | 47% (25 of 53) | 20% (1 of 5) | 45% (26 of 58) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 76% (68 of 89) | 83% (10 of 12) | 77% (78 of 101) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (21%) | 1.0 (19%) | 5.7 (20%) |
| CHARGED: it charged | 2.3 (10%) | 0.3 (6%) | 2.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (6%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (12%) | 0.7 (2%) |
| NO TARGET IN RANGE | 6.3 (28%) | 2.7 (50%) | 9.0 (33%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.0 (31%) | 0.3 (6%) | 7.3 (27%) |
| SHELTERED: the target was sheltered | 2.0 (9%) | 0.0 (0%) | 2.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 0.7 | 89% | 4.7 pts | 28 pts |
| character | 4.3 | 2.7 | 69% | 17.6 pts | 76 pts |
| infantry | 17.7 | 6.0 | 77% | 8.2 pts | 146 pts |
| monster | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 26.0 | 18.3 | 62% | 21.8 pts | 567 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 0.7 | 1.8 |
| Charges that made contact a game | 1.7 | 0.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.24 contact (21 units) | 0.10 declared, 0.00 contact (20 units) | 0.27 declared, 0.12 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | - | 50% (1 of 2) | 67% (4 of 6) |
| Character in a unit | 83% (5 of 6) | 100% (3 of 3) | 100% (1 of 1) | 90% (9 of 10) |
| Character on its own | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) | 100% (6 of 6) |
| Infantry | 57% (4 of 7) | 50% (3 of 6) | - | 54% (7 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 100% (8 of 8) | - | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 95% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 91% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 67% (2 of 3); on the table 67% | 0% (0 of 6) | 89% | 87% (13 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 67% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 0% (0 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 59% (56 of 95) | 67% (8 of 12) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 623.7 | 56.7 |
| Movement | Fights charged into per game | 1.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 5, net +62 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.3 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (31 of 58) | 15% (2 of 13) |
| Shooting | Points destroyed by shooting units | 383.7 | 0.0 |
| Shooting | War machine shots | 22.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (47 of 68) | 40% (4 of 10) |
| Shooting | Points destroyed by war machines | 59.0 | 96.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 35.7 | 20.0 |
| Combat | Net points per charged fight, damage counted | +89 | - |
| Combat | Net per 100 charger points, damage counted | +129.4 | - |
| Combat | First round won (charged fights) | 60% | - |
| Combat | Net points per charged fight | +37 | - |
| Combat | Net points per supported fight / lone fight | - / +37 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | - |
| Game | Points lost | 116.7 | 488.3 |
| Game | VP from objectives | 740.0 | 453.3 |
| Game | Lone holders (player turns) | 0.0 | 6.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +746 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 605
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.3 | +264.8 | 0.0 | 0.0 | 12.7 | -5.2 | 0.0 | 274.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 1.0 | +12.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 305.0 | 0.0 | 0.3 | +0.0 | 38.3 | 0.0 |
| CANNON PLANNED TARGET | 22.0 | +181.6 | 2180.7 | 38.3 | 3.3 | +175.4 | 191.7 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +41.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.0 | -220.2 | 0.0 | 0.0 | 24.3 | -1394.3 | 0.0 | 1545.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 46.3 | 20.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 544.7 |
| COVER ONCE | 10.3 | -1032.5 | 0.0 | 0.0 | 5.3 | -243.6 | 0.0 | 239.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 3.0 | +13.6 | 82.0 | 20.0 | 0.7 | +4.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +0.1 | 82.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 16.7 | +296.3 | 0.0 | 409.3 |
| FEATURE BUFFS | 1.3 | +19.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +3.2 | 46.3 | 20.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 20.0 | 0.0 |
| FIVE ACTION | 136.3 | +4618.7 | 5412.0 | 96.7 | 75.7 | +2336.0 | 306.7 | 1771.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +64.6 | 82.0 | 20.0 | 0.7 | +1.1 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -13.7 | 0.0 | 0.0 | 2.0 | -4.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +8.8 | 0.0 | 20.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 2.7 | +84.3 | 0.0 | 0.0 | 14.0 | +908.7 | 0.0 | 277.0 |
| GUN FIGURES | 1.7 | +1.5 | 163.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.3 | +32.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 5.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 825.7 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 0.0 | 16.7 | +0.0 | 0.0 | 99.7 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 471.0 |
| HIS MOVE AND SHOT | 0.7 | -2.4 | 0.0 | 0.0 | 4.7 | -44.1 | 0.0 | 35.7 |
| HIS MOVE AS HE DECIDES | 33.3 | +9.0 | 678.0 | 0.0 | 39.3 | +16.3 | 60.0 | 0.0 |
| HIS MOVE WHY | - | - | - | - | 33.7 | +0.0 | 0.0 | 850.0 |
| HIS ONE MOVE | 20.0 | -24.6 | 0.0 | 0.0 | 15.3 | +27.1 | 0.0 | 124.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 124.7 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 314.0 |
| HIS RANDOM MOVE | 15.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +863.0 | 0.0 | 0.0 | 60.7 | +5249.9 | 0.0 | 1377.3 |
| HIS SHOTS BY HIS RUN | 17.7 | +337.9 | 0.0 | 0.0 | 49.0 | +1295.0 | 0.0 | 1744.0 |
| HIS TURN DENIED | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 11.0 | +1258.9 | 0.0 | 0.0 | 7.3 | +791.5 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -13.2 | 82.0 | 20.0 | 0.7 | -26.5 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.0 | -304.2 | 0.0 | 541.3 |
| JOINT CHARGE NOW | 1.0 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 26.7 | 40.0 | 3.0 | +0.0 | 40.0 | 80.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | +3.6 | 82.0 | 20.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -10.4 | 0.0 | 0.0 | 1.0 | +3.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +40.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +22.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +2.3 | 0.0 | 0.0 | 1.0 | +15.4 | 0.0 | 0.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.5 | 0.0 | 0.0 |
| MODEL FACING | 3.3 | +924.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 203.3 |
| MOVE TO CHARGE COMPUTED | 6.0 | +277.2 | 0.0 | 0.0 | 0.3 | +18.9 | 0.0 | 157.0 |
| NEARER NOT NEEDED | 6.0 | +272.0 | 0.0 | 0.0 | 3.3 | +134.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +157.4 | 0.0 | 0.0 | 0.3 | +18.9 | 0.0 | 157.0 |
| NO DOUBLE ROUNDS | 2.7 | -30.8 | 82.0 | 20.0 | 0.7 | -3.1 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -35.1 | 0.0 | 38.3 | 2.7 | -87.6 | 0.0 | 62.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.3 | -50.6 | 0.0 | 0.0 | 3.3 | -69.1 | 0.0 | 483.0 |
| ONE OBJECTIVE FORMULA | 4.7 | -105.1 | 0.0 | 0.0 | 2.7 | -83.2 | 0.0 | 37.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +11.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +35.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 61.3 | +2416.5 | 1492.3 | 136.7 | 35.3 | +162.0 | 0.0 | 678.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -103.4 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -4.9 | 0.0 | 0.0 | 2.0 | -4.2 | 0.0 | 0.0 |
| QUARTER ODDS | 13.0 | +992.0 | 142.3 | 0.0 | 10.0 | +866.3 | 153.3 | 196.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +114.9 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -7.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +141.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 26.7 |
| REDIRECT WEIGHED | 0.7 | +3.3 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +42.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +82.0 | 46.3 | 20.0 | 0.3 | -46.3 | 0.0 | 0.0 |
| RUN DOWN | 2.7 | -16.7 | 82.0 | 20.0 | 0.3 | -0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -55.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.7 | 0.0 | 0.0 | 1.0 | +81.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -70.8 | 0.0 | 0.0 | 2.3 | -60.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.3 | +105.2 | 0.0 | 0.0 | 2.3 | +30.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 1.0 | -0.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 32.7 | +0.0 | 0.0 | 38.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +14.0 | 0.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -11.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.3 | +284.2 | 0.0 | 0.0 | 38.0 | -1177.3 | 0.0 | 1474.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 40.7 | +1235.2 | 0.0 | 38.3 | 8.3 | +333.8 | 0.0 | 398.7 |
| SPELL WORTH | - | - | - | - | 1.3 | +28.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 72.7 |
| STAND AND SHOOT | 0.3 | -0.3 | 0.0 | 0.0 | 0.7 | -3.5 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 326.0 |
| STANDS STILL | 104.0 | +0.0 | 5330.0 | 76.7 | 21.7 | +0.0 | 306.7 | 397.3 |
| STAY WORTH | 81.3 | -284.7 | 4550.7 | 115.0 | 11.0 | +270.6 | 306.7 | 326.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +24.1 | 0.0 | 0.0 | 0.7 | +15.1 | 0.0 | 53.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +24.1 | 0.0 | 0.0 | 0.7 | +15.1 | 0.0 | 53.3 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 13.7 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.0 | +0.0 | 0.0 | 38.3 | 34.7 | +0.0 | 0.0 | 850.0 |
| TIED UP BY THE SUM | 0.3 | +9.1 | 0.0 | 0.0 | 0.3 | +41.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 53.0 | +615.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -5.2 | 82.0 | 20.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +30.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -89.2 | 0.0 | 0.0 | 1.7 | -107.2 | 0.0 | 428.3 |
| WHOLE FIGHT GAIN | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 0.3 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +30.5 | 0.0 | 0.0 | 7.0 | +717.8 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 218 | 218 | 142 | 47.33 | +0 | +0.0 |
| HIS SHOT LIST | 277 | 269 | 83 | 27.67 | +2047 | +24.7 |
| HIS MOVE WHY | 101 | 101 | 79 | 26.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 200 | 194 | 59 | 19.67 | +606 | +10.3 |
| HOLDER ASSIGNMENT | 55 | 55 | 52 | 17.33 | +3660 | +70.4 |
| ARMY TABLE | 60 | 60 | 47 | 15.67 | +1380 | +29.4 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| SHOT RISK POINTS | 151 | 145 | 39 | 13.00 | +1901 | +48.7 |
| HIS ONE MOVE | 106 | 104 | 38 | 12.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 159 | 146 | 23 | 7.67 | +116 | +5.0 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -368 | -23.0 |
| FIVE ACTION | 636 | 626 | 15 | 5.00 | +114 | +7.6 |
| THE RISK READS HIS RUN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 19 | 16 | 12 | 4.00 | +413 | +34.4 |
| CANNON PLANNED TARGET | 76 | 76 | 11 | 3.67 | -21 | -1.9 |
| PROMISE BY ITS OWN SUM | 30 | 30 | 11 | 3.67 | -310 | -28.2 |
| MODEL FACING | 10 | 10 | 10 | 3.33 | +2773 | +277.3 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +344 | +34.4 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 47 | 36 | 9 | 3.00 | +46 | +5.1 |
| CHAFF IN THE MOVE | 8 | 8 | 8 | 2.67 | +29 | +3.7 |
| GOAL WALK | 50 | 50 | 8 | 2.67 | +290 | +36.3 |
| CHARGE LOSSES | 94 | 89 | 7 | 2.33 | +319 | +45.6 |
| QUARTER ODDS | 69 | 68 | 7 | 2.33 | +336 | +48.1 |
| SET UP BY THE SET | 17 | 15 | 7 | 2.33 | +202 | +28.8 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 25 | 24 | 6 | 2.00 | +126 | +21.0 |
| FOUR ROUNDS | 11 | 11 | 5 | 1.67 | +54 | +10.8 |
| RISK BY ARC | 7 | 7 | 5 | 1.67 | +56 | +11.3 |
| IDLE COST | 54 | 46 | 4 | 1.33 | +52 | +13.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| NEXT CHARGE BY LIST | 7 | 7 | 4 | 1.33 | +386 | +96.4 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +248 | +62.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 147 | 125 | 4 | 1.33 | +116 | +28.9 |
| STAY WORTH | 277 | 265 | 4 | 1.33 | +63 | +15.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 1.00 | +38 | +12.6 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -29 | -9.7 |
| MAX FOR POSITIONING | 4 | 4 | 3 | 1.00 | +4 | +1.3 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +55 | +18.4 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +127 | +42.2 |
| EXACT ROUND | 11 | 11 | 2 | 0.67 | +17 | +8.4 |
| FALLS SHORT | 50 | 39 | 2 | 0.67 | +21 | +10.7 |
| GUN MASK | 7 | 7 | 2 | 0.67 | +32 | +15.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +96 | +47.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +28 | +13.8 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +40 | +19.9 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +44 | +22.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +20 | +19.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -14 | -14.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -10 | -10.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +26 | +26.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| LOST AFTER ESCAPE | 5 | 5 | 1 | 0.33 | +3 | +3.1 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +11 | +11.4 |
| NEARER NOT NEEDED | 28 | 27 | 1 | 0.33 | +6 | +6.5 |
| NO DOUBLE ROUNDS | 10 | 10 | 1 | 0.33 | +21 | +21.0 |
| ONE FIGHT FORMULA | 29 | 23 | 1 | 0.33 | +6 | +6.1 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +24 | +23.9 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +24 | +23.9 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -25 | -25.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +13 | +12.9 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 9 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 53 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 50 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 71 | 67 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 9 | 9 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 45 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 22 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 290 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | not checked | - | - | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 10 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 112 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 36 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 377 | 372 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 6 | 5 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 6 | 5 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | not checked | - | - | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 2.33 | 25.0 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | - | 28.2 |
| ARMY TABLE | rule | 0.67 | 1.67 | 34.8 |
| CANNON PLANNED TARGET | rule | 1.00 | - | 10.0 |
| JOINT CHARGE NOW | rule | 0.67 | - | 15.3 |
| BEST PRIZE | rule | 0.33 | - | 14.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 10.2 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 45.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 10.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 25.0 |

### Plans: wfr-a92c160-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 70 | 93 | 132% |
| Mine | join | 2.7 | 100% | 75 | 0 | 0% |
| Mine | move | 30.0 | 100% | 1073 | 0 | 0% |
| Mine | shoot | 26.7 | 75% | 821 | 2324 | 283% |
| Opponent | charge | 0.3 | 0% | 6 | 0 | 0% |
| Opponent | move | 30.7 | 93% | 956 | 0 | 0% |
| Opponent | shoot | 3.3 | 50% | 298 | 162 | 54% |
| Opponent | support | 1.0 | 100% | 5 | 0 | 0% |

### Battle groups: wfr-a92c160-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 50% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 32 (13) | 32 | 0 | 0 | 62% | 2.2 | 171 (3) | 0 (7) | 0 (3) | 0 (8) | 99 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 54 (6) | 13 | 41 | 0 | 83% | 1.0 | - | 80 (4) | 0 (2) | 74 (5) | 0 (1) |
| Mine | Shooter | 10 | 94 (10) | 13 | 81 | 8 | 10% | 2.0 | - | 169 (4) | 15 (6) | 156 (5) | 17 (5) |
| Mine | War machine | 17 | 38 (17) | 38 | 0 | 13 | 18% | 1.3 | 19 (9) | 0 (2) | 83 (6) | 157 (3) | 13 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 46 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 44 | 75% | 3.5 | 0 (3) | 0 (1) | 0 (3) | 0 (5) | 0 (2) |
| Opponent | Clean-up | 3 | 53 (3) | 0 | 53 | 0 | 100% | - | 71 (1) | 34 (2) | - | 53 (3) | - |
| Opponent | Fast Hammer | 4 | 59 (4) | 5 | 53 | 0 | 75% | 1.0 | - | 105 (3) | 0 (1) | 134 (2) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.5 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 145 (2) | 145 | 0 | 0 | 0% | 1.0 | - | - | 145 (2) | - | 145 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: wfr-a92c160-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 443 | 82 | 1.7 | 1.0 | 49 | 12 | +37 | 0 of 5 | 3 of 5 | - | +37 |
| Opponent | Kingdom of Bretonnia | 1 | 290 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 97 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: wfr-a92c160-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 3 (net +62) | 1 (net +0) | 0 | 1 (net +0) | 0 | 60% (3 of 5) |

### Charged fights, damage counted: wfr-a92c160-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 75 | 109 | +62 | 190 | 42 | +148 | +197.2 |
| Mine | 76-89% | 1 | 60 | 137 | +0 | 85 | 0 | +85 | +141.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 60 | 137 | +0 | 0 | 82 | -82 | -137.1 |
| Mine | All fights | 5 | 69 | 120 | +37 | 131 | 42 | +89 | +129.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p40 | move | 18 | 1 (6%) | 0 (0%) | 1 (6%) | 16 (89%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

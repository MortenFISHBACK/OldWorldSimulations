# Doctrine scorecard: wfr-a92c160-p28

### Scorecard: wfr-a92c160-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 285 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 385 |
| L0612 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 724 |
| L0628 | 4 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | - | 0.3 | 3.0 | 0.0 | 0.0 | 0.0 | 464.7 |
| **Average** | | | Opponent | 0% | 4.5 | 3.0 | 0.7 | 2.0 | 0.3 | 0.0 | 0.0 | 110.0 |

### KPIs: wfr-a92c160-p28

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 14) | 52% (15 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 43% (13 of 30) | 43% (13 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 45% (13 of 29) | 45% (13 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 93% (5585 of 6000) | 81% (4856 of 5998) | 87% (10441 of 11998) |
|   infantry points that never fought | lower | 100% (2232 of 2232) | 100% (694 of 694) | 100% (2926 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (19 of 27) | 57% (13 of 23) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.7 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (2849 of 4232) | 64% (3687 of 5787) | 65% (6536 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (24%) | 1.3 (24%) |
| MARCHED: its unit marched | - | 3.3 (59%) | 3.3 (59%) |
| CHARGED: its unit charged | - | 0.7 (12%) | 0.7 (12%) |
| IN COMBAT: engaged in combat | - | 0.3 (6%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 4.3 | 1.0 | 0.7 |
| not cast | 2.0 | 2.7 | 5.7 | 3.0 | 23.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (100%) | 1.3 (24%) | 0.7 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.3 (59%) | 1.7 (56%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.3 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (97%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (130 of 216) | 86% (12 of 14) | 62% (142 of 230) |
|   cavalry | 45% (10 of 22) | 0% (0 of 2) | 42% (10 of 24) |
|   character | 90% (26 of 29) | - | 90% (26 of 29) |
|   infantry | 46% (27 of 59) | - | 46% (27 of 59) |
|   monster | 36% (4 of 11) | - | 36% (4 of 11) |
|   war machine | 66% (63 of 95) | 100% (12 of 12) | 70% (75 of 107) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (15%) | 0.7 (100%) | 5.0 (17%) |
| CHARGED: it charged | 1.3 (5%) | 0.0 (0%) | 1.3 (5%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 10.7 (37%) | 0.0 (0%) | 10.7 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 2.0 (7%) | 0.0 (0%) | 2.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 8.3 (29%) | 0.0 (0%) | 8.3 (28%) |
| SHELTERED: the target was sheltered | 1.3 (5%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.0 | 70% | 7.4 pts | 25 pts |
| character | 9.7 | 5.0 | 79% | 7.2 pts | 70 pts |
| infantry | 18.7 | 8.3 | 62% | 12.3 pts | 230 pts |
| monster | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.3 | 17.3 | 66% | 20.5 pts | 520 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.7 | 1.5 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.00 contact (3 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.14 contact (21 units) | 0.31 declared, 0.15 contact (13 units) | 0.24 declared, 0.15 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | 100% (1 of 1) | 50% (1 of 2) | 29% (2 of 7) |
| Character in a unit | 88% (7 of 8) | 75% (3 of 4) | 100% (1 of 1) | 85% (11 of 13) |
| Character on its own | - | 67% (2 of 3) | 100% (2 of 2) | 80% (4 of 5) |
| Infantry | 14% (1 of 7) | 67% (4 of 6) | - | 38% (5 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 90% (9 of 10) | - | - | 90% (9 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 93% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 50% (9 of 18) | 100% | 44% (4 of 9) | 100% (3 of 3); 11.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 92% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 51% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 50% (1) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: wfr-a92c160-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (41 of 78) | 43% (9 of 21) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 464.7 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net -120 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +41 | 2 of 2, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 24.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (41 of 74) | - |
| Shooting | Points destroyed by shooting units | 182.0 | 0.0 |
| Shooting | War machine shots | 21.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (40 of 63) | 0% (0 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 60.0 |
| Magic | Magic missiles cast | - | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 35.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.0 / 0.7 / 0.7 / 1.0 |
| Combat | Points destroyed in combat | 13.7 | 103.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -23 | +63 |
| Combat | Net per 100 charger points, damage counted | -20.7 | +39.0 |
| Combat | First round won (charged fights) | 50% | 100% |
| Combat | Net points per charged fight | -40 | +95 |
| Combat | Net points per supported fight / lone fight | -120 / +41 | - / +95 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 0 of 2 |
| Game | Points lost | 230.0 | 195.7 |
| Game | VP from objectives | 720.0 | 583.3 |
| Game | Lone holders (player turns) | 2.0 | 4.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +112 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 426
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 8.3 | +167.4 | 0.0 | 40.0 | 7.7 | +91.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 124.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 17.7 | +62.5 | 390.0 | 135.0 | 4.0 | +145.5 | 95.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.3 | +9.9 | 70.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| CHARACTER GUNS | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.7 | -188.4 | 0.0 | 205.0 | 17.3 | -817.7 | 0.0 | 330.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 31.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 33.3 |
| COVER ONCE | 10.7 | -610.6 | 0.0 | 98.3 | 3.0 | -157.5 | 0.0 | 56.0 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -3.2 | 31.7 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 40.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +0.7 | 0.0 | 0.0 | 1.0 | +5.4 | 63.3 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +0.4 | 63.3 | 16.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 24.0 | +326.9 | 0.0 | 310.0 |
| FEATURE BUFFS | - | - | - | - | 1.3 | +2.0 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 138.7 | +4098.7 | 1812.0 | 736.7 | 66.7 | +2086.3 | 276.7 | 380.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 70.0 | 2.7 | +0.0 | 0.0 | 16.7 |
| FOUR ROUNDS | 1.3 | +140.2 | 0.0 | 40.0 | 1.7 | +36.4 | 63.3 | 16.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.3 | -16.9 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.0 | -56.4 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 72.3 |
| GOAL WALK | 3.7 | +286.5 | 0.0 | 0.0 | 1.3 | +59.5 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +10.0 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.7 | +51.4 | 0.0 | 0.0 | 2.7 | +84.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 185.0 | 8.3 | +0.0 | 0.0 | 186.0 |
| HIS CHARGE LIST | 14.0 | +0.0 | 0.0 | 63.3 | 10.0 | +0.0 | 0.0 | 184.3 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 144.7 |
| HIS MOVE AND SHOT | 4.3 | -20.1 | 0.0 | 55.0 | 4.0 | -23.8 | 0.0 | 186.0 |
| HIS MOVE AS HE DECIDES | 32.7 | +7.3 | 364.0 | 0.0 | 38.0 | +16.7 | 130.0 | 0.0 |
| HIS MOVE WHY | 41.0 | +0.0 | 0.0 | 130.0 | - | - | - | - |
| HIS ONE MOVE | 19.7 | -51.7 | 0.0 | 40.0 | 16.0 | +9.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 72.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.3 | +1387.1 | 0.0 | 220.0 | 41.0 | +4032.8 | 0.0 | 330.7 |
| HIS SHOTS BY HIS RUN | 30.3 | +462.5 | 0.0 | 283.3 | 37.3 | +1289.0 | 0.0 | 330.7 |
| HIS TURN DENIED | 0.3 | +0.5 | 0.0 | 20.0 | 0.7 | +36.6 | 31.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 0.0 | 16.7 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 9.7 | +916.5 | 0.0 | 0.0 | 9.7 | +1106.3 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -2.7 | 0.0 | 0.0 | 1.3 | -24.5 | 63.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +181.5 | 0.0 | 72.3 |
| IDLE COST | - | - | - | - | 15.3 | -384.9 | 0.0 | 16.7 |
| JOINT CHARGE NOW | 0.7 | +24.9 | 0.0 | 40.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 27.3 | 0.0 | 1.0 | +0.0 | 0.0 | 27.3 |
| LOST AFTER ESCAPE | 1.0 | +0.2 | 0.0 | 40.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -9.3 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +20.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +134.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +27.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.3 | +189.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +3.3 | 0.0 | 0.0 | 1.7 | +8.2 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 40.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 7.0 | +45.3 | 0.0 | 56.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.7 | +52.8 | 0.0 | 56.0 |
| MODEL FACING | 4.7 | +1643.1 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +159.2 | 0.0 | 0.0 | 2.0 | +114.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +244.6 | 0.0 | 0.0 | 4.7 | +215.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +108.2 | 0.0 | 0.0 | 1.7 | +96.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -9.1 | 0.0 | 40.0 | 1.0 | -19.2 | 63.3 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -143.4 | 0.0 | 20.0 | 4.7 | -136.2 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 5.0 | +18.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -20.5 | 0.0 | 0.0 | 2.0 | -57.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -103.3 | 0.0 | 0.0 | 4.3 | -69.1 | 0.0 | 37.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +68.6 | 0.0 | 0.0 |
| PLAN RESULT | 60.7 | +1385.1 | 336.3 | 380.0 | 31.0 | +58.1 | 141.7 | 364.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -54.3 | 0.0 | 0.0 | 3.7 | -15.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -3.6 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 72.3 |
| PROMISE SHOT AWAY | 2.3 | -30.3 | 259.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.0 | +927.3 | 27.3 | 120.0 | 1.7 | +333.3 | 0.0 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +10.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +50.2 | 0.0 | 0.0 | 0.7 | +38.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +9.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +39.1 | 0.0 | 40.0 | 1.0 | +31.5 | 0.0 | 16.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -6.6 | 63.3 | 16.7 |
| RUN DOWN | 0.7 | -2.8 | 0.0 | 0.0 | 0.7 | -0.4 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -99.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +11.1 | 0.0 | 0.0 | 1.3 | +21.0 | 0.0 | 93.0 |
| SECOND LOOK | 0.3 | +2.9 | 0.0 | 0.0 | 0.3 | +7.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -149.9 | 0.0 | 72.3 |
| SET UP BY THE SET | 1.0 | +4.2 | 0.0 | 0.0 | 2.7 | +128.7 | 0.0 | 72.3 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 26.0 | +0.0 | 0.0 | 135.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +34.8 | 186.0 | 0.0 | 2.0 | +6.3 | 63.3 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.9 | 31.7 | 0.0 |
| SHOT RISK POINTS | 25.3 | +711.2 | 0.0 | 260.0 | 18.7 | -292.4 | 0.0 | 144.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 35.0 | +939.3 | 0.0 | 236.7 | 4.0 | +212.9 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +138.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 202.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 133.3 | 0.0 |
| STANDS STILL | 105.3 | +0.0 | 1812.0 | 476.7 | 20.0 | +0.0 | 213.3 | 144.7 |
| STAY WORTH | 64.0 | +130.9 | 1147.7 | 143.3 | 13.3 | +103.5 | 110.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +1.5 | 0.0 | 20.0 | - | - | - | - |
| SUPPORT ADDS | 2.0 | +88.8 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.7 | +0.0 | 112.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +88.8 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.0 | 0.0 | 56.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.7 | +0.0 | 0.0 | 93.0 |
| THE STEP BACK IS MADE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 56.7 | +0.0 | 0.0 | 245.0 | 33.7 | +0.0 | 0.0 | 182.0 |
| TIED UP BY THE SUM | 0.3 | +11.2 | 0.0 | 0.0 | 0.3 | +22.0 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 59.0 | +621.1 | 0.0 | 70.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.1 | 0.0 | 0.0 | 1.0 | +9.0 | 63.3 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -88.0 | 0.0 | 95.0 | 2.0 | -125.0 | 0.0 | 186.0 |
| WHOLE FIGHT REACTION | 1.7 | +71.2 | 16.7 | 63.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.7 | +20.6 | 0.0 | 0.0 | 2.3 | +177.8 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 212 | 212 | 140 | 46.67 | +0 | +0.0 |
| HIS SHOT LIST | 271 | 264 | 72 | 24.00 | +2032 | +28.2 |
| HIS MOVE WHY | 123 | 123 | 54 | 18.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3385 | +62.7 |
| HIS SHOTS BY HIS RUN | 203 | 192 | 46 | 15.33 | +741 | +16.1 |
| ARMY TABLE | 48 | 48 | 39 | 13.00 | +731 | +18.7 |
| HIS ONE MOVE | 107 | 105 | 36 | 12.00 | +0 | +0.0 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -839 | -23.3 |
| SHOT RISK POINTS | 132 | 128 | 33 | 11.00 | +1274 | +38.6 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| TIME ON OUR SIDE | 177 | 165 | 30 | 10.00 | +173 | +5.8 |
| FIVE ACTION | 616 | 604 | 20 | 6.67 | +777 | +38.9 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 20 | 18 | 15 | 5.00 | +290 | +19.3 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +55 | +3.7 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4929 | +352.1 |
| COVER ONCE | 41 | 38 | 11 | 3.67 | +110 | +10.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CHARGE LOSSES | 90 | 86 | 9 | 3.00 | +426 | +47.3 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 9 | 3.00 | -210 | -23.4 |
| SHOTS AFTER THE MOVES | 22 | 22 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 46 | 39 | 8 | 2.67 | +226 | +28.3 |
| NEXT CHARGE BY LIST | 11 | 11 | 8 | 2.67 | +206 | +25.7 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +55 | +6.9 |
| THE RISK READS HIS RUN | 36 | 36 | 8 | 2.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 65 | 65 | 7 | 2.33 | -4 | -0.6 |
| PROMISE SHOT AWAY | 7 | 7 | 7 | 2.33 | -91 | -13.0 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 117 | 102 | 7 | 2.33 | +113 | +16.1 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 8 | 5 | 1.67 | +121 | +24.2 |
| LEGAL CHARGES ONLY | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 5 | 1.67 | +234 | +46.7 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +96 | +19.3 |
| SET UP BY THE SET | 11 | 9 | 5 | 1.67 | +267 | +53.5 |
| WOUNDS ON THE RANKS | 12 | 12 | 5 | 1.67 | +109 | +21.7 |
| FALLS SHORT | 72 | 64 | 4 | 1.33 | +65 | +16.3 |
| GOAL WALK | 15 | 15 | 4 | 1.33 | +407 | +101.7 |
| STAY WORTH | 232 | 217 | 4 | 1.33 | +10 | +2.5 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 3 | 1.00 | +1 | +0.4 |
| GUN MASK | 16 | 16 | 3 | 1.00 | +64 | +21.2 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -82 | -27.2 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RISK BY ARC | 7 | 6 | 3 | 1.00 | +62 | +20.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +75 | +37.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| QUARTER ODDS | 53 | 53 | 2 | 0.67 | +159 | +79.3 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +31 | +15.6 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -140 | -69.8 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +14 | +7.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.4 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -14 | -13.9 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 25 | 25 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 6 | 1 | 0.33 | +68 | +67.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +60 | +60.3 |
| MISSILES IN THE MOVE | 21 | 18 | 1 | 0.33 | +13 | +12.8 |
| MISSILES NEXT TURN | 29 | 26 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 30 | 28 | 1 | 0.33 | +4 | +3.7 |
| ONE OBJECTIVE FORMULA | 30 | 27 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +206 | +205.7 |
| PROMISE READS THE TABLE | 5 | 5 | 1 | 0.33 | +9 | +9.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +1 | +1.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 43 | 43 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 4 | 3 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 43 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 72 | 70 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 7 | 7 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 98 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 21 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | not checked | - | - | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 376 | 369 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 6 | 6 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 2 | not checked | - | - | - | - |
| THE TABLE BINDS | 271 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 11 | 11 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 3.67 | 25.5 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 0.33 | 23.4 |
| PROMISE SHOT AWAY | rule | 2.33 | - | 13.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 25.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 1.00 | - | 9.8 |
| ARMY TABLE | rule | 1.00 | - | 2.6 |
| MARCH OF THE TABLE | rule | - | 1.00 | 27.2 |
| RULE SWITCHED OFF | gate | - | 1.00 | 13.1 |
| SUPPORT NARROWED | rule | 0.67 | - | 69.8 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 4.2 |
| CHARGE NOW FIRST | rule | - | 0.33 | 13.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| JOINT CHARGE NOW | rule | 0.33 | - | 2.1 |
| NO REASON | gate | 0.33 | - | 32.0 |

### Plans: wfr-a92c160-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 14 | 15 | 108% |
| Mine | join | 1.7 | 100% | 54 | 0 | 0% |
| Mine | move | 35.0 | 98% | 923 | 0 | 0% |
| Mine | shoot | 23.3 | 70% | 791 | 1370 | 173% |
| Opponent | charge | 1.3 | 25% | 57 | 32 | 56% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 22.3 | 96% | 774 | 0 | 0% |
| Opponent | shoot | 5.3 | 19% | 181 | 26 | 15% |
| Opponent | support | 1.0 | 100% | 25 | 0 | 0% |

### Battle groups: wfr-a92c160-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 0 | 46% | 2.6 | 6 (6) | 0 (6) | 0 (1) | 4 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 10 | 75% | 1.0 | 0 (1) | 0 (1) | 0 (2) | 0 (4) | - |
| Mine | Fast | 3 | 75 (3) | 75 | 0 | 47 | 0% | 1.3 | - | 280 (1) | 0 (2) | 75 (3) | - |
| Mine | Hammer | 4 | 121 (4) | 0 | 121 | 0 | 50% | 2.0 | 0 (1) | 206 (3) | - | 121 (4) | - |
| Mine | Shooter | 8 | 105 (8) | 29 | 76 | 5 | 12% | 2.7 | 283 (1) | 108 (4) | 32 (3) | 107 (6) | 98 (2) |
| Mine | War machine | 17 | 0 (17) | 0 | 0 | 27 | 12% | 1.4 | 0 (4) | 0 (9) | 0 (4) | 0 (3) | 0 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 67% | 3.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 9 (10) | 9 | 0 | 11 | 60% | 2.2 | 11 (3) | 11 (5) | 0 (2) | 11 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 118 (1) | 118 | 0 | 0 | 0% | 3.0 | - | 118 (1) | - | 118 (1) | - |
| Opponent | Fast Hammer | 3 | 15 (3) | 0 | 15 | 0 | 67% | 6.0 | 0 (1) | 50 (1) | 0 (1) | 21 (2) | 0 (1) |
| Opponent | Holder | 6 | 76 (6) | 0 | 76 | 26 | 50% | 3.7 | 18 (1) | 86 (5) | - | 99 (4) | 37 (2) |
| Opponent | War machine | 2 | 55 (2) | 55 | 0 | 0 | 0% | 1.0 | - | 109 (1) | 0 (1) | - | 55 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: wfr-a92c160-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 182 | 14 | 0.7 | 1.5 | 20 | 60 | -40 | 1 of 2 | 1 of 2 | -120 | +41 |
| Opponent | Grand Cathay | 1 | 285 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 190 | 2.0 | 1.0 | 95 | 0 | +95 | 0 of 2 | 2 of 2 | - | +95 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 95 | 63 | 0.7 | 1.0 | 95 | 0 | +95 | 0 of 2 | 2 of 2 | - | +95 |

### Effective charges: wfr-a92c160-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net -120) | 0 | 0 | 0 | 0 | 1 (net +41) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +95) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: wfr-a92c160-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 357 | -120 | 32 | 120 | -88 | -73.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 105 | 41 | +41 | 41 | 0 | +41 | +39.0 |
| Mine | All fights | 2 | 112 | 199 | -40 | 37 | 60 | -23 | -20.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 161 | 95 | +95 | 95 | 32 | +63 | +39.0 |
| Opponent | All fights | 2 | 161 | 95 | +95 | 95 | 32 | +63 | +39.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p28 | move | 13 | 1 (8%) | 1 (8%) | 2 (15%) | 10 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

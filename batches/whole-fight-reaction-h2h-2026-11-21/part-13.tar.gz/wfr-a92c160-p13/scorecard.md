# Doctrine scorecard: wfr-a92c160-p13

### Scorecard: wfr-a92c160-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 758 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 3 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 2 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 984 |
| **Average** | | | Mine | 0% | 5.0 | - | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 2.3 | 1.3 | 0.0 | 0.0 | 0.0 | 580.7 |

### KPIs: wfr-a92c160-p13

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 65% (11 of 17) | 44% (11 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 100% | - | 83% (5 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (45 of 90) | - | 50% (45 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 58% (45 of 78) | - | 58% (45 of 78) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (3 of 5) | - | 60% (3 of 5) |
| Points that never fought | lower | 59% (3344 of 5699) | 70% (4182 of 6000) | 64% (7526 of 11699) |
|   infantry points that never fought | lower | 68% (1523 of 2239) | 86% (1825 of 2111) | 77% (3348 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (8 of 16) | 72% (18 of 25) | 63% (26 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 0.0 uses a game | 100% (4 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (1739 of 3916) | 67% (2926 of 4382) | 56% (4665 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (44%) | - | 6.7 (44%) |
| MARCHED: its unit marched | 4.3 (29%) | - | 4.3 (29%) |
| IN COMBAT: engaged in combat | 3.3 (22%) | - | 3.3 (22%) |
| GONE: slain | 0.7 (4%) | - | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.7 | 6.3 | 15.0 | 0.0 | 1.7 |
| not cast | 1.7 | 3.3 | 3.7 | 15.0 | 2.0 | 26.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (80%) | 0.0 (0%) | 6.7 (44%) | 2.0 (100%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (29%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (20%) | 1.7 (45%) | 3.3 (22%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) | 0.3 (1%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 0.0 (0%) | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.3 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.7 a game | 0.0 a game | 3.8 a game |
| stood (cast and not dispelled) | 87% (20 of 23) | - | 87% (20 of 23) |
| the unit moved after it | 55% (11 of 20) | - | 55% (11 of 20) |
| it charged on its next turn | 0% (0 of 20) | - | 0% (0 of 20) |
| the enemy charged it first | 10% (2 of 20) | - | 10% (2 of 20) |
| it fought by the end of its next turn | 5% (1 of 20) | - | 5% (1 of 20) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 20) | - | 5% (1 of 20) |
| none of these (no charge, no fight, no charge escaped) | 85% (17 of 20) | - | 85% (17 of 20) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (16 of 23) | 60% (114 of 189) | 61% (130 of 212) |
|   cavalry | - | 56% (18 of 32) | 56% (18 of 32) |
|   character | - | 53% (9 of 17) | 53% (9 of 17) |
|   chariot | - | 50% (1 of 2) | 50% (1 of 2) |
|   infantry | 70% (16 of 23) | 56% (40 of 71) | 60% (56 of 94) |
|   monster | - | 80% (8 of 10) | 80% (8 of 10) |
|   war machine | - | 67% (38 of 57) | 67% (38 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (71%) | 1.0 (4%) | 2.7 (10%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (9%) | 2.3 (9%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (4%) | 1.0 (4%) |
| NO TARGET IN RANGE | 0.3 (14%) | 9.7 (39%) | 10.0 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (4%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (14%) | 5.3 (21%) | 5.7 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (3%) | 0.7 (2%) |
| OTHER BAR | 0.0 (0%) | 4.0 (16%) | 4.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 2.3 | 76% | 3.4 pts | 29 pts |
| character | 3.0 | 4.0 | 56% | 9.2 pts | 28 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 26.3 | 10.3 | 71% | 3.5 pts | 92 pts |
| monster | 2.7 | 0.3 | 88% | 1.0 pts | 3 pts |
| war machine | 12.7 | 12.7 | 50% | 14.3 pts | 181 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 3.7 | 2.2 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.41 declared, 0.26 contact (27 units) | 0.28 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 100% (3 of 3) | 50% (2 of 4) | - | 71% (5 of 7) |
| Character on its own | 67% (2 of 3) | 50% (1 of 2) | 50% (1 of 2) | 57% (4 of 7) |
| Infantry | 43% (3 of 7) | 57% (4 of 7) | - | 50% (7 of 14) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 83% (5 of 6); on the table 100% | 50% (45 of 90) | 59% | 50% (8 of 16) | 100% (4 of 4); 4.3 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 80% | 75% (15 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 48% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 100% (1) | 71% (5) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (7 of 20) | 41% (30 of 73) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 45% (5 of 11) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 3.0 | 1.3 |
| Movement | Points that never moved of their own | 56.7 | 580.7 |
| Movement | Fights charged into per game | 0.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 6, net -105 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 6, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +186 | 3 of 6, net +75 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.3 | 27.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (5 of 16) | 51% (42 of 82) |
| Shooting | Points destroyed by shooting units | 24.0 | 241.3 |
| Shooting | War machine shots | - | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 79% (30 of 38) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 6.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (9 of 19) | - |
| Magic | Wounds caused by magic missiles | 14.3 | - |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 134.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.7 / 1.3 / 0.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 172.0 | 75.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +134 | +38 |
| Combat | Net per 100 charger points, damage counted | +83.1 | +17.7 |
| Combat | First round won (charged fights) | 0% | 67% |
| Combat | Net points per charged fight | +93 | +20 |
| Combat | Net points per supported fight / lone fight | - / +93 | -105 / +45 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 3 of 6 |
| Game | Points lost | 357.0 | 420.7 |
| Game | VP from objectives | 730.0 | 526.7 |
| Game | Lone holders (player turns) | 5.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +336 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 778
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 20.3 | +43.4 | 0.0 | 55.7 | 19.0 | +145.2 | 0.0 | 244.0 |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 21.7 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -6.3 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +15.4 | 66.7 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 13.7 | +234.4 | 830.3 | 290.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.0 | +25.4 | 372.0 | 301.7 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.0 | +208.8 | 144.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +81.0 | 0.0 | 56.7 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 4.3 | -1.0 | 0.0 | 72.0 |
| CHALLENGE BY POINTS | 0.7 | +30.3 | 0.0 | 25.7 | 0.3 | +9.5 | 0.0 | 62.0 |
| CHARACTER GUNS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -1281.2 | 0.0 | 440.7 | 10.0 | -270.6 | 0.0 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 2.3 | +0.0 | 187.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 20.0 | 7.0 | +0.0 | 0.0 | 94.0 |
| CONVEYANCE SEARCH | 5.3 | +707.7 | 181.3 | 0.0 | - | - | - | - |
| COVER ONCE | 7.3 | -418.8 | 0.0 | 151.3 | 8.7 | -330.5 | 0.0 | 35.0 |
| DENIED BY THE FIGHT | 0.7 | -3.9 | 62.0 | 17.3 | 0.7 | -1.0 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -230.5 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | -0.6 | 0.0 | 17.3 | 1.7 | +12.5 | 49.0 | 35.0 |
| FALL BACK GOOD ORDER | 0.7 | +2.4 | 62.0 | 17.3 | 3.3 | +0.0 | 70.7 | 35.0 |
| FALLS SHORT | 16.7 | +364.9 | 0.0 | 356.3 | 16.0 | +90.0 | 0.0 | 96.0 |
| FEATURE BUFFS | 14.0 | +483.8 | 0.0 | 20.0 | 1.3 | +4.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +2.4 | 62.0 | 17.3 | 0.7 | +47.0 | 17.3 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 21.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 74.3 | +7532.4 | 709.0 | 931.0 | 136.7 | +4297.3 | 2528.0 | 1005.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 164.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +163.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +20.6 | 62.0 | 17.3 | 3.7 | +186.0 | 96.3 | 35.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 90.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -11.5 | 90.7 | 0.0 |
| GOAL WALK | 14.7 | +2514.7 | 0.0 | 0.0 | 0.3 | +13.4 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.3 | +175.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 90.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 440.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 16.0 | +0.0 | 0.0 | 380.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.3 | +0.0 | 0.0 | 74.0 | 4.7 | +0.0 | 0.0 | 24.0 |
| HIS MOVE AND SHOT | 8.0 | -40.1 | 0.0 | 91.3 | 3.7 | -90.8 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 47.7 | +16.7 | 338.0 | 0.0 | 35.0 | +8.0 | 401.0 | 0.0 |
| HIS MOVE WHY | 25.7 | +0.0 | 0.0 | 423.7 | 14.7 | +0.0 | 0.0 | 35.0 |
| HIS ONE MOVE | 15.3 | +5.1 | 0.0 | 25.7 | 20.3 | -16.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 45.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 9.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 53.7 | +2386.7 | 0.0 | 568.7 | 57.3 | +2477.9 | 0.0 | 309.3 |
| HIS SHOTS BY HIS RUN | 45.0 | +929.8 | 0.0 | 517.3 | 45.3 | +1285.0 | 0.0 | 300.0 |
| HIS TURN DENIED | 0.7 | +14.6 | 62.0 | 17.3 | 1.0 | +22.0 | 21.7 | 35.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 32.7 | +0.0 | 0.0 | 201.3 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +1312.6 | 0.0 | 100.7 | 7.7 | +1018.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -5.1 | 62.0 | 17.3 | 2.7 | -117.2 | 96.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 2.7 | +395.2 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +31.7 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +36.4 | 31.7 | 0.0 |
| IDLE COST | 9.0 | -63.1 | 0.0 | 17.3 | 5.7 | -108.9 | 0.0 | 24.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +60.3 | 0.0 | 35.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -17.0 | 0.0 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +12.1 | 0.0 | 35.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 11.0 | +0.0 | 254.0 | 153.3 | 8.7 | +0.0 | 145.3 | 206.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +9.3 | 62.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 62.0 | 17.3 | 1.7 | +0.1 | 43.0 | 35.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +24.1 | 0.0 | 90.7 | 2.3 | -23.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +123.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | -107.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +76.4 | 0.0 | 195.7 | 2.3 | +19.8 | 0.0 | 24.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.0 | +443.5 | 0.0 | 318.0 | - | - | - | - |
| MISSILES NEXT TURN | 10.0 | +342.0 | 0.0 | 251.3 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.7 | -152.9 | 0.0 | 90.7 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.7 | +1483.3 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.7 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -21.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 3.7 | +0.0 | 0.0 | 181.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.3 | +237.7 | 0.0 | 0.0 | 4.0 | +108.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.7 | +245.7 | 0.0 | 21.7 | 11.0 | +456.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +159.2 | 0.0 | 0.0 | 4.0 | +97.4 | 90.7 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -13.7 | 62.0 | 17.3 | 3.3 | -108.4 | 79.0 | 35.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -109.6 | 0.0 | 203.0 | 5.3 | -115.7 | 0.0 | 143.3 |
| ONE CHALLENGE TEST | 0.3 | +1.4 | 62.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 7.3 | -85.3 | 0.0 | 169.0 | 5.0 | -44.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | -28.4 | 0.0 | 35.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +132.3 | 0.0 | 100.7 | 4.0 | -25.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +37.9 | 47.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.2 | 0.0 | 17.3 | 1.3 | +36.0 | 64.7 | 0.0 |
| PLAN RESULT | 33.7 | +256.3 | 296.0 | 454.0 | 61.3 | +1493.4 | 1142.7 | 774.7 |
| PROMISE BY ITS OWN SUM | 1.7 | +0.0 | 0.0 | 0.0 | 5.3 | -31.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 90.7 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +1119.5 | 0.0 | 0.0 | 14.7 | +816.4 | 0.0 | 168.3 |
| RANDOM MOVE BY FIGURES | 1.7 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -5.3 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 2.3 | +47.1 | 0.0 | 66.7 | 3.0 | +148.4 | 0.0 | 96.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +1.6 | 0.0 | 85.0 | 2.0 | +0.0 | 0.0 | 96.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -6.3 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.7 | 0.0 | 0.0 | 1.0 | +17.1 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.7 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +0.6 | 62.0 | 17.3 | 3.3 | -18.1 | 96.3 | 35.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -6.1 | 25.7 | 0.0 |
| RUN DOWN | 0.7 | -2.7 | 62.0 | 17.3 | 3.0 | -8.3 | 96.3 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.1 | 90.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -56.1 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +8.2 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +25.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -6.4 | 0.0 | 28.3 | 6.0 | -671.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +7.6 | 0.0 | 56.7 | 7.7 | +771.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.6 | 0.0 | 38.3 | 0.7 | +2.7 | 0.0 | 24.0 |
| SET-UP ANY TARGET | 0.3 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.3 | -35.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 186.7 | 24.7 | +0.0 | 0.0 | 290.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +53.4 | 35.0 | 0.0 | 1.7 | +48.8 | 134.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -0.5 | 186.0 | 136.7 | 0.7 | -0.6 | 21.7 | 0.0 |
| SHOT RISK POINTS | 37.7 | -7.4 | 0.0 | 423.3 | 43.0 | +671.5 | 0.0 | 247.3 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.3 | +229.4 | 0.0 | 43.3 | 44.0 | +992.7 | 0.0 | 454.3 |
| SPELL SETS UP CHARGE | 0.3 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 213.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -4.9 | 62.0 | 17.3 | 0.3 | -0.8 | 21.7 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 181.3 | 7.0 | +0.0 | 43.3 | 120.0 |
| STANDS STILL | 23.0 | +0.0 | 647.0 | 373.3 | 86.3 | +0.0 | 2431.7 | 828.7 |
| STAY WORTH | 7.3 | +66.8 | 296.0 | 168.3 | 59.3 | -166.1 | 1653.7 | 601.7 |
| STOPS | - | - | - | - | 0.3 | +2.5 | 31.7 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 40.0 |
| SUPPORT ADDS | 6.0 | +197.7 | 0.0 | 67.3 | 2.7 | +16.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 31.7 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +197.7 | 0.0 | 67.3 | 2.7 | +16.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +1.7 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 24.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -8.2 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 28.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 28.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.3 | +0.0 | 0.0 | 471.0 | 62.3 | +0.0 | 0.0 | 421.0 |
| TIED UP BY THE SUM | 0.3 | +28.9 | 62.0 | 0.0 | 1.0 | +67.5 | 79.0 | 0.0 |
| TIME ON OUR SIDE | 13.3 | +263.9 | 0.0 | 69.0 | 43.3 | +364.2 | 0.0 | 35.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -38.4 | 34.7 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -6.0 | 0.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +38.4 | 0.0 | 0.0 |
| WHO HITS BACK | 0.7 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +3.5 | 17.3 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -269.1 | 0.0 | 17.3 | 0.7 | -18.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.5 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 0.7 | +51.9 | 17.3 | 62.0 |
| WOUNDS ON THE RANKS | 7.3 | +1338.4 | 0.0 | 362.7 | 2.0 | +36.9 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 248 | 248 | 174 | 58.00 | +0 | +0.0 |
| HIS SHOT LIST | 333 | 325 | 106 | 35.33 | +1702 | +16.1 |
| HIS SHOTS BY HIS RUN | 271 | 262 | 76 | 25.33 | +1135 | +14.9 |
| ARMY TABLE | 118 | 118 | 75 | 25.00 | +639 | +8.5 |
| HIS MOVE WHY | 121 | 121 | 72 | 24.00 | +0 | +0.0 |
| SHOT RISK POINTS | 242 | 233 | 63 | 21.00 | +1480 | +23.5 |
| LEGAL CHARGES ONLY | 59 | 59 | 59 | 19.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 59 | 59 | 57 | 19.00 | +2938 | +51.5 |
| HIS ONE MOVE | 107 | 106 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -676 | -26.0 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| GOAL WALK | 45 | 45 | 21 | 7.00 | +3652 | +173.9 |
| TIME ON OUR SIDE | 170 | 159 | 21 | 7.00 | +116 | +5.5 |
| FIVE ACTION | 633 | 621 | 20 | 6.67 | +1078 | +53.9 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 17 | 5.67 | +0 | +0.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4450 | +317.9 |
| CHAFF PASSED | 13 | 13 | 13 | 4.33 | -3 | -0.2 |
| THE RISK READS HIS RUN | 36 | 36 | 13 | 4.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 41 | 41 | 12 | 4.00 | -34 | -2.8 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| WOUNDS ON THE RANKS | 28 | 27 | 12 | 4.00 | +736 | +61.4 |
| CASTING BLOCK | 12 | 12 | 11 | 3.67 | +240 | +21.8 |
| FALLS SHORT | 98 | 77 | 10 | 3.33 | +130 | +13.0 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| MAX FOR POSITIONING | 21 | 20 | 10 | 3.33 | +11 | +1.1 |
| MOVE TO CHARGE COMPUTED | 19 | 18 | 8 | 2.67 | +370 | +46.2 |
| NEXT CHARGE BY LIST | 16 | 15 | 8 | 2.67 | +315 | +39.4 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 148 | 130 | 6 | 2.00 | +373 | +62.2 |
| CAST JOB | 6 | 6 | 5 | 1.67 | +11 | +2.1 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 48 | 40 | 5 | 1.67 | +52 | +10.3 |
| FOUR ROUNDS | 13 | 11 | 5 | 1.67 | +52 | +10.3 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +369 | +73.9 |
| RESERVE MOVE SPELL | 5 | 5 | 5 | 1.67 | +121 | +24.3 |
| SET UP BY THE SET | 26 | 26 | 5 | 1.67 | +669 | +133.7 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 5 | 1.67 | +27 | +5.4 |
| SUPPORT ADDS | 26 | 25 | 5 | 1.67 | +171 | +34.3 |
| SUPPORT WORKED OUT | 26 | 25 | 5 | 1.67 | +171 | +34.3 |
| CHAFF IN THE MOVE | 7 | 6 | 4 | 1.33 | +21 | +5.2 |
| CHARGE LOSSES | 83 | 79 | 4 | 1.33 | +228 | +57.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +492 | +122.9 |
| HIS MOVE AND SHOT | 35 | 35 | 4 | 1.33 | +12 | +3.1 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 27 | 19 | 4 | 1.33 | +195 | +48.9 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +60 | +14.9 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +119 | +39.8 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +72 | +24.2 |
| QUARTER ODDS | 64 | 63 | 3 | 1.00 | +134 | +44.5 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 3 | 1.00 | +39 | +13.0 |
| RISK BY ARC | 12 | 10 | 3 | 1.00 | +28 | +9.4 |
| STAY WORTH | 200 | 195 | 3 | 1.00 | +15 | +5.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +66 | +21.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 4 | 3 | 2 | 0.67 | +76 | +38.2 |
| IDLE COST | 44 | 33 | 2 | 0.67 | +7 | +3.3 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +181 | +90.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 2 | 0.67 | -95 | -47.6 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +67 | +33.4 |
| SET CREDITED ONCE | 20 | 20 | 2 | 0.67 | +18 | +8.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +26 | +13.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -19 | -18.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +46 | +46.3 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -11 | -11.2 |
| FEATURE BUFFS | 46 | 46 | 1 | 0.33 | +4 | +4.3 |
| HIS TURN DENIED | 5 | 4 | 1 | 0.33 | +24 | +24.3 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +36 | +36.2 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +24 | +24.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -25 | -25.2 |
| MOVE SPELL IN RANGE | 2 | 2 | 1 | 0.33 | +15 | +15.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 3 | 2 | 1 | 0.33 | +125 | +124.7 |
| ONE OBJECTIVE FORMULA | 35 | 23 | 1 | 0.33 | +71 | +70.9 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +34 | +34.3 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +13 | +12.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +89 | +89.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +77 | +77.0 |
| SHOTS AFTER THE MOVES | 20 | 20 | 1 | 0.33 | +0 | +0.0 |
| STOPS | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.4 |
| THE ROW IN ITS ORDER | 9 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +115 | +115.3 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.33 | +11 | +10.5 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 20 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 63 | 62 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 4 | 4 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 138 | 138 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 8 | 8 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH CHECK | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 30 | 20 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 50 | 48 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 37 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 285 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 16 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 96 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 45 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 25 | 25 | 0 | 0.00 | - | - |
| STANDS STILL | 328 | 328 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 7 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 296 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.00 | 22.9 |
| ARMY TABLE | rule | 1.33 | 0.67 | 43.6 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 10.6 |
| CANNON PLANNED TARGET | rule | - | 1.33 | 8.7 |
| NO REASON | gate | - | 1.33 | 46.8 |
| CHAFF PASSED | rule | - | 1.00 | 1.0 |
| PROMISE BY ITS OWN SUM | rule | - | 0.67 | 47.6 |
| BEST PRIZE | rule | - | 0.33 | 18.9 |
| CHARGE NOW FIRST | rule | - | 0.33 | 11.2 |
| FALLBACK | gate | 0.33 | - | 1.6 |
| MARCH OF THE TABLE | rule | 0.33 | - | 25.2 |
| RESERVE FALL BACK | rule | - | 0.33 | 42.1 |
| RULE SWITCHED OFF | gate | 0.33 | - | 29.1 |

### Plans: wfr-a92c160-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 11 | 54 | 476% |
| Mine | join | 0.3 | 100% | 8 | 0 | 0% |
| Mine | move | 26.7 | 92% | 2752 | 0 | 0% |
| Mine | shoot | 5.3 | 50% | 784 | 203 | 26% |
| Mine | support | 0.7 | 100% | 1 | 0 | 0% |
| Opponent | charge | 3.3 | 40% | 318 | 96 | 30% |
| Opponent | move | 37.7 | 97% | 1447 | 0 | 0% |
| Opponent | shoot | 20.3 | 79% | 633 | 1398 | 221% |

### Packages: hunt the guns, wfr-a92c160-p13

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 109 | 95 | 100% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Dwarfen Mountain Holds | 0.5 | 1 | 0 | 100% | 100% | 0% | 2.0 | 109 | 95 | 100% | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: wfr-a92c160-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 14 | 75% | 2.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 19 (15) | 19 | 0 | 17 | 20% | 3.2 | - | 15 (10) | 25 (2) | 23 (7) | 8 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 33% | 3.5 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 83 (6) | 13 | 70 | 16 | 50% | 4.3 | 132 (1) | 105 (3) | 34 (2) | 59 (4) | 125 (2) |
| Mine | Holder | 5 | 49 (5) | 0 | 49 | 21 | 40% | 4.0 | 14 (3) | 195 (1) | 0 (1) | 0 (1) | 59 (4) |
| Mine | Shooter | 2 | 132 (2) | 55 | 77 | 50 | 0% | 1.0 | - | 265 (1) | 0 (1) | 132 (2) | - |
| Mine | Wizard | 3 | 50 (3) | 50 | 0 | 27 | 0% | 3.0 | - | 0 (1) | 226 (1) | 68 (2) | - |
| Opponent | Chaff | 2 | 69 (2) | 0 | 69 | 100 | 0% | 1.5 | 0 (1) | 139 (1) | - | 69 (2) | - |
| Opponent | Character | 8 | 25 (8) | 25 | 0 | 0 | 38% | 2.6 | 0 (1) | 29 (6) | 0 (1) | 62 (4) | 9 (4) |
| Opponent | Clean-up | 6 | 26 (6) | 13 | 13 | 0 | 17% | 2.6 | 0 (1) | 40 (5) | - | 18 (5) | 49 (1) |
| Opponent | Fast Hammer | 4 | 19 (4) | 19 | 0 | 31 | 25% | 3.0 | 0 (1) | 55 (1) | 0 (2) | 23 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.5 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 10 | 44 (10) | 10 | 33 | 14 | 0% | 2.4 | 0 (2) | 48 (8) | - | 55 (8) | 15 (2) |
| Opponent | War machine | 12 | 26 (12) | 26 | 0 | 53 | 8% | 1.9 | 31 (10) | - | 0 (2) | 0 (2) | 32 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: wfr-a92c160-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 158 | 62 | 0.7 | 1.0 | 93 | 0 | +93 | 1 of 2 | 0 of 2 | - | +93 |
| Opponent | Dwarfen Mountain Holds | 2 | 362 | 48 | 1.5 | 1.3 | 32 | 35 | -3 | 1 of 3 | 1 of 3 | -105 | +48 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 130 | 3.0 | 1.0 | 43 | 0 | +43 | 2 of 3 | 3 of 3 | - | +43 |
| **Opponent** | all armies | 3 | 241 | 75 | 2.0 | 1.2 | 38 | 18 | +20 | 3 of 6 | 4 of 6 | -105 | +45 |

### Effective charges: wfr-a92c160-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +186) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 3 | 1 (net -105) | 0 | 0 | 1 (net +0) | 0 | 1 (net +95) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 (net +65) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 52 | 105 | +0 | 79 | 35 | +44 | +84.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 271 | 186 | +186 | 224 | 0 | +224 | +82.8 |
| Mine | All fights | 2 | 162 | 146 | +93 | 151 | 17 | +134 | +83.1 |
| Opponent | Long shot (under 50%) | 1 | 155 | 836 | -105 | 71 | 105 | -34 | -21.7 |
| Opponent | 76-89% | 1 | 50 | 52 | +0 | 17 | 0 | +17 | +34.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 222 | 246 | +75 | 80 | 11 | +70 | +31.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 77 | +0 | 38 | 0 | +38 | +8.9 |
| Opponent | All fights | 6 | 217 | 284 | +20 | 61 | 23 | +38 | +17.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p13 | move | 23 | 0 (0%) | 0 (0%) | 3 (13%) | 20 (87%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

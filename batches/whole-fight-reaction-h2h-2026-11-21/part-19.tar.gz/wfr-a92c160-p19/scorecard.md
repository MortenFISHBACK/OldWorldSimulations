# Doctrine scorecard: wfr-a92c160-p19

### Scorecard: wfr-a92c160-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 4 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | no | 1 | 5 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 165 |
| L1228 | 4 | 1 | Opponent | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 1.5 | 3.0 | 1.7 | 0.7 | 0.3 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 2.5 | 4.0 | 2.7 | 1.7 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: wfr-a92c160-p19

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (5 of 15) | 20% (3 of 15) | 27% (8 of 30) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 80% (4 of 5); on the table 80% | 75% (6 of 8); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 50% (3 of 6); on the table 67% | 62% (5 of 8); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 67% (8 of 12); on the table 75% | 74% (14 of 19); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 26% (19 of 72) | 33% (6 of 18) | 28% (25 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (19 of 55) | 43% (6 of 14) | 36% (25 of 69) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 47% (2809 of 5998) | 32% (1892 of 6000) | 39% (4701 of 11998) |
|   infantry points that never fought | lower | 63% (462 of 730) | 79% (617 of 782) | 71% (1079 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 72% (18 of 25) | 69% (18 of 26) | 71% (36 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 57% (4 of 7); 3.7 uses a game | 50% (1 of 2); 1.3 uses a game | 56% (5 of 9); 2.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3697 of 5614) | 71% (3993 of 5644) | 68% (7690 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (34%) | 0.7 (17%) | 6.7 (31%) |
| MARCHED: its unit marched | 5.3 (30%) | 0.0 (0%) | 5.3 (25%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 5.0 (28%) | 1.0 (25%) | 6.0 (28%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (17%) | 0.7 (3%) |
| FLEEING: fleeing | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (33%) | 1.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 5.7 | 1.0 | 8.3 | 0.7 | 4.7 |
| not cast | 1.0 | 10.3 | 5.0 | 21.7 | 3.3 | 23.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (48%) | 0.3 (7%) | 6.7 (31%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (25%) | 0.7 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (6%) | 1.0 (20%) | 6.0 (28%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (19%) | 2.0 (40%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) | 0.3 (10%) | 1.0 (4%) |
| GONE: slain | 0.0 (0%) | 0.3 (3%) | 0.3 (7%) | 0.3 (2%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (33%) | 0.7 (6%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.3 (13%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (67%) | 0.0 (0%) | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 100% (3 of 3) | 100% (3 of 3) |
| the unit moved after it | - | 0% (0 of 3) | 0% (0 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (33 of 50) | 59% (48 of 81) | 62% (81 of 131) |
|   cavalry | - | 62% (13 of 21) | 62% (13 of 21) |
|   character | - | 67% (8 of 12) | 67% (8 of 12) |
|   chariot | 78% (7 of 9) | 92% (11 of 12) | 86% (18 of 21) |
|   infantry | 73% (8 of 11) | 44% (12 of 27) | 53% (20 of 38) |
|   monster | - | 44% (4 of 9) | 44% (4 of 9) |
|   war machine | 60% (18 of 30) | - | 60% (18 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (24%) | 4.0 (36%) | 5.3 (32%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (18%) | 2.0 (12%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 1.3 (12%) | 1.7 (10%) |
| MOVED: a war machine that moved | 1.3 (24%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (15%) | 1.7 (10%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (12%) | 0.0 (0%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 1.3 (12%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 1.0 (18%) | 0.0 (0%) | 1.0 (6%) |
| STUPIDITY | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.3 (6%) | 0.3 (3%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.0 | 82% | 7.7 pts | 44 pts |
| character | 2.7 | 1.3 | 75% | 27.5 pts | 73 pts |
| chariot | 6.0 | 1.0 | 89% | 8.0 pts | 48 pts |
| infantry | 9.3 | 1.7 | 82% | 2.1 pts | 20 pts |
| monster | 1.3 | 1.0 | 75% | 3.5 pts | 5 pts |
| war machine | 7.0 | 5.7 | 57% | 26.8 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.3 | 3.7 |
| Charges that made contact a game | 2.3 | 4.0 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.00 contact (6 units) | - | 1.33 declared, 1.00 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | - | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (9 units) | 0.50 declared, 0.46 contact (26 units) | 0.37 declared, 0.34 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (2 of 6) | - | 75% (3 of 4) | 50% (5 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (3 of 3) | - | 100% (5 of 5) |
| Character on its own | 100% (1 of 1) | 57% (4 of 7) | 40% (2 of 5) | 54% (7 of 13) |
| Chariot | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 86% (6 of 7); on the table 86% | 26% (19 of 72) | 47% | 72% (18 of 25) | 57% (4 of 7); 3.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 68% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 75% (3 of 4); on the table 75% | 67% (4 of 6) | 2% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (3 of 6); on the table 67% | 33% (2 of 6) | 25% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (4) | 50% (2) | 50% (6) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 91% (10 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (12 of 37) | 64% (14 of 22) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (5 of 8) | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 75% (3 of 4) |
| Strategy | Lone characters that fought | 90% (9 of 10) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 165.0 | 0.0 |
| Movement | Fights charged into per game | 2.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 6, net +379 | 3 of 7, net +32 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 6, net +56 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +0 | 3 of 7, net +334 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 16.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 15) | 54% (26 of 48) |
| Shooting | Points destroyed by shooting units | 0.0 | 55.0 |
| Shooting | War machine shots | 6.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (8 of 18) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 13% (2 of 15) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 3.3 | 0.7 |
| Magic | Wounds caused by other spells | 6.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 172.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.7 / 2.0 / 0.3 | 1.3 / 0.7 / 1.3 / 0.0 |
| Combat | Points destroyed in combat | 92.7 | 130.7 |
| Combat | Points run down | 252.7 | 234.7 |
| Combat | Net points per charged fight, damage counted | +81 | +123 |
| Combat | Net per 100 charger points, damage counted | +21.5 | +55.7 |
| Combat | First round won (charged fights) | 67% | 56% |
| Combat | Net points per charged fight | +145 | +91 |
| Combat | Net points per supported fight / lone fight | +758 / +22 | +704 / +14 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 6 | 6 of 9 |
| Game | Points lost | 408.7 | 551.7 |
| Game | VP from objectives | 793.3 | 453.3 |
| Game | Lone holders (player turns) | 1.5 | 2.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +307 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 960
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +16.0 | 0.0 | 136.0 | 0.3 | +124.1 | 0.0 | 0.0 |
| ARMY TABLE | 13.3 | +451.7 | 0.0 | 150.0 | 30.3 | +419.8 | 0.0 | 219.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +11.7 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +3.2 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 117.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +3.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -13.7 | 11.3 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -18.7 | 0.0 | 0.0 |
| BOMBING RUN | 0.3 | +10.8 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.7 | +123.4 | 135.7 | 165.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.3 | +25.1 | 85.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.7 | +89.3 | 114.0 | 0.0 | 1.7 | +17.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.3 | +88.5 | 0.0 | 37.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -17.1 | 136.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +33.7 | 136.0 | 0.0 |
| CHARGE LOSSES | 22.0 | -607.6 | 0.0 | 743.0 | 21.0 | -696.7 | 0.0 | 393.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 30.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 120.7 | 0.0 | 1.7 | +0.0 | 105.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 36.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +102.4 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -411.5 | 0.0 | 185.0 | 8.3 | -971.9 | 0.0 | 120.7 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.7 | -2.0 | 37.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +12.8 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +11.0 | 63.0 | 0.0 | 3.3 | -55.1 | 594.0 | 30.0 |
| FALL BACK GOOD ORDER | 1.7 | +3.6 | 170.0 | 0.0 | 3.3 | +7.4 | 643.0 | 0.0 |
| FALLS SHORT | 4.3 | +98.6 | 0.0 | 99.0 | 19.3 | +278.3 | 0.0 | 197.7 |
| FEATURE BUFFS | 2.0 | +6.7 | 0.0 | 98.0 | 0.3 | +11.1 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +16.1 | 271.3 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| FIVE ACTION | 79.3 | +4799.9 | 1098.3 | 1282.0 | 80.3 | +4464.0 | 1190.0 | 642.0 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 272.0 | 5.0 | +0.0 | 0.0 | 267.7 |
| FOLLOW UP WEIGHED | 0.7 | +184.5 | 0.0 | 0.0 | 1.0 | +32.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +545.1 | 455.0 | 0.0 | 4.0 | +271.2 | 779.0 | 30.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 83.7 |
| FRIEND SHOOTS FIRST | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -2.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.6 | 11.3 | 0.0 | - | - | - | - |
| GOAL WALK | 5.0 | +285.0 | 0.0 | 50.0 | 16.0 | +1486.5 | 0.0 | 83.7 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 2.3 | +54.8 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.0 | +0.0 | 0.0 | 593.0 | 11.0 | +0.0 | 0.0 | 355.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 272.0 | 4.3 | +0.0 | 0.0 | 83.7 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 271.3 |
| HIS MOVE AND SHOT | 3.7 | -11.6 | 0.0 | 50.0 | 11.7 | -113.9 | 0.0 | 49.3 |
| HIS MOVE AS HE DECIDES | 42.7 | +8.3 | 676.7 | 0.0 | 28.0 | +8.0 | 149.0 | 0.0 |
| HIS MOVE WHY | 29.0 | +0.0 | 0.0 | 149.0 | - | - | - | - |
| HIS ONE MOVE | 18.0 | +26.4 | 0.0 | 0.0 | 15.7 | +13.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 38.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 135.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +1164.1 | 0.0 | 952.0 | 52.3 | +2449.9 | 0.0 | 538.0 |
| HIS SHOTS BY HIS RUN | 39.7 | +870.3 | 0.0 | 952.0 | 51.0 | +1794.8 | 0.0 | 538.0 |
| HIS TURN DENIED | 1.0 | +7.3 | 172.7 | 0.0 | 0.7 | +7.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 740.0 | 7.3 | +0.0 | 0.0 | 271.3 |
| HOLDER ASSIGNMENT | 10.0 | +928.3 | 0.0 | 321.0 | 6.0 | +630.5 | 0.0 | 135.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -100.6 | 183.7 | 0.0 | 2.7 | -81.1 | 593.0 | 0.0 |
| HUNT IN PAIRS | 2.0 | +221.2 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +136.7 | 0.0 | 30.0 |
| IDLE COST | 1.3 | -42.1 | 0.0 | 0.0 | 11.3 | -223.7 | 0.0 | 83.7 |
| JOINT CHARGE NOW | 0.7 | +47.5 | 271.3 | 0.0 | 1.3 | +24.0 | 544.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -11.4 | 136.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 121.7 | 49.0 | 6.0 | +0.0 | 0.0 | 296.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | -3.1 | 392.0 | 0.0 | 3.3 | +17.0 | 729.0 | 30.0 |
| MANOEUVRE | 2.0 | +3.9 | 0.0 | 0.0 | 1.3 | +7.8 | 0.0 | 172.7 |
| MARCH BY THE SUM | 1.7 | +101.3 | 0.0 | 0.0 | 0.3 | +9.1 | 0.0 | 0.0 |
| MARCH CHECK | 2.3 | +107.1 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.3 | +189.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.3 | +137.9 | 0.0 | 0.0 | 0.7 | +127.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +100.3 | 0.0 | 0.0 | 3.3 | +119.9 | 0.0 | 149.3 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +118.6 | 0.0 | 0.0 | 4.3 | +40.1 | 0.0 | 135.7 |
| MISSILES NEXT TURN | 13.3 | +114.9 | 0.0 | 0.0 | 4.0 | +35.8 | 0.0 | 135.7 |
| MISSILES ON ONE TARGET | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 50.0 | 0.0 | 3.0 | +0.0 | 0.0 | 13.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -11.7 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.3 | +263.9 | 0.0 | 0.0 | 3.7 | +209.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +258.6 | 0.0 | 49.0 | 4.3 | +206.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +157.7 | 0.0 | 0.0 | 2.7 | +127.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -155.1 | 281.3 | 0.0 | 4.0 | -206.5 | 779.0 | 30.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -254.8 | 13.7 | 0.0 | 3.7 | -138.8 | 0.0 | 151.7 |
| OGRE LOADER SECOND SHOT | 4.0 | +36.0 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -60.8 | 0.0 | 0.0 | 4.3 | -102.8 | 0.0 | 135.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +103.3 | 272.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | +38.6 | 0.0 | 321.0 | 2.0 | +3.2 | 0.0 | 135.7 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +19.9 | 49.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +2.9 | 51.7 | 0.0 | 0.3 | +4.1 | 50.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +22.9 | 0.0 | 0.0 |
| PLAN RESULT | 34.7 | +694.8 | 417.3 | 635.0 | 37.0 | +320.6 | 541.0 | 663.3 |
| PROMISE BY ITS OWN SUM | 7.7 | -245.3 | 0.0 | 0.0 | 6.3 | -164.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -1.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.3 | 38.0 | 0.0 | 0.7 | -4.7 | 0.0 | 0.0 |
| QUARTER ODDS | 16.3 | +1840.5 | 423.3 | 0.0 | 10.7 | +654.5 | 544.0 | 38.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +375.0 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 25.0 |
| REFORMS TO MEET IT | 1.0 | -6.4 | 0.0 | 0.0 | 0.3 | -24.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +16.2 | 0.0 | 50.0 | 0.3 | +2.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +21.7 | 319.3 | 0.0 | 2.0 | -35.5 | 235.0 | 30.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -2.1 | 49.0 | 0.0 |
| RUN DOWN | 2.3 | -30.3 | 417.0 | 0.0 | 3.7 | -47.5 | 779.0 | 30.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.0 | 0.0 | 0.0 | 1.3 | +62.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +9.5 | 13.7 | 0.0 | 0.3 | +1.1 | 0.0 | 30.0 |
| SET CREDITED ONCE | 2.7 | -768.1 | 0.0 | 0.0 | 1.3 | -12.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +746.6 | 0.0 | 0.0 | 2.7 | +75.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.0 | +0.0 | 0.0 | 165.0 | 6.0 | +0.0 | 0.0 | 37.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +32.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -32.3 | 210.7 | 0.0 | 0.7 | -8.3 | 0.0 | 30.0 |
| SHOT RISK POINTS | 20.0 | -189.7 | 0.0 | 445.0 | 33.3 | -255.7 | 0.0 | 454.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +575.6 | 0.0 | 319.0 | 15.0 | +597.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +11.3 | 0.0 | 0.0 | 3.0 | +25.2 | 0.0 | 117.0 |
| SPELLS IN THE FIGHT | 0.3 | +10.9 | 83.7 | 0.0 | 0.3 | -21.7 | 0.0 | 30.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 186.0 | 6.7 | +0.0 | 0.0 | 334.3 |
| STAND AND SHOOT | 0.3 | -4.0 | 83.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 0.0 | 83.7 |
| STANDS STILL | 39.0 | +0.0 | 643.3 | 540.0 | 29.0 | +0.0 | 411.0 | 157.7 |
| STAY WORTH | 28.0 | +236.5 | 518.0 | 600.0 | 22.0 | +217.2 | 301.0 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +0.7 | 0.0 | 30.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +15.2 | 136.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.7 | +251.6 | 0.0 | 98.0 | 4.0 | +369.6 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.7 | +251.6 | 0.0 | 98.0 | 4.0 | +369.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +11.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 13.7 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 11.3 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 135.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.0 | +0.0 | 0.0 | 450.0 | 37.0 | +0.0 | 0.0 | 281.3 |
| TIED UP BY THE SUM | 1.0 | +110.9 | 62.0 | 0.0 | 1.0 | +127.1 | 99.0 | 0.0 |
| TIME ON OUR SIDE | 25.7 | +389.1 | 11.3 | 50.0 | 11.7 | +155.3 | 0.0 | 30.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 98.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +29.3 | 408.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +2.8 | 136.0 | 0.0 |
| WHO HITS BACK | 0.7 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -210.0 | 0.0 | 408.0 | 2.7 | -185.5 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 2.0 | +331.8 | 0.0 | 281.3 |
| WOUNDS ON THE RANKS | 5.0 | +77.5 | 0.0 | 136.0 | 5.0 | +101.4 | 0.0 | 271.3 |

### Rule changes: wfr-a92c160-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 212 | 212 | 163 | 54.33 | +0 | +0.0 |
| ARMY TABLE | 131 | 131 | 102 | 34.00 | +2853 | +28.0 |
| HIS SHOTS BY HIS RUN | 272 | 248 | 61 | 20.33 | +1523 | +25.0 |
| HIS SHOT LIST | 272 | 249 | 59 | 19.67 | +1501 | +25.4 |
| HIS MOVE WHY | 87 | 87 | 52 | 17.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 48 | 48 | 42 | 14.00 | +2364 | +56.3 |
| HIS ONE MOVE | 101 | 97 | 33 | 11.00 | +0 | +0.0 |
| THE TABLE AGAIN | 34 | 34 | 30 | 10.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| SHOT RISK POINTS | 160 | 142 | 25 | 8.33 | +589 | +23.6 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1181 | -49.2 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| FIVE ACTION | 479 | 450 | 21 | 7.00 | +1318 | +62.8 |
| GOAL WALK | 63 | 59 | 21 | 7.00 | +1254 | +59.7 |
| THE RISK READS HIS RUN | 34 | 34 | 19 | 6.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 17 | 5.67 | -1230 | -72.3 |
| STAY WORTH | 150 | 138 | 17 | 5.67 | +111 | +6.5 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| FOUR ROUNDS | 21 | 19 | 13 | 4.33 | +1364 | +105.0 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +108 | +9.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| SUPPORT ADDS | 26 | 25 | 10 | 3.33 | +224 | +22.4 |
| SUPPORT WORKED OUT | 26 | 25 | 10 | 3.33 | +224 | +22.4 |
| CHARGE LOSSES | 129 | 113 | 9 | 3.00 | +364 | +40.4 |
| MOVE TO CHARGE COMPUTED | 21 | 13 | 9 | 3.00 | +262 | +29.1 |
| SET UP BY THE SET | 16 | 13 | 9 | 3.00 | +1207 | +134.1 |
| SHOTS IN THE MOVE | 83 | 70 | 8 | 2.67 | +94 | +11.7 |
| TIME ON OUR SIDE | 112 | 92 | 8 | 2.67 | +23 | +2.9 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTING BLOCK | 16 | 16 | 7 | 2.33 | +65 | +9.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +215 | +35.8 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +331 | +55.2 |
| NEXT CHARGE BY LIST | 15 | 9 | 6 | 2.00 | +92 | +15.3 |
| QUARTER ODDS | 81 | 78 | 6 | 2.00 | +371 | +61.9 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 6 | 2.00 | +23 | +3.8 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 7 | 7 | 5 | 1.67 | +17 | +3.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +651 | +130.2 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH CHECK | 8 | 8 | 5 | 1.67 | +135 | +27.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 5 | 1.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +164 | +32.8 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +266 | +66.4 |
| COVER ONCE | 45 | 36 | 4 | 1.33 | +187 | +46.8 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 6 | 4 | 1.33 | +268 | +66.9 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -568 | -141.9 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +55 | +13.8 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +196 | +49.1 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 3 | 3 | 3 | 1.00 | +38 | +12.8 |
| FALLS SHORT | 71 | 63 | 3 | 1.00 | +47 | +15.5 |
| MISSILES NEXT TURN | 52 | 34 | 3 | 1.00 | +2 | +0.7 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -15 | -4.9 |
| RISK BY ARC | 13 | 11 | 3 | 1.00 | +79 | +26.4 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 30 | 29 | 3 | 1.00 | +97 | +32.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +420 | +210.2 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +10 | +4.9 |
| GUN MASK | 7 | 7 | 2 | 0.67 | +78 | +39.2 |
| HIS MOVE AND SHOT | 46 | 41 | 2 | 0.67 | +2 | +1.2 |
| IDLE COST | 38 | 24 | 2 | 0.67 | +45 | +22.5 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +35 | +17.6 |
| MAX FOR POSITIONING | 24 | 23 | 2 | 0.67 | +5 | +2.3 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +145 | +72.5 |
| ONE OBJECTIVE FORMULA | 25 | 23 | 2 | 0.67 | +14 | +6.8 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +32 | +15.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +69 | +34.4 |
| REDIRECT COUNTER | 10 | 10 | 2 | 0.67 | +170 | +85.2 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -30 | -15.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +32 | +15.9 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +46 | +22.8 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +16 | +8.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| CANNON PLANNED TARGET | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +101 | +101.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -1 | -1.2 |
| EXACT ROUND | 13 | 11 | 1 | 0.33 | +12 | +11.7 |
| ROUNDS AFTER TERROR | 3 | 3 | 1 | 0.33 | +4 | +3.7 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +19 | +18.6 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +34 | +34.0 |
| WAR ENGINE JOBS | 2 | 2 | 1 | 0.33 | -3 | -3.1 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| WHOLE FIGHT DANGER | 18 | 16 | 1 | 0.33 | +231 | +230.6 |
| WHOLE FIGHT REACTION | 6 | 6 | 1 | 0.33 | +5 | +4.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 36 | 34 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 20 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 19 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 70 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 34 | 34 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 14 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 15 | 14 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 34 | 26 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEARER NOT NEEDED | 31 | 30 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 215 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 9 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 51 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 32 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 204 | 192 | 0 | 0.00 | - | - |
| STOPS | 1 | not checked | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 16 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 213 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 2.33 | 72.3 |
| JOB FIRST | gate | 3.33 | 1.67 | 26.3 |
| ARMY TABLE | rule | 0.67 | 2.67 | 76.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.67 | 20.9 |
| NO REASON | gate | - | 2.00 | 43.9 |
| MARCH OF THE TABLE | rule | 1.33 | - | 141.9 |
| PROMISE SHOT AWAY | rule | 0.33 | 0.67 | 4.9 |
| RULE SWITCHED OFF | gate | 1.00 | - | 174.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 72.7 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 15.1 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 1.2 |
| WAR ENGINE JOBS | rule | - | 0.33 | 3.1 |

### Plans: wfr-a92c160-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 279 | 410 | 147% |
| Mine | move | 21.3 | 97% | 1538 | 0 | 0% |
| Mine | shoot | 11.0 | 30% | 582 | 285 | 49% |
| Opponent | charge | 2.0 | 33% | 93 | 148 | 159% |
| Opponent | move | 28.3 | 95% | 1187 | 0 | 0% |
| Opponent | shoot | 6.7 | 25% | 425 | 173 | 41% |

### Packages: hunt the guns, wfr-a92c160-p19

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 410 | 0 | 0% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 410 | 0 | 0% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: wfr-a92c160-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 57 (12) | 57 | 0 | 13 | 17% | 2.7 | - | 84 (5) | 46 (4) | 103 (4) | 51 (5) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 55 | 25% | 2.3 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Holder | 5 | 44 (5) | 0 | 44 | 0 | 60% | 2.0 | - | 73 (3) | 0 (2) | 50 (3) | 35 (2) |
| Mine | Shooter | 2 | 330 (2) | 0 | 330 | 76 | 0% | 1.0 | 247 (1) | 412 (1) | - | 330 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 33 | 0% | 1.5 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 38 (6) | 0 | 38 | 56 | 33% | 3.0 | 0 (5) | 250 (1) | - | 53 (5) | 0 (1) |
| Opponent | Character | 7 | 8 (7) | 8 | 0 | 12 | 0% | 3.3 | 72 (1) | 0 (5) | - | 14 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 36 | 0% | 3.7 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 78 (4) | 62 | 16 | 36 | 0% | 3.2 | - | 18 (3) | 559 (1) | 18 (3) | 559 (1) |
| Opponent | Hammer | 8 | 45 (8) | 26 | 20 | 16 | 38% | 2.4 | 0 (2) | 55 (2) | 64 (4) | 72 (5) | 0 (3) |
| Opponent | Holder | 1 | 135 (1) | 0 | 135 | 100 | 0% | 1.0 | - | 135 (1) | - | 135 (1) | - |
| Opponent | Shooter | 2 | 12 (2) | 0 | 12 | 0 | 0% | 1.5 | 21 (1) | 0 (1) | - | 12 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: wfr-a92c160-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 172 | 290 | 2.0 | 1.2 | 145 | 0 | +145 | 4 of 6 | 4 of 6 | +758 | +22 |
| Opponent | Ogre Kingdoms | 1 | 165 | 392 | 5.0 | 1.0 | 78 | 33 | +46 | 2 of 5 | 3 of 5 | - | +46 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 704 | 4.0 | 1.8 | 176 | 28 | +148 | 4 of 4 | 2 of 4 | +704 | -38 |
| **Opponent** | all armies | 3 | 55 | 365 | 3.0 | 1.3 | 122 | 31 | +91 | 6 of 9 | 5 of 9 | +704 | +14 |

### Effective charges: wfr-a92c160-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 2 (net +379) | 0 | 0 | 1 (net +0) | 2 (net +56) | 1 (net +0) | 0 | 0% (0 of 6) |
| Opponent | Ogre Kingdoms | 5 | 1 (net +95) | 0 | 0 | 0 | 0 | 2 (net +148) | 2 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 4 | 2 (net +0) | 0 | 0 | 1 (net -114) | 0 | 1 (net +704) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: wfr-a92c160-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 459 | 426 | +379 | 415 | 253 | +162 | +35.3 |
| Mine | 76-89% | 1 | 369 | 251 | +0 | 37 | 0 | +37 | +10.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 233 | 158 | +0 | 170 | 155 | +15 | +6.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 374 | 112 | +56 | 56 | 0 | +56 | +14.8 |
| Mine | All fights | 6 | 378 | 248 | +145 | 191 | 110 | +81 | +21.5 |
| Opponent | Long shot (under 50%) | 3 | 146 | 296 | +32 | 57 | 13 | +44 | +29.9 |
| Opponent | 76-89% | 1 | 499 | 369 | -114 | 158 | 114 | +44 | +8.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 308 | 202 | +334 | 334 | 6 | +328 | +106.5 |
| Opponent | No odds | 2 | 62 | 301 | -82 | 55 | 82 | -27 | -43.5 |
| Opponent | All fights | 9 | 220 | 274 | +91 | 160 | 37 | +123 | +55.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p19 | move | 13 | 2 (15%) | 2 (15%) | 2 (15%) | 9 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

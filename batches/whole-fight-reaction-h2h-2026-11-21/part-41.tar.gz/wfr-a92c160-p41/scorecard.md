# Doctrine scorecard: wfr-a92c160-p41

### Scorecard: wfr-a92c160-p41

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | yes | 3 | 1 | 0 | 2 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 6 | 0 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 416 |
| L0810 | 6 | 1 | Opponent | no | 15 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 573 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 33% | 1.5 | 3.0 | 0.3 | 1.7 | 0.0 | 0.0 | 0.0 | 428.0 |
| **Average** | | | Opponent | 67% | 7.5 | 2.0 | 1.3 | 4.0 | 0.0 | 0.0 | 0.0 | 296.7 |

### KPIs: wfr-a92c160-p41

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (17 of 17) | 0% (0 of 14) | 55% (17 of 31) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (8 of 8); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 100% | 50% (2 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 82% (9 of 11); on the table 100% | 83% (10 of 12); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 25% (9 of 36) | 33% (14 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (5 of 5) | 27% (9 of 33) | 37% (14 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (4 of 8) | 50% (4 of 8) |
| Points that never fought | lower | 62% (3728 of 5999) | 82% (4933 of 5998) | 72% (8661 of 11997) |
|   infantry points that never fought | lower | 62% (597 of 968) | 100% (1113 of 1113) | 82% (1710 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (22 of 30) | 60% (15 of 25) | 67% (37 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.7 uses a game | 50% (1 of 2); 0.3 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 69% (3702 of 5378) | 63% (3285 of 5181) | 66% (6987 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (56%) | 5.0 (54%) |
| MARCHED: its unit marched | 0.0 (0%) | 2.3 (26%) | 2.3 (25%) |
| IN COMBAT: engaged in combat | 0.3 (100%) | 0.3 (4%) | 0.7 (7%) |
| GONE: slain | 0.0 (0%) | 0.7 (7%) | 0.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (7%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 2.0 | 4.0 | 4.7 | 0.7 | 0.3 |
| not cast | 3.3 | 0.0 | 2.0 | 9.3 | 3.3 | 27.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.7 (33%) | 5.0 (54%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 2.3 (25%) | 0.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (20%) | - | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 1.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.7 (7%) | 1.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (80%) | - | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.0 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.0 a game | 2.0 a game |
| stood (cast and not dispelled) | - | 58% (7 of 12) | 58% (7 of 12) |
| the unit moved after it | - | 86% (6 of 7) | 86% (6 of 7) |
| it charged on its next turn | - | 0% (0 of 7) | 0% (0 of 7) |
| the enemy charged it first | - | 0% (0 of 7) | 0% (0 of 7) |
| it fought by the end of its next turn | - | 0% (0 of 7) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 7) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (7 of 7) | 100% (7 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (74 of 93) | 67% (18 of 27) | 77% (92 of 120) |
|   cavalry | 93% (14 of 15) | - | 93% (14 of 15) |
|   chariot | 73% (8 of 11) | 54% (7 of 13) | 62% (15 of 24) |
|   infantry | 67% (8 of 12) | 73% (8 of 11) | 70% (16 of 23) |
|   war machine | 80% (44 of 55) | 100% (3 of 3) | 81% (47 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (16%) | 0.3 (11%) | 1.3 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (11%) | 0.3 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.3 (11%) | 0.7 (7%) |
| MOVED: a war machine that moved | 1.0 (16%) | 0.0 (0%) | 1.0 (11%) |
| NO TARGET IN RANGE | 0.7 (11%) | 1.7 (56%) | 2.3 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (21%) | 0.0 (0%) | 1.3 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (21%) | 0.3 (11%) | 1.7 (18%) |
| OTHER BAR | 0.7 (11%) | 0.0 (0%) | 0.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 3.0 | 77% | 7.6 pts | 76 pts |
| chariot | 5.3 | 1.3 | 88% | 11.9 pts | 63 pts |
| infantry | 5.3 | 2.7 | 62% | 9.7 pts | 52 pts |
| war machine | 16.0 | 14.3 | 60% | 31.2 pts | 500 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 4.3 | 2.7 |
| Charges that made contact a game | 1.0 | 3.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.33 declared, 0.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.09 declared, 0.09 contact (22 units) | 0.55 declared, 0.36 contact (22 units) | 0.32 declared, 0.23 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 33% (1 of 3) | 100% (1 of 1) | 46% (6 of 13) |
| Character in a unit | 86% (6 of 7) | - | - | 86% (6 of 7) |
| Character on its own | 100% (4 of 4) | 50% (1 of 2) | 50% (2 of 4) | 70% (7 of 10) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 62% | 73% (22 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | - | 33% (8 of 24) | 75% | 40% (4 of 10) | 50% (1 of 2); 3.0 uses a game | 100% (1 of 1); 3.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 0% (0 of 6) | 93% | 78% (7 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 82% (9 of 11); on the table 100% | 17% (1 of 6) | 79% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p41, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 0% (0) | 17% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: wfr-a92c160-p41

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 3) | 69% (9 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (15 of 52) | 50% (6 of 12) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (3 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (3 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 45% (5 of 11) | 25% (2 of 8) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 1.7 | 4.0 |
| Movement | Points that never moved of their own | 428.0 | 296.7 |
| Movement | Fights charged into per game | 1.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 6, net +102 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +0 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 4 of 6, net +286 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (9 of 32) | 20% (3 of 15) |
| Shooting | Points destroyed by shooting units | 103.3 | 0.0 |
| Shooting | War machine shots | 14.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (22 of 44) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 286.7 | 43.3 |
| Magic | Magic missiles cast | 1.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 60% (3 of 5) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | - | 8.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 185.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.3 / 0.0 | 3.7 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 48.3 | 159.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +71 | +269 |
| Combat | Net per 100 charger points, damage counted | +25.8 | +125.4 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +67 | +228 |
| Combat | Net points per supported fight / lone fight | - / +67 | +445 / +120 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 3 of 6 |
| Game | Points lost | 695.0 | 553.0 |
| Game | VP from objectives | 543.3 | 846.7 |
| Game | Lone holders (player turns) | 1.5 | 7.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -486 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1248
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p41

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 7.3 | +255.7 | 0.0 | 117.7 | 23.0 | +266.9 | 0.0 | 406.3 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 216.7 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 13.0 | +312.9 | 1135.7 | 41.7 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | 1.3 | +70.3 | 236.7 | 0.0 | 1.7 | +35.0 | 342.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +31.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 37.3 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +21.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.7 | -593.7 | 0.0 | 373.3 | 20.0 | -1485.5 | 0.0 | 881.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 236.7 | 93.7 | 2.3 | +0.0 | 75.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 4.0 | +365.2 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -229.8 | 0.0 | 172.7 | 8.7 | -526.7 | 0.0 | 59.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -6.1 | 41.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +23.3 | 0.0 | 93.7 | 3.7 | -13.5 | 407.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 93.7 | 4.3 | +0.9 | 530.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 26.0 | +333.3 | 0.0 | 313.7 |
| FEATURE BUFFS | - | - | - | - | 2.3 | +27.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | -0.3 | 0.0 | 93.7 | 1.0 | +86.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 54.7 | - | - | - | - |
| FIVE ACTION | 94.3 | +4529.6 | 2256.3 | 1596.3 | 99.3 | +5589.1 | 1344.7 | 1853.7 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 220.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +21.6 | 0.0 | 0.0 | 1.0 | +225.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +70.7 | 0.0 | 93.7 | 4.3 | +381.3 | 530.7 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 70.0 |
| FRIEND SHOOTS FIRST | 1.0 | -84.9 | 96.7 | 0.0 | 0.7 | -15.6 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -8.4 | 84.0 | 0.0 |
| GOAL WALK | 6.3 | +600.2 | 0.0 | 0.0 | 16.0 | +1163.6 | 0.0 | 74.7 |
| GUN FIGURES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +11.3 | 63.0 | 21.7 |
| GUN MASK | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 37.3 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 1.0 | +0.0 | 247.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 373.3 | 9.3 | +0.0 | 0.0 | 140.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 109.3 | - | - | - | - |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 54.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -33.2 | 0.0 | 0.0 | 3.3 | -96.5 | 0.0 | 235.0 |
| HIS MOVE AS HE DECIDES | 48.0 | +17.7 | 601.0 | 0.0 | 31.0 | +7.0 | 988.3 | 0.0 |
| HIS MOVE WHY | 10.7 | +0.0 | 0.0 | 380.3 | 29.0 | +0.0 | 0.0 | 597.7 |
| HIS ONE MOVE | 15.7 | +21.4 | 0.0 | 123.7 | 28.3 | -111.3 | 0.0 | 127.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 247.3 | 9.0 | +0.0 | 0.0 | 193.0 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.3 | +1071.8 | 0.0 | 726.7 | 67.3 | +4586.2 | 0.0 | 1120.3 |
| HIS SHOTS BY HIS RUN | 28.0 | +549.8 | 0.0 | 617.3 | 57.7 | +1930.8 | 0.0 | 1383.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +70.9 | 41.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 0.0 | 26.3 | +0.0 | 0.0 | 74.7 |
| HOLDER ASSIGNMENT | 9.7 | +978.0 | 0.0 | 0.0 | 13.7 | +1106.1 | 0.0 | 37.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -15.0 | 0.0 | 93.7 | 3.7 | -88.0 | 283.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +67.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -212.0 | 0.0 | 360.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | +20.5 | 405.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 0.0 | 240.7 | 2.0 | +0.0 | 138.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +0.9 | 0.0 | 93.7 | 1.7 | +2.7 | 289.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +34.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +30.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +195.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.0 | +48.4 | 0.0 | 0.0 | 4.7 | +91.4 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +70.0 | 0.0 | 0.0 | 7.3 | +138.6 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 1.3 | +32.3 | 0.0 | 0.0 | 11.0 | +159.2 | 0.0 | 360.0 |
| MOVE ORDER | 0.3 | +0.0 | 63.0 | 0.0 | 3.3 | +0.0 | 59.0 | 217.3 |
| MOVE SPELL SPOT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.3 | +211.3 | 0.0 | 0.0 | 3.0 | +437.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +251.6 | 0.0 | 84.0 | 7.7 | +372.8 | 0.0 | 37.3 |
| NEXT CHARGE BY LIST | 3.3 | +304.9 | 236.7 | 0.0 | 1.7 | +172.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -2.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -36.2 | 0.0 | 93.7 | 3.3 | -186.4 | 373.0 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 34.0 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -1.3 | 0.0 | 56.7 | - | - | - | - |
| OFF BEST | 5.7 | -212.8 | 0.0 | 199.3 | 1.0 | -72.3 | 0.0 | 55.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -81.9 | 0.0 | 0.0 | 5.7 | -146.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +26.7 | 34.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -45.7 | 0.0 | 0.0 | 9.3 | +2.4 | 0.0 | 37.3 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +24.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +13.1 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +3.1 | 0.0 | 0.0 | 1.0 | +11.4 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +41.3 | 0.0 | 180.0 |
| PLAN RESULT | 41.7 | +1067.1 | 777.7 | 1064.0 | 48.0 | +513.7 | 172.3 | 911.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.7 | -48.5 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -3.5 | 0.0 | 0.0 | 1.0 | -42.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.7 | +1135.8 | 276.3 | 713.3 | 19.7 | +1973.1 | 405.0 | 326.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +11.9 | 0.0 | 285.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +7.6 | 0.0 | 0.0 | 0.3 | +7.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +12.3 | 48.3 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +12.9 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +12.2 | 0.0 | 93.7 | 3.0 | +26.4 | 159.7 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -10.1 | 0.0 | 0.0 | 1.7 | -26.4 | 331.3 | 0.0 |
| RUN DOWN | 0.7 | -12.0 | 0.0 | 93.7 | 2.3 | -27.8 | 373.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -11.6 | 70.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -198.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +17.8 | 0.0 | 151.3 | 0.3 | +5.4 | 0.0 | 21.7 |
| SET CREDITED ONCE | 4.0 | -168.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 4.0 | +213.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +44.9 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +66.5 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 180.3 | 4.3 | +0.0 | 0.0 | 186.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +37.4 | 55.0 | 168.0 | 1.7 | +21.8 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.6 | 123.7 | 0.0 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 18.3 | +156.0 | 0.0 | 617.3 | 42.3 | -248.6 | 0.0 | 1181.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.7 | +1080.8 | 0.0 | 302.3 | 6.7 | +321.1 | 0.0 | 208.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +44.9 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +1.9 | 0.0 | 0.0 | 5.3 | +83.0 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | +4.7 | 0.0 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 191.0 | 9.7 | +0.0 | 0.0 | 211.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 63.3 | +0.0 | 2256.3 | 885.3 | 25.7 | +0.0 | 814.0 | 733.7 |
| STAY WORTH | 38.0 | +316.0 | 2066.7 | 122.0 | 8.7 | +115.3 | 455.0 | 581.7 |
| SUPPORT ADDS | 2.0 | +65.8 | 0.0 | 109.3 | 5.0 | +202.7 | 0.0 | 37.3 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 34.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +65.8 | 0.0 | 109.3 | 5.0 | +202.7 | 0.0 | 37.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 186.7 | 5.7 | +0.0 | 0.0 | 130.3 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 751.3 | 48.3 | +0.0 | 0.0 | 784.3 |
| TIED UP BY THE SUM | 0.3 | +31.7 | 0.0 | 0.0 | 0.7 | +42.1 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 45.7 | +491.1 | 0.0 | 555.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -2.3 | 0.0 | 0.0 | 2.3 | +92.9 | 207.7 | 0.0 |
| WHO GETS IN | - | - | - | - | 1.7 | +36.1 | 371.0 | 0.0 |
| WHO HITS BACK | 0.3 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -360.3 | 0.0 | 247.3 | 1.3 | -33.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +18.2 | 34.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.7 | +292.7 | 0.0 | 249.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +25.3 | 0.0 | 247.3 | 5.0 | +175.9 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p41

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 237 | 237 | 163 | 54.33 | +0 | +0.0 |
| HIS SHOT LIST | 299 | 295 | 85 | 28.33 | +1970 | +23.2 |
| HIS MOVE WHY | 119 | 119 | 67 | 22.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 70 | 70 | 65 | 21.67 | +4452 | +68.5 |
| HIS SHOTS BY HIS RUN | 257 | 256 | 63 | 21.00 | +1119 | +17.8 |
| ARMY TABLE | 91 | 91 | 58 | 19.33 | +1969 | +33.9 |
| HIS ONE MOVE | 132 | 132 | 39 | 13.00 | +0 | +0.0 |
| SHOT RISK POINTS | 182 | 181 | 31 | 10.33 | +888 | +28.6 |
| TIME ON OUR SIDE | 137 | 124 | 28 | 9.33 | +59 | +2.1 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| FIVE ACTION | 581 | 577 | 20 | 6.67 | +708 | +35.4 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -855 | -42.8 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 19 | 19 | 16 | 5.33 | +635 | +39.7 |
| GOAL WALK | 67 | 67 | 14 | 4.67 | +932 | +66.6 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 15 | 11 | 3.67 | +494 | +44.9 |
| QUARTER ODDS | 115 | 113 | 11 | 3.67 | +496 | +45.1 |
| THE RISK READS HIS RUN | 36 | 36 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 9 | 3.00 | +118 | +13.2 |
| CHARGE LOSSES | 98 | 98 | 9 | 3.00 | +571 | +63.4 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 8 | 2.67 | +22 | +2.8 |
| SUPPORT ADDS | 21 | 21 | 8 | 2.67 | +51 | +6.4 |
| SUPPORT WORKED OUT | 21 | 21 | 8 | 2.67 | +51 | +6.4 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 14 | 14 | 7 | 2.33 | -143 | -20.5 |
| FALLS SHORT | 78 | 68 | 6 | 2.00 | +18 | +2.9 |
| FOUR ROUNDS | 16 | 16 | 6 | 2.00 | +332 | +55.3 |
| IDLE COST | 47 | 44 | 6 | 2.00 | +22 | +3.7 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +62 | +10.3 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SET UP BY THE SET | 13 | 13 | 5 | 1.67 | +185 | +37.0 |
| WHO GETS IN | 5 | 5 | 5 | 1.67 | +108 | +21.7 |
| WOUNDS ON THE RANKS | 24 | 24 | 5 | 1.67 | +184 | +36.9 |
| COVER ONCE | 44 | 34 | 4 | 1.33 | +22 | +5.4 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +742 | +185.5 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +44 | +10.9 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 4 | 1.33 | -146 | -36.4 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 4 | 1.33 | +36 | +9.0 |
| CANNON PLANNED TARGET | 42 | 42 | 3 | 1.00 | +26 | +8.7 |
| FIGHT TO THE END | 4 | 4 | 3 | 1.00 | +215 | +71.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -92 | -30.7 |
| RISK BY ARC | 12 | 12 | 3 | 1.00 | +148 | +49.4 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +70 | +23.3 |
| STAY WORTH | 140 | 123 | 3 | 1.00 | +23 | +7.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 3 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +62 | +31.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 88 | 57 | 2 | 0.67 | +53 | +26.6 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +157 | +78.7 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +64 | +64.0 |
| EXACT ROUND | 14 | 14 | 1 | 0.33 | +25 | +24.6 |
| HIS MOVE AND SHOT | 20 | 20 | 1 | 0.33 | +4 | +4.1 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +1 | +0.8 |
| HUNT IN PAIRS | 3 | 3 | 1 | 0.33 | +25 | +25.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +2 | +2.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +59 | +58.6 |
| MAX FOR POSITIONING | 20 | 19 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 37 | 26 | 1 | 0.33 | +19 | +18.7 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +1 | +0.8 |
| ONE OBJECTIVE FORMULA | 44 | 35 | 1 | 0.33 | +38 | +37.5 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +59 | +58.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +124 | +123.8 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | -17 | -17.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +91 | +90.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +39 | +38.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +22 | +21.7 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +5 | +5.4 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 3 | 1 | 0.33 | +59 | +58.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +14 | +13.7 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +1 | +0.8 |
| WHOLE FIGHT REACTION | 5 | 5 | 1 | 0.33 | +5 | +5.3 |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 84 | 84 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 14 | not checked | - | - | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 5 | 5 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 16 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 125 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 14 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 27 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 44 | 43 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 5 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 12 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 63 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 44 | 42 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 267 | 264 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 271 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p41

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 0.33 | 42.8 |
| CHARGE NOW FIRST | rule | 2.00 | 0.33 | 20.5 |
| ARMY TABLE | rule | 0.67 | 1.33 | 24.2 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | - | 36.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 7.2 |
| MARCH OF THE TABLE | rule | - | 1.00 | 30.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.67 | 55.0 |
| JOINT CHARGE NOW | rule | - | 0.67 | 55.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 16.3 |
| NO REASON | gate | 0.33 | - | 18.1 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 17.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.1 |
| WHO GETS IN | rule | - | 0.33 | 63.2 |

### Plans: wfr-a92c160-p41

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 104 | 43 | 41% |
| Mine | join | 0.7 | 50% | 20 | 0 | 0% |
| Mine | move | 26.0 | 95% | 1144 | 0 | 0% |
| Mine | shoot | 14.0 | 50% | 823 | 1024 | 124% |
| Opponent | charge | 3.3 | 60% | 506 | 226 | 45% |
| Opponent | join | 2.0 | 100% | 62 | 0 | 0% |
| Opponent | move | 38.0 | 95% | 2252 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 207 | 288 | 139% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p41

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p41

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 10 (12) | 10 | 0 | 44 | 67% | 2.8 | 0 (3) | 0 (4) | 18 (4) | 16 (6) | 0 (5) |
| Mine | Fast Hammer | 5 | 26 (5) | 0 | 26 | 48 | 80% | 1.0 | 18 (3) | 0 (1) | 63 (1) | 45 (3) | 0 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 29 | 25% | 2.7 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 72 (5) | 45 | 26 | 77 | 0% | 1.6 | 0 (1) | 62 (2) | 122 (2) | 72 (5) | - |
| Mine | War machine | 11 | 61 (11) | 61 | 0 | 18 | 9% | 1.4 | 43 (5) | 76 (6) | - | 0 (2) | 75 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 24 (11) | 24 | 0 | 22 | 27% | 2.8 | 0 (3) | 34 (5) | 32 (3) | 25 (5) | 23 (6) |
| Opponent | Clean-up | 1 | 73 (1) | 0 | 73 | 0 | 100% | - | - | 73 (1) | - | 73 (1) | - |
| Opponent | Fast Hammer | 6 | 137 (6) | 97 | 39 | 0 | 33% | 1.8 | 157 (3) | 106 (3) | - | 214 (4) | 48 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 39 (4) | 39 | 0 | 69 | 50% | 2.0 | 97 (2) | 0 (1) | 0 (1) | 56 (3) | 0 (1) |
| Opponent | Holder | 4 | 129 (4) | 0 | 129 | 46 | 100% | - | - | 0 (2) | 240 (2) | 168 (3) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: wfr-a92c160-p41

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 390 | 67 | 1.0 | 1.0 | 67 | 0 | +67 | 0 of 3 | 2 of 3 | - | +67 |
| Opponent | Grand Cathay | 1 | 496 | 125 | 1.0 | 1.0 | 125 | 0 | +125 | 0 of 1 | 1 of 1 | - | +125 |
| Opponent | Skaven | 1 | 189 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 1244 | 5.0 | 1.6 | 249 | 0 | +249 | 3 of 5 | 5 of 5 | +445 | +118 |
| **Opponent** | all armies | 3 | 228 | 456 | 2.0 | 1.5 | 228 | 0 | +228 | 3 of 6 | 6 of 6 | +445 | +120 |

### Effective charges: wfr-a92c160-p41

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +125) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 5 | 1 (net +102) | 0 | 0 | 0 | 0 | 4 (net +286) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: wfr-a92c160-p41

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 181 | 145 | +0 | 0 | 45 | -45 | -25.0 |
| Mine | 76-89% | 1 | 265 | 167 | +0 | 111 | 53 | +58 | +22.0 |
| Mine | No odds | 1 | 380 | 145 | +200 | 200 | 0 | +200 | +52.6 |
| Mine | All fights | 3 | 275 | 152 | +67 | 104 | 33 | +71 | +25.8 |
| Opponent | Long shot (under 50%) | 1 | 50 | 102 | +102 | 102 | 0 | +102 | +204.0 |
| Opponent | 76-89% | 1 | 205 | 125 | +125 | 125 | 0 | +125 | +61.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 258 | 241 | +286 | 346 | 0 | +346 | +134.4 |
| Opponent | All fights | 6 | 214 | 198 | +228 | 269 | 0 | +269 | +125.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p41 | move | 19 | 3 (16%) | 2 (11%) | 2 (11%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

# Doctrine scorecard: wfr-a92c160-p14

### Scorecard: wfr-a92c160-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 2 | 1 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 144 |
| L0307 | 1 | 1 | Mine | yes | 5 | - | 0 | 2 | 0 | 0 | 0 | 445 |
| L0307 | 1 | 1 | Opponent | no | 7 | - | 0 | 4 | 0 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 245 |
| **Average** | | | Mine | 33% | 3.5 | 1.0 | 0.7 | 2.3 | 0.3 | 0.0 | 0.0 | 430.0 |
| **Average** | | | Opponent | 33% | 3.5 | 2.5 | 1.7 | 2.3 | 0.0 | 0.0 | 0.0 | 254.7 |

### KPIs: wfr-a92c160-p14

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (3 of 12) | 0% (0 of 16) | 11% (3 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (8 of 8); on the table 100% | 100% (2 of 2); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (8 of 8); on the table 100% | 80% (4 of 5); on the table 80% | 92% (12 of 13); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 17% (6 of 36) | 67% (4 of 6) | 24% (10 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 19% (6 of 32) | 67% (4 of 6) | 26% (10 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 54% (3191 of 5897) | 71% (4253 of 5999) | 63% (7444 of 11896) |
|   infantry points that never fought | lower | 41% (595 of 1437) | 94% (883 of 938) | 62% (1478 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 60% (12 of 20) | 64% (27 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2747 of 4484) | 53% (2453 of 4648) | 57% (5200 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (63%) | 0.0 (0%) | 6.3 (59%) |
| MARCHED: its unit marched | 1.3 (13%) | 0.7 (100%) | 2.0 (19%) |
| GONE: slain | 1.3 (13%) | 0.0 (0%) | 1.3 (12%) |
| STUPIDITY: Stupidity | 1.0 (10%) | 0.0 (0%) | 1.0 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 3.3 | 0.7 | 0.0 |
| not cast | 0.0 | 3.0 | 10.7 | 1.3 | 8.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.3 (59%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.0 (19%) | 0.3 (25%) | 0.0 (0%) |
| GONE: slain | - | 0.7 (22%) | 1.3 (12%) | 0.0 (0%) | 1.7 (21%) |
| STUPIDITY: Stupidity | - | 1.0 (33%) | 1.0 (9%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.7 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | - | 100% (3 of 3) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 33% (1 of 3) | - | 33% (1 of 3) |
| it fought by the end of its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 82% (42 of 51) | 65% (71 of 109) | 71% (113 of 160) |
|   cavalry | - | 91% (10 of 11) | 91% (10 of 11) |
|   character | - | 0% (0 of 20) | 0% (0 of 20) |
|   chariot | 65% (13 of 20) | 67% (4 of 6) | 65% (17 of 26) |
|   infantry | - | 75% (45 of 60) | 75% (45 of 60) |
|   war machine | 94% (29 of 31) | 100% (12 of 12) | 95% (41 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (22%) | 0.3 (3%) | 1.0 (6%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (18%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 0.3 (11%) | 1.0 (8%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.3 (11%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (11%) | 4.3 (34%) | 4.7 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (13%) | 1.7 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (44%) | 2.0 (16%) | 3.3 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.7 | 82% | 7.4 pts | 27 pts |
| chariot | 5.7 | 5.7 | 41% | 23.2 pts | 131 pts |
| infantry | 18.0 | 6.0 | 78% | 4.3 pts | 77 pts |
| war machine | 14.0 | 19.7 | 57% | 45.0 pts | 630 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 3.7 | 2.2 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.37 declared, 0.23 contact (30 units) | 0.26 declared, 0.18 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 40% (2 of 5) | 57% (4 of 7) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 78% (7 of 9) | 100% (2 of 2) | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (6 of 6); on the table 100% | 33% (4 of 12) | 18% | 50% (3 of 6) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 8% (2 of 24) | 71% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Empire of Man | 1 | - | 67% (4 of 6) | 100% | 80% (8 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 80% | - | 56% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 0% (0) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | - | 40% (4 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 57% (25 of 44) | 63% (26 of 41) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 83% (5 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 430.0 | 254.7 |
| Movement | Fights charged into per game | 0.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 2 of 6, net +120 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 2 of 6, net +26 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 6, net +81 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 20.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (5 of 13) | 27% (17 of 62) |
| Shooting | Points destroyed by shooting units | 150.0 | 93.3 |
| Shooting | War machine shots | 9.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (6 of 29) | 75% (9 of 12) |
| Shooting | Points destroyed by war machines | 41.7 | 65.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 24.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.7 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 212.7 | 371.3 |
| Combat | Points run down | 0.0 | 27.0 |
| Combat | Net points per charged fight, damage counted | +64 | +123 |
| Combat | Net per 100 charger points, damage counted | +89.6 | +35.5 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +64 | +98 |
| Combat | Net points per supported fight / lone fight | - / +64 | - / +98 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 3 of 7 |
| Game | Points lost | 696.7 | 395.0 |
| Game | VP from objectives | 386.7 | 876.7 |
| Game | Lone holders (player turns) | 3.5 | 3.5 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -909 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1092
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: wfr-a92c160-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +3.4 | 0.0 | 0.0 |
| ARMY TABLE | 18.7 | +272.7 | 0.0 | 204.7 | 25.7 | +625.4 | 0.0 | 22.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 120.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 46.7 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +18.9 | 85.0 | 276.7 | 4.0 | +87.2 | 111.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 1.7 | +11.7 | 130.0 | 0.0 | 0.7 | +8.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +49.6 | 0.0 | 54.0 | 0.3 | +2.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.3 | -893.8 | 0.0 | 74.0 | 17.7 | -443.9 | 0.0 | 256.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.3 | +0.0 | 101.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 17.3 | 10.7 | +0.0 | 0.0 | 65.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 160.0 | 1.3 | +0.0 | 56.7 | 170.3 |
| CONVEYANCE SEARCH | 1.0 | +273.5 | 0.0 | 73.3 | - | - | - | - |
| COVER ONCE | 9.3 | -624.3 | 0.0 | 140.0 | 6.3 | -188.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +0.6 | 24.0 | 0.0 | 2.3 | -8.4 | 177.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 24.0 | 0.0 | 3.0 | +3.7 | 290.3 | 0.0 |
| FALLS SHORT | 8.0 | +160.6 | 0.0 | 130.3 | 16.7 | +135.6 | 0.0 | 174.0 |
| FEATURE BUFFS | 6.3 | +130.8 | 0.0 | 0.0 | 3.0 | +80.8 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +72.4 | 206.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 86.0 | +3047.0 | 513.0 | 1560.0 | 109.0 | +7508.8 | 1286.3 | 474.0 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 204.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +116.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.7 | +17.9 | 24.0 | 0.0 | 3.7 | +277.0 | 307.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 34.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -15.7 | 0.0 | 0.0 | 1.3 | -37.5 | 0.0 | 130.0 |
| GIVES UP | 0.3 | -1.1 | 24.0 | 0.0 | 0.7 | -7.7 | 103.3 | 0.0 |
| GOAL WALK | 13.3 | +780.5 | 0.0 | 34.7 | 19.3 | +2444.5 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +69.7 | 172.0 | 103.3 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 34.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 16.0 | +0.0 | 0.0 | 74.0 | 5.0 | +0.0 | 0.0 | 126.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 185.7 | 5.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 2.3 | -5.9 | 0.0 | 102.3 | 3.0 | -96.6 | 0.0 | 44.0 |
| HIS MOVE AS HE DECIDES | 49.7 | +14.3 | 488.7 | 0.0 | 34.0 | +10.3 | 625.3 | 0.0 |
| HIS MOVE WHY | 26.3 | +0.0 | 0.0 | 231.7 | 20.3 | +0.0 | 0.0 | 174.0 |
| HIS ONE MOVE | 18.3 | -50.0 | 0.0 | 56.7 | 23.7 | +22.3 | 56.7 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 185.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.0 | +1127.9 | 0.0 | 593.3 | 64.7 | +1907.0 | 0.0 | 474.0 |
| HIS SHOTS BY HIS RUN | 41.0 | +529.8 | 0.0 | 372.0 | 46.7 | +782.9 | 0.0 | 474.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +24.0 | 130.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 0.0 | 22.3 | +0.0 | 0.0 | 88.0 |
| HOLDER ASSIGNMENT | 8.3 | +786.7 | 0.0 | 0.0 | 13.7 | +1174.5 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -2.3 | 24.0 | 0.0 | 3.0 | -155.9 | 307.7 | 0.0 |
| IDLE COST | 10.0 | -61.7 | 0.0 | 251.3 | 15.0 | -216.2 | 0.0 | 150.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +122.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.7 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 188.7 | 120.7 | 10.3 | +0.0 | 578.3 | 804.3 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 0.0 | 0.0 | 1.7 | +2.3 | 27.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +8.1 | 0.0 | 65.0 |
| MANOEUVRE | 2.3 | -7.3 | 0.0 | 27.0 | 2.0 | +9.0 | 0.0 | 65.0 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.3 | 0.0 | 0.0 | 0.3 | +5.9 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +32.8 | 0.0 | 27.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -1.1 | 0.0 | 0.0 | 0.7 | -4.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +33.4 | 0.0 | 83.7 | 3.7 | +48.1 | 0.0 | 87.0 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +53.5 | 0.0 | 54.0 | 1.3 | +16.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.3 | +74.4 | 0.0 | 110.7 | 1.7 | +33.3 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +117.4 | 0.0 | 28.3 | 5.7 | +419.2 | 0.0 | 195.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +394.2 | 0.0 | 0.0 | 10.0 | +413.3 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 1.7 | +78.3 | 0.0 | 28.3 | 2.0 | +152.6 | 0.0 | 65.0 |
| NO DOUBLE ROUNDS | 0.7 | -6.8 | 24.0 | 0.0 | 3.7 | -191.6 | 307.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -96.7 | 24.0 | 81.0 | 5.3 | -128.1 | 0.0 | 87.0 |
| OGRE LOADER SECOND SHOT | 2.7 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 27.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -17.7 | 0.0 | 187.0 | 7.3 | -156.1 | 0.0 | 65.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +58.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -6.2 | 0.0 | 0.0 | 5.3 | +47.8 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +24.2 | 44.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| PLAN RESULT | 39.7 | +337.1 | 233.0 | 1015.3 | 48.0 | +545.3 | 655.0 | 488.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -34.6 | 0.0 | 0.0 | 10.3 | -346.4 | 0.0 | 130.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -22.5 | 0.0 | 65.0 |
| QUARTER ODDS | 11.7 | +822.5 | 126.0 | 0.0 | 19.3 | +1556.9 | 103.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +6.5 | 0.0 | 54.0 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +51.9 | 0.0 | 110.7 | 1.7 | +20.1 | 0.0 | 22.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +17.9 | 0.0 | 82.3 | 3.7 | +0.0 | 0.0 | 44.0 |
| REFORMS TO MEET IT | 0.3 | -6.5 | 0.0 | 0.0 | 1.7 | -12.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +19.9 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +16.1 | 24.0 | 0.0 | 3.0 | -24.8 | 307.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | +19.5 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 2.3 | -9.3 | 44.3 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 48.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 48.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -74.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +29.9 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +16.0 | 24.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -18.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -5.9 | 0.0 | 28.3 | 2.3 | -135.5 | 103.3 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 2.3 | +9.9 | 0.0 | 65.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.3 | +0.0 | 0.0 | 453.7 | 13.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +198.5 | 63.0 | 0.0 | 1.3 | +7.1 | 56.7 | 0.0 |
| SHOT RISK POINTS | 27.0 | -323.8 | 0.0 | 187.3 | 28.3 | -227.4 | 0.0 | 452.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +384.0 | 0.0 | 576.7 | 25.7 | +451.6 | 0.0 | 44.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 198.3 | 7.3 | +0.0 | 0.0 | 83.3 |
| STAND AND SHOOT | 0.3 | -0.3 | 24.0 | 0.0 | 0.7 | -8.4 | 206.7 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 130.0 | 54.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 42.7 | +0.0 | 489.0 | 1003.3 | 42.7 | +0.0 | 978.7 | 0.0 |
| STAY WORTH | 29.3 | -432.8 | 426.0 | 1073.3 | 38.3 | +395.2 | 585.3 | 22.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +24.8 | 0.0 | 170.3 |
| SUPPORT ADDS | 9.3 | +1313.6 | 0.0 | 85.0 | 2.0 | +37.7 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 9.3 | +1313.6 | 0.0 | 85.0 | 2.0 | +37.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -30.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 131.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 103.3 | 3.0 | +0.0 | 0.0 | 63.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 0.0 | 65.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 128.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 732.0 | 52.0 | +0.0 | 0.0 | 237.0 |
| TIED UP BY THE SUM | 0.3 | +5.3 | 24.0 | 0.0 | 0.7 | +27.5 | 44.3 | 0.0 |
| TIME ON OUR SIDE | 19.7 | +282.5 | 0.0 | 263.3 | 18.3 | +199.0 | 113.3 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 3.3 | +0.0 | 0.0 | 206.7 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +0.3 | 24.0 | 0.0 | 0.7 | -0.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -509.6 | 0.0 | 56.7 | 0.3 | -18.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +8.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.3 | +179.2 | 0.0 | 0.0 | 1.7 | +152.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 251 | 251 | 177 | 59.00 | +0 | +0.0 |
| ARMY TABLE | 133 | 133 | 88 | 29.33 | +2237 | +25.4 |
| HIS MOVE WHY | 140 | 140 | 81 | 27.00 | +0 | +0.0 |
| HIS SHOT LIST | 344 | 332 | 72 | 24.00 | +863 | +12.0 |
| HOLDER ASSIGNMENT | 66 | 66 | 62 | 20.67 | +4106 | +66.2 |
| HIS ONE MOVE | 126 | 122 | 49 | 16.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 263 | 253 | 48 | 16.00 | +292 | +6.1 |
| LEGAL CHARGES ONLY | 34 | 34 | 34 | 11.33 | +0 | +0.0 |
| SHOT RISK POINTS | 166 | 156 | 34 | 11.33 | +578 | +17.0 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -674 | -21.7 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| GOAL WALK | 98 | 96 | 24 | 8.00 | +1472 | +61.3 |
| FIVE ACTION | 585 | 568 | 21 | 7.00 | +1096 | +52.2 |
| THE RISK READS HIS RUN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 114 | 97 | 20 | 6.67 | +77 | +3.8 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +44 | +2.3 |
| PROMISE BY ITS OWN SUM | 46 | 46 | 16 | 5.33 | -1143 | -71.4 |
| MOVE TO CHARGE COMPUTED | 26 | 21 | 15 | 5.00 | +285 | +19.0 |
| SUPPORT ADDS | 34 | 34 | 13 | 4.33 | +252 | +19.4 |
| SUPPORT WORKED OUT | 34 | 34 | 13 | 4.33 | +252 | +19.4 |
| STAY WORTH | 203 | 186 | 12 | 4.00 | +67 | +5.6 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 39 | 39 | 11 | 3.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 18 | 18 | 11 | 3.67 | +48 | +4.4 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 11 | 3.67 | +146 | +13.2 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| QUARTER ODDS | 93 | 91 | 10 | 3.33 | +539 | +53.9 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +21 | +2.7 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 47 | 37 | 6 | 2.00 | +47 | +7.8 |
| FALLS SHORT | 74 | 64 | 6 | 2.00 | +65 | +10.9 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| NEXT CHARGE BY LIST | 11 | 11 | 6 | 2.00 | +156 | +26.0 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 111 | 104 | 5 | 1.67 | +82 | +16.3 |
| FOUR ROUNDS | 13 | 11 | 5 | 1.67 | +432 | +86.4 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 53 | 50 | 4 | 1.33 | +177 | +44.3 |
| ONE OBJECTIVE FORMULA | 35 | 28 | 4 | 1.33 | +107 | +26.7 |
| SHOTS AFTER THE MOVES | 29 | 29 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +44 | +14.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 75 | 49 | 3 | 1.00 | +16 | +5.3 |
| MANOEUVRE | 13 | 13 | 3 | 1.00 | +48 | +15.8 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +29 | +9.8 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +90 | +29.9 |
| SET UP BY THE SET | 10 | 10 | 3 | 1.00 | +144 | +47.8 |
| THE ROW IN ITS ORDER | 19 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 7 | 7 | 2 | 0.67 | +8 | +4.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -38 | -18.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +350 | +175.2 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +366 | +183.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +101 | +50.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +28 | +13.8 |
| ONE FIGHT FORMULA | 32 | 20 | 2 | 0.67 | +5 | +2.6 |
| REDIRECT COUNTER | 11 | 8 | 2 | 0.67 | +40 | +20.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +60 | +29.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +48 | +24.1 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +74 | +37.1 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +44 | +21.8 |
| WAR ENGINE JOBS | 10 | 10 | 2 | 0.67 | -38 | -19.0 |
| WOUNDS ON THE RANKS | 18 | 17 | 2 | 0.67 | +230 | +114.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +10 | +10.1 |
| FEATURE BUFFS | 28 | 28 | 1 | 0.33 | +4 | +4.0 |
| FIGHT TO THE END | 3 | 3 | 1 | 0.33 | +166 | +165.9 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 17 | 9 | 1 | 0.33 | +7 | +7.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +166 | +165.9 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +3 | +2.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| REFORMS TO MEET IT | 6 | 5 | 1 | 0.33 | +3 | +3.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOTS IN THE MOVE | 122 | 97 | 1 | 0.33 | +107 | +106.6 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 7 | 7 | 1 | 0.33 | +19 | +19.0 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 9 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 29 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 11 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 13 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 11 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 83 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 256 | 253 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 4.33 | 24.3 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 4.33 | 71.4 |
| ARMY TABLE | rule | 1.67 | 1.67 | 28.2 |
| RULE SWITCHED OFF | gate | 1.00 | - | 19.9 |
| CHARGE NOW FIRST | rule | - | 0.67 | 18.8 |
| WAR ENGINE JOBS | rule | 0.67 | - | 19.0 |
| AFTERMATH BAND | gate | - | 0.33 | 4.6 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.2 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 1.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 23.4 |
| NO REASON | gate | - | 0.33 | 2.3 |

### Plans: wfr-a92c160-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 30 | 24 | 79% |
| Mine | move | 25.3 | 92% | 1705 | 0 | 0% |
| Mine | shoot | 13.0 | 36% | 280 | 313 | 112% |
| Mine | support | 0.7 | 100% | 9 | 0 | 0% |
| Opponent | charge | 2.7 | 75% | 289 | 292 | 101% |
| Opponent | move | 34.3 | 97% | 2287 | 0 | 0% |
| Opponent | shoot | 11.0 | 48% | 525 | 254 | 48% |

### Battle groups: wfr-a92c160-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 54 (7) | 54 | 0 | 20 | 29% | 2.8 | 0 (1) | 0 (1) | 89 (4) | 79 (5) | 0 (1) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 39 (5) | 39 | 0 | 84 | 60% | 2.5 | - | 81 (3) | 0 (2) | 46 (4) | 0 (1) |
| Mine | Hammer | 9 | 34 (9) | 19 | 15 | 36 | 11% | 2.6 | 0 (1) | 24 (4) | 56 (4) | 31 (7) | 42 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 52 | 0% | 1.1 | 0 (2) | 20 (5) | 0 (1) | 0 (3) | 17 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 20 | 80% | 3.0 | 0 (1) | 0 (2) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Chaff | 5 | 48 (5) | 48 | 0 | 60 | 20% | 1.2 | 231 (1) | 0 (4) | - | 48 (5) | - |
| Opponent | Character | 8 | 43 (8) | 43 | 0 | 21 | 50% | 2.2 | 68 (3) | 34 (2) | 23 (3) | 54 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 0 | 75% | 5.0 | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 4 (6) | 4 | 0 | 33 | 83% | 4.0 | 0 (3) | 9 (3) | - | 14 (2) | 0 (4) |
| Opponent | Holder | 9 | 26 (9) | 0 | 26 | 9 | 0% | 2.0 | 0 (3) | 45 (4) | 23 (2) | 57 (4) | 0 (5) |
| Opponent | Shooter | 2 | 139 (2) | 55 | 85 | 0 | 0% | 1.5 | 59 (1) | 226 (1) | - | 59 (1) | 226 (1) |
| Opponent | War machine | 3 | 52 (3) | 52 | 0 | 33 | 33% | 1.0 | 52 (3) | - | - | 0 (2) | 156 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: wfr-a92c160-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 127 | 1.0 | 1.0 | 127 | 0 | +127 | 0 of 1 | 1 of 1 | - | +127 |
| Mine | Chaos Dwarfs | 2 | 288 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 216 | 42 | 0.7 | 1.0 | 64 | 0 | +64 | 0 of 2 | 2 of 2 | - | +64 |
| Opponent | Empire of Man | 1 | 195 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 2 | 140 | 598 | 3.5 | 1.0 | 171 | 73 | +98 | 3 of 7 | 6 of 7 | - | +98 |
| **Opponent** | all armies | 3 | 158 | 398 | 2.3 | 1.0 | 171 | 73 | +98 | 3 of 7 | 6 of 7 | - | +98 |

### Effective charges: wfr-a92c160-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Tomb Kings of Khemri | 7 | 2 (net +120) | 0 | 0 | 1 (net +0) | 2 (net +26) | 1 (net +81) | 1 | 0% (0 of 6) |

### Charged fights, damage counted: wfr-a92c160-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 2 | 72 | 71 | +64 | 87 | 23 | +64 | +89.6 |
| Mine | All fights | 2 | 72 | 71 | +64 | 87 | 23 | +64 | +89.6 |
| Opponent | Long shot (under 50%) | 2 | 426 | 291 | +120 | 412 | 256 | +157 | +36.8 |
| Opponent | 76-89% | 1 | 431 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 72 | 81 | +81 | 145 | 29 | +116 | +160.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 313 | 68 | +26 | 47 | 16 | +31 | +9.8 |
| Opponent | No odds | 1 | 440 | 310 | +310 | 467 | 98 | +369 | +83.9 |
| Opponent | All fights | 7 | 346 | 183 | +98 | 219 | 96 | +123 | +35.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p14 | move | 18 | 4 (22%) | 4 (22%) | 0 (0%) | 14 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

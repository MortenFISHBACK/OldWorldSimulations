# Doctrine scorecard: wfr-a92c160-p8

### Scorecard: wfr-a92c160-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 110 |
| L1431 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 67% | 5.0 | 3.0 | 2.0 | 1.7 | 0.3 | 0.0 | 0.0 | 152.3 |
| **Average** | | | Opponent | 33% | 1.0 | 2.0 | 1.3 | 3.3 | 0.3 | 0.0 | 0.0 | 93.3 |

### KPIs: wfr-a92c160-p8

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 13) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 50% (1 of 2); on the table 50% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 17% (3 of 18) | 58% (14 of 24) | 40% (17 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (3 of 12) | 67% (14 of 21) | 52% (17 of 33) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (5 of 10) | 50% (5 of 10) |
| Points that never fought | lower | 49% (2945 of 6000) | 42% (2532 of 6000) | 46% (5477 of 12000) |
|   infantry points that never fought | lower | 88% (1153 of 1315) | 73% (671 of 921) | 82% (1824 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (15 of 25) | 75% (24 of 32) | 68% (39 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 50% (1 of 2); 1.3 uses a game | 75% (3 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 20% (2 of 10); 1.0 uses a game | 0.0 uses a game | 20% (2 of 10); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3367 of 5720) | 66% (3819 of 5830) | 62% (7186 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (27%) | 1.3 (40%) | 2.7 (32%) |
| MARCHED: its unit marched | 1.0 (20%) | 1.0 (30%) | 2.0 (24%) |
| CHARGED: its unit charged | 0.7 (13%) | 0.0 (0%) | 0.7 (8%) |
| IN COMBAT: engaged in combat | 0.7 (13%) | 0.7 (20%) | 1.3 (16%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) |
| GONE: slain | 1.3 (27%) | 0.0 (0%) | 1.3 (16%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.0 | 1.7 | 5.7 | 0.3 | 2.3 |
| not cast | 3.3 | 3.0 | 4.3 | 8.3 | 1.7 | 21.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 0.0 (0%) | 2.7 (32%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (24%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.7 (40%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 1.3 (16%) | 0.3 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (40%) | 0.0 (0%) | 1.3 (31%) | 1.3 (16%) | 0.0 (0%) | 3.0 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (60%) | 0.0 (0%) | 2.7 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 50% (2 of 4) | - | 50% (2 of 4) |
| the unit moved after it | 50% (1 of 2) | - | 50% (1 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 50% (1 of 2) | - | 50% (1 of 2) |
| it fought by the end of its next turn | 50% (1 of 2) | - | 50% (1 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | - | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (60 of 94) | 61% (19 of 31) | 63% (79 of 125) |
|   cavalry | 33% (4 of 12) | 65% (11 of 17) | 52% (15 of 29) |
|   character | 32% (10 of 31) | 20% (1 of 5) | 31% (11 of 36) |
|   infantry | 89% (24 of 27) | 78% (7 of 9) | 86% (31 of 36) |
|   war machine | 92% (22 of 24) | - | 92% (22 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (29%) | 1.7 (42%) | 5.0 (33%) |
| CHARGED: it charged | 3.0 (26%) | 1.3 (33%) | 4.3 (28%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (17%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 4.0 (35%) | 0.0 (0%) | 4.0 (26%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 0.7 | 91% | 2.6 pts | 20 pts |
| character | 6.0 | 1.0 | 89% | 8.7 pts | 52 pts |
| infantry | 20.3 | 5.0 | 82% | 9.3 pts | 190 pts |
| war machine | 7.3 | 2.7 | 82% | 8.3 pts | 61 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 3.0 | 3.2 |
| Charges that made contact a game | 2.3 | 1.7 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.23 contact (22 units) | 0.39 declared, 0.22 contact (23 units) | 0.33 declared, 0.22 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (10 of 15) | 50% (1 of 2) | - | 65% (11 of 17) |
| Character in a unit | 33% (1 of 3) | 50% (1 of 2) | - | 40% (2 of 5) |
| Character on its own | 100% (4 of 4) | 75% (3 of 4) | 43% (3 of 7) | 67% (10 of 15) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 75% (3 of 4); on the table 75% | 17% (3 of 18) | 49% | 60% (15 of 25) | 100% (2 of 2); 2.7 uses a game | 20% (2 of 10); 1.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 83% (10 of 12) | 33% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | - | 67% (4 of 6) | 48% | 92% (11 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 46% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 67% (2) | 83% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.33 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (20 of 37) | 8% (1 of 12) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | - | 80% (4 of 5) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.7 | 3.3 |
| Movement | Points that never moved of their own | 152.3 | 93.3 |
| Movement | Fights charged into per game | 2.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net -400 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 1 of 4, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 6, net +114 | 2 of 4, net +221 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.3 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (23 of 40) | 80% (16 of 20) |
| Shooting | Points destroyed by shooting units | 122.0 | 133.3 |
| Shooting | War machine shots | 7.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 82% (18 of 22) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 33% (2 of 6) |
| Magic | Wounds caused by magic missiles | 3.0 | 0.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 41.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 1.0 / 0.0 | 2.0 / 0.7 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 98.7 | 254.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +74 | +194 |
| Combat | Net per 100 charger points, damage counted | +22.8 | +49.7 |
| Combat | First round won (charged fights) | 86% | 80% |
| Combat | Net points per charged fight | +50 | +135 |
| Combat | Net points per supported fight / lone fight | - / +50 | - / +135 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 3 of 5 |
| Game | Points lost | 606.3 | 583.3 |
| Game | VP from objectives | 750.0 | 410.0 |
| Game | Lone holders (player turns) | 5.0 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +357 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1190
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 27.7 | +344.2 | 0.0 | 1021.0 | 19.3 | +215.9 | 0.0 | 132.0 |
| ASSAILMENT BY POINTS | 0.7 | +3.6 | 0.0 | 133.3 | 0.3 | +2.7 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.7 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -3.7 | 56.7 | 0.0 | 0.3 | -20.8 | 23.3 | 0.0 |
| CANNON PLANNED TARGET | 7.3 | +67.0 | 36.7 | 23.3 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 1.7 | +21.9 | 133.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 266.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +21.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +30.9 | 0.0 | 54.0 | 0.3 | +8.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.7 | -766.6 | 0.0 | 882.0 | 16.7 | -1035.2 | 0.0 | 660.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 103.7 | 0.0 | 1.3 | +0.0 | 547.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 294.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +132.7 | 400.0 | 400.0 | - | - | - | - |
| COVER ONCE | 10.7 | -581.8 | 0.0 | 299.3 | 7.0 | -392.3 | 0.0 | 67.0 |
| DENIED BY THE FIGHT | 0.3 | -4.3 | 36.7 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +117.1 | 67.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 5.0 | +790.1 | 156.7 | 41.7 |
| EXACT ROUND | 1.3 | +8.4 | 42.0 | 0.0 | 1.7 | +15.1 | 304.0 | 0.0 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +89.2 | 78.7 | 133.3 | 0.7 | +0.0 | 147.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.3 | +310.0 | 0.0 | 251.3 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 99.7 | +5937.7 | 881.7 | 2229.3 | 71.7 | +4939.0 | 1237.3 | 827.3 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 342.3 | 6.0 | +0.0 | 0.0 | 105.7 |
| FOLLOW UP WEIGHED | 1.0 | +290.0 | 0.0 | 0.0 | 0.7 | +120.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +333.4 | 145.7 | 133.3 | 2.0 | +204.8 | 304.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 6.3 | +265.6 | 0.0 | 0.0 | 5.3 | +201.0 | 0.0 | 0.0 |
| GUN MASK | 2.3 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 75.3 |
| HE REFORMS ONCE FREED | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 748.7 | 12.0 | +0.0 | 0.0 | 447.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +33.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 38.7 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 67.0 |
| HIS MOVE AND SHOT | 4.0 | -88.3 | 0.0 | 414.0 | 3.3 | -18.9 | 0.0 | 60.0 |
| HIS MOVE AS HE DECIDES | 38.7 | +9.7 | 346.3 | 0.0 | 41.3 | +13.0 | 1099.3 | 0.0 |
| HIS MOVE WHY | 26.0 | +0.0 | 0.0 | 756.0 | 8.3 | +0.0 | 0.0 | 248.0 |
| HIS ONE MOVE | 21.3 | +57.2 | 0.0 | 133.3 | 24.3 | +119.5 | 0.0 | 83.3 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 166.7 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.3 | +0.0 | 0.0 | 196.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 100.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +1454.9 | 0.0 | 1700.7 | 43.0 | +949.5 | 0.0 | 452.7 |
| HIS SHOTS BY HIS RUN | 38.0 | +960.2 | 0.0 | 1331.3 | 51.3 | +1110.8 | 0.0 | 754.0 |
| HIS TURN DENIED | 0.7 | +9.9 | 78.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 134.0 |
| HOLDER ASSIGNMENT | 10.0 | +866.7 | 0.0 | 0.0 | 4.7 | +386.3 | 0.0 | 67.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -89.2 | 145.7 | 0.0 | 2.0 | -80.2 | 304.0 | 0.0 |
| IDLE COST | - | - | - | - | 8.7 | -108.8 | 0.0 | 253.0 |
| JOINT CHARGE NOW | 0.7 | +72.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 56.7 | 0.0 | 5.3 | +0.0 | 231.3 | 256.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +6.4 | 67.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -4.7 | 0.0 | 133.3 | 0.7 | +2.3 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -133.2 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +0.5 | 0.0 | 133.3 | - | - | - | - |
| MANOEUVRE | 1.7 | +2.8 | 0.0 | 50.3 | 0.3 | +5.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +30.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.0 | +100.7 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +31.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +10.5 | 0.0 | 0.0 | 0.3 | +21.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +16.4 | 0.0 | 0.0 | 1.3 | -39.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +2.6 | 0.0 | 133.3 | 2.3 | +198.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +63.5 | 0.0 | 374.7 | 5.7 | +183.8 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 6.0 | +42.4 | 0.0 | 508.0 | 6.0 | +123.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 266.7 | 1.7 | +0.0 | 18.3 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +680.1 | 0.0 | 0.0 | 5.7 | +567.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +322.2 | 0.0 | 151.0 | 7.7 | +306.6 | 0.0 | 103.7 |
| NEXT CHARGE BY LIST | 4.3 | +236.2 | 0.0 | 0.0 | 4.7 | +538.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.0 | -103.8 | 145.7 | 0.0 | 1.3 | -143.6 | 304.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +8.6 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -141.6 | 0.0 | 23.3 | 5.0 | -275.3 | 0.0 | 158.0 |
| ONE CHALLENGE TEST | 0.3 | -17.8 | 0.0 | 133.3 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -129.7 | 0.0 | 0.0 | 6.3 | -111.6 | 0.0 | 67.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +34.3 | 0.0 | 0.0 | 1.3 | -49.2 | 0.0 | 67.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.7 | +10.1 | 36.7 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +13.5 | 0.0 | 0.0 | 0.7 | +27.8 | 23.3 | 0.0 |
| OVERRUNS AWAY | 1.3 | +7.8 | 145.7 | 0.0 | 0.3 | +0.3 | 133.3 | 0.0 |
| PLAN RESULT | 44.3 | +665.5 | 250.0 | 1279.3 | 36.7 | +749.8 | 649.0 | 611.3 |
| PROMISE BY ITS OWN SUM | 11.3 | -459.8 | 0.0 | 0.0 | 6.7 | -61.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -5.0 | 73.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.0 | +2816.9 | 370.0 | 46.7 | 19.7 | +2451.9 | 23.3 | 166.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +42.6 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +6.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +96.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +38.2 | 0.0 | 18.3 |
| REDIRECT WEIGHED | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -97.0 | 0.0 | 0.0 | 1.3 | -7.2 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +25.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | -54.4 | 145.7 | 133.3 | 1.0 | -40.0 | 280.7 | 0.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -11.9 | 67.0 | 0.0 | 0.3 | -6.7 | 23.3 | 0.0 |
| RUN DOWN | 2.7 | -96.8 | 145.7 | 0.0 | 1.3 | -11.9 | 280.7 | 0.0 |
| SEARCH SPOT | 0.3 | +9.9 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +2.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -74.9 | 0.0 | 266.7 | 0.3 | -7.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +196.2 | 0.0 | 266.7 | 1.3 | +4.6 | 67.0 | 77.3 |
| SET UP TOGETHER | 0.3 | +0.5 | 0.0 | 133.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.3 | +0.0 | 0.0 | 46.7 | 4.7 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +85.7 | 0.0 | 0.0 | 0.7 | +9.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -9.4 | 42.0 | 0.0 | 0.7 | -9.3 | 133.3 | 0.0 |
| SHOT RISK POINTS | 22.0 | -38.1 | 0.0 | 776.0 | 27.0 | -425.8 | 0.0 | 563.3 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.0 | +483.6 | 0.0 | 421.3 | 5.3 | +527.4 | 0.0 | 78.7 |
| SPELL WORTH | 2.3 | +77.7 | 533.3 | 533.3 | 2.0 | +10.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.5 | 42.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 601.3 | 12.0 | +0.0 | 0.0 | 213.7 |
| STAND AND SHOOT | 0.3 | -1.4 | 42.0 | 0.0 | 0.7 | -4.8 | 133.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 133.3 | 0.0 |
| STANDS STILL | 51.0 | +0.0 | 736.0 | 582.7 | 19.7 | +0.0 | 933.3 | 203.3 |
| STAY WORTH | 32.7 | +22.6 | 532.7 | 390.7 | 9.0 | +476.1 | 800.0 | 42.0 |
| STRIKE BY THE ODDS | 0.3 | +2.4 | 0.0 | 133.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +194.5 | 0.0 | 47.7 | 6.3 | +228.7 | 0.0 | 83.3 |
| SUPPORT NARROWED | 1.0 | +0.0 | 103.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +194.5 | 0.0 | 47.7 | 6.3 | +228.7 | 0.0 | 83.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.3 | 0.0 | 42.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 1.0 | -8.8 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 98.0 | 5.0 | +0.0 | 0.0 | 108.7 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 201.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 50.3 | 2.7 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.0 | +0.0 | 0.0 | 1048.0 | 32.7 | +0.0 | 0.0 | 415.0 |
| TIED UP BY THE SUM | 1.7 | +220.4 | 36.7 | 0.0 | 0.3 | +41.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 47.0 | +551.8 | 73.3 | 1433.0 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +8.1 | 0.0 | 0.0 | 0.3 | +4.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -315.7 | 0.0 | 334.7 | 3.7 | -535.9 | 0.0 | 218.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 2.3 | +92.1 | 0.0 | 145.7 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.3 | +129.4 | 0.0 | 134.0 |

### Rule changes: wfr-a92c160-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 240 | 240 | 172 | 57.33 | +0 | +0.0 |
| ARMY TABLE | 141 | 141 | 106 | 35.33 | +2045 | +19.3 |
| HIS MOVE WHY | 103 | 103 | 67 | 22.33 | +0 | +0.0 |
| HIS SHOT LIST | 244 | 230 | 63 | 21.00 | +1480 | +23.5 |
| HIS SHOTS BY HIS RUN | 268 | 254 | 49 | 16.33 | +850 | +17.4 |
| HOLDER ASSIGNMENT | 44 | 44 | 37 | 12.33 | +2830 | +76.5 |
| HIS ONE MOVE | 137 | 132 | 36 | 12.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1250 | -46.3 |
| SHOT RISK POINTS | 147 | 144 | 27 | 9.00 | +558 | +20.7 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| MOVE TO CHARGE COMPUTED | 41 | 34 | 22 | 7.33 | +1269 | +57.7 |
| THE RISK READS HIS RUN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 21 | 7.00 | -1563 | -74.4 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 131 | 129 | 19 | 6.33 | +1629 | +85.8 |
| FIVE ACTION | 514 | 495 | 17 | 5.67 | +766 | +45.0 |
| NEXT CHARGE BY LIST | 27 | 25 | 16 | 5.33 | +1239 | +77.4 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| COVER ONCE | 53 | 39 | 10 | 3.33 | +229 | +22.9 |
| TIME ON OUR SIDE | 141 | 124 | 10 | 3.33 | +58 | +5.8 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 9 | 3.00 | +138 | +15.3 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| STAY WORTH | 125 | 113 | 7 | 2.33 | +225 | +32.1 |
| CHARGE LOSSES | 97 | 94 | 6 | 2.00 | +503 | +83.9 |
| EVASIVE BY THE ODDS | 15 | 15 | 6 | 2.00 | +1200 | +200.0 |
| FOUR ROUNDS | 16 | 16 | 6 | 2.00 | +353 | +58.8 |
| FALLS SHORT | 64 | 52 | 5 | 1.67 | +52 | +10.3 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1232 | +246.4 |
| GOAL WALK | 35 | 35 | 5 | 1.67 | +116 | +23.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +128 | +25.6 |
| SET UP BY THE SET | 11 | 11 | 5 | 1.67 | +473 | +94.6 |
| SUPPORT ADDS | 32 | 29 | 5 | 1.67 | +113 | +22.6 |
| SUPPORT WORKED OUT | 32 | 29 | 5 | 1.67 | +113 | +22.6 |
| TIED UP BY THE SUM | 6 | 6 | 4 | 1.33 | +296 | +73.9 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +19 | +6.3 |
| CANNON PLANNED TARGET | 22 | 22 | 3 | 1.00 | +6 | +2.1 |
| CASTING BLOCK | 5 | 5 | 3 | 1.00 | +13 | +4.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +302 | +100.7 |
| MAX FOR POSITIONING | 9 | 8 | 3 | 1.00 | +25 | +8.4 |
| SHOTS IN THE MOVE | 79 | 56 | 3 | 1.00 | +341 | +113.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -74 | -36.9 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +117 | +58.3 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 26 | 17 | 2 | 0.67 | +1 | +0.7 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +216 | +108.0 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +26 | +13.2 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +60 | +29.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -97 | -48.5 |
| ONE OBJECTIVE FORMULA | 18 | 13 | 2 | 0.67 | +60 | +29.9 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -15 | -7.6 |
| REDIRECT COUNTER | 3 | 2 | 2 | 0.67 | +216 | +107.8 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +40 | +20.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +38 | +19.1 |
| WOUNDS ON THE RANKS | 7 | 7 | 2 | 0.67 | +42 | +20.8 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 7 | 7 | 1 | 0.33 | +5 | +4.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 15 | 15 | 1 | 0.33 | +5 | +4.8 |
| MISSILES IN THE MOVE | 28 | 20 | 1 | 0.33 | +5 | +4.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +17 | +16.5 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +34 | +33.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +76 | +76.0 |
| RISK BY ARC | 11 | 11 | 1 | 0.33 | +7 | +7.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 17 | 16 | 1 | 0.33 | +35 | +35.3 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 3 | 3 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 9 | 9 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 36 | 35 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 9 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 13 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 13 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 15 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 6 | 6 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 46 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 65 | 65 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 36 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 45 | 43 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 13 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 51 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 212 | 205 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 4.33 | 41.6 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 1.67 | 74.4 |
| ARMY TABLE | rule | 3.33 | 2.33 | 55.5 |
| BEST PRIZE | rule | 0.33 | 0.33 | 36.9 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 48.5 |
| NO REASON | gate | - | 0.67 | 105.8 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 7.6 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| SET UP BY THE SET | rule | - | 0.33 | 19.1 |

### Plans: wfr-a92c160-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 75% | 620 | 249 | 40% |
| Mine | move | 32.3 | 94% | 1849 | 0 | 0% |
| Mine | shoot | 9.3 | 46% | 336 | 416 | 124% |
| Opponent | charge | 1.0 | 33% | 189 | 262 | 138% |
| Opponent | join | 2.0 | 67% | 71 | 0 | 0% |
| Opponent | move | 30.0 | 93% | 1499 | 0 | 0% |
| Opponent | shoot | 3.3 | 80% | 528 | 488 | 92% |
| Opponent | support | 0.3 | 100% | 19 | 0 | 0% |

### Battle groups: wfr-a92c160-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 37 (8) | 37 | 0 | 42 | 12% | 2.3 | 49 (6) | 0 (2) | - | 17 (2) | 42 (6) |
| Mine | Clean-up | 3 | 69 (3) | 0 | 69 | 0 | 33% | 3.5 | 110 (2) | 0 (1) | - | 110 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 38 (7) | 12 | 26 | 42 | 57% | 3.7 | 0 (3) | 35 (3) | 159 (1) | 0 (2) | 53 (5) |
| Mine | Holder | 2 | 78 (2) | 0 | 78 | 0 | 100% | - | 78 (2) | - | - | 78 (2) | - |
| Mine | Shooter | 5 | 51 (5) | 51 | 0 | 19 | 0% | 1.4 | 63 (4) | 0 (1) | - | 63 (4) | 0 (1) |
| Mine | War machine | 4 | 20 (4) | 20 | 0 | 25 | 0% | 1.0 | 0 (2) | 39 (2) | - | 39 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 32 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 69 (9) | 69 | 0 | 34 | 22% | 2.7 | 109 (3) | 41 (5) | - | 77 (4) | 91 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 0% | 4.3 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 54 (3) | 7 | 47 | 29 | 0% | 3.0 | 209 (1) | 9 (2) | - | 15 (1) | 92 (2) |
| Opponent | Hammer | 8 | 22 (8) | 22 | 0 | 22 | 62% | 2.7 | 0 (4) | 86 (2) | 0 (2) | 33 (5) | 0 (3) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 35 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 30 | 0% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 3 | 17 (3) | 17 | 0 | 34 | 33% | 1.0 | 0 (1) | 26 (2) | - | 26 (2) | 0 (1) |

### Charged fights: wfr-a92c160-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 164 | 250 | 2.3 | 1.0 | 107 | 57 | +50 | 2 of 7 | 6 of 7 | - | +50 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 162 | 1.0 | 1.0 | 162 | 0 | +162 | 0 of 1 | 1 of 1 | - | +162 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 400 | 512 | 4.0 | 1.0 | 128 | 0 | +128 | 3 of 4 | 3 of 4 | - | +128 |
| **Opponent** | all armies | 3 | 133 | 225 | 1.7 | 1.0 | 135 | 0 | +135 | 3 of 5 | 4 of 5 | - | +135 |

### Effective charges: wfr-a92c160-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 1 (net -400) | 0 | 0 | 1 (net +126) | 0 | 4 (net +114) | 1 | 0% (0 of 6) |
| Opponent | Wood Elf Realms | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +70) | 2 (net +221) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: wfr-a92c160-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | -400 | 106 | 400 | -294 | -73.6 |
| Mine | 76-89% | 1 | 151 | 126 | +126 | 126 | 30 | +96 | +63.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 308 | 138 | +114 | 145 | 0 | +145 | +47.2 |
| Mine | No odds | 1 | 500 | 170 | +170 | 326 | 188 | +138 | +27.6 |
| Mine | All fights | 7 | 326 | 170 | +50 | 163 | 88 | +74 | +22.8 |
| Opponent | Long shot (under 50%) | 1 | 102 | 247 | +0 | 0 | 51 | -51 | -50.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 499 | 371 | +221 | 410 | 0 | +410 | +82.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 70 | +70 | 70 | 0 | +70 | +14.0 |
| Opponent | No odds | 1 | 350 | 162 | +162 | 162 | 33 | +129 | +36.9 |
| Opponent | All fights | 5 | 390 | 244 | +135 | 210 | 17 | +194 | +49.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p8 | move | 26 | 5 (19%) | 3 (12%) | 3 (12%) | 18 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

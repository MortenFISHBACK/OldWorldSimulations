# Doctrine scorecard: wfr-a92c160-p34

### Scorecard: wfr-a92c160-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 8 | 2 | 1 | 0 | 0 | 142 |
| L1923 | 3 | 1 | Mine | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 265 |
| L1923 | 3 | 1 | Opponent | yes | 12 | 2 | 3 | 2 | 0 | 0 | 0 | 70 |
| L2025 | 3 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 3.5 | 1.7 | 1.7 | 0.0 | 0.0 | 0.0 | 228.3 |
| **Average** | | | Opponent | 67% | 7.0 | 2.7 | 4.3 | 2.0 | 0.3 | 0.0 | 0.0 | 70.7 |

### KPIs: wfr-a92c160-p34

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 16) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 90% (9 of 10); on the table 90% | 100% (4 of 4); on the table 100% | 93% (13 of 14); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 90% (9 of 10); on the table 90% | 100% (7 of 7); on the table 100% | 94% (16 of 17); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 30% (9 of 30) | 39% (7 of 18) | 33% (16 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (9 of 20) | 44% (7 of 16) | 44% (16 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 25% (2 of 8) | - | 25% (2 of 8) |
| Points that never fought | lower | 28% (1651 of 5999) | 35% (2091 of 5999) | 31% (3742 of 11998) |
|   infantry points that never fought | lower | 35% (352 of 993) | 79% (822 of 1037) | 58% (1174 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 82% (18 of 22) | 44% (7 of 16) | 66% (25 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 84% (4313 of 5151) | 40% (1793 of 4500) | 63% (6106 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (14%) | 3.0 (82%) | 4.0 (38%) |
| MARCHED: its unit marched | 1.0 (14%) | 0.0 (0%) | 1.0 (9%) |
| CHARGED: its unit charged | 1.0 (14%) | 0.0 (0%) | 1.0 (9%) |
| IN COMBAT: engaged in combat | 1.3 (19%) | 0.0 (0%) | 1.3 (12%) |
| REAR RANK: in a rear rank | 0.7 (10%) | 0.0 (0%) | 0.7 (6%) |
| GONE: slain | 0.7 (10%) | 0.7 (18%) | 1.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (19%) | 0.0 (0%) | 1.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.3 | 1.3 | 5.3 | 0.3 |
| not cast | 6.3 | 0.7 | 4.7 | 10.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 4.0 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 1.3 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (11%) | 0.0 (0%) | 0.7 (14%) | 0.7 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.7 (11%) | 0.0 (0%) | 0.7 (14%) | 1.3 (12%) | 3.3 (17%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (21%) | 0.0 (0%) | 1.3 (29%) | 1.3 (12%) | 3.0 (15%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (58%) | 0.0 (0%) | 2.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (61%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 50% (2 of 4) | 50% (2 of 4) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (27 of 50) | 51% (43 of 84) | 52% (70 of 134) |
|   cavalry | - | 67% (14 of 21) | 67% (14 of 21) |
|   character | 100% (6 of 6) | 0% (0 of 19) | 24% (6 of 25) |
|   chariot | 100% (3 of 3) | - | 100% (3 of 3) |
|   infantry | 39% (12 of 31) | 66% (29 of 44) | 55% (41 of 75) |
|   monster | 60% (6 of 10) | - | 60% (6 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (26%) | 0.0 (0%) | 2.0 (9%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (22%) | 3.0 (14%) |
| FLEEING: it fled or was fleeing | 1.0 (13%) | 0.0 (0%) | 1.0 (5%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.3 (2%) | 0.7 (3%) |
| NO TARGET IN RANGE | 2.3 (30%) | 4.3 (32%) | 6.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (13%) | 3.7 (27%) | 4.7 (22%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (13%) | 2.3 (17%) | 3.3 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 2.3 | 60% | 11.1 pts | 55 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.0 | 1.0 | 67% | 23.3 pts | 23 pts |
| infantry | 16.0 | 9.7 | 71% | 5.8 pts | 92 pts |
| monster | 2.0 | 0.3 | 83% | 5.4 pts | 11 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 7.3 | 4.8 |
| Charges that made contact a game | 1.3 | 5.0 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.14 contact (28 units) | 0.69 declared, 0.45 contact (29 units) | 0.46 declared, 0.30 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 100% (3 of 3) | - | 100% (3 of 3) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 100% (4 of 4) | 100% (4 of 4) | 43% (3 of 7) | 73% (11 of 15) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 0% (0 of 4) | 67% (2 of 3) | - | 29% (2 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 32% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 6% | 100% (8 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 80% (4 of 5); on the table 80% | 50% (6 of 12) | 45% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 35% | 10% (1 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 58% (7 of 12) | 34% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 71% (5) | 100% (2) | 78% (7) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 47% (9 of 19) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (3 of 10) | 50% (9 of 18) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 67% (6 of 9) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 228.3 | 70.7 |
| Movement | Fights charged into per game | 1.3 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 8 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 1 of 8, net +297 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 3 of 8, net +106 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +0 | 3 of 8, net +268 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (12 of 27) | 12% (6 of 49) |
| Shooting | Points destroyed by shooting units | 0.0 | 84.7 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 7) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 15.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.3 / 0.0 | 1.3 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 182.3 | 369.3 |
| Combat | Points run down | 0.0 | 178.3 |
| Combat | Net points per charged fight, damage counted | -131 | +167 |
| Combat | Net per 100 charger points, damage counted | -63.5 | +40.5 |
| Combat | First round won (charged fights) | 75% | 83% |
| Combat | Net points per charged fight | -137 | +161 |
| Combat | Net points per supported fight / lone fight | - / -137 | +245 / +144 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 5 of 12 |
| Game | Points lost | 1236.3 | 322.0 |
| Game | VP from objectives | 330.0 | 1153.3 |
| Game | Lone holders (player turns) | 1.0 | 7.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1842 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1558
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +7.8 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +75.3 | 0.0 | 0.0 | 0.3 | +46.4 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | -141.6 | 0.0 | 303.0 | 15.7 | +67.2 | 0.0 | 22.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 1.3 | +6.5 | 0.0 | 0.0 | 1.3 | +7.6 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.7 | -20.2 | 83.7 | 65.0 |
| CAST JOB | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +6.9 | 0.0 | 198.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 70.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +18.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -3.8 | 0.0 | 61.7 | 0.3 | -1.9 | 61.7 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +3.7 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -754.5 | 0.0 | 826.0 | 10.7 | -214.3 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 22.0 | 30.0 | - | - | - | - |
| CHARGE NOW FIRST | - | - | - | - | 3.7 | +0.0 | 602.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 114.7 | 17.0 | +0.0 | 0.0 | 80.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 262.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +45.9 | 140.7 | 140.7 |
| COVER ONCE | 8.3 | -301.9 | 0.0 | 492.0 | 3.0 | -85.1 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 61.7 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -283.0 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +39.6 | 99.0 | 0.0 |
| EXACT ROUND | 0.7 | +7.1 | 22.0 | 30.0 | 6.0 | +85.7 | 983.3 | 65.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 22.0 | 30.0 | 6.7 | +23.7 | 1111.0 | 0.0 |
| FALLS SHORT | 9.0 | +136.8 | 0.0 | 464.0 | 10.0 | +106.0 | 0.0 | 189.0 |
| FEATURE BUFFS | 2.0 | +15.4 | 0.0 | 0.0 | 1.3 | +14.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | -11.2 | 0.0 | 0.0 | 2.3 | +77.2 | 635.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 18.3 | 0.0 |
| FIVE ACTION | 71.7 | +4506.6 | 22.0 | 1936.3 | 101.3 | +8890.7 | 1625.0 | 393.0 |
| FLANK NOT WEIGHED | 11.3 | +0.0 | 0.0 | 470.3 | 2.0 | +0.0 | 0.0 | 25.0 |
| FOCUS FIRE | - | - | - | - | 1.0 | +28.5 | 36.7 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +7.8 | 0.0 | 0.0 | 1.0 | +256.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +173.7 | 22.0 | 30.0 | 7.3 | +716.5 | 1144.3 | 65.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 85.0 | 1.3 | +0.0 | 0.0 | 33.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -19.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -4.4 | 0.0 | 0.0 | 1.7 | -21.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.7 | -15.1 | 244.7 | 0.0 |
| GOAL WALK | 10.3 | +739.4 | 0.0 | 365.0 | 6.3 | +646.3 | 0.0 | 30.0 |
| GUN FIGURES | 3.0 | +0.4 | 15.0 | 123.3 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 177.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 85.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 826.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 26.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.3 | +0.0 | 0.0 | 194.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -8.0 | 0.0 | 130.0 | 6.3 | -87.2 | 0.0 | 15.0 |
| HIS MOVE AS HE DECIDES | 43.0 | +13.0 | 371.3 | 0.0 | 34.0 | +9.3 | 968.7 | 0.0 |
| HIS MOVE WHY | 13.3 | +0.0 | 0.0 | 631.7 | 35.0 | +0.0 | 0.0 | 212.3 |
| HIS ONE MOVE | 21.3 | -151.3 | 0.0 | 138.3 | 27.3 | +17.1 | 0.0 | 45.0 |
| HIS ONE QUARTER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 194.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 12.0 | +0.0 | 0.0 | 80.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.3 | +0.0 | 0.0 | 83.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +311.9 | 0.0 | 1067.0 | 27.7 | +237.8 | 0.0 | 77.3 |
| HIS SHOTS BY HIS RUN | 33.7 | +257.9 | 0.0 | 907.7 | 32.3 | +247.1 | 0.0 | 124.0 |
| HIS TURN DENIED | 0.7 | +5.0 | 22.0 | 30.0 | 1.0 | +5.0 | 0.0 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 78.3 | 23.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +519.5 | 0.0 | 78.3 | 13.3 | +1049.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -39.0 | 22.0 | 30.0 | 6.7 | -249.3 | 1045.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +38.4 | 0.0 | 0.0 |
| IDLE COST | 3.7 | -33.3 | 0.0 | 213.0 | 7.0 | -64.3 | 0.0 | 197.3 |
| JOINT CHARGE NOW | 0.7 | +68.4 | 0.0 | 0.0 | 2.0 | -217.4 | 538.3 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +18.9 | 85.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +76.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 116.7 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 65.0 | 78.3 | 13.0 | +0.0 | 730.7 | 345.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.3 | 0.0 | 0.0 | 4.3 | +4.6 | 776.0 | 65.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -41.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +14.4 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -6.9 | 0.0 | 139.7 | 1.0 | -0.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +29.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +66.1 | 0.0 | 99.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +135.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +129.0 | 0.0 | 50.0 | 4.3 | +94.1 | 0.0 | 15.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +28.4 | 0.0 | 0.0 | 3.0 | +15.5 | 0.0 | 140.7 |
| MISSILES NEXT TURN | 4.7 | +64.3 | 0.0 | 198.0 | 4.3 | +14.3 | 0.0 | 140.7 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 99.0 | 2.7 | +0.0 | 0.0 | 70.3 |
| MOVE TO CHARGE COMPUTED | 3.7 | +117.3 | 0.0 | 0.0 | 14.0 | +1550.3 | 0.0 | 30.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.7 | +436.6 | 0.0 | 249.3 | 12.3 | +458.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +37.2 | 0.0 | 0.0 | 8.0 | +837.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -9.4 | 22.0 | 30.0 | 7.0 | -184.6 | 1114.3 | 65.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -35.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -252.7 | 0.0 | 223.3 | 4.3 | -198.3 | 0.0 | 16.7 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 26.7 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -29.4 | 0.0 | 80.0 | 8.3 | -204.0 | 0.0 | 15.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +244.4 | 262.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +13.1 | 0.0 | 0.0 | 5.7 | -16.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -28.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 2.0 | +189.0 | 82.7 | 65.0 |
| OVERRUNS AWAY | 0.3 | +12.7 | 22.0 | 30.0 | 2.3 | +34.5 | 243.3 | 65.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 33.3 | +86.7 | 0.0 | 879.7 | 48.0 | +822.0 | 530.7 | 413.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -57.1 | 0.0 | 0.0 | 14.0 | -606.9 | 0.0 | 15.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -4.4 | 0.0 | 0.0 | 1.3 | -45.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -1.2 | 18.3 | 0.0 |
| QUARTER ODDS | 16.3 | +1640.4 | 0.0 | 247.3 | 29.3 | +3253.4 | 426.0 | 65.0 |
| RANDOM MOVE BY FIGURES | 2.7 | +67.7 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.3 | +388.5 | 0.0 | 63.3 | 4.3 | +117.1 | 0.0 | 62.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.3 | +0.0 | 0.0 | 45.0 | 3.7 | +0.0 | 0.0 | 62.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +97.0 | 145.3 | 65.0 |
| REFORMS TO MEET IT | 0.7 | -10.8 | 0.0 | 0.0 | 1.0 | -13.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +57.6 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -6.9 | 22.0 | 30.0 | 6.3 | -58.6 | 1010.7 | 65.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 5.3 | -216.3 | 1045.0 | 65.0 |
| RUN DOWN | - | - | - | - | 6.3 | -50.1 | 1079.7 | 65.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -33.5 | 0.0 | 0.0 | 0.7 | -11.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +89.1 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +29.9 | 78.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.7 | -68.3 | 0.0 | 33.3 |
| SET UP BY THE SET | 0.3 | -20.9 | 0.0 | 0.0 | 5.0 | -50.0 | 0.0 | 33.3 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +14.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.7 | +0.0 | 0.0 | 322.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +202.2 | 0.0 | 167.3 | 2.3 | +21.9 | 80.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -5.4 | 20.0 | 0.0 |
| SHOT RISK POINTS | 17.3 | -112.6 | 0.0 | 584.7 | 16.3 | -121.9 | 0.0 | 63.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.7 | +135.0 | 0.0 | 367.7 | 14.0 | +97.7 | 0.0 | 22.0 |
| SPELL WORTH | 1.3 | +14.3 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 10.0 | +0.0 | 0.0 | 158.3 | 5.7 | +0.0 | 0.0 | 25.0 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -7.5 | 167.3 | 0.0 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 78.0 | 0.7 | +0.0 | 0.0 | 140.7 |
| STANDS STILL | 19.0 | +0.0 | 0.0 | 810.7 | 41.0 | +0.0 | 480.7 | 0.0 |
| STAY WORTH | 6.7 | +28.7 | 0.0 | 246.7 | 15.3 | +109.2 | 251.3 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +18.5 | 22.0 | 108.3 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.7 | +913.9 | 0.0 | 323.0 | 7.0 | +170.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 9.7 | +913.9 | 0.0 | 323.0 | 7.0 | +170.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.5 | 0.0 | 116.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -9.8 | 0.0 | 0.0 | 0.3 | -21.6 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.7 | +0.0 | 0.0 | 61.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 206.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 169.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.0 | +0.0 | 0.0 | 777.7 | 49.0 | +0.0 | 0.0 | 234.3 |
| TIED UP BY THE SUM | 0.3 | +11.8 | 22.0 | 30.0 | 2.7 | +290.7 | 206.7 | 0.0 |
| TIME ON OUR SIDE | 22.7 | +205.0 | 0.0 | 497.3 | 35.7 | +290.0 | 80.0 | 22.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +153.5 | 0.0 | 0.0 | 0.7 | -17.4 | 60.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.4 | 22.0 | 30.0 | 2.0 | +27.5 | 554.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -21.6 | 85.0 | 0.0 |
| WHO HITS BACK | 0.7 | +54.7 | 0.0 | 167.3 | 1.3 | +20.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -2.7 | 30.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -710.4 | 0.0 | 361.3 | 1.7 | -45.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +8.8 | 131.0 | 0.0 |
| WHOLE FIGHT REACTION | 4.3 | +461.4 | 65.0 | 569.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.3 | +10.7 | 0.0 | 0.0 | 1.7 | +14.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 231 | 231 | 164 | 54.67 | +0 | +0.0 |
| HIS MOVE WHY | 145 | 145 | 73 | 24.33 | +0 | +0.0 |
| ARMY TABLE | 98 | 98 | 60 | 20.00 | +770 | +12.8 |
| HOLDER ASSIGNMENT | 63 | 63 | 57 | 19.00 | +2292 | +40.2 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| FIVE ACTION | 519 | 498 | 42 | 14.00 | +2308 | +55.0 |
| HIS ONE MOVE | 146 | 142 | 32 | 10.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 198 | 190 | 30 | 10.00 | +162 | +5.4 |
| MOVE TO CHARGE COMPUTED | 53 | 47 | 29 | 9.67 | +1009 | +34.8 |
| HIS SHOT LIST | 186 | 178 | 28 | 9.33 | +213 | +7.6 |
| REDIRECT FOR A FRIEND IN REACH | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| THE TABLE AGAIN | 34 | 34 | 26 | 8.67 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -1353 | -58.8 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 20 | 6.67 | -1992 | -99.6 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SUPPORT ADDS | 50 | 47 | 16 | 5.33 | +536 | +33.5 |
| SUPPORT WORKED OUT | 50 | 47 | 16 | 5.33 | +536 | +33.5 |
| NEXT CHARGE BY LIST | 29 | 26 | 15 | 5.00 | +751 | +50.1 |
| THE RISK READS HIS RUN | 34 | 34 | 14 | 4.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 175 | 157 | 14 | 4.67 | +35 | +2.5 |
| QUARTER ODDS | 137 | 131 | 12 | 4.00 | +669 | +55.7 |
| FOUR ROUNDS | 26 | 23 | 11 | 3.67 | +1064 | +96.7 |
| GOAL WALK | 50 | 47 | 11 | 3.67 | +625 | +56.8 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | -447 | -55.9 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 7 | 2.33 | +386 | +55.1 |
| TIED UP BY THE SUM | 9 | 8 | 7 | 2.33 | +355 | +50.7 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +793 | +132.2 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| MAX FOR POSITIONING | 25 | 25 | 6 | 2.00 | +7 | +1.2 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +173 | +28.8 |
| SHOT RISK POINTS | 101 | 100 | 6 | 2.00 | +29 | +4.9 |
| WHO HITS BACK | 6 | 6 | 6 | 2.00 | +180 | +30.1 |
| IDLE COST | 32 | 18 | 5 | 1.67 | +41 | +8.1 |
| REDIRECT COUNTER | 29 | 25 | 5 | 1.67 | +167 | +33.5 |
| SET UP BY THE SET | 16 | 16 | 5 | 1.67 | +255 | +51.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +40 | +10.0 |
| OPENS UP | 6 | 5 | 4 | 1.33 | +243 | +60.7 |
| SEARCH SPOT | 7 | 7 | 4 | 1.33 | +267 | +66.8 |
| STAY WORTH | 66 | 61 | 4 | 1.33 | +7 | +1.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +17 | +5.8 |
| CHARGE LOSSES | 65 | 61 | 3 | 1.00 | +60 | +20.1 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -138 | -46.1 |
| FALLS SHORT | 57 | 49 | 3 | 1.00 | +15 | +5.0 |
| FOCUS FIRE | 3 | 3 | 3 | 1.00 | +85 | +28.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +308 | +102.8 |
| WOUNDS ON THE RANKS | 12 | 12 | 3 | 1.00 | +13 | +4.3 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +365 | +182.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -61 | -30.4 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -17 | -8.5 |
| FALL BACK GOOD ORDER | 22 | 19 | 2 | 0.67 | +16 | +7.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +10 | +4.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +90 | +44.8 |
| MISSILES IN THE MOVE | 18 | 10 | 2 | 0.67 | +27 | +13.7 |
| NEARER NOT NEEDED | 66 | 63 | 2 | 0.67 | +106 | +52.8 |
| NO DOUBLE ROUNDS | 23 | 20 | 2 | 0.67 | +72 | +36.0 |
| PROMISE READS THE TABLE | 6 | 6 | 2 | 0.67 | -118 | -59.0 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 2 | 0.67 | +203 | +101.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +90 | +44.8 |
| SHOTS AFTER THE MOVES | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 71 | 56 | 2 | 0.67 | +3 | +1.3 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +56 | +27.8 |
| WHAT THE JOINER ADDS | 4 | 4 | 2 | 0.67 | +207 | +103.4 |
| WHOLE FIGHT DANGER | 14 | 11 | 2 | 0.67 | +35 | +17.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +24 | +23.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -22 | -22.5 |
| COVER ONCE | 34 | 21 | 1 | 0.33 | +46 | +46.2 |
| FEATURE BUFFS | 10 | 10 | 1 | 0.33 | +5 | +4.8 |
| FIGHT TO THE END | 8 | 6 | 1 | 0.33 | +31 | +31.1 |
| HONEST WORTH | 24 | 21 | 1 | 0.33 | +17 | +17.3 |
| HUNT IN PAIRS | 5 | 2 | 1 | 0.33 | +26 | +26.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +57 | +56.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +231 | +230.8 |
| LOST AFTER ESCAPE | 14 | 12 | 1 | 0.33 | +0 | +0.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -46 | -46.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +31 | +31.1 |
| ONE OBJECTIVE FORMULA | 29 | 19 | 1 | 0.33 | +38 | +37.5 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -84 | -84.2 |
| OVERRUNS AWAY | 8 | 7 | 1 | 0.33 | +22 | +22.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -4 | -3.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| RISK BY ARC | 21 | 18 | 1 | 0.33 | +30 | +29.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -65 | -64.7 |
| BACKUP TARGETS | 8 | 5 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 70 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 20 | 18 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 14 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 40 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 5 | 5 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 34 | 34 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 34 | 34 | 0 | 0.00 | - | - |
| HOLD ODDS | 112 | 111 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 20 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 16 | 13 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 27 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 180 | 172 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 4 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 246 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 7 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.00 | 53.1 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 5.00 | 99.6 |
| ARMY TABLE | rule | 1.67 | 1.33 | 26.6 |
| JOINT CHARGE NOW | rule | 0.33 | 1.33 | 156.9 |
| CHARGE NOW FIRST | rule | - | 1.00 | 46.1 |
| BEST PRIZE | rule | - | 0.67 | 30.4 |
| CHAFF PASSED | rule | 0.33 | 0.33 | 8.5 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 19.4 |
| NO REASON | gate | 0.67 | - | 83.8 |
| PROMISE READS THE TABLE | rule | - | 0.67 | 59.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 22.5 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| MARCH OF THE TABLE | rule | 0.33 | - | 46.1 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 84.2 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 3.6 |
| RULE SWITCHED OFF | gate | - | 0.33 | 123.6 |
| WHO GETS IN | rule | - | 0.33 | 64.7 |

### Plans: wfr-a92c160-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 123 | 46 | 38% |
| Mine | move | 29.0 | 89% | 1593 | 0 | 0% |
| Mine | shoot | 3.3 | 50% | 488 | 40 | 8% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 6.0 | 61% | 982 | 664 | 68% |
| Opponent | join | 2.0 | 100% | 89 | 0 | 0% |
| Opponent | move | 36.0 | 97% | 2213 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 137 | 158 | 115% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 38% | 33% | 0% | - | 17% | 0% | 0% | 83% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 15% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 73 (1) | 73 | 0 | 100 | 0% | 3.0 | - | 73 (1) | - | 73 (1) | - |
| Mine | Chaff | 7 | 27 (7) | 0 | 27 | 80 | 86% | 2.0 | 31 (6) | 0 (1) | - | 27 (7) | - |
| Mine | Character | 8 | 2 (8) | 2 | 0 | 56 | 12% | 2.3 | 6 (3) | 0 (2) | 0 (1) | 0 (2) | 4 (4) |
| Mine | Clean-up | 4 | 48 (4) | 0 | 48 | 32 | 25% | 4.7 | 77 (2) | 0 (1) | 0 (1) | 156 (1) | 0 (3) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 11 | 26 (11) | 26 | 0 | 79 | 9% | 1.8 | 36 (3) | 21 (7) | 0 (1) | 32 (4) | 22 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.7 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 41 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 8 | 163 (8) | 31 | 133 | 36 | 25% | 2.2 | 252 (2) | 185 (4) | 0 (2) | 249 (5) | 0 (3) |
| Opponent | Character | 8 | 60 (8) | 60 | 0 | 2 | 38% | 1.8 | 57 (5) | 66 (3) | - | 86 (3) | 45 (5) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 47 | 50% | 3.5 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Fast Hammer | 7 | 109 (7) | 109 | 0 | 21 | 43% | 2.5 | 31 (2) | 168 (5) | - | 165 (4) | 70 (3) |
| Opponent | Holder | 4 | 180 (4) | 21 | 159 | 0 | 0% | 2.0 | 247 (3) | - | 0 (1) | 396 (2) | 0 (2) |
| Opponent | Shooter | 4 | 8 (4) | 8 | 0 | 0 | 0% | 1.2 | 16 (2) | 0 (2) | - | 0 (2) | 11 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 55 | 0% | 3.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: wfr-a92c160-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 350 | -350 | 1 of 1 | 0 of 1 | - | -350 |
| Mine | Skaven | 1 | 45 | 0 | 2.0 | 1.0 | 0 | 98 | -98 | 1 of 2 | 2 of 2 | - | -98 |
| **Mine** | all armies | 3 | 38 | 0 | 1.3 | 1.0 | 0 | 137 | -137 | 2 of 4 | 3 of 4 | - | -137 |
| Opponent | Tomb Kings of Khemri | 2 | 127 | 1098 | 5.0 | 1.3 | 220 | 26 | +194 | 5 of 10 | 8 of 10 | +245 | +181 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| **Opponent** | all armies | 3 | 85 | 732 | 4.0 | 1.2 | 183 | 22 | +161 | 5 of 12 | 10 of 12 | +245 | +144 |

### Effective charges: wfr-a92c160-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Skaven | 2 | 0 | 1 (net -197) | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 10 | 0 | 0 | 1 (net +297) | 1 (net +56) | 3 (net +106) | 2 (net +402) | 3 | 14% (1 of 7) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 192 | 480 | -197 | 0 | 197 | -197 | -102.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 141 | 67 | +0 | 15 | 3 | +12 | +8.4 |
| Mine | No odds | 1 | 350 | 431 | -350 | 0 | 350 | -350 | -100.0 |
| Mine | All fights | 4 | 206 | 261 | -137 | 7 | 138 | -131 | -63.5 |
| Opponent | Effective (55-75%) | 1 | 195 | 297 | +297 | 297 | 0 | +297 | +152.3 |
| Opponent | 76-89% | 1 | 195 | 251 | +56 | 251 | 195 | +56 | +28.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 597 | 263 | +268 | 350 | 72 | +278 | +46.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 482 | 128 | +106 | 128 | 22 | +106 | +22.0 |
| Opponent | No odds | 4 | 328 | 217 | +115 | 124 | 0 | +124 | +38.0 |
| Opponent | All fights | 12 | 412 | 216 | +161 | 207 | 40 | +167 | +40.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p34 | move | 29 | 8 (28%) | 5 (17%) | 6 (21%) | 15 (52%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

# Doctrine scorecard: wfr-a92c160-p38

### Scorecard: wfr-a92c160-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 2 | 1 | 1 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 3 | 1 | 3 | 1 | 0 | 0 | 0 | 144 |
| L0307 | 1 | 1 | Mine | yes | 5 | - | 0 | 2 | 0 | 0 | 0 | 445 |
| L0307 | 1 | 1 | Opponent | no | 7 | - | 0 | 4 | 0 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 245 |
| **Average** | | | Mine | 33% | 3.5 | 1.0 | 0.7 | 2.7 | 0.3 | 0.0 | 0.0 | 430.0 |
| **Average** | | | Opponent | 33% | 5.0 | 2.5 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 254.7 |

### KPIs: wfr-a92c160-p38

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (3 of 12) | 0% (0 of 15) | 11% (3 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 100% (3 of 3); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (7 of 7); on the table 100% | 80% (4 of 5); on the table 80% | 92% (11 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 17% (6 of 36) | 67% (4 of 6) | 24% (10 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 19% (6 of 31) | 67% (4 of 6) | 27% (10 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 56% (3323 of 5897) | 74% (4448 of 5999) | 65% (7771 of 11896) |
|   infantry points that never fought | lower | 53% (760 of 1437) | 94% (883 of 938) | 69% (1643 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 55% (11 of 20) | 62% (26 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2747 of 4484) | 49% (2258 of 4648) | 55% (5005 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (63%) | 0.0 (0%) | 6.3 (59%) |
| MARCHED: its unit marched | 1.3 (13%) | 0.7 (100%) | 2.0 (19%) |
| IN COMBAT: engaged in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.3 (13%) | 0.0 (0%) | 1.3 (12%) |
| STUPIDITY: Stupidity | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 3.3 | 0.7 | 0.0 |
| not cast | 0.0 | 3.0 | 10.7 | 1.3 | 8.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.3 (59%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.0 (19%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.3 (11%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.7 (22%) | 1.3 (12%) | 0.0 (0%) | 1.7 (21%) |
| STUPIDITY: Stupidity | - | 0.7 (22%) | 0.7 (6%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.7 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | - | 100% (3 of 3) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 33% (1 of 3) | - | 33% (1 of 3) |
| it fought by the end of its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 82% (42 of 51) | 64% (70 of 109) | 70% (112 of 160) |
|   cavalry | - | 91% (10 of 11) | 91% (10 of 11) |
|   character | - | 0% (0 of 20) | 0% (0 of 20) |
|   chariot | 65% (13 of 20) | 67% (4 of 6) | 65% (17 of 26) |
|   infantry | - | 73% (44 of 60) | 73% (44 of 60) |
|   war machine | 94% (29 of 31) | 100% (12 of 12) | 95% (41 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (22%) | 0.3 (3%) | 1.0 (6%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (13%) | 1.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (11%) | 1.3 (10%) | 1.7 (10%) |
| MOVED: a war machine that moved | 0.3 (11%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (11%) | 5.0 (38%) | 5.3 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (13%) | 1.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (44%) | 2.0 (15%) | 3.3 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.7 | 82% | 7.4 pts | 27 pts |
| chariot | 5.7 | 5.0 | 53% | 21.7 pts | 123 pts |
| infantry | 17.3 | 8.7 | 73% | 5.3 pts | 92 pts |
| war machine | 14.3 | 20.0 | 56% | 44.1 pts | 632 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 4.0 | 2.5 |
| Charges that made contact a game | 1.0 | 1.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.40 declared, 0.13 contact (30 units) | 0.30 declared, 0.14 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 40% (2 of 5) | 57% (4 of 7) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 78% (7 of 9) | 100% (2 of 2) | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (5 of 5); on the table 100% | 33% (4 of 12) | 25% | 50% (3 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 8% (2 of 24) | 71% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Empire of Man | 1 | - | 67% (4 of 6) | 100% | 80% (8 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 80% | - | 61% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 0% (0) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: wfr-a92c160-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 57% (25 of 44) | 55% (21 of 38) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 83% (5 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 430.0 | 254.7 |
| Movement | Fights charged into per game | 1.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 2 of 4, net +120 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net +122 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 4, net +310 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 20.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (6 of 13) | 37% (22 of 60) |
| Shooting | Points destroyed by shooting units | 150.0 | 93.3 |
| Shooting | War machine shots | 9.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (6 of 29) | 75% (9 of 12) |
| Shooting | Points destroyed by war machines | 41.7 | 65.0 |
| Magic | Magic missiles cast | 0.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 24.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 253.3 | 354.0 |
| Combat | Points run down | 0.0 | 62.7 |
| Combat | Net points per charged fight, damage counted | +69 | +180 |
| Combat | Net per 100 charger points, damage counted | +91.1 | +41.7 |
| Combat | First round won (charged fights) | 67% | 75% |
| Combat | Net points per charged fight | +83 | +159 |
| Combat | Net points per supported fight / lone fight | - / +83 | - / +159 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 3 of 4 |
| Game | Points lost | 715.0 | 419.0 |
| Game | VP from objectives | 320.0 | 973.3 |
| Game | Lone holders (player turns) | 3.5 | 5.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1036 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1134
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +3.4 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +243.0 | 0.0 | 171.7 | 28.0 | +554.5 | 0.0 | 22.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 120.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 46.7 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +18.9 | 85.0 | 276.7 | 4.0 | +87.2 | 111.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 1.7 | +11.7 | 130.0 | 0.0 | 0.7 | +8.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +49.6 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 19.3 | -920.8 | 0.0 | 91.3 | 17.7 | -455.0 | 0.0 | 256.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 40.7 | 28.3 | 1.3 | +0.0 | 74.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 56.0 | 9.3 | +0.0 | 0.0 | 65.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 40.7 | 188.3 | 1.0 | +0.0 | 56.7 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +274.0 | 0.0 | 73.3 | - | - | - | - |
| COVER ONCE | 9.3 | -599.5 | 0.0 | 140.0 | 6.0 | -176.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | -0.1 | 64.7 | 28.3 | 3.0 | -3.7 | 233.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 64.7 | 28.3 | 3.0 | +3.5 | 280.7 | 0.0 |
| FALLS SHORT | 8.0 | +159.0 | 0.0 | 159.3 | 16.7 | +135.6 | 0.0 | 174.0 |
| FEATURE BUFFS | 6.3 | +130.8 | 0.0 | 0.0 | 3.3 | +90.8 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +72.4 | 206.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 84.3 | +3211.0 | 553.7 | 1602.3 | 107.3 | +7924.4 | 1050.7 | 474.0 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 211.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +116.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +23.5 | 64.7 | 28.3 | 4.0 | +214.2 | 336.7 | 0.0 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 69.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -62.3 | 0.0 | 0.0 | 1.3 | -37.5 | 0.0 | 130.0 |
| GIVES UP | 0.3 | -1.1 | 24.0 | 0.0 | 0.7 | -7.7 | 103.3 | 0.0 |
| GOAL WALK | 13.3 | +780.5 | 0.0 | 34.7 | 19.3 | +2444.5 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +68.2 | 172.0 | 103.3 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 69.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 40.7 | 28.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 16.0 | +0.0 | 0.0 | 91.3 | 4.3 | +0.0 | 0.0 | 126.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 34.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 103.3 | 5.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 2.3 | -10.7 | 0.0 | 73.7 | 2.7 | -95.9 | 0.0 | 44.0 |
| HIS MOVE AS HE DECIDES | 49.3 | +14.7 | 529.3 | 0.0 | 33.3 | +10.3 | 633.7 | 0.0 |
| HIS MOVE WHY | 25.3 | +0.0 | 0.0 | 210.7 | 20.3 | +0.0 | 0.0 | 174.0 |
| HIS ONE MOVE | 17.0 | -57.0 | 0.0 | 28.3 | 22.0 | +25.8 | 56.7 | 0.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 103.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.7 | +1111.1 | 0.0 | 608.0 | 64.0 | +1892.0 | 0.0 | 474.0 |
| HIS SHOTS BY HIS RUN | 39.7 | +509.9 | 0.0 | 351.3 | 48.0 | +812.4 | 0.0 | 474.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +23.5 | 103.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 112.0 | 22.7 | +0.0 | 0.0 | 88.0 |
| HOLDER ASSIGNMENT | 8.3 | +807.3 | 0.0 | 56.0 | 14.7 | +1336.2 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -4.3 | 64.7 | 28.3 | 3.3 | -158.2 | 336.7 | 0.0 |
| IDLE COST | 9.3 | -57.3 | 0.0 | 229.3 | 15.0 | -216.2 | 0.0 | 150.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +237.7 | 56.0 | 0.0 |
| KEEP FALLS | 0.7 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 229.3 | 149.0 | 10.3 | +0.0 | 568.7 | 334.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.3 | 40.7 | 28.3 | 1.3 | +4.0 | 28.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +8.1 | 0.0 | 65.0 |
| MANOEUVRE | 2.3 | -7.3 | 0.0 | 0.0 | 1.7 | +9.4 | 0.0 | 65.0 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.3 | 0.0 | 0.0 | 0.3 | +6.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +27.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -1.1 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +29.5 | 0.0 | 28.3 | 3.7 | +44.8 | 0.0 | 87.0 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.7 | +64.0 | 0.0 | 0.0 | 1.3 | +16.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.3 | +74.4 | 0.0 | 56.7 | 1.7 | +33.3 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -17.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.3 | +149.7 | 0.0 | 0.0 | 5.7 | +492.6 | 0.0 | 195.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +394.2 | 0.0 | 0.0 | 10.0 | +413.3 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 2.0 | +112.8 | 0.0 | 0.0 | 3.0 | +306.0 | 0.0 | 65.0 |
| NO DOUBLE ROUNDS | 0.7 | -6.8 | 24.0 | 0.0 | 4.0 | -191.1 | 336.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | -8.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -96.3 | 24.0 | 88.7 | 6.3 | -176.9 | 0.0 | 87.0 |
| OGRE LOADER SECOND SHOT | 3.0 | +15.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -20.9 | 0.0 | 149.0 | 8.0 | -166.8 | 0.0 | 65.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +58.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -6.2 | 0.0 | 56.0 | 5.3 | +69.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -106.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +17.4 | 17.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +353.1 | 273.7 | 1052.0 | 47.7 | +547.2 | 598.3 | 529.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -36.9 | 0.0 | 0.0 | 10.0 | -360.2 | 0.0 | 130.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -22.5 | 0.0 | 65.0 |
| PROMISE SHOT AWAY | 0.3 | -1.2 | 63.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 11.7 | +967.5 | 126.0 | 0.0 | 19.3 | +1534.8 | 103.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.3 | +21.5 | 0.0 | 28.3 | 1.7 | +16.1 | 0.0 | 22.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +17.9 | 0.0 | 56.3 | 3.7 | +0.0 | 0.0 | 44.0 |
| REFORMS TO MEET IT | 0.3 | -5.3 | 0.0 | 0.0 | 2.7 | -15.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +28.4 | 64.7 | 28.3 | 3.0 | -26.4 | 280.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | +19.4 | 45.3 | 0.0 |
| RUN DOWN | - | - | - | - | 2.7 | -13.5 | 73.3 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 48.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 48.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -74.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +29.9 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +16.0 | 24.0 | 0.0 | 0.3 | +6.6 | 17.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -18.9 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 2.7 | -241.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 2.3 | +9.9 | 0.0 | 65.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.0 | +0.0 | 0.0 | 426.7 | 11.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +198.5 | 63.0 | 0.0 | 0.3 | +6.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 27.0 | -344.9 | 0.0 | 238.7 | 28.7 | -237.2 | 0.0 | 452.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +391.5 | 0.0 | 576.7 | 25.0 | +447.5 | 0.0 | 44.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 198.3 | 7.0 | +0.0 | 0.0 | 83.3 |
| STAND AND SHOOT | 0.7 | -0.5 | 64.7 | 28.3 | 0.7 | -8.4 | 206.7 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 130.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 42.7 | +0.0 | 489.0 | 1059.3 | 40.7 | +0.0 | 714.0 | 0.0 |
| STAY WORTH | 29.3 | -432.8 | 426.0 | 1073.3 | 36.7 | +393.3 | 490.7 | 22.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +1294.3 | 0.0 | 56.7 | 2.0 | +42.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 8.3 | +1294.3 | 0.0 | 56.7 | 2.0 | +42.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +1.0 | 0.0 | 0.0 | 0.7 | +3.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 0.3 | -4.0 | 0.0 | 0.0 | 0.3 | -30.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 120.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 138.0 | 2.3 | +0.0 | 0.0 | 63.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 65.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 17.3 | 2.3 | +0.0 | 0.0 | 128.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 712.0 | 51.3 | +0.0 | 0.0 | 237.0 |
| TIED UP BY THE SUM | 0.3 | +5.3 | 24.0 | 0.0 | 0.7 | +40.4 | 17.3 | 0.0 |
| TIME ON OUR SIDE | 19.7 | +282.5 | 0.0 | 263.3 | 17.0 | +192.8 | 56.7 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 3.3 | +0.0 | 0.0 | 206.7 | - | - | - | - |
| WHO FIGHTS | 0.7 | +0.3 | 24.0 | 0.0 | 0.7 | -0.5 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +24.0 | 0.0 | 40.7 |
| WHOLE FIGHT DANGER | 1.7 | -539.9 | 0.0 | 56.7 | 0.3 | -18.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +8.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.3 | +448.1 | 0.0 | 34.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.3 | +191.8 | 0.0 | 0.0 | 1.7 | +152.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 248 | 248 | 173 | 57.67 | +0 | +0.0 |
| ARMY TABLE | 135 | 135 | 91 | 30.33 | +1949 | +21.4 |
| HIS MOVE WHY | 137 | 137 | 75 | 25.00 | +0 | +0.0 |
| HIS SHOT LIST | 338 | 326 | 72 | 24.00 | +895 | +12.4 |
| HOLDER ASSIGNMENT | 69 | 69 | 65 | 21.67 | +3847 | +59.2 |
| HIS ONE MOVE | 117 | 113 | 48 | 16.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 263 | 251 | 46 | 15.33 | +298 | +6.5 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -819 | -23.4 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| SHOT RISK POINTS | 167 | 157 | 29 | 9.67 | +567 | +19.5 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| FIVE ACTION | 575 | 557 | 28 | 9.33 | +1792 | +64.0 |
| GOAL WALK | 98 | 96 | 24 | 8.00 | +1472 | +61.3 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +44 | +2.3 |
| THE RISK READS HIS RUN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 110 | 94 | 19 | 6.33 | +78 | +4.1 |
| MOVE TO CHARGE COMPUTED | 27 | 21 | 18 | 6.00 | +315 | +17.5 |
| PROMISE BY ITS OWN SUM | 45 | 45 | 17 | 5.67 | -1191 | -70.1 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SUPPORT ADDS | 31 | 31 | 12 | 4.00 | +244 | +20.3 |
| SUPPORT WORKED OUT | 31 | 31 | 12 | 4.00 | +244 | +20.3 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 39 | 39 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 14 | 11 | 3.67 | +222 | +20.1 |
| STAY WORTH | 198 | 182 | 11 | 3.67 | +66 | +6.0 |
| MAX FOR POSITIONING | 16 | 16 | 9 | 3.00 | +47 | +5.2 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +46 | +5.1 |
| QUARTER ODDS | 93 | 91 | 9 | 3.00 | +609 | +67.7 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 9 | 3.00 | +100 | +11.1 |
| COVER ONCE | 46 | 39 | 7 | 2.33 | +86 | +12.3 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 74 | 63 | 6 | 2.00 | +139 | +23.1 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| SET UP BY THE SET | 8 | 8 | 5 | 1.67 | +144 | +28.7 |
| CHARGE LOSSES | 111 | 104 | 4 | 1.33 | +80 | +20.1 |
| FOUR ROUNDS | 15 | 12 | 4 | 1.33 | +392 | +98.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +713 | +178.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 53 | 50 | 4 | 1.33 | +177 | +44.3 |
| SHOTS AFTER THE MOVES | 27 | 27 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +44 | +14.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 73 | 46 | 3 | 1.00 | +16 | +5.3 |
| MANOEUVRE | 12 | 12 | 3 | 1.00 | +48 | +15.8 |
| MISSILES IN THE MOVE | 18 | 10 | 3 | 1.00 | +14 | +4.8 |
| ONE OBJECTIVE FORMULA | 35 | 29 | 3 | 1.00 | +85 | +28.4 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +90 | +29.9 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +68 | +22.6 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 18 | 17 | 3 | 1.00 | +135 | +45.1 |
| CAST JOB | 7 | 7 | 2 | 0.67 | +8 | +4.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -38 | -18.8 |
| FEATURE BUFFS | 29 | 29 | 2 | 0.67 | +21 | +10.7 |
| FIGHT TO THE END | 3 | 3 | 2 | 0.67 | +176 | +87.9 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +350 | +175.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +101 | +50.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +29 | +14.5 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +27 | +13.6 |
| ONE FIGHT FORMULA | 33 | 21 | 2 | 0.67 | +5 | +2.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -318 | -159.2 |
| REDIRECT COUNTER | 9 | 6 | 2 | 0.67 | +40 | +20.1 |
| WAR ENGINE JOBS | 10 | 10 | 2 | 0.67 | -38 | -19.0 |
| WHOLE FIGHT REACTION | 4 | 4 | 2 | 0.67 | +8 | +3.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +10 | +10.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +9 | +9.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +166 | +165.9 |
| OVERRUNS AWAY | 3 | 2 | 1 | 0.33 | +9 | +9.4 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -4 | -3.7 |
| REFORMS TO MEET IT | 9 | 7 | 1 | 0.33 | +3 | +3.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +12 | +12.5 |
| RISK BY ARC | 12 | 9 | 1 | 0.33 | +27 | +27.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOTS IN THE MOVE | 120 | 95 | 1 | 0.33 | +107 | +106.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| TIED UP BY THE SUM | 3 | 1 | 1 | 0.33 | +9 | +9.4 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +41 | +40.9 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 47 | 46 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 11 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 9 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 36 | 34 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 22 | 21 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 15 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 11 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 125 | 125 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 18 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 261 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 77 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 250 | 247 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 276 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 5.33 | 26.7 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 4.33 | 70.1 |
| ARMY TABLE | rule | 1.67 | 2.67 | 39.3 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 196.9 |
| NO REASON | gate | 1.00 | - | 19.9 |
| CHARGE NOW FIRST | rule | - | 0.67 | 18.8 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 2.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 20.6 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 159.2 |
| WAR ENGINE JOBS | rule | 0.67 | - | 19.0 |
| AFTERMATH BAND | gate | - | 0.33 | 4.6 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.7 |
| RULE SWITCHED OFF | gate | - | 0.33 | 2.3 |
| TURN GATE | gate | 0.33 | - | 26.7 |

### Plans: wfr-a92c160-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 43 | 40 | 94% |
| Mine | move | 24.7 | 92% | 1684 | 0 | 0% |
| Mine | shoot | 13.0 | 36% | 280 | 313 | 112% |
| Mine | support | 0.7 | 100% | 9 | 0 | 0% |
| Opponent | charge | 2.7 | 62% | 287 | 269 | 94% |
| Opponent | move | 34.0 | 97% | 2287 | 0 | 0% |
| Opponent | shoot | 11.0 | 48% | 531 | 279 | 52% |

### Battle groups: wfr-a92c160-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 54 (7) | 54 | 0 | 20 | 29% | 2.8 | 0 (1) | 0 (1) | 89 (4) | 79 (5) | 0 (1) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 76 (5) | 76 | 0 | 100 | 60% | 3.0 | - | 81 (3) | 72 (2) | 91 (4) | 0 (1) |
| Mine | Hammer | 9 | 34 (9) | 19 | 15 | 33 | 11% | 2.6 | 0 (1) | 24 (4) | 56 (4) | 31 (7) | 42 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 52 | 0% | 1.1 | 0 (2) | 20 (5) | 0 (1) | 0 (3) | 17 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 20 | 80% | 3.0 | 0 (1) | 0 (2) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Chaff | 5 | 24 (5) | 24 | 0 | 95 | 20% | 1.2 | 118 (1) | 0 (4) | - | 24 (5) | - |
| Opponent | Character | 8 | 43 (8) | 43 | 0 | 21 | 50% | 2.2 | 68 (3) | 34 (2) | 23 (3) | 54 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 0 | 75% | 5.0 | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 16 (6) | 16 | 0 | 33 | 100% | - | 0 (3) | 32 (3) | - | 35 (2) | 7 (4) |
| Opponent | Holder | 9 | 51 (9) | 15 | 36 | 9 | 0% | 2.0 | 94 (3) | 45 (4) | 0 (2) | 45 (4) | 55 (5) |
| Opponent | Shooter | 2 | 124 (2) | 31 | 93 | 0 | 0% | 1.5 | 59 (1) | 194 (1) | - | 59 (1) | 194 (1) |
| Opponent | War machine | 3 | 52 (3) | 52 | 0 | 33 | 33% | 1.0 | 52 (3) | - | - | 0 (2) | 156 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: wfr-a92c160-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 249 | 2.0 | 1.0 | 124 | 0 | +124 | 0 of 2 | 1 of 2 | - | +124 |
| Mine | Chaos Dwarfs | 2 | 288 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 216 | 83 | 1.0 | 1.0 | 83 | 0 | +83 | 0 of 3 | 2 of 3 | - | +83 |
| Opponent | Empire of Man | 1 | 195 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 2 | 140 | 573 | 2.0 | 1.0 | 286 | 128 | +159 | 3 of 4 | 3 of 4 | - | +159 |
| **Opponent** | all armies | 3 | 158 | 382 | 1.3 | 1.0 | 286 | 128 | +159 | 3 of 4 | 3 of 4 | - | +159 |

### Effective charges: wfr-a92c160-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +122) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net +120) | 0 | 0 | 1 (net +84) | 0 | 1 (net +310) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: wfr-a92c160-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 85 | 72 | +122 | 122 | 42 | +80 | +93.5 |
| Mine | No odds | 2 | 72 | 71 | +64 | 87 | 23 | +64 | +89.6 |
| Mine | All fights | 3 | 76 | 71 | +83 | 99 | 29 | +69 | +91.1 |
| Opponent | Long shot (under 50%) | 2 | 426 | 291 | +120 | 412 | 279 | +133 | +31.2 |
| Opponent | 76-89% | 1 | 431 | 170 | +84 | 84 | 0 | +84 | +19.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 440 | 310 | +310 | 467 | 98 | +369 | +83.9 |
| Opponent | All fights | 4 | 430 | 266 | +159 | 344 | 164 | +180 | +41.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p38 | move | 19 | 4 (21%) | 2 (11%) | 1 (5%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

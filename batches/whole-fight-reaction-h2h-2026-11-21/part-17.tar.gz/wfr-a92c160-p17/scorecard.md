# Doctrine scorecard: wfr-a92c160-p17

### Scorecard: wfr-a92c160-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 5 | 1 | 3 | 1 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 2 | 6 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 336 |
| L0810 | 6 | 1 | Opponent | no | 12 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 300 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.5 | 2.5 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 310.3 |
| **Average** | | | Opponent | 67% | 6.0 | 2.0 | 1.3 | 3.7 | 0.0 | 0.0 | 0.0 | 228.3 |

### KPIs: wfr-a92c160-p17

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 13) | 54% (15 of 28) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (10 of 10); on the table 100% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 92% (11 of 12); on the table 100% | 86% (12 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 31% (11 of 36) | 36% (15 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (4 of 4) | 37% (11 of 30) | 44% (15 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (8 of 13) | 62% (8 of 13) |
| Points that never fought | lower | 52% (3144 of 5999) | 65% (3925 of 5998) | 59% (7069 of 11997) |
|   infantry points that never fought | lower | 54% (520 of 968) | 92% (1021 of 1113) | 74% (1541 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 77% (23 of 30) | 60% (15 of 25) | 69% (38 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.7 uses a game | 100% (3 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3812 of 5378) | 58% (2985 of 5181) | 64% (6797 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (44%) | 3.7 (41%) |
| MARCHED: its unit marched | 0.0 (0%) | 2.0 (24%) | 2.0 (22%) |
| IN COMBAT: engaged in combat | 0.7 (100%) | 1.7 (20%) | 2.3 (26%) |
| GONE: slain | 0.0 (0%) | 0.3 (4%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (8%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.7 | 1.7 | 2.7 | 5.0 | 0.0 | 1.3 |
| not cast | 2.3 | 0.3 | 3.3 | 9.0 | 4.0 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 3.7 (41%) | 2.3 (58%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.7 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (100%) | 0.7 (20%) | 2.3 (26%) | 0.7 (17%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.3 (8%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (86%) | 0.0 (0%) | 2.3 (70%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.3 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.7 a game | 1.3 a game |
| stood (cast and not dispelled) | - | 38% (3 of 8) | 38% (3 of 8) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 75% (66 of 88) | 74% (23 of 31) | 75% (89 of 119) |
|   cavalry | 82% (14 of 17) | - | 82% (14 of 17) |
|   chariot | 100% (8 of 8) | 67% (12 of 18) | 77% (20 of 26) |
|   infantry | 60% (6 of 10) | 80% (8 of 10) | 70% (14 of 20) |
|   war machine | 72% (38 of 53) | 100% (3 of 3) | 73% (41 of 56) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (23%) | 0.0 (0%) | 1.7 (17%) |
| CHARGED: it charged | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (12%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.7 (23%) | 0.7 (25%) | 2.3 (23%) |
| MOVED: a war machine that moved | 2.0 (27%) | 0.0 (0%) | 2.0 (20%) |
| NO TARGET IN RANGE | 0.3 (5%) | 1.3 (50%) | 1.7 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.3 (12%) | 0.7 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (9%) | 0.0 (0%) | 0.7 (7%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 3.7 | 70% | 9.7 pts | 97 pts |
| chariot | 7.0 | 1.0 | 86% | 3.2 pts | 22 pts |
| infantry | 4.7 | 2.0 | 64% | 9.6 pts | 45 pts |
| war machine | 14.0 | 15.7 | 62% | 35.5 pts | 497 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.7 | 3.0 |
| Charges that made contact a game | 1.3 | 3.7 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.40 declared, 0.40 contact (5 units) | 0.50 declared, 0.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.14 contact (22 units) | 0.41 declared, 0.41 contact (22 units) | 0.34 declared, 0.27 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | 100% (1 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (8 of 8) | - | - | 100% (8 of 8) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 25% (1 of 4) | 56% (5 of 9) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 50% (1 of 2); on the table 50% | 67% (4 of 6) | 52% | 77% (23 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | 0% (0 of 1); on the table 100% | 25% (6 of 24) | 71% | 40% (4 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 48% | 78% (7 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (10 of 10); on the table 100% | 67% (4 of 6) | 77% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 33% (1) | 25% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 17% (1 of 6) | 100% (11 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 19% (8 of 43) | 38% (5 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.7 |
| Movement | Points that never moved of their own | 310.3 | 228.3 |
| Movement | Fights charged into per game | 1.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 2 of 9, net +40 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 4, net +0 | 0 of 9 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +0 | 5 of 9, net +119 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (10 of 32) | 55% (11 of 20) |
| Shooting | Points destroyed by shooting units | 55.0 | 0.0 |
| Shooting | War machine shots | 12.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (24 of 38) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 216.7 | 43.3 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 0.3 | 4.7 |
| Magic | Wounds caused by other spells | 1.0 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 130.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 0.7 / 0.0 | 5.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 243.7 | 232.0 |
| Combat | Points run down | 0.0 | 25.7 |
| Combat | Net points per charged fight, damage counted | +175 | +78 |
| Combat | Net per 100 charger points, damage counted | +76.5 | +41.3 |
| Combat | First round won (charged fights) | 75% | 78% |
| Combat | Net points per charged fight | +125 | +83 |
| Combat | Net points per supported fight / lone fight | - / +125 | +0 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 4 of 9 |
| Game | Points lost | 542.3 | 574.3 |
| Game | VP from objectives | 523.3 | 830.0 |
| Game | Lone holders (player turns) | 2.5 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -253 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1117
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +62.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.7 | +260.1 | 0.0 | 25.7 | 21.3 | +343.8 | 0.0 | 299.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 128.3 | 0.3 | +0.0 | 0.0 | 55.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 21.7 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 10.7 | +205.6 | 638.3 | 128.3 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | 0.7 | +17.9 | 140.0 | 0.0 | 2.7 | +51.1 | 214.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +26.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 48.3 |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -486.3 | 0.0 | 126.0 | 21.0 | -1581.7 | 0.0 | 825.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 390.0 | 93.7 | 2.0 | +0.0 | 178.0 | 62.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 48.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 3.0 | +230.9 | 0.0 | 0.0 |
| COVER ONCE | 4.0 | -112.7 | 0.0 | 106.3 | 5.7 | -372.4 | 0.0 | 360.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -3.3 | 138.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -18.8 | 71.3 | 0.0 |
| EXACT ROUND | 2.3 | +67.9 | 430.0 | 156.7 | 3.0 | +8.2 | 178.0 | 62.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 430.0 | 156.7 | 3.3 | +8.5 | 178.0 | 62.0 |
| FALLS SHORT | - | - | - | - | 28.0 | +283.9 | 0.0 | 335.3 |
| FEATURE BUFFS | - | - | - | - | 1.7 | +16.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +9.5 | 180.0 | 156.7 | 1.3 | +101.6 | 25.7 | 0.0 |
| FIVE ACTION | 89.3 | +4500.2 | 2580.0 | 1078.0 | 98.3 | +5052.7 | 788.3 | 1681.7 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 63.0 | 5.3 | +0.0 | 0.0 | 37.3 |
| FOLLOW UP WEIGHED | 0.3 | +7.0 | 0.0 | 0.0 | 2.0 | +289.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +265.9 | 430.0 | 156.7 | 3.7 | +320.7 | 249.3 | 62.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 107.3 |
| FRIEND SHOOTS FIRST | 1.0 | -30.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -4.0 | 71.3 | 0.0 |
| GOAL WALK | 6.3 | +516.3 | 0.0 | 126.0 | 17.0 | +1188.3 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +9.1 | 189.0 | 21.7 |
| GUN MASK | 0.7 | +27.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 126.0 | 8.0 | +0.0 | 0.0 | 596.7 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 180.0 |
| HIS MOVE AND SHOT | 5.7 | -61.4 | 0.0 | 0.0 | 2.7 | -93.8 | 0.0 | 228.3 |
| HIS MOVE AS HE DECIDES | 48.3 | +15.7 | 382.7 | 0.0 | 30.0 | +9.0 | 611.7 | 0.0 |
| HIS MOVE WHY | 11.7 | +0.0 | 0.0 | 134.7 | 28.3 | +0.0 | 0.0 | 328.0 |
| HIS ONE MOVE | 16.0 | +56.8 | 0.0 | 134.7 | 29.7 | +30.4 | 0.0 | 243.3 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 306.7 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 9.3 | +0.0 | 0.0 | 25.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.3 | +871.7 | 0.0 | 378.3 | 65.7 | +4555.5 | 0.0 | 886.3 |
| HIS SHOTS BY HIS RUN | 24.3 | +451.8 | 0.0 | 286.3 | 60.0 | +1834.4 | 0.0 | 955.7 |
| HIS TURN DENIED | - | - | - | - | 2.7 | +155.5 | 182.0 | 62.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 0.0 | 23.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +700.3 | 0.0 | 0.0 | 13.7 | +1044.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -26.6 | 250.0 | 156.7 | 3.0 | -82.4 | 249.3 | 62.0 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +67.8 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +182.4 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -225.6 | 0.0 | 180.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | -119.4 | 71.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 48.3 | 210.0 | 4.7 | +0.0 | 114.7 | 30.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +20.0 | 25.7 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +0.2 | 430.0 | 156.7 | 1.3 | +0.4 | 110.7 | 62.0 |
| LOST CHARGE | 0.3 | -1.6 | 180.0 | 63.0 | - | - | - | - |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 25.7 | 2.7 | +16.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +28.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +76.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +27.3 | 0.0 | 180.0 |
| MARCH OVER CASTS | - | - | - | - | 1.7 | +152.2 | 0.0 | 180.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +48.7 | 0.0 | 0.0 | 4.3 | +83.2 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +41.0 | 0.0 | 0.0 | 7.0 | +98.5 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 1.3 | +31.5 | 0.0 | 0.0 | 10.7 | +119.4 | 0.0 | 360.0 |
| MOVE ORDER | - | - | - | - | 4.7 | +0.0 | 21.7 | 37.3 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.7 | +282.0 | 0.0 | 0.0 | 4.3 | +631.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.7 | +370.8 | 0.0 | 160.3 | 8.7 | +408.9 | 0.0 | 74.7 |
| NEXT CHARGE BY LIST | 3.3 | +270.1 | 140.0 | 0.0 | 2.7 | +299.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.3 | -127.7 | 360.0 | 156.7 | 2.7 | -111.2 | 249.3 | 62.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -152.7 | 0.0 | 67.3 | 3.0 | -92.4 | 0.0 | 70.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -88.6 | 0.0 | 0.0 | 5.3 | -129.5 | 0.0 | 180.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +13.6 | 71.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.7 | -31.6 | 0.0 | 0.0 | 8.0 | -66.1 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +4.9 | 70.0 | 0.0 | 1.0 | +15.1 | 164.3 | 0.0 |
| PATHS CROSS | 0.3 | +2.4 | 0.0 | 0.0 | 1.0 | +11.4 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.5 | 0.0 | 180.0 |
| PLAN RESULT | 41.0 | +1357.5 | 1018.3 | 823.3 | 49.0 | +413.7 | 134.3 | 913.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.7 | -107.2 | 0.0 | 0.0 | 4.0 | -94.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -3.5 | 0.0 | 0.0 | 0.3 | -28.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.7 | +1205.1 | 1080.0 | 86.7 | 21.7 | +1534.9 | 0.0 | 628.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +43.3 | 0.0 | 333.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +5.9 | 0.0 | 0.0 | 1.3 | +168.1 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -1.8 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +12.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | -13.6 | 430.0 | 156.7 | 3.0 | -18.6 | 249.3 | 62.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -9.8 | 0.0 | 0.0 | 0.7 | -8.0 | 110.7 | 62.0 |
| RUN DOWN | 1.0 | -10.0 | 0.0 | 93.7 | 2.0 | -16.3 | 249.3 | 62.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -11.6 | 70.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -176.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +10.9 | 0.0 | 134.7 | 0.3 | +5.4 | 0.0 | 180.0 |
| SET CREDITED ONCE | 1.7 | -19.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.3 | -16.8 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +44.9 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +66.5 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.7 | +0.0 | 0.0 | 128.3 | 6.0 | +0.0 | 0.0 | 186.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +7.6 | 0.0 | 0.0 | 2.7 | +78.5 | 25.7 | 180.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 3.3 | -299.3 | 1220.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 17.7 | -2.4 | 0.0 | 302.3 | 45.7 | -218.0 | 0.0 | 991.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.3 | +963.6 | 0.0 | 288.7 | 6.7 | +228.8 | 0.0 | 208.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +44.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +6.7 | 0.0 | 0.0 | 5.7 | +92.7 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 1.7 | -27.9 | 430.0 | 156.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 134.7 | 11.7 | +0.0 | 0.0 | 267.3 |
| STAND AND SHOOT | 0.3 | -2.2 | 0.0 | 0.0 | 0.7 | -11.5 | 97.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 25.7 | 0.0 |
| STANDS STILL | 60.0 | +0.0 | 2150.0 | 526.0 | 28.7 | +0.0 | 539.0 | 769.0 |
| STAY WORTH | 38.0 | +322.4 | 2150.0 | 383.3 | 9.0 | +110.0 | 387.3 | 538.3 |
| STOPS | - | - | - | - | 0.3 | +18.3 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 3.0 | +36.5 | 0.0 | 0.0 | 5.3 | +471.6 | 0.0 | 59.0 |
| SUPPORT WORKED OUT | 3.0 | +36.5 | 0.0 | 0.0 | 5.3 | +471.6 | 0.0 | 59.0 |
| SURE REACH TOGETHER | 0.3 | +23.2 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -49.1 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 37.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 180.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 393.3 | 47.7 | +0.0 | 0.0 | 635.7 |
| TIED UP BY THE SUM | 0.3 | +27.3 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 47.0 | +492.8 | 0.0 | 290.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -14.8 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -3.0 | 0.0 | 0.0 | 1.0 | +42.1 | 43.3 | 62.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +49.6 | 0.0 | 180.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -246.3 | 0.0 | 0.0 | 1.7 | -148.6 | 0.0 | 360.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +42.4 | 71.3 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.0 | +124.9 | 63.0 | 360.0 |
| WOUNDS ON THE RANKS | 3.3 | +47.8 | 0.0 | 0.0 | 6.0 | +216.6 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 235 | 235 | 161 | 53.67 | +0 | +0.0 |
| HIS SHOT LIST | 297 | 291 | 78 | 26.00 | +1801 | +23.1 |
| HIS MOVE WHY | 120 | 120 | 67 | 22.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 253 | 250 | 61 | 20.33 | +1076 | +17.6 |
| HOLDER ASSIGNMENT | 64 | 64 | 59 | 19.67 | +3441 | +58.3 |
| ARMY TABLE | 87 | 87 | 57 | 19.00 | +1714 | +30.1 |
| HIS ONE MOVE | 137 | 136 | 44 | 14.67 | +0 | +0.0 |
| SHOT RISK POINTS | 190 | 188 | 37 | 12.33 | +1003 | +27.1 |
| FIVE ACTION | 563 | 555 | 33 | 11.00 | +971 | +29.4 |
| TIME ON OUR SIDE | 141 | 129 | 32 | 10.67 | +36 | +1.1 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| LEGAL CHARGES ONLY | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -735 | -36.8 |
| GOAL WALK | 70 | 70 | 18 | 6.00 | +1015 | +56.4 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 24 | 23 | 16 | 5.33 | +691 | +43.2 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| NEXT CHARGE BY LIST | 18 | 17 | 12 | 4.00 | +512 | +42.7 |
| THE RISK READS HIS RUN | 36 | 36 | 11 | 3.67 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SUPPORT ADDS | 25 | 25 | 10 | 3.33 | +131 | +13.1 |
| SUPPORT WORKED OUT | 25 | 25 | 10 | 3.33 | +131 | +13.1 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 18 | 18 | 9 | 3.00 | +485 | +53.9 |
| QUARTER ODDS | 109 | 104 | 9 | 3.00 | +413 | +45.9 |
| CHARGE NOW FIRST | 14 | 14 | 8 | 2.67 | -302 | -37.7 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 8 | 2.67 | +130 | +16.2 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 8 | 2.67 | +72 | +9.1 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 7 | 2.33 | +54 | +7.7 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +890 | +127.2 |
| IDLE COST | 47 | 41 | 7 | 2.33 | +38 | +5.5 |
| CHARGE LOSSES | 104 | 103 | 6 | 2.00 | +441 | +73.5 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 6 | 2.00 | -604 | -100.6 |
| STAY WORTH | 141 | 131 | 5 | 1.67 | +27 | +5.3 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -358 | -89.5 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +42 | +10.4 |
| RISK BY ARC | 15 | 15 | 4 | 1.33 | +21 | +5.4 |
| WOUNDS ON THE RANKS | 28 | 28 | 4 | 1.33 | +97 | +24.1 |
| CHAFF IN THE MOVE | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 16 | 16 | 3 | 1.00 | +66 | +21.9 |
| HIS TURN DENIED | 8 | 8 | 3 | 1.00 | +37 | +12.2 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MANOEUVRE | 13 | 13 | 3 | 1.00 | +103 | +34.4 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +146 | +48.5 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -82 | -27.3 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +49 | +16.3 |
| SHOTS AFTER THE MOVES | 21 | 21 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 84 | 71 | 2 | 0.67 | +27 | +13.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +84 | +42.2 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.67 | +20 | +10.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 81 | 64 | 2 | 0.67 | +31 | +15.4 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 24 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +74 | +36.9 |
| WHOLE FIGHT DANGER | 15 | 14 | 2 | 0.67 | +85 | +42.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +187 | +186.9 |
| CANNON PLANNED TARGET | 35 | 35 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -14 | -14.3 |
| COVER ONCE | 29 | 22 | 1 | 0.33 | +22 | +21.7 |
| FALL BACK GOOD ORDER | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +84 | +83.5 |
| HUNT IN PAIRS | 3 | 3 | 1 | 0.33 | +25 | +25.0 |
| MAX FOR POSITIONING | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 25 | 17 | 1 | 0.33 | +13 | +12.6 |
| MISSILES NEXT TURN | 36 | 23 | 1 | 0.33 | +6 | +6.3 |
| NEARER NOT NEEDED | 52 | 51 | 1 | 0.33 | +22 | +21.7 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +8 | +7.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +39 | +38.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +48 | +48.3 |
| SET UP BY THE SET | 7 | 7 | 1 | 0.33 | +76 | +75.7 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.33 | +5 | +5.4 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +23 | +23.2 |
| THE PROMISE ADDS | 2 | 2 | 1 | 0.33 | +8 | +8.5 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +8 | +8.2 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +20 | +20.5 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 47 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 16 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 7 | 7 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 24 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 103 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 18 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 32 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 270 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 59 | not checked | - | - | - | - |
| SHOT OR CHARGE | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 22 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 46 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 266 | 260 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 8 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 2.33 | 36.2 |
| CHARGE NOW FIRST | rule | 1.33 | 1.33 | 37.7 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 0.67 | 100.6 |
| ARMY TABLE | rule | - | 1.33 | 52.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 26.1 |
| JOINT CHARGE NOW | rule | - | 1.00 | 122.0 |
| MARCH OF THE TABLE | rule | - | 1.00 | 27.3 |
| NO REASON | gate | - | 0.67 | 41.6 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 14.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.1 |

### Plans: wfr-a92c160-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 245 | 284 | 116% |
| Mine | move | 26.0 | 95% | 1131 | 0 | 0% |
| Mine | shoot | 13.0 | 51% | 580 | 1073 | 185% |
| Opponent | charge | 3.3 | 70% | 367 | 258 | 70% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 39.0 | 96% | 2104 | 0 | 0% |
| Opponent | shoot | 3.0 | 44% | 240 | 155 | 65% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Packages: hunt the guns, wfr-a92c160-p17

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 547 | 0 | 0% | 232 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 650 |
| Vampire Counts | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 547 | 0 | 0% | 45 |

### Battle groups: wfr-a92c160-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 34 (12) | 34 | 0 | 26 | 67% | 3.0 | 0 (4) | 0 (3) | 72 (3) | 52 (6) | 0 (4) |
| Mine | Fast Hammer | 5 | 23 (5) | 0 | 23 | 42 | 60% | 2.5 | 0 (3) | 0 (1) | 88 (1) | 39 (3) | 0 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 0 | 25% | 2.7 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 46 (5) | 24 | 22 | 72 | 0% | 1.4 | 0 (1) | 37 (2) | 81 (2) | 46 (5) | - |
| Mine | War machine | 11 | 49 (11) | 49 | 0 | 36 | 9% | 1.4 | 84 (5) | 20 (6) | - | 0 (2) | 60 (9) |
| Mine | Wizard | 2 | 109 (2) | 109 | 0 | 0 | 50% | 3.0 | 219 (1) | 0 (1) | - | 219 (1) | 0 (1) |
| Opponent | Chaff | 5 | 42 (5) | 42 | 0 | 15 | 80% | 2.0 | 69 (3) | 0 (2) | - | 42 (5) | - |
| Opponent | Character | 11 | 22 (11) | 22 | 0 | 22 | 55% | 1.6 | 0 (3) | 22 (5) | 37 (3) | 14 (5) | 26 (6) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 94 (6) | 52 | 42 | 15 | 17% | 2.0 | 94 (3) | 95 (3) | - | 156 (4) | 23 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 39 (4) | 39 | 0 | 69 | 25% | 2.3 | 97 (2) | 0 (1) | 0 (1) | 56 (3) | 0 (1) |
| Opponent | Holder | 4 | 145 (4) | 16 | 129 | 23 | 75% | 4.0 | - | 0 (2) | 269 (2) | 189 (3) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: wfr-a92c160-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 272 | 167 | 1.3 | 1.0 | 125 | 0 | +125 | 2 of 4 | 3 of 4 | - | +125 |
| Opponent | Grand Cathay | 1 | 332 | 339 | 2.0 | 1.0 | 170 | 0 | +170 | 0 of 2 | 1 of 2 | - | +170 |
| Opponent | Skaven | 1 | 189 | 77 | 2.0 | 1.0 | 38 | 0 | +38 | 1 of 2 | 2 of 2 | - | +38 |
| Opponent | Vampire Counts | 1 | 0 | 559 | 5.0 | 1.4 | 112 | 46 | +66 | 3 of 5 | 4 of 5 | +0 | +82 |
| **Opponent** | all armies | 3 | 174 | 325 | 3.0 | 1.2 | 108 | 26 | +83 | 4 of 9 | 7 of 9 | +0 | +93 |

### Effective charges: wfr-a92c160-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 4 | 0 | 0 | 2 (net +0) | 1 (net +500) | 0 | 1 (net +0) | 0 | 50% (2 of 4) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +125) | 0 | 1 (net +214) | 0 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +77) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 5 | 1 (net +80) | 0 | 0 | 1 (net -56) | 0 | 3 (net +101) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: wfr-a92c160-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 185 | 292 | +0 | 143 | 44 | +99 | +53.8 |
| Mine | 76-89% | 1 | 380 | 210 | +500 | 500 | 0 | +500 | +131.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 164 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 4 | 228 | 245 | +125 | 197 | 22 | +175 | +76.5 |
| Opponent | Long shot (under 50%) | 2 | 22 | 252 | +40 | 62 | 22 | +40 | +177.8 |
| Opponent | 76-89% | 2 | 196 | 128 | +34 | 133 | 93 | +40 | +20.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 251 | 195 | +119 | 119 | 11 | +108 | +42.8 |
| Opponent | All fights | 9 | 188 | 193 | +83 | 110 | 32 | +78 | +41.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p17 | move | 18 | 4 (22%) | 3 (17%) | 2 (11%) | 12 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

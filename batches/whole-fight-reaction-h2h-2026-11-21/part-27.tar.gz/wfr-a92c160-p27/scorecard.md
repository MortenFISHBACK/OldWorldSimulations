# Doctrine scorecard: wfr-a92c160-p27

### Scorecard: wfr-a92c160-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1258 |
| L0421 | 1 | 1 | Mine | no | 10 | 4 | 2 | 3 | 0 | 0 | 0 | 139 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 5.7 | 3.0 | 1.0 | 2.7 | 0.3 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.0 | 3.7 | 0.0 | 0.0 | 0.0 | 676.0 |

### KPIs: wfr-a92c160-p27

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 50% (3 of 6) | 18% (3 of 17) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | - | - |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 17% (1 of 6) | 33% (6 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 62% (5 of 8) | 25% (1 of 4) | 50% (6 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 80% (4775 of 5998) | 86% (5182 of 5999) | 83% (9957 of 11997) |
|   infantry points that never fought | lower | 95% (1359 of 1424) | 86% (1464 of 1703) | 90% (2823 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 65% (17 of 26) | 65% (32 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2895 of 5120) | 63% (2946 of 4677) | 60% (5841 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (29%) | 0.7 (40%) | 1.3 (33%) |
| MARCHED: its unit marched | 0.3 (14%) | 0.3 (20%) | 0.7 (17%) |
| IN COMBAT: engaged in combat | 0.3 (14%) | 0.0 (0%) | 0.3 (8%) |
| GONE: slain | 0.7 (29%) | 0.0 (0%) | 0.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (14%) | 0.7 (40%) | 1.0 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.0 | 2.0 | 1.3 | 0.3 |
| not cast | 3.0 | 4.0 | 4.0 | 2.7 | 11.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (58%) | 1.3 (33%) | 0.3 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (17%) | 0.3 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (8%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (22%) | 0.7 (17%) | 0.7 (17%) | 0.7 (25%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (22%) | 0.3 (8%) | 1.0 (25%) | 0.3 (12%) | 2.0 (17%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (56%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.3 (80%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (43 of 76) | 72% (71 of 98) | 66% (114 of 174) |
|   cavalry | 58% (7 of 12) | 0% (0 of 7) | 37% (7 of 19) |
|   character | 50% (5 of 10) | 71% (15 of 21) | 65% (20 of 31) |
|   chariot | 44% (7 of 16) | 50% (6 of 12) | 46% (13 of 28) |
|   infantry | 17% (2 of 12) | 65% (13 of 20) | 47% (15 of 32) |
|   war machine | 85% (22 of 26) | 97% (37 of 38) | 92% (59 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (36%) | 1.3 (15%) | 5.3 (27%) |
| CHARGED: it charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (39%) | 5.3 (59%) | 9.7 (48%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (21%) | 1.7 (19%) | 4.0 (20%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 1.0 | 71% | 11.3 pts | 26 pts |
| character | 7.0 | 3.7 | 67% | 16.6 pts | 117 pts |
| chariot | 4.3 | 4.7 | 62% | 14.7 pts | 64 pts |
| infantry | 7.7 | 3.7 | 65% | 18.7 pts | 144 pts |
| war machine | 19.7 | 17.0 | 66% | 24.7 pts | 486 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 0.0 | 0.7 |
| Charges that made contact a game | 0.3 | 0.0 | 0.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.05 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.07 declared, 0.02 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character in a unit | 90% (9 of 10) | 50% (1 of 2) | - | 83% (10 of 12) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 67% (2 of 3) | 71% (5 of 7) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 62% (5 of 8) | 40% (2 of 5) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | - | 42% (5 of 12) | 69% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 88% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 17% (1 of 6) | 82% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 25% (1 of 4) | - |
| Strategy | Shoot objectives carried out (shot that target) | 66% (19 of 29) | 67% (33 of 49) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 20% (2 of 10) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 3.7 |
| Movement | Points that never moved of their own | 173.0 | 676.0 |
| Movement | Fights charged into per game | 0.3 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net +0 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.0 | 11.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (10 of 21) | 63% (22 of 35) |
| Shooting | Points destroyed by shooting units | 132.3 | 343.0 |
| Shooting | War machine shots | 7.3 | 12.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 43% (16 of 37) |
| Shooting | Points destroyed by war machines | 176.0 | 21.7 |
| Magic | Magic missiles cast | 0.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 70.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 1.3 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -617 | - |
| Combat | Net per 100 charger points, damage counted | -182.1 | - |
| Combat | First round won (charged fights) | 0% | - |
| Combat | Net points per charged fight | +0 | - |
| Combat | Net points per supported fight / lone fight | - / +0 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | - |
| Game | Points lost | 519.7 | 775.3 |
| Game | VP from objectives | 1046.7 | 726.7 |
| Game | Lone holders (player turns) | 5.7 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +542 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1295
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 16.0 | +294.6 | 0.0 | 299.3 | 13.0 | +9.0 | 0.0 | 270.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 43.3 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 2.3 | +0.0 | 707.7 | 31.7 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.3 | +599.7 | 1368.7 | 253.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +8.9 | 0.0 | 0.0 | 0.7 | +6.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +1.9 | 0.0 | 12.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.0 | -793.9 | 0.0 | 582.7 | 7.3 | -426.9 | 0.0 | 793.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 146.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 2.3 | -47.5 | 0.0 | 135.0 | 2.7 | -163.7 | 0.0 | 360.0 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 92.7 | 0.0 |
| DENIED BY THE FIGHT | 0.7 | -14.7 | 180.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.3 | -23.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +6.0 | 198.3 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +28.3 | 198.3 | 0.0 | - | - | - | - |
| FALLS SHORT | 7.0 | +108.2 | 0.0 | 296.7 | 9.0 | +135.3 | 0.0 | 409.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +1.3 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 94.0 | +6116.9 | 2001.7 | 1482.7 | 87.0 | +5786.3 | 4610.0 | 2058.3 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 193.3 | 2.7 | +0.0 | 0.0 | 396.7 |
| FOUR ROUNDS | 1.3 | +220.6 | 198.3 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -24.0 | 21.7 | 103.3 | - | - | - | - |
| GOAL WALK | 10.3 | +1513.6 | 0.0 | 250.0 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +22.9 | 35.3 | 0.0 | 2.0 | +0.9 | 0.0 | 21.7 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 386.7 | 3.7 | +0.0 | 0.0 | 610.0 |
| HIS CHARGE LIST | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 193.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -12.3 | 0.0 | 0.0 | 3.0 | -42.9 | 0.0 | 91.7 |
| HIS MOVE AS HE DECIDES | 29.3 | +11.7 | 602.0 | 0.0 | 38.3 | +13.0 | 936.0 | 0.0 |
| HIS MOVE WHY | 11.0 | +0.0 | 0.0 | 43.3 | 23.7 | +0.0 | 0.0 | 175.7 |
| HIS ONE MOVE | 23.0 | -85.1 | 0.0 | 0.0 | 15.0 | +4.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 73.3 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 8.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.3 | +2145.0 | 0.0 | 792.7 | 29.3 | +1152.5 | 0.0 | 1027.3 |
| HIS SHOTS BY HIS RUN | 38.0 | +887.9 | 0.0 | 772.7 | 23.7 | +479.3 | 0.0 | 903.3 |
| HIS TURN DENIED | 0.3 | +30.3 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 27.3 |
| HOLDER ASSIGNMENT | 11.0 | +1051.4 | 0.0 | 0.0 | 9.3 | +918.7 | 0.0 | 81.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -65.6 | 198.3 | 0.0 | - | - | - | - |
| IDLE COST | 8.3 | -125.6 | 0.0 | 215.0 | 9.0 | -117.3 | 0.0 | 415.3 |
| JOINT CHARGE NOW | 0.3 | -86.4 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 48.3 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 43.3 |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 1.0 | +85.2 | 0.0 | 103.3 | - | - | - | - |
| MANOEUVRE | 2.3 | +17.5 | 0.0 | 103.3 | 2.3 | -40.5 | 0.0 | 57.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +33.2 | 0.0 | 193.3 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +23.2 | 0.0 | 193.3 | - | - | - | - |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +185.0 | 0.0 | 103.3 | - | - | - | - |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 2.0 | +30.0 | 0.0 | 0.0 | 1.3 | +10.7 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 2.7 | +25.5 | 0.0 | 193.3 | 2.7 | +8.7 | 0.0 | 360.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.7 | +65.3 | 0.0 | 193.3 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -93.3 | 0.0 | 193.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +738.3 | 0.0 | 0.0 | 0.7 | +37.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +232.4 | 0.0 | 0.0 | 5.7 | +222.2 | 0.0 | 13.7 |
| NEXT CHARGE BY LIST | 4.0 | +615.1 | 21.7 | 103.3 | 0.7 | +37.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -17.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.0 | -62.8 | 198.3 | 0.0 | - | - | - | - |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -199.6 | 0.0 | 78.0 | 3.0 | -122.5 | 0.0 | 73.3 |
| ONE FIGHT FORMULA | 4.7 | -150.2 | 0.0 | 103.3 | 0.7 | -2.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | -26.9 | 0.0 | 0.0 | 4.3 | +87.8 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +14.8 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +674.2 | 455.0 | 1062.7 | 41.0 | +1759.7 | 1268.3 | 1157.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -245.6 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.0 | +2552.7 | 233.0 | 156.0 | 24.3 | +1816.8 | 1623.3 | 438.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +13.9 | 0.0 | 285.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 0.7 | +8.3 | 0.0 | 35.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 40.0 |
| RISK BY ARC | 1.0 | -23.9 | 180.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -9.2 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +15.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +128.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.0 | +85.2 | 0.0 | 103.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 198.3 | 16.0 | +0.0 | 0.0 | 275.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +51.0 | 360.0 | 206.7 | - | - | - | - |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 29.7 | +517.1 | 0.0 | 346.0 | 15.7 | +108.3 | 0.0 | 680.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +287.2 | 0.0 | 333.3 | 21.0 | +1374.4 | 0.0 | 296.7 |
| SPELL WORTH | - | - | - | - | 3.0 | +51.8 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 296.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 48.0 | +0.0 | 1803.3 | 802.7 | 55.3 | +0.0 | 4610.0 | 1184.3 |
| STAY WORTH | 27.0 | +220.1 | 1007.3 | 738.3 | 45.0 | +591.8 | 4332.0 | 819.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 3.7 | +84.6 | 0.0 | 0.0 | 3.3 | +812.5 | 0.0 | 41.0 |
| SUPPORT WORKED OUT | 3.7 | +84.6 | 0.0 | 0.0 | 3.3 | +812.5 | 0.0 | 41.0 |
| SURE REACH TOGETHER | 0.7 | +55.7 | 0.0 | 193.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 103.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 21.7 | 4.3 | +0.0 | 0.0 | 223.3 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 193.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 43.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 606.3 | 42.0 | +0.0 | 0.0 | 819.3 |
| TIED UP BY THE SUM | 0.3 | +50.9 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 24.3 | +300.1 | 269.3 | 293.3 | 14.0 | +207.2 | 593.3 | 197.3 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -255.4 | 0.0 | 386.7 | 1.7 | -280.1 | 0.0 | 540.0 |
| WHOLE FIGHT GAIN | 0.3 | +95.5 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 1.3 | +9.1 | 0.0 | 134.7 |

### Rule changes: wfr-a92c160-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 203 | 203 | 129 | 43.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +2640 | +46.3 |
| ARMY TABLE | 87 | 87 | 56 | 18.67 | +316 | +5.7 |
| HIS SHOT LIST | 233 | 220 | 45 | 15.00 | +709 | +15.8 |
| HIS MOVE WHY | 104 | 104 | 44 | 14.67 | +0 | +0.0 |
| HIS ONE MOVE | 114 | 113 | 41 | 13.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 185 | 178 | 39 | 13.00 | +418 | +10.7 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -966 | -48.3 |
| SHOT RISK POINTS | 136 | 131 | 19 | 6.33 | +274 | +14.4 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| IDLE COST | 52 | 47 | 14 | 4.67 | +74 | +5.3 |
| GOAL WALK | 40 | 38 | 13 | 4.33 | +976 | +75.1 |
| TIME ON OUR SIDE | 115 | 98 | 13 | 4.33 | +7 | +0.5 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 17 | 15 | 11 | 3.67 | +778 | +70.7 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 14 | 13 | 10 | 3.33 | +767 | +76.7 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FIVE ACTION | 543 | 529 | 9 | 3.00 | +505 | +56.1 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 8 | 2.67 | -737 | -92.1 |
| QUARTER ODDS | 145 | 142 | 8 | 2.67 | +477 | +59.6 |
| THE RISK READS HIS RUN | 36 | 36 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 216 | 195 | 6 | 2.00 | +159 | +26.5 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| SUPPORT ADDS | 21 | 19 | 5 | 1.67 | +610 | +122.0 |
| SUPPORT WORKED OUT | 21 | 19 | 5 | 1.67 | +610 | +122.0 |
| CANNON PLANNED TARGET | 57 | 57 | 4 | 1.33 | -384 | -96.0 |
| CHARGE LOSSES | 79 | 76 | 4 | 1.33 | +649 | +162.1 |
| FOUR ROUNDS | 4 | 4 | 4 | 1.33 | +316 | +79.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +42 | +10.5 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| CAST JOB | 4 | 4 | 3 | 1.00 | +16 | +5.2 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +18 | +6.0 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +159 | +52.9 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +51 | +17.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 3 | 1.00 | +55 | +18.4 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 48 | 42 | 2 | 0.67 | +22 | +10.8 |
| HIS MOVE AND SHOT | 12 | 12 | 2 | 0.67 | +21 | +10.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MANOEUVRE | 14 | 14 | 2 | 0.67 | +53 | +26.3 |
| REDIRECT COUNTER | 3 | 2 | 2 | 0.67 | +99 | +49.6 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +46 | +23.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +102 | +51.1 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -26 | -13.0 |
| COVER ONCE | 15 | 10 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 3 | 3 | 1 | 0.33 | +9 | +9.4 |
| FALL BACK GOOD ORDER | 4 | 4 | 1 | 0.33 | +55 | +55.1 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -259 | -259.1 |
| ONE OBJECTIVE FORMULA | 20 | 13 | 1 | 0.33 | +28 | +28.1 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SET UP BY THE SET | 2 | 2 | 1 | 0.33 | +358 | +358.4 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 107 | 77 | 1 | 0.33 | +8 | +8.5 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +19 | +18.7 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +207 | +207.3 |
| CANNON PLAN MISSED | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 24 | 24 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 48 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 15 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 26 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 6 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 6 | 6 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 86 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 10 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 16 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEARER NOT NEEDED | 33 | 31 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 8 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 247 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 76 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 20 | 20 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 28 | 18 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 310 | 303 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 16 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 15 | 15 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 3.00 | 49.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | - | 92.1 |
| ARMY TABLE | rule | 1.00 | 0.67 | 121.5 |
| NO REASON | gate | 1.00 | - | 59.6 |
| CANNON PLANNED TARGET | rule | - | 0.67 | 192.0 |
| WAR ENGINE JOBS | rule | 0.67 | - | 13.0 |
| AFTERMATH BAND | gate | 0.33 | - | 2.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 18.2 |
| JOINT CHARGE NOW | rule | 0.33 | - | 259.1 |
| PATHS CROSS | rule | 0.33 | - | 6.7 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |

### Plans: wfr-a92c160-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 175 | 185 | 106% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 31.0 | 95% | 2244 | 0 | 0% |
| Mine | shoot | 8.7 | 58% | 165 | 506 | 306% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 25.0 | 88% | 1205 | 0 | 0% |
| Opponent | shoot | 14.3 | 67% | 1321 | 1760 | 133% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 24 (11) | 24 | 0 | 23 | 18% | 2.1 | 44 (5) | 16 (4) | 0 (2) | 35 (7) | 12 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 0 | 100% | - | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 22 (8) | 7 | 15 | 37 | 25% | 2.2 | 0 (2) | 26 (6) | - | 37 (5) | 7 (3) |
| Mine | Holder | 4 | 70 (4) | 0 | 70 | 27 | 75% | 1.0 | 0 (1) | 92 (3) | - | 259 (1) | 0 (3) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 45 (14) | 45 | 0 | 32 | 50% | 2.9 | 61 (10) | 0 (3) | - | 59 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 79 (4) | 0 | 79 | 6 | 100% | - | - | 79 (4) | - | 79 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 62 (6) | 33 | 29 | 40 | 17% | 2.4 | 104 (2) | 0 (1) | 55 (3) | 62 (6) | - |
| Opponent | Holder | 3 | 38 (3) | 0 | 38 | 0 | 100% | - | - | 59 (2) | 0 (1) | 0 (1) | 54 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 67 | 75% | 3.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 7 (9) | 7 | 0 | 71 | 11% | 1.0 | 7 (9) | - | - | 0 (1) | 8 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: wfr-a92c160-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 202 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 378 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 1029 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 365 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: wfr-a92c160-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: wfr-a92c160-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 339 | 239 | +0 | 30 | 647 | -617 | -182.1 |
| Mine | All fights | 1 | 339 | 239 | +0 | 30 | 647 | -617 | -182.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p27 | move | 11 | 3 (27%) | 1 (9%) | 0 (0%) | 8 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

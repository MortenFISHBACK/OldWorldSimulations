# Doctrine scorecard: wfr-a92c160-p10

### Scorecard: wfr-a92c160-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 6 | 0 | 1 | 0 | 0 | 226 |
| L1923 | 3 | 1 | Opponent | yes | 13 | 2 | 1 | 2 | 0 | 0 | 0 | 325 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 5 | 3 | 5 | 0 | 0 | 0 | 68 |
| **Average** | | | Mine | 0% | 0.5 | 1.0 | 2.7 | 1.0 | 0.7 | 0.0 | 0.0 | 215.3 |
| **Average** | | | Opponent | 67% | 10.5 | 3.0 | 3.7 | 3.0 | 0.0 | 0.0 | 0.0 | 154.3 |

### KPIs: wfr-a92c160-p10

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 83% (5 of 6); on the table 83% | 75% (6 of 8); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | - | 71% (5 of 7); on the table 71% | 71% (5 of 7); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 75% (12 of 16); on the table 75% | 72% (13 of 18); on the table 72% |
| Magic missiles tried each own turn | 50%+ | 20% (6 of 30) | 22% (4 of 18) | 21% (10 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (6 of 17) | 22% (4 of 18) | 29% (10 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 25% (1491 of 5999) | 44% (2627 of 5999) | 34% (4118 of 11998) |
|   infantry points that never fought | lower | 86% (856 of 993) | 100% (1037 of 1037) | 93% (1893 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 77% (17 of 22) | 38% (6 of 16) | 61% (23 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 80% (4101 of 5151) | 28% (1244 of 4500) | 55% (5345 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (12%) | 4.7 (100%) | 5.7 (45%) |
| MARCHED: its unit marched | 1.3 (17%) | 0.0 (0%) | 1.3 (11%) |
| CHARGED: its unit charged | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 1.0 (12%) | 0.0 (0%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |
| GONE: slain | 1.7 (21%) | 0.0 (0%) | 1.7 (13%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (21%) | 0.0 (0%) | 1.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.3 | 1.0 | 3.3 | 0.0 |
| not cast | 6.7 | 0.7 | 5.0 | 12.7 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 5.7 (45%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (10%) | 0.0 (0%) | 0.7 (13%) | 0.7 (5%) | 0.0 (0%) |
| GONE: slain | 1.7 (25%) | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 1.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (20%) | 0.0 (0%) | 1.7 (33%) | 1.7 (13%) | 4.3 (22%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (45%) | 0.0 (0%) | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 33% (1 of 3) | 33% (1 of 3) |
| the unit moved after it | - | 100% (1 of 1) | 100% (1 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (31 of 50) | 47% (38 of 81) | 53% (69 of 131) |
|   cavalry | - | 73% (16 of 22) | 73% (16 of 22) |
|   character | 100% (6 of 6) | 0% (0 of 14) | 30% (6 of 20) |
|   chariot | 75% (3 of 4) | - | 75% (3 of 4) |
|   infantry | 52% (17 of 33) | 49% (22 of 45) | 50% (39 of 78) |
|   monster | 71% (5 of 7) | - | 71% (5 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (11%) | 0.0 (0%) | 0.7 (3%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (14%) | 2.0 (10%) |
| FLEEING: it fled or was fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (11%) | 0.3 (2%) | 1.0 (5%) |
| NO TARGET IN RANGE | 3.0 (47%) | 8.3 (58%) | 11.3 (55%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (11%) | 0.7 (5%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (16%) | 0.7 (5%) | 1.7 (8%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 2.3 (16%) | 2.3 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 2.3 | 72% | 6.9 pts | 42 pts |
| character | 2.0 | 0.3 | 83% | 8.1 pts | 16 pts |
| chariot | 1.0 | 1.0 | 67% | 23.3 pts | 23 pts |
| infantry | 14.7 | 7.7 | 64% | 7.0 pts | 103 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 6.7 | 4.7 |
| Charges that made contact a game | 2.0 | 4.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.21 contact (28 units) | 0.62 declared, 0.45 contact (29 units) | 0.46 declared, 0.33 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 75% (3 of 4) | 75% (3 of 4) | 29% (2 of 7) | 53% (8 of 15) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 83% (5 of 6) | - | - | 83% (5 of 6) |
| Monster | 0% (0 of 4) | 100% (3 of 3) | - | 43% (3 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 26% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 8% (1 of 12) | 3% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 42% (5 of 12) | 45% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 69% (9 of 13); on the table 69% | 0% (0 of 6) | 35% | 20% (2 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 61% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 70% (7) | 0% (0) | 54% (7) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.00 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 40% (8 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (3 of 11) | 39% (9 of 23) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 89% (8 of 9) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 3.0 |
| Movement | Points that never moved of their own | 215.3 | 154.3 |
| Movement | Fights charged into per game | 2.0 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 1 of 13, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 13, net +297 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 3 of 13, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 8 of 13, net +223 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (14 of 32) | 26% (12 of 46) |
| Shooting | Points destroyed by shooting units | 25.0 | 108.0 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.0 / 0.0 | 1.0 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 202.0 | 719.3 |
| Combat | Points run down | 0.0 | 341.0 |
| Combat | Net points per charged fight, damage counted | -164 | +173 |
| Combat | Net per 100 charger points, damage counted | -79.7 | +62.1 |
| Combat | First round won (charged fights) | 33% | 86% |
| Combat | Net points per charged fight | -167 | +163 |
| Combat | Net points per supported fight / lone fight | - / -167 | - / +163 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 6 | 6 of 14 |
| Game | Points lost | 1516.0 | 217.0 |
| Game | VP from objectives | 273.3 | 1313.3 |
| Game | Lone holders (player turns) | 0.5 | 10.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -2434 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1733
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: wfr-a92c160-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +55.6 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 0.0 |
| ARMY TABLE | 22.3 | -129.6 | 0.0 | 581.7 | 18.3 | +611.5 | 0.0 | 72.0 |
| BACKUP TARGETS | 0.3 | +2.2 | 0.0 | 0.0 | 1.0 | +5.7 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +4.8 | 0.0 | 0.0 | 1.0 | +6.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +6.9 | 0.0 | 198.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +18.7 | 0.0 | 49.3 | 0.7 | +8.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -6.1 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.7 | -1337.6 | 0.0 | 1315.7 | 5.3 | -125.1 | 0.0 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 4.3 | +0.0 | 663.0 | 180.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 11.3 | 14.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 18.3 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +37.5 | 0.0 | 0.0 |
| COVER ONCE | 12.3 | -440.4 | 0.0 | 560.3 | 4.0 | -216.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 61.7 | 7.3 | +33.6 | 0.0 | 23.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +43.5 | 184.0 | 180.0 |
| EXACT ROUND | 0.3 | -0.6 | 0.0 | 18.3 | 5.0 | +46.4 | 758.0 | 180.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 18.3 | 4.7 | +15.1 | 576.3 | 180.0 |
| FALLS SHORT | 9.3 | +88.2 | 0.0 | 578.7 | 7.3 | +103.0 | 0.0 | 0.0 |
| FEATURE BUFFS | 2.0 | +13.4 | 0.0 | 53.3 | 1.0 | +10.5 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 2.0 | +62.1 | 267.7 | 180.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 68.0 | +4072.0 | 100.0 | 2292.3 | 106.7 | +9362.3 | 2347.0 | 324.0 |
| FLANK NOT WEIGHED | 16.7 | +0.0 | 0.0 | 754.7 | 1.7 | +0.0 | 0.0 | 25.0 |
| FOCUS FIRE | 0.3 | +8.0 | 0.0 | 0.0 | 1.0 | +34.2 | 48.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +235.8 | 0.0 | 180.0 |
| FOUR ROUNDS | 0.3 | +6.1 | 0.0 | 18.3 | 7.0 | +409.4 | 931.7 | 180.0 |
| FREED FROM HIS FIGHT | 19.7 | +0.0 | 0.0 | 838.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -4.4 | 0.0 | 0.0 | 1.7 | -16.6 | 11.3 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +9.7 | 0.0 | 180.0 |
| GIVES UP | 0.3 | -1.1 | 0.0 | 18.3 | 0.7 | -18.9 | 24.7 | 0.0 |
| GOAL WALK | 10.0 | +763.1 | 0.0 | 286.7 | 5.7 | +662.1 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +11.5 | 0.0 | 61.7 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 177.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 14.0 | +0.0 | 0.0 | 557.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 1192.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 10.0 | +0.0 | 0.0 | 41.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 116.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.3 | -0.8 | 0.0 | 85.0 | 4.0 | -98.2 | 0.0 | 50.0 |
| HIS MOVE AS HE DECIDES | 48.7 | +15.7 | 274.0 | 0.0 | 32.7 | +9.0 | 1063.3 | 0.0 |
| HIS MOVE WHY | 12.0 | +0.0 | 0.0 | 530.3 | 39.0 | +0.0 | 0.0 | 230.0 |
| HIS ONE MOVE | 16.7 | +144.3 | 0.0 | 345.3 | 25.7 | -76.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 23.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 116.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.7 | +337.0 | 0.0 | 1694.7 | 23.0 | +312.6 | 0.0 | 44.0 |
| HIS SHOTS BY HIS RUN | 27.7 | +200.5 | 0.0 | 1142.0 | 31.0 | +285.3 | 0.0 | 144.0 |
| HIS TURN DENIED | 0.3 | +1.9 | 0.0 | 18.3 | 1.3 | +49.7 | 244.0 | 0.0 |
| HIS TURN RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 106.7 | 22.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.0 | +517.3 | 0.0 | 26.7 | 13.0 | +1113.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -0.8 | 0.0 | 18.3 | 6.7 | -221.4 | 832.7 | 180.0 |
| HUNT IN PAIRS | - | - | - | - | 2.3 | +382.6 | 0.0 | 180.0 |
| IDLE COST | 2.7 | -26.3 | 0.0 | 213.0 | 8.7 | -92.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +21.5 | 244.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 116.7 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 180.0 | 325.3 | 11.3 | +0.0 | 596.0 | 66.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +0.0 | 50.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +1.9 | 109.3 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.5 | 78.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -141.2 | 0.0 | 22.7 | - | - | - | - |
| MANOEUVRE | 2.3 | +1.0 | 0.0 | 83.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +44.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +33.7 | 0.0 | 99.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -13.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +69.7 | 0.0 | 24.7 | 2.7 | +57.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +47.0 | 0.0 | 180.0 | 3.0 | +28.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +53.5 | 0.0 | 378.0 | 4.0 | +23.0 | 0.0 | 0.0 |
| MOVE ORDER | 3.7 | +0.0 | 61.7 | 99.0 | 3.3 | +0.0 | 0.0 | 22.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +271.3 | 0.0 | 22.7 | 10.7 | +1433.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.0 | +380.4 | 0.0 | 334.0 | 13.0 | +474.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +82.8 | 0.0 | 22.7 | 7.7 | +890.9 | 11.3 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -2.8 | 0.0 | 18.3 | 6.3 | -319.9 | 901.7 | 180.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -70.8 | 0.0 | 112.0 | 6.0 | -200.5 | 13.3 | 25.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 13.3 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -13.9 | 0.0 | 11.3 | 7.3 | -181.3 | 0.0 | 180.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +42.9 | 0.0 | 26.7 | 5.3 | +10.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.3 | +107.0 | 39.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.7 | 0.0 | 18.3 | 2.3 | +77.4 | 333.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 32.3 | +222.8 | 25.0 | 1204.3 | 50.0 | +1375.3 | 618.7 | 454.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -367.8 | 0.0 | 11.3 | 11.7 | -616.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -4.4 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -61.5 | 0.0 | 0.0 |
| QUARTER ODDS | 13.0 | +1162.6 | 100.0 | 203.7 | 34.0 | +3903.5 | 1050.0 | 100.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.3 | +229.4 | 0.0 | 104.7 | 3.0 | +85.8 | 0.0 | 22.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 85.0 | 5.7 | +0.0 | 0.0 | 47.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +17.1 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 2.3 | -20.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 11.7 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +4.6 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | +4.8 | 0.0 | 18.3 | 4.7 | -77.3 | 637.7 | 180.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.3 | -106.3 | 393.0 | 180.0 |
| RUN DOWN | - | - | - | - | 5.3 | -36.6 | 721.7 | 180.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -11.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +21.1 | 0.0 | 85.0 | 1.3 | +81.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +2.9 | 13.3 | 0.0 |
| SELF MOVE SPELL | 1.7 | -3.3 | 0.0 | 108.7 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.3 | -128.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -11.9 | 0.0 | 0.0 | 2.7 | +37.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 188.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +36.3 | 50.0 | 0.0 | 2.7 | +84.2 | 257.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.7 | -57.8 | 261.7 | 0.0 |
| SHOT RISK POINTS | 13.3 | -60.8 | 0.0 | 972.7 | 14.7 | -43.7 | 0.0 | 100.0 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.0 | +182.7 | 0.0 | 367.0 | 14.3 | +122.8 | 0.0 | 202.0 |
| SPELL OFF EDGE | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +10.8 | 180.0 | 180.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 336.3 | 7.0 | +0.0 | 0.0 | 50.0 |
| STAND AND SHOOT | 0.3 | -0.3 | 0.0 | 18.3 | 1.3 | -15.7 | 223.3 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 18.7 | +0.0 | 100.0 | 403.3 | 50.0 | +0.0 | 1415.3 | 50.0 |
| STAY WORTH | 7.3 | +40.0 | 50.0 | 61.7 | 18.7 | +98.5 | 627.7 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +18.5 | 22.0 | 30.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.7 | +1085.6 | 0.0 | 181.3 | 6.0 | +173.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 9.7 | +1085.6 | 0.0 | 181.3 | 6.0 | +173.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.5 | 0.0 | 116.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -4.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 0.0 | 11.7 | - | - | - | - |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 365.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 265.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 266.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.7 | +0.0 | 0.0 | 1000.3 | 52.3 | +0.0 | 0.0 | 72.0 |
| TIED UP BY THE SUM | - | - | - | - | 3.3 | +337.3 | 240.0 | 0.0 |
| TIME ON OUR SIDE | 23.0 | +228.5 | 0.0 | 538.7 | 40.0 | +316.2 | 73.3 | 202.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 18.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -20.1 | 60.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.3 | 0.0 | 18.3 | 1.0 | +17.3 | 119.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -3.1 | 30.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -1273.2 | 0.0 | 788.3 | 0.7 | -14.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +13.9 | 0.0 | 142.7 | 0.3 | +5.4 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 244 | 244 | 170 | 56.67 | +0 | +0.0 |
| HIS MOVE WHY | 153 | 153 | 80 | 26.67 | +0 | +0.0 |
| ARMY TABLE | 122 | 122 | 62 | 20.67 | +2191 | +35.3 |
| HOLDER ASSIGNMENT | 60 | 60 | 54 | 18.00 | +2859 | +53.0 |
| FIVE ACTION | 524 | 506 | 44 | 14.67 | +3068 | +69.7 |
| LEGAL CHARGES ONLY | 44 | 44 | 44 | 14.67 | +0 | +0.0 |
| HIS ONE MOVE | 127 | 125 | 32 | 10.67 | +0 | +0.0 |
| HIS SHOT LIST | 182 | 175 | 32 | 10.67 | +66 | +2.1 |
| MOVE TO CHARGE COMPUTED | 44 | 40 | 27 | 9.00 | +1341 | +49.7 |
| HIS SHOTS BY HIS RUN | 176 | 165 | 26 | 8.67 | +78 | +3.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -814 | -31.3 |
| THE TABLE AGAIN | 33 | 33 | 26 | 8.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 22 | 7.33 | -2953 | -134.2 |
| MOVE ORDER | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| TIME ON OUR SIDE | 189 | 170 | 16 | 5.33 | +36 | +2.3 |
| GOAL WALK | 47 | 45 | 15 | 5.00 | +935 | +62.3 |
| NEXT CHARGE BY LIST | 27 | 27 | 15 | 5.00 | +1194 | +79.6 |
| SUPPORT ADDS | 47 | 44 | 14 | 4.67 | +404 | +28.9 |
| SUPPORT WORKED OUT | 47 | 44 | 14 | 4.67 | +404 | +28.9 |
| SHOT RISK POINTS | 84 | 83 | 13 | 4.33 | +49 | +3.8 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 33 | 33 | 12 | 4.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 9 | 3.00 | +146 | +16.2 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOUR ROUNDS | 22 | 21 | 8 | 2.67 | +132 | +16.5 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| TIED UP BY THE SUM | 10 | 9 | 8 | 2.67 | +184 | +23.0 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +65 | +13.0 |
| MAX FOR POSITIONING | 18 | 17 | 5 | 1.67 | +9 | +1.7 |
| QUARTER ODDS | 141 | 133 | 5 | 1.67 | +962 | +192.5 |
| REDIRECT COUNTER | 25 | 19 | 5 | 1.67 | +259 | +51.9 |
| CAST JOB | 5 | 5 | 4 | 1.33 | +4 | +1.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 6 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 51 | 48 | 4 | 1.33 | +367 | +91.7 |
| EXACT ROUND | 16 | 16 | 4 | 1.33 | +95 | +23.7 |
| FOCUS FIRE | 4 | 4 | 4 | 1.33 | +127 | +31.7 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +308 | +77.1 |
| STAY WORTH | 78 | 67 | 4 | 1.33 | +5 | +1.2 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -24 | -8.0 |
| CHARGE NOW FIRST | 13 | 13 | 3 | 1.00 | -157 | -52.3 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +708 | +235.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +135 | +44.9 |
| OVERRUNS AWAY | 8 | 8 | 3 | 1.00 | +57 | +18.9 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +206 | +68.6 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +14 | +4.6 |
| RISK BY ARC | 15 | 14 | 3 | 1.00 | +78 | +26.0 |
| SET UP BY THE SET | 9 | 9 | 3 | 1.00 | +143 | +47.6 |
| WHOLE FIGHT DANGER | 15 | 13 | 3 | 1.00 | +179 | +59.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +208 | +104.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 49 | 31 | 2 | 0.67 | +66 | +32.9 |
| FIGHT TO THE END | 6 | 6 | 2 | 0.67 | +28 | +13.8 |
| HIS MOVE AND SHOT | 13 | 13 | 2 | 0.67 | +5 | +2.4 |
| IDLE COST | 34 | 19 | 2 | 0.67 | +18 | +9.0 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +9 | +4.6 |
| OPENS UP | 4 | 3 | 2 | 0.67 | +90 | +44.9 |
| WOUNDS ON THE RANKS | 5 | 5 | 2 | 0.67 | +11 | +5.7 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +7 | +7.4 |
| FALL BACK GOOD ORDER | 15 | 15 | 1 | 0.33 | +20 | +19.5 |
| FEATURE BUFFS | 9 | 9 | 1 | 0.33 | +6 | +6.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +29 | +29.0 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 21 | 20 | 1 | 0.33 | +67 | +67.3 |
| HUNT IN PAIRS | 7 | 5 | 1 | 0.33 | +26 | +26.0 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +3 | +2.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 66 | 61 | 1 | 0.33 | +56 | +55.6 |
| NO DOUBLE ROUNDS | 20 | 19 | 1 | 0.33 | +37 | +36.6 |
| ONE OBJECTIVE FORMULA | 28 | 16 | 1 | 0.33 | +38 | +37.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -184 | -184.4 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +33 | +32.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOTS AFTER THE MOVES | 14 | 14 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 73 | 58 | 1 | 0.33 | +10 | +9.9 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +56 | +55.6 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -22 | -21.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +9 | +9.1 |
| BACKUP TARGETS | 4 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| FALLS SHORT | 50 | 38 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 61 | 58 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 42 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 37 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 10 | 10 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 13 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 33 | 33 | 0 | 0.00 | - | - |
| HIS TURN RUN | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 103 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 247 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 15 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 42 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 206 | 202 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 6 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 16 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 4.33 | 134.2 |
| JOB FIRST | gate | 2.67 | 4.33 | 24.1 |
| ARMY TABLE | rule | 1.67 | 1.00 | 25.1 |
| NO REASON | gate | - | 1.33 | 13.8 |
| CHAFF PASSED | rule | 0.67 | 0.33 | 8.0 |
| CHARGE NOW FIRST | rule | - | 1.00 | 52.3 |
| JOINT CHARGE NOW | rule | - | 1.00 | 34.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 252.5 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 13.2 |
| PURSUES BIG PREY | rule | - | 0.33 | 184.4 |
| SUPPORT NARROWED | rule | - | 0.33 | 21.7 |

### Plans: wfr-a92c160-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 0% | 12 | 0 | 0% |
| Mine | move | 28.7 | 84% | 1637 | 0 | 0% |
| Mine | shoot | 3.0 | 56% | 521 | 223 | 43% |
| Mine | support | 0.3 | 0% | 0 | 0 | - |
| Opponent | charge | 5.3 | 100% | 650 | 790 | 122% |
| Opponent | join | 2.7 | 100% | 118 | 0 | 0% |
| Opponent | move | 36.0 | 100% | 2458 | 0 | 0% |
| Opponent | shoot | 5.7 | 82% | 507 | 585 | 115% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 50% | 38% | 0% | - | 0% | 0% | 0% | 88% | 12% |
| Opponent | REDIRECT COUNTER | 3.0 | 44% | 25% | 25% | 100% | 67% | 0% | 0% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 73 (1) | 73 | 0 | 100 | 0% | 3.0 | - | 73 (1) | - | 73 (1) | - |
| Mine | Chaff | 7 | 18 (7) | 0 | 18 | 100 | 29% | 4.0 | 20 (6) | 0 (1) | - | 18 (7) | - |
| Mine | Character | 8 | 16 (8) | 16 | 0 | 93 | 0% | 2.6 | 0 (3) | 297 (1) | 0 (1) | 297 (1) | 0 (4) |
| Mine | Clean-up | 4 | 58 (4) | 0 | 58 | 0 | 100% | - | 93 (2) | 0 (1) | 0 (1) | 188 (1) | 0 (3) |
| Mine | Fast Hammer | 1 | 22 (1) | 22 | 0 | 115 | 0% | 3.0 | 22 (1) | - | - | - | 22 (1) |
| Mine | Hammer | 11 | 3 (11) | 3 | 0 | 90 | 0% | 2.0 | 10 (3) | 0 (7) | 0 (1) | 8 (4) | 0 (7) |
| Mine | Shooter | 3 | 38 (3) | 38 | 0 | 0 | 0% | 1.7 | 0 (2) | 115 (1) | - | 0 (1) | 58 (2) |
| Mine | Wizard | 2 | 40 (2) | 40 | 0 | 126 | 0% | 3.0 | 68 (1) | - | - | 68 (1) | - |
| Opponent | Chaff | 8 | 184 (8) | 45 | 138 | 27 | 50% | 1.0 | 252 (2) | 225 (4) | 0 (2) | 280 (5) | 0 (3) |
| Opponent | Character | 8 | 93 (8) | 93 | 0 | 21 | 25% | 2.0 | 90 (5) | 98 (3) | - | 139 (3) | 67 (5) |
| Opponent | Clean-up | 4 | 81 (4) | 81 | 0 | 0 | 75% | 1.0 | 0 (2) | 110 (2) | - | 0 (2) | 110 (2) |
| Opponent | Fast Hammer | 7 | 133 (7) | 133 | 0 | 6 | 43% | 2.5 | 11 (2) | 225 (5) | - | 158 (4) | 115 (3) |
| Opponent | Holder | 4 | 193 (4) | 34 | 159 | 0 | 0% | 1.8 | 350 (2) | - | 62 (2) | 350 (2) | 62 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: wfr-a92c160-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 540 | 5.0 | 1.0 | 108 | 308 | -200 | 4 of 5 | 1 of 5 | - | -200 |
| Mine | Skaven | 1 | 75 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 48 | 180 | 2.0 | 1.0 | 90 | 257 | -167 | 4 of 6 | 2 of 6 | - | -167 |
| Opponent | Tomb Kings of Khemri | 2 | 162 | 782 | 5.5 | 1.0 | 142 | 6 | +136 | 3 of 11 | 10 of 11 | - | +136 |
| Opponent | Vampire Counts | 1 | 0 | 785 | 3.0 | 1.0 | 262 | 0 | +262 | 3 of 3 | 2 of 3 | - | +262 |
| **Opponent** | all armies | 3 | 108 | 783 | 4.7 | 1.0 | 168 | 5 | +163 | 6 of 14 | 12 of 14 | - | +163 |

### Effective charges: wfr-a92c160-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 4 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 11 | 0 | 0 | 1 (net +297) | 0 | 3 (net +66) | 6 (net +167) | 1 | 10% (1 of 10) |
| Opponent | Vampire Counts | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +392) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 55 | 66 | +0 | 0 | 28 | -28 | -50.0 |
| Mine | No odds | 5 | 236 | 313 | -200 | 127 | 319 | -191 | -81.1 |
| Mine | All fights | 6 | 206 | 272 | -167 | 106 | 270 | -164 | -79.7 |
| Opponent | Long shot (under 50%) | 1 | 50 | 210 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 195 | 297 | +297 | 297 | 0 | +297 | +152.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 329 | 236 | +223 | 253 | 12 | +240 | +73.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 274 | 61 | +66 | 88 | 22 | +66 | +24.1 |
| Opponent | No odds | 1 | 195 | 185 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 14 | 278 | 197 | +163 | 184 | 12 | +173 | +62.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p10 | move | 24 | 3 (12%) | 2 (8%) | 8 (33%) | 13 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

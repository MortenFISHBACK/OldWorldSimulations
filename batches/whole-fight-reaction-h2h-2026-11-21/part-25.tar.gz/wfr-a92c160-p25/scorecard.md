# Doctrine scorecard: wfr-a92c160-p25

### Scorecard: wfr-a92c160-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 1 | 2 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 2 | - | 2 | 4 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 1 | - | 0 | 7 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 2.7 | - | 0.0 | 1.3 | 0.0 | 0.0 | 0.0 | 18.3 |
| **Average** | | | Opponent | 0% | 1.3 | 2.0 | 0.7 | 5.7 | 0.3 | 0.0 | 0.0 | 131.3 |

### KPIs: wfr-a92c160-p25

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 11) | 0% (0 of 16) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 39% (35 of 90) | 46% (11 of 24) | 40% (46 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (35 of 90) | 46% (11 of 24) | 40% (46 of 114) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (5 of 6) | 83% (5 of 6) |
| Points that never fought | lower | 84% (4809 of 5700) | 98% (5780 of 5899) | 91% (10589 of 11599) |
|   infantry points that never fought | lower | 86% (2331 of 2703) | 100% (1219 of 1219) | 91% (3550 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 27% (4 of 15) | 80% (20 of 25) | 60% (24 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.0 uses a game | 75% (3 of 4); 3.7 uses a game | 86% (6 of 7); 3.8 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 1.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 26% (1055 of 4077) | 72% (3517 of 4883) | 51% (4572 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.3 (73%) | 3.0 (69%) | 16.3 (72%) |
| MARCHED: its unit marched | 3.3 (18%) | 1.3 (31%) | 4.7 (21%) |
| STUPIDITY: Stupidity | 1.3 (7%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 1.7 | 9.0 | 15.3 | 0.0 |
| not cast | 7.3 | 8.3 | 7.0 | 22.7 | 44.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (56%) | 0.7 (10%) | 16.3 (72%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (21%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.7 (9%) | 0.0 (0%) | 0.7 (10%) | 1.3 (6%) | 1.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.7 (91%) | 3.7 (44%) | 5.7 (81%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 41.3 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.3 a game | 2.7 a game | 5.0 a game |
| stood (cast and not dispelled) | 64% (14 of 22) | 75% (6 of 8) | 67% (20 of 30) |
| the unit moved after it | 64% (9 of 14) | 33% (2 of 6) | 55% (11 of 20) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 6) | 0% (0 of 20) |
| the enemy charged it first | 0% (0 of 14) | 0% (0 of 6) | 0% (0 of 20) |
| it fought by the end of its next turn | 0% (0 of 14) | 0% (0 of 6) | 0% (0 of 20) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 14) | 0% (0 of 6) | 0% (0 of 20) |
| none of these (no charge, no fight, no charge escaped) | 100% (14 of 14) | 100% (6 of 6) | 100% (20 of 20) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 49% (17 of 35) | 51% (31 of 61) | 50% (48 of 96) |
|   cavalry | - | 67% (8 of 12) | 67% (8 of 12) |
|   character | - | 75% (9 of 12) | 75% (9 of 12) |
|   chariot | - | 50% (1 of 2) | 50% (1 of 2) |
|   infantry | 49% (17 of 35) | 25% (6 of 24) | 39% (23 of 59) |
|   monster | - | 64% (7 of 11) | 64% (7 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (50%) | 2.3 (23%) | 5.3 (33%) |
| FLEEING: it fled or was fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.3 (22%) | 7.0 (70%) | 8.3 (52%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (17%) | 0.7 (7%) | 1.7 (10%) |
| SHELTERED: the target was sheltered | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 75% | 2.2 pts | 9 pts |
| character | 3.0 | 2.3 | 44% | 6.0 pts | 18 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 7.7 | 2.3 | 83% | 3.4 pts | 26 pts |
| monster | 2.3 | 1.7 | 71% | 5.8 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 1.0 | 0.5 |
| Charges that made contact a game | 0.0 | 0.7 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.09 declared, 0.06 contact (32 units) | 0.06 declared, 0.04 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 60% (3 of 5) | 70% (7 of 10) | - | 67% (10 of 15) |
| Character on its own | - | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 0% (0 of 7) | - | 33% (4 of 12) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 42% (45 of 108) | 87% | 43% (9 of 21) | 100% (5 of 5); 5.0 uses a game | 67% (2 of 3); 0.8 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 98% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 100% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 11% (2 of 18) | 41% (7 of 17) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | 17% (3 of 18) | 0% (0 of 7) |
| Strategy | Lone characters that fought | - | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.3 | 5.7 |
| Movement | Points that never moved of their own | 18.3 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 1, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (5 of 17) | 74% (23 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 8.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (4 of 24) | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | 24.3 | 6.7 |
| Magic | Points destroyed by magic (all spells) | 445.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.0 / 1.0 / 0.0 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +10 |
| Combat | Net per 100 charger points, damage counted | - | +17.6 |
| Combat | First round won (charged fights) | - | 50% |
| Combat | Net points per charged fight | - | +10 |
| Combat | Net points per supported fight / lone fight | - / - | - / +10 |
| Combat | Charged fights on a top-3 enemy unit | - | 1 of 2 |
| Game | Points lost | 58.3 | 555.0 |
| Game | VP from objectives | 996.7 | 640.0 |
| Game | Lone holders (player turns) | 2.7 | 1.3 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +842 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 613
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 98.3 |
| ARMY TABLE | 12.0 | -121.8 | 0.0 | 40.0 | 18.7 | +326.1 | 0.0 | 239.7 |
| CAST JOB | - | - | - | - | 2.0 | +2.6 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 7.7 | +933.2 | 678.0 | 0.0 | 1.3 | +47.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +8.3 | 0.0 | 36.7 | 1.0 | +16.3 | 0.0 | 20.0 |
| CHARGE LOSSES | 17.3 | -302.7 | 0.0 | 0.0 | 11.7 | -439.2 | 0.0 | 558.0 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.3 | +0.0 | 0.0 | 18.3 | 13.7 | +0.0 | 0.0 | 263.3 |
| CONVEYANCE SEARCH | 7.0 | +869.7 | 0.0 | 0.0 | 2.7 | +84.3 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -65.7 | 0.0 | 0.0 | 5.3 | -213.7 | 0.0 | 83.7 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 198.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +3.7 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 0.3 | +1.9 | 18.3 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 24.7 | +254.2 | 0.0 | 78.0 |
| FEATURE BUFFS | 15.3 | +668.1 | 0.0 | 55.0 | 0.3 | +12.5 | 0.0 | 0.0 |
| FIVE ACTION | 57.7 | +8527.2 | 1001.3 | 215.0 | 96.3 | +3255.5 | 73.3 | 1218.7 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 127.7 |
| FOUR ROUNDS | - | - | - | - | 0.7 | +13.4 | 18.3 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 43.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 318.7 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -37.8 | 0.0 | 36.7 | 2.0 | -19.7 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 45.3 | +14.3 | 583.0 | 0.0 | 29.7 | +7.3 | 98.3 | 0.0 |
| HIS MOVE WHY | 17.3 | +0.0 | 0.0 | 80.0 | 18.7 | +0.0 | 0.0 | 469.3 |
| HIS ONE MOVE | 13.7 | +2.8 | 0.0 | 0.0 | 19.3 | +17.5 | 0.0 | 83.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 43.3 | 7.7 | +0.0 | 0.0 | 167.3 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.0 | +460.6 | 0.0 | 116.7 | 55.0 | +2593.0 | 0.0 | 620.7 |
| HIS SHOTS BY HIS RUN | 36.0 | +262.7 | 0.0 | 153.3 | 38.0 | +1036.0 | 0.0 | 569.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +40.3 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 38.0 | +0.0 | 0.0 | 110.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.3 | +1918.0 | 0.0 | 0.0 | 9.0 | +1088.1 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 0.3 | -3.4 | 18.3 | 0.0 |
| IDLE COST | - | - | - | - | 30.0 | -327.8 | 0.0 | 352.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -11.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.0 | +0.0 | 11.3 | 91.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +18.5 | 0.0 | 0.0 | 1.3 | +78.2 | 0.0 | 78.0 |
| MARCH AT ESCAPER | 0.7 | +27.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +110.7 | 0.0 | 0.0 | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | 0.7 | +89.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -26.8 | 0.0 | 0.0 | 0.3 | -29.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +21.9 | 0.0 | 18.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 198.0 |
| MISSILES IN THE MOVE | 9.3 | +773.5 | 0.0 | 0.0 | 6.7 | +119.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.7 | +501.5 | 0.0 | 0.0 | 6.3 | +60.2 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 5.3 | -201.2 | 0.0 | 0.0 | 0.7 | -23.2 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 89.3 |
| MOVE SPELL NOT WORTH | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.0 | -159.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 0.3 | +4.3 | 0.0 | 0.0 | 3.0 | +133.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +353.9 | 0.0 | 21.7 | 3.0 | +163.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.3 | +4.3 | 0.0 | 0.0 | 1.3 | +52.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 0.7 | -7.5 | 18.3 | 0.0 |
| NOT WORTH A CAST | 4.0 | -6.2 | 0.0 | 0.0 | 1.3 | -1.8 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -81.0 | 0.0 | 0.0 | 2.0 | -20.4 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -70.7 | 0.0 | 36.7 | 3.3 | -51.8 | 0.0 | 112.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +28.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 9.0 | +242.1 | 0.0 | 0.0 | 2.0 | -11.5 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +1.3 | 167.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +21.1 | 18.3 | 0.0 |
| PLAN RESULT | 24.3 | +191.1 | 229.3 | 98.3 | 42.7 | +73.6 | 0.0 | 622.7 |
| PROMISE BY ITS OWN SUM | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 9.7 | +1784.8 | 235.3 | 43.3 | 19.3 | +1640.7 | 0.0 | 558.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +155.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | -11.3 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 55.0 | 2.7 | +0.0 | 0.0 | 22.7 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -30.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| RESERVE MOVE SPELL | 1.0 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 0.7 | -23.9 | 18.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 0.3 | -0.1 | 18.3 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -53.2 | 0.0 | 18.3 | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 0.7 | +10.0 | 0.0 | 0.0 | 0.7 | +15.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | -0.4 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +38.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.3 | -0.2 | 0.0 | 18.3 | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 21.7 | 6.3 | +0.0 | 0.0 | 171.7 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +35.0 | 0.0 | 43.3 | - | - | - | - |
| SHOT RISK POINTS | 22.3 | -179.7 | 0.0 | 55.0 | 48.3 | +538.6 | 0.0 | 648.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 7.0 | +120.8 | 0.0 | 43.3 | 11.7 | +86.2 | 0.0 | 301.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +38.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +12.9 | 201.3 | 0.0 | 2.7 | +9.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 36.7 | 3.7 | +0.0 | 0.0 | 11.3 |
| STANDS FOR A REASON | - | - | - | - | 13.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 21.3 | +0.0 | 1001.3 | 120.0 | 36.0 | +0.0 | 55.0 | 391.3 |
| STAY WORTH | 10.7 | +126.5 | 458.7 | 43.3 | 17.3 | +56.7 | 55.0 | 373.7 |
| SUPPORT ADDS | 5.0 | +166.9 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 5.0 | +166.9 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 83.7 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 106.3 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 41.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 28.3 | +0.0 | 0.0 | 116.7 | 46.7 | +0.0 | 0.0 | 613.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 27.0 | +689.0 | 0.0 | 150.0 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -84.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.4 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.0 | +171.0 | 11.3 | 18.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 10.3 | +234.3 | 0.0 | 0.0 | 0.7 | +56.8 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 225 | 225 | 160 | 53.33 | +0 | +0.0 |
| HIS SHOT LIST | 261 | 260 | 95 | 31.67 | +1262 | +13.3 |
| HIS MOVE WHY | 108 | 108 | 71 | 23.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 76 | 76 | 68 | 22.67 | +3642 | +53.6 |
| HIS SHOTS BY HIS RUN | 222 | 218 | 63 | 21.00 | +673 | +10.7 |
| ARMY TABLE | 92 | 92 | 62 | 20.67 | +216 | +3.5 |
| SHOT RISK POINTS | 212 | 210 | 47 | 15.67 | +473 | +10.1 |
| HIS ONE MOVE | 99 | 99 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| CASTING BLOCK | 27 | 27 | 25 | 8.33 | +872 | +34.9 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| IDLE COST | 90 | 73 | 19 | 6.33 | +176 | +9.3 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| OFF BEST | 13 | 13 | 13 | 4.33 | -304 | -23.4 |
| TIME ON OUR SIDE | 81 | 67 | 12 | 4.00 | +140 | +11.6 |
| CHARGE LOSSES | 87 | 86 | 11 | 3.67 | +519 | +47.2 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| STAY WORTH | 84 | 64 | 11 | 3.67 | +68 | +6.2 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 33 | 33 | 8 | 2.67 | +127 | +15.9 |
| FEATURE BUFFS | 47 | 47 | 7 | 2.33 | +105 | +15.0 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| QUARTER ODDS | 87 | 83 | 7 | 2.33 | +669 | +95.6 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +2 | +0.4 |
| GOAL WALK | 14 | 14 | 6 | 2.00 | +1220 | +203.2 |
| MOVE TO CHARGE COMPUTED | 10 | 10 | 6 | 2.00 | +244 | +40.7 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 74 | 56 | 5 | 1.67 | +108 | +21.7 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 5 | 1.67 | +323 | +64.6 |
| NEXT CHARGE BY LIST | 5 | 5 | 5 | 1.67 | +123 | +24.5 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 5 | 1.67 | +468 | +93.6 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +10 | +2.0 |
| THE RISK READS HIS RUN | 36 | 36 | 5 | 1.67 | +0 | +0.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +445 | +111.2 |
| MISSILES IN THE MOVE | 48 | 36 | 4 | 1.33 | +305 | +76.3 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +75 | +18.8 |
| CHAFF IN THE MOVE | 5 | 4 | 3 | 1.00 | +19 | +6.3 |
| FIVE ACTION | 462 | 457 | 3 | 1.00 | +250 | +83.2 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +110 | +36.7 |
| SET UP BY THE SET | 3 | 3 | 3 | 1.00 | +3 | +1.0 |
| COVER ONCE | 22 | 15 | 2 | 0.67 | +3 | +1.7 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +90 | +45.2 |
| MAX FOR POSITIONING | 7 | 7 | 2 | 0.67 | +4 | +1.8 |
| MISSILES NEXT TURN | 45 | 34 | 2 | 0.67 | +119 | +59.4 |
| ONE OBJECTIVE FORMULA | 33 | 21 | 2 | 0.67 | +103 | +51.4 |
| REDIRECT COUNTER | 7 | 4 | 2 | 0.67 | +38 | +19.2 |
| SHOTS AFTER THE MOVES | 13 | 13 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 56 | 32 | 2 | 0.67 | +21 | +10.7 |
| HIS MOVE AND SHOT | 22 | 22 | 1 | 0.33 | +4 | +4.0 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +40 | +40.2 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -34 | -34.1 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -7 | -6.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +40 | +40.2 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SUPPORT ADDS | 15 | 15 | 1 | 0.33 | +12 | +12.1 |
| SUPPORT WORKED OUT | 15 | 15 | 1 | 0.33 | +12 | +12.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| WHOLE FIGHT DANGER | 8 | 8 | 1 | 0.33 | +31 | +30.9 |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 47 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FOUR ROUNDS | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 33 | 32 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 8 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 154 | 154 | 0 | 0.00 | - | - |
| HONEST WORTH | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 18 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 31 | 26 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 15 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 201 | trace | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 26 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 39 | 39 | 0 | 0.00 | - | - |
| STANDS STILL | 172 | 171 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 31 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 26 | not checked | - | - | - | - |
| THE TABLE BINDS | 225 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 2.00 | 23.4 |
| ARMY TABLE | rule | 2.00 | 1.33 | 84.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 14.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.1 |
| MARCH OF THE TABLE | rule | 0.33 | - | 6.7 |

### Plans: wfr-a92c160-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 19.7 | 95% | 2465 | 0 | 0% |
| Mine | shoot | 4.3 | 31% | 786 | 191 | 24% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 0.3 | 100% | 11 | 18 | 170% |
| Opponent | move | 37.7 | 94% | 1051 | 0 | 0% |
| Opponent | shoot | 4.3 | 46% | 156 | 55 | 35% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: wfr-a92c160-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 45 (18) | 45 | 0 | 0 | 17% | 1.7 | 97 (3) | 44 (12) | 0 (3) | 62 (12) | 11 (6) |
| Mine | Hammer | 6 | 50 (6) | 2 | 49 | 0 | 83% | 2.0 | 56 (1) | 59 (4) | 11 (1) | 49 (4) | 52 (2) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 0 | 100% | - | - | 65 (3) | - | 195 (1) | 0 (2) |
| Mine | Shooter | 6 | 54 (6) | 0 | 54 | 17 | 0% | 2.2 | - | 65 (5) | 0 (1) | 69 (4) | 23 (2) |
| Opponent | Chaff | 6 | 118 (6) | 0 | 118 | 25 | 67% | 3.0 | 0 (3) | 429 (2) | 0 (1) | 118 (6) | - |
| Opponent | Character | 8 | 3 (8) | 3 | 0 | 0 | 25% | 1.7 | 5 (4) | 0 (4) | - | 5 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 24 (7) | 9 | 15 | 28 | 57% | 2.0 | 57 (1) | 0 (3) | 25 (3) | 29 (3) | 21 (4) |
| Opponent | Hammer | 13 | 15 (13) | 0 | 15 | 54 | 69% | 1.5 | - | 21 (8) | 0 (5) | 0 (3) | 20 (10) |
| Opponent | Holder | 1 | 36 (1) | 0 | 36 | 0 | 100% | - | - | 36 (1) | - | - | 36 (1) |
| Opponent | Shooter | 3 | 74 (3) | 0 | 74 | 62 | 67% | 1.0 | 193 (1) | 0 (2) | - | 193 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: wfr-a92c160-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 445 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 18 | 18 | 0.7 | 1.0 | 28 | 17 | +10 | 1 of 2 | 1 of 2 | - | +10 |

### Effective charges: wfr-a92c160-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 55 | +55 | 55 | 0 | +55 | +64.7 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 2 | 60 | 446 | +10 | 28 | 17 | +10 | +17.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p25 | move | 11 | 0 (0%) | 0 (0%) | 0 (0%) | 11 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

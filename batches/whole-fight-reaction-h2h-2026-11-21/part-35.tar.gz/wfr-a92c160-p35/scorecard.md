# Doctrine scorecard: wfr-a92c160-p35

### Scorecard: wfr-a92c160-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 5 | 1 | 1 | 0 | 0 | 55 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 1 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 1 | 7 | 1 | 0 | 0 | 0 | 158 |
| **Average** | | | Mine | 33% | 3.5 | 2.5 | 3.0 | 1.7 | 0.3 | 0.0 | 0.0 | 203.3 |
| **Average** | | | Opponent | 0% | 1.5 | 1.5 | 4.0 | 1.7 | 0.3 | 0.0 | 0.0 | 109.3 |

### KPIs: wfr-a92c160-p35

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 13) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 71% (5 of 7); on the table 100% | 100% (4 of 4); on the table 100% | 82% (9 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 50% | - | 25% (1 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 55% (6 of 11); on the table 82% | 100% (4 of 4); on the table 100% | 67% (10 of 15); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 17% (3 of 18) | 25% (6 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (3 of 6) | 21% (3 of 14) | 30% (6 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | 67% (6 of 9) | 60% (9 of 15) |
| Points that never fought | lower | 52% (3138 of 5999) | 46% (2784 of 6000) | 49% (5922 of 11999) |
|   infantry points that never fought | lower | 83% (1288 of 1552) | 48% (501 of 1035) | 69% (1789 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 73% (22 of 30) | 67% (33 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (2022 of 4484) | 70% (3876 of 5546) | 59% (5898 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (67%) | 3.7 (73%) | 4.3 (72%) |
| MARCHED: its unit marched | 0.3 (33%) | 0.0 (0%) | 0.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (27%) | 1.3 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.3 | 0.3 | 0.7 | 2.0 | 1.3 | 0.7 |
| not cast | 2.7 | 1.7 | 1.3 | 6.0 | 0.7 | 15.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 4.3 (72%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (80%) | 1.3 (100%) | 1.3 (22%) | 0.0 (0%) | 2.3 (15%) |
| STUPIDITY: Stupidity | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.7 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (64 of 97) | 81% (17 of 21) | 69% (81 of 118) |
|   cavalry | 93% (14 of 15) | 91% (10 of 11) | 92% (24 of 26) |
|   character | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 72% (41 of 57) | 88% (7 of 8) | 74% (48 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 0.7 (50%) | 1.0 (8%) |
| CHARGED: it charged | 3.0 (27%) | 0.7 (50%) | 3.7 (30%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 3.3 (30%) | 0.0 (0%) | 3.3 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (27%) | 0.0 (0%) | 3.0 (24%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.0 | 0.7 | 94% | 1.6 pts | 19 pts |
| chariot | 3.0 | 0.7 | 78% | 1.7 pts | 5 pts |
| infantry | 19.0 | 4.3 | 86% | 4.6 pts | 88 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 4.0 | 4.7 |
| Charges that made contact a game | 3.7 | 3.0 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.34 contact (32 units) | 0.48 declared, 0.39 contact (23 units) | 0.49 declared, 0.36 contact (55 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (1 of 1) | 0% (0 of 1) | 56% (5 of 9) |
| Character in a unit | 100% (4 of 4) | - | 0% (0 of 1) | 80% (4 of 5) |
| Character on its own | 100% (4 of 4) | 100% (1 of 1) | 43% (3 of 7) | 67% (8 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 82% (9 of 11) | 100% (1 of 1) | - | 83% (10 of 12) |
| Monster | 50% (3 of 6) | 100% (1 of 1) | - | 57% (4 of 7) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 75% (3 of 4); on the table 100% | 50% (3 of 6) | 50% | 78% (7 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 43% (3 of 7); on the table 71% | - | 53% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 70% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 50% | 83% (10 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 19% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 83% (5) | 82% (9) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 1.00 | 0.00 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: wfr-a92c160-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 43% (6 of 14) | 55% (6 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (10 of 19) | 44% (4 of 9) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 44% (4 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 1.7 |
| Movement | Points that never moved of their own | 203.3 | 109.3 |
| Movement | Fights charged into per game | 3.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +45 | 2 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +180 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 7, net +94 | 5 of 8, net -86 |
| Shooting | Shots by shooting units (incl. breath weapons) | 24.3 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 11% (8 of 73) | 44% (8 of 18) |
| Shooting | Points destroyed by shooting units | 0.0 | 48.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 80.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.7 / 0.0 / 0.3 / 0.0 | 3.0 / 0.3 / 0.0 / 1.0 |
| Combat | Points destroyed in combat | 420.0 | 249.3 |
| Combat | Points run down | 76.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +148 | -62 |
| Combat | Net per 100 charger points, damage counted | +50.2 | -42.2 |
| Combat | First round won (charged fights) | 80% | 44% |
| Combat | Net points per charged fight | +125 | -67 |
| Combat | Net points per supported fight / lone fight | +236 / +112 | - / -67 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 10 | 3 of 9 |
| Game | Points lost | 319.3 | 817.3 |
| Game | VP from objectives | 1150.0 | 570.0 |
| Game | Lone holders (player turns) | 3.5 | 1.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +1276 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1137
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: wfr-a92c160-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +29.3 | 0.0 | 70.0 | - | - | - | - |
| ARMY TABLE | 32.0 | +474.7 | 0.0 | 204.0 | 22.3 | +210.2 | 0.0 | 365.3 |
| BACKUP TARGETS | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +1.1 | 15.0 | 0.0 | 2.3 | +7.8 | 161.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 91.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +10.9 | 0.0 | 0.0 | 0.7 | +18.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 96.7 | 0.3 | -0.6 | 0.0 | 52.7 |
| CHALLENGE BY POINTS | 0.3 | +3.0 | 0.0 | 0.0 | 0.7 | +31.1 | 0.0 | 83.3 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +38.7 | 40.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.3 | -447.7 | 0.0 | 48.3 | 20.3 | -663.1 | 0.0 | 396.3 |
| CHARGE NOW FIRST | 4.0 | +0.0 | 311.3 | 65.0 | 2.0 | +0.0 | 20.0 | 267.7 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 48.0 | 9.7 | +0.0 | 0.0 | 62.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +15.2 | 199.7 | 91.3 |
| COVER ONCE | 9.3 | -685.4 | 0.0 | 0.0 | 6.3 | -343.9 | 0.0 | 162.3 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 36.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +4.9 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.3 | +248.7 | 22.0 | 845.3 |
| EXACT ROUND | 3.3 | +48.5 | 243.0 | 65.0 | 3.0 | +6.6 | 112.3 | 319.7 |
| FACES THE THREAT | - | - | - | - | 0.3 | +16.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.3 | +32.0 | 309.7 | 65.0 | 2.0 | +0.3 | 64.0 | 251.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.0 | +45.0 | 0.0 | 44.0 | 19.0 | +179.8 | 0.0 | 166.3 |
| FEATURE BUFFS | 1.3 | +5.5 | 0.0 | 48.0 | 2.0 | +5.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.3 | 15.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 111.7 | +10355.7 | 867.7 | 542.7 | 79.0 | +3982.4 | 273.3 | 1446.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 198.7 |
| FOLLOW UP WEIGHED | 0.7 | +137.6 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 5.3 | +338.9 | 408.0 | 65.0 | 4.0 | +229.7 | 112.3 | 519.3 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 48.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.3 | -33.3 | 0.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -2.8 | 36.7 | 0.0 | 0.3 | -5.9 | 48.3 | 0.0 |
| GOAL WALK | 15.7 | +2052.7 | 0.0 | 0.0 | 5.0 | +269.9 | 0.0 | 83.3 |
| GUN FIGURES | 0.7 | +0.4 | 18.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 48.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 48.3 | 14.7 | +0.0 | 0.0 | 343.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +31.3 | 0.0 | 199.7 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 21.7 | 4.7 | +0.0 | 0.0 | 40.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 95.0 |
| HIS MOVE AND SHOT | 1.3 | -13.8 | 0.0 | 0.0 | 4.7 | -61.9 | 0.0 | 38.7 |
| HIS MOVE AS HE DECIDES | 43.3 | +14.3 | 864.3 | 0.0 | 52.7 | +19.7 | 217.7 | 0.0 |
| HIS MOVE WHY | 34.0 | +0.0 | 0.0 | 85.3 | 14.0 | +0.0 | 0.0 | 117.3 |
| HIS ONE MOVE | 22.0 | +89.3 | 0.0 | 0.0 | 22.0 | -3.5 | 0.0 | 267.3 |
| HIS ONE QUARTER | 10.3 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 266.3 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 19.0 | +0.0 | 0.0 | 48.0 | 4.3 | +0.0 | 0.0 | 62.0 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 48.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.3 | +588.5 | 0.0 | 322.7 | 46.3 | +1165.1 | 0.0 | 709.3 |
| HIS SHOTS BY HIS RUN | 31.3 | +403.5 | 0.0 | 176.0 | 51.3 | +740.3 | 0.0 | 770.0 |
| HIS TURN DENIED | 1.3 | +37.0 | 78.7 | 0.0 | 0.7 | +3.8 | 22.0 | 34.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 22.0 | +0.0 | 0.0 | 204.0 | 16.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.7 | +1043.9 | 0.0 | 112.0 | 10.0 | +881.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -138.4 | 300.3 | 0.0 | 3.0 | -61.1 | 112.3 | 467.3 |
| HUNT IN PAIRS | 0.7 | +33.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 3.3 | -49.8 | 0.0 | 0.0 | 16.3 | -142.8 | 0.0 | 100.7 |
| JOINT CHARGE NOW | 1.0 | -26.3 | 80.0 | 0.0 | 0.7 | +10.9 | 0.0 | 18.0 |
| JOINT ON THE TABLE | 0.3 | +11.1 | 40.0 | 0.0 | 0.3 | +10.1 | 0.0 | 18.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 20.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 582.3 | 88.0 | 12.7 | +0.0 | 135.0 | 208.3 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +4.3 | 0.0 | 34.0 |
| LOST AFTER ESCAPE | 1.3 | +1.2 | 116.7 | 65.0 | 0.3 | +0.2 | 48.3 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +3.4 | 0.0 | 62.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -8.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +63.9 | 0.0 | 0.0 | 1.0 | +11.5 | 0.0 | 18.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +121.3 | 0.0 | 0.0 | 4.0 | +76.5 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 3.3 | +74.3 | 0.0 | 0.0 | 5.7 | +36.5 | 0.0 | 52.7 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 42.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +1182.9 | 0.0 | 0.0 | 5.3 | +415.5 | 0.0 | 116.7 |
| NEARER NOT NEEDED | 15.0 | +600.7 | 0.0 | 64.0 | 7.0 | +279.2 | 0.0 | 89.3 |
| NEXT CHARGE BY LIST | 6.3 | +973.4 | 83.3 | 0.0 | 2.7 | +256.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.4 | 0.0 | 20.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 5.0 | -235.0 | 408.0 | 65.0 | 2.7 | -207.4 | 90.3 | 301.7 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -148.5 | 78.7 | 22.0 | 7.7 | -257.6 | 0.0 | 147.3 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 40.0 |
| ONE FIGHT FORMULA | 7.3 | -140.7 | 0.0 | 0.0 | 3.7 | -58.6 | 0.0 | 132.7 |
| ONE JOINT FIGURE | 0.7 | +6.0 | 55.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.7 | +22.6 | 0.0 | 68.0 | 3.3 | -21.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -147.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +27.3 | 0.0 | 0.0 | 0.3 | +16.2 | 22.0 | 199.7 |
| OVERRUNS AWAY | 1.0 | +16.5 | 131.3 | 0.0 | 1.7 | +14.7 | 68.3 | 301.7 |
| PATHS CROSS | 0.3 | +3.9 | 0.0 | 0.0 | 1.0 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 50.7 | +490.8 | 348.7 | 474.3 | 44.0 | +114.3 | 66.0 | 1173.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -423.1 | 0.0 | 0.0 | 8.0 | -94.2 | 0.0 | 98.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -4.0 | 0.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 30.3 | +3456.0 | 266.7 | 0.0 | 25.0 | +2135.7 | 65.0 | 403.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +108.8 | 0.0 | 215.0 | 3.0 | +22.1 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +129.4 | 0.0 | 24.0 | 2.3 | +87.6 | 0.0 | 18.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.0 | +28.2 | 0.0 | 44.0 | 2.7 | +0.0 | 0.0 | 48.0 |
| REFORMS TO MEET IT | 2.0 | -18.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +16.3 | 0.0 | 0.0 | 0.3 | +6.3 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | -47.5 | 356.3 | 65.0 | 2.7 | -34.5 | 90.3 | 501.3 |
| ROUNDS AFTER TERROR | 2.3 | -55.7 | 176.0 | 65.0 | - | - | - | - |
| RUN DOWN | 4.3 | -93.7 | 336.3 | 65.0 | 0.3 | -3.4 | 48.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -6.1 | 41.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -12.4 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +15.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +64.3 | 78.7 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -36.8 | 0.0 | 0.0 | 3.7 | -89.9 | 0.0 | 30.0 |
| SET UP BY THE SET | 4.3 | -103.4 | 0.0 | 0.0 | 5.0 | +347.6 | 0.0 | 30.0 |
| SET UP TOGETHER | 0.7 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +190.1 | 331.3 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -28.5 | 56.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -147.9 | 0.0 | 44.0 | 31.7 | -210.8 | 0.0 | 438.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.3 | +306.7 | 0.0 | 88.0 | 4.7 | +112.8 | 0.0 | 89.3 |
| SPELL WORTH | 1.7 | +12.5 | 0.0 | 0.0 | 3.3 | +3.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -1.7 | 52.7 | 0.0 | 0.7 | -11.7 | 0.0 | 18.0 |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 70.0 | 10.3 | +0.0 | 0.0 | 202.7 |
| STAND AND SHOOT | 1.3 | -10.1 | 120.0 | 0.0 | 1.7 | -2.6 | 90.3 | 267.7 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 47.7 | +0.0 | 459.7 | 188.3 | 24.0 | +0.0 | 161.0 | 148.3 |
| STAY WORTH | 17.7 | +53.7 | 113.3 | 42.0 | 7.0 | +42.8 | 96.0 | 141.3 |
| STRIKE BY THE ODDS | 1.0 | +259.1 | 109.3 | 65.0 | 0.3 | +0.1 | 0.0 | 40.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.0 | +519.3 | 0.0 | 0.0 | 1.3 | +21.4 | 0.0 | 38.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 15.0 | 0.0 | 0.3 | +0.0 | 20.0 | 34.0 |
| SUPPORT WORKED OUT | 5.0 | +519.3 | 0.0 | 0.0 | 1.3 | +21.4 | 0.0 | 38.7 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 41.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 98.7 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 62.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.7 | +0.0 | 0.0 | 131.3 | 39.3 | +0.0 | 0.0 | 420.0 |
| TIED UP BY THE SUM | 2.7 | +331.4 | 212.0 | 0.0 | 1.0 | +122.3 | 70.3 | 399.3 |
| TIME ON OUR SIDE | 44.0 | +393.0 | 56.7 | 130.7 | 5.0 | +41.7 | 0.0 | 125.7 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -6.2 | 40.0 | 0.0 | 0.7 | -0.8 | 0.0 | 34.0 |
| WHO GETS IN | 0.7 | -4.6 | 80.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +3.8 | 0.0 | 0.0 | 1.3 | +104.3 | 0.0 | 133.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -248.8 | 0.0 | 48.3 | 3.3 | -359.6 | 0.0 | 166.7 |
| WHOLE FIGHT GAIN | 0.3 | +7.1 | 40.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 0.7 | +242.4 | 18.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +0.5 | 0.0 | 0.0 | 3.7 | +60.7 | 0.0 | 52.7 |

### Rule changes: wfr-a92c160-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 288 | 288 | 186 | 62.00 | +0 | +0.0 |
| ARMY TABLE | 163 | 163 | 116 | 38.67 | +2277 | +19.6 |
| HIS MOVE WHY | 144 | 144 | 82 | 27.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 71 | 71 | 65 | 21.67 | +3459 | +53.2 |
| HIS SHOT LIST | 266 | 256 | 64 | 21.33 | +796 | +12.4 |
| LEGAL CHARGES ONLY | 61 | 61 | 61 | 20.33 | +0 | +0.0 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1218 | -30.5 |
| HIS ONE MOVE | 132 | 128 | 35 | 11.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 248 | 236 | 34 | 11.33 | +182 | +5.3 |
| FIVE ACTION | 572 | 552 | 31 | 10.33 | +1415 | +45.7 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| QUARTER ODDS | 166 | 160 | 27 | 9.00 | +2432 | +90.1 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| REDIRECT FOR A FRIEND IN REACH | 26 | 26 | 25 | 8.33 | +68 | +2.7 |
| MOVE TO CHARGE COMPUTED | 39 | 34 | 18 | 6.00 | +986 | +54.8 |
| PROMISE BY ITS OWN SUM | 51 | 51 | 16 | 5.33 | -1552 | -97.0 |
| SHOT RISK POINTS | 164 | 157 | 15 | 5.00 | +296 | +19.7 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 27 | 26 | 14 | 4.67 | +830 | +59.3 |
| THE RISK READS HIS RUN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| GOAL WALK | 62 | 61 | 13 | 4.33 | +947 | +72.9 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 12 | 4.00 | +160 | +13.4 |
| FOUR ROUNDS | 28 | 25 | 11 | 3.67 | +581 | +52.8 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 15 | 15 | 9 | 3.00 | +392 | +43.6 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 59 | 37 | 8 | 2.67 | +31 | +3.8 |
| TIME ON OUR SIDE | 147 | 126 | 8 | 2.67 | +12 | +1.4 |
| CHARGE LOSSES | 95 | 90 | 7 | 2.33 | +926 | +132.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| SET UP BY THE SET | 28 | 26 | 6 | 2.00 | +124 | +20.7 |
| TIED UP BY THE SUM | 11 | 9 | 6 | 2.00 | +365 | +60.8 |
| WHOLE FIGHT DANGER | 18 | 17 | 6 | 2.00 | +596 | +99.3 |
| COVER ONCE | 47 | 24 | 5 | 1.67 | +81 | +16.2 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -46 | -9.2 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +216 | +43.2 |
| EVASIVE BY THE ODDS | 7 | 7 | 4 | 1.33 | +724 | +181.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +134 | +33.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 74 | 70 | 4 | 1.33 | +13 | +3.2 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +252 | +62.9 |
| SUPPORT ADDS | 19 | 18 | 4 | 1.33 | +53 | +13.3 |
| SUPPORT WORKED OUT | 19 | 18 | 4 | 1.33 | +53 | +13.3 |
| CAST JOB | 8 | 8 | 3 | 1.00 | +6 | +2.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -2 | -0.6 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +102 | +34.1 |
| CHARGE NOW FIRST | 18 | 18 | 3 | 1.00 | -39 | -13.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +68 | +22.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +211 | +70.3 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +88 | +43.9 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 19 | 17 | 2 | 0.67 | +39 | +19.3 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +413 | +206.4 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.67 | +64 | +31.9 |
| NEARER NOT NEEDED | 66 | 63 | 2 | 0.67 | +49 | +24.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.2 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +45 | +22.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | -14 | -6.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +116 | +116.1 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +8 | +8.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +49 | +48.7 |
| FALLS SHORT | 69 | 56 | 1 | 0.33 | +26 | +26.2 |
| HIS TURN DENIED | 6 | 4 | 1 | 0.33 | +7 | +7.4 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +18 | +17.9 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| NO DOUBLE ROUNDS | 23 | 20 | 1 | 0.33 | +27 | +27.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -444 | -443.6 |
| REDIRECT COUNTER | 17 | 13 | 1 | 0.33 | +47 | +47.1 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -3 | -3.0 |
| RISK BY ARC | 18 | 16 | 1 | 0.33 | +18 | +18.4 |
| SHOTS IN THE MOVE | 81 | 63 | 1 | 0.33 | +68 | +68.2 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -23 | -22.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +18 | +18.4 |
| WHOLE FIGHT REACTION | 2 | 2 | 1 | 0.33 | +330 | +329.8 |
| WOUNDS ON THE RANKS | 12 | 12 | 1 | 0.33 | +15 | +15.4 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 11 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 19 | 17 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 28 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 18 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 69 | 67 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 9 | 9 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 70 | 70 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 115 | 115 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 18 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 8 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 22 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 13 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 33 | 15 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 30 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 8 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 284 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 12 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 18 | 16 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 13 | 13 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 58 | 51 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 9 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 215 | 212 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 5.67 | 29.8 |
| ARMY TABLE | rule | 4.33 | 1.00 | 63.0 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 2.33 | 97.0 |
| RULE SWITCHED OFF | gate | - | 1.67 | 49.2 |
| CHARGE NOW FIRST | rule | 1.00 | - | 13.0 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 21.2 |
| NO REASON | gate | 1.00 | - | 23.6 |
| JOINT CHARGE NOW | rule | 0.67 | - | 56.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 5.9 |
| CHAFF PASSED | rule | - | 0.33 | 1.8 |
| FALLBACK | gate | - | 0.33 | 0.7 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 443.6 |
| REFUSING RETIRES | rule | - | 0.33 | 3.0 |
| SUPPORT NARROWED | rule | 0.33 | - | 22.7 |
| WHO GETS IN | rule | 0.33 | - | 47.2 |

### Plans: wfr-a92c160-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 58% | 699 | 262 | 38% |
| Mine | move | 40.3 | 95% | 3180 | 0 | 0% |
| Mine | shoot | 5.7 | 65% | 452 | 229 | 51% |
| Mine | support | 0.7 | 100% | 15 | 0 | 0% |
| Opponent | charge | 3.0 | 33% | 369 | 90 | 24% |
| Opponent | join | 5.7 | 94% | 271 | 0 | 0% |
| Opponent | move | 32.3 | 93% | 1375 | 0 | 0% |
| Opponent | shoot | 2.7 | 12% | 131 | 24 | 18% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 50% | 50% | 0% | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 112 (6) | 30 | 82 | 34 | 17% | 1.0 | - | 129 (5) | 0 (1) | 129 (5) | 0 (1) |
| Mine | Character | 7 | 52 (7) | 42 | 10 | 0 | 14% | 2.7 | 34 (2) | 55 (1) | 84 (2) | 59 (4) | 55 (1) |
| Mine | Clean-up | 1 | 220 (1) | 0 | 220 | 0 | 100% | - | - | 220 (1) | - | - | 220 (1) |
| Mine | Fast Hammer | 6 | 150 (6) | 150 | 0 | 21 | 33% | 3.8 | 173 (4) | 94 (2) | - | - | 150 (6) |
| Mine | Hammer | 5 | 49 (5) | 16 | 33 | 55 | 20% | 1.5 | 29 (3) | 74 (2) | - | 50 (2) | 49 (3) |
| Mine | Holder | 8 | 50 (8) | 7 | 43 | 0 | 12% | 2.7 | 214 (2) | 0 (5) | - | 214 (2) | 0 (5) |
| Mine | Shooter | 5 | 14 (5) | 0 | 14 | 30 | 20% | 1.8 | 0 (2) | 32 (3) | - | 17 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 150 (4) | 0 | 150 | 19 | 50% | 5.0 | 200 (3) | - | 0 (1) | 200 (3) | 0 (1) |
| Opponent | Character | 11 | 8 (11) | 8 | 0 | 41 | 45% | 3.5 | 0 (2) | 13 (8) | - | 14 (6) | 0 (4) |
| Opponent | Fast Hammer | 6 | 41 (6) | 29 | 12 | 38 | 17% | 2.4 | - | 47 (5) | 0 (1) | 0 (3) | 67 (3) |
| Opponent | Hammer | 8 | 19 (8) | 19 | 0 | 60 | 25% | 3.2 | 0 (3) | 30 (5) | - | 25 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 82 (3) | 0 | 82 | 69 | 0% | 1.0 | - | 118 (2) | 0 (1) | 36 (2) | 184 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 240 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 1 of 2 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 698 | 4.0 | 1.1 | 174 | 24 | +150 | 2 of 8 | 7 of 8 | +236 | +138 |
| **Mine** | all armies | 3 | 80 | 480 | 3.3 | 1.1 | 144 | 20 | +125 | 2 of 10 | 8 of 10 | +236 | +112 |
| Opponent | Vampire Counts | 1 | 145 | 145 | 3.0 | 1.0 | 48 | 0 | +48 | 1 of 3 | 1 of 3 | - | +48 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 170 | -170 | 1 of 1 | 1 of 1 | - | -170 |
| Opponent | Wood Elf Realms | 1 | 0 | 126 | 5.0 | 1.0 | 25 | 140 | -115 | 1 of 5 | 2 of 5 | - | -115 |
| **Opponent** | all armies | 3 | 48 | 90 | 3.0 | 1.0 | 30 | 97 | -67 | 3 of 9 | 4 of 9 | - | -67 |

### Effective charges: wfr-a92c160-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 1 (net +45) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 0 | 2 (net +180) | 3 (net +126) | 3 | 0% (0 of 5) |
| Opponent | Vampire Counts | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net +145) | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 (net -144) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: wfr-a92c160-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 45 | +45 | 45 | 18 | +27 | - |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 233 | 151 | +94 | 196 | 57 | +139 | +59.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 472 | 122 | +180 | 223 | 12 | +211 | +44.8 |
| Mine | No odds | 3 | 358 | 113 | +154 | 159 | 0 | +159 | +44.4 |
| Mine | All fights | 10 | 295 | 123 | +125 | 175 | 27 | +148 | +50.2 |
| Opponent | Long shot (under 50%) | 2 | 52 | 276 | +0 | 8 | 9 | -1 | -1.9 |
| Opponent | 76-89% | 1 | 102 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 198 | 108 | -86 | 64 | 140 | -77 | -38.7 |
| Opponent | No odds | 1 | 120 | 431 | -170 | 0 | 170 | -170 | -141.7 |
| Opponent | All fights | 9 | 146 | 176 | -67 | 37 | 99 | -62 | -42.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p35 | move | 23 | 7 (30%) | 5 (22%) | 5 (22%) | 11 (48%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

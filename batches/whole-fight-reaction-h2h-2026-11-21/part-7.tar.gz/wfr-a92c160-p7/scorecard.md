# Doctrine scorecard: wfr-a92c160-p7

### Scorecard: wfr-a92c160-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 526 |
| L1131 | 3 | 1 | Opponent | no | 3 | 3 | 1 | 2 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 7 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.3 | 2.0 | 1.7 | 0.0 | 0.0 | 0.0 | 0.0 | 395.3 |
| **Average** | | | Opponent | 0% | 1.7 | 3.5 | 1.3 | 2.3 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: wfr-a92c160-p7

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (7 of 14) | 0% (0 of 14) | 25% (7 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 47% (31 of 66) | 22% (4 of 18) | 42% (35 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (31 of 61) | 31% (4 of 13) | 47% (35 of 74) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 33% (3 of 9) | 33% (3 of 9) |
| Points that never fought | lower | 54% (3211 of 5998) | 61% (3642 of 5998) | 57% (6853 of 11996) |
|   infantry points that never fought | lower | 87% (633 of 730) | 100% (913 of 913) | 94% (1546 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (10 of 25) | 71% (20 of 28) | 57% (30 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 8.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (8 of 8); 4.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 1.0 uses a game | 33% (2 of 6); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 34% (1936 of 5614) | 72% (4221 of 5828) | 54% (6157 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (20%) | 1.7 (36%) | 4.0 (24%) |
| MARCHED: its unit marched | 6.3 (54%) | 1.3 (29%) | 7.7 (47%) |
| CHARGED: its unit charged | 1.0 (9%) | 0.0 (0%) | 1.0 (6%) |
| IN COMBAT: engaged in combat | 1.7 (14%) | 0.3 (7%) | 2.0 (12%) |
| GONE: slain | 0.0 (0%) | 1.3 (29%) | 1.3 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 3.3 | 2.3 | 11.7 | 2.3 | 2.0 |
| not cast | 1.0 | 8.7 | 1.7 | 16.3 | 5.7 | 34.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.7 (88%) | 0.0 (0%) | 4.0 (24%) | 1.0 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.7 (47%) | 2.7 (47%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) | 0.7 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (20%) | 2.0 (12%) | 0.7 (12%) | 0.0 (0%) |
| GONE: slain | 0.3 (33%) | 0.3 (4%) | 0.3 (20%) | 1.3 (8%) | 0.0 (0%) | 0.7 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.7 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (67%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 32.7 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.3 a game | 1.2 a game |
| stood (cast and not dispelled) | - | 57% (4 of 7) | 57% (4 of 7) |
| the unit moved after it | - | 25% (1 of 4) | 25% (1 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 25% (1 of 4) | 25% (1 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 75% (3 of 4) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (51 of 67) | 25% (4 of 16) | 66% (55 of 83) |
|   cavalry | 0% (0 of 12) | 43% (3 of 7) | 16% (3 of 19) |
|   character | - | 0% (0 of 8) | 0% (0 of 8) |
|   chariot | 71% (5 of 7) | - | 71% (5 of 7) |
|   infantry | 92% (11 of 12) | 100% (1 of 1) | 92% (12 of 13) |
|   war machine | 97% (35 of 36) | - | 97% (35 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (6%) | 0.7 (17%) | 1.0 (11%) |
| CHARGED: it charged | 0.7 (12%) | 0.3 (8%) | 1.0 (11%) |
| FREE: none of these - no target in range or sight, or held its fire | 3.7 (69%) | 0.0 (0%) | 3.7 (39%) |
| NO TARGET IN RANGE | 0.3 (6%) | 3.0 (75%) | 3.3 (36%) |
| OTHER BAR | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 8.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 13.0 | 14.3 | 56% | 32.8 pts | 426 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 2.3 | 2.7 |
| Charges that made contact a game | 1.7 | 2.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.43 contact (7 units) | 0.33 declared, 0.33 contact (3 units) | 0.60 declared, 0.40 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.20 contact (10 units) | 0.29 declared, 0.29 contact (21 units) | 0.32 declared, 0.26 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 45% (5 of 11) | 50% (1 of 2) | 50% (1 of 2) | 47% (7 of 15) |
| Character in a unit | 100% (1 of 1) | - | 100% (1 of 1) | 100% (2 of 2) |
| Character on its own | 100% (6 of 6) | 33% (2 of 6) | 33% (2 of 6) | 56% (10 of 18) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 100% (2 of 2); on the table 100% | 47% (31 of 66) | 54% | 40% (10 of 25) | 100% (7 of 7); 8.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 61% | 67% (6 of 9) | 0.0 uses a game | 33% (2 of 6); 3.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 57% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | 33% (2 of 6) | 64% | 75% (9 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 50% (2) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 100% (6 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (18 of 56) | 50% (2 of 4) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 67% (6 of 9) | 40% (4 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.0 | 2.3 |
| Movement | Points that never moved of their own | 395.3 | 56.7 |
| Movement | Fights charged into per game | 1.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 2 of 6, net +204 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +195 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +235 | 1 of 6, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.3 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (11 of 16) | 75% (6 of 8) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 12.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (16 of 36) | - |
| Shooting | Points destroyed by war machines | 190.7 | 0.0 |
| Magic | Magic missiles cast | 7.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (7 of 23) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 11.7 | - |
| Magic | Wounds caused by other spells | 2.3 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 334.7 | 72.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.7 / 1.0 / 1.0 | 1.7 / 0.3 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 221.7 | 236.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +190 | +102 |
| Combat | Net per 100 charger points, damage counted | +51.8 | +54.0 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +166 | +101 |
| Combat | Net points per supported fight / lone fight | +470 / +65 | - / +101 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 4 | 3 of 7 |
| Game | Points lost | 291.7 | 849.0 |
| Game | VP from objectives | 760.0 | 703.3 |
| Game | Lone holders (player turns) | 2.3 | 1.7 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +812 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1141
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| ARMY TABLE | 8.3 | +65.4 | 0.0 | 136.0 | 20.7 | -249.2 | 0.0 | 626.0 |
| ARTILLERY RE-ROLL WEIGHED | 9.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.2 | 0.0 | 0.0 | 1.0 | +17.0 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -9.9 | 0.0 | 50.0 | - | - | - | - |
| BOMBING RUN | 0.7 | +40.6 | 0.0 | 100.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.7 | +524.2 | 420.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +62.9 | 343.7 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 156.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +144.6 | 0.0 | 80.0 |
| CHALLENGE BY POINTS | 0.3 | +57.8 | 0.0 | 0.0 | 0.3 | +57.8 | 0.0 | 114.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +41.6 | 156.7 | 0.0 | 0.3 | -22.3 | 136.0 | 0.0 |
| CHARGE LOSSES | 12.7 | -547.9 | 0.0 | 372.0 | 30.0 | -1862.4 | 0.0 | 1111.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 557.7 | 50.0 | 1.0 | +0.0 | 150.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 462.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 156.7 |
| CONVEYANCE SEARCH | - | - | - | - | 2.0 | +205.8 | 156.7 | 156.7 |
| COVER ONCE | 12.7 | -750.1 | 0.0 | 50.0 | 8.0 | -580.9 | 0.0 | 67.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -7.9 | 100.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -11.3 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +1.0 | 0.0 | 59.0 |
| EXACT ROUND | 1.7 | +28.3 | 378.3 | 122.3 | 1.7 | -2.5 | 150.0 | 50.3 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 114.3 | 0.0 | 1.3 | +0.0 | 100.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.3 | +129.8 | 0.0 | 785.0 |
| FEATURE BUFFS | 0.7 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +18.6 | 156.7 | 72.3 | 0.7 | +2.5 | 50.0 | 0.0 |
| FIVE ACTION | 89.0 | +8163.2 | 2603.3 | 594.3 | 80.3 | +3240.9 | 286.0 | 2345.0 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 186.0 | 7.0 | +0.0 | 0.0 | 273.3 |
| FOLLOW UP WEIGHED | 0.7 | +211.8 | 0.0 | 72.3 | 0.3 | +27.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +589.5 | 649.3 | 122.3 | 2.3 | +184.0 | 286.0 | 50.3 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 33.3 |
| FRIEND SHOOTS FIRST | 2.7 | -64.4 | 65.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -6.0 | 156.7 | 72.3 | - | - | - | - |
| GOAL WALK | 0.7 | +63.3 | 0.0 | 0.0 | 13.0 | +1612.5 | 0.0 | 116.0 |
| GUN MASK | 4.7 | +348.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 33.3 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 372.0 | 17.0 | +0.0 | 0.0 | 635.0 |
| HIS CHARGE LIST | - | - | - | - | 6.0 | +0.0 | 0.0 | 152.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 472.0 | 6.3 | +0.0 | 0.0 | 196.7 |
| HIS MOVE AND SHOT | 6.3 | -22.4 | 0.0 | 0.0 | 16.0 | -241.2 | 0.0 | 773.0 |
| HIS MOVE AS HE DECIDES | 39.7 | +11.0 | 996.7 | 0.0 | 33.7 | +9.0 | 494.3 | 0.0 |
| HIS MOVE WHY | 10.3 | +0.0 | 0.0 | 100.0 | 26.3 | +0.0 | 0.0 | 715.0 |
| HIS ONE MOVE | 24.7 | +84.3 | 0.0 | 236.0 | 19.0 | +73.6 | 0.0 | 230.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 134.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 236.0 | 2.7 | +0.0 | 0.0 | 158.0 |
| HIS RANDOM MOVE | 8.7 | +0.0 | 0.0 | 272.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 13.3 | +156.8 | 0.0 | 0.0 | 59.3 | +4605.2 | 0.0 | 1977.0 |
| HIS SHOTS BY HIS RUN | 24.7 | +176.0 | 0.0 | 272.0 | 59.7 | +2344.7 | 0.0 | 1964.3 |
| HIS TURN DENIED | 0.7 | +1.1 | 313.3 | 0.0 | 1.0 | +14.1 | 150.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 107.3 |
| HOLDER ASSIGNMENT | 10.3 | +1006.5 | 0.0 | 0.0 | 10.7 | +990.0 | 0.0 | 53.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -62.0 | 649.3 | 72.3 | 0.7 | -47.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.3 | +51.1 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 21.0 | -373.3 | 0.0 | 521.0 |
| JOINT CHARGE NOW | 1.3 | -242.0 | 313.3 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 186.7 | 0.0 | 2.0 | +0.0 | 122.3 | 316.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +7.0 | 470.0 | 72.3 | 2.0 | -1.6 | 236.0 | 50.3 |
| LOST CHARGE | 0.3 | -0.3 | 0.0 | 50.0 | - | - | - | - |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +7.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +78.4 | 0.0 | 0.0 | 0.7 | +44.3 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +59.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 2.0 | +102.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | +58.2 | 0.0 | 0.0 | 2.0 | +58.7 | 0.0 | 156.7 |
| MAX FOR POSITIONING | 8.3 | +182.3 | 0.0 | 0.0 | 3.3 | +26.6 | 0.0 | 286.7 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 16.3 | +571.9 | 0.0 | 0.0 | 2.7 | +12.6 | 0.0 | 130.0 |
| MISSILES NEXT TURN | 18.0 | +326.4 | 0.0 | 0.0 | 5.7 | +24.3 | 0.0 | 286.7 |
| MISSILES ON ONE TARGET | 1.3 | -32.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 118.0 | 98.3 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 156.7 |
| MOVE TO CHARGE COMPUTED | 10.0 | +679.4 | 0.0 | 0.0 | 5.7 | +445.2 | 0.0 | 33.3 |
| NEARER NOT NEEDED | 6.0 | +265.7 | 0.0 | 0.0 | 6.0 | +226.3 | 0.0 | 73.7 |
| NEXT CHARGE BY LIST | 4.7 | +397.4 | 65.0 | 0.0 | 4.0 | +374.1 | 0.0 | 33.3 |
| NO DOUBLE ROUNDS | 1.7 | -173.6 | 492.7 | 72.3 | 2.0 | -106.5 | 286.0 | 50.3 |
| NOT TURNED | - | - | - | - | 0.3 | -31.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -275.0 | 0.0 | 0.0 | 5.7 | -412.0 | 0.0 | 133.3 |
| OGRE LOADER SECOND SHOT | 13.0 | +134.0 | 56.7 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +41.6 | 156.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 8.7 | -193.1 | 0.0 | 236.0 | 7.0 | -156.2 | 0.0 | 342.0 |
| ONE JOINT FIGURE | 0.7 | +96.8 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.3 | -25.3 | 0.0 | 0.0 | 4.3 | -69.3 | 0.0 | 53.7 |
| OPENS A LANE | 2.0 | +15.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +26.9 | 0.0 | 50.0 | 0.7 | +1.7 | 50.0 | 0.0 |
| PATHS CROSS | 0.3 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -55.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.7 | +1533.7 | 1051.7 | 616.7 | 39.7 | +122.3 | 122.3 | 1592.7 |
| PROMISE BY ITS OWN SUM | 17.3 | -592.2 | 0.0 | 0.0 | 7.0 | -118.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.0 | -0.3 | 0.0 | 33.3 |
| PROMISE READS THE TABLE | 1.7 | -77.0 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.0 | -15.5 | 195.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.7 | +1610.3 | 381.3 | 100.0 | 12.0 | +1770.8 | 50.0 | 419.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +72.2 | 0.0 | 226.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +30.2 | 0.0 | 20.0 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +36.3 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 40.0 |
| REFORMS TO MEET IT | 3.7 | -92.7 | 0.0 | 0.0 | 0.7 | -183.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -14.4 | 649.3 | 122.3 | 1.3 | +63.8 | 150.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -5.5 | 0.0 | 0.0 |
| RUN DOWN | 1.0 | -30.8 | 65.0 | 0.0 | 2.3 | -31.5 | 286.0 | 50.3 |
| SAME CHARGE LATER | 0.3 | -1.9 | 65.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | +86.7 | 0.0 | 40.0 |
| SEARCH SPOT | 1.0 | +12.0 | 0.0 | 0.0 | 0.3 | +13.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -60.1 | 0.0 | 100.0 | 1.3 | -62.6 | 0.0 | 20.0 |
| SET UP BY THE SET | 4.0 | +130.6 | 65.0 | 100.0 | 2.7 | +160.1 | 0.0 | 20.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +72.6 | 156.7 | 156.7 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.7 | 0.0 | 40.0 |
| SHOOTERS ON THE TABLE | 19.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 8.0 | +436.5 | 297.0 | 0.0 | 1.3 | +29.7 | 0.0 | 65.0 |
| SHOT OR CHARGE | 0.7 | -16.6 | 130.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.0 | -59.3 | 0.0 | 136.0 | 47.3 | +628.0 | 0.0 | 1777.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.7 | +1457.2 | 0.0 | 100.0 | 2.0 | +31.7 | 0.0 | 59.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +266.9 | 156.7 | 156.7 |
| SPELL WORTH | 1.3 | +8.7 | 0.0 | 0.0 | 1.7 | +41.5 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 1.0 | -9.8 | 313.3 | 72.3 | 0.7 | +1.4 | 50.0 | 50.3 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 100.0 | 7.7 | +0.0 | 0.0 | 641.7 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 46.3 | +0.0 | 1954.0 | 0.0 | 19.0 | +0.0 | 0.0 | 558.0 |
| STAY WORTH | 34.0 | -372.2 | 1033.3 | 0.0 | 1.0 | +6.6 | 0.0 | 59.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| SUPPORT ADDS | 2.3 | +156.4 | 0.0 | 0.0 | 4.7 | +494.6 | 0.0 | 210.7 |
| SUPPORT NARROWED | 1.0 | +0.0 | 244.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +156.4 | 0.0 | 0.0 | 4.7 | +494.6 | 0.0 | 210.7 |
| SURE REACH TOGETHER | 0.7 | +25.9 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 59.0 |
| THE PROMISE ADDS | 0.7 | -51.0 | 65.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 38.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 218.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.7 | +0.0 | 0.0 | 236.0 | 39.7 | +0.0 | 0.0 | 1063.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +31.6 | 50.0 | 0.0 |
| TIME ON OUR SIDE | 30.7 | +568.8 | 0.0 | 50.0 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.7 | +4.4 | 50.0 | 50.3 |
| WHO HITS BACK | 0.7 | +41.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -455.7 | 0.0 | 372.0 | 4.7 | -578.1 | 0.0 | 272.3 |
| WHOLE FIGHT GAIN | 0.7 | +209.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | - | - | - | - | 1.0 | +53.3 | 50.0 | 65.0 |
| WOUNDS ON THE RANKS | 3.3 | +10.4 | 0.0 | 136.0 | 0.3 | +0.0 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 220 | 220 | 160 | 53.33 | +0 | +0.0 |
| HIS MOVE WHY | 110 | 110 | 77 | 25.67 | +0 | +0.0 |
| ARMY TABLE | 87 | 87 | 64 | 21.33 | +265 | +4.1 |
| HOLDER ASSIGNMENT | 63 | 63 | 57 | 19.00 | +3898 | +68.4 |
| HIS SHOT LIST | 218 | 207 | 52 | 17.33 | +1503 | +28.9 |
| OGRE LOADER SECOND SHOT | 39 | 39 | 39 | 13.00 | +402 | +10.3 |
| FIVE ACTION | 508 | 476 | 38 | 12.67 | +2618 | +68.9 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -2061 | -55.7 |
| HIS ONE MOVE | 131 | 118 | 36 | 12.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 73 | 73 | 35 | 11.67 | -2132 | -60.9 |
| HIS SHOTS BY HIS RUN | 253 | 230 | 34 | 11.33 | +647 | +19.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 27 | 9.00 | +335 | +12.4 |
| SHOT RISK POINTS | 178 | 164 | 27 | 9.00 | +948 | +35.1 |
| THE RISK READS HIS RUN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 47 | 33 | 22 | 7.33 | +1140 | +51.8 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| CHARGE LOSSES | 128 | 116 | 14 | 4.67 | +2418 | +172.7 |
| SET UP BY THE SET | 20 | 20 | 14 | 4.67 | +1055 | +75.3 |
| FOUR ROUNDS | 16 | 15 | 12 | 4.00 | +982 | +81.8 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| NEXT CHARGE BY LIST | 26 | 19 | 12 | 4.00 | +907 | +75.6 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 92 | 69 | 11 | 3.67 | +78 | +7.1 |
| QUARTER ODDS | 83 | 79 | 10 | 3.33 | +1113 | +111.3 |
| CAST JOB | 11 | 11 | 9 | 3.00 | +21 | +2.3 |
| GOAL WALK | 41 | 41 | 9 | 3.00 | +1157 | +128.5 |
| COVER ONCE | 62 | 43 | 8 | 2.67 | +160 | +20.0 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 63 | 45 | 8 | 2.67 | +82 | +10.2 |
| MARCH BY THE SUM | 7 | 7 | 7 | 2.33 | +368 | +52.6 |
| MISSILES IN THE MOVE | 57 | 40 | 7 | 2.33 | +284 | +40.6 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 2.00 | -309 | -51.4 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -47 | -7.8 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 12 | 12 | 5 | 1.67 | -305 | -61.1 |
| FALLS SHORT | 64 | 56 | 5 | 1.67 | +16 | +3.2 |
| GUN MASK | 14 | 14 | 5 | 1.67 | +232 | +46.3 |
| HIS MOVE AND SHOT | 67 | 61 | 5 | 1.67 | +34 | +6.8 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| SHOTS AFTER THE MOVES | 21 | 21 | 5 | 1.67 | +0 | +0.0 |
| SUPPORT ADDS | 21 | 20 | 5 | 1.67 | +236 | +47.3 |
| SUPPORT WORKED OUT | 21 | 20 | 5 | 1.67 | +236 | +47.3 |
| WHOLE FIGHT DANGER | 22 | 22 | 5 | 1.67 | +610 | +122.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -726 | -181.5 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +48 | +12.1 |
| RISK BY ARC | 11 | 10 | 4 | 1.33 | +128 | +31.9 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +77 | +19.3 |
| CHAFF IN THE MOVE | 7 | 6 | 3 | 1.00 | +4 | +1.5 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +718 | +239.3 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 3 | 1.00 | +217 | +72.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +122 | +60.9 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +347 | +173.3 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MAX FOR POSITIONING | 35 | 30 | 2 | 0.67 | +17 | +8.3 |
| NEARER NOT NEEDED | 36 | 35 | 2 | 0.67 | +76 | +37.8 |
| ONE FIGHT FORMULA | 47 | 27 | 2 | 0.67 | +42 | +21.2 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| SHOTS IN THE MOVE | 59 | 41 | 2 | 0.67 | +415 | +207.5 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -14 | -7.0 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +99 | +49.5 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +271 | +135.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +14 | +13.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -30 | -29.7 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 1 | 0.33 | +32 | +32.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 4 | 3 | 1 | 0.33 | +28 | +28.3 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +10 | +10.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| MANOEUVRE | 2 | 2 | 1 | 0.33 | +24 | +23.6 |
| MISSILES NEXT TURN | 71 | 47 | 1 | 0.33 | +12 | +11.8 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +32 | +32.4 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +93 | +93.3 |
| ONE OBJECTIVE FORMULA | 29 | 25 | 1 | 0.33 | +199 | +199.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +58 | +57.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -167 | -167.2 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 1 | 0.33 | -1 | -1.0 |
| RUN DOWN | 10 | 9 | 1 | 0.33 | +10 | +10.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +17 | +17.1 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 105 | 94 | 1 | 0.33 | +2 | +2.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +65 | +65.1 |
| WHOLE FIGHT REACTION | 3 | 3 | 1 | 0.33 | +65 | +65.3 |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 35 | 35 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 13 | 12 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 80 | 70 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 43 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 26 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 91 | 91 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 11 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 4 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 11 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 5 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 235 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 35 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 196 | 188 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 244 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 10.00 | 1.67 | 60.9 |
| JOB FIRST | gate | 6.33 | 4.67 | 55.5 |
| ARMY TABLE | rule | 0.67 | 2.67 | 172.0 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 7.8 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 61.1 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 22.0 |
| MARCH OF THE TABLE | rule | 1.67 | - | 61.7 |
| JOINT CHARGE NOW | rule | 1.00 | - | 245.6 |
| NO REASON | gate | - | 0.67 | 61.7 |
| SUPPORT NARROWED | rule | 0.67 | - | 7.0 |
| BEST PRIZE | rule | 0.33 | - | 29.7 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 167.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.0 |
| RULE SWITCHED OFF | gate | 0.33 | - | 13.0 |
| TURN GATE | gate | - | 0.33 | 93.3 |

### Plans: wfr-a92c160-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 344 | 493 | 143% |
| Mine | move | 21.0 | 97% | 1524 | 0 | 0% |
| Mine | shoot | 15.3 | 63% | 1401 | 1041 | 74% |
| Opponent | charge | 1.3 | 50% | 83 | 114 | 138% |
| Opponent | join | 2.3 | 86% | 164 | 0 | 0% |
| Opponent | move | 34.3 | 93% | 2220 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 11 | 8 | 71% |
| Opponent | support | 0.7 | 100% | 81 | 0 | 0% |

### Battle groups: wfr-a92c160-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 59 (9) | 59 | 0 | 10 | 11% | 2.8 | 23 (3) | 70 (6) | - | 57 (5) | 60 (4) |
| Mine | Clean-up | 2 | 58 (2) | 0 | 58 | 0 | 0% | 2.0 | 0 (1) | 108 (1) | - | 58 (2) | - |
| Mine | Fast Hammer | 4 | 53 (4) | 17 | 35 | 70 | 25% | 3.3 | 59 (2) | 50 (2) | - | 82 (3) | 0 (1) |
| Mine | Holder | 1 | 193 (1) | 0 | 193 | 0 | 0% | 1.0 | 193 (1) | - | - | 193 (1) | - |
| Mine | Shooter | 4 | 43 (4) | 9 | 34 | 0 | 0% | 1.5 | 53 (3) | 0 (1) | - | 43 (4) | - |
| Mine | War machine | 6 | 58 (6) | 58 | 0 | 0 | 0% | 1.0 | 173 (2) | 0 (2) | 0 (2) | 276 (1) | 14 (5) |
| Mine | Wizard | 3 | 45 (3) | 45 | 0 | 0 | 0% | 1.3 | 35 (2) | 53 (1) | - | 45 (3) | - |
| Opponent | Chaff | 2 | 300 (2) | 0 | 300 | 50 | 100% | - | - | 600 (1) | 0 (1) | 300 (2) | - |
| Opponent | Character | 10 | 8 (10) | 8 | 0 | 39 | 60% | 2.0 | 0 (3) | 17 (5) | 0 (2) | 0 (5) | 17 (5) |
| Opponent | Fast Hammer | 9 | 59 (9) | 18 | 41 | 51 | 44% | 4.0 | 10 (2) | 71 (7) | - | 51 (5) | 69 (4) |
| Opponent | Hammer | 3 | 41 (3) | 41 | 0 | 75 | 33% | 3.0 | 0 (2) | 111 (1) | - | 0 (2) | 111 (1) |
| Opponent | Holder | 5 | 61 (5) | 29 | 32 | 0 | 80% | 6.0 | 0 (1) | 93 (2) | 132 (1) | 88 (3) | 0 (1) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: wfr-a92c160-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 525 | 222 | 1.3 | 1.2 | 166 | 0 | +166 | 4 of 4 | 4 of 4 | +470 | +65 |
| Opponent | High Elf Realms | 1 | 0 | 150 | 4.0 | 1.0 | 38 | 0 | +38 | 1 of 4 | 3 of 4 | - | +38 |
| Opponent | Vampire Counts | 1 | 217 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 558 | 2.0 | 1.0 | 279 | 0 | +279 | 1 of 2 | 2 of 2 | - | +279 |
| **Opponent** | all armies | 3 | 72 | 236 | 2.3 | 1.0 | 101 | 0 | +101 | 3 of 7 | 6 of 7 | - | +101 |

### Effective charges: wfr-a92c160-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 4 | 0 | 0 | 1 (net +195) | 1 (net +0) | 0 | 2 (net +235) | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 4 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +75) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 2 | 1 (net +408) | 0 | 0 | 0 | 0 | 1 (net +150) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: wfr-a92c160-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 369 | 195 | +195 | 195 | 0 | +195 | +52.8 |
| Mine | 76-89% | 1 | 217 | 470 | +0 | 12 | 0 | +12 | +5.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 440 | 406 | +235 | 301 | 24 | +277 | +62.8 |
| Mine | All fights | 4 | 367 | 370 | +166 | 202 | 12 | +190 | +51.8 |
| Opponent | Long shot (under 50%) | 2 | 148 | 364 | +204 | 253 | 21 | +232 | +157.6 |
| Opponent | Effective (55-75%) | 1 | 489 | 97 | +0 | 48 | 0 | +48 | +9.9 |
| Opponent | 76-89% | 2 | 143 | 150 | +75 | 75 | 0 | +75 | +52.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 201 | 150 | +150 | 150 | 100 | +50 | +24.6 |
| Opponent | No odds | 1 | 50 | 217 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 7 | 189 | 213 | +101 | 122 | 20 | +102 | +54.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p7 | move | 35 | 7 (20%) | 5 (14%) | 1 (3%) | 27 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

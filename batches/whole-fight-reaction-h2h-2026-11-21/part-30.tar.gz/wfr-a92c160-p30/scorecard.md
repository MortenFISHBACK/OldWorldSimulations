# Doctrine scorecard: wfr-a92c160-p30

### Scorecard: wfr-a92c160-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 4 | 3 | 3 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0930 | 6 | 1 | Opponent | no | 12 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 11 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 6.0 | 3.0 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 306.7 |
| **Average** | | | Opponent | 0% | 5.3 | 3.0 | 1.0 | 2.3 | 0.7 | 0.0 | 0.0 | 143.3 |

### KPIs: wfr-a92c160-p30

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (5 of 13) | 0% (0 of 11) | 21% (5 of 24) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% | 50% (2 of 4); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 56% (27 of 48) | 8% (1 of 12) | 47% (28 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 59% (27 of 46) | 8% (1 of 12) | 48% (28 of 58) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 77% (4647 of 5997) | 78% (4651 of 5999) | 78% (9298 of 11996) |
|   infantry points that never fought | lower | 93% (1487 of 1591) | 90% (1488 of 1660) | 92% (2975 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (23 of 34) | 74% (17 of 23) | 70% (40 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3863 of 5667) | 72% (3688 of 5150) | 70% (7551 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (67%) | 2.7 (73%) | 7.3 (69%) |
| MARCHED: its unit marched | 1.7 (24%) | 0.7 (18%) | 2.3 (22%) |
| IN COMBAT: engaged in combat | 0.7 (10%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.0 | 1.3 | 9.3 | 0.3 | 0.7 |
| not cast | 0.0 | 5.0 | 0.7 | 10.7 | 1.7 | 19.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 4.0 (80%) | 0.0 (0%) | 7.3 (69%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 2.3 (22%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 1.0 (20%) | 0.0 (0%) | 0.3 (3%) | 1.3 (80%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 100% (4 of 4) | 100% (4 of 4) |
| the unit moved after it | - | 25% (1 of 4) | 25% (1 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (75 of 118) | 79% (38 of 48) | 68% (113 of 166) |
|   character | 100% (7 of 7) | 64% (7 of 11) | 78% (14 of 18) |
|   chariot | 69% (11 of 16) | 100% (6 of 6) | 77% (17 of 22) |
|   infantry | 46% (23 of 50) | 68% (13 of 19) | 52% (36 of 69) |
|   monster | 64% (7 of 11) | - | 64% (7 of 11) |
|   war machine | 79% (27 of 34) | 100% (12 of 12) | 85% (39 of 46) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (16%) | 2.3 (70%) | 4.7 (26%) |
| CHARGED: it charged | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 3.7 (26%) | 1.0 (30%) | 4.7 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (9%) | 0.0 (0%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (23%) | 0.0 (0%) | 3.3 (19%) |
| SHELTERED: the target was sheltered | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.7 | 1.0 | 79% | 5.0 pts | 23 pts |
| chariot | 5.7 | 2.3 | 76% | 19.2 pts | 109 pts |
| infantry | 14.7 | 7.7 | 61% | 11.2 pts | 164 pts |
| monster | 4.3 | 1.7 | 85% | 9.3 pts | 40 pts |
| war machine | 13.0 | 11.0 | 62% | 26.2 pts | 341 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.3 | 1.3 |
| Charges that made contact a game | 1.3 | 0.7 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.17 declared, 0.09 contact (23 units) | 0.16 declared, 0.12 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 100% (7 of 7) | 100% (2 of 2) | - | 100% (9 of 9) |
| Character on its own | - | 75% (3 of 4) | 50% (2 of 4) | 62% (5 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (5 of 14) | 100% (4 of 4) | - | 50% (9 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 62% (15 of 24) | 79% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 0% (0 of 1); on the table 0% | 50% (12 of 24) | 75% | 70% (7 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 83% | 38% (3 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 17% (1 of 6) | 78% | 100% (9 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 72% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 50% (2) | 60% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 19% (11 of 57) | 55% (12 of 22) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 9) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 306.7 | 143.3 |
| Movement | Fights charged into per game | 1.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net -390 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 2, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +0 | 1 of 2, net +125 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (28 of 48) | 67% (20 of 30) |
| Shooting | Points destroyed by shooting units | 159.7 | 75.7 |
| Shooting | War machine shots | 9.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (11 of 27) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 381.7 | 0.0 |
| Magic | Magic missiles cast | 5.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 18% (3 of 17) | - |
| Magic | Wounds caused by magic missiles | 10.0 | 2.3 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 85.0 | 56.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.3 / 0.3 | 3.3 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 171.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -43 | +114 |
| Combat | Net per 100 charger points, damage counted | -17.2 | +33.5 |
| Combat | First round won (charged fights) | 50% | 100% |
| Combat | Net points per charged fight | -98 | +114 |
| Combat | Net points per supported fight / lone fight | - / -98 | - / +114 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 0 of 2 |
| Game | Points lost | 380.3 | 576.3 |
| Game | VP from objectives | 736.7 | 813.3 |
| Game | Lone holders (player turns) | 6.0 | 5.3 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +183 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 957
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +32.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.3 | +868.2 | 0.0 | 151.3 | 26.0 | +248.1 | 0.0 | 270.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -4.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 151.3 | 0.0 |
| CANNON PLANNED TARGET | 9.0 | +535.1 | 902.7 | 125.0 | 4.0 | +207.8 | 310.3 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 41.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 5.7 | +102.2 | 0.0 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +23.1 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -2.2 | 41.7 | 0.0 |
| CHARACTER GUNS | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -722.3 | 0.0 | 186.0 | 30.7 | -1840.9 | 0.0 | 1249.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 48.3 | 0.0 | 1.0 | +0.0 | 76.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +129.6 | 99.0 | 0.0 |
| COVER ONCE | 11.3 | -1091.7 | 0.0 | 117.3 | 3.0 | -119.8 | 0.0 | 32.7 |
| DEFENSIVE ARMY | 1.7 | +0.0 | 638.7 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -24.7 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 41.7 | 7.0 | +37.9 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +9.6 | 48.3 | 88.3 | 1.0 | +6.6 | 41.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 48.3 | 0.0 | 1.3 | +0.0 | 76.3 | 0.0 |
| FALLS SHORT | 2.3 | +32.3 | 0.0 | 0.0 | 26.7 | +287.1 | 0.0 | 230.7 |
| FEATURE BUFFS | 2.0 | +37.3 | 0.0 | 0.0 | 4.0 | +72.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 100.3 | +9263.4 | 2751.0 | 677.0 | 101.3 | +6056.8 | 1110.7 | 1630.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 32.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +163.4 | 0.0 | 159.7 |
| FOUR ROUNDS | 1.3 | +62.9 | 48.3 | 88.3 | 1.3 | +38.8 | 76.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -21.4 | 0.0 | 0.0 | 0.7 | -2.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -4.6 | 0.0 | 0.0 |
| GOAL WALK | 8.3 | +1445.7 | 0.0 | 0.0 | 14.7 | +1629.0 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +129.7 | 198.0 | 0.0 | 1.3 | +0.1 | 0.0 | 21.7 |
| GUN MASK | 3.3 | +49.7 | 0.0 | 0.0 | 0.7 | +35.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 151.3 | 9.3 | +0.0 | 0.0 | 183.7 |
| HIS CHARGE DENIED | 0.3 | +22.3 | 0.0 | 88.3 | - | - | - | - |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 140.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -14.0 | 0.0 | 0.0 | 4.0 | -62.3 | 0.0 | 261.3 |
| HIS MOVE AS HE DECIDES | 44.3 | +12.3 | 696.7 | 0.0 | 38.3 | +15.3 | 397.3 | 0.0 |
| HIS MOVE WHY | - | - | - | - | 45.3 | +0.0 | 0.0 | 718.3 |
| HIS ONE MOVE | 15.7 | -24.6 | 0.0 | 34.7 | 18.7 | -54.9 | 30.0 | 390.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 75.7 | 7.3 | +0.0 | 0.0 | 73.3 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 16.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.0 | +728.1 | 0.0 | 118.0 | 75.3 | +4930.5 | 0.0 | 1478.0 |
| HIS SHOTS BY HIS RUN | 29.3 | +716.7 | 0.0 | 186.0 | 79.3 | +2214.9 | 0.0 | 1457.7 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +173.6 | 76.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 0.0 | 32.0 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 12.0 | +1147.2 | 0.0 | 0.0 | 16.3 | +1498.6 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -11.9 | 48.3 | 88.3 | 1.3 | -41.7 | 76.3 | 0.0 |
| IDLE COST | 0.3 | -2.9 | 0.0 | 0.0 | 15.0 | -279.7 | 0.0 | 267.3 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 159.7 | 164.0 | 4.3 | +0.0 | 247.3 | 1789.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -7.0 | 0.0 | 0.0 | 0.3 | +14.8 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +4.1 | 48.3 | 88.3 | 0.7 | +0.0 | 34.7 | 0.0 |
| MANOEUVRE | 3.0 | -27.8 | 0.0 | 0.0 | 3.0 | -7.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +38.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +90.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -232.9 | 0.0 | 0.0 | 0.7 | +35.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +38.3 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.7 | +398.8 | 0.0 | 0.0 | 2.3 | +65.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 14.7 | +272.7 | 0.0 | 0.0 | 5.7 | +43.9 | 0.0 | 180.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 99.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +147.2 | 0.0 | 0.0 | 1.7 | +218.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 13.0 | +624.5 | 0.0 | 34.7 | 9.0 | +413.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +70.7 | 0.0 | 0.0 | 1.7 | +218.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -57.7 | 48.3 | 88.3 | 1.3 | -38.3 | 76.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -268.9 | 0.0 | 34.7 | 2.0 | -51.3 | 0.0 | 15.0 |
| OGRE LOADER SECOND SHOT | 2.7 | +26.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -99.2 | 0.0 | 0.0 | 2.3 | -44.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.0 | -61.7 | 0.0 | 0.0 | 7.7 | +120.3 | 0.0 | 32.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +15.6 | 34.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +11.0 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +1235.5 | 1086.7 | 647.3 | 46.0 | +312.7 | 387.3 | 1049.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -142.3 | 0.0 | 0.0 | 2.0 | -16.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -9.2 | 48.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.0 | +2331.2 | 650.0 | 151.3 | 23.3 | +2048.4 | 756.7 | 836.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +46.6 | 0.0 | 193.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +19.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -31.9 | 48.3 | 0.0 | 1.3 | -3.3 | 76.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -18.1 | 76.3 | 0.0 |
| RUN DOWN | 1.0 | -19.1 | 48.3 | 0.0 | 1.0 | -6.5 | 34.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -95.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +20.4 | 0.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.7 | +0.0 | 0.0 | 159.7 | 7.7 | +0.0 | 0.0 | 21.7 |
| SHOOTS FROM THE BEST SPOT | 6.0 | +301.7 | 473.0 | 0.0 | 2.3 | +37.1 | 69.3 | 0.0 |
| SHOT OR CHARGE | 1.3 | -70.6 | 0.0 | 88.3 | 0.7 | -23.6 | 41.7 | 0.0 |
| SHOT RISK POINTS | 11.3 | -182.7 | 0.0 | 186.0 | 50.7 | -335.3 | 0.0 | 1586.7 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.3 | +1735.6 | 0.0 | 277.0 | 12.0 | +523.8 | 0.0 | 142.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +96.2 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 34.7 | 8.3 | +0.0 | 0.0 | 397.3 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -8.1 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.7 | +0.0 | 2702.7 | 554.0 | 36.0 | +0.0 | 1034.3 | 170.0 |
| STAY WORTH | 40.0 | +426.1 | 1221.7 | 333.3 | 20.0 | +259.3 | 511.0 | 120.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +51.7 | 0.0 | 0.0 | 3.3 | +108.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +51.7 | 0.0 | 0.0 | 3.3 | +108.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +0.5 | 0.0 | 0.0 | 0.7 | +13.2 | 0.0 | 99.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 201.7 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 114.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 21.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 15.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.0 | +0.0 | 0.0 | 235.3 | 48.3 | +0.0 | 0.0 | 685.7 |
| TIED UP BY THE SUM | 0.7 | +62.8 | 48.3 | 0.0 | 0.7 | +69.2 | 76.3 | 0.0 |
| TIME ON OUR SIDE | 36.3 | +542.9 | 0.0 | 49.7 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +10.1 | 0.0 | 159.7 |
| WHOLE FIGHT DANGER | 5.0 | -372.6 | 0.0 | 0.0 | 2.3 | -337.9 | 0.0 | 65.3 |
| WHOLE FIGHT REACTION | 1.3 | +23.0 | 0.0 | 76.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +3.9 | 0.0 | 0.0 | 3.0 | +123.9 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 248 | 248 | 165 | 55.00 | +0 | +0.0 |
| HIS MOVE WHY | 136 | 136 | 94 | 31.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 326 | 319 | 90 | 30.00 | +1449 | +16.1 |
| HIS SHOT LIST | 331 | 321 | 87 | 29.00 | +2272 | +26.1 |
| HOLDER ASSIGNMENT | 85 | 85 | 80 | 26.67 | +5859 | +73.2 |
| ARMY TABLE | 127 | 127 | 75 | 25.00 | +2746 | +36.6 |
| HIS ONE MOVE | 103 | 103 | 40 | 13.33 | +0 | +0.0 |
| SHOT RISK POINTS | 186 | 180 | 35 | 11.67 | +1164 | +33.3 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -960 | -43.7 |
| GOAL WALK | 69 | 69 | 20 | 6.67 | +2943 | +147.1 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 19 | 6.33 | +178 | +9.3 |
| FIVE ACTION | 605 | 593 | 16 | 5.33 | +1036 | +64.8 |
| CAST JOB | 19 | 19 | 15 | 5.00 | +78 | +5.2 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| QUARTER ODDS | 121 | 114 | 15 | 5.00 | +1014 | +67.6 |
| THE RISK READS HIS RUN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 109 | 94 | 12 | 4.00 | +28 | +2.3 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| STAY WORTH | 180 | 167 | 11 | 3.67 | +56 | +5.1 |
| CHARGE LOSSES | 137 | 131 | 10 | 3.33 | +789 | +78.9 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 43 | 36 | 8 | 2.67 | +285 | +35.7 |
| MOVE TO CHARGE COMPUTED | 14 | 14 | 8 | 2.67 | +270 | +33.7 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +80 | +10.0 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 8 | 2.67 | -475 | -59.4 |
| SHOTS IN THE MOVE | 124 | 97 | 8 | 2.67 | +927 | +115.9 |
| SHOTS AFTER THE MOVES | 22 | 22 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 46 | 40 | 6 | 2.00 | +53 | +8.8 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +140 | +23.3 |
| CANNON PLANNED TARGET | 39 | 39 | 5 | 1.67 | -19 | -3.8 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FEATURE BUFFS | 18 | 18 | 4 | 1.33 | +46 | +11.4 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +116 | +29.0 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +97 | +24.2 |
| MAX FOR POSITIONING | 16 | 15 | 4 | 1.33 | +11 | +2.7 |
| NEARER NOT NEEDED | 66 | 60 | 4 | 1.33 | +143 | +35.7 |
| NEXT CHARGE BY LIST | 9 | 9 | 4 | 1.33 | +143 | +35.8 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +121 | +30.4 |
| SUPPORT ADDS | 16 | 16 | 4 | 1.33 | +11 | +2.8 |
| SUPPORT WORKED OUT | 16 | 16 | 4 | 1.33 | +11 | +2.8 |
| THE ROW IN ITS ORDER | 29 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 3 | 1.00 | -233 | -77.6 |
| FALLS SHORT | 87 | 72 | 3 | 1.00 | +29 | +9.8 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +490 | +163.3 |
| FOUR ROUNDS | 8 | 8 | 3 | 1.00 | +18 | +6.1 |
| GUN MASK | 12 | 12 | 3 | 1.00 | +64 | +21.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 48 | 32 | 3 | 1.00 | +36 | +11.9 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +103 | +34.2 |
| WHOLE FIGHT DANGER | 22 | 20 | 3 | 1.00 | +107 | +35.6 |
| EXACT ROUND | 5 | 5 | 2 | 0.67 | +14 | +7.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -24 | -12.1 |
| ONE OBJECTIVE FORMULA | 41 | 32 | 2 | 0.67 | +42 | +20.9 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -28 | -13.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| WHOLE FIGHT REACTION | 4 | 4 | 2 | 0.67 | +28 | +14.1 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +99 | +98.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -15 | -14.6 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -6.6 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +9 | +9.2 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +184 | +184.1 |
| LOST AFTER ESCAPE | 6 | 6 | 1 | 0.33 | +4 | +4.3 |
| MANOEUVRE | 18 | 18 | 1 | 0.33 | +19 | +18.8 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +9 | +9.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -29 | -28.6 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +39 | +38.9 |
| SET UP BY THE SET | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| SURE REACH TOGETHER | 4 | 3 | 1 | 0.33 | +19 | +19.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 25 | 25 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 47 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 50 | 46 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 150 | 150 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 61 | 43 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 79 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 19 | 19 | 0 | 0.00 | - | - |
| STANDS STILL | 257 | 250 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 283 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 1.33 | 50.0 |
| ARMY TABLE | rule | 1.00 | 4.00 | 45.5 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 0.33 | 59.4 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 14.0 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 77.6 |
| MARCH OF THE TABLE | rule | 0.67 | - | 12.1 |
| NO REASON | gate | 0.67 | - | 25.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 28.1 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| AFTERMATH BAND | gate | 0.33 | - | 2.5 |
| BEST PRIZE | rule | - | 0.33 | 14.6 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 65.8 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 28.6 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 27.1 |

### Plans: wfr-a92c160-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 78 | 68 | 87% |
| Mine | move | 27.3 | 96% | 2273 | 0 | 0% |
| Mine | shoot | 15.3 | 50% | 1354 | 1168 | 86% |
| Opponent | charge | 1.3 | 50% | 299 | 90 | 30% |
| Opponent | move | 37.7 | 96% | 2289 | 0 | 0% |
| Opponent | shoot | 6.0 | 44% | 269 | 223 | 83% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p30

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 16 (10) | 16 | 0 | 3 | 40% | 2.7 | 23 (6) | 0 (4) | - | 24 (6) | 0 (4) |
| Mine | Clean-up | 3 | 93 (3) | 0 | 93 | 0 | 100% | - | 0 (1) | 142 (2) | - | 93 (3) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 3.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Hammer | 6 | 21 (6) | 21 | 0 | 35 | 33% | 1.8 | 0 (2) | 31 (4) | - | 25 (5) | 0 (1) |
| Mine | Shooter | 6 | 197 (6) | 77 | 120 | 17 | 0% | 1.5 | 0 (1) | 173 (3) | 331 (2) | 197 (6) | - |
| Mine | War machine | 8 | 79 (8) | 79 | 0 | 46 | 0% | 1.5 | 0 (3) | 26 (3) | 227 (2) | 0 (1) | 89 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 3.2 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 288 (2) | 0 | 288 | 0 | 100% | - | 514 (1) | 0 (1) | - | 514 (1) | 0 (1) |
| Opponent | Character | 9 | 23 (9) | 23 | 0 | 49 | 44% | 2.0 | 0 (1) | 21 (7) | 67 (1) | 13 (7) | 42 (2) |
| Opponent | Clean-up | 3 | 73 (3) | 0 | 73 | 0 | 100% | - | 0 (1) | 133 (2) | - | 133 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 58 (6) | 0 | 58 | 10 | 83% | 1.0 | - | 90 (4) | 8 (2) | 58 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 43 | 25% | 2.0 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 0 | 50% | 5.5 | - | 0 (4) | - | 0 (2) | 0 (2) |
| Opponent | Shooter | 4 | 85 (4) | 85 | 0 | 28 | 25% | 2.0 | 0 (1) | 0 (1) | 117 (2) | 98 (3) | 0 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 437 | 0 | 1.0 | 1.0 | 0 | 195 | -195 | 1 of 2 | 1 of 2 | - | -195 |
| Mine | Grand Cathay | 1 | 1005 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 3 | 626 | 0 | 1.3 | 1.0 | 0 | 98 | -98 | 1 of 4 | 2 of 4 | - | -98 |
| Opponent | High Elf Realms | 1 | 397 | 229 | 2.0 | 1.0 | 114 | 0 | +114 | 0 of 2 | 2 of 2 | - | +114 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 132 | 76 | 0.7 | 1.0 | 114 | 0 | +114 | 0 of 2 | 2 of 2 | - | +114 |

### Effective charges: wfr-a92c160-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 1 (net -390) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +104) | 1 (net +125) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: wfr-a92c160-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 265 | 479 | -390 | 204 | 432 | -227 | -85.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 244 | 106 | +0 | 41 | 22 | +19 | +7.7 |
| Mine | All fights | 4 | 249 | 199 | -98 | 82 | 125 | -43 | -17.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 342 | 125 | +125 | 125 | 0 | +125 | +36.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 342 | 104 | +104 | 104 | 0 | +104 | +30.4 |
| Opponent | All fights | 2 | 342 | 114 | +114 | 114 | 0 | +114 | +33.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p30 | move | 12 | 2 (17%) | 2 (17%) | 0 (0%) | 10 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

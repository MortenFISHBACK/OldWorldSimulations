# Doctrine scorecard: wfr-a92c160-p21

### Scorecard: wfr-a92c160-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 5 | 1 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1727 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 3.5 | 1.5 | 3.5 | 1.0 | 0.0 | 0.0 | 0.0 | 100.0 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 2.0 | 2.5 | 1.5 | 0.0 | 0.0 | 85.0 |

### KPIs: wfr-a92c160-p21

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 12) | 0% (0 of 24) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 67% (2 of 3); on the table 67% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | - | 62% (5 of 8) | 62% (5 of 8) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 71% (5 of 7) | 71% (5 of 7) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 58% (7 of 12) | 58% (7 of 12) |
| Points that never fought | lower | 51% (2024 of 4000) | 35% (1397 of 3999) | 43% (3421 of 7999) |
|   infantry points that never fought | lower | 67% (638 of 959) | 35% (236 of 681) | 53% (874 of 1640) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (9 of 13) | 58% (11 of 19) | 62% (20 of 32) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (2507 of 3520) | 48% (1870 of 3884) | 59% (4377 of 7404) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (67%) | 0.7 (67%) |
| GONE: slain | - | 0.3 (33%) | 0.3 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 1.3 | 1.7 | 1.7 | 1.7 |
| not cast | 4.0 | 0.7 | 0.3 | 1.0 | 9.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 1.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (8%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (75%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (31 of 55) | 14% (1 of 7) | 52% (32 of 62) |
|   cavalry | 69% (9 of 13) | 20% (1 of 5) | 56% (10 of 18) |
|   character | 20% (2 of 10) | 0% (0 of 2) | 17% (2 of 12) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 50% (8 of 16) | - | 50% (8 of 16) |
|   war machine | 100% (10 of 10) | - | 100% (10 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (58%) | 0.7 (33%) | 5.3 (53%) |
| CHARGED: it charged | 1.3 (17%) | 0.7 (33%) | 2.0 (20%) |
| FLEEING: it fled or was fleeing | 0.7 (8%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET IN RANGE | 1.3 (17%) | 0.7 (33%) | 2.0 (20%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 3.7 | 2.0 | 55% | 19.2 pts | 70 pts |
| war machine | 3.3 | 1.7 | 60% | 16.8 pts | 56 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 2.0 | 2.5 |
| Charges that made contact a game | 2.0 | 1.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.27 contact (22 units) | 0.29 declared, 0.14 contact (21 units) | 0.35 declared, 0.21 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 67% (2 of 3) | 100% (1 of 1) | 71% (5 of 7) |
| Character in a unit | - | - | 100% (1 of 1) | 100% (1 of 1) |
| Character on its own | 75% (3 of 4) | 100% (2 of 2) | 40% (2 of 5) | 64% (7 of 11) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 50% (3 of 6) | 33% (1 of 3) | - | 44% (4 of 9) |
| Monster | 67% (2 of 3) | - | - | 67% (2 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (3 of 3); on the table 100% | - | 54% | 57% (4 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 48% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 67% (2 of 3); on the table 67% | 83% (5 of 6) | 35% | 58% (11 of 19) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 80% (4) | 67% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: wfr-a92c160-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 14% (1 of 7) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 71% (15 of 21) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | - | 100% (1 of 1) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 2.5 |
| Movement | Points that never moved of their own | 100.0 | 85.0 |
| Movement | Fights charged into per game | 2.5 | 1.5 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 4, net -110 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +98 | 2 of 2, net +138 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.7 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (11 of 23) | 60% (3 of 5) |
| Shooting | Points destroyed by shooting units | 38.7 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (4 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.0 | 1.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.0 / 0.0 / 0.0 | 0.0 / 0.0 / 1.7 / 0.0 |
| Combat | Points destroyed in combat | 276.7 | 248.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +39 | +146 |
| Combat | Net per 100 charger points, damage counted | +8.5 | +46.5 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | +29 | +127 |
| Combat | Net points per supported fight / lone fight | - / +29 | - / +127 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 5 | 0 of 3 |
| Game | Points lost | 761.5 | 423.0 |
| Game | VP from objectives | 750.0 | 1070.0 |
| Game | Lone holders (player turns) | 3.5 | 0.0 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -678 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1184
- Games not ended: 1 (L1727-1); findings 1, warnings 0

### Opponent rules: wfr-a92c160-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 14.3 | +351.9 | 0.0 | 203.3 | 16.7 | -116.7 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 1.3 | +7.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.3 | +62.9 | 0.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.3 | +9.8 | 260.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +79.3 | 0.0 | 0.0 | 2.7 | +63.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +86.1 | 0.0 | 198.7 | 0.7 | +24.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.3 | -334.0 | 0.0 | 224.0 | 14.3 | -1320.3 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 125.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 157.0 | 0.3 | +0.0 | 0.0 | 56.7 |
| COVER ONCE | 8.0 | -475.1 | 0.0 | 132.0 | 8.3 | -1087.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -115.9 | 112.0 | 0.0 |
| EXACT ROUND | 1.7 | +11.4 | 121.7 | 157.0 | 1.0 | +4.0 | 33.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +6.1 | 0.0 | 91.7 | 1.0 | +0.0 | 112.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 14.7 | +233.9 | 0.0 | 0.0 |
| FEATURE BUFFS | 0.7 | +8.6 | 0.0 | 0.0 | 2.0 | +144.2 | 0.0 | 0.0 |
| FIGHT LIFT | 1.0 | +57.3 | 157.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +3.3 | 0.0 | 91.7 | 0.3 | +6.4 | 0.0 | 0.0 |
| FIVE ACTION | 61.3 | +4497.0 | 536.3 | 690.7 | 62.7 | +3979.8 | 349.0 | 130.0 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 147.7 | 8.7 | +0.0 | 0.0 | 65.0 |
| FOLLOW UP WEIGHED | 1.3 | +340.2 | 0.0 | 157.0 | 0.3 | +141.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +301.0 | 121.7 | 248.7 | 2.0 | +91.1 | 349.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -9.8 | 0.0 | 20.0 | 1.0 | -18.7 | 0.0 | 0.0 |
| GIVES UP | 1.3 | -17.1 | 56.7 | 157.0 | - | - | - | - |
| GOAL WALK | 9.7 | +793.8 | 0.0 | 0.0 | 7.7 | +595.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 20.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 224.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +2.8 | 0.0 | 157.0 | 0.3 | +6.3 | 91.7 | 0.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.3 | -10.8 | 0.0 | 0.0 | 2.7 | -31.3 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 30.3 | +7.3 | 207.3 | 0.0 | 28.0 | +7.7 | 655.7 | 0.0 |
| HIS MOVE WHY | 13.0 | +0.0 | 0.0 | 40.0 | 19.7 | +0.0 | 0.0 | 0.0 |
| HIS ONE MOVE | 15.7 | -51.4 | 0.0 | 132.0 | 19.0 | -2.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 147.7 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 17.0 | +0.0 | 0.0 | 244.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 224.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 8.7 | +211.1 | 0.0 | 71.3 | 30.0 | +596.9 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 15.3 | +296.6 | 0.0 | 224.0 | 39.3 | +1090.1 | 0.0 | 0.0 |
| HIS TURN DENIED | 0.3 | +10.3 | 0.0 | 0.0 | 0.7 | +26.2 | 33.3 | 0.0 |
| HIS TURN RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 9.0 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.0 | +577.5 | 0.0 | 0.0 | 6.3 | +603.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -59.7 | 121.7 | 91.7 | 1.7 | -65.0 | 237.0 | 0.0 |
| HUNT DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +92.9 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 13.0 | -175.1 | 0.0 | 38.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -25.6 | 224.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 16.0 | +0.0 | 431.7 | 385.3 | 3.3 | +0.0 | 228.3 | 620.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +29.2 | 91.7 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +1.4 | 0.0 | 248.7 | 1.0 | +3.0 | 112.0 | 0.0 |
| MANOEUVRE | 1.3 | -16.7 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +19.0 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +114.1 | 0.0 | 0.0 | 0.3 | +41.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +29.9 | 0.0 | 0.0 | 3.3 | +84.5 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +30.1 | 0.0 | 0.0 | 1.3 | +56.0 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.3 | +30.6 | 0.0 | 0.0 | 2.7 | +47.7 | 0.0 | 65.0 |
| MOVE ORDER | 0.7 | +0.0 | 20.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +284.5 | 0.0 | 20.0 | 6.7 | +618.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +372.9 | 0.0 | 0.0 | 3.3 | +138.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +147.1 | 0.0 | 0.0 | 2.7 | +307.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.6 | 0.0 | 0.0 | 0.3 | -30.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -156.5 | 121.7 | 248.7 | 1.0 | -12.9 | 125.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -128.7 | 56.7 | 35.7 | 3.0 | -37.6 | 0.0 | 38.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -130.2 | 0.0 | 20.0 | 6.3 | -136.9 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +192.6 | 224.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -37.5 | 0.0 | 0.0 | 3.3 | +98.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +1.1 | 20.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +30.0 | 33.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +17.9 | 0.0 | 0.0 |
| PLAN RESULT | 27.3 | +285.3 | 199.0 | 722.3 | 30.7 | +138.3 | 0.0 | 264.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -271.6 | 0.0 | 0.0 | 8.0 | -179.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -8.0 | 0.0 | 20.0 | 0.7 | -14.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +1525.1 | 402.3 | 295.3 | 16.3 | +2022.4 | 257.3 | 130.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +112.5 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -0.1 | 0.0 | 0.0 | 1.0 | -10.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +75.4 | 0.0 | 0.0 | 2.3 | +363.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +18.3 | 0.0 | 0.0 | 1.3 | +17.8 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +11.1 | 35.7 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -2.3 | 0.0 | 0.0 | 0.3 | -3.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 310.0 |
| RESERVE FALL BACK | 0.7 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +36.1 | 65.0 | 91.7 | 2.0 | +7.6 | 349.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -24.3 | 65.0 | 0.0 | 0.7 | -20.8 | 112.0 | 0.0 |
| RUN DOWN | 2.0 | -125.1 | 65.0 | 91.7 | 1.3 | -10.5 | 145.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -98.8 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +16.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +18.4 | 56.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +183.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -47.7 | 0.0 | 0.0 | 1.0 | -39.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +70.7 | 0.0 | 0.0 | 2.0 | +75.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 8.0 | +0.0 | 0.0 | 33.3 | 3.0 | +0.0 | 0.0 | 65.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +46.8 | 0.0 | 0.0 | 1.7 | +155.0 | 0.0 | 130.0 |
| SHOT OR CHARGE | 0.3 | -1.4 | 65.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 6.7 | -8.1 | 0.0 | 0.0 | 18.0 | -358.7 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.3 | +365.4 | 0.0 | 33.3 | 1.0 | +28.1 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +129.7 | 157.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -5.4 | 0.0 | 157.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 112.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| STANDS STILL | 22.0 | +0.0 | 414.7 | 218.7 | 14.7 | +0.0 | 0.0 | 130.0 |
| STAY WORTH | 15.7 | +15.9 | 284.7 | 0.0 | - | - | - | - |
| STOPS | 0.3 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +51.8 | 0.0 | 0.0 | 5.7 | +645.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +51.8 | 0.0 | 0.0 | 5.7 | +645.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +2.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 112.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 27.3 | +0.0 | 0.0 | 221.0 | 31.7 | +0.0 | 0.0 | 103.7 |
| TIED UP BY THE SUM | 1.0 | +106.5 | 56.7 | 91.7 | 0.3 | +41.6 | 33.3 | 0.0 |
| TIME ON OUR SIDE | 27.3 | +344.7 | 0.0 | 80.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +90.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -277.2 | 0.0 | 224.0 | 2.7 | -838.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +80.2 | 224.0 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +246.3 | 0.0 | 65.0 |
| WOUNDS ON THE RANKS | 0.3 | +1.9 | 0.0 | 0.0 | 2.0 | +130.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 175 | 175 | 130 | 43.33 | +0 | +0.0 |
| HIS MOVE WHY | 98 | 98 | 62 | 20.67 | +0 | +0.0 |
| ARMY TABLE | 93 | 93 | 61 | 20.33 | +955 | +15.7 |
| LEGAL CHARGES ONLY | 58 | 58 | 58 | 19.33 | +0 | +0.0 |
| FIVE ACTION | 372 | 352 | 37 | 12.33 | +2241 | +60.6 |
| HOLDER ASSIGNMENT | 40 | 40 | 37 | 12.33 | +2221 | +60.0 |
| HIS ONE MOVE | 104 | 97 | 28 | 9.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 164 | 155 | 27 | 9.00 | +192 | +7.1 |
| THE TABLE AGAIN | 27 | 27 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| QUARTER ODDS | 91 | 84 | 24 | 8.00 | +1574 | +65.6 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -499 | -23.8 |
| PROMISE BY ITS OWN SUM | 51 | 51 | 21 | 7.00 | -1353 | -64.4 |
| THE RISK READS HIS RUN | 27 | 27 | 18 | 6.00 | +0 | +0.0 |
| HIS SHOT LIST | 116 | 108 | 16 | 5.33 | +304 | +19.0 |
| MOVE TO CHARGE COMPUTED | 33 | 24 | 16 | 5.33 | +822 | +51.4 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 11 | 3.67 | +17 | +1.6 |
| GOAL WALK | 52 | 51 | 10 | 3.33 | +648 | +64.8 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 56 | 50 | 8 | 2.67 | +891 | +111.4 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| SET UP BY THE SET | 14 | 14 | 8 | 2.67 | +283 | +35.3 |
| SHOT RISK POINTS | 74 | 65 | 8 | 2.67 | +177 | +22.1 |
| SUPPORT ADDS | 26 | 24 | 8 | 2.67 | +624 | +78.0 |
| SUPPORT WORKED OUT | 26 | 24 | 8 | 2.67 | +624 | +78.0 |
| WHOLE FIGHT DANGER | 16 | 15 | 8 | 2.67 | +680 | +84.9 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 2.33 | +338 | +48.2 |
| COVER ONCE | 49 | 31 | 6 | 2.00 | +149 | +24.9 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 8 | 5 | 1.67 | +158 | +31.6 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +332 | +66.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1444 | +288.7 |
| FOUR ROUNDS | 14 | 13 | 5 | 1.67 | +170 | +34.1 |
| IDLE COST | 39 | 31 | 5 | 1.67 | +27 | +5.3 |
| NEXT CHARGE BY LIST | 14 | 12 | 5 | 1.67 | +451 | +90.3 |
| CANNON PLANNED TARGET | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 4 | 1.33 | +103 | +25.7 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -172 | -57.4 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -77 | -25.6 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -59 | -19.8 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| STAY WORTH | 47 | 40 | 3 | 1.00 | +16 | +5.4 |
| CAST JOB | 7 | 7 | 2 | 0.67 | +1 | +0.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 18 | 16 | 2 | 0.67 | +26 | +13.1 |
| NEARER NOT NEEDED | 36 | 33 | 2 | 0.67 | +88 | +43.8 |
| ONE FIGHT FORMULA | 30 | 21 | 2 | 0.67 | +5 | +2.5 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +52 | +25.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +54 | +26.8 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 2 | 0.67 | -5 | -2.7 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | +5 | +2.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +80 | +40.1 |
| RISK BY ARC | 12 | 12 | 2 | 0.67 | +18 | +8.9 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -86 | -42.9 |
| TIED UP BY THE SUM | 4 | 3 | 2 | 0.67 | +120 | +60.1 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +52 | +25.8 |
| WOUNDS ON THE RANKS | 7 | 6 | 2 | 0.67 | +73 | +36.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +7 | +7.1 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| MISSILES IN THE MOVE | 12 | 9 | 1 | 0.33 | +29 | +28.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | -8 | -8.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REDIRECT COUNTER | 15 | 14 | 1 | 0.33 | +92 | +92.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +149 | +149.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +50 | +49.6 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +55 | +55.2 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 34 | 23 | 1 | 0.33 | +39 | +38.7 |
| SURE REACH TOGETHER | 3 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 82 | 66 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +239 | +238.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 49 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FALLS SHORT | 44 | 37 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 25 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 18 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 46 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 9 | 7 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 35 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 51 | 46 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 27 | 27 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 28 | 28 | 0 | 0.00 | - | - |
| HOLD ODDS | 63 | 63 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 15 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 21 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 174 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 33 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 110 | 102 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 177 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.67 | 64.4 |
| JOB FIRST | gate | 3.00 | 2.33 | 26.2 |
| ARMY TABLE | rule | 2.00 | 2.33 | 77.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 57.4 |
| JOINT CHARGE NOW | rule | - | 1.00 | 25.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 22.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 24.7 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 29.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 2.7 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 42.9 |
| FALLBACK | gate | - | 0.33 | 3.8 |
| NO REASON | gate | - | 0.33 | 9.9 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 8.3 |
| REFUSING RETIRES | rule | 0.33 | - | 28.2 |

### Plans: wfr-a92c160-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 294 | 121 | 41% |
| Mine | move | 19.3 | 93% | 1062 | 0 | 0% |
| Mine | shoot | 6.0 | 44% | 443 | 164 | 37% |
| Opponent | charge | 1.0 | 100% | 362 | 138 | 38% |
| Opponent | join | 3.3 | 90% | 128 | 0 | 0% |
| Opponent | move | 25.0 | 100% | 1308 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 37 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 9 | 0 | 0% |

### Packages: hunt the guns, wfr-a92c160-p21

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 279 | 0 | 0% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 279 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: wfr-a92c160-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 14% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 300 (2) | 0 | 300 | 0 | 0% | 1.5 | 338 (1) | 262 (1) | - | 338 (1) | 262 (1) |
| Mine | Character | 5 | 20 (5) | 20 | 0 | 41 | 20% | 2.0 | 0 (2) | 47 (2) | 0 (1) | 29 (3) | 0 (2) |
| Mine | Clean-up | 1 | 245 (1) | 217 | 28 | 100 | 0% | 3.0 | 245 (1) | - | - | 245 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 0% | 4.0 | 0 (3) | - | - | 0 (2) | 0 (1) |
| Mine | Hammer | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Shooter | 2 | 158 (2) | 38 | 119 | 0 | 0% | 2.0 | 66 (1) | 286 (1) | - | 286 (1) | 66 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | - | - | - | - |
| Opponent | Chaff | 1 | 1320 (1) | 1320 | 0 | 0 | 100% | - | - | 1320 (1) | - | - | 1320 (1) |
| Opponent | Character | 6 | 36 (6) | 36 | 0 | 36 | 50% | 2.0 | 0 (1) | 10 (4) | 129 (1) | 0 (4) | 67 (2) |
| Opponent | Clean-up | 1 | 98 (1) | 0 | 98 | 0 | 0% | 5.0 | - | 98 (1) | - | - | 98 (1) |
| Opponent | Fast Hammer | 3 | 20 (3) | 0 | 20 | 0 | 67% | 4.0 | 0 (1) | 30 (2) | - | 30 (2) | 0 (1) |
| Opponent | Hammer | 5 | 89 (5) | 52 | 38 | 18 | 20% | 3.8 | 104 (3) | 63 (2) | - | 82 (4) | 126 (1) |
| Opponent | Holder | 4 | 18 (4) | 0 | 18 | 0 | 75% | 5.0 | 0 (1) | 24 (3) | - | 0 (1) | 26 (3) |
| Opponent | Wizard | 1 | 31 (1) | 31 | 0 | 100 | 0% | 2.0 | - | - | 31 (1) | 31 (1) | - |

### Charged fights: wfr-a92c160-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 116 | 365 | 4.0 | 1.0 | 91 | 0 | +91 | 3 of 4 | 3 of 4 | - | +91 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 465 | 1.0 | 1.0 | 465 | 685 | -220 | 1 of 1 | 1 of 1 | - | -220 |
| **Mine** | all armies | 2 | 58 | 415 | 2.5 | 1.0 | 166 | 137 | +29 | 4 of 5 | 4 of 5 | - | +29 |
| Opponent | Warriors of Chaos | 2 | 30 | 191 | 1.5 | 1.0 | 127 | 0 | +127 | 0 of 3 | 3 of 3 | - | +127 |

### Effective charges: wfr-a92c160-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +98) | 1 | 33% (1 of 3) |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 1 (net -220) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +138) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: wfr-a92c160-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 434 | 283 | -110 | 289 | 359 | -70 | -16.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 464 | 198 | +98 | 179 | 96 | +83 | +17.8 |
| Mine | No odds | 1 | 497 | 170 | +170 | 170 | 0 | +170 | +34.2 |
| Mine | All fights | 5 | 459 | 226 | +29 | 221 | 182 | +39 | +8.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 222 | 178 | +138 | 170 | 5 | +165 | +74.1 |
| Opponent | No odds | 1 | 494 | 107 | +107 | 107 | 0 | +107 | +21.7 |
| Opponent | All fights | 3 | 313 | 154 | +127 | 149 | 3 | +146 | +46.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p21 | move | 22 | 2 (9%) | 2 (9%) | 0 (0%) | 20 (91%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

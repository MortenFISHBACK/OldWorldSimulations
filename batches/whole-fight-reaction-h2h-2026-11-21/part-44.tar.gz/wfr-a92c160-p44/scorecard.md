# Doctrine scorecard: wfr-a92c160-p44

### Scorecard: wfr-a92c160-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 1 | 2 | 0 | 2 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 4 | 0 | 0 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 2 | 4 | 1 | 3 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | yes | 2 | 1 | 0 | 5 | 0 | 0 | 0 | 110 |
| **Average** | | | Mine | 0% | 2.5 | 2.7 | 2.3 | 2.3 | 0.3 | 0.0 | 0.0 | 87.7 |
| **Average** | | | Opponent | 100% | 1.5 | 3.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 160.3 |

### KPIs: wfr-a92c160-p44

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | - | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (4 of 9) | - | 44% (4 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 54% (3219 of 6000) | 53% (3186 of 6000) | 53% (6405 of 12000) |
|   infantry points that never fought | lower | 63% (584 of 923) | 77% (892 of 1159) | 71% (1476 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (17 of 26) | 58% (14 of 24) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 2.0 uses a game | 0.0 uses a game | 29% (4 of 14); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3633 of 5860) | 48% (2474 of 5131) | 56% (6107 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (14%) | - | 0.7 (14%) |
| MARCHED: its unit marched | 1.0 (21%) | - | 1.0 (21%) |
| IN COMBAT: engaged in combat | 0.7 (14%) | - | 0.7 (14%) |
| GONE: slain | 2.3 (50%) | - | 2.3 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 4.3 | 2.7 | 1.3 | 1.7 |
| not cast | 3.7 | 5.7 | 5.3 | 4.7 | 26.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (47%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.7 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (45%) | 1.7 (29%) | 1.7 (31%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (45%) | 1.3 (24%) | 2.7 (50%) | 2.3 (50%) | 7.7 (29%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (9%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 62% (5 of 8) | - | 62% (5 of 8) |
| the unit moved after it | 20% (1 of 5) | - | 20% (1 of 5) |
| it charged on its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| the enemy charged it first | 20% (1 of 5) | - | 20% (1 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 60% (3 of 5) | - | 60% (3 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (44 of 81) | 62% (65 of 105) | 59% (109 of 186) |
|   cavalry | 52% (13 of 25) | 77% (17 of 22) | 64% (30 of 47) |
|   character | 13% (3 of 23) | 40% (6 of 15) | 24% (9 of 38) |
|   chariot | - | 67% (8 of 12) | 67% (8 of 12) |
|   infantry | 76% (16 of 21) | 61% (27 of 44) | 66% (43 of 65) |
|   monster | - | 58% (7 of 12) | 58% (7 of 12) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (22%) | 1.7 (12%) | 4.3 (17%) |
| CHARGED: it charged | 1.7 (14%) | 1.7 (12%) | 3.3 (13%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.3 (2%) | 1.0 (4%) |
| NO TARGET IN RANGE | 5.3 (43%) | 4.3 (32%) | 9.7 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (16%) | 3.7 (28%) | 5.7 (22%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 1.0 (8%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.7 | 1.3 | 91% | 3.8 pts | 55 pts |
| character | 4.0 | 0.7 | 83% | 1.8 pts | 7 pts |
| chariot | 2.7 | 1.3 | 75% | 31.2 pts | 83 pts |
| infantry | 20.3 | 5.7 | 74% | 10.7 pts | 218 pts |
| monster | 2.3 | 1.3 | 57% | 35.7 pts | 83 pts |
| war machine | 4.0 | 1.7 | 75% | 12.0 pts | 48 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 4.0 | 3.7 |
| Charges that made contact a game | 3.0 | 2.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.30 contact (23 units) | 0.36 declared, 0.21 contact (33 units) | 0.36 declared, 0.25 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | - | 75% (3 of 4) | 38% (3 of 8) | 50% (6 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (8 of 10) | 100% (1 of 1) | - | 82% (9 of 11) |
| Monster | 0% (0 of 2) | 0% (0 of 1) | - | 0% (0 of 3) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (4 of 4); on the table 100% | 22% (4 of 18) | 54% | 65% (17 of 26) | 100% (1 of 1); 1.0 uses a game | 29% (4 of 14); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 44% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 52% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 63% | 67% (8 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 60% (3) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 80% (8 of 10) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 70% (19 of 27) | 55% (12 of 22) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | 33% (3 of 9) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 87.7 | 160.3 |
| Movement | Fights charged into per game | 2.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 8, net +88 | 1 of 3, net +143 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +336 | 2 of 3, net +288 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 23.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 18% (7 of 38) | 75% (53 of 71) |
| Shooting | Points destroyed by shooting units | 11.3 | 217.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (8 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 11.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 1.3 / 0.0 | 3.0 / 3.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 230.7 | 246.3 |
| Combat | Points run down | 340.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +125 | +127 |
| Combat | Net per 100 charger points, damage counted | +32.1 | +40.2 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +150 | +147 |
| Combat | Net points per supported fight / lone fight | +66 / +161 | +400 / +96 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 2 of 6 |
| Game | Points lost | 635.3 | 647.3 |
| Game | VP from objectives | 410.0 | 846.7 |
| Game | Lone holders (player turns) | 2.5 | 1.5 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -375 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1283
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 28.0 | +583.5 | 0.0 | 516.3 | 36.3 | +955.2 | 0.0 | 512.7 |
| BACKUP TARGETS | 0.3 | +2.8 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -30.3 | 76.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 47.7 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +21.8 | 130.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 76.7 | 0.0 |
| CAST JOB | 0.7 | +12.8 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 231.3 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +42.0 | 0.0 | 66.7 |
| CHAFF PASSED | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +25.9 | 0.0 | 101.7 | 0.3 | +23.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 22.3 | -1313.8 | 0.0 | 1277.7 | 12.3 | -495.3 | 0.0 | 130.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 195.0 | 0.0 | 1.7 | +0.0 | 323.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 65.0 |
| CONVEYANCE SEARCH | 2.7 | +469.3 | 433.3 | 433.3 | - | - | - | - |
| COVER ONCE | 11.3 | -666.8 | 0.0 | 611.7 | 6.7 | -569.4 | 0.0 | 219.0 |
| DENIED BY THE FIGHT | 0.7 | -3.5 | 36.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -46.4 | 76.7 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.5 | 47.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.3 | +56.9 | 0.0 | 42.0 |
| EXACT ROUND | 2.7 | +30.8 | 249.3 | 0.0 | 1.0 | +6.4 | 228.7 | 78.0 |
| FALL BACK GOOD ORDER | 2.3 | +34.4 | 251.7 | 0.0 | 1.3 | +23.4 | 340.7 | 65.0 |
| FALLS SHORT | 13.7 | +142.4 | 0.0 | 327.3 | 14.3 | +144.8 | 0.0 | 78.7 |
| FEATURE BUFFS | 2.3 | +29.9 | 0.0 | 0.0 | 1.0 | +10.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +11.9 | 76.7 | 65.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 78.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 93.3 | +4746.6 | 851.7 | 2004.7 | 108.0 | +8747.3 | 2196.3 | 1685.7 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 501.0 | 6.7 | +0.0 | 0.0 | 248.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +279.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +143.3 | 365.0 | 0.0 | 2.7 | +202.8 | 495.0 | 143.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 13.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -13.3 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -16.7 | 124.3 | 65.0 |
| GOAL WALK | 5.3 | +434.2 | 0.0 | 362.0 | 9.0 | +502.2 | 0.0 | 65.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +2.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 25.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.0 | +0.0 | 0.0 | 13.3 |
| HIS CHARGE BY HIS RUN | 14.7 | +0.0 | 0.0 | 1118.0 | 7.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +25.5 | 47.7 | 78.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 158.3 | 11.3 | +0.0 | 0.0 | 432.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 95.3 | 2.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 6.0 | -52.6 | 0.0 | 166.7 | 4.7 | -52.8 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 52.7 | +14.0 | 983.0 | 0.0 | 42.0 | +10.0 | 911.3 | 0.0 |
| HIS MOVE WHY | 24.7 | +0.0 | 0.0 | 604.7 | 15.3 | +0.0 | 0.0 | 540.0 |
| HIS ONE MOVE | 25.3 | +0.5 | 0.0 | 100.7 | 22.3 | -56.7 | 0.0 | 65.0 |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 100.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 47.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 64.7 | +3145.4 | 0.0 | 1469.0 | 61.7 | +1630.6 | 0.0 | 885.0 |
| HIS SHOTS BY HIS RUN | 58.7 | +1826.7 | 0.0 | 1732.3 | 42.3 | +732.2 | 0.0 | 698.0 |
| HIS TURN DENIED | 1.7 | +171.8 | 94.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 153.3 | 19.7 | +0.0 | 0.0 | 53.3 |
| HOLDER ASSIGNMENT | 9.3 | +970.6 | 0.0 | 76.7 | 12.3 | +902.8 | 0.0 | 26.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -138.2 | 365.0 | 0.0 | 2.3 | -96.3 | 418.3 | 78.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| IDLE COST | 8.7 | -114.0 | 0.0 | 214.3 | 12.0 | -146.4 | 0.0 | 109.0 |
| JOINT CHARGE NOW | 1.0 | -15.5 | 66.0 | 0.0 | 0.7 | -25.1 | 153.3 | 65.0 |
| JOINT ON THE TABLE | 0.3 | +0.7 | 22.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 153.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 79.0 | 54.0 | 6.7 | +0.0 | 397.3 | 135.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +1.4 | 129.0 | 0.0 | 1.3 | +0.4 | 260.0 | 143.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -138.5 | 0.0 | 22.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| MANOEUVRE | 1.7 | +3.5 | 0.0 | 47.7 | 3.3 | +58.1 | 0.0 | 50.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +13.3 | 0.0 | 133.3 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +34.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +15.8 | 0.0 | 300.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +155.9 | 0.0 | 300.0 | 0.7 | +160.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +4.8 | 0.0 | 0.0 | 2.7 | +113.4 | 0.0 | 36.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +27.9 | 0.0 | 54.0 | 2.7 | +49.6 | 0.0 | 231.3 |
| MISSILES NEXT TURN | 3.7 | +21.2 | 0.0 | 487.3 | 3.3 | +80.9 | 0.0 | 231.3 |
| MOVE ORDER | 3.0 | +0.0 | 59.0 | 166.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +1105.2 | 0.0 | 0.0 | 6.7 | +1161.4 | 0.0 | 65.0 |
| NEARER NOT NEEDED | 7.3 | +256.8 | 0.0 | 76.7 | 9.3 | +371.0 | 0.0 | 191.3 |
| NEXT CHARGE BY LIST | 4.7 | +730.2 | 0.0 | 0.0 | 5.7 | +1015.8 | 0.0 | 65.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -141.7 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.3 | -40.6 | 299.0 | 0.0 | 2.3 | -155.3 | 418.3 | 143.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -228.5 | 0.0 | 47.7 | 5.7 | -360.8 | 54.0 | 162.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 24.7 |
| ONE FIGHT FORMULA | 6.7 | -137.4 | 0.0 | 214.3 | 4.7 | -86.0 | 0.0 | 42.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +25.0 | 153.3 | 65.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +85.1 | 0.0 | 0.0 | 5.3 | -87.2 | 0.0 | 13.3 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +2.3 | 56.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +3.1 | 22.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +92.5 | 238.3 | 0.0 | 0.3 | +0.3 | 59.0 | 0.0 |
| PATHS CROSS | 0.3 | +19.6 | 0.0 | 0.0 | 0.3 | +16.6 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +607.4 | 100.0 | 965.3 | 49.0 | +1007.3 | 887.3 | 1026.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -380.2 | 0.0 | 0.0 | 7.7 | -166.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -3.8 | 42.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1451.6 | 42.0 | 319.3 | 22.7 | +2508.6 | 260.3 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +0.9 | 0.0 | 22.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +387.8 | 0.0 | 93.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.3 | +4.9 | 0.0 | 104.7 |
| REFORMS TO MEET IT | 3.3 | -215.2 | 0.0 | 0.0 | 2.0 | -83.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | -147.8 | 273.7 | 0.0 | 2.3 | +19.2 | 495.0 | 143.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -27.5 | 115.7 | 0.0 | 1.7 | -33.9 | 382.0 | 143.0 |
| RUN DOWN | 2.3 | -13.9 | 299.0 | 0.0 | 2.3 | -14.7 | 361.7 | 143.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -41.4 | 0.0 | 11.3 |
| SEARCH SPOT | - | - | - | - | 1.3 | +51.7 | 0.0 | 78.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +2.3 | 54.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -5.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +96.2 | 0.0 | 0.0 | 1.0 | -119.3 | 153.3 | 65.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| SET-UP ANY TARGET | 0.3 | +26.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 59.0 | 9.7 | +0.0 | 0.0 | 323.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +50.2 | 0.0 | 118.0 | 3.7 | +100.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 39.0 | -657.8 | 0.0 | 1323.0 | 21.7 | -1.4 | 0.0 | 274.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +390.9 | 0.0 | 172.0 | 22.3 | +1017.4 | 0.0 | 379.3 |
| SPELL SETS UP CHARGE | 0.3 | +26.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +15.4 | 266.7 | 266.7 | 1.7 | +21.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +3.7 | 13.3 | 0.0 | 0.3 | -1.9 | 47.7 | 78.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 347.7 | 8.0 | +0.0 | 0.0 | 30.0 |
| STAND AND SHOOT | 1.0 | -14.5 | 58.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 64.0 |
| STANDS STILL | 35.7 | +0.0 | 486.7 | 224.7 | 45.3 | +0.0 | 1701.3 | 1033.3 |
| STAY WORTH | 24.7 | +41.8 | 360.7 | 59.0 | 17.0 | +79.8 | 500.0 | 112.7 |
| STRIKE BY THE ODDS | 0.3 | +0.0 | 65.0 | 133.3 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +282.1 | 0.0 | 100.7 | 5.7 | +345.9 | 0.0 | 49.3 |
| SUPPORT WORKED OUT | 4.0 | +282.1 | 0.0 | 100.7 | 5.7 | +345.9 | 0.0 | 49.3 |
| SURE REACH TOGETHER | 0.3 | +2.6 | 0.0 | 0.0 | 1.3 | +5.9 | 0.0 | 87.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 133.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 172.0 | 5.7 | +0.0 | 0.0 | 24.7 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 172.0 | 5.7 | +0.0 | 0.0 | 24.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 954.7 | 52.0 | +0.0 | 0.0 | 778.7 |
| TIED UP BY THE SUM | 2.3 | +228.5 | 158.0 | 0.0 | 1.3 | +198.8 | 160.7 | 0.0 |
| TIME ON OUR SIDE | 23.7 | +294.3 | 86.0 | 563.0 | 27.3 | +293.5 | 0.0 | 743.7 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -5.8 | 0.0 | 0.0 | 0.3 | -5.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 2.3 | +0.0 | 666.7 | 0.0 |
| WHO FIGHTS | 0.3 | -1.0 | 13.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.7 | +99.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -188.2 | 0.0 | 291.0 | 1.3 | -208.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +47.4 | 153.3 | 65.0 |
| WHOLE FIGHT REACTION | 1.3 | +225.8 | 41.3 | 181.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 1.0 | +101.5 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 284 | 284 | 212 | 70.67 | +0 | +0.0 |
| ARMY TABLE | 193 | 193 | 146 | 48.67 | +4240 | +29.0 |
| HIS SHOT LIST | 379 | 350 | 84 | 28.00 | +1487 | +17.7 |
| HIS MOVE WHY | 120 | 120 | 72 | 24.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 65 | 65 | 61 | 20.33 | +4041 | +66.2 |
| HIS SHOTS BY HIS RUN | 303 | 284 | 59 | 19.67 | +1269 | +21.5 |
| HIS ONE MOVE | 143 | 139 | 36 | 12.00 | +0 | +0.0 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1768 | -53.6 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| SHOT RISK POINTS | 182 | 171 | 30 | 10.00 | +968 | +32.3 |
| LEGAL CHARGES ONLY | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 44 | 40 | 24 | 8.00 | +2568 | +107.0 |
| THE RISK READS HIS RUN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 30 | 19 | 6.33 | +2282 | +120.1 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 19 | 6.33 | -1640 | -86.3 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 121 | 115 | 15 | 5.00 | +1054 | +70.3 |
| FIVE ACTION | 604 | 574 | 14 | 4.67 | +1151 | +82.2 |
| GOAL WALK | 43 | 42 | 13 | 4.33 | +604 | +46.5 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +14 | +1.1 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 12 | 4.00 | +142 | +11.9 |
| FOUR ROUNDS | 18 | 17 | 11 | 3.67 | +400 | +36.3 |
| TIME ON OUR SIDE | 153 | 127 | 11 | 3.67 | +77 | +7.0 |
| CHARGE LOSSES | 104 | 99 | 10 | 3.33 | +1264 | +126.4 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| COVER ONCE | 54 | 35 | 7 | 2.33 | +149 | +21.3 |
| SUPPORT ADDS | 29 | 27 | 7 | 2.33 | +79 | +11.3 |
| SUPPORT WORKED OUT | 29 | 27 | 7 | 2.33 | +79 | +11.3 |
| TIED UP BY THE SUM | 11 | 10 | 7 | 2.33 | +161 | +23.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -122 | -24.4 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 116 | 80 | 5 | 1.67 | +141 | +28.3 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +293 | +58.6 |
| CHARGE NOW FIRST | 11 | 11 | 4 | 1.33 | -224 | -56.1 |
| MANOEUVRE | 15 | 15 | 4 | 1.33 | +227 | +56.8 |
| SET UP BY THE SET | 6 | 6 | 4 | 1.33 | +299 | +74.6 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 3 | 3 | 1.00 | +14 | +4.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +148 | +49.3 |
| EVASIVE BY THE ODDS | 7 | 7 | 3 | 1.00 | +91 | +30.4 |
| FALL BACK GOOD ORDER | 11 | 10 | 3 | 1.00 | +85 | +28.2 |
| IDLE COST | 62 | 46 | 3 | 1.00 | +30 | +10.0 |
| NEARER NOT NEEDED | 50 | 48 | 3 | 1.00 | +88 | +29.4 |
| OVERRUNS AWAY | 7 | 7 | 3 | 1.00 | +82 | +27.5 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +169 | +56.2 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +22 | +11.2 |
| FALLS SHORT | 84 | 71 | 2 | 0.67 | +12 | +5.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +838 | +418.9 |
| HIS MOVE AND SHOT | 32 | 31 | 2 | 0.67 | +70 | +35.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -47 | -23.7 |
| MAX FOR POSITIONING | 12 | 11 | 2 | 0.67 | +3 | +1.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +108 | +54.2 |
| RISK BY ARC | 15 | 14 | 2 | 0.67 | +57 | +28.6 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| STAY WORTH | 125 | 109 | 2 | 0.67 | +3 | +1.4 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -34 | -16.9 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +45 | +22.7 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +50 | +25.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -163 | -163.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CANNON PLANNED TARGET | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.7 |
| EXACT ROUND | 11 | 11 | 1 | 0.33 | +17 | +17.4 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +23 | +22.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +6 | +6.3 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +175 | +175.1 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +23 | +22.7 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -12 | -11.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| SHOTS AFTER THE MOVES | 26 | 26 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 5 | 4 | 1 | 0.33 | +2 | +2.1 |
| WOUNDS ON THE RANKS | 3 | 3 | 1 | 0.33 | +107 | +107.1 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 52 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 57 | 56 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 111 | 111 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 16 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 13 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 20 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 32 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 13 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 55 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 243 | 223 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 18 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 29 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 25 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.67 | 54.8 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 2.00 | 86.3 |
| ARMY TABLE | rule | 3.00 | 2.67 | 35.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.67 | 14.1 |
| RULE SWITCHED OFF | gate | - | 2.00 | 48.6 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 56.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 47.1 |
| NO REASON | gate | 1.00 | - | 71.4 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 23.7 |
| WALKS ON ITS ROUTE | rule | 0.33 | 0.33 | 16.9 |
| AFTERMATH BAND | gate | 0.33 | - | 0.5 |
| BEST PRIZE | rule | 0.33 | - | 163.1 |
| CHAFF PASSED | rule | 0.33 | - | 0.7 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 11.5 |

### Plans: wfr-a92c160-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 100% | 405 | 288 | 71% |
| Mine | move | 31.0 | 95% | 1613 | 0 | 0% |
| Mine | shoot | 7.7 | 74% | 166 | 320 | 193% |
| Opponent | charge | 2.3 | 86% | 281 | 450 | 160% |
| Opponent | move | 39.7 | 95% | 2650 | 0 | 0% |
| Opponent | shoot | 5.7 | 59% | 615 | 558 | 91% |
| Opponent | support | 1.3 | 50% | 5 | 0 | 0% |

### Battle groups: wfr-a92c160-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 36% | 100% | 0% | - | 0% | 0% | 0% | 75% | 25% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 56 (7) | 56 | 0 | 30 | 14% | 1.2 | 19 (5) | 267 (1) | 0 (1) | 19 (5) | 133 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 32 (14) | 8 | 24 | 22 | 50% | 2.9 | 26 (8) | 40 (6) | - | 50 (9) | 0 (5) |
| Mine | Shooter | 4 | 5 (4) | 5 | 0 | 49 | 0% | 1.0 | 0 (3) | 19 (1) | - | 7 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 148 (7) | 0 | 148 | 100 | 14% | 2.3 | - | 287 (4) | 16 (3) | 338 (4) | 14 (3) |
| Opponent | Character | 4 | 48 (4) | 48 | 0 | 14 | 0% | 1.8 | - | 48 (4) | - | 20 (2) | 71 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 61 (4) | 52 | 9 | 48 | 0% | 2.2 | 65 (2) | 55 (2) | - | 48 (3) | 91 (1) |
| Opponent | Hammer | 8 | 42 (8) | 42 | 0 | 38 | 38% | 2.4 | 115 (2) | 20 (3) | 0 (3) | 0 (4) | 71 (4) |
| Opponent | Holder | 3 | 204 (3) | 79 | 125 | 0 | 0% | 3.0 | 350 (1) | 0 (1) | 302 (1) | 350 (1) | 137 (2) |
| Opponent | Shooter | 4 | 66 (4) | 0 | 66 | 20 | 0% | 2.2 | 0 (1) | 142 (2) | 0 (1) | 134 (2) | 18 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 0% | 2.3 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 23 | 399 | 2.7 | 1.1 | 150 | 0 | +150 | 1 of 8 | 8 of 8 | +66 | +161 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 151 | 739 | 3.0 | 1.3 | 246 | 0 | +246 | 1 of 3 | 3 of 3 | +400 | +170 |
| Opponent | Wood Elf Realms | 1 | 0 | 143 | 1.0 | 1.0 | 143 | 0 | +143 | 0 of 1 | 1 of 1 | - | +143 |
| **Opponent** | all armies | 3 | 217 | 294 | 2.0 | 1.2 | 147 | 0 | +147 | 2 of 6 | 4 of 6 | +400 | +96 |

### Effective charges: wfr-a92c160-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 0 | 0 | 6 (net +88) | 2 (net +336) | 0 | 0% (0 of 8) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +288) | 1 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +143) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 489 | 266 | +336 | 336 | 0 | +336 | +68.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 355 | 75 | +88 | 94 | 39 | +54 | +15.3 |
| Mine | All fights | 8 | 388 | 122 | +150 | 154 | 30 | +125 | +32.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 415 | 288 | +288 | 288 | 81 | +207 | +49.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 143 | +143 | 143 | 0 | +143 | +28.7 |
| Opponent | No odds | 3 | 188 | 258 | +54 | 70 | 3 | +68 | +35.9 |
| Opponent | All fights | 6 | 316 | 249 | +147 | 155 | 28 | +127 | +40.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p44 | move | 20 | 3 (15%) | 3 (15%) | 3 (15%) | 14 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

# Doctrine scorecard: wfr-a92c160-p16

### Scorecard: wfr-a92c160-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 702 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 385 |
| L0632 | 2 | 1 | Opponent | - | - | 5 | 1 | 5 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | - | 1.3 | 3.0 | 0.0 | 0.0 | 0.0 | 628.3 |
| **Average** | | | Opponent | 0% | 5.5 | 5.0 | 0.3 | 2.3 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: wfr-a92c160-p16

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 11) | 52% (12 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 75% (3 of 4); on the table 75% | 71% (5 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 73% (8 of 11) | 73% (8 of 11) |
| Points that never fought | lower | 87% (5222 of 6000) | 72% (4328 of 5999) | 80% (9550 of 11999) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 53% (384 of 720) | 81% (2383 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (21 of 27) | 71% (15 of 21) | 75% (36 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 76% (3221 of 4232) | 74% (4031 of 5415) | 75% (7252 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (67%) | 1.3 (67%) |
| MARCHED: its unit marched | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.7 | 0.0 | 0.0 | 0.0 |
| not cast | 3.3 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (125 of 194) | 62% (21 of 34) | 64% (146 of 228) |
|   cavalry | 39% (7 of 18) | 67% (8 of 12) | 50% (15 of 30) |
|   character | 70% (16 of 23) | 0% (0 of 5) | 57% (16 of 28) |
|   infantry | 44% (23 of 52) | 60% (3 of 5) | 46% (26 of 57) |
|   monster | 73% (8 of 11) | - | 73% (8 of 11) |
|   war machine | 79% (71 of 90) | 83% (10 of 12) | 79% (81 of 102) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.0 (22%) | 1.0 (23%) | 6.0 (22%) |
| CHARGED: it charged | 2.3 (10%) | 0.3 (8%) | 2.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 0.3 (8%) | 0.7 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (15%) | 0.7 (2%) |
| NO TARGET IN RANGE | 6.7 (29%) | 2.0 (46%) | 8.7 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.3 (32%) | 0.0 (0%) | 7.3 (27%) |
| SHELTERED: the target was sheltered | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.7 | 69% | 8.9 pts | 47 pts |
| character | 5.3 | 3.3 | 69% | 12.0 pts | 64 pts |
| infantry | 16.7 | 6.7 | 68% | 11.5 pts | 191 pts |
| monster | 2.7 | 0.3 | 88% | 2.4 pts | 7 pts |
| war machine | 27.0 | 20.3 | 63% | 20.4 pts | 550 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 0.3 | 1.3 |
| Charges that made contact a game | 2.3 | 0.3 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.33 contact (21 units) | 0.05 declared, 0.05 contact (20 units) | 0.20 declared, 0.20 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | - | 50% (1 of 2) | 67% (4 of 6) |
| Character in a unit | 100% (6 of 6) | 100% (3 of 3) | 100% (1 of 1) | 100% (10 of 10) |
| Character on its own | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) | 100% (6 of 6) |
| Infantry | 57% (4 of 7) | 50% (3 of 6) | - | 54% (7 of 13) |
| Monster | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 67% (2 of 3); on the table 67% | - | 87% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 72% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 72% | 73% (11 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 33% (1) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (6 of 6) | 100% (1 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 62% (58 of 94) | 86% (12 of 14) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 8% (1 of 12) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 29% (2 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 628.3 | 0.0 |
| Movement | Fights charged into per game | 1.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +60 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.3 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (22 of 58) | 7% (1 of 15) |
| Shooting | Points destroyed by shooting units | 423.7 | 0.0 |
| Shooting | War machine shots | 23.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (47 of 71) | 60% (6 of 10) |
| Shooting | Points destroyed by war machines | 59.0 | 38.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 20.0 | 55.0 |
| Combat | Points run down | 26.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +67 | +31 |
| Combat | Net per 100 charger points, damage counted | +65.9 | +6.2 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | -5 | +0 |
| Combat | Net points per supported fight / lone fight | +60 / -21 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 1 of 1 |
| Game | Points lost | 185.0 | 493.0 |
| Game | VP from objectives | 573.3 | 566.7 |
| Game | Lone holders (player turns) | 0.0 | 5.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +421 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 678
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 7.3 | +314.6 | 0.0 | 70.0 | 12.0 | +235.7 | 0.0 | 220.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 1.0 | +10.9 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 3.7 | +0.0 | 1120.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 23.7 | +579.7 | 2667.0 | 150.0 | 3.3 | +129.4 | 76.7 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.3 | +50.5 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -2.2 | 0.0 | 35.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 4.7 | -63.1 | 0.0 | 70.0 | 25.3 | -1519.1 | 0.0 | 1378.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 26.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 20.0 | 7.3 | +0.0 | 0.0 | 498.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 35.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -887.4 | 0.0 | 35.0 | 5.7 | -200.9 | 0.0 | 157.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -4.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -32.6 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +13.4 | 26.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.0 | +286.2 | 0.0 | 579.3 |
| FEATURE BUFFS | 0.7 | +10.7 | 0.0 | 0.0 | 0.7 | +13.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +2.8 | 26.7 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 134.0 | +6095.1 | 6888.7 | 410.0 | 73.3 | +2157.7 | 153.3 | 1722.7 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 35.0 | 4.7 | +0.0 | 0.0 | 163.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +106.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +83.0 | 26.7 | 0.0 | 0.3 | +26.7 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 70.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -13.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -2.4 | 0.0 | 0.0 | 0.3 | -16.3 | 0.0 | 0.0 |
| GOAL WALK | 2.7 | +84.3 | 0.0 | 0.0 | 14.0 | +916.0 | 0.0 | 184.3 |
| GUN FIGURES | 2.3 | +5.0 | 163.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 70.0 | 10.3 | +0.0 | 0.0 | 927.7 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 18.0 | +0.0 | 0.0 | 53.3 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 35.0 | 5.3 | +0.0 | 0.0 | 524.3 |
| HIS MOVE AND SHOT | - | - | - | - | 3.7 | -59.1 | 0.0 | 83.3 |
| HIS MOVE AS HE DECIDES | 33.0 | +8.0 | 607.0 | 0.0 | 39.7 | +17.7 | 90.0 | 0.0 |
| HIS MOVE WHY | - | - | - | - | 31.7 | +0.0 | 0.0 | 804.7 |
| HIS ONE MOVE | 20.7 | -65.3 | 0.0 | 0.0 | 16.0 | +29.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 340.7 |
| HIS RANDOM MOVE | 16.3 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.0 | +1002.7 | 0.0 | 70.0 | 57.7 | +5160.2 | 0.0 | 1328.7 |
| HIS SHOTS BY HIS RUN | 18.3 | +279.7 | 0.0 | 40.0 | 47.7 | +1577.3 | 0.0 | 1532.3 |
| HIS TURN DENIED | 0.3 | +0.9 | 0.0 | 0.0 | 0.3 | +39.3 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 10.3 | +1265.5 | 0.0 | 0.0 | 8.3 | +892.4 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -9.0 | 26.7 | 0.0 | 0.3 | -38.4 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 16.0 | -291.7 | 0.0 | 578.0 |
| JOINT CHARGE NOW | 1.3 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 0.0 | 140.0 | 4.7 | +0.0 | 0.0 | 53.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | -1.8 | 26.7 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | -1.0 | 0.0 | 0.0 | 1.0 | +3.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +40.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +22.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +5.8 | 0.0 | 0.0 | 0.7 | +9.3 | 0.0 | 26.7 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.5 | 0.0 | 0.0 |
| MODEL FACING | 3.0 | +939.1 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 157.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +403.8 | 0.0 | 0.0 | 0.7 | +24.7 | 0.0 | 157.0 |
| NEARER NOT NEEDED | 5.7 | +261.8 | 0.0 | 0.0 | 3.7 | +167.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +318.8 | 0.0 | 0.0 | 0.7 | +24.7 | 0.0 | 157.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -41.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -42.1 | 26.7 | 0.0 | 0.3 | -21.4 | 0.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -160.2 | 0.0 | 0.0 | 3.3 | -141.3 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -11.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -51.8 | 0.0 | 35.0 | 3.0 | -59.3 | 0.0 | 509.7 |
| ONE JOINT FIGURE | 1.0 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.0 | -29.2 | 0.0 | 0.0 | 3.0 | -136.8 | 0.0 | 37.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 61.0 | +3243.1 | 1649.3 | 260.0 | 35.0 | +141.6 | 0.0 | 720.3 |
| PROMISE BY ITS OWN SUM | 8.3 | -95.8 | 0.0 | 0.0 | 2.0 | -14.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.0 | -0.9 | 489.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +1095.8 | 0.0 | 0.0 | 9.3 | +764.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +34.9 | 0.0 | 113.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | -14.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.7 | +169.5 | 0.0 | 53.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.7 | -68.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +33.9 | 0.0 | 26.7 |
| RISK BY ARC | 1.3 | +42.2 | 26.7 | 0.0 | 0.3 | -23.2 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| RUN DOWN | 2.0 | -11.6 | 26.7 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -58.3 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.7 | +121.7 | 0.0 | 163.0 |
| SECOND LOOK | 0.3 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -19.9 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +46.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 32.3 | +0.0 | 0.0 | 150.0 | 5.7 | +0.0 | 0.0 | 163.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +0.6 | 0.0 | 163.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -27.3 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 13.3 | +465.9 | 0.0 | 0.0 | 40.0 | -1087.8 | 0.0 | 1478.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 38.3 | +1636.5 | 0.0 | 185.0 | 8.0 | +359.1 | 0.0 | 253.3 |
| SPELL WORTH | - | - | - | - | 0.7 | +10.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 363.0 |
| STAND AND SHOOT | 0.7 | -1.2 | 26.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 163.0 |
| STANDS STILL | 102.0 | +0.0 | 6862.0 | 300.0 | 22.3 | +0.0 | 153.3 | 439.3 |
| STAY WORTH | 80.7 | +116.8 | 6002.7 | 450.0 | 10.7 | +254.2 | 153.3 | 163.0 |
| STRIKE BY THE ODDS | 1.3 | +29.5 | 20.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +13.5 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 56.7 |
| SUPPORT ADDS | 3.0 | +64.7 | 0.0 | 0.0 | 1.7 | +46.3 | 0.0 | 10.0 |
| SUPPORT WORKED OUT | 3.0 | +64.7 | 0.0 | 0.0 | 1.7 | +46.3 | 0.0 | 10.0 |
| SURE REACH TOGETHER | 1.3 | +7.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 1.0 | +1.3 | 0.0 | 33.7 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 13.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 163.0 |
| THE STEP BACK IS MADE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.3 | +0.0 | 0.0 | 205.0 | 34.0 | +0.0 | 0.0 | 804.7 |
| TIME ON OUR SIDE | 53.7 | +609.3 | 0.0 | 55.0 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | -14.6 | 26.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +14.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -9.5 | 0.0 | 70.0 | 1.3 | -241.5 | 0.0 | 520.0 |
| WHOLE FIGHT GAIN | 1.3 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +99.3 | 0.0 | 26.7 |
| WOUNDS ON THE RANKS | - | - | - | - | 9.0 | +733.8 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 218 | 218 | 141 | 47.00 | +0 | +0.0 |
| HIS SHOT LIST | 272 | 265 | 84 | 28.00 | +2041 | +24.3 |
| HIS MOVE WHY | 95 | 95 | 68 | 22.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 56 | 56 | 53 | 17.67 | +3952 | +74.6 |
| SHOT RISK POINTS | 160 | 155 | 47 | 15.67 | +2386 | +50.8 |
| HIS SHOTS BY HIS RUN | 198 | 193 | 43 | 14.33 | +650 | +15.1 |
| ARMY TABLE | 58 | 58 | 42 | 14.00 | +1631 | +38.8 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| HIS ONE MOVE | 110 | 110 | 38 | 12.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 161 | 147 | 28 | 9.33 | +122 | +4.4 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -905 | -43.1 |
| FIVE ACTION | 622 | 613 | 20 | 6.67 | +596 | +29.8 |
| MOVE TO CHARGE COMPUTED | 23 | 23 | 17 | 5.67 | +857 | +50.4 |
| THE RISK READS HIS RUN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 14 | 4.67 | -331 | -23.7 |
| CANNON PLANNED TARGET | 81 | 81 | 13 | 4.33 | -34 | -2.6 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 10 | 10 | 10 | 3.33 | +55 | +5.5 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 50 | 50 | 9 | 3.00 | +368 | +40.9 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +2817 | +313.0 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 8 | 2.67 | +104 | +13.1 |
| COVER ONCE | 43 | 31 | 7 | 2.33 | +224 | +31.9 |
| NEXT CHARGE BY LIST | 10 | 10 | 7 | 2.33 | +813 | +116.2 |
| CHARGE LOSSES | 90 | 88 | 6 | 2.00 | +122 | +20.3 |
| FOUR ROUNDS | 8 | 8 | 6 | 2.00 | +123 | +20.5 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 139 | 117 | 6 | 2.00 | +148 | +24.8 |
| QUARTER ODDS | 73 | 70 | 5 | 1.67 | +73 | +14.6 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +365 | +73.0 |
| WOUNDS ON THE RANKS | 27 | 27 | 5 | 1.67 | +118 | +23.5 |
| ARTILLERY RE-ROLL WEIGHED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 48 | 40 | 4 | 1.33 | +86 | +21.4 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +89 | +22.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +102 | +25.4 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -7 | -2.2 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -3 | -0.9 |
| RISK BY ARC | 5 | 5 | 3 | 1.00 | +20 | +6.5 |
| SET UP BY THE SET | 8 | 8 | 3 | 1.00 | +51 | +16.9 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 14 | 14 | 3 | 1.00 | +12 | +3.9 |
| SUPPORT WORKED OUT | 14 | 14 | 3 | 1.00 | +12 | +3.9 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +4 | +1.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 57 | 46 | 2 | 0.67 | +31 | +15.3 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +319 | +159.4 |
| GUN MASK | 2 | 2 | 2 | 0.67 | +50 | +25.0 |
| HIS TURN DENIED | 2 | 2 | 2 | 0.67 | +48 | +24.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +96 | +47.9 |
| NEARER NOT NEEDED | 28 | 27 | 2 | 0.67 | +70 | +35.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 274 | 261 | 2 | 0.67 | +63 | +31.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +13 | +12.6 |
| EXACT ROUND | 6 | 6 | 1 | 0.33 | +3 | +3.1 |
| HIS MOVE AND SHOT | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| LOST AFTER ESCAPE | 8 | 8 | 1 | 0.33 | +2 | +1.6 |
| MANOEUVRE | 4 | 4 | 1 | 0.33 | +11 | +11.4 |
| MAX FOR POSITIONING | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 8 | 8 | 1 | 0.33 | +14 | +13.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +32 | +32.2 |
| STRIKE BY THE ODDS | 4 | 4 | 1 | 0.33 | +56 | +55.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +41 | +40.5 |
| SURE REACH TOGETHER | 5 | 3 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +9 | +9.4 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +24 | +23.8 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 11 | 11 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 43 | 43 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 69 | 67 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 49 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 19 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 288 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 8 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 114 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 37 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 373 | 367 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 9 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 3.00 | 39.2 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.67 | 23.7 |
| ARMY TABLE | rule | 0.33 | 1.33 | 25.3 |
| CANNON PLANNED TARGET | rule | 1.00 | 0.33 | 8.2 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 1.1 |
| CHAFF PASSED | rule | 0.33 | - | 6.6 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 24.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 0.7 |
| NO REASON | gate | - | 0.33 | 8.9 |
| RULE SWITCHED OFF | gate | 0.33 | - | 181.9 |

### Plans: wfr-a92c160-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 39 | 53 | 136% |
| Mine | join | 2.7 | 100% | 75 | 0 | 0% |
| Mine | move | 29.7 | 98% | 1316 | 0 | 0% |
| Mine | shoot | 27.3 | 76% | 1413 | 3190 | 226% |
| Opponent | charge | 0.3 | 100% | 23 | 30 | 134% |
| Opponent | move | 29.7 | 92% | 889 | 0 | 0% |
| Opponent | shoot | 3.7 | 55% | 280 | 111 | 40% |
| Opponent | support | 1.3 | 100% | 3 | 0 | 0% |

### Battle groups: wfr-a92c160-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.7 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 0 (13) | 0 | 0 | 0 | 46% | 3.0 | 0 (3) | 0 (7) | 0 (3) | 0 (8) | 0 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 16 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 54 (6) | 13 | 41 | 0 | 67% | 3.5 | - | 80 (4) | 0 (2) | 74 (5) | 0 (1) |
| Mine | Shooter | 10 | 95 (10) | 56 | 39 | 7 | 10% | 2.0 | - | 166 (4) | 20 (6) | 153 (5) | 22 (5) |
| Mine | War machine | 17 | 40 (17) | 40 | 0 | 20 | 12% | 1.4 | 22 (9) | 0 (2) | 83 (6) | 157 (3) | 15 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 58 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 44 | 75% | 3.0 | 0 (3) | 0 (1) | 0 (3) | 0 (5) | 0 (2) |
| Opponent | Clean-up | 3 | 44 (3) | 0 | 44 | 0 | 67% | 6.0 | 18 (1) | 69 (2) | - | 44 (3) | - |
| Opponent | Fast Hammer | 4 | 80 (4) | 0 | 80 | 0 | 75% | 1.0 | - | 143 (3) | 0 (1) | 182 (2) | 0 (2) |
| Opponent | Hammer | 3 | 41 (3) | 41 | 0 | 42 | 33% | 5.0 | 0 (1) | 49 (2) | - | 41 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 44 | 0% | 2.5 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 2 | 58 (2) | 58 | 0 | 0 | 0% | 1.0 | - | - | 58 (2) | - | 58 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 15 | 50% | 1.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: wfr-a92c160-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 483 | 47 | 1.7 | 1.4 | 28 | 33 | -5 | 1 of 5 | 4 of 5 | +60 | -21 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 38 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |

### Effective charges: wfr-a92c160-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +10) | 0 | 1 (net +60) | 1 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 80 | +0 | 67 | 0 | +67 | +111.1 |
| Mine | 76-89% | 2 | 82 | 108 | +10 | 163 | 30 | +133 | +160.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 225 | 336 | +60 | 89 | 20 | +69 | +30.8 |
| Mine | No odds | 1 | 60 | 139 | -105 | 60 | 125 | -65 | -109.0 |
| Mine | All fights | 5 | 102 | 154 | -5 | 108 | 41 | +67 | +65.9 |
| Opponent | 76-89% | 1 | 499 | 183 | +0 | 131 | 100 | +31 | +6.2 |
| Opponent | All fights | 1 | 499 | 183 | +0 | 131 | 100 | +31 | +6.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p16 | move | 18 | 1 (6%) | 1 (6%) | 2 (11%) | 15 (83%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

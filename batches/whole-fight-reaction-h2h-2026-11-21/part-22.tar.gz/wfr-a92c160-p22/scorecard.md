# Doctrine scorecard: wfr-a92c160-p22

### Scorecard: wfr-a92c160-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 0 | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 3 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 133 |
| L2029 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 2.3 | 3.0 | 2.7 | 1.3 | 0.3 | 0.0 | 0.0 | 140.0 |
| **Average** | | | Opponent | 0% | 4.7 | 2.3 | 3.3 | 1.7 | 0.0 | 0.0 | 0.0 | 101.0 |

### KPIs: wfr-a92c160-p22

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (11 of 11); on the table 100% | 100% (8 of 8); on the table 100% | 100% (19 of 19); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 83% (5 of 6); on the table 100% | 83% (5 of 6); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (11 of 11); on the table 100% | 88% (14 of 16); on the table 94% | 93% (25 of 27); on the table 96% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 24) | 33% (4 of 12) | 11% (4 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 15) | 33% (4 of 12) | 15% (4 of 27) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 45% (5 of 11) | 0% (0 of 5) | 31% (5 of 16) |
| Points that never fought | lower | 24% (1436 of 5999) | 33% (1955 of 5999) | 28% (3391 of 11998) |
|   infantry points that never fought | lower | 74% (736 of 993) | 38% (302 of 793) | 58% (1038 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 58% (11 of 19) | 59% (24 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3108 of 5151) | 48% (2386 of 4976) | 54% (5494 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (8%) | 2.7 (100%) | 3.3 (31%) |
| MARCHED: its unit marched | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 2.0 (25%) | 0.0 (0%) | 2.0 (19%) |
| REAR RANK: in a rear rank | 2.7 (33%) | 0.0 (0%) | 2.7 (25%) |
| GONE: slain | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NOT OFFERED: not in the cast list | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.3 | 1.3 | 0.3 | 3.7 |
| not cast | 8.0 | 8.7 | 10.7 | 3.7 | 28.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.3 (31%) | 2.7 (73%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (8%) | 2.0 (19%) | 0.7 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.3 (29%) | 2.7 (31%) | 2.7 (25%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (21%) | 0.7 (8%) | 1.0 (9%) | 0.3 (9%) | 5.3 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (46%) | 4.7 (54%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (24 of 47) | 14% (1 of 7) | 46% (25 of 54) |
|   cavalry | - | 50% (1 of 2) | 50% (1 of 2) |
|   character | 50% (2 of 4) | 0% (0 of 5) | 22% (2 of 9) |
|   chariot | 100% (6 of 6) | - | 100% (6 of 6) |
|   infantry | 36% (10 of 28) | - | 36% (10 of 28) |
|   monster | 67% (6 of 9) | - | 67% (6 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (30%) | 0.0 (0%) | 2.3 (24%) |
| CHARGED: it charged | 0.3 (4%) | 1.0 (50%) | 1.3 (14%) |
| IN COMBAT: it fought this turn or the last | 1.3 (17%) | 0.0 (0%) | 1.3 (14%) |
| NO TARGET IN RANGE | 2.7 (35%) | 0.7 (33%) | 3.3 (34%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (13%) | 0.3 (17%) | 1.3 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 0.7 | 0.3 | 50% | 3.8 pts | 2 pts |
| chariot | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 3.3 | 0.3 | 90% | 5.5 pts | 18 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 5.0 | 5.0 |
| Charges that made contact a game | 3.7 | 3.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.25 declared, 0.25 contact (4 units) | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.39 contact (28 units) | 0.61 declared, 0.43 contact (23 units) | 0.57 declared, 0.41 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 67% (2 of 3) | 0% (0 of 2) | 44% (4 of 9) |
| Character in a unit | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Character on its own | 100% (2 of 2) | 100% (2 of 2) | 50% (3 of 6) | 70% (7 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 67% (2 of 3) | - | 50% (2 of 4) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 17% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 12) | 8% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 90% (9 of 10); on the table 100% | 33% (4 of 12) | 31% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 83% (5 of 6); on the table 83% | - | 36% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (5) | 60% (6) | 61% (11) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (2 of 6) | 43% (6 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 11% (1 of 9) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 100% (4 of 4) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 64% (7 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 140.0 | 101.0 |
| Movement | Fights charged into per game | 3.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +205 | 1 of 9, net -817 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net -34 | 3 of 9, net +351 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +646 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | 5 of 9, net +178 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.0 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (10 of 24) | 50% (1 of 2) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.7 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 648.0 | 379.7 |
| Combat | Points run down | 0.0 | 78.3 |
| Combat | Net points per charged fight, damage counted | +111 | +125 |
| Combat | Net per 100 charger points, damage counted | +55.0 | +44.6 |
| Combat | First round won (charged fights) | 91% | 80% |
| Combat | Net points per charged fight | +107 | +136 |
| Combat | Net points per supported fight / lone fight | - / +107 | -817 / +242 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 11 | 7 of 10 |
| Game | Points lost | 885.0 | 633.0 |
| Game | VP from objectives | 916.7 | 743.3 |
| Game | Lone holders (player turns) | 2.3 | 4.7 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -124 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1518
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: wfr-a92c160-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 21.3 | -80.0 | 0.0 | 370.0 | 16.7 | +326.8 | 0.0 | 532.3 |
| ASSAILMENT BY POINTS | 1.0 | +2.9 | 0.0 | 180.0 | 0.7 | +9.7 | 0.0 | 380.7 |
| CAST JOB | 0.3 | +0.5 | 0.0 | 180.0 | 2.0 | +12.1 | 22.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +41.1 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +101.6 | 0.0 | 15.0 |
| CHAFF PASSED | 1.0 | -8.5 | 0.0 | 61.7 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +13.4 | 0.0 | 0.0 | 0.3 | +37.2 | 0.0 | 77.7 |
| CHARGE LOSSES | 6.0 | -439.9 | 0.0 | 401.7 | 6.3 | -149.3 | 0.0 | 232.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 40.0 | 11.3 | 2.3 | +0.0 | 545.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 170.0 | 17.3 | +0.0 | 0.0 | 666.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 190.3 |
| CONVEYANCE SEARCH | 0.7 | +51.0 | 0.0 | 0.0 | 0.7 | +10.2 | 0.0 | 0.0 |
| COVER ONCE | 5.0 | -229.2 | 0.0 | 83.3 | 1.7 | -50.7 | 0.0 | 130.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 61.7 | 7.0 | +58.5 | 0.0 | 62.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | +23.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.8 | 85.0 | 0.0 |
| EXACT ROUND | 1.7 | +8.0 | 83.3 | 22.7 | 3.3 | +26.4 | 476.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 83.3 | 22.7 | 3.3 | +16.3 | 644.7 | 0.0 |
| FALLS SHORT | 0.7 | +10.8 | 0.0 | 0.0 | 17.0 | +180.0 | 0.0 | 353.7 |
| FEATURE BUFFS | 2.0 | +19.9 | 0.0 | 156.7 | - | - | - | - |
| FIGHT TO THE END | 0.3 | -0.2 | 0.0 | 11.3 | 2.0 | +20.9 | 241.3 | 0.0 |
| FIVE ACTION | 71.3 | +6544.1 | 108.3 | 1353.0 | 77.3 | +6391.3 | 678.7 | 1472.3 |
| FLANK NOT WEIGHED | 12.0 | +0.0 | 0.0 | 256.7 | 3.0 | +0.0 | 0.0 | 68.3 |
| FOLLOW UP WEIGHED | 0.3 | +175.3 | 0.0 | 0.0 | 1.7 | +219.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +54.9 | 108.3 | 22.7 | 5.0 | +432.6 | 656.0 | 33.3 |
| FREED FROM HIS FIGHT | 11.3 | +0.0 | 0.0 | 188.3 | 3.0 | +0.0 | 0.0 | 15.0 |
| FRIEND SHOOTS FIRST | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -66.0 | 78.0 | 0.0 |
| GOAL WALK | 13.0 | +1491.4 | 0.0 | 280.0 | 10.7 | +1598.5 | 0.0 | 348.7 |
| GUN FIGURES | 4.0 | +11.1 | 0.0 | 166.7 | - | - | - | - |
| HE REFORMS ONCE FREED | 8.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 15.0 |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 401.7 | 1.7 | +0.0 | 0.0 | 170.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 123.3 | 2.3 | +0.0 | 0.0 | 68.3 |
| HIS MOVE AND SHOT | 2.7 | -4.8 | 0.0 | 22.7 | 3.3 | -56.1 | 0.0 | 92.0 |
| HIS MOVE AS HE DECIDES | 37.0 | +10.3 | 434.7 | 0.0 | 36.7 | +11.0 | 883.7 | 0.0 |
| HIS MOVE WHY | - | - | - | - | 41.0 | +0.0 | 0.0 | 755.3 |
| HIS ONE MOVE | 18.7 | +9.9 | 0.0 | 83.3 | 22.3 | -0.3 | 0.0 | 573.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 123.3 | 6.7 | +0.0 | 0.0 | 151.7 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 61.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 290.0 | 5.0 | +0.0 | 0.0 | 193.3 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 65.0 | 1.0 | +0.0 | 0.0 | 68.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 13.0 | +149.3 | 0.0 | 108.3 | 36.3 | +651.1 | 0.0 | 524.3 |
| HIS SHOTS BY HIS RUN | 9.7 | +70.0 | 0.0 | 225.0 | 21.0 | +334.4 | 0.0 | 169.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 313.3 | 12.0 | +0.0 | 0.0 | 286.7 |
| HOLDER ASSIGNMENT | 11.3 | +1259.5 | 0.0 | 78.3 | 8.3 | +877.1 | 0.0 | 143.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -28.0 | 40.0 | 11.3 | 5.0 | -131.5 | 656.0 | 33.3 |
| IDLE COST | 0.3 | -1.8 | 0.0 | 21.7 | 17.7 | -213.5 | 0.0 | 358.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +3.9 | 0.0 | 33.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.7 | -30.8 | 0.0 | 33.3 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.0 | +0.0 | 303.0 | 423.7 | 9.3 | +0.0 | 272.3 | 557.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -5.7 | 15.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -1.6 | 68.3 | 11.3 | 2.3 | +3.6 | 163.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +49.7 | 0.0 | 176.7 |
| MANOEUVRE | 1.7 | -4.3 | 0.0 | 0.0 | 1.7 | +1.7 | 0.0 | 20.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +59.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +50.1 | 0.0 | 11.7 | 1.7 | +62.5 | 0.0 | 211.7 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 61.7 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +64.7 | 0.0 | 0.0 | 2.7 | +13.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +32.3 | 0.0 | 180.0 | 2.7 | +4.7 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 168.3 |
| MOVE SPELL OUT OF RANGE | 0.7 | -12.7 | 0.0 | 63.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.0 | +520.6 | 0.0 | 0.0 | 9.0 | +755.1 | 0.0 | 567.7 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.3 | +393.4 | 0.0 | 0.0 | 5.0 | +187.3 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 1.7 | +118.2 | 0.0 | 0.0 | 3.0 | +306.8 | 0.0 | 449.0 |
| NO DOUBLE ROUNDS | 1.7 | -31.4 | 93.3 | 11.3 | 4.0 | -275.5 | 634.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -79.3 | 15.0 | 21.7 | 5.7 | -147.9 | 78.0 | 198.7 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -28.1 | 0.0 | 0.0 | 5.7 | -158.1 | 0.0 | 492.3 |
| ONE OBJECTIVE FORMULA | 3.3 | +119.2 | 0.0 | 78.3 | 2.7 | -71.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -29.0 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +19.3 | 43.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +116.3 | 40.0 | 0.0 | 1.7 | +13.9 | 163.3 | 33.3 |
| PERIAPT WORTH | 0.3 | +21.5 | 0.0 | 180.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -0.7 | 0.0 | 61.7 | - | - | - | - |
| PLAN RESULT | 36.3 | +125.6 | 0.0 | 1086.7 | 39.7 | +536.5 | 300.3 | 808.3 |
| PROMISE BY ITS OWN SUM | 8.3 | -316.8 | 0.0 | 0.0 | 12.0 | -389.1 | 0.0 | 118.7 |
| PROMISE KNOWS THE FIGHT | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.3 | +2604.6 | 68.3 | 157.3 | 20.7 | +2306.5 | 34.0 | 166.7 |
| RANDOM MOVE BY FIGURES | 3.7 | +92.8 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | -3.2 | 0.0 | 0.0 | 0.7 | +11.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +39.2 | 0.0 | 11.7 | 3.0 | +51.1 | 0.0 | 48.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +15.7 | 0.0 | 45.7 | 2.3 | +36.7 | 0.0 | 43.3 |
| REFORMS TO MEET IT | 0.7 | -13.4 | 0.0 | 0.0 | 0.7 | -9.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | -71.1 | 108.3 | 11.3 | 3.3 | -50.1 | 545.0 | 33.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -74.7 | 185.0 | 33.3 |
| RUN DOWN | 0.7 | -2.2 | 68.3 | 0.0 | 3.0 | -24.0 | 432.7 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -102.6 | 0.0 | 15.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +1.2 | 15.0 | 0.0 | 0.3 | +1.7 | 78.0 | 0.0 |
| SELF MOVE SPELL | 1.0 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -1.2 | 0.0 | 0.0 | 1.7 | -139.3 | 0.0 | 335.0 |
| SET UP BY THE SET | 1.7 | +14.3 | 0.0 | 0.0 | 2.7 | +70.3 | 0.0 | 436.7 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +49.7 | 0.0 | 176.7 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +12.0 | 0.0 | 0.0 | 0.3 | +6.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.4 | 0.0 | 11.3 | 0.3 | -3.0 | 11.3 | 0.0 |
| SHOT RISK POINTS | 5.0 | +5.7 | 0.0 | 0.0 | 19.7 | +44.4 | 0.0 | 154.0 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.7 | +102.4 | 0.0 | 183.0 | 0.3 | +40.0 | 0.0 | 28.3 |
| SPELL WORTH | 1.0 | +78.8 | 360.0 | 360.0 | 2.7 | +14.7 | 40.0 | 40.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 241.7 | 9.7 | +0.0 | 0.0 | 556.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -2.4 | 43.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 26.0 | +0.0 | 0.0 | 375.0 | 16.7 | +0.0 | 22.7 | 0.0 |
| STAY WORTH | 2.7 | +0.6 | 0.0 | 183.0 | 1.7 | +21.8 | 22.7 | 28.3 |
| STRIKE BY THE ODDS | 1.7 | +10.0 | 716.7 | 0.0 | 1.0 | +2.1 | 0.0 | 222.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.0 | +0.0 | 0.0 | 380.7 |
| SUPPORT ADDS | 8.0 | +376.0 | 0.0 | 145.0 | 3.3 | +77.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 25.0 | 0.0 | 0.7 | +0.0 | 21.7 | 16.7 |
| SUPPORT WORKED OUT | 8.0 | +376.0 | 0.0 | 145.0 | 3.3 | +77.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +3.7 | 0.0 | 33.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | -0.7 | 0.0 | 11.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -10.6 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 148.3 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 99.7 | 4.0 | +0.0 | 0.0 | 50.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 190.3 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 78.0 | 2.7 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.3 | +0.0 | 0.0 | 654.3 | 37.7 | +0.0 | 0.0 | 727.0 |
| TIED UP BY THE SUM | 0.7 | +38.0 | 25.0 | 0.0 | 0.7 | +71.6 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 32.3 | +324.4 | 0.0 | 846.3 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 1.0 | +8.4 | 0.0 | 160.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 437.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -58.7 | 0.0 | 66.7 |
| WHO FIGHTS | 0.7 | -0.8 | 68.3 | 11.3 | 1.3 | +67.3 | 163.0 | 0.0 |
| WHO HITS BACK | 1.0 | +115.9 | 0.0 | 11.3 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +2.1 | 0.0 | 33.3 |
| WHOLE FIGHT DANGER | 5.0 | -429.0 | 0.0 | 401.7 | 1.7 | -33.0 | 0.0 | 108.3 |
| WHOLE FIGHT REACTION | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +5.2 | 0.0 | 0.0 | 0.7 | +17.6 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 221 | 221 | 157 | 52.33 | +0 | +0.0 |
| HIS MOVE WHY | 123 | 123 | 87 | 29.00 | +0 | +0.0 |
| ARMY TABLE | 114 | 114 | 74 | 24.67 | +881 | +11.9 |
| HOLDER ASSIGNMENT | 59 | 59 | 53 | 17.67 | +2773 | +52.3 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| FIVE ACTION | 446 | 420 | 41 | 13.67 | +1382 | +33.7 |
| HIS ONE MOVE | 123 | 121 | 35 | 11.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 28 | 9.33 | -2118 | -75.6 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| MOVE TO CHARGE COMPUTED | 45 | 37 | 26 | 8.67 | +793 | +30.5 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -682 | -26.2 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +136 | +6.8 |
| QUARTER ODDS | 111 | 98 | 17 | 5.67 | +1282 | +75.4 |
| GOAL WALK | 71 | 68 | 16 | 5.33 | +1431 | +89.4 |
| HIS SHOT LIST | 148 | 135 | 15 | 5.00 | +53 | +3.6 |
| SUPPORT ADDS | 34 | 32 | 11 | 3.67 | +244 | +22.2 |
| SUPPORT WORKED OUT | 34 | 32 | 11 | 3.67 | +244 | +22.2 |
| IDLE COST | 54 | 36 | 10 | 3.33 | +39 | +3.9 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 22 | 20 | 8 | 2.67 | +240 | +30.0 |
| HIS SHOTS BY HIS RUN | 92 | 82 | 8 | 2.67 | +56 | +7.0 |
| STRIKE BY THE ODDS | 8 | 8 | 8 | 2.67 | +36 | +4.5 |
| TIME ON OUR SIDE | 97 | 78 | 8 | 2.67 | +101 | +12.7 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +19 | +2.7 |
| COMBAT PIVOT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1185 | +197.5 |
| ASSAILMENT BY POINTS | 5 | 5 | 5 | 1.67 | +38 | +7.6 |
| EXACT ROUND | 15 | 13 | 5 | 1.67 | +19 | +3.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| NEXT CHARGE BY LIST | 14 | 12 | 5 | 1.67 | +205 | +41.0 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 5 | 1.67 | +278 | +55.7 |
| THE RISK READS HIS RUN | 36 | 36 | 5 | 1.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 20 | 19 | 5 | 1.67 | +231 | +46.1 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +152 | +38.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 16 | 15 | 4 | 1.33 | +36 | +9.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +119 | +29.6 |
| CHAFF IN THE MOVE | 7 | 7 | 3 | 1.00 | +72 | +24.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -25 | -8.5 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -286 | -95.4 |
| COVER ONCE | 20 | 9 | 3 | 1.00 | +31 | +10.4 |
| OVERRUNS AWAY | 7 | 6 | 3 | 1.00 | +50 | +16.8 |
| REDIRECT COUNTER | 18 | 11 | 3 | 1.00 | +100 | +33.4 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 3 | 1.00 | +14 | +4.8 |
| THE ROW IN ITS ORDER | 25 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +258 | +85.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +31 | +15.7 |
| CHARGE LOSSES | 37 | 35 | 2 | 0.67 | +29 | +14.6 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| NEARER NOT NEEDED | 40 | 38 | 2 | 0.67 | +81 | +40.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +9 | +4.4 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 4 | 4 | 2 | 0.67 | +35 | +17.7 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +61 | +60.6 |
| FALL BACK GOOD ORDER | 15 | 13 | 1 | 0.33 | +9 | +8.8 |
| FIGHT TO THE END | 7 | 6 | 1 | 0.33 | +0 | +0.1 |
| HONEST WORTH | 20 | 18 | 1 | 0.33 | +3 | +2.8 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +5 | +5.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +179 | +179.4 |
| MISSILES IN THE MOVE | 14 | 6 | 1 | 0.33 | +1 | +1.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 17 | 16 | 1 | 0.33 | +3 | +2.8 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -87 | -86.9 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +3 | +2.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +64 | +64.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -2.2 |
| SET UP TOGETHER | 4 | 4 | 1 | 0.33 | +22 | +22.0 |
| SHOT RISK POINTS | 74 | 66 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 18 | 13 | 1 | 0.33 | +16 | +16.2 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -24 | -24.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -2 | -2.0 |
| WHO FIGHTS | 6 | 5 | 1 | 0.33 | +9 | +8.8 |
| CLOSES ON WHAT IT BEATS | 72 | 72 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 53 | 44 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 43 | 39 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 29 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 15 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 8 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 50 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 93 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 16 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 9 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 18 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 228 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 13 | 8 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 13 | 12 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 15 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 54 | 47 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 128 | 117 | 0 | 0.00 | - | - |
| STAY WORTH | 13 | 12 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 207 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.67 | 75.6 |
| ARMY TABLE | rule | 3.67 | 1.33 | 90.1 |
| JOB FIRST | gate | 1.67 | 3.00 | 30.4 |
| NO REASON | gate | - | 2.33 | 20.2 |
| RULE SWITCHED OFF | gate | 1.33 | - | 27.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 95.4 |
| CHAFF PASSED | rule | 0.67 | - | 12.7 |
| JOINT CHARGE NOW | rule | - | 0.33 | 23.7 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 5.0 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 86.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 2.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 24.4 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 2.0 |

### Plans: wfr-a92c160-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 100% | 76 | 126 | 166% |
| Mine | move | 31.3 | 94% | 2410 | 0 | 0% |
| Mine | shoot | 2.3 | 0% | 151 | 0 | 0% |
| Mine | support | 0.7 | 100% | 31 | 0 | 0% |
| Opponent | charge | 4.3 | 46% | 767 | 536 | 70% |
| Opponent | join | 2.3 | 100% | 81 | 0 | 0% |
| Opponent | move | 31.3 | 94% | 1982 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 78 | 0 | 0% |
| Opponent | support | 1.0 | 100% | 18 | 0 | 0% |

### Battle groups: wfr-a92c160-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.0 | 44% | 75% | 50% | 0% | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 7 | 179 (7) | 0 | 179 | 20 | 57% | 2.7 | 203 (6) | 0 (1) | - | 203 (6) | 0 (1) |
| Mine | Character | 7 | 75 (7) | 75 | 0 | 77 | 14% | 1.5 | 0 (1) | 117 (3) | 219 (1) | 218 (3) | 0 (2) |
| Mine | Clean-up | 2 | 151 (2) | 87 | 64 | 0 | 50% | 5.0 | 151 (2) | - | - | 697 (1) | 46 (1) |
| Mine | Fast Hammer | 1 | 138 (1) | 138 | 0 | 0 | 0% | 1.0 | - | 138 (1) | - | 138 (1) | - |
| Mine | Hammer | 10 | 10 (10) | 6 | 4 | 52 | 20% | 2.1 | 20 (2) | 13 (5) | 0 (3) | 23 (4) | 3 (6) |
| Mine | Holder | 3 | 50 (3) | 0 | 50 | 8 | 33% | 3.5 | 0 (1) | 93 (2) | - | 50 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 65 (9) | 7 | 59 | 44 | 44% | 2.8 | 0 (4) | 333 (2) | 17 (3) | 167 (4) | 10 (5) |
| Opponent | Character | 10 | 52 (10) | 52 | 0 | 40 | 40% | 2.7 | 0 (4) | 55 (5) | 118 (1) | 48 (5) | 55 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 57 (8) | 38 | 19 | 43 | 25% | 2.5 | 42 (2) | 37 (4) | 125 (2) | 52 (5) | 63 (3) |
| Opponent | Hammer | 2 | 79 (2) | 24 | 55 | 0 | 0% | 4.5 | - | 79 (2) | - | 70 (1) | 84 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Support | 1 | 63 (1) | 63 | 0 | 0 | 0% | 2.0 | - | 63 (1) | - | - | 63 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 12 | 0% | 1.8 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |

### Charged fights: wfr-a92c160-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 45 | 5.0 | 1.0 | 9 | 14 | -5 | 0 of 5 | 4 of 5 | - | -5 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 997 | 5.0 | 1.0 | 199 | 0 | +199 | 2 of 5 | 5 of 5 | - | +199 |
| Mine | Skaven | 1 | 0 | 205 | 1.0 | 1.0 | 205 | 0 | +205 | 0 of 1 | 1 of 1 | - | +205 |
| **Mine** | all armies | 3 | 0 | 416 | 3.7 | 1.0 | 113 | 6 | +107 | 2 of 11 | 10 of 11 | - | +107 |
| Opponent | Vampire Counts | 2 | 0 | 771 | 3.5 | 1.1 | 220 | 117 | +104 | 4 of 7 | 5 of 7 | -817 | +257 |
| Opponent | Warriors of Chaos | 1 | 0 | 635 | 3.0 | 1.0 | 212 | 0 | +212 | 3 of 3 | 3 of 3 | - | +212 |
| **Opponent** | all armies | 3 | 0 | 726 | 3.3 | 1.1 | 218 | 82 | +136 | 7 of 10 | 8 of 10 | -817 | +242 |

### Effective charges: wfr-a92c160-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net -34) | 1 (net -34) | 0 | 1 (net +0) | 2 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 1 (net +646) | 0 | 4 | 0% (0 of 1) |
| Mine | Skaven | 1 | 1 (net +205) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 7 | 1 (net -817) | 0 | 3 (net +351) | 0 | 0 | 2 (net +128) | 1 | 50% (3 of 6) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +212) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 38 | 205 | +205 | 205 | 3 | +202 | +531.1 |
| Mine | Effective (55-75%) | 1 | 34 | 54 | -34 | 18 | 34 | -16 | -47.1 |
| Mine | 76-89% | 1 | 34 | 75 | -34 | 0 | 34 | -34 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 34 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 75 | +646 | 646 | 0 | +646 | +184.6 |
| Mine | No odds | 6 | 288 | 221 | +66 | 76 | 6 | +70 | +24.4 |
| Mine | All fights | 11 | 202 | 165 | +107 | 121 | 10 | +111 | +55.0 |
| Opponent | Long shot (under 50%) | 1 | 100 | 343 | -817 | 26 | 817 | -791 | -790.6 |
| Opponent | Effective (55-75%) | 3 | 281 | 253 | +351 | 384 | 0 | +384 | +136.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 337 | 319 | +178 | 214 | 82 | +132 | +39.1 |
| Opponent | No odds | 1 | 186 | 234 | +234 | 234 | 0 | +234 | +125.8 |
| Opponent | All fights | 10 | 281 | 293 | +136 | 248 | 123 | +125 | +44.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p22 | move | 14 | 7 (50%) | 5 (36%) | 2 (14%) | 5 (36%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

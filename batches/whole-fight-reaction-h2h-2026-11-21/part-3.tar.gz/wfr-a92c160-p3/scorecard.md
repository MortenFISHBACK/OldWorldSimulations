# Doctrine scorecard: wfr-a92c160-p3

### Scorecard: wfr-a92c160-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 11 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1163 |
| L0421 | 1 | 1 | Mine | no | 9 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 9.0 | 3.0 | 1.7 | 2.0 | 0.0 | 0.0 | 0.0 | 126.7 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.0 | 3.3 | 0.3 | 0.0 | 0.0 | 644.3 |

### KPIs: wfr-a92c160-p3

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 71% (5 of 7) | 31% (5 of 16) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 50% (1 of 2); on the table 50% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | 17% (1 of 6) | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 27% (3 of 11) | 17% (1 of 6) | 24% (4 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 78% (4684 of 5998) | 77% (4599 of 5999) | 77% (9283 of 11997) |
|   infantry points that never fought | lower | 87% (1239 of 1424) | 82% (1389 of 1703) | 84% (2628 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 69% (18 of 26) | 65% (32 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3200 of 5120) | 65% (3058 of 4677) | 64% (6258 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (56%) | 0.7 (40%) | 2.3 (50%) |
| MARCHED: its unit marched | 0.7 (22%) | 1.0 (60%) | 1.7 (36%) |
| CHARGED: its unit charged | 0.3 (11%) | 0.0 (0%) | 0.3 (7%) |
| IN COMBAT: engaged in combat | 0.3 (11%) | 0.0 (0%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 0.0 | 1.3 | 1.3 | 1.0 |
| not cast | 2.3 | 4.0 | 4.7 | 2.7 | 11.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (67%) | 2.3 (50%) | 0.7 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (36%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (8%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (75%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (100%) | 1.0 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (88%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (48 of 82) | 67% (67 of 100) | 63% (115 of 182) |
|   cavalry | 67% (8 of 12) | 0% (0 of 7) | 42% (8 of 19) |
|   character | 50% (5 of 10) | 82% (18 of 22) | 72% (23 of 32) |
|   chariot | 50% (11 of 22) | 54% (7 of 13) | 51% (18 of 35) |
|   infantry | 17% (2 of 12) | 42% (8 of 19) | 32% (10 of 31) |
|   war machine | 85% (22 of 26) | 87% (34 of 39) | 86% (56 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (26%) | 1.7 (15%) | 4.7 (21%) |
| CHARGED: it charged | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| NO TARGET IN RANGE | 5.0 (44%) | 4.7 (42%) | 9.7 (43%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (21%) | 2.7 (24%) | 5.0 (22%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 1.3 (12%) | 1.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.3 | 88% | 0.6 pts | 2 pts |
| character | 7.7 | 3.7 | 70% | 12.9 pts | 99 pts |
| chariot | 6.0 | 10.3 | 44% | 25.4 pts | 153 pts |
| infantry | 6.0 | 4.0 | 61% | 17.5 pts | 105 pts |
| war machine | 18.7 | 19.3 | 55% | 23.3 pts | 435 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 0.0 | 1.0 |
| Charges that made contact a game | 1.0 | 0.0 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.14 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.11 declared, 0.07 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 90% (9 of 10) | 50% (1 of 2) | - | 83% (10 of 12) |
| Character on its own | 100% (2 of 2) | 100% (2 of 2) | 67% (2 of 3) | 86% (6 of 7) |
| Chariot | 50% (1 of 2) | 80% (4 of 5) | - | 71% (5 of 7) |
| Infantry | 62% (5 of 8) | 40% (2 of 5) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 75% (3 of 4); on the table 75% | 25% (3 of 12) | 67% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 100% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 30% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 67% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 17% (1 of 6) | - |
| Strategy | Shoot objectives carried out (shot that target) | 58% (18 of 31) | 78% (32 of 41) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 20% (2 of 10) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.3 |
| Movement | Points that never moved of their own | 126.7 | 644.3 |
| Movement | Fights charged into per game | 1.0 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +0 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +72 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (16 of 26) | 73% (24 of 33) |
| Shooting | Points destroyed by shooting units | 119.7 | 46.3 |
| Shooting | War machine shots | 7.3 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 53% (18 of 34) |
| Shooting | Points destroyed by war machines | 176.0 | 238.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (2 of 2) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | - | 0.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 1.3 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 70.0 | 21.7 |
| Combat | Points run down | 48.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +55 | - |
| Combat | Net per 100 charger points, damage counted | +21.5 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +48 | - |
| Combat | Net points per supported fight / lone fight | - / +48 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | - |
| Game | Points lost | 369.3 | 525.7 |
| Game | VP from objectives | 1083.3 | 636.7 |
| Game | Lone holders (player turns) | 9.0 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +553 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 895
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +31.1 | 0.0 | 48.3 |
| ARMY TABLE | 15.7 | +344.9 | 0.0 | 253.0 | 15.7 | -117.9 | 0.0 | 309.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -14.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 0.7 | +0.0 | 125.0 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 11.3 | +85.7 | 1043.7 | 126.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.3 | +8.2 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +1.9 | 0.0 | 12.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -771.9 | 0.0 | 479.0 | 9.7 | -783.8 | 0.0 | 305.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 61.3 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 43.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 1.7 | -58.9 | 0.0 | 31.7 | 5.7 | -564.9 | 0.0 | 21.7 |
| DENIED BY THE FIGHT | 0.7 | -7.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.3 | -23.9 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +3.8 | 79.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +24.6 | 61.3 | 0.0 | - | - | - | - |
| FALLS SHORT | 7.7 | +56.5 | 0.0 | 262.7 | 8.7 | +130.5 | 0.0 | 30.7 |
| FEATURE BUFFS | 0.7 | +8.4 | 0.0 | 0.0 | 1.3 | +11.7 | 0.0 | 61.3 |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 92.7 | +6438.6 | 1703.0 | 908.7 | 92.0 | +3061.2 | 2952.7 | 923.0 |
| FLANK NOT WEIGHED | 2.0 | +0.0 | 0.0 | 113.0 | 5.0 | +0.0 | 0.0 | 83.0 |
| FOLLOW UP WEIGHED | 0.3 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +262.9 | 109.7 | 0.0 | - | - | - | - |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 109.7 |
| FRIEND SHOOTS FIRST | 1.0 | -22.8 | 0.0 | 0.0 | 2.0 | -6.5 | 452.0 | 0.0 |
| GIVES UP | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 11.0 | +1744.2 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +26.9 | 52.3 | 0.0 | 2.0 | +0.9 | 0.0 | 43.3 |
| GUN MASK | - | - | - | - | 0.7 | +3.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 61.3 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 329.3 | 6.7 | +0.0 | 0.0 | 171.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -8.9 | 0.0 | 0.0 | 2.0 | -42.2 | 0.0 | 79.0 |
| HIS MOVE AS HE DECIDES | 30.7 | +9.7 | 208.7 | 0.0 | 38.3 | +13.0 | 522.3 | 0.0 |
| HIS MOVE WHY | 11.0 | +0.0 | 0.0 | 43.3 | 25.3 | +0.0 | 0.0 | 117.3 |
| HIS ONE MOVE | 24.0 | -61.4 | 0.0 | 149.7 | 16.0 | +19.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 48.3 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.3 | +2311.1 | 0.0 | 632.0 | 35.0 | +1340.9 | 0.0 | 459.7 |
| HIS SHOTS BY HIS RUN | 36.7 | +841.0 | 0.0 | 612.0 | 28.0 | +774.6 | 0.0 | 421.3 |
| HIS TURN DENIED | 0.7 | +21.3 | 48.3 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 122.7 |
| HOLDER ASSIGNMENT | 11.0 | +1119.2 | 0.0 | 0.0 | 7.7 | +697.9 | 0.0 | 98.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -70.5 | 109.7 | 0.0 | - | - | - | - |
| IDLE COST | 7.3 | -133.5 | 0.0 | 181.0 | 9.7 | -120.9 | 0.0 | 98.7 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 70.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +18.8 | 109.7 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +23.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +1.5 | 0.0 | 0.0 | 1.3 | -11.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +158.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +165.4 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 1.0 | +20.9 | 0.0 | 0.0 | 1.0 | +7.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +33.4 | 0.0 | 0.0 | 3.0 | +10.8 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 103.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.3 | +111.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.7 | -189.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +732.2 | 0.0 | 329.3 | 0.3 | +11.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +236.1 | 0.0 | 0.0 | 4.7 | +195.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.3 | +434.1 | 0.0 | 103.3 | 1.7 | +44.5 | 452.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -92.3 | 61.3 | 0.0 | - | - | - | - |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -195.1 | 0.0 | 31.7 | 4.7 | -77.2 | 0.0 | 94.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -110.1 | 0.0 | 216.3 | 1.0 | -24.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | +70.0 | 0.0 | 0.0 | 2.7 | +76.3 | 0.0 | 30.7 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +5.6 | 30.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | -2.2 | 0.0 | 0.0 | 0.7 | +2.6 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +649.2 | 402.3 | 649.0 | 42.3 | +1509.4 | 475.0 | 646.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -508.6 | 0.0 | 226.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -3.3 | 0.0 | 0.0 |
| QUARTER ODDS | 23.3 | +1978.6 | 438.7 | 63.3 | 27.0 | +1702.3 | 826.7 | 241.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +22.8 | 0.0 | 215.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 1.0 | -41.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -17.7 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.3 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | -21.8 | 61.3 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -9.2 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.7 | -31.0 | 109.7 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +22.7 | 0.0 | 103.3 | 0.7 | +16.8 | 0.0 | 21.7 |
| SET CREDITED ONCE | 0.3 | -2.0 | 0.0 | 0.0 | 0.7 | -28.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | -17.8 | 0.0 | 0.0 | 0.7 | +28.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +23.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.3 | +0.0 | 0.0 | 95.0 | 13.7 | +0.0 | 0.0 | 126.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +123.4 | 48.3 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.3 | -20.5 | 48.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 28.7 | +298.8 | 0.0 | 629.0 | 19.7 | +20.0 | 0.0 | 459.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +348.6 | 0.0 | 126.7 | 20.3 | +476.9 | 0.0 | 148.3 |
| SPELL WORTH | - | - | - | - | 3.7 | +95.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 216.3 | 4.7 | +0.0 | 0.0 | 70.0 |
| STANDS FOR A REASON | 1.7 | +0.0 | 0.0 | 103.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 48.0 | +0.0 | 1593.3 | 446.3 | 55.0 | +0.0 | 2952.7 | 690.0 |
| STAY WORTH | 29.0 | +272.7 | 1109.0 | 325.0 | 31.7 | +32.5 | 1822.7 | 469.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 1.7 | +15.7 | 0.0 | 0.0 | 4.3 | +519.5 | 0.0 | 30.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 30.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.7 | +15.7 | 0.0 | 0.0 | 4.3 | +519.5 | 0.0 | 30.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -36.4 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 103.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 68.0 | 4.0 | +0.0 | 0.0 | 21.7 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 113.0 | 1.0 | +0.0 | 0.0 | 52.3 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 68.0 | 3.0 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.3 | +0.0 | 0.0 | 422.7 | 43.0 | +0.0 | 0.0 | 286.7 |
| TIED UP BY THE SUM | 0.3 | +42.5 | 30.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 24.0 | +308.7 | 269.3 | 86.7 | 18.7 | +210.8 | 452.0 | 67.3 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 96.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +0.8 | 48.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -110.1 | 0.0 | 226.0 | 2.7 | -564.6 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +289.9 | 0.0 | 61.3 |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 1.7 | +24.0 | 0.0 | 134.7 |

### Rule changes: wfr-a92c160-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 207 | 207 | 139 | 46.33 | +0 | +0.0 |
| ARMY TABLE | 94 | 94 | 60 | 20.00 | +742 | +12.4 |
| HIS SHOT LIST | 250 | 241 | 53 | 17.67 | +929 | +17.5 |
| HOLDER ASSIGNMENT | 56 | 56 | 52 | 17.33 | +2628 | +50.5 |
| HIS MOVE WHY | 109 | 109 | 49 | 16.33 | +0 | +0.0 |
| HIS ONE MOVE | 120 | 118 | 42 | 14.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 194 | 186 | 41 | 13.67 | +923 | +22.5 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -817 | -30.3 |
| FIVE ACTION | 554 | 542 | 18 | 6.00 | +865 | +48.0 |
| SHOT RISK POINTS | 145 | 140 | 18 | 6.00 | +361 | +20.1 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 42 | 40 | 15 | 5.00 | +1484 | +99.0 |
| TIME ON OUR SIDE | 128 | 111 | 14 | 4.67 | +11 | +0.8 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 20 | 18 | 13 | 4.33 | +516 | +39.7 |
| CANNON PLANNED TARGET | 54 | 54 | 12 | 4.00 | +0 | +0.0 |
| IDLE COST | 51 | 47 | 12 | 4.00 | +51 | +4.2 |
| NEXT CHARGE BY LIST | 18 | 18 | 12 | 4.00 | +505 | +42.1 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 11 | 3.67 | -1526 | -138.7 |
| THE RISK READS HIS RUN | 36 | 36 | 11 | 3.67 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| STAY WORTH | 182 | 162 | 7 | 2.33 | +163 | +23.3 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 6 | 2.00 | +139 | +23.2 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| FOUR ROUNDS | 6 | 6 | 4 | 1.33 | +189 | +47.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +68 | +17.1 |
| SET UP BY THE SET | 7 | 7 | 4 | 1.33 | +39 | +9.8 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SUPPORT ADDS | 18 | 18 | 4 | 1.33 | +80 | +20.0 |
| SUPPORT WORKED OUT | 18 | 18 | 4 | 1.33 | +80 | +20.0 |
| CHARGE LOSSES | 83 | 81 | 3 | 1.00 | +260 | +86.7 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +162 | +53.9 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| QUARTER ODDS | 151 | 147 | 3 | 1.00 | +37 | +12.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +119 | +39.5 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +21 | +10.5 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 22 | 16 | 2 | 0.67 | +19 | +9.4 |
| FALLS SHORT | 49 | 46 | 2 | 0.67 | +22 | +10.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MAX FOR POSITIONING | 9 | 8 | 2 | 0.67 | +173 | +86.7 |
| ONE OBJECTIVE FORMULA | 15 | 9 | 2 | 0.67 | +46 | +23.1 |
| REDIRECT COUNTER | 4 | 2 | 2 | 0.67 | +99 | +49.6 |
| SHOTS AFTER THE MOVES | 23 | 23 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 110 | 79 | 2 | 0.67 | +12 | +6.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 6 | 6 | 2 | 0.67 | -226 | -113.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +93 | +93.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -44 | -43.7 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -41 | -41.2 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +10 | +9.6 |
| FALL BACK GOOD ORDER | 5 | 5 | 1 | 0.33 | +48 | +47.6 |
| FEATURE BUFFS | 6 | 6 | 1 | 0.33 | +4 | +3.5 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +75 | +75.3 |
| LOST AFTER ESCAPE | 4 | 4 | 1 | 0.33 | +3 | +2.6 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +4 | +4.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +25 | +25.1 |
| MISSILES NEXT TURN | 16 | 10 | 1 | 0.33 | +2 | +2.4 |
| ONE FIGHT FORMULA | 19 | 11 | 1 | 0.33 | +4 | +3.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +28 | +27.5 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +48 | +47.6 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 29 | 29 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 45 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 21 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 33 | 33 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 8 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 5 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 3 | 3 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 93 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| NEARER NOT NEEDED | 30 | 29 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 250 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 72 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 33 | 22 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 309 | 303 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 17 | 17 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 5 | 5 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.33 | 26.1 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | - | 138.7 |
| ARMY TABLE | rule | 0.67 | 1.67 | 108.6 |
| RULE SWITCHED OFF | gate | 1.33 | - | 64.2 |
| WAR ENGINE JOBS | rule | 0.67 | - | 113.2 |
| AFTERMATH BAND | gate | 0.33 | - | 1.3 |
| BEST PRIZE | rule | 0.33 | - | 43.7 |
| CHARGE NOW FIRST | rule | 0.33 | - | 41.2 |
| NO REASON | gate | - | 0.33 | 11.1 |
| PATHS CROSS | rule | 0.33 | - | 6.7 |
| SET UP BY THE SET | rule | 0.33 | - | 40.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |

### Plans: wfr-a92c160-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 282 | 128 | 45% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 30.7 | 93% | 1958 | 0 | 0% |
| Mine | shoot | 8.7 | 62% | 296 | 521 | 176% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 28.3 | 93% | 1186 | 0 | 0% |
| Opponent | shoot | 12.3 | 84% | 354 | 1509 | 426% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 16 (11) | 16 | 0 | 13 | 27% | 2.0 | 38 (5) | 0 (4) | 0 (2) | 31 (7) | 0 (4) |
| Mine | Clean-up | 3 | 139 (3) | 40 | 99 | 0 | 67% | 6.0 | 139 (3) | - | - | 210 (2) | 0 (1) |
| Mine | Hammer | 8 | 23 (8) | 9 | 15 | 20 | 12% | 2.4 | 0 (2) | 28 (6) | - | 47 (5) | 0 (3) |
| Mine | Holder | 4 | 93 (4) | 0 | 93 | 27 | 75% | 1.0 | 0 (1) | 123 (3) | - | 194 (1) | 56 (3) |
| Mine | Shooter | 1 | 80 (1) | 0 | 80 | 0 | 0% | 2.0 | 80 (1) | - | - | - | 80 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 23 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 7 (14) | 7 | 0 | 5 | 43% | 3.0 | 10 (10) | 0 (3) | - | 9 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 50% | 5.0 | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 24 (6) | 17 | 7 | 40 | 17% | 2.4 | 19 (2) | 0 (1) | 42 (3) | 24 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 67 | 50% | 3.5 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 72 (9) | 72 | 0 | 52 | 11% | 1.0 | 72 (9) | - | - | 0 (1) | 84 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: wfr-a92c160-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 78 | 72 | 1.5 | 1.0 | 48 | 0 | +48 | 1 of 3 | 3 of 3 | - | +48 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 296 | 48 | 1.0 | 1.0 | 48 | 0 | +48 | 1 of 3 | 3 of 3 | - | +48 |
| Opponent | Dwarfen Mountain Holds | 1 | 788 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 284 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: wfr-a92c160-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 (net +72) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 230 | 292 | +72 | 203 | 121 | +82 | +35.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 92 | +0 | 46 | 44 | +2 | +0.6 |
| Mine | All fights | 3 | 256 | 226 | +48 | 151 | 96 | +55 | +21.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p3 | move | 15 | 4 (27%) | 2 (13%) | 0 (0%) | 11 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

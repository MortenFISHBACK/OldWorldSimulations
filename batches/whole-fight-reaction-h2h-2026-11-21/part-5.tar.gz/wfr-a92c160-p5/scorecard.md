# Doctrine scorecard: wfr-a92c160-p5

### Scorecard: wfr-a92c160-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0717 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0733 | 1 | 1 | Mine | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 295 |
| L0733 | 1 | 1 | Opponent | no | 3 | 4 | 4 | 3 | 0 | 0 | 0 | 234 |
| L0823 | 1 | 1 | Mine | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 551 |
| L0823 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 1 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 8.0 | 2.0 | 1.5 | 0.5 | 0.5 | 0.0 | 0.0 | 423.0 |
| **Average** | | | Opponent | 0% | 2.0 | 3.0 | 3.0 | 3.0 | 0.5 | 0.0 | 0.0 | 214.5 |

### KPIs: wfr-a92c160-p5

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 93% (13 of 14) | 0% (0 of 11) | 52% (13 of 25) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 100% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (5 of 10) | 25% (3 of 12) | 36% (8 of 22) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (5 of 10) | 38% (3 of 8) | 44% (8 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 60% (2381 of 3999) | 55% (2206 of 4000) | 57% (4587 of 7999) |
|   infantry points that never fought | lower | 100% (561 of 561) | 80% (837 of 1045) | 87% (1398 of 1606) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 60% (9 of 15) | 57% (20 of 35) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (1675 of 3589) | 51% (1748 of 3408) | 49% (3423 of 6997) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (60%) | 1.3 (44%) | 2.3 (50%) |
| MARCHED: its unit marched | 0.7 (40%) | 0.3 (11%) | 1.0 (21%) |
| FLEEING: fleeing | 0.0 (0%) | 1.3 (44%) | 1.3 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 2.7 | 0.3 | 0.3 |
| not cast | 3.3 | 0.7 | 4.7 | 1.7 | 9.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 2.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.3 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 1.3 (40%) | 0.0 (0%) | 1.3 (29%) | 1.3 (80%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (96%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (44 of 69) | 75% (48 of 64) | 69% (92 of 133) |
|   cavalry | 73% (8 of 11) | 73% (11 of 15) | 73% (19 of 26) |
|   character | - | 67% (8 of 12) | 67% (8 of 12) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 8% (1 of 12) | 78% (29 of 37) | 61% (30 of 49) |
|   war machine | 76% (31 of 41) | - | 76% (31 of 41) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (32%) | 1.7 (31%) | 4.3 (32%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (25%) | 1.3 (10%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.0 (12%) | 0.7 (12%) | 1.7 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.7 (12%) | 1.3 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (20%) | 1.0 (19%) | 2.7 (20%) |
| SHELTERED: the target was sheltered | 1.3 (16%) | 0.0 (0%) | 1.3 (10%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.7 | 3.7 | 66% | 9.6 pts | 92 pts |
| character | 2.7 | 0.7 | 75% | 5.2 pts | 14 pts |
| chariot | 1.3 | 0.7 | 75% | 24.4 pts | 33 pts |
| infantry | 16.0 | 6.0 | 71% | 9.1 pts | 145 pts |
| war machine | 10.3 | 8.7 | 48% | 24.1 pts | 249 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.3 | 2.3 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (26 units) | 0.34 declared, 0.17 contact (29 units) | 0.25 declared, 0.16 contact (55 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 0% (0 of 2) | - | 38% (3 of 8) |
| Character in a unit | 100% (4 of 4) | - | 0% (0 of 1) | 80% (4 of 5) |
| Character on its own | 100% (2 of 2) | 100% (1 of 1) | 33% (1 of 3) | 67% (4 of 6) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 1) | 33% (1 of 3) | 0% (0 of 1) | 20% (1 of 5) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 71% (5 of 7) | - | - | 71% (5 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 50% (1 of 2); on the table 100% | 50% (3 of 6) | 60% | 55% (11 of 20) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 69% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 42% | 70% (7 of 10) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 0% (0) | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (16 of 52) | 83% (10 of 12) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 0.5 | 3.0 |
| Movement | Points that never moved of their own | 423.0 | 214.5 |
| Movement | Fights charged into per game | 1.5 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -281 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +0 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +342 | 1 of 1, net +130 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (8 of 15) | 56% (30 of 54) |
| Shooting | Points destroyed by shooting units | 251.3 | 101.3 |
| Shooting | War machine shots | 10.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (12 of 31) | - |
| Shooting | Points destroyed by war machines | 6.3 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 4.7 | 1.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.0 / 0.3 / 0.0 | 2.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 70.7 | 182.0 |
| Combat | Points run down | 114.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +8 | +113 |
| Combat | Net per 100 charger points, damage counted | +4.6 | +67.2 |
| Combat | First round won (charged fights) | 33% | 80% |
| Combat | Net points per charged fight | +20 | +36 |
| Combat | Net points per supported fight / lone fight | - / +20 | - / +36 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 4 of 5 |
| Game | Points lost | 462.5 | 614.0 |
| Game | VP from objectives | 990.0 | 835.0 |
| Game | Lone holders (player turns) | 8.0 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +164 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1076
- Games not ended: 1 (L0717-1); findings 1, warnings 0

### Opponent rules: wfr-a92c160-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +97.5 | 0.0 | 182.0 | 28.3 | +481.7 | 0.0 | 79.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -12.9 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -5.2 | 67.3 | 0.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 540.0 | 43.3 | - | - | - | - |
| CANNON PLANNED TARGET | 11.7 | +652.6 | 1647.7 | 86.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.0 | +153.4 | 144.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +44.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.1 | 0.0 | 36.3 |
| CHARACTER GUNS | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.7 | -1079.2 | 0.0 | 156.3 | 16.0 | -1250.1 | 0.0 | 432.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 36.0 | 0.0 | 1.3 | +0.0 | 67.3 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -7.8 | 0.0 | 93.7 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 61.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 176.7 | - | - | - | - |
| COVER ONCE | 11.7 | -775.8 | 0.0 | 110.7 | 9.7 | -598.4 | 0.0 | 180.0 |
| DENIED BY THE FIGHT | 0.7 | -5.0 | 36.0 | 0.0 | 0.3 | -0.8 | 0.0 | 36.3 |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 71.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.3 | 43.3 | 0.0 |
| EXACT ROUND | 1.0 | -14.6 | 36.0 | 0.0 | 1.3 | +10.4 | 43.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +11.2 | 36.0 | 0.0 | 2.0 | +3.2 | 110.7 | 36.3 |
| FALLS SHORT | - | - | - | - | 22.3 | +221.1 | 0.0 | 288.3 |
| FEATURE BUFFS | 0.7 | +40.8 | 0.0 | 0.0 | 0.7 | +25.0 | 0.0 | 36.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 110.0 | +7792.8 | 3894.7 | 833.7 | 80.7 | +5118.1 | 781.0 | 685.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 88.3 | 4.0 | +0.0 | 0.0 | 216.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +74.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +243.6 | 36.0 | 93.7 | 2.0 | +202.6 | 110.7 | 36.3 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.7 | -32.2 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.7 | -79.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -7.7 | 0.0 | 93.7 | 0.7 | -0.8 | 43.3 | 36.3 |
| GOAL WALK | 6.0 | +444.6 | 0.0 | 0.0 | 14.7 | +876.3 | 0.0 | 97.3 |
| GUN FIGURES | 1.3 | +129.2 | 180.0 | 88.3 | - | - | - | - |
| GUN MASK | 2.3 | +45.6 | 0.0 | 93.7 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 11.3 | +0.0 | 0.0 | 88.3 | 10.3 | +0.0 | 0.0 | 396.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.6 | 0.0 | 36.3 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 88.3 | 5.3 | +0.0 | 0.0 | 180.0 |
| HIS MOVE AND SHOT | 3.0 | -78.3 | 0.0 | 0.0 | 2.3 | -41.2 | 0.0 | 366.3 |
| HIS MOVE AS HE DECIDES | 41.0 | +9.7 | 473.3 | 0.0 | 34.7 | +8.3 | 410.3 | 0.0 |
| HIS MOVE WHY | 26.0 | +0.0 | 0.0 | 34.0 | 11.7 | +0.0 | 0.0 | 126.0 |
| HIS ONE MOVE | 21.7 | +15.0 | 0.0 | 88.3 | 21.7 | +35.5 | 30.0 | 34.7 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 244.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 88.3 | 2.0 | +0.0 | 0.0 | 180.0 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.3 | +1872.5 | 0.0 | 432.0 | 55.0 | +3268.9 | 0.0 | 253.3 |
| HIS SHOTS BY HIS RUN | 48.0 | +1154.6 | 0.0 | 338.3 | 40.7 | +1794.7 | 0.0 | 588.0 |
| HIS TURN DENIED | 0.7 | +47.8 | 36.0 | 0.0 | 1.0 | +61.4 | 43.3 | 0.0 |
| HIS TURN RUN | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 25.7 | +0.0 | 0.0 | 0.0 | 21.3 | +0.0 | 0.0 | 144.0 |
| HOLDER ASSIGNMENT | 15.7 | +1518.5 | 0.0 | 67.3 | 15.0 | +1242.6 | 0.0 | 72.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -20.7 | 36.0 | 0.0 | 2.0 | -50.9 | 110.7 | 36.3 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +12.9 | 0.0 | 180.0 |
| IDLE COST | - | - | - | - | 13.0 | -236.2 | 0.0 | 235.3 |
| KEEP FALLS | 0.3 | +24.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 0.0 | 88.3 | 4.7 | +0.0 | 88.3 | 41.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.3 | 0.0 | 0.0 | 0.7 | +1.2 | 67.3 | 36.3 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | -28.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 36.0 |
| MARCH BY THE SUM | 0.7 | +7.5 | 0.0 | 0.0 | 0.3 | +39.4 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 36.0 |
| MARCH OF THE TABLE | 0.7 | +38.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +18.6 | 0.0 | 0.0 | 0.7 | -24.3 | 0.0 | 36.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +90.2 | 0.0 | 93.7 | 1.3 | +11.6 | 0.0 | 180.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +108.3 | 0.0 | 0.0 | 2.7 | +26.4 | 0.0 | 36.0 |
| MISSILES NEXT TURN | 3.3 | +72.4 | 0.0 | 0.0 | 3.7 | +26.5 | 0.0 | 72.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +577.7 | 0.0 | 0.0 | 4.7 | +382.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +351.1 | 0.0 | 67.3 | 11.7 | +565.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.0 | +284.5 | 0.0 | 0.0 | 3.3 | +279.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -49.0 | 36.0 | 93.7 | 2.0 | -156.7 | 110.7 | 36.3 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -145.8 | 0.0 | 0.0 | 5.7 | -118.9 | 0.0 | 252.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -96.5 | 0.0 | 88.3 | 2.0 | -60.4 | 0.0 | 180.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -40.6 | 0.0 | 67.3 | 5.7 | -61.4 | 0.0 | 72.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +4.7 | 72.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +9.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -6.1 | 0.0 | 0.0 | 0.3 | -8.3 | 0.0 | 0.0 |
| PLAN RESULT | 49.7 | +2479.9 | 972.0 | 585.3 | 36.7 | +331.0 | 322.0 | 544.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.3 | -193.1 | 0.0 | 0.0 | 5.7 | -137.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -60.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.0 | +2411.7 | 0.0 | 331.3 | 13.3 | +1716.2 | 178.0 | 71.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +38.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +9.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 6.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -12.9 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -27.7 | 0.0 | 0.0 | 0.3 | -4.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 36.3 |
| RISK BY ARC | 1.3 | -11.3 | 36.0 | 93.7 | 1.3 | -93.0 | 110.7 | 36.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -8.9 | 110.7 | 0.0 |
| RUN DOWN | 1.0 | -31.5 | 36.0 | 0.0 | 1.0 | -18.2 | 110.7 | 36.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.4 | 0.0 | 0.0 | 0.3 | +25.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +3.3 | 0.0 | 36.3 |
| SET UP BY THE SET | 0.7 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 20.3 | +0.0 | 0.0 | 154.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +9.8 | 0.0 | 0.0 | 1.7 | +61.6 | 254.7 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -23.0 | 36.0 | 0.0 | 0.3 | -6.7 | 67.3 | 0.0 |
| SHOT RISK POINTS | 35.7 | -238.7 | 0.0 | 255.3 | 28.7 | +305.8 | 0.0 | 293.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.3 | +1364.5 | 0.0 | 242.3 | 19.7 | +365.5 | 0.0 | 36.0 |
| SPELL WORTH | 1.7 | +8.6 | 0.0 | 0.0 | 2.7 | +24.9 | 0.0 | 156.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 107.0 |
| STAND AND SHOOT | 0.7 | -8.5 | 0.0 | 0.0 | 0.3 | -5.4 | 67.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.3 | +0.0 | 67.3 | 0.0 |
| STANDS STILL | 62.0 | +0.0 | 3858.7 | 308.0 | 18.3 | +0.0 | 670.3 | 36.0 |
| STAY WORTH | 49.0 | +652.2 | 2958.7 | 260.0 | 13.7 | +65.9 | 134.7 | 36.0 |
| STRIKE BY THE ODDS | 0.3 | +1.8 | 36.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.0 | +52.7 | 0.0 | 93.7 | 8.3 | +699.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +52.7 | 0.0 | 93.7 | 8.3 | +699.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +23.1 | 0.0 | 67.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 36.0 |
| THE RISK READS HIS RUN | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 36.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.7 | +0.0 | 0.0 | 370.0 | 38.3 | +0.0 | 0.0 | 307.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +54.0 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 44.7 | +505.7 | 0.0 | 176.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +14.2 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +53.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -509.2 | 0.0 | 88.3 | 2.3 | -380.0 | 0.0 | 396.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.0 | +86.6 | 0.0 | 36.0 |
| WOUNDS ON THE RANKS | 6.7 | +132.3 | 0.0 | 0.0 | 2.3 | +63.8 | 0.0 | 72.0 |

### Rule changes: wfr-a92c160-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 227 | 227 | 173 | 57.67 | +0 | +0.0 |
| ARMY TABLE | 120 | 120 | 88 | 29.33 | +1626 | +18.5 |
| HIS SHOT LIST | 310 | 305 | 82 | 27.33 | +1726 | +21.0 |
| HOLDER ASSIGNMENT | 92 | 92 | 81 | 27.00 | +4335 | +53.5 |
| HIS MOVE WHY | 113 | 113 | 68 | 22.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 266 | 259 | 54 | 18.00 | +1062 | +19.7 |
| HIS ONE MOVE | 130 | 125 | 35 | 11.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -794 | -26.5 |
| SHOT RISK POINTS | 193 | 186 | 28 | 9.33 | +874 | +31.2 |
| FIVE ACTION | 572 | 558 | 26 | 8.67 | +1802 | +69.3 |
| THE TABLE AGAIN | 33 | 33 | 26 | 8.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 37 | 32 | 16 | 5.33 | +1012 | +63.3 |
| THE RISK READS HIS RUN | 33 | 33 | 16 | 5.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 134 | 109 | 16 | 5.33 | +26 | +1.6 |
| QUARTER ODDS | 124 | 117 | 15 | 5.00 | +802 | +53.5 |
| NEXT CHARGE BY LIST | 25 | 21 | 14 | 4.67 | +655 | +46.8 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 39 | 39 | 13 | 4.33 | -991 | -76.2 |
| GOAL WALK | 62 | 62 | 12 | 4.00 | +536 | +44.6 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| STAY WORTH | 188 | 173 | 11 | 3.67 | +136 | +12.4 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| CHARGE LOSSES | 113 | 110 | 8 | 2.67 | +731 | +91.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 6 | 2.00 | +69 | +11.5 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| SUPPORT ADDS | 28 | 27 | 5 | 1.67 | +94 | +18.7 |
| SUPPORT WORKED OUT | 28 | 27 | 5 | 1.67 | +94 | +18.7 |
| THE ROW IN ITS ORDER | 16 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 10 | 9 | 4 | 1.33 | +321 | +80.3 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 4 | 1.33 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +141 | +46.9 |
| RISK BY ARC | 8 | 7 | 3 | 1.00 | +140 | +46.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +157 | +52.2 |
| SHOTS IN THE MOVE | 132 | 100 | 3 | 1.00 | +32 | +10.5 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +156 | +52.1 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +69 | +34.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +224 | +112.0 |
| IDLE COST | 39 | 27 | 2 | 0.67 | +25 | +12.7 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MANOEUVRE | 12 | 12 | 2 | 0.67 | +31 | +15.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -115 | -57.3 |
| MAX FOR POSITIONING | 13 | 9 | 2 | 0.67 | +17 | +8.6 |
| NEARER NOT NEEDED | 59 | 55 | 2 | 0.67 | +94 | +46.9 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -43 | -21.6 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +11 | +5.6 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +81 | +40.6 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +121 | +60.6 |
| WOUNDS ON THE RANKS | 27 | 27 | 2 | 0.67 | +28 | +13.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -39 | -38.6 |
| CANNON PLANNED TARGET | 35 | 35 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -133 | -133.0 |
| COVER ONCE | 64 | 42 | 1 | 0.33 | +11 | +11.2 |
| FEATURE BUFFS | 4 | 4 | 1 | 0.33 | +11 | +10.8 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +23 | +22.8 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 9 | 8 | 1 | 0.33 | +17 | +16.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +107 | +107.4 |
| MISSILES IN THE MOVE | 15 | 8 | 1 | 0.33 | +40 | +39.5 |
| NO DOUBLE ROUNDS | 10 | 9 | 1 | 0.33 | +82 | +81.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +40 | +39.5 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -7 | -6.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -14 | -14.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +10 | +9.8 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -46 | -46.5 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +69 | +69.3 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +136 | +136.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 16 | 12 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 65 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 8 | 0 | 0.00 | - | - |
| FALLS SHORT | 67 | 61 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 29 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 33 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 36 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 32 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 33 | 33 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 141 | 141 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 27 | 27 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 10 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 32 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 74 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 24 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 241 | 235 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 5.00 | 24.8 |
| ARMY TABLE | rule | 1.67 | 3.67 | 40.0 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.00 | 76.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 18.6 |
| MARCH OF THE TABLE | rule | 0.67 | - | 57.3 |
| NO REASON | gate | - | 0.67 | 58.5 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 21.6 |
| RULE SWITCHED OFF | gate | 0.67 | - | 28.0 |
| BEST PRIZE | rule | - | 0.33 | 38.6 |
| CHARGE NOW FIRST | rule | - | 0.33 | 133.0 |
| FALLBACK | gate | 0.33 | - | 25.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 1.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 6.6 |
| REFUSING RETIRES | rule | - | 0.33 | 14.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 46.5 |

### Plans: wfr-a92c160-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 222 | 45 | 20% |
| Mine | join | 2.7 | 100% | 28 | 0 | 0% |
| Mine | move | 31.7 | 99% | 1949 | 0 | 0% |
| Mine | shoot | 14.0 | 79% | 1185 | 2435 | 206% |
| Opponent | charge | 2.0 | 33% | 396 | 86 | 22% |
| Opponent | move | 31.3 | 94% | 1800 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 174 | 245 | 141% |
| Opponent | support | 0.7 | 100% | 27 | 0 | 0% |

### Battle groups: wfr-a92c160-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 8 | 10 (8) | 10 | 0 | 39 | 62% | 3.0 | 18 (5) | - | 0 (3) | 11 (6) | 0 (2) |
| Mine | Clean-up | 1 | 176 (1) | 95 | 82 | 0 | 0% | 5.0 | - | 176 (1) | - | 176 (1) | - |
| Mine | Fast Hammer | 4 | 95 (4) | 66 | 29 | 25 | 25% | 2.0 | 129 (3) | - | 13 (1) | 95 (4) | - |
| Mine | Hammer | 2 | 38 (2) | 0 | 38 | 42 | 50% | 1.0 | - | 0 (1) | 65 (1) | 38 (2) | - |
| Mine | Shooter | 3 | 166 (3) | 6 | 160 | 0 | 33% | 2.0 | - | 220 (1) | 110 (2) | 220 (1) | 110 (2) |
| Mine | War machine | 7 | 63 (7) | 63 | 0 | 15 | 0% | 1.9 | 63 (7) | - | - | 400 (1) | 3 (6) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 22 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 6 | 31 (6) | 31 | 0 | 44 | 0% | 1.5 | - | 35 (3) | 28 (3) | 33 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 44 | 67% | 5.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 4 | 22 (4) | 22 | 0 | 68 | 25% | 3.7 | 67 (1) | 0 (1) | 0 (2) | 26 (3) | 0 (1) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 330 (3) | 158 | 172 | 0 | 0% | 1.7 | 150 (1) | 412 (2) | - | 528 (2) | 0 (1) |
| Opponent | Shooter | 3 | 86 (3) | 0 | 86 | 0 | 0% | 1.0 | - | 78 (2) | 101 (1) | 88 (2) | 81 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: wfr-a92c160-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 386 | 171 | 1.5 | 1.0 | 114 | 94 | +20 | 0 of 3 | 1 of 3 | - | +20 |
| Opponent | Tomb Kings of Khemri | 1 | 304 | 395 | 2.0 | 1.0 | 198 | 0 | +198 | 2 of 2 | 2 of 2 | - | +198 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 71 | -71 | 2 of 3 | 2 of 3 | - | -71 |
| **Opponent** | all armies | 2 | 152 | 198 | 2.5 | 1.0 | 79 | 43 | +36 | 4 of 5 | 4 of 5 | - | +36 |

### Effective charges: wfr-a92c160-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 1 (net -281) | 0 | 1 (net +0) | 0 | 0 | 1 (net +342) | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +130) | 1 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 181 | 0 | -281 | 80 | 376 | -296 | -163.3 |
| Mine | Effective (55-75%) | 1 | 189 | 208 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 189 | 108 | +342 | 342 | 21 | +321 | +169.8 |
| Mine | All fights | 3 | 186 | 105 | +20 | 141 | 132 | +8 | +4.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 202 | +130 | 384 | 140 | +244 | +125.3 |
| Opponent | No odds | 4 | 161 | 236 | +13 | 145 | 65 | +80 | +49.6 |
| Opponent | All fights | 5 | 168 | 229 | +36 | 193 | 80 | +113 | +67.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p5 | move | 19 | 4 (21%) | 4 (21%) | 0 (0%) | 15 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

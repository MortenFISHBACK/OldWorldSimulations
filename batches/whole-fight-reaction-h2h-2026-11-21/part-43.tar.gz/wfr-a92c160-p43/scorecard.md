# Doctrine scorecard: wfr-a92c160-p43

### Scorecard: wfr-a92c160-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 413 |
| L1135 | 1 | 1 | Mine | yes | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 3 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1228 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 3.0 | 2.3 | 0.7 | 0.3 | 0.0 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 3.0 | - | 2.0 | 1.3 | 0.0 | 0.0 | 0.0 | 137.7 |

### KPIs: wfr-a92c160-p43

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (3 of 15) | 0% (0 of 15) | 10% (3 of 30) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 100% | 100% (2 of 2); on the table 100% | 89% (8 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | 0% (0 of 1); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 82% (9 of 11); on the table 91% | 67% (2 of 3); on the table 100% | 79% (11 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 31% (22 of 72) | 39% (7 of 18) | 32% (29 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (22 of 56) | 44% (7 of 16) | 40% (29 of 72) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 53% (3178 of 5998) | 65% (3894 of 6000) | 59% (7072 of 11998) |
|   infantry points that never fought | lower | 63% (462 of 730) | 68% (532 of 782) | 66% (994 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (17 of 25) | 69% (18 of 26) | 69% (35 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 71% (5 of 7); 3.3 uses a game | 50% (1 of 2); 2.0 uses a game | 67% (6 of 9); 2.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3751 of 5614) | 72% (4043 of 5644) | 69% (7794 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.0 (42%) | 1.0 (27%) | 8.0 (39%) |
| MARCHED: its unit marched | 3.7 (22%) | 0.0 (0%) | 3.7 (18%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 4.7 (28%) | 0.0 (0%) | 4.7 (23%) |
| FLEEING: fleeing | 0.7 (4%) | 0.7 (18%) | 1.3 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 2.0 (55%) | 2.0 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 6.0 | 1.0 | 9.7 | 1.7 | 2.3 |
| not cast | 1.0 | 10.0 | 5.0 | 20.3 | 2.3 | 25.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 6.0 (60%) | 0.3 (7%) | 8.0 (39%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (18%) | 0.7 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 4.7 (23%) | 1.0 (43%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (20%) | 2.0 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.7 (7%) | 0.7 (13%) | 1.3 (7%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (10%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (100%) | 0.0 (0%) | 2.0 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 77% (40 of 52) | 76% (59 of 78) | 76% (99 of 130) |
|   cavalry | - | 90% (19 of 21) | 90% (19 of 21) |
|   character | - | 82% (9 of 11) | 82% (9 of 11) |
|   chariot | 60% (6 of 10) | 100% (6 of 6) | 75% (12 of 16) |
|   infantry | 83% (10 of 12) | 57% (17 of 30) | 64% (27 of 42) |
|   monster | - | 80% (8 of 10) | 80% (8 of 10) |
|   war machine | 80% (24 of 30) | - | 80% (24 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (33%) | 4.0 (63%) | 5.3 (52%) |
| CHARGED: it charged | 0.3 (8%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.3 (8%) | 0.7 (11%) | 1.0 (10%) |
| MOVED: a war machine that moved | 0.3 (8%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.0 (16%) | 1.0 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (11%) | 0.7 (6%) |
| SHELTERED: the target was sheltered | 0.7 (17%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR | 1.0 (25%) | 0.0 (0%) | 1.0 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 1.3 | 84% | 1.4 pts | 12 pts |
| character | 3.0 | 1.3 | 78% | 23.9 pts | 72 pts |
| chariot | 4.3 | 2.3 | 77% | 20.6 pts | 89 pts |
| infantry | 12.7 | 3.0 | 79% | 6.0 pts | 76 pts |
| monster | 2.7 | 0.7 | 88% | 5.4 pts | 14 pts |
| war machine | 9.3 | 6.7 | 61% | 19.9 pts | 186 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 2.0 | 2.5 |
| Charges that made contact a game | 2.0 | 2.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.17 declared, 0.83 contact (6 units) | - | 1.17 declared, 0.83 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | - | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.11 declared, 0.00 contact (9 units) | 0.23 declared, 0.23 contact (26 units) | 0.20 declared, 0.17 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | - | 75% (3 of 4) | 60% (6 of 10) |
| Character in a unit | 100% (3 of 3) | 100% (4 of 4) | 100% (1 of 1) | 100% (8 of 8) |
| Character on its own | - | 50% (3 of 6) | 50% (2 of 4) | 50% (5 of 10) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 62% (5 of 8) | - | - | 62% (5 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 82% (9 of 11); on the table 91% | 31% (22 of 72) | 53% | 68% (17 of 25) | 71% (5 of 7); 3.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 72% | 57% (4 of 7) | 100% (1 of 1); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 45% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 100% | 67% (4 of 6) | 77% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 33% (1) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 100% (4 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (14 of 42) | 77% (20 of 26) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 0% (0 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 1.3 |
| Movement | Points that never moved of their own | 275.0 | 137.7 |
| Movement | Fights charged into per game | 1.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 3 of 3, net -34 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +185 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +41 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +0 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.3 | 20.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 16) | 51% (31 of 61) |
| Shooting | Points destroyed by shooting units | 78.0 | 55.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (10 of 24) | - |
| Shooting | Points destroyed by war machines | 61.7 | 55.0 |
| Magic | Magic missiles cast | 5.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (3 of 15) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 5.7 | 2.0 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 11.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.3 / 0.3 | 1.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 162.3 | 0.0 |
| Combat | Points run down | 137.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +80 | -62 |
| Combat | Net per 100 charger points, damage counted | +21.1 | -71.8 |
| Combat | First round won (charged fights) | 80% | 0% |
| Combat | Net points per charged fight | +67 | -73 |
| Combat | Net points per supported fight / lone fight | +0 / +84 | - / -73 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 4 of 6 |
| Game | Points lost | 160.0 | 434.0 |
| Game | VP from objectives | 1013.3 | 360.0 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1085 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 594
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 10.0 | +103.5 | 0.0 | 0.0 | 30.7 | +989.6 | 0.0 | 81.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +18.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -13.7 | 11.3 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +10.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +226.5 | 300.7 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +125.1 | 48.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.3 | +22.9 | 0.0 | 0.0 | 1.3 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +55.1 | 0.0 | 13.7 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +17.0 | 0.0 | 37.0 |
| CHARGE LOSSES | 20.0 | -358.4 | 0.0 | 0.0 | 16.7 | -933.6 | 0.0 | 298.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 137.3 | 50.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 22.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +64.6 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -298.2 | 0.0 | 0.0 | 9.7 | -1086.7 | 0.0 | 335.7 |
| DENIED BY THE FIGHT | 0.7 | -1.2 | 100.3 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | -2.7 | 125.3 | 0.0 | 1.3 | -18.9 | 0.0 | 34.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.8 | 148.7 | 50.0 | 1.3 | +0.2 | 0.0 | 34.0 |
| FALLS SHORT | 2.7 | +47.3 | 0.0 | 0.0 | 27.0 | +347.4 | 0.0 | 396.3 |
| FEATURE BUFFS | 1.3 | +38.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +32.5 | 100.3 | 0.0 | 0.7 | +29.6 | 0.0 | 0.0 |
| FIVE ACTION | 81.0 | +6099.0 | 944.7 | 490.0 | 81.0 | +4735.0 | 770.0 | 850.0 |
| FLANK NOT WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 203.3 |
| FOLLOW UP WEIGHED | 1.3 | +214.6 | 0.0 | 50.0 | - | - | - | - |
| FOUR ROUNDS | 3.0 | +331.5 | 224.0 | 50.0 | 1.3 | +103.4 | 0.0 | 34.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 3.3 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +8.1 | 0.0 | 0.0 | 0.3 | +8.8 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.6 | 11.3 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +247.6 | 0.0 | 0.0 | 14.3 | +1272.5 | 0.0 | 200.7 |
| GUN FIGURES | - | - | - | - | 1.0 | +46.6 | 55.0 | 61.7 |
| GUN MASK | 3.3 | +135.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 298.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +64.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 307.3 |
| HIS MOVE AND SHOT | 4.7 | -42.2 | 0.0 | 0.0 | 6.0 | -57.9 | 0.0 | 125.3 |
| HIS MOVE AS HE DECIDES | 41.7 | +9.7 | 853.0 | 0.0 | 32.0 | +9.3 | 50.0 | 0.0 |
| HIS MOVE WHY | 29.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | 18.3 | -23.2 | 0.0 | 0.0 | 18.7 | +19.4 | 0.0 | 55.3 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 27.3 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 112.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.3 | +944.1 | 0.0 | 0.0 | 51.0 | +2581.1 | 0.0 | 341.3 |
| HIS SHOTS BY HIS RUN | 37.0 | +962.0 | 0.0 | 0.0 | 49.7 | +1796.4 | 0.0 | 569.3 |
| HIS TURN DENIED | 1.0 | +74.5 | 162.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.0 | +959.6 | 0.0 | 0.0 | 5.7 | +862.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -113.2 | 224.0 | 50.0 | 1.3 | -32.3 | 0.0 | 34.0 |
| HUNT IN PAIRS | 1.3 | +192.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 1.0 | -18.5 | 0.0 | 0.0 | 13.0 | -247.3 | 0.0 | 220.0 |
| JOINT CHARGE NOW | 1.0 | +36.5 | 100.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 148.7 | 150.0 | 2.7 | +0.0 | 50.0 | 201.7 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +3.8 | 0.0 | 34.0 |
| LOST AFTER ESCAPE | 2.0 | -9.5 | 162.0 | 50.0 | 0.7 | +2.1 | 0.0 | 34.0 |
| MANOEUVRE | 2.0 | +35.3 | 0.0 | 0.0 | 1.7 | +18.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 2.0 | +187.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +74.4 | 0.0 | 0.0 | 0.3 | +18.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +172.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | -74.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 4.0 | +111.6 | 0.0 | 0.0 | 2.3 | +84.5 | 0.0 | 61.7 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +202.7 | 0.0 | 0.0 | 5.0 | +69.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.3 | +116.1 | 0.0 | 0.0 | 4.7 | +35.6 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.3 | -24.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 1.7 | +0.0 | 100.3 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +377.6 | 0.0 | 0.0 | 1.3 | +64.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +296.9 | 0.0 | 0.0 | 6.3 | +326.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +273.4 | 0.0 | 0.0 | 1.7 | +102.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -21.4 | 0.0 | 0.0 | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -106.9 | 224.0 | 50.0 | 1.0 | -23.7 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -247.5 | 37.0 | 0.0 | 4.3 | -112.5 | 0.0 | 41.7 |
| OGRE LOADER SECOND SHOT | 7.7 | +52.0 | 34.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -76.1 | 0.0 | 0.0 | 5.7 | -167.3 | 0.0 | 215.3 |
| ONE JOINT FIGURE | 0.7 | +51.9 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 7.0 | -55.8 | 0.0 | 0.0 | 2.0 | +29.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +2.7 | 61.7 | 55.0 | - | - | - | - |
| OPENS UP | 0.3 | +8.2 | 11.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +41.3 | 61.7 | 50.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| PLAN RESULT | 35.0 | +488.5 | 567.7 | 265.0 | 36.3 | +318.7 | 220.0 | 853.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -135.1 | 0.0 | 0.0 | 2.3 | -54.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 3.0 | -11.0 | 0.0 | 0.0 | 0.3 | -3.8 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -1.5 | 27.3 | 0.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| QUARTER ODDS | 16.3 | +2226.9 | 82.0 | 0.0 | 14.3 | +1261.4 | 0.0 | 129.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +448.4 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 11.3 |
| REFORMS TO MEET IT | 1.0 | -123.7 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.0 | +49.6 | 224.0 | 50.0 | 0.7 | -28.2 | 0.0 | 0.0 |
| RUN DOWN | 3.0 | -18.5 | 224.0 | 50.0 | 1.0 | -4.4 | 0.0 | 34.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -143.6 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +5.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 13.7 |
| SECOND LOOK | 0.3 | +6.3 | 37.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.0 | -359.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 3.0 | +558.8 | 0.0 | 0.0 | 1.0 | +74.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +17.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 220.0 | 8.7 | +0.0 | 0.0 | 123.3 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +54.2 | 41.0 | 0.0 | 1.3 | +13.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.7 | 13.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 20.7 | -103.6 | 0.0 | 0.0 | 28.3 | -160.1 | 0.0 | 359.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +703.5 | 0.0 | 220.0 | 18.3 | +607.6 | 0.0 | 301.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +17.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +9.1 | 0.0 | 0.0 | 3.3 | +24.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +10.5 | 61.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 11.3 |
| STAND AND SHOOT | 0.3 | -2.5 | 100.3 | 0.0 | 0.3 | -2.6 | 0.0 | 34.0 |
| STANDS FOR A REASON | - | - | - | - | 8.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 44.3 | +0.0 | 720.7 | 440.0 | 30.0 | +0.0 | 770.0 | 288.3 |
| STAY WORTH | 30.7 | +209.4 | 434.3 | 660.0 | 22.3 | +151.3 | 440.0 | 185.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +71.6 | 0.0 | 0.0 | 6.3 | +288.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +71.6 | 0.0 | 0.0 | 6.3 | +288.3 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 13.7 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 53.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.7 | +0.0 | 0.0 | 220.0 | 39.7 | +0.0 | 0.0 | 402.3 |
| TIED UP BY THE SUM | 1.0 | +111.7 | 48.3 | 50.0 | - | - | - | - |
| TIME ON OUR SIDE | 30.7 | +466.6 | 11.3 | 0.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 78.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +78.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.7 | -17.6 | 0.0 | 0.0 | 2.7 | -231.7 | 0.0 | 41.7 |
| WHOLE FIGHT GAIN | 0.3 | +32.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.7 | +373.0 | 45.3 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +130.8 | 0.0 | 0.0 | 5.7 | +230.2 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 221 | 221 | 164 | 54.67 | +0 | +0.0 |
| ARMY TABLE | 122 | 122 | 93 | 31.00 | +3278 | +35.2 |
| HIS SHOT LIST | 244 | 226 | 56 | 18.67 | +1691 | +30.2 |
| HIS SHOTS BY HIS RUN | 260 | 243 | 50 | 16.67 | +1687 | +33.7 |
| HIS MOVE WHY | 88 | 88 | 49 | 16.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 50 | 50 | 44 | 14.67 | +4011 | +91.1 |
| HIS ONE MOVE | 111 | 110 | 35 | 11.67 | +0 | +0.0 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1080 | -32.7 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 23 | 23 | 23 | 7.67 | +156 | +6.8 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| SHOT RISK POINTS | 147 | 135 | 22 | 7.33 | +684 | +31.1 |
| FIVE ACTION | 486 | 466 | 20 | 6.67 | +1136 | +56.8 |
| GOAL WALK | 54 | 50 | 19 | 6.33 | +997 | +52.5 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CHARGE LOSSES | 110 | 101 | 14 | 4.67 | +997 | +71.2 |
| QUARTER ODDS | 92 | 91 | 13 | 4.33 | +868 | +66.8 |
| STAY WORTH | 159 | 145 | 11 | 3.67 | +110 | +10.0 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| MOVE TO CHARGE COMPUTED | 20 | 16 | 10 | 3.33 | +620 | +62.0 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 10 | 3.33 | -570 | -57.0 |
| SET UP BY THE SET | 12 | 11 | 9 | 3.00 | +1248 | +138.6 |
| CAST JOB | 12 | 12 | 8 | 2.67 | +94 | +11.8 |
| NEXT CHARGE BY LIST | 15 | 14 | 8 | 2.67 | +459 | +57.4 |
| COVER ONCE | 48 | 35 | 7 | 2.33 | +184 | +26.2 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 7 | 2.33 | +14 | +2.0 |
| SHOTS AFTER THE MOVES | 26 | 26 | 7 | 2.33 | +0 | +0.0 |
| SUPPORT ADDS | 25 | 24 | 7 | 2.33 | +218 | +31.1 |
| SUPPORT WORKED OUT | 25 | 24 | 7 | 2.33 | +218 | +31.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +564 | +93.9 |
| SHOTS IN THE MOVE | 97 | 76 | 6 | 2.00 | +254 | +42.3 |
| TIME ON OUR SIDE | 92 | 73 | 6 | 2.00 | +48 | +8.1 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 22 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +644 | +160.9 |
| FOUR ROUNDS | 13 | 12 | 4 | 1.33 | +340 | +85.0 |
| GUN MASK | 10 | 10 | 4 | 1.33 | +154 | +38.5 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HUNT IN PAIRS | 4 | 4 | 4 | 1.33 | +285 | +71.3 |
| IDLE COST | 42 | 30 | 4 | 1.33 | +45 | +11.2 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 32 | 32 | 4 | 1.33 | +63 | +15.7 |
| CASTING BLOCK | 11 | 11 | 3 | 1.00 | +10 | +3.5 |
| FALLS SHORT | 89 | 79 | 3 | 1.00 | +3 | +1.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +110 | +36.5 |
| MARCH CHECK | 7 | 7 | 3 | 1.00 | +100 | +33.4 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -14 | -4.6 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +25 | +8.4 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +51 | +25.3 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +99 | +49.4 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +182 | +91.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -518 | -258.8 |
| MAX FOR POSITIONING | 19 | 17 | 2 | 0.67 | +12 | +5.9 |
| ONE OBJECTIVE FORMULA | 27 | 23 | 2 | 0.67 | +44 | +21.9 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +32 | +16.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +8.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| CANNON PLANNED TARGET | 21 | 21 | 1 | 0.33 | -5 | -5.1 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 4 | 1 | 0.33 | +1 | +0.7 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +51 | +51.0 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -16 | -16.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +3 | +2.6 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +121 | +120.9 |
| HIS MOVE AND SHOT | 32 | 30 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 37 | 29 | 1 | 0.33 | +12 | +12.1 |
| MISSILES NEXT TURN | 48 | 31 | 1 | 0.33 | +0 | +0.2 |
| NO DOUBLE ROUNDS | 12 | 11 | 1 | 0.33 | +62 | +61.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +37 | +36.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +10 | +10.4 |
| PROMISE READS THE TABLE | 10 | 10 | 1 | 0.33 | +1 | +0.7 |
| REDIRECT COUNTER | 9 | 8 | 1 | 0.33 | +188 | +188.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| RISK BY ARC | 11 | 10 | 1 | 0.33 | +40 | +40.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +19 | +18.7 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +10 | +9.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +19 | +18.6 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -117 | -117.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +22 | +21.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +226 | +226.1 |
| WHOLE FIGHT DANGER | 10 | 10 | 1 | 0.33 | +114 | +114.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 16 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 4 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 71 | 71 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 4 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 39 | 38 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 20 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 214 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 71 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 23 | 0 | 0.00 | - | - |
| STANDS STILL | 223 | 216 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 229 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 1.67 | 23.3 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.00 | 57.0 |
| ARMY TABLE | rule | 1.67 | 1.33 | 80.1 |
| RULE SWITCHED OFF | gate | - | 2.67 | 33.5 |
| NO REASON | gate | 1.00 | - | 83.9 |
| PROMISE SHOT AWAY | rule | 0.67 | 0.33 | 4.6 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 3.8 |
| MARCH OF THE TABLE | rule | 0.67 | - | 258.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 72.1 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 5.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 16.3 |
| JOINT CHARGE NOW | rule | 0.33 | - | 2.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 117.1 |

### Plans: wfr-a92c160-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 75% | 428 | 290 | 68% |
| Mine | move | 20.7 | 100% | 1466 | 0 | 0% |
| Mine | shoot | 11.7 | 23% | 756 | 199 | 26% |
| Opponent | charge | 0.7 | 50% | 134 | 21 | 16% |
| Opponent | move | 28.0 | 94% | 1372 | 0 | 0% |
| Opponent | shoot | 7.0 | 52% | 526 | 298 | 57% |
| Opponent | support | 0.7 | 100% | 19 | 0 | 0% |

### Battle groups: wfr-a92c160-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 33% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 24 (12) | 24 | 0 | 0 | 17% | 2.7 | - | 32 (7) | 14 (5) | 32 (7) | 18 (5) |
| Mine | Fast Hammer | 4 | 12 (4) | 12 | 0 | 15 | 25% | 1.7 | 42 (2) | 0 (2) | - | 19 (3) | 0 (1) |
| Mine | Holder | 5 | 55 (5) | 0 | 55 | 0 | 40% | 4.0 | - | 90 (3) | 0 (2) | 42 (4) | 107 (1) |
| Mine | Shooter | 2 | 694 (2) | 173 | 521 | 0 | 0% | 1.0 | 322 (1) | 1066 (1) | - | 694 (2) | - |
| Mine | War machine | 6 | 19 (6) | 19 | 0 | 33 | 0% | 1.5 | 0 (2) | 0 (2) | 56 (2) | 0 (1) | 22 (5) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 41 | 17% | 3.6 | 0 (5) | 0 (1) | - | 0 (5) | 0 (1) |
| Opponent | Character | 7 | 8 (7) | 8 | 0 | 0 | 29% | 2.6 | 72 (1) | 0 (6) | - | 11 (6) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 32 | 0% | 1.7 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 0 | 11 | 0 | 25% | 2.3 | - | 12 (3) | 0 (1) | 12 (3) | 0 (1) |
| Opponent | Hammer | 8 | 34 (8) | 21 | 13 | 67 | 25% | 2.0 | 45 (2) | 36 (2) | 25 (4) | 53 (5) | 0 (3) |
| Opponent | Holder | 1 | 108 (1) | 0 | 108 | 100 | 0% | 1.0 | - | 108 (1) | - | 108 (1) | - |
| Opponent | Shooter | 2 | 36 (2) | 0 | 36 | 0 | 0% | 1.5 | 64 (1) | 0 (1) | - | 36 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: wfr-a92c160-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 151 | 112 | 1.7 | 1.2 | 67 | 0 | +67 | 2 of 5 | 4 of 5 | +0 | +84 |
| Opponent | Ogre Kingdoms | 1 | 330 | 0 | 3.0 | 1.0 | 0 | 112 | -112 | 2 of 3 | 0 of 3 | - | -112 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 34 | -34 | 2 of 3 | 0 of 3 | - | -34 |
| **Opponent** | all armies | 3 | 110 | 0 | 2.0 | 1.0 | 0 | 73 | -73 | 4 of 6 | 0 of 6 | - | -73 |

### Effective charges: wfr-a92c160-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 0 | 0 | 1 (net +185) | 1 (net +0) | 1 (net +41) | 1 (net +0) | 1 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 3 | 3 (net -34) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 369 | 185 | +185 | 185 | 158 | +27 | +7.3 |
| Mine | 76-89% | 1 | 713 | 357 | +0 | 325 | 102 | +223 | +31.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 233 | 251 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 205 | 41 | +41 | 41 | 0 | +41 | +20.0 |
| Mine | No odds | 1 | 379 | 111 | +111 | 111 | 0 | +111 | +29.3 |
| Mine | All fights | 5 | 380 | 189 | +67 | 132 | 52 | +80 | +21.1 |
| Opponent | Long shot (under 50%) | 3 | 102 | 229 | -34 | 103 | 116 | -13 | -12.5 |
| Opponent | No odds | 3 | 71 | 212 | -112 | 0 | 112 | -112 | -156.5 |
| Opponent | All fights | 6 | 87 | 221 | -73 | 52 | 114 | -62 | -71.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p43 | move | 16 | 1 (6%) | 1 (6%) | 1 (6%) | 14 (88%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

# Doctrine scorecard: wfr-a92c160-p9

### Scorecard: wfr-a92c160-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 4.0 | 2.0 | 2.0 | 1.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 3.0 | 4.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: wfr-a92c160-p9

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 0% (0 of 10) | 0% (0 of 20) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | - | 100% (5 of 5); on the table 100% | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 56% (9 of 16) | 56% (9 of 16) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 56% (9 of 16) | 56% (9 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 47% (942 of 2000) | 56% (1123 of 2000) | 52% (2065 of 4000) |
|   infantry points that never fought | lower | 0% (0 of 302) | 100% (174 of 174) | 37% (174 of 476) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (4 of 7) | 50% (3 of 6) | 54% (7 of 13) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (1118 of 1940) | 33% (509 of 1546) | 47% (1627 of 3486) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.3 (100%) | 2.3 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 1.7 | 0.7 | 3.0 | 0.0 | 2.0 |
| not cast | 5.7 | 1.7 | 1.3 | 2.3 | 1.3 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 2.3 (100%) | 1.3 (100%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (100%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 26% (6 of 23) | - | 26% (6 of 23) |
|   character | 20% (2 of 10) | - | 20% (2 of 10) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 29% (2 of 7) | - | 29% (2 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (59%) | - | 3.3 (59%) |
| CHARGED: it charged | 1.3 (24%) | - | 1.3 (24%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | - | 0.7 (12%) |
| NO TARGET IN RANGE | 0.3 (6%) | - | 0.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 1.3 | 1.7 | 75% | 9.4 pts | 12 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.7 | 3.0 |
| Charges that made contact a game | 1.7 | 3.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 1.00 contact (3 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.28 declared, 0.20 contact (25 units) | 0.33 declared, 0.29 contact (24 units) | 0.31 declared, 0.24 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | - | 50% (1 of 2) | 40% (2 of 5) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | - | - | 33% (1 of 3) | 33% (1 of 3) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | - | - | 47% | 57% (4 of 7) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (5 of 5); on the table 100% | 58% (7 of 12) | 56% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 25% (1) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: wfr-a92c160-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 20% (1 of 5) | 56% (5 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (1 of 7) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 3) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 4.0 |
| Movement | Points that never moved of their own | 0.0 | 0.0 |
| Movement | Fights charged into per game | 2.0 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 1 of 3, net -50 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net +75 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 3, net +375 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (4 of 8) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (3 of 6) |
| Magic | Wounds caused by magic missiles | 0.7 | 0.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.0 / 0.0 | 1.3 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 56.7 | 66.3 |
| Combat | Points run down | 0.0 | 100.7 |
| Combat | Net points per charged fight, damage counted | +30 | +113 |
| Combat | Net per 100 charger points, damage counted | +5.8 | +36.7 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +60 | +113 |
| Combat | Net points per supported fight / lone fight | +75 / +45 | +375 / +25 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 1 of 4 |
| Game | Points lost | 561.0 | 170.0 |
| Game | VP from objectives | 460.0 | 960.0 |
| Game | Lone holders (player turns) | 4.0 | 0.0 |

- Mine won / drew / lost: 0 / 0 / 1 of 1 ended games (of 3); mean margin (Mine - Opponent) -891 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 731
- Games not ended: 2 (L1625-1, L1723-1); findings 3, warnings 0

### Opponent rules: wfr-a92c160-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +222.0 | 0.0 | 140.7 | 14.0 | +491.3 | 0.0 | 33.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 1.3 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +2.2 | 0.0 | 0.0 | 1.3 | +7.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +107.6 | 0.0 | 65.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +39.6 | 0.0 | 58.7 | - | - | - | - |
| CHARGE LOSSES | 12.0 | -197.3 | 0.0 | 142.7 | 7.3 | -194.6 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 66.7 | 0.0 | 1.7 | +0.0 | 167.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.3 | -407.2 | 0.0 | 78.7 | 4.7 | -357.6 | 0.0 | 16.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -8.1 | 58.7 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -0.9 | 58.7 | 0.0 |
| EXACT ROUND | 2.3 | +10.2 | 81.7 | 0.0 | 2.7 | -12.5 | 42.0 | 16.7 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 65.0 | 0.0 | 2.7 | +2.8 | 167.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.0 | +212.8 | 0.0 | 0.0 |
| FEATURE BUFFS | 1.7 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +3.2 | 25.0 | 0.0 | 1.3 | -4.6 | 66.3 | 0.0 |
| FIVE ACTION | 52.3 | +2783.4 | 81.7 | 414.0 | 61.0 | +3342.9 | 233.3 | 50.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 207.0 | 4.3 | +0.0 | 0.0 | 16.7 |
| FOLLOW UP WEIGHED | 0.7 | +146.1 | 0.0 | 0.0 | 0.7 | +87.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +119.0 | 81.7 | 0.0 | 3.7 | +146.5 | 233.3 | 16.7 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 172.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -9.4 | 15.0 | 0.0 | 0.3 | -1.2 | 0.0 | 0.0 |
| GOAL WALK | 10.0 | +805.1 | 0.0 | 0.0 | 4.3 | +387.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 172.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 142.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 33.3 |
| HIS LEGAL MOVES | 7.7 | +0.0 | 0.0 | 211.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -16.4 | 0.0 | 0.0 | 2.7 | -69.7 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 30.0 | +8.0 | 88.3 | 0.0 | 22.7 | +4.0 | 207.0 | 0.0 |
| HIS MOVE WHY | 10.7 | +0.0 | 0.0 | 106.3 | 16.3 | +0.0 | 0.0 | 0.0 |
| HIS ONE MOVE | 17.3 | +90.5 | 0.0 | 0.0 | 19.3 | -24.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 86.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.7 | +83.1 | 0.0 | 138.7 | 31.0 | +678.5 | 0.0 | 33.3 |
| HIS SHOTS BY HIS RUN | 12.0 | +51.6 | 0.0 | 330.0 | 26.0 | +533.9 | 0.0 | 0.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +16.2 | 58.7 | 0.0 |
| HIS TURN RUN | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 7.7 | +0.0 | 0.0 | 334.0 | 11.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 5.3 | +441.3 | 0.0 | 167.0 | 8.0 | +619.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -112.2 | 81.7 | 0.0 | 3.0 | -101.5 | 233.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +29.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 14.7 | -180.2 | 0.0 | 16.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +47.7 | 132.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.0 | +0.0 | 30.0 | 225.7 | 4.7 | +0.0 | 174.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +9.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +1.7 | 66.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -104.7 | 0.0 | 80.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +31.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +22.1 | 0.0 | 66.3 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +401.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +5.2 | 0.0 | 0.0 | 2.3 | +41.1 | 0.0 | 25.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +42.3 | 0.0 | 66.3 | 2.7 | +16.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +44.8 | 0.0 | 66.3 | 4.7 | +15.8 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +423.5 | 0.0 | 0.0 | 8.3 | +885.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +233.4 | 0.0 | 167.0 | 6.7 | +216.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +177.0 | 0.0 | 0.0 | 6.0 | +590.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -29.3 | 66.7 | 0.0 | 3.0 | -156.2 | 167.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -121.0 | 15.0 | 0.0 | 3.7 | -111.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -61.8 | 0.0 | 0.0 | 5.7 | -85.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.0 | -11.0 | 0.0 | 108.3 | 3.0 | +27.5 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +39.8 | 40.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.3 | 0.0 | 0.0 | 1.3 | +12.8 | 167.0 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.3 | +35.6 | 0.0 | 0.0 |
| PLAN RESULT | 21.7 | +106.7 | 0.0 | 374.0 | 29.7 | +207.7 | 299.7 | 88.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -163.6 | 0.0 | 0.0 | 7.0 | -159.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -38.4 | 0.0 | 0.0 |
| QUARTER ODDS | 4.0 | +661.7 | 16.7 | 0.0 | 9.0 | +1290.3 | 0.0 | 16.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +62.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +34.9 | 0.0 | 0.0 | 3.7 | +475.8 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 40.0 |
| REFORMS TO MEET IT | 1.7 | -35.6 | 0.0 | 0.0 | 1.0 | -16.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 66.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +124.9 | 81.7 | 0.0 | 3.0 | +57.9 | 233.3 | 16.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -9.4 | 191.3 | 0.0 |
| RUN DOWN | - | - | - | - | 2.7 | -18.9 | 167.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | -4.8 | 0.0 | 0.0 | 1.7 | +37.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +21.4 | 15.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +19.6 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -96.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | -105.2 | 25.0 | 0.0 | 5.0 | +330.8 | 58.7 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 40.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +1.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 14.0 | -54.5 | 0.0 | 138.7 | 20.7 | -128.6 | 0.0 | 33.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.0 | +128.8 | 0.0 | 58.7 | 3.0 | +9.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.3 | +0.0 | 0.0 | 58.7 | 7.3 | +0.0 | 0.0 | 16.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -5.8 | 58.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 11.3 | +0.0 | 0.0 | 80.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 4.7 | +3.5 | 0.0 | 0.0 | 3.0 | +5.4 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 25.0 |
| STUPIDITY NEXT TURN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +156.3 | 0.0 | 0.0 | 3.0 | +136.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 25.0 | 0.0 | 0.3 | +0.0 | 0.0 | 15.0 |
| SUPPORT WORKED OUT | 1.0 | +156.3 | 0.0 | 0.0 | 3.0 | +136.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -13.0 | 0.0 | 0.0 | 0.3 | -51.2 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 42.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 58.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 42.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 23.0 | +0.0 | 0.0 | 207.0 | 32.7 | +0.0 | 0.0 | 56.7 |
| TIED UP BY THE SUM | 2.0 | +236.7 | 56.7 | 0.0 | 1.0 | +194.7 | 125.0 | 0.0 |
| TIME ON OUR SIDE | 26.3 | +401.3 | 0.0 | 287.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 50.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -36.1 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +16.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -146.8 | 0.0 | 84.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +18.0 | 66.3 | 0.0 |
| WOUNDS ON THE RANKS | 1.7 | +2.7 | 0.0 | 0.0 | 2.0 | +36.1 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 158 | 158 | 122 | 40.67 | +0 | +0.0 |
| HIS MOVE WHY | 81 | 81 | 59 | 19.67 | +0 | +0.0 |
| ARMY TABLE | 77 | 77 | 55 | 18.33 | +2284 | +41.5 |
| HOLDER ASSIGNMENT | 40 | 40 | 36 | 12.00 | +2319 | +64.4 |
| LEGAL CHARGES ONLY | 32 | 32 | 32 | 10.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| FIVE ACTION | 340 | 331 | 24 | 8.00 | +1057 | +44.0 |
| HIS ONE MOVE | 110 | 110 | 24 | 8.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 46 | 46 | 24 | 8.00 | +1094 | +45.6 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -697 | -31.7 |
| HIS SHOT LIST | 140 | 137 | 21 | 7.00 | +160 | +7.6 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| THE TABLE AGAIN | 23 | 23 | 19 | 6.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 114 | 113 | 15 | 5.00 | +53 | +3.5 |
| THE RISK READS HIS RUN | 23 | 23 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 43 | 43 | 14 | 4.67 | +729 | +52.1 |
| NEXT CHARGE BY LIST | 27 | 27 | 14 | 4.67 | +1072 | +76.6 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 14 | 4.67 | -969 | -69.2 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 19 | 16 | 10 | 3.33 | +201 | +20.1 |
| QUARTER ODDS | 39 | 38 | 10 | 3.33 | +1163 | +116.3 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| SET UP BY THE SET | 20 | 20 | 8 | 2.67 | +432 | +54.0 |
| TIED UP BY THE SUM | 9 | 7 | 7 | 2.33 | +185 | +26.4 |
| CHAFF IN THE MOVE | 8 | 8 | 6 | 2.00 | +41 | +6.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 58 | 58 | 5 | 1.67 | +854 | +170.7 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +143 | +28.6 |
| RISK BY ARC | 17 | 15 | 5 | 1.67 | +65 | +13.0 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +111 | +22.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 45 | 27 | 4 | 1.33 | +23 | +5.8 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +701 | +175.3 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +107 | +26.7 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| SUPPORT ADDS | 12 | 11 | 4 | 1.33 | +141 | +35.2 |
| SUPPORT WORKED OUT | 12 | 11 | 4 | 1.33 | +141 | +35.2 |
| CAST JOB | 5 | 5 | 3 | 1.00 | +3 | +1.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +119 | +39.5 |
| CHARGE NOW FIRST | 10 | 10 | 3 | 1.00 | -178 | -59.2 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 44 | 34 | 3 | 1.00 | +48 | +16.1 |
| MAX FOR POSITIONING | 10 | 10 | 3 | 1.00 | +1 | +0.3 |
| MISSILES IN THE MOVE | 14 | 12 | 3 | 1.00 | +84 | +28.1 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +14 | +4.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +70 | +23.4 |
| SHOT RISK POINTS | 104 | 103 | 3 | 1.00 | +66 | +21.9 |
| TIME ON OUR SIDE | 79 | 62 | 3 | 1.00 | +10 | +3.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 4 | 2 | 0.67 | +5 | +2.4 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +99 | +49.7 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 2 | 0.67 | +41 | +20.7 |
| REDIRECT COUNTER | 15 | 15 | 2 | 0.67 | +226 | +113.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| CANNON PLANNED TARGET | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -24 | -24.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 15 | 12 | 1 | 0.33 | +1 | +1.4 |
| FALLS SHORT | 57 | 46 | 1 | 0.33 | +42 | +42.5 |
| HARD STAY DROPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +52 | +51.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 16 | 14 | 1 | 0.33 | +24 | +24.3 |
| ONE FIGHT FORMULA | 29 | 21 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +24 | +24.2 |
| OPENS UP | 2 | 1 | 1 | 0.33 | +1 | +1.4 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +0 | +0.3 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -113.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -21 | -20.8 |
| STAY WORTH | 23 | 20 | 1 | 0.33 | +9 | +9.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -23 | -22.7 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 6 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| WHOLE FIGHT DANGER | 5 | 5 | 1 | 0.33 | +248 | +247.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +1 | +0.8 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 61 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 40 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 46 | 46 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 45 | 43 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 23 | 23 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 23 | 23 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 24 | 24 | 0 | 0.00 | - | - |
| HOLD ODDS | 57 | 57 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 14 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 16 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 42 | 39 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 15 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 154 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 14 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 5 | 5 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 27 | 22 | 0 | 0.00 | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 65 | 63 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 167 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 3.33 | 27.1 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 1.33 | 69.2 |
| ARMY TABLE | rule | 0.67 | 0.67 | 15.7 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 59.2 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 3.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 62.9 |
| SET UP BY THE SET | rule | 0.67 | 0.33 | 9.5 |
| JOINT CHARGE NOW | rule | - | 0.67 | 24.3 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 24.2 |
| NO REASON | gate | - | 0.33 | 19.8 |
| OWN CAST FIRST | rule | - | 0.33 | 1.7 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 113.0 |
| REFUSING RETIRES | rule | - | 0.33 | 20.8 |
| SUPPORT NARROWED | rule | - | 0.33 | 22.7 |

### Plans: wfr-a92c160-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 100% | 168 | 107 | 64% |
| Mine | move | 18.7 | 96% | 1057 | 0 | 0% |
| Mine | shoot | 1.3 | 0% | 25 | 0 | 0% |
| Opponent | charge | 3.0 | 56% | 193 | 208 | 108% |
| Opponent | join | 3.3 | 100% | 135 | 0 | 0% |
| Opponent | move | 20.7 | 98% | 1079 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 12 | 0 | 0% |
| Opponent | support | 2.0 | 67% | 72 | 0 | 0% |

### Battle groups: wfr-a92c160-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.7 | 9% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 2 | 19 (2) | 19 | 0 | 0 | 0% | 1.0 | - | 19 (2) | - | 0 (1) | 34 (1) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 32 (3) | 0 | 32 | 27 | 33% | 1.5 | - | 32 (3) | - | 121 (1) | 0 (2) |
| Mine | Shooter | 2 | 40 (2) | 0 | 40 | 100 | 0% | 2.5 | 95 (1) | 0 (1) | - | 95 (1) | 0 (1) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 50 | 50% | 3.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Character | 4 | 53 (4) | 53 | 0 | 7 | 25% | 4.0 | 0 (1) | 72 (2) | 0 (1) | 80 (1) | 0 (3) |
| Opponent | Fast Hammer | 3 | 45 (3) | 17 | 28 | 0 | 67% | 2.0 | 55 (1) | - | 34 (2) | - | 45 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 2 | 24 (2) | 24 | 0 | 0 | 0% | 2.5 | 0 (1) | 100 (1) | - | 0 (1) | 100 (1) |

### Charged fights: wfr-a92c160-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 120 | 2.0 | 1.5 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | +75 | +45 |
| Opponent | Vampire Counts | 1 | 60 | 501 | 4.0 | 1.2 | 125 | 12 | +113 | 1 of 4 | 2 of 4 | +375 | +25 |

### Effective charges: wfr-a92c160-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 0 | 0 | 1 (net +75) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Vampire Counts | 4 | 1 (net -50) | 0 | 0 | 1 (net +126) | 0 | 1 (net +375) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 557 | 75 | +75 | 84 | 68 | +16 | +2.9 |
| Mine | No odds | 1 | 497 | 45 | +45 | 45 | 0 | +45 | +9.1 |
| Mine | All fights | 2 | 527 | 60 | +60 | 64 | 34 | +30 | +5.8 |
| Opponent | Long shot (under 50%) | 1 | 50 | 497 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | 76-89% | 1 | 186 | 126 | +126 | 126 | 0 | +126 | +67.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 521 | 199 | +375 | 375 | 0 | +375 | +72.0 |
| Opponent | No odds | 1 | 471 | 176 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 4 | 307 | 250 | +113 | 125 | 12 | +113 | +36.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p9 | move | 20 | 3 (15%) | 3 (15%) | 5 (25%) | 12 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

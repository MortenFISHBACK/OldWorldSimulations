# Doctrine scorecard: wfr-a92c160-p36

### Scorecard: wfr-a92c160-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 340 |
| L2730 | 6 | 1 | Mine | no | 1 | 2 | 9 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 1 | 4 | 2 | 3 | 0 | 0 | 0 | 200 |
| **Average** | | | Mine | 33% | 0.5 | 2.3 | 4.0 | 2.7 | 0.0 | 0.0 | 0.0 | 127.0 |
| **Average** | | | Opponent | 33% | 2.5 | 3.0 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 180.0 |

### KPIs: wfr-a92c160-p36

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 17) | 0% (0 of 34) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (3 of 4); on the table 75% | - | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 60% | - | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 70% | 100% (2 of 2); on the table 100% | 75% (9 of 12); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 100% (6 of 6) | 50% (3 of 6) | 75% (9 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (6 of 6) | 50% (3 of 6) | 75% (9 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 71% (5 of 7) | 69% (9 of 13) |
| Points that never fought | lower | 47% (2807 of 5998) | 36% (2165 of 5998) | 41% (4972 of 11996) |
|   infantry points that never fought | lower | 48% (432 of 902) | 46% (498 of 1072) | 47% (930 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 73% (19 of 26) | 67% (30 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2396 of 5038) | 69% (3709 of 5360) | 59% (6105 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.3 (33%) | 0.3 (33%) |
| MARCHED: its unit marched | - | 0.7 (67%) | 0.7 (67%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.3 | 2.7 | 3.0 | 0.3 | 0.7 |
| not cast | 2.7 | 0.0 | 1.3 | 1.0 | 1.7 | 23.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (12%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (88%) | - | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.3 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 50% (4 of 8) | - | 50% (4 of 8) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | - | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 33% (2 of 6) | 70% (26 of 37) | 65% (28 of 43) |
|   cavalry | 67% (2 of 3) | 83% (10 of 12) | 80% (12 of 15) |
|   character | 0% (0 of 3) | 54% (7 of 13) | 44% (7 of 16) |
|   infantry | - | 75% (9 of 12) | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.7 (45%) | 1.7 (33%) |
| CHARGED: it charged | 0.3 (25%) | 1.3 (36%) | 1.7 (33%) |
| IN COMBAT: it fought this turn or the last | 0.3 (25%) | 0.0 (0%) | 0.3 (7%) |
| NO TARGET IN RANGE | 0.7 (50%) | 0.3 (9%) | 1.0 (20%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (9%) | 0.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 0.3 | 96% | 0.3 pts | 2 pts |
| character | 2.3 | 0.3 | 86% | 7.8 pts | 18 pts |
| infantry | 5.0 | 0.7 | 87% | 4.3 pts | 21 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 4.0 | 5.0 |
| Charges that made contact a game | 5.0 | 2.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.33 declared, 2.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.75 declared, 1.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.38 contact (24 units) | 0.46 declared, 0.31 contact (26 units) | 0.46 declared, 0.34 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (5 of 5) | 0% (0 of 1) | 69% (9 of 13) |
| Character in a unit | 100% (4 of 4) | - | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 33% (1 of 3) | 100% (3 of 3) | 29% (2 of 7) | 46% (6 of 13) |
| Infantry | 57% (4 of 7) | 0% (0 of 1) | - | 50% (4 of 8) |
| Monster | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 86% (6 of 7); on the table 86% | 100% (6 of 6) | 52% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 60% (3 of 5); on the table 60% | 50% (3 of 6) | 38% | 72% (18 of 25) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 29% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (5) | 43% (6) | 58% (11) |
| ...free all their last turn and able to turn (per game) | 1.33 | 2.00 | 3.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 2.00 | 3.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.33 | 0.00 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (12 of 18) | 67% (8 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 67% (4 of 6) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 100% (8 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 127.0 | 180.0 |
| Movement | Fights charged into per game | 4.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 14, net +146 | 2 of 8, net -14 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 14, net +142 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 14, net +46 | 1 of 8, net +45 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 14, net +110 | 5 of 8, net +130 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 61% (19 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.7 / 0.3 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 328.0 | 163.7 |
| Combat | Points run down | 152.7 | 68.3 |
| Combat | Net points per charged fight, damage counted | +112 | +35 |
| Combat | Net per 100 charger points, damage counted | +33.1 | +14.0 |
| Combat | First round won (charged fights) | 86% | 75% |
| Combat | Net points per charged fight | +108 | +84 |
| Combat | Net points per supported fight / lone fight | +170 / +103 | - / +84 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 14 | 2 of 8 |
| Game | Points lost | 242.0 | 549.0 |
| Game | VP from objectives | 646.7 | 373.3 |
| Game | Lone holders (player turns) | 0.5 | 2.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +647 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 791
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | -12.8 | 0.0 | 262.0 | 23.0 | -90.5 | 0.0 | 140.3 |
| ASSAILMENT BY POINTS | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +2.1 | 0.0 | 0.0 | 0.7 | +10.9 | 30.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 3.3 | +57.6 | 0.0 | 15.0 | 0.3 | +12.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | -0.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.3 | +34.5 | 0.0 | 153.0 | 0.3 | +3.5 | 0.0 | 38.7 |
| CHARGE LIST READ AGAIN | 0.3 | +27.4 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 15.3 | -355.1 | 0.0 | 423.3 | 6.0 | -183.6 | 0.0 | 65.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 32.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 4.3 | +0.0 | 403.3 | 0.0 | 1.7 | +0.0 | 182.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 20.7 | +0.0 | 0.0 | 226.7 | 13.0 | +0.0 | 0.0 | 112.0 |
| CONVEYANCE SEARCH | 2.7 | +46.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.3 | -788.0 | 0.0 | 133.7 | 10.0 | -577.0 | 0.0 | 69.0 |
| DENIED BY THE FIGHT | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| EXACT ROUND | 4.7 | -12.8 | 341.7 | 0.0 | 2.3 | +18.2 | 143.0 | 0.0 |
| FALL BACK GOOD ORDER | 5.3 | +9.9 | 397.0 | 0.0 | 3.0 | +0.0 | 196.3 | 0.0 |
| FALLS SHORT | 22.3 | +350.2 | 0.0 | 153.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 2.0 | +24.4 | 0.0 | 46.7 |
| FIGHT TO THE END | 2.7 | +87.8 | 209.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 88.0 | +4275.2 | 460.0 | 630.7 | 92.0 | +5399.7 | 326.0 | 894.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 153.0 | 10.0 | +0.0 | 0.0 | 150.0 |
| FOLLOW UP WEIGHED | 0.3 | +18.0 | 0.0 | 0.0 | 1.3 | +191.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.3 | +491.0 | 460.0 | 0.0 | 4.0 | +227.9 | 296.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 2.7 | +0.0 | 0.0 | 9.0 |
| GOAL WALK | 7.3 | +533.7 | 0.0 | 0.0 | 13.3 | +1063.4 | 0.0 | 276.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 30.3 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 423.3 | 5.3 | +0.0 | 0.0 | 65.3 |
| HIS CHARGE DENIED | 0.3 | +9.7 | 0.0 | 0.0 | 0.3 | +9.6 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 30.0 | 13.3 | +0.0 | 0.0 | 194.7 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -46.7 | 0.0 | 169.3 | 0.7 | -6.5 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 43.7 | +10.7 | 371.3 | 0.0 | 47.3 | +12.3 | 315.3 | 0.0 |
| HIS MOVE WHY | 28.3 | +0.0 | 0.0 | 98.3 | 9.7 | +0.0 | 0.0 | 228.3 |
| HIS ONE MOVE | 20.7 | -173.4 | 0.0 | 169.3 | 23.0 | +18.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 45.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.3 | +0.0 | 0.0 | 327.3 | 19.0 | +0.0 | 0.0 | 60.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 45.7 | +641.8 | 0.0 | 486.0 | 13.3 | +165.7 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 41.7 | +363.8 | 0.0 | 521.7 | 9.0 | +158.3 | 0.0 | 117.3 |
| HIS TURN DENIED | 0.3 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.3 | +0.0 | 0.0 | 0.0 | 18.3 | +0.0 | 0.0 | 339.3 |
| HOLDER ASSIGNMENT | 11.7 | +1167.2 | 0.0 | 0.0 | 10.3 | +1156.3 | 0.0 | 146.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.3 | -218.4 | 460.0 | 0.0 | 3.3 | -68.1 | 247.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +24.2 | 0.0 | 0.0 |
| IDLE COST | 20.3 | -298.2 | 0.0 | 132.3 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +0.1 | 113.3 | 0.0 | 1.3 | -14.6 | 30.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 65.3 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 9.0 | 387.7 | 7.0 | +0.0 | 0.0 | 152.7 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.7 | +13.2 | 208.7 | 0.0 | 1.3 | +2.6 | 68.3 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 15.0 | - | - | - | - |
| MANOEUVRE | 3.0 | +52.8 | 0.0 | 68.3 | - | - | - | - |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +23.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +17.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.3 | +170.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| MAX FOR POSITIONING | 2.3 | +119.5 | 0.0 | 15.0 | 3.3 | +118.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +6.0 | 0.0 | 0.0 | 1.7 | +41.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +2.8 | 0.0 | 0.0 | 3.0 | +49.0 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 15.0 | 0.0 | 1.3 | +0.0 | 0.0 | 69.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +496.7 | 0.0 | 169.3 | 7.3 | +534.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.7 | +364.4 | 0.0 | 84.7 | 7.3 | +345.6 | 0.0 | 81.0 |
| NEXT CHARGE BY LIST | 3.7 | +241.6 | 0.0 | 169.3 | 5.3 | +424.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 5.7 | -273.0 | 460.0 | 0.0 | 2.3 | -78.4 | 202.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 65.3 |
| NOT WORTH A CAST | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -118.9 | 0.0 | 0.0 | 5.0 | -228.0 | 0.0 | 57.7 |
| ONE CHALLENGE TEST | 0.3 | +1.0 | 30.3 | 0.0 | 0.3 | +1.4 | 84.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -86.6 | 0.0 | 15.0 | 4.0 | -81.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +4.3 | 151.7 | 0.0 | 0.3 | +30.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.0 | -46.9 | 0.0 | 0.0 | 4.7 | +43.4 | 0.0 | 113.7 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| OPENS UP | 0.7 | +22.5 | 53.7 | 0.0 | 0.3 | +23.0 | 15.0 | 0.0 |
| OVERRUNS AWAY | 2.3 | +32.2 | 215.7 | 0.0 | 0.3 | +1.9 | 49.0 | 0.0 |
| PATHS CROSS | 1.3 | +8.0 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -17.5 | 0.0 | 0.0 |
| PLAN RESULT | 47.0 | +533.4 | 271.0 | 459.0 | 44.0 | +220.4 | 306.7 | 699.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -225.9 | 0.0 | 0.0 | 13.3 | -570.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 10.0 | +685.1 | 0.0 | 60.0 | 8.7 | +1249.8 | 60.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +69.5 | 0.0 | 0.0 | 2.3 | +2.5 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +52.4 | 0.0 | 0.0 | 1.3 | +37.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +146.1 | 0.0 | 30.0 | 3.7 | +146.3 | 0.0 | 32.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +73.1 | 0.0 | 45.0 | 4.0 | +66.5 | 0.0 | 32.3 |
| REFORMS TO MEET IT | 1.7 | -29.8 | 0.0 | 0.0 | 2.7 | -283.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 30.3 |
| RISK BY ARC | 5.0 | +39.1 | 436.7 | 0.0 | 2.3 | +127.4 | 197.7 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -23.1 | 56.0 | 0.0 | 0.3 | -14.3 | 0.0 | 0.0 |
| RUN DOWN | 5.0 | -32.4 | 346.7 | 0.0 | 1.7 | -8.2 | 68.3 | 0.0 |
| SAFER THAN THE JOB | 0.3 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 2.3 | -122.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +31.8 | 0.0 | 0.0 | 0.7 | +26.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -25.1 | 0.0 | 15.0 | 2.3 | -26.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +26.2 | 56.7 | 15.0 | 2.7 | +28.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.3 | 0.0 | 15.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.7 | +90.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +11.6 | 0.0 | 0.0 | 0.7 | +3.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -4.7 | 15.0 | 0.0 |
| SHOT RISK POINTS | 20.3 | -114.5 | 0.0 | 267.7 | 7.3 | +24.3 | 0.0 | 60.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.3 | +38.8 | 0.0 | 0.0 | 9.0 | +120.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +90.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.0 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 1.0 | +2.4 | 95.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.7 | +0.0 | 0.0 | 212.0 | 8.7 | +0.0 | 0.0 | 63.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 16.0 | +0.0 | 0.0 | 0.0 | 39.3 | +0.0 | 30.0 | 345.7 |
| STAY WORTH | 1.0 | +5.7 | 0.0 | 0.0 | 9.3 | +30.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 6.0 | +776.7 | 0.0 | 68.3 | 5.7 | +599.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 182.7 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +776.7 | 0.0 | 68.3 | 5.7 | +599.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | 0.7 | +21.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +3.9 | 0.0 | 65.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 15.0 | 3.3 | +0.0 | 0.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 68.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 2.0 | +0.0 | 0.0 | 68.3 | 2.0 | +0.0 | 0.0 | 125.3 |
| THE STEP BACK IS MADE | 4.3 | +0.0 | 0.0 | 68.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 266.3 | 42.7 | +0.0 | 0.0 | 418.7 |
| TIED UP BY THE SUM | 2.7 | +384.0 | 269.7 | 0.0 | 1.3 | +123.5 | 113.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 67.7 | +646.4 | 0.0 | 665.3 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | +24.7 | 95.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | +1.3 | 56.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +162.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -180.4 | 0.0 | 185.7 | 3.3 | -167.5 | 0.0 | 65.3 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 56.7 | 0.0 | 0.3 | +36.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.0 | +67.3 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +26.8 | 0.0 | 0.0 | 0.3 | +2.6 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 273 | 273 | 204 | 68.00 | +0 | +0.0 |
| ARMY TABLE | 132 | 132 | 101 | 33.67 | -93 | -0.9 |
| HIS MOVE WHY | 114 | 114 | 71 | 23.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 66 | 66 | 61 | 20.33 | +4151 | +68.1 |
| LEGAL CHARGES ONLY | 37 | 37 | 37 | 12.33 | +0 | +0.0 |
| HIS ONE MOVE | 131 | 125 | 35 | 11.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 34 | 11.33 | +0 | +0.0 |
| FIVE ACTION | 540 | 512 | 32 | 10.67 | +1786 | +55.8 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -1040 | -32.5 |
| TIME ON OUR SIDE | 203 | 167 | 31 | 10.33 | +48 | +1.6 |
| PROMISE BY ITS OWN SUM | 68 | 68 | 28 | 9.33 | -2388 | -85.3 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| HIS SHOT LIST | 177 | 163 | 24 | 8.00 | +266 | +11.1 |
| HIS SHOTS BY HIS RUN | 152 | 139 | 22 | 7.33 | +84 | +3.8 |
| THE RISK READS HIS RUN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| GOAL WALK | 62 | 59 | 19 | 6.33 | +1088 | +57.2 |
| MOVE TO CHARGE COMPUTED | 43 | 32 | 19 | 6.33 | +686 | +36.1 |
| FOUR ROUNDS | 31 | 31 | 18 | 6.00 | +666 | +37.0 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 18 | 6.00 | +301 | +16.7 |
| COVER ONCE | 58 | 44 | 14 | 4.67 | +124 | +8.8 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 27 | 21 | 12 | 4.00 | +433 | +36.1 |
| QUARTER ODDS | 56 | 52 | 12 | 4.00 | +905 | +75.4 |
| TIED UP BY THE SUM | 12 | 12 | 11 | 3.67 | +300 | +27.2 |
| FALLS SHORT | 67 | 57 | 9 | 3.00 | +3 | +0.3 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 9 | 3.00 | +216 | +24.0 |
| SHOT RISK POINTS | 83 | 74 | 9 | 3.00 | +131 | +14.6 |
| CHARGE NOW FIRST | 18 | 18 | 8 | 2.67 | -352 | -44.0 |
| RISK BY ARC | 22 | 22 | 8 | 2.67 | +319 | +39.8 |
| IDLE COST | 61 | 37 | 7 | 2.33 | +49 | +7.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | -44 | -7.3 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +114 | +22.8 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +629 | +125.7 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| MAX FOR POSITIONING | 17 | 14 | 5 | 1.67 | +21 | +4.1 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +17 | +3.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 11 | 9 | 4 | 1.33 | +0 | +0.0 |
| SUPPORT ADDS | 35 | 34 | 4 | 1.33 | +8 | +2.0 |
| SUPPORT WORKED OUT | 35 | 34 | 4 | 1.33 | +8 | +2.0 |
| CAST JOB | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -1 | -0.5 |
| EXACT ROUND | 21 | 21 | 3 | 1.00 | +12 | +4.0 |
| HONEST WORTH | 29 | 29 | 3 | 1.00 | +101 | +33.6 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +56 | +18.7 |
| OVERRUNS AWAY | 8 | 8 | 3 | 1.00 | +9 | +3.1 |
| REDIRECT COUNTER | 19 | 17 | 3 | 1.00 | +173 | +57.5 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +174 | +58.0 |
| SET UP BY THE SET | 15 | 15 | 3 | 1.00 | +184 | +61.4 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 3 | 1.00 | +1 | +0.3 |
| SHOTS IN THE MOVE | 31 | 22 | 3 | 1.00 | +40 | +13.2 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +70 | +23.3 |
| CHARGE LOSSES | 64 | 57 | 2 | 0.67 | +9 | +4.6 |
| FIGHT TO THE END | 8 | 8 | 2 | 0.67 | +53 | +26.5 |
| LOST AFTER ESCAPE | 15 | 15 | 2 | 0.67 | +1 | +0.3 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +158 | +79.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +70 | +35.0 |
| MISSILES IN THE MOVE | 11 | 5 | 2 | 0.67 | +31 | +15.6 |
| NO DOUBLE ROUNDS | 24 | 24 | 2 | 0.67 | +44 | +22.1 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 2 | 0.67 | +58 | +29.2 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -9 | -4.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 2 | 0.67 | -361 | -180.7 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +12 | +5.9 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +482 | +241.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +82 | +82.3 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -81 | -80.9 |
| FALL BACK GOOD ORDER | 25 | 25 | 1 | 0.33 | +1 | +0.7 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +7 | +7.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| ONE FIGHT FORMULA | 29 | 12 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +7 | +7.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -53 | -52.6 |
| RUN DOWN | 20 | 20 | 1 | 0.33 | +7 | +7.1 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +6 | +6.0 |
| STAY WORTH | 31 | 22 | 1 | 0.33 | +2 | +1.8 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +24 | +23.7 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +7 | +7.1 |
| WOUNDS ON THE RANKS | 7 | 7 | 1 | 0.33 | +19 | +18.6 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 101 | 96 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 50 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 47 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 51 | 48 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 33 | 30 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 103 | 96 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 113 | 113 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 7 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 48 | 44 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 32 | 29 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 273 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 10 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 16 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 55 | 49 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 166 | 153 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 5.00 | 35.4 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 6.33 | 85.3 |
| ARMY TABLE | rule | 3.00 | 3.00 | 131.2 |
| CHARGE NOW FIRST | rule | 2.67 | - | 44.0 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 46.1 |
| CHAFF PASSED | rule | - | 0.67 | 0.7 |
| FIGHT ORDER BAND | gate | 0.67 | - | 1.2 |
| PATHS CROSS | rule | 0.33 | 0.33 | 33.1 |
| REFUSING RETIRES | rule | - | 0.67 | 4.5 |
| SUPPORT NARROWED | rule | 0.67 | - | 180.7 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 80.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 5.5 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| NO REASON | gate | 0.33 | - | 10.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 52.6 |

### Plans: wfr-a92c160-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.7 | 65% | 519 | 533 | 103% |
| Mine | join | 4.7 | 100% | 204 | 0 | 0% |
| Mine | move | 34.7 | 99% | 1512 | 0 | 0% |
| Mine | support | 2.0 | 83% | 39 | 0 | 0% |
| Opponent | charge | 3.0 | 56% | 307 | 215 | 70% |
| Opponent | join | 0.7 | 50% | 62 | 0 | 0% |
| Opponent | move | 39.3 | 95% | 1849 | 0 | 0% |
| Opponent | shoot | 0.3 | 100% | 3 | 5 | 195% |
| Opponent | support | 0.7 | 100% | 35 | 0 | 0% |

### Battle groups: wfr-a92c160-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 50% | 50% | 50% | 0% | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 36% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 63 (9) | 0 | 63 | 23 | 78% | 4.0 | 0 (4) | 133 (3) | 111 (2) | 98 (6) | 0 (3) |
| Mine | Character | 9 | 47 (9) | 47 | 0 | 0 | 44% | 3.6 | 103 (2) | 7 (6) | 0 (1) | 59 (6) | 0 (3) |
| Mine | Clean-up | 1 | 270 (1) | 0 | 270 | 0 | 100% | - | - | - | 270 (1) | 270 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 6 | 49 (6) | 37 | 12 | 14 | 50% | 4.0 | - | 42 (4) | 69 (2) | 51 (3) | 45 (3) |
| Mine | Hammer | 2 | 36 (2) | 5 | 30 | 0 | 0% | 3.0 | - | 36 (2) | - | 0 (1) | 55 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 73 | 50% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 97 (3) | 0 | 97 | 78 | 0% | 5.0 | 0 (1) | 171 (1) | 0 (1) | 97 (3) | - |
| Opponent | Character | 10 | 24 (10) | 24 | 0 | 25 | 10% | 2.8 | 0 (3) | 52 (5) | 0 (1) | 28 (5) | 25 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 20 (5) | 0 | 20 | 55 | 40% | 2.0 | 30 (2) | 0 (1) | 23 (2) | 30 (2) | 15 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 11 (6) | 0 | 11 | 54 | 33% | 4.0 | - | 14 (4) | 0 (2) | 0 (3) | 24 (3) |
| Opponent | Holder | 6 | 34 (6) | 0 | 34 | 0 | 50% | 2.3 | 64 (2) | 48 (2) | - | 150 (1) | 34 (3) |
| Opponent | Shooter | 1 | 56 (1) | 0 | 56 | 0 | 0% | 2.0 | - | - | 56 (1) | 56 (1) | - |

### Charged fights: wfr-a92c160-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 58 | 708 | 6.0 | 1.1 | 118 | 0 | +118 | 3 of 12 | 10 of 12 | +170 | +113 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 2.0 | 1.0 | 46 | 0 | +46 | 0 of 2 | 2 of 2 | - | +46 |
| **Mine** | all armies | 3 | 39 | 502 | 4.7 | 1.1 | 108 | 0 | +108 | 3 of 14 | 12 of 14 | +170 | +103 |
| Opponent | Warriors of Chaos | 2 | 0 | 246 | 2.5 | 1.0 | 98 | 0 | +98 | 1 of 5 | 5 of 5 | - | +98 |
| Opponent | Wood Elf Realms | 1 | 0 | 205 | 3.0 | 1.0 | 68 | 9 | +59 | 1 of 3 | 1 of 3 | - | +59 |
| **Opponent** | all armies | 3 | 0 | 232 | 2.7 | 1.0 | 87 | 3 | +84 | 2 of 8 | 6 of 8 | - | +84 |

### Effective charges: wfr-a92c160-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 12 | 4 (net +146) | 0 | 2 (net +142) | 1 (net +0) | 1 (net +0) | 4 (net +137) | 0 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +91) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 5 | 0 | 0 | 0 | 0 | 1 (net +45) | 4 (net +112) | 0 | 0% (0 of 5) |
| Opponent | Wood Elf Realms | 3 | 2 (net -14) | 0 | 0 | 0 | 0 | 1 (net +205) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 326 | 232 | +146 | 148 | 15 | +133 | +40.7 |
| Mine | Effective (55-75%) | 2 | 186 | 285 | +142 | 142 | 31 | +112 | +59.9 |
| Mine | 76-89% | 1 | 480 | 116 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 327 | 157 | +110 | 146 | 0 | +146 | +44.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 482 | 80 | +46 | 46 | 0 | +46 | +9.4 |
| Mine | All fights | 14 | 340 | 183 | +108 | 121 | 9 | +112 | +33.1 |
| Opponent | Long shot (under 50%) | 2 | 263 | 204 | -14 | 17 | 138 | -121 | -45.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 193 | 160 | +130 | 130 | 36 | +95 | +49.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 479 | 45 | +45 | 45 | 0 | +45 | +9.4 |
| Opponent | All fights | 8 | 246 | 156 | +84 | 91 | 57 | +35 | +14.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p36 | move | 21 | 4 (19%) | 3 (14%) | 7 (33%) | 10 (48%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

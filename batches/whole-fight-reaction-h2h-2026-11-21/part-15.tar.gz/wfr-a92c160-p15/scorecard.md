# Doctrine scorecard: wfr-a92c160-p15

### Scorecard: wfr-a92c160-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 8 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 719 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 375 |
| L0425 | 5 | 1 | Opponent | no | - | 5 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 668 |
| L0512 | 2 | 1 | Opponent | - | - | 6 | 0 | 1 | 1 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 8.0 | 3.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 347.7 |
| **Average** | | | Opponent | 0% | 0.0 | 5.5 | 0.7 | 2.0 | 0.3 | 0.0 | 0.0 | 349.7 |

### KPIs: wfr-a92c160-p15

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (4 of 15) | 0% (0 of 14) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | - | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 100% | - | 88% (7 of 8); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 75% (9 of 12) | 33% (12 of 36) | 44% (21 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 75% (9 of 12) | 48% (12 of 25) | 57% (21 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 75% (4505 of 5998) | 76% (4588 of 5998) | 76% (9093 of 11996) |
|   infantry points that never fought | lower | 71% (1015 of 1424) | 78% (930 of 1187) | 74% (1945 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 85% (23 of 27) | 76% (38 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3042 of 5120) | 87% (4727 of 5442) | 74% (7769 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (42%) | 3.3 (37%) |
| MARCHED: its unit marched | 1.0 (100%) | 1.0 (12%) | 2.0 (22%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (8%) | 0.7 (7%) |
| GONE: slain | 0.0 (0%) | 2.7 (33%) | 2.7 (30%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (4%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.3 | 0.0 | 1.7 | 7.0 | 0.3 | 0.7 |
| not cast | 3.7 | 6.0 | 4.3 | 9.0 | 1.7 | 19.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (50%) | 4.0 (92%) | 3.3 (37%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 2.7 (44%) | 0.0 (0%) | 2.7 (30%) | 1.3 (80%) | 1.0 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (100%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (57 of 99) | 67% (47 of 70) | 62% (104 of 169) |
|   cavalry | 33% (4 of 12) | - | 33% (4 of 12) |
|   character | 81% (17 of 21) | 100% (3 of 3) | 83% (20 of 24) |
|   chariot | 12% (3 of 24) | 50% (2 of 4) | 18% (5 of 28) |
|   infantry | 50% (6 of 12) | 63% (17 of 27) | 59% (23 of 39) |
|   monster | - | 83% (5 of 6) | 83% (5 of 6) |
|   war machine | 90% (27 of 30) | 67% (20 of 30) | 78% (47 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (19%) | 0.3 (4%) | 3.0 (14%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.3 (4%) | 0.7 (3%) |
| NO TARGET IN RANGE | 7.0 (50%) | 1.3 (17%) | 8.3 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 1.3 (17%) | 1.7 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (24%) | 1.0 (13%) | 4.3 (20%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 3.0 (39%) | 3.3 (15%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 6.7 | 1.0 | 90% | 3.0 pts | 20 pts |
| chariot | 1.7 | 3.3 | 60% | 15.4 pts | 26 pts |
| infantry | 9.7 | 2.0 | 79% | 8.0 pts | 77 pts |
| monster | 3.3 | 1.0 | 70% | 20.6 pts | 69 pts |
| war machine | 15.7 | 10.7 | 62% | 16.2 pts | 253 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 1.3 | 1.5 |
| Charges that made contact a game | 1.7 | 0.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.22 contact (23 units) | 0.18 declared, 0.06 contact (17 units) | 0.20 declared, 0.15 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | - | 100% (5 of 5) |
| Character on its own | 100% (3 of 3) | 50% (3 of 6) | 75% (3 of 4) | 69% (9 of 13) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 67% (8 of 12) | 67% (2 of 3) | - | 67% (10 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 83% (5 of 6); on the table 100% | 75% (9 of 12) | 80% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 100% (2 of 2); on the table 100% | - | 65% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 33% (4 of 12) | 68% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 22% (4 of 18) | 72% | 78% (7 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 67% (4 of 6) | 89% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 75% (3) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.33 | 0.00 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: wfr-a92c160-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 22% (9 of 41) | 45% (19 of 42) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 38% (3 of 8) | 56% (5 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 347.7 | 349.7 |
| Movement | Fights charged into per game | 1.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +466 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +85 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net -62 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (14 of 30) | 78% (21 of 27) |
| Shooting | Points destroyed by shooting units | 15.0 | 46.3 |
| Shooting | War machine shots | 9.0 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (12 of 27) | 45% (9 of 20) |
| Shooting | Points destroyed by war machines | 194.7 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 6.0 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 214.0 | 129.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +104 | -217 |
| Combat | Net per 100 charger points, damage counted | +43.9 | -39.4 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +101 | -217 |
| Combat | Net points per supported fight / lone fight | - / +101 | -217 / - |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 1 of 1 |
| Game | Points lost | 142.3 | 686.3 |
| Game | VP from objectives | 620.0 | 576.7 |
| Game | Lone holders (player turns) | 8.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +508 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 829
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 21.7 | +165.3 | 0.0 | 0.0 | 17.0 | +470.0 | 0.0 | 191.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.7 | 0.0 | 0.0 | 0.7 | +0.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 263.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.7 | +239.8 | 750.0 | 0.0 | 6.7 | +494.6 | 231.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.3 | +183.9 | 346.0 | 0.0 | 2.7 | +26.3 | 0.0 | 238.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +4.9 | 0.0 | 30.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +6.7 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -2.4 | 63.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.7 | -949.8 | 0.0 | 185.3 | 15.0 | -545.7 | 0.0 | 782.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 25.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 88.3 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +267.0 | 0.0 | 0.0 |
| COVER ONCE | 12.0 | -1859.6 | 0.0 | 0.0 | 5.3 | -543.9 | 0.0 | 157.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +3.2 | 25.0 | 0.0 | 0.3 | -19.8 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 63.0 | 0.0 | 1.0 | +3.0 | 0.0 | 72.3 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.0 | +100.9 | 0.0 | 92.7 | 16.3 | +181.6 | 0.0 | 683.3 |
| FIGHT TO THE END | 0.7 | +18.7 | 63.0 | 0.0 | 0.3 | +16.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 107.0 | +5347.9 | 1942.0 | 185.3 | 91.0 | +5591.9 | 463.3 | 1814.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 286.7 |
| FOLLOW UP WEIGHED | 1.0 | +182.7 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +89.2 | 88.0 | 0.0 | 1.3 | +245.0 | 0.0 | 72.3 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -6.1 | 0.0 | 0.0 | 4.3 | -24.5 | 0.0 | 393.3 |
| GIVES UP | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| GOAL WALK | 12.7 | +998.2 | 0.0 | 0.0 | 4.7 | +141.7 | 0.0 | 169.3 |
| GUN FIGURES | 0.7 | +1.9 | 15.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| GUN MASK | 2.3 | +137.4 | 0.0 | 0.0 | 0.7 | -2.0 | 0.0 | 68.3 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 56.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 476.0 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 237.7 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 461.7 |
| HIS MOVE AND SHOT | 2.0 | -25.8 | 0.0 | 0.0 | 1.7 | -7.5 | 0.0 | 140.7 |
| HIS MOVE AS HE DECIDES | 37.0 | +10.7 | 723.0 | 0.0 | 44.7 | +17.3 | 92.7 | 0.0 |
| HIS MOVE WHY | 16.0 | +0.0 | 0.0 | 92.7 | 26.0 | +0.0 | 0.0 | 823.0 |
| HIS ONE MOVE | 24.3 | +2.7 | 0.0 | 0.0 | 20.0 | -41.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.7 | +3679.9 | 0.0 | 185.3 | 48.7 | +2793.3 | 0.0 | 1121.3 |
| HIS SHOTS BY HIS RUN | 35.0 | +731.7 | 0.0 | 185.3 | 25.7 | +804.8 | 0.0 | 1035.3 |
| HIS TURN DENIED | 1.0 | +28.3 | 63.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.0 | +642.9 | 0.0 | 0.0 | 7.7 | +968.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -38.2 | 88.0 | 0.0 | 1.3 | -67.7 | 0.0 | 72.3 |
| HUNT IN PAIRS | 1.3 | +112.5 | 0.0 | 0.0 | 4.0 | +645.9 | 0.0 | 267.0 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 92.7 | 10.7 | -171.9 | 0.0 | 462.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -55.4 | 0.0 | 72.3 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 176.7 | 0.0 | 1.0 | +0.0 | 0.0 | 151.3 |
| LONE CHARACTER SAFE SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.5 | 63.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -2.2 | 63.0 | 0.0 | 1.0 | -24.8 | 0.0 | 72.3 |
| MANOEUVRE | 2.3 | -17.5 | 0.0 | 0.0 | 3.3 | -25.2 | 0.0 | 63.0 |
| MARCH BY THE SUM | 0.7 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +46.0 | 0.0 | 0.0 | 2.3 | +141.7 | 0.0 | 189.3 |
| MARCH OF THE TABLE | 0.3 | +7.4 | 0.0 | 0.0 | 0.3 | +43.0 | 0.0 | 126.3 |
| MARCH OVER CASTS | 0.7 | -44.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +93.2 | 0.0 | 0.0 | 5.7 | +245.7 | 0.0 | 335.7 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +132.4 | 0.0 | 0.0 | 9.3 | +111.0 | 0.0 | 301.3 |
| MISSILES NEXT TURN | 3.3 | +87.8 | 0.0 | 0.0 | 10.3 | +106.1 | 0.0 | 427.7 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 4.0 | +154.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -8.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.7 | +240.6 | 0.0 | 0.0 | 3.0 | +221.3 | 0.0 | 72.3 |
| NEARER NOT NEEDED | 9.7 | +421.9 | 0.0 | 0.0 | 9.3 | +379.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +185.4 | 0.0 | 0.0 | 0.7 | +27.5 | 0.0 | 72.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -68.4 | 88.0 | 0.0 | 0.7 | -10.5 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -145.7 | 0.0 | 0.0 | 4.0 | -199.2 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -77.2 | 0.0 | 0.0 | 4.7 | -92.6 | 0.0 | 379.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +103.7 | 0.0 | 72.3 |
| ONE OBJECTIVE FORMULA | 1.7 | +5.6 | 0.0 | 0.0 | 3.7 | +80.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +29.5 | 25.0 | 0.0 | - | - | - | - |
| OWN CAST FIRST | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +36.0 | 0.0 | 0.0 | 1.0 | +3.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 1.0 | -26.1 | 0.0 | 68.3 |
| PLAN RESULT | 48.0 | +1153.4 | 610.0 | 92.7 | 42.0 | +563.5 | 231.7 | 739.3 |
| PROMISE BY ITS OWN SUM | 6.0 | -137.0 | 0.0 | 0.0 | 6.0 | -118.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.7 | -5.6 | 0.0 | 0.0 | 4.0 | -23.3 | 0.0 | 393.3 |
| QUARTER ODDS | 20.3 | +2182.5 | 63.0 | 0.0 | 15.3 | +850.2 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +292.6 | 0.0 | 0.0 | 1.3 | +137.7 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.7 | -3.7 | 0.0 | 0.0 | 0.3 | -5.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +28.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -8.2 | 88.0 | 0.0 | 1.3 | -78.4 | 0.0 | 72.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -7.4 | 0.0 | 72.3 |
| RUN DOWN | 0.7 | -0.7 | 63.0 | 0.0 | 1.0 | -2.0 | 0.0 | 72.3 |
| SAFER THAN THE JOB | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -19.6 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | -20.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +54.1 | 25.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -18.7 | 0.0 | 0.0 | 8.3 | -863.2 | 0.0 | 602.3 |
| SET UP BY THE SET | 1.0 | -22.5 | 0.0 | 0.0 | 9.0 | +721.2 | 0.0 | 602.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.7 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 134.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +87.6 | 0.0 | 0.0 | 2.3 | +20.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 23.0 | +517.1 | 0.0 | 185.3 | 22.3 | -26.9 | 0.0 | 883.7 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +388.1 | 0.0 | 0.0 | 18.7 | +1184.7 | 0.0 | 63.0 |
| SPELL WORTH | - | - | - | - | 2.0 | +56.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -11.6 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 46.3 | 10.7 | +0.0 | 0.0 | 575.3 |
| STAND AND SHOOT | 0.3 | -3.0 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 57.3 | +0.0 | 1854.0 | 92.7 | 41.7 | +0.0 | 463.3 | 238.0 |
| STAY WORTH | 32.3 | -18.1 | 1854.0 | 0.0 | 31.0 | -135.6 | 463.3 | 238.0 |
| SUPPORT ADDS | 8.0 | +355.9 | 0.0 | 0.0 | 3.0 | +521.6 | 0.0 | 93.3 |
| SUPPORT WORKED OUT | 8.0 | +355.9 | 0.0 | 0.0 | 3.0 | +521.6 | 0.0 | 93.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +119.4 | 0.0 | 112.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 25.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 46.3 | 3.0 | +0.0 | 0.0 | 81.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 72.3 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 46.3 | 2.0 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 53.0 | +0.0 | 0.0 | 92.7 | 43.3 | +0.0 | 0.0 | 886.0 |
| TIED UP BY THE SUM | 0.3 | +32.1 | 25.0 | 0.0 | 0.3 | +46.1 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 36.0 | +447.5 | 0.0 | 0.0 | 14.7 | +165.9 | 0.0 | 63.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -52.5 | 0.0 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | -55.4 | 0.0 | 72.3 |
| WHO HITS BACK | 0.3 | +109.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -285.0 | 0.0 | 0.0 | 1.0 | -135.2 | 0.0 | 194.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +161.1 | 0.0 | 72.3 |
| WHOLE FIGHT REACTION | - | - | - | - | 0.3 | +34.2 | 0.0 | 63.0 |
| WOUNDS ON THE RANKS | 2.0 | +48.5 | 0.0 | 0.0 | 1.3 | +9.4 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 245 | 245 | 161 | 53.67 | +0 | +0.0 |
| ARMY TABLE | 116 | 116 | 87 | 29.00 | +2278 | +26.2 |
| HIS MOVE WHY | 126 | 126 | 85 | 28.33 | +0 | +0.0 |
| HIS SHOT LIST | 292 | 268 | 63 | 21.00 | +1723 | +27.3 |
| HIS ONE MOVE | 133 | 128 | 42 | 14.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 44 | 44 | 42 | 14.00 | +3044 | +72.5 |
| HIS SHOTS BY HIS RUN | 182 | 167 | 34 | 11.33 | +692 | +20.4 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -1035 | -35.7 |
| SHOT RISK POINTS | 136 | 124 | 28 | 9.33 | +978 | +34.9 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 152 | 135 | 22 | 7.33 | +45 | +2.1 |
| FIVE ACTION | 594 | 564 | 19 | 6.33 | +930 | +48.9 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SET UP BY THE SET | 30 | 25 | 16 | 5.33 | +1041 | +65.0 |
| CAST JOB | 18 | 18 | 15 | 5.00 | +143 | +9.5 |
| COVER ONCE | 52 | 44 | 12 | 4.00 | +224 | +18.6 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| QUARTER ODDS | 107 | 98 | 12 | 4.00 | +1293 | +107.8 |
| SUPPORT ADDS | 33 | 31 | 12 | 4.00 | +376 | +31.3 |
| SUPPORT WORKED OUT | 33 | 31 | 12 | 4.00 | +376 | +31.3 |
| THE RISK READS HIS RUN | 36 | 36 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 83 | 74 | 11 | 3.67 | +429 | +39.0 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 20 | 12 | 9 | 3.00 | +362 | +40.3 |
| PROMISE BY ITS OWN SUM | 36 | 36 | 9 | 3.00 | -765 | -85.0 |
| GOAL WALK | 52 | 52 | 8 | 2.67 | +426 | +53.2 |
| IDLE COST | 48 | 44 | 7 | 2.33 | +39 | +5.6 |
| MARCH CHECK | 10 | 10 | 7 | 2.33 | +141 | +20.1 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 8 | 6 | 2.00 | +623 | +103.9 |
| HUNT IN PAIRS | 16 | 14 | 6 | 2.00 | +486 | +81.1 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 6 | 2.00 | +57 | +9.5 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +119 | +23.8 |
| SHOTS IN THE MOVE | 97 | 79 | 5 | 1.67 | +325 | +65.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MAX FOR POSITIONING | 26 | 24 | 4 | 1.33 | +37 | +9.3 |
| NEXT CHARGE BY LIST | 9 | 7 | 4 | 1.33 | +253 | +63.3 |
| SET CREDITED ONCE | 27 | 22 | 4 | 1.33 | +161 | +40.2 |
| STAY WORTH | 190 | 177 | 4 | 1.33 | +13 | +3.3 |
| CANNON PLANNED TARGET | 46 | 46 | 3 | 1.00 | +35 | +11.6 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +548 | +182.7 |
| MANOEUVRE | 17 | 17 | 3 | 1.00 | +12 | +3.9 |
| NEARER NOT NEEDED | 57 | 57 | 3 | 1.00 | +106 | +35.3 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 1.00 | -78 | -26.1 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +20 | +10.1 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -166 | -83.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +60 | +29.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -151 | -75.4 |
| MISSILES IN THE MOVE | 37 | 28 | 2 | 0.67 | +160 | +80.0 |
| ONE OBJECTIVE FORMULA | 16 | 12 | 2 | 0.67 | +224 | +111.9 |
| PROMISE READS THE TABLE | 17 | 17 | 2 | 0.67 | +6 | +3.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 5 | 4 | 2 | 0.67 | +74 | +36.8 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | -166 | -83.2 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +383 | +191.6 |
| WOUNDS ON THE RANKS | 10 | 9 | 2 | 0.67 | +16 | +7.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -94 | -94.1 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -69 | -68.6 |
| FALLS SHORT | 70 | 61 | 1 | 0.33 | +26 | +25.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 9 | 7 | 1 | 0.33 | +116 | +116.3 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +74 | +74.2 |
| HONEST WORTH | 8 | 7 | 1 | 0.33 | +7 | +7.1 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +154 | +154.1 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -9 | -8.6 |
| REDIRECT COUNTER | 7 | 6 | 1 | 0.33 | +224 | +223.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -0 | -0.4 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +84 | +84.2 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +21 | +21.4 |
| SEARCH SPOT | 4 | 4 | 1 | 0.33 | +6 | +5.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +162 | +162.3 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +30 | +29.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +157 | +157.1 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +8 | +7.8 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 5 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 43 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| EXACT ROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 18 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 48 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 56 | 51 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 11 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 60 | 60 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 41 | 32 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| OPENS UP | 1 | not checked | - | - | - | - |
| PLAN RESULT | 270 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | not checked | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | not checked | - | - | - | - |
| RISK BY ARC | 7 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 85 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 56 | 47 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 297 | 283 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 289 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 11 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.67 | 33.8 |
| ARMY TABLE | rule | 3.00 | 0.33 | 57.8 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 1.00 | 85.0 |
| NO REASON | gate | - | 1.33 | 68.4 |
| RULE SWITCHED OFF | gate | 1.33 | - | 20.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 15.5 |
| PIVOT GUARDS FLANK | rule | - | 1.00 | 26.1 |
| JOINT CHARGE NOW | rule | - | 0.67 | 83.2 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 75.4 |
| SET UP BY THE SET | rule | - | 0.67 | 5.5 |
| WHO GETS IN | rule | - | 0.67 | 83.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 94.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 68.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 5.4 |
| OWN CAST FIRST | rule | - | 0.33 | 8.6 |
| PATHS CROSS | rule | - | 0.33 | 6.7 |

### Plans: wfr-a92c160-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 113 | 123 | 109% |
| Mine | join | 1.7 | 100% | 48 | 0 | 0% |
| Mine | move | 33.0 | 99% | 1970 | 0 | 0% |
| Mine | shoot | 12.3 | 57% | 670 | 1030 | 154% |
| Opponent | charge | 0.7 | 0% | 52 | 0 | 0% |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 27.3 | 95% | 1235 | 0 | 0% |
| Opponent | shoot | 11.7 | 63% | 642 | 564 | 88% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 26 (11) | 26 | 0 | 15 | 18% | 2.1 | 26 (8) | 28 (3) | - | 36 (8) | 0 (3) |
| Mine | Clean-up | 6 | 146 (6) | 72 | 74 | 0 | 67% | 5.5 | 0 (3) | 167 (2) | 563 (1) | 178 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 67% | 3.0 | 12 (2) | 0 (4) | - | 4 (5) | 0 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 50 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 45 (2) | 45 | 0 | 0 | 0% | 1.5 | 91 (1) | 0 (1) | - | 45 (2) | - |
| Mine | War machine | 5 | 123 (5) | 123 | 0 | 0 | 0% | 1.2 | 108 (2) | 0 (1) | 199 (2) | - | 123 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 50% | 4.5 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 22 (9) | 22 | 0 | 36 | 56% | 4.0 | 0 (3) | 41 (5) | 0 (1) | 26 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 100 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 38 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 93 (3) | 0 | 93 | 31 | 67% | 5.0 | - | 136 (2) | - | 0 (1) | 289 (1) |
| Opponent | Shooter | 3 | 150 (3) | 45 | 106 | 0 | 0% | 1.0 | - | 317 (1) | 67 (2) | 159 (2) | 134 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 0 (5) | 0 | 0 | 0 | 20% | 1.0 | - | - | 0 (5) | - | 0 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 66 | 20% | 3.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |

### Charged fights: wfr-a92c160-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 446 | 2.0 | 1.0 | 223 | 0 | +223 | 1 of 4 | 4 of 4 | - | +223 |
| Mine | Dwarfen Mountain Holds | 1 | 584 | 0 | 1.0 | 1.0 | 0 | 388 | -388 | 1 of 1 | 1 of 1 | - | -388 |
| **Mine** | all armies | 3 | 294 | 297 | 1.7 | 1.0 | 178 | 78 | +101 | 2 of 5 | 5 of 5 | - | +101 |
| Opponent | Empire of Man | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 217 | -217 | 1 of 1 | 0 of 1 | -217 | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 46 | 0 | 0.3 | 2.0 | 0 | 217 | -217 | 1 of 1 | 0 of 1 | -217 | - |

### Effective charges: wfr-a92c160-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 1 (net +466) | 0 | 0 | 0 | 1 (net +85) | 1 (net +265) | 1 | 0% (0 of 3) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -388) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net -217) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 189 | +466 | 466 | 9 | +457 | +380.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 194 | 300 | -62 | 156 | 209 | -53 | -27.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 68 | +85 | 95 | 0 | +95 | +27.9 |
| Mine | No odds | 1 | 339 | 75 | +75 | 75 | 0 | +75 | +22.1 |
| Mine | All fights | 5 | 237 | 186 | +101 | 190 | 85 | +104 | +43.9 |
| Opponent | 76-89% | 1 | 551 | 239 | -217 | 0 | 217 | -217 | -39.4 |
| Opponent | All fights | 1 | 551 | 239 | -217 | 0 | 217 | -217 | -39.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p15 | move | 12 | 1 (8%) | 1 (8%) | 3 (25%) | 8 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

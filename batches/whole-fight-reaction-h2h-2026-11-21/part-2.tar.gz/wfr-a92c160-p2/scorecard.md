# Doctrine scorecard: wfr-a92c160-p2

### Scorecard: wfr-a92c160-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 9 | 0 | 0 | 0 | 285 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 148 |
| L0235 | 1 | 1 | Mine | no | 2 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 5 | 5 | 1 | 0 | 0 | 0 | 0 | 540 |
| L0319 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.5 | 5.0 | 0.7 | 4.0 | 0.0 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 0.0 | 2.5 | 0.7 | 3.3 | 0.0 | 0.0 | 0.0 | 91.0 |

### KPIs: wfr-a92c160-p2

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (2 of 8) | 0% (0 of 14) | 9% (2 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (6 of 6); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 100% (7 of 7); on the table 100% | 100% (10 of 10); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 55% (23 of 42) | 12% (3 of 24) | 39% (26 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (23 of 42) | 14% (3 of 22) | 41% (26 of 64) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 73% (8 of 11) | - | 73% (8 of 11) |
| Points that never fought | lower | 82% (4766 of 5797) | 60% (3586 of 6000) | 71% (8352 of 11797) |
|   infantry points that never fought | lower | 100% (1374 of 1374) | 69% (577 of 842) | 88% (1951 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 80% (16 of 20) | 44% (12 of 27) | 60% (28 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.0 uses a game | 50% (1 of 2); 1.7 uses a game | 83% (5 of 6); 3.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 76% (3083 of 4039) | 42% (2329 of 5515) | 57% (5412 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (89%) | 0.0 (0%) | 5.7 (42%) |
| MARCHED: its unit marched | 0.7 (11%) | 0.3 (5%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.3 (62%) | 4.3 (32%) |
| GONE: slain | 0.0 (0%) | 0.7 (10%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (24%) | 1.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 3.0 | 8.7 | 0.0 |
| not cast | 2.7 | 7.0 | 13.3 | 28.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 5.7 (42%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 4.0 (57%) | 4.3 (32%) | 0.0 (0%) |
| GONE: slain | 0.7 (25%) | 0.7 (10%) | 0.7 (5%) | 1.3 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.3 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 67% (4 of 6) | 0% (0 of 3) | 44% (4 of 9) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | - | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (18 of 30) | 58% (49 of 85) | 58% (67 of 115) |
|   cavalry | - | 72% (13 of 18) | 72% (13 of 18) |
|   character | - | 67% (8 of 12) | 67% (8 of 12) |
|   chariot | 30% (3 of 10) | 58% (7 of 12) | 45% (10 of 22) |
|   infantry | - | 35% (11 of 31) | 35% (11 of 31) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 75% (15 of 20) | - | 75% (15 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (42%) | 2.0 (17%) | 3.7 (23%) |
| CHARGED: it charged | 0.3 (8%) | 1.0 (8%) | 1.3 (8%) |
| IN COMBAT: it fought this turn or the last | 0.3 (8%) | 0.7 (6%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.7 (17%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.3 (44%) | 5.3 (33%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (25%) | 1.0 (8%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 1.7 (14%) | 1.7 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.3 | 76% | 4.4 pts | 25 pts |
| character | 2.7 | 1.7 | 50% | 12.8 pts | 34 pts |
| chariot | 3.3 | 2.7 | 50% | 15.3 pts | 51 pts |
| infantry | 3.7 | 4.0 | 45% | 12.2 pts | 45 pts |
| monster | 3.3 | 3.7 | 50% | 14.8 pts | 49 pts |
| war machine | 5.0 | 4.7 | 73% | 29.4 pts | 147 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.3 | 2.3 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.16 declared, 0.16 contact (25 units) | 0.34 declared, 0.17 contact (29 units) | 0.26 declared, 0.17 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 0% (0 of 1) | - | 25% (1 of 4) |
| Character in a unit | 62% (5 of 8) | 67% (4 of 6) | - | 64% (9 of 14) |
| Character on its own | - | 100% (2 of 2) | 50% (1 of 2) | 75% (3 of 4) |
| Chariot | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |
| Infantry | 40% (2 of 5) | 33% (1 of 3) | - | 38% (3 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (3 of 3); on the table 100% | 70% (21 of 30) | 89% | 75% (9 of 12) | 100% (4 of 4); 9.0 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 17% (2 of 12) | 69% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 12) | 50% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 29% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 0% (0) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (8 of 21) | 36% (5 of 14) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 80% (4 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 4.0 | 3.3 |
| Movement | Points that never moved of their own | 275.0 | 91.0 |
| Movement | Fights charged into per game | 1.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 3, net +0 | 1 of 2, net +85 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +274 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 37% (18 of 49) |
| Shooting | Points destroyed by shooting units | 0.0 | 84.0 |
| Shooting | War machine shots | 5.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (5 of 15) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 3.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (3 of 11) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 12.3 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 121.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 91.3 | 188.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +129 | +115 |
| Combat | Net per 100 charger points, damage counted | +83.0 | +48.3 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +91 | +135 |
| Combat | Net points per supported fight / lone fight | +274 / +0 | - / +135 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 1 of 5 |
| Game | Points lost | 404.3 | 249.3 |
| Game | VP from objectives | 676.7 | 953.3 |
| Game | Lone holders (player turns) | 3.5 | 0.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -383 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 654
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| AFTERMATH WITH FRIENDS | 0.3 | +16.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 12.7 | +199.0 | 0.0 | 73.0 | 23.0 | +42.5 | 0.0 | 117.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 1.0 | +36.8 | 0.0 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 55.0 | 36.7 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +29.4 | 91.7 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.7 | +10.9 | 38.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.7 | +31.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +69.7 | 0.0 | 85.0 | 1.0 | +0.6 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.7 | 56.7 | 0.0 |
| CHARGE LOSSES | 14.0 | -268.4 | 0.0 | 398.0 | 10.0 | -486.0 | 0.0 | 38.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 28.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 105.0 | 10.7 | +0.0 | 0.0 | 18.3 |
| CONVEYANCE SEARCH | 1.7 | +220.1 | 0.0 | 0.0 | 1.0 | +105.8 | 0.0 | 91.3 |
| COVER ONCE | 3.7 | -90.9 | 0.0 | 133.7 | 4.0 | -122.9 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +12.2 | 28.3 | 0.0 |
| DENIED BY THE FIGHT | 1.0 | -1.6 | 0.0 | 17.3 | - | - | - | - |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -19.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +16.0 | 56.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | -46.8 | 0.0 | 17.3 | 1.7 | -2.1 | 28.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +2.5 | 0.0 | 17.3 | 1.0 | +13.5 | 28.3 | 0.0 |
| FALLS SHORT | 22.7 | +286.8 | 0.0 | 48.3 | 3.0 | +83.5 | 0.0 | 0.0 |
| FEATURE BUFFS | 12.0 | +488.4 | 0.0 | 137.3 | 1.0 | +7.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 91.7 | +7537.5 | 148.0 | 1199.3 | 95.7 | +5227.4 | 381.0 | 272.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 103.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +27.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +360.7 | 0.0 | 17.3 | 2.3 | +137.7 | 85.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.0 |
| FRIEND SHOOTS FIRST | 1.3 | -22.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -11.8 | 56.7 | 0.0 |
| GOAL WALK | 6.7 | +780.2 | 0.0 | 170.0 | 11.3 | +952.1 | 0.0 | 41.7 |
| GUN FIGURES | 1.0 | +2.6 | 0.0 | 103.3 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 380.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +20.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 44.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 30.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.3 | -72.8 | 0.0 | 130.7 | 2.0 | -21.2 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 49.0 | +14.7 | 154.3 | 0.0 | 36.3 | +10.7 | 405.0 | 0.0 |
| HIS MOVE WHY | 24.0 | +0.0 | 0.0 | 359.3 | 23.3 | +0.0 | 0.0 | 0.0 |
| HIS ONE MOVE | 16.0 | +29.1 | 0.0 | 340.3 | 21.0 | +8.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 76.0 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 30.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 12.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 58.7 | +1919.5 | 0.0 | 394.7 | 65.3 | +2936.2 | 0.0 | 192.3 |
| HIS SHOTS BY HIS RUN | 52.3 | +965.1 | 0.0 | 822.0 | 41.3 | +1122.7 | 0.0 | 158.0 |
| HIS TURN DENIED | 1.0 | +5.4 | 0.0 | 17.3 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 35.7 | +0.0 | 0.0 | 254.7 | 16.3 | +0.0 | 0.0 | 38.0 |
| HOLDER ASSIGNMENT | 16.0 | +1766.4 | 0.0 | 153.7 | 11.7 | +1167.8 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -23.2 | 0.0 | 0.0 | 2.3 | -85.7 | 85.0 | 0.0 |
| IDLE COST | 17.0 | -94.5 | 0.0 | 85.0 | 4.0 | -67.2 | 0.0 | 18.3 |
| JOINT CHARGE NOW | 0.7 | +43.7 | 0.0 | 17.3 | - | - | - | - |
| KEEP FALLS | 0.7 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 120.7 | 76.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.7 | 0.0 | 17.3 | 1.3 | -2.0 | 56.7 | 0.0 |
| LOST CHARGE | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +5.3 | 0.0 | 0.0 | 3.0 | -35.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +57.1 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 0.7 | +31.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +19.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -70.9 | 0.0 | 0.0 | 0.3 | +33.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +26.5 | 0.0 | 56.7 | 1.0 | +11.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +312.1 | 0.0 | 0.0 | 3.7 | +76.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +240.2 | 0.0 | 0.0 | 4.0 | +57.7 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.0 | -164.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -84.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +933.2 | 0.0 | 237.0 | 4.7 | +206.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.0 | +214.3 | 0.0 | 0.0 | 11.0 | +483.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +508.9 | 0.0 | 133.7 | 2.3 | +79.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -126.8 | 0.0 | 17.3 | 1.7 | -27.8 | 85.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -1067.9 | 0.0 | 131.7 | 4.3 | -104.4 | 56.7 | 38.0 |
| OGRE LOADER SECOND SHOT | 1.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -52.6 | 0.0 | 188.3 | 3.7 | -62.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +200.7 | 0.0 | 10.0 | 3.3 | -141.8 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +11.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 42.3 | +243.9 | 55.0 | 695.3 | 43.3 | +216.5 | 28.3 | 136.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -1611.6 | 0.0 | 206.7 | 6.3 | -216.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -22.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.0 | -2.1 | 0.0 | 110.0 | - | - | - | - |
| QUARTER ODDS | 13.7 | +1287.1 | 38.0 | 125.3 | 11.0 | +1198.7 | 126.0 | 76.0 |
| RANDOM MOVE BY FIGURES | 3.7 | +69.8 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +26.1 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 1.7 | +34.4 | 0.0 | 66.7 | 2.0 | -64.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +33.1 | 0.0 | 85.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -159.1 | 0.0 | 0.0 | 1.0 | -6.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +38.0 | 0.0 | 38.0 |
| RISK BY ARC | 0.7 | +10.3 | 0.0 | 0.0 | 1.0 | -11.9 | 28.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -14.0 | 0.0 | 0.0 |
| RUN DOWN | 1.0 | -4.8 | 0.0 | 17.3 | 1.3 | -7.3 | 28.3 | 0.0 |
| SAME TERRAIN AS THE BOARD | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +17.1 | 0.0 | 0.0 | 2.0 | +46.4 | 0.0 | 38.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +29.6 | 56.7 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +35.7 | 0.0 | 0.0 | 0.3 | +10.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 110.0 | 5.3 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +60.7 | 0.0 | 0.0 | 3.3 | +30.3 | 69.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.2 | 0.0 | 36.7 | - | - | - | - |
| SHOT REPLANNED | 0.7 | +0.0 | 18.3 | 36.7 | - | - | - | - |
| SHOT RISK POINTS | 48.0 | +631.3 | 0.0 | 481.7 | 49.7 | +443.7 | 0.0 | 234.0 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.7 | +117.5 | 0.0 | 250.0 | 19.3 | +479.4 | 0.0 | 38.0 |
| SPELLS IN THE FIGHT | 1.0 | -58.2 | 0.0 | 17.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 205.7 | 7.3 | +0.0 | 0.0 | 38.0 |
| STAND AND SHOOT | 1.0 | -8.5 | 0.0 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 40.3 | +0.0 | 148.0 | 623.3 | 45.0 | +0.0 | 296.0 | 79.7 |
| STAY WORTH | 17.3 | +78.5 | 148.0 | 506.7 | 21.0 | +126.1 | 170.0 | 114.0 |
| STRIKE BY THE ODDS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +70.1 | 0.0 | 0.0 | 2.3 | +324.9 | 0.0 | 38.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 17.3 | 0.3 | +0.0 | 28.3 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +70.1 | 0.0 | 0.0 | 2.3 | +324.9 | 0.0 | 38.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 103.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 6.3 | +0.0 | 0.0 | 188.3 | 2.3 | +0.0 | 0.0 | 38.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 497.7 | 45.0 | +0.0 | 0.0 | 136.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +91.9 | 56.7 | 0.0 |
| TIME ON OUR SIDE | 9.0 | +154.0 | 0.0 | 237.0 | 66.3 | +510.2 | 0.0 | 121.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 30.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +107.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 56.7 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | +28.5 | 0.0 | 17.3 | 0.3 | +2.8 | 28.3 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -88.2 | 0.0 | 133.7 | 0.7 | -271.0 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 0.7 | -43.3 | 17.3 | 0.0 |
| WOUNDS ON THE RANKS | 5.3 | +398.3 | 0.0 | 0.0 | 2.3 | +144.4 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 256 | 256 | 180 | 60.00 | +0 | +0.0 |
| SHOT RISK POINTS | 293 | 290 | 107 | 35.67 | +1889 | +17.7 |
| HIS SHOT LIST | 372 | 368 | 96 | 32.00 | +942 | +9.8 |
| HIS SHOTS BY HIS RUN | 281 | 273 | 96 | 32.00 | +1759 | +18.3 |
| HOLDER ASSIGNMENT | 83 | 83 | 77 | 25.67 | +4186 | +54.4 |
| HIS MOVE WHY | 142 | 142 | 68 | 22.67 | +0 | +0.0 |
| ARMY TABLE | 107 | 107 | 66 | 22.00 | +379 | +5.7 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| HIS ONE MOVE | 111 | 108 | 36 | 12.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 226 | 202 | 35 | 11.67 | +133 | +3.8 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 562 | 544 | 22 | 7.33 | +827 | +37.6 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -3517 | -175.8 |
| PROMISE BY ITS OWN SUM | 36 | 36 | 17 | 5.67 | -5483 | -322.5 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 54 | 51 | 13 | 4.33 | +916 | +70.5 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 11 | 3.67 | +88 | +8.0 |
| WOUNDS ON THE RANKS | 23 | 23 | 11 | 3.67 | +574 | +52.2 |
| MOVE TO CHARGE COMPUTED | 23 | 18 | 10 | 3.33 | +2260 | +226.0 |
| THE RISK READS HIS RUN | 36 | 36 | 10 | 3.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 11 | 11 | 8 | 2.67 | +10 | +1.2 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 74 | 70 | 8 | 2.67 | +314 | +39.2 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 8 | 2.67 | +210 | +26.2 |
| STAY WORTH | 115 | 99 | 8 | 2.67 | +27 | +3.4 |
| NEXT CHARGE BY LIST | 13 | 11 | 7 | 2.33 | +1049 | +149.9 |
| SEARCH SPOT | 8 | 8 | 7 | 2.33 | +193 | +27.6 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 72 | 68 | 6 | 2.00 | +199 | +33.2 |
| FALLS SHORT | 77 | 55 | 6 | 2.00 | +126 | +20.9 |
| CASTING BLOCK | 5 | 5 | 5 | 1.67 | +41 | +8.3 |
| FEATURE BUFFS | 39 | 39 | 5 | 1.67 | +105 | +20.9 |
| MISSILES IN THE MOVE | 32 | 20 | 5 | 1.67 | +169 | +33.8 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +1 | +0.3 |
| FOUR ROUNDS | 11 | 9 | 4 | 1.33 | +41 | +10.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 7 | 7 | 3 | 1.00 | +10 | +3.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -6 | -2.1 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +183 | +61.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 13 | 13 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 12 | 11 | 3 | 1.00 | +9 | +2.9 |
| SUPPORT WORKED OUT | 12 | 11 | 3 | 1.00 | +9 | +2.9 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 6 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +131 | +65.6 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +27 | +13.7 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +218 | +109.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -59 | -29.5 |
| MAX FOR POSITIONING | 8 | 6 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +89 | +44.3 |
| SET UP BY THE SET | 3 | 3 | 2 | 0.67 | +63 | +31.6 |
| SHOT REPLANNED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 26 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +48 | +48.1 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.2 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -2.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +82 | +81.8 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +26 | +26.2 |
| HIS MOVE AND SHOT | 25 | 23 | 1 | 0.33 | +5 | +4.8 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +16 | +15.7 |
| MARCH CHECK | 4 | 4 | 1 | 0.33 | +60 | +59.9 |
| ONE OBJECTIVE FORMULA | 33 | 22 | 1 | 0.33 | +19 | +19.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +114 | +114.0 |
| RISK BY ARC | 5 | 4 | 1 | 0.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 78 | 65 | 1 | 0.33 | +8 | +7.5 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +26 | +26.2 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 8 | 7 | 1 | 0.33 | +72 | +72.4 |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARGE NOW FIRST | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| COVER ONCE | 23 | 11 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 20 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 30 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 7 | 7 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 156 | 156 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 7 | 0 | 0.00 | - | - |
| IDLE COST | 63 | 49 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 21 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 6 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 45 | 41 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | not checked | - | - | - | - |
| OVERRUNS AWAY | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 257 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 6 | 0 | 0.00 | - | - |
| SAME TERRAIN AS THE BOARD | 1 | not checked | - | - | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 256 | 252 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 256 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT REACTION | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 3.33 | 322.5 |
| ARMY TABLE | rule | 0.67 | 3.67 | 76.7 |
| JOB FIRST | gate | 2.00 | 2.33 | 211.8 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 59.2 |
| NO REASON | gate | - | 1.33 | 24.3 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.67 | 56.4 |
| CHAFF PASSED | rule | - | 0.33 | 2.0 |
| JOINT CHARGE NOW | rule | 0.33 | - | 33.4 |
| MARCH OF THE TABLE | rule | 0.33 | - | 59.0 |
| RULE SWITCHED OFF | gate | 0.33 | - | 553.0 |

### Plans: wfr-a92c160-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 490 | 93 | 19% |
| Mine | move | 34.7 | 93% | 2619 | 0 | 0% |
| Mine | shoot | 6.0 | 56% | 200 | 151 | 76% |
| Mine | support | 0.3 | 0% | 17 | 0 | 0% |
| Opponent | charge | 1.7 | 60% | 214 | 105 | 49% |
| Opponent | move | 38.7 | 96% | 2202 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 194 | 111 | 57% |

### Battle groups: wfr-a92c160-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 14 (11) | 14 | 0 | 0 | 55% | 1.6 | - | 0 (6) | 30 (5) | 14 (11) | - |
| Mine | Clean-up | 2 | 226 (2) | 0 | 226 | 49 | 100% | - | 316 (1) | - | 132 (1) | 226 (2) | - |
| Mine | Fast Hammer | 10 | 42 (10) | 42 | 0 | 60 | 60% | 4.2 | 79 (6) | 0 (1) | 0 (3) | 40 (7) | 48 (3) |
| Mine | Hammer | 9 | 32 (9) | 6 | 26 | 24 | 44% | 3.4 | 0 (2) | 14 (4) | 109 (3) | 32 (9) | - |
| Mine | Holder | 2 | 60 (2) | 0 | 60 | 0 | 100% | - | 119 (1) | 0 (1) | - | 0 (1) | 119 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 37 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 15 (8) | 0 | 15 | 28 | 75% | 5.5 | 31 (3) | 0 (4) | 0 (1) | 17 (7) | 0 (1) |
| Opponent | Character | 7 | 22 (7) | 22 | 0 | 14 | 14% | 2.2 | 0 (1) | 28 (4) | 40 (1) | 42 (4) | 0 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 13 (1) | 13 | 0 | 0 | 0% | 4.0 | - | 13 (1) | - | 13 (1) | - |
| Opponent | Hammer | 10 | 70 (10) | 13 | 57 | 12 | 50% | 1.6 | 15 (5) | 127 (4) | 68 (1) | 27 (5) | 101 (5) |
| Opponent | Shooter | 4 | 84 (4) | 26 | 57 | 22 | 0% | 1.8 | 77 (1) | 96 (2) | 64 (1) | 85 (3) | 79 (1) |
| Opponent | Wizard | 2 | 12 (2) | 12 | 0 | 0 | 0% | 4.0 | - | 12 (2) | - | 12 (2) | - |

### Charged fights: wfr-a92c160-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 182 | 137 | 1.0 | 1.5 | 137 | 0 | +137 | 1 of 2 | 2 of 2 | +274 | +0 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 121 | 91 | 1.0 | 1.3 | 91 | 0 | +91 | 2 of 3 | 2 of 3 | +274 | +0 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 420 | 1.0 | 1.0 | 420 | 0 | +420 | 1 of 1 | 1 of 1 | - | +420 |
| Opponent | Wood Elf Realms | 1 | 167 | 255 | 4.0 | 1.0 | 64 | 0 | +64 | 0 of 4 | 4 of 4 | - | +64 |
| **Opponent** | all armies | 3 | 112 | 225 | 1.7 | 1.0 | 135 | 0 | +135 | 1 of 5 | 5 of 5 | - | +135 |

### Effective charges: wfr-a92c160-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +274) | 0 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +85) | 0 | 0 | 1 (net +0) | 2 | 50% (1 of 2) |

### Charged fights, damage counted: wfr-a92c160-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 181 | 242 | +0 | 119 | 44 | +74 | +41.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 104 | 158 | +274 | 274 | 36 | +238 | +228.6 |
| Mine | All fights | 3 | 155 | 214 | +91 | 170 | 42 | +129 | +83.0 |
| Opponent | Effective (55-75%) | 1 | 125 | 85 | +85 | 85 | 0 | +85 | +68.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 102 | 52 | +0 | 35 | 0 | +35 | +34.0 |
| Opponent | No odds | 3 | 323 | 177 | +197 | 208 | 56 | +152 | +47.2 |
| Opponent | All fights | 5 | 239 | 134 | +135 | 149 | 33 | +115 | +48.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p2 | move | 19 | 7 (37%) | 5 (26%) | 2 (11%) | 10 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

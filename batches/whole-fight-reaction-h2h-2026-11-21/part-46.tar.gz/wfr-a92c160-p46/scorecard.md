# Doctrine scorecard: wfr-a92c160-p46

### Scorecard: wfr-a92c160-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1827 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 1 | 0 | 0 | 133 |
| L2029 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 2.5 | 1.0 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 337.5 |
| **Average** | | | Opponent | 0% | 2.0 | 2.5 | 2.5 | 2.0 | 0.5 | 0.0 | 0.0 | 151.5 |

### KPIs: wfr-a92c160-p46

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 7) | 0% (0 of 10) | 0% (0 of 17) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 100% (3 of 3); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 83% (5 of 6); on the table 83% | 91% (10 of 11); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 19) | 25% (2 of 8) | 7% (2 of 27) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 8) | 25% (2 of 8) | 12% (2 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 45% (5 of 11) | 0% (0 of 5) | 31% (5 of 16) |
| Points that never fought | lower | 31% (1234 of 3999) | 24% (972 of 3999) | 28% (2206 of 7998) |
|   infantry points that never fought | lower | 62% (519 of 836) | 29% (182 of 619) | 48% (701 of 1455) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (6 of 15) | 54% (7 of 13) | 46% (13 of 28) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (1642 of 3466) | 41% (1406 of 3430) | 44% (3048 of 6896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (32%) | 2.0 (100%) | 4.0 (48%) |
| MARCHED: its unit marched | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 3.0 (47%) | 0.0 (0%) | 3.0 (36%) |
| GONE: slain | 0.7 (11%) | 0.0 (0%) | 0.7 (8%) |
| NOT OFFERED: not in the cast list | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.3 | 0.7 | 0.7 | 3.3 |
| not cast | 6.7 | 5.7 | 8.3 | 2.0 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 4.0 (48%) | 1.0 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (12%) | 3.0 (36%) | 0.7 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (20%) | 0.3 (6%) | 0.7 (8%) | 0.3 (17%) | 1.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (12%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (70%) | 4.3 (76%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (7 of 10) | 14% (1 of 7) | 47% (8 of 17) |
|   cavalry | - | 50% (1 of 2) | 50% (1 of 2) |
|   character | - | 0% (0 of 5) | 0% (0 of 5) |
|   infantry | 70% (7 of 10) | - | 70% (7 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | 0.0 (0%) | 1.0 (50%) | 1.0 (33%) |
| NO TARGET IN RANGE | 0.3 (33%) | 0.7 (33%) | 1.0 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (67%) | 0.3 (17%) | 1.0 (33%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 2.3 | 0.3 | 86% | 7.8 pts | 18 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 3.3 | 3.0 |
| Charges that made contact a game | 2.0 | 2.3 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.21 contact (28 units) | 0.38 declared, 0.27 contact (26 units) | 0.33 declared, 0.24 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (1 of 2) | 67% (2 of 3) | 0% (0 of 1) | 50% (3 of 6) |
| Character in a unit | 25% (1 of 4) | 0% (0 of 1) | - | 20% (1 of 5) |
| Character on its own | 100% (2 of 2) | - | 60% (3 of 5) | 71% (5 of 7) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 50% (1 of 2) | - | 33% (1 of 3) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 12) | 16% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 12% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 83% (5 of 6); on the table 83% | - | 36% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 40% (2) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 40% (4 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 3) | - |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 100% (4 of 4) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 2.0 |
| Movement | Points that never moved of their own | 337.5 | 151.5 |
| Movement | Fights charged into per game | 2.5 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net +205 | 2 of 6, net -116 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 6, net +345 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 3 of 6, net +212 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.3 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (3 of 7) | 50% (1 of 2) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 1.7 / 0.0 | 0.7 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 442.7 | 270.0 |
| Combat | Points run down | 0.0 | 78.3 |
| Combat | Net points per charged fight, damage counted | +83 | +72 |
| Combat | Net per 100 charger points, damage counted | +34.9 | +26.1 |
| Combat | First round won (charged fights) | 80% | 67% |
| Combat | Net points per charged fight | +89 | +124 |
| Combat | Net points per supported fight / lone fight | -55 / +125 | +0 / +149 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 5 of 6 |
| Game | Points lost | 957.5 | 691.5 |
| Game | VP from objectives | 590.0 | 780.0 |
| Game | Lone holders (player turns) | 2.5 | 2.0 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -431 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1649
- Games not ended: 1 (L1827-1); findings 2, warnings 0

### Opponent rules: wfr-a92c160-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | -113.3 | 0.0 | 246.7 | 15.7 | +441.5 | 0.0 | 187.7 |
| ASSAILMENT BY POINTS | 1.3 | +3.0 | 0.0 | 180.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| CAST JOB | 0.3 | +0.5 | 0.0 | 180.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +240.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +16.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +10.0 | 0.0 | 0.0 | 0.3 | +37.2 | 0.0 | 77.7 |
| CHARGE LOSSES | 5.0 | -370.9 | 0.0 | 245.0 | 5.0 | -117.9 | 0.0 | 192.3 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 460.0 | 16.7 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 73.3 | 20.3 | +0.0 | 0.0 | 716.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 85.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +51.0 | 0.0 | 0.0 | 0.7 | +10.2 | 0.0 | 0.0 |
| COVER ONCE | 2.3 | -75.2 | 0.0 | 21.7 | 2.0 | -103.0 | 0.0 | 130.3 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 62.0 |
| EXACT ROUND | 0.3 | -3.9 | 68.3 | 0.0 | 2.0 | +5.8 | 301.7 | 18.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 68.3 | 0.0 | 2.0 | +11.6 | 481.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 0.7 | +10.8 | 0.0 | 0.0 | 13.0 | +177.0 | 0.0 | 445.3 |
| FEATURE BUFFS | 1.3 | +13.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.7 | +3.2 | 78.3 | 0.0 |
| FIVE ACTION | 43.7 | +3312.2 | 68.3 | 853.3 | 60.0 | +5464.4 | 481.7 | 1308.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 293.3 | 2.0 | +0.0 | 0.0 | 68.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +139.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.7 | +2.2 | 68.3 | 0.0 | 3.3 | +266.0 | 481.7 | 51.3 |
| FREED FROM HIS FIGHT | 5.7 | +0.0 | 0.0 | 138.3 | - | - | - | - |
| GOAL WALK | 10.7 | +1206.5 | 0.0 | 85.0 | 10.3 | +1477.8 | 0.0 | 384.7 |
| GUN FIGURES | 2.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 3.0 | +0.0 | 0.0 | 245.0 | 0.7 | +0.0 | 0.0 | 130.3 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 36.7 | - | - | - | - |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 116.7 | 1.7 | +0.0 | 0.0 | 68.3 |
| HIS MOVE AND SHOT | 0.3 | -0.1 | 0.0 | 0.0 | 1.3 | -12.7 | 0.0 | 62.0 |
| HIS MOVE AS HE DECIDES | 20.7 | +5.7 | 424.7 | 0.0 | 23.7 | +6.0 | 693.3 | 0.0 |
| HIS MOVE WHY | - | - | - | - | 31.3 | +0.0 | 0.0 | 656.7 |
| HIS ONE MOVE | 11.3 | +8.9 | 0.0 | 21.7 | 17.0 | +90.6 | 0.0 | 192.3 |
| HIS ONE QUARTER | - | - | - | - | 3.7 | +0.0 | 0.0 | 136.7 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 116.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 290.0 | 5.0 | +0.0 | 0.0 | 193.3 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 65.0 | 1.0 | +0.0 | 0.0 | 68.3 |
| HIS RUN AFTER OUR TURN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 10.0 | +145.3 | 0.0 | 108.3 | 21.7 | +289.7 | 0.0 | 772.7 |
| HIS SHOTS BY HIS RUN | 7.0 | +69.0 | 0.0 | 225.0 | 10.7 | +184.1 | 0.0 | 124.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| HIS TURN RUN | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 573.3 |
| HOLDER ASSIGNMENT | 7.3 | +821.2 | 0.0 | 0.0 | 5.7 | +724.9 | 0.0 | 286.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -1.5 | 0.0 | 0.0 | 2.7 | -58.8 | 481.7 | 18.0 |
| IDLE COST | 0.3 | -1.8 | 0.0 | 21.7 | 15.0 | -191.2 | 0.0 | 143.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +11.7 | 0.0 | 34.7 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 77.7 | 343.3 | 2.7 | +0.0 | 238.3 | 134.3 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.7 | 68.3 | 0.0 | 0.7 | +0.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +44.0 | 0.0 | 143.3 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +83.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +43.0 | 0.0 | 11.7 | 2.0 | +57.8 | 0.0 | 211.7 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.7 | +20.8 | 0.0 | 0.0 | 1.0 | +1.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.3 | +11.4 | 0.0 | 180.0 | 1.7 | +1.9 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -12.7 | 0.0 | 63.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.7 | +46.6 | 0.0 | 116.7 | 8.3 | +939.3 | 0.0 | 187.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.3 | +191.2 | 0.0 | 0.0 | 3.3 | +126.8 | 0.0 | 163.3 |
| NEXT CHARGE BY LIST | 0.3 | +6.7 | 0.0 | 116.7 | 4.0 | +551.0 | 0.0 | 68.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -11.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -6.7 | 68.3 | 0.0 | 2.3 | -249.0 | 460.0 | 18.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.3 | -0.4 | 0.0 | 40.0 |
| OFF BEST | 2.0 | -53.1 | 0.0 | 21.7 | 3.0 | -96.1 | 0.0 | 198.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 0.7 | -1.7 | 0.0 | 0.0 | 5.3 | -123.9 | 0.0 | 302.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +85.4 | 0.0 | 0.0 | 0.7 | +14.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +19.3 | 43.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +3.0 | 78.3 | 33.3 |
| PATHS CROSS | - | - | - | - | 1.0 | +20.1 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +21.5 | 0.0 | 180.0 | - | - | - | - |
| PLAN RESULT | 19.0 | +73.3 | 0.0 | 885.0 | 28.3 | +272.1 | 280.0 | 469.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| PROMISE BY ITS OWN SUM | 1.7 | -7.1 | 0.0 | 0.0 | 8.3 | -279.1 | 0.0 | 118.7 |
| QUARTER ODDS | 6.0 | +996.2 | 68.3 | 0.0 | 10.0 | +1881.3 | 0.0 | 136.7 |
| RANDOM MOVE BY FIGURES | 3.7 | +92.8 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +19.7 | 0.0 | 11.7 | 1.3 | -20.6 | 0.0 | 18.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 11.7 | 1.0 | +0.0 | 0.0 | 28.3 |
| REFORMS TO MEET IT | 0.7 | -13.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 160.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +20.3 | 68.3 | 0.0 | 2.7 | -22.7 | 460.0 | 51.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -22.0 | 100.0 | 16.7 |
| RUN DOWN | 0.7 | -2.2 | 68.3 | 0.0 | 1.0 | -5.0 | 258.3 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.3 | -242.7 | 0.0 | 286.7 |
| SET UP BY THE SET | 0.7 | +13.1 | 0.0 | 0.0 | 2.7 | +300.1 | 0.0 | 355.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +44.0 | 0.0 | 143.3 |
| SHOOTERS ON THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 3.0 | +7.8 | 0.0 | 0.0 | 9.7 | -32.2 | 0.0 | 124.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.3 | +50.6 | 0.0 | 43.3 | 0.3 | +40.0 | 0.0 | 28.3 |
| SPELL WORTH | 1.0 | +78.8 | 360.0 | 360.0 | 0.7 | +5.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 133.3 | 8.3 | +0.0 | 0.0 | 190.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -2.4 | 43.3 | 0.0 |
| STANDS STILL | 12.3 | +0.0 | 0.0 | 326.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 3.3 | -0.3 | 0.0 | 43.3 | 0.3 | +18.5 | 0.0 | 28.3 |
| STRIKE BY THE ODDS | 0.7 | +3.5 | 286.7 | 0.0 | 1.0 | +2.9 | 0.0 | 105.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +325.5 | 0.0 | 66.7 | 4.7 | +153.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| SUPPORT WORKED OUT | 8.3 | +325.5 | 0.0 | 66.7 | 4.7 | +153.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -10.6 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 130.3 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 58.3 | 4.0 | +0.0 | 0.0 | 163.3 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 36.7 | 3.0 | +0.0 | 0.0 | 163.3 |
| THE TABLE AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 18.3 | +0.0 | 0.0 | 315.0 | 29.3 | +0.0 | 0.0 | 628.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +71.6 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 19.7 | +199.9 | 0.0 | 531.7 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 1.0 | +7.6 | 0.0 | 143.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 116.7 | 1.7 | +0.0 | 0.0 | 56.7 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -41.6 | 0.0 | 68.0 |
| WHO FIGHTS | 0.3 | +0.9 | 68.3 | 0.0 | 0.7 | +18.2 | 0.0 | 18.0 |
| WHO HITS BACK | 0.3 | +72.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 1.0 | +0.7 | 0.0 | 51.3 |
| WHOLE FIGHT DANGER | 4.7 | -362.2 | 0.0 | 245.0 | 1.0 | -22.9 | 0.0 | 68.3 |
| WHOLE FIGHT REACTION | 2.0 | +228.2 | 0.0 | 481.7 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 0.7 | +18.4 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 133 | 133 | 98 | 32.67 | +0 | +0.0 |
| HIS MOVE WHY | 94 | 94 | 75 | 25.00 | +0 | +0.0 |
| ARMY TABLE | 101 | 101 | 68 | 22.67 | +827 | +12.2 |
| HOLDER ASSIGNMENT | 39 | 39 | 33 | 11.00 | +1985 | +60.1 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| HIS ONE MOVE | 85 | 85 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 311 | 306 | 21 | 7.00 | +1122 | +53.4 |
| THE TABLE AGAIN | 26 | 26 | 20 | 6.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 30 | 29 | 19 | 6.33 | +980 | +51.6 |
| OFF BEST | 15 | 15 | 15 | 5.00 | -448 | -29.8 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 30 | 30 | 12 | 4.00 | -858 | -71.5 |
| GOAL WALK | 63 | 60 | 11 | 3.67 | +1133 | +103.0 |
| SUPPORT ADDS | 39 | 38 | 10 | 3.33 | +126 | +12.6 |
| SUPPORT WORKED OUT | 39 | 38 | 10 | 3.33 | +126 | +12.6 |
| HIS SHOT LIST | 95 | 95 | 9 | 3.00 | +13 | +1.5 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 48 | 47 | 8 | 2.67 | +390 | +48.8 |
| IDLE COST | 46 | 31 | 7 | 2.33 | +38 | +5.5 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| NEXT CHARGE BY LIST | 13 | 12 | 7 | 2.33 | +597 | +85.3 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 6 | 6 | 6 | 2.00 | +38 | +6.4 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 5 | 1.67 | +278 | +55.7 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +19 | +3.8 |
| THE RISK READS HIS RUN | 26 | 26 | 5 | 1.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 17 | 16 | 5 | 1.67 | +231 | +46.1 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +142 | +35.4 |
| FOUR ROUNDS | 12 | 12 | 4 | 1.33 | +41 | +10.4 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +420 | +139.9 |
| HIS SHOTS BY HIS RUN | 53 | 51 | 3 | 1.00 | +20 | +6.7 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +0 | +0.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +60 | +20.1 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOT RISK POINTS | 38 | 37 | 3 | 1.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 59 | 46 | 3 | 1.00 | +5 | +1.5 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +721 | +360.5 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -25 | -12.7 |
| CHARGE LOSSES | 30 | 28 | 2 | 0.67 | +29 | +14.6 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -296 | -148.0 |
| EXACT ROUND | 7 | 7 | 2 | 0.67 | +3 | +1.4 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +35 | +17.5 |
| REDIRECT COUNTER | 7 | 3 | 2 | 0.67 | +85 | +42.3 |
| RISK BY ARC | 10 | 10 | 2 | 0.67 | +5 | +2.4 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +70 | +34.9 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| HARD STAY DROPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 9 | 9 | 1 | 0.33 | +3 | +2.8 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +5 | +5.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +250 | +250.0 |
| MISSILES IN THE MOVE | 5 | 4 | 1 | 0.33 | +1 | +1.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 9 | 9 | 1 | 0.33 | +3 | +2.8 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +3 | +2.8 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +64 | +64.5 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.33 | +21 | +20.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| SET UP BY THE SET | 10 | 9 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 11 | 10 | 1 | 0.33 | +16 | +16.2 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +1 | +1.2 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +156 | +156.3 |
| WOUNDS ON THE RANKS | 2 | 2 | 1 | 0.33 | +21 | +20.8 |
| CLOSES ON WHAT IT BEATS | 76 | 76 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| COVER ONCE | 13 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 41 | 31 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 11 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 9 | 9 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 7 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 5 | 4 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 6 | 6 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 50 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 26 | 26 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 26 | 26 | 0 | 0.00 | - | - |
| HOLD ODDS | 60 | 60 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 9 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEARER NOT NEEDED | 23 | 21 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 7 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 11 | 6 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 142 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 4 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 57 | 57 | 0 | 0.00 | - | - |
| STAY WORTH | 11 | 10 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 143 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.00 | 1.67 | 88.1 |
| JOB FIRST | gate | 1.33 | 2.67 | 33.7 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 3.33 | 71.5 |
| CHAFF PASSED | rule | 0.67 | - | 12.7 |
| CHARGE NOW FIRST | rule | - | 0.67 | 148.0 |
| NO REASON | gate | 0.67 | - | 13.8 |
| RULE SWITCHED OFF | gate | - | 0.33 | 15.7 |

### Plans: wfr-a92c160-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 22 | 73 | 334% |
| Mine | move | 17.7 | 87% | 919 | 0 | 0% |
| Mine | shoot | 0.7 | 0% | 12 | 0 | 0% |
| Opponent | charge | 2.7 | 38% | 373 | 272 | 73% |
| Opponent | join | 1.3 | 100% | 50 | 0 | 0% |
| Opponent | move | 24.0 | 92% | 1983 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 50% | 2.0 | 0 (2) | - | - | 0 (2) | - |
| Mine | Character | 5 | 46 (5) | 46 | 0 | 87 | 20% | 1.2 | 0 (1) | 215 (2) | 0 (1) | 93 (3) | 0 (1) |
| Mine | Clean-up | 2 | 151 (2) | 87 | 64 | 0 | 50% | 5.0 | 151 (2) | - | - | 697 (1) | 46 (1) |
| Mine | Fast Hammer | 1 | 182 (1) | 182 | 0 | 0 | 0% | 1.0 | - | 182 (1) | - | 182 (1) | - |
| Mine | Hammer | 5 | 21 (5) | 9 | 12 | 62 | 40% | 2.3 | 20 (2) | 41 (2) | 0 (1) | 27 (4) | 0 (1) |
| Mine | Holder | 3 | 50 (3) | 0 | 50 | 8 | 33% | 3.5 | 0 (1) | 93 (2) | - | 50 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 10 (3) | 10 | 0 | 20 | 0% | 2.0 | - | 13 (2) | - | 13 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 67 | 40% | 3.7 | 0 (3) | 0 (1) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | Character | 6 | 60 (6) | 60 | 0 | 21 | 17% | 2.4 | 67 (2) | 0 (3) | 118 (1) | 78 (5) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 37 (5) | 30 | 8 | 71 | 20% | 2.5 | - | 12 (3) | 88 (2) | 37 (5) | - |
| Opponent | Hammer | 2 | 79 (2) | 24 | 55 | 0 | 0% | 4.5 | - | 79 (2) | - | 70 (1) | 84 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 24 | 0% | 2.5 | 0 (1) | - | 0 (1) | - | 0 (2) |

### Charged fights: wfr-a92c160-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 1 | 0 | 900 | 4.0 | 1.2 | 225 | 165 | +60 | 1 of 4 | 3 of 4 | -55 | +98 |
| Mine | Skaven | 1 | 0 | 205 | 1.0 | 1.0 | 205 | 0 | +205 | 0 of 1 | 1 of 1 | - | +205 |
| **Mine** | all armies | 2 | 0 | 552 | 2.5 | 1.2 | 221 | 132 | +89 | 1 of 5 | 4 of 5 | -55 | +125 |
| Opponent | Vampire Counts | 1 | 0 | 345 | 3.0 | 1.3 | 115 | 78 | +37 | 2 of 3 | 1 of 3 | +0 | +56 |
| Opponent | Warriors of Chaos | 1 | 0 | 635 | 3.0 | 1.0 | 212 | 0 | +212 | 3 of 3 | 3 of 3 | - | +212 |
| **Opponent** | all armies | 2 | 0 | 490 | 3.0 | 1.2 | 163 | 39 | +124 | 5 of 6 | 4 of 6 | +0 | +149 |

### Effective charges: wfr-a92c160-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 1 (net +205) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 3 | 2 (net -116) | 0 | 1 (net +345) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +212) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 38 | 205 | +205 | 205 | 3 | +202 | +531.1 |
| Mine | No odds | 4 | 288 | 226 | +60 | 225 | 172 | +53 | +18.6 |
| Mine | All fights | 5 | 238 | 222 | +89 | 221 | 138 | +83 | +34.9 |
| Opponent | Long shot (under 50%) | 2 | 77 | 343 | -116 | 0 | 116 | -116 | -151.3 |
| Opponent | Effective (55-75%) | 1 | 186 | 235 | +345 | 345 | 0 | +345 | +185.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 437 | 363 | +212 | 244 | 137 | +106 | +24.3 |
| Opponent | All fights | 6 | 275 | 335 | +124 | 179 | 107 | +72 | +26.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p46 | move | 11 | 3 (27%) | 2 (18%) | 1 (9%) | 7 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

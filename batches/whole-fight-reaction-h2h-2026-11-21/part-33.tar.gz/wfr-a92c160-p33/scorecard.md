# Doctrine scorecard: wfr-a92c160-p33

### Scorecard: wfr-a92c160-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1527 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 100% | - | 3.0 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 200.0 |
| **Average** | | | Opponent | 0% | - | - | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: wfr-a92c160-p33

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 7) | 0% (0 of 6) | 0% (0 of 13) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 75% (6 of 8) | 75% (6 of 8) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 75% (6 of 8) | 75% (6 of 8) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 45% (897 of 2000) | 50% (998 of 1999) | 47% (1895 of 3999) |
|   infantry points that never fought | lower | 100% (657 of 657) | 48% (136 of 283) | 84% (793 of 940) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (3 of 6) | 83% (5 of 6) | 67% (8 of 12) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 42% (657 of 1580) | 84% (1354 of 1608) | 63% (2011 of 3188) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (100%) | 0.7 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 0.7 | 0.7 | 0.3 | 2.0 | 0.3 | 0.0 |
| not cast | 4.7 | 2.0 | 0.3 | 0.7 | 1.7 | 12.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.7 (100%) | 1.3 (80%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (100%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (10 of 17) | - | 59% (10 of 17) |
|   cavalry | 88% (7 of 8) | - | 88% (7 of 8) |
|   infantry | 0% (0 of 4) | - | 0% (0 of 4) |
|   war machine | 60% (3 of 5) | - | 60% (3 of 5) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| FLEEING: it fled or was fleeing | 0.3 (14%) | - | 0.3 (14%) |
| IN COMBAT: it fought this turn or the last | 0.3 (14%) | - | 0.3 (14%) |
| MOVED: a war machine that moved | 0.3 (14%) | - | 0.3 (14%) |
| NO TARGET IN RANGE | 1.3 (57%) | - | 1.3 (57%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 1.0 | 57% | 0.9 pts | 2 pts |
| war machine | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 0.3 | 1.0 |
| Charges that made contact a game | 1.7 | 0.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.22 contact (23 units) | 0.04 declared, 0.04 contact (27 units) | 0.12 declared, 0.12 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Character on its own | - | 0% (0 of 2) | 50% (1 of 2) | 25% (1 of 4) |
| Infantry | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 45% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 50% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 50% (2) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 0% (0 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 5) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 100% (3 of 3) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 200.0 | 0.0 |
| Movement | Fights charged into per game | 4.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 4, net +134 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (2 of 7) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 1.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.0 / 0.0 | 0.7 / 0.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 367.0 | 33.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +175 | +0 |
| Combat | Net per 100 charger points, damage counted | +58.2 | +0.0 |
| Combat | First round won (charged fights) | 75% | 100% |
| Combat | Net points per charged fight | +230 | +0 |
| Combat | Net points per supported fight / lone fight | - / +230 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 0 of 1 |
| Game | Points lost | 280.0 | 1001.0 |
| Game | VP from objectives | 500.0 | 500.0 |

- Mine won / drew / lost: 1 / 0 / 0 of 1 ended games (of 3); mean margin (Mine - Opponent) +821 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1281
- Games not ended: 2 (L1527-1, L1723-1); findings 2, warnings 0

### Opponent rules: wfr-a92c160-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.0 | +155.7 | 0.0 | 0.0 | 10.3 | +418.1 | 0.0 | 203.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 1.0 | +8.8 | 0.0 | 66.7 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.7 | +3.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +47.4 | 0.0 | 15.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +19.9 | 0.0 | 278.0 |
| CHARGE LOSSES | 4.7 | -115.9 | 0.0 | 0.0 | 5.3 | -172.7 | 0.0 | 242.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 15.0 | 0.0 | 0.3 | +0.0 | 33.3 | 84.7 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 98.0 |
| COVER ONCE | 8.3 | -362.6 | 0.0 | 66.7 | 5.0 | -484.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +9.7 | 233.3 | 0.0 | 0.7 | +5.9 | 33.3 | 109.7 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 15.0 | 0.0 | 0.7 | +0.0 | 33.3 | 109.7 |
| FALLS SHORT | - | - | - | - | 9.7 | +145.2 | 0.0 | 208.3 |
| FEATURE BUFFS | 0.7 | +13.9 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +1.1 | 33.3 | 84.7 |
| FIVE ACTION | 41.0 | +2500.5 | 318.0 | 200.0 | 38.0 | +2416.6 | 33.3 | 729.3 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 193.3 |
| FOLLOW UP WEIGHED | 0.3 | +70.7 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +183.6 | 318.0 | 0.0 | 0.7 | +47.5 | 33.3 | 109.7 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -4.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.0 | +631.8 | 0.0 | 0.0 | 5.0 | +414.2 | 0.0 | 98.0 |
| GUN MASK | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 242.3 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 193.3 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 193.3 |
| HIS MOVE AND SHOT | 1.3 | -7.7 | 0.0 | 0.0 | 2.0 | -44.3 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 17.3 | +3.7 | 407.0 | 0.0 | 12.3 | +3.3 | 26.7 | 0.0 |
| HIS MOVE WHY | 4.7 | +0.0 | 0.0 | 0.0 | 17.3 | +0.0 | 0.0 | 322.3 |
| HIS ONE MOVE | 10.0 | +44.8 | 0.0 | 0.0 | 12.0 | -83.5 | 0.0 | 218.3 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 14.0 | +64.8 | 0.0 | 66.7 | 15.0 | +307.6 | 0.0 | 105.0 |
| HIS SHOTS BY HIS RUN | 6.0 | +19.5 | 0.0 | 0.0 | 16.0 | +119.0 | 0.0 | 223.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +10.7 | 33.3 | 84.7 |
| HIS TURN RUN | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 5.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 4.0 | +434.6 | 0.0 | 0.0 | 4.3 | +531.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -56.5 | 124.7 | 0.0 | 0.3 | -21.6 | 33.3 | 84.7 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +16.2 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 10.7 | -139.5 | 0.0 | 307.3 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 60.0 | 278.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.1 | 193.3 | 0.0 | 0.7 | +0.3 | 33.3 | 109.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -49.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -19.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +46.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | - | - | - | - | 3.0 | +121.9 | 0.0 | 55.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +19.5 | 0.0 | 0.0 | 2.0 | +9.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.3 | +19.8 | 0.0 | 0.0 | 2.3 | +7.8 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 49.0 | 25.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +343.8 | 0.0 | 0.0 | 7.3 | +634.4 | 0.0 | 193.3 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +141.1 | 0.0 | 0.0 | 3.3 | +145.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +243.0 | 0.0 | 0.0 | 4.0 | +367.7 | 0.0 | 193.3 |
| NO DOUBLE ROUNDS | 1.3 | -35.7 | 233.3 | 0.0 | 0.3 | -0.4 | 33.3 | 84.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.3 | -21.2 | 0.0 | 33.3 | 1.3 | -141.4 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -30.2 | 0.0 | 0.0 | 3.7 | -66.5 | 0.0 | 193.3 |
| ONE OBJECTIVE FORMULA | 1.3 | +9.0 | 0.0 | 0.0 | 1.0 | +43.4 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +14.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +1.7 | 193.3 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| PLAN RESULT | 14.7 | +318.0 | 471.3 | 126.7 | 13.3 | +0.0 | 33.3 | 734.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.3 | -95.0 | 0.0 | 0.0 | 8.0 | -393.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 8.0 | +782.8 | 0.0 | 0.0 | 3.0 | +651.3 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +8.9 | 0.0 | 0.0 | 3.0 | +327.3 | 0.0 | 55.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +12.8 | 26.7 | 84.7 |
| REFORMS TO MEET IT | 1.0 | -15.8 | 0.0 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | +124.2 | 318.0 | 0.0 | 0.7 | +79.8 | 33.3 | 109.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -16.3 | 33.3 | 84.7 |
| RUN DOWN | - | - | - | - | 0.7 | -3.4 | 33.3 | 109.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | -0.0 | 0.0 | 0.0 | 1.0 | +31.4 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.7 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -51.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +76.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 66.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 6.0 | -31.5 | 0.0 | 0.0 | 11.0 | -128.5 | 0.0 | 193.3 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 4.7 | +77.1 | 0.0 | 100.0 | 1.3 | +2.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 303.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 15.0 | +0.0 | 0.0 | 200.0 | 3.3 | +0.0 | 0.0 | 15.0 |
| STAY WORTH | 5.0 | +1.5 | 0.0 | 233.3 | 1.3 | +2.4 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 193.3 |
| SUPPORT ADDS | 2.3 | +135.0 | 0.0 | 0.0 | 4.3 | +350.3 | 0.0 | 70.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 25.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.3 | +135.0 | 0.0 | 0.0 | 4.3 | +350.3 | 0.0 | 70.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -55.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 193.3 |
| THE ROW KEEPS ITS WAY | - | - | - | - | 1.3 | +0.0 | 0.0 | 25.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 1.3 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 17.7 | +0.0 | 0.0 | 66.7 | 21.3 | +0.0 | 0.0 | 322.3 |
| TIED UP BY THE SUM | 1.0 | +104.3 | 40.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 16.0 | +251.4 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | - | - | - | - | 0.3 | -1.7 | 0.0 | 25.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.3 | -2.8 | 84.7 | 0.0 | 0.7 | +20.4 | 0.0 | 50.0 |
| WHO HITS BACK | 0.7 | +72.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +0.0 | 84.7 | 0.0 | 0.3 | +3.5 | 0.0 | 25.0 |
| WHOLE FIGHT DANGER | 0.7 | -95.7 | 0.0 | 0.0 | 0.7 | -57.5 | 0.0 | 49.0 |
| WHOLE FIGHT REACTION | 0.7 | +2.9 | 169.3 | 60.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +2.3 | 0.0 | 0.0 | 1.0 | +7.2 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 89 | 89 | 68 | 22.67 | +0 | +0.0 |
| ARMY TABLE | 52 | 52 | 44 | 14.67 | +1830 | +41.6 |
| HIS MOVE WHY | 66 | 66 | 44 | 14.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| HOLDER ASSIGNMENT | 25 | 25 | 21 | 7.00 | +1884 | +89.7 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| PROMISE BY ITS OWN SUM | 40 | 40 | 18 | 6.00 | -1464 | -81.4 |
| HIS ONE MOVE | 66 | 66 | 17 | 5.67 | +0 | +0.0 |
| FIVE ACTION | 237 | 227 | 16 | 5.33 | +1013 | +63.3 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| HIS SHOT LIST | 87 | 82 | 14 | 4.67 | +45 | +3.2 |
| MOVE TO CHARGE COMPUTED | 35 | 32 | 12 | 4.00 | +331 | +27.6 |
| THE TABLE AGAIN | 16 | 16 | 12 | 4.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 66 | 60 | 11 | 3.67 | +7 | +0.6 |
| THE RISK READS HIS RUN | 16 | 16 | 11 | 3.67 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| OFF BEST | 8 | 8 | 8 | 2.67 | -488 | -60.9 |
| FOUR ROUNDS | 7 | 7 | 7 | 2.33 | +432 | +61.8 |
| GOAL WALK | 39 | 39 | 7 | 2.33 | +474 | +67.7 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 40 | 26 | 5 | 1.67 | +13 | +2.6 |
| SUPPORT ADDS | 20 | 20 | 5 | 1.67 | +256 | +51.3 |
| SUPPORT WORKED OUT | 20 | 20 | 5 | 1.67 | +256 | +51.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 30 | 28 | 4 | 1.33 | +1217 | +304.4 |
| NEXT CHARGE BY LIST | 19 | 19 | 4 | 1.33 | +300 | +74.9 |
| QUARTER ODDS | 33 | 33 | 4 | 1.33 | +202 | +50.5 |
| RISK BY ARC | 7 | 7 | 4 | 1.33 | +59 | +14.6 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| CHARGE NOW FIRST | 3 | 3 | 3 | 1.00 | -88 | -29.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 32 | 27 | 3 | 1.00 | +48 | +16.1 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +0 | +0.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +17 | +5.8 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +94 | +31.4 |
| SHOT RISK POINTS | 51 | 48 | 3 | 1.00 | +46 | +15.2 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +27 | +9.1 |
| CHAFF IN THE MOVE | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +60 | +29.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MISSILES IN THE MOVE | 9 | 5 | 2 | 0.67 | +26 | +13.2 |
| REDIRECT COUNTER | 10 | 10 | 2 | 0.67 | +91 | +45.5 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +207 | +103.4 |
| WHAT THE JOINER ADDS | 3 | 3 | 2 | 0.67 | +59 | +29.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +196 | +98.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +212 | +212.2 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +31 | +31.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 5 | 5 | 1 | 0.33 | +27 | +27.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +137 | +136.9 |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| SHOTS AFTER THE MOVES | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -20 | -20.3 |
| TIME ON OUR SIDE | 48 | 37 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 2 | 2 | 1 | 0.33 | +2 | +2.5 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 3 | 3 | 0 | 0.00 | - | - |
| CAST JOB | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 54 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 29 | 21 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 24 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 29 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 16 | 16 | 0 | 0.00 | - | - |
| HIS TURN RUN | 17 | 17 | 0 | 0.00 | - | - |
| HOLD ODDS | 31 | 31 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 11 | 7 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 25 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 10 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 7 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 84 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 2 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 6 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 18 | 14 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 17 | 14 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 55 | 51 | 0 | 0.00 | - | - |
| STAY WORTH | 19 | 15 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 4 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 4 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 4 | not checked | - | - | - | - |
| THE TABLE BINDS | 117 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 4.00 | 81.4 |
| JOB FIRST | gate | 1.00 | 1.33 | 66.0 |
| ARMY TABLE | rule | 0.33 | 1.33 | 32.9 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 29.5 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 1.0 |
| NO REASON | gate | 0.33 | - | 25.8 |
| SUPPORT NARROWED | rule | 0.33 | - | 20.3 |

### Plans: wfr-a92c160-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 100% | 144 | 318 | 221% |
| Mine | move | 12.3 | 97% | 741 | 0 | 0% |
| Mine | shoot | 1.0 | 0% | 20 | 0 | 0% |
| Opponent | charge | 0.7 | 0% | 54 | 0 | 0% |
| Opponent | join | 1.3 | 100% | 47 | 0 | 0% |
| Opponent | move | 10.3 | 97% | 586 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 3 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 100% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.0 | 44% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 3 | 119 (3) | 119 | 0 | 0 | 0% | 3.0 | 129 (2) | 96 (1) | - | 129 (2) | 96 (1) |
| Mine | Hammer | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 50% | 3.5 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Opponent | Character | 3 | 0 (3) | 0 | 0 | 83 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Opponent | Clean-up | 2 | 25 (2) | 25 | 0 | 100 | 0% | 3.0 | - | 25 (2) | - | 0 (1) | 39 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1101 | 4.0 | 1.0 | 275 | 45 | +230 | 2 of 4 | 3 of 4 | - | +230 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |

### Effective charges: wfr-a92c160-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 2 (net +327) | 2 (net +134) | 0 | 0 | 0% (0 of 4) |

### Charged fights, damage counted: wfr-a92c160-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 323 | 367 | +327 | 417 | 201 | +216 | +66.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 277 | 60 | +134 | 134 | 0 | +134 | +48.2 |
| Mine | All fights | 4 | 300 | 214 | +230 | 275 | 101 | +175 | +58.2 |
| Opponent | No odds | 1 | 254 | 80 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 1 | 254 | 80 | +0 | 0 | 0 | +0 | +0.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p33 | move | 14 | 2 (14%) | 2 (14%) | 1 (7%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

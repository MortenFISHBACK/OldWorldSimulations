# Doctrine scorecard: wfr-a92c160-p32

### Scorecard: wfr-a92c160-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 291 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 8 | 2 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 110 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 0 | 1 | 0 | 0 | 314 |
| **Average** | | | Mine | 33% | 4.0 | 2.0 | 2.0 | 1.3 | 0.0 | 0.0 | 0.0 | 202.7 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 3.7 | 2.0 | 0.3 | 0.0 | 0.0 | 141.3 |

### KPIs: wfr-a92c160-p32

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 16) | 3% (1 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 100% (3 of 3); on the table 100% | 75% (6 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 18) | 38% (9 of 24) | 21% (9 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 13) | 38% (9 of 24) | 24% (9 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (5 of 10) | 50% (5 of 10) |
| Points that never fought | lower | 41% (2434 of 6000) | 56% (3381 of 6000) | 48% (5815 of 12000) |
|   infantry points that never fought | lower | 74% (976 of 1315) | 62% (570 of 921) | 69% (1546 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (11 of 25) | 84% (27 of 32) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 50% (1 of 2); 0.3 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 20% (2 of 10); 1.7 uses a game | 0.0 uses a game | 20% (2 of 10); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 41% (2357 of 5720) | 78% (4537 of 5830) | 60% (6894 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (33%) | 2.3 (47%) | 4.3 (39%) |
| MARCHED: its unit marched | 2.0 (33%) | 2.7 (53%) | 4.7 (42%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.0 (0%) | 0.7 (6%) |
| GONE: slain | 1.0 (17%) | 0.0 (0%) | 1.0 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.3 | 2.7 | 3.0 | 0.3 | 1.3 |
| not cast | 4.0 | 2.7 | 3.3 | 11.0 | 1.7 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (100%) | 0.0 (0%) | 4.3 (39%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (42%) | 1.0 (60%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.7 (6%) | 0.3 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.0 (25%) | 0.0 (0%) | 1.0 (30%) | 1.0 (9%) | 0.0 (0%) | 2.3 (10%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (75%) | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.7 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 60% (3 of 5) | - | 60% (3 of 5) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 67% (2 of 3) | - | 67% (2 of 3) |
| it fought by the end of its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 33% (1 of 3) | - | 33% (1 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (55 of 93) | 68% (19 of 28) | 61% (74 of 121) |
|   cavalry | 75% (9 of 12) | 80% (12 of 15) | 78% (21 of 27) |
|   character | 26% (8 of 31) | 0% (0 of 5) | 22% (8 of 36) |
|   infantry | 63% (19 of 30) | 88% (7 of 8) | 68% (26 of 38) |
|   war machine | 95% (19 of 20) | - | 95% (19 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (26%) | 1.0 (33%) | 4.3 (28%) |
| CHARGED: it charged | 1.7 (13%) | 2.0 (67%) | 3.7 (23%) |
| IN COMBAT: it fought this turn or the last | 1.0 (8%) | 0.0 (0%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (34%) | 0.0 (0%) | 4.3 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (11%) | 0.0 (0%) | 1.3 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 1.7 | 86% | 4.2 pts | 52 pts |
| character | 4.3 | 1.0 | 85% | 8.8 pts | 38 pts |
| infantry | 14.7 | 2.3 | 84% | 5.5 pts | 81 pts |
| war machine | 6.3 | 2.7 | 79% | 11.5 pts | 73 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 5.3 | 4.0 |
| Charges that made contact a game | 2.0 | 2.3 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.23 contact (22 units) | 0.70 declared, 0.30 contact (23 units) | 0.49 declared, 0.27 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (7 of 15) | 100% (2 of 2) | - | 53% (9 of 17) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | 75% (3 of 4) | 50% (2 of 4) | 29% (2 of 7) | 47% (7 of 15) |
| Infantry | 92% (11 of 12) | 50% (1 of 2) | - | 86% (12 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 60% (3 of 5); on the table 60% | 0% (0 of 18) | 41% | 44% (11 of 25) | 100% (2 of 2); 3.3 uses a game | 20% (2 of 10); 1.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 77% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 29% | 83% (10 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 63% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 50% (2) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 20% (1 of 5) | 8% (1 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (18 of 32) | 0% (0 of 9) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.3 | 2.0 |
| Movement | Points that never moved of their own | 202.7 | 141.3 |
| Movement | Fights charged into per game | 2.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +163 | 1 of 2, net +470 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (20 of 38) | 80% (16 of 20) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (13 of 19) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.3 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 60.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.7 / 0.0 | 1.3 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 137.0 | 562.7 |
| Combat | Points run down | 0.0 | 23.3 |
| Combat | Net points per charged fight, damage counted | +103 | +203 |
| Combat | Net per 100 charger points, damage counted | +28.0 | +68.5 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +97 | +210 |
| Combat | Net points per supported fight / lone fight | - / +97 | - / +210 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 4 of 7 |
| Game | Points lost | 626.3 | 556.0 |
| Game | VP from objectives | 803.3 | 480.0 |
| Game | Lone holders (player turns) | 4.0 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +282 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1182
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 26.0 | +368.9 | 0.0 | 47.7 | 27.7 | -575.8 | 0.0 | 124.7 |
| BACKUP TARGETS | 0.3 | +2.2 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.7 | +3.5 | 73.7 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.0 | 23.3 | - | - | - | - |
| CANNON PLANNED TARGET | 6.3 | +26.3 | 114.0 | 140.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.3 | +11.8 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 133.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +66.5 | 0.0 | 163.3 | 1.0 | +25.6 | 0.0 | 89.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -4.9 | 0.0 | 0.0 | 0.3 | -1.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -519.0 | 0.0 | 228.7 | 19.7 | -982.1 | 0.0 | 565.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 202.0 | 147.3 | 3.0 | +0.0 | 133.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 47.7 | 6.3 | +0.0 | 0.0 | 56.7 |
| CONVEYANCE SEARCH | 1.3 | +262.1 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 9.0 | -490.6 | 0.0 | 235.0 | 6.7 | -542.5 | 0.0 | 105.7 |
| DENIED BY THE FIGHT | 0.3 | -4.3 | 36.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -0.8 | 83.3 | 147.3 | 0.3 | -57.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +122.1 | 108.7 | 0.0 | 0.3 | +33.8 | 147.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.3 | +81.0 | 180.0 | 41.7 |
| EXACT ROUND | 0.7 | +2.8 | 48.0 | 0.0 | 3.0 | +32.0 | 437.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +5.3 | 93.3 | 0.0 | 2.7 | +13.3 | 156.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.7 | +236.3 | 0.0 | 439.3 |
| FIGHT TO THE END | - | - | - | - | 1.3 | +5.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 97.3 | +5501.1 | 679.0 | 1377.3 | 71.7 | +4545.1 | 570.7 | 832.3 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 228.7 | 5.3 | +0.0 | 0.0 | 198.3 |
| FOLLOW UP WEIGHED | 0.3 | +32.5 | 0.0 | 0.0 | 0.3 | +46.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +229.0 | 291.7 | 147.3 | 4.3 | +309.1 | 437.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 190.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +7.8 | 0.0 | 147.3 | - | - | - | - |
| GIVES UP | 0.3 | -4.7 | 48.0 | 0.0 | 0.7 | -17.5 | 156.7 | 0.0 |
| GOAL WALK | 5.7 | +249.6 | 0.0 | 0.0 | 6.0 | +190.3 | 0.0 | 41.7 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 23.3 | - | - | - | - |
| GUN MASK | 2.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 36.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 95.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 228.7 | 12.0 | +0.0 | 0.0 | 489.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 133.3 | 4.0 | +0.0 | 0.0 | 38.7 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 115.0 |
| HIS MOVE AND SHOT | 2.0 | -14.5 | 0.0 | 0.0 | 4.0 | -24.1 | 0.0 | 18.3 |
| HIS MOVE AS HE DECIDES | 39.3 | +7.7 | 469.7 | 0.0 | 39.7 | +11.3 | 634.7 | 0.0 |
| HIS MOVE WHY | 27.0 | +0.0 | 0.0 | 527.0 | 8.3 | +0.0 | 0.0 | 240.3 |
| HIS ONE MOVE | 23.0 | +17.0 | 0.0 | 118.0 | 23.7 | -56.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 47.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 190.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 95.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.7 | +1149.2 | 0.0 | 724.0 | 42.0 | +1006.6 | 0.0 | 472.3 |
| HIS SHOTS BY HIS RUN | 37.7 | +847.6 | 0.0 | 651.3 | 50.0 | +911.8 | 0.0 | 678.7 |
| HIS TURN DENIED | 0.3 | +7.6 | 36.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 152.3 |
| HOLDER ASSIGNMENT | 11.7 | +858.4 | 0.0 | 0.0 | 4.7 | +384.0 | 0.0 | 85.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -60.9 | 291.7 | 147.3 | 3.7 | -136.3 | 437.3 | 0.0 |
| IDLE COST | - | - | - | - | 10.0 | -129.8 | 0.0 | 256.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | -54.8 | 0.0 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +16.6 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.3 | +0.0 | 161.3 | 113.0 | 6.0 | +0.0 | 316.3 | 118.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +6.4 | 67.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 2.0 | +2.9 | 280.7 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +3.5 | 0.0 | 137.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +49.5 | 0.0 | 0.0 | 0.7 | +20.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +10.0 | 0.0 | 0.0 | 0.7 | +31.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.3 | +25.9 | 0.0 | 0.0 | 0.3 | +18.9 | 0.0 | 38.7 |
| MARCH OVER CASTS | 1.3 | +66.4 | 0.0 | 133.3 | 1.3 | +14.9 | 0.0 | 38.7 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.0 | +2.7 | 0.0 | 0.0 | 1.7 | +122.1 | 0.0 | 38.7 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +69.9 | 0.0 | 54.0 | 3.7 | +84.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.3 | +49.7 | 0.0 | 320.7 | 5.7 | +91.7 | 0.0 | 38.7 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.7 | +577.4 | 0.0 | 0.0 | 4.7 | +494.9 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +290.2 | 0.0 | 0.0 | 7.3 | +291.5 | 0.0 | 199.7 |
| NEXT CHARGE BY LIST | 2.7 | +220.1 | 0.0 | 0.0 | 3.7 | +439.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -111.1 | 291.7 | 147.3 | 4.0 | -177.6 | 437.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.0 | -1.2 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -206.3 | 141.3 | 23.3 | 4.3 | -205.6 | 0.0 | 77.3 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -164.1 | 0.0 | 133.3 | 4.3 | -71.5 | 0.0 | 115.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +85.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -20.5 | 0.0 | 0.0 | 0.7 | +56.7 | 0.0 | 67.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 1.0 | +42.1 | 23.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +4.1 | 160.3 | 0.0 | 1.0 | +11.2 | 133.3 | 0.0 |
| PLAN RESULT | 44.0 | +602.3 | 141.3 | 1218.7 | 37.3 | +281.5 | 739.0 | 612.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -288.3 | 0.0 | 0.0 | 6.7 | -101.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.0 | -5.6 | 73.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 25.0 | +2557.5 | 41.7 | 562.0 | 19.7 | +2433.2 | 147.3 | 18.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +44.6 | 0.0 | 56.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 18.3 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +39.0 | 109.3 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -31.7 | 0.0 | 0.0 | 1.7 | -12.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +47.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +5.8 | 202.0 | 0.0 | 4.0 | -75.7 | 290.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -16.4 | 115.0 | 0.0 | 2.0 | -41.6 | 266.7 | 0.0 |
| RUN DOWN | 2.3 | -97.8 | 235.0 | 147.3 | 3.7 | -20.1 | 414.0 | 0.0 |
| SEARCH SPOT | 1.0 | +27.4 | 0.0 | 0.0 | 0.3 | +5.9 | 0.0 | 0.0 |
| SECOND LOOK | 1.0 | +48.6 | 141.3 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +61.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -186.8 | 0.0 | 0.0 | 0.3 | -5.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +188.4 | 0.0 | 0.0 | 1.3 | -7.9 | 67.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 194.0 | 2.7 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +44.2 | 0.0 | 0.0 | 0.7 | +14.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -5.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.7 | -226.7 | 0.0 | 324.0 | 26.3 | -307.7 | 0.0 | 491.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.0 | +369.4 | 0.0 | 194.0 | 5.7 | +112.7 | 0.0 | 74.7 |
| SPELL SETS UP CHARGE | 0.3 | +60.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.7 | +58.6 | 266.7 | 266.7 | 1.0 | +3.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.9 | 0.0 | 0.0 | 0.7 | -10.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 181.0 | 8.3 | +0.0 | 0.0 | 204.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -2.5 | 266.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 133.3 | 0.0 |
| STANDS STILL | 49.3 | +0.0 | 387.3 | 388.0 | 18.3 | +0.0 | 133.3 | 207.3 |
| STAY WORTH | 25.3 | -39.6 | 235.3 | 332.3 | 7.3 | +21.8 | 133.3 | 38.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +69.9 | 0.0 | 0.0 | 5.7 | +805.8 | 0.0 | 18.3 |
| SUPPORT NARROWED | 1.0 | +0.0 | 103.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +69.9 | 0.0 | 0.0 | 5.7 | +805.8 | 0.0 | 18.3 |
| SURE REACH TOGETHER | 0.7 | +4.1 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.4 | 0.0 | 50.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 47.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 67.0 |
| THE ROW READS HIS LAST RUN | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 615.0 | 31.7 | +0.0 | 0.0 | 417.3 |
| TIED UP BY THE SUM | 1.7 | +218.8 | 224.7 | 147.3 | 1.3 | +124.0 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 49.3 | +547.0 | 73.3 | 314.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.7 | +0.0 | 0.0 | 147.3 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +46.7 | 0.0 | 38.7 |
| WHOLE FIGHT DANGER | 3.7 | -156.3 | 0.0 | 228.7 | 3.0 | -527.1 | 0.0 | 134.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +83.6 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 5.0 | +373.9 | 18.3 | 511.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +152.0 | 0.0 | 134.0 |

### Rule changes: wfr-a92c160-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 237 | 237 | 180 | 60.00 | +0 | +0.0 |
| ARMY TABLE | 161 | 161 | 109 | 36.33 | +1137 | +10.4 |
| HIS MOVE WHY | 106 | 106 | 59 | 19.67 | +0 | +0.0 |
| HIS SHOT LIST | 239 | 223 | 54 | 18.00 | +772 | +14.3 |
| HIS SHOTS BY HIS RUN | 263 | 248 | 45 | 15.00 | +413 | +9.2 |
| HOLDER ASSIGNMENT | 49 | 49 | 42 | 14.00 | +2644 | +63.0 |
| LEGAL CHARGES ONLY | 37 | 37 | 37 | 12.33 | +0 | +0.0 |
| HIS ONE MOVE | 140 | 135 | 36 | 12.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -1236 | -47.5 |
| SHOT RISK POINTS | 150 | 142 | 20 | 6.67 | +621 | +31.1 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| FIVE ACTION | 507 | 482 | 16 | 5.33 | +653 | +40.8 |
| QUARTER ODDS | 134 | 123 | 16 | 5.33 | +2118 | +132.4 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 13 | 4.33 | -1169 | -90.0 |
| TIME ON OUR SIDE | 148 | 131 | 13 | 4.33 | +60 | +4.6 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 108 | 101 | 11 | 3.67 | +953 | +86.6 |
| MOVE TO CHARGE COMPUTED | 28 | 23 | 11 | 3.67 | +926 | +84.2 |
| COVER ONCE | 47 | 36 | 9 | 3.00 | +253 | +28.1 |
| FOUR ROUNDS | 21 | 17 | 9 | 3.00 | +416 | +46.2 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 19 | 14 | 7 | 2.33 | +880 | +125.7 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +276 | +46.0 |
| WHOLE FIGHT REACTION | 15 | 15 | 6 | 2.00 | +245 | +40.8 |
| GOAL WALK | 35 | 35 | 5 | 1.67 | +105 | +21.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -134 | -26.8 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +134 | +26.8 |
| TIED UP BY THE SUM | 9 | 6 | 5 | 1.67 | +143 | +28.5 |
| EVASIVE BY THE ODDS | 10 | 10 | 4 | 1.33 | +89 | +22.3 |
| FALLS SHORT | 59 | 53 | 4 | 1.33 | +54 | +13.5 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -164 | -41.1 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +211 | +52.7 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +296 | +74.1 |
| RISK BY ARC | 17 | 14 | 4 | 1.33 | +39 | +9.8 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +100 | +25.0 |
| WHOLE FIGHT DANGER | 20 | 19 | 4 | 1.33 | +172 | +43.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 20 | 17 | 3 | 1.00 | +45 | +14.9 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +25 | +8.3 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -17 | -5.7 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +141 | +47.1 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +146 | +48.6 |
| SET UP BY THE SET | 12 | 12 | 3 | 1.00 | +219 | +73.0 |
| SUPPORT ADDS | 25 | 25 | 3 | 1.00 | +144 | +48.1 |
| SUPPORT WORKED OUT | 25 | 25 | 3 | 1.00 | +144 | +48.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -99 | -49.6 |
| CHARGE NOW FIRST | 14 | 14 | 2 | 0.67 | -59 | -29.5 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +3 | +1.7 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +237 | +118.5 |
| IDLE COST | 30 | 23 | 2 | 0.67 | +5 | +2.7 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +81 | +40.4 |
| MAX FOR POSITIONING | 8 | 5 | 2 | 0.67 | +0 | +0.0 |
| ONE JOINT FIGURE | 3 | 2 | 2 | 0.67 | +82 | +40.8 |
| ONE OBJECTIVE FORMULA | 19 | 14 | 2 | 0.67 | +85 | +42.3 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 2 | 0.67 | +5 | +2.3 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +134 | +66.8 |
| WOUNDS ON THE RANKS | 10 | 10 | 2 | 0.67 | +42 | +20.8 |
| CANNON PLANNED TARGET | 19 | 19 | 1 | 0.33 | -5 | -5.3 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +11 | +10.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +24 | +23.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +50 | +49.8 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +10 | +10.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 42 | 42 | 1 | 0.33 | +61 | +61.2 |
| OVERRUNS AWAY | 6 | 4 | 1 | 0.33 | +3 | +2.9 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -4 | -3.8 |
| RUN DOWN | 18 | 15 | 1 | 0.33 | +3 | +2.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 74 | 54 | 1 | 0.33 | +4 | +3.7 |
| STAY WORTH | 98 | 88 | 1 | 0.33 | +26 | +26.2 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 1 | 0.33 | -248 | -248.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 2 | 1 | 0.33 | +12 | +12.3 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 38 | 37 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 26 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | not checked | - | - | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 75 | 74 | 0 | 0.00 | - | - |
| HONEST WORTH | 19 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 21 | 18 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 39 | 32 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 36 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 16 | 16 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 45 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 203 | 196 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 237 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 1.33 | 4.67 | 87.5 |
| JOB FIRST | gate | 2.67 | 2.67 | 61.5 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.00 | 90.0 |
| NO REASON | gate | 1.67 | - | 16.4 |
| MARCH OF THE TABLE | rule | 1.00 | 0.33 | 33.6 |
| RULE SWITCHED OFF | gate | - | 1.33 | 12.0 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 5.7 |
| BEST PRIZE | rule | - | 0.67 | 49.6 |
| CHARGE NOW FIRST | rule | - | 0.67 | 29.5 |
| JOINT CHARGE NOW | rule | - | 0.67 | 99.6 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 5.3 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 121.8 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 1.1 |
| REFUSING RETIRES | rule | 0.33 | - | 3.8 |
| SET UP BY THE SET | rule | - | 0.33 | 19.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 248.1 |

### Plans: wfr-a92c160-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 420 | 263 | 63% |
| Mine | move | 32.0 | 96% | 1695 | 0 | 0% |
| Mine | shoot | 9.7 | 45% | 271 | 339 | 125% |
| Opponent | charge | 4.0 | 33% | 328 | 278 | 85% |
| Opponent | join | 2.0 | 100% | 73 | 0 | 0% |
| Opponent | move | 29.3 | 93% | 2023 | 0 | 0% |
| Opponent | shoot | 2.0 | 17% | 37 | 3 | 8% |

### Battle groups: wfr-a92c160-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 48 (8) | 48 | 0 | 28 | 0% | 2.9 | 64 (6) | 0 (2) | - | 26 (2) | 54 (6) |
| Mine | Clean-up | 3 | 99 (3) | 30 | 69 | 37 | 0% | 2.0 | 110 (2) | 81 (1) | - | 110 (2) | 81 (1) |
| Mine | Fast Hammer | 7 | 29 (7) | 0 | 29 | 42 | 71% | 4.5 | 46 (3) | 13 (3) | 20 (1) | 70 (2) | 12 (5) |
| Mine | Holder | 2 | 52 (2) | 0 | 52 | 0 | 100% | - | 52 (2) | - | - | 52 (2) | - |
| Mine | Shooter | 5 | 15 (5) | 15 | 0 | 40 | 20% | 1.0 | 18 (4) | 0 (1) | - | 18 (4) | 0 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 75 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 32 | 33% | 5.0 | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 72 (9) | 72 | 0 | 29 | 33% | 2.7 | 124 (3) | 25 (5) | - | 32 (4) | 130 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 34 (3) | 0 | 34 | 29 | 33% | 2.0 | 152 (1) | 0 (2) | - | 0 (1) | 67 (2) |
| Opponent | Hammer | 8 | 22 (8) | 22 | 0 | 41 | 50% | 3.2 | 0 (4) | 84 (2) | 0 (2) | 32 (5) | 0 (3) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 35 | 67% | 4.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 62 | 0% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |

### Charged fights: wfr-a92c160-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 60 | 289 | 2.0 | 1.0 | 144 | 48 | +97 | 1 of 6 | 6 of 6 | - | +97 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 232 | 3.0 | 1.0 | 77 | 0 | +77 | 2 of 3 | 2 of 3 | - | +77 |
| Opponent | Warriors of Chaos | 1 | 0 | 151 | 1.0 | 1.0 | 151 | 0 | +151 | 0 of 1 | 1 of 1 | - | +151 |
| Opponent | Wood Elf Realms | 1 | 0 | 1089 | 3.0 | 1.0 | 363 | 0 | +363 | 2 of 3 | 3 of 3 | - | +363 |
| **Opponent** | all armies | 3 | 0 | 491 | 2.3 | 1.0 | 210 | 0 | +210 | 4 of 7 | 6 of 7 | - | +210 |

### Effective charges: wfr-a92c160-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 0 | 0 | 0 | 0 | 0 | 2 (net +163) | 4 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 1 (net +619) | 0 | 1 (net +470) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: wfr-a92c160-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 416 | 163 | +163 | 163 | 0 | +163 | +39.2 |
| Mine | No odds | 4 | 345 | 135 | +64 | 168 | 95 | +73 | +21.2 |
| Mine | All fights | 6 | 368 | 144 | +97 | 167 | 64 | +103 | +28.0 |
| Opponent | 76-89% | 1 | 499 | 342 | +619 | 619 | 0 | +619 | +124.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 400 | +470 | 470 | 0 | +470 | +94.2 |
| Opponent | No odds | 5 | 215 | 246 | +77 | 99 | 33 | +66 | +30.8 |
| Opponent | All fights | 7 | 296 | 282 | +210 | 227 | 24 | +203 | +68.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p32 | move | 20 | 5 (25%) | 2 (10%) | 5 (25%) | 10 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

# Doctrine scorecard: wfr-a92c160-p42

### Scorecard: wfr-a92c160-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Opponent | no | 5 | - | 1 | 3 | 1 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 503 |
| L0934 | 4 | 1 | Opponent | no | 3 | 3 | 3 | 6 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 12 | 3 | 3 | 1 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 3.0 | 1.0 | 1.3 | 0.0 | 0.0 | 0.0 | 222.7 |
| **Average** | | | Opponent | 0% | 2.7 | 4.5 | 1.7 | 3.7 | 0.3 | 0.0 | 0.0 | 61.7 |

### KPIs: wfr-a92c160-p42

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (3 of 11) | 0% (0 of 14) | 12% (3 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 50% (1 of 2); on the table 50% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 50% (1 of 2); on the table 50% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 40% (19 of 48) | 8% (1 of 12) | 33% (20 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (19 of 45) | 8% (1 of 12) | 35% (20 of 57) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 77% (4619 of 5997) | 82% (4906 of 5998) | 79% (9525 of 11995) |
|   infantry points that never fought | lower | 82% (1298 of 1591) | 90% (1027 of 1147) | 85% (2325 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (23 of 34) | 75% (15 of 20) | 70% (38 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 1.0 uses a game | 100% (1 of 1); 1.3 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3859 of 5667) | 76% (3954 of 5186) | 72% (7813 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (52%) | 0.0 (0%) | 5.0 (38%) |
| MARCHED: its unit marched | 3.7 (38%) | 1.3 (36%) | 5.0 (38%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (18%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (36%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.0 | 6.7 | 0.7 | 1.3 |
| not cast | 2.0 | 4.0 | 13.3 | 3.3 | 14.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (50%) | 5.0 (38%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 5.0 (38%) | 1.7 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (50%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (98%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (89 of 127) | 73% (57 of 78) | 71% (146 of 205) |
|   cavalry | - | 58% (7 of 12) | 58% (7 of 12) |
|   character | 100% (9 of 9) | 56% (9 of 16) | 72% (18 of 25) |
|   chariot | 89% (16 of 18) | 100% (12 of 12) | 93% (28 of 30) |
|   infantry | 48% (20 of 42) | 69% (18 of 26) | 56% (38 of 68) |
|   monster | 90% (9 of 10) | 92% (11 of 12) | 91% (20 of 22) |
|   war machine | 73% (35 of 48) | - | 73% (35 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (21%) | 4.3 (62%) | 7.0 (36%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 2.0 (16%) | 0.0 (0%) | 2.0 (10%) |
| NO TARGET IN RANGE | 2.7 (21%) | 0.7 (10%) | 3.3 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (21%) | 1.7 (24%) | 4.3 (22%) |
| SHELTERED: the target was sheltered | 1.7 (13%) | 0.0 (0%) | 1.7 (8%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.3 | 90% | 0.8 pts | 3 pts |
| character | 6.0 | 2.3 | 61% | 3.2 pts | 19 pts |
| chariot | 9.3 | 7.7 | 54% | 18.5 pts | 173 pts |
| infantry | 13.0 | 6.3 | 67% | 6.7 pts | 87 pts |
| monster | 9.7 | 3.0 | 79% | 6.1 pts | 59 pts |
| war machine | 11.7 | 10.0 | 60% | 18.8 pts | 220 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.0 | 1.5 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 1.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.13 declared, 0.06 contact (31 units) | 0.08 declared, 0.04 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 67% (2 of 3) | 80% (4 of 5) | 75% (6 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 50% (1 of 2) | 100% (5 of 5) | - | 86% (6 of 7) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 50% (12 of 24) | 88% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (3 of 3); on the table 100% | 29% (7 of 24) | 55% | 70% (7 of 10) | 50% (1 of 2); 3.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 53% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 95% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 67% (2) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (20 of 62) | 74% (20 of 27) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 22% (2 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.7 |
| Movement | Points that never moved of their own | 222.7 | 61.7 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +60 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +0 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 19.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (16 of 54) | 54% (31 of 57) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 11.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (16 of 35) | - |
| Shooting | Points destroyed by war machines | 122.3 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (4 of 12) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 10.3 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 248.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.0 / 0.3 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 31.3 | 34.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +86 | +33 |
| Combat | Net per 100 charger points, damage counted | +29.7 | +15.6 |
| Combat | First round won (charged fights) | 100% | 33% |
| Combat | Net points per charged fight | +20 | +23 |
| Combat | Net points per supported fight / lone fight | - / +20 | - / +23 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 1 of 3 |
| Game | Points lost | 179.7 | 369.0 |
| Game | VP from objectives | 466.7 | 733.3 |
| Game | Lone holders (player turns) | 4.0 | 2.7 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -46 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 549
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: wfr-a92c160-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| ARMY TABLE | 12.0 | +312.5 | 0.0 | 69.3 | 25.0 | +210.5 | 0.0 | 104.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.4 | 0.0 | 199.7 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 199.7 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 36.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.7 | +200.1 | 1269.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.0 | +44.5 | 60.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +39.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +25.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.0 | -761.6 | 0.0 | 220.7 | 21.0 | -862.4 | 0.0 | 562.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 11.3 |
| COVER ONCE | 9.0 | -350.5 | 0.0 | 34.7 | 4.3 | -424.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -15.7 | 69.3 | 199.7 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.1 | 0.0 | 399.3 |
| EXACT ROUND | 0.7 | -1.1 | 20.0 | 0.0 | 1.0 | -7.3 | 34.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 20.0 | 0.0 | 1.0 | +0.5 | 69.3 | 199.7 |
| FALLS SHORT | - | - | - | - | 35.3 | +393.7 | 0.0 | 298.7 |
| FEATURE BUFFS | 0.7 | +13.8 | 0.0 | 0.0 | 0.7 | +10.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +0.2 | 34.7 | 0.0 |
| FIVE ACTION | 106.3 | +4748.5 | 3516.7 | 290.0 | 111.7 | +5302.5 | 517.0 | 1203.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 34.7 | 5.7 | +0.0 | 0.0 | 20.0 |
| FOLLOW UP WEIGHED | 0.7 | +21.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +99.3 | 20.0 | 0.0 | 1.7 | +63.9 | 69.3 | 199.7 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 34.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -4.1 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +493.3 | 0.0 | 0.0 | 22.3 | +2136.8 | 0.0 | 97.3 |
| GUN FIGURES | 2.7 | +35.7 | 238.7 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 5.3 | +226.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 34.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 34.7 | 8.0 | +0.0 | 0.0 | 72.7 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 11.3 |
| HIS MOVE AND SHOT | 3.7 | -13.8 | 0.0 | 0.0 | 9.0 | -109.5 | 0.0 | 106.7 |
| HIS MOVE AS HE DECIDES | 54.3 | +15.3 | 697.0 | 0.0 | 36.7 | +10.3 | 249.0 | 0.0 |
| HIS MOVE WHY | 27.0 | +0.0 | 0.0 | 75.7 | 22.7 | +0.0 | 0.0 | 623.0 |
| HIS ONE MOVE | 15.3 | +26.6 | 0.0 | 0.0 | 24.7 | +32.6 | 0.0 | 144.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 60.7 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 11.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.0 | +1117.3 | 0.0 | 220.7 | 84.7 | +6093.9 | 0.0 | 966.0 |
| HIS SHOTS BY HIS RUN | 39.0 | +753.4 | 0.0 | 255.3 | 68.7 | +1611.9 | 0.0 | 857.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +54.6 | 69.3 | 199.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 0.0 | 19.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.3 | +1167.0 | 0.0 | 0.0 | 14.3 | +1450.9 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -43.1 | 20.0 | 0.0 | 1.7 | -44.0 | 69.3 | 199.7 |
| IDLE COST | - | - | - | - | 24.3 | -367.6 | 0.0 | 71.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +81.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 34.7 | 5.3 | +0.0 | 208.0 | 397.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.3 | 0.0 | 0.0 | 1.3 | +6.2 | 34.7 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.6 | 0.0 | 75.7 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -4.1 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +7.7 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +49.9 | 0.0 | 0.0 | 0.3 | +42.9 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +90.1 | 0.0 | 0.0 | 0.7 | +34.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +9.0 | 0.0 | 0.0 | 0.3 | +29.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.7 | +221.7 | 0.0 | 0.0 | 1.0 | +115.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +16.3 | 0.0 | 75.7 | 3.0 | +33.9 | 0.0 | 22.7 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.7 | +143.7 | 0.0 | 0.0 | 1.7 | +41.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 13.0 | +121.9 | 0.0 | 0.0 | 3.3 | +29.3 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 47.0 | 11.3 |
| MOVE TO CHARGE COMPUTED | 2.3 | +129.5 | 0.0 | 0.0 | 3.3 | +229.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +236.7 | 0.0 | 0.0 | 5.0 | +232.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +72.6 | 0.0 | 0.0 | 1.7 | +107.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -25.2 | 20.0 | 0.0 | 1.3 | -29.2 | 69.3 | 199.7 |
| NO LATE CUT | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -182.5 | 0.0 | 0.0 | 5.0 | -110.1 | 0.0 | 35.7 |
| OGRE LOADER SECOND SHOT | 3.0 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 30.3 |
| ONE FIGHT FORMULA | 4.0 | -67.2 | 0.0 | 75.7 | 4.3 | -86.3 | 0.0 | 211.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +11.0 | 0.0 | 0.0 | 5.7 | -47.4 | 0.0 | 0.0 |
| ONE ROUTE | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 199.7 |
| PATHS CROSS | - | - | - | - | 0.3 | +49.9 | 0.0 | 0.0 |
| PLAN RESULT | 45.3 | +1514.2 | 1321.3 | 324.7 | 50.0 | +446.8 | 413.0 | 697.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.0 | -73.7 | 0.0 | 0.0 | 5.7 | -249.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| QUARTER ODDS | 9.3 | +944.7 | 258.7 | 0.0 | 13.3 | +912.0 | 0.0 | 312.0 |
| REAL GROUND | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 5.3 | +390.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 7.0 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -27.8 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +39.6 | 0.0 | 35.7 |
| RISK BY ARC | 1.0 | +93.0 | 20.0 | 0.0 | 0.7 | -58.9 | 69.3 | 199.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -17.5 | 34.7 | 199.7 |
| RUN DOWN | - | - | - | - | 1.7 | -17.5 | 69.3 | 199.7 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.0 | -299.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 34.7 | 0.7 | +55.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -39.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +2.5 | 0.0 | 0.0 | 1.3 | -87.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.6 | 0.0 | 75.7 | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 19.7 | +0.0 | 0.0 | 34.7 | 11.3 | +0.0 | 0.0 | 18.7 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +133.1 | 37.3 | 0.0 | 2.0 | +36.3 | 75.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -13.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -544.8 | 0.0 | 220.7 | 49.3 | -217.7 | 0.0 | 808.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 33.0 | +1011.1 | 0.0 | 145.0 | 18.7 | +301.9 | 0.0 | 218.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +54.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -3.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 151.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.8 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 12.0 | +0.0 | 69.3 | 436.7 |
| STANDS STILL | 56.3 | +0.0 | 3496.7 | 69.3 | 33.3 | +0.0 | 447.7 | 170.3 |
| STAY WORTH | 48.7 | +270.9 | 2763.7 | 110.3 | 28.7 | +296.7 | 372.0 | 310.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 2.3 | +173.0 | 0.0 | 0.0 | 2.3 | +45.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +173.0 | 0.0 | 0.0 | 2.3 | +45.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 34.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 84.3 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 36.3 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 36.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 145.0 | 55.3 | +0.0 | 0.0 | 496.0 |
| TIED UP BY THE SUM | 0.3 | +47.5 | 20.0 | 0.0 | 0.3 | +53.6 | 34.7 | 199.7 |
| TIME ON OUR SIDE | 52.7 | +678.3 | 37.3 | 296.3 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 302.7 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +15.4 | 0.0 | 36.3 |
| WHOLE FIGHT DANGER | 2.0 | -146.5 | 0.0 | 0.0 | 0.7 | -98.9 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.3 | +131.1 | 211.0 | 34.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 6.7 | +81.1 | 0.0 | 0.0 | 0.7 | +9.0 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 273 | 273 | 196 | 65.33 | +0 | +0.0 |
| HIS SHOT LIST | 380 | 371 | 147 | 49.00 | +2645 | +18.0 |
| HIS SHOTS BY HIS RUN | 323 | 312 | 97 | 32.33 | +1135 | +11.7 |
| HIS MOVE WHY | 149 | 149 | 92 | 30.67 | +0 | +0.0 |
| ARMY TABLE | 111 | 111 | 88 | 29.33 | +1581 | +18.0 |
| HOLDER ASSIGNMENT | 80 | 80 | 74 | 24.67 | +4565 | +61.7 |
| SHOT RISK POINTS | 217 | 210 | 48 | 16.00 | +1106 | +23.0 |
| HIS ONE MOVE | 120 | 117 | 38 | 12.67 | +0 | +0.0 |
| GOAL WALK | 94 | 93 | 35 | 11.67 | +1312 | +37.5 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -878 | -25.1 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| HARD STAY DROPPED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 158 | 130 | 24 | 8.00 | +155 | +6.5 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| STAY WORTH | 232 | 209 | 16 | 5.33 | +194 | +12.1 |
| FIVE ACTION | 654 | 639 | 15 | 5.00 | +518 | +34.5 |
| THE RISK READS HIS RUN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 17 | 14 | 13 | 4.33 | +331 | +25.5 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 12 | 4.00 | -971 | -80.9 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 11 | 3.67 | +68 | +6.2 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +21 | +2.3 |
| CHARGE LOSSES | 114 | 109 | 8 | 2.67 | +619 | +77.4 |
| IDLE COST | 73 | 49 | 8 | 2.67 | +69 | +8.7 |
| NEXT CHARGE BY LIST | 8 | 8 | 7 | 2.33 | +211 | +30.2 |
| SHOTS IN THE MOVE | 155 | 124 | 7 | 2.33 | +155 | +22.2 |
| WOUNDS ON THE RANKS | 22 | 22 | 7 | 2.33 | +67 | +9.6 |
| GUN MASK | 16 | 16 | 6 | 2.00 | +224 | +37.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MAX FOR POSITIONING | 19 | 18 | 6 | 2.00 | +10 | +1.6 |
| CAST JOB | 9 | 9 | 5 | 1.67 | +28 | +5.7 |
| FALLS SHORT | 106 | 85 | 5 | 1.67 | +59 | +11.7 |
| MARCH CHECK | 7 | 7 | 5 | 1.67 | +86 | +17.3 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SUPPORT ADDS | 14 | 14 | 5 | 1.67 | +250 | +49.9 |
| SUPPORT WORKED OUT | 14 | 14 | 5 | 1.67 | +250 | +49.9 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +69 | +17.3 |
| COVER ONCE | 40 | 32 | 4 | 1.33 | +27 | +6.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +278 | +69.6 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -114 | -28.6 |
| MISSILES IN THE MOVE | 34 | 25 | 4 | 1.33 | +58 | +14.5 |
| SHOTS AFTER THE MOVES | 27 | 27 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FEATURE BUFFS | 4 | 4 | 3 | 1.00 | +15 | +4.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +63 | +31.5 |
| FOUR ROUNDS | 8 | 7 | 2 | 0.67 | +86 | +43.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +245 | +122.5 |
| NEARER NOT NEEDED | 30 | 28 | 2 | 0.67 | +10 | +4.8 |
| ONE OBJECTIVE FORMULA | 30 | 25 | 2 | 0.67 | +17 | +8.5 |
| REDIRECT COUNTER | 16 | 15 | 2 | 0.67 | +436 | +218.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +119 | +59.4 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +167 | +83.4 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +51 | +25.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| THE ROW IN ITS ORDER | 23 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +104 | +52.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +54 | +26.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +18 | +18.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| CANNON PLANNED TARGET | 32 | 32 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.4 |
| CHARGE NOW FIRST | 1 | 1 | 1 | 0.33 | -39 | -38.9 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 38 | 36 | 1 | 0.33 | +3 | +2.8 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +62 | +62.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +48 | +48.0 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +1 | +0.6 |
| MISSILES NEXT TURN | 49 | 31 | 1 | 0.33 | +1 | +1.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +150 | +149.6 |
| QUARTER ODDS | 68 | 63 | 1 | 0.33 | +24 | +24.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +26 | +26.2 |
| REFORMS TO MEET IT | 3 | 3 | 1 | 0.33 | +10 | +9.8 |
| RISK BY ARC | 5 | 4 | 1 | 0.33 | +6 | +5.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| SET UP TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.3 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| WHOLE FIGHT DANGER | 8 | 8 | 1 | 0.33 | +83 | +83.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 74 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 114 | 114 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 29 | 29 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 20 | 20 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 20 | 20 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 286 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 20 | 20 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 93 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 36 | 34 | 0 | 0.00 | - | - |
| STANDS STILL | 269 | 260 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 18 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 30 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 308 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 19 | 19 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 3.67 | 27.3 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 2.00 | 80.9 |
| ARMY TABLE | rule | 0.33 | 3.00 | 31.8 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.00 | 25.0 |
| RULE SWITCHED OFF | gate | - | 1.33 | 21.3 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 38.1 |
| NO REASON | gate | 0.67 | - | 11.7 |
| AFTERMATH BAND | gate | 0.33 | - | 4.8 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 38.9 |

### Plans: wfr-a92c160-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 26 | 28 | 107% |
| Mine | move | 27.7 | 96% | 1371 | 0 | 0% |
| Mine | shoot | 17.0 | 71% | 839 | 1486 | 177% |
| Opponent | charge | 0.7 | 100% | 35 | 59 | 170% |
| Opponent | move | 41.3 | 95% | 1953 | 0 | 0% |
| Opponent | shoot | 6.7 | 60% | 341 | 388 | 114% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: wfr-a92c160-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 5.3 | 6% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 46 (12) | 46 | 0 | 0 | 33% | 2.9 | 6 (5) | 0 (5) | 421 (2) | 90 (7) | 6 (5) |
| Mine | Clean-up | 2 | 100 (2) | 0 | 100 | 0 | 100% | - | - | - | 100 (2) | 100 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 0 | 33% | 2.5 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 8 (7) | 8 | 0 | 14 | 29% | 1.4 | 0 (1) | 5 (3) | 13 (3) | 11 (5) | 0 (2) |
| Mine | Shooter | 6 | 77 (6) | 0 | 77 | 50 | 0% | 2.0 | 0 (1) | 159 (2) | 48 (3) | 92 (5) | 0 (1) |
| Mine | War machine | 8 | 26 (8) | 26 | 0 | 0 | 0% | 1.1 | 86 (1) | 34 (4) | 0 (3) | - | 26 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 124 (11) | 0 | 124 | 32 | 45% | 2.8 | 142 (3) | 117 (1) | 118 (7) | 124 (11) | - |
| Opponent | Character | 6 | 4 (6) | 4 | 0 | 24 | 0% | 2.2 | 0 (2) | 14 (2) | 0 (2) | 10 (2) | 0 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 50% | 1.0 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 6 (10) | 6 | 0 | 11 | 40% | 2.2 | 0 (4) | 11 (4) | 0 (2) | 24 (2) | 0 (8) |
| Opponent | Holder | 1 | 67 (1) | 0 | 67 | 0 | 100% | - | - | 67 (1) | - | - | 67 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: wfr-a92c160-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 556 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 0 | 60 | 3.0 | 1.0 | 20 | 0 | +20 | 0 of 3 | 3 of 3 | - | +20 |
| **Mine** | all armies | 3 | 371 | 20 | 1.0 | 1.0 | 20 | 0 | +20 | 0 of 3 | 3 of 3 | - | +20 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| **Opponent** | all armies | 3 | 0 | 35 | 1.0 | 1.0 | 35 | 11 | +23 | 1 of 3 | 1 of 3 | - | +23 |

### Effective charges: wfr-a92c160-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 1 (net +60) | 1 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 1 (net +104) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 334 | 329 | +0 | 188 | 0 | +188 | +56.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 60 | +60 | 92 | 81 | +11 | +3.3 |
| Mine | No odds | 1 | 205 | 60 | +0 | 60 | 0 | +60 | +29.5 |
| Mine | All fights | 3 | 291 | 150 | +20 | 114 | 27 | +86 | +29.7 |
| Opponent | 76-89% | 1 | 109 | 104 | +104 | 146 | 54 | +91 | +83.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 369 | +0 | 105 | 62 | +43 | +8.6 |
| Opponent | No odds | 1 | 34 | 189 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 3 | 214 | 221 | +23 | 84 | 50 | +33 | +15.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p42 | move | 17 | 4 (24%) | 3 (18%) | 2 (12%) | 11 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

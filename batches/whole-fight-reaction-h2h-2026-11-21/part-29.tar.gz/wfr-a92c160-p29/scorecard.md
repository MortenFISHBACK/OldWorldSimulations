# Doctrine scorecard: wfr-a92c160-p29

### Scorecard: wfr-a92c160-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0717 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0733 | 1 | 1 | Mine | no | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Opponent | no | 3 | 4 | 2 | 5 | 1 | 0 | 0 | 234 |
| L0823 | 1 | 1 | Mine | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 551 |
| L0823 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 1 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 10.0 | 3.0 | 1.5 | 0.5 | 0.0 | 0.0 | 0.0 | 360.5 |
| **Average** | | | Opponent | 0% | 2.0 | 3.0 | 2.0 | 4.0 | 1.0 | 0.0 | 0.0 | 214.5 |

### KPIs: wfr-a92c160-p29

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 92% (12 of 13) | 0% (0 of 12) | 48% (12 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 67% (2 of 3); on the table 100% | 86% (6 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 67% (2 of 3); on the table 100% | 86% (6 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 40% (4 of 10) | 25% (3 of 12) | 32% (7 of 22) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (4 of 9) | 33% (3 of 9) | 39% (7 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 62% (2491 of 3999) | 55% (2183 of 4000) | 58% (4674 of 7999) |
|   infantry points that never fought | lower | 100% (561 of 561) | 58% (601 of 1045) | 72% (1162 of 1606) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 60% (9 of 15) | 57% (20 of 35) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (1675 of 3589) | 51% (1748 of 3408) | 49% (3423 of 6997) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (33%) | 1.7 (56%) | 2.3 (47%) |
| MARCHED: its unit marched | 1.0 (50%) | 0.3 (11%) | 1.3 (27%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.3 (11%) | 0.7 (13%) |
| GONE: slain | 0.0 (0%) | 0.7 (22%) | 0.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.3 | 2.3 | 0.3 | 0.0 |
| not cast | 2.7 | 0.7 | 5.0 | 1.7 | 8.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (27%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (12%) | 0.0 (0%) | 0.7 (13%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.7 (25%) | 0.0 (0%) | 0.7 (13%) | 0.7 (40%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.3 (96%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (47 of 69) | 75% (50 of 67) | 71% (97 of 136) |
|   cavalry | 73% (8 of 11) | 63% (12 of 19) | 67% (20 of 30) |
|   character | - | 69% (9 of 13) | 69% (9 of 13) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 33% (4 of 12) | 83% (29 of 35) | 70% (33 of 47) |
|   war machine | 76% (31 of 41) | - | 76% (31 of 41) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (27%) | 0.7 (12%) | 2.7 (21%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (35%) | 2.0 (15%) |
| FLEEING: it fled or was fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (12%) | 0.7 (5%) |
| MOVED: a war machine that moved | 0.7 (9%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 1.0 (14%) | 0.7 (12%) | 1.7 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.7 (12%) | 1.0 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (27%) | 1.0 (18%) | 3.0 (23%) |
| SHELTERED: the target was sheltered | 0.7 (9%) | 0.0 (0%) | 0.7 (5%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.3 | 3.3 | 71% | 7.5 pts | 77 pts |
| character | 3.0 | 0.7 | 78% | 4.7 pts | 14 pts |
| chariot | 1.3 | 0.7 | 75% | 24.4 pts | 33 pts |
| infantry | 16.3 | 5.0 | 78% | 5.7 pts | 93 pts |
| war machine | 10.3 | 8.3 | 48% | 23.6 pts | 244 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.7 | 2.3 |
| Charges that made contact a game | 1.7 | 1.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.15 contact (26 units) | 0.28 declared, 0.14 contact (29 units) | 0.24 declared, 0.15 contact (55 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 0% (0 of 2) | - | 38% (3 of 8) |
| Character in a unit | 100% (4 of 4) | - | 0% (0 of 1) | 80% (4 of 5) |
| Character on its own | 100% (2 of 2) | 100% (1 of 1) | 33% (1 of 3) | 67% (4 of 6) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 1) | 33% (1 of 3) | 0% (0 of 1) | 20% (1 of 5) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 71% (5 of 7) | - | - | 71% (5 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 62% | 55% (11 of 20) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 69% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 40% | 70% (7 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | - | 50% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (17 of 47) | 55% (6 of 11) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 0.5 | 4.0 |
| Movement | Points that never moved of their own | 360.5 | 214.5 |
| Movement | Fights charged into per game | 1.5 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net +114 | 1 of 1, net +130 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 18.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (8 of 18) | 57% (32 of 56) |
| Shooting | Points destroyed by shooting units | 251.3 | 101.3 |
| Shooting | War machine shots | 10.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (12 of 31) | - |
| Shooting | Points destroyed by war machines | 6.3 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 34.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.0 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 114.0 | 182.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +169 | +209 |
| Combat | Net per 100 charger points, damage counted | +53.4 | +133.7 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +114 | +169 |
| Combat | Net points per supported fight / lone fight | +0 / +171 | - / +169 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 3 of 4 |
| Game | Points lost | 440.0 | 559.5 |
| Game | VP from objectives | 1115.0 | 990.0 |
| Game | Lone holders (player turns) | 10.0 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +197 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1000
- Games not ended: 1 (L0717-1); findings 2, warnings 0

### Opponent rules: wfr-a92c160-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +37.4 | 0.0 | 0.0 |
| ARMY TABLE | 10.3 | -199.1 | 0.0 | 88.3 | 28.3 | +433.0 | 0.0 | 138.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -12.9 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -5.2 | 67.3 | 0.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 540.0 | 43.3 | - | - | - | - |
| CANNON PLANNED TARGET | 11.0 | +605.2 | 1635.0 | 86.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.7 | +141.5 | 156.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +44.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.0 | -1022.7 | 0.0 | 156.3 | 16.7 | -1398.6 | 0.0 | 360.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 67.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 12.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 176.7 | - | - | - | - |
| COVER ONCE | 10.3 | -675.7 | 0.0 | 110.7 | 10.3 | -853.1 | 0.0 | 216.0 |
| DENIED BY THE FIGHT | 0.7 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 71.3 |
| DUEL STOPS AT THE KILL | 0.3 | -18.5 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.3 | 43.3 | 0.0 |
| EXACT ROUND | 1.0 | -5.8 | 36.0 | 0.0 | 1.3 | +10.4 | 43.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +11.2 | 36.0 | 93.7 | 1.7 | +3.2 | 110.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.0 | +230.6 | 0.0 | 285.3 |
| FEATURE BUFFS | 0.7 | +50.1 | 0.0 | 0.0 | 0.3 | +2.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 103.3 | +7345.9 | 3930.7 | 646.3 | 82.0 | +4864.9 | 312.7 | 608.7 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 88.3 | 5.0 | +0.0 | 0.0 | 180.0 |
| FOLLOW UP WEIGHED | 1.3 | +226.3 | 0.0 | 0.0 | 0.7 | +74.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +221.8 | 36.0 | 93.7 | 1.7 | +186.8 | 110.7 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -69.5 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -18.5 | 36.0 | 93.7 | 0.3 | -0.2 | 43.3 | 0.0 |
| GOAL WALK | 6.7 | +461.5 | 0.0 | 0.0 | 14.7 | +909.1 | 0.0 | 151.3 |
| GUN FIGURES | 1.3 | +129.2 | 180.0 | 88.3 | - | - | - | - |
| GUN MASK | 2.3 | +20.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 88.3 | 11.0 | +0.0 | 0.0 | 360.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 138.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 88.3 | 4.7 | +0.0 | 0.0 | 360.0 |
| HIS MOVE AND SHOT | 3.0 | -29.1 | 0.0 | 0.0 | 3.7 | -58.0 | 0.0 | 366.3 |
| HIS MOVE AS HE DECIDES | 39.7 | +10.0 | 478.0 | 0.0 | 35.3 | +10.3 | 410.3 | 0.0 |
| HIS MOVE WHY | 23.3 | +0.0 | 0.0 | 34.0 | 11.3 | +0.0 | 0.0 | 124.3 |
| HIS ONE MOVE | 17.0 | -1.1 | 0.0 | 88.3 | 23.7 | +88.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 7.7 | +0.0 | 0.0 | 244.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 88.3 | 1.0 | +0.0 | 0.0 | 180.0 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.3 | +1766.3 | 0.0 | 244.7 | 57.7 | +3188.3 | 0.0 | 176.7 |
| HIS SHOTS BY HIS RUN | 38.7 | +951.0 | 0.0 | 244.7 | 43.0 | +1832.7 | 0.0 | 385.3 |
| HIS TURN DENIED | 1.0 | +26.5 | 36.0 | 0.0 | 1.0 | +61.4 | 43.3 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 24.0 | +0.0 | 0.0 | 0.0 | 20.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.3 | +1444.1 | 0.0 | 67.3 | 15.0 | +1279.5 | 0.0 | 36.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -47.2 | 36.0 | 0.0 | 1.7 | -46.2 | 110.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +12.9 | 0.0 | 180.0 |
| IDLE COST | - | - | - | - | 12.3 | -228.0 | 0.0 | 199.0 |
| JOINT CHARGE NOW | 0.7 | -12.4 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +24.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 78.0 | 88.3 | 6.7 | +0.0 | 88.3 | 91.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +0.4 | 36.0 | 93.7 | 0.3 | +1.1 | 67.3 | 0.0 |
| MANOEUVRE | 1.0 | +10.5 | 0.0 | 0.0 | 2.0 | -2.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +68.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +43.8 | 0.0 | 0.0 | 0.3 | +17.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +132.5 | 0.0 | 0.0 | 1.3 | +20.7 | 0.0 | 180.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +95.2 | 0.0 | 0.0 | 3.0 | +31.5 | 0.0 | 36.0 |
| MISSILES NEXT TURN | 3.0 | +79.7 | 0.0 | 0.0 | 3.7 | +32.0 | 0.0 | 36.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 34.7 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +629.4 | 0.0 | 0.0 | 5.0 | +479.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +419.8 | 0.0 | 67.3 | 12.7 | +621.4 | 0.0 | 36.0 |
| NEXT CHARGE BY LIST | 4.7 | +261.6 | 0.0 | 0.0 | 3.3 | +318.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -46.3 | 36.0 | 93.7 | 1.7 | -154.1 | 110.7 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -55.7 | 0.0 | 0.0 | 5.7 | -70.2 | 0.0 | 180.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -101.2 | 0.0 | 88.3 | 2.7 | -74.3 | 0.0 | 180.0 |
| ONE JOINT FIGURE | 0.3 | +14.9 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | -22.8 | 0.0 | 67.3 | 5.7 | -37.5 | 0.0 | 36.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +9.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +50.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 46.0 | +2428.6 | 948.7 | 585.3 | 36.3 | +211.5 | 228.3 | 514.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -243.9 | 0.0 | 0.0 | 5.7 | -138.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -60.3 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| QUARTER ODDS | 22.0 | +2032.4 | 0.0 | 331.3 | 13.3 | +1226.8 | 178.0 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +38.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +9.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 12.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -12.9 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -7.3 | 0.0 | 0.0 | 0.7 | -2.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | -6.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +47.3 | 36.0 | 93.7 | 1.0 | -67.9 | 110.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -8.1 | 0.0 | 0.0 | 0.7 | -8.9 | 110.7 | 0.0 |
| RUN DOWN | 1.7 | -19.1 | 36.0 | 0.0 | 0.7 | -17.9 | 110.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +8.5 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -5.5 | 0.0 | 0.0 | 0.7 | -8.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -0.3 | 0.0 | 0.0 | 1.0 | +37.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 19.7 | +0.0 | 0.0 | 154.0 | 3.0 | +0.0 | 0.0 | 36.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +32.2 | 70.7 | 0.0 | 1.0 | +13.7 | 67.3 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -6.7 | 67.3 | 0.0 |
| SHOT RISK POINTS | 30.7 | -276.9 | 0.0 | 68.0 | 28.3 | +261.6 | 0.0 | 325.0 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.7 | +1311.9 | 0.0 | 242.3 | 19.7 | +353.1 | 0.0 | 36.0 |
| SPELL WORTH | 1.7 | +8.6 | 0.0 | 0.0 | 3.0 | +26.1 | 0.0 | 78.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 69.3 |
| STAND AND SHOOT | 0.7 | -5.4 | 36.0 | 0.0 | 0.3 | -5.4 | 67.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 67.3 | 0.0 |
| STANDS STILL | 61.0 | +0.0 | 3894.7 | 308.0 | 17.7 | +0.0 | 202.0 | 72.0 |
| STAY WORTH | 45.3 | +574.1 | 2911.3 | 260.0 | 14.0 | +62.2 | 134.7 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +3.6 | 72.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +133.8 | 0.0 | 0.0 | 8.7 | +893.7 | 0.0 | 104.0 |
| SUPPORT WORKED OUT | 1.7 | +133.8 | 0.0 | 0.0 | 8.7 | +893.7 | 0.0 | 104.0 |
| SURE REACH TOGETHER | 1.3 | +23.0 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +23.1 | 0.0 | 67.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 34.7 |
| THE RISK READS HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 34.7 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 276.3 | 39.0 | +0.0 | 0.0 | 304.3 |
| TIED UP BY THE SUM | 0.3 | +29.9 | 0.0 | 0.0 | 0.7 | +54.0 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 43.3 | +500.4 | 0.0 | 67.3 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +19.0 | 36.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +20.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -521.4 | 0.0 | 88.3 | 3.7 | -519.8 | 0.0 | 360.0 |
| WHOLE FIGHT GAIN | 0.3 | +31.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.3 | +59.2 | 0.0 | 161.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 7.0 | +137.3 | 0.0 | 0.0 | 2.0 | +118.0 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 225 | 225 | 164 | 54.67 | +0 | +0.0 |
| HIS SHOT LIST | 312 | 306 | 88 | 29.33 | +1449 | +16.5 |
| ARMY TABLE | 116 | 116 | 81 | 27.00 | +701 | +8.7 |
| HOLDER ASSIGNMENT | 88 | 88 | 77 | 25.67 | +3995 | +51.9 |
| HIS MOVE WHY | 104 | 104 | 62 | 20.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 245 | 236 | 52 | 17.33 | +840 | +16.2 |
| HIS ONE MOVE | 122 | 116 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| THE TABLE AGAIN | 32 | 32 | 26 | 8.67 | +0 | +0.0 |
| FIVE ACTION | 556 | 541 | 22 | 7.33 | +1581 | +71.9 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -378 | -17.2 |
| SHOT RISK POINTS | 177 | 170 | 20 | 6.67 | +556 | +27.8 |
| TIME ON OUR SIDE | 130 | 109 | 17 | 5.67 | +28 | +1.6 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 32 | 32 | 16 | 5.33 | +0 | +0.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 41 | 41 | 13 | 4.33 | -1146 | -88.2 |
| CHARGE LOSSES | 107 | 105 | 11 | 3.67 | +785 | +71.4 |
| GOAL WALK | 64 | 64 | 10 | 3.33 | +508 | +50.8 |
| MOVE TO CHARGE COMPUTED | 34 | 27 | 10 | 3.33 | +883 | +88.3 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| STAY WORTH | 178 | 167 | 9 | 3.00 | +165 | +18.3 |
| SUPPORT ADDS | 31 | 31 | 9 | 3.00 | +362 | +40.2 |
| SUPPORT WORKED OUT | 31 | 31 | 9 | 3.00 | +362 | +40.2 |
| NEXT CHARGE BY LIST | 24 | 21 | 8 | 2.67 | +594 | +74.2 |
| QUARTER ODDS | 106 | 104 | 8 | 2.67 | +229 | +28.6 |
| COVER ONCE | 62 | 49 | 7 | 2.33 | +189 | +27.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +903 | +150.5 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 11 | 11 | 5 | 1.67 | +362 | +72.4 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| MAX FOR POSITIONING | 12 | 11 | 5 | 1.67 | +13 | +2.5 |
| WHOLE FIGHT DANGER | 19 | 19 | 5 | 1.67 | +234 | +46.8 |
| NEARER NOT NEEDED | 66 | 64 | 4 | 1.33 | +208 | +52.0 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 4 | 1.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 17 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 5 | 5 | 3 | 1.00 | +181 | +60.2 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +73 | +24.2 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +16 | +5.3 |
| CANNON PLANNED TARGET | 33 | 33 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +69 | +34.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 37 | 25 | 2 | 0.67 | +25 | +12.7 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -37 | -18.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +37 | +18.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +207 | +103.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +152 | +76.2 |
| RISK BY ARC | 7 | 7 | 2 | 0.67 | +94 | +46.9 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | -43 | -21.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOTS IN THE MOVE | 127 | 103 | 2 | 0.67 | +5 | +2.3 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +11 | +5.4 |
| SURE REACH TOGETHER | 4 | 4 | 2 | 0.67 | +19 | +9.4 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +121 | +60.6 |
| WOUNDS ON THE RANKS | 27 | 25 | 2 | 0.67 | +28 | +13.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +112 | +112.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -39 | -38.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -133 | -133.0 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +23 | +22.8 |
| HIS MOVE AND SHOT | 20 | 19 | 1 | 0.33 | +15 | +15.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 10 | 10 | 1 | 0.33 | +12 | +12.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +107 | +107.4 |
| MISSILES IN THE MOVE | 13 | 10 | 1 | 0.33 | +73 | +72.5 |
| NO DOUBLE ROUNDS | 10 | 10 | 1 | 0.33 | +82 | +81.8 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +30 | +30.1 |
| ONE OBJECTIVE FORMULA | 30 | 24 | 1 | 0.33 | +194 | +193.6 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | -0 | -0.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -69 | -68.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | -19 | -18.9 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +69 | +69.3 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +35 | +34.7 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +30 | +30.1 |
| WHOLE FIGHT REACTION | 4 | 4 | 1 | 0.33 | +0 | +0.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 71 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FALLS SHORT | 69 | 62 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 7 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 7 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 62 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 31 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 41 | 40 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 31 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 32 | 32 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS TURN RUN | 32 | 32 | 0 | 0.00 | - | - |
| HOLD ODDS | 134 | 134 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 247 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | not checked | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 68 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 236 | 230 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 19 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 258 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.00 | 5.67 | 17.6 |
| ARMY TABLE | rule | 2.67 | 3.67 | 64.0 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.33 | 88.2 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 42.6 |
| BEST PRIZE | rule | - | 0.33 | 38.6 |
| CHARGE NOW FIRST | rule | - | 0.33 | 133.0 |
| FALLBACK | gate | 0.33 | - | 25.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 113.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 1.2 |
| REFUSING RETIRES | rule | 0.33 | - | 68.8 |
| RESERVE FALL BACK | rule | - | 0.33 | 18.9 |
| SET UP BY THE SET | rule | - | 0.33 | 59.9 |

### Plans: wfr-a92c160-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 234 | 52 | 22% |
| Mine | join | 2.7 | 100% | 28 | 0 | 0% |
| Mine | move | 28.7 | 100% | 1915 | 0 | 0% |
| Mine | shoot | 13.3 | 78% | 1209 | 2376 | 197% |
| Opponent | charge | 1.7 | 40% | 367 | 86 | 23% |
| Opponent | move | 31.7 | 94% | 1755 | 0 | 0% |
| Opponent | shoot | 2.3 | 57% | 200 | 126 | 63% |
| Opponent | support | 0.7 | 100% | 27 | 0 | 0% |

### Battle groups: wfr-a92c160-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 8 | 9 (8) | 9 | 0 | 35 | 62% | 3.3 | 17 (5) | - | 0 (3) | 10 (6) | 0 (2) |
| Mine | Clean-up | 1 | 136 (1) | 0 | 136 | 0 | 100% | - | - | 136 (1) | - | 136 (1) | - |
| Mine | Fast Hammer | 4 | 121 (4) | 66 | 55 | 25 | 25% | 2.3 | 129 (3) | - | 101 (1) | 121 (4) | - |
| Mine | Hammer | 2 | 38 (2) | 0 | 38 | 42 | 50% | 1.0 | - | 0 (1) | 65 (1) | 38 (2) | - |
| Mine | Shooter | 3 | 129 (3) | 6 | 123 | 0 | 0% | 2.0 | - | 220 (1) | 32 (2) | 220 (1) | 32 (2) |
| Mine | War machine | 7 | 63 (7) | 63 | 0 | 15 | 0% | 1.9 | 63 (7) | - | - | 400 (1) | 3 (6) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 22 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 6 | 31 (6) | 31 | 0 | 44 | 0% | 1.5 | - | 35 (3) | 28 (3) | 33 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 4 | 22 (4) | 22 | 0 | 68 | 50% | 3.0 | 67 (1) | 0 (1) | 0 (2) | 26 (3) | 0 (1) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 330 (3) | 158 | 172 | 0 | 0% | 1.7 | 150 (1) | 412 (2) | - | 528 (2) | 0 (1) |
| Opponent | Shooter | 3 | 95 (3) | 0 | 95 | 0 | 0% | 1.0 | - | 107 (2) | 72 (1) | 101 (2) | 81 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: wfr-a92c160-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 438 | 171 | 1.5 | 1.3 | 114 | 0 | +114 | 1 of 3 | 2 of 3 | +0 | +171 |
| Opponent | Tomb Kings of Khemri | 1 | 304 | 395 | 2.0 | 1.0 | 198 | 0 | +198 | 2 of 2 | 2 of 2 | - | +198 |
| Opponent | Wood Elf Realms | 1 | 0 | 281 | 2.0 | 1.0 | 140 | 0 | +140 | 1 of 2 | 2 of 2 | - | +140 |
| **Opponent** | all armies | 2 | 152 | 338 | 2.0 | 1.0 | 169 | 0 | +169 | 3 of 4 | 4 of 4 | - | +169 |

### Effective charges: wfr-a92c160-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +114) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +130) | 1 | 0% (0 of 1) |

### Charged fights, damage counted: wfr-a92c160-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 316 | 184 | +114 | 176 | 7 | +169 | +53.4 |
| Mine | All fights | 3 | 316 | 184 | +114 | 176 | 7 | +169 | +53.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 202 | +130 | 384 | 140 | +244 | +125.3 |
| Opponent | No odds | 3 | 144 | 212 | +182 | 214 | 16 | +198 | +137.5 |
| Opponent | All fights | 4 | 156 | 209 | +169 | 256 | 47 | +209 | +133.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p29 | move | 16 | 5 (31%) | 5 (31%) | 1 (6%) | 10 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

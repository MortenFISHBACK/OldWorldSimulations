# Doctrine scorecard: wfr-a92c160-p48

### Scorecard: wfr-a92c160-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2535 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 4 | 0 | 0 | 0 | 38 |
| **Average** | | | Mine | 50% | 1.0 | 2.5 | 2.5 | 3.5 | 0.5 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 50% | 2.0 | 2.0 | 4.5 | 3.0 | 0.0 | 0.0 | 0.0 | 19.0 |

### KPIs: wfr-a92c160-p48

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 45% (5 of 11) | 25% (5 of 20) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 78% (7 of 9); on the table 78% | 80% (8 of 10); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 78% (7 of 9); on the table 78% | 80% (8 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 33% (5 of 15) | 47% (7 of 15) | 40% (12 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (5 of 11) | 47% (7 of 15) | 46% (12 of 26) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 43% (1722 of 4000) | 58% (2313 of 4000) | 50% (4035 of 8000) |
|   infantry points that never fought | lower | 88% (437 of 497) | 72% (932 of 1293) | 76% (1369 of 1790) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (9 of 12) | 82% (18 of 22) | 79% (27 of 34) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2077 of 3200) | 72% (2848 of 3962) | 69% (4925 of 7162) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (50%) | 2.0 (75%) | 3.7 (61%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (25%) | 0.7 (11%) |
| IN COMBAT: engaged in combat | 1.3 (40%) | 0.0 (0%) | 1.3 (22%) |
| STUPIDITY: Stupidity | 0.3 (10%) | 0.0 (0%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.7 | 3.3 | 4.0 | 1.3 | 2.7 |
| not cast | 3.3 | 0.7 | 1.7 | 6.0 | 4.7 | 15.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 3.7 (61%) | 2.7 (57%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 1.3 (22%) | 0.7 (14%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (80%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 2.3 a game | 1.7 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | 29% (2 of 7) | 50% (5 of 10) |
| the unit moved after it | 100% (3 of 3) | 50% (1 of 2) | 80% (4 of 5) |
| it charged on its next turn | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | 100% (2 of 2) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 70% (40 of 57) | 66% (40 of 61) |
|   cavalry | - | 75% (18 of 24) | 75% (18 of 24) |
|   character | 0% (0 of 4) | 71% (10 of 14) | 56% (10 of 18) |
|   infantry | - | 63% (12 of 19) | 63% (12 of 19) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.3 (24%) | 1.3 (19%) |
| CHARGED: it charged | 0.7 (50%) | 2.0 (35%) | 2.7 (38%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (6%) | 0.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (50%) | 2.0 (35%) | 2.7 (38%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.0 | 1.3 | 83% | 3.7 pts | 29 pts |
| character | 3.3 | 1.0 | 70% | 4.5 pts | 15 pts |
| infantry | 6.0 | 0.7 | 89% | 4.0 pts | 24 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.0 | 4.7 |
| Charges that made contact a game | 3.0 | 3.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | - | 0.50 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | - | 1.00 declared, 1.00 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.19 contact (21 units) | 0.48 declared, 0.35 contact (31 units) | 0.44 declared, 0.29 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 88% (7 of 8) | - | 100% (1 of 1) | 89% (8 of 9) |
| Character in a unit | 100% (3 of 3) | 100% (3 of 3) | 0% (0 of 1) | 86% (6 of 7) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 0% (0 of 3) | 40% (2 of 5) |
| Infantry | 83% (5 of 6) | 100% (3 of 3) | - | 89% (8 of 9) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 67% (2 of 3) | - | - | 67% (2 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | - | 50% (3 of 6) | 15% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 71% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 2 | 78% (7 of 9); on the table 78% | 42% (5 of 12) | 58% | 82% (18 of 22) | 67% (2 of 3); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (4) | 67% (4) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: wfr-a92c160-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 91% (10 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | - | 11% (1 of 9) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 67% (4 of 6) | 100% (1 of 1) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.5 | 3.0 |
| Movement | Points that never moved of their own | 0.0 | 19.0 |
| Movement | Fights charged into per game | 3.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +57 | 1 of 6, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +25 | 4 of 6, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 63% (26 of 41) |
| Shooting | Points destroyed by shooting units | 6.3 | 32.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | - | 2.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.3 / 1.7 / 0.3 | 0.7 / 0.3 / 0.0 / 1.0 |
| Combat | Points destroyed in combat | 114.3 | 271.7 |
| Combat | Points run down | 86.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -19 | +46 |
| Combat | Net per 100 charger points, damage counted | -5.3 | +21.2 |
| Combat | First round won (charged fights) | 67% | 71% |
| Combat | Net points per charged fight | +48 | +38 |
| Combat | Net points per supported fight / lone fight | - / +48 | +60 / +34 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 2 of 7 |
| Game | Points lost | 456.5 | 403.0 |
| Game | VP from objectives | 555.0 | 715.0 |
| Game | Lone holders (player turns) | 1.0 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -284 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 860
- Games not ended: 1 (L2535-1); findings 2, warnings 0

### Opponent rules: wfr-a92c160-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +4.3 | 0.0 | 0.0 | 0.3 | +55.6 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +22.9 | 0.0 | 0.0 |
| ARMY TABLE | 19.0 | +142.0 | 0.0 | 186.0 | 30.3 | +83.5 | 0.0 | 383.0 |
| ASSAILMENT BY POINTS | 1.0 | +0.4 | 0.0 | 126.7 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.3 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +5.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 5.3 | +87.8 | 0.0 | 60.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.3 | -0.7 | 62.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +51.8 | 0.0 | 41.7 |
| CHARACTER GUNS | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.3 | -557.2 | 0.0 | 254.7 | 8.3 | -174.4 | 0.0 | 233.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 286.0 | 0.0 | 2.0 | +0.0 | 15.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +33.2 | 0.0 | 0.0 | 1.7 | +183.7 | 0.0 | 0.0 |
| COVER ONCE | 3.3 | -167.4 | 0.0 | 94.7 | 11.0 | -328.1 | 0.0 | 76.3 |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -21.3 | 164.7 | 0.0 | 0.3 | -86.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +2.0 | 79.7 | 95.3 | 2.3 | +3.2 | 93.7 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +16.4 | 200.0 | 33.3 | 2.7 | +0.0 | 64.3 | 0.0 |
| FALLBACK BY WORTH | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 19.3 | +252.0 | 0.0 | 287.3 | - | - | - | - |
| FEATURE BUFFS | 0.3 | +0.5 | 0.0 | 0.0 | 2.0 | +17.5 | 0.0 | 76.0 |
| FIGHT TO THE END | 1.0 | +0.3 | 0.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| FIVE ACTION | 70.7 | +4035.3 | 286.0 | 613.0 | 82.3 | +6367.1 | 141.3 | 790.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 62.0 | 6.0 | +0.0 | 0.0 | 120.7 |
| FOLLOW UP WEIGHED | 0.7 | +103.0 | 0.0 | 0.0 | 2.0 | +294.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +261.5 | 286.0 | 95.3 | 3.7 | +431.5 | 126.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 327.3 |
| GIVES UP | 1.0 | -15.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +527.4 | 0.0 | 124.0 | 17.7 | +1506.0 | 0.0 | 34.7 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 327.3 |
| HELPER UNSEEN | 1.0 | +0.0 | 0.0 | 95.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 254.7 | 7.7 | +0.0 | 0.0 | 233.3 |
| HIS CHARGE DENIED | 0.3 | +4.6 | 0.0 | 16.7 | 1.3 | +41.4 | 78.7 | 0.0 |
| HIS CHARGE LIST | 8.0 | +0.0 | 0.0 | 139.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 189.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -23.8 | 0.0 | 0.0 | 2.3 | -15.8 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 39.7 | +11.3 | 415.7 | 0.0 | 38.0 | +11.7 | 303.0 | 0.0 |
| HIS MOVE WHY | 26.0 | +0.0 | 0.0 | 170.7 | 14.3 | +0.0 | 0.0 | 298.0 |
| HIS ONE MOVE | 21.3 | -60.7 | 0.0 | 139.0 | 18.3 | -1.7 | 0.0 | 34.7 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 124.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 65.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 55.3 | +1098.7 | 0.0 | 207.7 | 29.0 | +406.4 | 0.0 | 410.7 |
| HIS SHOTS BY HIS RUN | 44.7 | +570.0 | 0.0 | 393.7 | 9.3 | +91.3 | 0.0 | 278.0 |
| HIS TURN DENIED | 0.3 | +3.0 | 38.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 152.0 |
| HOLDER ASSIGNMENT | 8.3 | +516.7 | 0.0 | 0.0 | 8.3 | +692.4 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 3.7 | -192.2 | 286.0 | 16.7 | 3.3 | -124.2 | 126.3 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| IDLE COST | 17.3 | -195.9 | 0.0 | 32.7 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | +50.0 | 0.0 | 62.0 | 1.0 | +5.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 40.0 | 6.0 | +0.0 | 175.0 | 76.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.1 | 16.7 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +1.0 | 164.7 | 78.7 | 0.7 | -3.1 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +15.9 | 0.0 | 0.0 | 1.3 | -16.2 | 0.0 | 86.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +73.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +22.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | +92.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +2.6 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +4.5 | 0.0 | 0.0 | 5.3 | +188.5 | 0.0 | 86.0 |
| MISSILES NEXT TURN | 3.0 | +13.5 | 0.0 | 0.0 | 5.7 | +107.3 | 0.0 | 172.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.0 | -61.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.7 | +541.4 | 0.0 | 124.0 | 5.3 | +489.6 | 0.0 | 34.7 |
| NEARER NOT NEEDED | 9.0 | +310.6 | 0.0 | 0.0 | 6.0 | +255.3 | 0.0 | 288.7 |
| NEXT CHARGE BY LIST | 2.7 | +337.5 | 0.0 | 0.0 | 2.3 | +274.1 | 0.0 | 34.7 |
| NO DOUBLE ROUNDS | 3.7 | -129.7 | 286.0 | 16.7 | 3.0 | -112.7 | 126.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 2.0 | -3.4 | 0.0 | 0.0 |
| OFF BEST | 7.3 | -236.1 | 0.0 | 31.7 | 4.7 | -172.0 | 0.0 | 6.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -38.6 | 0.0 | 94.7 | 3.7 | -53.8 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +20.1 | 0.0 | 0.0 | 1.0 | +6.7 | 0.0 | 38.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +17.0 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.7 | +7.4 | 162.0 | 62.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| PATHS CROSS | 2.3 | +48.1 | 0.0 | 0.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +267.9 | 120.3 | 385.0 | 37.3 | +234.6 | 72.7 | 570.7 |
| PROMISE BY ITS OWN SUM | 7.0 | -249.0 | 0.0 | 186.0 | 8.7 | -273.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -55.1 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1746.1 | 41.7 | 219.3 | 15.7 | +1944.0 | 16.7 | 12.7 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -6.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | +160.6 | 0.0 | 30.0 | - | - | - | - |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +10.6 | 0.0 | 15.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -17.9 | 0.0 | 0.0 | 1.3 | -96.8 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +1.8 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | -119.6 | 286.0 | 95.3 | 3.0 | +33.5 | 77.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -22.0 | 164.7 | 0.0 | 0.3 | -11.0 | 32.7 | 0.0 |
| RUN DOWN | 3.7 | -24.5 | 286.0 | 78.7 | 0.3 | -1.5 | 32.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.0 | -71.5 | 0.0 | 45.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +43.0 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 38.0 |
| SECOND LOOK | 1.7 | +92.5 | 41.7 | 16.7 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -10.0 | 0.0 | 15.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +34.2 | 0.0 | 15.0 | - | - | - | - |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +13.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 0.7 | +0.0 | 0.0 | 15.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.3 | +21.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.0 | 15.0 | 0.0 |
| SHOT RISK POINTS | 33.3 | -187.7 | 0.0 | 393.7 | 9.0 | -3.7 | 0.0 | 180.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 18.0 | +184.6 | 0.0 | 202.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +13.3 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +1.9 | 0.0 | 0.0 | 1.0 | +5.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 62.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 16.7 | - | - | - | - |
| STANDS STILL | 11.3 | +0.0 | 0.0 | 127.3 | 30.3 | +0.0 | 15.0 | 294.3 |
| STAY WORTH | - | - | - | - | 11.3 | +87.0 | 0.0 | 86.0 |
| STRIKE BY THE ODDS | 0.3 | +0.4 | 0.0 | 20.0 | 0.3 | +6.8 | 62.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 6.7 | +866.6 | 0.0 | 124.0 | 3.3 | +52.5 | 0.0 | 44.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 41.7 | 0.0 | 0.7 | +0.0 | 15.0 | 0.0 |
| SUPPORT WORKED OUT | 6.7 | +866.6 | 0.0 | 124.0 | 3.3 | +52.5 | 0.0 | 44.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 38.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -73.4 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 62.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 62.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 62.0 | 1.3 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 62.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.0 | +0.0 | 0.0 | 266.3 | 38.3 | +0.0 | 0.0 | 377.7 |
| TIED UP BY THE SUM | 1.7 | +299.6 | 200.0 | 0.0 | 0.7 | +95.6 | 94.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 48.0 | +494.8 | 0.0 | 667.7 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 62.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | +17.0 | 0.0 | 157.3 | - | - | - | - |
| WHO FIGHTS | 0.3 | +2.1 | 0.0 | 62.0 | 0.3 | -1.1 | 62.0 | 0.0 |
| WHO HITS BACK | 0.3 | +35.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.7 | +24.3 | 0.0 | 78.7 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.7 | -245.1 | 0.0 | 130.7 | 2.0 | -146.1 | 0.0 | 157.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.3 | +195.4 | 34.7 | 65.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.7 | +74.4 | 0.0 | 0.0 | 1.0 | +27.4 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 233 | 233 | 164 | 54.67 | +0 | +0.0 |
| ARMY TABLE | 148 | 148 | 99 | 33.00 | +853 | +8.6 |
| HIS MOVE WHY | 121 | 121 | 82 | 27.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 50 | 50 | 43 | 14.33 | +2354 | +54.8 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1225 | -34.0 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| HIS ONE MOVE | 119 | 115 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOT LIST | 253 | 238 | 28 | 9.33 | +284 | +10.2 |
| THE TABLE AGAIN | 30 | 30 | 26 | 8.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 162 | 149 | 24 | 8.00 | +102 | +4.2 |
| FIVE ACTION | 459 | 431 | 22 | 7.33 | +1200 | +54.6 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| MOVE ORDER | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 19 | 6.33 | -1566 | -82.4 |
| THE RISK READS HIS RUN | 30 | 30 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 33 | 27 | 17 | 5.67 | +1046 | +61.6 |
| TIME ON OUR SIDE | 144 | 113 | 16 | 5.33 | +65 | +4.1 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| FOUR ROUNDS | 24 | 20 | 13 | 4.33 | +572 | +44.0 |
| SHOT RISK POINTS | 127 | 114 | 13 | 4.33 | +151 | +11.6 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 52 | 40 | 10 | 3.33 | +62 | +6.2 |
| NEXT CHARGE BY LIST | 15 | 13 | 10 | 3.33 | +768 | +76.8 |
| QUARTER ODDS | 101 | 91 | 10 | 3.33 | +1034 | +103.4 |
| GOAL WALK | 80 | 77 | 9 | 3.00 | +386 | +42.9 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| CHAFF IN THE MOVE | 16 | 16 | 8 | 2.67 | +15 | +1.9 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1194 | +149.2 |
| PATHS CROSS | 8 | 8 | 8 | 2.67 | +135 | +16.9 |
| CHARGE LOSSES | 77 | 70 | 7 | 2.33 | +214 | +30.5 |
| CHARGE NOW FIRST | 12 | 12 | 6 | 2.00 | -554 | -92.4 |
| TIED UP BY THE SUM | 7 | 6 | 6 | 2.00 | +213 | +35.5 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +130 | +26.0 |
| SECOND LOOK | 5 | 5 | 5 | 1.67 | +278 | +55.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -2 | -0.6 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +166 | +41.5 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +15 | +3.9 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 4 | 1.33 | +3 | +0.7 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| COVER ONCE | 43 | 23 | 3 | 1.00 | +0 | +0.0 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| NEARER NOT NEEDED | 45 | 42 | 3 | 1.00 | +112 | +37.4 |
| WHOLE FIGHT DANGER | 17 | 17 | 3 | 1.00 | +52 | +17.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +180 | +90.0 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +69 | +34.3 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +156 | +77.8 |
| EXACT ROUND | 14 | 11 | 2 | 0.67 | +3 | +1.3 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 21 | 18 | 2 | 0.67 | +73 | +36.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +220 | +109.8 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +30 | +15.1 |
| OVERRUNS AWAY | 6 | 5 | 2 | 0.67 | +9 | +4.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +11 | +5.5 |
| RISK BY ARC | 21 | 18 | 2 | 0.67 | +35 | +17.4 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +22 | +10.9 |
| SUPPORT ADDS | 30 | 26 | 2 | 0.67 | +24 | +12.1 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -300 | -149.9 |
| SUPPORT WORKED OUT | 30 | 26 | 2 | 0.67 | +24 | +12.1 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| DUEL STOPS AT THE KILL | 3 | 3 | 1 | 0.33 | +38 | +38.3 |
| EDGE GIVE GROUND | 2 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 17 | 14 | 1 | 0.33 | +9 | +8.9 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.33 | +4 | +4.5 |
| FALLS SHORT | 58 | 49 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 4 | 2 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +16 | +16.3 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +49 | +49.2 |
| MAX FOR POSITIONING | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -165 | -164.9 |
| REDIRECT COUNTER | 8 | 7 | 1 | 0.33 | +4 | +3.6 |
| SET UP BY THE SET | 2 | 1 | 1 | 0.33 | +57 | +56.9 |
| SHOTS AFTER THE MOVES | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 34 | 27 | 1 | 0.33 | +17 | +17.2 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARACTER GUNS | 19 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 19 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 17 | 17 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 52 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 47 | 43 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 40 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 30 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 30 | 30 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 30 | 30 | 0 | 0.00 | - | - |
| HOLD ODDS | 83 | 82 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 12 | 11 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 19 | 15 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 20 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 7 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 13 | 10 | 0 | 0.00 | - | - |
| ONE ROUTE | 12 | 11 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 221 | trace | - | - | - | - |
| REAL GROUND | 12 | 11 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 6 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 54 | 37 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 44 | 38 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | not checked | - | - | - | - |
| STANDS STILL | 125 | 120 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 9 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 232 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.67 | 36.0 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 3.33 | 82.4 |
| ARMY TABLE | rule | 2.00 | 3.67 | 99.0 |
| NO REASON | gate | 4.00 | - | 30.0 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 92.3 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 16.7 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 149.9 |
| CHAFF PASSED | rule | - | 0.33 | 2.2 |
| JOINT CHARGE NOW | rule | - | 0.33 | 225.6 |
| PATHS CROSS | rule | - | 0.33 | 8.9 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 164.9 |

### Plans: wfr-a92c160-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 50% | 210 | 268 | 128% |
| Mine | join | 4.3 | 100% | 198 | 0 | 0% |
| Mine | move | 27.7 | 95% | 1441 | 0 | 0% |
| Mine | support | 1.7 | 80% | 27 | 0 | 0% |
| Opponent | charge | 2.7 | 75% | 300 | 171 | 57% |
| Opponent | move | 32.0 | 93% | 2005 | 0 | 0% |
| Opponent | shoot | 2.7 | 38% | 105 | 63 | 61% |

### Battle groups: wfr-a92c160-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 50% | 25% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 34 | 60% | 3.0 | 0 (4) | 0 (1) | - | 0 (5) | - |
| Mine | Character | 7 | 50 (7) | 50 | 0 | 3 | 43% | 3.8 | 28 (4) | 73 (3) | - | 29 (3) | 69 (4) |
| Mine | Fast Hammer | 7 | 0 (7) | 0 | 0 | 40 | 29% | 3.6 | 0 (1) | 0 (4) | 0 (2) | 0 (1) | 0 (6) |
| Mine | Hammer | 1 | 208 (1) | 0 | 208 | 0 | 100% | - | 208 (1) | - | - | 208 (1) | - |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 76 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 5 | 30 (5) | 30 | 0 | 0 | 0% | 1.0 | 33 (4) | - | 0 (1) | 0 (2) | 45 (3) |
| Opponent | Clean-up | 2 | 128 (2) | 45 | 83 | 0 | 50% | 1.0 | 257 (1) | 0 (1) | - | 257 (1) | 0 (1) |
| Opponent | Fast Hammer | 3 | 0 (3) | 0 | 0 | 27 | 0% | 2.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Hammer | 6 | 43 (6) | 43 | 0 | 16 | 50% | 3.3 | 0 (3) | 169 (2) | 0 (1) | 338 (1) | 0 (5) |
| Opponent | Shooter | 5 | 0 (5) | 0 | 0 | 75 | 0% | 1.0 | 0 (1) | 0 (3) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: wfr-a92c160-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 0 | 239 | 5.0 | 1.0 | 48 | 37 | +11 | 1 of 5 | 3 of 5 | - | +11 |
| Mine | Warriors of Chaos | 1 | 19 | 236 | 1.0 | 1.0 | 236 | 0 | +236 | 1 of 1 | 1 of 1 | - | +236 |
| **Mine** | all armies | 2 | 10 | 238 | 3.0 | 1.0 | 79 | 31 | +48 | 2 of 6 | 4 of 6 | - | +48 |
| Opponent | Wood Elf Realms | 2 | 49 | 314 | 3.5 | 1.1 | 90 | 52 | +38 | 2 of 7 | 5 of 7 | +60 | +34 |

### Effective charges: wfr-a92c160-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 1 (net +0) | 0 | 0 | 0 | 2 (net +57) | 1 (net -186) | 1 | 0% (0 of 4) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +236) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 7 | 1 (net +0) | 0 | 0 | 0 | 1 (net +60) | 4 (net +142) | 1 | 0% (0 of 6) |

### Charged fights, damage counted: wfr-a92c160-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 102 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 332 | 368 | +25 | 118 | 236 | -118 | -35.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 471 | 120 | +57 | 57 | 0 | +57 | +12.1 |
| Mine | No odds | 1 | 471 | 125 | +125 | 125 | 118 | +7 | +1.5 |
| Mine | All fights | 6 | 355 | 200 | +48 | 79 | 98 | -19 | -5.3 |
| Opponent | Long shot (under 50%) | 1 | 499 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 176 | 95 | +142 | 142 | 0 | +142 | +80.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 204 | 60 | +60 | 60 | 0 | +60 | +29.4 |
| Opponent | No odds | 1 | 104 | 479 | -362 | 53 | 362 | -309 | -296.9 |
| Opponent | All fights | 7 | 216 | 185 | +38 | 97 | 52 | +46 | +21.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p48 | move | 11 | 4 (36%) | 3 (27%) | 3 (27%) | 4 (36%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

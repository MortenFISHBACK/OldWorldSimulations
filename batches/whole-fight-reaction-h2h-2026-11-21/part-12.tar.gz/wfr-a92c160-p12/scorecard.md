# Doctrine scorecard: wfr-a92c160-p12

### Scorecard: wfr-a92c160-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 5 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 3 | 0 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 1 | 5 | 3 | 4 | 0 | 0 | 0 | 200 |
| **Average** | | | Mine | 33% | 4.0 | 3.0 | 4.0 | 2.3 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 33% | 0.5 | 3.0 | 3.7 | 2.3 | 0.0 | 0.0 | 0.0 | 123.3 |

### KPIs: wfr-a92c160-p12

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 17) | 0% (0 of 34) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 80% | - | 60% (3 of 5); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 56% (5 of 9); on the table 67% | 100% (3 of 3); on the table 100% | 67% (8 of 12); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 17% (1 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 80% (4 of 5) | 17% (1 of 6) | 45% (5 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 86% (6 of 7) | 77% (10 of 13) |
| Points that never fought | lower | 27% (1602 of 5998) | 36% (2167 of 5998) | 31% (3769 of 11996) |
|   infantry points that never fought | lower | 51% (457 of 902) | 30% (321 of 1072) | 39% (778 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 65% (17 of 26) | 62% (28 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (2344 of 5038) | 58% (3113 of 5360) | 52% (5457 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (50%) | 1.0 (60%) | 1.3 (57%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (40%) | 0.7 (29%) |
| IN COMBAT: engaged in combat | 0.3 (50%) | 0.0 (0%) | 0.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.3 | 2.0 | 1.7 | 0.3 | 1.3 |
| not cast | 3.0 | 0.0 | 2.0 | 2.3 | 1.7 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.3 (17%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (11%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (89%) | - | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 83% (5 of 6) | - | 83% (5 of 6) |
| the unit moved after it | 100% (5 of 5) | - | 100% (5 of 5) |
| it charged on its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| the enemy charged it first | 0% (0 of 5) | - | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | - | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 29% (2 of 7) | 71% (27 of 38) | 64% (29 of 45) |
|   cavalry | 67% (2 of 3) | 92% (11 of 12) | 87% (13 of 15) |
|   character | 0% (0 of 4) | 50% (7 of 14) | 39% (7 of 18) |
|   infantry | - | 75% (9 of 12) | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (20%) | 1.3 (36%) | 1.7 (31%) |
| CHARGED: it charged | 0.3 (20%) | 1.7 (45%) | 2.0 (38%) |
| NO TARGET IN RANGE | 0.7 (40%) | 0.3 (9%) | 1.0 (19%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (9%) | 0.3 (6%) |
| OTHER BAR | 0.3 (20%) | 0.0 (0%) | 0.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.0 | 1.0 | 92% | 1.0 pts | 8 pts |
| character | 2.3 | 0.3 | 86% | 7.8 pts | 18 pts |
| infantry | 5.0 | 0.7 | 87% | 5.5 pts | 28 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.3 | 4.8 |
| Charges that made contact a game | 2.3 | 4.7 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 0.75 contact (4 units) | 1.00 declared, 1.00 contact (1 units) | 1.40 declared, 0.80 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.18 contact (22 units) | 0.58 declared, 0.50 contact (26 units) | 0.46 declared, 0.35 contact (48 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 86% (6 of 7) | 80% (4 of 5) | 0% (0 of 1) | 77% (10 of 13) |
| Character in a unit | 100% (4 of 4) | 50% (1 of 2) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 67% (2 of 3) | 100% (1 of 1) | 29% (2 of 7) | 45% (5 of 11) |
| Infantry | 43% (3 of 7) | 0% (0 of 1) | - | 38% (3 of 8) |
| Monster | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 67% (2 of 3); on the table 100% | 67% (4 of 6) | 23% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 62% (5 of 8); on the table 62% | 17% (1 of 6) | 38% | 60% (15 of 25) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 27% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (5) | 43% (3) | 42% (8) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: wfr-a92c160-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (6 of 11) | 80% (12 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 0% (0 of 7) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 56.7 | 123.3 |
| Movement | Fights charged into per game | 2.3 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 6, net +0 | 3 of 11, net +41 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 6, net +118 | 2 of 11, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +0 | 4 of 11, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.3 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 58% (18 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.7 / 0.3 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 119.7 | 280.3 |
| Combat | Points run down | 97.7 | 40.7 |
| Combat | Net points per charged fight, damage counted | +65 | +49 |
| Combat | Net per 100 charger points, damage counted | +17.8 | +15.1 |
| Combat | First round won (charged fights) | 71% | 64% |
| Combat | Net points per charged fight | +65 | +44 |
| Combat | Net points per supported fight / lone fight | - / +65 | - / +44 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 6 of 14 |
| Game | Points lost | 331.0 | 319.0 |
| Game | VP from objectives | 573.3 | 590.0 |
| Game | Lone holders (player turns) | 4.0 | 0.5 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -24 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 650
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: wfr-a92c160-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.0 | +365.1 | 0.0 | 46.7 | 21.0 | -99.3 | 0.0 | 105.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -9.9 | 57.7 | 62.0 | - | - | - | - |
| CAST JOB | 1.0 | +4.0 | 56.7 | 0.0 | 2.0 | +14.9 | 199.3 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +20.3 | 0.0 | 15.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.0 | -0.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 2.0 | +49.2 | 0.0 | 0.0 | 0.7 | +48.2 | 0.0 | 105.7 |
| CHARGE LOSSES | 13.0 | -248.1 | 0.0 | 0.0 | 6.0 | -185.1 | 0.0 | 160.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.3 | +0.0 | 240.3 | 0.0 | 2.0 | +0.0 | 127.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 21.3 | +0.0 | 0.0 | 203.3 | 10.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +89.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.3 | -834.2 | 0.0 | 102.7 | 6.3 | -339.1 | 0.0 | 95.7 |
| DENIED BY THE FIGHT | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -142.2 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | -7.9 | 30.3 | 62.0 | 2.3 | +13.3 | 159.3 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +4.1 | 153.3 | 62.0 | 4.3 | +1.2 | 236.3 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 21.3 | +342.8 | 0.0 | 117.7 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 1.0 | +14.6 | 0.0 | 123.0 |
| FIGHT TO THE END | 1.0 | +30.3 | 0.0 | 0.0 | 0.3 | +1.0 | 40.7 | 0.0 |
| FIVE ACTION | 82.7 | +3689.3 | 240.3 | 444.0 | 91.7 | +5387.2 | 435.7 | 485.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 127.7 | 9.0 | +0.0 | 0.0 | 153.3 |
| FOLLOW UP WEIGHED | 1.0 | +135.3 | 0.0 | 0.0 | 0.7 | +147.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +232.3 | 183.7 | 62.0 | 5.0 | +570.9 | 236.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 62.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -21.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -24.8 | 16.7 | 0.0 |
| GOAL WALK | 7.0 | +528.5 | 0.0 | 0.0 | 12.7 | +1028.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 30.3 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 62.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 130.3 |
| HIS CHARGE DENIED | 0.3 | +9.7 | 0.0 | 0.0 | 0.3 | +22.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -12.2 | 0.0 | 0.0 | 1.0 | -23.3 | 0.0 | 30.3 |
| HIS MOVE AS HE DECIDES | 46.3 | +12.7 | 347.7 | 0.0 | 42.7 | +12.0 | 385.3 | 0.0 |
| HIS MOVE WHY | 25.3 | +0.0 | 0.0 | 104.0 | 11.7 | +0.0 | 0.0 | 90.3 |
| HIS ONE MOVE | 21.7 | +58.2 | 0.0 | 15.0 | 20.0 | +52.1 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 62.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 63.3 | 19.0 | +0.0 | 0.0 | 121.3 |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.3 | +430.2 | 0.0 | 98.3 | 10.7 | +106.9 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 31.0 | +370.3 | 0.0 | 158.3 | 10.7 | +206.2 | 0.0 | 297.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 81.3 | 16.0 | +0.0 | 0.0 | 246.0 |
| HOLDER ASSIGNMENT | 11.3 | +1015.0 | 0.0 | 40.7 | 9.7 | +1157.2 | 0.0 | 90.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -151.1 | 183.7 | 62.0 | 5.0 | -244.9 | 236.3 | 0.0 |
| IDLE COST | 22.7 | -308.8 | 0.0 | 135.3 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | -1.3 | 0.0 | 0.0 | 0.7 | -10.5 | 40.7 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 307.7 | 397.3 | 6.3 | +0.0 | 166.0 | 57.7 |
| LONG SHOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | -1.7 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +7.6 | 40.0 | 0.0 | 2.3 | -10.8 | 102.7 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 15.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 40.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +91.5 | 0.0 | 15.0 | 2.3 | +91.5 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +5.2 | 0.0 | 0.0 | 2.0 | +21.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +3.4 | 0.0 | 0.0 | 3.0 | +27.8 | 0.0 | 0.0 |
| MOVE ORDER | 4.0 | +0.0 | 0.0 | 56.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +639.2 | 0.0 | 62.0 | 5.3 | +367.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +354.7 | 0.0 | 40.7 | 6.7 | +308.8 | 0.0 | 120.7 |
| NEXT CHARGE BY LIST | 6.0 | +361.7 | 0.0 | 62.0 | 4.0 | +278.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -149.3 | 183.7 | 62.0 | 3.7 | -122.3 | 221.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -155.5 | 0.0 | 30.0 | 6.3 | -387.5 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.3 | +1.0 | 30.3 | 0.0 | 0.7 | -4.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -111.1 | 0.0 | 15.0 | 3.3 | -74.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +16.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -75.1 | 0.0 | 40.7 | 3.3 | +18.2 | 0.0 | 32.7 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +10.9 | 30.3 | 0.0 | 0.7 | +28.6 | 40.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +8.3 | 30.3 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +19.5 | 0.0 | 0.0 | 1.0 | +58.3 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +277.9 | 112.7 | 436.0 | 45.3 | +365.9 | 461.3 | 461.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 11.7 | -245.3 | 0.0 | 0.0 | 10.7 | -704.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 6.7 | +586.6 | 48.0 | 0.0 | 7.7 | +1148.8 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +93.8 | 0.0 | 0.0 | 2.3 | +6.8 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +41.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +294.3 | 0.0 | 70.0 | 3.0 | +38.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 30.0 | 3.7 | +71.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | -9.9 | 57.7 | 62.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.0 | -75.6 | 0.0 | 62.0 | 0.7 | -195.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.3 | +0.0 | 0.0 | 30.3 |
| RESERVE FALL BACK | 0.3 | +36.3 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +52.0 | 183.7 | 62.0 | 4.3 | +446.6 | 236.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -22.4 | 80.7 | 0.0 | 0.7 | -47.3 | 0.0 | 0.0 |
| RUN DOWN | 3.7 | -46.9 | 183.7 | 62.0 | 1.7 | -9.2 | 40.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.7 | -96.8 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +31.8 | 0.0 | 0.0 | 0.7 | +11.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.3 | -83.3 | 0.0 | 107.0 | 2.3 | -19.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 5.0 | +41.9 | 65.3 | 107.0 | 3.0 | +21.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.3 | 0.0 | 15.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 15.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.7 | +29.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -13.8 | 15.0 | 0.0 |
| SHOT RISK POINTS | 12.7 | -149.0 | 0.0 | 30.0 | 7.0 | +1.9 | 0.0 | 161.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.0 | +12.5 | 0.0 | 0.0 | 9.0 | +59.8 | 0.0 | 0.0 |
| SPELL WORTH | 2.7 | +14.9 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 112.7 | 7.0 | +0.0 | 0.0 | 120.7 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 13.3 | +0.0 | 56.7 | 0.0 | 40.0 | +0.0 | 199.3 | 80.0 |
| STAY WORTH | 0.7 | +1.9 | 0.0 | 0.0 | 10.7 | +46.2 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 1.0 | +42.0 | 0.0 | 124.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.0 | +484.1 | 0.0 | 0.0 | 6.0 | +488.5 | 0.0 | 123.0 |
| SUPPORT WORKED OUT | 3.0 | +484.1 | 0.0 | 0.0 | 6.0 | +488.5 | 0.0 | 123.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 15.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 25.0 | 1.7 | +0.0 | 0.0 | 78.3 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 63.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 78.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 206.0 | 43.7 | +0.0 | 0.0 | 214.0 |
| TIED UP BY THE SUM | 2.7 | +377.9 | 183.7 | 62.0 | 1.7 | +260.1 | 102.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 70.3 | +654.2 | 30.0 | 294.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +14.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +2.5 | 0.0 | 62.0 | 0.7 | -2.6 | 40.7 | 0.0 |
| WHO HITS BACK | 1.3 | +228.1 | 0.0 | 40.7 | 0.3 | +31.0 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -113.6 | 0.0 | 0.0 | 3.3 | -155.1 | 0.0 | 90.3 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +10.6 | 40.7 | 0.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 2.3 | +81.2 | 62.0 | 113.3 |
| WOUNDS ON THE RANKS | 0.3 | +5.3 | 0.0 | 0.0 | 0.7 | +5.3 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 267 | 267 | 193 | 64.33 | +0 | +0.0 |
| ARMY TABLE | 111 | 111 | 86 | 28.67 | +1616 | +18.8 |
| HIS MOVE WHY | 111 | 111 | 74 | 24.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 63 | 63 | 58 | 19.33 | +4244 | +73.2 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 211 | 172 | 40 | 13.33 | +47 | +1.2 |
| FIVE ACTION | 523 | 491 | 38 | 12.67 | +2183 | +57.4 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -1628 | -42.8 |
| HIS ONE MOVE | 125 | 117 | 35 | 11.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 34 | 11.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 30 | 10.00 | -2849 | -95.0 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| GOAL WALK | 59 | 57 | 18 | 6.00 | +1088 | +60.5 |
| FOUR ROUNDS | 28 | 28 | 17 | 5.67 | +655 | +38.5 |
| THE RISK READS HIS RUN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| HIS SHOT LIST | 123 | 108 | 15 | 5.00 | +115 | +7.7 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| TIED UP BY THE SUM | 13 | 13 | 13 | 4.33 | +640 | +49.2 |
| HIS SHOTS BY HIS RUN | 125 | 115 | 12 | 4.00 | +62 | +5.2 |
| IDLE COST | 68 | 42 | 12 | 4.00 | +120 | +10.0 |
| QUARTER ODDS | 43 | 41 | 12 | 4.00 | +905 | +75.4 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 11 | 3.67 | +103 | +9.3 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 10 | 3.33 | +302 | +30.2 |
| MOVE TO CHARGE COMPUTED | 46 | 32 | 9 | 3.00 | +213 | +23.7 |
| SET UP BY THE SET | 24 | 23 | 9 | 3.00 | +338 | +37.5 |
| SUPPORT ADDS | 27 | 25 | 9 | 3.00 | +571 | +63.5 |
| SUPPORT WORKED OUT | 27 | 25 | 9 | 3.00 | +571 | +63.5 |
| CHALLENGE BY POINTS | 8 | 8 | 8 | 2.67 | +292 | +36.6 |
| RISK BY ARC | 25 | 25 | 8 | 2.67 | +559 | +69.9 |
| CAST JOB | 9 | 9 | 7 | 2.33 | +3 | +0.4 |
| COVER ONCE | 47 | 29 | 7 | 2.33 | +22 | +3.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 16 | 16 | 6 | 2.00 | -297 | -49.5 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 24 | 6 | 2.00 | +135 | +22.6 |
| FALLS SHORT | 64 | 50 | 5 | 1.67 | +27 | +5.3 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +847 | +169.4 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +234 | +46.7 |
| SHOT RISK POINTS | 59 | 53 | 5 | 1.67 | +103 | +20.6 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +603 | +120.7 |
| WHOLE FIGHT DANGER | 17 | 15 | 5 | 1.67 | +219 | +43.8 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 10 | 8 | 4 | 1.33 | +0 | +0.0 |
| REDIRECT COUNTER | 19 | 17 | 4 | 1.33 | +287 | +71.8 |
| STAY WORTH | 34 | 24 | 4 | 1.33 | +19 | +4.8 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -1 | -0.5 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -35 | -11.8 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +49 | +16.3 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +131 | +43.7 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +126 | +42.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 14 | 14 | 2 | 0.67 | +0 | +0.2 |
| HONEST WORTH | 28 | 28 | 2 | 0.67 | +66 | +33.1 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | -9 | -4.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +110 | +55.2 |
| SHOTS IN THE MOVE | 30 | 19 | 2 | 0.67 | +13 | +6.6 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +67 | +33.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +88 | +87.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -30 | -29.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -41 | -41.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 23 | 23 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 13 | 13 | 1 | 0.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| ONE FIGHT FORMULA | 28 | 8 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +19 | +19.1 |
| ONE OBJECTIVE FORMULA | 30 | 28 | 1 | 0.33 | +20 | +20.0 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| PROMISE KNOWS THE FIGHT | 7 | 3 | 1 | 0.33 | -2 | -1.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -4 | -3.8 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 7 | 7 | 1 | 0.33 | +3 | +2.9 |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARGE LOSSES | 57 | 50 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 96 | 91 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 23 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 9 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 92 | 83 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 102 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 5 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 11 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 7 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 45 | 40 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 23 | 23 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 17 | 16 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 14 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 54 | 48 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 160 | 148 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 6.33 | 46.1 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 6.33 | 95.0 |
| ARMY TABLE | rule | 2.00 | 2.33 | 60.7 |
| CHARGE NOW FIRST | rule | 1.67 | 0.33 | 49.5 |
| CHAFF PASSED | rule | - | 0.67 | 0.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 3.2 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 17.8 |
| REFUSING RETIRES | rule | - | 0.67 | 4.5 |
| RULE SWITCHED OFF | gate | 0.67 | - | 5.3 |
| AFTERMATH BAND | gate | 0.33 | - | 3.8 |
| BEST PRIZE | rule | 0.33 | - | 29.6 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 41.1 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.7 |
| REDIRECT WEIGHED | rule | 0.33 | - | 3.8 |

### Plans: wfr-a92c160-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 64% | 322 | 221 | 69% |
| Mine | join | 4.3 | 100% | 170 | 0 | 0% |
| Mine | move | 34.0 | 95% | 1315 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 69 | 57 | 82% |
| Mine | support | 1.0 | 67% | 0 | 0 | - |
| Opponent | charge | 4.3 | 69% | 506 | 219 | 43% |
| Opponent | join | 2.0 | 100% | 118 | 0 | 0% |
| Opponent | move | 36.3 | 93% | 1814 | 0 | 0% |
| Opponent | shoot | 2.0 | 83% | 77 | 147 | 190% |
| Opponent | support | 0.7 | 100% | 35 | 0 | 0% |

### Battle groups: wfr-a92c160-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 60% | 50% | 50% | 0% | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 103 (9) | 0 | 103 | 37 | 67% | 3.0 | 0 (4) | 200 (3) | 200 (2) | 160 (6) | 0 (3) |
| Mine | Character | 9 | 39 (9) | 28 | 11 | 2 | 22% | 3.6 | 56 (2) | 27 (6) | 0 (1) | 49 (6) | 0 (3) |
| Mine | Clean-up | 1 | 148 (1) | 0 | 148 | 100 | 0% | 4.0 | - | - | 148 (1) | 148 (1) | - |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 100 | 0% | 2.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 6 | 6 (6) | 0 | 6 | 25 | 17% | 4.8 | - | 8 (4) | 0 (2) | 10 (3) | 0 (3) |
| Mine | Hammer | 2 | 49 (2) | 18 | 30 | 0 | 0% | 3.0 | - | 49 (2) | - | 54 (1) | 46 (1) |
| Mine | Holder | 1 | 71 (1) | 0 | 71 | 0 | 0% | 4.0 | 71 (1) | - | - | 71 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 121 (3) | 0 | 121 | 56 | 100% | - | 0 (1) | 214 (1) | 0 (1) | 121 (3) | - |
| Opponent | Character | 10 | 29 (10) | 29 | 0 | 0 | 50% | 2.2 | 11 (3) | 44 (6) | 0 (1) | 42 (6) | 10 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 32 (5) | 9 | 24 | 11 | 40% | 3.0 | 30 (2) | 0 (1) | 51 (2) | 41 (2) | 28 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 9 (6) | 6 | 4 | 65 | 0% | 4.0 | - | 12 (4) | 0 (2) | 0 (3) | 20 (3) |
| Opponent | Holder | 6 | 34 (6) | 0 | 34 | 38 | 33% | 2.8 | 0 (4) | 106 (2) | - | 0 (1) | 39 (5) |
| Opponent | Shooter | 1 | 56 (1) | 0 | 56 | 0 | 0% | 2.0 | - | - | 56 (1) | 56 (1) | - |

### Charged fights: wfr-a92c160-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 181 | 2.5 | 1.0 | 72 | 0 | +72 | 1 of 5 | 3 of 5 | - | +72 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 2.0 | 1.0 | 46 | 0 | +46 | 0 of 2 | 2 of 2 | - | +46 |
| **Mine** | all armies | 3 | 0 | 151 | 2.3 | 1.0 | 65 | 0 | +65 | 1 of 7 | 5 of 7 | - | +65 |
| Opponent | Warriors of Chaos | 2 | 0 | 420 | 5.0 | 1.0 | 84 | 34 | +50 | 4 of 10 | 8 of 10 | - | +50 |
| Opponent | Wood Elf Realms | 1 | 0 | 122 | 4.0 | 1.0 | 30 | 0 | +30 | 2 of 4 | 1 of 4 | - | +30 |
| **Opponent** | all armies | 3 | 0 | 321 | 4.7 | 1.0 | 69 | 24 | +44 | 6 of 14 | 9 of 14 | - | +44 |

### Effective charges: wfr-a92c160-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 2 (net +0) | 0 | 0 | 0 | 2 (net +132) | 0 | 1 | 0% (0 of 4) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +91) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 10 | 1 (net +0) | 0 | 0 | 2 (net -60) | 2 (net +60) | 3 (net +139) | 2 | 0% (0 of 8) |
| Opponent | Wood Elf Realms | 4 | 2 (net +61) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: wfr-a92c160-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 152 | 228 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 323 | 109 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 485 | 118 | +118 | 118 | 0 | +118 | +24.4 |
| Mine | No odds | 1 | 471 | 98 | +98 | 98 | 0 | +98 | +20.8 |
| Mine | All fights | 7 | 365 | 145 | +65 | 65 | 0 | +65 | +17.8 |
| Opponent | Long shot (under 50%) | 3 | 363 | 275 | +41 | 57 | 80 | -23 | -6.3 |
| Opponent | 76-89% | 2 | 116 | 152 | -60 | 25 | 85 | -60 | -51.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 409 | 156 | +104 | 180 | 16 | +164 | +40.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 382 | 60 | +60 | 60 | 0 | +60 | +15.7 |
| Opponent | No odds | 3 | 263 | 381 | +27 | 116 | 84 | +32 | +12.1 |
| Opponent | All fights | 14 | 322 | 215 | +44 | 101 | 52 | +49 | +15.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p12 | move | 19 | 4 (21%) | 1 (5%) | 5 (26%) | 10 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

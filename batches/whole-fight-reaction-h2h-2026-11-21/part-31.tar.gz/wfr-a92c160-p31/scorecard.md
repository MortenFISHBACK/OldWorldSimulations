# Doctrine scorecard: wfr-a92c160-p31

### Scorecard: wfr-a92c160-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 4 | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 262 |
| L1131 | 3 | 1 | Opponent | no | 4 | 3 | 2 | 3 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 3.0 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 | 197.3 |
| **Average** | | | Opponent | 0% | 2.7 | 4.5 | 1.0 | 3.0 | 1.3 | 0.0 | 0.0 | 56.7 |

### KPIs: wfr-a92c160-p31

Rules off - Opponent only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (7 of 15) | 0% (0 of 14) | 24% (7 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (9 of 9); on the table 100% | - | 100% (9 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 20% (1 of 5); on the table 60% | - | 20% (1 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 73% (11 of 15); on the table 87% | 0% (0 of 1); on the table 0% | 69% (11 of 16); on the table 81% |
| Magic missiles tried each own turn | 50%+ | 39% (26 of 66) | 11% (2 of 18) | 33% (28 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (26 of 55) | 15% (2 of 13) | 41% (28 of 68) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (5 of 10) | 50% (5 of 10) |
| Points that never fought | lower | 43% (2571 of 5998) | 58% (3461 of 5998) | 50% (6032 of 11996) |
|   infantry points that never fought | lower | 77% (559 of 730) | 78% (708 of 913) | 77% (1267 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 36% (9 of 25) | 75% (21 of 28) | 57% (30 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 5.7 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (8 of 8); 3.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 0.7 uses a game | 33% (2 of 6); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 31% (1731 of 5614) | 76% (4442 of 5828) | 54% (6173 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (25%) | 1.7 (31%) | 5.0 (27%) |
| MARCHED: its unit marched | 6.0 (45%) | 1.3 (25%) | 7.3 (39%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 3.7 (28%) | 0.3 (6%) | 4.0 (21%) |
| GONE: slain | 0.0 (0%) | 1.3 (25%) | 1.3 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (2%) | 0.3 (6%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 3.3 | 2.3 | 9.3 | 2.0 | 2.7 |
| not cast | 1.0 | 8.7 | 1.7 | 18.7 | 6.0 | 33.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.0 (81%) | 0.3 (20%) | 5.0 (27%) | 2.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (39%) | 2.0 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (21%) | 1.3 (22%) | 0.0 (0%) |
| GONE: slain | 0.7 (67%) | 0.7 (8%) | 0.7 (40%) | 1.3 (7%) | 0.0 (0%) | 3.0 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.7 (4%) | 0.7 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (33%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 29.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.3 a game | 1.2 a game |
| stood (cast and not dispelled) | - | 71% (5 of 7) | 71% (5 of 7) |
| the unit moved after it | - | 20% (1 of 5) | 20% (1 of 5) |
| it charged on its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| the enemy charged it first | - | 20% (1 of 5) | 20% (1 of 5) |
| it fought by the end of its next turn | - | 20% (1 of 5) | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 5) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | - | 80% (4 of 5) | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 86% (48 of 56) | 20% (3 of 15) | 72% (51 of 71) |
|   cavalry | - | 33% (2 of 6) | 33% (2 of 6) |
|   character | - | 0% (0 of 8) | 0% (0 of 8) |
|   chariot | 62% (5 of 8) | - | 62% (5 of 8) |
|   infantry | 92% (11 of 12) | 100% (1 of 1) | 92% (12 of 13) |
|   war machine | 89% (32 of 36) | - | 89% (32 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (25%) | 0.3 (8%) | 1.0 (15%) |
| CHARGED: it charged | 0.3 (12%) | 0.3 (8%) | 0.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |
| MOVED: a war machine that moved | 1.0 (38%) | 0.0 (0%) | 1.0 (15%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.7 (67%) | 2.7 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (12%) | 0.0 (0%) | 0.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |
| OTHER BAR | 0.3 (12%) | 0.0 (0%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.7 | 0.3 | 80% | 13.0 pts | 22 pts |
| infantry | 7.7 | 1.0 | 91% | 7.0 pts | 53 pts |
| war machine | 11.7 | 9.0 | 54% | 27.4 pts | 319 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 2.0 | 2.8 |
| Charges that made contact a game | 3.3 | 1.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.86 declared, 0.86 contact (7 units) | 1.00 declared, 0.67 contact (3 units) | 0.90 declared, 0.80 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (10 units) | 0.15 declared, 0.10 contact (20 units) | 0.27 declared, 0.20 contact (30 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 50% (1 of 2) | 50% (1 of 2) | 53% (8 of 15) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 17% (1 of 6) | 43% (3 of 7) | 50% (9 of 18) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 73% (11 of 15); on the table 87% | 39% (26 of 66) | 43% | 36% (9 of 25) | 100% (7 of 7); 5.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 87% | 78% (7 of 9) | 0.0 uses a game | 33% (2 of 6); 2.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 40% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 46% | 67% (8 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 83% (5) | 89% (8) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 82% (9 of 11) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (13 of 55) | 100% (1 of 1) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (3 of 3) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 89% (8 of 9) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.0 | 3.0 |
| Movement | Points that never moved of their own | 197.3 | 56.7 |
| Movement | Fights charged into per game | 2.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 8, net +393 | 1 of 4, net -201 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 1 of 4, net +296 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 8, net +0 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +154 | 2 of 4, net +75 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.3 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (9 of 16) | 43% (3 of 7) |
| Shooting | Points destroyed by shooting units | 47.7 | 0.0 |
| Shooting | War machine shots | 10.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (15 of 32) | - |
| Shooting | Points destroyed by war machines | 167.0 | 0.0 |
| Magic | Magic missiles cast | 7.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 18% (4 of 22) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 10.0 | 0.3 |
| Magic | Wounds caused by other spells | 3.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 191.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.0 / 1.7 / 1.0 | 1.3 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 445.7 | 148.7 |
| Combat | Points run down | 47.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +216 | +81 |
| Combat | Net per 100 charger points, damage counted | +64.6 | +38.2 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +200 | +61 |
| Combat | Net points per supported fight / lone fight | +332 / +157 | - / +61 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 3 of 4 |
| Game | Points lost | 115.3 | 1021.7 |
| Game | VP from objectives | 660.0 | 643.3 |
| Game | Lone holders (player turns) | 3.0 | 2.7 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +948 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1137
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +4.6 | 0.0 | 16.7 |
| ARMY TABLE | 9.3 | +588.6 | 0.0 | 0.0 | 22.3 | +80.8 | 0.0 | 873.7 |
| ARTILLERY RE-ROLL WEIGHED | 7.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.2 | 0.0 | 0.0 | 1.3 | +21.7 | 0.0 | 128.3 |
| BEST PRIZE | - | - | - | - | 0.3 | -6.7 | 0.0 | 38.7 |
| BOMBING RUN | 0.3 | +15.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 128.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.3 | +242.1 | 912.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.3 | +96.4 | 282.7 | 0.0 | 0.7 | +16.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.7 | +0.0 | 0.0 | 313.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +173.8 | 0.0 | 100.0 |
| CHALLENGE BY POINTS | 0.3 | +0.5 | 0.0 | 0.0 | 1.0 | +80.0 | 0.0 | 236.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +53.1 | 156.7 | 0.0 | 0.3 | -19.4 | 0.0 | 67.0 |
| CHARGE LOSSES | 11.0 | -337.5 | 0.0 | 100.0 | 27.0 | -1565.7 | 0.0 | 1500.7 |
| CHARGE NOW FIRST | 4.3 | +0.0 | 744.0 | 0.0 | 1.0 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 77.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 16.7 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 2.0 | +132.5 | 156.7 | 156.7 |
| COVER ONCE | 13.3 | -755.1 | 0.0 | 50.0 | 9.3 | -753.6 | 0.0 | 620.0 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -28.7 | 131.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +52.5 | 41.0 | 0.0 | 0.3 | +33.0 | 0.0 | 67.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +1.0 | 0.0 | 59.0 |
| EXACT ROUND | 2.0 | +14.8 | 384.3 | 0.0 | 1.0 | +11.1 | 50.0 | 55.3 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 306.0 | 0.0 | 1.7 | +0.4 | 50.0 | 55.3 |
| FALLS SHORT | - | - | - | - | 22.0 | +134.5 | 0.0 | 1359.7 |
| FIGHT TO THE END | 1.3 | +14.7 | 361.0 | 0.0 | 0.3 | +2.5 | 0.0 | 16.7 |
| FIRE IN ORDER | 0.7 | +0.0 | 47.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 85.7 | +5641.9 | 3175.7 | 100.0 | 75.7 | +4670.2 | 50.0 | 2895.7 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 50.0 | 7.0 | +0.0 | 0.0 | 336.3 |
| FOLLOW UP WEIGHED | 2.3 | +223.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +354.7 | 760.7 | 0.0 | 2.0 | +133.4 | 50.0 | 122.3 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 40.0 |
| FRIEND SHOOTS FIRST | 1.7 | -27.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -26.2 | 76.3 | 0.0 | - | - | - | - |
| GOAL WALK | 0.7 | +63.3 | 0.0 | 0.0 | 13.0 | +1721.4 | 0.0 | 250.0 |
| GUN MASK | 4.3 | +344.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 100.0 | 17.0 | +0.0 | 0.0 | 1290.3 |
| HIS CHARGE DENIED | 0.3 | +40.7 | 38.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 158.0 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 50.0 | 5.7 | +0.0 | 0.0 | 794.0 |
| HIS MOVE AND SHOT | 4.7 | -27.2 | 0.0 | 0.0 | 14.3 | -220.4 | 0.0 | 1271.0 |
| HIS MOVE AS HE DECIDES | 38.3 | +8.7 | 1580.0 | 0.0 | 33.7 | +11.7 | 100.0 | 0.0 |
| HIS MOVE WHY | 10.3 | +0.0 | 0.0 | 0.0 | 25.7 | +0.0 | 0.0 | 771.0 |
| HIS ONE MOVE | 22.0 | +11.4 | 0.0 | 50.0 | 18.3 | +140.9 | 0.0 | 453.7 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 50.0 | 3.3 | +0.0 | 0.0 | 176.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 100.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 13.0 | +112.0 | 0.0 | 0.0 | 58.3 | +4253.9 | 0.0 | 2313.0 |
| HIS SHOTS BY HIS RUN | 24.7 | +193.2 | 0.0 | 100.0 | 57.7 | +2137.0 | 0.0 | 2691.3 |
| HIS TURN DENIED | 0.3 | +9.8 | 65.0 | 0.0 | 0.3 | +3.4 | 50.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 9.7 | +918.6 | 0.0 | 0.0 | 10.7 | +968.2 | 0.0 | 61.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -116.9 | 760.7 | 0.0 | 1.3 | -26.9 | 0.0 | 55.3 |
| HUNT IN PAIRS | 0.7 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +106.1 | 0.0 | 38.7 |
| IDLE COST | - | - | - | - | 19.7 | -347.6 | 0.0 | 778.0 |
| JOINT CHARGE NOW | 1.3 | +61.6 | 408.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 141.3 | 0.0 | 3.3 | +0.0 | 0.0 | 536.7 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.3 | -0.2 | 568.3 | 0.0 | 1.3 | +3.4 | 0.0 | 83.7 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.3 | 0.0 | 38.7 |
| MANOEUVRE | 1.3 | -9.9 | 0.0 | 0.0 | 1.0 | +8.6 | 0.0 | 20.0 |
| MARCH BY THE SUM | 2.0 | +48.0 | 0.0 | 0.0 | 0.3 | +16.5 | 0.0 | 156.7 |
| MARCH CHECK | 1.3 | +69.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +68.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | -18.3 | 0.0 | 0.0 | 1.7 | +168.9 | 0.0 | 313.3 |
| MAX FOR POSITIONING | 7.3 | +147.1 | 0.0 | 0.0 | 3.0 | +33.1 | 0.0 | 418.3 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 15.0 | +389.3 | 0.0 | 0.0 | 2.3 | +28.3 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 17.0 | +302.9 | 0.0 | 0.0 | 5.7 | +24.3 | 0.0 | 378.3 |
| MISSILES ON ONE TARGET | 0.7 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 134.7 | 128.3 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 313.3 |
| MOVE TO CHARGE COMPUTED | 8.7 | +570.0 | 0.0 | 50.0 | 4.3 | +532.1 | 0.0 | 361.0 |
| NEARER NOT NEEDED | 6.7 | +281.4 | 0.0 | 0.0 | 6.3 | +244.2 | 0.0 | 93.7 |
| NEXT CHARGE BY LIST | 4.3 | +342.4 | 0.0 | 0.0 | 2.3 | +123.1 | 0.0 | 313.3 |
| NO DOUBLE ROUNDS | 3.3 | -141.5 | 760.7 | 0.0 | 2.0 | -77.3 | 50.0 | 122.3 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 8.3 | -282.3 | 0.0 | 0.0 | 3.0 | -358.9 | 0.0 | 148.3 |
| OGRE LOADER SECOND SHOT | 9.7 | +86.4 | 56.7 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.7 | +56.6 | 204.3 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 76.3 |
| ONE FIGHT FORMULA | 8.0 | -166.6 | 0.0 | 50.0 | 8.0 | -186.6 | 0.0 | 759.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -46.4 | 0.0 | 0.0 | 3.0 | -105.2 | 0.0 | 61.0 |
| OVERRUNS AWAY | 0.7 | +0.5 | 79.7 | 0.0 | 0.7 | +5.4 | 0.0 | 83.7 |
| OWN CAST FIRST | 0.3 | -11.2 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +19.3 | 0.0 | 0.0 | 0.7 | +33.1 | 0.0 | 20.0 |
| PIVOT GUARDS FLANK | 0.3 | -55.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.0 | +1991.2 | 1524.7 | 100.0 | 39.3 | +73.9 | 67.0 | 2071.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 18.0 | -634.9 | 0.0 | 50.0 | 5.7 | -304.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | -0.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.7 | -13.5 | 128.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +1425.7 | 77.3 | 0.0 | 11.7 | +1909.5 | 0.0 | 38.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +57.0 | 0.0 | 113.3 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +12.4 | 0.0 | 20.0 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +18.1 | 0.0 | 80.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 40.0 |
| REFORMS TO MEET IT | 3.0 | -83.8 | 0.0 | 0.0 | 1.0 | -142.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 67.0 |
| RESERVE FALL BACK | 0.3 | +1.4 | 0.0 | 50.0 | - | - | - | - |
| RISK BY ARC | 3.0 | +98.3 | 564.7 | 0.0 | 1.7 | -22.1 | 50.0 | 122.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| RUN DOWN | 1.7 | -8.2 | 240.0 | 0.0 | 2.0 | -43.7 | 50.0 | 122.3 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | +86.7 | 0.0 | 40.0 |
| SEARCH SPOT | 0.3 | +4.2 | 0.0 | 0.0 | 0.3 | +13.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +14.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -123.7 | 0.0 | 0.0 | 1.3 | -203.5 | 0.0 | 20.0 |
| SET UP BY THE SET | 4.0 | +121.3 | 0.0 | 0.0 | 2.7 | +248.1 | 0.0 | 333.3 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.7 | 0.0 | 40.0 |
| SHOOTERS ON THE TABLE | 17.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 61.0 |
| SHOOTS FROM THE BEST SPOT | 5.7 | +166.3 | 549.7 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -68.0 | 180.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 38.7 | 50.0 | - | - | - | - |
| SHOT RISK POINTS | 10.3 | -53.4 | 0.0 | 100.0 | 42.7 | +222.6 | 0.0 | 2267.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.3 | +740.1 | 0.0 | 50.0 | 1.3 | +40.9 | 0.0 | 100.0 |
| SPELL WORTH | 1.7 | +4.6 | 0.0 | 0.0 | 1.3 | +28.8 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 1.0 | -17.1 | 204.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 50.0 | 7.3 | +0.0 | 0.0 | 713.3 |
| STAND AND SHOOT | 0.3 | -1.6 | 41.0 | 0.0 | 0.3 | -6.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 45.7 | +0.0 | 2415.0 | 0.0 | 15.3 | +0.0 | 0.0 | 693.3 |
| STAY WORTH | 33.3 | -525.8 | 1469.3 | 0.0 | 1.0 | +6.7 | 0.0 | 59.0 |
| STOPS | - | - | - | - | 0.3 | +41.0 | 0.0 | 38.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.3 | 0.0 | 67.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| SUPPORT ADDS | 3.7 | +139.1 | 0.0 | 0.0 | 8.7 | +756.8 | 0.0 | 660.0 |
| SUPPORT NARROWED | 2.0 | +0.0 | 310.3 | 0.0 | 1.0 | +0.0 | 0.0 | 55.3 |
| SUPPORT WORKED OUT | 3.7 | +139.1 | 0.0 | 0.0 | 8.7 | +756.8 | 0.0 | 660.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 79.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 50.0 | 2.7 | +0.0 | 0.0 | 423.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.0 | +0.0 | 0.0 | 50.0 | 37.0 | +0.0 | 0.0 | 1209.0 |
| TIED UP BY THE SUM | 1.3 | +147.2 | 192.3 | 0.0 | 1.0 | +43.0 | 50.0 | 55.3 |
| TIME ON OUR SIDE | 30.0 | +546.4 | 152.7 | 50.0 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 47.7 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | +1.2 | 50.0 | 0.0 |
| WHO HITS BACK | 0.3 | +79.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -280.4 | 0.0 | 0.0 | 4.3 | -374.4 | 0.0 | 434.3 |
| WHOLE FIGHT REACTION | 1.7 | +354.7 | 122.3 | 50.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +18.2 | 0.0 | 0.0 | 0.7 | +7.5 | 0.0 | 0.0 |

### Rule changes: wfr-a92c160-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 216 | 216 | 155 | 51.67 | +0 | +0.0 |
| HIS MOVE WHY | 108 | 108 | 77 | 25.67 | +0 | +0.0 |
| ARMY TABLE | 95 | 95 | 66 | 22.00 | +2235 | +33.9 |
| HOLDER ASSIGNMENT | 61 | 61 | 55 | 18.33 | +4338 | +78.9 |
| HIS SHOT LIST | 214 | 203 | 37 | 12.33 | +1401 | +37.9 |
| HIS ONE MOVE | 121 | 108 | 36 | 12.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 71 | 71 | 36 | 12.00 | -2818 | -78.3 |
| FIVE ACTION | 484 | 453 | 35 | 11.67 | +3559 | +101.7 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1923 | -56.6 |
| OGRE LOADER SECOND SHOT | 29 | 29 | 29 | 9.67 | +260 | +8.9 |
| HIS SHOTS BY HIS RUN | 247 | 225 | 28 | 9.33 | +773 | +27.6 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 159 | 148 | 22 | 7.33 | +1031 | +46.9 |
| THE RISK READS HIS RUN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| CHARGE LOSSES | 114 | 104 | 17 | 5.67 | +2556 | +150.4 |
| MOVE TO CHARGE COMPUTED | 39 | 25 | 17 | 5.67 | +1168 | +68.7 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 16 | 5.33 | +132 | +8.3 |
| SET UP BY THE SET | 20 | 20 | 14 | 4.67 | +1303 | +93.1 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| COVER ONCE | 68 | 54 | 11 | 3.67 | +218 | +19.9 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 59 | 44 | 10 | 3.33 | +97 | +9.7 |
| QUARTER ODDS | 80 | 75 | 10 | 3.33 | +639 | +63.9 |
| SUPPORT ADDS | 37 | 37 | 10 | 3.33 | +227 | +22.7 |
| SUPPORT WORKED OUT | 37 | 37 | 10 | 3.33 | +227 | +22.7 |
| TIME ON OUR SIDE | 90 | 67 | 9 | 3.00 | +40 | +4.4 |
| GOAL WALK | 41 | 41 | 8 | 2.67 | +1474 | +184.2 |
| CAST JOB | 15 | 15 | 7 | 2.33 | +39 | +5.6 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +670 | +95.7 |
| MARCH BY THE SUM | 7 | 7 | 7 | 2.33 | +194 | +27.7 |
| NEXT CHARGE BY LIST | 20 | 12 | 7 | 2.33 | +368 | +52.5 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 17 | 16 | 6 | 2.00 | +529 | +88.1 |
| ONE FIGHT FORMULA | 48 | 29 | 6 | 2.00 | +60 | +9.9 |
| RISK BY ARC | 14 | 14 | 6 | 2.00 | +152 | +25.4 |
| SHOTS AFTER THE MOVES | 19 | 19 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 16 | 16 | 5 | 1.67 | -378 | -75.7 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -206 | -41.2 |
| MISSILES IN THE MOVE | 52 | 33 | 5 | 1.67 | +139 | +27.9 |
| PROMISE SHOT AWAY | 5 | 5 | 5 | 1.67 | -40 | -8.1 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +171 | +34.2 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +242 | +60.4 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +185 | +46.2 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +78 | +19.6 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 7 | 4 | 1.33 | +247 | +61.8 |
| WHOLE FIGHT DANGER | 17 | 16 | 4 | 1.33 | +258 | +64.6 |
| CHAFF IN THE MOVE | 6 | 6 | 3 | 1.00 | +4 | +1.5 |
| MAX FOR POSITIONING | 31 | 27 | 3 | 1.00 | +29 | +9.6 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +157 | +52.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 13 | 13 | 2 | 0.67 | +22 | +11.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +26 | +12.9 |
| NEARER NOT NEEDED | 39 | 38 | 2 | 0.67 | +76 | +37.8 |
| PROMISE KNOWS THE FIGHT | 4 | 3 | 2 | 0.67 | -1 | -0.5 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +54 | +27.1 |
| SUPPORT NARROWED | 9 | 9 | 2 | 0.67 | -67 | -33.4 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +14 | +13.7 |
| BACKUP TARGETS | 5 | 2 | 1 | 0.33 | +2 | +1.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -20 | -20.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +47 | +47.3 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 1 | 0.33 | +28 | +27.5 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +6 | +5.8 |
| FALLS SHORT | 66 | 63 | 1 | 0.33 | +0 | +0.4 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +28 | +28.3 |
| HIS MOVE AND SHOT | 57 | 52 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 16 | 15 | 1 | 0.33 | +13 | +13.2 |
| ONE CHALLENGE TEST | 2 | 2 | 1 | 0.33 | +28 | +27.5 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -34 | -33.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -167 | -167.2 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +4 | +4.4 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -23 | -22.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +43 | +43.4 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STOPS | 1 | 1 | 1 | 0.33 | +119 | +119.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +221 | +221.4 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 31 | 31 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 36 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 24 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 71 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 1 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 84 | 84 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 14 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 68 | 43 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 22 | 20 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 232 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | not checked | - | - | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 11 | 11 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 59 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 56 | 35 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 183 | 176 | 0 | 0.00 | - | - |
| STAY WORTH | 103 | 87 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 228 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 5 | 5 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 11 | 10 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 10.33 | 1.67 | 78.3 |
| JOB FIRST | gate | 7.33 | 2.67 | 58.2 |
| ARMY TABLE | rule | 1.00 | 2.33 | 73.2 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.33 | 29.1 |
| CHARGE NOW FIRST | rule | 1.67 | - | 75.7 |
| PROMISE SHOT AWAY | rule | 1.67 | - | 8.1 |
| MARCH OF THE TABLE | rule | 1.33 | - | 51.5 |
| NO REASON | gate | 1.00 | - | 23.2 |
| SUPPORT NARROWED | rule | 0.67 | - | 33.4 |
| BEST PRIZE | rule | - | 0.33 | 20.2 |
| JOINT CHARGE NOW | rule | 0.33 | - | 52.5 |
| OWN CAST FIRST | rule | 0.33 | - | 33.6 |
| PATHS CROSS | rule | - | 0.33 | 33.1 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 167.2 |
| REFUSING RETIRES | rule | - | 0.33 | 22.8 |
| RULE SWITCHED OFF | gate | - | 0.33 | 106.6 |

### Plans: wfr-a92c160-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 91% | 507 | 694 | 137% |
| Mine | move | 19.3 | 98% | 1323 | 0 | 0% |
| Mine | shoot | 15.0 | 62% | 712 | 1297 | 182% |
| Opponent | charge | 1.3 | 25% | 175 | 74 | 42% |
| Opponent | join | 2.0 | 100% | 125 | 0 | 0% |
| Opponent | move | 35.0 | 89% | 2224 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 11 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 81 | 0 | 0% |

### Packages: hunt the guns, wfr-a92c160-p31

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 318 | 0 | 0% | 167 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 385 |
| Warriors of Chaos | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 318 | 0 | 0% | 116 |

### Battle groups: wfr-a92c160-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 72 (9) | 72 | 0 | 13 | 22% | 2.3 | 81 (2) | 79 (6) | - | 82 (5) | 76 (3) |
| Mine | Clean-up | 2 | 74 (2) | 0 | 74 | 0 | 0% | 2.0 | 0 (1) | 139 (1) | - | 74 (2) | - |
| Mine | Fast Hammer | 4 | 53 (4) | 17 | 35 | 15 | 25% | 2.7 | 59 (2) | 50 (2) | - | 82 (3) | 0 (1) |
| Mine | Holder | 1 | 175 (1) | 0 | 175 | 0 | 0% | 1.0 | 175 (1) | - | - | 175 (1) | - |
| Mine | Shooter | 4 | 85 (4) | 57 | 28 | 0 | 0% | 1.5 | 71 (3) | 147 (1) | - | 85 (4) | - |
| Mine | War machine | 6 | 51 (6) | 51 | 0 | 0 | 0% | 1.0 | 35 (2) | 117 (2) | 0 (2) | 70 (1) | 47 (5) |
| Mine | Wizard | 3 | 52 (3) | 52 | 0 | 0 | 0% | 1.3 | 59 (2) | 46 (1) | - | 52 (3) | - |
| Opponent | Chaff | 2 | 200 (2) | 0 | 200 | 100 | 100% | - | - | 400 (1) | 0 (1) | 200 (2) | - |
| Opponent | Character | 10 | 11 (10) | 11 | 0 | 51 | 30% | 3.4 | 29 (3) | 0 (5) | 0 (2) | 21 (5) | 0 (5) |
| Opponent | Fast Hammer | 9 | 41 (9) | 8 | 33 | 84 | 56% | 3.5 | 30 (2) | 44 (7) | - | 31 (5) | 56 (4) |
| Opponent | Hammer | 3 | 5 (3) | 5 | 0 | 37 | 67% | 3.0 | 0 (2) | 15 (1) | - | 0 (2) | 15 (1) |
| Opponent | Holder | 5 | 39 (5) | 0 | 39 | 0 | 80% | 5.0 | 47 (2) | 0 (2) | 73 (1) | 34 (2) | 44 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: wfr-a92c160-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 406 | 534 | 2.7 | 1.2 | 200 | 0 | +200 | 3 of 8 | 8 of 8 | +332 | +157 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 446 | 3.0 | 1.0 | 149 | 67 | +82 | 2 of 3 | 2 of 3 | - | +82 |
| **Opponent** | all armies | 3 | 0 | 149 | 1.3 | 1.0 | 112 | 50 | +61 | 3 of 4 | 3 of 4 | - | +61 |

### Effective charges: wfr-a92c160-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 8 | 1 (net +393) | 0 | 0 | 3 (net +250) | 1 (net +0) | 3 (net +154) | 0 | 0% (0 of 8) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 1 (net -201) | 0 | 1 (net +296) | 0 | 0 | 1 (net +150) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: wfr-a92c160-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 379 | 343 | +393 | 393 | 0 | +393 | +103.7 |
| Mine | 76-89% | 3 | 314 | 268 | +250 | 305 | 14 | +291 | +92.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 328 | 154 | +154 | 200 | 53 | +147 | +44.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 369 | 116 | +0 | 77 | 55 | +22 | +6.1 |
| Mine | All fights | 8 | 334 | 216 | +200 | 248 | 32 | +216 | +64.6 |
| Opponent | Long shot (under 50%) | 1 | 201 | 358 | -201 | 0 | 201 | -201 | -100.0 |
| Opponent | Effective (55-75%) | 1 | 392 | 358 | +296 | 320 | 0 | +320 | +81.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 126 | 184 | +75 | 102 | 0 | +102 | +81.1 |
| Opponent | All fights | 4 | 211 | 271 | +61 | 131 | 50 | +81 | +38.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p31 | move | 32 | 8 (25%) | 7 (22%) | 2 (6%) | 22 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

# Doctrine scorecard: wfr-a92c160-p6

### Scorecard: wfr-a92c160-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 8 | 3 | 3 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 170 |
| L0930 | 6 | 1 | Opponent | no | 13 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 5.0 | 3.0 | 0.7 | 0.7 | 0.0 | 0.0 | 0.0 | 306.7 |
| **Average** | | | Opponent | 0% | 7.0 | 3.0 | 1.0 | 2.7 | 0.3 | 0.0 | 0.0 | 143.3 |

### KPIs: wfr-a92c160-p6

Rules off - Mine only: WHOLE FIGHT REACTION.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (5 of 13) | 0% (0 of 13) | 19% (5 of 26) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 33% (1 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 100% | 67% (2 of 3); on the table 67% | 67% (4 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 35% (17 of 48) | 25% (3 of 12) | 33% (20 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (17 of 41) | 25% (3 of 12) | 38% (20 of 53) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 79% (4751 of 5997) | 84% (5037 of 5999) | 82% (9788 of 11996) |
|   infantry points that never fought | lower | 74% (1174 of 1591) | 74% (1226 of 1660) | 74% (2400 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (22 of 34) | 70% (16 of 23) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3468 of 5667) | 74% (3825 of 5150) | 67% (7293 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.3 (42%) | 1.7 (56%) | 6.0 (45%) |
| MARCHED: its unit marched | 2.7 (26%) | 1.0 (33%) | 3.7 (28%) |
| CHARGED: its unit charged | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| IN COMBAT: engaged in combat | 1.7 (16%) | 0.0 (0%) | 1.7 (12%) |
| FLEEING: fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.7 | 1.3 | 6.7 | 0.3 | 1.0 |
| not cast | 0.0 | 4.3 | 0.7 | 13.3 | 1.7 | 19.0 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.7 (62%) | 0.0 (0%) | 6.0 (45%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 3.7 (28%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | - | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.3 (8%) | 0.0 (0%) | 1.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | - | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 1.3 (31%) | 0.0 (0%) | 0.3 (2%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 0% (0 of 3) | 0% (0 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (82 of 123) | 79% (37 of 47) | 70% (119 of 170) |
|   character | 100% (5 of 5) | 64% (7 of 11) | 75% (12 of 16) |
|   chariot | 83% (15 of 18) | 100% (6 of 6) | 88% (21 of 24) |
|   infantry | 43% (23 of 53) | 67% (12 of 18) | 49% (35 of 71) |
|   monster | 73% (8 of 11) | - | 73% (8 of 11) |
|   war machine | 86% (31 of 36) | 100% (12 of 12) | 90% (43 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (22%) | 2.7 (80%) | 5.7 (33%) |
| CHARGED: it charged | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 4.7 (34%) | 0.7 (20%) | 5.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (20%) | 0.0 (0%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.3 | 0.7 | 92% | 1.2 pts | 5 pts |
| chariot | 7.0 | 6.3 | 67% | 30.1 pts | 211 pts |
| infantry | 14.7 | 8.7 | 64% | 12.0 pts | 177 pts |
| monster | 5.0 | 0.7 | 93% | 4.0 pts | 20 pts |
| war machine | 14.3 | 10.0 | 63% | 19.6 pts | 281 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 2.7 | 2.0 |
| Charges that made contact a game | 0.7 | 1.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.60 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.35 declared, 0.22 contact (23 units) | 0.21 declared, 0.14 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 100% (7 of 7) | - | - | 100% (7 of 7) |
| Character on its own | - | 67% (4 of 6) | 75% (3 of 4) | 70% (7 of 10) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (5 of 14) | 75% (3 of 4) | - | 44% (8 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 67% (2 of 3); on the table 100% | 50% (12 of 24) | 81% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 21% (5 of 24) | 75% | 50% (5 of 10) | 100% (2 of 2); 6.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 71% | 25% (2 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 80% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 100% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (wfr-a92c160-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: wfr-a92c160-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 25% (1 of 4) | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (16 of 61) | 48% (10 of 21) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | - |
| Strategy | Joined characters whose unit fought | 12% (1 of 8) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 14% (1 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 306.7 | 143.3 |
| Movement | Fights charged into per game | 0.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 4, net -41 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 4, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +0 | 2 of 4, net +92 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (33 of 51) | 59% (16 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 90.7 |
| Shooting | War machine shots | 10.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (13 of 31) | 50% (6 of 12) |
| Shooting | Points destroyed by war machines | 317.3 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 57% (4 of 7) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 4.7 | 2.7 |
| Magic | Wounds caused by other spells | 3.3 | - |
| Magic | Points destroyed by magic (all spells) | 147.3 | 41.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 1.0 / 0.3 | 3.7 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 61.7 |
| Combat | Points run down | 13.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +13 | +124 |
| Combat | Net per 100 charger points, damage counted | +5.3 | +46.5 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +0 | +62 |
| Combat | Net points per supported fight / lone fight | - / +0 | -41 / +96 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 1 of 4 |
| Game | Points lost | 270.3 | 461.7 |
| Game | VP from objectives | 796.7 | 846.7 |
| Game | Lone holders (player turns) | 5.0 | 7.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +150 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 732
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: wfr-a92c160-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.3 | +351.1 | 0.0 | 151.3 | 17.3 | +249.1 | 0.0 | 161.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 87.7 | 0.0 | 0.3 | +0.0 | 75.7 | 0.0 |
| CANNON PLANNED TARGET | 10.3 | +484.1 | 1428.3 | 125.0 | 4.0 | +214.8 | 310.3 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 41.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 4.0 | +65.5 | 319.3 | 0.0 | 1.3 | +13.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +41.7 | 0.0 | 27.3 |
| CHAFF PASSED | - | - | - | - | 0.3 | -2.2 | 41.7 | 0.0 |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -710.4 | 0.0 | 186.0 | 27.7 | -1808.9 | 0.0 | 1322.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 70.0 | 0.0 | 1.0 | +0.0 | 76.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +141.5 | 99.0 | 0.0 |
| COVER ONCE | 11.3 | -967.9 | 0.0 | 75.7 | 2.0 | -102.4 | 0.0 | 341.0 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 638.7 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -24.6 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 41.7 | 7.0 | +37.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +11.4 | 83.7 | 0.0 | 2.0 | +15.1 | 41.7 | 13.7 |
| FALL BACK GOOD ORDER | 1.0 | +2.7 | 70.0 | 0.0 | 2.0 | +0.5 | 76.3 | 13.7 |
| FALLS SHORT | 1.7 | +38.1 | 0.0 | 0.0 | 26.3 | +278.1 | 0.0 | 605.0 |
| FEATURE BUFFS | 1.3 | +22.7 | 0.0 | 0.0 | 3.3 | +49.9 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | -1.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 101.0 | +7977.9 | 5460.0 | 505.3 | 96.7 | +5532.1 | 1035.0 | 1569.7 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 75.7 | 3.3 | +0.0 | 0.0 | 354.7 |
| FOLLOW UP WEIGHED | 0.7 | +51.2 | 0.0 | 0.0 | 0.7 | +90.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +41.2 | 83.7 | 0.0 | 2.7 | +41.7 | 152.0 | 13.7 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.0 | -21.5 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -4.6 | 0.0 | 0.0 |
| GOAL WALK | 8.3 | +1445.7 | 0.0 | 0.0 | 14.7 | +1663.2 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +224.4 | 357.7 | 0.0 | 1.0 | +1.5 | 0.0 | 43.3 |
| GUN MASK | 3.3 | +27.3 | 0.0 | 0.0 | 0.7 | +35.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 151.3 | 6.7 | +0.0 | 0.0 | 844.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +17.6 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 161.7 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 638.7 |
| HIS MOVE AND SHOT | 2.7 | -10.0 | 0.0 | 0.0 | 3.7 | -57.0 | 0.0 | 246.3 |
| HIS MOVE AS HE DECIDES | 43.3 | +12.0 | 720.0 | 0.0 | 38.3 | +13.3 | 220.7 | 0.0 |
| HIS MOVE WHY | - | - | - | - | 43.7 | +0.0 | 0.0 | 662.0 |
| HIS ONE MOVE | 16.0 | -0.2 | 0.0 | 34.7 | 16.3 | -33.2 | 30.0 | 159.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 43.3 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 159.7 |
| HIS RANDOM MOVE | 16.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.3 | +733.1 | 0.0 | 186.0 | 70.7 | +4561.5 | 0.0 | 1512.7 |
| HIS SHOTS BY HIS RUN | 28.0 | +573.0 | 0.0 | 186.0 | 73.3 | +2549.5 | 0.0 | 1457.0 |
| HIS TURN DENIED | 0.3 | +37.5 | 21.7 | 0.0 | 1.3 | +156.7 | 152.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 0.0 | 30.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +1216.4 | 0.0 | 0.0 | 16.3 | +1451.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -37.1 | 83.7 | 0.0 | 1.3 | -56.4 | 152.0 | 0.0 |
| IDLE COST | - | - | - | - | 13.7 | -260.9 | 0.0 | 219.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +132.1 | 0.0 | 13.7 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 75.7 | 1.0 | +0.0 | 75.7 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +14.8 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +2.1 | 48.3 | 0.0 | 1.7 | +10.0 | 34.7 | 13.7 |
| MANOEUVRE | 2.0 | -7.2 | 0.0 | 0.0 | 3.3 | -17.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +60.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +70.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +19.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | -151.0 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +50.8 | 0.0 | 0.0 | 1.3 | +13.3 | 0.0 | 13.7 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.7 | +175.2 | 0.0 | 0.0 | 3.3 | +61.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 13.0 | +188.5 | 0.0 | 0.0 | 5.7 | +44.4 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 99.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +143.9 | 0.0 | 0.0 | 1.7 | +207.0 | 0.0 | 319.3 |
| NEARER NOT NEEDED | 11.7 | +548.4 | 0.0 | 34.7 | 8.7 | +398.1 | 0.0 | 66.0 |
| NEXT CHARGE BY LIST | 1.3 | +61.7 | 132.0 | 0.0 | 1.3 | +202.5 | 0.0 | 159.7 |
| NO DOUBLE ROUNDS | 0.7 | -35.7 | 48.3 | 0.0 | 2.3 | -90.6 | 152.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +1.2 | 0.0 | 13.7 |
| OFF BEST | 6.0 | -308.5 | 0.0 | 34.7 | 2.7 | -85.1 | 0.0 | 13.7 |
| OGRE LOADER SECOND SHOT | 2.0 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -88.5 | 0.0 | 0.0 | 3.0 | -75.9 | 0.0 | 319.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +17.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -125.1 | 0.0 | 0.0 | 7.3 | +166.4 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +11.1 | 35.3 | 0.0 | 0.3 | +15.6 | 34.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.9 | 21.7 | 0.0 | 0.7 | +41.1 | 75.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +21.6 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +2161.6 | 1236.7 | 387.3 | 45.7 | +391.1 | 387.3 | 913.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 159.7 |
| PROMISE BY ITS OWN SUM | 4.3 | -77.3 | 0.0 | 0.0 | 2.0 | -16.2 | 0.0 | 159.7 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -10.3 | 48.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.7 | +2100.1 | 122.0 | 151.3 | 17.7 | +1483.4 | 681.0 | 43.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +41.2 | 0.0 | 193.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +33.3 | 0.0 | 27.3 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +75.5 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +41.9 | 0.0 | 41.0 |
| REDIRECT WEIGHED | 0.3 | +1.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | -13.9 | 70.0 | 0.0 | 2.7 | -28.5 | 152.0 | 13.7 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -18.1 | 76.3 | 0.0 |
| RUN DOWN | 1.0 | -11.3 | 70.0 | 0.0 | 1.3 | -20.4 | 34.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -4.6 | 66.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -152.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +51.1 | 0.0 | 66.0 |
| SET UP BY THE SET | 0.3 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 20.3 | +0.0 | 0.0 | 159.7 | 7.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +107.2 | 473.0 | 0.0 | 2.3 | +50.5 | 69.3 | 0.0 |
| SHOT OR CHARGE | 0.7 | -7.2 | 43.3 | 0.0 | 1.0 | -143.3 | 193.0 | 0.0 |
| SHOT RISK POINTS | 12.3 | -184.1 | 0.0 | 186.0 | 45.0 | -615.9 | 0.0 | 1077.0 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.3 | +1482.6 | 0.0 | 235.3 | 12.3 | +361.9 | 0.0 | 461.7 |
| SPELL WORTH | - | - | - | - | 4.0 | +100.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | 0.3 | -45.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 34.7 | 5.3 | +0.0 | 0.0 | 762.3 |
| STAND AND SHOOT | 0.3 | -4.8 | 21.7 | 0.0 | 0.7 | -3.7 | 75.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 52.0 | +0.0 | 5376.3 | 470.7 | 35.0 | +0.0 | 883.0 | 96.7 |
| STAY WORTH | 43.3 | +401.6 | 3296.0 | 291.7 | 21.0 | +276.1 | 511.0 | 120.7 |
| STRIKE BY THE ODDS | 0.3 | +8.5 | 13.7 | 0.0 | 1.0 | +13.2 | 20.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +53.7 | 0.0 | 0.0 | 2.0 | +68.7 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +53.7 | 0.0 | 0.0 | 2.0 | +68.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +13.2 | 0.0 | 99.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 21.7 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 99.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 225.7 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 235.3 | 45.0 | +0.0 | 0.0 | 648.3 |
| TIED UP BY THE SUM | 1.0 | +93.6 | 70.0 | 0.0 | 0.7 | +69.2 | 76.3 | 0.0 |
| TIME ON OUR SIDE | 39.0 | +573.0 | 319.3 | 49.7 | - | - | - | - |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -5.2 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.0 | -356.2 | 0.0 | 0.0 | 1.7 | -225.3 | 0.0 | 479.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +24.7 | 0.0 | 13.7 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.0 | +16.5 | 0.0 | 35.3 |
| WOUNDS ON THE RANKS | 1.7 | +9.1 | 0.0 | 0.0 | 2.0 | +245.6 | 0.0 | 198.0 |

### Rule changes: wfr-a92c160-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 245 | 245 | 169 | 56.33 | +0 | +0.0 |
| HIS MOVE WHY | 131 | 131 | 95 | 31.67 | +0 | +0.0 |
| HIS SHOT LIST | 300 | 297 | 90 | 30.00 | +2023 | +22.5 |
| HIS SHOTS BY HIS RUN | 304 | 300 | 88 | 29.33 | +1503 | +17.1 |
| HOLDER ASSIGNMENT | 85 | 85 | 80 | 26.67 | +5298 | +66.2 |
| ARMY TABLE | 86 | 86 | 57 | 19.00 | +1423 | +25.0 |
| HIS ONE MOVE | 97 | 96 | 39 | 13.00 | +0 | +0.0 |
| SHOT RISK POINTS | 172 | 170 | 35 | 11.67 | +723 | +20.7 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -1181 | -45.4 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| GOAL WALK | 69 | 69 | 20 | 6.67 | +2939 | +147.0 |
| TIME ON OUR SIDE | 117 | 102 | 17 | 5.67 | +57 | +3.3 |
| FIVE ACTION | 593 | 588 | 15 | 5.00 | +453 | +30.2 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 15 | 5.00 | +156 | +10.4 |
| THE RISK READS HIS RUN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| STAY WORTH | 193 | 176 | 13 | 4.33 | +90 | +6.9 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CAST JOB | 16 | 16 | 10 | 3.33 | +86 | +8.6 |
| CHARGE LOSSES | 128 | 125 | 10 | 3.33 | +484 | +48.4 |
| QUARTER ODDS | 100 | 99 | 10 | 3.33 | +603 | +60.3 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 9 | 9 | 3.00 | +2 | +0.2 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 9 | 3.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 43 | 43 | 7 | 2.33 | -75 | -10.7 |
| COVER ONCE | 40 | 31 | 7 | 2.33 | +214 | +30.6 |
| SHOTS IN THE MOVE | 125 | 92 | 7 | 2.33 | +521 | +74.4 |
| LEGAL CHARGES ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +26 | +4.4 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 6 | 2.00 | -280 | -46.7 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +124 | +20.6 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MOVE TO CHARGE COMPUTED | 17 | 16 | 5 | 1.67 | +150 | +30.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +424 | +106.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +396 | +99.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +65 | +16.2 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +130 | +32.5 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOUR ROUNDS | 12 | 12 | 3 | 1.00 | +48 | +16.2 |
| GUN MASK | 12 | 12 | 3 | 1.00 | +64 | +21.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 41 | 36 | 3 | 1.00 | +13 | +4.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +180 | +60.1 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +59 | +19.6 |
| MAX FOR POSITIONING | 18 | 15 | 3 | 1.00 | +2 | +0.8 |
| SUPPORT ADDS | 12 | 12 | 3 | 1.00 | +7 | +2.4 |
| SUPPORT WORKED OUT | 12 | 12 | 3 | 1.00 | +7 | +2.4 |
| THE ROW IN ITS ORDER | 19 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 20 | 19 | 3 | 1.00 | +137 | +45.7 |
| WOUNDS ON THE RANKS | 11 | 11 | 3 | 1.00 | +89 | +29.7 |
| FALLS SHORT | 84 | 64 | 2 | 0.67 | +29 | +14.7 |
| FEATURE BUFFS | 14 | 14 | 2 | 0.67 | +21 | +10.5 |
| HIS MOVE AND SHOT | 19 | 18 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +196 | +98.2 |
| MANOEUVRE | 16 | 16 | 2 | 0.67 | +54 | +27.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -58 | -28.9 |
| NEARER NOT NEEDED | 61 | 56 | 2 | 0.67 | +77 | +38.3 |
| NEXT CHARGE BY LIST | 8 | 7 | 2 | 0.67 | +24 | +12.1 |
| ONE OBJECTIVE FORMULA | 39 | 31 | 2 | 0.67 | +65 | +32.5 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +2 | +0.8 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +396 | +198.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +153 | +76.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 3 | 3 | 2 | 0.67 | -4 | -2.1 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -9 | -9.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -6.6 |
| CHARGE NOW FIRST | 5 | 5 | 1 | 0.33 | -39 | -38.6 |
| EXACT ROUND | 10 | 10 | 1 | 0.33 | +5 | +4.9 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| MISSILES IN THE MOVE | 36 | 26 | 1 | 0.33 | +13 | +13.2 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +12 | +12.4 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +73 | +72.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +65 | +64.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -31 | -30.9 |
| REDIRECT COUNTER | 4 | 3 | 1 | 0.33 | +30 | +29.5 |
| SET UP BY THE SET | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +19 | +19.1 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +38 | +38.5 |
| WHOLE FIGHT REACTION | 3 | 3 | 1 | 0.33 | +0 | +0.2 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 24 | 24 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 47 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 31 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 7 | 7 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 49 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 147 | 147 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 56 | 41 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 16 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 11 | 11 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 84 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 261 | 261 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 30 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 278 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 15 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: wfr-a92c160-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 2.33 | 49.1 |
| ARMY TABLE | rule | 1.67 | 2.00 | 48.3 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 0.33 | 46.7 |
| HOLDER ASSIGNMENT | rule | - | 1.67 | 25.8 |
| AFTERMATH BAND | gate | 0.67 | - | 2.8 |
| CANNON PLANNED TARGET | rule | 0.33 | 0.33 | 61.0 |
| MARCH OF THE TABLE | rule | 0.67 | - | 28.9 |
| RULE SWITCHED OFF | gate | 0.67 | - | 36.0 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| BEST PRIZE | rule | 0.33 | - | 9.0 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| CHARGE NOW FIRST | rule | 0.33 | - | 38.6 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 3.1 |
| NO REASON | gate | - | 0.33 | 72.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 30.9 |

### Plans: wfr-a92c160-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 81 | 85 | 105% |
| Mine | move | 25.7 | 96% | 1916 | 0 | 0% |
| Mine | shoot | 17.0 | 61% | 1100 | 2076 | 189% |
| Opponent | charge | 1.7 | 100% | 283 | 162 | 57% |
| Opponent | move | 36.3 | 93% | 2210 | 0 | 0% |
| Opponent | shoot | 6.3 | 42% | 270 | 229 | 85% |
| Opponent | support | 1.3 | 100% | 21 | 0 | 0% |

### Battle groups: wfr-a92c160-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: wfr-a92c160-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 11 (10) | 11 | 0 | 3 | 40% | 3.0 | 19 (5) | 0 (5) | - | 14 (6) | 7 (4) |
| Mine | Clean-up | 3 | 55 (3) | 0 | 55 | 0 | 100% | - | 0 (1) | 83 (2) | - | 55 (3) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Hammer | 6 | 34 (6) | 34 | 0 | 16 | 17% | 2.4 | 0 (2) | 51 (4) | - | 40 (5) | 0 (1) |
| Mine | Shooter | 6 | 135 (6) | 0 | 135 | 17 | 0% | 1.5 | 0 (1) | 202 (3) | 101 (2) | 135 (6) | - |
| Mine | War machine | 8 | 44 (8) | 44 | 0 | 35 | 0% | 1.5 | 0 (3) | 53 (3) | 83 (2) | 0 (1) | 50 (7) |
| Mine | Wizard | 4 | 124 (4) | 124 | 0 | 25 | 25% | 2.7 | 0 (1) | 248 (2) | - | 248 (2) | 0 (1) |
| Opponent | Chaff | 2 | 264 (2) | 0 | 264 | 0 | 100% | - | 471 (1) | 0 (1) | - | 471 (1) | 0 (1) |
| Opponent | Character | 9 | 9 (9) | 9 | 0 | 29 | 44% | 2.0 | 0 (1) | 0 (5) | 35 (2) | 15 (6) | 0 (2) |
| Opponent | Clean-up | 3 | 97 (3) | 12 | 85 | 8 | 33% | 5.0 | 0 (1) | 177 (2) | - | 177 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 80 (6) | 0 | 80 | 20 | 83% | 1.0 | - | 105 (4) | 39 (2) | 80 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 43 | 50% | 1.0 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Opponent | Holder | 4 | 15 (4) | 0 | 15 | 0 | 50% | 5.5 | - | 15 (4) | - | 29 (2) | 0 (2) |
| Opponent | Shooter | 4 | 36 (4) | 36 | 0 | 28 | 25% | 2.0 | 0 (1) | 0 (1) | 50 (2) | 42 (3) | 0 (1) |
| Opponent | War machine | 2 | 162 (2) | 162 | 0 | 0 | 0% | 1.0 | - | - | 162 (2) | 324 (1) | 0 (1) |

### Charged fights: wfr-a92c160-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 487 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 420 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| **Mine** | all armies | 3 | 465 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | High Elf Realms | 1 | 397 | 289 | 3.0 | 1.0 | 96 | 0 | +96 | 0 of 3 | 3 of 3 | - | +96 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 41 | -41 | 1 of 1 | 0 of 1 | -41 | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 132 | 96 | 1.3 | 1.2 | 72 | 10 | +62 | 1 of 4 | 3 of 4 | -41 | +96 |

### Effective charges: wfr-a92c160-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 3 | 0 | 0 | 0 | 0 | 1 (net +104) | 2 (net +92) | 0 | 0% (0 of 3) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net -41) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: wfr-a92c160-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 252 | 118 | +0 | 23 | 10 | +13 | +5.3 |
| Mine | All fights | 2 | 252 | 118 | +0 | 23 | 10 | +13 | +5.3 |
| Opponent | Effective (55-75%) | 1 | 153 | 369 | -41 | 184 | 80 | +104 | +68.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 286 | 114 | +92 | 245 | 101 | +144 | +50.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 342 | 104 | +104 | 104 | 0 | +104 | +30.4 |
| Opponent | All fights | 4 | 267 | 176 | +62 | 195 | 71 | +124 | +46.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| wfr-a92c160-p6 | move | 14 | 2 (14%) | 2 (14%) | 1 (7%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

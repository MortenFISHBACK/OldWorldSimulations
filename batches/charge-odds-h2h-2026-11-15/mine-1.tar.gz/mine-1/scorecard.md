# Doctrine scorecard: co-h2h-mine-324c342-p1

### Scorecard: co-h2h-mine-324c342-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 11 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 4 | 1 | 2 | 3 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 4 | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 5 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 14 | 2 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 55 |
| L0405 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 124 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 836 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 2 | 3 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 350 |
| L0733 | 1 | 1 | Mine | no | 1 | 1 | 0 | 1 | 0 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 5 | 3 | 2 | 2 | 0 | 0 | 0 | 208 |
| L0823 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 679 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 2 | - | 1 | 2 | 1 | 0 | 0 | 447 |
| L1114 | 4 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 3 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 9 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 3 | 1 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 12 | 2 | 1 | 0 | 0 | 0 | 0 | 300 |
| L1431 | 3 | 1 | Opponent | no | 7 | - | 4 | 2 | 2 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 60 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 260 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 4 | 1 | 0 | 0 | 0 | 68 |
| L1723 | 1 | 1 | Mine | no | 0 | 1 | 2 | 0 | 1 | 0 | 0 | 207 |
| L1723 | 1 | 1 | Opponent | yes | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 1 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 3 | 3 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 2 | - | 0 | 5 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 657 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 8 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 2.6 | 2.5 | 2.4 | 1.1 | 0.2 | 0.0 | 0.0 | 267.4 |
| **Average** | | | Opponent | 15% | 2.8 | 2.3 | 2.7 | 2.0 | 0.4 | 0.0 | 0.0 | 178.3 |

### KPIs: co-h2h-mine-324c342-p1

Rules off - Opponent only: JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (52 of 176) | 3% (5 of 170) | 16% (57 of 346) |
| Winner chose to follow up after the loser gave ground |  | 94% (59 of 63); on the table 95% | 100% (48 of 48); on the table 100% | 96% (107 of 111); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 78% | 90% (18 of 20); on the table 90% | 86% (25 of 29); on the table 86% |
| Winner chose to pursue after the loser fled |  | 71% (22 of 31); on the table 74% | 91% (29 of 32); on the table 94% | 81% (51 of 63); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 85% (88 of 103); on the table 87% | 95% (95 of 100); on the table 96% | 90% (183 of 203); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 26% (87 of 330) | 26% (55 of 210) | 26% (142 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (87 of 225) | 38% (55 of 143) | 39% (142 of 368) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 74% (23 of 31) | 65% (33 of 51) | 68% (56 of 82) |
| Points that never fought | lower | 40% (28858 of 71484) | 42% (30454 of 71889) | 41% (59312 of 143373) |
|   infantry points that never fought | lower | 51% (8574 of 16863) | 68% (9035 of 13348) | 58% (17609 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (154 of 279) | 62% (182 of 295) | 59% (336 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.8 uses a game | 75% (15 of 20); 1.4 uses a game | 86% (36 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.9 uses a game | 38% (3 of 8); 0.1 uses a game | 58% (14 of 24); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 42% (8 of 19); 0.2 uses a game | 58% (7 of 12); 0.2 uses a game | 48% (15 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29778 of 59666) | 57% (35857 of 62699) | 54% (65635 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (31%) | 1.2 (28%) | 3.3 (30%) |
| MARCHED: its unit marched | 1.2 (17%) | 0.6 (14%) | 1.8 (16%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.2 (5%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.4 (20%) | 0.6 (14%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (8%) | 0.4 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |
| GONE: slain | 0.5 (8%) | 1.0 (23%) | 1.5 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.9 (13%) | 0.2 (5%) | 1.1 (10%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.1 | 1.5 | 3.9 | 0.4 | 1.7 |
| not cast | 4.3 | 3.2 | 3.2 | 11.1 | 1.9 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (36%) | 0.3 (10%) | 3.3 (30%) | 0.6 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (16%) | 0.3 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.4 (12%) | 0.2 (8%) | 2.0 (18%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (10%) | 0.5 (15%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.0 (1%) | 0.5 (2%) |
| GONE: slain | 1.1 (25%) | 0.6 (19%) | 0.5 (15%) | 1.5 (14%) | 0.1 (3%) | 3.1 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.4 (13%) | 0.3 (9%) | 1.1 (10%) | 0.0 (0%) | 1.9 (9%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.4 (24%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (49%) | 0.2 (6%) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 68% (28 of 41) | 50% (6 of 12) | 64% (34 of 53) |
| the unit moved after it | 61% (17 of 28) | 50% (3 of 6) | 59% (20 of 34) |
| it charged on its next turn | 0% (0 of 28) | 0% (0 of 6) | 0% (0 of 34) |
| the enemy charged it first | 21% (6 of 28) | 33% (2 of 6) | 24% (8 of 34) |
| it fought by the end of its next turn | 11% (3 of 28) | 33% (2 of 6) | 15% (5 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 32% (9 of 28) | 0% (0 of 6) | 26% (9 of 34) |
| none of these (no charge, no fight, no charge escaped) | 46% (13 of 28) | 67% (4 of 6) | 50% (17 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (558 of 915) | 62% (377 of 608) | 61% (935 of 1523) |
|   cavalry | 61% (48 of 79) | 68% (91 of 133) | 66% (139 of 212) |
|   character | 49% (53 of 109) | 31% (34 of 109) | 40% (87 of 218) |
|   chariot | 46% (43 of 94) | 73% (30 of 41) | 54% (73 of 135) |
|   infantry | 54% (162 of 299) | 64% (154 of 242) | 58% (316 of 541) |
|   monster | 57% (25 of 44) | 47% (8 of 17) | 54% (33 of 61) |
|   war machine | 78% (227 of 290) | 91% (60 of 66) | 81% (287 of 356) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (25%) | 1.6 (26%) | 4.1 (25%) |
| CHARGED: it charged | 1.2 (12%) | 1.3 (21%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.2 (4%) | 0.8 (5%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.3 (20%) | 2.9 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (8%) | 0.6 (9%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (24%) | 0.9 (14%) | 3.3 (20%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.8 | 77% | 6.2 pts | 33 pts |
| character | 2.8 | 1.0 | 73% | 9.2 pts | 25 pts |
| chariot | 2.0 | 1.1 | 73% | 8.3 pts | 17 pts |
| infantry | 12.7 | 4.3 | 72% | 9.6 pts | 122 pts |
| monster | 1.1 | 0.5 | 69% | 13.8 pts | 15 pts |
| war machine | 8.0 | 6.9 | 59% | 24.4 pts | 195 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.1 | 5.1 |
| Charges that made contact a game | 3.0 | 3.8 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.05 declared, 0.75 contact (20 units) | 0.38 declared, 0.23 contact (13 units) | 0.79 declared, 0.55 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.67 contact (6 units) | 1.20 declared, 0.80 contact (10 units) | 1.06 declared, 0.75 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.36 contact (247 units) | 0.72 declared, 0.45 contact (278 units) | 0.61 declared, 0.41 contact (525 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (39 of 70) | 52% (11 of 21) | 25% (2 of 8) | 53% (52 of 99) |
| Character in a unit | 93% (39 of 42) | 77% (17 of 22) | 100% (3 of 3) | 88% (59 of 67) |
| Character on its own | 80% (36 of 45) | 53% (20 of 38) | 32% (20 of 63) | 52% (76 of 146) |
| Chariot | 50% (8 of 16) | 80% (8 of 10) | - | 62% (16 of 26) |
| Infantry | 56% (50 of 89) | 39% (14 of 36) | 50% (1 of 2) | 51% (65 of 127) |
| Monster | 59% (19 of 32) | 90% (9 of 10) | - | 67% (28 of 42) |
| Monstrous | 27% (3 of 11) | 43% (6 of 14) | - | 36% (9 of 25) |
| War Machines | 73% (30 of 41) | 100% (1 of 1) | - | 74% (31 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 55% (6 of 11); on the table 55% | 33% (45 of 138) | 41% | 61% (20 of 33) | 100% (9 of 9); 5.2 uses a game | 100% (3 of 3); 1.0 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 89% (8 of 9); on the table 100% | 17% (4 of 24) | 38% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 89% (8 of 9); on the table 89% | - | 67% | 73% (30 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (16 of 18); on the table 89% | 28% (10 of 36) | 57% | 58% (37 of 64) | 0.0 uses a game | 100% (2 of 2); 1.7 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 5 | 92% (11 of 12); on the table 100% | 26% (28 of 108) | 40% | 39% (17 of 44) | 100% (12 of 12); 6.6 uses a game | 100% (1 of 1); 0.8 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 95% (19 of 20); on the table 95% | 17% (5 of 30) | 33% | 59% (29 of 49) | 100% (5 of 5); 3.3 uses a game | 44% (8 of 18); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 48% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 26% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 50% (3 of 6); on the table 67% | 17% (2 of 12) | 47% | 67% (14 of 21) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (12 of 12); on the table 100% | 8% (3 of 36) | 7% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 92% (11 of 12); on the table 92% | 23% (7 of 30) | 40% | 65% (22 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 94% (16 of 17); on the table 94% | 17% (2 of 12) | 37% | 30% (9 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (27 of 27); on the table 100% | 39% (21 of 54) | 39% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 89% (24 of 27); on the table 89% | 30% (9 of 30) | 41% | 69% (51 of 74) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (16 of 16); on the table 100% | 20% (6 of 30) | 44% | 55% (36 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-h2h-mine-324c342-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (40) | 49% (34) | 50% (74) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.50 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.33 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.89 | 1.31 | 3.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.78 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.19 | 4.69 | 9.89 |

### Quality by phase: co-h2h-mine-324c342-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (70 of 131) | 38% (78 of 205) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (189 of 380) | 70% (137 of 197) |
| Strategy | Close-in objectives charged next turn | 12% (19 of 161) | 18% (36 of 197) |
| Strategy | Support requests answered (helper made contact too) | 45% (9 of 20) | 40% (14 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (5 of 9) | 70% (7 of 10) |
| Strategy | Joined characters whose unit fought | 36% (18 of 50) | 49% (22 of 45) |
| Strategy | Lone characters that fought | 76% (73 of 96) | 73% (66 of 91) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 2.0 |
| Movement | Points that never moved of their own | 267.4 | 178.3 |
| Movement | Fights charged into per game | 2.5 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 19 of 84, net +0 | 24 of 98, net +42 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 84, net +154 | 18 of 98, net +82 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 84, net +78 | 4 of 98, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 84, net +117 | 31 of 98, net +177 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (140 of 356) | 43% (148 of 348) |
| Shooting | Points destroyed by shooting units | 92.4 | 28.3 |
| Shooting | War machine shots | 6.3 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (111 of 227) | 45% (27 of 60) |
| Shooting | Points destroyed by war machines | 84.1 | 20.4 |
| Magic | Magic missiles cast | 1.7 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (22 of 61) | 34% (11 of 32) |
| Magic | Wounds caused by magic missiles | 4.8 | 0.8 |
| Magic | Wounds caused by other spells | 1.5 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 80.7 | 22.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 0.8 / 0.2 | 1.1 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 289.0 | 320.1 |
| Combat | Points run down | 83.3 | 139.3 |
| Combat | Net points per charged fight, damage counted | +73 | +90 |
| Combat | Net per 100 charger points, damage counted | +26.4 | +37.2 |
| Combat | First round won (charged fights) | 68% | 55% |
| Combat | Net points per charged fight | +80 | +100 |
| Combat | Net points per supported fight / lone fight | +122 / +71 | +197 / +81 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 91 | 50 of 117 |
| Game | Points lost | 730.0 | 729.3 |
| Game | VP from objectives | 645.8 | 605.3 |
| Game | Lone holders (player turns) | 2.6 | 2.8 |

- Mine won / drew / lost: 15 / 6 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +73 VP
- The side that went first won 13 of 30 games with a winner
- Points traded per game (both sides' losses): 1459
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-h2h-mine-324c342-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 4.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 12.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +5.6 | 0.0 | 22.7 | 0.9 | +8.9 | 0.0 | 57.2 |
| BEST FACING | 0.9 | +39.1 | 0.0 | 29.9 | 0.5 | +17.8 | 0.0 | 15.3 |
| BEST FIRST | 4.4 | +171.9 | 221.6 | 91.1 | 3.9 | +217.2 | 114.3 | 56.8 |
| BEST OVERALL | 0.5 | +31.2 | 0.0 | 21.6 | 0.6 | +46.3 | 0.0 | 34.1 |
| BEST PREY | 0.6 | +48.4 | 24.7 | 20.3 | 0.8 | +30.9 | 18.1 | 19.0 |
| BEST PRIZE | 0.1 | -3.6 | 0.0 | 0.0 | 0.1 | -2.7 | 11.1 | 3.9 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 9.7 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| BLOCKED WHEEL | 0.3 | +2.3 | 0.0 | 6.4 | 0.4 | +3.0 | 0.0 | 1.8 |
| BLOWS WHERE AIMED | 0.3 | -66.2 | 28.5 | 35.9 | - | - | - | - |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 88.8 | 12.2 | 0.1 | +0.0 | 3.3 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +154.8 | 380.4 | 74.7 | 1.5 | +27.5 | 22.5 | 14.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.1 | 4.2 | 0.0 | 0.1 | -4.9 | 8.2 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 6.2 | 26.8 | 0.2 | -0.4 | 21.8 | 0.0 |
| CAST JOB | 0.6 | +19.2 | 35.7 | 6.1 | 0.4 | +9.4 | 23.5 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +28.1 | 2.8 | 17.2 | 0.1 | +3.6 | 11.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 11.2 | 0.2 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.3 | 0.0 | 5.6 | 0.2 | -0.4 | 3.5 | 8.6 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 173.4 | 88.8 | 2.7 | +0.0 | 226.9 | 64.2 |
| CHARGE NOW WEIGHED | 0.4 | -21.2 | 8.7 | 8.9 | 0.4 | -34.7 | 13.4 | 11.4 |
| CHARGER SLAIN LOST | 0.5 | -13.3 | 22.6 | 14.1 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 0.0 | 11.1 | 0.1 | -0.1 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 5.1 | 0.0 | 0.3 | +0.0 | 19.3 | 3.1 |
| COMBAT PIVOT | 0.6 | +0.0 | 42.2 | 41.2 | 0.2 | +0.0 | 4.5 | 26.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +285.7 | 2.1 | 22.5 | 0.2 | +31.8 | 17.4 | 35.9 |
| COUNTER-CHARGE COVER | 9.2 | +855.6 | 0.0 | 229.5 | 6.8 | +614.4 | 0.0 | 148.0 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 33.9 | 4.1 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.2 | 2.2 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.7 | 5.6 | 0.0 | 0.2 | +19.3 | 46.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +121.9 | 0.0 | 43.8 | 1.3 | +108.2 | 0.0 | 58.1 |
| FALLBACK BY WORTH | 5.0 | +80.0 | 0.0 | 74.9 | 5.2 | +57.1 | 0.0 | 49.9 |
| FIGHT LIFT | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +2.5 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 141.4 | 4.7 | +0.0 | 0.0 | 129.9 |
| FOCUS FIRE | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +122.6 | 0.0 | 40.5 | 0.9 | +142.6 | 0.0 | 21.4 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.3 | 0.0 | 4.7 | 0.1 | +8.5 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -3.8 | 22.3 | 0.0 | 0.2 | -2.8 | 15.0 | 9.2 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 15.0 | 1.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 38.2 | 1.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 12.6 | 16.5 | 0.5 | +0.0 | 35.5 | 12.3 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -15.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 4.8 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 3.2 |
| HUNT IN PAIRS | 0.5 | +28.7 | 0.0 | 10.2 | 0.5 | +34.6 | 0.0 | 17.5 |
| HUNT KEPT | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 1.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.6 |
| HUNT THE GUNS | 0.0 | +10.7 | 0.0 | 0.0 | 0.2 | +69.7 | 0.0 | 8.1 |
| INVITES THE FIGHT | 1.6 | +30.9 | 89.8 | 17.5 | 1.7 | +34.0 | 56.6 | 45.7 |
| JOINT CHARGE PLAN | 0.1 | +4.5 | 0.0 | 0.0 | 0.1 | +11.7 | 17.8 | 4.2 |
| JOINT KNOWS CHALLENGE | 0.0 | -1.7 | 6.2 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 3.2 | 0.0 | 0.1 | +0.2 | 4.2 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 104.1 | 56.3 | 2.0 | +60.8 | 146.0 | 32.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +72.4 | 121.2 | 13.9 | 2.2 | +88.3 | 150.8 | 39.1 |
| KILLS COUNT NEXT TURN | 4.6 | +151.7 | 108.6 | 95.8 | 5.6 | +248.7 | 257.9 | 166.9 |
| LONE CHARACTER SAFE SPOT | 0.3 | +12.9 | 1.0 | 2.0 | 0.4 | +5.5 | 0.0 | 26.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -2.2 | 7.2 | 3.1 | 0.8 | +8.2 | 46.8 | 12.1 |
| LOST CHARGE | 2.9 | -42.6 | 119.8 | 66.5 | 3.0 | -46.4 | 82.9 | 67.5 |
| LURE BY WHAT IT DRAWS | 0.1 | -1.5 | 0.0 | 1.5 | 0.1 | -9.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +70.1 | 18.6 | 39.1 | 0.7 | +75.3 | 81.7 | 6.5 |
| MANOEUVRE | 0.2 | +10.8 | 0.0 | 0.0 | 0.1 | +4.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.4 | 0.0 | 4.4 |
| MARCH CHECK | 0.5 | +24.6 | 0.0 | 2.4 | 0.5 | +19.7 | 0.0 | 20.4 |
| MARCH ODDS | 0.2 | +17.3 | 10.5 | 26.2 | 0.2 | +15.4 | 4.9 | 0.0 |
| MARCH OVER CASTS | 0.4 | +18.3 | 0.0 | 11.1 | 0.3 | +11.3 | 0.0 | 36.5 |
| MAX FOR POSITIONING | 4.9 | +174.8 | 0.0 | 105.7 | 4.6 | +175.9 | 0.0 | 115.9 |
| MISSILES IN THE MOVE | 3.9 | +148.1 | 0.0 | 75.4 | 3.5 | +54.9 | 0.0 | 70.4 |
| MISSILES NEXT TURN | 4.6 | +98.7 | 0.0 | 126.3 | 4.1 | +37.1 | 0.0 | 124.9 |
| MODEL FACING | 0.4 | +90.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 10.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +12.0 | 0.0 | 4.5 | 0.3 | +8.3 | 0.0 | 9.4 |
| MOVE SPELL IN RANGE | 0.2 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -49.0 | 0.0 | 9.9 | 0.1 | -11.6 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +298.2 | 75.2 | 70.3 | 4.5 | +375.5 | 189.4 | 178.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +12.2 | 0.0 | 0.0 | 0.1 | +8.6 | 11.9 | 11.1 |
| NO RALLY LEFT | 0.1 | +1.2 | 0.0 | 2.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -5.5 | 19.9 | 1.2 | 0.4 | -20.1 | 83.6 | 0.0 |
| NOT TURNED | 5.2 | +74.7 | 0.0 | 121.6 | 4.7 | +65.4 | 0.0 | 132.2 |
| NOT WORTH A CAST | 0.8 | -0.7 | 0.0 | 59.6 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 15.9 | -920.5 | 1.9 | 246.5 | 14.6 | -909.3 | 11.8 | 272.6 |
| OPENS A LANE | 0.1 | +0.1 | 6.1 | 0.0 | 0.1 | +0.3 | 6.7 | 0.0 |
| OPENS UP | 0.2 | +20.8 | 10.7 | 10.6 | 0.4 | +35.0 | 16.4 | 24.6 |
| OVERRUNS AWAY | 0.5 | +11.2 | 36.1 | 13.8 | 0.7 | +11.3 | 56.3 | 25.1 |
| PATHS CROSS | 2.0 | +87.1 | 0.0 | 41.1 | 2.5 | +193.7 | 0.0 | 65.0 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.0 | 0.0 | 1.4 | 0.1 | -4.2 | 0.0 | 9.9 |
| PLAN RESULT | 37.1 | +1580.8 | 1169.7 | 933.6 | 37.4 | +961.4 | 1294.7 | 867.1 |
| PURSUES BIG PREY | 0.1 | -8.6 | 0.0 | 0.0 | 0.1 | -20.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +9.0 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 0.9 | +22.6 | 0.0 | 18.6 | 1.4 | +26.4 | 0.0 | 42.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.8 | 8.8 | 4.7 | 0.2 | -7.1 | 1.5 | 20.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +0.2 | 0.0 | 4.5 | 0.2 | -5.9 | 0.0 | 2.4 |
| REDIRECT COUNTER | 1.8 | +112.9 | 0.0 | 27.7 | 3.8 | +327.1 | 0.0 | 54.1 |
| REDIRECT WEIGHED | 0.1 | -0.6 | 2.6 | 0.0 | 0.5 | +8.7 | 9.6 | 3.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 11.9 | - | - | - | - |
| RESERVE FALL BACK | 0.2 | +3.6 | 0.0 | 3.8 | 0.8 | +40.2 | 0.0 | 15.4 |
| RESTRAINS TO SHOOT | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +127.4 | 162.6 | 79.0 | 3.1 | +68.1 | 258.2 | 117.9 |
| SAFER THAN THE JOB | 0.9 | +47.0 | 0.0 | 22.9 | 0.8 | +47.8 | 0.0 | 9.5 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.9 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| SEARCH SPOT | 2.0 | +107.8 | 0.0 | 59.9 | 2.9 | +165.8 | 0.0 | 41.9 |
| SELF MOVE SPELL | 0.3 | +5.5 | 0.0 | 18.1 | 0.2 | +5.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +115.7 | 18.6 | 55.0 | 1.5 | +144.1 | 100.1 | 26.9 |
| SET-UP ANY TARGET | 0.2 | +35.3 | 0.0 | 0.0 | 0.1 | +9.6 | 13.1 | 20.7 |
| SET-UP MISSED | 0.0 | +2.4 | 0.0 | 0.0 | 0.0 | +3.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +30.0 | 59.1 | 7.6 | 0.4 | +7.4 | 3.7 | 14.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 100.5 | 15.4 | 0.3 | +0.0 | 36.2 | 0.0 |
| SHOTS IN THE MOVE | 14.1 | +501.7 | 0.0 | 240.3 | 9.2 | +202.8 | 0.0 | 84.1 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +240.1 | 0.0 | 0.0 | 0.1 | +23.7 | 13.1 | 20.7 |
| SPELL WORTH | 1.0 | +21.2 | 89.2 | 90.7 | 1.4 | +33.2 | 116.0 | 126.0 |
| SPELLS IN THE FIGHT | 0.5 | +1.1 | 48.3 | 39.1 | - | - | - | - |
| STABLE ROLE | 11.4 | +0.0 | 354.3 | 149.3 | 11.1 | +0.0 | 345.4 | 169.6 |
| STANDS TO CAST | - | - | - | - | 0.1 | +7.8 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +1.8 | 0.0 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +20.0 | 0.0 | 12.2 | 0.4 | +29.1 | 0.0 | 12.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.4 | -38.6 | 218.7 | 78.8 | 7.6 | -49.3 | 398.2 | 93.6 |
| SUPPORTS | 2.7 | +42.8 | 95.1 | 58.9 | 4.6 | +49.3 | 181.4 | 57.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -15.6 | 14.8 | 0.0 | 0.1 | -1.9 | 8.3 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -4.8 | 0.0 | 19.5 | 0.7 | +14.5 | 21.1 | 28.6 |
| THROUGH LINE OF FIRE | 0.7 | +31.1 | 0.0 | 19.8 | 0.1 | +10.8 | 0.0 | 10.2 |
| TURN WORTH | 0.2 | -12.6 | 4.4 | 0.0 | 0.5 | -28.7 | 44.6 | 1.9 |
| TWO OR MORE ARRIVE | 0.4 | +6.9 | 0.0 | 1.4 | 0.3 | +1.1 | 41.8 | 8.7 |
| WAIT AFTER COSTS | 7.4 | -346.8 | 217.6 | 133.4 | 8.3 | -457.0 | 351.3 | 227.6 |
| WALKS TO THE FIGHT | 2.1 | +54.6 | 49.3 | 39.4 | 1.3 | +43.1 | 59.0 | 3.1 |
| WAR ENGINE CHARGES | 0.1 | +9.0 | 1.8 | 0.0 | 0.0 | +1.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 20.8 | 8.8 | 0.5 | +0.0 | 24.3 | 5.1 |
| WEARS DOWN | 0.9 | +48.7 | 94.9 | 55.1 | 1.7 | +43.6 | 198.4 | 42.1 |
| WHO HITS BACK | 0.2 | +23.5 | 0.0 | 11.9 | 0.1 | +27.7 | 0.0 | 10.7 |
| WHOLE FIGHT | 0.2 | +10.3 | 18.4 | 0.0 | 0.6 | +20.1 | 63.4 | 2.5 |
| WHOLE FIGHT GAIN | 0.4 | +20.5 | 31.1 | 2.2 | 0.8 | +49.4 | 116.5 | 20.6 |
| WIDER SPREAD | 2.3 | -4.2 | 184.6 | 73.6 | - | - | - | - |

### Rule changes: co-h2h-mine-324c342-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1099 | 1099 | 1099 | 30.53 | -65870 | -59.9 |
| BEST FIRST | 301 | 301 | 301 | 8.36 | +14008 | +46.5 |
| SEARCH SPOT | 179 | 179 | 177 | 4.92 | +9863 | +55.7 |
| PATHS CROSS | 163 | 163 | 163 | 4.53 | +10108 | +62.0 |
| MOVE TO CHARGE | 283 | 283 | 157 | 4.36 | +10244 | +65.3 |
| COUNTER-CHARGE COVER | 578 | 311 | 155 | 4.31 | +11406 | +73.6 |
| FACES THE THREAT | 115 | 115 | 115 | 3.19 | +8282 | +72.0 |
| KILLS COUNT NEXT TURN | 368 | 368 | 107 | 2.97 | +4636 | +43.3 |
| SUPPORTS | 264 | 264 | 95 | 2.64 | +1012 | +10.7 |
| FALLBACK BY WORTH | 368 | 368 | 85 | 2.36 | +4937 | +58.1 |
| WALKS TO THE FIGHT | 122 | 122 | 82 | 2.28 | +1379 | +16.8 |
| SHOTS IN THE MOVE | 838 | 562 | 69 | 1.92 | +1528 | +22.1 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +9549 | +149.2 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +3413 | +55.0 |
| WAIT AFTER COSTS | 564 | 564 | 62 | 1.72 | +1114 | +18.0 |
| ARTILLERY RE-ROLL WEIGHED | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| CANNON PLANNED TARGET | 237 | 237 | 56 | 1.56 | -331 | -5.9 |
| RANDOM MOVE BY FIGURES | 82 | 82 | 56 | 1.56 | +1763 | +31.5 |
| BEST FACING | 52 | 52 | 52 | 1.44 | +2050 | +39.4 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CHARGE NOW FIRST | 183 | 183 | 50 | 1.39 | -3718 | -74.4 |
| RISK BY ARC | 205 | 193 | 49 | 1.36 | +2173 | +44.3 |
| REDIRECT COUNTER | 201 | 109 | 48 | 1.33 | +3493 | +72.8 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MAX FOR POSITIONING | 341 | 188 | 43 | 1.19 | +483 | +11.2 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +2789 | +66.4 |
| SET UP TOGETHER | 98 | 80 | 40 | 1.11 | +3323 | +83.1 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.00 | +1575 | +43.8 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOT REPLANNED | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| MARCH CHECK | 36 | 34 | 33 | 0.92 | +1836 | +55.6 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1766 | +53.5 |
| CHARGE NOW WEIGHED | 32 | 32 | 32 | 0.89 | +1285 | +40.1 |
| KILLS COUNT | 140 | 136 | 32 | 0.89 | +1267 | +39.6 |
| MISSILES IN THE MOVE | 266 | 164 | 29 | 0.81 | +667 | +23.0 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +1506 | +51.9 |
| COMBAT PIVOT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| INVITES THE FIGHT | 119 | 119 | 27 | 0.75 | +510 | +18.9 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +191 | +7.6 |
| SHOOTS FROM THE BEST SPOT | 46 | 46 | 25 | 0.69 | +582 | +23.3 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +731 | +31.8 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +699 | +30.4 |
| CAST JOB | 36 | 36 | 21 | 0.58 | +426 | +20.3 |
| WHOLE FIGHT GAIN | 43 | 40 | 20 | 0.56 | +666 | +33.3 |
| KEEPS ITS TARGET | 127 | 125 | 19 | 0.53 | +295 | +15.5 |
| MAKE SURE TOGETHER | 51 | 42 | 19 | 0.53 | +1906 | +100.3 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +228 | +13.4 |
| WEARS DOWN | 94 | 87 | 15 | 0.42 | +521 | +34.7 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MANOEUVRE | 14 | 14 | 14 | 0.39 | +532 | +38.0 |
| MODEL FACING | 13 | 13 | 13 | 0.36 | +3264 | +251.1 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +1533 | +127.8 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -24 | -2.2 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +713 | +64.8 |
| OPENS UP | 21 | 21 | 11 | 0.31 | +385 | +35.0 |
| BEST PREY | 50 | 50 | 10 | 0.28 | +675 | +67.5 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -30 | -3.0 |
| CASTING BLOCK | 15 | 15 | 10 | 0.28 | +566 | +56.6 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| WHOLE FIGHT | 27 | 25 | 10 | 0.28 | +513 | +51.3 |
| LOST CHARGE | 212 | 211 | 8 | 0.22 | +216 | +27.1 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WAR ENGINE JOBS | 31 | 31 | 8 | 0.22 | -797 | -99.6 |
| HUNT IN PAIRS | 36 | 23 | 7 | 0.19 | +390 | +55.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -1044 | -149.2 |
| SUPPORT NARROWED | 431 | 431 | 7 | 0.19 | -61 | -8.8 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -542 | -90.2 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +221 | +36.9 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -153 | -30.6 |
| SURE REACH TOGETHER | 49 | 33 | 5 | 0.14 | +77 | +15.4 |
| OVERRUNS AWAY | 42 | 38 | 4 | 0.11 | +43 | +10.6 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -627 | -156.8 |
| BACKUP TARGETS | 57 | 26 | 3 | 0.08 | +8 | +2.6 |
| HUNT ADVANCE | 6 | 6 | 3 | 0.08 | +99 | +33.0 |
| JOINT CHARGE PLAN | 10 | 10 | 3 | 0.08 | +108 | +35.9 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +63 | +20.9 |
| LONG SHOT | 47 | 45 | 3 | 0.08 | +55 | +18.5 |
| MISSILES NEXT TURN | 312 | 188 | 3 | 0.08 | +8 | +2.8 |
| NEEDED THERE | 5 | 4 | 3 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +332 | +110.5 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +64 | +21.4 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -26 | -8.7 |
| WIDER SPREAD | 84 | 79 | 3 | 0.08 | +29 | +9.8 |
| CARRIES OUT COUNTER | 4 | 4 | 2 | 0.06 | -179 | -89.7 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 12 | 12 | 2 | 0.06 | +215 | +107.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +97 | +48.7 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +77 | +38.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +26 | +13.0 |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 2 | 0.06 | +92 | +45.9 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.06 | -0 | -0.1 |
| SPELLS IN THE FIGHT | 19 | 17 | 2 | 0.06 | +76 | +37.8 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.06 | +225 | +112.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -15 | -15.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -30 | -29.9 |
| DEFENSIVE ARMY | 15 | 15 | 1 | 0.03 | -11 | -11.3 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +14 | +14.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +45 | +45.2 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 1 | 0.03 | -45 | -45.1 |
| MOVE SPELL IN RANGE | 7 | 3 | 1 | 0.03 | +15 | +14.7 |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 1 | 0.03 | +17 | +16.9 |
| TURN WORTH | 25 | 25 | 1 | 0.03 | +3 | +2.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 11 | 10 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 35 | 35 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 19 | 17 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 14 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 359 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 24 | 24 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 356 | 356 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2682 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 89 | not checked | - | - | - | - |
| STABLE ROLE | 807 | 803 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 22 | 0 | 0.00 | - | - |

### Off best figure: co-h2h-mine-324c342-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.97 | 13.06 | 61.5 |
| FALLBACK | gate | 0.83 | 0.58 | 40.8 |
| CHARGE NOW FIRST | rule | 0.64 | 0.75 | 74.4 |
| TURN GATE | gate | 0.50 | 0.44 | 51.8 |
| FIGHT ORDER BAND | gate | 0.19 | 0.11 | 1.9 |
| PATHS CROSS | rule | 0.19 | 0.06 | 36.0 |
| AFTERMATH BAND | gate | 0.14 | 0.08 | 2.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.17 | 38.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.17 | 122.2 |
| SUPPORT REQUEST | gate | 0.08 | 0.14 | 115.0 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 149.2 |
| WAR ENGINE JOBS | rule | 0.08 | 0.11 | 113.9 |
| BEST PRIZE | rule | 0.06 | 0.11 | 90.2 |
| BLOCKED WHEEL | rule | 0.06 | 0.11 | 27.5 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 71.2 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 10.2 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.03 | 11.1 |
| CHAFF PASSED | rule | 0.03 | 0.11 | 4.8 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.11 | 30.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 32.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.08 | 89.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 156.8 |
| MARCH ODDS | rule | 0.03 | 0.06 | 25.8 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 11.5 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 89.7 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 11.7 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 15.1 |
| CATCH ODDS | rule | - | 0.03 | 29.9 |
| DEFENSIVE ARMY | rule | 0.03 | - | 11.3 |
| FACES THE THREAT | rule | 0.03 | - | 12.0 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 0.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 45.1 |
| NO REASON | gate | 0.03 | - | 143.5 |
| RULE SWITCHED OFF | gate | - | 0.03 | 10.4 |
| SAFER THAN THE JOB | rule | 0.03 | - | 9.1 |
| STANDS TO CAST | rule | - | 0.03 | 34.3 |
| WHO HITS BACK | rule | - | 0.03 | 1.1 |

### Plans: co-h2h-mine-324c342-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 18% | 513 | 397 | 77% |
| Mine | charge | 3.0 | 61% | 304 | 263 | 86% |
| Mine | close in | 4.4 | 29% | 328 | 138 | 42% |
| Mine | hold | 5.2 | 41% | 332 | 0 | 0% |
| Mine | join | 0.6 | 95% | 22 | 0 | 0% |
| Mine | shoot | 9.0 | 67% | 335 | 783 | 234% |
| Mine | support | 3.1 | 86% | 30 | 0 | 0% |
| Opponent | advance | 12.5 | 17% | 426 | 287 | 67% |
| Opponent | charge | 4.9 | 49% | 443 | 361 | 82% |
| Opponent | close in | 5.4 | 27% | 490 | 140 | 29% |
| Opponent | hold | 4.2 | 43% | 288 | 0 | 0% |
| Opponent | join | 1.0 | 91% | 40 | 0 | 0% |
| Opponent | shoot | 4.4 | 52% | 94 | 177 | 189% |
| Opponent | support | 5.0 | 91% | 43 | 0 | 0% |

### Packages: hunt the guns, co-h2h-mine-324c342-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 17 |
| Opponent | 0.2 | 6 | 0 | 17% | 0% | 0% | - | 418 | 0 | 0% | 90 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 126 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 162 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 268 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 255 | 0 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 569 | 0 | 0% | 61 |
| Warriors of Chaos | 0.4 | 3 | 0 | 0% | 0% | 0% | - | 452 | 0 | 0% | 14 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 41 |

### Battle groups: co-h2h-mine-324c342-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 28% | 61% | 10% | 78% | 38% | 15% | 8% | 39% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 32% | 52% | 0% | - | 19% | 5% | 5% | 71% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 17% | 69% | 31% | 23% | 48% | 7% | 14% | 31% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 27% | 75% | 11% | 0% | 22% | 3% | 12% | 62% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-h2h-mine-324c342-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 81 | 0% | 4.3 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Mine | Chaff | 37 | 14 (37) | 5 | 9 | 43 | 49% | 2.4 | 4 (16) | 0 (9) | 36 (12) | 3 (24) | 31 (13) |
| Mine | Character | 123 | 48 (123) | 48 | 0 | 34 | 21% | 2.3 | 78 (31) | 41 (60) | 31 (9) | 67 (54) | 38 (46) |
| Mine | Clean-up | 26 | 71 (26) | 25 | 46 | 30 | 38% | 2.6 | 45 (10) | 85 (12) | 150 (4) | 100 (14) | 41 (12) |
| Mine | Fast | 4 | 18 (4) | 18 | 0 | 34 | 25% | 1.3 | 33 (1) | 0 (2) | 0 (1) | 18 (4) | - |
| Mine | Fast Hammer | 39 | 35 (39) | 24 | 11 | 61 | 26% | 2.9 | 40 (17) | 42 (11) | 21 (11) | 34 (28) | 37 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 57 | 45 (57) | 27 | 18 | 41 | 16% | 2.4 | 70 (10) | 44 (37) | 26 (10) | 64 (34) | 23 (23) |
| Mine | Holder | 25 | 100 (25) | 10 | 90 | 26 | 56% | 3.4 | 91 (8) | 96 (13) | 138 (4) | 151 (12) | 57 (13) |
| Mine | Shooter | 45 | 77 (45) | 30 | 47 | 47 | 4% | 1.8 | 0 (5) | 96 (33) | 68 (7) | 119 (23) | 38 (22) |
| Mine | Support | 5 | 24 (5) | 24 | 0 | 42 | 60% | 3.5 | 0 (1) | 58 (1) | - | 58 (1) | 0 (1) |
| Mine | War machine | 56 | 49 (56) | 49 | 0 | 36 | 5% | 1.3 | 76 (13) | 35 (37) | 80 (6) | 51 (11) | 48 (45) |
| Mine | Wizard | 23 | 32 (23) | 32 | 0 | 32 | 9% | 2.6 | 34 (6) | 41 (10) | 0 (2) | 58 (3) | 25 (15) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 82 (66) | 29 | 52 | 41 | 35% | 2.5 | 127 (28) | 45 (16) | 56 (22) | 100 (48) | 29 (18) |
| Opponent | Character | 114 | 51 (114) | 51 | 0 | 38 | 18% | 2.4 | 77 (42) | 42 (54) | 23 (5) | 58 (68) | 54 (33) |
| Opponent | Clean-up | 17 | 23 (17) | 10 | 13 | 64 | 35% | 3.2 | 0 (5) | 28 (9) | 52 (3) | 24 (9) | 23 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 47 (58) | 33 | 15 | 49 | 31% | 2.3 | 62 (25) | 19 (19) | 49 (14) | 50 (42) | 41 (16) |
| Opponent | Fragile | 10 | 46 (10) | 46 | 0 | 43 | 30% | 1.7 | 132 (4) | 0 (3) | 0 (3) | 46 (10) | - |
| Opponent | Hammer | 64 | 33 (64) | 24 | 9 | 38 | 30% | 2.5 | 15 (16) | 40 (41) | 25 (7) | 37 (39) | 27 (25) |
| Opponent | Holder | 40 | 54 (40) | 9 | 46 | 21 | 42% | 3.3 | 22 (11) | 82 (17) | 43 (11) | 66 (22) | 43 (17) |
| Opponent | Shooter | 30 | 85 (30) | 25 | 60 | 34 | 7% | 1.2 | 68 (7) | 96 (18) | 63 (5) | 99 (16) | 67 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | War machine | 13 | 43 (13) | 43 | 0 | 36 | 0% | 1.2 | 0 (5) | 65 (5) | 77 (3) | 101 (3) | 26 (10) |
| Opponent | Wizard | 22 | 0 (22) | 0 | 0 | 29 | 9% | 2.2 | 0 (11) | 0 (4) | 0 (3) | 0 (10) | 0 (8) |

### Charged fights: co-h2h-mine-324c342-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 222 | 117 | 1.0 | 1.0 | 117 | 6 | +111 | 1 of 5 | 3 of 5 | - | +111 |
| Mine | Chaos Dwarfs | 3 | 0 | 818 | 3.7 | 1.1 | 223 | 0 | +223 | 6 of 11 | 9 of 11 | +732 | +172 |
| Mine | Dwarfen Mountain Holds | 4 | 414 | 10 | 1.0 | 1.2 | 10 | 0 | +10 | 2 of 4 | 2 of 4 | +0 | +14 |
| Mine | Empire of Man | 5 | 544 | 39 | 1.4 | 1.1 | 28 | 54 | -26 | 1 of 7 | 4 of 7 | +0 | -31 |
| Mine | Grand Cathay | 4 | 715 | 380 | 4.0 | 1.2 | 95 | 21 | +74 | 10 of 16 | 10 of 16 | +20 | +87 |
| Mine | High Elf Realms | 4 | 84 | 177 | 2.2 | 1.0 | 79 | 61 | +17 | 5 of 9 | 5 of 9 | - | +17 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 750 | 4.0 | 1.5 | 188 | 0 | +188 | 2 of 4 | 4 of 4 | +204 | +172 |
| Mine | Lizardmen | 1 | 0 | 391 | 3.0 | 1.0 | 130 | 164 | -33 | 2 of 3 | 0 of 3 | - | -33 |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | +0 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 650 | 4.0 | 1.2 | 162 | 0 | +162 | 2 of 4 | 4 of 4 | +265 | +128 |
| Mine | Skaven | 2 | 258 | 0 | 1.0 | 1.5 | 0 | 98 | -98 | 2 of 2 | 1 of 2 | -195 | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1004 | 4.0 | 1.2 | 251 | 142 | +109 | 3 of 8 | 5 of 8 | +183 | +84 |
| Mine | Vampire Counts | 2 | 0 | 588 | 5.5 | 1.3 | 107 | 4 | +103 | 3 of 11 | 9 of 11 | +105 | +102 |
| Mine | Warriors of Chaos | 1 | 0 | 107 | 5.0 | 1.0 | 21 | 24 | -3 | 1 of 5 | 5 of 5 | - | -3 |
| **Mine** | all armies | 36 | 257 | 294 | 2.5 | 1.2 | 116 | 36 | +80 | 41 of 91 | 62 of 91 | +122 | +71 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 3.0 | 1.7 | 0 | 17 | -17 | 2 of 3 | 0 of 3 | -26 | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 399 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 355 | 381 | 4.0 | 1.0 | 95 | 0 | +95 | 3 of 4 | 2 of 4 | - | +95 |
| Opponent | High Elf Realms | 2 | 0 | 558 | 3.0 | 1.5 | 186 | 0 | +186 | 3 of 6 | 3 of 6 | +352 | +103 |
| Opponent | Lizardmen | 1 | 0 | 715 | 2.0 | 1.5 | 358 | 112 | +246 | 2 of 2 | 1 of 2 | +48 | +443 |
| Opponent | Ogre Kingdoms | 2 | 78 | 300 | 4.0 | 1.1 | 75 | 47 | +28 | 2 of 8 | 5 of 8 | +0 | +32 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 662 | 5.5 | 1.0 | 120 | 15 | +105 | 5 of 11 | 5 of 11 | - | +105 |
| Opponent | Skaven | 2 | 0 | 0 | 1.0 | 1.0 | 0 | 487 | -487 | 1 of 2 | 1 of 2 | - | -487 |
| Opponent | Tomb Kings of Khemri | 4 | 84 | 937 | 3.5 | 1.2 | 268 | 55 | +213 | 6 of 14 | 9 of 14 | +319 | +184 |
| Opponent | Vampire Counts | 6 | 81 | 410 | 4.2 | 1.2 | 98 | 18 | +80 | 10 of 25 | 13 of 25 | +272 | +43 |
| Opponent | Warriors of Chaos | 7 | 0 | 318 | 2.1 | 1.1 | 148 | 19 | +129 | 6 of 15 | 10 of 15 | +95 | +132 |
| Opponent | Wood Elf Realms | 6 | 138 | 501 | 4.2 | 1.2 | 120 | 23 | +97 | 8 of 25 | 14 of 25 | +181 | +77 |
| **Opponent** | all armies | 36 | 71 | 433 | 3.2 | 1.2 | 133 | 33 | +100 | 50 of 117 | 64 of 117 | +197 | +81 |

### Effective charges: co-h2h-mine-324c342-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net +258) | 0 | 0 | 1 (net +0) | 0 | 1 (net +40) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 11 | 2 (net +408) | 0 | 2 (net +0) | 1 (net +732) | 1 (net +112) | 4 (net +199) | 1 | 20% (2 of 10) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 2 (net +20) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 1 (net -380) | 0 | 1 (net +195) | 2 (net +0) | 2 (net +0) | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 16 | 2 (net -84) | 0 | 6 (net +108) | 3 (net +173) | 3 (net +34) | 1 (net +0) | 1 | 40% (6 of 15) |
| Mine | High Elf Realms | 9 | 2 (net -198) | 1 (net +0) | 1 (net +45) | 2 (net +0) | 0 | 3 (net +169) | 0 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +268) | 0 | 0 | 1 (net +75) | 1 (net +68) | 1 (net +339) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 3 | 1 (net +216) | 1 (net -175) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 2 (net +295) | 0 | 1 (net +60) | 0 | 1 | 67% (2 of 3) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net -195) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 2 (net -410) | 0 | 4 (net +244) | 1 (net +286) | 1 (net +432) | 0 | 0 | 50% (4 of 8) |
| Mine | Vampire Counts | 11 | 3 (net -15) | 0 | 1 (net +170) | 2 (net +240) | 3 (net +81) | 2 (net +142) | 0 | 9% (1 of 11) |
| Mine | Warriors of Chaos | 5 | 1 (net +0) | 0 | 0 | 2 (net -61) | 0 | 1 (net +107) | 1 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 3 | 2 (net +0) | 0 | 1 (net -52) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 4 | 2 (net +48) | 0 | 0 | 2 (net +143) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 6 | 2 (net +0) | 0 | 0 | 2 (net +206) | 0 | 2 (net +352) | 0 | 0% (0 of 6) |
| Opponent | Lizardmen | 2 | 2 (net +246) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 1 (net -40) | 0 | 1 (net +30) | 0 | 1 (net +0) | 3 (net +90) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 11 | 2 (net +110) | 0 | 0 | 1 (net +85) | 1 (net +110) | 2 (net +218) | 5 | 0% (0 of 6) |
| Opponent | Skaven | 2 | 1 (net -862) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 14 | 1 (net -136) | 1 (net +405) | 6 (net +180) | 0 | 0 | 5 (net +311) | 1 | 46% (6 of 13) |
| Opponent | Vampire Counts | 25 | 6 (net +22) | 1 (net +0) | 6 (net +124) | 4 (net +0) | 0 | 6 (net +151) | 2 | 26% (6 of 23) |
| Opponent | Warriors of Chaos | 15 | 2 (net +556) | 1 (net +143) | 1 (net -286) | 2 (net +176) | 1 (net +95) | 5 (net +69) | 3 | 8% (1 of 12) |
| Opponent | Wood Elf Realms | 25 | 3 (net +0) | 0 | 3 (net -14) | 6 (net +175) | 1 (net +60) | 7 (net +180) | 5 | 15% (3 of 20) |

### Charged fights, damage counted: co-h2h-mine-324c342-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 19 | 214 | 257 | +0 | 135 | 132 | +3 | +1.4 |
| Mine | 50-54% | 2 | 336 | 288 | -88 | 32 | 88 | -55 | -16.5 |
| Mine | Effective (55-75%) | 17 | 256 | 207 | +154 | 197 | 45 | +151 | +59.2 |
| Mine | 76-89% | 17 | 269 | 206 | +118 | 143 | 50 | +92 | +34.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 268 | 182 | +117 | 141 | 20 | +120 | +45.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 445 | 97 | +78 | 89 | 36 | +53 | +11.9 |
| Mine | No odds | 7 | 216 | 168 | -7 | 13 | 20 | -7 | -3.2 |
| Mine | All fights | 91 | 277 | 196 | +80 | 131 | 58 | +73 | +26.4 |
| Opponent | Long shot (under 50%) | 24 | 214 | 264 | +42 | 142 | 126 | +16 | +7.4 |
| Opponent | 50-54% | 3 | 234 | 248 | +183 | 216 | 0 | +216 | +92.0 |
| Opponent | Effective (55-75%) | 18 | 265 | 213 | +82 | 113 | 57 | +57 | +21.5 |
| Opponent | 76-89% | 18 | 215 | 166 | +121 | 134 | 2 | +131 | +60.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 275 | 180 | +177 | 223 | 51 | +173 | +62.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 382 | 102 | +66 | 85 | 20 | +65 | +17.2 |
| Opponent | No odds | 19 | 195 | 171 | +38 | 79 | 55 | +25 | +12.6 |
| Opponent | All fights | 117 | 241 | 198 | +100 | 148 | 58 | +90 | +37.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-h2h-mine-324c342-p1 | move | 438 | 88 (20%) | 53 (12%) | 77 (18%) | 273 (62%) |
| co-h2h-mine-324c342-p1 | objective | 358 | 55 (15%) | 33 (9%) | 60 (17%) | 243 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: co-h2h-opp-324c342-p2

### Scorecard: co-h2h-opp-324c342-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 2 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 821 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 593 |
| L0528 | 6 | 1 | Opponent | no | 9 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 2 | 6 | 0 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 20 | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 1 | 0 | 0 | 881 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 16 | 2 | 5 | 2 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 619 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 456 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 0 | 0 | 0 | 459 |
| L1135 | 1 | 1 | Mine | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 7 | 4 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 1 | 1 | 0 | 0 | 539 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 2 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 292 |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 4 | 2 | 1 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 9 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 6 | 3 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 20% | 1.5 | 2.7 | 2.5 | 1.1 | 0.2 | 0.0 | 0.0 | 299.3 |
| **Average** | | | Opponent | 23% | 3.7 | 2.2 | 3.1 | 1.7 | 0.5 | 0.0 | 0.0 | 183.0 |

### KPIs: co-h2h-opp-324c342-p2

Rules off - Mine only: JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (50 of 180) | 14% (24 of 176) | 21% (74 of 356) |
| Winner chose to follow up after the loser gave ground |  | 94% (65 of 69); on the table 94% | 97% (64 of 66); on the table 97% | 96% (129 of 135); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (11 of 11); on the table 100% | 73% (16 of 22); on the table 86% | 82% (27 of 33); on the table 91% |
| Winner chose to pursue after the loser fled |  | 72% (28 of 39); on the table 72% | 73% (27 of 37); on the table 81% | 72% (55 of 76); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 87% (104 of 119); on the table 87% | 86% (107 of 125); on the table 90% | 86% (211 of 244); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 35% (118 of 342) | 31% (49 of 156) | 34% (167 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (118 of 243) | 44% (49 of 111) | 47% (167 of 354) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (14 of 21) | 62% (30 of 48) | 64% (44 of 69) |
| Points that never fought | lower | 34% (24185 of 71583) | 37% (26466 of 71989) | 35% (50651 of 143572) |
|   infantry points that never fought | lower | 43% (7078 of 16324) | 59% (8323 of 14029) | 51% (15401 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (175 of 284) | 57% (169 of 297) | 59% (344 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 78% (14 of 18); 1.2 uses a game | 84% (32 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 72% (13 of 18); 0.7 uses a game | 50% (1 of 2); 0.1 uses a game | 70% (14 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33658 of 60231) | 50% (31514 of 63281) | 53% (65172 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (28%) | 1.0 (33%) | 2.7 (29%) |
| MARCHED: its unit marched | 1.3 (21%) | 0.4 (12%) | 1.7 (18%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.6 (21%) | 2.2 (24%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.7 (11%) | 0.5 (17%) | 1.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 1.3 | 4.6 | 0.4 | 2.3 |
| not cast | 3.9 | 3.2 | 3.7 | 9.2 | 2.0 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.9 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (52%) | 0.3 (8%) | 2.7 (29%) | 0.5 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.6 (19%) | 0.6 (15%) | 2.2 (24%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (13%) | 0.3 (9%) | 0.4 (11%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.4 (10%) | 0.1 (2%) | 0.2 (5%) | 0.2 (2%) | 0.0 (1%) | 0.5 (2%) |
| GONE: slain | 0.6 (17%) | 0.3 (9%) | 0.6 (15%) | 1.2 (13%) | 0.3 (15%) | 3.0 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (3%) | 0.1 (3%) | 0.3 (4%) | 0.0 (1%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.4 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (49%) | 0.1 (4%) | 1.6 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.4 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 48% (12 of 25) | 52% (13 of 25) | 50% (25 of 50) |
| the unit moved after it | 67% (8 of 12) | 54% (7 of 13) | 60% (15 of 25) |
| it charged on its next turn | 8% (1 of 12) | 8% (1 of 13) | 8% (2 of 25) |
| the enemy charged it first | 0% (0 of 12) | 23% (3 of 13) | 12% (3 of 25) |
| it fought by the end of its next turn | 0% (0 of 12) | 23% (3 of 13) | 12% (3 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (3 of 12) | 8% (1 of 13) | 16% (4 of 25) |
| none of these (no charge, no fight, no charge escaped) | 67% (8 of 12) | 62% (8 of 13) | 64% (16 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (555 of 877) | 52% (418 of 799) | 58% (973 of 1676) |
|   cavalry | 59% (47 of 80) | 60% (105 of 174) | 60% (152 of 254) |
|   character | 50% (54 of 109) | 24% (27 of 114) | 36% (81 of 223) |
|   chariot | 50% (50 of 101) | 66% (27 of 41) | 54% (77 of 142) |
|   infantry | 55% (143 of 259) | 50% (154 of 311) | 52% (297 of 570) |
|   monster | 45% (22 of 49) | 44% (16 of 36) | 45% (38 of 85) |
|   war machine | 86% (239 of 279) | 72% (89 of 123) | 82% (328 of 402) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (27%) | 2.3 (22%) | 4.7 (24%) |
| CHARGED: it charged | 1.5 (17%) | 2.1 (20%) | 3.6 (18%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.7 (7%) | 1.8 (9%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.5 (17%) | 2.0 (19%) | 3.5 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.5 (5%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (14%) | 2.1 (20%) | 3.4 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.6 (5%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.6 | 1.5 | 82% | 4.1 pts | 27 pts |
| character | 2.6 | 0.6 | 82% | 7.3 pts | 19 pts |
| chariot | 2.2 | 1.1 | 71% | 12.7 pts | 28 pts |
| infantry | 11.1 | 4.7 | 70% | 10.5 pts | 117 pts |
| monster | 1.3 | 0.2 | 85% | 3.4 pts | 4 pts |
| war machine | 9.1 | 7.0 | 64% | 20.9 pts | 191 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 6.6 | 5.6 |
| Charges that made contact a game | 3.5 | 4.9 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.69 declared, 0.58 contact (26 units) | 0.77 declared, 0.62 contact (13 units) | 0.72 declared, 0.59 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.57 contact (7 units) | 1.69 declared, 1.54 contact (13 units) | 1.30 declared, 1.20 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.58 declared, 0.43 contact (247 units) | 0.71 declared, 0.51 contact (288 units) | 0.65 declared, 0.47 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (46 of 73) | 61% (11 of 18) | 42% (5 of 12) | 60% (62 of 103) |
| Character in a unit | 97% (28 of 29) | 79% (15 of 19) | 50% (2 of 4) | 87% (45 of 52) |
| Character on its own | 67% (29 of 43) | 49% (17 of 35) | 23% (14 of 62) | 43% (60 of 140) |
| Chariot | 88% (15 of 17) | 77% (10 of 13) | - | 83% (25 of 30) |
| Infantry | 50% (47 of 94) | 53% (18 of 34) | 33% (1 of 3) | 50% (66 of 131) |
| Monster | 55% (16 of 29) | 89% (8 of 9) | - | 63% (24 of 38) |
| Monstrous | 43% (6 of 14) | 64% (9 of 14) | - | 54% (15 of 28) |
| War Machines | 79% (45 of 57) | 100% (2 of 2) | - | 80% (47 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (17 of 18); on the table 94% | 27% (28 of 102) | 62% | 77% (17 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 39% (14 of 36) | 49% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 80% (8 of 10); on the table 80% | - | 52% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 74% (17 of 23); on the table 74% | 42% (20 of 48) | 44% | 63% (48 of 76) | 0.0 uses a game | 100% (2 of 2); 0.9 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 93% (26 of 28); on the table 96% | 35% (48 of 138) | 37% | 43% (23 of 54) | 86% (12 of 14); 6.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 83% (10 of 12); on the table 83% | 22% (4 of 18) | 11% | 52% (17 of 33) | 100% (3 of 3); 2.2 uses a game | 64% (9 of 14); 4.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 46% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (9 of 9); on the table 100% | - | 26% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (9 of 9); on the table 100% | 0% (0 of 18) | 25% | 82% (23 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 83% (10 of 12); on the table 83% | 44% (8 of 18) | 31% | 72% (18 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 88% (14 of 16); on the table 88% | - | 35% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 79% (30 of 38); on the table 89% | 35% (23 of 66) | 23% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 81% (22 of 27); on the table 85% | 56% (10 of 18) | 28% | 47% (34 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 90% (26 of 29); on the table 90% | 42% (10 of 24) | 38% | 63% (49 of 78) | 57% (4 of 7); 2.4 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-h2h-opp-324c342-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (57) | 55% (40) | 54% (97) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.67 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.36 | 0.22 | 0.58 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.39 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.03 | 1.69 | 3.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 1.22 | 2.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.78 | 4.61 | 10.39 |

### Quality by phase: co-h2h-opp-324c342-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 56% (75 of 134) | 50% (114 of 230) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (144 of 336) | 48% (110 of 231) |
| Strategy | Close-in objectives charged next turn | 12% (15 of 130) | 18% (45 of 247) |
| Strategy | Support requests answered (helper made contact too) | 72% (13 of 18) | 45% (14 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 72% (13 of 18) |
| Strategy | Joined characters whose unit fought | 38% (19 of 50) | 39% (14 of 36) |
| Strategy | Lone characters that fought | 81% (77 of 95) | 84% (73 of 87) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 299.3 | 183.0 |
| Movement | Fights charged into per game | 3.0 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 94, net -37 | 27 of 133, net +164 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 94, net +138 | 28 of 133, net +34 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 94, net +90 | 11 of 133, net +93 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 94, net +131 | 24 of 133, net +94 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.5 | 9.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (142 of 343) | 45% (160 of 357) |
| Shooting | Points destroyed by shooting units | 125.6 | 28.3 |
| Shooting | War machine shots | 6.6 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (120 of 239) | 49% (44 of 89) |
| Shooting | Points destroyed by war machines | 47.7 | 27.0 |
| Magic | Magic missiles cast | 2.1 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (21 of 75) | 52% (16 of 31) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.1 |
| Magic | Wounds caused by other spells | 1.7 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 62.9 | 44.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.8 / 0.1 | 1.9 / 0.5 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 332.1 | 397.4 |
| Combat | Points run down | 81.5 | 95.7 |
| Combat | Net points per charged fight, damage counted | +76 | +91 |
| Combat | Net per 100 charger points, damage counted | +28.0 | +33.1 |
| Combat | First round won (charged fights) | 69% | 68% |
| Combat | Net points per charged fight | +74 | +87 |
| Combat | Net points per supported fight / lone fight | +96 / +69 | +102 / +85 |
| Combat | Charged fights on a top-3 enemy unit | 40 of 108 | 57 of 150 |
| Game | Points lost | 753.8 | 725.8 |
| Game | VP from objectives | 536.7 | 685.3 |
| Game | Lone holders (player turns) | 1.5 | 3.7 |

- Mine won / drew / lost: 11 / 6 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -194 VP
- The side that went first won 14 of 30 games with a winner
- Points traded per game (both sides' losses): 1480
- Games not ended: 0; findings 0, warnings 2

### Opponent rules: co-h2h-opp-324c342-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +5.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 30.7 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.0 | +6.9 | 0.0 | 13.2 | 0.8 | +6.7 | 0.0 | 19.4 |
| BEST FACING | 0.7 | +23.6 | 0.0 | 19.0 | 0.8 | +27.2 | 0.0 | 64.3 |
| BEST FIRST | 5.2 | +209.1 | 214.1 | 89.8 | 3.5 | +138.9 | 104.1 | 105.5 |
| BEST OVERALL | 0.7 | +51.5 | 0.0 | 25.5 | 0.7 | +49.6 | 0.0 | 34.5 |
| BEST PREY | 0.6 | +28.0 | 22.8 | 2.4 | 0.9 | +36.6 | 23.2 | 8.9 |
| BEST PRIZE | 0.0 | -0.6 | 0.0 | 6.3 | 0.1 | -0.4 | 16.9 | 7.7 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.5 | 5.2 | 0.1 | +0.0 | 12.1 | 9.6 |
| BLOCKED WHEEL | 0.4 | +3.5 | 0.0 | 3.6 | 0.4 | +3.8 | 0.0 | 24.3 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -30.4 | 36.3 | 7.1 |
| BOMBING RUN | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 224.2 | 2.8 | 0.2 | +0.0 | 6.1 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +175.0 | 360.0 | 88.3 | 2.1 | +70.5 | 60.7 | 13.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 16.6 | 23.2 | 0.1 | -0.5 | 13.9 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -0.2 | 23.6 | 1.4 |
| CAST JOB | 0.5 | +11.9 | 21.2 | 4.7 | 0.3 | +3.9 | 34.4 | 17.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +24.1 | 10.8 | 6.1 | 0.1 | +8.1 | 19.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 11.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 5.1 | 0.0 | 0.2 | +0.0 | 0.0 | 5.5 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.7 | +0.0 | 271.8 | 90.6 | 3.7 | +0.0 | 313.4 | 117.0 |
| CHARGE NOW WEIGHED | 0.6 | -36.8 | 10.2 | 3.9 | 0.4 | -45.3 | 12.8 | 28.4 |
| CHARGER SLAIN LOST | - | - | - | - | 0.9 | -22.9 | 78.4 | 26.1 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 14.8 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 16.1 | 48.5 | 0.5 | +0.0 | 35.1 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +51.0 | 0.0 | 0.0 | 0.6 | +69.3 | 21.6 | 26.5 |
| COUNTER-CHARGE COVER | 9.9 | +871.0 | 0.0 | 144.4 | 6.6 | +592.2 | 0.0 | 181.5 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 24.1 | 16.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.7 | 7.1 | 15.0 | 0.4 | +12.0 | 53.9 | 15.5 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +167.4 | 0.0 | 78.8 | 1.7 | +92.5 | 0.0 | 101.7 |
| FALLBACK BY WORTH | 5.0 | +74.0 | 0.0 | 55.8 | 5.4 | +58.4 | 0.0 | 34.8 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 110.2 | 4.5 | +0.0 | 0.0 | 163.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +133.9 | 0.0 | 43.8 | 1.1 | +144.1 | 0.0 | 46.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +21.9 | 0.0 | 0.0 | 0.2 | +18.1 | 0.0 | 1.1 |
| GIVES UP | 0.1 | -0.4 | 0.0 | 2.6 | 0.2 | -2.0 | 14.1 | 12.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 16.0 | 1.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 70.2 | 15.9 | 0.4 | +0.0 | 25.4 | 4.1 |
| HILL BY ITS CHANCE | 0.4 | -30.8 | 0.0 | 3.4 | 0.5 | -44.4 | 0.0 | 6.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +1.7 | 38.1 | 1.9 | 0.2 | +1.4 | 0.0 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 7.6 | 4.4 | 0.2 | +0.0 | 0.0 | 5.0 |
| HUNT IN PAIRS | 0.2 | +5.1 | 0.0 | 5.7 | 0.4 | +26.7 | 0.0 | 10.8 |
| HUNT KEPT | 0.2 | +0.9 | 20.6 | 8.3 | 0.1 | +2.4 | 9.2 | 0.0 |
| HUNT RESULT | 0.2 | +15.2 | 23.6 | 5.3 | 0.3 | +37.6 | 0.0 | 5.9 |
| HUNT THE GUNS | 0.2 | +74.8 | 22.8 | 0.0 | 0.4 | +120.6 | 13.8 | 2.9 |
| INVITES THE FIGHT | 1.5 | +26.9 | 67.8 | 18.3 | 1.1 | +17.7 | 45.2 | 36.9 |
| JOINT CHARGE PLAN | 0.0 | +0.1 | 0.0 | 0.0 | 0.2 | +5.4 | 0.0 | 2.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -8.0 | 0.0 | 1.8 |
| KEEP FALLS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.9 | 3.3 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.1 | +34.2 | 105.6 | 46.0 | 2.7 | +81.7 | 217.5 | 81.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.5 | +79.5 | 137.6 | 84.9 | 2.7 | +125.0 | 193.5 | 91.6 |
| KILLS COUNT NEXT TURN | 4.6 | +156.0 | 157.8 | 79.0 | 7.0 | +240.5 | 248.7 | 92.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +19.1 | 3.7 | 0.0 | 0.3 | +2.6 | 0.0 | 4.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 8.1 | 23.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +0.4 | 24.6 | 17.1 | 0.7 | +2.1 | 32.1 | 4.7 |
| LOST CHARGE | 3.2 | -49.8 | 84.6 | 22.5 | 2.4 | -41.4 | 85.8 | 98.4 |
| LURE BY WHAT IT DRAWS | 0.1 | -4.2 | 0.0 | 3.1 | 0.1 | -4.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +13.7 | 0.0 | 2.9 | 0.5 | +18.6 | 3.2 | 1.2 |
| MANOEUVRE | 0.2 | +12.7 | 0.0 | 14.7 | 0.2 | +10.6 | 0.0 | 3.8 |
| MARCH CHECK | 0.6 | +12.9 | 0.0 | 12.1 | 0.4 | +15.5 | 0.0 | 12.9 |
| MARCH ODDS | 0.3 | +30.3 | 3.1 | 4.6 | 0.3 | +19.9 | 11.0 | 20.3 |
| MARCH OVER CASTS | 0.6 | +56.9 | 0.0 | 12.1 | 0.2 | +11.4 | 0.0 | 19.7 |
| MAX FOR POSITIONING | 4.7 | +159.2 | 0.0 | 49.8 | 4.3 | +160.4 | 0.0 | 93.0 |
| MISSILES IN THE MOVE | 4.2 | +99.6 | 0.0 | 91.3 | 3.0 | +61.8 | 0.0 | 112.1 |
| MISSILES NEXT TURN | 4.6 | +67.6 | 0.0 | 101.8 | 3.4 | +50.1 | 0.0 | 121.2 |
| MODEL FACING | 0.2 | +52.2 | 0.0 | 0.0 | 0.4 | +107.7 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 24.1 | 10.5 |
| MOVE AND CAST | 0.2 | +14.3 | 0.0 | 9.2 | 0.3 | +29.7 | 0.0 | 9.8 |
| MOVE SPELL IN RANGE | 0.1 | +4.5 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 15.2 |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -18.5 | 0.0 | 9.9 | 0.1 | -2.8 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 2.7 | +129.0 | 89.8 | 37.0 | 5.3 | +315.7 | 196.2 | 121.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.2 | 1.4 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.7 | 0.0 | 2.4 | - | - | - | - |
| NOT NEEDED | 0.1 | -3.6 | 15.9 | 0.0 | 0.5 | -21.2 | 46.5 | 3.6 |
| NOT TURNED | 5.8 | +94.8 | 0.0 | 92.7 | 4.6 | +82.0 | 0.0 | 106.4 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 48.4 | 0.6 | -0.5 | 0.0 | 1.7 |
| OFF BEST | 15.7 | -760.6 | 0.0 | 232.0 | 16.6 | -898.1 | 4.4 | 289.7 |
| OPENS UP | 0.1 | +19.1 | 10.0 | 0.0 | 0.3 | +16.0 | 15.7 | 18.3 |
| OVERRUNS AWAY | 0.6 | +11.1 | 57.5 | 7.8 | 0.6 | +10.0 | 29.2 | 29.9 |
| PATHS CROSS | 2.3 | +151.4 | 0.0 | 15.8 | 2.6 | +154.2 | 0.0 | 78.5 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -6.3 | 0.0 | 12.7 | 0.1 | -0.5 | 0.0 | 5.1 |
| PLAN RESULT | 36.8 | +1573.7 | 1580.4 | 972.0 | 41.3 | +1244.2 | 1346.8 | 896.8 |
| PURSUES BIG PREY | 0.2 | -14.1 | 0.0 | 0.0 | 0.1 | -5.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +24.9 | 0.0 | 18.6 | 1.3 | +25.5 | 0.0 | 21.5 |
| RANDOM MOVER NO PROMISE | 0.2 | -20.2 | 0.0 | 10.6 | 0.2 | -15.6 | 19.9 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -6.6 | 0.0 | 3.1 | 0.2 | -6.3 | 0.0 | 2.2 |
| REDIRECT COUNTER | 2.0 | +129.8 | 0.0 | 46.9 | 3.4 | +283.6 | 0.0 | 51.9 |
| REDIRECT WEIGHED | 0.2 | +5.5 | 7.3 | 0.0 | 0.6 | +15.8 | 29.1 | 25.2 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +9.9 | 0.0 | 0.0 | 1.3 | +43.2 | 0.0 | 28.9 |
| RESTRAINS TO SHOOT | 0.1 | +5.0 | 0.0 | 6.5 | 0.1 | +3.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +81.4 | 219.0 | 79.1 | 4.0 | +107.2 | 308.4 | 117.2 |
| SAFER THAN THE JOB | 1.1 | +65.8 | 0.0 | 26.6 | 1.2 | +79.9 | 0.0 | 42.8 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -6.7 | 0.0 | 1.2 | 0.3 | -21.7 | 0.0 | 1.2 |
| SEARCH SPOT | 2.6 | +132.4 | 0.0 | 36.2 | 2.3 | +109.6 | 0.0 | 17.5 |
| SECOND HUNTER | 0.1 | -0.7 | 22.8 | 0.9 | 0.1 | -0.4 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.1 | +7.0 | 0.0 | 20.0 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +25.6 | 0.0 | 9.8 | 2.2 | +134.0 | 48.7 | 42.8 |
| SET-UP ANY TARGET | 0.2 | +19.4 | 0.0 | 0.0 | 0.3 | +40.1 | 0.0 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +8.6 | 0.0 | 11.2 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +38.6 | 73.9 | 14.6 | 0.9 | +33.7 | 46.9 | 18.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 214.6 | 9.3 | 0.3 | +0.0 | 19.9 | 5.2 |
| SHOTS IN THE MOVE | 13.7 | +609.2 | 0.0 | 203.2 | 10.9 | +349.8 | 0.0 | 184.5 |
| SPELL CATCH ODDS | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +56.3 | 0.0 | 0.0 | 0.3 | +40.1 | 0.0 | 7.6 |
| SPELL WORTH | 0.8 | +19.3 | 84.4 | 79.0 | 1.7 | +32.5 | 64.9 | 64.9 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.8 | -9.8 | 58.0 | 22.4 |
| STABLE ROLE | 11.0 | +0.0 | 405.9 | 149.1 | 12.2 | +0.0 | 357.9 | 213.4 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.9 | 0.0 | 3.2 | 0.2 | +13.6 | 22.9 | 2.9 |
| STOPS SHORT OF THE FLANK | 0.6 | +32.5 | 0.0 | 2.4 | 0.3 | +27.1 | 0.0 | 20.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.2 | -42.9 | 458.2 | 143.2 | 7.6 | -51.7 | 422.9 | 163.3 |
| SUPPORTS | 4.0 | +42.9 | 273.1 | 72.1 | 4.4 | +53.2 | 203.7 | 73.7 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -8.8 | 16.2 | 0.0 | 0.1 | -3.8 | 17.4 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +2.9 | 0.0 | 3.1 | 1.1 | +8.1 | 6.5 | 28.3 |
| THROUGH LINE OF FIRE | 0.2 | +7.9 | 0.0 | 0.0 | 0.3 | +7.8 | 0.0 | 1.9 |
| TURN WORTH | 0.5 | -37.3 | 34.5 | 16.6 | 0.2 | -8.6 | 19.4 | 15.8 |
| TWO OR MORE ARRIVE | 0.1 | +0.9 | 0.0 | 1.4 | 0.3 | +1.9 | 0.0 | 7.8 |
| WAIT AFTER COSTS | 5.9 | -228.3 | 204.2 | 66.1 | 9.0 | -383.7 | 333.9 | 193.2 |
| WALKS TO THE FIGHT | 1.7 | +30.1 | 39.8 | 4.6 | 1.7 | +35.6 | 63.4 | 29.6 |
| WAR ENGINE CHARGES | 0.2 | +18.7 | 5.4 | 0.0 | 0.0 | +3.0 | 0.0 | 5.1 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 23.1 | 14.4 | 0.2 | +0.0 | 5.1 | 15.4 |
| WEARS DOWN | 1.2 | +54.7 | 104.6 | 34.7 | 1.8 | +59.5 | 163.1 | 49.7 |
| WHO HITS BACK | 0.3 | +24.1 | 0.0 | 0.0 | 0.3 | +21.5 | 0.0 | 18.9 |
| WHOLE FIGHT | 0.4 | +18.3 | 46.1 | 5.7 | 0.8 | +25.4 | 91.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +46.2 | 34.4 | 19.6 | 0.9 | +70.5 | 86.3 | 24.8 |
| WIDER SPREAD | - | - | - | - | 4.4 | -9.7 | 376.1 | 86.7 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 5.7 | 0.0 | 0.0 | +0.0 | 4.5 | 0.0 |

### Rule changes: co-h2h-opp-324c342-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1164 | 1164 | 1164 | 32.33 | -59708 | -51.3 |
| BEST FIRST | 313 | 313 | 313 | 8.69 | +12529 | +40.0 |
| PATHS CROSS | 175 | 175 | 175 | 4.86 | +11000 | +62.9 |
| SEARCH SPOT | 176 | 176 | 174 | 4.83 | +8764 | +50.4 |
| COUNTER-CHARGE COVER | 595 | 334 | 148 | 4.11 | +9286 | +62.7 |
| MOVE TO CHARGE | 288 | 287 | 140 | 3.89 | +4995 | +35.7 |
| FACES THE THREAT | 134 | 134 | 134 | 3.72 | +9357 | +69.8 |
| KILLS COUNT NEXT TURN | 418 | 417 | 118 | 3.28 | +3258 | +27.6 |
| SUPPORTS | 304 | 304 | 118 | 3.28 | +1140 | +9.7 |
| SAFER THAN THE JOB | 85 | 85 | 85 | 2.36 | +5245 | +61.7 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +10009 | +133.5 |
| WAIT AFTER COSTS | 536 | 535 | 75 | 2.08 | +1053 | +14.0 |
| FALLBACK BY WORTH | 377 | 377 | 74 | 2.06 | +4764 | +64.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| WALKS TO THE FIGHT | 121 | 121 | 66 | 1.83 | +779 | +11.8 |
| SHOTS IN THE MOVE | 887 | 563 | 65 | 1.81 | +1900 | +29.2 |
| RESERVE FALL BACK | 56 | 56 | 56 | 1.56 | +1910 | +34.1 |
| BEST FACING | 53 | 53 | 53 | 1.47 | +1828 | +34.5 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| BEST OVERALL | 50 | 50 | 50 | 1.39 | +3639 | +72.8 |
| MAX FOR POSITIONING | 325 | 200 | 49 | 1.36 | +465 | +9.5 |
| CANNON PLANNED TARGET | 246 | 246 | 47 | 1.31 | -586 | -12.5 |
| REDIRECT COUNTER | 193 | 101 | 47 | 1.31 | +3685 | +78.4 |
| RANDOM MOVE BY FIGURES | 69 | 69 | 44 | 1.22 | +1816 | +41.3 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SET UP TOGETHER | 97 | 85 | 42 | 1.17 | +2549 | +60.7 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MISSILES IN THE MOVE | 257 | 145 | 36 | 1.00 | +658 | +18.3 |
| RISK BY ARC | 227 | 219 | 36 | 1.00 | +1078 | +29.9 |
| CHARGE NOW FIRST | 228 | 228 | 35 | 0.97 | -1766 | -50.4 |
| KILLS COUNT | 152 | 151 | 35 | 0.97 | +1497 | +42.8 |
| CHARGE NOW WEIGHED | 34 | 34 | 34 | 0.94 | +2286 | +67.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SHOOTS FROM THE BEST SPOT | 69 | 69 | 33 | 0.92 | +1300 | +39.4 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +2147 | +69.3 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +263 | +9.1 |
| REDIRECT WEIGHED | 29 | 29 | 29 | 0.81 | +1541 | +53.1 |
| MARCH CHECK | 33 | 33 | 28 | 0.78 | +828 | +29.6 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| MODEL FACING | 22 | 22 | 22 | 0.61 | +5759 | +261.8 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1098 | +49.9 |
| WHOLE FIGHT GAIN | 46 | 42 | 22 | 0.61 | +1420 | +64.6 |
| INVITES THE FIGHT | 93 | 93 | 21 | 0.58 | +317 | +15.1 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +406 | +19.3 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +1585 | +75.5 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1439 | +84.6 |
| KEEPS ITS TARGET | 139 | 136 | 17 | 0.47 | +293 | +17.3 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -14 | -0.8 |
| MANOEUVRE | 17 | 17 | 16 | 0.44 | +840 | +52.5 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +566 | +35.3 |
| BEST PREY | 53 | 53 | 15 | 0.42 | +495 | +33.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| LOST CHARGE | 202 | 201 | 15 | 0.42 | +512 | +34.1 |
| CAST JOB | 28 | 28 | 14 | 0.39 | +349 | +24.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 13 | 0.36 | +620 | +47.7 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -24 | -2.4 |
| MAKE SURE TOGETHER | 25 | 18 | 10 | 0.28 | +249 | +24.9 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -720 | -72.0 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -453 | -45.3 |
| WEARS DOWN | 108 | 105 | 10 | 0.28 | +271 | +27.1 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +320 | +35.5 |
| WAR ENGINE JOBS | 23 | 23 | 9 | 0.25 | -431 | -47.8 |
| OPENS UP | 16 | 16 | 7 | 0.19 | +478 | +68.3 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -243 | -34.7 |
| WHOLE FIGHT | 44 | 42 | 7 | 0.19 | +561 | +80.2 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -343 | -57.1 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.1 |
| HUNT IN PAIRS | 25 | 14 | 5 | 0.14 | +486 | +97.2 |
| OVERRUNS AWAY | 43 | 40 | 5 | 0.14 | +49 | +9.8 |
| BACKUP TARGETS | 65 | 37 | 4 | 0.11 | +2 | +0.5 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +75 | +18.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SUPPORT NARROWED | 497 | 497 | 4 | 0.11 | -68 | -17.1 |
| JOINT CHARGE PLAN | 7 | 7 | 3 | 0.08 | +127 | +42.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +153 | +51.0 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 3 | 0.08 | -76 | -25.4 |
| MISSILES NEXT TURN | 286 | 159 | 3 | 0.08 | +6 | +2.1 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +207 | +69.0 |
| SURE REACH TOGETHER | 60 | 38 | 3 | 0.08 | +48 | +16.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +41 | +20.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -72 | -36.2 |
| DEFENSIVE ARMY | 13 | 13 | 2 | 0.06 | -97 | -48.3 |
| EDGE GIVE GROUND | 20 | 19 | 2 | 0.06 | +65 | +32.5 |
| HILL BY ITS CHANCE | 32 | 32 | 2 | 0.06 | +54 | +27.2 |
| MOVE SPELL IN RANGE | 6 | 5 | 2 | 0.06 | +31 | +15.4 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +49 | +24.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +108 | +54.1 |
| STOPS | 12 | 12 | 2 | 0.06 | +84 | +42.1 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -390 | -194.8 |
| BLOWS WHERE AIMED | 11 | 10 | 1 | 0.03 | +125 | +124.7 |
| CARRIES OUT COUNTER | 7 | 7 | 1 | 0.03 | -17 | -16.7 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -6 | -6.0 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +16 | +16.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +13.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| LONG SHOT | 44 | 44 | 1 | 0.03 | +2 | +2.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -47 | -47.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +69 | +69.3 |
| WAR ENGINE CHARGES | 7 | 7 | 1 | 0.03 | +234 | +234.3 |
| WIDER SPREAD | 160 | 155 | 1 | 0.03 | +0 | +0.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 48 | 48 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 32 | 30 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 388 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 22 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 18 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 20 | trace | - | - | - | - |
| HUNT THE GUNS | 22 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 374 | 374 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| PLAN RESULT | 2811 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 14 | 14 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 90 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 28 | 26 | 0 | 0.00 | - | - |
| STABLE ROLE | 834 | 833 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: co-h2h-opp-324c342-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.56 | 14.78 | 53.8 |
| FALLBACK | gate | 0.92 | 0.78 | 38.4 |
| TURN GATE | gate | 0.75 | 0.53 | 36.8 |
| CHARGE NOW FIRST | rule | 0.47 | 0.50 | 50.4 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.17 | 43.5 |
| PATHS CROSS | rule | 0.14 | 0.14 | 10.6 |
| PURSUES BIG PREY | rule | 0.22 | 0.06 | 72.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.11 | 45.3 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.14 | 57.8 |
| WAR ENGINE JOBS | rule | 0.22 | 0.03 | 47.8 |
| AFTERMATH BAND | gate | 0.17 | 0.06 | 2.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | 0.03 | 40.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.17 | 46.3 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 34.7 |
| BEST PRIZE | rule | 0.03 | 0.14 | 57.1 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 2.4 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 19.8 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 16.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 29.2 |
| CHAFF PASSED | rule | 0.11 | - | 3.3 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 17.0 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 25.4 |
| NO REASON | gate | - | 0.08 | 2.3 |
| CATCH ODDS | rule | - | 0.06 | 36.2 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 48.3 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 16.0 |
| MARCH ODDS | rule | 0.03 | 0.03 | 2.9 |
| REDIRECT WEIGHED | rule | - | 0.06 | 31.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | - | 16.0 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 194.8 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 16.7 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 6.0 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.5 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.6 |
| MOVE AND CAST | rule | 0.03 | - | 60.2 |
| STANDS TO CAST | rule | - | 0.03 | 47.3 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 78.2 |

### Plans: co-h2h-opp-324c342-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.7 | 17% | 508 | 396 | 78% |
| Mine | charge | 3.4 | 55% | 366 | 322 | 88% |
| Mine | close in | 3.6 | 27% | 184 | 133 | 72% |
| Mine | hold | 4.3 | 26% | 293 | 0 | 0% |
| Mine | join | 0.6 | 96% | 25 | 0 | 0% |
| Mine | shoot | 7.9 | 64% | 243 | 723 | 297% |
| Mine | support | 4.2 | 88% | 24 | 0 | 0% |
| Opponent | advance | 13.2 | 17% | 342 | 327 | 96% |
| Opponent | charge | 5.8 | 51% | 593 | 465 | 78% |
| Opponent | close in | 6.8 | 30% | 430 | 135 | 31% |
| Opponent | hold | 4.7 | 43% | 350 | 0 | 0% |
| Opponent | join | 0.8 | 97% | 35 | 0 | 0% |
| Opponent | shoot | 5.1 | 62% | 175 | 317 | 181% |
| Opponent | support | 4.9 | 90% | 37 | 0 | 0% |

### Packages: hunt the guns, co-h2h-opp-324c342-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 9 | 0 | 11% | 22% | 0% | 3.0 | 299 | 61 | 22% | 31 |
| Opponent | 0.4 | 13 | 2 | 27% | 27% | 0% | 2.7 | 366 | 123 | 27% | 78 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 270 | 0 | 0% | 33 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 447 | 0 | 0% | 40 |
| Empire of Man | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 60 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 2.0 | 8 | 0 | 38% | 38% | 0% | 2.7 | 406 | 169 | 38% | 113 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 290 |
| Tomb Kings of Khemri | 1.6 | 8 | 1 | 0% | 29% | 0% | 3.0 | 248 | 78 | 29% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 331 | 0 | 0% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: co-h2h-opp-324c342-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 27% | 46% | 14% | 43% | 34% | 7% | 10% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 54% | 17% | 0% | 15% | 5% | 25% | 55% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 24% | 70% | 19% | 55% | 39% | 15% | 9% | 37% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 31% | 81% | 19% | 0% | 23% | 3% | 10% | 60% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-h2h-opp-324c342-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 20% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 33 | 79 (33) | 40 | 39 | 69 | 33% | 2.6 | 44 (18) | 216 (7) | 28 (8) | 106 (22) | 24 (11) |
| Mine | Character | 123 | 55 (123) | 54 | 1 | 35 | 21% | 2.5 | 79 (40) | 47 (54) | 11 (13) | 60 (55) | 56 (52) |
| Mine | Clean-up | 21 | 61 (21) | 31 | 30 | 42 | 38% | 2.9 | 66 (5) | 52 (13) | 87 (3) | 81 (13) | 39 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 27 (46) | 12 | 16 | 44 | 28% | 2.8 | 33 (22) | 25 (16) | 4 (8) | 38 (29) | 11 (17) |
| Mine | Fragile | 5 | 26 (5) | 26 | 0 | 60 | 0% | 1.6 | - | 44 (3) | 0 (2) | 26 (5) | - |
| Mine | Hammer | 57 | 38 (57) | 28 | 10 | 40 | 19% | 2.4 | 14 (18) | 50 (29) | 52 (10) | 43 (38) | 30 (19) |
| Mine | Holder | 28 | 58 (28) | 7 | 50 | 28 | 29% | 3.2 | 56 (8) | 80 (10) | 32 (10) | 69 (18) | 40 (10) |
| Mine | Shooter | 44 | 85 (44) | 39 | 46 | 56 | 2% | 1.5 | 97 (7) | 83 (30) | 86 (7) | 100 (26) | 65 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 39 (59) | 39 | 0 | 41 | 3% | 1.2 | 0 (10) | 44 (37) | 52 (12) | 0 (10) | 47 (49) |
| Mine | Wizard | 22 | 14 (22) | 14 | 0 | 45 | 14% | 2.4 | 0 (6) | 51 (7) | 0 (5) | 0 (5) | 20 (13) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 41 (76) | 19 | 22 | 43 | 37% | 2.5 | 39 (32) | 23 (19) | 61 (25) | 54 (54) | 8 (22) |
| Opponent | Character | 97 | 58 (97) | 58 | 0 | 41 | 22% | 2.4 | 75 (43) | 52 (40) | 17 (7) | 64 (62) | 59 (28) |
| Opponent | Clean-up | 19 | 40 (19) | 20 | 20 | 31 | 21% | 3.1 | 30 (9) | 55 (10) | - | 47 (14) | 21 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 37 (48) | 20 | 16 | 43 | 29% | 2.7 | 17 (22) | 38 (16) | 81 (10) | 45 (28) | 23 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 46 | 40% | 2.0 | - | 0 (4) | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Hammer | 70 | 29 (70) | 24 | 5 | 46 | 26% | 3.0 | 9 (17) | 28 (42) | 70 (11) | 26 (43) | 34 (27) |
| Opponent | Holder | 35 | 102 (35) | 10 | 91 | 17 | 43% | 3.0 | 130 (8) | 101 (22) | 79 (4) | 130 (22) | 55 (12) |
| Opponent | Shooter | 33 | 75 (33) | 8 | 67 | 25 | 6% | 1.8 | 32 (8) | 101 (19) | 42 (6) | 111 (22) | 21 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 24 | 39 (24) | 39 | 0 | 26 | 8% | 1.5 | 21 (6) | 40 (14) | 56 (4) | 85 (3) | 32 (21) |
| Opponent | Wizard | 26 | 23 (26) | 23 | 0 | 46 | 12% | 1.4 | 39 (10) | 15 (5) | 22 (7) | 49 (7) | 6 (15) |

### Charged fights: co-h2h-opp-324c342-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 100 | 233 | 2.0 | 1.2 | 116 | 15 | +102 | 2 of 8 | 7 of 8 | +60 | +116 |
| Mine | Chaos Dwarfs | 4 | 127 | 264 | 2.5 | 1.3 | 106 | 58 | +48 | 5 of 10 | 7 of 10 | +264 | -45 |
| Mine | Dwarfen Mountain Holds | 4 | 828 | 131 | 2.8 | 1.5 | 48 | 21 | +26 | 3 of 11 | 5 of 11 | +69 | -24 |
| Mine | Empire of Man | 5 | 477 | 127 | 1.4 | 1.0 | 91 | 56 | +35 | 4 of 7 | 4 of 7 | - | +35 |
| Mine | Grand Cathay | 4 | 207 | 492 | 3.8 | 1.1 | 131 | 28 | +103 | 5 of 15 | 10 of 15 | -205 | +125 |
| Mine | High Elf Realms | 4 | 160 | 624 | 5.0 | 1.1 | 125 | 20 | +104 | 8 of 20 | 16 of 20 | +117 | +103 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1569 | 7.0 | 1.0 | 224 | 11 | +213 | 2 of 7 | 6 of 7 | - | +213 |
| Mine | Lizardmen | 1 | 231 | 233 | 2.0 | 1.5 | 116 | 0 | +116 | 1 of 2 | 2 of 2 | +233 | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 62 | -62 | 1 of 2 | 0 of 2 | - | -62 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 4.0 | 1.2 | 59 | 0 | +59 | 1 of 4 | 3 of 4 | +45 | +63 |
| Mine | Skaven | 2 | 100 | 0 | 2.5 | 1.0 | 0 | 84 | -84 | 2 of 5 | 3 of 5 | - | -84 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 667 | 5.0 | 1.0 | 133 | 0 | +133 | 2 of 5 | 5 of 5 | - | +133 |
| Mine | Vampire Counts | 3 | 0 | 298 | 2.7 | 1.1 | 112 | 149 | -37 | 4 of 8 | 4 of 8 | +0 | -43 |
| Mine | Warriors of Chaos | 1 | 0 | 712 | 4.0 | 1.0 | 178 | 0 | +178 | 0 of 4 | 3 of 4 | - | +178 |
| **Mine** | all armies | 36 | 236 | 331 | 3.0 | 1.2 | 110 | 37 | +74 | 40 of 108 | 75 of 108 | +96 | +69 |
| Opponent | Dwarfen Mountain Holds | 2 | 205 | 42 | 3.0 | 1.0 | 14 | 0 | +14 | 0 of 6 | 3 of 6 | - | +14 |
| Opponent | Empire of Man | 2 | 225 | 88 | 2.5 | 1.2 | 35 | 76 | -41 | 2 of 5 | 3 of 5 | +91 | -74 |
| Opponent | Grand Cathay | 2 | 420 | 606 | 2.5 | 1.4 | 242 | 0 | +242 | 3 of 5 | 2 of 5 | +289 | +231 |
| Opponent | Kingdom of Bretonnia | 1 | 60 | 235 | 2.0 | 1.0 | 118 | 0 | +118 | 0 of 2 | 2 of 2 | - | +118 |
| Opponent | Ogre Kingdoms | 3 | 82 | 186 | 5.0 | 1.1 | 37 | 35 | +2 | 4 of 15 | 6 of 15 | +165 | -9 |
| Opponent | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 32 | -32 | 1 of 2 | 2 of 2 | - | -32 |
| Opponent | Tomb Kings of Khemri | 4 | 34 | 599 | 4.5 | 1.2 | 133 | 46 | +87 | 6 of 18 | 11 of 18 | +114 | +82 |
| Opponent | Vampire Counts | 6 | 39 | 611 | 5.0 | 1.3 | 122 | 55 | +67 | 15 of 30 | 22 of 29 | +8 | +84 |
| Opponent | Warriors of Chaos | 8 | 36 | 462 | 3.4 | 1.1 | 137 | 8 | +129 | 14 of 27 | 20 of 27 | +98 | +135 |
| Opponent | Wood Elf Realms | 7 | 132 | 692 | 5.7 | 1.1 | 121 | 3 | +118 | 12 of 40 | 31 of 40 | +168 | +109 |
| **Opponent** | all armies | 36 | 100 | 468 | 4.2 | 1.2 | 112 | 25 | +87 | 57 of 150 | 102 of 149 | +102 | +85 |

### Effective charges: co-h2h-opp-324c342-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 0 | 0 | 2 (net -32) | 2 (net +32) | 0 | 3 (net +102) | 1 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 10 | 3 (net +0) | 0 | 1 (net +195) | 2 (net -290) | 2 (net +344) | 2 (net +87) | 0 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 11 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 7 (net +75) | 2 | 0% (0 of 9) |
| Mine | Empire of Man | 7 | 1 (net +210) | 0 | 2 (net -195) | 1 (net +0) | 0 | 2 (net +214) | 1 | 33% (2 of 6) |
| Mine | Grand Cathay | 15 | 1 (net +0) | 0 | 3 (net +241) | 4 (net -3) | 2 (net +20) | 5 (net +159) | 0 | 20% (3 of 15) |
| Mine | High Elf Realms | 20 | 1 (net +0) | 2 (net +0) | 0 | 3 (net +77) | 4 (net +74) | 7 (net +220) | 3 | 0% (0 of 17) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 3 (net +430) | 0 | 1 (net +30) | 2 (net +0) | 1 | 50% (3 of 6) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +233) | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +45) | 0 | 1 (net +0) | 1 (net +190) | 1 | 33% (1 of 3) |
| Mine | Skaven | 5 | 2 (net -210) | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +274) | 2 (net +55) | 2 (net +142) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 8 | 2 (net -98) | 0 | 1 (net +0) | 2 (net +62) | 0 | 2 (net +0) | 1 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +304) | 2 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 1 (net +0) | 4 (net +21) | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | Empire of Man | 5 | 1 (net +0) | 0 | 2 (net -190) | 0 | 1 (net +91) | 1 (net +85) | 0 | 40% (2 of 5) |
| Opponent | Grand Cathay | 5 | 2 (net +454) | 0 | 0 | 2 (net +0) | 0 | 1 (net +304) | 0 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 1 (net +115) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 15 | 5 (net +59) | 0 | 3 (net -41) | 1 (net -185) | 0 | 2 (net +0) | 4 | 27% (3 of 11) |
| Opponent | Skaven | 2 | 0 | 0 | 2 (net -32) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Tomb Kings of Khemri | 18 | 3 (net +31) | 0 | 2 (net +181) | 5 (net +116) | 0 | 4 (net +40) | 4 | 14% (2 of 14) |
| Opponent | Vampire Counts | 30 | 5 (net +214) | 1 (net -186) | 8 (net +96) | 7 (net -118) | 4 (net +86) | 4 (net +119) | 1 | 28% (8 of 29) |
| Opponent | Warriors of Chaos | 27 | 2 (net +59) | 2 (net +125) | 5 (net +71) | 7 (net +114) | 3 (net +64) | 4 (net +215) | 4 | 22% (5 of 23) |
| Opponent | Wood Elf Realms | 40 | 8 (net +244) | 0 | 5 (net +9) | 13 (net +117) | 3 (net +134) | 8 (net +45) | 3 | 14% (5 of 37) |

### Charged fights, damage counted: co-h2h-opp-324c342-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 269 | 294 | -37 | 117 | 146 | -29 | -10.8 |
| Mine | 50-54% | 3 | 230 | 269 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 13 | 301 | 272 | +138 | 216 | 83 | +133 | +44.2 |
| Mine | 76-89% | 17 | 285 | 229 | +20 | 91 | 60 | +32 | +11.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 245 | 155 | +131 | 147 | 21 | +126 | +51.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 397 | 97 | +90 | 93 | 14 | +79 | +19.8 |
| Mine | No odds | 14 | 198 | 217 | +16 | 108 | 67 | +42 | +21.0 |
| Mine | All fights | 108 | 272 | 199 | +74 | 128 | 52 | +76 | +28.0 |
| Opponent | Long shot (under 50%) | 27 | 244 | 226 | +164 | 204 | 32 | +172 | +70.4 |
| Opponent | 50-54% | 4 | 291 | 272 | +45 | 91 | 46 | +45 | +15.4 |
| Opponent | Effective (55-75%) | 28 | 273 | 218 | +34 | 90 | 65 | +25 | +9.2 |
| Opponent | 76-89% | 39 | 268 | 178 | +51 | 124 | 65 | +59 | +22.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 276 | 173 | +94 | 111 | 21 | +91 | +32.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 558 | 131 | +93 | 93 | 5 | +88 | +15.8 |
| Opponent | No odds | 17 | 154 | 179 | +132 | 171 | 13 | +159 | +102.8 |
| Opponent | All fights | 150 | 275 | 193 | +87 | 132 | 41 | +91 | +33.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-h2h-opp-324c342-p2 | move | 431 | 100 (23%) | 80 (19%) | 64 (15%) | 267 (62%) |
| co-h2h-opp-324c342-p2 | objective | 377 | 60 (16%) | 42 (11%) | 61 (16%) | 256 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: co-h2h-mine-324c342-p2

### Scorecard: co-h2h-mine-324c342-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 55 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 4 | 3 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 11 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 713 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 1 | 5 | 0 | 0 | 0 | 118 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1127 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | yes | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 307 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 993 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 3 | - | 0 | 2 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 190 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 14 | 2 | 3 | 2 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 688 |
| L0934 | 4 | 1 | Opponent | yes | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 456 |
| L1026 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 5 | 0 | 0 | 0 | 0 | 40 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 2 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 617 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | 4 | 0 | 2 | 1 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 1 | 0 | 0 | 562 |
| L2235 | 3 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 4 | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 4 | 2 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 23% | 2.1 | 2.6 | 2.3 | 1.1 | 0.2 | 0.0 | 0.0 | 309.7 |
| **Average** | | | Opponent | 30% | 3.6 | 2.4 | 3.2 | 1.1 | 0.3 | 0.0 | 0.0 | 172.9 |

### KPIs: co-h2h-mine-324c342-p2

Rules off - Opponent only: JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 174) | 16% (28 of 177) | 22% (76 of 351) |
| Winner chose to follow up after the loser gave ground |  | 97% (69 of 71); on the table 97% | 96% (49 of 51); on the table 96% | 97% (118 of 122); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 93% (14 of 15); on the table 100% | 93% (25 of 27); on the table 96% |
| Winner chose to pursue after the loser fled |  | 75% (24 of 32); on the table 81% | 71% (22 of 31); on the table 71% | 73% (46 of 63); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 90% (104 of 115); on the table 92% | 88% (85 of 97); on the table 89% | 89% (189 of 212); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 30% (103 of 342) | 35% (54 of 156) | 32% (157 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (103 of 203) | 49% (54 of 111) | 50% (157 of 314) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 63% (22 of 35) | 62% (36 of 58) | 62% (58 of 93) |
| Points that never fought | lower | 33% (23691 of 71583) | 36% (26149 of 71989) | 35% (49840 of 143572) |
|   infantry points that never fought | lower | 43% (7057 of 16324) | 50% (6971 of 14029) | 46% (14028 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (159 of 284) | 55% (162 of 297) | 55% (321 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.6 uses a game | 83% (15 of 18); 1.3 uses a game | 89% (34 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 0.6 uses a game | 50% (1 of 2); 0.0 uses a game | 60% (12 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (31463 of 60231) | 50% (31590 of 63281) | 51% (63053 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (19%) | 0.6 (22%) | 1.9 (20%) |
| MARCHED: its unit marched | 1.0 (15%) | 0.5 (17%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.7 (26%) | 0.6 (23%) | 2.3 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 1.5 (23%) | 0.5 (18%) | 2.0 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (8%) | 0.1 (3%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.1 (2%) | 0.2 (3%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (9%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 2.0 | 1.2 | 4.4 | 0.4 | 2.2 |
| not cast | 3.7 | 2.9 | 3.8 | 9.5 | 1.9 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.4 (48%) | 0.4 (9%) | 1.9 (20%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (5%) | 0.4 (11%) | 2.3 (25%) | 0.5 (28%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.4 (12%) | 0.2 (7%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 1.0 (28%) | 0.5 (17%) | 0.9 (23%) | 2.0 (21%) | 0.2 (12%) | 3.0 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.2 (7%) | 0.2 (7%) | 0.6 (6%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.1 (1%) | 0.2 (3%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (51%) | 0.1 (4%) | 1.6 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 56% (9 of 16) | 60% (15 of 25) | 59% (24 of 41) |
| the unit moved after it | 100% (9 of 9) | 40% (6 of 15) | 62% (15 of 24) |
| it charged on its next turn | 0% (0 of 9) | 27% (4 of 15) | 17% (4 of 24) |
| the enemy charged it first | 44% (4 of 9) | 7% (1 of 15) | 21% (5 of 24) |
| it fought by the end of its next turn | 11% (1 of 9) | 0% (0 of 15) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 9) | 7% (1 of 15) | 4% (1 of 24) |
| none of these (no charge, no fight, no charge escaped) | 56% (5 of 9) | 60% (9 of 15) | 58% (14 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (535 of 874) | 55% (435 of 786) | 58% (970 of 1660) |
|   cavalry | 56% (45 of 80) | 62% (106 of 171) | 60% (151 of 251) |
|   character | 46% (52 of 112) | 24% (24 of 100) | 36% (76 of 212) |
|   chariot | 57% (63 of 111) | 67% (34 of 51) | 60% (97 of 162) |
|   infantry | 50% (124 of 250) | 53% (154 of 290) | 51% (278 of 540) |
|   monster | 52% (23 of 44) | 49% (22 of 45) | 51% (45 of 89) |
|   war machine | 82% (228 of 277) | 74% (95 of 129) | 80% (323 of 406) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (25%) | 2.2 (23%) | 4.6 (24%) |
| CHARGED: it charged | 1.3 (14%) | 1.9 (20%) | 3.2 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (9%) | 0.8 (8%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 1.5 (16%) | 1.7 (17%) | 3.2 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.9 (10%) | 0.6 (6%) | 1.5 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (17%) | 1.5 (15%) | 3.1 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.5 (5%) | 0.8 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.4 (5%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.6 | 1.7 | 82% | 4.6 pts | 30 pts |
| character | 2.3 | 1.0 | 73% | 12.0 pts | 28 pts |
| chariot | 2.7 | 2.0 | 66% | 14.2 pts | 39 pts |
| infantry | 10.7 | 3.6 | 76% | 8.4 pts | 90 pts |
| monster | 1.4 | 0.1 | 94% | 0.8 pts | 1 pts |
| war machine | 9.0 | 7.0 | 63% | 25.2 pts | 226 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 6.3 | 5.5 |
| Charges that made contact a game | 3.3 | 4.4 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.96 declared, 0.69 contact (26 units) | 1.23 declared, 0.85 contact (13 units) | 1.05 declared, 0.74 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.86 declared, 0.71 contact (7 units) | 1.38 declared, 0.92 contact (13 units) | 1.20 declared, 0.85 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.39 contact (245 units) | 0.66 declared, 0.46 contact (294 units) | 0.61 declared, 0.43 contact (539 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (35 of 73) | 56% (10 of 18) | 50% (6 of 12) | 50% (51 of 103) |
| Character in a unit | 76% (25 of 33) | 68% (13 of 19) | 75% (3 of 4) | 73% (41 of 56) |
| Character on its own | 85% (33 of 39) | 46% (16 of 35) | 31% (19 of 62) | 50% (68 of 136) |
| Chariot | 59% (10 of 17) | 77% (10 of 13) | - | 67% (20 of 30) |
| Infantry | 53% (50 of 94) | 47% (16 of 34) | 0% (0 of 3) | 50% (66 of 131) |
| Monster | 52% (15 of 29) | 56% (5 of 9) | - | 53% (20 of 38) |
| Monstrous | 36% (5 of 14) | 64% (9 of 14) | - | 50% (14 of 28) |
| War Machines | 70% (40 of 57) | 50% (1 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 27% (28 of 102) | 37% | 59% (13 of 22) | 83% (5 of 6); 2.8 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (6 of 6); on the table 100% | 50% (18 of 36) | 56% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (12 of 12); on the table 100% | - | 55% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 83% (15 of 18); on the table 83% | 25% (12 of 48) | 40% | 54% (41 of 76) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 91% (31 of 34); on the table 91% | 29% (40 of 138) | 35% | 43% (23 of 54) | 100% (14 of 14); 8.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 77% (10 of 13); on the table 77% | 11% (2 of 18) | 34% | 55% (18 of 33) | 100% (3 of 3); 1.8 uses a game | 57% (8 of 14); 4.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (7 of 7); on the table 100% | - | 53% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (10 of 10); on the table 100% | - | 30% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (12 of 12); on the table 100% | 0% (0 of 18) | 29% | 79% (22 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 80% (4 of 5); on the table 100% | 28% (5 of 18) | 25% | 52% (13 of 25) | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 87% (13 of 15); on the table 87% | - | 33% | 40% (10 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 83% (24 of 29); on the table 90% | 50% (33 of 66) | 34% | 61% (33 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 84% (16 of 19); on the table 84% | 44% (8 of 18) | 16% | 49% (36 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 86% (19 of 22); on the table 86% | 38% (9 of 24) | 33% | 56% (44 of 78) | 57% (4 of 7); 1.4 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-h2h-mine-324c342-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (46) | 45% (30) | 48% (76) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.53 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.39 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.14 | 3.11 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.92 | 1.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.92 | 4.69 | 10.61 |

### Quality by phase: co-h2h-mine-324c342-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (83 of 151) | 44% (99 of 224) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (148 of 320) | 58% (128 of 222) |
| Strategy | Close-in objectives charged next turn | 14% (18 of 131) | 18% (42 of 240) |
| Strategy | Support requests answered (helper made contact too) | 56% (9 of 16) | 38% (11 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (15 of 28) | 76% (13 of 17) |
| Strategy | Joined characters whose unit fought | 63% (29 of 46) | 38% (15 of 40) |
| Strategy | Lone characters that fought | 77% (76 of 99) | 76% (63 of 83) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 1.1 |
| Movement | Points that never moved of their own | 309.7 | 172.9 |
| Movement | Fights charged into per game | 2.9 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 94, net +45 | 28 of 121, net -21 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 94, net +52 | 18 of 121, net +11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 18 of 94, net +56 | 10 of 121, net +93 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 94, net +70 | 38 of 121, net +189 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (136 of 333) | 43% (163 of 377) |
| Shooting | Points destroyed by shooting units | 84.2 | 38.1 |
| Shooting | War machine shots | 6.3 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (137 of 228) | 55% (52 of 95) |
| Shooting | Points destroyed by war machines | 66.8 | 66.1 |
| Magic | Magic missiles cast | 1.8 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (20 of 63) | 45% (14 of 31) |
| Magic | Wounds caused by magic missiles | 1.8 | 1.2 |
| Magic | Wounds caused by other spells | 1.5 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 37.2 | 7.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.9 / 0.9 / 0.1 | 2.0 / 0.5 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 311.6 | 450.9 |
| Combat | Points run down | 78.7 | 91.2 |
| Combat | Net points per charged fight, damage counted | +49 | +90 |
| Combat | Net per 100 charger points, damage counted | +18.4 | +32.4 |
| Combat | First round won (charged fights) | 73% | 69% |
| Combat | Net points per charged fight | +42 | +90 |
| Combat | Net points per supported fight / lone fight | +114 / +33 | +74 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 18 of 105 | 58 of 137 |
| Game | Points lost | 825.1 | 680.4 |
| Game | VP from objectives | 492.2 | 639.2 |
| Game | Lone holders (player turns) | 2.1 | 3.6 |

- Mine won / drew / lost: 10 / 8 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -329 VP
- The side that went first won 17 of 28 games with a winner
- Points traded per game (both sides' losses): 1505
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: co-h2h-mine-324c342-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 10.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +5.2 | 0.0 | 25.0 | 1.3 | +14.7 | 0.0 | 15.2 |
| BEST FACING | 1.0 | +50.9 | 0.0 | 46.6 | 0.4 | +11.3 | 0.0 | 10.4 |
| BEST FIRST | 4.5 | +196.2 | 104.2 | 130.4 | 4.1 | +207.9 | 244.5 | 55.1 |
| BEST OVERALL | 0.8 | +52.1 | 0.0 | 31.5 | 0.4 | +27.1 | 0.0 | 13.7 |
| BEST PREY | 0.7 | +34.4 | 15.6 | 1.4 | 0.9 | +45.2 | 31.4 | 20.2 |
| BEST PRIZE | 0.1 | -2.0 | 0.0 | 0.0 | 0.1 | +2.4 | 12.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.4 | 0.0 | 11.1 | 0.1 | -0.1 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 2.6 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +5.1 | 0.0 | 1.8 | 0.5 | -0.2 | 0.0 | 30.2 |
| BLOWS WHERE AIMED | 0.2 | -6.2 | 13.2 | 10.2 | - | - | - | - |
| BOMBING RUN | 0.1 | +4.0 | 16.9 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 40.8 | 12.4 | 0.1 | +0.0 | 7.5 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +168.0 | 300.7 | 83.1 | 2.1 | +77.2 | 166.8 | 9.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.8 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 23.6 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.7 | 0.0 | 2.9 | 0.2 | -0.6 | 30.0 | 12.1 |
| CAST JOB | 0.5 | +9.7 | 4.2 | 19.1 | 0.2 | +8.1 | 26.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +27.0 | 10.8 | 0.0 | 0.2 | +14.7 | 12.8 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 11.1 | 0.4 | +0.0 | 0.0 | 24.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.0 | 6.1 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 147.2 | 136.8 | 3.4 | +0.0 | 432.8 | 159.5 |
| CHARGE NOW WEIGHED | 0.3 | -16.1 | 2.6 | 18.6 | 0.4 | -36.6 | 0.0 | 31.4 |
| CHARGER SLAIN LOST | 0.7 | -8.7 | 47.9 | 31.1 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 5.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.1 | 0.0 | 15.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 3.5 | 0.0 | 0.3 | +0.0 | 12.6 | 4.2 |
| COMBAT PIVOT | 0.3 | +0.0 | 3.4 | 42.1 | 0.6 | +0.0 | 68.1 | 71.0 |
| CONVEYANCE SEARCH | 0.2 | +42.0 | 0.0 | 0.0 | 0.6 | +77.1 | 26.3 | 50.6 |
| COUNTER-CHARGE COVER | 10.6 | +919.6 | 0.0 | 248.4 | 6.4 | +545.3 | 0.0 | 143.1 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 1.1 | 0.0 | 0.2 | +0.0 | 16.1 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +2.1 | 15.9 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +9.0 | 10.2 | 0.0 | 0.4 | +7.2 | 62.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +147.5 | 0.0 | 83.4 | 1.1 | +97.1 | 0.0 | 19.1 |
| FALLBACK BY WORTH | 4.7 | +37.6 | 0.0 | 61.2 | 5.6 | +87.7 | 0.0 | 57.1 |
| FIGHT LIFT | 0.1 | +0.3 | 3.3 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 3.1 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 167.0 | 4.4 | +0.0 | 0.0 | 124.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +111.0 | 0.0 | 66.0 | 1.0 | +130.6 | 0.0 | 5.4 |
| FRIENDS SHOTS CHECKED | 0.3 | +22.3 | 0.0 | 19.6 | 0.2 | +6.8 | 0.0 | 11.6 |
| GIVES UP | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -2.1 | 0.0 | 6.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.5 | 6.1 | 4.2 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.7 | 0.2 | +0.0 | 10.9 | 19.4 |
| HELPER UNSEEN | 0.2 | +0.0 | 8.1 | 7.9 | 0.4 | +0.0 | 26.0 | 9.2 |
| HILL BY ITS CHANCE | 0.3 | -22.1 | 0.0 | 4.2 | 0.6 | -54.0 | 0.0 | 8.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.9 | 5.6 | 2.4 | 0.3 | +2.1 | 8.8 | 8.2 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 23.9 | 9.1 |
| HUNT IN PAIRS | 0.2 | +12.5 | 0.0 | 12.1 | 0.6 | +26.0 | 0.0 | 23.4 |
| HUNT KEPT | 0.0 | +2.9 | 2.8 | 2.4 | 0.1 | +3.6 | 15.6 | 0.0 |
| HUNT RESULT | 0.1 | +11.9 | 0.0 | 3.3 | 0.4 | +51.4 | 44.1 | 13.4 |
| HUNT THE GUNS | 0.1 | +28.6 | 5.6 | 2.4 | 0.4 | +150.4 | 28.3 | 14.4 |
| INVITES THE FIGHT | 1.9 | +34.1 | 37.3 | 36.0 | 1.1 | +20.7 | 69.5 | 8.6 |
| JOINT CHARGE PLAN | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +8.0 | 8.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.0 | 0.0 | 1.7 | - | - | - | - |
| KEEP FALLS | 0.1 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.2 | 8.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 77.4 | 80.1 | 2.2 | +65.0 | 221.7 | 96.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +69.9 | 96.0 | 73.3 | 2.5 | +103.5 | 237.5 | 61.9 |
| KILLS COUNT NEXT TURN | 4.5 | +136.7 | 130.6 | 73.8 | 8.0 | +311.9 | 303.4 | 239.8 |
| LONE CHARACTER SAFE SPOT | 0.2 | +22.9 | 5.2 | 0.0 | 0.2 | +11.1 | 5.2 | 6.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 10.9 | 0.0 | 0.3 | +0.0 | 3.2 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -5.0 | 29.1 | 1.8 | 0.7 | -5.9 | 43.3 | 9.6 |
| LOST CHARGE | 2.8 | -47.8 | 44.3 | 107.2 | 2.4 | -62.4 | 109.6 | 49.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.4 | 0.0 | 3.1 | 0.0 | -3.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +35.9 | 4.8 | 1.4 | 0.9 | +69.0 | 0.0 | 49.5 |
| MANOEUVRE | 0.2 | +13.3 | 0.0 | 8.2 | 0.2 | +10.0 | 0.0 | 12.1 |
| MARCH AT ESCAPER | 0.0 | +0.1 | 0.0 | 2.2 | 0.1 | +2.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +19.9 | 0.0 | 12.4 | 0.6 | +25.5 | 0.0 | 13.5 |
| MARCH ODDS | 0.2 | +20.1 | 6.3 | 12.1 | 0.2 | +33.7 | 12.4 | 0.0 |
| MARCH OVER CASTS | 0.5 | +60.8 | 0.0 | 18.9 | 0.4 | +29.1 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 4.2 | +135.8 | 0.0 | 100.7 | 4.9 | +182.6 | 0.0 | 131.0 |
| MISSILES IN THE MOVE | 3.5 | +86.5 | 0.0 | 124.9 | 3.1 | +62.8 | 0.0 | 70.5 |
| MISSILES NEXT TURN | 4.1 | +58.5 | 0.0 | 127.3 | 3.6 | +48.6 | 0.0 | 87.8 |
| MODEL FACING | 0.3 | +49.1 | 0.0 | 0.0 | 0.2 | +78.9 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +6.1 | 0.0 | 14.4 | 0.2 | +9.9 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.2 | +10.5 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 5.3 | 2.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -8.5 | 11.2 | 9.9 | 0.2 | -7.7 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.7 | +160.5 | 70.8 | 56.8 | 5.0 | +368.6 | 215.3 | 193.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +13.5 | 7.1 | 0.0 | 0.1 | +5.8 | 3.2 | 5.4 |
| NOT NEEDED | 0.4 | -18.0 | 38.0 | 13.7 | 0.5 | -25.0 | 37.3 | 9.5 |
| NOT TURNED | 5.9 | +69.4 | 0.0 | 135.4 | 4.7 | +68.5 | 0.0 | 114.5 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 39.1 | 0.6 | -0.4 | 0.0 | 11.2 |
| OFF BEST | 14.3 | -710.3 | 0.0 | 266.1 | 15.1 | -814.9 | 8.0 | 241.0 |
| OPENS A LANE | 0.0 | +0.1 | 3.0 | 0.0 | 0.1 | +0.2 | 3.2 | 0.0 |
| OPENS UP | 0.2 | +22.2 | 17.8 | 0.0 | 0.2 | +14.5 | 16.8 | 0.0 |
| OVERRUNS AWAY | 0.6 | +8.8 | 52.9 | 26.8 | 0.7 | +12.4 | 100.2 | 47.1 |
| PATHS CROSS | 2.0 | +132.6 | 0.0 | 25.0 | 2.9 | +219.3 | 0.0 | 75.8 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.9 | 0.0 | 2.7 | 0.1 | -1.6 | 0.0 | 3.8 |
| PLAN RESULT | 36.5 | +1233.3 | 1219.6 | 1140.4 | 40.5 | +1390.7 | 1918.4 | 954.1 |
| PURSUES BIG PREY | 0.1 | -3.5 | 0.0 | 0.0 | 0.1 | -7.7 | 0.0 | 16.1 |
| PURSUES ON | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +15.0 | 0.0 | 17.5 | 1.6 | +38.8 | 0.0 | 32.8 |
| RANDOM MOVER NO PROMISE | 0.3 | -15.0 | 19.1 | 5.8 | 0.3 | -18.6 | 1.8 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.6 | 0.0 | 0.0 | 0.2 | -6.1 | 0.0 | 2.5 |
| REDIRECT COUNTER | 2.0 | +174.5 | 0.0 | 36.8 | 3.7 | +299.6 | 0.0 | 70.7 |
| REDIRECT WEIGHED | 0.3 | +8.2 | 0.0 | 21.0 | 0.4 | +6.0 | 7.3 | 4.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +7.3 | 0.0 | 0.0 | 1.1 | +29.5 | 0.0 | 15.2 |
| RESTRAINS TO SHOOT | 0.2 | +9.2 | 0.0 | 9.6 | 0.1 | +4.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +89.7 | 168.2 | 123.3 | 3.7 | +103.6 | 400.3 | 119.6 |
| SAFER THAN THE JOB | 1.0 | +58.1 | 0.0 | 25.1 | 0.9 | +62.3 | 0.0 | 49.9 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.5 | 0.0 | 1.2 | 0.4 | -18.2 | 0.0 | 6.9 |
| SEARCH SPOT | 2.8 | +163.6 | 0.0 | 34.4 | 2.7 | +131.6 | 0.0 | 32.6 |
| SECOND HUNTER | 0.0 | -0.5 | 2.8 | 1.4 | 0.1 | -0.6 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.2 | +13.1 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +54.7 | 4.8 | 1.4 | 1.8 | +143.5 | 32.1 | 66.9 |
| SET-UP ANY TARGET | 0.2 | +37.7 | 0.0 | 0.0 | 0.1 | +13.9 | 4.4 | 18.9 |
| SET-UP MISSED | - | - | - | - | 0.1 | +6.6 | 5.7 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +18.0 | 34.3 | 15.7 | 0.6 | +27.5 | 29.9 | 9.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 76.1 | 3.1 | 0.2 | +0.0 | 27.6 | 0.0 |
| SHOTS IN THE MOVE | 13.1 | +581.5 | 0.0 | 242.1 | 11.3 | +380.1 | 0.0 | 125.7 |
| SPELL CATCH ODDS | 0.0 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +48.1 | 0.0 | 0.0 | 0.2 | +52.6 | 4.4 | 26.5 |
| SPELL WORTH | 0.8 | +17.0 | 79.4 | 74.9 | 1.8 | +30.7 | 89.1 | 77.0 |
| SPELLS IN THE FIGHT | 0.6 | +4.0 | 35.2 | 34.9 | - | - | - | - |
| STABLE ROLE | 11.2 | +0.0 | 391.9 | 140.3 | 11.9 | +0.0 | 517.8 | 156.7 |
| STANDS TO CAST | 0.1 | +0.8 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +9.4 | 0.0 | 0.0 |
| STOPS | 0.0 | +2.9 | 2.8 | 2.4 | 0.3 | +13.6 | 35.1 | 6.2 |
| STOPS SHORT OF THE FLANK | 0.6 | +35.4 | 0.0 | 27.4 | 0.3 | +12.3 | 0.0 | 38.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 7.2 | -53.9 | 461.2 | 165.7 | 7.0 | -51.3 | 398.1 | 126.6 |
| SUPPORTS | 4.7 | +53.9 | 298.1 | 51.5 | 4.2 | +55.3 | 142.6 | 39.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.0 | 8.9 | 0.0 | 0.2 | -17.5 | 43.0 | 19.9 |
| SURE REACH TOGETHER | 0.4 | +0.8 | 5.7 | 2.4 | 0.7 | +9.8 | 0.0 | 20.4 |
| THROUGH LINE OF FIRE | 0.2 | +7.9 | 0.0 | 0.0 | 0.2 | +9.3 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -38.0 | 36.6 | 29.3 | 0.4 | -29.6 | 50.4 | 14.5 |
| TWO OR MORE ARRIVE | 0.1 | +0.8 | 0.0 | 0.0 | 0.6 | +3.8 | 8.0 | 16.4 |
| WAIT AFTER COSTS | 6.4 | -259.4 | 135.8 | 120.4 | 8.6 | -401.8 | 400.9 | 211.5 |
| WALKS TO THE FIGHT | 1.6 | +32.2 | 24.6 | 32.2 | 1.7 | +38.4 | 67.5 | 12.8 |
| WAR ENGINE CHARGES | 0.1 | +9.9 | 1.2 | 2.1 | 0.1 | +3.8 | 0.9 | 7.2 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 53.4 | 8.6 | 0.2 | +0.0 | 12.6 | 7.2 |
| WEARS DOWN | 1.3 | +56.7 | 68.4 | 35.8 | 1.9 | +63.5 | 224.8 | 126.2 |
| WHO HITS BACK | 0.3 | +38.1 | 0.0 | 42.1 | 0.2 | +12.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +14.7 | 49.9 | 0.0 | 0.6 | +32.7 | 87.2 | 5.2 |
| WHOLE FIGHT GAIN | 0.3 | +20.5 | 24.3 | 6.5 | 0.7 | +47.5 | 52.4 | 24.6 |
| WIDER SPREAD | 2.6 | -9.5 | 150.1 | 100.0 | - | - | - | - |

### Rule changes: co-h2h-mine-324c342-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1059 | 1059 | 1059 | 29.42 | -54899 | -51.8 |
| BEST FIRST | 310 | 310 | 310 | 8.61 | +14549 | +46.9 |
| SEARCH SPOT | 198 | 198 | 196 | 5.44 | +10641 | +54.3 |
| PATHS CROSS | 179 | 179 | 179 | 4.97 | +12670 | +70.8 |
| COUNTER-CHARGE COVER | 614 | 367 | 161 | 4.47 | +9549 | +59.3 |
| SUPPORTS | 322 | 322 | 142 | 3.94 | +1272 | +9.0 |
| MOVE TO CHARGE | 277 | 277 | 139 | 3.86 | +6367 | +45.8 |
| KILLS COUNT NEXT TURN | 449 | 449 | 133 | 3.69 | +3442 | +25.9 |
| FACES THE THREAT | 112 | 112 | 112 | 3.11 | +8803 | +78.6 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +8699 | +113.0 |
| FALLBACK BY WORTH | 370 | 370 | 72 | 2.00 | +4509 | +62.6 |
| WALKS TO THE FIGHT | 120 | 120 | 72 | 2.00 | +1047 | +14.5 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SAFER THAN THE JOB | 68 | 68 | 68 | 1.89 | +4334 | +63.7 |
| WAIT AFTER COSTS | 540 | 540 | 67 | 1.86 | +1398 | +20.9 |
| SHOTS IN THE MOVE | 881 | 588 | 65 | 1.81 | +1921 | +29.6 |
| RANDOM MOVE BY FIGURES | 93 | 93 | 58 | 1.61 | +1938 | +33.4 |
| RISK BY ARC | 228 | 224 | 54 | 1.50 | +1896 | +35.1 |
| RESERVE FALL BACK | 52 | 52 | 52 | 1.44 | +1322 | +25.4 |
| BEST FACING | 50 | 50 | 50 | 1.39 | +2238 | +44.8 |
| CHARGE NOW FIRST | 213 | 213 | 48 | 1.33 | -2844 | -59.2 |
| ARTILLERY RE-ROLL WEIGHED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| BEST OVERALL | 44 | 44 | 44 | 1.22 | +2851 | +64.8 |
| KILLS COUNT | 156 | 155 | 43 | 1.19 | +1396 | +32.5 |
| REDIRECT COUNTER | 207 | 115 | 43 | 1.19 | +3952 | +91.9 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| MAX FOR POSITIONING | 328 | 211 | 42 | 1.17 | +449 | +10.7 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| CANNON PLANNED TARGET | 248 | 248 | 37 | 1.03 | -667 | -18.0 |
| SET UP TOGETHER | 91 | 77 | 35 | 0.97 | +2466 | +70.5 |
| MARCH CHECK | 39 | 38 | 34 | 0.94 | +1568 | +46.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1719 | +52.1 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +176 | +6.5 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +1071 | +39.7 |
| MISSILES IN THE MOVE | 236 | 143 | 25 | 0.69 | +469 | +18.8 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| CHARGE NOW WEIGHED | 24 | 24 | 24 | 0.67 | +2209 | +92.0 |
| INVITES THE FIGHT | 108 | 108 | 24 | 0.67 | +381 | +15.9 |
| SHOOTS FROM THE BEST SPOT | 52 | 52 | 23 | 0.64 | +509 | +22.1 |
| WEARS DOWN | 114 | 112 | 22 | 0.61 | +952 | +43.3 |
| WHOLE FIGHT GAIN | 37 | 35 | 22 | 0.61 | +771 | +35.0 |
| MODEL FACING | 21 | 21 | 21 | 0.58 | +4606 | +219.3 |
| KEEPS ITS TARGET | 129 | 127 | 20 | 0.56 | +340 | +17.0 |
| SHOT REPLANNED | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1046 | +58.1 |
| CASTING BLOCK | 20 | 20 | 17 | 0.47 | +675 | +39.7 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1011 | +59.5 |
| CAST JOB | 26 | 26 | 16 | 0.44 | +310 | +19.4 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -9 | -0.5 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +616 | +38.5 |
| BEST PREY | 57 | 57 | 15 | 0.42 | +627 | +41.8 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 14 | 14 | 14 | 0.39 | +621 | +44.3 |
| LOST CHARGE | 190 | 190 | 13 | 0.36 | +399 | +30.7 |
| MOVE AND CAST | 13 | 13 | 13 | 0.36 | +575 | +44.2 |
| MANOEUVRE | 15 | 15 | 12 | 0.33 | +838 | +69.8 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 12 | 12 | 12 | 0.33 | -667 | -55.6 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | +11 | +1.0 |
| MAKE SURE TOGETHER | 49 | 30 | 11 | 0.31 | +873 | +79.3 |
| OPENS UP | 18 | 18 | 11 | 0.31 | +409 | +37.2 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +477 | +43.4 |
| SUPPORT NARROWED | 512 | 512 | 11 | 0.31 | -230 | -20.9 |
| WHOLE FIGHT | 29 | 29 | 11 | 0.31 | +714 | +64.9 |
| HUNT IN PAIRS | 29 | 22 | 10 | 0.28 | +391 | +39.1 |
| WAR ENGINE JOBS | 33 | 33 | 9 | 0.25 | -312 | -34.6 |
| OVERRUNS AWAY | 47 | 46 | 7 | 0.19 | +226 | +32.3 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -161 | -23.1 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -403 | -57.6 |
| SURE REACH TOGETHER | 39 | 26 | 6 | 0.17 | +82 | +13.6 |
| BACKUP TARGETS | 80 | 38 | 5 | 0.14 | +78 | +15.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -326 | -65.2 |
| BOMBING RUN | 5 | 5 | 5 | 0.14 | +144 | +28.8 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 274 | 168 | 4 | 0.11 | +6 | +1.6 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -29 | -7.1 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +337 | +84.3 |
| STOPS | 11 | 11 | 4 | 0.11 | +172 | +43.0 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -232 | -77.3 |
| DEFENSIVE ARMY | 18 | 18 | 3 | 0.08 | -152 | -50.6 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +46 | +15.2 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +312 | +104.0 |
| MOVE SPELL IN RANGE | 7 | 6 | 3 | 0.08 | +45 | +15.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +126 | +42.1 |
| SPELLS IN THE FIGHT | 21 | 21 | 3 | 0.08 | +30 | +10.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| CARRIES OUT SET-UP | 9 | 9 | 2 | 0.06 | -84 | -41.8 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -29 | -14.3 |
| HUNT ADVANCE | 14 | 14 | 2 | 0.06 | +13 | +6.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +176 | +87.8 |
| WAR ENGINE CHARGES | 7 | 7 | 2 | 0.06 | +211 | +105.6 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +3 | +2.7 |
| EDGE GIVE GROUND | 24 | 24 | 1 | 0.03 | +11 | +11.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +2 | +2.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +62 | +62.3 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 1 | 0.03 | -2 | -2.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +1 | +1.1 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +175 | +175.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.03 | -0 | -0.4 |
| WIDER SPREAD | 95 | 94 | 1 | 0.03 | +1 | +1.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 26 | 26 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 15 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 373 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 31 | 31 | 0 | 0.00 | - | - |
| HUNT DROPPED | 9 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 20 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LONG SHOT | 44 | 43 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 33 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 382 | 382 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 35 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2770 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 22 | 22 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 830 | 827 | 0 | 0.00 | - | - |
| TURN WORTH | 32 | 31 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 16 | 0 | 0.00 | - | - |

### Off best figure: co-h2h-mine-324c342-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.67 | 13.67 | 53.2 |
| CHARGE NOW FIRST | rule | 0.56 | 0.78 | 59.2 |
| TURN GATE | gate | 0.75 | 0.39 | 43.0 |
| FALLBACK | gate | 0.47 | 0.47 | 42.0 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.08 | 54.2 |
| AFTERMATH BAND | gate | 0.17 | 0.17 | 2.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.25 | 55.6 |
| SUPPORT NARROWED | rule | 0.28 | 0.03 | 20.9 |
| WAR ENGINE JOBS | rule | 0.22 | 0.03 | 34.6 |
| PATHS CROSS | rule | 0.08 | 0.14 | 38.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.14 | 74.2 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 23.1 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 57.6 |
| CHAFF PASSED | rule | 0.03 | 0.14 | 1.4 |
| BEST PRIZE | rule | 0.08 | 0.06 | 65.2 |
| BLOCKED WHEEL | rule | 0.03 | 0.11 | 10.0 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 42.9 |
| FIGHT ORDER BAND | gate | 0.11 | 0.03 | 2.7 |
| SUPPORT REQUEST | gate | - | 0.14 | 91.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 33.3 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.03 | 6.2 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 77.3 |
| DEFENSIVE ARMY | rule | 0.03 | 0.06 | 50.6 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 41.8 |
| CATCH ODDS | rule | 0.03 | 0.03 | 14.3 |
| NO REASON | gate | 0.06 | - | 30.4 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 4.3 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 24.8 |
| WHO HITS BACK | rule | - | 0.06 | 3.4 |
| FACES THE THREAT | rule | 0.03 | - | 9.8 |
| FALLBACK BY WORTH | rule | - | 0.03 | 140.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 2.3 |
| MARCH ODDS | rule | - | 0.03 | 17.4 |
| MOVE AND CAST | rule | 0.03 | - | 14.8 |
| REDIRECT WEIGHED | rule | - | 0.03 | 83.4 |
| RULE SWITCHED OFF | gate | - | 0.03 | 56.5 |
| STANDS TO CAST | rule | - | 0.03 | 34.2 |

### Plans: co-h2h-mine-324c342-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 17% | 439 | 283 | 65% |
| Mine | charge | 3.6 | 57% | 324 | 266 | 82% |
| Mine | close in | 3.6 | 21% | 207 | 74 | 36% |
| Mine | hold | 4.1 | 31% | 267 | 0 | 0% |
| Mine | join | 0.6 | 100% | 19 | 0 | 0% |
| Mine | shoot | 7.7 | 58% | 212 | 610 | 288% |
| Mine | support | 4.8 | 90% | 32 | 0 | 0% |
| Opponent | advance | 13.6 | 16% | 427 | 417 | 97% |
| Opponent | charge | 5.2 | 51% | 540 | 467 | 87% |
| Opponent | close in | 6.7 | 27% | 516 | 150 | 29% |
| Opponent | hold | 4.4 | 35% | 332 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 41 | 0 | 0% |
| Opponent | shoot | 5.0 | 55% | 171 | 358 | 209% |
| Opponent | support | 4.6 | 92% | 46 | 0 | 0% |

### Packages: hunt the guns, co-h2h-mine-324c342-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.5 | 257 | 107 | 25% | 58 |
| Opponent | 0.4 | 16 | 0 | 25% | 31% | 0% | 2.6 | 338 | 116 | 31% | 106 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 100% | 0% | 2.5 | 298 | 213 | 50% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 349 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 280 | 0 | 0% | 70 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 60% | 80% | 0% | 2.8 | 441 | 320 | 80% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 1.0 | 5 | 0 | 0% | 0% | 0% | - | 190 | 0 | 0% | 52 |
| Vampire Counts | 0.3 | 3 | 0 | 33% | 33% | 0% | 2.0 | 309 | 83 | 33% | 76 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 128 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 318 | 0 | 0% | 39 |

### Battle groups: co-h2h-mine-324c342-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.6 | 25% | 53% | 16% | 33% | 39% | 5% | 9% | 47% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 25% | 72% | 0% | - | 28% | 0% | 17% | 50% | 6% |
| Opponent | COUNTER-CHARGE COVER | 6.4 | 23% | 70% | 30% | 56% | 32% | 11% | 13% | 45% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 36% | 65% | 21% | 10% | 18% | 5% | 21% | 53% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-h2h-mine-324c342-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 27 (5) | 27 | 0 | 52 | 20% | 2.5 | 56 (2) | - | - | 56 (2) | - |
| Mine | Chaff | 36 | 78 (36) | 40 | 38 | 60 | 36% | 2.8 | 53 (20) | 244 (7) | 13 (9) | 103 (25) | 14 (11) |
| Mine | Character | 123 | 38 (123) | 37 | 1 | 43 | 17% | 2.3 | 51 (35) | 33 (54) | 57 (14) | 52 (51) | 33 (52) |
| Mine | Clean-up | 20 | 52 (20) | 18 | 34 | 44 | 30% | 2.9 | 18 (5) | 51 (12) | 152 (3) | 111 (12) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 60 (46) | 49 | 11 | 62 | 22% | 3.0 | 48 (22) | 85 (16) | 57 (8) | 60 (27) | 60 (19) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 37 (57) | 25 | 12 | 40 | 19% | 2.6 | 14 (18) | 43 (29) | 60 (10) | 27 (38) | 52 (19) |
| Mine | Holder | 29 | 58 (29) | 8 | 50 | 28 | 48% | 2.8 | 53 (11) | 85 (11) | 15 (7) | 73 (20) | 30 (9) |
| Mine | Shooter | 41 | 62 (41) | 26 | 36 | 39 | 2% | 1.6 | 100 (5) | 57 (30) | 64 (6) | 84 (25) | 29 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | War machine | 59 | 53 (59) | 53 | 0 | 47 | 2% | 1.2 | 42 (10) | 47 (37) | 84 (12) | 40 (10) | 56 (49) |
| Mine | Wizard | 22 | 6 (22) | 6 | 0 | 53 | 9% | 2.5 | 8 (7) | 13 (6) | 0 (5) | 0 (5) | 9 (13) |
| Opponent | Blocker | 2 | 240 (2) | 240 | 0 | 0 | 50% | 4.0 | - | 240 (2) | - | 240 (2) | - |
| Opponent | Chaff | 76 | 72 (76) | 34 | 38 | 55 | 32% | 2.6 | 91 (31) | 33 (20) | 89 (25) | 82 (54) | 48 (22) |
| Opponent | Character | 94 | 55 (94) | 55 | 0 | 30 | 22% | 2.7 | 64 (42) | 57 (38) | 12 (6) | 53 (59) | 67 (27) |
| Opponent | Clean-up | 21 | 40 (21) | 20 | 19 | 29 | 29% | 2.8 | 28 (9) | 52 (12) | - | 39 (15) | 43 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 0% | 5.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 43 (48) | 34 | 9 | 46 | 19% | 2.6 | 53 (22) | 23 (16) | 57 (10) | 48 (28) | 34 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 40% | 2.3 | - | 0 (3) | 0 (2) | 0 (3) | 0 (2) |
| Opponent | Hammer | 68 | 45 (68) | 41 | 4 | 35 | 18% | 2.8 | 40 (17) | 45 (40) | 52 (11) | 54 (42) | 30 (26) |
| Opponent | Holder | 35 | 83 (35) | 11 | 72 | 30 | 26% | 3.2 | 99 (5) | 97 (21) | 56 (6) | 116 (18) | 56 (14) |
| Opponent | Shooter | 33 | 80 (33) | 18 | 62 | 34 | 0% | 1.8 | 77 (8) | 98 (19) | 23 (6) | 124 (22) | 13 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 33% | 5.5 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 24 | 73 (24) | 73 | 0 | 16 | 8% | 1.5 | 22 (6) | 98 (14) | 56 (4) | 0 (3) | 84 (21) |
| Opponent | Wizard | 29 | 13 (29) | 13 | 0 | 48 | 7% | 1.7 | 0 (10) | 38 (7) | 0 (7) | 24 (12) | 0 (12) |

### Charged fights: co-h2h-mine-324c342-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 144 | 148 | 1.2 | 1.0 | 118 | 10 | +108 | 0 of 5 | 5 of 5 | - | +108 |
| Mine | Chaos Dwarfs | 4 | 88 | 158 | 1.8 | 1.1 | 90 | 9 | +81 | 3 of 7 | 4 of 7 | +0 | +94 |
| Mine | Dwarfen Mountain Holds | 4 | 660 | 48 | 3.0 | 1.2 | 16 | 9 | +7 | 2 of 12 | 5 of 12 | +0 | +9 |
| Mine | Empire of Man | 5 | 276 | 152 | 2.4 | 1.1 | 64 | 70 | -6 | 3 of 12 | 8 of 12 | +0 | -7 |
| Mine | Grand Cathay | 4 | 190 | 246 | 4.0 | 1.1 | 62 | 0 | +62 | 4 of 16 | 14 of 16 | +251 | +49 |
| Mine | High Elf Realms | 4 | 152 | 259 | 4.2 | 1.2 | 61 | 47 | +14 | 1 of 17 | 13 of 17 | +30 | +12 |
| Mine | Kingdom of Bretonnia | 1 | 170 | 410 | 5.0 | 1.0 | 82 | 55 | +27 | 1 of 5 | 4 of 5 | - | +27 |
| Mine | Lizardmen | 1 | 50 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 125 | 4.0 | 1.0 | 31 | 8 | +23 | 0 of 4 | 3 of 4 | - | +23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 3.0 | 1.3 | 78 | 0 | +78 | 1 of 3 | 2 of 3 | +45 | +95 |
| Mine | Skaven | 2 | 58 | 0 | 1.0 | 1.0 | 0 | 19 | -19 | 0 of 2 | 1 of 2 | - | -19 |
| Mine | Tomb Kings of Khemri | 1 | 125 | 534 | 6.0 | 1.2 | 89 | 30 | +60 | 1 of 6 | 6 of 6 | +432 | -15 |
| Mine | Vampire Counts | 3 | 0 | 151 | 3.7 | 1.2 | 41 | 5 | +37 | 1 of 11 | 9 of 11 | +205 | +20 |
| Mine | Warriors of Chaos | 1 | 0 | 866 | 3.0 | 1.3 | 289 | 0 | +289 | 0 of 3 | 2 of 3 | +258 | +304 |
| **Mine** | all armies | 36 | 188 | 189 | 2.9 | 1.1 | 65 | 23 | +42 | 18 of 105 | 77 of 105 | +114 | +33 |
| Opponent | Dwarfen Mountain Holds | 2 | 137 | 40 | 2.0 | 1.2 | 20 | 15 | +5 | 1 of 4 | 0 of 4 | -60 | +27 |
| Opponent | Empire of Man | 2 | 698 | 168 | 1.5 | 1.3 | 112 | 0 | +112 | 0 of 3 | 3 of 3 | +0 | +168 |
| Opponent | Grand Cathay | 2 | 241 | 770 | 3.5 | 1.7 | 220 | 29 | +191 | 4 of 7 | 7 of 7 | +254 | +144 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 0 | 648 | 5.0 | 1.1 | 130 | 3 | +127 | 7 of 15 | 8 of 15 | +95 | +129 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 169 | 560 | 3.8 | 1.1 | 149 | 161 | -11 | 8 of 15 | 9 of 15 | -706 | +38 |
| Opponent | Vampire Counts | 6 | 100 | 746 | 5.2 | 1.2 | 144 | 72 | +72 | 15 of 31 | 24 of 31 | -8 | +88 |
| Opponent | Warriors of Chaos | 8 | 7 | 564 | 3.0 | 1.2 | 188 | 43 | +145 | 10 of 24 | 17 of 24 | +218 | +126 |
| Opponent | Wood Elf Realms | 7 | 59 | 653 | 5.1 | 1.1 | 127 | 40 | +87 | 13 of 36 | 24 of 36 | +134 | +84 |
| **Opponent** | all armies | 36 | 111 | 551 | 3.8 | 1.2 | 145 | 54 | +90 | 58 of 137 | 94 of 137 | +74 | +93 |

### Effective charges: co-h2h-mine-324c342-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 1 (net +100) | 0 | 1 (net +365) | 1 (net +72) | 2 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 7 | 2 (net +203) | 0 | 1 (net +45) | 0 | 2 (net +90) | 2 (net -32) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 12 | 3 (net +0) | 1 (net +0) | 2 (net +40) | 0 | 0 | 5 (net +1) | 1 | 18% (2 of 11) |
| Mine | Empire of Man | 12 | 0 | 0 | 4 (net -16) | 4 (net -52) | 1 (net +0) | 2 (net +100) | 1 | 36% (4 of 11) |
| Mine | Grand Cathay | 16 | 0 | 1 (net +110) | 2 (net +38) | 1 (net +0) | 4 (net +35) | 8 (net +82) | 0 | 12% (2 of 16) |
| Mine | High Elf Realms | 17 | 0 | 1 (net -60) | 2 (net +148) | 5 (net +16) | 6 (net -27) | 2 (net +114) | 1 | 12% (2 of 16) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net -36) | 2 (net +0) | 0 | 1 (net +205) | 0 | 40% (2 of 5) |
| Mine | Lizardmen | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +62) | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 1 | 50% (1 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -19) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net -122) | 0 | 4 (net +120) | 0 | 1 | 20% (1 of 5) |
| Mine | Vampire Counts | 11 | 3 (net +0) | 0 | 1 (net -50) | 5 (net +41) | 0 | 1 (net +125) | 1 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +608) | 0 | 0 | 1 (net +258) | 1 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 4 | 1 (net +0) | 1 (net -60) | 1 (net +81) | 0 | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 1 (net +335) | 2 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 7 | 1 (net +407) | 0 | 1 (net +214) | 2 (net +180) | 1 (net +0) | 2 (net +177) | 0 | 14% (1 of 7) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +120) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Ogre Kingdoms | 15 | 4 (net +82) | 0 | 0 | 3 (net +210) | 0 | 3 (net +208) | 5 | 0% (0 of 10) |
| Opponent | Tomb Kings of Khemri | 15 | 4 (net -156) | 0 | 2 (net -353) | 4 (net +102) | 0 | 3 (net +157) | 2 | 15% (2 of 13) |
| Opponent | Vampire Counts | 31 | 9 (net -129) | 0 | 6 (net +108) | 4 (net +122) | 3 (net +131) | 9 (net +208) | 0 | 19% (6 of 31) |
| Opponent | Warriors of Chaos | 24 | 2 (net +69) | 1 (net +407) | 3 (net -56) | 5 (net +54) | 1 (net +328) | 10 (net +243) | 2 | 14% (3 of 22) |
| Opponent | Wood Elf Realms | 36 | 7 (net +47) | 1 (net +190) | 4 (net +3) | 4 (net +81) | 3 (net +71) | 10 (net +142) | 7 | 14% (4 of 29) |

### Charged fights, damage counted: co-h2h-mine-324c342-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 191 | 244 | +45 | 70 | 24 | +46 | +24.2 |
| Mine | 50-54% | 3 | 108 | 120 | +17 | 51 | 20 | +31 | +28.3 |
| Mine | Effective (55-75%) | 18 | 245 | 181 | +52 | 134 | 52 | +83 | +33.7 |
| Mine | 76-89% | 18 | 284 | 158 | +4 | 60 | 60 | -0 | -0.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 232 | 149 | +70 | 86 | 25 | +61 | +26.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 18 | 415 | 86 | +56 | 104 | 30 | +74 | +17.9 |
| Mine | No odds | 11 | 220 | 84 | -5 | 46 | 34 | +12 | +5.3 |
| Mine | All fights | 105 | 266 | 146 | +42 | 86 | 37 | +49 | +18.4 |
| Opponent | Long shot (under 50%) | 28 | 234 | 250 | -21 | 143 | 165 | -22 | -9.3 |
| Opponent | 50-54% | 3 | 243 | 220 | +179 | 235 | 75 | +160 | +65.9 |
| Opponent | Effective (55-75%) | 18 | 296 | 206 | +11 | 137 | 125 | +12 | +4.1 |
| Opponent | 76-89% | 24 | 272 | 189 | +117 | 141 | 20 | +121 | +44.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 282 | 211 | +189 | 224 | 32 | +192 | +68.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 480 | 98 | +93 | 100 | 22 | +78 | +16.3 |
| Opponent | No odds | 16 | 215 | 194 | +82 | 109 | 30 | +79 | +36.8 |
| Opponent | All fights | 137 | 278 | 204 | +90 | 159 | 69 | +90 | +32.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-h2h-mine-324c342-p2 | move | 438 | 96 (22%) | 65 (15%) | 69 (16%) | 273 (62%) |
| co-h2h-mine-324c342-p2 | objective | 371 | 60 (16%) | 41 (11%) | 53 (14%) | 258 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

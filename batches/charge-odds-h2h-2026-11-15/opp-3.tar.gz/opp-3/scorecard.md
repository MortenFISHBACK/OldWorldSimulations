# Doctrine scorecard: co-h2h-opp-324c342-p3

### Scorecard: co-h2h-opp-324c342-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 65 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 12 | 3 | 1 | 2 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 5 | 1 | 3 | 1 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 0 | 2 | 1 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 4 | 4 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 479 |
| L0429 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 2 | 7 | 1 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 1 | 5 | 0 | 0 | 2 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 929 |
| L0620 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | no | - | 4 | 3 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 781 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 2 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 0 | 2 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 498 |
| L1216 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 475 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 2 | 2 | 0 | 0 | 190 |
| L1422 | 6 | 1 | Mine | no | 10 | 2 | 3 | 1 | 1 | 0 | 0 | 123 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 297 |
| L1519 | 1 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 641 |
| L1731 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 0 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | 2 | 0 | 6 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 9 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 7 | 4 | 3 | 1 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 6 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 144 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 1 | 0 | 0 | 127 |
| L2832 | 6 | 1 | Opponent | no | 3 | 1 | 3 | 3 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 2 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 3.2 | 2.7 | 2.0 | 1.0 | 0.3 | 0.0 | 0.0 | 271.6 |
| **Average** | | | Opponent | 28% | 3.0 | 2.2 | 3.0 | 1.7 | 0.5 | 0.0 | 0.0 | 165.5 |

### KPIs: co-h2h-opp-324c342-p3

Rules off - Mine only: JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 174) | 8% (14 of 174) | 15% (52 of 348) |
| Winner chose to follow up after the loser gave ground |  | 100% (57 of 57); on the table 100% | 100% (50 of 50); on the table 100% | 100% (107 of 107); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 82% (9 of 11); on the table 82% | 90% (19 of 21); on the table 90% |
| Winner chose to pursue after the loser fled |  | 79% (15 of 19); on the table 79% | 84% (26 of 31); on the table 84% | 82% (41 of 50); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 95% (82 of 86); on the table 95% | 92% (85 of 92); on the table 92% | 94% (167 of 178); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 27% (94 of 342) | 34% (66 of 192) | 30% (160 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (94 of 208) | 48% (66 of 137) | 46% (160 of 345) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (12 of 20) | 48% (32 of 66) | 51% (44 of 86) |
| Points that never fought | lower | 37% (25646 of 68801) | 40% (29099 of 71990) | 39% (54745 of 140791) |
|   infantry points that never fought | lower | 46% (6478 of 14174) | 59% (8386 of 14220) | 52% (14864 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (147 of 272) | 58% (164 of 285) | 56% (311 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.4 uses a game | 96% (23 of 24); 2.5 uses a game | 94% (46 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 0.1 uses a game | 50% (3 of 6); 0.1 uses a game | 30% (6 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 53% (18 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29198 of 59391) | 51% (32596 of 64043) | 50% (61794 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (17%) | 0.9 (26%) | 2.1 (20%) |
| MARCHED: its unit marched | 1.5 (22%) | 0.8 (23%) | 2.3 (22%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.8 (25%) | 0.8 (21%) | 2.5 (24%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.2 (5%) | 0.2 (2%) |
| GONE: slain | 1.9 (27%) | 0.5 (14%) | 2.4 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.1 | 1.0 | 1.9 | 4.4 | 0.6 | 2.2 |
| not cast | 3.8 | 1.6 | 4.3 | 10.4 | 2.7 | 18.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (46%) | 0.5 (11%) | 2.1 (20%) | 0.5 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (22%) | 0.5 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (10%) | 0.2 (12%) | 0.9 (20%) | 2.5 (24%) | 0.6 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (4%) | 0.4 (9%) | 0.3 (3%) | 0.2 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (7%) | 0.1 (1%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.8 (21%) | 0.2 (12%) | 1.0 (23%) | 2.4 (23%) | 0.4 (15%) | 2.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (4%) | 0.1 (3%) | 0.1 (1%) | 0.1 (4%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.3 (11%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (56%) | 0.2 (12%) | 1.4 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.5 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 46% (16 of 35) | 76% (13 of 17) | 56% (29 of 52) |
| the unit moved after it | 81% (13 of 16) | 62% (8 of 13) | 72% (21 of 29) |
| it charged on its next turn | 6% (1 of 16) | 8% (1 of 13) | 7% (2 of 29) |
| the enemy charged it first | 6% (1 of 16) | 0% (0 of 13) | 3% (1 of 29) |
| it fought by the end of its next turn | 0% (0 of 16) | 0% (0 of 13) | 0% (0 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 16) | 0% (0 of 13) | 7% (2 of 29) |
| none of these (no charge, no fight, no charge escaped) | 75% (12 of 16) | 92% (12 of 13) | 83% (24 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (490 of 760) | 62% (383 of 617) | 63% (873 of 1377) |
|   cavalry | 64% (35 of 55) | 65% (79 of 121) | 65% (114 of 176) |
|   character | 56% (49 of 87) | 25% (30 of 119) | 38% (79 of 206) |
|   chariot | 50% (44 of 88) | 77% (20 of 26) | 56% (64 of 114) |
|   infantry | 53% (121 of 228) | 70% (187 of 267) | 62% (308 of 495) |
|   monster | 24% (7 of 29) | 100% (1 of 1) | 27% (8 of 30) |
|   war machine | 86% (234 of 273) | 80% (66 of 83) | 84% (300 of 356) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (32%) | 1.5 (23%) | 3.9 (28%) |
| CHARGED: it charged | 1.0 (13%) | 1.7 (26%) | 2.6 (19%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (8%) | 0.6 (9%) | 1.2 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.0 (13%) | 0.6 (9%) | 1.6 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (7%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 1.2 (19%) | 2.5 (18%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.2 (3%) | 0.4 (3%) |
| OTHER BAR | 0.3 (4%) | 0.2 (3%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 0.9 | 86% | 4.4 pts | 22 pts |
| character | 2.5 | 0.9 | 79% | 9.6 pts | 24 pts |
| chariot | 1.8 | 0.6 | 80% | 11.3 pts | 20 pts |
| infantry | 12.9 | 4.8 | 74% | 9.4 pts | 121 pts |
| monster | 0.2 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 8.7 | 8.1 | 59% | 28.6 pts | 248 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 5.5 | 4.6 |
| Charges that made contact a game | 2.9 | 3.8 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.71 contact (24 units) | 0.88 declared, 0.76 contact (17 units) | 0.85 declared, 0.73 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.00 contact (4 units) | 1.11 declared, 0.67 contact (9 units) | 1.23 declared, 0.77 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.38 contact (221 units) | 0.65 declared, 0.45 contact (265 units) | 0.57 declared, 0.42 contact (486 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (42 of 77) | 53% (8 of 15) | 30% (3 of 10) | 52% (53 of 102) |
| Character in a unit | 77% (34 of 44) | 60% (12 of 20) | 50% (3 of 6) | 70% (49 of 70) |
| Character on its own | 85% (28 of 33) | 44% (16 of 36) | 30% (21 of 69) | 47% (65 of 138) |
| Chariot | 82% (9 of 11) | 92% (11 of 12) | - | 87% (20 of 23) |
| Infantry | 60% (42 of 70) | 38% (16 of 42) | 20% (1 of 5) | 50% (59 of 117) |
| Monster | 65% (22 of 34) | 57% (4 of 7) | - | 63% (26 of 41) |
| Monstrous | 80% (8 of 10) | 64% (7 of 11) | - | 71% (15 of 21) |
| War Machines | 51% (22 of 43) | 100% (2 of 2) | - | 53% (24 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (9 of 9); on the table 100% | 25% (24 of 96) | 27% | 50% (11 of 22) | 83% (5 of 6); 4.5 uses a game | 0% (0 of 2); 0.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (12 of 12); on the table 100% | 33% (12 of 36) | 36% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 58% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 91% (10 of 11); on the table 91% | 53% (16 of 30) | 55% | 59% (35 of 59) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 95% (19 of 20); on the table 95% | 33% (64 of 192) | 40% | 49% (36 of 74) | 94% (17 of 18); 5.0 uses a game | 0% (0 of 4); 0.0 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 100% (13 of 13); on the table 100% | 29% (12 of 42) | 40% | 56% (30 of 54) | 100% (9 of 9); 2.9 uses a game | 42% (5 of 12); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (8 of 8); on the table 100% | - | 51% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 50% (1 of 2); on the table 50% | 83% (5 of 6) | 13% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 26% | 29% (2 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 2% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 83% (5 of 6); on the table 83% | 17% (2 of 12) | 66% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 94% (17 of 18); on the table 94% | 0% (0 of 6) | 25% | 62% (16 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (26 of 26); on the table 100% | 28% (15 of 54) | 30% | 50% (23 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 91% (30 of 33); on the table 91% | 27% (8 of 30) | 35% | 59% (57 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 78% (7 of 9); on the table 78% | 8% (1 of 12) | 56% | 68% (42 of 62) | 91% (10 of 11); 7.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-h2h-opp-324c342-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (39) | 47% (35) | 47% (74) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.50 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.28 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.44 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.56 | 1.19 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.92 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.44 | 5.06 | 10.50 |

### Quality by phase: co-h2h-opp-324c342-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (65 of 125) | 46% (78 of 168) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (181 of 359) | 50% (109 of 217) |
| Strategy | Close-in objectives charged next turn | 13% (20 of 153) | 17% (38 of 221) |
| Strategy | Support requests answered (helper made contact too) | 77% (10 of 13) | 33% (6 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (6 of 6) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 43% (3 of 7) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 46% (23 of 50) | 37% (17 of 46) |
| Strategy | Lone characters that fought | 73% (62 of 85) | 75% (66 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 271.6 | 165.5 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 82, net +44 | 28 of 101, net +39 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 82, net +176 | 18 of 101, net +134 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 82, net +104 | 8 of 101, net +37 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 82, net +73 | 21 of 101, net +88 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.8 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (122 of 280) | 42% (156 of 372) |
| Shooting | Points destroyed by shooting units | 71.4 | 69.4 |
| Shooting | War machine shots | 6.5 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (123 of 234) | 36% (28 of 78) |
| Shooting | Points destroyed by war machines | 110.0 | 5.6 |
| Magic | Magic missiles cast | 1.8 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (18 of 63) | 20% (9 of 45) |
| Magic | Wounds caused by magic missiles | 3.2 | 2.8 |
| Magic | Wounds caused by other spells | 2.3 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 51.9 | 55.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.2 / 1.1 / 0.0 | 1.9 / 0.2 / 0.3 / 0.4 |
| Combat | Points destroyed in combat | 330.9 | 330.6 |
| Combat | Points run down | 55.3 | 159.3 |
| Combat | Net points per charged fight, damage counted | +86 | +85 |
| Combat | Net per 100 charger points, damage counted | +26.2 | +29.4 |
| Combat | First round won (charged fights) | 74% | 72% |
| Combat | Net points per charged fight | +90 | +90 |
| Combat | Net points per supported fight / lone fight | +98 / +89 | +104 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 93 | 50 of 117 |
| Game | Points lost | 746.9 | 668.1 |
| Game | VP from objectives | 458.3 | 632.5 |
| Game | Lone holders (player turns) | 3.2 | 3.0 |

- Mine won / drew / lost: 14 / 5 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -269 VP
- The side that went first won 13 of 31 games with a winner
- Points traded per game (both sides' losses): 1415
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-h2h-opp-324c342-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 29.2 | 0.2 | +0.0 | 0.0 | 8.1 |
| BACKUP TARGETS | 1.1 | +7.6 | 0.0 | 32.0 | 0.7 | +5.1 | 0.0 | 47.7 |
| BEST FACING | 0.6 | +20.5 | 0.0 | 22.6 | 0.5 | +23.6 | 0.0 | 34.1 |
| BEST FIRST | 4.2 | +205.5 | 166.3 | 76.9 | 2.9 | +120.5 | 106.9 | 73.2 |
| BEST OVERALL | 0.5 | +32.2 | 0.0 | 0.0 | 0.5 | +38.2 | 0.0 | 17.9 |
| BEST PREY | 0.7 | +24.7 | 18.5 | 4.0 | 0.5 | +20.4 | 6.1 | 5.4 |
| BEST PRIZE | 0.0 | +2.7 | 2.9 | 0.0 | 0.1 | -3.9 | 2.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.8 | 0.0 | 13.1 | 0.3 | -0.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +0.3 | 0.0 | 0.0 | 0.3 | +10.5 | 0.0 | 1.2 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -57.4 | 86.0 | 0.0 |
| BOMBING RUN | 0.1 | +0.5 | 1.5 | 8.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 49.9 | 8.8 | 0.3 | +0.0 | 32.4 | 4.6 |
| CANNON PLANNED TARGET | 5.9 | +211.2 | 456.5 | 103.2 | 1.1 | +36.3 | 74.6 | 40.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.3 | 5.2 | 2.5 | 0.1 | +0.0 | 2.4 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -5.7 | 9.8 | 6.0 | 0.2 | -2.9 | 62.9 | 3.2 |
| CAST JOB | 0.6 | +16.3 | 1.9 | 15.4 | 0.6 | +8.6 | 28.7 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +11.8 | 22.4 | 6.1 | 0.1 | +3.4 | 11.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 11.0 | 0.5 | +0.0 | 0.0 | 6.5 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.7 | 0.0 | 0.0 | 0.2 | -0.4 | 0.0 | 2.2 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 248.2 | 92.9 | 2.5 | +0.0 | 275.4 | 96.4 |
| CHARGE NOW WEIGHED | 0.3 | -11.6 | 8.1 | 17.1 | 0.4 | -49.7 | 16.7 | 16.2 |
| CHARGER SLAIN LOST | - | - | - | - | 0.8 | -14.7 | 61.3 | 35.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 52.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.7 |
| COMBAT PIVOT | 0.5 | +0.0 | 7.6 | 62.3 | 0.5 | +0.0 | 14.4 | 9.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 11.9 |
| CONVEYANCE SEARCH | 0.9 | +97.2 | 5.2 | 0.0 | 0.4 | +34.2 | 8.3 | 18.3 |
| COUNTER-CHARGE COVER | 9.1 | +690.4 | 0.0 | 204.4 | 7.4 | +643.2 | 0.0 | 186.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 45.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +4.2 | 4.7 | 6.1 | 0.1 | +4.2 | 4.7 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.3 | 13.6 | 0.0 | 0.4 | +6.0 | 30.8 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +85.1 | 0.0 | 63.3 | 1.2 | +83.4 | 0.0 | 47.3 |
| FALLBACK BY WORTH | 5.0 | +64.5 | 0.0 | 115.7 | 5.4 | +46.3 | 0.0 | 35.4 |
| FIGHT LIFT | 0.1 | +1.1 | 0.8 | 0.0 | 0.0 | +1.4 | 7.3 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 167.1 | 4.9 | +0.0 | 0.0 | 115.2 |
| FOCUS FIRE | - | - | - | - | 0.1 | +3.7 | 1.2 | 1.7 |
| FOLLOW UP WEIGHED | 1.1 | +167.5 | 0.0 | 72.3 | 0.9 | +130.0 | 0.0 | 15.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +17.0 | 0.0 | 31.6 | 0.2 | +22.2 | 0.0 | 12.0 |
| GIVES UP | 0.1 | -1.8 | 0.0 | 0.0 | 0.1 | -1.9 | 15.2 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.2 | 1.9 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 4.7 | 1.7 | 0.4 | +0.0 | 19.9 | 21.7 |
| HILL BY ITS CHANCE | 0.1 | -16.7 | 0.0 | 0.0 | 0.4 | -42.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +12.4 | 4.6 | 5.2 | 0.1 | +3.4 | 6.1 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 9.2 | 5.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +13.8 | 0.0 | 5.4 | 0.5 | +33.5 | 0.0 | 24.6 |
| HUNT KEPT | 0.1 | +4.8 | 4.6 | 3.8 | 0.2 | +6.3 | 17.6 | 2.9 |
| HUNT RESULT | 0.1 | +0.0 | 9.2 | 5.3 | 0.2 | +11.0 | 15.5 | 5.0 |
| HUNT THE GUNS | 0.1 | +55.4 | 0.0 | 2.9 | 0.2 | +52.8 | 1.9 | 0.8 |
| INVITES THE FIGHT | 1.4 | +33.1 | 88.1 | 29.2 | 1.2 | +25.0 | 61.3 | 13.3 |
| JOINT CHARGE PLAN | 0.2 | +21.0 | 0.0 | 3.8 | 0.4 | +18.7 | 38.1 | 17.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.0 | -1.5 | 0.0 | 3.2 |
| KEEP FALLS | 0.1 | +3.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +0.9 | 0.0 | 9.4 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +40.8 | 72.8 | 13.9 | 2.1 | +64.2 | 247.2 | 15.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +69.4 | 133.3 | 65.2 | 2.1 | +96.0 | 173.9 | 35.0 |
| KILLS COUNT NEXT TURN | 5.4 | +206.6 | 133.1 | 154.8 | 7.6 | +261.6 | 322.4 | 186.6 |
| LONE CHARACTER SAFE SPOT | 0.4 | +15.2 | 0.0 | 0.0 | 0.3 | +5.8 | 10.3 | 25.8 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 13.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -7.5 | 22.4 | 8.1 | 0.3 | -0.7 | 6.3 | 0.0 |
| LOST CHARGE | 2.5 | -43.1 | 93.0 | 89.1 | 2.3 | -33.5 | 101.1 | 116.5 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +66.6 | 7.1 | 25.2 | 1.0 | +55.3 | 77.9 | 35.9 |
| MANOEUVRE | 0.3 | +22.7 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +52.1 | 0.0 | 16.3 | 1.0 | +48.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +28.1 | 13.6 | 0.0 | 0.2 | +11.8 | 5.8 | 0.0 |
| MARCH OVER CASTS | 0.7 | +66.4 | 0.0 | 10.2 | 0.4 | +0.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.5 | +168.4 | 0.0 | 134.8 | 3.9 | +158.6 | 0.0 | 133.6 |
| MISSILES IN THE MOVE | 3.7 | +116.5 | 0.0 | 113.4 | 4.2 | +68.0 | 0.0 | 83.2 |
| MISSILES NEXT TURN | 4.9 | +81.3 | 0.0 | 139.1 | 5.1 | +48.7 | 0.0 | 110.2 |
| MODEL FACING | 0.1 | +21.6 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 9.6 | 0.0 | 0.4 | +0.0 | 43.8 | 0.0 |
| MOVE AND CAST | 0.2 | +18.1 | 0.0 | 10.0 | 0.6 | +33.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -12.1 | 0.0 | 35.6 | 0.1 | -1.9 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 6.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.2 | +270.4 | 65.2 | 114.3 | 5.4 | +338.7 | 282.8 | 166.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +9.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +4.0 | 0.0 | 3.4 | - | - | - | - |
| NOT NEEDED | 0.4 | -27.1 | 36.8 | 3.3 | 0.2 | -14.1 | 13.1 | 0.0 |
| NOT TURNED | 5.4 | +67.8 | 0.0 | 143.3 | 5.1 | +46.1 | 0.0 | 93.8 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 31.0 | 0.8 | -1.0 | 0.0 | 5.3 |
| OFF BEST | 15.3 | -845.6 | 0.0 | 334.4 | 14.4 | -829.7 | 6.4 | 289.4 |
| OPENS A LANE | 0.0 | +0.0 | 12.1 | 0.0 | 0.1 | +1.6 | 2.5 | 0.0 |
| OPENS UP | 0.2 | +21.5 | 15.0 | 30.1 | 0.1 | +3.5 | 5.6 | 0.0 |
| OVERRUNS AWAY | 0.5 | +14.4 | 42.4 | 36.4 | 0.7 | +6.4 | 72.1 | 36.7 |
| PATHS CROSS | 2.1 | +171.1 | 0.0 | 17.2 | 2.2 | +143.8 | 0.0 | 15.4 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -2.0 | 0.0 | 1.4 | 0.1 | -4.1 | 0.0 | 13.3 |
| PLAN RESULT | 35.9 | +1280.2 | 1265.9 | 1021.1 | 37.0 | +1399.4 | 1663.2 | 929.2 |
| PURSUES BIG PREY | 0.0 | -3.1 | 0.0 | 0.0 | 0.0 | -0.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.6 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +6.7 | 0.0 | 18.9 | 1.8 | +24.5 | 0.0 | 49.4 |
| RANDOM MOVER NO PROMISE | 0.1 | -3.0 | 0.0 | 4.7 | 0.7 | -37.7 | 13.1 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -6.9 | 0.0 | 7.4 | 0.8 | -16.3 | 0.0 | 7.6 |
| REDIRECT COUNTER | 2.1 | +172.8 | 0.0 | 62.2 | 3.4 | +258.5 | 0.0 | 60.4 |
| REDIRECT WEIGHED | 0.2 | +9.0 | 4.9 | 13.6 | 0.3 | +2.8 | 9.4 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +5.9 | 0.0 | 17.0 | 1.2 | +44.8 | 0.0 | 10.2 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +87.2 | 180.2 | 89.5 | 2.7 | +63.6 | 252.8 | 85.7 |
| SAFER THAN THE JOB | 0.9 | +64.7 | 0.0 | 10.4 | 0.9 | +53.2 | 0.0 | 19.6 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.1 | 0.0 | 0.0 | 0.2 | -15.2 | 0.0 | 1.1 |
| SEARCH SPOT | 2.8 | +129.0 | 0.0 | 61.0 | 2.1 | +100.2 | 0.0 | 28.3 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +79.2 | 0.0 | 40.1 | 0.1 | +51.6 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.2 | +112.0 | 14.7 | 35.4 | 2.2 | +138.8 | 140.8 | 102.9 |
| SET-UP ANY TARGET | 0.4 | +72.4 | 0.0 | 0.0 | 0.2 | +13.0 | 0.0 | 6.5 |
| SET-UP MISSED | 0.1 | +8.0 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +37.9 | 62.2 | 15.9 | 0.5 | +14.3 | 36.0 | 7.6 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 87.7 | 6.1 | 0.3 | +0.0 | 59.6 | 0.0 |
| SHOTS IN THE MOVE | 13.8 | +639.1 | 0.0 | 250.5 | 10.0 | +340.7 | 0.0 | 170.2 |
| SPELL SETS UP CHARGE | 0.7 | +138.1 | 0.0 | 0.0 | 0.2 | +13.0 | 0.0 | 6.5 |
| SPELL WORTH | 1.4 | +21.2 | 48.2 | 37.6 | 2.4 | +30.5 | 70.1 | 62.8 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -5.9 | 66.3 | 10.5 |
| STABLE ROLE | 9.5 | +0.0 | 333.8 | 211.2 | 8.4 | +0.0 | 317.2 | 122.7 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +2.2 | 0.0 | 1.5 | 0.1 | +10.2 | 0.0 | 0.0 |
| STOPS | 0.1 | +1.7 | 0.0 | 0.0 | 0.2 | +7.6 | 8.1 | 3.7 |
| STOPS SHORT OF THE FLANK | 0.6 | +36.6 | 0.0 | 24.9 | 0.4 | +30.3 | 0.0 | 11.1 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.7 | -51.6 | 253.9 | 112.6 | 5.5 | -34.2 | 317.9 | 71.2 |
| SUPPORTS | 4.1 | +62.7 | 132.6 | 62.2 | 3.5 | +34.2 | 141.7 | 43.3 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.9 | 3.8 | 0.0 | 0.1 | -3.0 | 16.8 | 11.9 |
| SURE REACH TOGETHER | 0.3 | +3.2 | 0.0 | 17.3 | 0.8 | -0.1 | 6.4 | 45.6 |
| THROUGH LINE OF FIRE | 0.4 | +5.7 | 0.0 | 12.9 | 0.4 | +18.2 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -46.4 | 43.7 | 22.3 | 0.4 | -28.0 | 32.7 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +2.6 | 0.0 | 1.2 | 0.7 | +4.1 | 56.2 | 41.5 |
| WAIT AFTER COSTS | 6.6 | -303.0 | 195.0 | 212.5 | 8.0 | -388.4 | 395.8 | 183.6 |
| WALKS TO THE FIGHT | 1.8 | +37.9 | 27.4 | 52.5 | 0.9 | +13.0 | 28.5 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +19.3 | 12.3 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 26.2 | 42.4 | 0.1 | +0.0 | 0.0 | 7.5 |
| WEARS DOWN | 0.8 | +38.9 | 61.3 | 35.4 | 0.9 | +50.5 | 114.6 | 47.4 |
| WHO HITS BACK | 0.2 | +27.2 | 0.0 | 0.0 | 0.2 | +12.6 | 0.0 | 5.4 |
| WHOLE FIGHT | 0.2 | +16.6 | 46.4 | 12.0 | 0.5 | +42.7 | 59.7 | 28.4 |
| WHOLE FIGHT GAIN | 0.4 | +42.1 | 22.2 | 5.0 | 0.5 | +27.0 | 42.9 | 7.9 |
| WIDER SPREAD | - | - | - | - | 3.4 | -9.0 | 327.8 | 52.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 5.2 | 0.0 |

### Rule changes: co-h2h-opp-324c342-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1068 | 1068 | 1068 | 29.67 | -60309 | -56.5 |
| BEST FIRST | 253 | 253 | 253 | 7.03 | +11734 | +46.4 |
| SEARCH SPOT | 174 | 174 | 173 | 4.81 | +8251 | +47.7 |
| PATHS CROSS | 156 | 156 | 156 | 4.33 | +11336 | +72.7 |
| MOVE TO CHARGE | 310 | 310 | 146 | 4.06 | +9006 | +61.7 |
| COUNTER-CHARGE COVER | 593 | 319 | 137 | 3.81 | +8625 | +63.0 |
| KILLS COUNT NEXT TURN | 467 | 467 | 110 | 3.06 | +2448 | +22.3 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +6067 | +61.3 |
| SUPPORTS | 276 | 276 | 92 | 2.56 | +918 | +10.0 |
| SHOTS IN THE MOVE | 857 | 573 | 81 | 2.25 | +3034 | +37.5 |
| ARTILLERY RE-ROLL WEIGHED | 80 | 80 | 80 | 2.22 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 73 | 73 | 73 | 2.03 | +10709 | +146.7 |
| FALLBACK BY WORTH | 373 | 373 | 72 | 2.00 | +3987 | +55.4 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +4243 | +63.3 |
| RESERVE FALL BACK | 63 | 63 | 63 | 1.75 | +1826 | +29.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| WAIT AFTER COSTS | 526 | 526 | 55 | 1.53 | +892 | +16.2 |
| MARCH CHECK | 64 | 59 | 51 | 1.42 | +3574 | +70.1 |
| WALKS TO THE FIGHT | 96 | 96 | 49 | 1.36 | +738 | +15.1 |
| CANNON PLANNED TARGET | 254 | 254 | 47 | 1.31 | -766 | -16.3 |
| RISK BY ARC | 182 | 176 | 47 | 1.31 | +1346 | +28.6 |
| SET UP TOGETHER | 121 | 101 | 47 | 1.31 | +2594 | +55.2 |
| RANDOM MOVE BY FIGURES | 86 | 86 | 44 | 1.22 | +1125 | +25.6 |
| REDIRECT COUNTER | 197 | 104 | 42 | 1.17 | +3486 | +83.0 |
| MISSILES IN THE MOVE | 286 | 169 | 40 | 1.11 | +748 | +18.7 |
| BEST FACING | 39 | 39 | 39 | 1.08 | +1587 | +40.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| BEST OVERALL | 38 | 38 | 38 | 1.06 | +2535 | +66.7 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 38 | 38 | 38 | 1.06 | +2410 | +63.4 |
| MAX FOR POSITIONING | 304 | 161 | 36 | 1.00 | +345 | +9.6 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW FIRST | 183 | 183 | 35 | 0.97 | -1739 | -49.7 |
| INVITES THE FIGHT | 93 | 93 | 35 | 0.97 | +492 | +14.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOT REPLANNED | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| KILLS COUNT | 136 | 131 | 29 | 0.81 | +1123 | +38.7 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1853 | +63.9 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +857 | +29.6 |
| CHARGE NOW WEIGHED | 25 | 25 | 25 | 0.69 | +2316 | +92.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CAST JOB | 43 | 43 | 24 | 0.67 | +408 | +17.0 |
| SHOOTS FROM THE BEST SPOT | 45 | 45 | 24 | 0.67 | +1038 | +43.2 |
| KEEPS ITS TARGET | 126 | 123 | 22 | 0.61 | +380 | +17.3 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +389 | +18.5 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +310 | +14.8 |
| MAKE SURE TOGETHER | 63 | 43 | 19 | 0.53 | +1291 | +67.9 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +359 | +18.9 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1411 | +78.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| BEST PREY | 44 | 44 | 17 | 0.47 | +339 | +20.0 |
| WHOLE FIGHT GAIN | 33 | 31 | 16 | 0.44 | +842 | +52.6 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1089 | +77.8 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -43 | -3.3 |
| MANOEUVRE | 13 | 13 | 13 | 0.36 | +842 | +64.8 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -40 | -3.3 |
| WHOLE FIGHT | 25 | 23 | 12 | 0.33 | +635 | +52.9 |
| WAR ENGINE JOBS | 24 | 24 | 11 | 0.31 | -351 | -31.9 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WEARS DOWN | 60 | 59 | 9 | 0.25 | +329 | +36.5 |
| CASTING BLOCK | 11 | 11 | 8 | 0.22 | +230 | +28.7 |
| MISSILES NEXT TURN | 361 | 206 | 8 | 0.22 | +45 | +5.7 |
| OPENS UP | 11 | 10 | 8 | 0.22 | +360 | +45.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OVERRUNS AWAY | 43 | 43 | 7 | 0.19 | +166 | +23.7 |
| JOINT CHARGE PLAN | 22 | 22 | 6 | 0.17 | +369 | +61.4 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +280 | +46.7 |
| LOST CHARGE | 172 | 172 | 6 | 0.17 | +177 | +29.4 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -220 | -36.6 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +147 | +24.5 |
| HUNT IN PAIRS | 26 | 16 | 5 | 0.14 | +304 | +60.7 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +447 | +89.4 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -139 | -27.8 |
| CARRIES OUT SET-UP | 14 | 14 | 4 | 0.11 | -311 | -77.8 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +134 | +33.4 |
| LONG SHOT | 25 | 25 | 4 | 0.11 | +20 | +5.0 |
| STOPS | 8 | 8 | 4 | 0.11 | +165 | +41.2 |
| SUPPORT NARROWED | 401 | 401 | 4 | 0.11 | -41 | -10.2 |
| SURE REACH TOGETHER | 42 | 29 | 4 | 0.11 | +10 | +2.5 |
| WAR ENGINE CHARGES | 4 | 4 | 4 | 0.11 | +402 | +100.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -315 | -105.1 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| DEFENSIVE FLOOR | 5 | 5 | 3 | 0.08 | +69 | +22.9 |
| HUNT ADVANCE | 11 | 11 | 3 | 0.08 | +94 | +31.3 |
| REDIRECT BY WHAT IT STOPS | 38 | 38 | 3 | 0.08 | +67 | +22.4 |
| WIDER SPREAD | 123 | 119 | 3 | 0.08 | +12 | +4.1 |
| BACKUP TARGETS | 63 | 27 | 2 | 0.06 | +3 | +1.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +18 | +9.2 |
| CARRIES OUT COUNTER | 6 | 6 | 2 | 0.06 | -45 | -22.6 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -122 | -60.8 |
| DEFENSIVE ARMY | 11 | 11 | 2 | 0.06 | -141 | -70.4 |
| EDGE GIVE GROUND | 17 | 17 | 2 | 0.06 | +55 | +27.7 |
| MODEL FACING | 2 | 2 | 2 | 0.06 | +777 | +388.5 |
| MOVE SPELL IN RANGE | 9 | 8 | 2 | 0.06 | +56 | +27.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +39 | +19.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +109 | +54.4 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -132 | -66.2 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +309 | +154.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -7 | -7.2 |
| CHARGER SLAIN LOST | 30 | 30 | 1 | 0.03 | +35 | +35.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | -88 | -88.2 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.03 | -0 | -0.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +86 | +85.7 |
| STANDS TO CAST | 2 | 2 | 1 | 0.03 | -38 | -37.5 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -42 | -42.4 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 13 | 13 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 371 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 23 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 20 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 29 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 378 | 378 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2624 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 30 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 24 | 23 | 0 | 0.00 | - | - |
| STABLE ROLE | 647 | 645 | 0 | 0.00 | - | - |
| TURN WORTH | 32 | 30 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 38 | 35 | 0 | 0.00 | - | - |

### Off best figure: co-h2h-opp-324c342-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.53 | 12.97 | 56.7 |
| FALLBACK | gate | 0.64 | 0.64 | 60.1 |
| TURN GATE | gate | 0.67 | 0.47 | 52.6 |
| CHARGE NOW FIRST | rule | 0.58 | 0.39 | 49.7 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.03 | 78.1 |
| WAR ENGINE JOBS | rule | 0.25 | 0.06 | 31.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.11 | 53.1 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 3.2 |
| CHAFF PASSED | rule | 0.08 | 0.11 | 5.6 |
| PATHS CROSS | rule | 0.08 | 0.08 | 48.4 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.14 | 36.6 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.08 | 16.0 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.11 | 16.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.11 | 27.8 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.06 | 77.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 22.0 |
| SUPPORT REQUEST | gate | 0.03 | 0.08 | 135.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 48.3 |
| MARCH ODDS | rule | 0.03 | 0.06 | 10.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 19.6 |
| SUPPORT NARROWED | rule | - | 0.08 | 13.4 |
| BEST PRIZE | rule | 0.03 | 0.03 | 157.6 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 22.6 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 60.8 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 70.4 |
| FIGHT ORDER BAND | gate | 0.06 | - | 3.6 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 66.2 |
| BLOCKED WHEEL | rule | - | 0.03 | 2.1 |
| CATCH ODDS | rule | - | 0.03 | 7.2 |
| FACES THE THREAT | rule | - | 0.03 | 6.1 |
| FALLBACK BY WORTH | rule | - | 0.03 | 2.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.1 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 88.2 |
| LONG SHOT | rule | 0.03 | - | 3.0 |
| REDIRECT WEIGHED | rule | - | 0.03 | 244.5 |
| RULE SWITCHED OFF | gate | 0.03 | - | 6.8 |
| SAFER THAN THE JOB | rule | - | 0.03 | 15.9 |
| STANDS TO CAST | rule | - | 0.03 | 37.5 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 42.4 |

### Plans: co-h2h-opp-324c342-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.1 | 17% | 391 | 292 | 75% |
| Mine | charge | 2.8 | 61% | 269 | 242 | 90% |
| Mine | close in | 4.2 | 24% | 357 | 132 | 37% |
| Mine | hold | 4.4 | 29% | 281 | 0 | 0% |
| Mine | join | 0.5 | 95% | 17 | 0 | 0% |
| Mine | shoot | 8.5 | 59% | 257 | 614 | 239% |
| Mine | support | 4.3 | 90% | 40 | 0 | 0% |
| Opponent | advance | 12.5 | 19% | 355 | 401 | 113% |
| Opponent | charge | 3.9 | 65% | 415 | 404 | 97% |
| Opponent | close in | 6.1 | 24% | 407 | 210 | 51% |
| Opponent | hold | 4.0 | 28% | 263 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 33 | 0 | 0% |
| Opponent | shoot | 5.2 | 60% | 143 | 385 | 270% |
| Opponent | support | 4.4 | 85% | 34 | 0 | 0% |

### Packages: hunt the guns, co-h2h-opp-324c342-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 0% | 0% | 0% | - | 399 | 0 | 0% | 23 |
| Opponent | 0.2 | 7 | 1 | 50% | 50% | 0% | 3.3 | 276 | 66 | 17% | 120 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 405 | 0 | 0% | 29 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 375 | 0 | 0% | 78 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 143 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 316 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.5 | 3 | 1 | 50% | 50% | 0% | 3.0 | 315 | 62 | 0% | 77 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 76 | 73 | 100% | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 447 | 0 | 0% | 109 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 4.0 | 251 | 98 | 0% | 6 |

### Battle groups: co-h2h-opp-324c342-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.1 | 22% | 49% | 18% | 38% | 29% | 14% | 8% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 29% | 73% | 5% | 100% | 19% | 5% | 0% | 76% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.4 | 16% | 65% | 23% | 10% | 30% | 3% | 9% | 58% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 27% | 70% | 18% | 17% | 30% | 0% | 7% | 59% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-h2h-opp-324c342-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 42 (34) | 16 | 26 | 61 | 32% | 2.9 | 47 (21) | 20 (4) | 36 (9) | 62 (24) | 0 (10) |
| Mine | Character | 119 | 45 (119) | 45 | 0 | 31 | 18% | 2.4 | 69 (37) | 36 (61) | 26 (8) | 44 (58) | 52 (48) |
| Mine | Clean-up | 18 | 37 (18) | 8 | 29 | 47 | 39% | 2.3 | 42 (3) | 34 (13) | 52 (2) | 49 (12) | 19 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 29 (44) | 13 | 16 | 47 | 32% | 2.8 | 24 (22) | 33 (14) | 35 (8) | 29 (30) | 28 (14) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 33 | 33% | 4.0 | 10 (3) | - | - | 29 (1) | 0 (2) |
| Mine | Hammer | 52 | 39 (52) | 23 | 17 | 44 | 17% | 2.6 | 28 (14) | 35 (35) | 125 (3) | 43 (36) | 31 (16) |
| Mine | Holder | 25 | 46 (25) | 7 | 39 | 46 | 36% | 3.8 | 57 (7) | 38 (13) | 63 (5) | 64 (12) | 26 (13) |
| Mine | Shooter | 37 | 58 (37) | 37 | 22 | 45 | 3% | 1.8 | 36 (6) | 61 (28) | 72 (3) | 61 (23) | 54 (14) |
| Mine | Support | 4 | 76 (4) | 76 | 0 | 0 | 25% | 2.0 | 0 (1) | 132 (3) | - | - | 76 (4) |
| Mine | War machine | 52 | 66 (52) | 66 | 0 | 42 | 2% | 1.1 | 97 (13) | 49 (36) | 133 (3) | 77 (13) | 63 (39) |
| Mine | Wizard | 16 | 1 (16) | 1 | 0 | 30 | 19% | 2.1 | 0 (5) | 5 (6) | 0 (2) | 0 (7) | 3 (6) |
| Opponent | Blocker | 1 | 574 (1) | 574 | 0 | 0 | 0% | 6.0 | 574 (1) | - | - | 574 (1) | - |
| Opponent | Chaff | 68 | 53 (68) | 19 | 34 | 51 | 44% | 2.6 | 51 (29) | 66 (11) | 49 (28) | 67 (48) | 19 (20) |
| Opponent | Character | 102 | 51 (102) | 51 | 0 | 31 | 19% | 2.1 | 44 (36) | 63 (56) | 0 (5) | 56 (56) | 52 (41) |
| Opponent | Clean-up | 12 | 64 (12) | 22 | 42 | 19 | 25% | 4.0 | 28 (4) | 73 (7) | 130 (1) | 49 (6) | 74 (6) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 37 (59) | 20 | 18 | 49 | 25% | 2.7 | 25 (29) | 61 (20) | 24 (10) | 52 (27) | 23 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 27 (47) | 21 | 6 | 33 | 32% | 2.9 | 4 (16) | 34 (28) | 42 (3) | 29 (29) | 23 (18) |
| Opponent | Holder | 40 | 102 (40) | 36 | 66 | 24 | 35% | 2.6 | 56 (9) | 133 (20) | 118 (9) | 106 (28) | 112 (10) |
| Opponent | Shooter | 30 | 49 (30) | 30 | 18 | 29 | 0% | 1.3 | 36 (8) | 43 (20) | 230 (2) | 44 (18) | 56 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 50% | 5.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | War machine | 17 | 41 (17) | 41 | 0 | 55 | 6% | 1.4 | 82 (3) | 0 (10) | 106 (4) | 0 (3) | 48 (14) |
| Opponent | Wizard | 32 | 16 (32) | 16 | 0 | 36 | 12% | 2.4 | 29 (14) | 2 (7) | 0 (2) | 27 (14) | 0 (9) |

### Charged fights: co-h2h-opp-324c342-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 44 | 167 | 1.5 | 1.0 | 112 | 5 | +106 | 0 of 6 | 5 of 6 | - | +106 |
| Mine | Chaos Dwarfs | 4 | 201 | 340 | 3.8 | 1.2 | 91 | 12 | +79 | 9 of 15 | 11 of 15 | +356 | +9 |
| Mine | Dwarfen Mountain Holds | 3 | 594 | 107 | 2.3 | 1.4 | 46 | 35 | +11 | 0 of 7 | 3 of 7 | -20 | +34 |
| Mine | Empire of Man | 5 | 468 | 59 | 1.0 | 1.0 | 59 | 0 | +59 | 0 of 5 | 4 of 5 | - | +59 |
| Mine | Grand Cathay | 5 | 426 | 190 | 3.2 | 1.2 | 59 | 14 | +45 | 4 of 16 | 12 of 16 | +66 | +39 |
| Mine | High Elf Realms | 4 | 120 | 276 | 2.5 | 1.0 | 111 | 0 | +111 | 4 of 10 | 8 of 10 | - | +111 |
| Mine | Kingdom of Bretonnia | 1 | 38 | 532 | 3.0 | 1.7 | 177 | 92 | +85 | 0 of 3 | 2 of 3 | -277 | +266 |
| Mine | Lizardmen | 1 | 0 | 837 | 4.0 | 1.5 | 209 | 0 | +209 | 2 of 4 | 2 of 4 | +72 | +346 |
| Mine | Ogre Kingdoms | 1 | 311 | 421 | 3.0 | 1.3 | 140 | 0 | +140 | 2 of 3 | 2 of 3 | +251 | +85 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 274 | 4.0 | 1.0 | 68 | 28 | +41 | 1 of 4 | 3 of 4 | - | +41 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 158 | 873 | 6.5 | 1.0 | 134 | 5 | +129 | 3 of 13 | 10 of 13 | - | +129 |
| Mine | Vampire Counts | 2 | 0 | 486 | 2.0 | 1.2 | 243 | 0 | +243 | 1 of 4 | 4 of 4 | +80 | +298 |
| Mine | Warriors of Chaos | 2 | 0 | 15 | 1.5 | 1.0 | 10 | 0 | +10 | 0 of 3 | 2 of 2 | - | +10 |
| **Mine** | all armies | 36 | 233 | 264 | 2.6 | 1.2 | 102 | 12 | +90 | 26 of 93 | 68 of 92 | +98 | +89 |
| Opponent | Empire of Man | 1 | 238 | 380 | 1.0 | 1.0 | 380 | 104 | +276 | 1 of 1 | 0 of 1 | - | +276 |
| Opponent | Grand Cathay | 3 | 300 | 508 | 3.3 | 1.0 | 152 | 16 | +136 | 2 of 10 | 7 of 10 | - | +136 |
| Opponent | High Elf Realms | 3 | 260 | 356 | 3.0 | 1.2 | 119 | 57 | +62 | 5 of 9 | 9 of 9 | -81 | +103 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 192 | 1.0 | 1.0 | 192 | 40 | +152 | 1 of 2 | 2 of 2 | - | +152 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 435 | 6.0 | 1.2 | 72 | 42 | +30 | 2 of 6 | 4 of 6 | +176 | +1 |
| Opponent | Skaven | 1 | 335 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 262 | 528 | 3.2 | 1.2 | 163 | 33 | +129 | 7 of 13 | 9 of 13 | +158 | +124 |
| Opponent | Vampire Counts | 6 | 9 | 554 | 4.7 | 1.2 | 119 | 34 | +85 | 13 of 28 | 20 of 28 | +77 | +87 |
| Opponent | Warriors of Chaos | 9 | 22 | 475 | 3.4 | 1.2 | 138 | 49 | +90 | 13 of 31 | 22 of 31 | +191 | +74 |
| Opponent | Wood Elf Realms | 6 | 189 | 297 | 2.7 | 1.0 | 111 | 45 | +67 | 5 of 16 | 11 of 15 | - | +67 |
| **Opponent** | all armies | 36 | 130 | 425 | 3.2 | 1.1 | 131 | 40 | +90 | 50 of 117 | 84 of 116 | +104 | +89 |

### Effective charges: co-h2h-opp-324c342-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net -30) | 0 | 0 | 0 | 0 | 2 (net +20) | 3 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 15 | 2 (net +0) | 0 | 1 (net +465) | 7 (net -3) | 0 | 4 (net +140) | 1 | 7% (1 of 14) |
| Mine | Dwarfen Mountain Holds | 7 | 2 (net +0) | 1 (net +0) | 1 (net -60) | 1 (net -60) | 0 | 2 (net +97) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +99) | 1 | 0% (0 of 4) |
| Mine | Grand Cathay | 16 | 0 | 1 (net +0) | 5 (net +73) | 0 | 4 (net +28) | 5 (net +23) | 1 | 33% (5 of 15) |
| Mine | High Elf Realms | 10 | 1 (net +365) | 0 | 3 (net +82) | 1 (net +60) | 1 (net +54) | 3 (net +103) | 1 | 33% (3 of 9) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +190) | 0 | 0 | 1 (net -277) | 1 (net +342) | 0 | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 1 (net +693) | 0 | 2 (net +72) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 2 (net +126) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +137) | 3 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +0) | 0 | 1 (net +494) | 5 (net +116) | 4 (net +140) | 2 (net +20) | 0 | 8% (1 of 13) |
| Mine | Vampire Counts | 4 | 0 | 0 | 1 (net +608) | 1 (net +285) | 1 (net +80) | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 3 | 2 (net +0) | 1 (net +30) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 1 | 1 (net +276) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 10 | 2 (net +428) | 0 | 2 (net +168) | 3 (net +54) | 1 (net +0) | 1 (net -77) | 1 | 22% (2 of 9) |
| Opponent | High Elf Realms | 9 | 2 (net -174) | 0 | 1 (net +0) | 2 (net +204) | 0 | 2 (net +82) | 2 | 14% (1 of 7) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net +137) | 0 | 0 | 1 (net +168) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +199) | 1 (net +176) | 0 | 4 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 4 (net -16) | 0 | 2 (net +0) | 2 (net +426) | 2 (net +158) | 2 (net +175) | 1 | 17% (2 of 12) |
| Opponent | Vampire Counts | 28 | 10 (net +34) | 0 | 6 (net +149) | 4 (net +206) | 3 (net -93) | 3 (net +103) | 2 | 23% (6 of 26) |
| Opponent | Warriors of Chaos | 31 | 6 (net -16) | 2 (net +155) | 6 (net +126) | 7 (net +173) | 1 (net +83) | 9 (net +56) | 0 | 19% (6 of 31) |
| Opponent | Wood Elf Realms | 16 | 1 (net +0) | 0 | 1 (net +432) | 4 (net +43) | 0 | 4 (net +150) | 6 | 10% (1 of 10) |

### Charged fights, damage counted: co-h2h-opp-324c342-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 261 | 199 | +44 | 60 | 36 | +23 | +8.9 |
| Mine | 50-54% | 3 | 104 | 157 | +10 | 10 | 36 | -26 | -25.5 |
| Mine | Effective (55-75%) | 12 | 435 | 248 | +176 | 256 | 83 | +173 | +39.8 |
| Mine | 76-89% | 19 | 344 | 225 | +80 | 115 | 62 | +54 | +15.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 258 | 153 | +73 | 118 | 27 | +91 | +35.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 422 | 76 | +104 | 106 | 3 | +103 | +24.4 |
| Mine | No odds | 11 | 397 | 133 | +110 | 142 | 22 | +120 | +30.3 |
| Mine | All fights | 93 | 330 | 174 | +90 | 126 | 39 | +86 | +26.2 |
| Opponent | Long shot (under 50%) | 28 | 216 | 296 | +39 | 138 | 101 | +36 | +16.8 |
| Opponent | 50-54% | 2 | 427 | 402 | +155 | 155 | 0 | +155 | +36.3 |
| Opponent | Effective (55-75%) | 18 | 359 | 203 | +134 | 203 | 82 | +121 | +33.7 |
| Opponent | 76-89% | 24 | 286 | 197 | +167 | 198 | 32 | +166 | +58.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 271 | 199 | +88 | 119 | 49 | +70 | +25.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 580 | 110 | +37 | 107 | 80 | +27 | +4.7 |
| Opponent | No odds | 16 | 200 | 179 | +38 | 112 | 65 | +47 | +23.5 |
| Opponent | All fights | 117 | 289 | 217 | +90 | 151 | 67 | +85 | +29.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-h2h-opp-324c342-p3 | move | 428 | 81 (19%) | 65 (15%) | 58 (14%) | 289 (68%) |
| co-h2h-opp-324c342-p3 | objective | 374 | 58 (16%) | 35 (9%) | 53 (14%) | 263 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

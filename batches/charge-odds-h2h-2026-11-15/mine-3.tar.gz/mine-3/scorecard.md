# Doctrine scorecard: co-h2h-mine-324c342-p3

### Scorecard: co-h2h-mine-324c342-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 13 | 4 | 1 | 1 | 1 | 0 | 0 | 672 |
| L0126 | 6 | 1 | Opponent | no | 10 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 9 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 0 | 4 | 0 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 565 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 2 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 4 | 2 | 2 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 763 |
| L0516 | 6 | 1 | Opponent | no | 8 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | 6 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 5 | 2 | 4 | 0 | 2 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 726 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 751 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 5 | 1 | 0 | 0 | 0 | 0 | 617 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 841 |
| L0922 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 2 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 3 | 1 | 0 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 80 |
| L1122 | 6 | 1 | Mine | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 479 |
| L1327 | 1 | 1 | Opponent | no | 9 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 4 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 72 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 110 |
| L1633 | 1 | 1 | Mine | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 399 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 98 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 3 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 0 | 6 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 144 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 7 | 0 | 1 | 0 | 0 | 396 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 8 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 257 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 9 | 0 | 0 | 0 | 0 | 50 |
| L2433 | 3 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 129 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 144 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 2 | 3 | 0 | 1 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 34% | 2.1 | 2.7 | 3.1 | 0.8 | 0.3 | 0.0 | 0.0 | 347.6 |
| **Average** | | | Opponent | 22% | 3.0 | 2.3 | 3.2 | 1.3 | 0.5 | 0.0 | 0.0 | 158.3 |

### KPIs: co-h2h-mine-324c342-p3

Rules off - Opponent only: JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (47 of 177) | 12% (22 of 177) | 19% (69 of 354) |
| Winner chose to follow up after the loser gave ground |  | 99% (74 of 75); on the table 100% | 96% (43 of 45); on the table 98% | 98% (117 of 120); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 91% | 93% (13 of 14); on the table 93% | 88% (22 of 25); on the table 92% |
| Winner chose to pursue after the loser fled |  | 83% (15 of 18); on the table 83% | 70% (30 of 43); on the table 77% | 74% (45 of 61); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 94% (98 of 104); on the table 96% | 84% (86 of 102); on the table 88% | 89% (184 of 206); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 24% (81 of 342) | 29% (56 of 192) | 26% (137 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (81 of 197) | 43% (56 of 129) | 42% (137 of 326) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (9 of 18) | 47% (29 of 62) | 48% (38 of 80) |
| Points that never fought | lower | 33% (22804 of 68801) | 35% (24999 of 71990) | 34% (47803 of 140791) |
|   infantry points that never fought | lower | 39% (5545 of 14174) | 46% (6508 of 14220) | 42% (12053 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (152 of 272) | 60% (171 of 285) | 58% (323 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 84% (21 of 25); 1.4 uses a game | 88% (21 of 24); 2.1 uses a game | 86% (42 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.4 uses a game | 17% (1 of 6); 0.0 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 43% (6 of 14); 0.2 uses a game | 44% (15 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (28867 of 59391) | 55% (34912 of 64043) | 52% (63779 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (14%) | 0.9 (23%) | 1.9 (17%) |
| MARCHED: its unit marched | 1.7 (23%) | 0.8 (20%) | 2.4 (22%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.3 (7%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 2.6 (36%) | 0.8 (22%) | 3.5 (31%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 1.2 (17%) | 0.8 (20%) | 2.0 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 1.5 | 3.8 | 0.8 | 2.1 |
| not cast | 4.6 | 1.3 | 4.6 | 11.0 | 2.6 | 18.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.8 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.6 (49%) | 0.4 (8%) | 1.9 (17%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (22%) | 0.4 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | 0.2 (19%) | 1.2 (25%) | 3.5 (31%) | 0.6 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.5 (3%) |
| GONE: slain | 1.5 (34%) | 0.1 (9%) | 1.2 (26%) | 2.0 (18%) | 0.6 (24%) | 3.9 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (11%) | 0.0 (0%) | 0.1 (1%) | 0.4 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (46%) | 0.2 (13%) | 1.4 (30%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 59% (22 of 37) | 62% (8 of 13) | 60% (30 of 50) |
| the unit moved after it | 73% (16 of 22) | 62% (5 of 8) | 70% (21 of 30) |
| it charged on its next turn | 5% (1 of 22) | 12% (1 of 8) | 7% (2 of 30) |
| the enemy charged it first | 0% (0 of 22) | 12% (1 of 8) | 3% (1 of 30) |
| it fought by the end of its next turn | 5% (1 of 22) | 0% (0 of 8) | 3% (1 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (5 of 22) | 0% (0 of 8) | 17% (5 of 30) |
| none of these (no charge, no fight, no charge escaped) | 68% (15 of 22) | 75% (6 of 8) | 70% (21 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (509 of 801) | 61% (375 of 614) | 62% (884 of 1415) |
|   cavalry | 60% (38 of 63) | 59% (66 of 111) | 60% (104 of 174) |
|   character | 51% (54 of 106) | 21% (23 of 108) | 36% (77 of 214) |
|   chariot | 47% (48 of 102) | 74% (20 of 27) | 53% (68 of 129) |
|   infantry | 54% (113 of 211) | 69% (179 of 259) | 62% (292 of 470) |
|   monster | 42% (17 of 40) | 83% (5 of 6) | 48% (22 of 46) |
|   war machine | 86% (239 of 279) | 80% (82 of 103) | 84% (321 of 382) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (32%) | 1.3 (20%) | 3.9 (26%) |
| CHARGED: it charged | 1.2 (14%) | 1.7 (25%) | 2.8 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.8 (12%) | 1.6 (11%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (13%) | 0.7 (10%) | 1.7 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.6 (8%) | 1.1 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 1.1 (17%) | 2.4 (16%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.3 (4%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (4%) | 0.2 (3%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 0.8 | 83% | 5.4 pts | 25 pts |
| character | 2.4 | 0.4 | 88% | 3.1 pts | 8 pts |
| chariot | 1.9 | 0.9 | 78% | 9.0 pts | 17 pts |
| infantry | 12.8 | 4.1 | 77% | 9.1 pts | 116 pts |
| monster | 0.9 | 0.1 | 91% | 2.8 pts | 3 pts |
| war machine | 9.2 | 8.7 | 58% | 26.8 pts | 248 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 5.8 | 5.2 |
| Charges that made contact a game | 3.5 | 3.9 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.19 declared, 1.12 contact (26 units) | 1.15 declared, 0.75 contact (20 units) | 1.17 declared, 0.96 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.25 contact (4 units) | 1.75 declared, 1.38 contact (8 units) | 1.42 declared, 1.00 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.44 contact (219 units) | 0.64 declared, 0.42 contact (271 units) | 0.62 declared, 0.43 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (38 of 77) | 60% (9 of 15) | 20% (2 of 10) | 48% (49 of 102) |
| Character in a unit | 88% (30 of 34) | 60% (9 of 15) | 100% (5 of 5) | 81% (44 of 54) |
| Character on its own | 84% (36 of 43) | 56% (23 of 41) | 30% (21 of 70) | 52% (80 of 154) |
| Chariot | 82% (9 of 11) | 50% (6 of 12) | - | 65% (15 of 23) |
| Infantry | 64% (45 of 70) | 48% (20 of 42) | 20% (1 of 5) | 56% (66 of 117) |
| Monster | 68% (23 of 34) | 43% (3 of 7) | - | 63% (26 of 41) |
| Monstrous | 60% (6 of 10) | 64% (7 of 11) | - | 62% (13 of 21) |
| War Machines | 67% (29 of 43) | 50% (1 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (18 of 18); on the table 100% | 22% (21 of 96) | 18% | 59% (13 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 78% (7 of 9); on the table 89% | 31% (11 of 36) | 35% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 61% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (5 of 5); on the table 100% | 43% (13 of 30) | 49% | 68% (40 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 96% (24 of 25); on the table 100% | 26% (49 of 192) | 42% | 55% (41 of 74) | 78% (14 of 18); 4.5 uses a game | 0% (0 of 4); 0.0 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 7 | 94% (17 of 18); on the table 94% | 14% (6 of 42) | 32% | 46% (25 of 54) | 89% (8 of 9); 2.9 uses a game | 50% (6 of 12); 1.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (10 of 10); on the table 100% | - | 30% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 33% (2 of 6) | 30% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 100% | 0% (0 of 6) | 54% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 89% (8 of 9); on the table 89% | 25% (3 of 12) | 3% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 43% (3 of 7); on the table 71% | 8% (1 of 12) | 62% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 90% (19 of 21); on the table 90% | 17% (1 of 6) | 25% | 58% (15 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (16 of 18); on the table 89% | 39% (21 of 54) | 20% | 48% (22 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 86% (31 of 36); on the table 89% | 30% (9 of 30) | 33% | 55% (53 of 96) | 100% (4 of 4); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 82% (14 of 17); on the table 82% | 0% (0 of 12) | 38% | 71% (44 of 62) | 82% (9 of 11); 6.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-h2h-mine-324c342-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (39) | 47% (40) | 48% (79) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.72 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.19 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.47 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.19 | 3.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.33 | 0.75 | 2.08 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.25 | 5.56 | 10.81 |

### Quality by phase: co-h2h-mine-324c342-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (91 of 156) | 45% (81 of 180) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (189 of 356) | 52% (114 of 219) |
| Strategy | Close-in objectives charged next turn | 15% (25 of 169) | 19% (43 of 223) |
| Strategy | Support requests answered (helper made contact too) | 31% (4 of 13) | 39% (7 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 82% (9 of 11) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 51% (19 of 37) | 36% (13 of 36) |
| Strategy | Lone characters that fought | 78% (76 of 98) | 78% (76 of 98) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 0.8 | 1.3 |
| Movement | Points that never moved of their own | 347.6 | 158.3 |
| Movement | Fights charged into per game | 3.4 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 109, net +22 | 19 of 106, net +30 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 109, net +73 | 17 of 106, net +68 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 18 of 109, net +82 | 10 of 106, net +54 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 109, net +57 | 41 of 106, net +155 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.2 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (113 of 294) | 50% (176 of 352) |
| Shooting | Points destroyed by shooting units | 61.9 | 47.1 |
| Shooting | War machine shots | 6.6 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (122 of 239) | 47% (44 of 93) |
| Shooting | Points destroyed by war machines | 84.3 | 34.6 |
| Magic | Magic missiles cast | 1.5 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (14 of 53) | 40% (14 of 35) |
| Magic | Wounds caused by magic missiles | 2.9 | 2.1 |
| Magic | Wounds caused by other spells | 2.4 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 111.1 | 40.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.3 / 0.9 / 0.0 | 1.6 / 0.4 / 0.5 / 0.4 |
| Combat | Points destroyed in combat | 404.9 | 389.9 |
| Combat | Points run down | 45.6 | 158.3 |
| Combat | Net points per charged fight, damage counted | +62 | +95 |
| Combat | Net per 100 charger points, damage counted | +22.2 | +30.1 |
| Combat | First round won (charged fights) | 67% | 71% |
| Combat | Net points per charged fight | +60 | +94 |
| Combat | Net points per supported fight / lone fight | +218 / +46 | +177 / +81 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 123 | 56 of 118 |
| Game | Points lost | 777.9 | 728.6 |
| Game | VP from objectives | 467.2 | 575.0 |
| Game | Lone holders (player turns) | 2.1 | 3.0 |

- Mine won / drew / lost: 12 / 6 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -188 VP
- The side that went first won 15 of 30 games with a winner
- Points traded per game (both sides' losses): 1506
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-h2h-mine-324c342-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 44.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +10.2 | 0.0 | 30.9 | 0.9 | +12.2 | 0.0 | 24.2 |
| BEST FACING | 0.7 | +21.3 | 0.0 | 29.1 | 0.7 | +35.4 | 0.0 | 12.1 |
| BEST FIRST | 4.2 | +155.3 | 60.6 | 128.9 | 3.4 | +178.4 | 146.3 | 57.9 |
| BEST OVERALL | 0.9 | +49.3 | 0.0 | 13.1 | 0.6 | +53.6 | 0.0 | 9.8 |
| BEST PREY | 0.5 | +29.5 | 28.4 | 15.1 | 0.7 | +40.7 | 22.1 | 7.8 |
| BEST PRIZE | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | -1.4 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 7.1 | 0.0 | 0.1 | +0.0 | 12.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +1.6 | 0.0 | 20.3 | 0.3 | +11.6 | 0.0 | 0.8 |
| BLOWS WHERE AIMED | 0.1 | -28.6 | 9.9 | 5.4 | - | - | - | - |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 101.1 | 13.6 | 0.2 | +0.0 | 29.4 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +109.1 | 434.7 | 94.6 | 1.6 | +125.6 | 113.1 | 5.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -1.5 | 16.9 | 3.4 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 11.3 | 6.0 | 0.2 | -3.9 | 24.7 | 6.1 |
| CAST JOB | 0.7 | +20.4 | 54.7 | 7.6 | 0.6 | +19.1 | 32.9 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +20.6 | 11.9 | 31.6 | 0.1 | +0.6 | 3.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 22.9 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 2.9 | 0.1 | -0.6 | 11.0 | 2.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 205.3 | 110.5 | 3.1 | +0.0 | 307.7 | 124.9 |
| CHARGE NOW WEIGHED | 0.7 | -114.9 | 22.4 | 46.5 | 0.3 | -20.4 | 9.5 | 17.1 |
| CHARGER SLAIN LOST | 0.3 | -7.9 | 11.1 | 23.1 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 17.1 | 0.0 | 0.1 | +0.0 | 11.6 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 36.0 | 50.4 | 0.5 | +0.0 | 26.3 | 51.9 |
| CONVEYANCE SEARCH | 0.6 | +94.9 | 22.7 | 11.9 | 0.3 | +40.8 | 0.0 | 11.8 |
| COUNTER-CHARGE COVER | 7.9 | +654.8 | 0.0 | 216.1 | 7.2 | +689.0 | 0.0 | 186.7 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 15.0 | 2.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +5.9 | 11.1 | 1.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.1 | 4.2 | 0.0 | 0.4 | +13.0 | 29.8 | 5.1 |
| ELIXIR WORTH | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +157.9 | 0.0 | 79.1 | 1.2 | +112.3 | 0.0 | 32.0 |
| FALLBACK BY WORTH | 5.1 | +64.0 | 0.0 | 82.2 | 5.4 | +71.6 | 0.0 | 40.9 |
| FIGHT LIFT | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 1.7 |
| FIRE AND FLEE | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 185.1 | 5.4 | +0.0 | 0.0 | 159.5 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +111.5 | 0.0 | 52.0 | 1.3 | +181.3 | 0.0 | 67.9 |
| FRIENDS SHOTS CHECKED | 0.5 | +19.9 | 0.0 | 18.0 | 0.1 | +7.9 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.7 | 0.0 | 14.2 | 0.1 | -1.2 | 0.0 | 12.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 7.1 | 4.3 | 0.4 | +0.0 | 32.3 | 12.2 |
| HILL BY ITS CHANCE | 0.2 | -26.2 | 0.0 | 1.8 | 0.4 | -53.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.6 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.1 | +3.3 | 0.0 | 0.0 | 0.2 | +4.7 | 3.5 | 5.4 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 12.1 | 7.8 |
| HUNT IN PAIRS | 0.6 | +24.3 | 0.0 | 17.5 | 0.5 | +18.3 | 0.0 | 10.8 |
| HUNT KEPT | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 3.4 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.3 | 15.5 | 11.3 |
| HUNT THE GUNS | 0.1 | +33.9 | 0.0 | 0.0 | 0.2 | +90.6 | 15.5 | 5.4 |
| INVITES THE FIGHT | 1.6 | +28.5 | 70.8 | 14.9 | 1.2 | +24.8 | 59.4 | 12.3 |
| JOINT CHARGE PLAN | 0.1 | +1.9 | 0.0 | 0.0 | 0.2 | +4.2 | 4.8 | 11.9 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.8 | 0.0 | 7.5 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +55.0 | 101.5 | 43.6 | 2.4 | +73.3 | 224.9 | 54.4 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.0 | +80.7 | 133.0 | 57.4 | 2.4 | +140.7 | 182.6 | 74.2 |
| KILLS COUNT NEXT TURN | 5.9 | +184.0 | 143.4 | 127.6 | 7.6 | +231.5 | 275.7 | 200.4 |
| LONE CHARACTER SAFE SPOT | 0.5 | +8.3 | 13.9 | 13.3 | 0.4 | +16.9 | 26.1 | 24.7 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 1.7 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.9 | 27.4 | 9.2 | 0.2 | +0.2 | 2.9 | 8.2 |
| LOST CHARGE | 2.9 | -53.6 | 102.1 | 134.5 | 2.6 | -36.1 | 74.3 | 93.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.4 | 0.0 | 4.2 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +116.3 | 10.2 | 11.4 | 1.0 | +64.4 | 53.0 | 27.8 |
| MANOEUVRE | 0.2 | +4.1 | 0.0 | 6.6 | 0.1 | +1.2 | 0.0 | 1.5 |
| MARCH AT ESCAPER | 0.2 | +1.5 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 3.0 |
| MARCH CHECK | 0.6 | +25.2 | 0.0 | 8.1 | 0.6 | +36.6 | 0.0 | 15.2 |
| MARCH ODDS | 0.3 | +17.1 | 6.6 | 16.1 | 0.4 | +22.3 | 6.2 | 0.0 |
| MARCH OVER CASTS | 0.7 | +22.6 | 0.0 | 21.9 | 0.5 | +34.5 | 0.0 | 60.9 |
| MAX FOR POSITIONING | 4.2 | +168.5 | 0.0 | 85.8 | 4.5 | +177.7 | 0.0 | 126.4 |
| MISSILES IN THE MOVE | 3.6 | +118.2 | 0.0 | 128.2 | 3.9 | +71.2 | 0.0 | 47.2 |
| MISSILES NEXT TURN | 4.8 | +79.4 | 0.0 | 142.6 | 4.8 | +50.5 | 0.0 | 114.4 |
| MODEL FACING | 0.1 | +11.9 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 12.1 | 0.1 | +0.0 | 7.6 | 0.0 |
| MOVE AND CAST | 0.2 | +23.4 | 0.0 | 2.4 | 0.4 | +19.2 | 0.0 | 5.3 |
| MOVE SPELL IN RANGE | 0.2 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -37.1 | 6.6 | 76.4 | 0.1 | -1.9 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.6 | +288.5 | 109.2 | 57.0 | 5.2 | +571.0 | 214.0 | 158.6 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +4.9 | 0.0 | 2.2 | 0.1 | +7.1 | 8.5 | 0.0 |
| NO RALLY LEFT | 0.1 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -7.2 | 23.5 | 4.0 | 0.3 | -24.9 | 51.6 | 4.9 |
| NOT TURNED | 5.2 | +40.8 | 0.0 | 130.5 | 5.6 | +65.1 | 0.0 | 135.0 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 27.1 | 1.0 | -1.3 | 0.0 | 11.0 |
| OFF BEST | 15.3 | -759.9 | 13.7 | 330.6 | 14.2 | -908.5 | 7.6 | 267.4 |
| OPENS A LANE | 0.0 | +0.1 | 1.5 | 0.0 | 0.1 | +0.6 | 20.1 | 0.0 |
| OPENS UP | 0.2 | +17.8 | 8.1 | 28.1 | 0.2 | +18.7 | 14.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +6.6 | 40.7 | 0.0 | 0.5 | +5.7 | 72.8 | 37.5 |
| PATHS CROSS | 2.1 | +108.4 | 0.0 | 8.5 | 2.4 | +182.9 | 0.0 | 82.7 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -1.2 | 0.0 | 0.0 | 0.2 | -6.2 | 0.0 | 0.0 |
| PLAN RESULT | 37.1 | +1312.5 | 1289.1 | 1076.3 | 36.6 | +1182.5 | 1529.5 | 945.8 |
| PURSUES BIG PREY | 0.1 | -4.0 | 0.0 | 0.0 | 0.1 | -22.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 3.4 | 0.0 | +4.9 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.6 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.5 | +8.3 | 0.0 | 9.4 | 1.7 | +16.7 | 0.0 | 43.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.7 | 0.0 | 4.7 | 0.5 | -26.3 | 28.7 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -3.8 | 0.0 | 4.2 | 0.5 | -19.8 | 0.0 | 1.4 |
| REDIRECT COUNTER | 1.9 | +104.9 | 0.0 | 29.5 | 3.6 | +284.7 | 0.0 | 53.7 |
| REDIRECT WEIGHED | 0.2 | +3.5 | 3.5 | 1.1 | 0.4 | +5.7 | 8.2 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.5 | +12.5 | 0.0 | 3.7 | 0.9 | +31.9 | 0.0 | 16.9 |
| RESTRAINS TO SHOOT | 0.1 | +2.1 | 0.0 | 1.8 | 0.1 | +4.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.8 | +118.5 | 160.5 | 94.9 | 3.0 | +86.2 | 249.2 | 117.0 |
| SAFER THAN THE JOB | 1.3 | +74.7 | 0.0 | 33.2 | 0.8 | +42.1 | 0.0 | 6.8 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +0.7 | 0.0 | 0.9 | 0.1 | -5.4 | 0.0 | 1.1 |
| SEARCH SPOT | 2.3 | +89.1 | 0.0 | 48.1 | 2.7 | +139.5 | 0.0 | 40.0 |
| SELF MOVE SPELL | 0.4 | +33.2 | 0.0 | 40.1 | 0.1 | +21.9 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.2 | +139.2 | 25.7 | 11.4 | 1.5 | +117.7 | 53.0 | 36.0 |
| SET-UP ANY TARGET | 0.3 | +44.0 | 0.0 | 0.0 | 0.2 | +19.2 | 0.0 | 6.5 |
| SET-UP MISSED | 0.1 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.6 | +34.1 | 18.9 | 3.4 | 0.6 | +42.6 | 35.8 | 6.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.8 | +0.0 | 178.8 | 27.1 | 0.1 | +0.0 | 5.2 | 0.0 |
| SHOTS IN THE MOVE | 13.6 | +506.4 | 0.0 | 267.3 | 9.6 | +416.6 | 0.0 | 123.7 |
| SPELL SETS UP CHARGE | 0.4 | +74.7 | 22.7 | 11.9 | 0.2 | +19.2 | 0.0 | 6.5 |
| SPELL WORTH | 1.2 | +22.7 | 38.6 | 38.6 | 2.0 | +30.3 | 81.1 | 76.9 |
| SPELLS IN THE FIGHT | 0.6 | -6.3 | 71.1 | 22.4 | - | - | - | - |
| STABLE ROLE | 10.5 | +0.0 | 332.2 | 193.6 | 9.1 | +0.0 | 342.6 | 132.2 |
| STANDS TO CAST | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +3.2 | 12.1 | 3.4 |
| STOPS SHORT OF THE FLANK | 0.5 | +25.0 | 0.0 | 25.6 | 0.3 | +29.7 | 0.0 | 5.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.2 | -33.2 | 268.2 | 91.3 | 6.0 | -41.0 | 316.0 | 134.6 |
| SUPPORTS | 3.2 | +38.1 | 114.8 | 27.0 | 3.7 | +41.0 | 166.5 | 53.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.3 | 4.0 | 0.0 | 0.0 | -1.5 | 2.0 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +6.0 | 7.9 | 14.0 | 0.5 | +0.7 | 8.7 | 12.4 |
| THROUGH LINE OF FIRE | 0.6 | +12.4 | 0.0 | 27.2 | 0.3 | +25.1 | 0.0 | 6.6 |
| TURN WORTH | 0.6 | -42.1 | 35.3 | 15.9 | 0.5 | -44.4 | 38.9 | 3.8 |
| TWO OR MORE ARRIVE | 0.4 | +3.3 | 7.9 | 1.2 | 0.4 | +4.1 | 14.2 | 0.0 |
| WAIT AFTER COSTS | 7.2 | -315.5 | 222.2 | 95.8 | 8.0 | -504.3 | 289.3 | 212.0 |
| WALKS TO THE FIGHT | 1.6 | +30.2 | 24.7 | 21.6 | 1.0 | +16.1 | 6.5 | 14.4 |
| WAR ENGINE CHARGES | 0.1 | +19.9 | 23.1 | 8.6 | 0.0 | +0.3 | 0.0 | 2.1 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 37.7 | 6.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.1 | +50.9 | 103.5 | 47.5 | 1.3 | +46.0 | 166.9 | 74.4 |
| WHO HITS BACK | 0.3 | +20.0 | 0.0 | 2.0 | 0.2 | +19.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +19.4 | 60.3 | 2.2 | 0.4 | +40.0 | 43.2 | 6.8 |
| WHOLE FIGHT GAIN | 0.1 | +8.2 | 1.1 | 4.2 | 0.4 | +30.6 | 57.1 | 1.2 |
| WIDER SPREAD | 2.7 | -6.7 | 206.5 | 101.2 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |

### Rule changes: co-h2h-mine-324c342-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1061 | 1061 | 1061 | 29.47 | -60062 | -56.6 |
| BEST FIRST | 273 | 273 | 273 | 7.58 | +12014 | +44.0 |
| MOVE TO CHARGE | 316 | 316 | 184 | 5.11 | +13940 | +75.8 |
| SEARCH SPOT | 180 | 180 | 177 | 4.92 | +8229 | +46.5 |
| PATHS CROSS | 162 | 162 | 162 | 4.50 | +10486 | +64.7 |
| COUNTER-CHARGE COVER | 546 | 297 | 132 | 3.67 | +8646 | +65.5 |
| FACES THE THREAT | 115 | 115 | 115 | 3.19 | +9729 | +84.6 |
| KILLS COUNT NEXT TURN | 485 | 485 | 108 | 3.00 | +2339 | +21.7 |
| ARTILLERY RE-ROLL WEIGHED | 90 | 90 | 90 | 2.50 | +0 | +0.0 |
| FALLBACK BY WORTH | 378 | 378 | 86 | 2.39 | +4882 | +56.8 |
| SUPPORTS | 249 | 249 | 83 | 2.31 | +714 | +8.6 |
| FOLLOW UP WEIGHED | 82 | 82 | 82 | 2.28 | +10540 | +128.5 |
| SHOTS IN THE MOVE | 835 | 554 | 82 | 2.28 | +2427 | +29.6 |
| SAFER THAN THE JOB | 75 | 75 | 75 | 2.08 | +4204 | +56.1 |
| WAIT AFTER COSTS | 546 | 546 | 74 | 2.06 | +1528 | +20.6 |
| MAX FOR POSITIONING | 313 | 176 | 59 | 1.64 | +892 | +15.1 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| BEST OVERALL | 53 | 53 | 53 | 1.47 | +3706 | +69.9 |
| BEST FACING | 51 | 51 | 51 | 1.42 | +2042 | +40.0 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +1596 | +31.3 |
| WALKS TO THE FIGHT | 94 | 94 | 50 | 1.39 | +707 | +14.1 |
| CANNON PLANNED TARGET | 262 | 262 | 46 | 1.28 | -371 | -8.1 |
| REDIRECT COUNTER | 197 | 108 | 43 | 1.19 | +2667 | +62.0 |
| RISK BY ARC | 209 | 202 | 43 | 1.19 | +1351 | +31.4 |
| COMBAT PIVOT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| MISSILES IN THE MOVE | 267 | 161 | 40 | 1.11 | +932 | +23.3 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| CHARGE NOW FIRST | 210 | 210 | 38 | 1.06 | -2351 | -61.9 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 38 | 1.06 | +901 | +23.7 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +4238 | +114.5 |
| MARCH CHECK | 46 | 43 | 37 | 1.03 | +2481 | +67.1 |
| SET UP TOGETHER | 96 | 85 | 37 | 1.03 | +2214 | +59.8 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 159 | 156 | 35 | 0.97 | +1506 | +43.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| THROUGH LINE OF FIRE | 33 | 33 | 33 | 0.92 | +1350 | +40.9 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| CAST JOB | 47 | 47 | 28 | 0.78 | +647 | +23.1 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +1968 | +70.3 |
| MARCH ODDS | 25 | 25 | 25 | 0.69 | +369 | +14.8 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| INVITES THE FIGHT | 101 | 101 | 24 | 0.67 | +308 | +12.8 |
| KEEPS ITS TARGET | 154 | 151 | 23 | 0.64 | +375 | +16.3 |
| SHOOTS FROM THE BEST SPOT | 44 | 44 | 23 | 0.64 | +1339 | +58.2 |
| FRIENDS SHOTS CHECKED | 22 | 22 | 22 | 0.61 | +1002 | +45.6 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +1533 | +69.7 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +858 | +39.0 |
| MAKE SURE TOGETHER | 63 | 53 | 21 | 0.58 | +1266 | +60.3 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +868 | +43.4 |
| BLOCKED WHEEL | 19 | 19 | 19 | 0.53 | +475 | +25.0 |
| WEARS DOWN | 89 | 86 | 19 | 0.53 | +749 | +39.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| BEST PREY | 44 | 44 | 16 | 0.44 | +570 | +35.6 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 11 | 0.31 | +463 | +42.1 |
| MANOEUVRE | 13 | 13 | 11 | 0.31 | +193 | +17.6 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.25 | -67 | -7.4 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -26 | -2.9 |
| OPENS UP | 16 | 16 | 8 | 0.22 | +568 | +71.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -264 | -33.0 |
| SUPPORT NARROWED | 405 | 405 | 8 | 0.22 | -260 | -32.4 |
| WAR ENGINE JOBS | 28 | 28 | 8 | 0.22 | -178 | -22.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +216 | +30.8 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +217 | +31.0 |
| WHOLE FIGHT | 29 | 28 | 7 | 0.19 | +562 | +80.3 |
| BACKUP TARGETS | 70 | 31 | 6 | 0.17 | +33 | +5.5 |
| HUNT IN PAIRS | 37 | 21 | 6 | 0.17 | +274 | +45.6 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -969 | -161.5 |
| WHOLE FIGHT GAIN | 19 | 17 | 6 | 0.17 | +266 | +44.2 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 5 | 0.14 | -384 | -76.9 |
| LOST CHARGE | 199 | 198 | 5 | 0.14 | +67 | +13.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -173 | -34.6 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 345 | 198 | 4 | 0.11 | +5 | +1.2 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +27 | +8.8 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +94 | +31.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +73 | +24.4 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +430 | +143.3 |
| WAR ENGINE CHARGES | 6 | 6 | 3 | 0.08 | +256 | +85.2 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -141 | -70.6 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -229 | -114.4 |
| MOVE SPELL IN RANGE | 7 | 5 | 2 | 0.06 | +22 | +10.9 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +142 | +71.2 |
| OVERRUNS AWAY | 33 | 32 | 2 | 0.06 | +18 | +9.1 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -35 | -17.4 |
| SURE REACH TOGETHER | 36 | 28 | 2 | 0.06 | +64 | +31.9 |
| TWO OR MORE ARRIVE | 28 | 26 | 2 | 0.06 | +4 | +2.0 |
| WIDER SPREAD | 97 | 91 | 2 | 0.06 | +2 | +1.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -45 | -44.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CARRIES OUT COUNTER | 5 | 5 | 1 | 0.03 | -54 | -54.3 |
| DEFENSIVE ARMY | 10 | 10 | 1 | 0.03 | -8 | -7.7 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +148 | +147.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +42 | +41.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +12 | +11.8 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 22 | 21 | 1 | 0.03 | +75 | +74.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +154 | +153.8 |
| REFUSING RETIRES | 9 | 9 | 1 | 0.03 | -1 | -0.9 |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 1 | 0.03 | +23 | +22.8 |
| STOPS | 7 | 7 | 1 | 0.03 | +24 | +24.3 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 11 | 8 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 35 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 19 | 19 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 395 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 25 | 25 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 10 | 10 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 11 | 11 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 33 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 44 | 44 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 389 | 389 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 56 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2651 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 24 | 24 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 18 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 116 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 21 | 18 | 0 | 0.00 | - | - |
| STABLE ROLE | 705 | 705 | 0 | 0.00 | - | - |
| TURN WORTH | 40 | 39 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: co-h2h-mine-324c342-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.50 | 12.58 | 58.4 |
| FALLBACK | gate | 0.72 | 0.61 | 46.7 |
| CHARGE NOW FIRST | rule | 0.61 | 0.44 | 61.9 |
| TURN GATE | gate | 0.47 | 0.50 | 38.2 |
| PATHS CROSS | rule | 0.28 | 0.11 | 41.0 |
| AFTERMATH BAND | gate | 0.11 | 0.17 | 2.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.17 | 54.9 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.08 | 46.1 |
| SUPPORT REQUEST | gate | 0.19 | 0.06 | 100.1 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.11 | 34.9 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.19 | 33.0 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 37.0 |
| WAR ENGINE JOBS | rule | 0.14 | 0.06 | 25.5 |
| CHAFF PASSED | rule | 0.06 | 0.11 | 4.3 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 161.5 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.03 | 14.1 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 1.1 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.11 | 76.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.03 | 34.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 44.4 |
| MARCH ODDS | rule | 0.03 | 0.08 | 18.3 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 5.0 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 16.1 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 70.6 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 114.4 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 11.2 |
| STANDS TO CAST | rule | 0.06 | - | 17.4 |
| BEST PRIZE | rule | 0.03 | - | 44.9 |
| BLOCKED WHEEL | rule | 0.03 | - | 7.5 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 54.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 7.7 |
| NO REASON | gate | 0.03 | - | 10.7 |
| REFUSING RETIRES | rule | 0.03 | - | 0.9 |
| WHO HITS BACK | rule | - | 0.03 | 3.2 |

### Plans: co-h2h-mine-324c342-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 14% | 400 | 220 | 55% |
| Mine | charge | 3.6 | 58% | 332 | 294 | 88% |
| Mine | close in | 4.7 | 22% | 367 | 138 | 38% |
| Mine | hold | 4.7 | 35% | 302 | 0 | 0% |
| Mine | join | 0.5 | 100% | 13 | 0 | 0% |
| Mine | shoot | 8.4 | 58% | 185 | 661 | 358% |
| Mine | support | 3.4 | 93% | 28 | 0 | 0% |
| Opponent | advance | 12.3 | 17% | 438 | 289 | 66% |
| Opponent | charge | 4.2 | 49% | 502 | 366 | 73% |
| Opponent | close in | 6.1 | 27% | 522 | 214 | 41% |
| Opponent | hold | 3.8 | 29% | 256 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 36 | 0 | 0% |
| Opponent | shoot | 5.1 | 60% | 183 | 313 | 171% |
| Opponent | support | 4.1 | 85% | 24 | 0 | 0% |

### Packages: hunt the guns, co-h2h-mine-324c342-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 305 | 0 | 0% | 53 |
| Opponent | 0.2 | 9 | 1 | 0% | 0% | 12% | - | 370 | 1 | 0% | 114 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 0% | 0% | 0% | - | 334 | 0 | 0% | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 306 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Kingdom of Bretonnia | 0.7 | 2 | 1 | 0% | 0% | 0% | - | 445 | 0 | 0% | 157 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 220 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 100% | - | 441 | 9 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 302 |
| Tomb Kings of Khemri | 0.7 | 4 | 0 | 0% | 0% | 0% | - | 384 | 0 | 0% | 89 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 271 | 0 | 0% | 63 |

### Battle groups: co-h2h-mine-324c342-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.9 | 28% | 47% | 14% | 45% | 28% | 15% | 12% | 46% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 30% | 90% | 5% | 100% | 16% | 0% | 5% | 74% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 20% | 66% | 21% | 45% | 45% | 14% | 10% | 31% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 32% | 81% | 19% | 12% | 24% | 0% | 12% | 56% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-h2h-mine-324c342-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 133 (1) | 133 | 0 | 0 | 0% | 5.0 | - | 133 (1) | - | 133 (1) | - |
| Mine | Chaff | 34 | 65 (34) | 22 | 43 | 60 | 15% | 3.3 | 96 (21) | 6 (4) | 6 (9) | 97 (24) | 0 (10) |
| Mine | Character | 118 | 48 (118) | 48 | 0 | 37 | 19% | 2.3 | 78 (38) | 34 (55) | 38 (10) | 54 (61) | 50 (42) |
| Mine | Clean-up | 20 | 42 (20) | 10 | 31 | 34 | 40% | 2.8 | 44 (5) | 34 (13) | 124 (2) | 52 (14) | 19 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 28 (44) | 15 | 12 | 52 | 23% | 3.0 | 15 (22) | 34 (14) | 51 (8) | 35 (30) | 15 (14) |
| Mine | Fragile | 3 | 5 (3) | 5 | 0 | 100 | 33% | 5.5 | 5 (3) | - | - | 15 (1) | 0 (2) |
| Mine | Hammer | 50 | 37 (50) | 30 | 7 | 51 | 14% | 2.4 | 7 (12) | 45 (35) | 49 (3) | 43 (34) | 25 (16) |
| Mine | Holder | 25 | 41 (25) | 1 | 39 | 17 | 48% | 3.2 | 20 (8) | 54 (12) | 28 (5) | 56 (14) | 20 (11) |
| Mine | Shooter | 37 | 58 (37) | 32 | 26 | 49 | 5% | 1.9 | 21 (6) | 64 (28) | 68 (3) | 54 (23) | 64 (14) |
| Mine | Support | 4 | 126 (4) | 126 | 0 | 0 | 0% | 3.0 | 0 (1) | 218 (3) | - | 123 (3) | 139 (1) |
| Mine | War machine | 52 | 63 (52) | 63 | 0 | 35 | 2% | 1.1 | 66 (13) | 67 (36) | 0 (3) | 50 (13) | 67 (39) |
| Mine | Wizard | 17 | 34 (17) | 34 | 0 | 62 | 12% | 2.1 | 43 (3) | 0 (5) | 312 (1) | 93 (5) | 37 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 41 (68) | 12 | 30 | 54 | 34% | 2.9 | 25 (29) | 57 (11) | 46 (28) | 50 (48) | 20 (20) |
| Opponent | Character | 101 | 66 (101) | 66 | 0 | 38 | 19% | 2.1 | 68 (37) | 75 (50) | 0 (7) | 77 (56) | 57 (38) |
| Opponent | Clean-up | 9 | 43 (9) | 11 | 32 | 41 | 44% | 3.2 | 0 (3) | 54 (5) | 111 (1) | 32 (5) | 54 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 46 (60) | 26 | 20 | 38 | 27% | 2.8 | 60 (30) | 31 (20) | 32 (10) | 49 (28) | 43 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 35 (50) | 19 | 16 | 38 | 28% | 2.9 | 20 (17) | 42 (30) | 0 (3) | 34 (30) | 35 (20) |
| Opponent | Holder | 42 | 68 (42) | 9 | 59 | 38 | 29% | 3.1 | 47 (12) | 99 (21) | 21 (8) | 89 (28) | 34 (13) |
| Opponent | Shooter | 27 | 49 (27) | 24 | 25 | 38 | 0% | 1.1 | 0 (6) | 41 (19) | 413 (2) | 51 (16) | 47 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 25% | 5.3 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 93 (17) | 93 | 0 | 16 | 0% | 1.5 | 300 (3) | 76 (10) | 15 (4) | 292 (3) | 58 (14) |
| Opponent | Wizard | 33 | 23 (33) | 23 | 0 | 41 | 15% | 2.3 | 0 (13) | 83 (8) | 0 (2) | 8 (13) | 63 (10) |

### Charged fights: co-h2h-mine-324c342-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 32 | 70 | 1.2 | 1.0 | 56 | 6 | +50 | 1 of 5 | 4 of 5 | - | +50 |
| Mine | Chaos Dwarfs | 4 | 277 | 380 | 3.0 | 1.2 | 127 | 84 | +43 | 8 of 12 | 8 of 12 | +215 | +9 |
| Mine | Dwarfen Mountain Holds | 3 | 555 | 35 | 2.0 | 1.0 | 17 | 10 | +7 | 0 of 6 | 2 of 6 | - | +7 |
| Mine | Empire of Man | 5 | 441 | 62 | 1.4 | 1.0 | 45 | 0 | +45 | 3 of 7 | 4 of 7 | - | +45 |
| Mine | Grand Cathay | 5 | 632 | 282 | 4.0 | 1.1 | 71 | 0 | +71 | 4 of 20 | 17 of 20 | +81 | +69 |
| Mine | High Elf Realms | 4 | 198 | 537 | 5.5 | 1.1 | 98 | 24 | +73 | 8 of 22 | 13 of 22 | +172 | +63 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 1290 | 5.0 | 1.2 | 258 | 16 | +242 | 2 of 5 | 3 of 5 | +236 | +244 |
| Mine | Lizardmen | 1 | 0 | 1237 | 5.0 | 1.2 | 247 | 0 | +247 | 1 of 5 | 5 of 5 | +803 | +108 |
| Mine | Ogre Kingdoms | 1 | 116 | 264 | 3.0 | 1.0 | 88 | 13 | +75 | 0 of 3 | 3 of 3 | - | +75 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 293 | 8.0 | 1.0 | 37 | 21 | +16 | 2 of 8 | 6 of 8 | - | +16 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.5 | 10 | 32 | -23 | 0 of 2 | 1 of 2 | +19 | -65 |
| Mine | Tomb Kings of Khemri | 2 | 33 | 658 | 6.5 | 1.0 | 101 | 39 | +62 | 4 of 13 | 9 of 13 | - | +62 |
| Mine | Vampire Counts | 2 | 0 | 95 | 3.5 | 1.1 | 27 | 89 | -61 | 1 of 7 | 6 of 7 | +190 | -103 |
| Mine | Warriors of Chaos | 2 | 0 | 304 | 4.0 | 1.0 | 76 | 68 | +8 | 2 of 8 | 2 of 8 | - | +8 |
| **Mine** | all armies | 36 | 257 | 305 | 3.4 | 1.1 | 89 | 30 | +60 | 36 of 123 | 83 of 123 | +218 | +46 |
| Opponent | Empire of Man | 1 | 807 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | +0 | - |
| Opponent | Grand Cathay | 3 | 290 | 501 | 3.3 | 1.3 | 150 | 34 | +116 | 4 of 10 | 9 of 10 | +211 | +76 |
| Opponent | High Elf Realms | 3 | 405 | 408 | 3.3 | 1.0 | 122 | 79 | +43 | 7 of 10 | 8 of 10 | - | +43 |
| Opponent | Kingdom of Bretonnia | 2 | 32 | 302 | 4.0 | 1.1 | 76 | 75 | +0 | 6 of 8 | 4 of 8 | +0 | +1 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 176 | 3.0 | 1.0 | 59 | 18 | +40 | 1 of 3 | 2 of 3 | - | +40 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 31 | 416 | 3.5 | 1.0 | 119 | 28 | +90 | 7 of 14 | 12 of 14 | - | +90 |
| Opponent | Vampire Counts | 6 | 68 | 704 | 4.0 | 1.2 | 176 | 40 | +136 | 12 of 24 | 15 of 24 | +319 | +100 |
| Opponent | Warriors of Chaos | 9 | 0 | 538 | 3.6 | 1.2 | 151 | 22 | +129 | 14 of 32 | 22 of 32 | +186 | +119 |
| Opponent | Wood Elf Realms | 6 | 152 | 175 | 2.5 | 1.1 | 70 | 23 | +47 | 4 of 15 | 10 of 15 | +0 | +54 |
| **Opponent** | all armies | 36 | 122 | 424 | 3.3 | 1.1 | 129 | 35 | +94 | 56 of 118 | 84 of 118 | +177 | +81 |

### Effective charges: co-h2h-mine-324c342-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +15) | 0 | 0 | 1 (net +135) | 0 | 1 (net +40) | 2 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 12 | 2 (net +0) | 1 (net -692) | 1 (net +0) | 4 (net +225) | 0 | 2 (net +222) | 2 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 1 (net +104) | 0 | 1 (net -60) | 0 | 1 (net +0) | 2 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 3 (net +0) | 0 | 0 | 2 (net +120) | 1 (net +72) | 1 (net +0) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 20 | 0 | 2 (net +142) | 3 (net +42) | 6 (net +49) | 5 (net +92) | 4 (net +62) | 0 | 15% (3 of 20) |
| Mine | High Elf Realms | 22 | 2 (net +158) | 1 (net +0) | 6 (net +77) | 5 (net +9) | 4 (net +100) | 2 (net +95) | 2 | 30% (6 of 20) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +608) | 0 | 1 (net -80) | 0 | 0 | 3 (net +227) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 5 | 0 | 1 (net +803) | 0 | 1 (net +144) | 2 (net +145) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 3 | 1 (net -40) | 0 | 0 | 0 | 0 | 1 (net +144) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 8 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net -55) | 5 | 0% (0 of 3) |
| Mine | Skaven | 2 | 1 (net -65) | 0 | 0 | 0 | 1 (net +19) | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +0) | 1 (net +431) | 2 (net +135) | 3 (net +103) | 4 (net +58) | 2 (net -220) | 0 | 15% (2 of 13) |
| Mine | Vampire Counts | 7 | 1 (net -60) | 1 (net -60) | 1 (net +0) | 2 (net -155) | 1 (net +0) | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 8 | 3 (net -134) | 1 (net +0) | 3 (net +155) | 1 (net +0) | 0 | 0 | 0 | 38% (3 of 8) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 10 | 1 (net -205) | 0 | 1 (net +170) | 5 (net +107) | 2 (net +32) | 1 (net +597) | 0 | 10% (1 of 10) |
| Opponent | High Elf Realms | 10 | 0 | 2 (net -221) | 3 (net -74) | 1 (net +421) | 1 (net +125) | 2 (net +258) | 1 | 33% (3 of 9) |
| Opponent | Kingdom of Bretonnia | 8 | 3 (net +37) | 0 | 1 (net +0) | 1 (net +217) | 0 | 2 (net -30) | 1 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +176) | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 14 | 1 (net +0) | 0 | 3 (net +17) | 2 (net +133) | 2 (net +110) | 4 (net +125) | 2 | 25% (3 of 12) |
| Opponent | Vampire Counts | 24 | 6 (net +125) | 1 (net +0) | 2 (net -130) | 2 (net +313) | 4 (net +92) | 9 (net +198) | 0 | 8% (2 of 24) |
| Opponent | Warriors of Chaos | 32 | 8 (net -11) | 0 | 5 (net +184) | 3 (net +143) | 0 | 15 (net +190) | 1 | 16% (5 of 31) |
| Opponent | Wood Elf Realms | 15 | 0 | 0 | 2 (net +248) | 2 (net +88) | 1 (net -236) | 5 (net +0) | 5 | 20% (2 of 10) |

### Charged fights, damage counted: co-h2h-mine-324c342-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 223 | 239 | +22 | 73 | 81 | -8 | -3.7 |
| Mine | 50-54% | 9 | 306 | 259 | +97 | 235 | 108 | +127 | +41.5 |
| Mine | Effective (55-75%) | 17 | 304 | 188 | +73 | 123 | 33 | +90 | +29.6 |
| Mine | 76-89% | 27 | 293 | 171 | +63 | 104 | 52 | +52 | +17.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 214 | 164 | +57 | 117 | 34 | +83 | +38.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 18 | 370 | 84 | +82 | 86 | 7 | +79 | +21.5 |
| Mine | No odds | 14 | 258 | 185 | +34 | 75 | 36 | +39 | +15.1 |
| Mine | All fights | 123 | 280 | 177 | +60 | 108 | 46 | +62 | +22.2 |
| Opponent | Long shot (under 50%) | 19 | 300 | 291 | +30 | 130 | 103 | +27 | +9.0 |
| Opponent | 50-54% | 3 | 331 | 322 | -147 | 15 | 178 | -163 | -49.2 |
| Opponent | Effective (55-75%) | 17 | 292 | 298 | +68 | 162 | 101 | +61 | +20.9 |
| Opponent | 76-89% | 16 | 311 | 269 | +167 | 194 | 36 | +158 | +50.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 347 | 197 | +155 | 186 | 19 | +167 | +48.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 392 | 87 | +54 | 82 | 32 | +50 | +12.7 |
| Opponent | No odds | 12 | 215 | 186 | +21 | 61 | 36 | +25 | +11.6 |
| Opponent | All fights | 118 | 316 | 229 | +94 | 149 | 54 | +95 | +30.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-h2h-mine-324c342-p3 | move | 458 | 108 (24%) | 78 (17%) | 63 (14%) | 287 (63%) |
| co-h2h-mine-324c342-p3 | objective | 392 | 67 (17%) | 46 (12%) | 52 (13%) | 273 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

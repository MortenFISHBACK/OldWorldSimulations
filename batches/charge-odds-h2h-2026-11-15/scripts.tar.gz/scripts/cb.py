#!/usr/bin/env python3
"""Compares two simulation batches game by game (Morten 2026-10-27, item 1: "with and without" measurements).

    python3 scripts/compare-batches.py <batch A folder> <batch B folder> [--labels "with plays" "without plays"] > compare.md
    python3 scripts/compare-batches.py --plays <batch folder> > plays.md
    python3 scripts/compare-batches.py --scorecard <batch folder> > scorecard.md
    python3 scripts/compare-batches.py --kpis <batch folder> > kpis.md
    python3 scripts/compare-batches.py --packages <batch folder> > packages.md
    python3 scripts/compare-batches.py --claims <batch folder> [...] > claims.md
    python3 scripts/compare-batches.py --self-test

--scorecard (the doctrine's scorecard, Morten 2026-10-27): one batch's six numbers per game and side, with the batch average. The
comparison report has the same tables and a totals row per number.

Both the scorecard and the comparison have a "Charged fights" table per army (Morten 2026-11-04): the points a side won and lost in
every fight it charged into (a combined charge is one fight with all its points), and beside it the points it won by shooting and magic,
so shooting armies are read by their own number. Needs the batch's game-*.log.jsonl and records.db; without them the table is left out.
Below it, "Effective charges" (Morten 2026-11-04 20:13): each of a general's fights by the chance to win the first round it was told when it
picked the charge - a long shot (under 50%), effective (55-75%: just enough force) or overkill (90%+) - with the net points per band.

Both also have "Quality by phase" (Morten 2026-11-08, for Medium vs Medium batches that have no fixed yardstick): per side and game,
deployment, magic, movement, shooting and combat numbers read from the logs and the record, the charged fights' odds bands (the static
opponent's objective lines say its odds from 2026-11-08 on), then who won by side and by who went first, and swapped pairs ("A1s").
Under it, "Opponent rules" (batches from 2026-11-08 evening on): per side, how often each of the newer opponent rules decided an option
(WEARS DOWN, STOPS, NEEDED THERE, ...: the game log's OpponentRule lines), the VP it added to the figure, and the VP won and lost after it.

Both also have "KPIs" (Morten 2026-11-10): per side, how often a winner follows up or pursues instead of restraining (by what the loser
did), the share of the army's magic missiles tried each turn (target 50%, dead wizards counted; with why each was not tried, batches from
2026-11-10 on) and the share of points that never fought. --kpis prints that part alone, with a table by army.

"Packages" (Morten 2026-11-11, hunt the guns): per side and army, the hunts of enemy war machines and lone Wizards the hidden HUNT rows
trace - started, reached, killed, turns to kill, planned against won VP (worked = won 2/3+) - and the points the enemy's war machines
destroyed a game. In the quality part of both reports; --packages prints it alone.

"Claimed against happened" (Morten 2026-11-13, job figures option 12; scripts/job_claims.py): per job and side, picks a game, the VP the
pick claimed and what happened after it, then the same by unit type. In both reports and in --kpis; --claims prints it alone (several
folders add up).

--plays (the worked check, Morten 2026-10-27): one batch's plays, per play how often it was proposed, fired, worked / partly / not
worked, and its mean planned and taken worth - no "without" batch needed.

A batch folder is one of the simulation-data branch (games.csv, and plays.csv from 2026-10-27 on). The same match-up, scenario and seed in
both batches is one pair of games; the report gives each pair, then the totals: results, the Victory Point margin (Mine - Opponent) with
its noise band, the Victory Points by kind, the cost per side and the plays. Older batches lack the newer columns: those parts stay empty.
"""
import csv
import json
import math
import os
import re
import shutil
import sqlite3
import statistics
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import job_claims  # noqa: E402  (scripts/job_claims.py, the claimed-against-happened table)


def read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(row, key, default=None):
    try:
        return float(row.get(key) or "")
    except (TypeError, ValueError):
        return default


def margin(row):
    vp = (row.get("vp_mine_opponent") or "").split("-")
    if len(vp) != 2:
        return None
    try:
        return int(vp[0]) - int(vp[1])
    except ValueError:
        return None


def ended(rows):
    return [r for r in rows if r.get("ended") == "yes"]


def key(row):
    return (row.get("pair", ""), row.get("scenario", ""), row.get("seed", ""))


def mean(values):
    values = [v for v in values if v is not None]
    return sum(values) / len(values) if values else None


def fmt(value, digits=0, sign=False):
    if value is None:
        return "-"
    text = f"{value:+.{digits}f}" if sign else f"{value:.{digits}f}"
    return text


def result(row):
    if row is None:
        return "-"
    if row.get("ended") != "yes":
        return f"not ended ({row.get('ended') or '?'})"
    winner = row.get("winner") or "draw"
    return f"{winner} {row.get('vp_mine_opponent', '')}"


def wdl(rows):
    w = sum(1 for r in rows if r.get("winner") == "Mine")
    l = sum(1 for r in rows if r.get("winner") == "Opponent")
    return w, len(rows) - w - l, l


def noise_band(diffs):
    """The mean difference and its standard error (None with fewer than two pairs)."""
    if not diffs:
        return None, None
    m = sum(diffs) / len(diffs)
    if len(diffs) < 2:
        return m, None
    return m, statistics.stdev(diffs) / math.sqrt(len(diffs))


def plays_summary(rows, games):
    """Per side: plays run per game, their states at the end, steps done of the steps due-or-done, offers."""
    out = []
    for side in ("Mine", "Opponent"):
        mine = [r for r in rows if r.get("side") == side]
        if not mine:
            continue
        states = {}
        for r in mine:
            states[r["state"]] = states.get(r["state"], 0) + 1
        done = sum(int(r.get("steps_done") or 0) for r in mine)
        skipped = sum(int(r.get("steps_skipped") or 0) for r in mine)
        steps = sum(int(r.get("steps") or 0) for r in mine)
        yes = sum(int(r.get("offers_yes") or 0) for r in mine)
        no = sum(int(r.get("offers_no") or 0) for r in mine)
        out.append(f"{side}: {len(mine)} plays in {games} games ({len(mine) / max(1, games):.1f} a game); end states "
                   + ", ".join(f"{k} {v}" for k, v in sorted(states.items()))
                   + f"; steps done {done} of {steps} (skipped {skipped}); due steps with a candidate offered {yes}, without {no}")
    return out


def worked_table(rows):
    """Per play (the worked check): proposed, fired, worked / partly / not worked, mean planned and taken worth (Victory Points)."""
    rows = [r for r in rows if r.get("worked")]
    if not rows:
        return []
    out = ["| Side | Play | Proposed | Fired | Worked | Partly | Not worked | Mean planned | Mean taken |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    groups = {}
    for r in rows:
        groups.setdefault((r.get("side", ""), r.get("play", ""), r.get("name", "")), []).append(r)
    for (side, play, name), g in sorted(groups.items()):
        count = lambda v: sum(1 for r in g if r.get("worked") == v)
        out.append(f"| {side} | {play} {name} | {len(g)} | {sum(1 for r in g if r.get('state') == 'Fired')} | {count('worked')} | {count('partly')} | "
                   f"{count('not worked')} | {fmt(mean([num(r, 'planned_worth') for r in g]))} | {fmt(mean([num(r, 'taken_worth') for r in g]))} |")
    return out


def plays_report(batch_dir):
    rows = read_csv(os.path.join(batch_dir, "plays.csv"))
    games = read_csv(os.path.join(batch_dir, "games.csv"))
    lines = [f"# Plays: {os.path.basename(os.path.normpath(batch_dir))}", ""]
    summary = plays_summary(rows, len(games))
    lines.append("; ".join(summary) if summary else "No play run.")
    table = worked_table(rows)
    lines += ["", "## Worked / not worked (taken worth at least 2/3 of the planned worth and fired = worked; under 1/3 = not worked)", ""]
    lines += table if table else ["No play has a verdict (a batch before 2026-10-27's worth build)."]
    return "\n".join(lines) + "\n"


SPLIT = ["objectives", "kills", "leaders", "other"]

# The doctrine's scorecard (Morten 2026-10-27, build brief part 3): how "is the general getting better" is read from now on.
SCORECARD = [("far_contested", "Far marker / quarter contested by round 3"), ("lone_holders", "Lone holders (player turns)"),
             ("first_hammer_charge", "Round of the first Hammer charge"), ("lone_charges", "Lone charges into a block / monster / character"),
             ("idle_units", "Idle units"), ("wounded_lost", "Wounded Lords / monsters lost"),
             ("doctrine_flags", "Doctrine flags raised"), ("doctrine_changed", "Answers changed after a flag"),
             ("idle_points", "Points that never moved of their own")]


def score_value(row, col):
    v = (row.get(col) or "").strip()
    if v in ("yes", "no"):
        return 1.0 if v == "yes" else 0.0
    return num(row, col)


def score_fmt(col, value):
    if value is None:
        return "-"
    return f"{100 * value:.0f}%" if col == "far_contested" else f"{value:.1f}"


def scorecard_table(rows, label):
    """One batch: per game and side the six numbers + the flags, then the batch average (empty cells left out of it)."""
    if not rows or not any(f"{c}_mine" in rows[0] for c, _ in SCORECARD):
        return []
    out = [f"### Scorecard: {label}", "",
           "| Match-up | Scenario | Seed | Side | " + " | ".join(t for _, t in SCORECARD) + " |",
           "| --- | --- | --- | --- | " + " | ".join("---" for _ in SCORECARD) + " |"]
    for r in sorted(rows, key=key):
        for side in ("mine", "opponent"):
            cells = [(r.get(f"{c}_{side}") or "-") for c, _ in SCORECARD]
            out.append(f"| {r.get('pair', '')} | {r.get('scenario', '')} | {r.get('seed', '')} | {side.capitalize()} | " + " | ".join(cells) + " |")
    for side in ("mine", "opponent"):
        avg = [score_fmt(c, mean([score_value(r, f"{c}_{side}") for r in rows])) for c, _ in SCORECARD]
        out.append(f"| **Average** | | | {side.capitalize()} | " + " | ".join(avg) + " |")
    return out


def scorecard_totals(a, b):
    """Totals rows: both sides together, batch A against batch B."""
    out = []
    for col, label in SCORECARD:
        va = mean([score_value(r, f"{col}_{s}") for r in a for s in ("mine", "opponent")])
        vb = mean([score_value(r, f"{col}_{s}") for r in b for s in ("mine", "opponent")])
        if va is not None or vb is not None:
            out.append(f"| Scorecard: {label} (both sides) | {score_fmt(col, va)} | {score_fmt(col, vb)} |")
    return out


# Decision items and abilities without guidance (Morten 2026-10-27 22:10): per side, the names of its list's decision items and abilities
# no item guidance line matches (games.csv unguided_mine / unguided_opponent, "; "-separated) - the sheet for his verdicts is made from it.
def unguided_table(rows):
    if not rows or "unguided_mine" not in rows[0]:
        return []
    seen = {}
    for r in sorted(rows, key=key):
        for side in ("mine", "opponent"):
            for n in (x.strip() for x in (r.get(f"unguided_{side}") or "").split(";")):
                if n:
                    seen.setdefault((n, side.capitalize()), set()).add(r.get("pair", ""))
    if not seen:
        return ["## Decision items and abilities without guidance", "", "None: every decision item and ability on these lists has its guidance line."]
    out = ["## Decision items and abilities without guidance", "", "| Item or ability | Side | Match-ups |", "| --- | --- | --- |"]
    for (n, side), pairs in sorted(seen.items()):
        out.append(f"| {n} | {side} | {', '.join(sorted(pairs))} |")
    return out



# Charged fights (Morten 2026-11-04: "points per charge", not split, so big charges on important units count): every fight a side
# charged into, from its game log (game-*.log.jsonl) and the batch's records.db. A fight = the side's chargers that made contact with the
# same enemy unit in the same turn (a combined charge is ONE fight with all its points). It takes in every unit that exchanges blows with
# it (joined characters too) and lasts while its units still exchange blows. Points won = Victory Points the enemy gave up for units of
# the fight destroyed in it (Combat, RunDown, FledOff); points lost = the same for the side's own units. A unit's death counts for the
# latest fight it is in. Top-3 = the charged unit is one of the enemy's three costliest units; first round won = the first combat result of
# the charge turn for the fight's units says the side wins (out of the fights a result was found for).
GONE_IN_FIGHT = ("Combat", "RunDown", "FledOff")
# Shooting armies (Morten 2026-11-04: Dwarf gunline, Nuln, magic missiles) win their points this way instead: enemy units destroyed by
# shooting, war machines or magic, per game, beside the charge numbers.
GONE_TO_SHOOTING = ("Shooting", "WarMachine", "Magic")


def _records_by_game(batch_dir):
    path = os.path.join(batch_dir, "records.db")
    if not os.path.exists(path):
        return {}
    db = sqlite3.connect(path)
    try:
        cols = [r[1] for r in db.execute("pragma table_info(GameRecordUnits)")]
        army = "ArmyBook" if "ArmyBook" in cols else "''"
        rows = db.execute(f"select GameRecordId, Side, BoardName, Points, Gone, GoneRound, GoneCause, VictoryPointsGivenUp, {army} "
                          "from GameRecordUnits").fetchall()
    except sqlite3.Error:
        return {}
    finally:
        db.close()
    games = {}
    for gid, side, name, points, gone, rnd, cause, vp, book in rows:
        games.setdefault(gid, {})[name] = {"side": "Mine" if side == 0 else "Opponent", "points": points or 0, "gone": bool(gone),
                                            "round": rnd, "cause": cause, "vp": vp or 0, "army": book or ""}
    return games


def _game_fights(actions, units):
    """The fights of one game: [{side, turn, target, chargers, members, end}] with members by side."""
    fights = []
    for a in actions:
        if (a.get("type") == "Charge" and "made contact" in (a.get("summary") or "") and a.get("actor") in units
                and a.get("target") in units):
            f = next((f for f in fights if f["turn"] == a["turn"] and f["target"] == a["target"] and f["side"] == a["side"]), None)
            if f is None:
                f = {"side": a["side"], "turn": a["turn"], "target": a["target"], "chargers": [], "members": {a["target"]}, "end": a["turn"]}
                fights.append(f)
            f["chargers"].append(a["actor"])
            f["members"].add(a["actor"])
    # First round won (Morten 2026-11-04; corrected 2026-11-14): the first combat result AFTER the charge made contact whose blows, after that
    # contact, involve the fight's target or one of its chargers. Reading the first result of the charge turn took, for a charger going second
    # or one joining a running fight, the result of a round fought before the charge.
    for f in fights:
        f["start"] = next(i for i, a in enumerate(actions) if a.get("type") == "Charge" and "made contact" in (a.get("summary") or "")
                          and a.get("turn") == f["turn"] and a.get("side") == f["side"] and a.get("target") == f["target"]
                          and a.get("actor") in f["chargers"])
    # The round is better named by the computer's own line "Fights the combat: A and B against C" (exact unit names, longest first so "Gors"
    # does not match "Gors (Lodestone)"): other Combat-phase lines carry a unit's name without being its round (a skirmisher's form-up at the
    # contact, a reform after an earlier fight) and made the blow reading take another fight's result (found 2026-11-14 on 65 of 1,650 fights).
    # A fight with such a line takes the next CombatResult after it; the blow reading below is the fallback (the test player writes no line).
    names = sorted((n for n in units if n), key=len, reverse=True)

    def named(text):
        found = set()
        for n in names:
            if n in text:
                found.add(n)
                text = text.replace(n, "\0")
        return found
    for f in fights:
        mine = {f["target"], *f["chargers"]}
        line = next((i for i, a in enumerate(actions) if i > f["start"] and a.get("turn") == f["turn"] and a.get("type") == "Computer"
                     and (a.get("summary") or "").startswith("Fights the combat: ") and mine & named(a["summary"][len("Fights the combat: "):])), None)
        if line is not None:
            res = next((a for a in actions[line + 1:] if a.get("type") == "CombatResult"), None)
            if res is not None:
                f["first_round"] = f"{f['side']} wins" in (res.get("summary") or "")
    segment = []
    for i, a in enumerate(actions):
        if a.get("phase") != "Combat":
            continue
        if a.get("type") == "CombatResult":
            text = a.get("summary") or ""
            for f in fights:
                if ("first_round" not in f and f["turn"] == a["turn"] and i > f["start"]
                        and any(j > f["start"] and (x == f["target"] or x in f["chargers"]) for j, x in segment)):
                    f["first_round"] = f"{f['side']} wins" in text
            segment = []
        elif a.get("actor") or a.get("target"):
            segment += [(i, x) for x in (a.get("actor"), a.get("target")) if x]
    blows = {}
    for a in actions:
        if a.get("phase") == "Combat" and a.get("actor") and a.get("target") and a["actor"] in units and a["target"] in units:
            blows.setdefault(a["turn"], []).append((a["actor"], a["target"]))
    for f in fights:
        turn = f["turn"]
        while turn in blows:
            linked = False
            for x, y in blows[turn]:
                if (x in f["members"]) != (y in f["members"]) or (x in f["members"] and y in f["members"]):
                    if units[x]["side"] != units[y]["side"]:
                        f["members"] |= {x, y}
                        linked = True
            if not linked:
                break
            f["end"] = turn
            turn += 1
    return fights


# Effective charges (Morten 2026-11-04 20:13: "60-70% likelihood of win charges ... just the right amount of force to overcome the target but
# not too much so you waste your points or too little so you give up your points"). A fight's odds = the chance to win the first round the
# general was told when it picked the charge (its objective answer: "Charge #id Target (N pts): ... win first round N%"); a combined charge
# takes the "with #id X charging too ... win N%" figure when X charged too, else the best of its chargers' own figures. The free script
# (and a charge picked any other way) gives no figure: those fights are counted as "no figure".
# Sweet spot widened to 55-75% (Morten 2026-11-05 05:27: "Lets expand to 55-75 as Sweet spot").
EFFECTIVE_LOW, EFFECTIVE_HIGH = 55, 75
ODDS_BANDS = (("Long shot (under 50%)", 0, 50), (f"50-{EFFECTIVE_LOW - 1}%", 50, EFFECTIVE_LOW),
              (f"Effective ({EFFECTIVE_LOW}-{EFFECTIVE_HIGH}%)", EFFECTIVE_LOW, EFFECTIVE_HIGH + 1), (f"{EFFECTIVE_HIGH + 1}-89%", EFFECTIVE_HIGH + 1, 90),
              ("Overkill (90%+, target under 250 pts, chargers over 3x its points)", 90, 101))
# Overkill (Morten 2026-11-10, replacing rule 7 of 2026-11-08 "chargers dearer than the target"): a 90%+ charge on a target of 250 pts or
# more is never overkill; on a smaller target it is overkill only when the chargers are worth more than 3 times the target (characters joined
# to either counted). A redirected charge is left out ("not relevant"). The other 90%+ fights get their own column.
CHEAP_SURE = "90%+ not overkill (target 250+ pts or chargers up to 3x)"
OVERKILL_TARGET_BELOW, OVERKILL_RATIO = 250, 3


def _overkill(odds, charger_points, target_points, redirected):
    """Whether a fight is overkill by Morten's 2026-11-10 rule (the odds band is checked by the caller)."""
    return (not redirected and odds is not None and odds >= 90 and 0 < target_points < OVERKILL_TARGET_BELOW
            and charger_points > OVERKILL_RATIO * target_points)


def _band(f, lo, hi):
    """Whether fight tuple f (odds at [5], overkill by the 3x rule at [6]) is in the band; a 90%+ fight that is no overkill is not."""
    if not (lo <= f[5] < hi):
        return False
    return not (lo >= 90 and len(f) > 6 and f[6] is False)


def _cheap_sure(f):
    return f[5] is not None and f[5] >= 90 and len(f) > 6 and f[6] is False
_UNIT_LINE = re.compile(r"^UNIT #\d+ (.+?) \(\d+ pts")
_OPTION_LINE = re.compile(r"^\s*(\d+)\) (.*)$")
_CHARGE_OPTION = re.compile(r"Charge #\d+ (.+?) \(\d+ pts.*?win first round (\d+)%")
_CHARGE_PICK = re.compile(r"(\[[A-Z]+\] )*Charge #")
_HELP_FIGURE = re.compile(r"HELP: alone win \d+%, with #\d+ (.+?) charging too \(its reach \d+%\) win (\d+)%")


def _declared_odds(calls):
    """{(side, turn, charger, target): (alone %, helper or None, together % or None)} from the generals' picked Charge options."""
    out = {}
    for c in calls:
        if c.get("type") != "TurnObjective":
            continue
        try:
            pick = int(json.loads(c.get("answer") or "{}").get("option_id"))
        except (ValueError, TypeError, AttributeError):
            continue
        unit = None
        for line in (c.get("question") or "").split("\n"):
            u = _UNIT_LINE.match(line)
            if u:
                unit = u.group(1)
                continue
            o = _OPTION_LINE.match(line)
            if not o or unit is None or int(o.group(1)) != pick:
                continue
            m = _CHARGE_OPTION.search(o.group(2))
            if m and _CHARGE_PICK.match(o.group(2)):
                h = _HELP_FIGURE.search(o.group(2))
                out[(c.get("general"), c.get("turn"), unit, m.group(1))] = (int(m.group(2)), h.group(1) if h else None, int(h.group(2)) if h else None)
    return out


# The static opponent (Medium) asks no question: its picks are in its objective lines (Morten 2026-11-08, Medium vs Medium plan item 3: the
# line says the first-round odds it picked by), and a supported charge in its "asks ... to charge ... with it (alone win N%, together M%)".
_STATIC_CHARGE = re.compile(r"^Objective for (?P<unit>.+?): charge #\d+ (?P<target>.+?): .*?win first round (?P<pct>\d+)%")
_STATIC_HELP = re.compile(r"^(?P<unit>.+?) asks (?P<helpers>.+?) to charge (?P<target>.+?) with it \(alone win (?P<alone>\d+)%, together (?P<together>\d+)%\)")
# Unfigured charges (2026-11-10): a charge into a running fight names the fight after its target ("(joins the fight with ...)"); a charge made
# off an advance or close-in says its figure on its Movement line; a unit joining a friend's charge says the together figure.
_JOINS_FIGHT = re.compile(r" \(joins the fight with .*$")
_STATIC_CHARGE_NOW = re.compile(r"^(?P<unit>.+?) charges .*?: it can charge now (?P<target>.+?): it charges .*?win first round (?P<pct>\d+)%")
_STATIC_JOIN = re.compile(r"^(?P<unit>.+?) joins (?P<friend>.+?)'s charge on (?P<target>.+?) \(alone win (?P<alone>\d+)%, together (?P<together>\d+)%\)")


def _static_odds(actions):
    """The same as _declared_odds, from the static opponent's Strategy lines."""
    out = {}
    for a in actions:
        if a.get("type") != "Computer" or a.get("phase") not in ("Strategy", "Movement"):
            continue
        text = a.get("summary") or ""
        if a.get("phase") == "Movement":
            n = _STATIC_CHARGE_NOW.match(text)
            if n:
                out.setdefault((a.get("side"), a.get("turn"), n["unit"], n["target"]), (int(n["pct"]), None, None))
                continue
            j = _STATIC_JOIN.match(text)
            if j:
                out.setdefault((a.get("side"), a.get("turn"), j["unit"], j["target"]), (int(j["together"]), None, None))
            continue
        m = _STATIC_CHARGE.match(text)
        if m:
            k = (a.get("side"), a.get("turn"), m["unit"], _JOINS_FIGHT.sub("", m["target"]))
            out.setdefault(k, (int(m["pct"]), None, None))
            continue
        h = _STATIC_HELP.match(text)
        if h:
            out[(a.get("side"), a.get("turn"), h["unit"], h["target"])] = (int(h["alone"]), h["helpers"].split(" and "), int(h["together"]))
    return out


def _fight_odds(fight, odds):
    """The fight's declared chance to win the first round in %, or None when no charger's pick carried one."""
    best = None
    for ch in fight["chargers"]:
        d = odds.get((fight["side"], fight["turn"], ch, fight["target"]))
        if d is None:
            continue
        alone, helper, together = d
        helpers = helper if isinstance(helper, list) else [helper] if helper is not None else []
        figure = together if any(x in fight["chargers"] for x in helpers) else alone
        best = figure if best is None else max(best, figure)
    return best


def effective_charges_table(batch_dir, label, per=None):
    """Per side and army: the fights in each odds band, with their net points per fight."""
    per = per if per is not None else charged_fights(batch_dir)
    keys = sorted(k for k, v in per.items() if any(f[5] is not None for f in v["fights"]))
    if not keys:
        return []
    out = [f"### Effective charges: {label}", "",
           "Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static "
           "opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked "
           "another way) are counted apart.", "",
           "| Side | Army | Fights | " + " | ".join(b[0] for b in ODDS_BANDS) + f" | {CHEAP_SURE} | No figure | Effective share |",
           "| --- | --- | --- | " + " | ".join("---" for _ in ODDS_BANDS) + " | --- | --- | --- |"]

    def row(side, army, fights):
        known = [f for f in fights if f[5] is not None]
        cells = []
        for _, lo, hi in ODDS_BANDS:
            band = [f for f in known if _band(f, lo, hi)]
            cells.append(f"{len(band)} (net {fmt(mean([f[1] - f[2] for f in band]), sign=True)})" if band else "0")
        cheap = [f for f in known if _cheap_sure(f)]
        cells.append(f"{len(cheap)} (net {fmt(mean([f[1] - f[2] for f in cheap]), sign=True)})" if cheap else "0")
        eff = sum(1 for f in known if EFFECTIVE_LOW <= f[5] <= EFFECTIVE_HIGH)
        share = f"{100 * eff / len(known):.0f}% ({eff} of {len(known)})" if known else "-"
        return f"| {side} | {army} | {len(fights)} | " + " | ".join(cells) + f" | {len(fights) - len(known)} | {share} |"

    for k in keys:
        out.append(row(k[0], k[1] or "-", per[k]["fights"]))
    return out


def _joined_by_game(batch_dir):
    """{game id: {board name: the unit it joined}} from the records (empty for records without the column)."""
    path = os.path.join(batch_dir, "records.db")
    if not os.path.exists(path):
        return {}
    db = sqlite3.connect(path)
    try:
        rows = db.execute("select GameRecordId, BoardName, JoinedToUnitName from GameRecordUnits").fetchall()
    except sqlite3.Error:
        return {}
    finally:
        db.close()
    out = {}
    for gid, name, joined in rows:
        if joined:
            out.setdefault(gid, {})[name] = joined
    return out


# Damage counted (Morten 2026-11-10: "that is a problem for measurement"): a won fight that only wears its target down, or breaks it without
# catching it, counted 0. Each fight now also counts, for every unit in it that is not gone: the share of its wounds lost while the fight ran
# (from the log's board frames: models left x Wounds - wounds on the wounded model, against models x Wounds at the start, at its points), and
# half its points when it fled in that time and was not caught (the computer's own figure for a flee). A unit gone in the fight counts its
# Victory Points as before. Older logs without frames count the units gone only.
FLED_SHARE = 0.5


def _health_timeline(board, frames):
    """{board name: (full health, [(after action id, health, fleeing)])} from the log's board header and frames."""
    full, names = {}, {}
    for u in board:
        look = u.get("lk") or {}
        w, mc = look.get("w") or 1, look.get("mc") or 1
        names[u.get("id")] = u.get("n")
        full[u.get("n")] = (mc * w, w)
    out = {n: (h, []) for n, (h, _) in full.items()}
    for after, us in frames:
        for u in us:
            n = names.get(u.get("id"))
            if n not in full:
                continue
            if not u.get("on", 1):
                continue  # off the table (a pursuit off the edge, not yet arrived): its wounds are as they were; a unit gone counts its VP
            w = full[n][1]
            alive = len(u.get("m") or [])
            try:
                wt = float(u.get("wt") or 0)
            except (TypeError, ValueError):
                wt = 0
            out[n][1].append((after, max(0, alive * w - wt), bool(u.get("fl"))))
    return out


def _fight_damage(fight, members_owned, units, timeline, start_id, end_id, gone_owned):
    """(points won, points lost) of one fight, damage counted: gone units at their VP, the others by wounds lost or a flee not caught."""
    won = lost = 0.0
    enemy = "Opponent" if fight["side"] == "Mine" else "Mine"
    for m in members_owned:
        u = units[m]
        if m in gone_owned:
            pts = u["vp"]
        elif m in timeline and start_id is not None and end_id is not None:
            full, steps = timeline[m]
            before = [h for a, h, _ in steps if a < start_id]
            after = [h for a, h, _ in steps if a <= end_id]
            h0 = before[-1] if before else full
            h1 = after[-1] if after else full
            share = max(0.0, (h0 - h1) / full) if full else 0.0
            if any(fl for a, _, fl in steps if start_id <= a <= end_id):
                share = max(share, FLED_SHARE)
            pts = min(1.0, share) * u["points"]
        else:
            continue
        if u["side"] == enemy:
            won += pts
        else:
            lost += pts
    return won, lost


def charged_fights(batch_dir):
    """Per (side, army): games played and the list of its fights as (chargers, won, lost, top3, first round won, odds, overkill by the 3x
    rule, won with damage counted, lost with damage counted, chargers' points, target's points, redirected)."""
    records = _records_by_game(batch_dir)
    joined_all = _joined_by_game(batch_dir)
    out = {}
    for name in sorted(os.listdir(batch_dir)) if os.path.isdir(batch_dir) else []:
        if not (name.startswith("game-") and name.endswith(".log.jsonl")):
            continue
        actions, calls, board, frames = [], [], [], []
        with open(os.path.join(batch_dir, name)) as f:
            for line in f:
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                if d.get("kind") == "action":
                    actions.append(d)
                elif d.get("kind") == "call" and d.get("ok", True):
                    calls.append(d)
                elif d.get("kind") == "board":
                    board = d.get("units") or []
                elif d.get("kind") == "frame":
                    frames.append((d.get("after") or 0, d.get("units") or []))
        names = {a.get("actor") for a in actions} | {a.get("target") for a in actions}
        def fit(u):  # the smaller share of each army's units named in the log: both armies must be there
            return min(len(names & {n for n, x in u.items() if x["side"] == side}) / max(1, sum(1 for x in u.values() if x["side"] == side))
                       for side in ("Mine", "Opponent"))
        gid, units = max(records.items(), key=lambda kv: fit(kv[1]), default=(None, None))
        if not units or fit(units) < 0.6:
            continue  # a game without its record (one that did not end): no points to read
        joined = joined_all.get(gid, {})
        def with_joined(n):
            return units[n]["points"] + sum(units[c]["points"] for c, j in joined.items() if j == n and c in units and units[c]["side"] == units[n]["side"])
        timeline = _health_timeline(board, sorted(frames, key=lambda x: x[0]))
        redirected = {(a.get("side"), a.get("turn"), a.get("actor"), a.get("target")) for a in actions
                      if a.get("type") == "Charge" and "redirects its charge to" in (a.get("summary") or "")}
        fights = _game_fights(actions, units)
        odds = {**_static_odds(actions), **_declared_odds(calls)}
        for f in fights:
            f["odds"] = _fight_odds(f, odds)
        armies = {}
        for u in units.values():
            armies.setdefault(u["side"], u["army"])
        for side, army in armies.items():
            entry = out.setdefault((side, army), {"games": 0, "fights": [], "shot": 0})
            entry["games"] += 1
            entry["shot"] += sum(u["vp"] for u in units.values()
                                 if u["side"] != side and u["gone"] and u["cause"] in GONE_TO_SHOOTING)
        owner = {}
        for i, f in enumerate(fights):
            for m in f["members"]:
                u = units[m]
                if u["gone"] and u["cause"] in GONE_IN_FIGHT and u["round"] is not None and f["turn"] <= u["round"] <= f["end"]:
                    owner[m] = i  # the latest fight it is in (fights are in log order)
        # Damage counted: each unit's wounds count in the latest fight it is in; a fight runs from its first contact to the end of its last round.
        ids = [a.get("id") for a in actions]
        held = {}
        for i, f in enumerate(fights):
            for m in f["members"]:
                held[m] = i
        for i, f in enumerate(fights):
            enemy = "Opponent" if f["side"] == "Mine" else "Mine"
            top3 = sorted((u["points"] for u in units.values() if u["side"] == enemy), reverse=True)[:3]
            won = sum(units[m]["vp"] for m, j in owner.items() if j == i and units[m]["side"] == enemy)
            lost = sum(units[m]["vp"] for m, j in owner.items() if j == i and units[m]["side"] == f["side"])
            start = next((a.get("id") for a in actions if a.get("type") == "Charge" and a.get("turn") == f["turn"] and a.get("side") == f["side"]
                          and a.get("target") == f["target"] and "made contact" in (a.get("summary") or "")), None)
            end = max((a.get("id") for a in actions if a.get("id") is not None and (a.get("turn") or 0) <= f["end"]), default=None)
            if None in ids:
                start = end = None
            mine = [m for m in f["members"] if held.get(m) == i or owner.get(m) == i]
            won_d, lost_d = _fight_damage(f, mine, units, timeline, start, end, {m for m, j in owner.items() if j == i})
            charger_points = sum(with_joined(ch) for ch in f["chargers"] if ch in units)
            target_points = with_joined(f["target"])
            redirect = all((f["side"], f["turn"], ch, f["target"]) in redirected for ch in f["chargers"])
            out[(f["side"], armies.get(f["side"], ""))]["fights"].append(
                (len(f["chargers"]), won, lost, units[f["target"]]["points"] >= (top3[-1] if top3 else 0), f.get("first_round"), f.get("odds"),
                 _overkill(f.get("odds"), charger_points, target_points, redirect), won_d, lost_d, charger_points, target_points, redirect, name, f["side"], f["turn"], f["target"]))
    return out


def damage_counted_table(batch_dir, label, per=None):
    """Per side over all armies, by odds band: the chargers' points and the net per fight with units gone only and with damage counted
    (Morten 2026-11-10), and the net per 100 points of chargers."""
    per = per if per is not None else charged_fights(batch_dir)
    if not per:
        return []
    out = [f"### Charged fights, damage counted: {label}", "",
           "Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the "
           "fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.", "",
           "| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) "
           "| Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    bands = [(b[0], (lambda lo, hi: lambda f: f[5] is not None and _band(f, lo, hi))(b[1], b[2])) for b in ODDS_BANDS]
    bands.insert(len(bands) - 1, (CHEAP_SURE, _cheap_sure))
    bands += [("No odds", lambda f: f[5] is None), ("All fights", lambda f: True)]
    for side in SIDES:
        fights = [f for k, v in per.items() if k[0] == side for f in v["fights"]]
        if not fights:
            continue
        for name, test in bands:
            fs = [f for f in fights if test(f)]
            if not fs:
                continue
            cp = sum(f[9] for f in fs)
            net_d = sum(f[7] - f[8] for f in fs)
            out.append(f"| {side} | {name} | {len(fs)} | {fmt(mean([f[9] for f in fs]))} | {fmt(mean([f[10] for f in fs]))} | "
                       f"{fmt(mean([f[1] - f[2] for f in fs]), sign=True)} | {fmt(mean([f[7] for f in fs]))} | {fmt(mean([f[8] for f in fs]))} | "
                       f"{fmt(net_d / len(fs), sign=True)} | {fmt(100 * net_d / cp, 1, sign=True) if cp else '-'} |")
    return out


def charged_fights_table(batch_dir, label):
    """Per army (Morten 2026-11-04: a shooting army - Dwarf gunline, Nuln - should charge little, so read the numbers per army),
    then per side over all armies."""
    per = charged_fights(batch_dir)
    if not per:
        return []
    out = [f"### Charged fights: {label}", "",
           "| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight "
           "| On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]

    def row(side, army, games, fights, shot):
        lead = f"| {side} | {army} | {games} | {shot / max(1, games):.0f} | {sum(f[1] for f in fights) / max(1, games):.0f} |"
        if not fights:
            return lead + " 0.0 | - | - | - | - | - | - | - | - |"
        combined, lone = [f for f in fights if f[0] > 1], [f for f in fights if f[0] == 1]
        return (lead + f" {len(fights) / max(1, games):.1f} | {mean([f[0] for f in fights]):.1f} | "
                f"{fmt(mean([f[1] for f in fights]))} | {fmt(mean([f[2] for f in fights]))} | {fmt(mean([f[1] - f[2] for f in fights]), sign=True)} | "
                f"{sum(1 for f in fights if f[3])} of {len(fights)} | {sum(1 for f in fights if f[4])} of {sum(1 for f in fights if f[4] is not None)} | {fmt(mean([f[1] - f[2] for f in combined]), sign=True)} | "
                f"{fmt(mean([f[1] - f[2] for f in lone]), sign=True)} |")

    for side in ("Mine", "Opponent"):
        keys = sorted(k for k in per if k[0] == side)
        for k in keys:
            out.append(row(side, k[1] or "-", per[k]["games"], per[k]["fights"], per[k]["shot"]))
        if len(keys) > 1:
            out.append(row(f"**{side}**", "all armies", sum(per[k]["games"] for k in keys), [f for k in keys for f in per[k]["fights"]],
                           sum(per[k]["shot"] for k in keys)))
    return out


# Charges set up by the last move (Morten 2026-11-07, next-charge lookahead option 5): how often a charge the computer planned for next turn
# happened. Two sources, read from the game logs:
#  - "move": a computer move line that says "sets up next turn's charge on #id X" (the spot's WORTH counted that charge; batches from
#    2026-11-07 on);
#  - "objective": a computer objective "close in to charge #id X ... next turn" (older batches too, so a baseline can be compared).
# Next turn = the same side's turn in the next round. Charged = it declared a charge on that unit (a redirect counts as declared);
# contact = it made contact with it; other = it charged another unit instead; none = it declared no charge.
SET_UP_MOVE = re.compile(r'^(?P<unit>.+?) (?:moves|marches) [\d.]+".*?; sets up next turn\'s charge on #(?P<target>\d+) ')
SET_UP_OBJECTIVE = re.compile(r'^Objective for (?P<unit>.+?): close in (?:on #\d+ [^:]*? )?to charge #(?P<target>\d+) ')


def set_ups(batch_dir):
    """{source: {"set_ups", "charged", "contact", "other", "none"}} over the batch's game logs."""
    out = {src: {"set_ups": 0, "charged": 0, "contact": 0, "other": 0, "none": 0} for src in ("move", "objective")}
    for name in sorted(os.listdir(batch_dir)) if os.path.isdir(batch_dir) else []:
        if not (name.startswith("game-") and name.endswith(".log.jsonl")):
            continue
        actions = []
        with open(os.path.join(batch_dir, name)) as f:
            for line in f:
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                if d.get("kind") == "action":
                    actions.append(d)
        charges = {}  # (side, turn, unit) -> [(target_id, contact)]
        for a in actions:
            if a.get("type") != "Charge" or not a.get("actor"):
                continue
            summary = a.get("summary") or ""
            if " declares a charge against " in summary or " redirects its charge to " in summary:
                charges.setdefault((a.get("side"), a.get("turn"), a["actor"]), []).append((a.get("target_id"), False))
            elif ": made contact" in summary:
                charges.setdefault((a.get("side"), a.get("turn"), a["actor"]), []).append((a.get("target_id"), True))
        seen = set()
        for a in actions:
            if a.get("type") != "Computer":
                continue
            summary = a.get("summary") or ""
            for src, rx, phase in (("move", SET_UP_MOVE, "Movement"), ("objective", SET_UP_OBJECTIVE, "Strategy")):
                m = rx.match(summary)
                if not m or a.get("phase") != phase:
                    continue
                k = (src, a.get("side"), a.get("turn"), m["unit"])
                if k in seen:
                    continue
                seen.add(k)
                target = int(m["target"])
                nxt = charges.get((a.get("side"), (a.get("turn") or 0) + 1, m["unit"]), [])
                c = out[src]
                c["set_ups"] += 1
                if any(t == target for t, _ in nxt):
                    c["charged"] += 1
                    if any(t == target and hit for t, hit in nxt):
                        c["contact"] += 1
                elif nxt:
                    c["other"] += 1
                else:
                    c["none"] += 1
    return out


def set_ups_table(batches):
    """One row per (label, source) with set-ups; [] when no batch has any."""
    rows = []
    for label, batch_dir in batches:
        for src, c in set_ups(batch_dir).items():
            if c["set_ups"]:
                n = c["set_ups"]
                pct = lambda v: f"{v} ({100 * v / n:.0f}%)"
                rows.append(f"| {label} | {src} | {n} | {pct(c['charged'])} | {pct(c['contact'])} | {pct(c['other'])} | {pct(c['none'])} |")
    if not rows:
        return []
    return ["## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)", "",
            "| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |",
            "| --- | --- | --- | --- | --- | --- | --- |"] + rows


# Quality by phase (Morten 2026-11-08: "Try to come up with quality metrics for each phase", then 09:01: "Needs more granularity. Deployment:
# positions vs. Output (prob. need to be split by unit type), shooting magic missiles need to be included as separate as the current meta is
# heavy on this. Everything related to dice roll only is not relevant. Strategy phase should more relate to how to support the other phases").
# Read from what a batch already keeps (games.csv, records.db, the game logs), per side: a Medium vs Medium batch has no fixed yardstick
# (both sides improve together), so it is read by how well the games are played. Output = the Victory Points of the enemy units a unit
# destroyed (the record's GoneByUnitName), per 100 of its own points.
SIDES = ("Mine", "Opponent")
_ALONE_LINE = re.compile(r"^(?P<unit>.+?) stands on its own")
_OBJ_CHARGE = re.compile(r"^Objective for (?P<unit>.+?): charge #\d+ (?P<target>.+?)(?::| \(|$)")
_OBJ_SHOOT = re.compile(r"^Objective for (?P<unit>.+?): shoot #\d+ (?P<target>.+?)(?::| \(|$)")
_OBJ_CLOSE = re.compile(r"^Objective for (?P<unit>.+?): close in (?:on #\d+ [^:]*? )?to charge #\d+ (?P<target>.+?) next turn")
_ASKS = re.compile(r"^(?P<unit>.+?) asks (?P<helpers>.+?) to charge (?P<target>.+?) with it")
_CAST = re.compile(r"^(?P<wizard>.+?) attempts (?P<spell>.+?) \(")
_RESOLVES = re.compile(r"^(?P<spell>.+?) resolves(?: in the challenge)?: (?P<n>\d+) wounds? caused to (?P<target>.+)$")
_SPELL_TYPES = None


def _spell_types():
    """{spell name: Conveyance / Enchantment / Hex / MagicMissile / MagicalVortex / Assailment} from the seed catalogue (empty without it)."""
    global _SPELL_TYPES
    if _SPELL_TYPES is None:
        _SPELL_TYPES = {}
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "deploy", "seed", "oldworldwartable.db")
        if os.path.exists(path):
            names = ["Conveyance", "Enchantment", "Hex", "MagicMissile", "MagicalVortex", "Assailment"]
            db = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                _SPELL_TYPES = {n: names[t] if isinstance(t, int) and 0 <= t < len(names) else "Other" for n, t in db.execute("select Name, Type from Spells")}
            except sqlite3.Error:
                pass
            finally:
                db.close()
    return _SPELL_TYPES


_FIGHT_ONLY = None


def _fight_only_spells():
    """The augments the 11-06 rule casts only on a unit that fights (FightOnlySpells.IsFightOnly): an Enchantment that lasts until the end of
    the caster's own turn, has effects, and none moves the unit (Movement stat or a Reserve Move: Hellish Vigour, Daemonic Vigour, Khsar's).
    Spells that last longer (Deathly Cabal, Glittering Robe, Oaken Shield, Earthen Ramparts) are not limited, so they are not measured."""
    global _FIGHT_ONLY
    if _FIGHT_ONLY is None:
        _FIGHT_ONLY = set()
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "deploy", "seed", "oldworldwartable.db")
        if os.path.exists(path):
            db = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                effects = {}
                for name, stat, grant in db.execute("select s.Name, e.Stat, e.GrantsRuleName from Spells s join SpellEffects e on e.SpellId = s.Id "
                                                    "where s.Type = 1 and s.Duration = 1"):
                    effects.setdefault(name, []).append((stat, (grant or "").lower()))
                _FIGHT_ONLY = {n for n, eff in effects.items() if not any(st == 10 or g == "reserve move" for st, g in eff)}
            except sqlite3.Error:
                pass
            finally:
                db.close()
    return _FIGHT_ONLY


def _unit_records(batch_dir):
    """{record id: {board name: unit}} with the columns the quality report reads (older records lack some: left empty)."""
    path = os.path.join(batch_dir, "records.db")
    if not os.path.exists(path):
        return {}
    db = sqlite3.connect(path)
    try:
        have = {r[1] for r in db.execute("pragma table_info(GameRecordUnits)")}
        want = ["GameRecordId", "Side", "BoardName", "Points", "Gone", "GoneRound", "GoneCause", "VictoryPointsGivenUp", "TroopType", "IsCharacter",
                "Kind", "DeploySpot", "Fought", "RoundFirstFought", "GoneByUnitName", "JoinedToUnitName", "WoundsDealt", "VictoryPointsEarned", "UnitName", "ArmyBook"]
        rows = db.execute("select " + ", ".join(c if c in have else "NULL" for c in want) + " from GameRecordUnits").fetchall()
    except sqlite3.Error:
        return {}
    finally:
        db.close()
    games = {}
    for r in rows:
        u = dict(zip(want, r))
        role = (u["Kind"] or "").split(", ")[-1] if u["Kind"] else ""
        role = "" if re.match(r"^[<\d]", role) else role  # "Heavy Infantry, 100-199": no purpose given
        kind = ("War machine" if u["TroopType"] == "War Machines" else "Wizard" if role == "Wizard"
                else "Character" if u["IsCharacter"] else role or u["TroopType"] or "-")
        games.setdefault(u["GameRecordId"], {})[u["BoardName"]] = {
            "side": "Mine" if u["Side"] == 0 else "Opponent", "points": u["Points"] or 0, "gone": bool(u["Gone"]), "round": u["GoneRound"],
            "cause": u["GoneCause"], "vp": u["VictoryPointsGivenUp"] or 0, "type": kind, "spot": u["DeploySpot"], "fought": bool(u["Fought"]),
            "first_fought": u["RoundFirstFought"], "by": u["GoneByUnitName"], "joined": u["JoinedToUnitName"], "wounds": u["WoundsDealt"] or 0,
            "earned": u["VictoryPointsEarned"],
            "character": bool(u["IsCharacter"]), "terrain": u["TroopType"] == "Terrain", "unit_name": u["UnitName"],
            "troop": u["TroopType"], "army": u["ArmyBook"]}
    for units in games.values():  # a joined character deployed where its unit did (JoinedToUnitName is the unit's list name)
        hosts = {}
        for u in units.values():
            if not u["character"]:
                hosts.setdefault(u["unit_name"], u)
        for u in units.values():
            host = units.get(u["joined"]) or hosts.get(u["joined"])
            if not u["spot"] and host:
                u["spot"] = host["spot"]
    return games


def _record_results(batch_dir):
    """{record id: "mine-opponent" Victory Points}, to tell apart two games of the same lists (seeds 1 and 2 of one pair)."""
    path = os.path.join(batch_dir, "records.db")
    if not os.path.exists(path):
        return {}
    db = sqlite3.connect(path)
    try:
        return {i: f"{m}-{o}" for i, m, o in db.execute("select Id, MineVictoryPoints, OpponentVictoryPoints from GameRecords")}
    except sqlite3.Error:
        return {}
    finally:
        db.close()


def _game_logs(batch_dir):
    """[(game file, actions, record units or None)] for every game log of the batch, each matched to its record by the units it names and,
    between records of the same lists, by its result in games.csv; a record is matched once."""
    records = _unit_records(batch_dir)
    results = _record_results(batch_dir)
    csv_vp = {f"game-{r.get('pair')}-{r.get('scenario')}-{r.get('seed')}.log.jsonl": r.get("vp_mine_opponent") for r in read_csv(os.path.join(batch_dir, "games.csv"))}
    taken = set()
    out = []
    for name in sorted(os.listdir(batch_dir)) if os.path.isdir(batch_dir) else []:
        if not (name.startswith("game-") and name.endswith(".log.jsonl")):
            continue
        actions = []
        with open(os.path.join(batch_dir, name)) as f:
            for line in f:
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                # objective: a score and the unit that held it (logs from 2026-11-08 on); item: a bound or one-use item carried (2026-11-10 on)
                # board: the units' looks (models, Wounds each) - the shooting KPI's worth per wound (2026-11-11)
                if d.get("kind") in ("action", "objective", "item", "board"):
                    actions.append(d)
        names = {a.get("actor") for a in actions} | {a.get("target") for a in actions}

        def fit(u):
            return min(len(names & {n for n, x in u.items() if x["side"] == side}) / max(1, sum(1 for x in u.values() if x["side"] == side))
                       for side in SIDES)
        free = [(gid, u) for gid, u in records.items() if gid not in taken]
        best = max(free, key=lambda x: (round(fit(x[1]), 3), results.get(x[0]) == csv_vp.get(name)), default=None)
        if best and fit(best[1]) >= 0.6:
            taken.add(best[0])
            out.append((name, actions, best[1]))
        else:
            out.append((name, actions, None))
    return out


def _new_counts():
    return {s: {} for s in SIDES}


def _add(q, side, k, v=1):
    if side in q:
        q[side][k] = q[side].get(k, 0) + v


def _game_quality(actions, units):
    """One game: {side: {number: value}}; a share is kept as two numbers (k_yes, k_of) so a batch adds them up before dividing. Also the
    per-unit rows for the deployment tables: [(side, type, spot, points, output, first round it acted, lost VP)]."""
    q = _new_counts()
    types = _spell_types()
    side_of = lambda n, fallback=None: units[n]["side"] if units and n in units else fallback

    # Who did what, turn by turn.
    contact, declared, shot_at, fought = set(), set(), set(), set()
    first_act = {}
    for a in actions:
        t, text, turn, actor, target = a.get("type"), a.get("summary") or "", a.get("turn"), a.get("actor"), a.get("target")
        if t == "Charge" and actor:
            if ": made contact" in text:
                contact.add((turn, actor, target))
            elif " declares a charge against " in text or " redirects its charge to " in text:
                declared.add((turn, actor, target))
        elif t in ("Shooting", "WarMachineShot", "BreathWeapon") and actor:
            shot_at.add((turn, actor, target))
            first_act.setdefault(actor, turn)
        elif t == "SpellCast" and actor and "cast successfully" in text:
            first_act.setdefault(actor, turn)
        elif t in ("CombatAttack", "StompAttacks", "ImpactHits") and actor:
            fought.add((turn, actor))
    charged_targets = {(turn, side_of(actor, None), target) for turn, actor, target in contact}

    # Deployment: characters left alone (only an army the computer deployed says so).
    alone = set()
    for s in SIDES:
        if any(a.get("type") == "Computer" and a.get("phase") == "Deployment" and a.get("side") == s for a in actions):
            q[s]["chars_alone"] = 0
    for a in actions:
        if a.get("type") == "Computer" and a.get("phase") == "Deployment":
            m = _ALONE_LINE.match(a.get("summary") or "")
            if m and (a.get("side"), m["unit"]) not in alone:
                alone.add((a.get("side"), m["unit"]))
                _add(q, a.get("side"), "chars_alone")

    # Enemy units: top-3 by points, per side.
    top3 = {}
    if units:
        for s in SIDES:
            enemy = sorted(((u["points"], n) for n, u in units.items() if u["side"] != s and n), key=lambda x: x[0])
            top3[s] = {n for _, n in enemy[-3:]}

    # Shooting: the shots by kind, how many at a top-3 enemy unit or at a unit its side charged that turn.
    for turn, actor, target in shot_at:
        s = side_of(actor)
        kind = "wm" if units and units.get(actor, {}).get("type") == "War machine" else "shoot"
        _add(q, s, f"{kind}_shots")
        _add(q, s, f"{kind}_focus_of")
        if target in top3.get(s, ()) or (turn, s, target) in charged_targets:
            _add(q, s, f"{kind}_focus_yes")

    # Magic by kind: casts that went off, wounds caused, the share at a top-3 unit or that turn's charge target (missiles), augments on a
    # unit that fought or charged that turn, hexes on a unit its side charged or shot that turn.
    last_cast = {}
    for a in actions:
        text, turn = a.get("summary") or "", a.get("turn")
        if a.get("type") == "SpellCast" and "cast successfully" in text:
            m = _CAST.match(text)
            spell = m["spell"] if m else ""
            kind = types.get(spell, "Other")
            s, target = side_of(a.get("actor"), a.get("side")), a.get("target")
            last_cast[(turn, spell)] = kind
            _add(q, s, f"cast_{kind}")
            if kind == "MagicMissile" and target:
                _add(q, s, "missile_focus_of")
                if target in top3.get(s, ()) or (turn, s, target) in charged_targets:
                    _add(q, s, "missile_focus_yes")
            body = target or a.get("actor")  # a self spell (no target): its caster
            if kind == "Enchantment" and spell in _fight_only_spells() and body and side_of(body) == s:
                _add(q, s, "augment_of")
                if (turn, body) in fought or any(c[0] == turn and c[1] == body for c in contact | declared):
                    _add(q, s, "augment_yes")
            if kind == "Hex" and target and side_of(target) not in (None, s):
                _add(q, s, "hex_of")
                if (turn, s, target) in charged_targets or any(x[0] == turn and x[2] == target and side_of(x[1]) == s for x in shot_at):
                    _add(q, s, "hex_yes")
        elif a.get("type") == "SpellEffect":
            m = _RESOLVES.match(text)
            if m:
                kind = types.get(m["spell"], "Other")
                _add(q, side_of(a.get("actor"), a.get("side")), "wounds_missile" if kind == "MagicMissile" else "wounds_other_spell", int(m["n"]))

    # Strategy as support for the other phases: the turn's objectives carried out (charge: made contact with that target; shoot: shot it;
    # close in: charged it next turn), and the support requests (the helper charged the same target).
    for a in actions:
        if a.get("type") != "Computer" or a.get("phase") != "Strategy":
            continue
        text, turn, s = a.get("summary") or "", a.get("turn"), a.get("side")
        for k, rx, done in (("obj_charge", _OBJ_CHARGE, lambda u, tg: (turn, u, tg) in contact),
                            ("obj_shoot", _OBJ_SHOOT, lambda u, tg: (turn, u, tg) in shot_at),
                            ("obj_close", _OBJ_CLOSE, lambda u, tg: (turn + 1, u, tg) in contact or (turn + 1, u, tg) in declared)):
            m = rx.match(text)
            if m:
                _add(q, s, f"{k}_of")
                if done(m["unit"], m["target"]):
                    _add(q, s, f"{k}_yes")
                break
        h = _ASKS.match(text)
        if h:
            for helper in h["helpers"].split(" and "):
                _add(q, s, "help_of")
                if (turn, helper, h["target"]) in contact:
                    _add(q, s, "help_yes")

    # Points destroyed by cause, the characters joined to a unit (did it fight?), and the per-unit rows.
    rows = []
    if units:
        # Kills: the record's points earned (a fight's points shared by the wounds its winners caused); a record without them, the enemy
        # units it destroyed. Objectives: the scores the log names it for.
        out_by = {}
        for n, u in units.items():
            if u["earned"] is not None:
                out_by[n] = out_by.get(n, 0) + u["earned"]
            elif u["gone"] and u["by"]:
                out_by[u["by"]] = out_by.get(u["by"], 0) + u["vp"]
        obj_by = {}
        for a in actions:
            if a.get("kind") == "objective" and a.get("unit"):
                obj_by[a["unit"]] = obj_by.get(a["unit"], 0) + (a.get("points") or 0)
        for s in SIDES:
            for k in ("vp_shooting", "vp_war_machines", "vp_magic", "vp_combat", "vp_run_down"):
                q[s].setdefault(k, 0)
        for n, u in units.items():
            if u["gone"]:
                by = "Opponent" if u["side"] == "Mine" else "Mine"
                cause = {"Shooting": "vp_shooting", "WarMachine": "vp_war_machines", "Magic": "vp_magic", "Combat": "vp_combat",
                         "RunDown": "vp_run_down"}.get(u["cause"])
                if cause:
                    _add(q, by, cause, u["vp"])
            if u["character"]:
                key = "char_joined" if u["joined"] else "char_alone"
                _add(q, u["side"], f"{key}_of")
                if u["fought"]:
                    _add(q, u["side"], f"{key}_yes")
            if u["terrain"]:
                continue  # a baggage train
            acted = [r for r in (u["first_fought"], first_act.get(n)) if r is not None]
            rows.append((u["side"], u["type"], u["spot"], u["points"], out_by.get(n, 0) + obj_by.get(n, 0), min(acted) if acted else None,
                         u["vp"] if u["gone"] else 0, out_by.get(n, 0), obj_by.get(n, 0)))
    return q, rows


# (phase, label, number, kind): "n" = per game, "%" = share (k_yes of k_of), "pct" = a games.csv column per game.
QUALITY = [
    ("Deployment", "Characters standing alone", "chars_alone", "n"),
    ("Strategy", "Charge objectives carried out (made contact)", "obj_charge", "%"),
    ("Strategy", "Shoot objectives carried out (shot that target)", "obj_shoot", "%"),
    ("Strategy", "Close-in objectives charged next turn", "obj_close", "%"),
    ("Strategy", "Support requests answered (helper made contact too)", "help", "%"),
    ("Strategy", "Augments that last this turn, on a unit that fought or charged that turn", "augment", "%"),
    ("Strategy", "Hexes on a unit its side charged or shot that turn", "hex", "%"),
    ("Strategy", "Joined characters whose unit fought", "char_joined", "%"),
    ("Strategy", "Lone characters that fought", "char_alone", "%"),
    ("Movement", "Charges halted short of contact", "halted", "n"),
    ("Movement", "Idle units", "idle_units", "csv"),
    ("Movement", "Points that never moved of their own", "idle_points", "csv"),
    ("Shooting", "Shots by shooting units (incl. breath weapons)", "shoot_shots", "n"),
    ("Shooting", "  aimed at a top-3 enemy unit or that turn's charge target", "shoot_focus", "%"),
    ("Shooting", "Points destroyed by shooting units", "vp_shooting", "n"),
    ("Shooting", "War machine shots", "wm_shots", "n"),
    ("Shooting", "  aimed at a top-3 enemy unit or that turn's charge target", "wm_focus", "%"),
    ("Shooting", "Points destroyed by war machines", "vp_war_machines", "n"),
    ("Magic", "Magic missiles cast", "cast_MagicMissile", "n"),
    ("Magic", "  aimed at a top-3 enemy unit or that turn's charge target", "missile_focus", "%"),
    ("Magic", "Wounds caused by magic missiles", "wounds_missile", "n"),
    ("Magic", "Wounds caused by other spells", "wounds_other_spell", "n"),
    ("Magic", "Points destroyed by magic (all spells)", "vp_magic", "n"),
    ("Magic", "Augments / hexes / assailments / vortexes cast", "cast_mix", "mix"),
    ("Combat", "Points destroyed in combat", "vp_combat", "n"),
    ("Combat", "Points run down", "vp_run_down", "n"),
    ("Game", "Points lost", "points_lost", "csv"),
    ("Game", "VP from objectives", "vp_objectives", "csv"),
    ("Game", "Lone holders (player turns)", "lone_holders", "csv"),
]


def quality(batch_dir):
    """({side: {number: [per-game values]}}, per-unit rows, games.csv rows)."""
    rows = read_csv(os.path.join(batch_dir, "games.csv"))
    out = {s: {} for s in SIDES}
    units = []
    for _, actions, recs in _game_logs(batch_dir):
        q, r = _game_quality(actions, recs)
        units += r
        for s, metrics in q.items():
            for k, v in metrics.items():
                out[s].setdefault(k, []).append(v)
            out[s].setdefault("_games", []).append(1)
    for r in ended(rows):
        for s in SIDES:
            for k in ("idle_units", "idle_points", "points_lost", "vp_objectives", "lone_holders"):
                v = num(r, f"{k}_{s.lower()}")
                if v is not None:
                    out[s].setdefault(k, []).append(v)
    return out, units, rows


def _quality_cell(q, k, kind):
    games = len(q.get("_games", []))
    if kind == "%":
        y, n = sum(q.get(f"{k}_yes", [])), sum(q.get(f"{k}_of", []))
        return f"{100 * y / n:.0f}% ({y:.0f} of {n:.0f})" if n else "-"
    if kind == "mix":
        parts = [sum(q.get(f"cast_{t}", [])) / games if games else 0 for t in ("Enchantment", "Hex", "Assailment", "MagicalVortex")]
        return "-" if not games else " / ".join(f"{p:.1f}" for p in parts)
    values = [v for v in q.get(k, []) if v is not None]
    if kind == "csv":
        return fmt(mean(values), 1) if values else "-"
    return "-" if not games or not values else fmt(sum(values) / games, 1)


def _fight_numbers(batch_dir):
    """Per side over all armies: the charged fights (charged_fights), by odds band and alone / supported."""
    per = charged_fights(batch_dir)
    out = {}
    for s in SIDES:
        fights = [f for k, v in per.items() if k[0] == s for f in v["fights"]]
        games = sum(v["games"] for k, v in per.items() if k[0] == s)
        known = [f for f in fights if f[5] is not None]
        first = [f for f in fights if f[4] is not None]
        band = lambda lo, hi: [f for f in known if _band(f, lo, hi + 1)]
        def cell(fs):
            return f"{len(fs)} of {len(known)}, net {fmt(mean([f[1] - f[2] for f in fs]), sign=True)}" if fs else (f"0 of {len(known)}" if known else "-")
        out[s] = [
            ("Movement", "Fights charged into per game", fmt(len(fights) / games, 1) if games else "-"),
            ("Movement", "Charges with odds: long shots (under 50%)", cell(band(0, 49))),
            ("Movement", f"Charges with odds: sweet spot ({EFFECTIVE_LOW}-{EFFECTIVE_HIGH}%)", cell(band(EFFECTIVE_LOW, EFFECTIVE_HIGH))),
            ("Movement", "Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x)", cell(band(90, 100))),
            ("Movement", "Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x)", cell([f for f in known if _cheap_sure(f)])),
            ("Combat", "Net points per charged fight, damage counted", fmt(mean([f[7] - f[8] for f in fights]), sign=True)),
            ("Combat", "Net per 100 charger points, damage counted",
             fmt(100 * sum(f[7] - f[8] for f in fights) / sum(f[9] for f in fights), 1, sign=True) if sum(f[9] for f in fights) else "-"),
            ("Combat", "First round won (charged fights)", f"{100 * sum(1 for f in first if f[4]) / len(first):.0f}%" if first else "-"),
            ("Combat", "Net points per charged fight", fmt(mean([f[1] - f[2] for f in fights]), sign=True)),
            ("Combat", "Net points per supported fight / lone fight",
             f"{fmt(mean([f[1] - f[2] for f in fights if f[0] > 1]), sign=True)} / {fmt(mean([f[1] - f[2] for f in fights if f[0] == 1]), sign=True)}"),
            ("Combat", "Charged fights on a top-3 enemy unit", f"{sum(1 for f in fights if f[3])} of {len(fights)}" if fights else "-"),
        ]
    return out


def deployment_tables(units, label):
    """Positions vs output by unit type (Morten 2026-11-08): per side and type, output per 100 points by where it deployed."""
    units = [u for u in units if u[3]]
    if not units:
        return []
    spots = [("left", lambda s: s.startswith("left")), ("centre", lambda s: s.startswith("centre")), ("right", lambda s: s.startswith("right")),
             ("front half", lambda s: s.endswith("front half")), ("back half", lambda s: s.endswith("back half"))]
    per100 = lambda us: f"{100 * sum(u[4] for u in us) / sum(u[3] for u in us):.0f} ({len(us)})" if us and sum(u[3] for u in us) else "-"
    out = [f"### Deployment: positions vs output by unit type: {label}", "",
           "Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of "
           "the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs "
           "from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round "
           "of its first action. Joined characters count where their unit deployed.", "",
           "| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | "
           + " | ".join(f"Output per 100: {n}" for n, _ in spots) + " |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | " + " | ".join("---" for _ in spots) + " |"]
    for s in SIDES:
        for t in sorted({u[1] for u in units if u[0] == s}):
            us = [u for u in units if u[0] == s and u[1] == t]
            pts = sum(u[3] for u in us)
            never = sum(1 for u in us if u[5] is None)
            out.append(f"| {s} | {t} | {len(us)} | {per100(us)} | {100 * sum(u[7] for u in us) / pts:.0f} | {100 * sum(u[8] for u in us) / pts:.0f} | "
                       f"{100 * sum(u[6] for u in us) / pts:.0f} | {100 * never / len(us):.0f}% | "
                       f"{fmt(mean([u[5] for u in us]), 1)} | " + " | ".join(per100([u for u in us if u[2] and f(u[2])]) for _, f in spots) + " |")
    return out


def balance_lines(rows):
    """Who won: by side, and by who went first (a Medium vs Medium batch should be near even on both; a swapped pair "A1s" says it per army)."""
    e = ended(rows)
    if not e:
        return []
    w, d, l = wdl(e)
    first = [r for r in e if r.get("first_player") in SIDES and r.get("winner") in SIDES]
    firsts = sum(1 for r in first if r["winner"] == r["first_player"])
    out = [f"- Mine won / drew / lost: {w} / {d} / {l} of {len(e)} ended games (of {len(rows)}); mean margin (Mine - Opponent) {fmt(mean([margin(r) for r in e]), sign=True)} VP"]
    if first:
        out.append(f"- The side that went first won {firsts} of {len(first)} games with a winner")
    traded = [num(r, "points_lost_mine", 0) + num(r, "points_lost_opponent", 0) for r in e if r.get("points_lost_mine")]
    if traded:
        out.append(f"- Points traded per game (both sides' losses): {mean(traded):.0f}")
    stalled = [r for r in rows if r.get("ended") != "yes"]
    out.append(f"- Games not ended: {len(stalled)}" + (f" ({', '.join(sorted(r.get('pair', '') + '-' + r.get('seed', '') for r in stalled))})" if stalled else "")
               + f"; findings {sum(num(r, 'findings', 0) for r in rows):.0f}, warnings {sum(num(r, 'warnings', 0) for r in rows):.0f}")
    # Swapped pairs (simulate-local.sh --swap-sides): each army's result on both sides of the same match-up.
    by = {key(r): r for r in e}
    swaps = [(r, by.get((r["pair"] + "s", r.get("scenario", ""), r.get("seed", "")))) for r in e if not r.get("pair", "").endswith("s")]
    swaps = [(a, b) for a, b in swaps if b]
    if swaps:
        same = sum(1 for a, b in swaps if a.get("winner") in SIDES and b.get("winner") in SIDES and a["winner"] != b["winner"])
        out.append(f"- Swapped pairs: in {same} of {len(swaps)} the same army won from both sides (the list decides); the margin moves "
                   f"{fmt(mean([margin(a) + margin(b) for a, b in swaps]), sign=True)} VP towards Mine on average when the lists swap")
    return out


def _quality_rows(batch_dir):
    """[(phase, label, Mine cell, Opponent cell)] in phase order, and the per-unit rows and games.csv rows."""
    q, units, rows = quality(batch_dir)
    if not q["Mine"].get("_games") and not rows:
        return [], units, rows
    halted = _halted(batch_dir)
    for s in SIDES:
        q[s]["halted"] = halted.get(s, [])
    fights = _fight_numbers(batch_dir)
    out = []
    order = ["Deployment", "Strategy", "Movement", "Shooting", "Magic", "Combat", "Game"]
    for phase in order:
        for p, title, k, kind in QUALITY:
            if p != phase:
                continue
            cells = [_quality_cell(q[s], k, kind) for s in SIDES]
            if any(c != "-" for c in cells):
                out.append((p, title, cells[0], cells[1]))
        for i, (p, title, _) in enumerate(fights["Mine"]):
            if p == phase:
                cells = [fights[s][i][2] for s in SIDES]
                if any(c != "-" for c in cells):
                    out.append((p, title, cells[0], cells[1]))
    return out, units, rows


def _halted(batch_dir):
    """{side: [halted charges per game]}: a charge halted short of contact (blocked; most often by its own units)."""
    out = {s: [] for s in SIDES}
    for _, actions, units in _game_logs(batch_dir):
        n = dict.fromkeys(SIDES, 0)
        for a in actions:
            if a.get("type") == "Charge" and a.get("actor") and "halted" in (a.get("summary") or ""):
                s = units[a["actor"]]["side"] if units and a["actor"] in units else a.get("side")
                if s in n:
                    n[s] += 1
        for s in SIDES:
            out[s].append(n[s])
    return out


# Opponent rules (Morten 2026-11-08 20:27 "1 and 2"): each time Medium or Hard takes an option one of the newer rules changed, the game log
# has one "OpponentRule" action: "<TAG>: <+/-VP> VP: <what>", its actor the unit that decided and its target what it aimed at (OpponentRules.cs).
# Per side: how often each rule fired (a game), the VP its figure added (or took away), and in the fights or moves it chose the VP won (its
# target destroyed that round or the next) and lost (the unit itself destroyed that round or the next).
# Tags may hold a hyphen (COUNTER-CHARGE COVER, SET-UP MISSED, ARTILLERY RE-ROLL WEIGHED: left out of every report before 2026-11-12).
_RULE = re.compile(r"^(?P<tag>[A-Z][A-Z -]*?): (?P<vp>[+-]\d+(?:\.\d+)?) VP: ")


def opponent_rules(batch_dir):
    """({side: {tag: [fired, figure VP, VP won, VP lost]}}, games)."""
    out = {s: {} for s in SIDES}
    games = 0
    for _, actions, units in _game_logs(batch_dir):
        games += 1
        for a in actions:
            if a.get("type") != "OpponentRule":
                continue
            m = _RULE.match(a.get("summary") or "")
            side = a.get("side")
            if not m or side not in out:
                continue
            row = out[side].setdefault(m.group("tag"), [0, 0.0, 0.0, 0.0])
            row[0] += 1
            row[1] += float(m.group("vp"))
            turn = a.get("turn") or 0

            def gone(name):
                u = (units or {}).get(name)
                return u["vp"] if u and u["gone"] and u["round"] is not None and turn <= u["round"] <= turn + 1 else 0
            row[2] += gone(a.get("target"))
            row[3] += gone(a.get("actor"))
    return out, games


def opponent_rules_table(batch_dir, label):
    rules, games = opponent_rules(batch_dir)
    tags = sorted({t for s in SIDES for t in rules[s]})
    if not tags or not games:
        return []
    out = [f"### Opponent rules: {label}", "",
           "Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: "
           "took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.", "",
           "| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for t in tags:
        cells = []
        for s in SIDES:
            r = rules[s].get(t)
            cells += ["-"] * 4 if r is None else [fmt(r[0] / games, 1), fmt(r[1] / games, 1, sign=True), fmt(r[2] / games, 1), fmt(r[3] / games, 1)]
        out.append(f"| {t} | " + " | ".join(cells) + " |")
    return out


def opponent_rules_compare(a_dir, b_dir, a_label, b_label):
    ra, ga = opponent_rules(a_dir)
    rb, gb = opponent_rules(b_dir)
    tags = sorted({t for r in (ra, rb) for s in SIDES for t in r[s]})
    if not tags:
        return []
    out = ["## Opponent rules (fired a game, figure / won / lost VP a game)", "",
           "| Rule | A Mine | A Opponent | B Mine | B Opponent |", "| --- | --- | --- | --- | --- |"]

    def cell(r, g):
        return "-" if r is None or not g else f"{fmt(r[0] / g, 1)} ({fmt(r[1] / g, 0, sign=True)} / {fmt(r[2] / g, 0)} / {fmt(r[3] / g, 0)})"
    for t in tags:
        out.append(f"| {t} | {cell(ra['Mine'].get(t), ga)} | {cell(ra['Opponent'].get(t), ga)} | {cell(rb['Mine'].get(t), gb)} | {cell(rb['Opponent'].get(t), gb)} |")
    return out + ["", f"A = {a_label}, B = {b_label}."]


# Rule changes (Morten 2026-11-12, "all rules"): an OpponentRule row whose rule says what it changed ends "| CHANGED: <+/-VP> VP v <+/-VP> VP
# instead of <choice>" (the decision would have gone to <choice> without the rule) or "| SAME: ..." (it would not; <choice> is the runner-up).
# Per rule, both sides together: fired, checked (rows that say), changed, and the VP the changes were worth by the rule's own numbers (the
# taken choice's figure minus the replaced one's). Rows with no tail come from rules that do not say yet ("not checked").
_CHANGE = re.compile(r" \| (?P<kind>CHANGED|SAME): (?P<chosen>[+-]\d+(?:\.\d+)?) VP v (?P<instead>[+-]\d+(?:\.\d+)?) VP(?: instead of (?P<what>.*))?$")


# Rows that trace a plan or count a happening instead of deciding between choices: "trace" in the table, not "not checked".
_TRACE_TAGS = {"HUNT THE GUNS", "HUNT KEPT", "HUNT DROPPED", "HUNT RESULT", "PLAN RESULT", "MARCH AT ESCAPER", "MOVE SPELL OUT OF RANGE",
               "CASTS AFTER FRIENDS", "SET-UP MISSED"}


def rule_changes(batch_dir):
    """({tag: [fired, checked, changed, VP of the changes]}, games)."""
    out, games = {}, 0
    for _, actions, _units in _game_logs(batch_dir):
        games += 1
        for a in actions:
            if a.get("type") != "OpponentRule":
                continue
            text = a.get("summary") or ""
            m = _RULE.match(text)
            if not m:
                continue
            row = out.setdefault(m.group("tag"), [0, 0, 0, 0.0])
            row[0] += 1
            c = _CHANGE.search(text)
            if c:
                row[1] += 1
                if c.group("kind") == "CHANGED":
                    row[2] += 1
                    row[3] += float(c.group("chosen")) - float(c.group("instead"))
    return out, games


def rule_changes_table(batch_dir, label):
    rules, games = rule_changes(batch_dir)
    if not rules or not games or not any(r[1] for r in rules.values()):
        return []
    out = [f"### Rule changes: {label}", "",
           "Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way "
           "without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); "
           "a game = changed / games.", "",
           "| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |", "| --- | --- | --- | --- | --- | --- | --- |"]
    for t in sorted(rules, key=lambda t: (-rules[t][2], t)):
        f, k, c, vp = rules[t]
        out.append(f"| {t} | {f} | {k if k else 'trace' if t in _TRACE_TAGS else 'not checked'} | {c if k else '-'} | {fmt(c / games, 2) if k else '-'} | "
                   f"{fmt(vp, 0, sign=True) if c else '-'} | {fmt(vp / c, 1, sign=True) if c else '-'} |")
    return out


def rule_changes_compare(a_dir, b_dir, a_label, b_label):
    ra, ga = rule_changes(a_dir)
    rb, gb = rule_changes(b_dir)
    if not any(r[1] for r in list(ra.values()) + list(rb.values())):
        return []
    out = ["## Rule changes (changed a game, VP a change)", "", "| Rule | A | B |", "| --- | --- | --- |"]

    def cell(r, g):
        return "-" if r is None or not g or not r[1] else f"{fmt(r[2] / g, 2)} ({fmt(r[3] / r[2], 1, sign=True) if r[2] else '-'})"
    for t in sorted(set(ra) | set(rb)):
        out.append(f"| {t} | {cell(ra.get(t), ga)} | {cell(rb.get(t), gb)} |")
    return out + ["", f"A = {a_label}, B = {b_label}."]

# Off best figure (Morten 2026-11-13, "it is your code so should follow best overall?"): every time Medium or Hard takes less than the
# best figure on a list, by whose say. Two kinds of rows: OFF BEST rows (OffBest.cs) name a gate in brackets ("OFF BEST: -12.0 VP: [JOB FIRST]
# stays | CHANGED: +3.0 VP v +15.0 VP instead of ..."); any other rule row whose CHANGED tail says the rule took the lower figure counts under
# that rule's tag. Per reason and side: times a game, and the VP given up a time (the best figure minus the taken one, by the row's numbers).
# NO REASON is a pick below the best that nothing named - the tests refuse those, so in a batch it means code the tests never reach.
_OFF_BEST_TAG = "OFF BEST"
_OFF_BEST_REASON = re.compile(r"\[(?P<why>[A-Z][A-Z' -]*)\]")
_OFF_BEST_TOLERANCE = 0.5


def off_best(batch_dir):
    """({side: {reason: [times, VP given up]}}, {reason: "gate" or "rule"}, games)."""
    out = {s: {} for s in SIDES}
    kinds = {}
    games = 0
    for _, actions, _units in _game_logs(batch_dir):
        games += 1
        for a in actions:
            if a.get("type") != "OpponentRule" or a.get("side") not in out:
                continue
            text = a.get("summary") or ""
            m = _RULE.match(text)
            c = _CHANGE.search(text)
            if not m or not c or c.group("kind") != "CHANGED":
                continue
            gap = float(c.group("instead")) - float(c.group("chosen"))
            if m.group("tag") == _OFF_BEST_TAG:
                r = _OFF_BEST_REASON.search(text)
                why, kind = (r.group("why") if r else "NO REASON"), "gate"
            elif gap > _OFF_BEST_TOLERANCE:
                why, kind = m.group("tag"), "rule"
            else:
                continue
            kinds[why] = kind
            row = out[a["side"]].setdefault(why, [0, 0.0])
            row[0] += 1
            row[1] += gap
    return out, kinds, games


def off_best_table(batch_dir, label):
    picks, kinds, games = off_best(batch_dir)
    reasons = sorted(kinds, key=lambda r: (-sum(picks[s].get(r, [0, 0])[0] for s in SIDES), r))
    if not reasons or not games:
        return []
    out = [f"### Off best figure: {label}", "",
           "Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took "
           "the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = "
           "nothing named it (code the tests never reach).", "",
           "| Reason | Kind | Mine a game | Opponent a game | VP a time |", "| --- | --- | --- | --- | --- |"]
    for r in reasons:
        cells = [fmt(picks[s][r][0] / games, 2) if r in picks[s] else "-" for s in SIDES]
        n = sum(picks[s].get(r, [0, 0])[0] for s in SIDES)
        vp = sum(picks[s].get(r, [0, 0.0])[1] for s in SIDES)
        out.append(f"| {r} | {kinds[r]} | {cells[0]} | {cells[1]} | {fmt(vp / n, 1)} |")
    return out


def off_best_compare(a_dir, b_dir, a_label, b_label):
    pa, ka, ga = off_best(a_dir)
    pb, kb, gb = off_best(b_dir)
    reasons = sorted(set(ka) | set(kb))
    if not reasons:
        return []
    out = ["## Off best figure (times a game, both sides; VP a time)", "", "| Reason | A | B |", "| --- | --- | --- |"]

    def cell(p, r, g):
        n = sum(p[s].get(r, [0, 0])[0] for s in SIDES)
        return "-" if not n or not g else f"{fmt(n / g, 2)} ({fmt(sum(p[s].get(r, [0, 0.0])[1] for s in SIDES) / n, 1)})"
    for r in reasons:
        out.append(f"| {r} | {cell(pa, r, ga)} | {cell(pb, r, gb)} |")
    return out + ["", f"A = {a_label}, B = {b_label}."]


# Plans (Morten 2026-11-12, "yes" to a plan-versus-result check for every move): each Start of Turn, one hidden "PLAN RESULT: <+VP> VP:
# happened=yes|no won=<VP> planned=<VP> kind=<charge|close in|advance|shoot|hold|support|join>: <objective> (why)" row per unit for last
# turn's objective (MovePlans.cs). Per side and kind: plans, the share that happened, VP planned and won (a game), won as a share of planned.
_PLAN = re.compile(r"^PLAN RESULT: [+-][\d.]+ VP: happened=(?P<h>yes|no) won=(?P<won>[\d.]+) planned=(?P<planned>-?[\d.]+) kind=(?P<kind>[a-z ]+?): ")


def plan_results(batch_dir):
    """({side: {kind: [plans, happened, planned VP, won VP]}}, games)."""
    out = {s: {} for s in SIDES}
    games = 0
    for _, actions, _units in _game_logs(batch_dir):
        games += 1
        for a in actions:
            if a.get("type") != "OpponentRule" or a.get("side") not in out:
                continue
            m = _PLAN.match(a.get("summary") or "")
            if not m:
                continue
            row = out[a["side"]].setdefault(m.group("kind"), [0, 0, 0.0, 0.0])
            row[0] += 1
            row[1] += m.group("h") == "yes"
            row[2] += max(0.0, float(m.group("planned")))
            row[3] += float(m.group("won"))
    return out, games


def _plan_cells(r, games):
    if r is None or not games:
        return ["-"] * 5
    share = f"{fmt(100 * r[3] / r[2], 0)}%" if r[2] > 0 else "-"
    return [fmt(r[0] / games, 1), f"{fmt(100 * r[1] / r[0], 0)}%", fmt(r[2] / games, 0), fmt(r[3] / games, 0), share]


def plans_table(batch_dir, label):
    plans, games = plan_results(batch_dir)
    kinds = sorted({k for s in SIDES for k in plans[s]})
    if not kinds or not games:
        return []
    out = [f"### Plans: {label}", "",
           "Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or "
           "the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in "
           "place), VP planned and won a game, won as a share of planned.", "",
           "| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |", "| --- | --- | --- | --- | --- | --- | --- |"]
    for s in SIDES:
        for k in kinds:
            if k in plans[s]:
                out.append(f"| {s} | {k} | " + " | ".join(_plan_cells(plans[s][k], games)) + " |")
    return out


def plans_compare(a_dir, b_dir, a_label, b_label):
    pa, ga = plan_results(a_dir)
    pb, gb = plan_results(b_dir)
    kinds = sorted({k for p in (pa, pb) for s in SIDES for k in p[s]})
    if not kinds:
        return []
    out = ["## Plans (happened, won of planned)", "", "| Side | Plan | A | B |", "| --- | --- | --- | --- |"]

    def cell(r, g):
        c = _plan_cells(r, g)
        return "-" if c[0] == "-" else f"{c[1]} ({c[4]})"
    for s in SIDES:
        for k in kinds:
            out.append(f"| {s} | {k} | {cell(pa[s].get(k), ga)} | {cell(pb[s].get(k), gb)} |")
    return out + ["", f"A = {a_label}, B = {b_label}."]


# Packages (movement plan review 2026-11-11, 7a; Morten 19:23 "make sure to be able to trace when the plays are called such that we can see
# if it actually works"): each hunt of an enemy war machine or lone Wizard leaves hidden OpponentRule rows (HuntTheGuns.cs) - HUNT THE GUNS
# when a hunter takes one ("planned=..."), HUNT KEPT / HUNT DROPPED each later Start of Turn, HUNT RESULT when it ends ("reached=yes turns=2
# killed=yes broken=no stopped=34.0 won=120.0 planned=150.0 worked=yes end=Slain: ..."). worked = won at least 2/3 of planned. A hunt with no
# result row was still going on when the game ended. Beside them: the points the enemy's war machines destroyed, a game (lower is better).
_HUNT_KV = re.compile(r"(\w+)=([^\s:]+)")
_HUNT_TAGS = ("HUNT THE GUNS", "HUNT KEPT", "HUNT DROPPED", "HUNT RESULT")


def _packages_game(actions, units):
    """{side: counters} for one game's hunts and the points the other side's war machines destroyed."""
    q = _new_counts()
    for a in actions:
        if a.get("type") != "OpponentRule":
            continue
        m = _RULE.match(a.get("summary") or "")
        side = a.get("side")
        if not m or side not in q or m.group("tag") not in _HUNT_TAGS:
            continue
        tag = m.group("tag")
        kv = dict(_HUNT_KV.findall((a.get("summary") or "")[m.end():].split(": ", 1)[0]))
        if tag == "HUNT THE GUNS":
            _add(q, side, "started")
            _add(q, side, "planned_started", float(kv.get("planned", 0)))
        elif tag == "HUNT KEPT":
            _add(q, side, "kept")
        elif tag == "HUNT DROPPED":
            _add(q, side, "dropped")
        else:
            _add(q, side, "ended")
            for k in ("reached", "killed", "broken", "worked"):
                if kv.get(k) == "yes":
                    _add(q, side, k)
            _add(q, side, "planned", float(kv.get("planned", 0)))
            _add(q, side, "won", float(kv.get("won", 0)))
            _add(q, side, "stopped", float(kv.get("stopped", 0)))
            if kv.get("killed") == "yes":
                _add(q, side, "turns_to_kill", int(kv.get("turns", 0)))
    for side in SIDES:
        q[side]["wm_damage"] = sum(u.get("earned") or 0 for u in (units or {}).values()
                                   if u.get("type") == "War machine" and u.get("side") != side)
        q[side]["wm_known"] = 1 if units else 0
    return q


def packages(batch_dir):
    """({side: counters}, {army: counters}, games read)."""
    by_side, by_army, games = {s: {} for s in SIDES}, {}, 0
    for _, actions, units in _game_logs(batch_dir):
        games += 1
        armies = {u["side"]: u["army"] for u in (units or {}).values() if u.get("army")}
        for s, c in _packages_game(actions, units).items():
            targets = [by_side[s]] + ([by_army.setdefault(armies[s], {})] if s in armies else [])
            for t in targets:
                t["_games"] = t.get("_games", 0) + 1
                for k, v in c.items():
                    t[k] = t.get(k, 0) + v
    return by_side, by_army, games


def _package_cells(c):
    g, n, e = c.get("_games", 0), c.get("started", 0), c.get("ended", 0)

    def share(k):
        return f"{100 * c.get(k, 0) / e:.0f}%" if e else "-"
    kills = c.get("killed", 0)
    wm = f"{c.get('wm_damage', 0) / c['wm_known']:.0f}" if c.get("wm_known") else "-"
    return [f"{n / g:.1f}" if g else "-", f"{n:.0f}", f"{max(0, n - e):.0f}", share("reached"), share("killed"), share("broken"),
            f"{c.get('turns_to_kill', 0) / kills:.1f}" if kills else "-",
            f"{c.get('planned', 0) / e:.0f}" if e else "-", f"{c.get('won', 0) / e:.0f}" if e else "-", share("worked"), wm]


_PACKAGE_HEAD = ["Jobs a game", "Jobs", "Open at the end", "Reached", "Killed", "Broken", "Turns to kill", "Planned VP a job", "Won VP a job",
                 "Worked (won 2/3+)", "Enemy war machines' kills a game"]


def packages_table(batch_dir, label):
    by_side, by_army, games = packages(batch_dir)
    if not games or not any(c.get("started") for c in by_side.values()):
        return []
    out = [f"### Packages: hunt the guns, {label}", "",
           "Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; "
           "turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; "
           "the last column is the points the enemy's war machines destroyed, a game.", "",
           "| Side | " + " | ".join(_PACKAGE_HEAD) + " |", "| --- |" + " --- |" * len(_PACKAGE_HEAD)]
    out += [f"| {s} | " + " | ".join(_package_cells(by_side[s])) + " |" for s in SIDES]
    if by_army:
        out += ["", "| Army | " + " | ".join(_PACKAGE_HEAD) + " |", "| --- |" + " --- |" * len(_PACKAGE_HEAD)]
        out += [f"| {a} | " + " | ".join(_package_cells(by_army[a])) + " |" for a in sorted(by_army)]
    return out


def packages_compare(a_dir, b_dir, a_label, b_label):
    sa, _, ga = packages(a_dir)
    sb, _, gb = packages(b_dir)
    if not ga or not gb or not any(c.get("started") for d in (sa, sb) for c in d.values()):
        return []
    out = ["## Packages: hunt the guns (per side)", "", "| Batch | Side | " + " | ".join(_PACKAGE_HEAD) + " |",
           "| --- | --- |" + " --- |" * len(_PACKAGE_HEAD)]
    for name, d in (("A", sa), ("B", sb)):
        out += [f"| {name} | {s} | " + " | ".join(_package_cells(d[s])) + " |" for s in SIDES]
    return out + ["", f"A = {a_label}, B = {b_label}."]


def _packages_self_test():
    """The Packages part on a made-up log: one hunt that killed its cannon in 2 turns, one dropped, one still open."""
    rows = [
        ("Mine", 2, "HUNT THE GUNS: +310.0 VP: planned=310.0 figure=19.4 output=10.0: hunts the war machine #1 Cannon (250 VP)"),
        ("Mine", 3, "HUNT KEPT: +30.0 VP: turn 2: charge #1 Cannon"),
        ("Mine", 4, "HUNT RESULT: +290.0 VP: reached=yes turns=3 killed=yes broken=no stopped=40.0 won=290.0 planned=310.0 worked=yes end=Slain: war machine #1 Cannon (it is gone)"),
        ("Mine", 2, "HUNT THE GUNS: +100.0 VP: planned=100.0 figure=5.0 output=5.0: hunts the lone Wizard #7 Shaman (80 VP)"),
        ("Mine", 3, "HUNT DROPPED: +0.0 VP: turn 2: took charge #9 Goblins (~25 VP) instead"),
        ("Mine", 3, "HUNT RESULT: +0.0 VP: reached=no turns=2 killed=no broken=no stopped=0.0 won=0.0 planned=100.0 worked=no end=Dropped: lone Wizard #7 Shaman (took ...)"),
        ("Opponent", 2, "HUNT THE GUNS: +200.0 VP: planned=200.0 figure=9.0 output=8.0: hunts the war machine #3 Bolt Thrower (100 VP)"),
        ("Opponent", 2, "WEARS DOWN: +3.0 VP: charge #4 Knights"),
    ]
    with tempfile.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, "game-P1-1-1.log.jsonl"), "w") as f:
            for side, turn, summary in rows:
                f.write(json.dumps({"kind": "action", "type": "OpponentRule", "turn": turn, "phase": "Strategy", "side": side, "summary": summary}) + "\n")
        by_side, _, games = packages(tmp)
        mine, opp = by_side["Mine"], by_side["Opponent"]
        cells = _package_cells(mine)
        problems = []
        if games != 1 or (mine.get("started"), mine.get("ended"), mine.get("killed"), mine.get("worked")) != (2, 2, 1, 1):
            problems.append(f"packages counts {mine}")
        if cells[:10] != ["2.0", "2", "0", "50%", "50%", "0%", "3.0", "205", "145", "50%"] or cells[10] != "-":
            problems.append(f"packages cells {cells}")
        if (opp.get("started"), opp.get("ended", 0), _package_cells(opp)[2]) != (1, 0, "1"):
            problems.append(f"packages open hunt {opp}")
        if "### Packages: hunt the guns, p" not in "\n".join(packages_table(tmp, "p")) or "## Packages" not in "\n".join(packages_compare(tmp, tmp, "x", "y")):
            problems.append("packages table / compare")
    return problems

# Battle-group rework option 1 (Morten 2026-11-12, "yes 1 and 2"; "ensure that they tie with new way of tracing changes"): did the promised
# counter-charge come? Each COUNTER-CHARGE COVER / REDIRECT COUNTER row (one per unit and turn) names, in its note, the enemies that may charge
# the unit ("Knights 60% charge it") and the friends that would counter ("Riders counters 85% into its flank"). Read on the log: the unit
# charged by the enemy that round or the next; by a named enemy; that charger then charged by the side before the end of the following round;
# by a named friend; and when no counter came, why - the charger gone or fleeing, the named friend gone, the named friend charged another
# enemy, or the named friend charged nothing.
# GROUP AIM rows (one per unit, target and turn; note "group aim #3 Halberdiers with #12 Raiders (...)"): the unit charged that target within
# the next three rounds, and together with the partner the same round.
_COVER_TAGS = ("COUNTER-CHARGE COVER", "REDIRECT COUNTER")
_RULE_NOTE = re.compile(r"^[A-Z][A-Z -]*?: [+-][\d.]+ VP: (?:stays|\w+ to \([^)]*\))(?:: (?P<note>.*?))?(?: \| (?:CHANGED|SAME): .*)?$")
_COVER_ENEMY = re.compile(r"(?:^|; )(?P<e>[^;:]+?) \d+% charges? it")
_COVER_FRIEND = re.compile(r"(?:, |and |else |: )(?P<f>[^;:,]+?) counters")
_AIM_NOTE = re.compile(r"group aim #\d+ (?P<t>.+?) with #\d+ (?P<p>.+?) \(")
_COVER_WHY = ("charger gone or fled", "friend gone", "friend charged another", "friend charged nothing", "no friend named")


def _unit_gone_by(units, name, turn):
    u = (units or {}).get(name)
    return bool(u and u.get("gone") and u.get("round") is not None and u["round"] <= turn)


def _cover_game(actions, units, out):
    charges = sorted((a for a in actions if a.get("type") == "Charge" and a.get("id") is not None), key=lambda a: a["id"])
    seen = set()
    for a in actions:
        if a.get("type") != "OpponentRule" or a.get("side") not in out:
            continue
        m = _RULE.match(a.get("summary") or "")
        if not m or m.group("tag") not in _COVER_TAGS:
            continue
        side, unit, turn, tag = a["side"], a.get("actor"), a.get("turn") or 0, m.group("tag")
        if (tag, side, unit, turn) in seen:
            continue
        seen.add((tag, side, unit, turn))
        n = _RULE_NOTE.match(a.get("summary") or "")
        note = (n.group("note") or "") if n else ""
        enemies = {x.group("e").strip() for x in _COVER_ENEMY.finditer(note)}
        friends = {x.group("f").strip() for x in _COVER_FRIEND.finditer(note)}
        r = out[side].setdefault(tag, {"rows": 0, "charged": 0, "named enemy": 0, "answered": 0, "named friend": 0, **{w: 0 for w in _COVER_WHY}})
        r["rows"] += 1
        hit = next((c for c in charges if c["id"] > (a.get("id") or 0) and c.get("side") != side and c.get("target") == unit and (c.get("turn") or 0) <= turn + 1), None)
        if hit is None:
            continue
        r["charged"] += 1
        r["named enemy"] += hit.get("actor") in enemies
        ct = hit.get("turn") or 0
        answer = next((c for c in charges if c["id"] > hit["id"] and c.get("side") == side and c.get("target") == hit.get("actor") and (c.get("turn") or 0) <= ct + 1), None)
        if answer is not None:
            r["answered"] += 1
            r["named friend"] += answer.get("actor") in friends
            continue
        if _unit_gone_by(units, hit.get("actor"), ct + 1) or any(x.get("type") in ("Flee", "BreakTestMove") and x.get("actor") == hit.get("actor") and x["id"] > hit["id"]
                                                               and (x.get("turn") or 0) <= ct + 1 for x in actions if x.get("id") is not None):
            r["charger gone or fled"] += 1
        elif not friends:
            r["no friend named"] += 1
        elif all(_unit_gone_by(units, f, ct + 1) for f in friends):
            r["friend gone"] += 1
        elif any(c["id"] > hit["id"] and c.get("side") == side and c.get("actor") in friends and (c.get("turn") or 0) <= ct + 1 for c in charges):
            r["friend charged another"] += 1
        else:
            r["friend charged nothing"] += 1


def _aim_game(actions, out):
    charges = [a for a in actions if a.get("type") == "Charge"]
    seen = set()
    for a in actions:
        if a.get("type") != "OpponentRule" or a.get("side") not in out:
            continue
        s = a.get("summary") or ""
        if not s.startswith("GROUP AIM: "):
            continue
        m = _AIM_NOTE.search(s)
        if not m:
            continue
        side, unit, turn, target, partner = a["side"], a.get("actor"), a.get("turn") or 0, m.group("t"), m.group("p")
        r = out[side]
        r["rows"] += 1
        if (side, unit, target) in seen:
            continue
        seen.add((side, unit, target))
        r["aims"] += 1
        mine = [c for c in charges if c.get("side") == side and c.get("actor") == unit and c.get("target") == target and turn <= (c.get("turn") or 0) <= turn + 3]
        if mine:
            r["charged it"] += 1
            if any(c.get("side") == side and c.get("actor") == partner and c.get("target") == target and c.get("turn") == mine[0].get("turn") for c in charges):
                r["together"] += 1


def battle_group_results(batch_dir):
    """({side: {cover tag: counts}}, {side: aim counts}, games)."""
    cover = {s: {} for s in SIDES}
    aims = {s: {"rows": 0, "aims": 0, "charged it": 0, "together": 0} for s in SIDES}
    games = 0
    for _, actions, units in _game_logs(batch_dir):
        games += 1
        _cover_game(actions, units, cover)
        _aim_game(actions, aims)
    return cover, aims, games


def _pct(n, d):
    return f"{fmt(100 * n / d, 0)}%" if d else "-"


def battle_groups_table(batch_dir, label):
    cover, aims, games = battle_group_results(batch_dir)
    if not games or not any(cover[s] for s in SIDES) and not any(aims[s]["rows"] for s in SIDES):
        return []
    out = [f"### Battle groups: {label}", "",
           "Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those "
           "charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).", "",
           "| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | " + " | ".join(w.capitalize() for w in _COVER_WHY) + " |",
           "| --- | --- | --- | --- | --- | --- | --- | " + " | ".join("---" for _ in _COVER_WHY) + " |"]
    for s in SIDES:
        for tag, r in sorted(cover[s].items()):
            out.append(f"| {s} | {tag} | {fmt(r['rows'] / games, 1)} | {_pct(r['charged'], r['rows'])} | {_pct(r['named enemy'], r['charged'])} | "
                       f"{_pct(r['answered'], r['charged'])} | {_pct(r['named friend'], r['answered'])} | "
                       + " | ".join(_pct(r[w], r['charged'] - r['answered']) for w in _COVER_WHY) + " |")
    out += ["", "Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its "
            "partner charged it the same round).", "", "| Side | Rows | Aims | Charged it | Together |", "| --- | --- | --- | --- | --- |"]
    for s in SIDES:
        r = aims[s]
        out.append(f"| {s} | {fmt(r['rows'] / games, 1)} | {r['aims']} | {_pct(r['charged it'], r['aims'])} | {_pct(r['together'], r['charged it'])} |")
    return out


def _battle_groups_self_test():
    """The Battle groups part on a made-up log: a covered unit charged by the named enemy and countered by the named friend; one charged and
    not countered (the named friend charged another); a group aim that came off together."""
    rows = [
        {"id": 1, "type": "OpponentRule", "turn": 1, "side": "Mine", "actor": "Spearmen",
         "summary": "COUNTER-CHARGE COVER: +40.0 VP: stays: Knights 60% charge it, Riders counters 85% into its flank ~70 VP | SAME: +5.0 VP v +2.0 VP instead of x"},
        {"id": 2, "type": "OpponentRule", "turn": 1, "side": "Mine", "actor": "Archers",
         "summary": "COUNTER-CHARGE COVER: +20.0 VP: move to (4.0, 5.0): Wolves 50% charge it, Riders counters 40% into its front ~30 VP"},
        {"id": 3, "type": "OpponentRule", "turn": 1, "side": "Mine", "actor": "Gors",
         "summary": "GROUP AIM: +9.0 VP: move to (42.0, 24.0): group aim #1 Halberdiers with #3 Raiders (together in reach after 1 more move 75%, after 2 100%; together gain ~20.6 VP) | CHANGED: +9.0 VP v +5.0 VP instead of stay"},
        {"id": 4, "type": "Charge", "turn": 1, "side": "Opponent", "actor": "Knights", "target": "Spearmen"},
        {"id": 5, "type": "Charge", "turn": 1, "side": "Opponent", "actor": "Wolves", "target": "Archers"},
        {"id": 6, "type": "Charge", "turn": 2, "side": "Mine", "actor": "Riders", "target": "Knights"},
        {"id": 7, "type": "Charge", "turn": 3, "side": "Mine", "actor": "Gors", "target": "Halberdiers"},
        {"id": 8, "type": "Charge", "turn": 3, "side": "Mine", "actor": "Raiders", "target": "Halberdiers"},
    ]
    problems = []
    if _RULE.match("COUNTER-CHARGE COVER: +4.0 VP: stays") is None or _RULE.match("SET-UP MISSED: +0.0 VP: x").group("tag") != "SET-UP MISSED":
        problems.append("rule tags with a hyphen")
    with tempfile.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, "game-P1-1-1.log.jsonl"), "w") as f:
            for r in rows:
                f.write(json.dumps({"kind": "action", "phase": "Movement", **r}) + "\n")
        cover, aims, games = battle_group_results(tmp)
        c = cover["Mine"].get("COUNTER-CHARGE COVER", {})
        if (games, c.get("rows"), c.get("charged"), c.get("named enemy"), c.get("answered"), c.get("named friend"), c.get("friend charged another")) != (1, 2, 2, 2, 1, 1, 1):
            problems.append(f"battle groups cover {c}")
        if (aims["Mine"]["aims"], aims["Mine"]["charged it"], aims["Mine"]["together"]) != (1, 1, 1):
            problems.append(f"battle groups aims {aims['Mine']}")
        if "### Battle groups: p" not in "\n".join(battle_groups_table(tmp, "p")):
            problems.append("battle groups table")
        rules, _ = opponent_rules(tmp)
        if "COUNTER-CHARGE COVER" not in rules["Mine"]:
            problems.append("COUNTER-CHARGE COVER missing from the rules table")
    return problems


# Combined arms measures (paper 2026-11-09, item 8), per side and game, from the game logs (actions + frames):
#  - fights with 2+ chargers: charged fights (as Charged fights) where two or more units made contact;
#  - counter-charges: enemy charges on one of the side's units answered by the side charging one of those chargers before the end of the
#    next round (a charge that made contact);
#  - escorts: at the end of the side's own Movement, its blocks (CA_BLOCK_POINTS+ pts) with a cheap friend (CA_ESCORT_POINTS pts or less,
#    not a character) within CA_ESCORT_REACH inches (centre to centre) - a stand-in until the escort role exists;
#  - screens: an enemy charge that made contact with a cheap unit of the side (CA_ESCORT_POINTS or less) standing within CA_SCREEN_REACH of a
#    friend of at least twice its points, nearer the charger than that friend (it took the charge meant for the block);
#  - lanes: the side's OPENS A LANE rule rows, and how many of their targets were gone by the end of that round.
CA_BLOCK_POINTS, CA_ESCORT_POINTS, CA_ESCORT_REACH, CA_SCREEN_REACH = 175, 150, 12, 10


def _frames(path):
    """[(after action id, [unit dicts])] of one game log."""
    out = []
    with open(path) as f:
        for line in f:
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if d.get("kind") == "frame":
                out.append((d.get("after") or 0, d.get("units") or []))
    return out


def _combined_arms_game(path, actions, units):
    counts = _new_counts()
    other = {"Mine": "Opponent", "Opponent": "Mine"}
    names = {}
    for a in actions:
        for k in ("actor", "target"):
            if a.get(k + "_id") and a.get(k):
                names[a[k + "_id"]] = a[k]
    frames = sorted(_frames(path), key=lambda x: x[0])
    pos, fi = {}, 0

    def at(action_id):
        nonlocal fi
        while fi < len(frames) and frames[fi][0] <= action_id:
            for u in frames[fi][1]:
                n = names.get(u.get("id"))
                if n is None:  # a piece the records do not name (e.g. raised later): skipped
                    continue
                if u.get("on", 1) and n in units:
                    pos[n] = (u.get("x", 0), u.get("y", 0))
                else:
                    pos.pop(n, None)
            fi += 1
        return pos

    def dist(p, q):
        return math.hypot(p[0] - q[0], p[1] - q[1])

    def cheap(n):
        u = units.get(n)
        return u is not None and 0 < u["points"] <= CA_ESCORT_POINTS and not u.get("character")

    fights = _game_fights([a for a in actions if a.get("kind", "action") == "action"], units)
    for f in fights:
        _add(counts, f["side"], "fights")
        if len(f["chargers"]) > 1:
            _add(counts, f["side"], "fights_2plus")
    contacts = [a for a in actions if a.get("type") == "Charge" and "made contact" in (a.get("summary") or "")
                and a.get("actor") in units and a.get("target") in units]
    for i, c in enumerate(contacts):
        side = units[c["target"]]["side"]
        if side == c.get("side"):
            continue
        _add(counts, side, "charged")
        if any(d.get("side") == side and d.get("target") == c["actor"] and d.get("turn", 0) <= c.get("turn", 0) + 1 for d in contacts[i + 1:]):
            _add(counts, side, "countered")
        if cheap(c["target"]):
            here = at(c.get("id") or 0)
            t, ch = here.get(c["target"]), here.get(c["actor"])
            if t and ch and any(units[n]["side"] == side and n != c["target"] and units[n]["points"] >= 2 * units[c["target"]]["points"]
                                and dist(p, t) <= CA_SCREEN_REACH and dist(ch, t) < dist(ch, p) for n, p in here.items()):
                _add(counts, side, "screened")
    last_move = {}
    for a in actions:
        if a.get("phase") == "Movement" and a.get("id"):
            last_move[(a.get("turn"), a.get("side"))] = a["id"]
    for (turn, side), aid in sorted(last_move.items(), key=lambda x: x[1]):
        here = at(aid)
        for n, p in list(here.items()):
            u = units[n]
            if u["side"] != side or u["points"] < CA_BLOCK_POINTS or u.get("character") or u.get("joined"):
                continue
            _add(counts, side, "blocks")
            if any(m != n and units[m]["side"] == side and cheap(m) and dist(p, q) <= CA_ESCORT_REACH for m, q in here.items()):
                _add(counts, side, "escorted")
    for a in actions:
        if a.get("type") == "OpponentRule" and (a.get("summary") or "").startswith("OPENS A LANE:"):
            side = a.get("side") if a.get("side") in SIDES else (units.get(a.get("actor")) or {}).get("side")
            _add(counts, side, "lanes")
            t = units.get(a.get("target"))
            if t and t["gone"] and t["round"] is not None and t["round"] <= a.get("turn", 0):
                _add(counts, side, "lanes_cleared")
    return counts


def combined_arms(batch_dir):
    """{side: {number: total}} and the games counted."""
    total, games = _new_counts(), 0
    for name, actions, units in _game_logs(batch_dir):
        if units is None:
            continue
        games += 1
        for side, q in _combined_arms_game(os.path.join(batch_dir, name), actions, units).items():
            for k, v in q.items():
                _add(total, side, k, v)
    return total, games


def combined_arms_table(batch_dir, label):
    total, games = combined_arms(batch_dir)
    if not games:
        return []
    out = [f"### Combined arms: {label} ({games} games)", "",
           "| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) "
           "| Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |",
           "| --- | --- | --- | --- | --- | --- |"]
    for side in SIDES:
        q = total[side]

        def share(k, of):
            return f"{q.get(k, 0)} of {q.get(of, 0)}" + (f" ({100 * q.get(k, 0) / q[of]:.0f}%)" if q.get(of) else "")
        out.append(f"| {side} | {share('fights_2plus', 'fights')} | {share('countered', 'charged')} | {share('escorted', 'blocks')} | "
                   f"{q.get('screened', 0) / games:.2f} per game | {q.get('lanes', 0) / games:.2f} / {q.get('lanes_cleared', 0) / games:.2f} per game |")
    return out


# Morten's KPIs (2026-11-10, after the combat and missile review): three numbers per side, read the same way in every batch.
#  1. After a won combat round, how often the winner follows up / pursues instead of restraining, split by what the loser did (gave ground,
#     fell back in good order, fled). Read from the engine's own lines (both sides, every brain): the loser's BreakTest, then each enemy
#     winner's RestrainAndReform ("stays and reforms"), AftermathDeclared ("stays and will reform", "will follow up", "will pursue"),
#     FollowUp, Pursuit, PursuitDeclared, PursuitIntoFreshEnemy or Overrun before the next combat's result. Each winner counts once per
#     break test: "chose" = it chose to follow up / pursue (the review's reading of the decision); "on the table" adds the restrains
#     whose Restraint test failed, so the unit followed up or pursued anyway.
#  2. The share of an army's magic missiles tried each of its own turns, counted whether or not the wizard is alive (target: at least
#     50%). Batches from 2026-11-10 on log every missile not tried with why (MissileNotTried rows, TurnFlowService.MissilesNotTried.cs):
#     tried + not tried = the army's missiles that turn. Older logs never list what a wizard knows: the missiles seen in the log (tried,
#     swapped in, or weighed in a computer line) times the side's turns - a lower bound on the missiles, so the share reads high there.
#  3. The share of army points that never fought (the record's Fought flag; baggage left out), and of infantry points.
#  4. Units over 100 points that earned no points at all: no kill points and no objective points (Morten 2026-11-10 15:50).
# Movement measures (Morten 2026-11-11, movement plan review option 7 "Yes"): who reaches the enemy first and how the charges come together,
# per side, read from the game logs' Charge lines and the static opponent's set-up objectives. A "charge contact" is a Charge result line
# that made contact; a "charged target" is one enemy contacted by a side in one turn (2+ units of the side on it = a joint charge). The arc
# comes from the charge lines (" - in its front / flank / rear", logs from 2026-11-11 on; older logs: arc unknown). "Goes with winning" tables
# are correlations: a side that is winning charges more.
_ARC = re.compile(r" - in its (front|flank|rear)\b")
MOVEMENT_ROWS = [
    ("Games where this side made the first charge contact", "first_contact", "share"),
    ("Round of a side's first charge contact (sides that made one)", "first_round", "mean"),
    ("Sides that never declared a charge", "never_declared", "share"),
    ("Sides that never made charge contact", "never_contact", "share"),
    ("Charges declared a game", "declared", "rate"),
    ("Charge contacts made a game", "contacts", "rate"),
    ("Charge contacts received a game", "received", "rate"),
    ("Joint charges a game (2+ units on one target in one turn)", "joint", "rate"),
    ("  share of charged targets hit by 2+ units", "joint_share", "share"),
    ("Lone charges that a friend follows on the same target next turn", "lone_follow", "share"),
    ("Set-ups (close in to charge next turn) that charged that target next turn", "setup_charged", "share"),
    ("  ... and made contact", "setup_contact", "share"),
    ("  ... with a friend on it too", "setup_friend", "share"),
    ("Set-ups missed (no charge on that target next turn)", "setup_missed", "share"),
    ("Charge contacts in the flank or rear (arc known)", "flank_rear", "share"),
    ("  in the rear", "rear", "share"),
    ("Declared charges in the flank or rear (arc known)", "declared_flank_rear", "share"),
    ("Marches that gave up a magic missile a game (made: a failed march test or a MARCH CHECK turn left out)", "missile_marches", "rate"),
]


def _movement_game(actions):
    """One game: ({side: counters}, {side: features for the "goes with winning" table})."""
    k = {s: {} for s in SIDES}

    def add(side, key, v=1):
        if side in k:
            k[side][key] = k[side].get(key, 0) + v

    order = sorted(range(len(actions)), key=lambda i: (actions[i].get("id") or 0, i)) if any(a.get("id") for a in actions) else range(len(actions))
    contacts, declared = [], []  # (index, side, turn, actor, target, arc)
    for i in order:
        a = actions[i]
        if a.get("kind", "action") != "action" or a.get("type") != "Charge" or not a.get("actor"):
            continue
        text = a.get("summary") or ""
        arc = (m := _ARC.search(text)) and m.group(1)
        row = (i, a.get("side"), a.get("turn") or 0, a.get("actor_id") or a["actor"], a.get("target_id") or a.get("target"), arc)
        if ": made contact" in text:
            contacts.append(row)
        elif " declares a charge against " in text:
            declared.append(row)
    for _, side, _, _, _, arc in declared:
        add(side, "declared")
        if arc:
            add(side, "declared_flank_rear_of")
            add(side, "declared_flank_rear_yes", arc != "front")
    first = contacts[0][1] if contacts else None
    targets = {}  # (side, turn, target) -> chargers
    for _, side, turn, actor, target, arc in contacts:
        add(side, "contacts")
        add(next((o for o in SIDES if o != side), None), "received")
        targets.setdefault((side, turn, target), set()).add(actor)
        if arc:
            add(side, "flank_rear_of")
            add(side, "flank_rear_yes", arc != "front")
            add(side, "rear_of")
            add(side, "rear_yes", arc == "rear")
    for (side, turn, target), chargers in targets.items():
        add(side, "joint_share_of")
        if len(chargers) >= 2:
            add(side, "joint")
            add(side, "joint_share_yes")
        else:
            add(side, "lone_follow_of")
            later = targets.get((side, turn + 1, target), set())
            add(side, "lone_follow_yes", bool(later - chargers))
    # Set-ups: the static opponent's "close in to charge #id next turn" objective, then that unit's charges in its side's next turn.
    seen = set()
    for a in actions:
        m = SET_UP_OBJECTIVE.match(a.get("summary") or "") if a.get("type") == "Computer" and a.get("phase") == "Strategy" else None
        if not m or (a.get("side"), a.get("turn"), m["unit"]) in seen:
            continue
        seen.add((a.get("side"), a.get("turn"), m["unit"]))
        side, nxt, target = a.get("side"), (a.get("turn") or 0) + 1, int(m["target"])
        decl = [d for d in declared if d[1] == side and d[2] == nxt and _same_unit(actions[d[0]], m["unit"]) and _target_is(actions[d[0]], target)]
        hit = [c for c in contacts if c[1] == side and c[2] == nxt and _same_unit(actions[c[0]], m["unit"]) and _target_is(actions[c[0]], target)]
        for key in ("setup_charged", "setup_contact", "setup_friend", "setup_missed"):
            add(side, f"{key}_of")
        add(side, "setup_charged_yes", bool(decl or hit))
        add(side, "setup_contact_yes", bool(hit))
        add(side, "setup_missed_yes", not (decl or hit))
        if hit:
            friends = targets.get((side, nxt, hit[0][4]), set()) - {hit[0][3]}
            add(side, "setup_friend_yes", bool(friends))
    # Marches that gave up a missile (Morten 2026-11-12, "3. Yes"): the MARCH OVER CASTS rows of marches actually made - a unit whose march
    # test failed moved without marching, and in logs before 13 Nov the row was written before MARCH CHECK turned the plan.
    def _unit_turn(a, prefix=None, type_=None):
        return {(a.get("actor_id") or a.get("actor"), a.get("turn")) for a in actions
                if (type_ is None or a.get("type") == type_) and (prefix is None or (a.get("summary") or "").startswith(prefix))}
    not_made = _unit_turn(None, "MARCH CHECK:", "OpponentRule") | {
        (a.get("actor_id") or a.get("actor"), a.get("turn")) for a in actions
        if a.get("type") == "MarchTest" and "cannot march" in (a.get("summary") or "")}
    for a in actions:
        if a.get("type") == "OpponentRule" and (a.get("summary") or "").startswith("MARCH OVER CASTS:") \
                and (a.get("actor_id") or a.get("actor"), a.get("turn")) not in not_made:
            add(a.get("side"), "missile_marches")
    feats = {}
    for s in SIDES:
        mine = [c for c in contacts if c[1] == s]
        add(s, "sides")
        add(s, "never_declared_of")
        add(s, "never_declared_yes", not any(d[1] == s for d in declared))
        add(s, "never_contact_of")
        add(s, "never_contact_yes", not mine)
        if contacts:
            add(s, "first_contact_of")
            add(s, "first_contact_yes", first == s)
        if mine:
            add(s, "first_round_sum", mine[0][2])
            add(s, "first_round_n")
        theirs = [c for c in contacts if c[1] != s]
        feats[s] = {"first": "none" if not contacts else "first" if first == s else "second",
                    "round": str(mine[0][2]) if mine else "never",
                    "balance": len(mine) - len(theirs), "joint": k[s].get("joint", 0)}
    return k, feats


def _same_unit(a, name):
    return a.get("actor") == name


def _target_is(a, target_id):
    return a.get("target_id") == target_id or a.get("target_id") is None


def movement(batch_dir):
    """({side: counters}, [(side, win 1/0.5/0, margin, features)], games read) over a batch."""
    rows = {f"game-{r.get('pair')}-{r.get('scenario')}-{r.get('seed')}.log.jsonl": r for r in read_csv(os.path.join(batch_dir, "games.csv"))}
    by_side, sides, games = {s: {} for s in SIDES}, [], 0
    for name, actions, _ in _game_logs(batch_dir):
        games += 1
        k, feats = _movement_game([a for a in actions if a.get("kind", "action") == "action"])
        for s, counters in k.items():
            for key, v in counters.items():
                by_side[s][key] = by_side[s].get(key, 0) + v
        r = rows.get(name)
        if r and r.get("ended") == "yes" and margin(r) is not None:
            for s in SIDES:
                win = 1 if r.get("winner") == s else 0 if r.get("winner") in SIDES else 0.5
                sides.append((s, win, margin(r) * (1 if s == "Mine" else -1), feats[s]))
    return by_side, sides, games


def _movement_cell(c, key, kind):
    if kind == "share":
        return _share(c, key)
    if kind == "mean":
        n = c.get(f"{key}_n", 0)
        return f"{c.get(f'{key}_sum', 0) / n:.1f}" if n else "-"
    games = c.get("sides", 0)
    return f"{c.get(key, 0) / games:.1f}" if games else "-"


def _balance_bucket(b):
    return "-3 or less" if b <= -3 else "+3 or more" if b >= 3 else f"{b:+d}"


MOVEMENT_BUCKETS = [
    ("Who made the first charge contact", lambda f: f["first"], ["first", "second", "none"]),
    ("Round of the side's first charge contact", lambda f: f["round"], None),
    ("Charge contacts made minus received", lambda f: _balance_bucket(f["balance"]), ["-3 or less", "-2", "-1", "+0", "+1", "+2", "+3 or more"]),
    ("Joint charges in the game", lambda f: "4+" if f["joint"] >= 4 else str(f["joint"]), ["0", "1", "2", "3", "4+"]),
]


def _winning_rows(sides):
    out = []
    for title, fn, order in MOVEMENT_BUCKETS:
        groups = {}
        for s, win, m, f in sides:
            groups.setdefault(fn(f), []).append((win, m))
        keys = order or sorted(groups, key=lambda x: (x == "never", int(x) if x.isdigit() else 0))
        for b in keys:
            if b in groups:
                g = groups[b]
                out.append(f"| {title} | {b} | {len(g)} | {100 * sum(w for w, _ in g) / len(g):.0f}% | {sum(m for _, m in g) / len(g):+.0f} |")
    return out


def movement_table(batch_dir, label):
    by_side, sides, games = movement(batch_dir)
    if not games:
        return []
    both = _both(by_side)
    arc = "" if both.get("flank_rear_of") or both.get("declared_flank_rear_of") else " The charge lines of this batch say no arc (older logs): the arc rows are empty."
    out = [f"### Movement: {label}", "",
           f"Morten 2026-11-11 (movement plan review, option 7); {games} games, per side. A share is of the times it could happen; "
           f"\"a game\" = per side and game.{arc}", "",
           "| Measure | Mine | Opponent | Both |", "| --- | --- | --- | --- |"]
    for text, key, kind in MOVEMENT_ROWS:
        out.append(f"| {text} | " + " | ".join(_movement_cell(c, key, kind) for c in (by_side["Mine"], by_side["Opponent"], both)) + " |")
    if sides:
        out += ["", "Goes with winning (each side of each ended game; a correlation, not a cause: a side that is winning charges more):", "",
                "| Measure | Bucket | Sides | Won | VP margin |", "| --- | --- | --- | --- | --- |"] + _winning_rows(sides)
    return out


def movement_compare(a_dir, b_dir, a_label, b_label):
    (sa, _, ga), (sb, _, gb) = movement(a_dir), movement(b_dir)
    if not ga or not gb:
        return []
    ba, bb = _both(sa), _both(sb)
    out = ["## Movement (Morten 2026-11-11)", "", f"A = {a_label} ({ga} games), B = {b_label} ({gb} games); per side and game.", "",
           "| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |", "| --- | --- | --- | --- | --- | --- | --- |"]
    for text, key, kind in MOVEMENT_ROWS:
        out.append(f"| {text} | " + " | ".join(_movement_cell(c, key, kind) for c in (sa["Mine"], sa["Opponent"], ba, sb["Mine"], sb["Opponent"], bb)) + " |")
    return out


KPI_TARGET_MISSILES = 50
_LOSER_KIND = (("gives ground", "gave ground"), ("falls back in good order", "fell back"), ("breaks and flees", "fled"))
_LOSER_KINDS = ("gave ground", "fell back", "fled")
# "Captain (BSB) joins Empire Knights, your strongest unit ..." / "... joins Blood Knights: joins ..." / JoinUnit "X joins Y".
_JOIN_UNIT = re.compile(r"^(?P<who>.+?) joins (?P<host>.+?)(?:, your |: |$)")
_MISSILE_WIZARD = re.compile(r"^MISSILE WIZARD: (?P<cls>FIGHTER|OTHER): ")
_MISSILE_NOT_TRIED = re.compile(r"^MISSILE NOT TRIED: (?P<tag>[A-Z ]+?): (?P<spell>.+?): ")
_SPELL_NOT_CAST = re.compile(r"^SPELL NOT CAST: (?P<tag>[A-Z ]+?): (?P<type>[A-Za-z]+): (?P<spell>.+?): ")
_SWAP = re.compile(r"^(?P<wizard>.+?) swaps (?P<old>.+?) for (?P<new>.+?): ")
_BOUND_USE = re.compile(r"^(?P<bearer>.+?) uses (?P<item>.+?) to attempt (?P<spell>.+?) as a Bound Spell")
_ITEM_USE = re.compile(r"^(?P<bearer>.+?) uses (?P<item>[^:]+?): ")
_ITEM_GROUPS = ("bound missile", "bound other", "one-use")
_NP_BANDS = ("101-199", "200-349", "350+")


def _np_type(u):
    """The unit's troop type for the 'earned nothing' breakdown; characters split into joined and on their own."""
    if u.get("character"):
        return "Character in a unit" if u.get("joined") else "Character on its own"
    return u.get("troop") or "-"


def _np_band(points):
    return _NP_BANDS[0] if points < 200 else _NP_BANDS[1] if points < 350 else _NP_BANDS[2]
_CONVEY = re.compile(r"^.+? (?:attempts (?P<spell>.+?) \(|uses .+? to attempt (?P<bound>.+?) as a Bound Spell)")
_WEIGHS = re.compile(r"^(?P<wizard>.+?) (?:casts|does not cast) (?P<spell>.+?)(?: at | on |: )")


def _winner_choice(a):
    """'go' (follow up / pursue / overrun), 'restrain', 'failed restrain' (the Restraint test failed: it follows up or pursues on the
    table) or None for one action line."""
    t, text = a.get("type"), a.get("summary") or ""
    if "failed its Restraint test" in text or (t == "RestrainAndReform" and "must follow up or pursue" in text):
        return "failed restrain"
    if t in ("FollowUp", "Pursuit", "PursuitDeclared", "PursuitIntoFreshEnemy", "Overrun"):
        return "go"
    if t == "RestrainAndReform":
        return "restrain" if "stays and reforms" in text else None
    if t == "AftermathDeclared":
        if " stays and will reform" in text:
            return "restrain"
        if " will follow up " in text or " will pursue " in text or " will overrun" in text:
            return "go"
    return None


def _kpi_game(actions, units):
    """One game: {side: {counter: value}} for the three KPIs (counters add up over a batch)."""
    k = {s: {} for s in SIDES}
    side_of = lambda n, fallback=None: units[n]["side"] if units and n in units else fallback

    def add(side, key, v=1):
        if side in k:
            k[side][key] = k[side].get(key, 0) + v

    acts = [a for a in actions if a.get("kind", "action") == "action"]
    # 0. Army stance (Morten 2026-11-13: "mark in KPI whether or not it is a defensive or offensive army playing"): one ARMY STANCE row a
    # turn per computer side (ClaudeOpponentBrain.ArmyStanceLine) - the turns it played defensive.
    stance_seen = set()
    for a in acts:
        text = a.get("summary") or ""
        if a.get("type") == "ArmyStance" and text.startswith("ARMY STANCE:") and (a.get("side"), a.get("turn")) not in stance_seen:
            stance_seen.add((a.get("side"), a.get("turn")))
            add(a.get("side"), "stance_of")
            add(a.get("side"), "stance_yes", 1 if ": defensive:" in text else 0)
    # 1. Winners after a won round: chose to follow up / pursue, or chose to restrain (and whether its Restraint test failed).
    for i, a in enumerate(acts):
        if a.get("type") != "BreakTest" or not a.get("actor"):
            continue
        text = a.get("summary") or ""
        kind = next((v for w, v in _LOSER_KIND if w in text), None)
        if not kind:
            continue
        loser_side = side_of(a["actor"], a.get("side"))
        seen = {}
        for e in acts[i + 1:]:
            if e.get("turn") != a.get("turn") or e.get("phase") != "Combat" or e.get("type") == "CombatResult":
                break
            c, w = _winner_choice(e), e.get("actor")
            if c and w and side_of(w, None) not in (None, loser_side):
                seen.setdefault(w, set()).add(c)
        for w, cs in seen.items():
            s = side_of(w)
            add(s, f"after_{kind}_of")
            if "failed restrain" in cs:
                add(s, f"after_{kind}_failed")
            elif "restrain" not in cs:
                add(s, f"after_{kind}_yes")
    # 2. Magic missiles tried.
    types = _spell_types()
    is_missile = lambda spell: types.get(spell) == "MagicMissile"
    tried, not_tried = set(), []
    for a in acts:
        text = a.get("summary") or ""
        if a.get("type") == "SpellCast":
            m = _CAST.match(text)
            if m and is_missile(m["spell"]):
                tried.add((a.get("turn"), side_of(m["wizard"], a.get("side")), m["wizard"], m["spell"]))
        elif a.get("type") == "MissileNotTried":
            m = _MISSILE_NOT_TRIED.match(text)
            if m:
                not_tried.append((a.get("turn"), a.get("side"), a.get("actor"), m["spell"], m["tag"]))
    # Fighting wizards apart from the others, and round 1 apart (Morten 2026-11-14 23:23): MissileWizard rows (logs from 2026-11-14 on,
    # TurnFlowService.MissilesNotTried.cs) name each wizard's class, FIGHTER or OTHER.
    wizard_class = {}
    for a in acts:
        if a.get("type") == "MissileWizard":
            m = _MISSILE_WIZARD.match(a.get("summary") or "")
            if m:
                wizard_class[(a.get("side"), a.get("actor"))] = m["cls"]
    # A side whose log names its missiles not tried is read exactly; for a side with no such row the log may simply be older.
    newer = any(a.get("type") == "MissileNotTried" for a in acts)
    for s in SIDES:
        if newer:
            mine_tried = {x for x in tried if x[1] == s}
            add(s, "missile_try_yes", len(mine_tried))
            add(s, "missile_try_of", len(mine_tried) + sum(1 for x in not_tried if x[1] == s))
            for x in not_tried:
                if x[1] == s:
                    add(s, f"missile_why_{x[4]}")
            # Tried when they could be (Morten 2026-11-11, option 6, report only): wizards in combat, slain, fleeing or off the table left out.
            add(s, "missile_could_yes", len(mine_tried))
            add(s, "missile_could_of", len(mine_tried) + sum(1 for x in not_tried if x[1] == s and x[4] not in MISSILE_COULD_NOT))
            add(s, "missile_exact", 1)
            if wizard_class:
                for x in tried:
                    if x[1] == s and (s, x[2]) in wizard_class:
                        cls = wizard_class[(s, x[2])].lower()
                        for wk in (f"missile_{cls}", f"missile_{cls}_r1" if x[0] == 1 else f"missile_{cls}_later"):
                            add(s, f"{wk}_yes")
                            add(s, f"{wk}_of")
                for x in not_tried:
                    if x[1] == s and (s, x[2]) in wizard_class:
                        cls = wizard_class[(s, x[2])].lower()
                        for wk in (f"missile_{cls}", f"missile_{cls}_r1" if x[0] == 1 else f"missile_{cls}_later"):
                            add(s, f"{wk}_of")
            continue
        known = {(w, sp) for _, sd, w, sp in tried if sd == s}
        for a in acts:
            if a.get("type") != "Computer" or a.get("side") != s:
                continue
            text = a.get("summary") or ""
            m = _SWAP.match(text)
            if m and is_missile(m["new"]):
                known.add((m["wizard"], m["new"]))
                continue
            m = _WEIGHS.match(text)
            if m and is_missile(m["spell"]) and (not units or m["wizard"] in units):
                known.add((m["wizard"], m["spell"]))
        if not known:
            continue
        own_turns = {a.get("turn") for a in acts if a.get("side") == s and a.get("phase") in ("Strategy", "Movement", "Shooting") and a.get("turn")}
        add(s, "missile_try_yes", sum(1 for x in tried if x[1] == s and (x[2], x[3]) in known))
        add(s, "missile_try_of", len(known) * len(own_turns))
    # 2b. Every spell not cast, with why (Morten 2026-11-11, "not cast" reason for every spell): SpellNotCast rows (logs from 2026-11-11 on,
    # TurnFlowService.SpellsNotCast.cs) for Enchantments, Hexes, movement spells, Vortexes and Assailments; missiles keep their own rows (above).
    # The wizard spells tried, by type, from the cast lines (bound items left out).
    for a in acts:
        text = a.get("summary") or ""
        if a.get("type") == "SpellNotCast":
            m = _SPELL_NOT_CAST.match(text)
            if m:
                add(a.get("side"), f"spell_nc|{m['type']}|{m['tag']}")
                add(a.get("side"), "spell_nc_rows")
        elif a.get("type") == "SpellCast":
            m = _CAST.match(text)
            t = types.get(m["spell"]) if m else None
            if t and t != "MagicMissile":
                add(side_of(m["wizard"], a.get("side")), f"spell_try|{t}")
    # 5. Bound items and one-use items used (Morten 2026-11-10 15:51-15:53): the items each army carries are the log's "item" lines
    # (batches from 2026-11-10 on); a use is a bound cast ("<bearer> uses <item> to attempt <spell>") or an ItemActivated line
    # ("<bearer> uses <item>: ..."). Older logs: the uses only.
    carried = [(a.get("side"), a.get("bearer"), a.get("item"), a.get("group")) for a in actions if a.get("kind") == "item"]
    uses = set()
    for a in acts:
        text = a.get("summary") or ""
        m = _BOUND_USE.match(text) if a.get("type") == "SpellCast" else _ITEM_USE.match(text) if a.get("type") == "ItemActivated" else None
        if not m:
            continue
        side = side_of(m["bearer"], a.get("side"))
        group = ("bound missile" if is_missile(m["spell"]) else "bound other") if a.get("type") == "SpellCast" else "one-use"
        group = next((g for sd, _, it, g in carried if sd == side and it == m["item"]), group)
        uses.add((a.get("turn"), a.get("phase"), side, m["bearer"], m["item"], group, a.get("id") if a.get("type") == "SpellCast" else None))
    for s in SIDES:
        for _, _, _, _, _, g, _ in [u for u in uses if u[2] == s]:
            add(s, f"item_{g}_uses")
        mine = [c for c in carried if c[0] == s]
        for sd, bearer, item, g in mine:
            add(s, f"item_{g}_of")
            if any(u[2] == s and u[4] == item and (u[3] == bearer or sum(1 for c in mine if c[2] == item) == 1) for u in uses):
                add(s, f"item_{g}_yes")
        if carried:
            add(s, "item_logged", 1)
    # 6. Movement spells (Conveyance, Morten 2026-11-11 "5. yes"): how often they are tried, how often they stand, and what the unit they
    # stood on did by the end of its side's next turn - moved after the cast (same Movement phase), declared a charge on its next turn,
    # was charged by the enemy first (before that turn), fought (a close combat attack by or at it), or none of these.
    for i, a in enumerate(acts):
        if a.get("type") != "SpellCast":
            continue
        m = _CONVEY.match(a.get("summary") or "")
        spell = m and (m["spell"] or m["bound"])
        if not spell or types.get(spell) != "Conveyance":
            continue
        s, unit, turn = side_of(a.get("actor"), a.get("side")), a.get("target"), a.get("turn") or 0
        add(s, "conv_tried")
        if not unit:
            continue
        rest = acts[i + 1:]
        # A spell that logs what it does ("<spell> resolves: ..." - Steed of Shadows' Fly) stood when that line follows; one that only moves
        # the unit (Travel Mystical Pathway, Arcane Urgency) when its casting roll was made.
        resolves = lambda e: e.get("type") == "SpellEffect" and (e.get("summary") or "").startswith(spell + " resolves")
        if any(resolves(e) for e in acts):
            stood = any(resolves(e) and e.get("turn") == turn and e.get("target") == unit for e in rest[:40])
        else:
            stood = "cast successfully" in (a.get("summary") or "")
        add(s, "conv_stood_of")
        if not stood:
            continue
        add(s, "conv_stood_yes")
        flags, own_next = set(), False
        # The enemy had planned to charge it (its latest objective, this turn or last, was "charge" or "close in to charge" on the unit):
        # moved out of that charge when the enemy then did not charge it first (Morten 2026-11-11: a better spot may avoid a bad charge).
        planned = re.compile(r"^Objective for .+?: (?:charge|close in to charge) #\d+ " + re.escape(unit) + r"(?:[:\s(]|$)")
        if any(e.get("side") not in (None, s) and (e.get("turn") or 0) >= turn - 1 and planned.match(e.get("summary") or "") for e in acts[:i]):
            flags.add("enemy_planned")
        for e in rest:
            t, ph, sd, typ = e.get("turn") or 0, e.get("phase"), e.get("side"), e.get("type")
            text = e.get("summary") or ""
            if t > turn + 1 or (own_next and sd != s and ph in ("Strategy", "Movement", "Shooting")):
                break
            if t == turn + 1 and sd == s and ph in ("Strategy", "Movement", "Shooting"):
                own_next = True
            if t == turn and ph == "Movement" and (e.get("actor") == unit and typ in ("RemainingMove", "March", "Pivot", "Move")
                                                   or typ == "Computer" and " is placed " in text and f"({spell})" in text):
                flags.add("moved")
            if typ == "Charge" and " declares a charge against " in text:
                if own_next and e.get("actor") == unit:
                    flags.add("charged")
                elif not own_next and e.get("target") == unit and sd != s:
                    flags.add("charged_first")
            if typ == "CombatAttack" and unit in (e.get("actor"), e.get("target")):
                flags.add("fought")
        if "enemy_planned" in flags and "charged_first" not in flags:
            flags.add("escaped")
        for f in ("moved", "charged", "charged_first", "fought", "escaped"):
            add(s, f"conv_{f}_of")
            if f in flags:
                add(s, f"conv_{f}_yes")
        add(s, "conv_nothing_of")
        if not flags & {"charged", "charged_first", "fought", "escaped"}:
            add(s, "conv_nothing_yes")
    # 7. Shooting (Morten 2026-11-11, "per wound ... if you decrease an expensive monster character by two - four wounds that is a good
    # outcome"): each own turn a shooting unit or war machine is on the table, did it shoot, and if not, why (from what it did that turn);
    # what the shots were worth: wounds x the target's points / the target's Wounds at the start (models x Wounds each, from the board line).
    if units:
        _kpi_shooting(acts, actions, units, add)
    # 8. Random movers (option 11, Morten 2026-11-13 "lets ensure we can measure this in KPI"): every random move by the figures writes a
    # RANDOM MOVE BY FIGURES row - CHANGED when it turned off the straight line at the nearest enemy (risk of a charge or a cannon), SAME when not.
    for a in acts:
        text = a.get("summary") or ""
        if a.get("type") == "OpponentRule" and text.startswith("RANDOM MOVE BY FIGURES:"):
            add(a.get("side"), "random_turned_of")
            if " | CHANGED: " in text:
                add(a.get("side"), "random_turned_yes")
    # 3. Points that never fought.
    if units:
        for n, u in units.items():
            if u["terrain"]:
                continue
            for key in ("all",) + (("infantry",) if u.get("troop") == "Infantry" else ()):
                add(u["side"], f"never_{key}_of", u["points"])
                if not u["fought"]:
                    add(u["side"], f"never_{key}_yes", u["points"])
        # 4. Units over 100 points that earned nothing (Morten 2026-11-10 15:50): no kill points (the record's points earned; a record
        # without them, the enemy units it destroyed) and no objective points (the log's objective scores it held).
        killed = {}
        for u in units.values():
            if u["gone"] and u["by"]:
                killed[u["by"]] = killed.get(u["by"], 0) + u["vp"]
        held = {}
        for a in actions:
            if a.get("kind") == "objective" and a.get("unit"):
                held[a["unit"]] = held.get(a["unit"], 0) + (a.get("points") or 0)
        for n, u in units.items():
            if u["terrain"] or u["points"] <= 100:
                continue
            kills = u["earned"] if u["earned"] is not None else killed.get(n, 0)
            cell = f"np|{_np_type(u)}|{_np_band(u['points'])}"
            add(u["side"], "no_points_of")
            add(u["side"], "no_points_pts_of", u["points"])
            add(u["side"], f"{cell}_of")
            if not kills and not held.get(n):
                add(u["side"], "no_points_yes")
                add(u["side"], "no_points_pts_yes", u["points"])
                add(u["side"], f"{cell}_yes")
    # 5. Charges (Morten 2026-11-11 20:13, "afraid about this creating fewer charges"): charges declared and made a game, and per unit by
    # what it carries: a magic-missile wizard (one named by the missiles cast or not tried), another wizard (one that cast anything), or
    # neither - a lone wizard carries himself. Read from the log alone (units deployed, joins, casts), so batches without records count too.
    deployed = {a["actor"]: a.get("side") for a in acts if a.get("type") == "Deployment" and a.get("actor")}
    joined_to = {}
    for a in acts:
        text = a.get("summary") or ""
        m = _JOIN_UNIT.match(text) if a.get("type") in ("Computer", "JoinUnit") else None
        if m and m["who"] in deployed:
            joined_to[m["who"]] = m["host"]
    missile_wizards = {x[2] for x in tried} | {x[2] for x in not_tried}
    wizards = missile_wizards | {m["wizard"] for a in acts if a.get("type") == "SpellCast" for m in [_CAST.match(a.get("summary") or "")] if m}
    carries, carries_missile = set(), set()
    for w in wizards:
        host = joined_to.get(w, w)
        carries.add(host)
        if w in missile_wizards:
            carries_missile.add(host)
    group_of = lambda n: "mwiz" if n in carries_missile else "wiz" if n in carries else "other"
    for n, sd in deployed.items():
        u = (units or {}).get(n)
        if n in joined_to or u and (u["terrain"] or u["type"] == "War machine"):
            continue
        add(side_of(n, sd), f"ch_{group_of(n)}_units")
    for a in acts:
        if a.get("type") != "Charge" or not a.get("actor"):
            continue
        text = a.get("summary") or ""
        declared, contact = " declares a charge against " in text, "made contact" in text
        if not (declared or contact):
            continue
        n = a["actor"]
        sd = side_of(n, a.get("side"))
        for what, yes in (("declared", declared), ("contact", contact)):
            if yes:
                add(sd, f"ch_{what}")
                add(sd, f"ch_{group_of(n)}_{what}")
    return k


SHOOT_REASONS = [("marched", "MARCHED: its unit marched"), ("charged", "CHARGED: it charged"), ("fleeing", "FLEEING: it fled or was fleeing"),
                 ("combat", "IN COMBAT: it fought this turn or the last"), ("moved", "MOVED: a war machine that moved"),
                 ("free", "FREE: none of these - no target in range or sight, or held its fire"),
                 # the game's own ShotNotTaken reasons (logs from 2026-11-11 on)
                 ("held", "HELD FIRE: a target, but it held its fire"), ("no_range", "NO TARGET IN RANGE"),
                 ("only_combat", "ONLY IN COMBAT: the only targets were in combat"), ("no_sight", "NO LINE OF SIGHT: in range, out of arc or sight"),
                 ("sheltered", "SHELTERED: the target was sheltered"), ("stupid", "STUPIDITY"), ("other", "OTHER BAR")]
_SHOT_TAGS = {"HELD FIRE": "held", "NO TARGET IN RANGE": "no_range", "ONLY IN COMBAT": "only_combat", "NO LINE OF SIGHT": "no_sight",
              "SHELTERED": "sheltered", "FLEEING": "fleeing", "CHARGED": "charged", "IN COMBAT": "combat", "MARCHED": "marched",
              "MOVED": "moved", "STUPIDITY": "stupid", "OTHER BAR": "other"}
_SHOT_WOUNDS = re.compile(r"(\d+) wound\(s\)")
_SHOT_KILLED = re.compile(r"(\d+) killed")


def _shooter_kind(u):
    t = u.get("troop")
    return ("war machine" if t == "War Machines" else "character" if u.get("character") else "cavalry" if t == "Cavalry"
            else "chariot" if t == "Chariot" else "monster" if t in ("Monster", "Monstrous") else "infantry")


def _kpi_shooting(acts, actions, units, add):
    """Shooting KPI counters for one game (see _kpi_game, part 7)."""
    looks = {}
    for b in actions:
        if b.get("kind") == "board":
            looks = {u.get("n"): u.get("lk") or {} for u in b.get("units") or []}
            break
    last = max((a.get("turn") or 0 for a in acts), default=0)
    shot, did, seen = set(), {}, {}
    for a in acts:
        t, typ, actor, text = a.get("turn") or 0, a.get("type"), a.get("actor"), a.get("summary") or ""
        for n in (actor, a.get("target")):
            if n:
                first_last = seen.setdefault(n, [t, t])
                first_last[0], first_last[1] = min(first_last[0], t), max(first_last[1], t)
        if not actor:
            continue
        if typ in ("Shooting", "WarMachineShot", "BreathWeaponShot"):
            if a.get("phase") == "Shooting":
                shot.add((actor, t))
            u = units.get(actor)
            if not u:
                continue
            m = _SHOT_WOUNDS.search(text)
            target = units.get(a.get("target") or "")
            look = looks.get(a.get("target") or "", {})
            wounds = int(m.group(1)) if m else (int(k.group(1)) * (look.get("w") or 1) if (k := _SHOT_KILLED.search(text)) else 0)
            kind = _shooter_kind(u)
            add(u["side"], f"shot_n|{kind}")
            add(u["side"], f"shot_w|{kind}", wounds)
            if wounds == 0:
                add(u["side"], f"shot_blank|{kind}")
            if target and look:
                add(u["side"], f"shot_v|{kind}", wounds * target["points"] / max(1, (look.get("mc") or 1) * (look.get("w") or 1)))
            continue
        tag = {"March": "marched", "ContinuedFlee": "fleeing", "Flee": "fleeing", "FleeReaction": "fleeing", "BreakTestMove": "fleeing",
               "CombatAttack": "combat", "RemainingMove": "moved", "Move": "moved", "Pivot": "moved"}.get(typ)
        if typ == "Charge" and " declares a charge against " in text:
            tag = "charged"
        if tag:
            did.setdefault((actor, t), set()).add(tag)
            if tag == "combat" and a.get("target"):
                did.setdefault((a["target"], t), set()).add("combat")
    # Logs with the game's own ShotNotTaken rows (2026-11-11 on, one per shooter on the table that did not shoot, with its reason): those
    # rows and the shots are the count; older logs fall back on what the shooter did that turn.
    rows = [a for a in acts if a.get("type") == "ShotNotTaken" and a.get("actor") in units]
    if rows:
        for n, t in shot:
            if n in units:
                kind = _shooter_kind(units[n])
                for key in (f"shoot_turn|{kind}", "shoot_turn"):
                    add(units[n]["side"], f"{key}_of")
                    add(units[n]["side"], f"{key}_yes")
        for a in rows:
            u = units[a["actor"]]
            m = re.match(r"SHOT NOT TAKEN: ([A-Z ]+?):", a.get("summary") or "")
            add(u["side"], f"shoot_turn|{_shooter_kind(u)}_of")
            add(u["side"], "shoot_turn_of")
            add(u["side"], "shoot_why_" + _SHOT_TAGS.get(m.group(1) if m else "", "other"))
        return
    shooters = {n for n, u in units.items() if not u["terrain"] and (u.get("type") in ("Shooter", "War machine") and not u["character"]
                                                                     or u.get("troop") == "War Machines")} | {n for n, _ in shot if n in units}
    for n in shooters:
        u, (first, gone_after) = units[n], seen.get(n, [99, 0])
        kind = _shooter_kind(u)
        for t in range(max(1, first), last + 1):
            if t > gone_after and u["gone"]:
                break
            add(u["side"], f"shoot_turn|{kind}_of")
            add(u["side"], "shoot_turn_of")
            if (n, t) in shot:
                add(u["side"], f"shoot_turn|{kind}_yes")
                add(u["side"], "shoot_turn_yes")
                continue
            d = did.get((n, t), set())
            why = next((r for r in ("charged", "marched", "fleeing") if r in d), None)
            if not why and ("combat" in d or "combat" in did.get((n, t - 1), set()) and "moved" not in d):
                why = "combat"
            if not why and kind == "war machine" and "moved" in d:
                why = "moved"
            add(u["side"], f"shoot_why_{why or 'free'}")


def kpis(batch_dir):
    """({side: counters}, {army: counters}, games read) over a batch."""
    by_side, by_army, games = {s: {} for s in SIDES}, {}, 0
    for _, actions, units in _game_logs(batch_dir):
        games += 1
        k = _kpi_game(actions, units)
        armies = {}
        if units:
            for u in units.values():
                if u.get("army"):
                    armies.setdefault(u["side"], u["army"])
        for s, counters in k.items():
            by_side[s]["_games"] = by_side[s].get("_games", 0) + 1
            if s in armies:
                a = by_army.setdefault(armies[s], {"_sides": 0})
                a["_games"] = a.get("_games", 0) + 1
            for key, v in counters.items():
                by_side[s][key] = by_side[s].get(key, 0) + v
                if s in armies:
                    a = by_army.setdefault(armies[s], {"_sides": 0})
                    a[key] = a.get(key, 0) + v
            if s in armies:
                by_army[armies[s]]["_sides"] += 1
    return by_side, by_army, games


def _share(c, key):
    y, n = c.get(f"{key}_yes", 0), c.get(f"{key}_of", 0)
    return f"{100 * y / n:.0f}% ({y:.0f} of {n:.0f})" if n else "-"


def _share_short(c, key):
    y, n = c.get(f"{key}_yes", 0), c.get(f"{key}_of", 0)
    return f"{100 * y / n:.0f}%" if n else "-"


def _both(by_side):
    out = {}
    for c in by_side.values():
        for key, v in c.items():
            out[key] = out.get(key, 0) + v
    return out


def _go_all(c):
    return {f"go_{p}": sum(c.get(f"after_{x}_{p}", 0) for x in _LOSER_KINDS) for p in ("yes", "of", "failed")}


KPI_ROWS = [
    ("Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive)", "stance", ""),
    ("Winner chose to follow up after the loser gave ground", "after_gave ground", ""),
    ("Winner chose to pursue after the loser fell back in good order", "after_fell back", ""),
    ("Winner chose to pursue after the loser fled", "after_fled", ""),
    ("Winner chose to follow up or pursue (all three)", "go", ""),
    ("Magic missiles tried each own turn", "missile_try", f"{KPI_TARGET_MISSILES}%+"),
    ("  tried when they could be (not in combat, slain, fleeing or off the table)", "missile_could", f"{KPI_TARGET_MISSILES}%+"),
    ("  fighting wizards (on a monster, chariot or monstrous mount)", "missile_fighter", f"{KPI_TARGET_MISSILES}%+"),
    ("    round 1", "missile_fighter_r1", ""),
    ("    rounds 2+", "missile_fighter_later", ""),
    ("  other wizards", "missile_other", f"{KPI_TARGET_MISSILES}%+"),
    ("    round 1", "missile_other_r1", ""),
    ("    rounds 2+", "missile_other_later", ""),
    ("Random moves turned off the straight line at the nearest enemy (risk weighed)", "random_turned", ""),
    ("Points that never fought", "never_all", "lower"),
    ("  infantry points that never fought", "never_infantry", "lower"),
    ("Units over 100 pts that earned no points (no kill, no objective)", "no_points", "lower"),
    ("Bound items with a magic missile used (at least once a game)", "item_bound missile", ""),
    ("Bound items with another spell used", "item_bound other", ""),
    ("One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...)", "item_one-use", ""),
    ("  their share of the points of units over 100 pts", "no_points_pts", "lower"),
]
# The reasons a missile could not be tried at all (option 6, Morten 2026-11-11): left out of "tried when they could be".
MISSILE_COULD_NOT = ("IN COMBAT", "GONE", "FLEEING", "OFF THE TABLE")
MISSILE_REASONS = [("NOT CHOSEN", "could have been cast at a target"), ("NO TARGET", "no enemy in range, sight and arc it may target"),
                   ("MARCHED", "its unit marched"), ("CHARGED", "its unit charged"), ("IN COMBAT", "engaged in combat"),
                   ("REAR RANK", "in a rear rank"), ("NO CASTS LEFT", "every cast used on other spells"), ("FLEEING", "fleeing"),
                   ("GONE", "slain"), ("OFF THE TABLE", "off the table or not arrived"), ("STUPIDITY", "Stupidity"),
                   ("OTHER BAR", "another bar (miscast, baggage ...)"), ("NOT OFFERED", "not in the cast list"),
                   ("HELD BACK", "the computer weighed it and chose not to cast it")]
# Every spell not cast (2026-11-11): the missiles' reasons, and an Assailment whose wizard fought in no combat that turn.
SPELL_REASONS = MISSILE_REASONS + [("NOT IN COMBAT", "Assailment: the wizard fought in no combat")]
SPELL_TYPES = [("Enchantment", "Enchantments"), ("Hex", "Hexes"), ("Conveyance", "Movement spells"), ("MagicMissile", "Magic missiles"),
               ("MagicalVortex", "Vortexes"), ("Assailment", "Assailments")]


def _kpi_cell(c, key, short=False):
    c = dict(c, **_go_all(c)) if key == "go" else c
    cell = (_share_short if short else _share)(c, key)
    if key.startswith("item_"):
        games = c.get("_games", 0)
        rate = f"{c.get(f'{key}_uses', 0) / games:.1f} uses a game" if games else ""
        return rate if cell == "-" else (cell if short else f"{cell}; {rate}")
    if (key == "go" or key.startswith("after_")) and c.get(f"{key}_of"):
        cell += f"; on the table {100 * (c.get(f'{key}_yes', 0) + c.get(f'{key}_failed', 0)) / c[f'{key}_of']:.0f}%"
    return cell


def _missile_note(by_side):
    exact = sum(c.get("missile_exact", 0) for c in by_side.values())
    items = sum(c.get("item_logged", 0) for c in by_side.values())
    return (("" if exact else " Missiles: an older batch with no log of the missiles not tried - read from the missiles seen in the log, "
             "so the share reads high.") + ("" if items else " Items: the log does not list the items carried (older batch) - uses a game only."))


def rules_off_line(batch_dir):
    """Which rules each side played without (<batch>/rules-off.txt, SimRulesOff.Now): "TAG" is off for both sides, "TAG@Mine" or
    "TAG@Opponent" for that side's computer only (a head-to-head batch, Morten 2026-11-13). "" when every rule was on."""
    try:
        with open(os.path.join(batch_dir, "rules-off.txt"), encoding="utf-8") as f:
            tags = [t.strip() for t in f if t.strip()]
    except OSError:
        return ""
    if not tags:
        return ""
    sides = {s: [t.rsplit("@", 1)[0] for t in tags if t.endswith("@" + s)] for s in ("Mine", "Opponent")}
    both = [t for t in tags if "@" not in t]
    parts = [f"{s} only: {', '.join(v)}" for s, v in sides.items() if v] + ([f"both sides: {', '.join(both)}"] if both else [])
    return "Rules off - " + "; ".join(parts) + "."


def kpi_table(batch_dir, label):
    by_side, by_army, games = kpis(batch_dir)
    if not games:
        return []
    both = _both(by_side)
    off = rules_off_line(batch_dir)
    out = [f"### KPIs: {label}", "", *([off, ""] if off else []),
           f"Morten 2026-11-10; {games} games. A % is of the times it could happen (follow ups: winners after a won round, \"on the table\" adds "
           f"the restrains whose Restraint test failed; missiles: the "
           f"army's missiles x its turns, dead wizards included; points: army points).{_missile_note(by_side)}", "",
           "| KPI | Target | Mine | Opponent | Both |", "| --- | --- | --- | --- | --- |"]
    for text, key, target in KPI_ROWS:
        out.append(f"| {text} | {target} | {_kpi_cell(by_side['Mine'], key)} | {_kpi_cell(by_side['Opponent'], key)} | {_kpi_cell(both, key)} |")
    why = [(tag, text, [c.get(f"missile_why_{tag}", 0) for c in (by_side["Mine"], by_side["Opponent"], both)]) for tag, text in MISSILE_REASONS]
    not_tried = [sum(c.get(f"missile_why_{tag}", 0) for tag, _ in MISSILE_REASONS) for c in (by_side["Mine"], by_side["Opponent"], both)]
    if not_tried[2]:
        out += ["", "Why missiles were not tried (per game, and the share of the missiles not tried):", "",
                "| Reason | Mine | Opponent | Both |", "| --- | --- | --- | --- |"]
        for tag, text, n in why:
            if n[2]:
                out.append(f"| {tag}: {text} | " + " | ".join(f"{v / games:.1f} ({100 * v / t:.0f}%)" if t else "-" for v, t in zip(n, not_tried)) + " |")
    out += spells_not_cast_rows(both, games)
    out += conveyance_rows(by_side, both)
    out += shooting_rows(by_side, both, games)
    out += charge_rows(by_side, both)
    types = sorted({k.split("|")[1] for k in both if k.startswith("np|") and k.endswith("_of")})
    if types:
        out += ["", "Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):", "",
                "| Troop type | " + " | ".join(_NP_BANDS) + " | All |", "| --- | " + " | ".join("---" for _ in _NP_BANDS) + " | --- |"]
        for t in types:
            row = {"x_yes": 0, "x_of": 0}
            cells = []
            for b in _NP_BANDS:
                key = f"np|{t}|{b}"
                row["x_yes"] += both.get(f"{key}_yes", 0)
                row["x_of"] += both.get(f"{key}_of", 0)
                cells.append(_share(both, key))
            out.append(f"| {t} | " + " | ".join(cells) + f" | {_share(row, 'x')} |")
    if by_army:
        out += ["", "By army (both sides of every game it played):", "",
                "| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |",
                "| --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
        for army, c in sorted(by_army.items()):
            out.append(f"| {army} | {c['_sides']} | {_kpi_cell(c, 'go')} | {_kpi_cell(c, 'missile_try')} | {_kpi_cell(c, 'never_all', True)} | {_kpi_cell(c, 'no_points')} | "
                       + " | ".join(_kpi_cell(c, f"item_{g}") for g in _ITEM_GROUPS) + " |")
    out += _flank_charges().table(batch_dir, label)
    return out


def spells_not_cast_rows(both, games):
    """Why each kind of spell was not cast (Morten 2026-11-11), both sides: a game's spells tried and not cast with each reason, and the share
    of that kind's spells not cast. Magic missiles from their MissileNotTried rows, the rest from SpellNotCast rows (logs from 2026-11-11 on)."""
    if not both.get("spell_nc_rows") or not games:
        return []

    def nc(t, tag):
        return both.get(f"missile_why_{tag}", 0) if t == "MagicMissile" else both.get(f"spell_nc|{t}|{tag}", 0)

    def tried(t):
        return both.get("missile_try_yes", 0) if t == "MagicMissile" else both.get(f"spell_try|{t}", 0)
    cols = [(t, label, sum(nc(t, tag) for tag, _ in SPELL_REASONS)) for t, label in SPELL_TYPES]
    cols = [c for c in cols if c[2] or tried(c[0])]
    out = ["", "Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn "
           "in the phase it is cast in, dead wizards included:", "",
           "| Reason | " + " | ".join(label for _, label, _ in cols) + " |", "| --- | " + " | ".join("---" for _ in cols) + " |",
           "| tried | " + " | ".join(f"{tried(t) / games:.1f}" for t, _, _ in cols) + " |",
           "| not cast | " + " | ".join(f"{n / games:.1f}" for _, _, n in cols) + " |"]
    for tag, text in SPELL_REASONS:
        if any(nc(t, tag) for t, _, _ in cols):
            out.append(f"| {tag}: {text} | " + " | ".join(f"{nc(t, tag) / games:.1f} ({100 * nc(t, tag) / n:.0f}%)" if n else "-" for t, _, n in cols) + " |")
    return out


CONVEYANCE_ROWS = [("stood (cast and not dispelled)", "conv_stood"), ("the unit moved after it", "conv_moved"),
                   ("it charged on its next turn", "conv_charged"), ("the enemy charged it first", "conv_charged_first"),
                   ("it fought by the end of its next turn", "conv_fought"),
                   ("it moved out of a charge the enemy had planned (not charged first)", "conv_escaped"),
                   ("none of these (no charge, no fight, no charge escaped)", "conv_nothing")]


def conveyance_rows(by_side, both):
    """Movement spells (Morten 2026-11-11): tries a game, how often they stood, and what the unit did after (a % of the casts that stood)."""
    if not both.get("conv_tried"):
        return []
    cs = (by_side["Mine"], by_side["Opponent"], both)
    out = ["", "Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):", "",
           "| Movement spells | Mine | Opponent | Both |", "| --- | --- | --- | --- |",
           "| Movement spells tried | " + " | ".join(f"{c.get('conv_tried', 0) / max(1, c.get('_games', 0)):.1f} a game" for c in cs) + " |"]
    out += [f"| {text} | " + " | ".join(_share(c, key) for c in cs) + " |" for text, key in CONVEYANCE_ROWS]
    return out


def shooting_rows(by_side, both, games):
    """Shooting (Morten 2026-11-11): shooters' own turns on the table and how often they shot, why not, and what the shots were worth."""
    if not both.get("shoot_turn_of"):
        return []
    cs = (by_side["Mine"], by_side["Opponent"], both)
    kinds = sorted({k.split("|")[1][:-3] for k in both if k.startswith("shoot_turn|") and k.endswith("_of")})
    out = ["", "Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:", "",
           "| Shooters | Mine | Opponent | Both |", "| --- | --- | --- | --- |",
           "| Shot when on the table | " + " | ".join(_share(c, "shoot_turn") for c in cs) + " |"]
    out += [f"|   {k} | " + " | ".join(_share(c, f"shoot_turn|{k}") for c in cs) + " |" for k in kinds]
    not_shot = [c.get("shoot_turn_of", 0) - c.get("shoot_turn_yes", 0) for c in cs]
    out += ["", "Why a shooter on the table did not shoot (per game, and the share of its turns not shot):", "",
            "| Reason | Mine | Opponent | Both |", "| --- | --- | --- | --- |"]
    for tag, text in SHOOT_REASONS:
        n = [c.get(f"shoot_why_{tag}", 0) for c in cs]
        if n[2]:
            out.append(f"| {text} | " + " | ".join(f"{v / games:.1f} ({100 * v / t:.0f}%)" if t else "-" for v, t in zip(n, not_shot)) + " |")
    shooters = sorted({k.split("|")[1] for k in both if k.startswith("shot_n|")})
    out += ["", "What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):", "",
            "| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |", "| --- | --- | --- | --- | --- | --- |"]
    for k in shooters:
        n, w, v, blank = (both.get(f"shot_{x}|{k}", 0) for x in ("n", "w", "v", "blank"))
        out.append(f"| {k} | {n / games:.1f} | {w / games:.1f} | {100 * blank / max(1, n):.0f}% | {v / max(1, n):.1f} pts | {v / games:.0f} pts |")
    return out


def _flank_charges():
    # Unforced errors (Morten 2026-11-11, remedy 5): flank/rear charges a unit could have turned to face (scripts/flank_charges.py).
    import importlib.util
    spec = importlib.util.spec_from_file_location("flank_charges", os.path.join(os.path.dirname(os.path.abspath(__file__)), "flank_charges.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# Charges (2026-11-11): a game, and per unit by what it carries (charges declared / made contact).
CHARGE_GROUPS = [("mwiz", "units carrying a magic-missile wizard (or one alone)"), ("wiz", "units carrying another wizard (or one alone)"),
                 ("other", "the other units (no war machines, no joined characters)")]


def _charge_cells(c):
    games = max(1, c.get("_games", 0))
    rows = [("Charges declared a game", f"{c.get('ch_declared', 0) / games:.1f}"), ("Charges that made contact a game", f"{c.get('ch_contact', 0) / games:.1f}")]
    for g, text in CHARGE_GROUPS:
        n = c.get(f"ch_{g}_units", 0)
        rows.append((f"  per unit a game, {text}", f"{c.get(f'ch_{g}_declared', 0) / n:.2f} declared, {c.get(f'ch_{g}_contact', 0) / n:.2f} contact ({n:.0f} units)" if n else "-"))
    return rows


def charge_rows(by_side, both):
    """Charges a game and per unit carrying a wizard (Morten 2026-11-11), Mine / Opponent / Both."""
    if not both.get("ch_mwiz_units") and not both.get("ch_other_units"):
        return []
    cs = [_charge_cells(c) for c in (by_side["Mine"], by_side["Opponent"], both)]
    out = ["", "Charges (declared, and made contact) a game, and per unit by the wizard it carries:", "",
           "| Charges | Mine | Opponent | Both |", "| --- | --- | --- | --- |"]
    out += [f"| {cs[0][i][0]} | {cs[0][i][1]} | {cs[1][i][1]} | {cs[2][i][1]} |" for i in range(len(cs[0]))]
    return out


def charge_compare_rows(sa, sb):
    ba, bb = _both(sa), _both(sb)
    if not (ba.get("ch_other_units") or ba.get("ch_mwiz_units")) or not (bb.get("ch_other_units") or bb.get("ch_mwiz_units")):
        return []
    cs = [_charge_cells(c) for c in (sa["Mine"], sa["Opponent"], ba, sb["Mine"], sb["Opponent"], bb)]
    out = ["", "### Charges a game and per unit by the wizard it carries", "",
           "| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |", "| --- | --- | --- | --- | --- | --- | --- |"]
    out += [f"| {cs[0][i][0]} | " + " | ".join(c[i][1] for c in cs) + " |" for i in range(len(cs[0]))]
    return out


def kpi_compare(a_dir, b_dir, a_label, b_label):
    (sa, _, ga), (sb, _, gb) = kpis(a_dir), kpis(b_dir)
    if not ga or not gb:
        return []
    ba, bb = _both(sa), _both(sb)
    out = ["## KPIs (Morten 2026-11-10)", "", f"A = {a_label} ({ga} games), B = {b_label} ({gb} games).{_missile_note(sa)}{_missile_note(sb)}", "",
           "| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |", "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for text, key, target in KPI_ROWS:
        out.append(f"| {text} | {target} | " + " | ".join(_kpi_cell(c, key, True) for c in (sa["Mine"], sa["Opponent"], ba, sb["Mine"], sb["Opponent"], bb)) + " |")
    out += _flank_charges().compare(a_dir, b_dir, a_label, b_label)
    out += charge_compare_rows(sa, sb)
    return out


def kpi_report(batch_dir):
    label = os.path.basename(os.path.normpath(batch_dir))
    t = kpi_table(batch_dir, label)
    m = movement_table(batch_dir, label)
    c = job_claims.claims_table([batch_dir], label)
    lines = t + ([""] if t and m else []) + m
    lines += ([""] if lines and c else []) + c
    return "\n".join(lines or ["No games with logs in this batch."]) + "\n"


def quality_table(batch_dir, label):
    rows_, units, rows = _quality_rows(batch_dir)
    if not rows_:
        return []
    out = [f"### Quality by phase: {label}", "",
           "Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).", "",
           "| Phase | Number | Mine | Opponent |", "| --- | --- | --- | --- |"]
    out += [f"| {p} | {t} | {a} | {b} |" for p, t, a, b in rows_]
    balance = balance_lines(rows)
    out += ([""] + balance) if balance else []
    rules = opponent_rules_table(batch_dir, label)
    out += ([""] + rules) if rules else []
    changes = rule_changes_table(batch_dir, label)
    out += ([""] + changes) if changes else []
    off = off_best_table(batch_dir, label)
    out += ([""] + off) if off else []
    plans = plans_table(batch_dir, label)
    out += ([""] + plans) if plans else []
    hunts = packages_table(batch_dir, label)
    out += ([""] + hunts) if hunts else []
    groups = battle_groups_table(batch_dir, label)
    out += ([""] + groups) if groups else []
    dep = deployment_tables(units, label)
    return out + ([""] + dep if dep else [])


def quality_compare(a_dir, b_dir, a_label, b_label):
    """Both batches' quality side by side: A Mine / A Opponent / B Mine / B Opponent."""
    ra, ua, rowsa = _quality_rows(a_dir)
    rb, ub, rowsb = _quality_rows(b_dir)
    if not ra or not rb:
        return []
    ca, cb = {(p, t): (x, y) for p, t, x, y in ra}, {(p, t): (x, y) for p, t, x, y in rb}
    out = ["## Quality by phase (per game and side)", "", "| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |",
           "| --- | --- | --- | --- | --- | --- |"]
    for k in list(ca) + [k for k in cb if k not in ca]:
        a, b = ca.get(k, ("-", "-")), cb.get(k, ("-", "-"))
        out.append(f"| {k[0]} | {k[1]} | {a[0]} | {a[1]} | {b[0]} | {b[1]} |")
    out += ["", f"A = {a_label}:"] + balance_lines(rowsa)
    out += ["", f"B = {b_label}:"] + balance_lines(rowsb)
    rules = opponent_rules_compare(a_dir, b_dir, a_label, b_label)
    out += ([""] + rules) if rules else []
    changes = rule_changes_compare(a_dir, b_dir, a_label, b_label)
    out += ([""] + changes) if changes else []
    off = off_best_compare(a_dir, b_dir, a_label, b_label)
    out += ([""] + off) if off else []
    plans = plans_compare(a_dir, b_dir, a_label, b_label)
    out += ([""] + plans) if plans else []
    hunts = packages_compare(a_dir, b_dir, a_label, b_label)
    out += ([""] + hunts) if hunts else []
    for d, label in ((a_dir, a_label), (b_dir, b_label)):
        groups = battle_groups_table(d, label)
        out += ([""] + groups) if groups else []
    for units, label in ((ua, a_label), (ub, b_label)):
        dep = deployment_tables(units, label)
        if dep:
            out += [""] + dep
    return out


def scorecard_report(batch_dir):
    rows = read_csv(os.path.join(batch_dir, "games.csv"))
    name = os.path.basename(os.path.normpath(batch_dir))
    table = scorecard_table(rows, name)
    unguided = unguided_table(rows)
    fights = charged_fights_table(batch_dir, name)
    fights += ([""] + effective_charges_table(batch_dir, name)) if fights else []
    fights += ([""] + damage_counted_table(batch_dir, name)) if fights else []
    setup = set_ups_table([(name, batch_dir)])
    fights += ([""] + setup) if setup else []
    qual = quality_table(batch_dir, name)
    fights = (qual + [""] + fights) if qual else fights
    kpi = kpi_table(batch_dir, name)
    fights = (kpi + [""] + fights) if kpi else fights
    return "\n".join([f"# Doctrine scorecard: {name}", ""] + (table or ["No scorecard columns (a batch before 2026-10-27's doctrine build)."])
                     + ([""] + fights if fights else []) + ([""] + unguided if unguided else [])) + "\n"


def report(a_dir, b_dir, a_label, b_label):
    a, b = read_csv(os.path.join(a_dir, "games.csv")), read_csv(os.path.join(b_dir, "games.csv"))
    a_by, b_by = {key(r): r for r in a}, {key(r): r for r in b}
    lines = [f"# {a_label} vs {b_label}", "",
             f"A = {a_label}: {os.path.basename(os.path.normpath(a_dir))}, {len(ended(a))} of {len(a)} games ended",
             f"B = {b_label}: {os.path.basename(os.path.normpath(b_dir))}, {len(ended(b))} of {len(b)} games ended", "",
             "## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)", "",
             "| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |",
             "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    diffs = []
    for k in sorted(set(a_by) | set(b_by)):
        ra, rb = a_by.get(k), b_by.get(k)
        ma = margin(ra) if ra and ra.get("ended") == "yes" else None
        mb = margin(rb) if rb and rb.get("ended") == "yes" else None
        d = ma - mb if ma is not None and mb is not None else None
        if d is not None:
            diffs.append(d)
        lines.append(f"| {k[0]} | {k[1]} | {k[2]} | {result(ra)} | {result(rb)} | {fmt(ma, sign=True)} | {fmt(mb, sign=True)} | {fmt(d, sign=True)} | "
                     f"{fmt(num(ra, 'cost_usd') if ra else None, 2)} | {fmt(num(rb, 'cost_usd') if rb else None, 2)} |")
    lines += ["", "## Totals", "", f"| | A: {a_label} | B: {b_label} |", "| --- | --- | --- |"]
    ea, eb = ended(a), ended(b)
    lines.append("| Mine won / drew / lost | %d / %d / %d | %d / %d / %d |" % (wdl(ea) + wdl(eb)))
    lines.append(f"| Mean margin (Mine - Opponent) | {fmt(mean([margin(r) for r in ea]), sign=True)} | {fmt(mean([margin(r) for r in eb]), sign=True)} |")
    for col, label in (("cost_usd", "Cost per game"), ("cost_mine_usd", "Mine side per game"), ("cost_opponent_usd", "Opponent side per game")):
        lines.append(f"| {label} | ${fmt(mean([num(r, col) for r in a]), 3)} | ${fmt(mean([num(r, col) for r in b]), 3)} |")
    lines.append(f"| Cost of the batch | ${fmt(sum(num(r, 'cost_usd', 0) for r in a), 2)} | ${fmt(sum(num(r, 'cost_usd', 0) for r in b), 2)} |")
    lines.append(f"| Failed calls per game | {fmt(mean([num(r, 'failed_calls') for r in a]), 1)} | {fmt(mean([num(r, 'failed_calls') for r in b]), 1)} |")
    for kind in SPLIT:
        for side in ("mine", "opponent"):
            col = f"vp_{kind}_{side}"
            va, vb = mean([num(r, col) for r in ea]), mean([num(r, col) for r in eb])
            if va is not None or vb is not None:
                lines.append(f"| VP from {kind}, {side.capitalize()} | {fmt(va)} | {fmt(vb)} |")
    for side in ("mine", "opponent"):
        col = f"units_lost_{side}"
        va, vb = mean([num(r, col) for r in ea]), mean([num(r, col) for r in eb])
        if va is not None or vb is not None:
            lines.append(f"| Units lost, {side.capitalize()} | {fmt(va, 1)} | {fmt(vb, 1)} |")
    lines += scorecard_totals(a, b)
    m, se = noise_band(diffs)
    lines += ["", "## Is the difference more than noise?", ""]
    if m is None:
        lines.append("No match-up ended in both batches: nothing to compare.")
    elif se is None:
        lines.append(f"One pair of games only: A minus B = {m:+.0f} VP. One game says nothing about noise.")
    else:
        verdict = ("more than noise" if abs(m) > 2 * se else "within noise (could be chance)")
        lines.append(f"{len(diffs)} pairs of games: A's margin is {m:+.0f} VP a game against B's, give or take {2 * se:.0f} VP "
                     f"(two standard errors). Verdict: {verdict}.")
    kpi = kpi_compare(a_dir, b_dir, a_label, b_label)
    if kpi:
        lines += [""] + kpi
    move = movement_compare(a_dir, b_dir, a_label, b_label)
    if move:
        lines += [""] + move
    ca, cb = job_claims.claims_table([a_dir], a_label), job_claims.claims_table([b_dir], b_label)
    if ca or cb:
        lines += ["", "## Claimed against happened, per job (Morten 2026-11-13)", ""]
        for t in (ca, cb):
            if t:
                lines += t + [""]
    sa, sb = scorecard_table(a, a_label), scorecard_table(b, b_label)
    if sa or sb:
        lines += ["", "## Doctrine scorecard (per game and side; far = share of games contested)", ""]
        for t in (sa, sb):
            if t:
                lines += t + [""]
    fa, fb = charged_fights_table(a_dir, a_label), charged_fights_table(b_dir, b_label)
    if fa or fb:
        lines += ["", "## Charged fights (points per fight a side charged into; a combined charge is one fight)", ""]
        for t in (fa, fb):
            if t:
                lines += t + [""]
    ea_, eb_ = effective_charges_table(a_dir, a_label), effective_charges_table(b_dir, b_label)
    if ea_ or eb_:
        lines += ["", f"## Effective charges ({EFFECTIVE_LOW}-{EFFECTIVE_HIGH}% to win the first round: just enough force)", ""]
        for t in (ea_, eb_):
            if t:
                lines += t + [""]
    da, db_ = damage_counted_table(a_dir, a_label), damage_counted_table(b_dir, b_label)
    if da or db_:
        lines += ["", "## Charged fights by odds band, damage counted (Morten 2026-11-10)", ""]
        for t in (da, db_):
            if t:
                lines += t + [""]
    setup = set_ups_table([(a_label, a_dir), (b_label, b_dir)])
    if setup:
        lines += [""] + setup
    ca, cb = combined_arms_table(a_dir, a_label), combined_arms_table(b_dir, b_label)
    if ca or cb:
        lines += ["", "## Combined arms (paper 2026-11-09, item 8)", ""]
        for t in (ca, cb):
            if t:
                lines += t + [""]
    qual = quality_compare(a_dir, b_dir, a_label, b_label)
    if qual:
        lines += [""] + qual
    unguided = unguided_table(a + b)
    if unguided:
        lines += [""] + unguided
    pa, pb = read_csv(os.path.join(a_dir, "plays.csv")), read_csv(os.path.join(b_dir, "plays.csv"))
    if pa or pb:
        lines += ["", "## Plays", ""]
        for label, rows, games in ((a_label, pa, len(a)), (b_label, pb, len(b))):
            summary = plays_summary(rows, games)
            lines.append(f"- {label}: " + ("; ".join(summary) if summary else "no play run"))
        for label, rows in ((a_label, pa), (b_label, pb)):
            table = worked_table(rows)
            if table:
                lines += ["", f"### Worked / not worked: {label}", ""] + table
    return "\n".join(lines) + "\n"


GAMES_HEADER = ("batch,pair,scenario,seed,opponent,model,ended,round,winner,vp_mine_opponent,cost_usd,calls,failed_calls,findings,warnings,minutes,"
                "mine_model,cost_mine_usd,cost_opponent_usd,first_player,vp_objectives_mine,vp_objectives_opponent,vp_kills_mine,vp_kills_opponent,"
                "vp_leaders_mine,vp_leaders_opponent,vp_other_mine,vp_other_opponent,units_lost_mine,units_lost_opponent,points_lost_mine,"
                "points_lost_opponent,plays_mine,plays_opponent,far_contested_mine,far_contested_opponent,lone_holders_mine,lone_holders_opponent,"
                "first_hammer_charge_mine,first_hammer_charge_opponent,lone_charges_mine,lone_charges_opponent,idle_units_mine,idle_units_opponent,"
                "wounded_lost_mine,wounded_lost_opponent,doctrine_flags_mine,doctrine_flags_opponent,doctrine_changed_mine,doctrine_changed_opponent,"
                "idle_points_mine,idle_points_opponent,unguided_mine,unguided_opponent")
PLAYS_HEADER = ("batch,pair,scenario,seed,side,play,name,first_round,last_round,plans,state,steps,steps_done,steps_skipped,done_list,misses,offers,"
                "offers_yes,offers_no,started_round,reason,planned_worth,taken_worth,worked")


def _stance_self_test():
    row = lambda turn, side, what: {"kind": "action", "type": "ArmyStance", "turn": turn, "side": side, "summary": f"ARMY STANCE: {what}: shooting and magic ~9 a turn against the enemy's ~3"}
    k = _kpi_game([row(1, "Mine", "defensive"), row(1, "Mine", "defensive"), row(2, "Mine", "offensive"), row(1, "Opponent", "offensive")], {})
    ok = k["Mine"].get("stance_of") == 2 and k["Mine"].get("stance_yes") == 1 and k["Opponent"].get("stance_yes") == 0
    return [] if ok else [f"army stance KPI: {k}"]


def _first_round_self_test():
    """First round won (2026-11-14): the result read is the first one AFTER the charge made contact, for the fight's own units. A charger
    going second finds the round's first result is an older fight's (the target against someone else, fought before the charge)."""
    def act(i, typ, side, actor, target, summary, phase="Combat"):
        return {"id": i, "turn": 3, "phase": phase, "side": side, "type": typ, "actor": actor, "target": target, "summary": summary}
    units = {n: {"side": s} for n, s in (("Wolves", "Mine"), ("Trolls", "Opponent"), ("Boar", "Opponent"), ("Gyros", "Mine"))}
    actions = [
        # Before the charge: Trolls and Gyros fight, Trolls win the result (the Opponent's).
        act(1, "CombatAttack", "Opponent", "Trolls", "Gyros", "Trolls attacks Gyros: 2 hits"),
        act(2, "CombatResult", "Opponent", None, None, "Combat result: Mine 0 vs Opponent 2 - Opponent wins"),
        # Then Mine's Wolves charge the Trolls and lose that round.
        act(3, "Charge", "Mine", "Wolves", "Trolls", "Wolves charges Trolls: made contact, aligned", phase="Movement"),
        act(4, "CombatAttack", "Opponent", "Trolls", "Wolves", "Trolls attacks Wolves: 2 hits"),
        act(5, "CombatResult", "Mine", None, None, "Combat result: Mine 0 vs Opponent 3 - Opponent wins")]
    got = {f["target"]: f.get("first_round") for f in _game_fights(actions, units)}
    out = []
    if got.get("Trolls") is not False:
        out.append(f"first round won must read the result after the charge (lost), not the earlier fight's: {got}")
    # The mirror: the charger wins the round after the charge although the round before was lost.
    actions[4] = act(5, "CombatResult", "Mine", None, None, "Combat result: Mine 4 vs Opponent 1 - Mine wins")
    got = {f["target"]: f.get("first_round") for f in _game_fights(actions, units)}
    # A form-up line in the Combat phase at contact (named for the target) must not make the earlier or another fight's result the round's.
    decoy = [act(1, "CombatAttack", "Opponent", "Boar", "Gyros", "Boar attacks Gyros: 2 hits"),
             act(2, "CombatResult", "Opponent", None, None, "Combat result: Mine 0 vs Opponent 2 - Opponent wins"),
             act(3, "Charge", "Mine", "Wolves", "Trolls", "Wolves charges Trolls: made contact, aligned", phase="Movement"),
             act(4, "FormUp", "Opponent", "Trolls", None, "Trolls forms up into a fighting rank"),
             act(5, "CombatResult", "Opponent", None, None, "Combat result: Mine 0 vs Opponent 2 - Opponent wins"),
             act(6, "Computer", "Mine", None, None, "Fights the combat: Wolves against Trolls"),
             act(7, "CombatResult", "Mine", None, None, "Combat result: Mine 4 vs Opponent 1 - Mine wins")]
    got_decoy = {f["target"]: f.get("first_round") for f in _game_fights(decoy, units)}
    if got_decoy.get("Trolls") is not True:
        out.append(f"first round won must follow the 'Fights the combat' line, not a form-up line: {got_decoy}")
    if got.get("Trolls") is not True:
        out.append(f"first round won must read the result after the charge (won): {got}")
    return out


def self_test():
    problems = _packages_self_test() + _battle_groups_self_test() + job_claims.self_test() + _stance_self_test()
    if problems:
        print("MISSING:\n" + "\n".join(problems))
        return 1
    with tempfile.TemporaryDirectory() as tmp:
        a, b = os.path.join(tmp, "with"), os.path.join(tmp, "without")
        os.makedirs(a)
        os.makedirs(b)
        open(os.path.join(a, "games.csv"), "w").write(GAMES_HEADER + "\n"
            "x,B2,2,1,Generals,h,yes,6,Mine,1500-1000,0.30,1,2,0,0,1,,0.15,0.15,Mine,300,100,1000,800,100,0,100,100,2,3,300,400,3,0,yes,no,1,3,2,,0,1,2,3,0,1,2,1,1,0,700,300,Luckstone; Ruby Ring of Ruin,\n"
            "x,B2,2,2,Generals,h,yes,6,Opponent,900-1100,0.40,1,0,0,0,1,,0.20,0.20,Mine,300,100,500,900,100,100,0,0,4,2,500,200,2,0,no,no,3,1,4,3,2,1,0,1,1,0,0,2,0,1,900,200,Luckstone,Release the Fanatics!\n"
            "x,D3,3,1,Generals,h,no,,,,0.10,1,0,1,0,1,,0.05,0.05,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\n")
        # B is an older batch: no newer columns, no plays.csv.
        open(os.path.join(b, "games.csv"), "w").write(
            "batch,pair,scenario,seed,opponent,model,ended,round,winner,vp_mine_opponent,cost_usd,calls,failed_calls,findings,warnings,minutes,mine_model,cost_mine_usd,cost_opponent_usd\n"
            "y,B2,2,1,Generals,h,yes,6,draw,1000-1000,0.20,1,1,0,0,1,,0.10,0.10\n"
            "y,B2,2,2,Generals,h,yes,6,Opponent,700-1300,0.20,1,1,0,0,1,,0.10,0.10\n")
        open(os.path.join(a, "plays.csv"), "w").write(PLAYS_HEADER + "\n"
            "x,B2,2,1,Mine,BM-P1,\"Herdstone anchor, the base\",0,6,7,Running,5,3,0,1 2 3,,3:y,1,0,1,,300,150,partly\n"
            "x,B2,2,1,Mine,BM-P2,Hunt the guns,0,2,3,Stalled,6,1,1,1 2s,3:2,3:n,0,1,1,\"at step 3: no candidate\",400,0,not worked\n"
            "x,B2,2,2,Mine,BM-P2,Hunt the guns,0,2,3,Fired,6,4,0,1 2 3 4,,,0,0,1,,400,380,worked\n")
        out = report(a, b, "with plays", "without plays")
        checks = [
            "| B2 | 2 | 1 | Mine 1500-1000 | draw 1000-1000 | +500 | +0 | +500 |",
            "| B2 | 2 | 2 | Opponent 900-1100 | Opponent 700-1300 | -200 | -600 | +400 |",
            "| D3 | 3 | 1 | not ended (no) | - |",
            "| Mine won / drew / lost | 1 / 0 / 1 | 0 / 1 / 1 |",
            "| Mean margin (Mine - Opponent) | +150 | -300 |",
            "| VP from objectives, Mine | 300 | - |",
            "2 pairs of games: A's margin is +450 VP a game against B's, give or take 100 VP",
            "Verdict: more than noise.",
            "Mine: 3 plays in 3 games (1.0 a game); end states Fired 1, Running 1, Stalled 1; steps done 8 of 17 (skipped 1); due steps with a candidate offered 1, without 1",
            "- without plays: no play run",
            "| Mine | BM-P2 Hunt the guns | 2 | 1 | 1 | 0 | 1 | 400 | 190 |",
            "| Mine | BM-P1 Herdstone anchor, the base | 1 | 0 | 0 | 1 | 0 | 300 | 150 |",
            "| B2 | 2 | 1 | Mine | yes | 1 | 2 | 0 | 2 | 0 | 2 | 1 |",
            "| **Average** | | | Mine | 50% | 2.0 | 3.0 | 1.0 | 1.0 | 0.5 | 1.0 | 0.5 |",
            "| **Average** | | | Opponent | 0% | 2.0 | 3.0 | 1.0 | 2.0 | 0.5 | 1.5 | 0.5 |",
            "| Scorecard: Lone holders (player turns) (both sides) | 2.0 | - |",
            "| Scorecard: Points that never moved of their own (both sides) | 525.0 | - |",
        ]
        missing = [c for c in checks if c not in out]
        alone = plays_report(a)
        card = scorecard_report(a)
        missing += [c for c in ["# Doctrine scorecard: with", "| **Average** | | | Mine | 50% |", "| Luckstone | Mine | B2 |",
                                "| Release the Fanatics! | Opponent | B2 |", "| Ruby Ring of Ruin | Mine | B2 |"] if c not in card]
        missing += [c for c in ["## Decision items and abilities without guidance", "| Luckstone | Mine | B2 |"] if c not in out]
        missing += [c for c in ["# Plays: with", "| Mine | BM-P2 Hunt the guns | 2 | 1 | 1 | 0 | 1 | 400 | 190 |"] if c not in alone]

        # Charged fights (Morten 2026-11-04): a game log + its record. Mine's lone Boss charges the Knights and dies (lost 100); the
        # Opponent's Wolves + Trolls charge the Gyros together (one fight, 2 chargers) and kill them (won 150); the Gyros kill nothing.
        c = os.path.join(tmp, "charges")
        os.makedirs(c)
        open(os.path.join(c, "games.csv"), "w").write(GAMES_HEADER + "\n" + "z,C9,1,1,General,h,yes,6,Opponent,100-300,0.1,1,0,0,0,1" + "," * 38 + "\n")
        def act(turn, phase, side, typ, actor, target, summary):
            return json.dumps({"kind": "action", "turn": turn, "phase": phase, "side": side, "type": typ, "actor": actor, "target": target, "summary": summary})
        open(os.path.join(c, "game-C9-1-1.log.jsonl"), "w").write("\n".join([
            act(2, "Movement", "Mine", "Charge", "Boss", "Knights", "Boss charges Knights: made contact, aligned"),
            act(2, "Combat", "Opponent", "CombatAttack", "Knights", "Boss", "Knights attacks Boss: 3 hits - destroyed"),
            act(2, "Combat", "Mine", "CombatResult", None, None, "Boss wiped out - Opponent wins the combat automatically"),
            act(3, "Movement", "Opponent", "Charge", "Wolves", "Gyros", "Wolves charges Gyros: made contact, aligned"),
            act(3, "Movement", "Opponent", "Charge", "Trolls", "Gyros", "Trolls charges Gyros: made contact, aligned"),
            act(3, "Movement", "Opponent", "Charge", "Hounds", "Gyros", "Hounds charges Gyros: fell short - failed charge"),
            act(3, "Combat", "Opponent", "CombatAttack", "Trolls", "Gyros", "Trolls attacks Gyros: 4 hits - destroyed"),
            act(3, "Combat", "Mine", "CombatResult", None, None, "Combat result: Mine 0 vs Opponent 5 - Opponent wins"),
            act(4, "Combat", "Mine", "CombatAttack", "Gyros", "Wolves", "Gyros attacks Wolves: 1 hits"),
            # Effective charges: the generals' picks with their figures (the Boss a long shot, Wolves + Trolls together 65%).
            json.dumps({"kind": "call", "turn": 2, "general": "Mine", "type": "TurnObjective", "ok": True, "answer": '{"option_id":2}',
                        "question": "UNIT #1 Boss (100 pts, Combat).\n  1) Hold Marker 1 -> worth ~5 VP\n"
                                    "  2) [PRIMARY] Charge #9 Knights (300 pts): reach 90%, win first round 26%, slain or flees 0% -> worth ~3 VP"}),
            json.dumps({"kind": "call", "turn": 3, "general": "Opponent", "type": "TurnObjective", "ok": True, "answer": '{"option_id":1}',
                        "question": "UNIT #5 Wolves (60 pts, Chaff).\n  1) Charge #2 Gyros (150 pts): reach 80%, win first round 40%, slain or flees 10% -> "
                                    "worth ~9 VP; HELP: alone win 40%, with #6 Trolls charging too (its reach 90%) win 65%"})]) + "\n")
        db = sqlite3.connect(os.path.join(c, "records.db"))
        db.execute("create table GameRecordUnits (GameRecordId, Side, BoardName, Points, Gone, GoneRound, GoneCause, VictoryPointsGivenUp, ArmyBook)")
        db.executemany("insert into GameRecordUnits values (1,?,?,?,?,?,?,?,?)", [
            (0, "Boss", 100, 1, 2, "Combat", 100, "Dwarfs"), (0, "Gyros", 150, 1, 3, "Combat", 150, "Dwarfs"),
            (0, "Cannon", 120, 0, None, None, 0, "Dwarfs"), (1, "Knights", 300, 0, None, None, 0, "Empire"),
            (1, "Wolves", 60, 0, None, None, 0, "Empire"), (1, "Trolls", 200, 0, None, None, 0, "Empire"), (1, "Hounds", 50, 1, 4, "Shooting", 50, "Empire"),
            (1, "Archers", 70, 1, 5, "Magic", 70, "Empire")])
        # The quality report's columns (records from 2026-10-25 on): type, deploy spot, who destroyed it, points earned.
        for col in ("TroopType", "IsCharacter", "Kind", "DeploySpot", "Fought", "RoundFirstFought", "GoneByUnitName", "JoinedToUnitName",
                    "WoundsDealt", "VictoryPointsEarned"):
            db.execute(f"alter table GameRecordUnits add column {col}")
        for name, troop, char, kind, spot, fought, first, by, earned in [
                ("Boss", "Character", 1, "Regular Infantry, <100, Hammer", "centre, front half", 1, 2, "Knights", 0),
                ("Gyros", "Monster", 0, "Monster, 100-199, Fast Hammer", "left third, front half", 1, 4, "Trolls", 0),
                ("Cannon", "War Machines", 0, "War Machines, 100-199, Shooter", "centre, back half", 0, None, None, 50),
                ("Knights", "Cavalry", 0, "Heavy Cavalry, 200-349, Hammer", "centre, front half", 1, 2, None, 100),
                ("Wolves", "Cavalry", 0, "Light Cavalry, <100, Chaff", "left third, front half", 1, 3, None, 0),
                ("Trolls", "Infantry", 0, "Monstrous Infantry, 200-349, Hammer", "right third, back half", 1, 3, None, 150)]:
            db.execute("update GameRecordUnits set TroopType=?, IsCharacter=?, Kind=?, DeploySpot=?, Fought=?, RoundFirstFought=?, GoneByUnitName=?, "
                       "VictoryPointsEarned=? where BoardName=?", (troop, char, kind, spot, fought, first, by, earned, name))
        db.commit()
        with open(os.path.join(c, "game-C9-1-1.log.jsonl"), "a") as f:
            f.write("\n".join([
                act(3, "Strategy", "Opponent", "Computer", None, None, "Objective for Wolves: charge #2 Gyros: its best option, worth ~9 VP; win first round 40%"),
                act(3, "Strategy", "Opponent", "Computer", None, None, "Objective for Hounds: charge #2 Gyros: its best option, worth ~5 VP; win first round 30%"),
                act(3, "Shooting", "Mine", "WarMachineShot", "Cannon", "Knights", "Cannon fires Cannon at Knights: 1 hits, 2 wound(s)"),
                # Opponent rules: the Wolves' wear-down charge (the Gyros destroyed that round: won 150), the Hounds' screen given up (the
                # Hounds destroyed in round 4: lost 50), the Boss's blocked charge skipped (the Boss destroyed that round: lost 100).
                act(3, "Strategy", "Opponent", "OpponentRule", "Wolves", "Gyros", "WEARS DOWN: +12.0 VP: charge #2 Gyros | CHANGED: +20.0 VP v +14.5 VP instead of charge #4 Cannon"),
                act(4, "Strategy", "Opponent", "OpponentRule", "Hounds", "Gyros", "GIVES UP ITS SCREEN: -5.5 VP: charge #2 Gyros | SAME: +9.0 VP v +3.0 VP instead of hold Marker 1"),
                act(2, "Movement", "Mine", "OpponentRule", "Boss", "Knights", "BLOCKED CHARGE SKIPPED: +0.0 VP: no charge on #9 Knights: Wolves is in the way of its landing"),
                # Off best figure (2026-11-13): a gate's OFF BEST row, and a rule whose own row says it took the lower figure.
                act(4, "Movement", "Opponent", "OpponentRule", "Hounds", None, "OFF BEST: -12.0 VP: stays: [JOB FIRST] #7 stay | CHANGED: +3.0 VP v +15.0 VP instead of close in to charge #2 Gyros"),
                act(3, "Strategy", "Mine", "OpponentRule", "Boss", "Knights", "CHARIOT NO STATIC JOB: +0.0 VP: charge #9 Knights | CHANGED: +10.0 VP v +40.0 VP instead of hold Marker 1"),
                # Plans: the Wolves' charge happened (won 150 of 20 planned), the Hounds' close-in did not.
                act(4, "Strategy", "Opponent", "OpponentRule", "Wolves", "Gyros", "PLAN RESULT: +150.0 VP: happened=yes won=150.0 planned=20.0 kind=charge: charge #2 Gyros (it is gone)"),
                act(4, "Strategy", "Opponent", "OpponentRule", "Hounds", "Gyros", "PLAN RESULT: +0.0 VP: happened=no won=0.0 planned=10.0 kind=close in: close in to charge #2 Gyros next turn (now: hold Marker 1)"),
                json.dumps({"kind": "objective", "turn": 2, "objective": "StrategicLocation", "side": "Opponent", "unit": "Knights", "points": 30})]) + "\n")
        db.close()
        fights = charged_fights_table(c, "charges")
        missing += [x for x in [
            "| Mine | Dwarfs | 1 | 120 | 0 | 1.0 | 1.0 | 0 | 100 | -100 | 1 of 1 | 0 of 1 | - | -100 |",
            "| Opponent | Empire | 1 | 0 | 150 | 1.0 | 2.0 | 150 | 0 | +150 | 1 of 1 | 1 of 1 | +150 | - |"] if x not in "\n".join(fights)]
        effective = "\n".join(effective_charges_table(c, "charges"))
        missing += [x for x in [
            "| Mine | Dwarfs | 1 | 1 (net -100) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |",
            "| Opponent | Empire | 1 | 0 | 0 | 1 (net +150) | 0 | 0 | 0 | 0 | 100% (1 of 1) |"] if x not in effective]
        # Overkill (Morten 2026-11-10): a target of 250+ pts never; under 250 only when the chargers are worth more than 3x it; redirects left out.
        for args, want in [((95, 400, 300, False), False), ((95, 400, 249, False), False), ((95, 301, 100, False), True),
                           ((95, 300, 100, False), False), ((89, 500, 100, False), False), ((95, 500, 100, True), False)]:
            if _overkill(*args) != want:
                missing.append(f"overkill rule {args} -> {not want}")
        # Damage counted (Morten 2026-11-10): Ogres (3 models x 3 W, 120 pts) lose one model and a wound on another while the fight runs
        # (4 of 9 wounds: 53 pts), then run off later (not in the fight); Goblins (60 pts) flee and are not caught (half: 30 pts); the
        # Knights, gone in the fight, count their 200 VP.
        tl = _health_timeline([{"id": 1, "n": "Ogres", "lk": {"w": 3, "mc": 3}}, {"id": 2, "n": "Goblins", "lk": {"w": 1, "mc": 20}},
                               {"id": 3, "n": "Knights", "lk": {"w": 1, "mc": 5}}],
                              [(5, [{"id": 1, "on": 1, "m": [[0, 0]] * 3, "wt": None}]), (12, [{"id": 1, "on": 1, "m": [[0, 0]] * 2, "wt": 1}]),
                               (13, [{"id": 2, "on": 1, "m": [[0, 0]] * 20, "fl": 1}]), (14, [{"id": 1, "on": 0, "m": [[0, 0]]}]),
                               (30, [{"id": 1, "on": 1, "m": [[0, 0]]}])])
        du = {"Ogres": {"side": "Opponent", "points": 120, "vp": 120}, "Goblins": {"side": "Opponent", "points": 60, "vp": 60},
              "Knights": {"side": "Mine", "points": 200, "vp": 200}}
        won_d, lost_d = _fight_damage({"side": "Mine"}, ["Ogres", "Goblins", "Knights"], du, tl, 10, 20, {"Knights"})
        if (round(won_d), round(lost_d)) != (83, 200):
            missing.append(f"damage counted: won {won_d:.1f}, lost {lost_d:.1f} (want 83, 200)")
        # Old rule 7 tuples: [6] is now "overkill by the 3x rule" - a 90%+ fight that is no overkill goes to its own column.
        if _band((1, 0, 0, False, None, 95, False), 90, 101) or not _cheap_sure((1, 0, 0, False, None, 95, False)):
            missing.append("a cheaper 90%+ charge counted as overkill")
        if not _band((1, 0, 0, False, None, 95, True), 90, 101) or _cheap_sure((1, 0, 0, False, None, 95, True)):
            missing.append("a dearer 90%+ charge not counted as overkill")
        missing += [x for x in ["### Effective charges: charges"] if x not in scorecard_report(c)]
        # Quality by phase (Morten 2026-11-08): charges per side from the log, points per cause from the record.
        qual = "\n".join(quality_table(c, "charges"))
        missing += [x for x in [
            "| Combat | Points destroyed in combat | 0.0 | 250.0 |", "| Shooting | Points destroyed by shooting units | 50.0 | 0.0 |",
            "| Magic | Points destroyed by magic (all spells) | 70.0 | 0.0 |", "| Combat | First round won (charged fights) | 0% | 100% |",
            "| Combat | Net points per supported fight / lone fight | - / -100 | +150 / - |",
            "| Strategy | Charge objectives carried out (made contact) | - | 50% (1 of 2) |",
            "| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | - |",
            "| Mine | War machine | 1 | 42 (1) | 42 | 0 |",
            "| Opponent | Hammer | 2 | 56 (2) | 50 | 6 |"] if x not in qual]
        missing += [x for x in ["### Quality by phase: charges"] if x not in scorecard_report(c)]
        # Augments (2026-11-10): only spells that last this turn and do not move the unit count (Battle Lust, Daemonic Vessel), as the
        # 11-06 rule limits only those; a self spell (no target) counts its caster, and a declared charge that fell short counts as a charge.
        aug = os.path.join(tmp, "augments")
        shutil.copytree(c, aug)
        with open(os.path.join(aug, "game-C9-1-1.log.jsonl"), "a") as f:
            f.write("\n".join([
                act(2, "Strategy", "Mine", "SpellCast", "Cannon", "Boss", "Cannon attempts Battle Lust (6+3 = 9 vs 7+) on Boss: cast successfully"),
                act(3, "Strategy", "Mine", "SpellCast", "Cannon", "Cannon", "Cannon attempts Battle Lust (6+3 = 9 vs 7+) on Cannon: cast successfully"),
                act(3, "Strategy", "Mine", "SpellCast", "Cannon", "Cannon", "Cannon attempts Hellish Vigour (6+3 = 9 vs 7+) on Cannon: cast successfully"),
                act(4, "Strategy", "Mine", "SpellCast", "Cannon", "Gyros", "Cannon attempts Deathly Cabal (6+3 = 9 vs 7+) on Gyros: cast successfully"),
                act(4, "Strategy", "Mine", "SpellCast", "Gyros", None, "Gyros attempts Daemonic Vessel (6+3 = 9 vs 7+): cast successfully"),
                act(3, "Movement", "Opponent", "Charge", "Hounds", "Gyros", "Hounds declares a charge against Gyros"),
                act(3, "Strategy", "Opponent", "SpellCast", "Trolls", "Hounds", "Trolls attempts Battle Lust (6+3 = 9 vs 7+) on Hounds: cast successfully")]) + "\n")
        missing += [x for x in ["| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 100% (1 of 1) |"]
                    if x not in "\n".join(quality_table(aug, "augments"))]
        missing += [x for x in [
            "### Opponent rules: charges",
            "| BLOCKED CHARGE SKIPPED | 1.0 | +0.0 | 0.0 | 100.0 | - | - | - | - |",
            "| GIVES UP ITS SCREEN | - | - | - | - | 1.0 | -5.5 | 0.0 | 50.0 |",
            "| WEARS DOWN | - | - | - | - | 1.0 | +12.0 | 150.0 | 0.0 |"] if x not in qual]
        # Rule changes (Morten 2026-11-12): WEARS DOWN changed the Wolves' pick (+5.5 VP by its numbers), the screen rule did not, the blocked
        # charge row says nothing yet.
        missing += [x for x in [
            "### Rule changes: charges",
            "| WEARS DOWN | 1 | 1 | 1 | 1.00 | +6 | +5.5 |",
            "| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |",
            "| BLOCKED CHARGE SKIPPED | 1 | not checked | - | - | - | - |",
            "| PLAN RESULT | 2 | trace | - | - | - | - |"] if x not in qual]
        missing += [x for x in [
            "### Off best figure: charges",
            "| CHARIOT NO STATIC JOB | rule | 1.00 | - | 30.0 |",
            "| JOB FIRST | gate | - | 1.00 | 12.0 |"] if x not in qual]
        missing += [x for x in [
            "### Plans: charges",
            "| Opponent | charge | 1.0 | 100% | 20 | 150 | 750% |",
            "| Opponent | close in | 1.0 | 0% | 10 | 0 | 0% |"] if x not in qual]
        # The static opponent's odds from its objective and support lines (no call).
        so = _static_odds([
            {"type": "Computer", "phase": "Strategy", "side": "Opponent", "turn": 2,
             "summary": "Objective for Boar Boyz: charge #12 Spearmen (Shield): its best option, worth ~74.3 VP; win first round 63%"},
            {"type": "Computer", "phase": "Strategy", "side": "Opponent", "turn": 2,
             "summary": "Wolves asks Trolls and Ogres to charge Gyros with it (alone win 40%, together 91%): the best support by the figures"}])
        if so != {("Opponent", 2, "Boar Boyz", "Spearmen (Shield)"): (63, None, None), ("Opponent", 2, "Wolves", "Gyros"): (40, ["Trolls", "Ogres"], 91)}:
            missing.append(f"static odds: {so}")
        if _fight_odds({"side": "Opponent", "turn": 2, "target": "Gyros", "chargers": ["Wolves", "Ogres"]}, so) != 91:
            missing.append("a gang's together figure when one helper charged")
        # Unfigured charges (2026-11-10): a running-fight charge, a charge made now off a close-in, and a join each carry their figure.
        so2 = _static_odds([
            {"type": "Computer", "phase": "Strategy", "side": "Opponent", "turn": 5,
             "summary": "Objective for Doomseeker 5: charge #12133 Master Necromancer (Sceptre of De Noirot) (joins the fight with #12147 Slayers 3, "
                        "#12148 Doomseeker (Master Rune of Alaric The Mad): the combat won 73%, lost 12%): its only option; win first round 73%"},
            {"type": "Computer", "phase": "Movement", "side": "Opponent", "turn": 5,
             "summary": "Gors (Scourge) charges Cannon (Rune) (with Swiftstride): it can charge now Cannon (Rune): it charges (the charge now is worth ~40 VP; win first round 66%)"},
            {"type": "Computer", "phase": "Movement", "side": "Opponent", "turn": 5,
             "summary": "Tomb King (General) joins Skeleton Archers's charge on Hireling Outriders 2 (alone win 44%, together 100%): the figures favour it"}])
        if so2 != {("Opponent", 5, "Doomseeker 5", "Master Necromancer (Sceptre of De Noirot)"): (73, None, None),
                   ("Opponent", 5, "Gors (Scourge)", "Cannon (Rune)"): (66, None, None),
                   ("Opponent", 5, "Tomb King (General)", "Hireling Outriders 2"): (100, None, None)}:
            missing.append(f"unfigured charges' odds: {so2}")
        # The sweet spot is 55-75% inclusive (Morten 2026-11-05): 55 and 75 are effective, 54 and 76 are not.
        band_of = lambda pct: next(b[0] for b in ODDS_BANDS if b[1] <= pct < b[2])
        missing += [f"{pct}% in {band_of(pct)}" for pct, eff in ((54, False), (55, True), (75, True), (76, False))
                    if band_of(pct).startswith("Effective") != eff]
        # Combined arms (item 8): Mine's Block with the Hounds beside it; the Knights charge the Hounds in front of the Block (a screen),
        # Mine answers with the Gyros and the Block (a counter-charge, one fight with 2 chargers); a lane opened on the Wolves, gone that round.
        ca = os.path.join(tmp, "arms")
        os.makedirs(ca)
        open(os.path.join(ca, "games.csv"), "w").write(GAMES_HEADER + "\n" + "z,C8,1,1,General,h,yes,6,Mine,300-100,0.1,1,0,0,0,1" + "," * 38 + "\n")
        ids = {"Block": 1, "Hounds": 2, "Knights": 3, "Wolves": 4, "Gyros": 5}

        def ac(i, turn, phase, side, typ, actor, target, summary):
            return json.dumps({"kind": "action", "id": i, "turn": turn, "phase": phase, "side": side, "type": typ, "actor": actor, "target": target,
                               "actor_id": ids.get(actor), "target_id": ids.get(target), "summary": summary})

        def fr(after, **at):
            return json.dumps({"kind": "frame", "after": after, "units": [{"id": ids[n], "x": x, "y": y, "on": 1} for n, (x, y) in at.items()]})
        open(os.path.join(ca, "game-C8-1-1.log.jsonl"), "w").write("\n".join([
            fr(0, Block=(20, 10), Hounds=(25, 10), Knights=(20, 40), Wolves=(30, 40), Gyros=(40, 10)),
            ac(1, 1, "Movement", "Mine", "Move", "Block", None, "Block moves 2\""),
            ac(2, 1, "Movement", "Mine", "Move", "Hounds", None, "Hounds moves 6\""),
            fr(2, Hounds=(20, 16)),
            fr(2, Knights=(20, 22)),
            ac(3, 1, "Movement", "Opponent", "Charge", "Knights", "Hounds", "Knights charges Hounds: made contact, aligned"),
            ac(4, 2, "Movement", "Mine", "Charge", "Gyros", "Knights", "Gyros charges Knights: made contact, aligned"),
            ac(5, 2, "Shooting", "Mine", "OpponentRule", "Block", "Wolves", "OPENS A LANE: +20.0 VP: shoots at #4 Wolves"),
            ac(6, 2, "Movement", "Mine", "Charge", "Block", "Knights", "Block charges Knights: made contact, aligned")]) + "\n")
        db = sqlite3.connect(os.path.join(ca, "records.db"))
        db.execute("create table GameRecordUnits (GameRecordId, Side, BoardName, Points, Gone, GoneRound, GoneCause, VictoryPointsGivenUp, ArmyBook, IsCharacter)")
        db.executemany("insert into GameRecordUnits values (1,?,?,?,?,?,?,?,?,0)", [
            (0, "Block", 300, 0, None, None, 0, "Dwarfs"), (0, "Hounds", 50, 0, None, None, 0, "Dwarfs"), (0, "Gyros", 150, 0, None, None, 0, "Dwarfs"),
            (1, "Knights", 300, 0, None, None, 0, "Empire"), (1, "Wolves", 60, 1, 2, "Shooting", 60, "Empire")])
        db.commit()
        db.close()
        arms = "\n".join(combined_arms_table(ca, "arms"))
        missing += [x for x in [
            "| Mine | 1 of 1 (100%) | 1 of 1 (100%) | 2 of 2 (100%) | 1.00 per game | 1.00 / 1.00 per game |",
            "| Opponent | 0 of 1 (0%) | 0 of 2 (0%) | 0 of 1 (0%) | 0.00 per game | 0.00 / 0.00 per game |"] if x not in arms]
        # KPIs (Morten 2026-11-10). Round 2: Mine's Knights beat the Goblins (gave ground) and restrain; its Boss beats the Wolves (gave
        # ground), tries to restrain, fails the test and follows up anyway. Round 3: the Opponent's Trolls beat the Hounds (fled) and pursue.
        # Missiles: Mine's Wizard knows Fireball (tried in round 2, not tried in round 3: MARCHED); the Opponent's Shaman knows Fireball
        # and is slain in round 2 (round 3: GONE). Points: the Goblins, the Wizard and the Shaman never fought.
        # Units over 100 pts: the Knights earned nothing; the Trolls held a marker (30 points). Items: Mine's Ruby Ring used once, its
        # Arch-Lightning Rod never; the Opponent's Chalice used once (two lines, one use).
        kd = os.path.join(tmp, "kpi")
        os.makedirs(kd)
        open(os.path.join(kd, "games.csv"), "w").write(GAMES_HEADER + "\n" + "z,C7,1,1,General,h,yes,3,Mine,300-100,0.1,1,0,0,0,1" + "," * 38 + "\n")
        open(os.path.join(kd, "game-C7-1-1.log.jsonl"), "w").write("\n".join([
            act(2, "Shooting", "Mine", "SpellCast", "Wizard", "Goblins", "Wizard attempts Fireball (3+4 +1 Level 1 = 8 vs 8+) on Goblins: cast successfully"),
            act(2, "Shooting", "Opponent", "MissileNotTried", "Shaman", None, "MISSILE NOT TRIED: GONE: Fireball: the wizard is slain"),
            act(2, "Combat", "Mine", "CombatResult", None, None, "Combat result: Mine 4 vs Opponent 1 - Mine wins"),
            act(2, "Combat", "Opponent", "BreakTest", "Goblins", None, "Goblins break test: dice 2+2 = 4, +3 for losing by 3 = 7 is within Ld7: passed - gives ground"),
            act(2, "Combat", "Opponent", "BreakTestMove", "Goblins", None, "Goblins gives ground"),
            act(2, "Combat", "Mine", "RestrainAndReform", "Knights", None, "Knights attempts to restrain and reform (2+2 vs Ld8, no Warband bonus): stays and reforms"),
            act(2, "Combat", "Mine", "CombatResult", None, None, "Combat result: Mine 3 vs Opponent 1 - Mine wins"),
            act(2, "Combat", "Opponent", "BreakTest", "Wolves", None, "Wolves break test: dice 1+2 = 3, +2 for losing by 2 = 5 is within Ld6: passed - gives ground"),
            act(2, "Combat", "Mine", "RestrainAndReform", "Boss", None, "Boss attempts to restrain and reform (6+5 vs Ld8, no Warband bonus): must follow up or pursue"),
            act(2, "Combat", "Mine", "FollowUp", "Boss", "Wolves", "Boss failed its Restraint test and must follow up Wolves"),
            act(3, "Shooting", "Mine", "MissileNotTried", "Wizard", None, "MISSILE NOT TRIED: MARCHED: Fireball: Marched this turn - cannot cast a Magic Missile."),
            act(3, "Shooting", "Opponent", "MissileNotTried", "Shaman", None, "MISSILE NOT TRIED: GONE: Fireball: the wizard is slain"),
            # Missile wizard classes (2026-11-14): the Mine Wizard on foot, the Shaman on a monster.
            act(2, "Shooting", "Mine", "MissileWizard", "Wizard", None, "MISSILE WIZARD: OTHER: Wizard"),
            act(3, "Shooting", "Mine", "MissileWizard", "Wizard", None, "MISSILE WIZARD: OTHER: Wizard"),
            act(2, "Shooting", "Opponent", "MissileWizard", "Shaman", None, "MISSILE WIZARD: FIGHTER: Shaman"),
            act(3, "Shooting", "Opponent", "MissileWizard", "Shaman", None, "MISSILE WIZARD: FIGHTER: Shaman"),
            act(3, "Combat", "Opponent", "CombatResult", None, None, "Combat result: Mine 0 vs Opponent 4 - Opponent wins"),
            act(3, "Combat", "Mine", "BreakTest", "Hounds", None, "Hounds break test: dice 5+5 = 10 vs Ld6: failed - breaks and flees"),
            act(3, "Combat", "Opponent", "Pursuit", "Trolls", None, "Trolls pursues 7\" rolled, 7\" moved"),
            json.dumps({"kind": "objective", "turn": 3, "objective": "StrategicLocation", "side": "Opponent", "unit": "Trolls", "points": 30}),
            # Shooting (Morten 2026-11-11): the Hounds' 2 Wounds on the Trolls (3 models of 3 Wounds, 240 pts) are worth 2 x 240 / 9 = 53.3.
            json.dumps({"kind": "board", "units": [{"n": "Trolls", "s": "Opponent", "id": 9, "lk": {"mc": 3, "w": 3}}]}),
            act(2, "Shooting", "Mine", "Shooting", "Hounds", "Trolls", "Hounds fires Shortbow at Trolls: 5 shots, 2 hits, 2 wound(s)"),
            json.dumps({"kind": "item", "side": "Mine", "bearer": "Wizard", "item": "Ruby Ring of Ruin", "group": "bound missile"}),
            json.dumps({"kind": "item", "side": "Mine", "bearer": "Boss", "item": "Arch-Lightning Rod", "group": "one-use"}),
            json.dumps({"kind": "item", "side": "Opponent", "bearer": "Shaman", "item": "Chalice of Dark Rain", "group": "one-use"}),
            act(2, "Shooting", "Mine", "SpellCast", "Wizard", "Trolls", "Wizard uses Ruby Ring of Ruin to attempt Fireball as a Bound Spell (3+4 +1 Power Level 1 = 8 vs 8+) on Trolls: cast successfully"),
            act(1, "Strategy", "Opponent", "ItemActivated", "Shaman", None, "Shaman uses Chalice of Dark Rain: enemy missile weapon ranges are halved"),
            act(1, "Strategy", "Opponent", "ItemActivated", "Shaman", None, "Shaman uses Chalice of Dark Rain: enemy shooting -1 To Hit"),
            # Movement spells (Morten 2026-11-11): Mine's Steed of Shadows on the Knights stands, they move and charge next turn; the
            # Opponent's on the Wolves stands, they do not move and are charged by Mine first; its try on the Trolls fails.
            act(1, "Strategy", "Opponent", "Computer", None, None, "Objective for Goblins: close in to charge #7 Knights next turn: its best option"),
            act(1, "Movement", "Mine", "SpellCast", "Wizard", "Knights", "Wizard attempts Steed of Shadows (4+4 = 8 vs 8+) on Knights: cast successfully"),
            act(1, "Movement", "Mine", "SpellEffect", "Wizard", "Knights", "Steed of Shadows resolves: Knights: Fly (12) (until your next Start of Turn)"),
            act(1, "Movement", "Mine", "RemainingMove", "Knights", None, "Knights moves 10\""),
            act(1, "Movement", "Opponent", "SpellCast", "Shaman", "Wolves", "Shaman attempts Steed of Shadows (5+4 = 9 vs 8+) on Wolves: cast successfully"),
            act(1, "Movement", "Opponent", "SpellEffect", "Shaman", "Wolves", "Steed of Shadows resolves: Wolves: Fly (12) (until your next Start of Turn)"),
            act(2, "Movement", "Mine", "Charge", "Knights", "Goblins", "Knights declares a charge against Goblins"),
            act(2, "Movement", "Mine", "Charge", "Boss", "Wolves", "Boss declares a charge against Wolves"),
            act(2, "Combat", "Mine", "CombatAttack", "Boss", "Wolves", "Boss attacks Wolves: 2 hits"),
            act(2, "Movement", "Opponent", "SpellCast", "Shaman", "Trolls", "Shaman attempts Steed of Shadows (1+2 = 3 vs 8+) on Trolls: failed to cast"),
            act(3, "Movement", "Opponent", "SpellCast", "Shaman", "Trolls", "Shaman attempts Travel Mystical Pathway (5+5 = 10 vs 10+) on Trolls: cast successfully"),
            act(3, "Movement", "Opponent", "Computer", None, None, "Troll is placed 8\" towards the spot the search found (Travel Mystical Pathway): its best target"),
            # Spells not cast (2026-11-11): Mine's Hex not chosen, the Opponent's movement spell held back by the computer.
            act(2, "Strategy", "Mine", "SpellNotCast", "Wizard", None, "SPELL NOT CAST: NOT CHOSEN: Hex: Curse of Anraheir: 1 target(s) open to it: Trolls"),
            act(3, "Movement", "Opponent", "SpellNotCast", "Shaman", None, "SPELL NOT CAST: HELD BACK: Conveyance: Steed of Shadows: left out of the computer's spell plan"),
            # Random movers (option 11): the Opponent's Doomwheel turned away once (CHANGED) and went straight once (SAME).
            act(2, "Movement", "Opponent", "OpponentRule", "Doomwheel", None, "RANDOM MOVE BY FIGURES: +12.0 VP: x | CHANGED: +5.0 VP v -7.0 VP instead of straight at the nearest enemy (180 degrees)"),
            act(3, "Movement", "Opponent", "OpponentRule", "Doomwheel", None, "RANDOM MOVE BY FIGURES: +0.0 VP: x | SAME: +40.0 VP v +10.0 VP instead of the next best direction (90 degrees)")]) + "\n")
        db = sqlite3.connect(os.path.join(kd, "records.db"))
        db.execute("create table GameRecordUnits (GameRecordId, Side, BoardName, Points, Gone, Fought, TroopType, ArmyBook, IsCharacter, VictoryPointsGivenUp)")
        db.executemany("insert into GameRecordUnits values (1,?,?,?,0,?,?,?,?,0)", [
            (0, "Knights", 200, 1, "Cavalry", "Empire of Man", 0), (0, "Boss", 100, 1, "Character", "Empire of Man", 1),
            (0, "Hounds", 50, 1, "Infantry", "Empire of Man", 0), (0, "Wizard", 50, 0, "Character", "Empire of Man", 1),
            (1, "Goblins", 100, 0, "Infantry", "Orc & Goblin Tribes", 0), (1, "Wolves", 60, 1, "Cavalry", "Orc & Goblin Tribes", 0),
            (1, "Trolls", 240, 1, "Monstrous", "Orc & Goblin Tribes", 0), (1, "Shaman", 100, 0, "Character", "Orc & Goblin Tribes", 1)])
        db.commit()
        db.close()
        kt = "\n".join(kpi_table(kd, "kpi"))
        missing += [x for x in [
            "| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 50% | - | 0% (0 of 2); on the table 50% |",
            "| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (1 of 2) | 50% (1 of 2) |",
            "| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |",
            "| Magic missiles tried each own turn | 50%+ | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |",
            "|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | - | 0% (0 of 2) | 0% (0 of 2) |",
            "|   other wizards | 50%+ | 50% (1 of 2) | - | 50% (1 of 2) |",
            "|     rounds 2+ |  | 50% (1 of 2) | - | 50% (1 of 2) |",
            "| Points that never fought | lower | 12% (50 of 400) | 40% (200 of 500) | 28% (250 of 900) |",
            "|   infantry points that never fought | lower | 0% (0 of 50) | 100% (100 of 100) | 67% (100 of 150) |",
            "| MARCHED: its unit marched | 1.0 (100%) | 0.0 (0%) | 1.0 (33%) |", "| GONE: slain | 0.0 (0%) | 2.0 (100%) | 2.0 (67%) |",
            "| Units over 100 pts that earned no points (no kill, no objective) | lower | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |",
            "| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |",
            "| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 0.5 uses a game |",
            "| Cavalry | - | 100% (1 of 1) | - | 100% (1 of 1) |", "| Monstrous | - | 0% (0 of 1) | - | 0% (0 of 1) |",
            "| Movement spells tried | 1.0 a game | 3.0 a game | 2.0 a game |",
            "| Reason | Hexes | Movement spells | Magic missiles |", "| tried | 0.0 | 4.0 | 1.0 |", "| not cast | 1.0 | 1.0 | 3.0 |",
            "| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) |",
            "| NOT CHOSEN: could have been cast at a target | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) |",
            "| stood (cast and not dispelled) | 100% (1 of 1) | 67% (2 of 3) | 75% (3 of 4) |",
            "| the unit moved after it | 100% (1 of 1) | 50% (1 of 2) | 67% (2 of 3) |",
            "| it charged on its next turn | 100% (1 of 1) | 0% (0 of 2) | 33% (1 of 3) |",
            "| the enemy charged it first | 0% (0 of 1) | 50% (1 of 2) | 33% (1 of 3) |",
            "| it fought by the end of its next turn | 0% (0 of 1) | 50% (1 of 2) | 33% (1 of 3) |",
            "| it moved out of a charge the enemy had planned (not charged first) | 100% (1 of 1) | 0% (0 of 2) | 33% (1 of 3) |",
            "|   infantry | 50% (1 of 2) | - | 50% (1 of 2) |",
            "| FREE: none of these - no target in range or sight, or held its fire | 1.0 (100%) | - | 1.0 (100%) |",
            "| infantry | 1.0 | 2.0 | 0% | 53.3 pts | 53 pts |",
            "| none of these (no charge, no fight, no charge escaped) | 0% (0 of 1) | 50% (1 of 2) | 33% (1 of 3) |",
            "| Empire of Man | 1 | 0% (0 of 2); on the table 50% | 50% (1 of 2) | 12% | 100% (1 of 1) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |"] if x not in kt]
        # The game's own ShotNotTaken rows decide the shooting count when a log has them.
        sk = {}
        _kpi_shooting([{"kind": "action", "type": "ShotNotTaken", "turn": 2, "phase": "Shooting", "side": "Mine", "actor": "Archers",
                        "summary": "SHOT NOT TAKEN: NO LINE OF SIGHT: Archers: Trolls are behind the wood"},
                       {"kind": "action", "type": "Shooting", "turn": 3, "phase": "Shooting", "side": "Mine", "actor": "Archers", "target": "Trolls",
                        "summary": "Archers fires Longbow at Trolls: 10 shots, 4 hits, 1 wound(s)"}], [],
                      {"Archers": {"side": "Mine", "troop": "Infantry", "character": False, "terrain": False, "gone": False, "points": 100},
                       "Trolls": {"side": "Opponent", "troop": "Monstrous", "character": False, "terrain": False, "gone": False, "points": 240}},
                      lambda side, key, v=1: sk.__setitem__((side, key), sk.get((side, key), 0) + v))
        if (sk.get(("Mine", "shoot_turn_of")), sk.get(("Mine", "shoot_turn_yes")), sk.get(("Mine", "shoot_why_no_sight"))) != (2, 1, 1):
            missing.append(f"Shooting: ShotNotTaken rows not counted as the game gives them: {sk}")
        if "an older batch" in kt:
            missing.append("KPIs: a batch with MissileNotTried rows read as an older one")
        # An older log (no MissileNotTried rows): the missiles seen in the log x the side's turns.
        old = [{"kind": "action", "type": "SpellCast", "turn": 1, "phase": "Shooting", "side": "Mine", "actor": "Wizard",
                "summary": "Wizard attempts Fireball (3+4 = 7 vs 8+) on Goblins: failed to cast"},
               {"kind": "action", "type": "Computer", "turn": 0, "phase": "Deployment", "side": "Mine", "actor": None,
                "summary": "Wizard swaps Plague of Rust for Wind Blast: by the figures against this enemy army"},
               {"kind": "action", "type": "Move", "turn": 2, "phase": "Movement", "side": "Mine", "actor": "Wizard", "summary": "Wizard moves 4\""}]
        ok = _kpi_game(old, None)["Mine"]
        if (ok.get("missile_try_yes"), ok.get("missile_try_of")) != (1, 4):
            missing.append(f"KPIs, older log: missiles {ok}")
        # Charges per unit by the wizard it carries (2026-11-11): the Shaman (a missile wizard) joins the Boyz, the Seer (casts only an
        # augment) stays alone; Boyz charge twice (one contact), Seer once, Wolves once; Trolls never.
        def ka(turn, side, typ, actor, summary):
            return {"kind": "action", "turn": turn, "phase": "Movement" if typ == "Charge" else "Deployment", "side": side, "type": typ, "actor": actor, "summary": summary}
        cg = [ka(0, "Opponent", "Deployment", n, f"{n} deploys (Normal)") for n in ("Boyz", "Shaman", "Seer", "Wolves", "Trolls")] + [
            ka(0, "Opponent", "Computer", None, "Shaman joins Boyz, your strongest unit it may join: characters go inside a unit"),
            {"kind": "action", "turn": 1, "phase": "Shooting", "side": "Opponent", "type": "MissileNotTried", "actor": "Shaman",
             "summary": "MISSILE NOT TRIED: NO TARGET: Foot of Gork: no enemy in range"},
            {"kind": "action", "turn": 1, "phase": "Magic", "side": "Opponent", "type": "SpellCast", "actor": "Seer",
             "summary": "Seer attempts Mork's Augment (3+4 = 7 vs 8+): failed to cast"},
            ka(1, "Opponent", "Charge", "Boyz", "Boyz declares a charge against Knights"), ka(1, "Opponent", "Charge", "Boyz", "Boyz charges Knights: made contact, aligned"),
            ka(3, "Opponent", "Charge", "Boyz", "Boyz declares a charge against Archers"), ka(1, "Opponent", "Charge", "Seer", "Seer declares a charge against Archers"),
            ka(2, "Opponent", "Charge", "Wolves", "Wolves declares a charge against Archers")]
        ck = _kpi_game(cg, None)["Opponent"]
        want = {"ch_declared": 4, "ch_contact": 1, "ch_mwiz_units": 1, "ch_mwiz_declared": 2, "ch_mwiz_contact": 1, "ch_wiz_units": 1, "ch_wiz_declared": 1,
                "ch_other_units": 2, "ch_other_declared": 1}
        if any(ck.get(key, 0) != v for key, v in want.items()) or ck.get("ch_other_contact", 0):
            missing.append(f"KPIs, charges by wizard: {ck}")
        if "| Charges declared a game | - | 4.0 | 4.0 |" not in "\n".join(charge_rows({"Mine": {"_games": 0}, "Opponent": dict(ck, _games=1)}, dict(ck, _games=1))) \
                and "| Charges declared a game | 0.0 | 4.0 | 4.0 |" not in "\n".join(charge_rows({"Mine": {"_games": 0}, "Opponent": dict(ck, _games=1)}, dict(ck, _games=1))):
            missing.append("KPIs, charge rows")
        if kpi_report(kd).count("### KPIs: kpi") != 1 or "## KPIs (Morten 2026-11-10)" not in "\n".join(kpi_compare(kd, kd, "x", "y")):
            missing.append("KPIs report / compare")
        # Movement measures (Morten 2026-11-11): Mine set up Knights on #7 Goblins and charged it next turn with the Boss (a joint charge, flank
        # and front), the Opponent's Wolves made the first contact (rear) and were never followed; the Opponent's set-up on #3 was missed.
        mv = os.path.join(tmp, "movement")
        os.makedirs(mv)
        open(os.path.join(mv, "games.csv"), "w").write(GAMES_HEADER + "\n" + "x,M1,1,1,Static,h,yes,6,Mine,1500-1000,0,0,0,0,0,1" + "," * 37 + "\n")

        def ch(i, turn, side, actor, target, tid, summary):
            return json.dumps({"kind": "action", "id": i, "turn": turn, "phase": "Movement", "side": side, "type": "Charge", "actor": actor,
                               "target": target, "target_id": tid, "summary": summary})
        open(os.path.join(mv, "game-M1-1-1.log.jsonl"), "w").write("\n".join([
            json.dumps({"kind": "action", "id": 1, "turn": 1, "phase": "Strategy", "side": "Mine", "type": "Computer", "actor": None, "target": None,
                        "summary": "Objective for Knights: close in to charge #7 Goblins next turn: its best option"}),
            json.dumps({"kind": "action", "id": 2, "turn": 1, "phase": "Strategy", "side": "Opponent", "type": "Computer", "actor": None, "target": None,
                        "summary": "Objective for Trolls: close in to charge #3 Knights next turn: its best option"}),
            ch(3, 1, "Opponent", "Wolves", "Hounds", 4, "Wolves declares a charge against Hounds - in its rear"),
            ch(4, 1, "Opponent", "Wolves", "Hounds", 4, "Wolves charges Hounds: made contact, aligned - in its rear"),
            ch(5, 2, "Mine", "Knights", "Goblins", 7, "Knights declares a charge against Goblins - in its flank"),
            ch(6, 2, "Mine", "Boss", "Goblins", 7, "Boss declares a charge against Goblins - in its front"),
            ch(7, 2, "Mine", "Knights", "Goblins", 7, "Knights charges Goblins: made contact, aligned - in its flank"),
            ch(8, 2, "Mine", "Boss", "Goblins", 7, "Boss charges Goblins: made contact, aligned - in its front - 3\" moved to contact"),
            # Marches that gave up a missile (2026-11-12): Archers marched; Spears' march test failed; Guard's march was turned by MARCH CHECK.
            *[json.dumps({"kind": "action", "id": 9 + n, "turn": t, "phase": "Movement", "side": "Mine", "type": ty, "actor": who, "actor_id": aid,
                          "target": None, "summary": text}) for n, (t, ty, who, aid, text) in enumerate([
                (1, "OpponentRule", "Archers", 21, "MARCH OVER CASTS: -5.0 VP: move to (1.0, 2.0): casts ~5.0 VP given up; picked by the figures"),
                (1, "OpponentRule", "Spears", 22, "MARCH OVER CASTS: -5.0 VP: move to (1.0, 2.0): casts ~5.0 VP given up; picked by the figures"),
                (1, "MarchTest", "Spears", 22, "Spears tests to march with an enemy within 8\": 9+1 = 10 vs Ld7: failed - cannot march this turn"),
                (2, "OpponentRule", "Guard", 23, "MARCH OVER CASTS: -5.0 VP: move to (1.0, 2.0): casts ~5.0 VP given up; picked by the figures"),
                (2, "OpponentRule", "Guard", 23, "MARCH CHECK: +0.0 VP: moves to (1.0, 1.0) and casts instead of marching")])]]) + "\n")
        mt = "\n".join(movement_table(mv, "movement"))
        missing += [x for x in [
            "| Games where this side made the first charge contact | 0% (0 of 1) | 100% (1 of 1) | 50% (1 of 2) |",
            "| Round of a side's first charge contact (sides that made one) | 2.0 | 1.0 | 1.5 |",
            "| Sides that never declared a charge | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |",
            "| Charge contacts made a game | 2.0 | 1.0 | 1.5 |", "| Charge contacts received a game | 1.0 | 2.0 | 1.5 |",
            "| Joint charges a game (2+ units on one target in one turn) | 1.0 | 0.0 | 0.5 |",
            "|   share of charged targets hit by 2+ units | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |",
            "| Lone charges that a friend follows on the same target next turn | - | 0% (0 of 1) | 0% (0 of 1) |",
            "| Set-ups (close in to charge next turn) that charged that target next turn | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |",
            "|   ... with a friend on it too | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |",
            "| Set-ups missed (no charge on that target next turn) | 0% (0 of 1) | 100% (1 of 1) | 50% (1 of 2) |",
            "| Charge contacts in the flank or rear (arc known) | 50% (1 of 2) | 100% (1 of 1) | 67% (2 of 3) |",
            "|   in the rear | 0% (0 of 2) | 100% (1 of 1) | 33% (1 of 3) |",
            "| Declared charges in the flank or rear (arc known) | 50% (1 of 2) | 100% (1 of 1) | 67% (2 of 3) |",
            "| Marches that gave up a magic missile a game (made: a failed march test or a MARCH CHECK turn left out) | 1.0 | 0.0 | 0.5 |",
            "| Who made the first charge contact | first | 1 | 0% | -500 |", "| Who made the first charge contact | second | 1 | 100% | +500 |",
            "| Joint charges in the game | 1 | 1 | 100% | +500 |"] if x not in mt]
        if "## Movement (Morten 2026-11-11)" not in report(mv, mv, "x", "y") or "### Movement: " not in kpi_report(mv):
            missing.append("movement measures in the report / --kpis")
        missing += _first_round_self_test()
        if missing:
            print(arms)
            print(out)
            print("MISSING:\n" + "\n".join(missing))
            return 1
    print("self-test passed")
    return 0


def main(argv):
    if "--self-test" in argv:
        return self_test()
    if "--scorecard" in argv:
        rest = [x for x in argv if not x.startswith("--")]
        if len(rest) != 1:
            print(__doc__)
            return 2
        sys.stdout.write(scorecard_report(rest[0]))
        return 0
    if "--kpis" in argv:
        rest = [x for x in argv if not x.startswith("--")]
        if len(rest) != 1:
            print(__doc__)
            return 2
        sys.stdout.write(kpi_report(rest[0]))
        return 0
    if "--packages" in argv:
        rest = [x for x in argv if not x.startswith("--")]
        if len(rest) != 1:
            print(__doc__)
            return 2
        sys.stdout.write("\n".join(packages_table(rest[0], os.path.basename(rest[0].rstrip("/")))) + "\n")
        return 0
    if "--claims" in argv:
        rest = [x for x in argv if not x.startswith("--")]
        if not rest:
            print(__doc__)
            return 2
        sys.stdout.write("\n".join(job_claims.claims_table(rest, ", ".join(os.path.basename(os.path.normpath(d)) for d in rest))
                                   or ["No game with job picks in these folders."]) + "\n")
        return 0
    if "--plays" in argv:
        rest = [x for x in argv if not x.startswith("--")]
        if len(rest) != 1:
            print(__doc__)
            return 2
        sys.stdout.write(plays_report(rest[0]))
        return 0
    args = [x for x in argv if not x.startswith("--")]
    labels = ["A", "B"]
    if "--labels" in argv:
        i = argv.index("--labels")
        labels = argv[i + 1:i + 3]
        args = [x for x in argv[:i] if not x.startswith("--")]
    if len(args) != 2:
        print(__doc__)
        return 2
    sys.stdout.write(report(args[0], args[1], labels[0], labels[1]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

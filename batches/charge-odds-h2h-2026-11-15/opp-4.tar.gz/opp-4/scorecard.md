# Doctrine scorecard: co-h2h-opp-324c342-p4

### Scorecard: co-h2h-opp-324c342-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 10 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 1 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 3 | 0 | 0 | 0 | 30 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 60 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 3 | 2 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 0 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 5 | 0 | 2 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 98 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 1 | 0 | 0 | 583 |
| L1126 | 4 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 6 | 0 | 0 | 0 | 197 |
| L1314 | 6 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 0 | 4 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 2 | 0 | 0 | 135 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 3 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 4 | 1 | 5 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 4 | 1 | 0 | 0 | 555 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 6 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 3 | 3 | 0 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 5 | 2 | 5 | 0 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 6 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 1.6 | 2.7 | 2.9 | 1.0 | 0.5 | 0.0 | 0.0 | 279.8 |
| **Average** | | | Opponent | 39% | 2.6 | 2.2 | 3.2 | 1.9 | 0.4 | 0.0 | 0.0 | 86.0 |

### KPIs: co-h2h-opp-324c342-p4

Rules off - Mine only: JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 173) | 1% (1 of 175) | 14% (49 of 348) |
| Winner chose to follow up after the loser gave ground |  | 97% (73 of 75); on the table 97% | 98% (59 of 60); on the table 98% | 98% (132 of 135); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 85% (11 of 13); on the table 92% | 100% (10 of 10); on the table 100% | 91% (21 of 23); on the table 96% |
| Winner chose to pursue after the loser fled |  | 70% (14 of 20); on the table 80% | 69% (20 of 29); on the table 79% | 69% (34 of 49); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 91% (98 of 108); on the table 94% | 90% (89 of 99); on the table 93% | 90% (187 of 207); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 28% (76 of 267) | 38% (66 of 172) | 32% (142 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (76 of 179) | 51% (66 of 130) | 46% (142 of 309) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (18 of 36) | 52% (37 of 71) | 51% (55 of 107) |
| Points that never fought | lower | 32% (21604 of 67942) | 32% (22874 of 71984) | 32% (44478 of 139926) |
|   infantry points that never fought | lower | 41% (6242 of 15347) | 53% (7318 of 13804) | 47% (13560 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (160 of 270) | 52% (147 of 280) | 56% (307 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.3 uses a game | 89% (8 of 9); 0.6 uses a game | 94% (29 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.4 uses a game | 35% (7 of 20); 0.3 uses a game | 42% (15 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 87% (13 of 15); 0.4 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30298 of 57750) | 46% (29236 of 63347) | 49% (59534 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (30%) | 0.8 (27%) | 2.4 (29%) |
| MARCHED: its unit marched | 1.1 (21%) | 0.5 (17%) | 1.6 (20%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (8%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.4 (27%) | 0.7 (25%) | 2.2 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (15%) | 0.4 (15%) | 1.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.5 | 2.0 | 3.9 | 0.3 | 2.2 |
| not cast | 2.7 | 2.4 | 2.8 | 8.2 | 1.7 | 20.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (49%) | 0.2 (8%) | 2.4 (29%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (20%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (14%) | 0.5 (19%) | 2.2 (26%) | 0.4 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (5%) | 0.2 (8%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (21%) | 0.4 (15%) | 0.4 (16%) | 1.2 (15%) | 0.1 (3%) | 1.7 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (13%) | 0.1 (2%) | 0.1 (1%) | 0.4 (21%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | 0.1 (4%) | 1.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.1 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 64% (28 of 44) | 56% (9 of 16) | 62% (37 of 60) |
| the unit moved after it | 75% (21 of 28) | 56% (5 of 9) | 70% (26 of 37) |
| it charged on its next turn | 7% (2 of 28) | 11% (1 of 9) | 8% (3 of 37) |
| the enemy charged it first | 21% (6 of 28) | 0% (0 of 9) | 16% (6 of 37) |
| it fought by the end of its next turn | 7% (2 of 28) | 11% (1 of 9) | 8% (3 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (4 of 28) | 11% (1 of 9) | 14% (5 of 37) |
| none of these (no charge, no fight, no charge escaped) | 54% (15 of 28) | 78% (7 of 9) | 59% (22 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (551 of 875) | 51% (265 of 520) | 58% (816 of 1395) |
|   cavalry | 53% (42 of 79) | 69% (73 of 106) | 62% (115 of 185) |
|   character | 40% (40 of 101) | 13% (17 of 127) | 25% (57 of 228) |
|   chariot | 49% (50 of 102) | 50% (9 of 18) | 49% (59 of 120) |
|   infantry | 61% (160 of 264) | 61% (139 of 227) | 61% (299 of 491) |
|   monster | 64% (28 of 44) | 38% (9 of 24) | 54% (37 of 68) |
|   war machine | 81% (231 of 285) | 100% (18 of 18) | 82% (249 of 303) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (27%) | 1.6 (22%) | 4.1 (25%) |
| CHARGED: it charged | 1.2 (14%) | 1.9 (27%) | 3.1 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.4 (5%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.2 (17%) | 2.8 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.6 (8%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.3 (19%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.5 | 80% | 5.5 pts | 30 pts |
| character | 1.8 | 0.7 | 75% | 7.4 pts | 13 pts |
| chariot | 1.7 | 1.3 | 67% | 19.8 pts | 34 pts |
| infantry | 11.9 | 4.9 | 72% | 10.8 pts | 129 pts |
| monster | 1.1 | 0.2 | 85% | 2.9 pts | 3 pts |
| war machine | 6.9 | 6.1 | 63% | 29.8 pts | 206 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 7.1 | 5.8 |
| Charges that made contact a game | 3.4 | 4.8 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.41 declared, 1.18 contact (17 units) | 0.73 declared, 0.60 contact (15 units) | 1.09 declared, 0.91 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.89 declared, 0.56 contact (9 units) | 1.08 declared, 1.00 contact (13 units) | 1.00 declared, 0.82 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.39 contact (249 units) | 0.79 declared, 0.52 contact (293 units) | 0.67 declared, 0.46 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (49 of 81) | 44% (7 of 16) | 33% (2 of 6) | 56% (58 of 103) |
| Character in a unit | 81% (26 of 32) | 77% (10 of 13) | 100% (1 of 1) | 80% (37 of 46) |
| Character on its own | 70% (23 of 33) | 41% (12 of 29) | 30% (23 of 77) | 42% (58 of 139) |
| Chariot | 80% (12 of 15) | 67% (8 of 12) | - | 74% (20 of 27) |
| Infantry | 53% (44 of 83) | 32% (8 of 25) | 33% (2 of 6) | 47% (54 of 114) |
| Monster | 71% (24 of 34) | 64% (9 of 14) | - | 69% (33 of 48) |
| Monstrous | 64% (9 of 14) | 50% (7 of 14) | - | 57% (16 of 28) |
| War Machines | 70% (30 of 43) | 50% (1 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 91% (10 of 11); on the table 91% | 29% (30 of 102) | 11% | 64% (14 of 22) | 100% (6 of 6); 3.8 uses a game | 100% (2 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (7 of 7); on the table 100% | 42% (10 of 24) | 28% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (8 of 8); on the table 100% | - | 63% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (14 of 18); on the table 78% | 50% (9 of 18) | 42% | 61% (38 of 62) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 92% (12 of 13); on the table 92% | 27% (23 of 84) | 36% | 43% (16 of 37) | 100% (9 of 9); 4.8 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 9 | 83% (24 of 29); on the table 90% | 20% (7 of 35) | 32% | 49% (34 of 70) | 100% (7 of 7); 2.0 uses a game | 37% (11 of 30); 2.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 39% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 75% (3 of 4); on the table 100% | 67% (4 of 6) | 18% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 78% (7 of 9); on the table 89% | 17% (1 of 6) | 37% | 93% (13 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (13 of 13); on the table 100% | 36% (15 of 42) | 32% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 89% (8 of 9); on the table 100% | 33% (14 of 42) | 39% | 71% (32 of 45) | 100% (3 of 3); 1.5 uses a game | 0.0 uses a game | 83% (5 of 6); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 100% | 17% (1 of 6) | 16% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (31 of 32); on the table 97% | 34% (19 of 56) | 23% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 93% (25 of 27); on the table 93% | 25% (3 of 12) | 30% | 57% (41 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (12 of 12); on the table 100% | 100% (6 of 6) | 38% | 59% (33 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (co-h2h-opp-324c342-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (51) | 55% (41) | 51% (92) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.64 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.31 | 0.58 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.39 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.64 | 1.25 | 2.89 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.67 | 1.47 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.92 | 5.58 | 10.50 |

### Quality by phase: co-h2h-opp-324c342-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (83 of 162) | 37% (83 of 227) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (156 of 344) | 40% (57 of 142) |
| Strategy | Close-in objectives charged next turn | 12% (18 of 150) | 15% (30 of 204) |
| Strategy | Support requests answered (helper made contact too) | 42% (5 of 12) | 39% (14 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (8 of 13) | 75% (6 of 8) |
| Strategy | Joined characters whose unit fought | 67% (22 of 33) | 39% (13 of 33) |
| Strategy | Lone characters that fought | 79% (71 of 90) | 82% (68 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 279.8 | 86.0 |
| Movement | Fights charged into per game | 3.3 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 111, net +48 | 31 of 122, net +27 |
| Movement | Charges with odds: sweet spot (55-75%) | 23 of 111, net -95 | 21 of 122, net +108 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 111, net +125 | 8 of 122, net +148 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 111, net +47 | 35 of 122, net +70 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (162 of 358) | 46% (137 of 297) |
| Shooting | Points destroyed by shooting units | 71.8 | 33.8 |
| Shooting | War machine shots | 6.4 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (121 of 231) | 6% (1 of 18) |
| Shooting | Points destroyed by war machines | 105.6 | 11.4 |
| Magic | Magic missiles cast | 1.2 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (18 of 44) | 14% (6 of 44) |
| Magic | Wounds caused by magic missiles | 2.4 | 1.7 |
| Magic | Wounds caused by other spells | 1.4 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 64.7 | 46.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.6 / 0.2 | 1.9 / 0.5 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 332.6 | 500.5 |
| Combat | Points run down | 67.1 | 114.2 |
| Combat | Net points per charged fight, damage counted | +28 | +83 |
| Combat | Net per 100 charger points, damage counted | +10.6 | +26.0 |
| Combat | First round won (charged fights) | 71% | 69% |
| Combat | Net points per charged fight | +25 | +83 |
| Combat | Net points per supported fight / lone fight | -6 / +28 | +122 / +75 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 118 | 70 of 141 |
| Game | Points lost | 857.8 | 706.0 |
| Game | VP from objectives | 500.3 | 522.5 |
| Game | Lone holders (player turns) | 1.6 | 2.6 |

- Mine won / drew / lost: 10 / 13 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -206 VP
- The side that went first won 13 of 23 games with a winner
- Points traded per game (both sides' losses): 1564
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-h2h-opp-324c342-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 22.6 | 0.3 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.0 | +6.2 | 0.0 | 31.2 | 1.2 | +10.4 | 0.0 | 39.9 |
| BEST FACING | 0.7 | +46.9 | 0.0 | 47.7 | 0.5 | +21.0 | 0.0 | 33.7 |
| BEST FIRST | 3.5 | +148.0 | 132.4 | 85.8 | 3.6 | +134.3 | 156.0 | 28.7 |
| BEST OVERALL | 0.6 | +43.4 | 0.0 | 23.1 | 0.7 | +43.2 | 0.0 | 39.8 |
| BEST PREY | 0.7 | +52.5 | 10.3 | 12.1 | 0.9 | +33.2 | 14.4 | 32.9 |
| BEST PRIZE | - | - | - | - | 0.0 | +1.4 | 3.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.4 | 0.0 | 27.3 | 0.3 | -0.3 | 0.0 | 16.6 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | -1.1 | 0.0 | 0.0 | 0.4 | +19.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -59.2 | 25.8 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | 0.1 | +0.0 | 0.0 | 11.4 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 133.4 | 15.4 | 0.1 | +0.0 | 9.0 | 3.5 |
| CANNON PLANNED TARGET | 4.7 | +163.0 | 426.2 | 74.4 | 0.5 | +26.5 | 31.9 | 16.2 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 9.7 | 15.0 | 0.0 | -3.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 3.2 | 5.1 | 0.1 | -1.9 | 14.9 | 0.0 |
| CAST JOB | 0.5 | +29.8 | 74.2 | 7.1 | 0.4 | +2.8 | 15.9 | 18.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +24.1 | 18.2 | 8.9 | 0.1 | +2.5 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 23.8 | 0.3 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.9 | 12.1 | 8.1 | 0.1 | -0.1 | 8.2 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 266.2 | 123.4 | 3.7 | +0.0 | 356.4 | 91.9 |
| CHARGE NOW WEIGHED | 0.4 | -47.2 | 3.3 | 33.9 | 0.5 | -23.2 | 20.3 | 13.9 |
| CHARGER SLAIN LOST | - | - | - | - | 0.9 | -24.5 | 64.8 | 45.1 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 4.7 | 0.0 | 0.1 | -0.5 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 4.4 | 0.0 | 0.1 | +0.0 | 18.8 | 6.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 13.9 | 61.6 | 0.6 | +0.0 | 80.9 | 40.0 |
| CONVEYANCE SEARCH | 1.0 | +122.5 | 9.0 | 19.2 | 0.3 | +47.3 | 11.1 | 22.2 |
| COUNTER-CHARGE COVER | 7.8 | +613.6 | 0.0 | 252.0 | 8.1 | +746.8 | 0.0 | 167.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 24.6 | 2.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 5.2 | 3.6 | 0.1 | +7.6 | 3.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.4 | 7.7 | 2.2 | 0.2 | +7.8 | 30.9 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +127.6 | 0.0 | 94.9 | 1.2 | +88.3 | 0.0 | 55.5 |
| FALLBACK BY WORTH | 5.3 | +74.8 | 0.0 | 82.3 | 6.0 | +44.1 | 0.0 | 60.3 |
| FIGHT LIFT | 0.1 | +0.2 | 8.1 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 216.4 | 5.4 | +0.0 | 0.0 | 109.6 |
| FOLLOW UP WEIGHED | 1.3 | +213.6 | 0.0 | 117.4 | 1.1 | +163.2 | 0.0 | 26.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.0 | 0.0 | 23.1 | 0.1 | +4.1 | 0.0 | 12.3 |
| GIVES UP | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -1.2 | 16.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.2 | 0.0 | 3.4 |
| GROUND FLIERS | - | - | - | - | 0.1 | +1.9 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 4.6 | 0.0 | +0.0 | 4.6 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 34.5 | 19.6 | 0.6 | +0.0 | 38.8 | 1.9 |
| HILL BY ITS CHANCE | 0.4 | -42.5 | 0.0 | 12.8 | 0.5 | -50.0 | 0.0 | 16.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.9 | 0.0 | 9.5 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.2 | +8.7 | 0.0 | 4.9 | 0.6 | +39.8 | 0.0 | 12.8 |
| HUNT RESULT | - | - | - | - | 0.2 | +8.1 | 8.1 | 7.4 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +48.0 | 9.2 | 11.8 |
| INVITES THE FIGHT | 1.8 | +30.4 | 104.9 | 35.6 | 1.2 | +20.8 | 37.5 | 28.7 |
| JOINT CHARGE PLAN | 0.1 | +1.9 | 0.0 | 0.0 | 0.1 | +3.7 | 10.1 | 9.1 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.2 | 15.5 | 5.0 |
| KEEP FALLS | 0.1 | +3.7 | 0.0 | 6.6 | 0.1 | +0.5 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +53.3 | 117.8 | 73.0 | 2.0 | +60.8 | 187.4 | 21.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +47.8 | 118.3 | 57.9 | 2.3 | +126.9 | 203.4 | 65.2 |
| KILLS COUNT NEXT TURN | 5.4 | +190.4 | 154.0 | 150.4 | 6.2 | +195.9 | 272.9 | 170.8 |
| LONE CHARACTER SAFE SPOT | 0.4 | +11.1 | 14.9 | 3.8 | 0.1 | +11.7 | 2.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 8.8 | 10.8 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +0.8 | 26.6 | 6.9 | 0.6 | +1.5 | 57.3 | 5.6 |
| LOST CHARGE | 3.0 | -40.4 | 102.2 | 130.7 | 2.0 | -28.8 | 105.7 | 20.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.1 | 0.0 | 0.0 | 0.1 | -4.5 | 0.0 | 6.2 |
| MAKE SURE TOGETHER | 0.6 | +30.6 | 4.7 | 27.1 | 0.5 | +59.7 | 30.3 | 15.9 |
| MANOEUVRE | 0.2 | +5.1 | 0.0 | 3.2 | 0.2 | +8.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +25.1 | 0.0 | 7.1 | 0.3 | +4.1 | 0.0 | 19.8 |
| MARCH ODDS | 0.2 | +14.0 | 11.3 | 4.6 | 0.4 | +29.3 | 7.9 | 0.0 |
| MARCH OVER CASTS | 0.6 | +53.0 | 0.0 | 34.1 | 0.3 | +22.3 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 4.4 | +139.9 | 0.0 | 118.3 | 4.6 | +182.1 | 0.0 | 118.0 |
| MISSILES IN THE MOVE | 3.4 | +134.8 | 0.0 | 96.8 | 2.2 | +34.0 | 0.0 | 63.5 |
| MISSILES NEXT TURN | 4.6 | +95.2 | 0.0 | 139.4 | 2.9 | +27.6 | 0.0 | 74.6 |
| MODEL FACING | 0.1 | +14.1 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 12.3 | 0.0 | 0.2 | +0.0 | 4.8 | 0.0 |
| MOVE AND CAST | 0.3 | +6.0 | 0.0 | 0.0 | 0.2 | +8.3 | 0.0 | 37.4 |
| MOVE SPELL IN RANGE | 0.3 | +7.1 | 0.0 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -27.6 | 20.0 | 0.0 | 0.2 | -5.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 38.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +175.5 | 112.9 | 78.2 | 4.2 | +272.5 | 156.0 | 109.6 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +13.1 | 8.4 | 4.6 | 0.0 | +1.9 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +7.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -14.0 | 27.6 | 1.4 | 0.4 | -23.4 | 58.2 | 6.3 |
| NOT TURNED | 4.9 | +79.6 | 0.0 | 178.0 | 5.6 | +89.3 | 0.0 | 103.1 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.9 | -677.6 | 6.4 | 355.1 | 13.4 | -724.1 | 22.8 | 266.5 |
| OPENS A LANE | 0.2 | +0.3 | 22.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +23.1 | 26.3 | 0.0 | 0.4 | +29.1 | 30.4 | 27.4 |
| OVERRUNS AWAY | 0.8 | +31.1 | 42.8 | 20.6 | 0.8 | +11.6 | 92.9 | 0.0 |
| PATHS CROSS | 2.3 | +159.4 | 0.0 | 52.0 | 2.9 | +209.6 | 0.0 | 73.5 |
| PERIAPT WORTH | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +6.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 16.5 |
| PLAN RESULT | 37.9 | +1468.8 | 1635.1 | 1172.4 | 38.3 | +1268.4 | 1591.2 | 950.7 |
| PURSUES BIG PREY | 0.1 | -8.2 | 0.0 | 0.0 | 0.1 | -11.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.3 | 0.0 | 0.0 | 0.1 | +13.9 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +5.4 | 0.0 | 22.2 | 2.0 | +27.3 | 0.0 | 69.3 |
| RANDOM MOVER NO PROMISE | 0.4 | -22.3 | 5.9 | 4.7 | 0.2 | -6.9 | 8.2 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -5.9 | 0.0 | 8.5 | 0.7 | -15.8 | 0.0 | 9.9 |
| REDIRECT COUNTER | 2.0 | +109.0 | 0.0 | 44.7 | 3.3 | +250.4 | 0.0 | 53.0 |
| REDIRECT WEIGHED | 0.2 | +3.2 | 4.9 | 3.4 | 0.3 | +5.9 | 7.2 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 12.3 |
| RESERVE FALL BACK | 0.5 | +21.0 | 0.0 | 15.2 | 0.5 | +19.8 | 0.0 | 15.3 |
| RESTRAINS TO SHOOT | 0.1 | +5.6 | 0.0 | 5.1 | 0.1 | +7.7 | 0.0 | 5.9 |
| RISK BY ARC | 3.2 | +90.3 | 288.1 | 107.8 | 3.4 | +74.5 | 312.7 | 97.5 |
| SAFER THAN THE JOB | 0.8 | +63.1 | 0.0 | 12.9 | 0.7 | +33.4 | 0.0 | 25.5 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.6 | 0.0 | 0.0 | 0.3 | -17.6 | 0.0 | 4.3 |
| SEARCH SPOT | 2.7 | +125.7 | 0.0 | 41.4 | 2.7 | +128.6 | 0.0 | 18.9 |
| SELF MOVE SPELL | 0.2 | +38.6 | 0.0 | 0.0 | 0.5 | +18.6 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.7 | +44.1 | 4.7 | 27.1 | 1.1 | +89.6 | 44.6 | 23.4 |
| SET-UP ANY TARGET | 0.7 | +93.9 | 9.0 | 9.3 | 0.2 | +35.7 | 0.0 | 11.1 |
| SET-UP MISSED | 0.1 | +12.9 | 0.0 | 9.3 | 0.1 | +16.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.6 | +16.7 | 16.1 | 12.4 | 0.7 | +14.7 | 13.6 | 24.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 127.2 | 7.2 | 0.3 | +0.0 | 27.4 | 6.6 |
| SHOTS IN THE MOVE | 13.9 | +562.6 | 0.0 | 296.2 | 6.6 | +178.3 | 0.0 | 128.3 |
| SPELL CATCH ODDS | 0.1 | -1.5 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +101.0 | 9.0 | 9.3 | 0.2 | +58.4 | 0.0 | 11.1 |
| SPELL WORTH | 1.4 | +25.5 | 86.5 | 97.6 | 2.4 | +45.3 | 52.2 | 52.2 |
| SPELLS IN THE FIGHT | - | - | - | - | 1.1 | -14.5 | 70.6 | 44.4 |
| STABLE ROLE | 10.4 | +0.0 | 362.1 | 255.5 | 10.1 | +0.0 | 386.5 | 149.8 |
| STANDS TO CAST | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.2 | +13.2 | 0.0 | 1.8 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.9 | 9.2 | 2.4 |
| STOPS SHORT OF THE FLANK | 0.4 | +19.3 | 0.0 | 17.4 | 0.5 | +17.5 | 0.0 | 7.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.4 | +0.0 | 0.0 | 15.7 |
| SUPPORT NARROWED | 6.4 | -45.8 | 387.6 | 159.0 | 8.1 | -65.8 | 390.3 | 77.9 |
| SUPPORTS | 4.1 | +62.7 | 219.3 | 67.0 | 5.2 | +67.8 | 147.7 | 32.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.2 | 17.6 | 0.0 | 0.1 | -1.1 | 5.5 | 7.9 |
| SURE REACH TOGETHER | 0.5 | -1.4 | 0.0 | 20.0 | 0.6 | +2.6 | 0.0 | 11.2 |
| THROUGH LINE OF FIRE | 0.3 | +6.9 | 0.0 | 0.0 | 0.2 | +24.7 | 0.0 | 3.2 |
| TURN WORTH | 0.6 | -48.8 | 43.9 | 8.0 | 0.4 | -32.6 | 35.1 | 31.2 |
| TWO OR MORE ARRIVE | 0.3 | +0.9 | 4.7 | 0.0 | 0.4 | +2.3 | 10.1 | 4.5 |
| WAIT AFTER COSTS | 6.8 | -280.0 | 253.7 | 138.2 | 7.2 | -338.6 | 274.4 | 169.4 |
| WALKS TO THE FIGHT | 1.5 | +29.5 | 34.3 | 19.4 | 1.0 | +20.5 | 32.6 | 11.9 |
| WAR ENGINE CHARGES | 0.1 | +18.9 | 13.4 | 13.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 52.6 | 13.8 | 0.1 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 1.5 | +74.2 | 154.7 | 71.0 | 1.1 | +38.9 | 74.1 | 20.7 |
| WHO HITS BACK | 0.3 | +32.1 | 0.0 | 16.8 | 0.2 | +7.9 | 0.0 | 14.8 |
| WHOLE FIGHT | 0.5 | +16.4 | 75.1 | 22.5 | 0.7 | +23.1 | 110.9 | 13.6 |
| WHOLE FIGHT GAIN | 0.3 | +39.1 | 22.6 | 4.6 | 0.8 | +53.2 | 63.6 | 26.5 |
| WIDER SPREAD | - | - | - | - | 4.2 | -6.1 | 409.9 | 97.4 |

### Rule changes: co-h2h-opp-324c342-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1018 | 1018 | 1018 | 28.28 | -50459 | -49.6 |
| BEST FIRST | 256 | 256 | 256 | 7.11 | +10164 | +39.7 |
| SEARCH SPOT | 195 | 195 | 192 | 5.33 | +9157 | +47.7 |
| PATHS CROSS | 188 | 188 | 188 | 5.22 | +13285 | +70.7 |
| COUNTER-CHARGE COVER | 570 | 330 | 172 | 4.78 | +11118 | +64.6 |
| MOVE TO CHARGE | 268 | 268 | 133 | 3.69 | +5883 | +44.2 |
| SUPPORTS | 332 | 332 | 119 | 3.31 | +1639 | +13.8 |
| KILLS COUNT NEXT TURN | 420 | 420 | 108 | 3.00 | +3135 | +29.0 |
| FACES THE THREAT | 104 | 104 | 104 | 2.89 | +7770 | +74.7 |
| FOLLOW UP WEIGHED | 87 | 87 | 87 | 2.42 | +13565 | +155.9 |
| FALLBACK BY WORTH | 408 | 408 | 76 | 2.11 | +4280 | +56.3 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 738 | 487 | 58 | 1.61 | +2289 | +39.5 |
| WAIT AFTER COSTS | 502 | 502 | 57 | 1.58 | +758 | +13.3 |
| CHARGE NOW FIRST | 243 | 243 | 55 | 1.53 | -3171 | -57.6 |
| RANDOM MOVE BY FIGURES | 107 | 107 | 55 | 1.53 | +1179 | +21.4 |
| WALKS TO THE FIGHT | 90 | 90 | 55 | 1.53 | +605 | +11.0 |
| ADVANCE LANE KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| SAFER THAN THE JOB | 53 | 53 | 53 | 1.47 | +3474 | +65.5 |
| BEST OVERALL | 45 | 45 | 45 | 1.25 | +3118 | +69.3 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +2443 | +58.2 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| MAX FOR POSITIONING | 325 | 199 | 42 | 1.17 | +534 | +12.7 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.00 | +1472 | +40.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RISK BY ARC | 236 | 231 | 35 | 0.97 | +1061 | +30.3 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1324 | +39.0 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +2075 | +62.9 |
| REDIRECT COUNTER | 190 | 111 | 33 | 0.92 | +2593 | +78.6 |
| KILLS COUNT | 150 | 147 | 32 | 0.89 | +1351 | +42.2 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +657 | +23.5 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| CANNON PLANNED TARGET | 186 | 186 | 26 | 0.72 | -308 | -11.8 |
| MISSILES IN THE MOVE | 203 | 122 | 26 | 0.72 | +501 | +19.3 |
| SET UP TOGETHER | 64 | 58 | 24 | 0.67 | +2137 | +89.0 |
| MARCH CHECK | 29 | 28 | 23 | 0.64 | +1144 | +49.7 |
| WHOLE FIGHT GAIN | 38 | 35 | 23 | 0.64 | +1333 | +57.9 |
| INVITES THE FIGHT | 106 | 106 | 22 | 0.61 | +210 | +9.6 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +404 | +18.4 |
| KEEPS ITS TARGET | 137 | 136 | 21 | 0.58 | +305 | +14.5 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | +3 | +0.2 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +746 | +41.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| SHOOTS FROM THE BEST SPOT | 45 | 45 | 18 | 0.50 | +473 | +26.3 |
| STUCK PIVOT | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +1138 | +63.2 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +1020 | +56.7 |
| BEST PREY | 58 | 58 | 17 | 0.47 | +905 | +53.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +516 | +30.4 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -37 | -2.6 |
| CAST JOB | 31 | 31 | 13 | 0.36 | +440 | +33.8 |
| MANOEUVRE | 15 | 15 | 12 | 0.33 | +489 | +40.8 |
| MAKE SURE TOGETHER | 39 | 32 | 11 | 0.31 | +1202 | +109.3 |
| SUPPORT NARROWED | 523 | 523 | 11 | 0.31 | -115 | -10.5 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +618 | +61.8 |
| MISSILES NEXT TURN | 270 | 153 | 10 | 0.28 | +23 | +2.3 |
| OPENS UP | 25 | 25 | 10 | 0.28 | +402 | +40.2 |
| WAR ENGINE JOBS | 30 | 30 | 10 | 0.28 | -136 | -13.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 179 | 178 | 9 | 0.25 | +214 | +23.8 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 8 | 0.22 | +426 | +53.3 |
| WEARS DOWN | 94 | 91 | 8 | 0.22 | +503 | +62.8 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +332 | +47.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| RAIDS THE BAGGAGE NEXT TURN | 8 | 8 | 7 | 0.19 | +282 | +40.3 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +480 | +68.5 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -228 | -32.6 |
| BACKUP TARGETS | 79 | 43 | 6 | 0.17 | +33 | +5.5 |
| HUNT IN PAIRS | 28 | 15 | 6 | 0.17 | +344 | +57.3 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +364 | +60.6 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -689 | -114.9 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +474 | +79.1 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +508 | +101.7 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -79 | -15.9 |
| SPELLS IN THE FIGHT | 38 | 36 | 5 | 0.14 | +51 | +10.1 |
| WHOLE FIGHT | 41 | 41 | 5 | 0.14 | +330 | +66.0 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 4 | 0.11 | -198 | -49.6 |
| LONG SHOT | 41 | 41 | 4 | 0.11 | +36 | +8.9 |
| OVERRUNS AWAY | 55 | 54 | 4 | 0.11 | +66 | +16.6 |
| REFUSING RETIRES | 9 | 9 | 4 | 0.11 | -1 | -0.3 |
| WAR ENGINE CHARGES | 5 | 5 | 4 | 0.11 | +522 | +130.5 |
| WIDER SPREAD | 150 | 146 | 4 | 0.11 | +28 | +7.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +209 | +69.5 |
| SURE REACH TOGETHER | 42 | 35 | 3 | 0.08 | +12 | +4.1 |
| EDGE GIVE GROUND | 13 | 13 | 2 | 0.06 | +61 | +30.6 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +43 | +21.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +405 | +202.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -28 | -27.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -128 | -128.3 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -67 | -67.3 |
| CHARGER SLAIN LOST | 31 | 28 | 1 | 0.03 | +5 | +5.0 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -3 | -3.1 |
| DEFENSIVE FLOOR | 6 | 6 | 1 | 0.03 | +4 | +4.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +12.3 |
| HILL BY ITS CHANCE | 34 | 34 | 1 | 0.03 | +10 | +10.0 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +55 | +54.8 |
| REDIRECT BY WHAT IT STOPS | 32 | 32 | 1 | 0.03 | +6 | +6.1 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +9 | +9.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +38 | +38.5 |
| STOPS | 4 | 4 | 1 | 0.03 | +16 | +16.3 |
| TURN WORTH | 36 | 36 | 1 | 0.03 | +36 | +35.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 14 | 13 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 40 | 40 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CHARIOT NO STATIC JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 366 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 30 | 30 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 9 | 9 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 8 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 20 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 26 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 378 | 378 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 31 | not checked | - | - | - | - |
| OPENS A LANE | 12 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2742 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 31 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 4 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 34 | not checked | - | - | - | - |
| SPELL WORTH | 138 | not checked | - | - | - | - |
| STABLE ROLE | 738 | 737 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 25 | 0 | 0.00 | - | - |

### Off best figure: co-h2h-opp-324c342-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.22 | 11.75 | 51.5 |
| CHARGE NOW FIRST | rule | 0.69 | 0.81 | 58.7 |
| FALLBACK | gate | 0.64 | 0.58 | 42.5 |
| TURN GATE | gate | 0.53 | 0.50 | 29.8 |
| PATHS CROSS | rule | 0.17 | 0.17 | 28.4 |
| AFTERMATH BAND | gate | 0.08 | 0.22 | 2.2 |
| SUPPORT NARROWED | rule | 0.14 | 0.17 | 10.5 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 33.1 |
| WAR ENGINE JOBS | rule | 0.28 | - | 13.6 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 7.6 |
| FIGHT ORDER BAND | gate | 0.17 | 0.06 | 2.3 |
| BLOCKED WHEEL | rule | 0.14 | 0.06 | 7.0 |
| CHAFF PASSED | rule | 0.14 | 0.06 | 5.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.03 | 66.1 |
| SUPPORT REQUEST | gate | 0.08 | 0.11 | 90.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.08 | 32.6 |
| PURSUES BIG PREY | rule | 0.11 | 0.06 | 114.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.11 | 8.4 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 51.9 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.06 | 15.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 49.6 |
| NO REASON | gate | - | 0.08 | 3.1 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 16.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 56.9 |
| BEST PRIZE | rule | - | 0.03 | 27.9 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 128.3 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 67.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 3.1 |
| FACES THE THREAT | rule | - | 0.03 | 3.7 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 2.0 |
| MARCH ODDS | rule | - | 0.03 | 4.6 |
| RULE SWITCHED OFF | gate | 0.03 | - | 15.7 |
| SAFER THAN THE JOB | rule | - | 0.03 | 6.9 |
| WHO HITS BACK | rule | - | 0.03 | 4.1 |

### Plans: co-h2h-opp-324c342-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 17% | 423 | 291 | 69% |
| Mine | charge | 3.7 | 58% | 311 | 308 | 99% |
| Mine | close in | 4.2 | 26% | 252 | 141 | 56% |
| Mine | hold | 4.6 | 34% | 269 | 0 | 0% |
| Mine | join | 0.6 | 91% | 10 | 0 | 0% |
| Mine | shoot | 8.3 | 63% | 326 | 728 | 224% |
| Mine | support | 4.3 | 88% | 42 | 0 | 0% |
| Opponent | advance | 12.6 | 19% | 332 | 455 | 137% |
| Opponent | charge | 5.7 | 59% | 547 | 538 | 98% |
| Opponent | close in | 5.6 | 22% | 377 | 106 | 28% |
| Opponent | hold | 4.4 | 34% | 301 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 26 | 0 | 0% |
| Opponent | shoot | 3.2 | 55% | 83 | 177 | 213% |
| Opponent | support | 6.0 | 94% | 52 | 0 | 0% |

### Packages: hunt the guns, co-h2h-opp-324c342-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 11 |
| Opponent | 0.2 | 7 | 0 | 14% | 14% | 0% | 2.0 | 247 | 41 | 14% | 113 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 137 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 268 | 0 | 0% | 71 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 107 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 20% | 20% | 0% | 2.0 | 275 | 58 | 20% | 79 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 85 | 0 | 0% | 112 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |

### Battle groups: co-h2h-opp-324c342-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.8 | 30% | 41% | 9% | 12% | 32% | 14% | 14% | 39% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 52% | 73% | 14% | 40% | 9% | 3% | 19% | 66% | 3% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 20% | 79% | 28% | 31% | 39% | 5% | 10% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 27% | 78% | 28% | 11% | 43% | 0% | 17% | 35% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-h2h-opp-324c342-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 33 (34) | 26 | 7 | 67 | 32% | 2.4 | 29 (14) | 0 (5) | 48 (15) | 35 (20) | 30 (14) |
| Mine | Character | 106 | 43 (106) | 43 | 0 | 41 | 13% | 2.3 | 53 (32) | 46 (51) | 10 (6) | 44 (44) | 49 (45) |
| Mine | Clean-up | 23 | 52 (23) | 20 | 32 | 68 | 26% | 2.5 | 0 (2) | 58 (17) | 57 (4) | 57 (11) | 48 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 55 (4) | 55 | 0 | 100 | 0% | 3.2 | 111 (2) | 0 (2) | - | 76 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 57 (41) | 31 | 25 | 50 | 15% | 2.9 | 51 (27) | 98 (9) | 11 (5) | 78 (25) | 26 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 100 | 25% | 2.3 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 36 (64) | 28 | 8 | 54 | 14% | 2.6 | 43 (13) | 36 (44) | 27 (7) | 38 (39) | 34 (25) |
| Mine | Holder | 31 | 71 (31) | 11 | 60 | 43 | 29% | 3.0 | 25 (6) | 118 (18) | 12 (7) | 91 (21) | 38 (10) |
| Mine | Shooter | 34 | 67 (34) | 29 | 38 | 51 | 3% | 1.5 | 46 (8) | 90 (21) | 5 (5) | 76 (25) | 36 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 60 (56) | 60 | 0 | 44 | 5% | 1.2 | 69 (16) | 52 (30) | 63 (10) | 56 (9) | 60 (47) |
| Mine | Wizard | 17 | 0 (17) | 0 | 0 | 60 | 6% | 2.8 | 0 (3) | 0 (6) | 0 (1) | 0 (3) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 77 | 45 (77) | 23 | 21 | 59 | 35% | 2.6 | 38 (32) | 61 (18) | 38 (27) | 52 (58) | 18 (19) |
| Opponent | Character | 97 | 64 (97) | 64 | 0 | 29 | 20% | 2.5 | 69 (43) | 60 (39) | 76 (7) | 66 (53) | 66 (36) |
| Opponent | Clean-up | 12 | 36 (12) | 12 | 24 | 55 | 33% | 2.5 | 39 (4) | 18 (5) | 68 (3) | 20 (7) | 46 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 51 (54) | 32 | 19 | 47 | 35% | 2.6 | 54 (22) | 36 (24) | 92 (8) | 43 (33) | 63 (21) |
| Opponent | Fragile | 17 | 13 (17) | 13 | 0 | 72 | 24% | 2.3 | 0 (4) | 24 (9) | 0 (4) | 17 (13) | 0 (4) |
| Opponent | Hammer | 65 | 37 (65) | 23 | 14 | 39 | 37% | 3.0 | 5 (20) | 47 (38) | 51 (7) | 42 (41) | 30 (24) |
| Opponent | Holder | 30 | 32 (30) | 9 | 23 | 17 | 50% | 4.0 | 15 (10) | 47 (15) | 0 (5) | 38 (17) | 24 (13) |
| Opponent | Shooter | 34 | 72 (34) | 30 | 41 | 37 | 0% | 1.5 | 49 (10) | 85 (21) | 55 (3) | 79 (19) | 63 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 50% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 63 (6) | 63 | 0 | 80 | 17% | 1.0 | 106 (3) | 0 (3) | - | 106 (3) | 0 (3) |
| Opponent | Wizard | 20 | 30 (20) | 30 | 0 | 30 | 10% | 2.3 | 20 (12) | 0 (3) | 73 (3) | 39 (12) | 0 (6) |

### Charged fights: co-h2h-opp-324c342-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 104 | 116 | 2.5 | 1.1 | 46 | 39 | +8 | 2 of 10 | 6 of 10 | +70 | +1 |
| Mine | Chaos Dwarfs | 4 | 128 | 399 | 3.0 | 1.0 | 133 | 52 | +81 | 6 of 12 | 9 of 12 | - | +81 |
| Mine | Dwarfen Mountain Holds | 3 | 560 | 145 | 3.0 | 1.0 | 48 | 7 | +42 | 4 of 9 | 6 of 9 | - | +42 |
| Mine | Empire of Man | 5 | 676 | 149 | 2.0 | 1.2 | 74 | 164 | -90 | 5 of 10 | 4 of 10 | -514 | -42 |
| Mine | Grand Cathay | 4 | 272 | 429 | 4.5 | 1.2 | 95 | 0 | +95 | 3 of 18 | 16 of 18 | +158 | +83 |
| Mine | High Elf Realms | 4 | 220 | 396 | 3.8 | 1.0 | 106 | 20 | +86 | 4 of 15 | 12 of 15 | - | +86 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 987 | 7.0 | 1.3 | 141 | 0 | +141 | 4 of 7 | 6 of 7 | +105 | +155 |
| Mine | Lizardmen | 1 | 0 | 660 | 4.0 | 1.0 | 165 | 119 | +46 | 2 of 4 | 4 of 4 | - | +46 |
| Mine | Ogre Kingdoms | 2 | 0 | 28 | 3.0 | 1.3 | 9 | 220 | -210 | 4 of 6 | 3 of 6 | -150 | -240 |
| Mine | Skaven | 2 | 335 | 162 | 2.5 | 1.0 | 65 | 22 | +42 | 0 of 5 | 4 of 5 | - | +42 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 215 | 3.0 | 1.0 | 72 | 183 | -111 | 2 of 6 | 2 of 6 | - | -111 |
| Mine | Vampire Counts | 2 | 14 | 147 | 4.0 | 1.1 | 37 | 52 | -15 | 2 of 8 | 6 of 8 | +0 | -17 |
| Mine | Warriors of Chaos | 2 | 0 | 416 | 4.0 | 1.0 | 104 | 98 | +6 | 3 of 8 | 6 of 8 | - | +6 |
| **Mine** | all armies | 36 | 242 | 281 | 3.3 | 1.1 | 86 | 61 | +25 | 41 of 118 | 84 of 118 | -6 | +28 |
| Opponent | Empire of Man | 1 | 575 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 277 | 639 | 3.8 | 1.2 | 168 | 20 | +148 | 9 of 19 | 14 of 18 | +291 | +121 |
| Opponent | Lizardmen | 2 | 0 | 631 | 3.5 | 1.6 | 180 | 32 | +148 | 4 of 7 | 6 of 7 | +52 | +220 |
| Opponent | Orc & Goblin Tribes | 3 | 11 | 267 | 3.3 | 1.2 | 80 | 0 | +80 | 4 of 10 | 9 of 10 | +117 | +71 |
| Opponent | Skaven | 4 | 123 | 69 | 1.8 | 1.0 | 39 | 60 | -21 | 1 of 7 | 5 of 7 | - | -21 |
| Opponent | Tomb Kings of Khemri | 2 | 22 | 1084 | 4.5 | 1.6 | 241 | 0 | +241 | 3 of 9 | 7 of 9 | +200 | +274 |
| Opponent | Vampire Counts | 6 | 25 | 581 | 6.3 | 1.2 | 92 | 35 | +57 | 22 of 38 | 24 of 38 | +108 | +49 |
| Opponent | Warriors of Chaos | 7 | 12 | 373 | 3.4 | 1.0 | 109 | 50 | +58 | 15 of 24 | 14 of 24 | -155 | +68 |
| Opponent | Wood Elf Realms | 6 | 87 | 405 | 4.5 | 1.2 | 90 | 38 | +52 | 12 of 27 | 18 of 27 | +73 | +48 |
| **Opponent** | all armies | 36 | 91 | 451 | 3.9 | 1.2 | 115 | 32 | +83 | 70 of 141 | 97 of 140 | +122 | +75 |

### Effective charges: co-h2h-opp-324c342-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 1 (net +0) | 1 (net -85) | 1 (net -81) | 2 (net -62) | 0 | 5 (net +73) | 0 | 10% (1 of 10) |
| Mine | Chaos Dwarfs | 12 | 2 (net +308) | 0 | 3 (net -207) | 3 (net +0) | 2 (net +169) | 1 (net +482) | 1 | 27% (3 of 11) |
| Mine | Dwarfen Mountain Holds | 9 | 0 | 0 | 3 (net +0) | 2 (net +0) | 0 | 4 (net +94) | 0 | 33% (3 of 9) |
| Mine | Empire of Man | 10 | 2 (net -119) | 1 (net -189) | 2 (net -257) | 2 (net +294) | 0 | 2 (net -152) | 1 | 22% (2 of 9) |
| Mine | Grand Cathay | 18 | 0 | 1 (net +0) | 1 (net +329) | 7 (net +41) | 3 (net +119) | 6 (net +124) | 0 | 6% (1 of 18) |
| Mine | High Elf Realms | 15 | 2 (net +0) | 0 | 2 (net +35) | 2 (net +326) | 4 (net +92) | 4 (net +35) | 1 | 14% (2 of 14) |
| Mine | Kingdom of Bretonnia | 7 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +540) | 2 (net +151) | 2 (net +72) | 0 | 14% (1 of 7) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net +255) | 0 | 2 (net -64) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 2 (net -65) | 1 (net +0) | 0 | 1 (net -301) | 2 | 50% (2 of 4) |
| Mine | Skaven | 5 | 0 | 0 | 0 | 1 (net +112) | 0 | 4 (net +25) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 2 (net -388) | 4 (net +27) | 0 | 0 | 0 | 33% (2 of 6) |
| Mine | Vampire Counts | 8 | 1 (net +0) | 0 | 3 (net -123) | 1 (net -18) | 2 (net +134) | 1 (net +0) | 0 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 8 | 1 (net +107) | 0 | 3 (net -29) | 0 | 0 | 3 (net +9) | 1 | 43% (3 of 7) |
| Opponent | High Elf Realms | 19 | 2 (net +119) | 0 | 3 (net +492) | 3 (net +193) | 1 (net +0) | 4 (net +19) | 6 | 23% (3 of 13) |
| Opponent | Lizardmen | 7 | 1 (net -175) | 0 | 2 (net +295) | 4 (net +156) | 0 | 0 | 0 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 1 (net +77) | 1 (net +0) | 3 (net +136) | 0 | 0 | 5 | 20% (1 of 5) |
| Opponent | Skaven | 7 | 3 (net -94) | 1 (net +0) | 0 | 0 | 0 | 3 (net +46) | 0 | 0% (0 of 7) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +210) | 0 | 0 | 3 (net +119) | 2 (net +145) | 3 (net +437) | 0 | 0% (0 of 9) |
| Opponent | Vampire Counts | 38 | 11 (net +61) | 1 (net +0) | 7 (net +82) | 7 (net +101) | 1 (net +104) | 9 (net +34) | 2 | 19% (7 of 36) |
| Opponent | Warriors of Chaos | 24 | 5 (net +97) | 0 | 4 (net -93) | 0 | 2 (net +265) | 7 (net -14) | 6 | 22% (4 of 18) |
| Opponent | Wood Elf Realms | 27 | 8 (net -39) | 0 | 4 (net +0) | 4 (net +186) | 2 (net +128) | 9 (net +80) | 0 | 15% (4 of 27) |

### Charged fights, damage counted: co-h2h-opp-324c342-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 266 | 295 | +48 | 117 | 86 | +31 | +11.7 |
| Mine | 50-54% | 3 | 176 | 194 | -91 | 18 | 99 | -80 | -45.5 |
| Mine | Effective (55-75%) | 23 | 282 | 239 | -95 | 92 | 164 | -72 | -25.5 |
| Mine | 76-89% | 27 | 242 | 200 | +89 | 135 | 50 | +85 | +35.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 208 | 173 | +47 | 108 | 51 | +57 | +27.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 444 | 100 | +125 | 148 | 27 | +121 | +27.3 |
| Mine | No odds | 7 | 212 | 261 | -114 | 49 | 191 | -142 | -67.0 |
| Mine | All fights | 118 | 261 | 200 | +25 | 110 | 83 | +28 | +10.6 |
| Opponent | Long shot (under 50%) | 31 | 267 | 283 | +27 | 115 | 75 | +40 | +14.9 |
| Opponent | 50-54% | 3 | 147 | 141 | +26 | 31 | 7 | +24 | +16.1 |
| Opponent | Effective (55-75%) | 21 | 269 | 224 | +108 | 158 | 66 | +92 | +34.4 |
| Opponent | 76-89% | 24 | 396 | 201 | +142 | 180 | 42 | +138 | +34.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 274 | 201 | +70 | 113 | 33 | +80 | +29.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 553 | 121 | +148 | 159 | 29 | +131 | +23.6 |
| Opponent | No odds | 19 | 369 | 197 | +75 | 104 | 38 | +66 | +18.0 |
| Opponent | All fights | 141 | 319 | 216 | +83 | 131 | 48 | +83 | +26.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-h2h-opp-324c342-p4 | move | 441 | 100 (23%) | 73 (17%) | 64 (15%) | 277 (63%) |
| co-h2h-opp-324c342-p4 | objective | 354 | 47 (13%) | 38 (11%) | 59 (17%) | 248 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

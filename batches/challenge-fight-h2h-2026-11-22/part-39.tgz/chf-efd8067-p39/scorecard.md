# Doctrine scorecard: chf-efd8067-p39

### Scorecard: chf-efd8067-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 5 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 295 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 473 |
| L0512 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 5.0 | 4.5 | 1.3 | 3.0 | 0.0 | 0.0 | 0.0 | 179.3 |
| **Average** | | | Opponent | 0% | 4.0 | 5.0 | 0.0 | 1.7 | 0.0 | 0.0 | 0.0 | 208.3 |

### KPIs: chf-efd8067-p39

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 9% (1 of 11) | 0% (0 of 11) | 5% (1 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 50% (1 of 2); on the table 50% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | 39% (14 of 36) | 35% (17 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (3 of 9) | 41% (14 of 34) | 40% (17 of 43) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 77% (4633 of 5998) | 79% (4714 of 5998) | 78% (9347 of 11996) |
|   infantry points that never fought | lower | 100% (1424 of 1424) | 78% (930 of 1187) | 90% (2354 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (18 of 23) | 74% (20 of 27) | 76% (38 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 81% (4157 of 5120) | 80% (4377 of 5442) | 81% (8534 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (44%) | 3.7 (50%) | 5.0 (48%) |
| MARCHED: its unit marched | 0.3 (11%) | 3.0 (41%) | 3.3 (32%) |
| IN COMBAT: engaged in combat | 1.0 (33%) | 0.7 (9%) | 1.7 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (11%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 1.0 | 2.7 | 5.7 | 1.0 | 0.0 |
| not cast | 3.3 | 5.0 | 3.3 | 10.3 | 1.0 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (100%) | 1.7 (50%) | 5.0 (48%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (32%) | 0.3 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.0 (0%) | 1.0 (30%) | 1.7 (16%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.3 (3%) | 0.7 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (70%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.7 a game | 1.3 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | 60% (3 of 5) | 62% (5 of 8) |
| the unit moved after it | 0% (0 of 2) | 100% (3 of 3) | 60% (3 of 5) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 3) | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 2) | 67% (2 of 3) | 40% (2 of 5) |
| it fought by the end of its next turn | 0% (0 of 2) | 33% (1 of 3) | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 33% (1 of 3) | 20% (1 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | 0% (0 of 3) | 40% (2 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (54 of 82) | 66% (39 of 59) | 66% (93 of 141) |
|   cavalry | 55% (6 of 11) | - | 55% (6 of 11) |
|   character | 60% (6 of 10) | 100% (6 of 6) | 75% (12 of 16) |
|   chariot | 58% (14 of 24) | 100% (6 of 6) | 67% (20 of 30) |
|   infantry | 33% (4 of 12) | 42% (10 of 24) | 39% (14 of 36) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 96% (24 of 25) | 76% (13 of 17) | 88% (37 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (39%) | 3.0 (45%) | 6.7 (42%) |
| CHARGED: it charged | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.0 (32%) | 1.0 (15%) | 4.0 (25%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (25%) | 1.0 (15%) | 3.3 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (15%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 0.5 pts | 1 pts |
| character | 4.0 | 1.0 | 83% | 6.1 pts | 24 pts |
| chariot | 6.7 | 11.0 | 40% | 24.7 pts | 165 pts |
| infantry | 6.0 | 1.3 | 78% | 7.6 pts | 46 pts |
| monster | 2.7 | 0.7 | 75% | 12.1 pts | 32 pts |
| war machine | 12.3 | 7.3 | 68% | 17.1 pts | 210 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 1.7 | 1.7 |
| Charges that made contact a game | 1.3 | 1.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.60 declared, 0.60 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.10 contact (21 units) | 0.17 declared, 0.11 contact (18 units) | 0.15 declared, 0.10 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (7 of 7) | 100% (1 of 1) | - | 100% (8 of 8) |
| Character on its own | - | 83% (5 of 6) | 75% (3 of 4) | 80% (8 of 10) |
| Chariot | - | 100% (5 of 5) | - | 100% (5 of 5) |
| Infantry | 42% (5 of 12) | 100% (3 of 3) | - | 53% (8 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 68% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 95% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 50% (1 of 2); on the table 50% | 50% (6 of 12) | 82% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 28% (5 of 18) | 90% | 67% (6 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 50% (3 of 6) | 64% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (3) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (13 of 32) | 62% (16 of 26) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 50% (3 of 6) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 38% (3 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 3.0 | 1.7 |
| Movement | Points that never moved of their own | 179.3 | 208.3 |
| Movement | Fights charged into per game | 1.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +232 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (12 of 30) | 62% (16 of 26) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 8.0 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (5 of 24) | 23% (3 of 13) |
| Shooting | Points destroyed by war machines | 111.0 | 31.7 |
| Magic | Magic missiles cast | 0.7 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (2 of 2) | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | 1.3 | 7.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.7 / 0.0 / 0.0 / 0.0 | 1.7 / 0.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 170.0 | 31.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +93 | -13 |
| Combat | Net per 100 charger points, damage counted | +26.4 | -8.1 |
| Combat | First round won (charged fights) | 75% | 50% |
| Combat | Net points per charged fight | +128 | +48 |
| Combat | Net points per supported fight / lone fight | - / +128 | +0 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 1 of 2 |
| Game | Points lost | 122.3 | 364.3 |
| Game | VP from objectives | 636.7 | 670.0 |
| Game | Lone holders (player turns) | 5.0 | 4.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +115 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 487
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: chf-efd8067-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 20.7 | +92.3 | 0.0 | 37.3 | 21.3 | +54.4 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 31.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +12.1 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -116.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 56.0 | 31.7 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +94.5 | 280.0 | 63.3 | 4.3 | +59.0 | 31.7 | 166.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.7 | +31.5 | 63.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 70.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +5.4 | 0.0 | 43.3 | 0.7 | +7.3 | 0.0 | 30.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +41.3 | 0.0 | 84.7 |
| CHALLENGE IN THE FIGHT | 0.3 | +0.5 | 84.7 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +39.5 | 0.0 | 0.0 | 0.3 | +17.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.3 | -379.0 | 0.0 | 37.3 | 14.3 | -408.8 | 0.0 | 281.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 84.7 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +133.2 | 21.7 | 0.0 | 1.0 | +137.6 | 70.3 | 70.3 |
| COVER ONCE | 5.3 | -194.1 | 0.0 | 0.0 | 8.0 | -923.9 | 0.0 | 84.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +68.3 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 55.0 |
| EXACT ROUND | 1.0 | -29.0 | 70.3 | 0.0 | 1.7 | +22.9 | 31.7 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 70.3 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 84.7 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.3 | +53.6 | 0.0 | 0.0 | 22.3 | +198.3 | 0.0 | 366.0 |
| FEATURE BUFFS | 1.3 | +3.2 | 0.0 | 0.0 | 1.3 | +8.5 | 0.0 | 0.0 |
| FIVE ACTION | 99.3 | +5466.0 | 842.0 | 282.0 | 91.0 | +3759.7 | 158.3 | 754.7 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 155.0 |
| FOLLOW UP WEIGHED | 1.0 | +98.0 | 0.0 | 0.0 | 0.3 | +5.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +127.1 | 170.0 | 0.0 | 1.7 | +86.4 | 31.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -13.6 | 31.7 | 0.0 |
| GOAL WALK | 17.7 | +1612.2 | 0.0 | 0.0 | 5.3 | +267.3 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +0.5 | 15.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +20.7 | 0.0 | 0.0 | 3.3 | -16.1 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | +16.8 | 0.0 | 0.0 | 1.3 | -1.2 | 31.7 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 169.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +83.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AND SHOT | 3.0 | -31.3 | 0.0 | 0.0 | 2.0 | -21.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.0 | +0.0 | 0.0 | 112.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 51.0 | +3156.1 | 0.0 | 155.3 | 49.3 | +3528.4 | 0.0 | 222.0 |
| HIS SHOTS BY HIS RUN | 38.3 | +718.6 | 0.0 | 155.3 | 33.3 | +816.3 | 0.0 | 281.3 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 112.0 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.0 | +621.2 | 0.0 | 74.7 | 8.7 | +1090.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -84.5 | 170.0 | 0.0 | 1.3 | -29.3 | 31.7 | 0.0 |
| HUNT IN PAIRS | 1.3 | +123.2 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 3.0 | -57.3 | 0.0 | 0.0 | 15.7 | -269.7 | 0.0 | 15.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +12.0 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +48.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +85.7 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 84.7 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -17.0 | 15.0 | 0.0 | 1.3 | +1.2 | 31.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +3.1 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | -20.0 | 0.0 | 0.0 | 1.7 | +5.2 | 0.0 | 140.7 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +37.8 | 0.0 | 0.0 | 2.3 | +118.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +30.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +5.0 | 0.0 | 0.0 | 1.0 | -20.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +44.3 | 0.0 | 0.0 | 2.0 | +6.8 | 0.0 | 56.0 |
| MEETS IN TIME | 5.3 | +153.3 | 0.0 | 0.0 | 2.3 | +27.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +61.5 | 0.0 | 0.0 | 8.3 | +75.9 | 0.0 | 112.0 |
| MISSILES NEXT TURN | 2.7 | +52.3 | 0.0 | 0.0 | 11.7 | +76.5 | 0.0 | 112.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.7 | +97.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -63.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 0.3 | +3.9 | 0.0 | 0.0 | 2.7 | +63.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.0 | +418.8 | 0.0 | 0.0 | 8.0 | +335.0 | 0.0 | 140.7 |
| NEXT CHARGE BY LIST | 0.3 | +3.9 | 0.0 | 0.0 | 1.3 | +50.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.0 | +13.5 | 70.3 | 0.0 | 1.3 | +20.0 | 31.7 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -54.3 | 170.0 | 0.0 | 1.0 | -17.3 | 0.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -82.4 | 0.0 | 0.0 | 4.3 | -111.3 | 0.0 | 84.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.3 | -10.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -36.6 | 0.0 | 0.0 | 2.0 | -46.0 | 0.0 | 56.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +94.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | -12.9 | 0.0 | 37.3 | 3.3 | -70.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.7 | +8.8 | 70.3 | 0.0 | 1.0 | +7.5 | 31.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +12.3 | 0.0 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | -4.2 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.3 | +494.0 | 252.7 | 244.7 | 41.7 | +173.0 | 0.0 | 408.3 |
| PROMISE BY ITS OWN SUM | 2.0 | -60.8 | 0.0 | 0.0 | 3.3 | -12.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 19.3 | +1805.7 | 70.3 | 112.0 | 16.3 | +1438.5 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +28.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 30.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 15.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +13.5 | 15.0 | 0.0 | 1.7 | -21.2 | 31.7 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | - | - | - | - | 1.0 | -5.6 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -3.6 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -41.3 | 0.0 | 43.3 | 0.7 | -33.9 | 0.0 | 30.0 |
| SEARCH SPOT | 0.3 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -108.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +32.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 1.3 | +3.1 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +29.4 | 21.7 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.7 | +0.0 | 0.0 | 85.0 | 10.3 | +0.0 | 0.0 | 322.3 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +70.5 | 0.0 | 0.0 | 2.0 | +38.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -9.9 | 31.7 | 0.0 |
| SHOT RISK POINTS | 28.7 | +0.0 | 0.0 | 155.3 | 23.0 | -60.1 | 0.0 | 281.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +501.6 | 0.0 | 100.7 | 14.3 | +311.9 | 0.0 | 221.7 |
| SPELL SETS UP CHARGE | 0.3 | +29.4 | 21.7 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +19.0 | 0.0 | 0.0 | 2.0 | +29.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +6.1 | 31.7 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 84.7 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 56.0 | +0.0 | 672.0 | 244.7 | 29.7 | +0.0 | 126.7 | 612.7 |
| STAY WORTH | 26.7 | +77.2 | 560.0 | 132.3 | 25.7 | -67.5 | 126.7 | 555.0 |
| STRIKE BY THE ODDS | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.3 | +54.0 | 0.0 | 0.0 | 2.7 | +44.8 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +54.0 | 0.0 | 0.0 | 2.7 | +44.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +7.1 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | +0.2 | 15.0 | 0.0 | 0.7 | +17.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.3 | +0.0 | 0.0 | 144.0 | 46.0 | +0.0 | 0.0 | 478.0 |
| TIED UP BY THE SUM | 0.3 | +29.4 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 49.7 | +546.2 | 112.0 | 65.0 | 8.7 | +90.3 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +9.1 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -79.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.3 | -12.0 | 0.0 | 0.0 | 0.7 | -26.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +18.4 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.0 | +96.9 | 0.0 | 31.7 | 0.3 | +165.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.0 | +68.3 | 0.0 | 0.0 | 4.7 | +63.5 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 301 | 298 | 95 | 31.67 | +1748 | +18.4 |
| ARMY TABLE | 126 | 126 | 86 | 28.67 | +783 | +9.1 |
| HIS SHOTS BY HIS RUN | 215 | 213 | 61 | 20.33 | +808 | +13.3 |
| HOLDER ASSIGNMENT | 50 | 50 | 48 | 16.00 | +3971 | +82.7 |
| SHOT RISK POINTS | 155 | 155 | 30 | 10.00 | +548 | +18.3 |
| GOAL WALK | 69 | 69 | 26 | 8.67 | +1491 | +57.4 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -581 | -25.3 |
| TIME ON OUR SIDE | 175 | 167 | 23 | 7.67 | +92 | +4.0 |
| DEPLOY BY FIGURES | 45 | 45 | 21 | 7.00 | +420 | +20.0 |
| QUARTER ODDS | 107 | 106 | 17 | 5.67 | +1270 | +74.7 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 12 | 4.00 | +398 | +33.1 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 98 | 98 | 8 | 2.67 | +338 | +42.2 |
| FIVE ACTION | 571 | 568 | 8 | 2.67 | +274 | +34.3 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 56 | 41 | 8 | 2.67 | +86 | +10.8 |
| MARCH CHECK | 10 | 10 | 8 | 2.67 | +102 | +12.7 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 7 | 2.33 | +112 | +16.0 |
| STAY WORTH | 157 | 143 | 7 | 2.33 | +41 | +5.8 |
| PROMISE BY ITS OWN SUM | 16 | 16 | 6 | 2.00 | -221 | -36.8 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 40 | 28 | 4 | 1.33 | +83 | +20.8 |
| FALLS SHORT | 77 | 68 | 4 | 1.33 | +36 | +9.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +310 | +77.4 |
| FOUR ROUNDS | 10 | 10 | 4 | 1.33 | +149 | +37.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +257 | +64.3 |
| SUPPORT ADDS | 12 | 12 | 4 | 1.33 | +121 | +30.3 |
| SUPPORT WORKED OUT | 12 | 12 | 4 | 1.33 | +121 | +30.3 |
| WOUNDS ON THE RANKS | 26 | 26 | 4 | 1.33 | +8 | +1.9 |
| CAST JOB | 11 | 11 | 3 | 1.00 | +4 | +1.2 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +36 | +12.0 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NO CHAFF EDGES | 7 | 7 | 3 | 1.00 | +62 | +20.5 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | -19 | -6.3 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| THE ROW IN ITS ORDER | 20 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 34 | 34 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 2 | 0.67 | +128 | +64.1 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 12 | 12 | 2 | 0.67 | +59 | +29.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -92 | -46.0 |
| MAX FOR POSITIONING | 10 | 10 | 2 | 0.67 | +7 | +3.4 |
| MISSILES IN THE MOVE | 28 | 23 | 2 | 0.67 | +77 | +38.5 |
| MOVE TO CHARGE COMPUTED | 9 | 9 | 2 | 0.67 | +59 | +29.7 |
| NEXT CHARGE BY LIST | 5 | 5 | 2 | 0.67 | +59 | +29.7 |
| ONE OBJECTIVE FORMULA | 17 | 15 | 2 | 0.67 | +224 | +111.9 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +17 | +8.5 |
| RISK BY ARC | 8 | 8 | 2 | 0.67 | +52 | +25.9 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 2 | 2 | 2 | 0.67 | +388 | +194.2 |
| SHOTS IN THE MOVE | 92 | 71 | 2 | 0.67 | +43 | +21.5 |
| SURE REACH TOGETHER | 3 | 3 | 2 | 0.67 | +4 | +1.8 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +124 | +124.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -121 | -121.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +10 | +9.8 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +51 | +51.4 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +144 | +144.3 |
| MANOEUVRE | 13 | 13 | 1 | 0.33 | +23 | +23.4 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| NEARER NOT NEEDED | 54 | 52 | 1 | 0.33 | +31 | +31.2 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +51 | +51.4 |
| OPENS UP IN FULL | 5 | 5 | 1 | 0.33 | +10 | +9.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -17 | -16.7 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +43 | +43.1 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +10 | +9.8 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| THE FIGHT MOVES | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 13 | 12 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 17 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 39 | 39 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 35 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 45 | 44 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 87 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 35 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 12 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 261 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 69 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 257 | 256 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 3.67 | 25.8 |
| ARMY TABLE | rule | 1.33 | 2.33 | 120.5 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 1.33 | 36.8 |
| JOINT CHARGE NOW | rule | - | 0.67 | 54.1 |
| MARCH OF THE TABLE | rule | - | 0.67 | 46.0 |
| PATHS CROSS | rule | 0.33 | 0.33 | 9.5 |
| RULE SWITCHED OFF | gate | - | 0.67 | 19.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 121.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 9.1 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 16.7 |

### Plans: chf-efd8067-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 151 | 68 | 45% |
| Mine | join | 1.7 | 100% | 58 | 0 | 0% |
| Mine | move | 33.7 | 99% | 1869 | 0 | 0% |
| Mine | shoot | 8.7 | 50% | 320 | 426 | 133% |
| Mine | support | 0.3 | 0% | 0 | 0 | - |
| Opponent | charge | 0.3 | 100% | 0 | 32 | - |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 31.0 | 98% | 1142 | 0 | 0% |
| Opponent | shoot | 8.0 | 50% | 422 | 141 | 33% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: chf-efd8067-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 18 (11) | 18 | 0 | 0 | 45% | 3.3 | 29 (6) | 0 (5) | - | 30 (7) | 0 (4) |
| Mine | Clean-up | 7 | 65 (7) | 6 | 59 | 15 | 71% | 3.0 | 9 (4) | 185 (2) | 125 (1) | 37 (5) | 129 (2) |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 5 | 33% | 2.5 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Holder | 2 | 76 (2) | 0 | 76 | 0 | 100% | - | 151 (1) | 0 (1) | - | 76 (2) | - |
| Mine | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 5 | 70 (5) | 70 | 0 | 40 | 0% | 1.0 | 175 (2) | 0 (1) | 0 (2) | - | 70 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 50% | 4.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 5 (9) | 5 | 0 | 0 | 33% | 3.5 | 0 (3) | 10 (5) | 0 (1) | 6 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 34 (2) | 0 | 34 | 57 | 0% | 4.5 | 79 (1) | 0 (1) | - | 79 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 75 (3) | 0 | 75 | 31 | 33% | 3.0 | - | 109 (2) | 0 (1) | 110 (2) | 0 (1) |
| Opponent | Shooter | 3 | 67 (3) | 0 | 67 | 0 | 0% | 1.0 | - | 87 (1) | 58 (2) | 72 (2) | 58 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 13 (5) | 13 | 0 | 59 | 20% | 1.0 | - | - | 13 (5) | - | 13 (5) |
| Opponent | Wizard | 5 | 8 (5) | 8 | 0 | 27 | 0% | 3.0 | 0 (3) | 15 (2) | - | 13 (3) | 0 (2) |

### Charged fights: chf-efd8067-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 255 | 2.0 | 1.0 | 128 | 0 | +128 | 1 of 4 | 3 of 4 | - | +128 |
| Mine | Dwarfen Mountain Holds | 1 | 333 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 111 | 170 | 1.3 | 1.0 | 128 | 0 | +128 | 1 of 4 | 3 of 4 | - | +128 |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 95 | 95 | 1.0 | 1.0 | 95 | 0 | +95 | 0 of 1 | 1 of 1 | - | +95 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | +0 | - |
| **Opponent** | all armies | 3 | 53 | 32 | 0.7 | 1.5 | 48 | 0 | +48 | 1 of 2 | 1 of 2 | +0 | +95 |

### Effective charges: chf-efd8067-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 0 | 1 (net +45) | 0 | 2 (net +232) | 1 | 0% (0 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +95) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 112 | 45 | +45 | 45 | 0 | +45 | +40.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 480 | 232 | +232 | 232 | 0 | +232 | +48.4 |
| Mine | No odds | 1 | 339 | 189 | +0 | 33 | 170 | -137 | -40.4 |
| Mine | All fights | 4 | 353 | 175 | +128 | 136 | 42 | +93 | +26.4 |
| Opponent | 50-54% | 1 | 118 | 339 | +0 | 0 | 39 | -39 | -33.3 |
| Opponent | 76-89% | 1 | 205 | 95 | +95 | 170 | 157 | +13 | +6.4 |
| Opponent | All fights | 2 | 162 | 217 | +48 | 85 | 98 | -13 | -8.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p39 | move | 6 | 2 (33%) | 1 (17%) | 0 (0%) | 4 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

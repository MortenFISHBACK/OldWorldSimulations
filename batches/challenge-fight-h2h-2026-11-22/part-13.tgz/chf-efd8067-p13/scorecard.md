# Doctrine scorecard: chf-efd8067-p13

### Scorecard: chf-efd8067-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 754 |
| L0122 | 2 | 1 | Mine | - | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 200 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 515 |
| **Average** | | | Mine | 0% | 2.0 | - | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 0.7 | 2.0 | 0.3 | 0.0 | 0.0 | 447.0 |

### KPIs: chf-efd8067-p13

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 62% (10 of 16) | 36% (10 of 28) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 33% | 0% (0 of 1); on the table 0% | 25% (1 of 4); on the table 25% |
| Magic missiles tried each own turn | 50%+ | 39% (35 of 90) | - | 39% (35 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (35 of 86) | - | 41% (35 of 86) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | - | 67% (4 of 6) |
| Points that never fought | lower | 78% (4472 of 5699) | 76% (4569 of 6000) | 77% (9041 of 11699) |
|   infantry points that never fought | lower | 86% (1917 of 2239) | 92% (1951 of 2111) | 89% (3868 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (10 of 16) | 80% (20 of 25) | 73% (30 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 0.0 uses a game | 100% (4 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2382 of 3916) | 81% (3548 of 4382) | 71% (5930 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.0 (71%) | - | 13.0 (71%) |
| MARCHED: its unit marched | 2.3 (13%) | - | 2.3 (13%) |
| IN COMBAT: engaged in combat | 1.3 (7%) | - | 1.3 (7%) |
| STUPIDITY: Stupidity | 1.7 (9%) | - | 1.7 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.7 | 6.0 | 11.7 | 0.3 | 1.3 |
| not cast | 2.0 | 3.3 | 4.0 | 18.3 | 1.7 | 26.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) | 13.0 (71%) | 1.7 (100%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (13%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (10%) | 0.7 (17%) | 1.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (17%) | 0.0 (0%) | 0.7 (17%) | 1.7 (9%) | 0.0 (0%) | 1.0 (4%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 1.0 (30%) | 2.7 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.7 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.3 a game | 0.0 a game | 3.7 a game |
| stood (cast and not dispelled) | 73% (16 of 22) | - | 73% (16 of 22) |
| the unit moved after it | 56% (9 of 16) | - | 56% (9 of 16) |
| it charged on its next turn | 0% (0 of 16) | - | 0% (0 of 16) |
| the enemy charged it first | 12% (2 of 16) | - | 12% (2 of 16) |
| it fought by the end of its next turn | 12% (2 of 16) | - | 12% (2 of 16) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | - | 0% (0 of 16) |
| none of these (no charge, no fight, no charge escaped) | 88% (14 of 16) | - | 88% (14 of 16) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 46% (11 of 24) | 60% (109 of 181) | 59% (120 of 205) |
|   cavalry | - | 59% (20 of 34) | 59% (20 of 34) |
|   character | - | 50% (9 of 18) | 50% (9 of 18) |
|   infantry | 46% (11 of 24) | 56% (31 of 55) | 53% (42 of 79) |
|   monster | - | 50% (5 of 10) | 50% (5 of 10) |
|   war machine | - | 69% (44 of 64) | 69% (44 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (62%) | 5.0 (21%) | 7.7 (27%) |
| CHARGED: it charged | 0.3 (8%) | 2.7 (11%) | 3.0 (11%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO TARGET IN RANGE | 1.0 (23%) | 10.3 (43%) | 11.3 (40%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (8%) | 1.7 (7%) | 2.0 (7%) |
| OTHER BAR | 0.0 (0%) | 4.0 (17%) | 4.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.7 | 3.7 | 75% | 2.8 pts | 30 pts |
| character | 3.0 | 3.3 | 44% | 8.5 pts | 25 pts |
| infantry | 21.3 | 12.3 | 59% | 5.7 pts | 122 pts |
| monster | 1.7 | 0.3 | 80% | 4.2 pts | 7 pts |
| war machine | 14.7 | 16.0 | 50% | 11.8 pts | 172 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 4.3 | 2.7 |
| Charges that made contact a game | 0.0 | 3.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.00 contact (20 units) | 0.48 declared, 0.41 contact (27 units) | 0.34 declared, 0.23 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 83% (5 of 6) | 67% (4 of 6) | - | 75% (9 of 12) |
| Character on its own | - | - | 100% (2 of 2) | 100% (2 of 2) |
| Infantry | 43% (3 of 7) | 71% (5 of 7) | - | 57% (8 of 14) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 33% (1 of 3); on the table 33% | 39% (35 of 90) | 78% | 62% (10 of 16) | 100% (4 of 4); 4.3 uses a game | 100% (2 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 0% (0 of 1); on the table 0% | - | 88% | 80% (16 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 53% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | - | 20% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 3) | 8% (1 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (2 of 14) | 46% (37 of 80) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 18% (3 of 17) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 100% (1 of 1) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 66.7 | 447.0 |
| Movement | Fights charged into per game | 0.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 2 of 5, net -438 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 5, net +25 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 5, net +85 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 22.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (8 of 11) | 35% (23 of 66) |
| Shooting | Points destroyed by shooting units | 0.0 | 91.0 |
| Shooting | War machine shots | - | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 61% (27 of 44) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 7.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 22% (5 of 23) | - |
| Magic | Wounds caused by magic missiles | 12.0 | - |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 73.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 1.0 / 0.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 370.3 | 56.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | -80 |
| Combat | Net per 100 charger points, damage counted | - | -33.0 |
| Combat | First round won (charged fights) | - | 43% |
| Combat | Net points per charged fight | - | -113 |
| Combat | Net points per supported fight / lone fight | - / - | -172 / -69 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 7 |
| Game | Points lost | 157.7 | 543.3 |
| Game | VP from objectives | 720.0 | 420.0 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +675 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 701
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +164.1 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.0 | +307.3 | 0.0 | 176.3 | 8.0 | +67.9 | 0.0 | 118.0 |
| ASSAILMENT BY POINTS | 0.3 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 2.7 | +352.0 | 0.0 | 18.3 |
| BACKUP TARGETS | 1.7 | +3.5 | 0.0 | 45.7 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 1.3 | +0.0 | 52.0 | 35.0 |
| CANNON PLANNED TARGET | - | - | - | - | 13.3 | +36.4 | 160.0 | 40.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 6.3 | +413.5 | 380.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +22.6 | 0.0 | 28.3 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.3 | +0.0 | 0.0 | 35.0 |
| CHALLENGE BY POINTS | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.7 | -187.3 | 0.0 | 287.3 |
| CHARACTER GUNS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 2.0 | -236.6 | 0.0 | 454.0 |
| CHARGE LOSSES | 20.3 | -545.5 | 0.0 | 69.3 | 14.3 | -237.9 | 0.0 | 235.0 |
| CHARGE NOW FIRST | - | - | - | - | 2.3 | +0.0 | 28.3 | 208.7 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 222.0 | 4.3 | +0.0 | 0.0 | 48.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 5.3 | +250.8 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 4.3 | -229.8 | 0.0 | 45.7 | 7.3 | -206.6 | 0.0 | 73.3 |
| DEFENSIVE FLOOR | 0.7 | -4.5 | 18.3 | 18.3 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +65.2 | 0.0 | 0.0 | 11.7 | -180.5 | 0.0 | 24.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -493.3 | 0.0 | 287.3 |
| EXACT ROUND | 0.7 | -2.7 | 18.3 | 0.0 | 3.0 | +27.2 | 113.3 | 130.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.6 | 56.7 | 454.0 |
| FALLS SHORT | 16.3 | +305.2 | 0.0 | 167.3 | 10.0 | +126.9 | 0.0 | 84.7 |
| FEATURE BUFFS | 14.7 | +382.0 | 0.0 | 121.7 | 1.3 | +28.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.8 | 18.3 | 0.0 | 1.3 | -10.1 | 0.0 | 417.3 |
| FIVE ACTION | 75.0 | +7264.8 | 658.3 | 572.3 | 121.7 | +3775.9 | 861.0 | 985.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 141.7 | 1.3 | +0.0 | 0.0 | 70.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +13.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +11.6 | 18.3 | 18.3 | 4.3 | +89.7 | 113.3 | 454.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -5.7 | 0.0 | 0.0 | 0.3 | -8.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.3 | -12.7 | 0.0 | 110.0 |
| GIVES UP | - | - | - | - | 0.7 | -2.0 | 0.0 | 208.7 |
| GIVES UP ITS SCREEN | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 17.0 | +2314.5 | 0.0 | 69.3 | 0.7 | +29.4 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.3 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 2.7 | +22.1 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | +0.1 | 0.0 | 0.0 | 1.3 | -0.8 | 56.7 | 287.3 |
| HARD STAY DROPPED | - | - | - | - | 9.3 | +0.0 | 0.0 | 20.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 2.3 | +0.0 | 56.7 | 324.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 34.7 | 7.3 | +0.0 | 0.0 | 216.7 |
| HIS CHARGE LIST | 15.0 | +0.0 | 0.0 | 226.7 | 2.7 | +0.0 | 0.0 | 48.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 176.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -39.7 | 0.0 | 56.7 | 2.7 | -70.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 40.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 176.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 40.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 57.7 | +1603.0 | 0.0 | 519.3 | 46.7 | +1602.7 | 0.0 | 223.0 |
| HIS SHOTS BY HIS RUN | 47.0 | +866.2 | 0.0 | 525.7 | 29.3 | +318.7 | 0.0 | 275.0 |
| HIS TURN DENIED | 0.3 | +3.7 | 0.0 | 0.0 | 0.7 | +7.7 | 0.0 | 162.0 |
| HOLD ODDS | 39.7 | +0.0 | 0.0 | 243.3 | 10.0 | +0.0 | 0.0 | 18.3 |
| HOLDER ASSIGNMENT | 12.0 | +1580.2 | 0.0 | 0.0 | 9.3 | +905.9 | 0.0 | 18.3 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -1.7 | 18.3 | 0.0 | 2.3 | -115.1 | 28.3 | 417.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +58.5 | 0.0 | 0.0 |
| IDLE COST | 12.0 | -134.9 | 0.0 | 145.3 | 2.7 | -41.6 | 0.0 | 24.0 |
| JOINT CHARGE NOW | - | - | - | - | 3.0 | +527.0 | 113.3 | 310.3 |
| KEEP FALLS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +20.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 65.0 | 56.7 | 1.3 | +0.0 | 0.0 | 130.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +3.4 | 18.3 | 18.3 | 1.0 | +2.0 | 28.3 | 36.7 |
| LOST AFTER ESCAPE | 0.7 | -0.3 | 0.0 | 18.3 | 2.3 | +0.9 | 85.0 | 417.3 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | -16.9 | 0.0 | 0.0 | 2.0 | -20.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -73.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +62.9 | 0.0 | 141.7 | 1.3 | +6.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +101.8 | 0.0 | 0.0 | 7.7 | +79.1 | 0.0 | 24.0 |
| MISSILES IN THE MOVE | 8.3 | +276.2 | 0.0 | 54.0 | - | - | - | - |
| MISSILES NEXT TURN | 9.0 | +255.0 | 0.0 | 27.0 | - | - | - | - |
| MISSILES ON ONE TARGET | 3.0 | -100.5 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 3.3 | +511.5 | 0.0 | 40.0 |
| MOVE ORDER | - | - | - | - | 1.0 | +0.0 | 18.3 | 24.0 |
| MOVE SPELL OUT OF RANGE | 2.3 | -55.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.7 | +45.4 | 0.0 | 0.0 | 7.0 | +473.8 | 0.0 | 128.3 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.0 | +159.7 | 0.0 | 0.0 | 7.7 | +316.9 | 0.0 | 60.7 |
| NEXT CHARGE BY LIST | 1.0 | +21.0 | 0.0 | 0.0 | 4.0 | +236.7 | 0.0 | 88.3 |
| NO CHAFF EDGES | 1.7 | +29.3 | 36.7 | 0.0 | 3.7 | +46.7 | 56.7 | 273.7 |
| NO DOUBLE ROUNDS | 0.7 | -4.1 | 18.3 | 18.3 | 3.7 | -107.9 | 56.7 | 454.0 |
| NO LATE CUT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -151.6 | 0.0 | 28.3 | 4.7 | -86.3 | 0.0 | 95.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -22.5 | 0.0 | 102.3 | 4.7 | -41.8 | 0.0 | 55.0 |
| ONE JOINT FIGURE | - | - | - | - | 3.0 | +176.4 | 85.0 | 310.3 |
| ONE OBJECTIVE FORMULA | 7.3 | +81.6 | 0.0 | 0.0 | 2.0 | +31.7 | 0.0 | 18.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | +62.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 1.7 | +5.7 | 28.3 | 273.7 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +2.7 | 0.0 | 143.7 |
| PIVOT GUARDS FLANK | 0.3 | -13.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 33.3 | +323.4 | 100.0 | 288.0 | 54.3 | +619.8 | 225.0 | 790.7 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +3.4 | 28.3 | 0.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 18.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 2.7 | -14.5 | 0.0 | 0.0 | 11.3 | -261.4 | 0.0 | 76.7 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -5.5 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 18.3 |
| PROMISE READS THE TABLE | - | - | - | - | 3.0 | -112.9 | 0.0 | 40.0 |
| PROMISE SHOT AWAY | 0.7 | -2.9 | 70.0 | 0.0 | 1.3 | -6.4 | 0.0 | 0.0 |
| QUARTER ODDS | 6.0 | +1053.0 | 0.0 | 0.0 | 14.0 | +831.5 | 0.0 | 40.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 6.0 | +313.1 | 0.0 | 103.3 | 2.7 | +29.5 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 85.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +1.6 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -2.9 | 0.0 | 0.0 | 1.3 | -20.5 | 0.0 | 40.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 208.7 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +11.4 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 2.0 | +68.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +2.9 | 18.3 | 18.3 | 3.7 | -35.6 | 56.7 | 454.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -5.2 | 0.0 | 417.3 |
| RUN DOWN | 0.3 | -0.5 | 0.0 | 0.0 | 3.3 | -17.7 | 85.0 | 417.3 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUTS HUNT GUNS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +10.6 | 0.0 | 0.0 | 0.3 | -14.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +3.8 | 28.3 | 0.0 |
| SET CREDITED ONCE | 0.3 | -0.5 | 0.0 | 0.0 | 2.0 | -251.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | -11.8 | 0.0 | 0.0 | 2.7 | +237.7 | 0.0 | 24.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +4.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 0.0 | 25.3 | +0.0 | 0.0 | 75.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +28.9 | 130.0 | 0.0 | 3.7 | +24.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -9.2 | 0.0 | 0.0 | 0.7 | -19.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 37.3 | -546.6 | 0.0 | 412.3 | 38.0 | +319.4 | 0.0 | 363.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.3 | +32.5 | 0.0 | 0.0 | 41.0 | +534.2 | 0.0 | 190.7 |
| SPELL OFF EDGE | 0.3 | +16.9 | 24.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -45.6 | 0.0 | 130.0 |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 170.0 | 3.0 | +0.0 | 0.0 | 55.0 |
| STAND AND SHOOT | 0.7 | -0.9 | 18.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 36.7 |
| STANDS STILL | 21.3 | +0.0 | 640.0 | 65.0 | 89.0 | +0.0 | 747.7 | 245.0 |
| STAY WORTH | 5.3 | +50.7 | 110.0 | 0.0 | 70.0 | +234.1 | 570.3 | 265.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +0.9 | 0.0 | 36.7 |
| STRONG ENOUGH TO HOLD | 0.7 | -1.8 | 0.0 | 0.0 | 1.0 | -31.1 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.2 | 0.0 | 35.0 |
| SUPPORT ADDS | 5.3 | +181.6 | 0.0 | 141.7 | 0.3 | +7.5 | 0.0 | 18.3 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 5.3 | +181.6 | 0.0 | 141.7 | 0.3 | +7.5 | 0.0 | 18.3 |
| SURE REACH TOGETHER | - | - | - | - | 3.0 | +7.5 | 0.0 | 35.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 38.3 |
| THE FIGHT MOVES | 1.0 | +0.3 | 18.3 | 18.3 | 0.3 | +0.1 | 28.3 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.3 | -103.5 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 56.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 56.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.7 | +0.0 | 0.0 | 277.0 | 52.3 | +0.0 | 0.0 | 265.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 16.0 | +285.8 | 130.0 | 55.0 | 43.7 | +367.1 | 0.0 | 150.0 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 28.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +37.2 | 0.0 | 287.3 |
| WHO FIGHTS | 0.7 | -1.7 | 18.3 | 18.3 | 0.7 | +60.5 | 0.0 | 130.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +26.0 | 0.0 | 143.7 |
| WHOLE FIGHT DANGER | 0.7 | -8.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.8 | 28.3 | 0.0 |
| WHOLE FIGHT REACTION | 3.0 | +372.8 | 162.0 | 85.0 | 0.3 | +15.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 8.3 | +725.9 | 0.0 | 0.0 | 2.7 | +26.4 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 313 | 294 | 97 | 32.33 | +1112 | +11.5 |
| ARMY TABLE | 84 | 84 | 65 | 21.67 | +989 | +15.2 |
| HOLDER ASSIGNMENT | 64 | 64 | 63 | 21.00 | +3082 | +48.9 |
| HIS SHOTS BY HIS RUN | 229 | 215 | 61 | 20.33 | +603 | +9.9 |
| SHOT RISK POINTS | 226 | 206 | 43 | 14.33 | +620 | +14.4 |
| FIVE ACTION | 590 | 568 | 36 | 12.00 | +1564 | +43.5 |
| HARD STAY DROPPED | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 56 | 56 | 27 | 9.00 | +398 | +14.7 |
| TIME ON OUR SIDE | 179 | 152 | 27 | 9.00 | +237 | +8.8 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -714 | -28.6 |
| GOAL WALK | 53 | 52 | 24 | 8.00 | +2295 | +95.6 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 33 | 33 | 17 | 5.67 | +461 | +27.1 |
| MEETS IN TIME | 35 | 35 | 15 | 5.00 | +168 | +11.2 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 15 | 5.00 | -828 | -55.2 |
| CASTING BLOCK | 19 | 19 | 14 | 4.67 | +560 | +40.0 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 40 | 40 | 12 | 4.00 | -2 | -0.2 |
| NO CHAFF EDGES | 16 | 16 | 12 | 4.00 | +212 | +17.7 |
| MOVE TO CHARGE COMPUTED | 26 | 21 | 11 | 3.67 | +163 | +14.8 |
| CHARGE LOSSES | 104 | 97 | 10 | 3.33 | +449 | +44.9 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| MODEL FACING | 10 | 10 | 10 | 3.33 | +1534 | +153.4 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +1581 | +175.6 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 60 | 60 | 9 | 3.00 | +383 | +42.5 |
| FALLS SHORT | 79 | 54 | 8 | 2.67 | +114 | +14.3 |
| REDIRECT COUNTER | 26 | 22 | 8 | 2.67 | +220 | +27.5 |
| FOUR ROUNDS | 16 | 16 | 7 | 2.33 | +130 | +18.5 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 7 | 2.33 | +10 | +1.4 |
| COVER ONCE | 35 | 20 | 6 | 2.00 | +64 | +10.6 |
| NEXT CHARGE BY LIST | 15 | 14 | 6 | 2.00 | +99 | +16.5 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -28 | -4.6 |
| RESERVE MOVE SPELL | 6 | 6 | 6 | 2.00 | +204 | +34.0 |
| RISK BY ARC | 13 | 13 | 6 | 2.00 | +41 | +6.8 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 17 | 17 | 6 | 2.00 | +72 | +11.9 |
| SUPPORT WORKED OUT | 17 | 17 | 6 | 2.00 | +72 | +11.9 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SCOUT BY DROPS | 6 | 6 | 5 | 1.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| BACKS UP THE FIGHT | 8 | 6 | 4 | 1.33 | +89 | +22.3 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 4 | 1.33 | -50 | -12.5 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 44 | 23 | 4 | 1.33 | +6 | +1.6 |
| MAX FOR POSITIONING | 16 | 13 | 4 | 1.33 | +10 | +2.5 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +95 | +23.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +34 | +8.6 |
| SET UP BY THE SET | 13 | 10 | 4 | 1.33 | +392 | +98.1 |
| SHOTS AFTER THE MOVES | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 133 | 108 | 4 | 1.33 | +12 | +3.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 11 | 11 | 3 | 1.00 | +18 | +5.9 |
| FEATURE BUFFS | 48 | 47 | 3 | 1.00 | +33 | +10.9 |
| GUN MASK | 8 | 8 | 3 | 1.00 | +25 | +8.3 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 10 | 8 | 3 | 1.00 | -16 | -5.5 |
| PROMISE READS THE TABLE | 9 | 9 | 3 | 1.00 | -90 | -29.9 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 226 | 208 | 3 | 1.00 | +2 | +0.6 |
| WHOLE FIGHT REACTION | 10 | 10 | 3 | 1.00 | +29 | +9.5 |
| CLEAR LANE AHEAD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +62 | +30.9 |
| MAIN BODY KEEPS ITS BAND | 2 | 2 | 2 | 0.67 | +97 | +48.5 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +41 | +20.4 |
| NEARER NOT NEEDED | 32 | 31 | 2 | 0.67 | +112 | +56.2 |
| ONE JOINT FIGURE | 9 | 9 | 2 | 0.67 | +111 | +55.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +186 | +93.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +24 | +12.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +32 | +15.9 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +3 | +1.3 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -92 | -45.9 |
| SURE REACH TOGETHER | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| WHOLE FIGHT DANGER | 2 | 2 | 2 | 0.67 | +4 | +2.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +492 | +492.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.1 |
| BACKUP TARGETS | 5 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +39 | +39.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| LONG SHOT | 5 | 5 | 1 | 0.33 | +5 | +4.8 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| MISSILES IN THE MOVE | 25 | 17 | 1 | 0.33 | +34 | +33.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| OPENS UP IN FULL | 5 | 5 | 1 | 0.33 | +2 | +1.5 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +2 | +2.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -40 | -39.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +10 | +10.1 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | +409 | +409.1 |
| RUN DOWN | 11 | 11 | 1 | 0.33 | +5 | +4.8 |
| SCOUT WAITS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| THE ROW IN ITS ORDER | 9 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +71 | +70.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 5 | 4 | 0 | 0.00 | - | - |
| CHALLENGE IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 46 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 46 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 53 | 49 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 149 | 147 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 16 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 9 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 13 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 14 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 28 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 88 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 32 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 331 | 319 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 4 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 9 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.00 | 27.4 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 4.67 | 55.2 |
| ARMY TABLE | rule | 2.67 | 1.33 | 28.4 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 47.4 |
| PROMISE SHOT AWAY | rule | 0.67 | 1.33 | 4.6 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 0.8 |
| CHARGE NOW FIRST | rule | - | 1.00 | 16.6 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 5.5 |
| JOINT CHARGE NOW | rule | - | 0.67 | 2.3 |
| NO REASON | gate | - | 0.67 | 29.7 |
| PROMISE READS THE TABLE | rule | - | 0.67 | 55.9 |
| SUPPORT NARROWED | rule | - | 0.67 | 45.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 39.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 52.0 |

### Plans: chf-efd8067-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 9 | 18 | 212% |
| Mine | move | 28.7 | 94% | 2732 | 0 | 0% |
| Mine | shoot | 4.0 | 83% | 404 | 305 | 75% |
| Opponent | charge | 3.7 | 36% | 508 | 89 | 17% |
| Opponent | move | 30.0 | 94% | 811 | 0 | 0% |
| Opponent | shoot | 20.7 | 74% | 516 | 532 | 103% |

### Battle groups: chf-efd8067-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 6.0 | 28% | 60% | 0% | - | 40% | 0% | 0% | 60% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 75 | 75% | 3.0 | 0 (2) | - | 0 (2) | 0 (4) | - |
| Mine | Character | 16 | 11 (16) | 11 | 0 | 3 | 25% | 2.9 | 0 (1) | 9 (13) | 25 (2) | 18 (5) | 8 (11) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 104 (6) | 65 | 39 | 0 | 67% | 2.0 | 168 (1) | 122 (4) | 0 (1) | 69 (3) | 136 (3) |
| Mine | Holder | 5 | 24 (5) | 0 | 24 | 0 | 60% | 1.5 | 0 (3) | 117 (1) | 0 (1) | 0 (2) | 38 (3) |
| Mine | Shooter | 2 | 154 (2) | 0 | 154 | 0 | 0% | 2.5 | - | 308 (1) | 0 (1) | 154 (2) | - |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | - | 0 (2) | 0 (2) | - |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 30 | 50% | 2.8 | 0 (1) | 0 (5) | 0 (2) | 0 (4) | 0 (4) |
| Opponent | Clean-up | 5 | 16 (5) | 16 | 0 | 11 | 20% | 2.0 | - | 16 (5) | - | 30 (4) | 0 (1) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 25% | 1.7 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 4 | 16 (4) | 16 | 0 | 0 | 50% | 3.5 | 0 (1) | 170 (1) | 0 (2) | 24 (3) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 10 | 65 (10) | 15 | 50 | 17 | 10% | 2.1 | 0 (3) | 95 (6) | 32 (1) | 44 (9) | 192 (1) |
| Opponent | War machine | 12 | 7 (12) | 7 | 0 | 18 | 8% | 1.9 | 8 (10) | - | 0 (2) | 0 (2) | 8 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (2) | 0 (2) | - |

### Charged fights: chf-efd8067-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 73 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Dwarfen Mountain Holds | 2 | 109 | 100 | 2.0 | 1.2 | 50 | 15 | +35 | 0 of 4 | 3 of 4 | +25 | +38 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 0 | 3.0 | 2.0 | 0 | 310 | -310 | 3 of 3 | 0 of 3 | -270 | -390 |
| **Opponent** | all armies | 3 | 91 | 67 | 2.3 | 1.6 | 29 | 142 | -113 | 3 of 7 | 3 of 7 | -172 | -69 |

### Effective charges: chf-efd8067-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +25) | 0 | 0 | 1 (net +85) | 2 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 2 (net -438) | 0 | 0 | 1 (net -55) | 0 | 0 | 0 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 2 | 458 | 322 | -438 | 12 | 438 | -426 | -92.9 |
| Opponent | Effective (55-75%) | 1 | 110 | 85 | +25 | 327 | 80 | +247 | +224.4 |
| Opponent | 76-89% | 1 | 445 | 322 | -55 | 0 | 67 | -67 | -15.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 85 | +85 | 85 | 0 | +85 | +170.0 |
| Opponent | No odds | 2 | 82 | 85 | +15 | 15 | 0 | +15 | +18.2 |
| Opponent | All fights | 7 | 241 | 187 | -113 | 67 | 146 | -80 | -33.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p13 | move | 23 | 1 (4%) | 1 (4%) | 2 (9%) | 20 (87%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

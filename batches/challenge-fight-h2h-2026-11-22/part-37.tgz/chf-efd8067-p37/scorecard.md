# Doctrine scorecard: chf-efd8067-p37

### Scorecard: chf-efd8067-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 751 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 200 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 515 |
| **Average** | | | Mine | 0% | 2.0 | - | 0.0 | 3.7 | 0.3 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 1.7 | 2.0 | 0.0 | 0.0 | 0.0 | 422.0 |

### KPIs: chf-efd8067-p37

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 62% (10 of 16) | 37% (10 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 0% (0 of 1); on the table 0% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 31% (28 of 90) | - | 31% (28 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (28 of 70) | - | 40% (28 of 70) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | - | 67% (4 of 6) |
| Points that never fought | lower | 77% (4407 of 5699) | 76% (4589 of 6000) | 77% (8996 of 11699) |
|   infantry points that never fought | lower | 83% (1852 of 2239) | 92% (1951 of 2111) | 87% (3803 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (11 of 16) | 72% (18 of 25) | 71% (29 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 75% (3 of 4); 3.3 uses a game | 0.0 uses a game | 75% (3 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (2592 of 3916) | 61% (2681 of 4382) | 64% (5273 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 10.7 (52%) | - | 10.7 (52%) |
| MARCHED: its unit marched | 2.3 (11%) | - | 2.3 (11%) |
| IN COMBAT: engaged in combat | 2.7 (13%) | - | 2.7 (13%) |
| GONE: slain | 4.0 (19%) | - | 4.0 (19%) |
| STUPIDITY: Stupidity | 1.0 (5%) | - | 1.0 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.3 | 5.0 | 9.3 | 0.0 | 1.3 |
| not cast | 2.0 | 3.7 | 5.0 | 20.7 | 2.0 | 26.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (55%) | 0.0 (0%) | 10.7 (52%) | 2.0 (100%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (11%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (18%) | 1.3 (27%) | 2.7 (13%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 1.0 (27%) | 2.0 (40%) | 4.0 (19%) | 0.0 (0%) | 2.3 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 1.0 (5%) | 0.0 (0%) | 0.7 (2%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 5.3 a game | 0.0 a game | 2.7 a game |
| stood (cast and not dispelled) | 62% (10 of 16) | - | 62% (10 of 16) |
| the unit moved after it | 70% (7 of 10) | - | 70% (7 of 10) |
| it charged on its next turn | 0% (0 of 10) | - | 0% (0 of 10) |
| the enemy charged it first | 10% (1 of 10) | - | 10% (1 of 10) |
| it fought by the end of its next turn | 10% (1 of 10) | - | 10% (1 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 10) | - | 0% (0 of 10) |
| none of these (no charge, no fight, no charge escaped) | 90% (9 of 10) | - | 90% (9 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (14 of 20) | 57% (104 of 183) | 58% (118 of 203) |
|   cavalry | - | 59% (20 of 34) | 59% (20 of 34) |
|   character | - | 42% (8 of 19) | 42% (8 of 19) |
|   infantry | 70% (14 of 20) | 51% (30 of 59) | 56% (44 of 79) |
|   monster | - | 44% (4 of 9) | 44% (4 of 9) |
|   war machine | - | 68% (42 of 62) | 68% (42 of 62) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (67%) | 5.0 (19%) | 6.3 (22%) |
| CHARGED: it charged | 0.0 (0%) | 3.3 (13%) | 3.3 (12%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (3%) | 0.7 (2%) |
| NO TARGET IN RANGE | 0.3 (17%) | 10.7 (41%) | 11.0 (39%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (17%) | 2.7 (10%) | 3.0 (11%) |
| OTHER BAR | 0.0 (0%) | 4.0 (15%) | 4.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 2.7 | 83% | 2.1 pts | 21 pts |
| character | 2.7 | 2.0 | 62% | 6.8 pts | 18 pts |
| infantry | 22.7 | 12.3 | 63% | 5.4 pts | 122 pts |
| monster | 1.3 | 0.3 | 75% | 5.3 pts | 7 pts |
| war machine | 14.0 | 12.3 | 55% | 10.3 pts | 144 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 5.3 | 2.7 |
| Charges that made contact a game | 0.0 | 3.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.59 declared, 0.37 contact (27 units) | 0.34 declared, 0.21 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 100% (5 of 5) | 80% (4 of 5) | - | 90% (9 of 10) |
| Character on its own | 100% (1 of 1) | 0% (0 of 1) | 0% (0 of 2) | 25% (1 of 4) |
| Infantry | 57% (4 of 7) | 71% (5 of 7) | - | 64% (9 of 14) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 80% (4 of 5); on the table 80% | 31% (28 of 90) | 77% | 69% (11 of 16) | 75% (3 of 4); 3.3 uses a game | 50% (1 of 2); 0.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 0% (0 of 1); on the table 0% | - | 88% | 80% (16 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 54% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | - | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | - | 15% (2 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (4 of 16) | 41% (29 of 71) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 14) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 100% (4 of 4) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 3.7 | 2.0 |
| Movement | Points that never moved of their own | 66.7 | 422.0 |
| Movement | Fights charged into per game | 0.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 4, net +10 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 4, net +25 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 4, net +85 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 21.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (9 of 15) | 35% (22 of 63) |
| Shooting | Points destroyed by shooting units | 0.0 | 72.7 |
| Shooting | War machine shots | - | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 52% (22 of 42) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (5 of 15) | - |
| Magic | Wounds caused by magic missiles | 6.7 | - |
| Magic | Points destroyed by magic (all spells) | 55.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 1.0 / 0.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 161.7 | 250.0 |
| Combat | Points run down | 0.0 | 185.7 |
| Combat | Net points per charged fight, damage counted | - | +154 |
| Combat | Net per 100 charger points, damage counted | - | +87.4 |
| Combat | First round won (charged fights) | - | 43% |
| Combat | Net points per charged fight | - | +131 |
| Combat | Net points per supported fight / lone fight | - / - | -15 / +189 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 7 |
| Game | Points lost | 468.3 | 309.0 |
| Game | VP from objectives | 686.7 | 620.0 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -97 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 777
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 19.3 | +244.9 | 0.0 | 234.7 | 13.3 | +182.5 | 0.0 | 106.3 |
| ASSAILMENT BY POINTS | 0.3 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +3.2 | 0.0 | 45.7 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 1.3 | +0.0 | 52.0 | 35.0 |
| CANNON PLANNED TARGET | - | - | - | - | 12.7 | +37.4 | 160.0 | 106.7 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 7.0 | +452.2 | 110.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +29.1 | 0.0 | 28.3 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.3 | -159.4 | 0.0 | 83.3 |
| CHARGE LOSSES | 20.3 | -479.4 | 0.0 | 199.3 | 13.3 | -248.0 | 0.0 | 110.0 |
| CHARGE NOW FIRST | - | - | - | - | 3.0 | +0.0 | 90.0 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 16.7 | +0.0 | 0.0 | 302.0 | 6.3 | +0.0 | 0.0 | 48.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| CONVEYANCE SEARCH | 4.3 | +549.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 4.0 | -174.7 | 0.0 | 67.3 | 7.7 | -185.4 | 0.0 | 73.3 |
| DEPLOY BY FIGURES | 7.0 | +65.2 | 0.0 | 0.0 | 11.7 | -180.5 | 0.0 | 24.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -245.9 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 4.3 | +25.9 | 196.7 | 83.3 |
| FALL BACK GOOD ORDER | - | - | - | - | 3.7 | +0.6 | 96.7 | 101.7 |
| FALLS SHORT | 18.7 | +363.3 | 0.0 | 210.7 | 6.0 | +73.2 | 0.0 | 42.3 |
| FEATURE BUFFS | 14.3 | +359.3 | 0.0 | 201.7 | 0.7 | +22.9 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.3 | +64.3 | 21.7 | 83.3 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| FIVE ACTION | 69.7 | +6612.2 | 150.0 | 764.0 | 129.3 | +4031.2 | 856.0 | 729.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 141.7 | 1.7 | +0.0 | 0.0 | 35.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +13.1 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 5.3 | +168.6 | 218.3 | 101.7 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -5.5 | 0.0 | 110.0 |
| GIVES UP | - | - | - | - | 0.7 | -7.4 | 0.0 | 65.0 |
| GOAL WALK | 16.3 | +2293.3 | 0.0 | 69.3 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.7 | +0.3 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 3.3 | +31.4 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | - | - | - | - | 1.7 | -1.1 | 100.0 | 18.3 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 35.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.3 | +0.0 | 56.7 | 18.3 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 164.7 | 7.7 | +0.0 | 0.0 | 110.0 |
| HIS CHARGE LIST | 16.0 | +0.0 | 0.0 | 226.7 | 5.3 | +0.0 | 0.0 | 158.0 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 278.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -35.8 | 0.0 | 56.7 | 3.0 | -105.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 40.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 278.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 40.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 53.3 | +1472.7 | 0.0 | 729.3 | 55.7 | +1974.9 | 0.0 | 234.7 |
| HIS SHOTS BY HIS RUN | 45.3 | +776.4 | 0.0 | 692.3 | 29.0 | +335.3 | 0.0 | 146.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +12.7 | 65.0 | 18.3 |
| HOLD ODDS | 36.7 | +0.0 | 0.0 | 403.3 | 10.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.7 | +1278.5 | 0.0 | 40.0 | 9.7 | +1052.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 3.7 | -129.6 | 133.3 | 83.3 |
| IDLE COST | 13.0 | -156.5 | 0.0 | 145.3 | 1.7 | -32.8 | 0.0 | 24.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.7 | +260.7 | 135.0 | 83.3 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +6.3 | 21.7 | 0.0 |
| KEEP FALLS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +20.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 65.0 | 180.7 | 2.3 | +0.0 | 182.3 | 195.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +3.5 | 50.0 | 36.7 |
| LOST AFTER ESCAPE | - | - | - | - | 2.7 | +2.8 | 128.3 | 83.3 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.8 | 0.0 | 35.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | -11.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +8.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -28.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +65.2 | 0.0 | 160.0 | 2.3 | +16.2 | 0.0 | 35.0 |
| MEETS IN TIME | 4.0 | +101.8 | 0.0 | 0.0 | 7.7 | +79.1 | 0.0 | 24.0 |
| MISSILES IN THE MOVE | 8.0 | +240.1 | 0.0 | 54.0 | - | - | - | - |
| MISSILES NEXT TURN | 8.0 | +225.5 | 0.0 | 27.0 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.7 | -82.4 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.3 | +1036.6 | 0.0 | 60.0 |
| MOVE ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 24.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -100.3 | 0.0 | 268.3 | - | - | - | - |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.0 | +26.3 | 0.0 | 0.0 | 6.0 | +296.0 | 0.0 | 110.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.0 | +150.0 | 0.0 | 21.7 | 7.0 | +284.7 | 0.0 | 18.3 |
| NEXT CHARGE BY LIST | 0.7 | +11.8 | 0.0 | 0.0 | 4.0 | +234.3 | 0.0 | 70.0 |
| NO CHAFF EDGES | 1.0 | +18.9 | 0.0 | 21.7 | 5.0 | +99.5 | 165.0 | 65.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 4.7 | -100.7 | 161.7 | 101.7 |
| NO LATE CUT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -155.6 | 0.0 | 50.0 | 5.0 | -98.7 | 0.0 | 110.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -22.6 | 0.0 | 160.7 | 5.0 | -51.0 | 0.0 | 55.0 |
| ONE JOINT FIGURE | - | - | - | - | 2.3 | +47.6 | 85.0 | 83.3 |
| ONE OBJECTIVE FORMULA | 6.3 | +18.4 | 0.0 | 40.0 | 2.7 | -46.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -2.5 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +38.3 | 18.3 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 2.7 | +59.7 | 111.7 | 65.0 |
| OVERRUNS AWAY | - | - | - | - | 2.3 | +38.9 | 105.0 | 18.3 |
| PATHS CROSS | - | - | - | - | 0.3 | -6.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -13.2 | 0.0 | 0.0 | 0.3 | -13.8 | 0.0 | 0.0 |
| PLAN RESULT | 31.0 | +147.4 | 0.0 | 356.3 | 57.3 | +679.3 | 315.7 | 468.3 |
| PRIZE BY WORTH | - | - | - | - | 0.7 | +7.6 | 28.3 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 1.0 | -14.5 | 0.0 | 0.0 | 8.7 | -116.0 | 0.0 | 70.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -1.2 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -3.0 | 0.0 | 40.0 |
| QUARTER ODDS | 6.7 | +1001.1 | 40.0 | 0.0 | 14.0 | +866.5 | 0.0 | 40.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.7 | +235.7 | 0.0 | 121.7 | 1.3 | +19.7 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 121.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +1.6 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.4 | 0.0 | 0.0 | 1.3 | -1.8 | 0.0 | 40.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +39.8 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.7 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 4.7 | -51.8 | 161.7 | 101.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -5.5 | 21.7 | 65.0 |
| RUN DOWN | - | - | - | - | 4.7 | -19.2 | 190.0 | 83.3 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUTS HUNT GUNS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.8 | 0.0 | 21.7 | 0.3 | -14.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +31.3 | 28.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -314.4 | 0.0 | 18.3 |
| SET UP BY THE SET | - | - | - | - | 3.3 | +253.5 | 0.0 | 42.3 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +2.1 | 0.0 | 35.0 |
| SET-UP ANY TARGET | 0.7 | +80.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | 23.0 | +0.0 | 0.0 | 141.7 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +11.7 | 0.0 | 0.0 | 0.7 | +10.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -19.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 38.0 | -464.9 | 0.0 | 535.7 | 41.0 | +457.4 | 0.0 | 308.0 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.7 | +67.6 | 0.0 | 86.7 | 41.0 | +503.6 | 0.0 | 180.0 |
| SPELL SETS UP CHARGE | 1.0 | +210.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.3 | +0.8 | 20.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -45.6 | 0.0 | 65.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 191.7 | 4.0 | +0.0 | 0.0 | 55.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -7.0 | 86.7 | 18.3 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 18.3 | 18.3 |
| STANDS STILL | 18.7 | +0.0 | 150.0 | 65.0 | 94.3 | +0.0 | 637.7 | 371.7 |
| STAY WORTH | 6.0 | +58.7 | 110.0 | 0.0 | 66.0 | +278.0 | 442.0 | 423.3 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +34.6 | 118.3 | 18.3 |
| STRONG ENOUGH TO HOLD | 1.3 | -7.6 | 0.0 | 0.0 | 0.7 | -22.8 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.2 | 0.0 | 35.0 |
| SUPPORT ADDS | 5.3 | +180.9 | 0.0 | 178.3 | - | - | - | - |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 5.3 | +180.9 | 0.0 | 178.3 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 3.3 | +8.1 | 0.0 | 35.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 21.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.7 | +0.1 | 50.0 | 18.3 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 56.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.3 | +0.0 | 0.0 | 382.0 | 55.7 | +0.0 | 0.0 | 314.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.7 | +142.4 | 83.3 | 0.0 |
| TIME ON OUR SIDE | 5.3 | +110.1 | 0.0 | 80.0 | 59.3 | +473.3 | 0.0 | 180.0 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 108.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +7.7 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -56.2 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +57.1 | 21.7 | 83.3 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +28.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -49.4 | 0.0 | 43.3 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.8 | 28.3 | 0.0 |
| WHOLE FIGHT REACTION | 3.7 | +518.8 | 36.7 | 125.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 7.0 | +582.6 | 0.0 | 0.0 | 1.7 | +36.2 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 327 | 317 | 99 | 33.00 | +998 | +10.1 |
| ARMY TABLE | 98 | 98 | 71 | 23.67 | +1298 | +18.3 |
| HOLDER ASSIGNMENT | 61 | 61 | 60 | 20.00 | +2684 | +44.7 |
| HIS SHOTS BY HIS RUN | 223 | 220 | 53 | 17.67 | +527 | +9.9 |
| SHOT RISK POINTS | 237 | 227 | 48 | 16.00 | +427 | +8.9 |
| TIME ON OUR SIDE | 194 | 175 | 35 | 11.67 | +245 | +7.0 |
| FIVE ACTION | 597 | 584 | 31 | 10.33 | +1876 | +60.5 |
| HARD STAY DROPPED | 30 | 30 | 30 | 10.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 56 | 56 | 27 | 9.00 | +398 | +14.7 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -763 | -30.5 |
| GOAL WALK | 49 | 49 | 21 | 7.00 | +2249 | +107.1 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MEETS IN TIME | 35 | 35 | 15 | 5.00 | +168 | +11.2 |
| CASTING BLOCK | 21 | 21 | 13 | 4.33 | +435 | +33.4 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +3110 | +239.2 |
| NO CHAFF EDGES | 18 | 17 | 13 | 4.33 | +293 | +22.6 |
| QUARTER ODDS | 62 | 62 | 11 | 3.67 | +738 | +67.1 |
| CHARGE LOSSES | 101 | 100 | 10 | 3.33 | +1275 | +127.5 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 10 | 3.33 | -391 | -39.1 |
| WOUNDS ON THE RANKS | 26 | 26 | 10 | 3.33 | +408 | +40.8 |
| MOVE TO CHARGE COMPUTED | 21 | 18 | 9 | 3.00 | +435 | +48.3 |
| CANNON PLANNED TARGET | 38 | 38 | 8 | 2.67 | -2 | -0.3 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +782 | +97.7 |
| NEXT CHARGE BY LIST | 14 | 13 | 7 | 2.33 | +432 | +61.7 |
| SUPPORT ADDS | 16 | 16 | 7 | 2.33 | +78 | +11.1 |
| SUPPORT WORKED OUT | 16 | 16 | 7 | 2.33 | +78 | +11.1 |
| CHARGE NOW FIRST | 9 | 9 | 6 | 2.00 | -143 | -23.9 |
| COVER ONCE | 35 | 24 | 6 | 2.00 | +32 | +5.4 |
| FALLS SHORT | 74 | 51 | 6 | 2.00 | +81 | +13.6 |
| MAX FOR POSITIONING | 19 | 16 | 6 | 2.00 | +14 | +2.4 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 216 | 200 | 6 | 2.00 | +42 | +7.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FEATURE BUFFS | 45 | 44 | 5 | 1.67 | +53 | +10.6 |
| FOUR ROUNDS | 16 | 14 | 5 | 1.67 | +23 | +4.6 |
| GUN MASK | 10 | 10 | 5 | 1.67 | +36 | +7.3 |
| IDLE COST | 44 | 23 | 5 | 1.67 | +12 | +2.4 |
| REDIRECT COUNTER | 21 | 16 | 5 | 1.67 | +108 | +21.7 |
| RISK BY ARC | 14 | 12 | 5 | 1.67 | +37 | +7.4 |
| SCOUT BY DROPS | 6 | 6 | 5 | 1.67 | +0 | +0.0 |
| SET UP BY THE SET | 10 | 10 | 5 | 1.67 | +25 | +5.1 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOTS IN THE MOVE | 137 | 116 | 5 | 1.67 | +18 | +3.7 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| EXACT ROUND | 13 | 12 | 4 | 1.33 | +18 | +4.6 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +95 | +23.8 |
| SHOTS AFTER THE MOVES | 19 | 19 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 4 | 4 | 1.33 | +122 | +30.6 |
| WHOLE FIGHT DANGER | 6 | 6 | 4 | 1.33 | +43 | +10.8 |
| WHOLE FIGHT REACTION | 11 | 11 | 4 | 1.33 | +31 | +7.8 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| OPENS UP IN FULL | 8 | 7 | 3 | 1.00 | +88 | +29.5 |
| OVERRUNS AWAY | 7 | 5 | 3 | 1.00 | +31 | +10.4 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +37 | +12.2 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +119 | +39.8 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +104 | +34.6 |
| SURE REACH TOGETHER | 10 | 10 | 3 | 1.00 | +1 | +0.4 |
| CLEAR LANE AHEAD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 2 | 2 | 0.67 | +6 | +2.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +62 | +30.9 |
| MAIN BODY KEEPS ITS BAND | 2 | 2 | 2 | 0.67 | +97 | +48.5 |
| MISSILES IN THE MOVE | 24 | 15 | 2 | 0.67 | +69 | +34.5 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -7 | -3.7 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -81 | -40.6 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +23 | +11.4 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 2 | 0.67 | -4 | -1.8 |
| RESERVE MOVE SPELL | 2 | 2 | 2 | 0.67 | +17 | +8.6 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +94 | +47.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 2 | 0.67 | +10 | +4.8 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -92 | -45.9 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.1 |
| BACKS UP THE FIGHT | 2 | 2 | 1 | 0.33 | +2 | +2.1 |
| BACKUP TARGETS | 4 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +44 | +43.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +39 | +39.4 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +19 | +18.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +5 | +4.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +26 | +25.7 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| MOVE ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 30 | 30 | 1 | 0.33 | +49 | +49.0 |
| ONE JOINT FIGURE | 7 | 7 | 1 | 0.33 | +5 | +4.8 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +74 | +73.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -18 | -18.0 |
| RUN DOWN | 14 | 12 | 1 | 0.33 | +5 | +4.8 |
| SCOUT WAITS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +8 | +8.3 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| THE ROW IN ITS ORDER | 11 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +23 | +23.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +71 | +70.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 68 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 4 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 51 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 64 | 60 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 142 | 140 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 13 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 27 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 265 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 5 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 84 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 339 | 333 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 9 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 267 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.00 | 30.1 |
| ARMY TABLE | rule | 2.33 | 1.00 | 29.7 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 3.00 | 39.1 |
| CHARGE NOW FIRST | rule | - | 1.67 | 28.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 79.9 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 0.8 |
| JOINT CHARGE NOW | rule | - | 1.00 | 24.4 |
| RULE SWITCHED OFF | gate | - | 1.00 | 35.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 40.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 1.8 |
| SET UP BY THE SET | rule | - | 0.67 | 12.9 |
| SUPPORT NARROWED | rule | - | 0.67 | 45.9 |
| AFTERMATH BAND | gate | 0.33 | - | 2.0 |
| NO REASON | gate | 0.33 | - | 52.0 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 32.2 |
| PATHS CROSS | rule | - | 0.33 | 18.0 |

### Plans: chf-efd8067-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 27.0 | 91% | 2365 | 0 | 0% |
| Mine | shoot | 4.0 | 58% | 464 | 147 | 32% |
| Opponent | charge | 4.7 | 64% | 485 | 209 | 43% |
| Opponent | move | 33.3 | 96% | 1361 | 0 | 0% |
| Opponent | shoot | 19.3 | 67% | 387 | 470 | 121% |

### Battle groups: chf-efd8067-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.7 | 41% | 57% | 0% | - | 29% | 0% | 0% | 71% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 75 | 75% | 3.0 | 0 (2) | - | 0 (2) | 0 (4) | - |
| Mine | Character | 16 | 6 (16) | 6 | 0 | 24 | 31% | 2.7 | 0 (1) | 3 (10) | 0 (2) | 7 (5) | 0 (8) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 44 (6) | 26 | 18 | 22 | 67% | 2.0 | 168 (1) | 38 (4) | 0 (1) | 61 (3) | 28 (3) |
| Mine | Holder | 5 | 41 (5) | 0 | 41 | 0 | 60% | 1.5 | 0 (3) | 195 (1) | 0 (1) | 0 (2) | 63 (3) |
| Mine | Shooter | 2 | 350 (2) | 42 | 308 | 100 | 0% | 1.5 | - | 615 (1) | 85 (1) | 350 (2) | - |
| Mine | Wizard | 2 | 50 (2) | 50 | 0 | 0 | 50% | 2.0 | - | 0 (1) | 111 (1) | 111 (1) | 0 (1) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | - | 0 (2) | 0 (2) | - |
| Opponent | Character | 8 | 74 (8) | 74 | 0 | 0 | 50% | 2.5 | 247 (1) | 7 (5) | 0 (2) | 0 (4) | 102 (4) |
| Opponent | Clean-up | 5 | 16 (5) | 16 | 0 | 11 | 20% | 2.0 | - | 16 (5) | - | 30 (4) | 0 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 11 | 0 | 66 | 25% | 1.7 | - | 13 (3) | 0 (1) | 17 (3) | 0 (1) |
| Opponent | Hammer | 4 | 16 (4) | 16 | 0 | 0 | 50% | 3.5 | 0 (1) | 170 (1) | 0 (2) | 24 (3) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Shooter | 10 | 84 (10) | 10 | 73 | 13 | 10% | 2.1 | 0 (3) | 130 (6) | 0 (1) | 66 (9) | 192 (1) |
| Opponent | War machine | 12 | 7 (12) | 7 | 0 | 26 | 8% | 1.9 | 8 (10) | - | 0 (2) | 0 (2) | 8 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (2) | 0 (2) | - |

### Charged fights: chf-efd8067-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Dwarfen Mountain Holds | 2 | 109 | 100 | 2.0 | 1.2 | 50 | 15 | +35 | 0 of 4 | 3 of 4 | +25 | +38 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1082 | 3.0 | 1.7 | 361 | 102 | +259 | 2 of 3 | 0 of 3 | -55 | +416 |
| **Opponent** | all armies | 3 | 73 | 427 | 2.3 | 1.4 | 183 | 52 | +131 | 2 of 7 | 3 of 7 | -15 | +189 |

### Effective charges: chf-efd8067-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +25) | 0 | 0 | 1 (net +85) | 2 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +10) | 0 | 0 | 1 (net -55) | 0 | 0 | 1 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 55 | 65 | +10 | 65 | 101 | -36 | -64.8 |
| Opponent | Effective (55-75%) | 1 | 110 | 85 | +25 | 327 | 80 | +247 | +224.4 |
| Opponent | 76-89% | 1 | 445 | 322 | -55 | 47 | 115 | -68 | -15.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 85 | +85 | 85 | 0 | +85 | +170.0 |
| Opponent | No odds | 3 | 192 | 164 | +284 | 349 | 65 | +284 | +147.9 |
| Opponent | All fights | 7 | 177 | 150 | +131 | 224 | 70 | +154 | +87.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p37 | move | 24 | 2 (8%) | 1 (4%) | 3 (12%) | 19 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

# Doctrine scorecard: chf-efd8067-p4

### Scorecard: chf-efd8067-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 473 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 5 | - | 0 | 4 | 0 | 0 | 0 | 675 |
| L0612 | 6 | 1 | Opponent | no | 11 | 5 | 1 | 0 | 2 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 773 |
| L0628 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.5 | 3.0 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 640.3 |
| **Average** | | | Opponent | 0% | 7.0 | 5.5 | 0.3 | 2.0 | 0.7 | 0.0 | 0.0 | 110.0 |

### KPIs: chf-efd8067-p4

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 93% (13 of 14) | 0% (0 of 14) | 46% (13 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 50% (15 of 30) | 50% (15 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 50% (15 of 30) | 50% (15 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 85% (5077 of 6000) | 97% (5796 of 5998) | 91% (10873 of 11998) |
|   infantry points that never fought | lower | 89% (1993 of 2232) | 100% (694 of 694) | 92% (2687 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (18 of 27) | 57% (13 of 23) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2575 of 4232) | 61% (3536 of 5787) | 61% (6111 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (20%) | 1.0 (20%) |
| MARCHED: its unit marched | - | 2.7 (53%) | 2.7 (53%) |
| CHARGED: its unit charged | - | 0.7 (13%) | 0.7 (13%) |
| STUPIDITY: Stupidity | - | 0.7 (13%) | 0.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 2.0 | 5.0 | 1.0 | 0.0 |
| not cast | 2.0 | 2.0 | 5.0 | 3.0 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (67%) | 1.0 (20%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.7 (53%) | 1.3 (44%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (13%) | 0.3 (11%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| STUPIDITY: Stupidity | 0.7 (33%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (86%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (135 of 204) | 93% (13 of 14) | 68% (148 of 218) |
|   cavalry | 50% (7 of 14) | 50% (1 of 2) | 50% (8 of 16) |
|   character | 88% (29 of 33) | - | 88% (29 of 33) |
|   infantry | 38% (21 of 55) | - | 38% (21 of 55) |
|   monster | 80% (8 of 10) | - | 80% (8 of 10) |
|   war machine | 76% (70 of 92) | 100% (12 of 12) | 79% (82 of 104) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.3 (23%) | 0.0 (0%) | 5.3 (23%) |
| CHARGED: it charged | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 7.7 (33%) | 0.3 (100%) | 8.0 (34%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.3 (23%) | 0.0 (0%) | 5.3 (23%) |
| SHELTERED: the target was sheltered | 1.7 (7%) | 0.0 (0%) | 1.7 (7%) |
| STUPIDITY | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.7 | 75% | 10.9 pts | 29 pts |
| character | 9.7 | 5.3 | 76% | 11.2 pts | 109 pts |
| infantry | 13.7 | 3.7 | 80% | 10.8 pts | 148 pts |
| monster | 2.7 | 0.7 | 75% | 20.6 pts | 55 pts |
| war machine | 27.7 | 17.0 | 70% | 20.5 pts | 567 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 1.3 | 1.0 |
| Charges that made contact a game | 0.7 | 0.7 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.67 declared, 0.33 contact (3 units) | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (21 units) | 0.15 declared, 0.08 contact (13 units) | 0.12 declared, 0.09 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 75% (6 of 8) | 67% (2 of 3) | - | 73% (8 of 11) |
| Character on its own | - | 75% (3 of 4) | 67% (2 of 3) | 71% (5 of 7) |
| Infantry | 43% (3 of 7) | 50% (3 of 6) | - | 46% (6 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 85% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 61% (11 of 18) | 100% | 22% (2 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 92% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 98% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: chf-efd8067-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 68% (52 of 77) | 47% (7 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 25% (3 of 12) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 2.0 |
| Movement | Points that never moved of their own | 640.3 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 2, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +161 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 22.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (43 of 66) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 72.3 | 0.0 |
| Shooting | War machine shots | 23.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (51 of 70) | 42% (5 of 12) |
| Shooting | Points destroyed by war machines | 119.0 | 78.3 |
| Magic | Magic missiles cast | - | 4.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 54% (7 of 13) |
| Magic | Wounds caused by magic missiles | - | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 73.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.0 / 0.7 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 67.3 | 0.0 |
| Combat | Points run down | 0.0 | 35.0 |
| Combat | Net points per charged fight, damage counted | +249 | +0 |
| Combat | Net per 100 charger points, damage counted | +144.9 | +0.0 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +101 | +0 |
| Combat | Net points per supported fight / lone fight | - / +101 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 0 of 2 |
| Game | Points lost | 235.0 | 364.0 |
| Game | VP from objectives | 663.3 | 523.3 |
| Game | Lone holders (player turns) | 2.5 | 7.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +252 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 599
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: chf-efd8067-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 5.7 | -153.5 | 0.0 | 40.0 | 11.0 | +240.7 | 0.0 | 74.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 31.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 19.3 | +367.7 | 837.0 | 103.3 | 4.0 | +132.7 | 98.3 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 1.3 | +16.6 | 66.7 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +34.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 53.7 |
| CHARACTER GUNS | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +7.3 | 53.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.0 | -198.7 | 0.0 | 0.0 | 25.0 | -1243.6 | 0.0 | 755.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 67.3 | 0.0 | 0.3 | +0.0 | 0.0 | 53.7 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.7 | -1288.0 | 0.0 | 35.0 | 4.0 | -112.5 | 0.0 | 109.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.7 | 35.0 | 0.0 |
| DEPLOY BY FIGURES | 12.7 | -143.8 | 0.0 | 20.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +1.0 | 13.7 | 0.0 | 1.3 | -1.5 | 66.7 | 53.7 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 13.7 | 0.0 | 1.3 | +0.1 | 66.7 | 53.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 24.7 | +279.6 | 0.0 | 390.7 |
| FEATURE BUFFS | 0.7 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| FIVE ACTION | 129.7 | +4784.8 | 2268.7 | 460.0 | 68.3 | +1848.4 | 325.0 | 823.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 35.0 | 2.3 | +0.0 | 0.0 | 209.0 |
| FOLLOW UP WEIGHED | 0.3 | +37.2 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +39.4 | 67.3 | 0.0 | 1.3 | +47.8 | 66.7 | 53.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -34.8 | 0.0 | 0.0 | 3.3 | -65.5 | 0.0 | 144.7 |
| GIVES UP | - | - | - | - | 0.3 | -17.9 | 35.0 | 0.0 |
| GOAL WALK | 5.0 | +322.7 | 0.0 | 0.0 | 5.0 | +414.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 37.0 | 0.0 | - | - | - | - |
| GUN MASK | 4.7 | +53.5 | 0.0 | 0.0 | 2.7 | +69.9 | 0.0 | 136.7 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 20.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 562.7 |
| HIS CHARGE DENIED | 0.3 | +12.7 | 53.7 | 0.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 9.7 | +0.0 | 0.0 | 63.3 | 7.0 | +0.0 | 0.0 | 119.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 119.0 |
| HIS MOVE AND SHOT | 6.3 | -43.0 | 0.0 | 0.0 | 6.0 | -96.6 | 0.0 | 392.3 |
| HIS ONE QUARTER | - | - | - | - | 0.3 | +0.0 | 0.0 | 119.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 119.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.7 | +1024.9 | 0.0 | 253.3 | 46.0 | +4248.2 | 0.0 | 769.3 |
| HIS SHOTS BY HIS RUN | 30.7 | +512.2 | 0.0 | 190.0 | 42.7 | +1308.0 | 0.0 | 769.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +4.6 | 35.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +1150.9 | 0.0 | 0.0 | 8.3 | +1027.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -23.0 | 67.3 | 0.0 | 1.3 | -31.0 | 66.7 | 53.7 |
| IDLE COST | - | - | - | - | 16.3 | -335.4 | 0.0 | 181.7 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 27.3 | 0.0 | 1.7 | +0.0 | 0.0 | 134.7 |
| LONG SHOT | 0.3 | -0.4 | 53.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 2.0 | +52.7 | 0.0 | 72.3 |
| MANOEUVRE | 2.3 | -27.8 | 0.0 | 0.0 | 2.0 | +9.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.0 | +40.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +48.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +9.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 2.0 | +67.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 2.7 | +21.8 | 0.0 | 68.3 |
| MEETS IN TIME | 9.0 | +209.9 | 0.0 | 20.0 | 2.0 | +354.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 7.7 | +49.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.3 | +52.1 | 0.0 | 0.0 |
| MODEL FACING | 2.0 | +714.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +47.7 | 0.0 | 0.0 | 2.7 | +123.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +248.0 | 0.0 | 0.0 | 4.7 | +197.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +11.6 | 0.0 | 0.0 | 1.7 | +92.7 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.7 | +0.6 | 0.0 | 0.0 | 0.7 | +8.8 | 35.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -12.1 | 67.3 | 0.0 | 1.3 | -25.1 | 66.7 | 53.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -274.6 | 13.7 | 31.7 | 6.3 | -204.3 | 0.0 | 144.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.3 | +5.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -15.1 | 0.0 | 35.0 | 4.7 | -98.2 | 0.0 | 173.7 |
| ONE OBJECTIVE FORMULA | 5.3 | +4.8 | 0.0 | 0.0 | 3.0 | -133.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -7.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +9.7 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 0.3 | +1.1 | 35.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +24.6 | 0.0 | 0.0 |
| PLAN RESULT | 57.7 | +1084.0 | 1214.0 | 358.3 | 32.0 | +171.6 | 20.0 | 728.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -126.1 | 0.0 | 0.0 | 6.7 | -32.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -34.8 | 0.0 | 0.0 | 3.0 | -39.0 | 0.0 | 144.7 |
| PROMISE SHOT AWAY | 0.7 | -1.5 | 136.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.3 | +1100.1 | 1190.0 | 0.0 | 3.0 | +754.9 | 0.0 | 119.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +41.0 | 0.0 | 0.0 | 0.7 | +24.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 13.7 |
| REFORMS TO MEET IT | 0.7 | -10.4 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | +20.2 | 13.7 | 0.0 | 1.0 | +29.2 | 35.0 | 53.7 |
| RUN DOWN | 0.3 | -3.4 | 13.7 | 0.0 | 1.0 | -1.3 | 35.0 | 53.7 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +60.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +5.1 | 13.7 | 0.0 | 0.3 | +3.4 | 0.0 | 53.7 |
| SET CREDITED ONCE | 1.3 | -67.9 | 0.0 | 0.0 | 2.7 | -221.2 | 0.0 | 144.7 |
| SET UP BY THE SET | 1.7 | +70.8 | 0.0 | 0.0 | 4.3 | +172.1 | 0.0 | 218.7 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +57.8 | 0.0 | 72.3 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 27.0 | +0.0 | 0.0 | 103.3 | 6.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.0 | +7.5 | 35.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 21.3 | +274.1 | 0.0 | 190.0 | 27.7 | -656.8 | 0.0 | 755.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 37.7 | +1350.7 | 0.0 | 158.3 | 4.3 | +201.8 | 0.0 | 37.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +155.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +3.4 | 66.7 | 0.0 |
| SPOT AS THE GAME MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 123.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -3.6 | 35.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 100.7 | +0.0 | 2201.3 | 390.0 | 16.7 | +0.0 | 258.3 | 0.0 |
| STAY WORTH | 58.3 | -63.1 | 1198.0 | 235.0 | 10.7 | +94.9 | 156.7 | 0.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -3.1 | 0.0 | 0.0 | 1.0 | -19.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +18.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.7 | +0.7 | 31.7 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.3 | +0.0 | 0.0 | 158.3 | 34.3 | +0.0 | 0.0 | 318.3 |
| TIED UP BY THE SUM | 0.3 | +12.1 | 13.7 | 0.0 | 0.3 | +48.0 | 35.0 | 0.0 |
| TIME ON OUR SIDE | 57.3 | +572.8 | 74.0 | 55.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.2 | 13.7 | 0.0 | 0.7 | +3.2 | 0.0 | 53.7 |
| WHOLE FIGHT DANGER | - | - | - | - | 0.7 | -56.6 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.0 | +34.4 | 0.0 | 66.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +75.6 | 0.0 | 0.0 | 5.3 | +799.2 | 0.0 | 119.0 |

### Rule changes: chf-efd8067-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 257 | 249 | 89 | 29.67 | +2550 | +28.7 |
| HIS SHOTS BY HIS RUN | 220 | 208 | 53 | 17.67 | +745 | +14.1 |
| HOLDER ASSIGNMENT | 56 | 56 | 52 | 17.33 | +3970 | +76.4 |
| OFF BEST | 41 | 41 | 41 | 13.67 | -1437 | -35.0 |
| ARMY TABLE | 50 | 50 | 39 | 13.00 | +171 | +4.4 |
| TIME ON OUR SIDE | 172 | 151 | 34 | 11.33 | +105 | +3.1 |
| DEPLOY BY FIGURES | 51 | 51 | 32 | 10.67 | +306 | +9.6 |
| SHOT RISK POINTS | 147 | 140 | 28 | 9.33 | +770 | +27.5 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| IDLE COST | 49 | 36 | 14 | 4.67 | +231 | +16.5 |
| MEETS IN TIME | 33 | 33 | 14 | 4.67 | +432 | +30.9 |
| THE TABLE AGAIN | 35 | 35 | 14 | 4.67 | +0 | +0.0 |
| GOAL WALK | 30 | 30 | 13 | 4.33 | +1175 | +90.4 |
| FIVE ACTION | 594 | 577 | 12 | 4.00 | +381 | +31.8 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 12 | 4.00 | -476 | -39.6 |
| COVER ONCE | 47 | 38 | 11 | 3.67 | +169 | +15.3 |
| WOUNDS ON THE RANKS | 25 | 25 | 11 | 3.67 | +362 | +32.9 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CHARGE LOSSES | 105 | 102 | 10 | 3.33 | +772 | +77.2 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +15 | +1.5 |
| MOVE TO CHARGE COMPUTED | 16 | 12 | 9 | 3.00 | +199 | +22.1 |
| FALLS SHORT | 74 | 64 | 7 | 2.33 | +97 | +13.9 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 70 | 70 | 6 | 2.00 | +0 | +0.0 |
| MODEL FACING | 6 | 6 | 6 | 2.00 | +2142 | +357.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 6 | 5 | 5 | 1.67 | +53 | +10.6 |
| SHOTS AFTER THE MOVES | 24 | 24 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 126 | 105 | 5 | 1.67 | +180 | +36.0 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +1 | +0.3 |
| NEXT CHARGE BY LIST | 7 | 7 | 4 | 1.33 | +142 | +35.6 |
| NO CHAFF EDGES | 4 | 4 | 4 | 1.33 | +28 | +7.0 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +532 | +177.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +120 | +40.0 |
| MAX FOR POSITIONING | 8 | 7 | 3 | 1.00 | +3 | +1.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +74 | +24.6 |
| SET UP BY THE SET | 18 | 10 | 3 | 1.00 | +161 | +53.5 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -63 | -31.7 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +38 | +18.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +44 | +21.9 |
| MOVE ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -24 | -11.9 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -4 | -2.2 |
| QUARTER ODDS | 61 | 61 | 2 | 0.67 | +12 | +5.8 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +29 | +14.3 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +25 | +12.7 |
| SET UP TOGETHER | 8 | 7 | 2 | 0.67 | +49 | +24.6 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +4 | +1.8 |
| THE ROW IN ITS ORDER | 9 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 5 | 4 | 1 | 0.33 | +3 | +3.2 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +112 | +111.6 |
| GUN MASK | 22 | 22 | 1 | 0.33 | +17 | +17.4 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| HONEST WORTH | 6 | 5 | 1 | 0.33 | +0 | +0.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| MANOEUVRE | 13 | 13 | 1 | 0.33 | +29 | +28.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -29 | -28.9 |
| MISSILES IN THE MOVE | 23 | 17 | 1 | 0.33 | +15 | +14.6 |
| MISSILES NEXT TURN | 28 | 23 | 1 | 0.33 | +3 | +3.1 |
| NEARER NOT NEEDED | 30 | 28 | 1 | 0.33 | +37 | +37.4 |
| NO DOUBLE ROUNDS | 6 | 5 | 1 | 0.33 | +0 | +0.5 |
| ONE FIGHT FORMULA | 21 | 17 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 25 | 21 | 1 | 0.33 | +15 | +14.7 |
| OPENS UP IN FULL | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 5 | 5 | 1 | 0.33 | +42 | +41.9 |
| RISK BY ARC | 4 | 3 | 1 | 0.33 | +3 | +2.8 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +180 | +180.1 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +3 | +3.2 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +3 | +3.2 |
| WHO FIGHTS | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| WHOLE FIGHT REACTION | 3 | 3 | 1 | 0.33 | +10 | +9.7 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 14 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 41 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 37 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 50 | 50 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 1 | 1 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 34 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 78 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 13 | 13 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 100 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 24 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 352 | 349 | 0 | 0.00 | - | - |
| STAY WORTH | 207 | 188 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 269 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 5.67 | 39.0 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.00 | 39.6 |
| ARMY TABLE | rule | 1.67 | 0.33 | 104.5 |
| RULE SWITCHED OFF | gate | 1.00 | - | 8.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 31.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 20.8 |
| NO REASON | gate | - | 0.67 | 3.9 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 11.9 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 2.2 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 28.9 |

### Plans: chf-efd8067-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 68 | 67 | 99% |
| Mine | join | 2.0 | 100% | 70 | 0 | 0% |
| Mine | move | 34.7 | 96% | 1058 | 0 | 0% |
| Mine | shoot | 20.3 | 49% | 569 | 1017 | 179% |
| Opponent | charge | 1.0 | 33% | 9 | 49 | 541% |
| Opponent | join | 2.0 | 100% | 93 | 0 | 0% |
| Opponent | move | 24.7 | 95% | 821 | 0 | 0% |
| Opponent | shoot | 3.7 | 64% | 189 | 122 | 65% |
| Opponent | support | 0.7 | 100% | 15 | 0 | 0% |

### Battle groups: chf-efd8067-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 100% | 100% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 8 (13) | 8 | 0 | 0 | 31% | 2.6 | 16 (5) | 0 (7) | 0 (1) | 9 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | - | 0 (3) | 0 (1) | 0 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 100 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 93 (4) | 7 | 87 | 0 | 50% | 2.0 | 17 (1) | 147 (3) | - | 93 (4) | - |
| Mine | Holder | 2 | 98 (2) | 0 | 98 | 0 | 0% | 1.5 | 0 (1) | 194 (1) | - | 194 (1) | 0 (1) |
| Mine | Shooter | 6 | 65 (6) | 29 | 37 | 0 | 17% | 3.8 | 148 (2) | 0 (1) | 9 (3) | 82 (5) | 0 (1) |
| Mine | War machine | 17 | 21 (17) | 21 | 0 | 25 | 12% | 1.4 | 0 (4) | 38 (9) | 0 (4) | 0 (3) | 26 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 67% | 1.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 7 (10) | 7 | 0 | 17 | 70% | 1.0 | 23 (2) | 5 (5) | 0 (2) | 10 (8) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 8 (3) | 0 | 8 | 30 | 100% | - | - | 13 (2) | 0 (1) | 11 (2) | 0 (1) |
| Opponent | Holder | 6 | 110 (6) | 15 | 95 | 10 | 50% | 2.3 | - | 110 (6) | - | 134 (4) | 69 (2) |
| Opponent | War machine | 2 | 71 (2) | 71 | 0 | 0 | 0% | 1.0 | - | 73 (1) | 70 (1) | - | 71 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: chf-efd8067-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 191 | 67 | 0.7 | 1.0 | 101 | 0 | +101 | 0 of 2 | 2 of 2 | - | +101 |
| Opponent | Grand Cathay | 1 | 455 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 0 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 152 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 1 | - | +0 |

### Effective charges: chf-efd8067-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +161) | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 239 | 161 | +161 | 184 | 104 | +81 | +33.8 |
| Mine | No odds | 1 | 105 | 41 | +41 | 418 | 0 | +418 | +397.7 |
| Mine | All fights | 2 | 172 | 101 | +101 | 301 | 52 | +249 | +144.9 |
| Opponent | Long shot (under 50%) | 1 | 41 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 470 | 95 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 2 | 256 | 78 | +0 | 0 | 0 | +0 | +0.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p4 | move | 12 | 1 (8%) | 1 (8%) | 1 (8%) | 10 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

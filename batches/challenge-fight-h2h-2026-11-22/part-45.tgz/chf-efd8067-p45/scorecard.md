# Doctrine scorecard: chf-efd8067-p45

### Scorecard: chf-efd8067-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 176 |
| L1531 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 4 | 2 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 280 |
| L1629 | 3 | 1 | Opponent | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 0.5 | 1.7 | 2.7 | 0.3 | 0.0 | 0.0 | 0.0 | 152.0 |
| **Average** | | | Opponent | 33% | 4.0 | 1.7 | 4.0 | 2.7 | 0.7 | 0.0 | 0.0 | 56.7 |

### KPIs: chf-efd8067-p45

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 80% (8 of 10); on the table 80% | 67% (2 of 3); on the table 100% | 77% (10 of 13); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 50% (1 of 2); on the table 50% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 79% (11 of 14); on the table 79% | 60% (3 of 5); on the table 80% | 74% (14 of 19); on the table 79% |
| Magic missiles tried each own turn | 50%+ | - | 50% (6 of 12) | 50% (6 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 50% (6 of 12) | 50% (6 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 78% (7 of 9) | 78% (7 of 9) |
| Points that never fought | lower | 30% (1790 of 6000) | 35% (2114 of 5999) | 33% (3904 of 11999) |
|   infantry points that never fought | lower | 42% (564 of 1332) | 100% (855 of 855) | 65% (1419 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 80% (20 of 25) | 71% (32 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (3 of 3); 2.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2811 of 5135) | 71% (3876 of 5430) | 63% (6687 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (67%) | 1.3 (67%) |
| MARCHED: its unit marched | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 1.3 | 1.3 | 2.0 | 1.3 |
| not cast | 7.3 | 0.7 | 0.7 | 2.0 | 18.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (5%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.0 (82%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (45 of 84) | 12% (1 of 8) | 50% (46 of 92) |
|   cavalry | 75% (6 of 8) | 25% (1 of 4) | 58% (7 of 12) |
|   character | 55% (6 of 11) | 0% (0 of 4) | 40% (6 of 15) |
|   chariot | 83% (5 of 6) | - | 83% (5 of 6) |
|   infantry | 53% (19 of 36) | - | 53% (19 of 36) |
|   monster | 19% (3 of 16) | - | 19% (3 of 16) |
|   war machine | 86% (6 of 7) | - | 86% (6 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (21%) | 0.7 (29%) | 3.3 (22%) |
| CHARGED: it charged | 1.3 (10%) | 1.0 (43%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 3.3 (26%) | 0.0 (0%) | 3.3 (22%) |
| NO TARGET IN RANGE | 3.0 (23%) | 0.3 (14%) | 3.3 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 2.3 (18%) | 0.0 (0%) | 2.3 (15%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 0.3 (14%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.7 | 0.7 | 88% | 7.1 pts | 19 pts |
| chariot | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 10.7 | 1.7 | 88% | 5.3 pts | 57 pts |
| monster | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 2.0 | 2.0 | 50% | 54.9 pts | 110 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.7 | 5.2 |
| Charges that made contact a game | 4.0 | 4.3 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 0.67 declared, 0.67 contact (3 units) | 0.57 declared, 0.57 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.50 contact (20 units) | 0.71 declared, 0.52 contact (21 units) | 0.66 declared, 0.51 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 100% (3 of 3) | 100% (2 of 2) | 90% (9 of 10) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 83% (5 of 6) | 100% (2 of 2) | 33% (3 of 9) | 59% (10 of 17) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 71% (5 of 7) | 33% (1 of 3) | - | 60% (6 of 10) |
| Monster | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 75% (3 of 4); on the table 75% | - | 54% | 57% (4 of 7) | 100% (2 of 2); 10.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 28% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 67% (4 of 6); on the table 67% | - | 8% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 30% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 60% (3 of 5); on the table 80% | 67% (4 of 6) | 38% | 79% (15 of 19) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 73% (8) | 61% (11) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 1.00 | 1.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.67 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 75% (6 of 8) | 47% (7 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (16 of 25) | 0% (0 of 9) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 83% (10 of 12) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.7 |
| Movement | Points that never moved of their own | 152.0 | 56.7 |
| Movement | Fights charged into per game | 4.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 6, net +0 | 4 of 10, net +4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 1 of 10, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +45 | 2 of 10, net +82 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +118 | 2 of 10, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (19 of 42) | 100% (3 of 3) |
| Shooting | Points destroyed by shooting units | 56.7 | 0.0 |
| Shooting | War machine shots | 2.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (6 of 6) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 2.0 | 0.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.0 / 0.0 | 0.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 510.0 | 87.7 |
| Combat | Points run down | 68.3 | 26.7 |
| Combat | Net points per charged fight, damage counted | +140 | +5 |
| Combat | Net per 100 charger points, damage counted | +52.7 | +2.1 |
| Combat | First round won (charged fights) | 83% | 45% |
| Combat | Net points per charged fight | +148 | +3 |
| Combat | Net points per supported fight / lone fight | - / +148 | +42 / -5 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 12 | 7 of 11 |
| Game | Points lost | 147.7 | 715.3 |
| Game | VP from objectives | 803.3 | 566.7 |
| Game | Lone holders (player turns) | 0.5 | 4.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +888 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 863
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +71.2 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 67.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +39.7 | 0.0 | 0.0 |
| ARMY TABLE | 24.3 | -78.7 | 0.0 | 0.0 | 18.7 | +178.4 | 0.0 | 50.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 1.0 | +47.0 | 0.0 | 0.0 | 2.3 | +95.9 | 0.0 | 10.0 |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.3 | +7.4 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 2.0 | +61.0 | 0.0 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +3.5 | 48.0 | 0.0 | 3.7 | +20.8 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +91.2 | 0.0 | 25.0 |
| CHALLENGE BY POINTS | 0.3 | +1.5 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| CHALLENGE IN THE FIGHT | 1.0 | -168.8 | 278.7 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -14.5 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -35.8 | 210.3 | 0.0 | 0.7 | -6.7 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +11.6 | 33.3 | 10.0 |
| CHARGE LOSSES | 9.3 | -365.4 | 0.0 | 0.0 | 9.3 | -584.2 | 0.0 | 113.3 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 240.0 | 0.0 | 3.0 | +0.0 | 94.3 | 146.7 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 660.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 25.0 |
| COVER ONCE | 8.0 | -486.0 | 0.0 | 0.0 | 10.7 | -1341.5 | 0.0 | 143.3 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -4.9 | 66.7 | 78.3 |
| DEPLOY BY FIGURES | 6.3 | -5.6 | 0.0 | 0.0 | 6.3 | +70.2 | 0.0 | 15.0 |
| DUEL STOPS AT THE KILL | 0.3 | -59.6 | 143.3 | 0.0 | 0.3 | -11.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | -1.4 | 93.3 | 26.7 | 4.0 | +11.5 | 120.0 | 146.7 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +1.0 | 258.3 | 0.0 | 4.7 | +0.7 | 115.3 | 165.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.3 | +303.9 | 0.0 | 244.7 |
| FEATURE BUFFS | 0.7 | +7.1 | 0.0 | 0.0 | 2.0 | +19.5 | 0.0 | 382.7 |
| FIGHT TO THE END | 1.0 | +12.8 | 210.3 | 0.0 | 1.7 | +36.2 | 27.7 | 0.0 |
| FIRE AND FLEE | 0.3 | +1.6 | 0.0 | 26.7 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 56.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 84.7 | +8180.3 | 903.7 | 268.7 | 76.0 | +4969.8 | 175.3 | 884.3 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 226.3 |
| FOLLOW UP WEIGHED | 2.3 | +239.1 | 0.0 | 0.0 | 0.7 | +14.3 | 0.0 | 10.0 |
| FOUR ROUNDS | 3.7 | +174.6 | 408.3 | 26.7 | 5.7 | +218.8 | 175.3 | 175.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 286.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -25.3 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -10.1 | 0.0 | 0.0 | 2.3 | -25.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +13.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -37.2 | 143.3 | 0.0 | 1.0 | -21.0 | 0.0 | 28.3 |
| GOAL WALK | 8.0 | +873.1 | 0.0 | 0.0 | 5.0 | +487.5 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.3 | +0.6 | 211.7 | 0.0 | 1.7 | -2.0 | 61.0 | 38.3 |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 56.7 |
| HIS CHARGE DENIED | 0.7 | +24.6 | 68.3 | 0.0 | 0.7 | +33.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 55.3 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 30.0 |
| HIS MOVE AND SHOT | 2.0 | -12.8 | 0.0 | 0.0 | 1.7 | -9.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 20.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 11.3 | +111.2 | 0.0 | 0.0 | 27.7 | +722.4 | 0.0 | 506.0 |
| HIS SHOTS BY HIS RUN | 17.0 | +150.3 | 0.0 | 26.7 | 29.3 | +896.1 | 0.0 | 276.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +51.6 | 94.3 | 78.3 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 0.0 | 16.7 | +0.0 | 0.0 | 765.3 |
| HOLDER ASSIGNMENT | 9.3 | +751.8 | 0.0 | 0.0 | 8.3 | +587.7 | 0.0 | 191.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -141.5 | 408.3 | 26.7 | 4.3 | -110.5 | 175.3 | 146.7 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +73.1 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +65.9 | 0.0 | 10.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +82.1 | 33.3 | 10.0 |
| IDLE COST | - | - | - | - | 11.3 | -159.0 | 0.0 | 15.0 |
| JOINT CHARGE NOW | 0.3 | +76.0 | 143.3 | 0.0 | 1.7 | +112.9 | 55.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +81.8 | 0.0 | 0.0 | 1.0 | +16.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.3 | +0.0 | 362.0 | 0.0 | 9.3 | +0.0 | 26.7 | 73.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | -0.2 | 288.7 | 26.7 | 3.0 | +11.5 | 88.7 | 38.3 |
| MAKE SURE TOGETHER | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -0.5 | 0.0 | 0.0 | 2.0 | +8.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | +4.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.0 | +44.9 | 0.0 | 0.0 | 3.0 | +79.8 | 0.0 | 43.3 |
| MEETS IN TIME | 3.7 | +208.2 | 0.0 | 0.0 | 2.0 | +143.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +60.6 | 0.0 | 0.0 | 4.0 | +67.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +29.9 | 0.0 | 0.0 | 4.7 | +50.2 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 12.7 | +878.0 | 0.0 | 0.0 | 13.3 | +947.4 | 0.0 | 326.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.0 | +414.1 | 0.0 | 54.3 | 6.3 | +294.4 | 0.0 | 219.7 |
| NEXT CHARGE BY LIST | 10.0 | +644.9 | 0.0 | 0.0 | 8.7 | +694.2 | 0.0 | 316.7 |
| NO CHAFF EDGES | 2.3 | +38.8 | 95.3 | 0.0 | 1.3 | +76.1 | 26.7 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -122.0 | 408.3 | 26.7 | 4.3 | -153.8 | 81.0 | 96.7 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 2.0 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -90.2 | 0.0 | 0.0 | 5.3 | -162.3 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.3 | -4.2 | 68.3 | 0.0 | 1.0 | +26.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 8.0 | -282.6 | 0.0 | 0.0 | 6.0 | -133.0 | 0.0 | 15.0 |
| ONE JOINT FIGURE | 0.7 | +12.8 | 143.3 | 0.0 | 1.0 | +26.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -46.5 | 0.0 | 0.0 | 5.0 | -7.6 | 0.0 | 191.3 |
| ONE PROMISE A TARGET | 0.3 | -14.6 | 0.0 | 0.0 | 1.3 | -14.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 2.3 | +10.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +10.6 | 27.7 | 0.0 |
| OPENS UP IN FULL | 0.7 | +3.4 | 67.0 | 0.0 | 1.0 | +41.3 | 54.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +32.2 | 60.0 | 68.3 |
| PATHS CROSS | - | - | - | - | 0.3 | +10.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -18.5 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +776.4 | 210.3 | 268.7 | 41.7 | +312.5 | 230.0 | 903.7 |
| PROMISE BY ITS OWN SUM | 17.7 | -723.6 | 0.0 | 0.0 | 12.3 | -253.4 | 0.0 | 10.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3.3 | -0.6 | 0.0 | 0.0 | 6.7 | -12.6 | 0.0 | 296.7 |
| PROMISE READS THE TABLE | 1.0 | -83.7 | 0.0 | 0.0 | 0.7 | -7.6 | 0.0 | 0.0 |
| QUARTER ODDS | 24.3 | +3330.5 | 135.3 | 26.7 | 20.3 | +2200.1 | 26.7 | 48.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +137.9 | 0.0 | 170.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +18.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +216.7 | 0.0 | 26.7 | 4.0 | +377.3 | 0.0 | 68.3 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 1.7 | +31.8 | 0.0 | 76.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 68.3 |
| REFORMS TO MEET IT | 4.0 | -149.2 | 0.0 | 0.0 | 1.7 | -29.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 27.7 | 1.0 | +0.0 | 0.0 | 68.3 |
| RISK BY ARC | 3.0 | +129.6 | 408.3 | 26.7 | 4.7 | +117.1 | 175.3 | 175.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -1.2 | 67.0 | 0.0 | 1.3 | -33.1 | 82.0 | 0.0 |
| RUN DOWN | 2.0 | -69.0 | 193.3 | 26.7 | 3.3 | -37.2 | 82.0 | 68.3 |
| SAME CHARGE LATER | 1.0 | -41.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +82.8 | 123.7 | 0.0 | 0.7 | +11.7 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +180.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -52.3 | 0.0 | 26.7 | 1.0 | -58.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +38.9 | 143.3 | 26.7 | 2.7 | +30.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +13.4 | 0.0 | 0.0 | 1.0 | +11.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 93.3 | 5.0 | +0.0 | 0.0 | 28.3 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +17.7 | 0.0 | 0.0 | 2.0 | +189.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.7 | 48.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 12.0 | -77.7 | 0.0 | 26.7 | 13.3 | -109.2 | 0.0 | 162.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.7 | +457.1 | 0.0 | 93.3 | 1.0 | +26.0 | 0.0 | 28.3 |
| SPELL WORTH | 1.7 | +26.2 | 0.0 | 0.0 | 1.0 | +2.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +5.7 | 0.0 | 0.0 | 0.7 | +1.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 210.3 |
| STAND AND SHOOT | - | - | - | - | 2.0 | -24.8 | 147.7 | 146.7 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 34.7 | +0.0 | 495.3 | 160.0 | 18.0 | +0.0 | 0.0 | 221.3 |
| STAY WORTH | 18.7 | +87.4 | 274.7 | 200.0 | 2.3 | +6.5 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +0.3 | 33.3 | 10.0 |
| STRIKE BY THE ODDS | 0.3 | +0.4 | 143.3 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +686.4 | 0.0 | 0.0 | 6.0 | +358.8 | 0.0 | 96.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 66.7 | 26.7 | 0.7 | +0.0 | 33.3 | 10.0 |
| SUPPORT WORKED OUT | 5.7 | +686.4 | 0.0 | 0.0 | 6.0 | +358.8 | 0.0 | 96.0 |
| SURE REACH TOGETHER | 2.7 | +35.2 | 0.0 | 0.0 | 3.0 | +45.7 | 0.0 | 28.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE FIGHT MOVES | 1.3 | +38.4 | 210.3 | 0.0 | 2.0 | +15.6 | 27.7 | 28.3 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 121.0 | 36.7 | +0.0 | 0.0 | 269.7 |
| TIED UP BY THE SUM | 1.7 | +154.2 | 129.7 | 26.7 | 1.3 | +117.7 | 54.3 | 68.3 |
| TIME ON OUR SIDE | 37.3 | +485.8 | 30.0 | 81.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +4.6 | 68.3 | 0.0 | 2.0 | -21.0 | 0.0 | 68.3 |
| WHO HITS BACK | 1.0 | +245.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -170.7 | 0.0 | 0.0 | 2.3 | -254.8 | 0.0 | 56.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +11.1 | 27.7 | 0.0 |
| WHOLE FIGHT REACTION | 4.7 | +714.4 | 243.3 | 147.7 | 1.3 | +154.1 | 26.7 | 125.0 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.3 | +12.9 | 0.0 | 0.0 | 0.7 | +39.5 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 129 | 129 | 73 | 24.33 | -437 | -6.0 |
| FIVE ACTION | 482 | 447 | 58 | 19.33 | +3002 | +51.8 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +2695 | +53.9 |
| LEGAL CHARGES ONLY | 50 | 50 | 50 | 16.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 90 | 90 | 42 | 14.00 | -2931 | -69.8 |
| MOVE TO CHARGE COMPUTED | 78 | 61 | 32 | 10.67 | +1240 | +38.7 |
| QUARTER ODDS | 134 | 126 | 31 | 10.33 | +2995 | +96.6 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -758 | -26.1 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 139 | 126 | 26 | 8.67 | +212 | +8.1 |
| HIS SHOT LIST | 117 | 109 | 25 | 8.33 | +317 | +12.7 |
| DEPLOY BY FIGURES | 38 | 38 | 23 | 7.67 | +208 | +9.0 |
| NEXT CHARGE BY LIST | 56 | 50 | 20 | 6.67 | +877 | +43.8 |
| SUPPORT ADDS | 35 | 35 | 16 | 5.33 | +794 | +49.6 |
| SUPPORT WORKED OUT | 35 | 35 | 16 | 5.33 | +794 | +49.6 |
| COVER ONCE | 56 | 39 | 13 | 4.33 | +480 | +36.9 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| GOAL WALK | 39 | 39 | 12 | 4.00 | +536 | +44.6 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CAST JOB | 14 | 14 | 10 | 3.33 | +8 | +0.8 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +760 | +84.4 |
| FOUR ROUNDS | 28 | 25 | 9 | 3.00 | +506 | +56.2 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 34 | 26 | 8 | 2.67 | +87 | +10.9 |
| MEETS IN TIME | 17 | 17 | 8 | 2.67 | +423 | +52.9 |
| NO CHAFF EDGES | 11 | 10 | 8 | 2.67 | +295 | +36.8 |
| PROMISE KNOWS THE FIGHT | 30 | 23 | 8 | 2.67 | -39 | -4.9 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +82 | +10.3 |
| TIME ON OUR SIDE | 112 | 88 | 8 | 2.67 | +44 | +5.5 |
| BACKS UP THE FIGHT | 10 | 10 | 7 | 2.33 | +8 | +1.2 |
| CHARGE NOW FIRST | 18 | 18 | 7 | 2.33 | -465 | -66.4 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 7 | 2.33 | +414 | +59.1 |
| RISK BY ARC | 23 | 20 | 7 | 2.33 | +178 | +25.5 |
| TIED UP BY THE SUM | 9 | 9 | 7 | 2.33 | +177 | +25.3 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +566 | +94.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +295 | +49.2 |
| MAX FOR POSITIONING | 18 | 18 | 6 | 2.00 | +36 | +6.0 |
| SHOT RISK POINTS | 76 | 64 | 6 | 2.00 | +64 | +10.7 |
| STAY WORTH | 63 | 58 | 6 | 2.00 | +69 | +11.5 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -88 | -17.5 |
| SURE REACH TOGETHER | 17 | 14 | 5 | 1.67 | +34 | +6.7 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PROMISE READS THE TABLE | 5 | 5 | 4 | 1.33 | -77 | -19.4 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +284 | +70.9 |
| THE ROW IN ITS ORDER | 24 | 4 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +220 | +73.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 3 | 1.00 | +88 | +29.4 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +13 | +4.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS IN THE MOVE | 38 | 31 | 3 | 1.00 | +109 | +36.3 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +609 | +203.2 |
| WHOLE FIGHT REACTION | 18 | 18 | 3 | 1.00 | +38 | +12.7 |
| WOUNDS ON THE RANKS | 9 | 9 | 3 | 1.00 | +70 | +23.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 61 | 47 | 2 | 0.67 | +4 | +1.9 |
| HIS CHARGE DENIED | 4 | 3 | 2 | 0.67 | +69 | +34.3 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +115 | +57.4 |
| MISSILES IN THE MOVE | 22 | 13 | 2 | 0.67 | +63 | +31.4 |
| NEARER NOT NEEDED | 49 | 46 | 2 | 0.67 | +30 | +15.1 |
| OPENS UP IN FULL | 5 | 4 | 2 | 0.67 | +58 | +29.1 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -63 | -31.3 |
| REDIRECT COUNTER | 16 | 16 | 2 | 0.67 | +400 | +200.1 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +347 | +173.4 |
| SET UP BY THE SET | 15 | 14 | 2 | 0.67 | +172 | +85.9 |
| SHOTS AFTER THE MOVES | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +119 | +119.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +35 | +34.7 |
| CHARGE LOSSES | 56 | 52 | 1 | 0.33 | +41 | +40.7 |
| EXACT ROUND | 18 | 18 | 1 | 0.33 | +0 | +0.1 |
| FEATURE BUFFS | 8 | 8 | 1 | 0.33 | +4 | +4.3 |
| FIGHT TO THE END | 8 | 6 | 1 | 0.33 | +15 | +14.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +40 | +40.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +25 | +25.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| MISSILES NEXT TURN | 24 | 16 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 23 | 20 | 1 | 0.33 | +6 | +6.1 |
| ONE OBJECTIVE FORMULA | 25 | 19 | 1 | 0.33 | +7 | +7.0 |
| OPENS A LANE | 7 | 6 | 1 | 0.33 | +7 | +7.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +80 | +80.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +30 | +30.4 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.33 | -7 | -6.7 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -67 | -67.2 |
| WHOLE FIGHT GAIN | 2 | 1 | 1 | 0.33 | +15 | +14.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 6 | 6 | 0 | 0.00 | - | - |
| CHALLENGE IN THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 75 | 71 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 17 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 24 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 9 | 9 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 15 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 37 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 32 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 11 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 17 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 93 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 22 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 4 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 15 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 4 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 7 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 23 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 5 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 238 | trace | - | - | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 17 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 14 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 158 | 148 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 11 | 9 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE FIGHT MOVES | 10 | 8 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 230 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 7 | 7 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 13 | 13 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 9.00 | 5.00 | 69.8 |
| ARMY TABLE | rule | 6.67 | 3.33 | 69.0 |
| JOB FIRST | gate | 3.67 | 3.33 | 30.4 |
| CHARGE NOW FIRST | rule | 1.00 | 1.33 | 66.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 1.33 | 6.4 |
| ONE PROMISE A TARGET | rule | 0.33 | 1.00 | 21.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 31.2 |
| PROMISE READS THE TABLE | rule | 1.00 | - | 26.3 |
| RULE SWITCHED OFF | gate | - | 1.00 | 28.0 |
| JOINT CHARGE NOW | rule | - | 0.67 | 27.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 31.3 |
| AFTERMATH BAND | gate | - | 0.33 | 2.5 |
| FALLBACK | gate | - | 0.33 | 8.6 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 9.7 |
| MARCH OF THE TABLE | rule | - | 0.33 | 1.0 |
| NO REASON | gate | 0.33 | - | 14.6 |
| REFUSING RETIRES | rule | 0.33 | - | 6.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 67.2 |

### Plans: chf-efd8067-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 89% | 380 | 324 | 85% |
| Mine | move | 27.0 | 98% | 2203 | 0 | 0% |
| Mine | shoot | 7.7 | 48% | 586 | 453 | 77% |
| Opponent | charge | 5.0 | 47% | 449 | 312 | 70% |
| Opponent | join | 4.7 | 93% | 216 | 0 | 0% |
| Opponent | move | 29.3 | 94% | 1596 | 0 | 0% |
| Opponent | shoot | 2.3 | 0% | 85 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Packages: hunt the guns, chf-efd8067-p45

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 246 | 198 | 100% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.5 | 1 | 0 | 100% | 100% | 0% | 2.0 | 246 | 198 | 100% | 0 |

### Battle groups: chf-efd8067-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 75% | 100% | 67% | 50% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 25% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.0 | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 112 (2) | 19 | 94 | 100 | 0% | 1.5 | 225 (1) | 0 (1) | - | 225 (1) | 0 (1) |
| Mine | Character | 8 | 64 (8) | 64 | 0 | 0 | 12% | 3.0 | 46 (3) | 93 (4) | 0 (1) | 61 (5) | 69 (3) |
| Mine | Clean-up | 1 | 194 (1) | 96 | 98 | 0 | 0% | 4.0 | 194 (1) | - | - | 194 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 0 | 0% | 2.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Hammer | 3 | 7 (3) | 7 | 0 | 0 | 0% | 2.3 | - | 7 (3) | - | 0 (1) | 9 (2) |
| Mine | Shooter | 6 | 44 (6) | 0 | 44 | 12 | 0% | 2.3 | 0 (2) | 82 (4) | - | 69 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 37 (5) | 37 | 0 | 56 | 40% | 2.7 | 0 (2) | 67 (3) | - | 0 (1) | 44 (4) |
| Opponent | Character | 10 | 11 (10) | 11 | 0 | 37 | 0% | 3.5 | 13 (3) | 21 (4) | 0 (1) | 9 (6) | 19 (2) |
| Opponent | Clean-up | 1 | 148 (1) | 0 | 148 | 0 | 100% | - | - | 148 (1) | - | - | 148 (1) |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 61 | 17% | 3.0 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 36 | 60% | 1.5 | 59 (3) | 0 (2) | - | 46 (4) | 0 (1) |
| Opponent | Holder | 4 | 12 (4) | 0 | 12 | 46 | 75% | 4.0 | 0 (1) | 17 (3) | - | 0 (1) | 17 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.5 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: chf-efd8067-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 286 | 693 | 2.0 | 1.0 | 346 | 0 | +346 | 1 of 2 | 2 of 2 | - | +346 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 405 | 5.0 | 1.0 | 81 | 20 | +61 | 0 of 5 | 4 of 5 | - | +61 |
| Mine | Lizardmen | 1 | 0 | 783 | 5.0 | 1.0 | 157 | 0 | +157 | 1 of 5 | 4 of 5 | - | +157 |
| **Mine** | all armies | 3 | 95 | 627 | 4.0 | 1.0 | 157 | 8 | +148 | 2 of 12 | 10 of 12 | - | +148 |
| Opponent | Vampire Counts | 1 | 0 | 83 | 4.0 | 1.2 | 21 | 0 | +21 | 2 of 4 | 1 of 4 | +83 | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 90 | 3.5 | 1.1 | 26 | 33 | -7 | 5 of 7 | 4 of 7 | +0 | -8 |
| **Opponent** | all armies | 3 | 0 | 88 | 3.7 | 1.2 | 24 | 21 | +3 | 7 of 11 | 5 of 11 | +42 | -5 |

### Effective charges: chf-efd8067-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +0) | 0 | 0 | 0 | 0 | 2 (net +118) | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 5 | 0 | 0 | 0 | 1 (net +0) | 1 (net +45) | 0 | 3 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 (net +83) | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Warriors of Chaos | 7 | 3 (net +5) | 0 | 1 (net +0) | 0 | 1 (net +80) | 1 (net +0) | 1 | 17% (1 of 6) |

### Charged fights, damage counted: chf-efd8067-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 275 | 205 | +0 | 17 | 0 | +17 | +6.2 |
| Mine | 76-89% | 1 | 185 | 186 | +0 | 0 | 37 | -37 | -20.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 147 | 118 | +118 | 118 | 0 | +118 | +79.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 175 | 45 | +45 | 45 | 0 | +45 | +25.7 |
| Mine | No odds | 6 | 331 | 165 | +250 | 270 | 36 | +234 | +70.7 |
| Mine | All fights | 12 | 266 | 156 | +148 | 161 | 21 | +140 | +52.7 |
| Opponent | Long shot (under 50%) | 4 | 126 | 310 | +4 | 25 | 21 | +4 | +3.0 |
| Opponent | 50-54% | 1 | 186 | 185 | +0 | 22 | 0 | +22 | +12.1 |
| Opponent | Effective (55-75%) | 1 | 116 | 432 | +0 | 96 | 0 | +96 | +82.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 454 | 286 | +0 | 0 | 36 | -36 | -8.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 508 | 82 | +82 | 82 | 0 | +82 | +16.1 |
| Opponent | No odds | 1 | 116 | 432 | -144 | 58 | 221 | -164 | -141.2 |
| Opponent | All fights | 11 | 259 | 275 | +3 | 40 | 34 | +5 | +2.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p45 | move | 28 | 3 (11%) | 3 (11%) | 5 (18%) | 20 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

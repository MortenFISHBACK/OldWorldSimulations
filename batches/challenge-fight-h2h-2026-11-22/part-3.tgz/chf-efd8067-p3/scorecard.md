# Doctrine scorecard: chf-efd8067-p3

### Scorecard: chf-efd8067-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 9 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 588 |
| L0421 | 1 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 500 |
| L0508 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 613 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 877 |
| **Average** | | | Mine | 0% | 6.3 | 2.0 | 2.3 | 2.0 | 0.0 | 0.0 | 0.0 | 204.3 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 655.0 |

### KPIs: chf-efd8067-p3

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 100% (5 of 5) | 31% (5 of 16) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | 33% (2 of 6) | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 17% (2 of 12) | 33% (2 of 6) | 22% (4 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 86% (5135 of 5998) | 92% (5549 of 5999) | 89% (10684 of 11997) |
|   infantry points that never fought | lower | 87% (1239 of 1424) | 100% (1703 of 1703) | 94% (2942 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 65% (17 of 26) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (1 of 1); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3286 of 5120) | 69% (3205 of 4677) | 66% (6491 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (50%) | 1.3 (100%) | 3.0 (64%) |
| MARCHED: its unit marched | 1.3 (40%) | 0.0 (0%) | 1.3 (29%) |
| CHARGED: its unit charged | 0.3 (10%) | 0.0 (0%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.0 | 1.3 | 1.3 | 0.0 |
| not cast | 3.0 | 4.0 | 4.7 | 2.7 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (75%) | 3.0 (64%) | 1.0 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 1.3 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.3 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (100%) | 1.0 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (41 of 77) | 79% (89 of 112) | 69% (130 of 189) |
|   cavalry | 50% (6 of 12) | 42% (5 of 12) | 46% (11 of 24) |
|   character | 85% (11 of 13) | 92% (22 of 24) | 89% (33 of 37) |
|   chariot | 32% (7 of 22) | 64% (9 of 14) | 44% (16 of 36) |
|   infantry | 33% (4 of 12) | 60% (9 of 15) | 48% (13 of 27) |
|   war machine | 72% (13 of 18) | 94% (44 of 47) | 88% (57 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (33%) | 0.3 (4%) | 4.3 (22%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (9%) | 0.7 (3%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (36%) | 2.3 (30%) | 6.7 (34%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (25%) | 3.3 (43%) | 6.3 (32%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.7 | 88% | 1.9 pts | 10 pts |
| character | 11.0 | 4.3 | 73% | 11.5 pts | 126 pts |
| chariot | 5.3 | 3.0 | 81% | 16.3 pts | 87 pts |
| infantry | 8.0 | 3.3 | 71% | 13.4 pts | 107 pts |
| war machine | 19.0 | 20.7 | 53% | 22.6 pts | 429 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 0.3 | 1.2 |
| Charges that made contact a game | 0.7 | 0.0 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.09 contact (22 units) | 0.04 declared, 0.00 contact (24 units) | 0.13 declared, 0.04 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 0% (0 of 1) | - | 0% (0 of 4) |
| Character in a unit | 100% (8 of 8) | 100% (2 of 2) | 100% (1 of 1) | 100% (11 of 11) |
| Character on its own | 100% (4 of 4) | 0% (0 of 2) | 100% (2 of 2) | 75% (6 of 8) |
| Chariot | 0% (0 of 2) | 80% (4 of 5) | - | 57% (4 of 7) |
| Infantry | 50% (4 of 8) | 60% (3 of 5) | 100% (1 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 50% (2 of 4) | - | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 78% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 98% | 86% (12 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 82% | 56% (5 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: chf-efd8067-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 25% (1 of 4) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (18 of 28) | 57% (32 of 56) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 0% (0 of 10) |
| Strategy | Lone characters that fought | 25% (2 of 8) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 3.3 |
| Movement | Points that never moved of their own | 204.3 | 655.0 |
| Movement | Fights charged into per game | 0.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +95 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (13 of 28) | 62% (28 of 45) |
| Shooting | Points destroyed by shooting units | 118.3 | 103.3 |
| Shooting | War machine shots | 4.3 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 15% (2 of 13) | 61% (27 of 44) |
| Shooting | Points destroyed by war machines | 103.3 | 239.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | - | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.7 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 31.7 | 21.7 |
| Combat | Points run down | 39.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +150 | - |
| Combat | Net per 100 charger points, damage counted | +44.1 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +120 | - |
| Combat | Net points per supported fight / lone fight | - / +120 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | - |
| Game | Points lost | 362.3 | 425.7 |
| Game | VP from objectives | 926.7 | 790.0 |
| Game | Lone holders (player turns) | 6.3 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +146 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 788
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.7 | +322.3 | 0.0 | 0.0 | 12.3 | +123.9 | 0.0 | 43.3 |
| ARTILLERY RE-ROLL WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 31.7 |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 45.0 | 0.0 | 1.3 | +0.0 | 116.7 | 0.0 |
| CANNON PLANNED TARGET | 4.3 | +75.2 | 281.7 | 158.3 | 14.7 | +504.0 | 418.7 | 146.7 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -25.9 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +38.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.7 | -1092.0 | 0.0 | 196.0 | 9.7 | -215.5 | 0.0 | 118.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 198.3 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 70.0 |
| COVER ONCE | 5.0 | -256.0 | 0.0 | 103.3 | 4.0 | -661.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +9.9 | 0.0 | 31.7 | 9.0 | -42.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +56.3 | 70.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +23.3 | 101.7 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 39.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.1 | 31.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 12.0 | +167.6 | 0.0 | 103.3 | 6.0 | +117.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.7 | +5685.6 | 1148.3 | 746.0 | 99.7 | +5224.0 | 980.7 | 933.3 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 125.0 | 4.3 | +0.0 | 0.0 | 39.0 |
| FOLLOW UP WEIGHED | 0.3 | +56.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +60.0 | 101.7 | 0.0 | 0.3 | +115.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -43.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 12.0 | +1335.8 | 0.0 | 43.3 | 4.7 | +324.9 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +18.0 | 48.3 | 103.3 | 1.3 | +42.1 | 0.0 | 21.7 |
| GUN MASK | 1.3 | -10.9 | 0.0 | 0.0 | 0.7 | +39.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.7 | +0.0 | 0.0 | 103.3 | 1.7 | +0.0 | 0.0 | 118.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS MOVE AND SHOT | 0.7 | -0.1 | 0.0 | 0.0 | 4.3 | -47.6 | 0.0 | 48.3 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 6.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 52.0 | +2430.9 | 0.0 | 282.7 | 42.7 | +1002.3 | 0.0 | 311.7 |
| HIS SHOTS BY HIS RUN | 38.3 | +706.1 | 0.0 | 326.0 | 26.7 | +707.3 | 0.0 | 208.3 |
| HIS TURN DENIED | 0.7 | +21.8 | 31.7 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.3 | +895.2 | 0.0 | 0.0 | 10.3 | +920.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -70.8 | 101.7 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 1.3 | +292.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 10.0 | -161.6 | 0.0 | 89.7 | 4.0 | -32.4 | 0.0 | 65.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +55.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 39.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -18.1 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.2 | 70.0 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +18.3 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +99.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +56.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +56.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | -35.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.3 | +112.1 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 2.7 | +296.6 | 0.0 | 0.0 | 4.3 | +181.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +50.7 | 0.0 | 0.0 | 1.7 | +22.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +51.1 | 0.0 | 0.0 | 1.3 | +10.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| MOVE SPELL IN RANGE | 3.0 | +46.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.0 | -218.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +430.2 | 0.0 | 103.3 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +213.9 | 0.0 | 0.0 | 5.7 | +243.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.3 | +362.3 | 0.0 | 103.3 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 0.7 | -63.1 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 2.3 | +100.8 | 31.7 | 0.0 | 0.7 | +2.1 | 0.0 | 96.7 |
| NO DOUBLE ROUNDS | 2.0 | -18.8 | 101.7 | 0.0 | 0.3 | -78.4 | 0.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 39.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -252.5 | 0.0 | 95.0 | 1.0 | -33.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -124.4 | 0.0 | 103.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 1.7 | +63.3 | 0.0 | 0.0 | 4.3 | -43.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.7 | +69.6 | 31.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +66.0 | 70.0 | 0.0 | - | - | - | - |
| OWN CAST FIRST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +513.0 | 444.0 | 437.7 | 46.7 | +975.8 | 288.7 | 686.3 |
| PRIZE BY WORTH | 0.3 | +73.8 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.7 | -254.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.0 | +2586.8 | 463.3 | 0.0 | 31.7 | +2177.0 | 0.0 | 301.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +37.7 | 0.0 | 333.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +40.8 | 0.0 | 21.7 | 0.7 | +20.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.7 | +25.1 | 39.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | -162.8 | 101.7 | 0.0 | 0.3 | -2.5 | 0.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -1.4 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | 0.3 | -0.4 | 0.0 | 0.0 | 0.3 | -18.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +111.6 | 70.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -70.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +12.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.3 | +63.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 158.3 | 18.7 | +0.0 | 0.0 | 185.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +106.5 | 193.3 | 0.0 | 2.0 | +29.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -7.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 29.3 | +364.8 | 0.0 | 282.7 | 24.3 | +167.7 | 0.0 | 295.0 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.3 | +477.4 | 0.0 | 261.7 | 27.0 | +1084.3 | 0.0 | 256.7 |
| SPELL WORTH | 0.3 | +0.4 | 0.0 | 0.0 | 2.7 | +12.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 166.7 |
| STANDS FOR A REASON | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 39.7 | +0.0 | 1046.7 | 420.0 | 66.7 | +0.0 | 980.7 | 636.7 |
| STAY WORTH | 29.0 | +565.3 | 766.7 | 681.7 | 40.3 | +447.7 | 588.7 | 490.0 |
| STRONG ENOUGH TO HOLD | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 0.7 | +36.1 | 0.0 | 0.0 | 0.7 | +40.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 0.7 | +36.1 | 0.0 | 0.0 | 0.7 | +40.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +22.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | -0.0 | 70.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 43.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 43.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 373.0 | 47.7 | +0.0 | 0.0 | 289.7 |
| TIED UP BY THE SUM | 1.3 | +154.3 | 31.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 14.7 | +207.1 | 0.0 | 21.7 | 31.7 | +311.8 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.7 | +0.0 | 193.3 | 103.3 | - | - | - | - |
| WHO HITS BACK | 0.3 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 6.0 | -235.6 | 0.0 | 0.0 | 0.3 | -6.6 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 0.3 | +10.9 | 0.0 | 0.0 | 2.0 | +62.0 | 0.0 | 31.7 |
| WOUNDS ON THE RANKS | 2.0 | +292.8 | 0.0 | 0.0 | 5.7 | +127.3 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 284 | 279 | 56 | 18.67 | +1025 | +18.3 |
| HOLDER ASSIGNMENT | 59 | 59 | 56 | 18.67 | +2759 | +49.3 |
| ARMY TABLE | 90 | 90 | 54 | 18.00 | +692 | +12.8 |
| HIS SHOTS BY HIS RUN | 195 | 188 | 38 | 12.67 | +453 | +11.9 |
| SHOT RISK POINTS | 161 | 160 | 36 | 12.00 | +1338 | +37.2 |
| DEPLOY BY FIGURES | 53 | 53 | 29 | 9.67 | +502 | +17.3 |
| ARTILLERY RE-ROLL WEIGHED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 139 | 120 | 21 | 7.00 | +84 | +4.0 |
| GOAL WALK | 50 | 50 | 19 | 6.33 | +1064 | +56.0 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -857 | -47.6 |
| QUARTER ODDS | 179 | 178 | 16 | 5.33 | +853 | +53.3 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| IDLE COST | 42 | 34 | 12 | 4.00 | +72 | +6.0 |
| FIVE ACTION | 583 | 574 | 11 | 3.67 | +713 | +64.8 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 57 | 57 | 10 | 3.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 16 | 14 | 9 | 3.00 | +505 | +56.1 |
| PROMISE BY ITS OWN SUM | 23 | 23 | 9 | 3.00 | -764 | -84.9 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +437 | +54.6 |
| STAY WORTH | 208 | 184 | 8 | 2.67 | +155 | +19.4 |
| WOUNDS ON THE RANKS | 23 | 23 | 8 | 2.67 | +173 | +21.6 |
| CHARGE LOSSES | 88 | 87 | 7 | 2.33 | +307 | +43.9 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 13 | 12 | 7 | 2.33 | +505 | +72.1 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 121 | 84 | 6 | 2.00 | +390 | +65.0 |
| WHOLE FIGHT DANGER | 19 | 19 | 6 | 2.00 | +72 | +12.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 27 | 22 | 4 | 1.33 | +5 | +1.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +165 | +41.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +300 | +74.9 |
| NO CHAFF EDGES | 9 | 7 | 4 | 1.33 | +100 | +25.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +113 | +28.3 |
| SET UP BY THE SET | 4 | 4 | 4 | 1.33 | -64 | -16.1 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 4 | 1.33 | +148 | +36.9 |
| FALLS SHORT | 54 | 43 | 3 | 1.00 | +56 | +18.7 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +55 | +18.4 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +300 | +100.1 |
| WHOLE FIGHT REACTION | 7 | 7 | 3 | 1.00 | +52 | +17.4 |
| CAST JOB | 3 | 3 | 2 | 0.67 | +4 | +2.2 |
| FOUR ROUNDS | 7 | 5 | 2 | 0.67 | +158 | +79.0 |
| GUN MASK | 6 | 6 | 2 | 0.67 | +33 | +16.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -170 | -85.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +335 | +167.4 |
| SHOTS AFTER THE MOVES | 23 | 23 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 4 | 4 | 2 | 0.67 | +9 | +4.7 |
| SUPPORT WORKED OUT | 4 | 4 | 2 | 0.67 | +9 | +4.7 |
| SURE REACH TOGETHER | 3 | 3 | 2 | 0.67 | +22 | +10.8 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -78 | -77.7 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +30 | +30.5 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +171 | +170.6 |
| HIS MOVE AND SHOT | 15 | 15 | 1 | 0.33 | +0 | +0.2 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +57 | +57.2 |
| HUNT IN PAIRS | 4 | 4 | 1 | 0.33 | +147 | +147.3 |
| LEGAL CHARGES ONLY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +28 | +28.1 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -144 | -144.3 |
| MAX FOR POSITIONING | 10 | 8 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 7 | 5 | 1 | 0.33 | +30 | +30.5 |
| ONE FIGHT FORMULA | 16 | 10 | 1 | 0.33 | +2 | +1.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -8 | -7.7 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +55 | +54.7 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -11 | -10.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +222 | +221.5 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +68 | +68.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +29 | +28.9 |
| RISK BY ARC | 6 | 4 | 1 | 0.33 | +30 | +30.5 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 2 | 1 | 0.33 | +15 | +15.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 27 | 27 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 31 | 31 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 4 | 4 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 7 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 18 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH CHECK | 2 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 9 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| NEARER NOT NEEDED | 32 | 30 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 18 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 5 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 1 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 22 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 319 | 314 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE FIGHT MOVES | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 277 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 1.00 | 48.2 |
| ARMY TABLE | rule | 4.67 | 0.33 | 46.7 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | - | 84.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 23.1 |
| MARCH OF THE TABLE | rule | 0.67 | - | 85.1 |
| SET UP BY THE SET | rule | 0.67 | - | 115.7 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 77.7 |
| MARCH ODDS | rule | 0.33 | - | 144.3 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 7.7 |
| OWN CAST FIRST | rule | 0.33 | - | 10.6 |
| RULE SWITCHED OFF | gate | 0.33 | - | 38.0 |

### Plans: chf-efd8067-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 199 | 102 | 51% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 30.7 | 97% | 1654 | 0 | 0% |
| Mine | shoot | 8.7 | 54% | 589 | 411 | 70% |
| Opponent | charge | 0.3 | 0% | 68 | 0 | 0% |
| Opponent | join | 2.7 | 100% | 92 | 0 | 0% |
| Opponent | move | 27.7 | 93% | 1281 | 0 | 0% |
| Opponent | shoot | 16.0 | 73% | 805 | 976 | 121% |

### Battle groups: chf-efd8067-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 16 (11) | 16 | 0 | 13 | 18% | 3.3 | 23 (5) | 0 (2) | 23 (3) | 0 (6) | 34 (4) |
| Mine | Clean-up | 2 | 150 (2) | 0 | 150 | 0 | 50% | 2.0 | 150 (2) | - | - | 150 (2) | - |
| Mine | Hammer | 8 | 27 (8) | 16 | 11 | 20 | 25% | 2.5 | 0 (2) | 33 (6) | - | 55 (5) | 0 (3) |
| Mine | Holder | 5 | 47 (5) | 0 | 47 | 22 | 80% | 6.0 | 36 (2) | 54 (3) | - | 108 (1) | 30 (4) |
| Mine | Shooter | 1 | 54 (1) | 0 | 54 | 0 | 0% | 1.0 | 54 (1) | - | - | - | 54 (1) |
| Mine | War machine | 5 | 65 (5) | 65 | 0 | 60 | 0% | 1.0 | 46 (4) | 142 (1) | - | - | 65 (5) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Character | 13 | 0 (13) | 0 | 0 | 10 | 46% | 2.6 | 0 (9) | 0 (3) | 0 (1) | 0 (9) | 0 (4) |
| Opponent | Clean-up | 2 | 66 (2) | 0 | 66 | 0 | 100% | - | - | 66 (2) | - | 66 (2) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 8 | 44 (8) | 28 | 16 | 27 | 25% | 2.0 | 87 (3) | 16 (2) | 18 (3) | 44 (8) | - |
| Opponent | Holder | 3 | 95 (3) | 0 | 95 | 0 | 100% | - | - | 147 (2) | 0 (1) | 130 (1) | 80 (2) |
| Opponent | Shooter | 4 | 73 (4) | 0 | 73 | 26 | 25% | 1.7 | - | 73 (4) | - | 73 (4) | - |
| Opponent | War machine | 9 | 72 (9) | 72 | 0 | 49 | 11% | 1.0 | 72 (9) | - | - | 0 (1) | 84 (8) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: chf-efd8067-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 178 | 152 | 1.0 | 1.0 | 152 | 32 | +120 | 1 of 2 | 2 of 2 | - | +120 |
| Mine | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 222 | 102 | 0.7 | 1.0 | 152 | 32 | +120 | 1 of 2 | 2 of 2 | - | +120 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 578 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 342 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: chf-efd8067-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 95 | +95 | 95 | 0 | +95 | +28.0 |
| Mine | No odds | 1 | 339 | 210 | +145 | 318 | 113 | +204 | +60.2 |
| Mine | All fights | 2 | 339 | 152 | +120 | 206 | 57 | +150 | +44.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p3 | move | 14 | 3 (21%) | 1 (7%) | 1 (7%) | 10 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

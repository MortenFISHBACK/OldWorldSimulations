# Doctrine scorecard: chf-efd8067-p6

### Scorecard: chf-efd8067-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 13 | 3 | 1 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 117 |
| L0930 | 6 | 1 | Opponent | no | 7 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 7 | 3 | 2 | 0 | 1 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 500 |
| **Average** | | | Mine | 0% | 3.0 | 3.0 | 0.7 | 1.0 | 0.3 | 0.0 | 0.0 | 234.0 |
| **Average** | | | Opponent | 0% | 6.7 | 2.5 | 1.3 | 2.3 | 0.7 | 0.0 | 0.0 | 213.3 |

### KPIs: chf-efd8067-p6

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 57% (8 of 14) | 0% (0 of 13) | 30% (8 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 38% (18 of 48) | 8% (1 of 12) | 32% (19 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (18 of 39) | 8% (1 of 12) | 37% (19 of 51) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 70% (7 of 10) | 70% (7 of 10) |
| Points that never fought | lower | 80% (4818 of 5997) | 85% (5112 of 5999) | 83% (9930 of 11996) |
|   infantry points that never fought | lower | 82% (1298 of 1591) | 83% (1375 of 1660) | 82% (2673 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (17 of 34) | 61% (14 of 23) | 54% (31 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 2.0 uses a game | 100% (2 of 2); 2.7 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2511 of 5667) | 59% (3029 of 5150) | 51% (5540 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (37%) | 2.7 (73%) | 6.3 (46%) |
| MARCHED: its unit marched | 3.0 (30%) | 1.0 (27%) | 4.0 (29%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| GONE: slain | 2.0 (20%) | 0.0 (0%) | 2.0 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.7 | 1.7 | 6.3 | 0.3 | 1.0 |
| not cast | 0.0 | 3.7 | 0.3 | 13.7 | 1.7 | 19.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (55%) | 0.0 (0%) | 6.3 (46%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 4.0 (29%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | - | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (18%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.7 (18%) | 0.0 (0%) | 2.0 (15%) | 0.0 (0%) | 1.0 (5%) |
| OFF THE TABLE: off the table or not arrived | - | 0.3 (9%) | 0.0 (0%) | 0.3 (2%) | 0.3 (20%) | 0.7 (4%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 75% (3 of 4) | 75% (3 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (78 of 119) | 72% (39 of 54) | 68% (117 of 173) |
|   character | 100% (10 of 10) | 44% (7 of 16) | 65% (17 of 26) |
|   chariot | 72% (13 of 18) | 40% (2 of 5) | 65% (15 of 23) |
|   infantry | 46% (21 of 46) | 86% (18 of 21) | 58% (39 of 67) |
|   monster | 60% (3 of 5) | - | 60% (3 of 5) |
|   war machine | 78% (31 of 40) | 100% (12 of 12) | 83% (43 of 52) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (29%) | 2.7 (53%) | 6.7 (36%) |
| CHARGED: it charged | 0.7 (5%) | 0.7 (13%) | 1.3 (7%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.3 (7%) | 1.0 (5%) |
| MOVED: a war machine that moved | 2.0 (15%) | 0.0 (0%) | 2.0 (11%) |
| NO TARGET IN RANGE | 1.7 (12%) | 1.0 (20%) | 2.7 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (27%) | 0.3 (7%) | 4.0 (21%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 7.3 | 1.7 | 77% | 6.3 pts | 46 pts |
| chariot | 5.0 | 3.7 | 53% | 36.2 pts | 181 pts |
| infantry | 17.0 | 9.7 | 63% | 10.2 pts | 173 pts |
| monster | 1.3 | 0.7 | 50% | 15.1 pts | 20 pts |
| war machine | 14.3 | 12.7 | 63% | 26.2 pts | 375 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.7 | 1.5 |
| Charges that made contact a game | 0.7 | 1.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.22 declared, 0.13 contact (23 units) | 0.16 declared, 0.12 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 100% (6 of 6) | 100% (2 of 2) | 100% (1 of 1) | 100% (9 of 9) |
| Character on its own | 100% (1 of 1) | 25% (1 of 4) | 33% (1 of 3) | 38% (3 of 8) |
| Chariot | 67% (2 of 3) | 0% (0 of 2) | - | 40% (2 of 5) |
| Infantry | 21% (3 of 14) | 75% (3 of 4) | - | 33% (6 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 42% (10 of 24) | 88% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 33% (8 of 24) | 65% | 30% (3 of 10) | 50% (1 of 2); 6.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 88% | 38% (3 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 77% | 78% (7 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 91% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (12 of 47) | 78% (18 of 23) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 7) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 25% (1 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 234.0 | 213.3 |
| Movement | Fights charged into per game | 0.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 2, net +229 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (30 of 47) | 76% (22 of 29) |
| Shooting | Points destroyed by shooting units | 98.7 | 117.3 |
| Shooting | War machine shots | 10.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (15 of 31) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 333.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | - |
| Magic | Wounds caused by magic missiles | 7.7 | 1.3 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 102.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 0.3 / 0.0 | 2.3 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 215.3 |
| Combat | Points run down | 0.0 | 110.3 |
| Combat | Net points per charged fight, damage counted | +15 | +94 |
| Combat | Net per 100 charger points, damage counted | +11.1 | +47.7 |
| Combat | First round won (charged fights) | 50% | 100% |
| Combat | Net points per charged fight | +0 | +169 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +169 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 0 of 3 |
| Game | Points lost | 508.0 | 604.3 |
| Game | VP from objectives | 900.0 | 763.3 |
| Game | Lone holders (player turns) | 3.0 | 6.7 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +141 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1112
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: chf-efd8067-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +12.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 17.0 | +184.0 | 0.0 | 151.3 | 33.7 | +489.4 | 0.0 | 269.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +6.5 | 0.0 | 0.0 | 1.3 | +41.3 | 0.0 | 65.3 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 151.3 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +424.7 | 328.3 | 83.3 | 4.0 | +163.9 | 352.0 | 0.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.0 | +32.2 | 298.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 133.3 |
| CHAFF PASSED | 1.3 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.0 | -541.8 | 0.0 | 220.7 | 34.7 | -1981.0 | 0.0 | 1248.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 75.7 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 151.3 | 9.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +379.0 | 266.7 | 266.7 |
| COVER ONCE | 10.3 | -699.4 | 0.0 | 110.3 | 4.3 | -223.9 | 0.0 | 43.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -13.4 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +4.6 | 0.0 | 41.7 | 7.0 | +32.4 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +8.2 | 21.7 | 0.0 | 0.7 | +4.6 | 41.7 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +9.4 | 21.7 | 0.0 | 1.0 | +20.0 | 110.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.7 | +348.8 | 0.0 | 286.7 |
| FEATURE BUFFS | 3.3 | +49.7 | 0.0 | 0.0 | 2.7 | +48.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.2 | 0.0 | 0.0 | 0.3 | +2.9 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 41.7 | 0.0 |
| FIVE ACTION | 97.3 | +8940.8 | 2835.3 | 868.0 | 97.7 | +5955.3 | 1378.0 | 2084.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 75.7 | 5.7 | +0.0 | 0.0 | 246.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +6.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +59.0 | 21.7 | 0.0 | 1.3 | +120.1 | 152.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -12.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.0 | -32.8 | 0.0 | 0.0 | 0.7 | -70.6 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -6.7 | 21.7 | 0.0 | 0.3 | -4.9 | 34.7 | 0.0 |
| GOAL WALK | 9.0 | +428.0 | 0.0 | 151.3 | 14.3 | +2048.5 | 0.0 | 0.0 |
| GUN FIGURES | 3.0 | +280.1 | 452.7 | 0.0 | 2.7 | +45.8 | 164.7 | 86.7 |
| GUN MASK | 5.0 | +187.6 | 0.0 | 0.0 | 2.0 | +61.6 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | -0.3 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 220.7 | 16.3 | +0.0 | 0.0 | 931.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 83.3 | 3.7 | +0.0 | 0.0 | 58.3 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 159.7 |
| HIS MOVE AND SHOT | 6.7 | -101.8 | 0.0 | 0.0 | 9.0 | -155.7 | 0.0 | 231.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 310.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 159.7 |
| HIS RANDOM MOVE | 13.7 | +0.0 | 0.0 | 246.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +908.4 | 0.0 | 701.3 | 79.0 | +7354.9 | 0.0 | 2035.7 |
| HIS SHOTS BY HIS RUN | 36.0 | +845.1 | 0.0 | 550.0 | 62.0 | +2627.5 | 0.0 | 1569.7 |
| HIS TURN DENIED | 0.3 | +27.1 | 21.7 | 0.0 | 0.7 | +99.1 | 76.3 | 0.0 |
| HOLD ODDS | 28.7 | +0.0 | 0.0 | 0.0 | 25.0 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 16.0 | +1429.6 | 0.0 | 0.0 | 14.3 | +1461.1 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -40.3 | 21.7 | 0.0 | 1.3 | -51.2 | 152.0 | 0.0 |
| IDLE COST | - | - | - | - | 13.0 | -269.7 | 0.0 | 478.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 6.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.1 | 0.0 | 0.0 | 0.7 | +37.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 0.0 | 123.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +1.0 | 0.0 | 0.0 | 0.7 | +0.2 | 34.7 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +41.4 | 0.0 | 0.0 | 2.7 | +48.6 | 0.0 | 159.7 |
| MANOEUVRE | 2.7 | +27.5 | 0.0 | 0.0 | 3.0 | +31.0 | 0.0 | 54.3 |
| MARCH AT ESCAPER | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +64.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 4.0 | +192.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.4 | 0.0 | 0.0 | 0.3 | +91.2 | 0.0 | 133.3 |
| MARCH OVER CASTS | 2.0 | +47.3 | 0.0 | 0.0 | 0.7 | +153.0 | 0.0 | 266.7 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.0 | +161.7 | 0.0 | 0.0 | 3.3 | +55.4 | 0.0 | 159.7 |
| MEETS IN TIME | 3.7 | +429.5 | 0.0 | 0.0 | 2.7 | +345.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.3 | +271.5 | 0.0 | 0.0 | 3.3 | +153.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 13.3 | +232.9 | 0.0 | 123.0 | 5.0 | +101.6 | 0.0 | 133.3 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 133.3 |
| MOVE TO CHARGE COMPUTED | 3.7 | +204.4 | 0.0 | 0.0 | 4.7 | +353.9 | 0.0 | 225.0 |
| NEARER NOT NEEDED | 9.7 | +456.3 | 0.0 | 34.7 | 10.3 | +461.4 | 0.0 | 65.3 |
| NEXT CHARGE BY LIST | 3.7 | +204.4 | 0.0 | 0.0 | 4.3 | +338.3 | 0.0 | 65.3 |
| NO CHAFF EDGES | 1.3 | +66.6 | 40.0 | 0.0 | 1.3 | +23.0 | 75.7 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -33.4 | 0.0 | 0.0 | 1.3 | -54.2 | 152.0 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.0 | -160.9 | 0.0 | 0.0 | 4.3 | -204.4 | 0.0 | 76.0 |
| OGRE LOADER SECOND SHOT | 0.3 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -104.9 | 0.0 | 0.0 | 5.7 | -138.7 | 0.0 | 159.7 |
| ONE OBJECTIVE FORMULA | 7.3 | +25.2 | 0.0 | 0.0 | 5.3 | +147.3 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -10.0 | 0.0 | 65.3 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +12.5 | 21.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.7 | +25.0 | 21.7 | 0.0 | 0.3 | +10.5 | 75.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +17.7 | 21.7 | 0.0 | 1.0 | +41.1 | 152.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -13.7 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +764.6 | 573.0 | 709.0 | 44.0 | +611.4 | 420.0 | 1160.3 |
| PRIZE BY WORTH | 0.3 | +4.3 | 0.0 | 0.0 | 0.3 | +6.1 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -158.0 | 0.0 | 0.0 | 5.3 | -120.8 | 0.0 | 159.7 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.7 | +0.0 | 0.0 | 225.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -10.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 15.7 | +1652.8 | 1080.0 | 83.3 | 19.3 | +1540.4 | 647.0 | 380.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +240.7 | 0.0 | 333.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 0.7 | +37.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 18.3 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -26.1 | 21.7 | 0.0 | 1.3 | -115.7 | 152.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -7.6 | 41.7 | 0.0 |
| RUN DOWN | 0.7 | -12.9 | 0.0 | 0.0 | 1.3 | -7.5 | 152.0 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +49.5 | 0.0 | 0.0 | 1.0 | +35.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -72.1 | 0.0 | 98.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +26.2 | 0.0 | 98.0 |
| SET UP TOGETHER | 1.0 | +41.4 | 0.0 | 0.0 | 2.7 | +48.6 | 0.0 | 159.7 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.0 | +0.0 | 0.0 | 83.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 7.0 | +710.9 | 1316.0 | 0.0 | 2.3 | +213.0 | 151.3 | 0.0 |
| SHOT RISK POINTS | 16.3 | -324.3 | 0.0 | 550.0 | 47.7 | +550.6 | 0.0 | 1954.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.7 | +2165.1 | 0.0 | 311.0 | 14.7 | +703.7 | 0.0 | 246.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +96.9 | 266.7 | 266.7 |
| SPOT AS THE GAME MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 394.3 |
| STAND AND SHOOT | 0.3 | -11.5 | 21.7 | 0.0 | 0.7 | -4.3 | 110.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 319.3 |
| STANDS STILL | 50.3 | +0.0 | 2813.7 | 373.0 | 36.0 | +0.0 | 1226.0 | 584.0 |
| STAY WORTH | 35.7 | -97.8 | 491.7 | 166.7 | 21.0 | +502.2 | 1074.7 | 43.3 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +2.8 | 20.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +238.4 | 0.0 | 0.0 | 7.7 | +144.2 | 0.0 | 156.0 |
| SUPPORT WORKED OUT | 5.7 | +238.4 | 0.0 | 0.0 | 7.7 | +144.2 | 0.0 | 156.0 |
| SURE REACH TOGETHER | 0.7 | +10.9 | 0.0 | 0.0 | 0.7 | +19.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +2.1 | 34.7 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 75.7 | 8.0 | +0.0 | 0.0 | 61.7 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 50.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 72.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 392.3 | 46.0 | +0.0 | 0.0 | 875.3 |
| TIED UP BY THE SUM | 0.3 | +27.9 | 21.7 | 0.0 | 0.7 | +103.6 | 110.3 | 0.0 |
| TIME ON OUR SIDE | 36.0 | +539.8 | 0.0 | 570.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 32.7 |
| WAR ENGINE CHARGES | 0.7 | +23.8 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -4.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +40.6 | 0.0 | 0.0 | 0.3 | +54.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -71.7 | 0.0 | 69.3 | 3.3 | -278.4 | 0.0 | 81.0 |
| WHOLE FIGHT REACTION | 1.3 | +162.8 | 0.0 | 110.3 | 1.3 | +40.6 | 0.0 | 21.7 |
| WOUNDS ON THE RANKS | 2.0 | +34.0 | 0.0 | 0.0 | 2.0 | +78.3 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 152 | 152 | 108 | 36.00 | +2333 | +21.6 |
| HIS SHOT LIST | 340 | 325 | 88 | 29.33 | +3921 | +44.6 |
| HOLDER ASSIGNMENT | 91 | 91 | 82 | 27.33 | +4585 | +55.9 |
| HIS SHOTS BY HIS RUN | 294 | 282 | 65 | 21.67 | +1781 | +27.4 |
| SHOT RISK POINTS | 192 | 183 | 41 | 13.67 | +2026 | +49.4 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -1095 | -35.3 |
| DEPLOY BY FIGURES | 46 | 46 | 29 | 9.67 | +567 | +19.6 |
| GOAL WALK | 70 | 70 | 24 | 8.00 | +1891 | +78.8 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 24 | 8.00 | +1088 | +45.3 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| FIVE ACTION | 585 | 569 | 21 | 7.00 | +812 | +38.7 |
| MOVE TO CHARGE COMPUTED | 25 | 25 | 19 | 6.33 | +684 | +36.0 |
| NEXT CHARGE BY LIST | 24 | 24 | 17 | 5.67 | +614 | +36.1 |
| TIME ON OUR SIDE | 108 | 86 | 13 | 4.33 | +75 | +5.8 |
| SHOTS IN THE MOVE | 130 | 96 | 12 | 4.00 | +1343 | +111.9 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 11 | 3.67 | -837 | -76.0 |
| CHARGE LOSSES | 152 | 144 | 9 | 3.00 | +544 | +60.4 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 105 | 102 | 9 | 3.00 | +706 | +78.4 |
| STAY WORTH | 170 | 151 | 9 | 3.00 | +105 | +11.7 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MARCH CHECK | 12 | 11 | 8 | 2.67 | +257 | +32.1 |
| CAST JOB | 9 | 9 | 7 | 2.33 | +9 | +1.3 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1246 | +177.9 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 7 | 2.33 | +722 | +103.1 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 44 | 30 | 6 | 2.00 | +152 | +25.3 |
| IDLE COST | 39 | 30 | 6 | 2.00 | +53 | +8.8 |
| NO CHAFF EDGES | 8 | 8 | 6 | 2.00 | +200 | +33.3 |
| SHOTS AFTER THE MOVES | 24 | 24 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 8 | 8 | 5 | 1.67 | +136 | +27.2 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MANOEUVRE | 17 | 17 | 5 | 1.67 | +197 | +39.4 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +760 | +152.1 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +256 | +51.2 |
| SUPPORT ADDS | 40 | 39 | 5 | 1.67 | +111 | +22.3 |
| SUPPORT WORKED OUT | 40 | 39 | 5 | 1.67 | +111 | +22.3 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -7 | -1.8 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| GUN MASK | 21 | 21 | 4 | 1.33 | +184 | +46.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +147 | +36.7 |
| NEARER NOT NEEDED | 60 | 54 | 4 | 1.33 | +134 | +33.4 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +547 | +136.8 |
| THE ROW IN ITS ORDER | 28 | 4 | 4 | 1.33 | +0 | +0.0 |
| BACKS UP THE FIGHT | 6 | 6 | 3 | 1.00 | +49 | +16.4 |
| FALL BACK GOOD ORDER | 7 | 7 | 3 | 1.00 | +42 | +14.2 |
| FALLS SHORT | 77 | 55 | 3 | 1.00 | +72 | +23.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +192 | +64.0 |
| MAX FOR POSITIONING | 25 | 21 | 3 | 1.00 | +2 | +0.8 |
| ONE OBJECTIVE FORMULA | 38 | 26 | 3 | 1.00 | +132 | +44.1 |
| SET UP BY THE SET | 8 | 8 | 3 | 1.00 | +166 | +55.4 |
| SURE REACH TOGETHER | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -37 | -18.4 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +18 | +9.1 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +80 | +39.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -275 | -137.4 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -30 | -15.0 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +31 | +15.5 |
| PROMISE READS THE TABLE | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.2 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +78 | +39.2 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.67 | +16 | +8.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +192 | +96.0 |
| WHOLE FIGHT REACTION | 8 | 8 | 2 | 0.67 | +61 | +30.6 |
| WOUNDS ON THE RANKS | 12 | 10 | 2 | 0.67 | +49 | +24.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +37 | +37.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 40 | 40 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 18 | 18 | 1 | 0.33 | +20 | +20.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 47 | 45 | 1 | 0.33 | +32 | +32.1 |
| HONEST WORTH | 8 | 8 | 1 | 0.33 | +4 | +3.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 38 | 28 | 1 | 0.33 | +14 | +13.5 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| ONE FIGHT FORMULA | 31 | 18 | 1 | 0.33 | +74 | +74.0 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +26 | +26.3 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -6 | -6.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| REDIRECT COUNTER | 2 | 1 | 1 | 0.33 | +51 | +51.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -28 | -28.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| RISK BY ARC | 7 | 7 | 1 | 0.33 | +26 | +25.6 |
| RUN DOWN | 6 | 6 | 1 | 0.33 | +4 | +3.5 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 24 | 22 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 47 | 47 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 17 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 73 | 70 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 31 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 41 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 161 | 161 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 55 | 40 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 11 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 69 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 45 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 259 | 249 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 24 | not checked | - | - | - | - |
| THE TABLE BINDS | 269 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 3.67 | 34.9 |
| ARMY TABLE | rule | 1.67 | 3.33 | 77.2 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.33 | 76.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.67 | 23.9 |
| CHAFF PASSED | rule | 1.33 | - | 1.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 18.4 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 137.4 |
| NO REASON | gate | - | 0.67 | 36.0 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 15.0 |
| OWN CAST FIRST | rule | 0.33 | - | 6.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 41.0 |
| REFUSING RETIRES | rule | - | 0.33 | 28.0 |
| RULE SWITCHED OFF | gate | 0.33 | - | 46.6 |

### Plans: chf-efd8067-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 72 | 33 | 46% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 29.3 | 95% | 2302 | 0 | 0% |
| Mine | shoot | 12.0 | 50% | 822 | 732 | 89% |
| Opponent | charge | 1.0 | 100% | 75 | 121 | 162% |
| Opponent | move | 36.0 | 94% | 2169 | 0 | 0% |
| Opponent | shoot | 7.0 | 62% | 821 | 490 | 60% |

### Battle groups: chf-efd8067-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 26 (10) | 26 | 0 | 39 | 30% | 2.7 | 43 (4) | 0 (5) | 0 (1) | 33 (6) | 12 (4) |
| Mine | Clean-up | 3 | 93 (3) | 0 | 93 | 0 | 67% | 3.0 | - | 67 (2) | 143 (1) | 93 (3) | - |
| Mine | Fast Hammer | 3 | 64 (3) | 31 | 32 | 0 | 67% | 2.0 | 46 (2) | - | 107 (1) | 64 (3) | - |
| Mine | Hammer | 6 | 73 (6) | 73 | 0 | 32 | 50% | 1.3 | 35 (2) | 91 (4) | - | 107 (4) | 0 (2) |
| Mine | Shooter | 6 | 111 (6) | 0 | 111 | 17 | 0% | 1.3 | 58 (2) | 115 (3) | 202 (1) | 115 (5) | 87 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 35 | 0% | 1.6 | - | 0 (3) | 17 (5) | - | 11 (8) |
| Mine | Wizard | 4 | 41 (4) | 41 | 0 | 25 | 0% | 2.8 | 0 (1) | 163 (1) | 0 (1) | 82 (2) | 0 (1) |
| Opponent | Chaff | 2 | 120 (2) | 0 | 120 | 44 | 100% | - | - | 120 (2) | - | 214 (1) | 0 (1) |
| Opponent | Character | 8 | 26 (8) | 26 | 0 | 39 | 50% | 2.0 | 47 (1) | 10 (4) | 93 (1) | 28 (5) | 37 (1) |
| Opponent | Clean-up | 2 | 232 (2) | 0 | 232 | 0 | 100% | - | - | 232 (2) | - | 232 (2) | - |
| Opponent | Fast Hammer | 6 | 55 (6) | 0 | 55 | 25 | 83% | 3.0 | - | 41 (4) | 96 (2) | 78 (5) | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 5 | 76 (5) | 72 | 3 | 56 | 20% | 2.8 | - | 104 (2) | 57 (3) | 51 (4) | 177 (1) |
| Opponent | Holder | 4 | 23 (4) | 0 | 23 | 0 | 75% | 3.0 | - | 32 (3) | - | 0 (1) | 47 (2) |
| Opponent | Shooter | 4 | 48 (4) | 48 | 0 | 28 | 0% | 1.8 | - | 0 (1) | 56 (3) | 48 (4) | - |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | - | - | - |

### Charged fights: chf-efd8067-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 564 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 475 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 3 | 534 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Opponent | High Elf Realms | 1 | 352 | 229 | 1.0 | 1.0 | 229 | 0 | +229 | 0 of 1 | 1 of 1 | - | +229 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 277 | 2.0 | 1.0 | 138 | 0 | +138 | 0 of 2 | 2 of 2 | - | +138 |
| **Opponent** | all armies | 3 | 117 | 169 | 1.0 | 1.0 | 169 | 0 | +169 | 0 of 3 | 3 of 3 | - | +169 |

### Effective charges: chf-efd8067-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +229) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 135 | 112 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 135 | 112 | +0 | 69 | 39 | +30 | +22.3 |
| Mine | All fights | 2 | 135 | 112 | +0 | 34 | 19 | +15 | +11.1 |
| Opponent | Long shot (under 50%) | 1 | 173 | 189 | +0 | 65 | 12 | +54 | +31.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 104 | +229 | 444 | 491 | -48 | -19.3 |
| Opponent | No odds | 1 | 173 | 189 | +277 | 277 | 0 | +277 | +160.1 |
| Opponent | All fights | 3 | 198 | 161 | +169 | 262 | 168 | +94 | +47.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p6 | move | 22 | 1 (5%) | 1 (5%) | 4 (18%) | 17 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

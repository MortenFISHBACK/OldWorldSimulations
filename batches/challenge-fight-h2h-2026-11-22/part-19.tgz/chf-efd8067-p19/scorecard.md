# Doctrine scorecard: chf-efd8067-p19

### Scorecard: chf-efd8067-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 1 | 0 | 0 | 287 |
| **Average** | | | Mine | 50% | 2.0 | 2.7 | 1.3 | 1.0 | 0.0 | 0.0 | 0.0 | 220.0 |
| **Average** | | | Opponent | 50% | 0.5 | 3.5 | 0.3 | 3.0 | 0.3 | 0.0 | 0.0 | 95.7 |

### KPIs: chf-efd8067-p19

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (6 of 15) | 0% (0 of 10) | 24% (6 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | - | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 78% (7 of 9); on the table 89% | - | 78% (7 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 18% (13 of 72) | 33% (6 of 18) | 21% (19 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 27% (13 of 48) | 46% (6 of 13) | 31% (19 of 61) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 65% (3883 of 5998) | 64% (3845 of 6000) | 64% (7728 of 11998) |
|   infantry points that never fought | lower | 77% (559 of 730) | 68% (532 of 782) | 72% (1091 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (14 of 25) | 65% (17 of 26) | 61% (31 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 5.0 uses a game | 50% (1 of 2); 0.3 uses a game | 78% (7 of 9); 2.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (3104 of 5614) | 71% (3997 of 5644) | 63% (7101 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (24%) | 0.3 (8%) | 5.0 (21%) |
| MARCHED: its unit marched | 6.0 (31%) | 0.0 (0%) | 6.0 (25%) |
| CHARGED: its unit charged | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |
| IN COMBAT: engaged in combat | 4.3 (22%) | 0.0 (0%) | 4.3 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (42%) | 1.7 (7%) |
| GONE: slain | 3.7 (19%) | 0.0 (0%) | 3.7 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (42%) | 1.7 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (8%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 2.7 | 1.3 | 6.3 | 0.0 | 3.3 |
| not cast | 1.0 | 13.3 | 4.7 | 23.7 | 4.0 | 24.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 6.0 (45%) | 0.3 (7%) | 5.0 (21%) | 1.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.0 (25%) | 1.0 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) | 0.7 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 4.3 (18%) | 1.0 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (15%) | 2.0 (43%) | 1.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 2.7 (20%) | 0.0 (0%) | 3.7 (15%) | 0.0 (0%) | 3.0 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (12%) | 1.7 (36%) | 1.7 (7%) | 0.0 (0%) | 3.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (100%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 50% (2 of 4) | 50% (2 of 4) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (30 of 47) | 60% (53 of 88) | 61% (83 of 135) |
|   cavalry | - | 82% (18 of 22) | 82% (18 of 22) |
|   character | - | 50% (6 of 12) | 50% (6 of 12) |
|   chariot | 67% (8 of 12) | 67% (8 of 12) | 67% (16 of 24) |
|   infantry | 78% (7 of 9) | 37% (11 of 30) | 46% (18 of 39) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 58% (15 of 26) | - | 58% (15 of 26) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (18%) | 2.3 (20%) | 3.3 (19%) |
| CHARGED: it charged | 0.7 (12%) | 1.0 (9%) | 1.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.3 (3%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (18%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.0 (43%) | 5.0 (29%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 1.3 (11%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 2.0 (35%) | 0.0 (0%) | 2.0 (12%) |
| STUPIDITY | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 1.3 (11%) | 1.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.7 | 1.3 | 85% | 2.6 pts | 22 pts |
| character | 2.0 | 1.3 | 67% | 25.5 pts | 51 pts |
| chariot | 5.3 | 5.0 | 56% | 24.4 pts | 130 pts |
| infantry | 8.0 | 2.3 | 71% | 5.4 pts | 43 pts |
| monster | 3.7 | 1.3 | 73% | 13.5 pts | 49 pts |
| war machine | 6.0 | 4.7 | 72% | 13.4 pts | 80 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 1.7 | 3.2 |
| Charges that made contact a game | 3.0 | 1.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.00 contact (6 units) | - | 1.33 declared, 1.00 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.00 contact (1 units) | - | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.22 contact (9 units) | 0.19 declared, 0.12 contact (26 units) | 0.26 declared, 0.14 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | - | 75% (3 of 4) | 60% (6 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| Character on its own | 100% (1 of 1) | 50% (4 of 8) | 60% (3 of 5) | 57% (8 of 14) |
| Chariot | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Infantry | 38% (3 of 8) | - | - | 38% (3 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 78% (7 of 9); on the table 89% | 18% (13 of 72) | 65% | 56% (14 of 25) | 86% (6 of 7); 5.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 86% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 49% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 100% (6 of 6) | 57% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 20% (1) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 54% (7 of 13) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (8 of 33) | 82% (18 of 22) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 67% (6 of 9) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 3.0 |
| Movement | Points that never moved of their own | 220.0 | 95.7 |
| Movement | Fights charged into per game | 2.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +428 | 1 of 2, net +192 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 7, net +62 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 7 | 1 of 2, net +165 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +79 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (8 of 15) | 48% (26 of 54) |
| Shooting | Points destroyed by shooting units | 11.3 | 105.0 |
| Shooting | War machine shots | 6.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (9 of 18) | - |
| Shooting | Points destroyed by war machines | 34.0 | 123.0 |
| Magic | Magic missiles cast | 2.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 2.0 | 2.0 |
| Magic | Wounds caused by other spells | 3.3 | - |
| Magic | Points destroyed by magic (all spells) | 164.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.3 / 1.0 / 0.0 | 1.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 294.7 | 86.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +118 | +108 |
| Combat | Net per 100 charger points, damage counted | +40.7 | +50.9 |
| Combat | First round won (charged fights) | 88% | 33% |
| Combat | Net points per charged fight | +127 | +108 |
| Combat | Net points per supported fight / lone fight | +428 / +84 | - / +108 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 8 | 0 of 3 |
| Game | Points lost | 402.0 | 806.7 |
| Game | VP from objectives | 1043.3 | 570.0 |
| Game | Lone holders (player turns) | 2.0 | 0.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +945 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1209
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +13.2 | 0.0 | 0.0 |
| ARMY TABLE | 6.0 | +40.0 | 0.0 | 64.7 | 26.0 | +186.3 | 0.0 | 332.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.3 | +6.7 | 0.0 | 0.0 | 1.3 | +33.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.5 | 0.0 | 50.0 | - | - | - | - |
| BOMBING RUN | 1.0 | +23.3 | 11.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +53.4 | 68.0 | 165.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -21.7 | 41.7 | 50.0 | - | - | - | - |
| CAST JOB | 4.7 | +61.5 | 52.3 | 246.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +12.3 | 0.0 | 0.0 | 0.3 | +3.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +23.7 | 0.0 | 11.3 |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 1.0 | -141.6 | 329.3 | 0.0 | 0.3 | -6.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 22.3 | -685.5 | 0.0 | 520.7 | 23.0 | -1027.9 | 0.0 | 907.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 37.0 | 0.0 | 0.7 | +0.0 | 55.0 | 0.0 |
| CLEAR LANE AHEAD | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 75.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +279.4 | 0.0 | 0.0 |
| COVER ONCE | 5.0 | -248.6 | 0.0 | 114.7 | 5.7 | -314.9 | 0.0 | 83.3 |
| DENIED BY THE FIGHT | 1.0 | -1.1 | 164.7 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | -83.3 | 0.0 | 110.0 | 7.3 | +61.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +148.4 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +36.3 | 310.3 | 50.0 | 1.0 | +17.1 | 110.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 4.0 | +1.3 | 577.7 | 50.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.0 | +60.5 | 0.0 | 123.0 | 12.0 | +118.7 | 0.0 | 119.0 |
| FEATURE BUFFS | 2.0 | +21.2 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.7 | +6.0 | 329.3 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 76.0 | +5403.0 | 989.0 | 1211.3 | 89.0 | +4587.0 | 1264.3 | 1040.3 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 117.3 |
| FOLLOW UP WEIGHED | 1.3 | +346.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +279.9 | 690.3 | 50.0 | 1.3 | +56.8 | 110.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 3.0 | -35.2 | 0.0 | 32.3 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 1.0 | +70.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.1 | 75.7 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| GOAL WALK | 5.3 | +965.5 | 0.0 | 246.0 | 11.7 | +1031.8 | 0.0 | 567.3 |
| GUN FIGURES | - | - | - | - | 2.3 | +0.0 | 123.0 | 0.0 |
| GUN MASK | 3.3 | +117.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.7 | -0.7 | 282.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 1.7 | +0.0 | 446.7 | 50.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 174.7 | 11.0 | +0.0 | 0.0 | 601.0 |
| HIS CHARGE DENIED | 0.3 | +6.4 | 164.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 64.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 329.3 |
| HIS MOVE AND SHOT | 5.3 | -54.1 | 0.0 | 64.7 | 8.3 | -51.4 | 0.0 | 118.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 110.0 | 1.3 | +0.0 | 0.0 | 27.3 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 100.0 | 2.0 | +0.0 | 0.0 | 329.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.3 | +1087.8 | 0.0 | 585.3 | 62.3 | +2495.2 | 0.0 | 1040.3 |
| HIS SHOTS BY HIS RUN | 31.0 | +916.1 | 0.0 | 585.3 | 47.3 | +1049.9 | 0.0 | 1040.3 |
| HIS TURN DENIED | 0.7 | +14.3 | 0.0 | 0.0 | 0.7 | +21.5 | 55.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 64.7 | 13.3 | +0.0 | 0.0 | 275.0 |
| HOLDER ASSIGNMENT | 10.3 | +883.6 | 0.0 | 64.7 | 9.7 | +1043.5 | 0.0 | 156.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -136.9 | 648.7 | 0.0 | 1.3 | -59.1 | 110.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +99.6 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 3.7 | -54.0 | 0.0 | 123.0 | 9.0 | -171.3 | 0.0 | 283.7 |
| JOINT CHARGE NOW | 2.3 | +202.8 | 598.0 | 50.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +37.9 | 0.0 | 0.0 | 0.3 | +25.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 269.3 | 32.3 | 4.3 | +0.0 | 0.0 | 648.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -1.3 | 0.0 | 0.0 | 0.3 | -6.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | +0.8 | 488.3 | 50.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +7.0 | 0.0 | 50.0 | - | - | - | - |
| MANOEUVRE | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +1.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +65.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +67.0 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +32.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.3 | +6.5 | 0.0 | 0.0 | 0.3 | +55.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +43.3 | 0.0 | 50.0 | 2.0 | +85.8 | 0.0 | 25.0 |
| MEETS IN TIME | 1.7 | +156.8 | 0.0 | 0.0 | 2.7 | +164.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.0 | +76.2 | 0.0 | 246.0 | 3.0 | +45.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.3 | +111.1 | 0.0 | 246.0 | 3.7 | +37.2 | 0.0 | 119.0 |
| MOVE ORDER | 2.3 | +0.0 | 32.3 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 3.7 | -228.4 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +574.5 | 0.0 | 100.0 | 2.0 | +181.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +156.5 | 0.0 | 64.7 | 7.0 | +285.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.7 | +520.4 | 11.3 | 0.0 | 3.0 | +199.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -15.8 | 0.0 | 64.7 | - | - | - | - |
| NO CHAFF EDGES | 4.0 | +86.7 | 282.3 | 0.0 | 1.0 | +62.9 | 142.3 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -124.2 | 285.3 | 50.0 | 1.3 | -29.9 | 110.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 0.7 | -17.5 | 0.0 | 0.0 | 6.0 | -201.0 | 0.0 | 41.7 |
| OGRE LOADER SECOND SHOT | 5.0 | +46.9 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -87.9 | 0.0 | 50.0 | 1.3 | -31.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 2.0 | +228.7 | 522.3 | 50.0 | 0.3 | +7.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -74.4 | 0.0 | 32.3 | 5.3 | -233.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -37.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 2.0 | +24.2 | 282.3 | 0.0 | 0.7 | +48.9 | 110.0 | 0.0 |
| OVERRUNS AWAY | 2.3 | +31.6 | 83.3 | 50.0 | 0.3 | +2.5 | 55.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 33.3 | +479.3 | 692.0 | 397.7 | 39.3 | +496.9 | 155.0 | 891.7 |
| PRIZE BY WORTH | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.3 | -93.1 | 0.0 | 100.0 | 4.7 | -81.7 | 0.0 | 83.3 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -3.5 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.0 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 2.7 | -12.1 | 101.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.3 | +2039.7 | 427.0 | 370.0 | 12.0 | +1069.8 | 410.0 | 413.3 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.0 | +121.2 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.7 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.0 | -90.5 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +20.8 | 0.0 | 0.0 | 0.7 | +14.2 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +7.3 | 374.3 | 50.0 | 1.0 | -22.4 | 55.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -10.1 | 55.0 | 0.0 |
| RUN DOWN | 3.7 | -41.1 | 285.3 | 50.0 | 1.0 | -3.4 | 110.0 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +8.2 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -49.7 | 0.0 | 11.3 |
| SEARCH SPOT | 0.7 | +4.2 | 0.0 | 0.0 | 1.0 | +33.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -3.1 | 0.0 | 32.3 | 2.0 | -125.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +6.9 | 0.0 | 32.3 | 2.0 | +126.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.7 | +9.2 | 0.0 | 50.0 | - | - | - | - |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +26.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.7 | +0.0 | 0.0 | 288.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +16.1 | 74.0 | 0.0 | 2.0 | +20.4 | 100.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -38.2 | 75.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 22.7 | -450.8 | 0.0 | 410.7 | 36.0 | -283.3 | 0.0 | 356.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +460.6 | 0.0 | 284.7 | 19.3 | +532.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +26.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +17.8 | 0.0 | 0.0 | 2.0 | +29.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.0 | +23.2 | 227.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 32.3 | 5.7 | +0.0 | 0.0 | 92.3 |
| STAND AND SHOOT | 1.0 | -8.0 | 37.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 246.0 | 3.7 | +0.0 | 32.3 | 0.0 |
| STANDS STILL | 34.7 | +0.0 | 298.7 | 750.7 | 38.7 | +0.0 | 1154.3 | 83.3 |
| STAY WORTH | 25.3 | +251.1 | 177.0 | 608.3 | 22.0 | +168.4 | 954.3 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +15.2 | 164.7 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -68.7 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +6.7 | 0.0 | 0.0 |
| STUBBORN ONCE | 0.3 | -0.2 | 164.7 | 0.0 | 0.3 | -8.8 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +73.9 | 0.0 | 0.0 | 7.0 | +266.0 | 0.0 | 106.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +73.9 | 0.0 | 0.0 | 7.0 | +266.0 | 0.0 | 106.0 |
| SURE REACH TOGETHER | 0.7 | +3.1 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +16.2 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 32.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.0 | +51.8 | 405.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 34.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 130.3 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.3 | +0.0 | 0.0 | 525.7 | 43.0 | +0.0 | 0.0 | 501.7 |
| TIED UP BY THE SUM | 0.7 | +48.3 | 37.0 | 0.0 | 0.3 | +41.9 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 19.0 | +321.7 | 74.0 | 187.7 | 37.0 | +314.5 | 110.0 | 11.3 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 83.3 |
| WAR ENGINE CHARGES | 0.3 | -35.8 | 41.7 | 50.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +0.8 | 41.7 | 50.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +51.0 | 0.0 | 0.0 | 0.3 | +64.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -124.8 | 0.0 | 110.0 | 3.7 | -461.3 | 0.0 | 601.0 |
| WHOLE FIGHT GAIN | 2.0 | +104.9 | 522.3 | 50.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.7 | +117.0 | 11.3 | 110.0 | 2.0 | +412.6 | 0.0 | 316.0 |
| WOUNDS ON THE RANKS | 11.3 | +265.3 | 0.0 | 0.0 | 3.3 | +87.1 | 0.0 | 402.7 |

### Rule changes: chf-efd8067-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 281 | 267 | 71 | 23.67 | +1507 | +21.2 |
| ARMY TABLE | 96 | 96 | 63 | 21.00 | +796 | +12.6 |
| HIS SHOTS BY HIS RUN | 235 | 223 | 54 | 18.00 | +1030 | +19.1 |
| HOLDER ASSIGNMENT | 60 | 60 | 54 | 18.00 | +3189 | +59.1 |
| FIVE ACTION | 495 | 478 | 27 | 9.00 | +1683 | +62.3 |
| LEGAL CHARGES ONLY | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 176 | 166 | 22 | 7.33 | +536 | +24.4 |
| DEPLOY BY FIGURES | 40 | 40 | 21 | 7.00 | +360 | +17.1 |
| GOAL WALK | 51 | 49 | 21 | 7.00 | +2851 | +135.8 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -656 | -32.8 |
| THE TABLE AGAIN | 35 | 35 | 20 | 6.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 168 | 149 | 20 | 6.67 | +79 | +3.9 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +141 | +9.4 |
| QUARTER ODDS | 85 | 81 | 15 | 5.00 | +1002 | +66.8 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 29 | 24 | 13 | 4.33 | +695 | +53.5 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 39 | 39 | 12 | 4.00 | -524 | -43.7 |
| CAST JOB | 14 | 14 | 9 | 3.00 | +63 | +6.9 |
| NEXT CHARGE BY LIST | 26 | 21 | 9 | 3.00 | +663 | +73.7 |
| NO CHAFF EDGES | 15 | 14 | 8 | 2.67 | +280 | +35.1 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 2.67 | -36 | -4.5 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHARGE LOSSES | 136 | 130 | 7 | 2.33 | +195 | +27.9 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +608 | +86.9 |
| MEETS IN TIME | 13 | 13 | 7 | 2.33 | +64 | +9.2 |
| IDLE COST | 38 | 25 | 6 | 2.00 | +109 | +18.2 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 6 | 2.00 | +27 | +4.4 |
| SUPPORT ADDS | 24 | 22 | 6 | 2.00 | +115 | +19.2 |
| SUPPORT WORKED OUT | 24 | 22 | 6 | 2.00 | +115 | +19.2 |
| WOUNDS ON THE RANKS | 44 | 44 | 6 | 2.00 | +113 | +18.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1038 | +207.6 |
| FOUR ROUNDS | 18 | 16 | 5 | 1.67 | +184 | +36.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +191 | +38.3 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +195 | +39.0 |
| SET UP BY THE SET | 11 | 11 | 5 | 1.67 | +196 | +39.1 |
| SHOTS AFTER THE MOVES | 22 | 22 | 5 | 1.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 32 | 18 | 4 | 1.33 | +99 | +24.7 |
| GUN MASK | 10 | 10 | 4 | 1.33 | +70 | +17.5 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 4 | 4 | 4 | 1.33 | +537 | +134.3 |
| MAX FOR POSITIONING | 16 | 15 | 4 | 1.33 | +5 | +1.2 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +105 | +26.2 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +122 | +30.5 |
| THE ROW IN ITS ORDER | 20 | 4 | 4 | 1.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 4 | 1.33 | -86 | -21.5 |
| BOMBING RUN | 3 | 3 | 3 | 1.00 | +70 | +23.3 |
| CASTING BLOCK | 3 | 3 | 3 | 1.00 | +25 | +8.5 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +3 | +1.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 1.00 | +213 | +70.9 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +98 | +32.5 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -97 | -32.4 |
| ONE JOINT FIGURE | 7 | 6 | 3 | 1.00 | +276 | +92.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +84 | +27.8 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +34 | +17.2 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +34 | +17.2 |
| HUNT IN PAIRS | 2 | 2 | 2 | 0.67 | +278 | +138.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MANOEUVRE | 16 | 16 | 2 | 0.67 | +23 | +11.5 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -113 | -56.5 |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 2 | 0.67 | -10 | -5.2 |
| PROMISE READS THE TABLE | 6 | 6 | 2 | 0.67 | +37 | +18.5 |
| REDIRECT COUNTER | 12 | 7 | 2 | 0.67 | +40 | +19.8 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +25 | +12.7 |
| RISK BY ARC | 13 | 11 | 2 | 0.67 | +32 | +16.2 |
| SCOUT BY DROPS | 8 | 8 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 94 | 76 | 2 | 0.67 | +33 | +16.3 |
| STAY WORTH | 142 | 132 | 2 | 0.67 | +18 | +9.2 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +52 | +25.9 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +300 | +149.9 |
| WHOLE FIGHT REACTION | 11 | 11 | 2 | 0.67 | +74 | +37.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +40 | +39.6 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -65 | -65.0 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -5 | -5.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 10 | 9 | 1 | 0.33 | +29 | +29.3 |
| FALLS SHORT | 60 | 51 | 1 | 0.33 | +11 | +11.4 |
| MISSILES IN THE MOVE | 27 | 20 | 1 | 0.33 | +4 | +3.7 |
| OPENS UP IN FULL | 8 | 7 | 1 | 0.33 | +51 | +51.0 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -6 | -5.6 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| SET UP TOGETHER | 5 | 3 | 1 | 0.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +46 | +45.6 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +20 | +20.0 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 6 | 5 | 1 | 0.33 | +97 | +96.8 |
| BACKS UP THE FIGHT | 5 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 15 | 15 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 45 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 12 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 13 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 6 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 41 | 41 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 16 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 48 | 33 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| NEARER NOT NEEDED | 32 | 30 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 13 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 35 | 35 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 17 | 8 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 32 | 29 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 35 | 35 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 8 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 218 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 55 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 31 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 220 | 209 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 7 | 6 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 229 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | not checked | - | - | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.67 | 5.33 | 25.7 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.67 | 43.7 |
| ARMY TABLE | rule | 0.33 | 3.00 | 19.2 |
| PROMISE SHOT AWAY | rule | 2.67 | - | 4.5 |
| JOINT CHARGE NOW | rule | 1.33 | - | 39.1 |
| WAR ENGINE JOBS | rule | 1.33 | - | 21.5 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 7.1 |
| MARCH OF THE TABLE | rule | 1.00 | - | 32.4 |
| NO REASON | gate | - | 0.67 | 96.2 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 56.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 5.2 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 65.0 |
| CHARGE NOW FIRST | rule | 0.33 | - | 5.2 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.33 | 3.7 |
| OWN CAST FIRST | rule | 0.33 | - | 5.6 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 3.3 |

### Plans: chf-efd8067-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 457 | 385 | 84% |
| Mine | move | 20.0 | 98% | 1671 | 0 | 0% |
| Mine | shoot | 10.3 | 16% | 478 | 94 | 20% |
| Opponent | charge | 1.0 | 0% | 165 | 4 | 2% |
| Opponent | move | 32.0 | 95% | 1396 | 0 | 0% |
| Opponent | shoot | 5.7 | 59% | 337 | 493 | 147% |
| Opponent | support | 0.7 | 50% | 1 | 0 | 0% |

### Battle groups: chf-efd8067-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.0 | 17% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 44 (12) | 44 | 0 | 16 | 25% | 3.2 | 0 (1) | 68 (8) | 0 (2) | 11 (7) | 87 (4) |
| Mine | Fast Hammer | 4 | 19 (4) | 10 | 9 | 15 | 50% | 1.0 | 35 (2) | 13 (2) | - | 30 (3) | 0 (1) |
| Mine | Holder | 5 | 128 (5) | 0 | 128 | 0 | 40% | 2.7 | - | 128 (5) | - | 209 (3) | 0 (2) |
| Mine | Shooter | 2 | 79 (2) | 18 | 62 | 50 | 0% | 1.5 | 124 (1) | 35 (1) | - | 79 (2) | - |
| Mine | War machine | 6 | 10 (6) | 10 | 0 | 50 | 17% | 1.0 | 0 (1) | 21 (3) | 0 (2) | 0 (1) | 12 (5) |
| Opponent | Chaff | 6 | 188 (6) | 0 | 188 | 41 | 67% | 3.5 | 0 (3) | 1250 (1) | 0 (2) | 265 (5) | 0 (1) |
| Opponent | Character | 7 | 17 (7) | 17 | 0 | 43 | 14% | 2.0 | 0 (1) | 23 (5) | - | 18 (4) | 21 (2) |
| Opponent | Clean-up | 3 | 49 (3) | 30 | 19 | 32 | 33% | 2.0 | - | 49 (3) | - | 47 (2) | 53 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 24 (4) | 0 | 24 | 75 | 25% | 1.7 | 171 (1) | 0 (1) | 0 (2) | 27 (3) | 0 (1) |
| Opponent | Hammer | 8 | 24 (8) | 24 | 0 | 16 | 25% | 2.3 | 61 (3) | 0 (1) | 0 (4) | 49 (4) | 0 (4) |
| Opponent | Holder | 1 | 135 (1) | 0 | 135 | 100 | 0% | 2.0 | - | 135 (1) | - | 135 (1) | - |
| Opponent | Shooter | 2 | 72 (2) | 60 | 12 | 0 | 0% | 2.0 | - | 136 (1) | 21 (1) | 72 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |

### Charged fights: chf-efd8067-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 210 | 339 | 2.7 | 1.1 | 127 | 0 | +127 | 2 of 8 | 7 of 8 | +428 | +84 |
| Opponent | Ogre Kingdoms | 1 | 534 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 150 | 357 | 2.0 | 1.0 | 178 | 0 | +178 | 0 of 2 | 1 of 2 | - | +178 |
| **Opponent** | all armies | 3 | 228 | 119 | 1.0 | 1.0 | 119 | 11 | +108 | 0 of 3 | 1 of 3 | - | +108 |

### Effective charges: chf-efd8067-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 8 | 1 (net +428) | 1 (net +227) | 2 (net +62) | 0 | 0 | 3 (net +79) | 1 | 29% (2 of 7) |
| Opponent | Wood Elf Realms | 2 | 1 (net +192) | 0 | 0 | 0 | 1 (net +165) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 713 | 494 | +428 | 675 | 143 | +532 | +74.6 |
| Mine | 50-54% | 1 | 379 | 127 | +227 | 227 | 0 | +227 | +59.9 |
| Mine | Effective (55-75%) | 2 | 192 | 188 | +62 | 77 | 112 | -35 | -18.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 203 | 113 | +79 | 96 | 11 | +85 | +41.9 |
| Mine | No odds | 1 | 233 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 8 | 290 | 182 | +127 | 168 | 50 | +118 | +40.7 |
| Opponent | Long shot (under 50%) | 1 | 102 | 171 | +192 | 192 | 0 | +192 | +188.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 165 | +165 | 165 | 0 | +165 | +33.1 |
| Opponent | No odds | 1 | 34 | 150 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 3 | 212 | 162 | +108 | 119 | 11 | +108 | +50.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p19 | move | 15 | 6 (40%) | 3 (20%) | 4 (27%) | 5 (33%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

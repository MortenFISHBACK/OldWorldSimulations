# Doctrine scorecard: chf-efd8067-p16

### Scorecard: chf-efd8067-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 735 |
| L0528 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 516 |
| L0616 | 4 | 1 | Opponent | no | 8 | 4 | 1 | 1 | 0 | 0 | 0 | 280 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 175 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 6 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.5 | 3.0 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 475.3 |
| **Average** | | | Opponent | 0% | 4.0 | 3.5 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 93.3 |

### KPIs: chf-efd8067-p16

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 13) | 48% (12 of 25) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (5 of 5); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 20% (1 of 5) | 20% (1 of 5) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 93% (5568 of 6000) | 88% (5258 of 5999) | 90% (10826 of 11999) |
|   infantry points that never fought | lower | 83% (1860 of 2232) | 91% (657 of 720) | 85% (2517 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 71% (15 of 21) | 73% (35 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (2847 of 4232) | 75% (4055 of 5415) | 72% (6902 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (60%) | 1.0 (60%) |
| MARCHED: its unit marched | - | 0.3 (20%) | 0.3 (20%) |
| GONE: slain | - | 0.3 (20%) | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 0.0 | 0.3 | 0.0 |
| not cast | 2.7 | 2.0 | 1.7 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (50%) | 1.0 (60%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.3 (12%) | 0.3 (17%) | 0.3 (20%) | 1.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (75%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (141 of 200) | 25% (8 of 32) | 64% (149 of 232) |
|   cavalry | 44% (8 of 18) | 30% (3 of 10) | 39% (11 of 28) |
|   character | 81% (26 of 32) | 0% (0 of 12) | 59% (26 of 44) |
|   infantry | 65% (33 of 51) | 0% (0 of 2) | 62% (33 of 53) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 76% (66 of 87) | 62% (5 of 8) | 75% (71 of 95) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (20%) | 2.7 (33%) | 6.7 (24%) |
| CHARGED: it charged | 2.0 (10%) | 0.3 (4%) | 2.3 (8%) |
| IN COMBAT: it fought this turn or the last | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET IN RANGE | 4.7 (24%) | 3.7 (46%) | 8.3 (30%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.0 (31%) | 0.7 (8%) | 6.7 (24%) |
| SHELTERED: the target was sheltered | 1.3 (7%) | 0.7 (8%) | 2.0 (7%) |
| OTHER BAR | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.7 | 58% | 9.3 pts | 37 pts |
| character | 8.7 | 6.3 | 62% | 16.9 pts | 147 pts |
| infantry | 21.3 | 9.3 | 66% | 11.6 pts | 248 pts |
| monster | 2.7 | 0.3 | 88% | 0.9 pts | 2 pts |
| war machine | 23.7 | 16.7 | 61% | 22.4 pts | 530 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 1.3 | 2.0 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.05 contact (21 units) | 0.20 declared, 0.10 contact (20 units) | 0.29 declared, 0.07 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 83% (5 of 6) | 0% (0 of 1) | - | 71% (5 of 7) |
| Character on its own | 100% (1 of 1) | 100% (4 of 4) | 75% (3 of 4) | 89% (8 of 9) |
| Infantry | 71% (5 of 7) | 50% (3 of 6) | - | 62% (8 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 0% (0 of 1); on the table 0% | - | 93% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 81% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 91% | 73% (11 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 20% (1 of 5) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 72% (61 of 85) | 0% (0 of 6) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 11% (1 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 475.3 | 93.3 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net -60 | 1 of 1, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (43 of 78) | 0% (0 of 3) |
| Shooting | Points destroyed by shooting units | 303.3 | 0.0 |
| Shooting | War machine shots | 22.0 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (39 of 66) | 20% (1 of 5) |
| Shooting | Points destroyed by war machines | 117.0 | 111.7 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 82.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +65 | +155 |
| Combat | Net per 100 charger points, damage counted | +108.6 | +71.5 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -60 | +186 |
| Combat | Net points per supported fight / lone fight | - / -60 | - / +186 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 2 of 2 |
| Game | Points lost | 297.3 | 793.0 |
| Game | VP from objectives | 540.0 | 356.7 |
| Game | Lone holders (player turns) | 2.5 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +702 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1090
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 5.7 | +121.5 | 0.0 | 0.0 | 15.0 | +283.6 | 0.0 | 154.7 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 2.0 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 119.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 21.3 | +96.8 | 1484.7 | 33.3 | 1.0 | +32.1 | 38.3 | 66.7 |
| CANNON SIGHT KEPT | 4.0 | +0.0 | 0.0 | 60.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +53.3 | 0.0 | 37.3 |
| CHALLENGE BY POINTS | 0.3 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.0 | -86.8 | 0.0 | 120.0 | 26.7 | -1117.6 | 0.0 | 1530.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 20.0 | 0.7 | +0.0 | 20.0 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 86.7 | 11.0 | +0.0 | 0.0 | 117.3 |
| COVER ONCE | 6.3 | -536.6 | 0.0 | 0.0 | 4.0 | -210.2 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 10.7 | -119.8 | 0.0 | 21.7 | 6.0 | +70.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +3.2 | 10.0 | 20.0 | 0.7 | +2.8 | 20.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.1 | 10.0 | 20.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 15.3 | +266.1 | 0.0 | 549.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -1.0 | 0.0 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 126.0 | +5438.0 | 3574.7 | 250.0 | 69.0 | +2880.0 | 256.7 | 1920.0 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 87.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +199.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +38.5 | 10.0 | 20.0 | 1.0 | +53.5 | 20.0 | 0.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.7 | -25.0 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | - | - | - | - | 13.3 | +1103.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +5.0 | 46.3 | 0.0 | - | - | - | - |
| GUN MASK | 4.3 | +54.4 | 0.0 | 0.0 | 1.7 | +74.3 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.0 | +0.2 | 0.0 | 20.0 | - | - | - | - |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 40.0 | 13.0 | +0.0 | 0.0 | 154.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 80.0 | 19.3 | +0.0 | 0.0 | 139.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -26.9 | 0.0 | 40.0 | 6.0 | -58.6 | 0.0 | 10.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.7 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 28.7 | +1059.8 | 0.0 | 80.0 | 59.7 | +5088.1 | 0.0 | 1786.7 |
| HIS SHOTS BY HIS RUN | 8.0 | +90.9 | 0.0 | 120.0 | 46.3 | +1219.9 | 0.0 | 1740.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +22.4 | 0.0 | 0.0 |
| HOLD ODDS | 8.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 1077.3 |
| HOLDER ASSIGNMENT | 8.7 | +1045.4 | 0.0 | 0.0 | 7.0 | +760.2 | 0.0 | 538.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -13.0 | 0.0 | 20.0 | 1.0 | -48.7 | 20.0 | 0.0 |
| IDLE COST | - | - | - | - | 19.7 | -387.0 | 0.0 | 478.0 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.3 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 329.3 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +67.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 124.0 | 1.3 | +0.0 | 186.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +2.0 | 10.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | +2.9 | 0.0 | 20.0 | - | - | - | - |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | -5.8 | 0.0 | 0.0 | 1.7 | -0.8 | 0.0 | 119.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +19.0 | 0.0 | 119.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +3.1 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| MEETS IN TIME | 6.3 | +318.2 | 0.0 | 0.0 | 3.3 | +286.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 1.0 | +4.2 | 0.0 | 119.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +3.9 | 0.0 | 238.0 |
| MODEL FACING | 4.3 | +926.6 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 37.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +359.7 | 0.0 | 40.0 | 2.3 | +126.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +213.1 | 0.0 | 0.0 | 1.7 | +71.7 | 0.0 | 119.0 |
| NEXT CHARGE BY LIST | 2.3 | +81.8 | 0.0 | 0.0 | 2.3 | +126.6 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.0 | +27.7 | 0.0 | 82.0 | 1.3 | +13.4 | 0.0 | 10.0 |
| NO DOUBLE ROUNDS | 2.7 | -45.5 | 10.0 | 20.0 | 1.0 | -34.5 | 20.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.9 | 0.0 | 117.0 |
| OFF BEST | 6.3 | -181.9 | 0.0 | 0.0 | 3.3 | -72.5 | 0.0 | 87.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -41.0 | 0.0 | 41.7 | 4.0 | -83.6 | 0.0 | 46.3 |
| ONE JOINT FIGURE | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | +13.7 | 0.0 | 0.0 | 2.0 | -19.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +5.6 | 0.0 | 20.0 | 1.0 | +72.3 | 20.0 | 0.0 |
| PLAN RESULT | 55.3 | +1653.6 | 1309.0 | 288.7 | 33.0 | +79.0 | 162.0 | 758.0 |
| PRIZE BY WORTH | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 12.3 | -199.0 | 0.0 | 40.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 2.0 | -15.4 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -40.1 | 80.0 | 33.3 |
| QUARTER ODDS | 11.7 | +762.6 | 0.0 | 0.0 | 8.7 | +1292.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +60.1 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +23.0 | 0.0 | 21.7 | 0.7 | +9.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 33.7 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.0 | -48.9 | 0.0 | 40.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +42.3 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +10.1 | 0.0 | 20.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +58.6 | 10.0 | 20.0 | 1.0 | -108.3 | 20.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -4.6 | 0.0 | 0.0 |
| RUN DOWN | 2.7 | -21.5 | 10.0 | 20.0 | 0.7 | -2.9 | 20.0 | 0.0 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.0 | -141.3 | 0.0 | 37.3 |
| SEARCH SPOT | 0.3 | +7.6 | 0.0 | 20.0 | - | - | - | - |
| SECOND LOOK | 1.0 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 3.3 | -92.5 | 0.0 | 0.0 | 0.7 | -15.1 | 0.0 | 36.7 |
| SET UP BY THE SET | 3.3 | +90.0 | 0.0 | 0.0 | 1.0 | +6.3 | 0.0 | 36.7 |
| SET UP TOGETHER | 1.3 | +3.4 | 0.0 | 0.0 | 0.7 | +0.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 28.7 | +0.0 | 0.0 | 33.3 | 2.3 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +10.3 | 0.0 | 0.0 | 1.3 | +5.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -3.9 | 10.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 16.0 | +639.8 | 0.0 | 120.0 | 39.7 | -364.9 | 0.0 | 1542.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 39.0 | +1121.7 | 0.0 | 53.3 | 2.7 | +169.7 | 0.0 | 66.7 |
| SPELL WORTH | - | - | - | - | 1.3 | +20.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 41.7 | 7.7 | +0.0 | 0.0 | 166.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -36.5 | 0.0 | 0.0 |
| STANDS STILL | 90.0 | +0.0 | 3564.7 | 146.7 | 17.0 | +0.0 | 236.7 | 186.7 |
| STAY WORTH | 74.3 | +370.3 | 2065.3 | 100.0 | 6.0 | +202.9 | 236.7 | 200.0 |
| STRIKE BY THE ODDS | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -6.7 | 0.0 | 329.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +35.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +35.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 2.0 | +17.5 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 37.0 |
| THE FIGHT MOVES | 1.3 | +3.4 | 0.0 | 20.0 | 0.3 | +6.3 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 20.0 | 4.0 | +0.0 | 0.0 | 252.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 178.3 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 164.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.0 | +0.0 | 0.0 | 75.0 | 30.7 | +0.0 | 0.0 | 965.0 |
| TIED UP BY THE SUM | 1.3 | +35.5 | 0.0 | 20.0 | 1.0 | +111.1 | 20.0 | 0.0 |
| TIME ON OUR SIDE | 46.7 | +584.1 | 74.0 | 41.7 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | -10.5 | 10.0 | 0.0 | 0.3 | +1.1 | 20.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 4.7 | -209.6 | 0.0 | 154.7 |
| WHOLE FIGHT GAIN | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.3 | +66.2 | 0.0 | 82.0 | 2.7 | +90.3 | 20.0 | 20.0 |
| WOUNDS ON THE RANKS | 2.7 | +13.5 | 0.0 | 0.0 | 8.7 | +393.7 | 0.0 | 1134.7 |

### Rule changes: chf-efd8067-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 265 | 261 | 66 | 22.00 | +1712 | +25.9 |
| ARMY TABLE | 62 | 62 | 49 | 16.33 | +1070 | +21.8 |
| HOLDER ASSIGNMENT | 47 | 47 | 42 | 14.00 | +2753 | +65.6 |
| SHOT RISK POINTS | 167 | 163 | 37 | 12.33 | +897 | +24.2 |
| HIS SHOTS BY HIS RUN | 163 | 161 | 29 | 9.67 | +788 | +27.2 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -763 | -26.3 |
| DEPLOY BY FIGURES | 50 | 50 | 26 | 8.67 | +480 | +18.5 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 21 | 7.00 | -597 | -28.4 |
| FIVE ACTION | 585 | 568 | 20 | 6.67 | +427 | +21.3 |
| TIME ON OUR SIDE | 140 | 132 | 20 | 6.67 | +58 | +2.9 |
| CANNON PLANNED TARGET | 67 | 67 | 18 | 6.00 | -469 | -26.1 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 31 | 23 | 15 | 5.00 | +301 | +20.1 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +2780 | +213.8 |
| IDLE COST | 59 | 44 | 10 | 3.33 | +196 | +19.6 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 98 | 96 | 8 | 2.67 | +532 | +66.5 |
| MEETS IN TIME | 29 | 29 | 8 | 2.67 | +96 | +12.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +180 | +22.5 |
| SET UP BY THE SET | 13 | 11 | 8 | 2.67 | +208 | +26.0 |
| GOAL WALK | 40 | 40 | 7 | 2.33 | +325 | +46.4 |
| GUN MASK | 18 | 17 | 7 | 2.33 | +114 | +16.3 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 11 | 9 | 6 | 2.00 | +57 | +9.5 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 6 | 6 | 2.00 | +152 | +25.3 |
| CHAFF IN THE MOVE | 7 | 6 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 14 | 9 | 5 | 1.67 | +222 | +44.3 |
| NO CHAFF EDGES | 7 | 6 | 5 | 1.67 | +100 | +20.1 |
| QUARTER ODDS | 61 | 56 | 5 | 1.67 | +578 | +115.7 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RISK BY ARC | 11 | 9 | 5 | 1.67 | +35 | +7.1 |
| SHOTS AFTER THE MOVES | 21 | 21 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 125 | 107 | 5 | 1.67 | +71 | +14.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +204 | +50.9 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +8 | +2.1 |
| CHARGE NOW FIRST | 5 | 5 | 3 | 1.00 | -44 | -14.6 |
| EXACT ROUND | 10 | 8 | 3 | 1.00 | +2 | +0.8 |
| FALLS SHORT | 46 | 36 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +766 | +255.5 |
| OVERRUNS AWAY | 5 | 5 | 3 | 1.00 | +28 | +9.2 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +127 | +42.3 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +58 | +19.3 |
| STAY WORTH | 241 | 223 | 3 | 1.00 | +21 | +7.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 8 | 5 | 3 | 1.00 | +5 | +1.7 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 12 | 12 | 3 | 1.00 | +55 | +18.2 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 6 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +598 | +299.2 |
| HIS MOVE AND SHOT | 26 | 25 | 2 | 0.67 | +8 | +4.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +4 | +1.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -120 | -60.1 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +25 | +12.7 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 34 | 34 | 2 | 0.67 | +113 | +56.6 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +52 | +52.0 |
| COVER ONCE | 31 | 21 | 1 | 0.33 | +5 | +4.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +26 | +26.4 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MAX FOR POSITIONING | 3 | 3 | 1 | 0.33 | +29 | +28.9 |
| NEARER NOT NEEDED | 19 | 18 | 1 | 0.33 | +30 | +29.9 |
| NO DOUBLE ROUNDS | 11 | 9 | 1 | 0.33 | +30 | +30.2 |
| ONE FIGHT FORMULA | 26 | 19 | 1 | 0.33 | +6 | +6.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -29 | -29.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +11 | +11.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +30 | +30.3 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +23 | +22.8 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -13 | -13.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| THE FIGHT MOVES | 5 | 4 | 1 | 0.33 | +4 | +4.1 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 4 | 3 | 1 | 0.33 | +0 | +0.4 |
| WHOLE FIGHT DANGER | 14 | 14 | 1 | 0.33 | +111 | +110.8 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +10 | +10.3 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 16 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 53 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 8 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 69 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 38 | 33 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 60 | 59 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 6 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 13 | 9 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 265 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 9 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 6 | 4 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 93 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 34 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 321 | 314 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 7 | 3 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 7 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 3 | not checked | - | - | - | - |
| THE TABLE BINDS | 254 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 3.00 | 27.9 |
| PROMISE BY ITS OWN SUM | rule | 7.00 | - | 28.4 |
| CANNON PLANNED TARGET | rule | 3.33 | - | 49.0 |
| ARMY TABLE | rule | - | 2.00 | 3.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 14.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 6.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 48.1 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 60.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 11.4 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 46.7 |
| NO REASON | gate | - | 0.33 | 45.8 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 29.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 13.3 |

### Plans: chf-efd8067-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 25% | 89 | 49 | 55% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 27.3 | 96% | 707 | 0 | 0% |
| Mine | shoot | 24.7 | 74% | 1432 | 1604 | 112% |
| Opponent | charge | 1.0 | 67% | 45 | 41 | 90% |
| Opponent | move | 29.0 | 93% | 1221 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 103 | 38 | 37% |
| Opponent | support | 1.7 | 60% | 20 | 0 | 0% |

### Battle groups: chf-efd8067-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 22 (13) | 22 | 0 | 0 | 38% | 2.1 | 0 (1) | 25 (9) | 23 (3) | 27 (10) | 0 (3) |
| Mine | Clean-up | 4 | 22 (4) | 22 | 0 | 10 | 50% | 1.0 | 0 (1) | 232 (1) | 0 (2) | 38 (3) | 0 (1) |
| Mine | Hammer | 5 | 145 (5) | 63 | 81 | 0 | 60% | 1.5 | - | 212 (3) | 66 (2) | 145 (5) | - |
| Mine | Shooter | 10 | 39 (10) | 0 | 39 | 30 | 0% | 1.7 | 0 (1) | 67 (5) | 0 (4) | 49 (8) | 0 (2) |
| Mine | War machine | 17 | 22 (17) | 22 | 0 | 20 | 12% | 1.4 | 0 (3) | 0 (5) | 44 (9) | 0 (3) | 27 (14) |
| Opponent | Chaff | 5 | 23 (5) | 0 | 23 | 69 | 80% | 2.0 | 0 (2) | 38 (2) | 0 (1) | 0 (4) | 75 (1) |
| Opponent | Character | 8 | 7 (8) | 7 | 0 | 31 | 88% | 4.0 | 0 (2) | 29 (2) | 0 (1) | 16 (3) | 0 (2) |
| Opponent | Clean-up | 2 | 86 (2) | 0 | 86 | 0 | 100% | - | - | 86 (2) | - | 86 (2) | - |
| Opponent | Fast Hammer | 4 | 25 (4) | 0 | 25 | 76 | 75% | 5.0 | 0 (1) | 50 (1) | 16 (2) | 25 (4) | - |
| Opponent | Hammer | 4 | 33 (4) | 33 | 0 | 0 | 50% | 4.5 | - | 18 (2) | 47 (2) | 33 (4) | - |
| Opponent | Holder | 2 | 12 (2) | 0 | 12 | 100 | 100% | - | 0 (1) | 27 (1) | - | 12 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | War machine | 2 | 168 (2) | 168 | 0 | 50 | 0% | 1.0 | - | 168 (2) | - | - | 168 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 85 | 0% | 2.5 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: chf-efd8067-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 420 | 0 | 0.3 | 1.0 | 0 | 60 | -60 | 0 of 1 | 1 of 1 | - | -60 |
| Opponent | Kingdom of Bretonnia | 1 | 335 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| Opponent | Warriors of Chaos | 2 | 0 | 93 | 0.5 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| **Opponent** | all armies | 3 | 112 | 124 | 0.7 | 1.0 | 186 | 0 | +186 | 2 of 2 | 2 of 2 | - | +186 |

### Effective charges: chf-efd8067-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -60) | 0 | 0% (0 of 1) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 60 | 137 | -60 | 125 | 60 | +65 | +108.6 |
| Mine | All fights | 1 | 60 | 137 | -60 | 125 | 60 | +65 | +108.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 371 | 186 | +186 | 186 | 62 | +124 | +33.5 |
| Opponent | No odds | 1 | 63 | 186 | +186 | 186 | 0 | +186 | +295.2 |
| Opponent | All fights | 2 | 217 | 186 | +186 | 186 | 31 | +155 | +71.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p16 | move | 18 | 2 (11%) | 1 (6%) | 3 (17%) | 13 (72%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

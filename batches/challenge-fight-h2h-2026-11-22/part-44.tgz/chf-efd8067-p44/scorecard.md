# Doctrine scorecard: chf-efd8067-p44

### Scorecard: chf-efd8067-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 540 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 1 | 5 | 1 | 2 | 0 | 0 | 72 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 254 |
| **Average** | | | Mine | 0% | 6.5 | 2.7 | 3.7 | 1.3 | 0.0 | 0.0 | 0.0 | 180.0 |
| **Average** | | | Opponent | 50% | 0.0 | 2.3 | 3.0 | 0.7 | 0.7 | 0.0 | 0.0 | 108.7 |

### KPIs: chf-efd8067-p44

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 17) | 0% (0 of 34) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 50% (1 of 2); on the table 50% | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 50% (3 of 6); on the table 50% | 83% (5 of 6); on the table 83% | 67% (8 of 12); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 28% (5 of 18) | - | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (5 of 12) | - | 42% (5 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 35% (2084 of 6000) | 49% (2920 of 6000) | 42% (5004 of 12000) |
|   infantry points that never fought | lower | 37% (339 of 923) | 54% (627 of 1159) | 46% (966 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (13 of 26) | 71% (17 of 24) | 60% (30 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 50% (1 of 2); 1.3 uses a game | 67% (2 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 2.0 uses a game | 0.0 uses a game | 21% (3 of 14); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 41% (2401 of 5860) | 67% (3420 of 5131) | 53% (5821 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (31%) | - | 1.3 (31%) |
| MARCHED: its unit marched | 0.7 (15%) | - | 0.7 (15%) |
| CHARGED: its unit charged | 0.3 (8%) | - | 0.3 (8%) |
| IN COMBAT: engaged in combat | 1.3 (31%) | - | 1.3 (31%) |
| GONE: slain | 0.7 (15%) | - | 0.7 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 3.0 | 3.7 | 1.7 | 2.7 |
| not cast | 3.3 | 7.0 | 4.3 | 4.3 | 25.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (48%) | 0.3 (8%) | 1.3 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 1.3 (31%) | 1.3 (31%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (20%) | 0.7 (10%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.0 (60%) | 1.3 (19%) | 2.0 (46%) | 0.7 (15%) | 4.3 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (20%) | 1.3 (19%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.7 a game | 0.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 91% (10 of 11) | - | 91% (10 of 11) |
| the unit moved after it | 50% (5 of 10) | - | 50% (5 of 10) |
| it charged on its next turn | 0% (0 of 10) | - | 0% (0 of 10) |
| the enemy charged it first | 20% (2 of 10) | - | 20% (2 of 10) |
| it fought by the end of its next turn | 20% (2 of 10) | - | 20% (2 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 10) | - | 0% (0 of 10) |
| none of these (no charge, no fight, no charge escaped) | 80% (8 of 10) | - | 80% (8 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (41 of 77) | 60% (61 of 102) | 57% (102 of 179) |
|   cavalry | 59% (10 of 17) | 100% (19 of 19) | 81% (29 of 36) |
|   character | 14% (4 of 28) | 24% (4 of 17) | 18% (8 of 45) |
|   chariot | - | 71% (5 of 7) | 71% (5 of 7) |
|   infantry | 81% (17 of 21) | 50% (25 of 50) | 59% (42 of 71) |
|   monster | - | 89% (8 of 9) | 89% (8 of 9) |
|   war machine | 91% (10 of 11) | - | 91% (10 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (33%) | 1.0 (7%) | 5.0 (19%) |
| CHARGED: it charged | 3.0 (25%) | 3.0 (22%) | 6.0 (23%) |
| IN COMBAT: it fought this turn or the last | 1.7 (14%) | 0.3 (2%) | 2.0 (8%) |
| NO TARGET IN RANGE | 1.7 (14%) | 6.7 (49%) | 8.3 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 1.0 (7%) | 1.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (8%) | 1.0 (7%) | 2.0 (8%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.3 | 3.0 | 79% | 8.6 pts | 124 pts |
| character | 4.3 | 1.3 | 69% | 5.5 pts | 24 pts |
| chariot | 1.7 | 0.7 | 80% | 9.8 pts | 16 pts |
| infantry | 19.7 | 4.0 | 81% | 5.3 pts | 105 pts |
| monster | 3.0 | 1.0 | 67% | 10.5 pts | 31 pts |
| war machine | 3.3 | 1.0 | 80% | 11.3 pts | 38 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.3 | 5.3 |
| Charges that made contact a game | 2.7 | 4.0 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.00 contact (3 units) | - | 1.33 declared, 1.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.22 contact (23 units) | 0.58 declared, 0.36 contact (33 units) | 0.50 declared, 0.30 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (8 of 17) | - | - | 47% (8 of 17) |
| Character on its own | - | 80% (4 of 5) | 25% (2 of 8) | 46% (6 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (8 of 10) | 0% (0 of 1) | - | 73% (8 of 11) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 50% (3 of 6); on the table 50% | 28% (5 of 18) | 35% | 50% (13 of 26) | 100% (1 of 1); 1.7 uses a game | 21% (3 of 14); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | - | 60% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 40% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 46% | 58% (7 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 50% (2) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 45% (5 of 11) | 44% (7 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (9 of 22) | 52% (13 of 25) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 0.7 |
| Movement | Points that never moved of their own | 180.0 | 108.7 |
| Movement | Fights charged into per game | 2.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 2 of 9, net -130 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 2 of 9, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +51 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +66 | 5 of 9, net +209 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | 21.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (22 of 36) | 55% (35 of 64) |
| Shooting | Points destroyed by shooting units | 0.0 | 139.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | - |
| Magic | Wounds caused by magic missiles | 4.7 | 2.3 |
| Magic | Wounds caused by other spells | 4.0 | - |
| Magic | Points destroyed by magic (all spells) | 158.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 1.3 / 0.0 | 2.7 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 220.0 | 380.7 |
| Combat | Points run down | 328.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +47 | +85 |
| Combat | Net per 100 charger points, damage counted | +12.3 | +29.3 |
| Combat | First round won (charged fights) | 100% | 45% |
| Combat | Net points per charged fight | +61 | +83 |
| Combat | Net points per supported fight / lone fight | - / +61 | -195 / +110 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 5 of 11 |
| Game | Points lost | 601.0 | 1091.7 |
| Game | VP from objectives | 866.7 | 663.3 |
| Game | Lone holders (player turns) | 6.5 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +670 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1693
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 28.3 | +293.8 | 0.0 | 898.3 | 26.0 | +292.9 | 0.0 | 1101.7 |
| ASSAILMENT BY POINTS | 0.7 | +3.0 | 0.0 | 133.3 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 1.0 | +0.1 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLANNED TARGET | 3.3 | +0.0 | 130.0 | 46.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +25.1 | 41.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.3 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +35.3 | 0.0 | 22.7 |
| CHALLENGE BY POINTS | 2.0 | +80.8 | 0.0 | 109.3 | 0.3 | +5.9 | 0.0 | 41.7 |
| CHALLENGE IN THE FIGHT | 0.3 | -29.5 | 52.7 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +4.8 | 0.0 | 41.7 |
| CHARACTERS BY THEIR POINTS | 0.3 | -0.5 | 52.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 23.3 | -875.6 | 0.0 | 379.3 | 12.7 | -876.9 | 0.0 | 664.7 |
| CHARGE NOW FIRST | 3.7 | +0.0 | 518.7 | 0.0 | 5.3 | +0.0 | 431.0 | 310.3 |
| CLEAR LANE AHEAD | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 342.3 | 15.3 | +0.0 | 0.0 | 336.7 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 59.0 | 65.0 |
| CONVEYANCE SEARCH | 3.3 | +247.8 | 428.0 | 266.7 | - | - | - | - |
| COVER ONCE | 9.7 | -607.9 | 0.0 | 150.3 | 3.3 | -276.8 | 0.0 | 101.3 |
| DENIED BY THE FIGHT | 0.7 | -11.9 | 136.3 | 0.0 | 1.0 | -2.5 | 0.0 | 34.0 |
| DEPLOY BY FIGURES | 8.0 | -63.7 | 0.0 | 0.0 | 8.3 | +31.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -70.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +1.6 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 1.3 | +175.9 | 0.0 | 0.0 | 3.7 | +1922.4 | 41.0 | 0.0 |
| EXACT ROUND | 2.3 | +40.0 | 355.0 | 0.0 | 3.7 | +54.3 | 345.0 | 112.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +7.1 | 208.3 | 0.0 | 4.0 | +14.2 | 413.3 | 65.0 |
| FALLS SHORT | 2.3 | +22.9 | 0.0 | 41.0 | 18.7 | +213.5 | 0.0 | 370.0 |
| FEATURE BUFFS | 0.3 | +1.5 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +2.5 | 52.7 | 0.0 | 0.7 | +10.5 | 0.0 | 65.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 41.0 | - | - | - | - |
| FIVE ACTION | 88.0 | +5992.4 | 1094.7 | 2059.3 | 86.0 | +5697.9 | 855.3 | 2307.3 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 98.0 | 7.3 | +0.0 | 0.0 | 191.3 |
| FOLLOW UP WEIGHED | 0.3 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +249.2 | 407.7 | 0.0 | 5.7 | +366.8 | 454.3 | 218.7 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.3 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -11.5 | 23.3 | 0.0 |
| GOAL WALK | 10.0 | +585.3 | 0.0 | 428.0 | 9.3 | +579.8 | 0.0 | 698.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 41.0 | 123.3 |
| GUN MASK | 2.0 | +12.7 | 0.0 | 147.3 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | -0.1 | 83.7 | 0.0 | 0.7 | -1.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 38.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 106.7 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 297.3 | 9.3 | +0.0 | 0.0 | 581.0 |
| HIS CHARGE DENIED | 0.3 | +11.2 | 0.0 | 0.0 | 1.0 | +49.9 | 0.0 | 75.7 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 294.7 | 3.7 | +0.0 | 0.0 | 174.7 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 82.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -40.3 | 0.0 | 0.0 | 2.7 | -11.9 | 0.0 | 34.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 83.3 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 82.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 54.0 | +2203.1 | 0.0 | 1907.0 | 42.3 | +984.8 | 0.0 | 1139.0 |
| HIS SHOTS BY HIS RUN | 58.3 | +1463.9 | 0.0 | 917.7 | 41.0 | +646.8 | 0.0 | 1030.7 |
| HIS TURN DENIED | 2.0 | +50.9 | 274.3 | 0.0 | 1.0 | +32.2 | 82.3 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 164.0 | 13.3 | +0.0 | 0.0 | 105.3 |
| HOLDER ASSIGNMENT | 10.0 | +893.7 | 0.0 | 82.0 | 9.3 | +752.9 | 0.0 | 52.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -134.9 | 253.7 | 0.0 | 5.0 | -207.7 | 454.3 | 184.7 |
| IDLE COST | 1.3 | -32.7 | 0.0 | 0.0 | 12.3 | -129.9 | 0.0 | 288.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +51.1 | 0.0 | 106.7 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +46.1 | 0.0 | 0.0 | 1.0 | +34.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 147.0 | 100.0 | 2.0 | +0.0 | 0.0 | 41.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 167.3 |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 83.7 | 0.0 | 1.0 | +1.2 | 0.0 | 65.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -99.9 | 0.0 | 95.3 | - | - | - | - |
| MAKE SURE TOGETHER | 1.3 | +15.2 | 0.0 | 41.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +29.9 | 0.0 | 0.0 | 1.0 | -1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 115.7 |
| MARCH BY THE SUM | 0.7 | +71.2 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 115.7 |
| MARCH CHECK | 0.3 | +5.7 | 0.0 | 0.0 | 0.3 | +10.2 | 0.0 | 115.7 |
| MARCH ODDS | 0.3 | +10.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +95.4 | 0.0 | 133.3 | 0.3 | -27.0 | 0.0 | 115.7 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +56.4 | 0.0 | 41.0 | 0.3 | +21.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +80.0 | 0.0 | 0.0 | 4.0 | +131.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +49.0 | 0.0 | 0.0 | 1.7 | +49.8 | 0.0 | 168.3 |
| MISSILES NEXT TURN | 5.0 | +30.7 | 0.0 | 266.7 | 2.0 | +40.4 | 0.0 | 284.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 147.3 | 1.7 | +0.0 | 95.7 | 115.7 |
| MOVE SPELL SPOT | 3.3 | +0.0 | 0.0 | 428.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +862.1 | 0.0 | 0.0 | 4.3 | +355.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +273.9 | 0.0 | 41.0 | 9.3 | +309.3 | 0.0 | 38.0 |
| NEXT CHARGE BY LIST | 8.3 | +1129.5 | 167.0 | 0.0 | 5.3 | +482.5 | 0.0 | 156.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 5.0 | +125.7 | 206.7 | 41.0 | 4.0 | +88.6 | 200.7 | 253.0 |
| NO DOUBLE ROUNDS | 3.0 | -120.3 | 351.7 | 0.0 | 5.0 | -318.7 | 454.3 | 218.7 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -107.4 | 0.0 | 73.7 | 4.3 | -284.4 | 0.0 | 61.7 |
| ONE CHALLENGE TEST | - | - | - | - | 0.7 | +3.3 | 0.0 | 41.7 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -147.6 | 0.0 | 41.0 | 4.0 | -121.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +26.6 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 6.3 | +7.6 | 0.0 | 82.0 | 4.7 | -286.7 | 0.0 | 52.7 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +2.3 | 67.3 | 0.0 | - | - | - | - |
| OPENS UP | 1.0 | +72.4 | 72.0 | 0.0 | 0.3 | +17.6 | 23.3 | 0.0 |
| OPENS UP IN FULL | 2.3 | +154.7 | 278.7 | 0.0 | 3.3 | +101.8 | 173.7 | 143.0 |
| OVERRUNS AWAY | 1.0 | +14.7 | 154.0 | 0.0 | 0.7 | +2.0 | 133.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 41.7 | +788.4 | 317.0 | 1227.7 | 42.7 | +957.0 | 492.7 | 1424.7 |
| PRIZE BY WORTH | 0.3 | +12.5 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -273.8 | 0.0 | 0.0 | 7.3 | -371.5 | 0.0 | 123.3 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.0 | +1497.1 | 150.3 | 229.3 | 15.0 | +1783.2 | 333.0 | 127.3 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +24.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +185.3 | 0.0 | 55.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.0 | +33.6 | 0.0 | 44.0 |
| REDIRECT WEIGHED | 0.7 | +14.5 | 41.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -1.1 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 83.3 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +29.1 | 0.0 | 22.0 |
| RISK BY ARC | 3.0 | -59.5 | 369.7 | 0.0 | 5.0 | +32.1 | 454.3 | 218.7 |
| ROUNDS AFTER TERROR | 1.0 | +5.5 | 90.7 | 0.0 | 2.0 | -44.3 | 183.7 | 65.0 |
| RUN DOWN | 2.7 | -31.6 | 328.3 | 0.0 | 4.3 | -28.7 | 390.0 | 65.0 |
| SAME CHARGE LATER | 1.3 | -46.1 | 125.3 | 0.0 | 0.7 | -7.5 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +0.3 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -43.4 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | +15.2 | 0.0 | 0.0 | 0.3 | +12.9 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +9.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -25.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +14.9 | 0.0 | 0.0 | 1.0 | +18.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +15.2 | 0.0 | 41.0 | - | - | - | - |
| SET-UP ANY TARGET | 1.3 | +163.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 153.3 | 9.0 | +0.0 | 0.0 | 199.7 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +62.4 | 167.0 | 0.0 | 4.0 | +239.7 | 100.7 | 156.0 |
| SHOT OR CHARGE | 0.7 | -9.5 | 107.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 36.7 | -106.3 | 0.0 | 643.3 | 18.7 | +50.7 | 0.0 | 502.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +264.3 | 0.0 | 228.7 | 21.3 | +549.8 | 0.0 | 655.3 |
| SPELL SETS UP CHARGE | 1.7 | +245.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.3 | +15.8 | 266.7 | 266.7 | 1.3 | +14.7 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 1.0 | +17.1 | 195.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.3 | +0.0 | 0.0 | 516.7 | 4.0 | +0.0 | 0.0 | 161.0 |
| STAND AND SHOOT | 2.0 | -17.4 | 219.7 | 0.0 | 0.3 | -3.3 | 41.0 | 78.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 211.3 |
| STANDS STILL | 33.7 | +0.0 | 687.0 | 592.7 | 33.3 | +0.0 | 401.0 | 718.7 |
| STAY WORTH | 16.3 | -26.1 | 390.0 | 41.0 | 21.0 | +363.6 | 218.3 | 715.0 |
| SUPPORT ADDS | 3.0 | +407.5 | 0.0 | 0.0 | 4.7 | +347.8 | 0.0 | 186.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 41.0 | 234.0 |
| SUPPORT WORKED OUT | 3.0 | +407.5 | 0.0 | 0.0 | 4.7 | +347.8 | 0.0 | 186.0 |
| SURE REACH TOGETHER | 0.3 | +1.9 | 0.0 | 0.0 | 1.0 | +1.7 | 0.0 | 22.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +4.0 | 0.0 | 50.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 41.0 | 1.7 | +0.0 | 0.0 | 11.3 |
| THE FIGHT MOVES | 0.7 | +52.5 | 76.0 | 0.0 | 1.3 | +37.0 | 280.7 | 65.0 |
| THE PROMISE ADDS | 0.7 | -59.4 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 41.0 | 3.3 | +0.0 | 0.0 | 231.3 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 345.0 | 3.0 | +0.0 | 0.0 | 107.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 50.3 | 2.0 | +0.0 | 0.0 | 161.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 1077.3 | 40.3 | +0.0 | 0.0 | 1038.7 |
| TIED UP BY THE SUM | 1.7 | +224.5 | 148.0 | 0.0 | 2.0 | +263.5 | 173.7 | 78.0 |
| TIME ON OUR SIDE | 40.7 | +529.2 | 0.0 | 1379.3 | 9.7 | +103.2 | 0.0 | 670.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -2.5 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +52.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 5.0 | -375.8 | 0.0 | 215.3 | 2.7 | -647.6 | 0.0 | 367.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +44.0 | 0.0 | 41.7 |
| WHOLE FIGHT REACTION | 4.7 | +388.4 | 176.3 | 436.3 | 2.3 | +58.9 | 0.0 | 353.3 |
| WOUNDS ON THE RANKS | - | - | - | - | 0.7 | +0.0 | 0.0 | 52.7 |

### Rule changes: chf-efd8067-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 163 | 163 | 116 | 38.67 | +1754 | +15.1 |
| HIS SHOT LIST | 289 | 276 | 66 | 22.00 | +818 | +12.4 |
| HIS SHOTS BY HIS RUN | 298 | 284 | 65 | 21.67 | +746 | +11.5 |
| HOLDER ASSIGNMENT | 58 | 58 | 55 | 18.33 | +2949 | +53.6 |
| NEXT CHARGE BY LIST | 41 | 39 | 29 | 9.67 | +1797 | +62.0 |
| DEPLOY BY FIGURES | 49 | 49 | 28 | 9.33 | +268 | +9.6 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1175 | -42.0 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 522 | 505 | 23 | 7.67 | +1031 | +44.8 |
| GOAL WALK | 58 | 58 | 23 | 7.67 | +921 | +40.1 |
| SHOT RISK POINTS | 166 | 157 | 22 | 7.33 | +309 | +14.1 |
| MOVE TO CHARGE COMPUTED | 37 | 29 | 20 | 6.67 | +1435 | +71.8 |
| NO CHAFF EDGES | 27 | 26 | 19 | 6.33 | +202 | +10.6 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 18 | 6.00 | -1936 | -107.6 |
| FOUR ROUNDS | 28 | 27 | 16 | 5.33 | +507 | +31.7 |
| CHARGE NOW FIRST | 27 | 27 | 14 | 4.67 | -659 | -47.1 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 151 | 127 | 13 | 4.33 | +32 | +2.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 12 | 4.00 | +54 | +4.5 |
| QUARTER ODDS | 84 | 84 | 11 | 3.67 | +687 | +62.5 |
| TIED UP BY THE SUM | 11 | 11 | 11 | 3.67 | +315 | +28.6 |
| EVASIVE BY THE ODDS | 15 | 15 | 9 | 3.00 | +3427 | +380.8 |
| MEETS IN TIME | 21 | 21 | 9 | 3.00 | +103 | +11.4 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +88 | +9.8 |
| SUPPORT ADDS | 23 | 21 | 9 | 3.00 | +354 | +39.3 |
| SUPPORT WORKED OUT | 23 | 21 | 9 | 3.00 | +354 | +39.3 |
| CHARGE LOSSES | 108 | 99 | 8 | 2.67 | +801 | +100.2 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| OPENS UP IN FULL | 17 | 16 | 8 | 2.67 | +118 | +14.8 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +260 | +37.1 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +242 | +34.6 |
| STAY WORTH | 112 | 96 | 7 | 2.33 | +512 | +73.2 |
| EXACT ROUND | 18 | 17 | 5 | 1.67 | +43 | +8.6 |
| FALLS SHORT | 63 | 53 | 5 | 1.67 | +65 | +13.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +153 | +30.7 |
| COVER ONCE | 39 | 23 | 4 | 1.33 | +189 | +47.2 |
| MAX FOR POSITIONING | 10 | 9 | 4 | 1.33 | +6 | +1.5 |
| ONE OBJECTIVE FORMULA | 33 | 29 | 4 | 1.33 | +98 | +24.5 |
| RISK BY ARC | 24 | 23 | 4 | 1.33 | +139 | +34.9 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 107 | 73 | 4 | 1.33 | +135 | +33.7 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 1.00 | +0 | +0.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +49 | +16.2 |
| CHAFF IN THE MOVE | 6 | 6 | 3 | 1.00 | +14 | +4.6 |
| HIS TURN DENIED | 9 | 9 | 3 | 1.00 | +63 | +21.0 |
| IDLE COST | 41 | 22 | 3 | 1.00 | +5 | +1.7 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +225 | +74.9 |
| NO DOUBLE ROUNDS | 24 | 23 | 3 | 1.00 | +93 | +31.0 |
| OPENS UP | 4 | 4 | 3 | 1.00 | +60 | +20.0 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +46 | +15.4 |
| REFUSING RETIRES | 4 | 4 | 3 | 1.00 | -54 | -17.9 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +87 | +29.1 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 3 | 1.00 | -78 | -26.2 |
| THE FIGHT MOVES | 6 | 6 | 3 | 1.00 | +165 | +55.0 |
| WHOLE FIGHT DANGER | 23 | 23 | 3 | 1.00 | +170 | +56.6 |
| WHOLE FIGHT REACTION | 21 | 21 | 3 | 1.00 | +187 | +62.2 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 4 | 3 | 2 | 0.67 | +39 | +19.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +90 | +44.8 |
| NEARER NOT NEEDED | 48 | 46 | 2 | 0.67 | +74 | +37.2 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +21 | +10.4 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +63 | +31.4 |
| PROMISE READS THE TABLE | 4 | 4 | 2 | 0.67 | +5 | +2.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +84 | +42.1 |
| SET UP BY THE SET | 5 | 5 | 2 | 0.67 | +80 | +40.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +36 | +35.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +17 | +17.3 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -27 | -26.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -81 | -81.1 |
| ONE FIGHT FORMULA | 32 | 12 | 1 | 0.33 | +3 | +3.3 |
| OPENS A LANE | 3 | 1 | 1 | 0.33 | +0 | +0.0 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +9 | +8.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -4.2 |
| REDIRECT COUNTER | 10 | 8 | 1 | 0.33 | +32 | +31.7 |
| RUN DOWN | 21 | 20 | 1 | 0.33 | +11 | +11.2 |
| SAME CHARGE LATER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +28 | +28.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SURE REACH TOGETHER | 4 | 3 | 1 | 0.33 | +2 | +1.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +12 | +11.9 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +147 | +146.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +4 | +3.6 |
| BACKS UP THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 71 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 16 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 38 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 11 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 64 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 14 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 23 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 253 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 48 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 21 | 21 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 201 | 196 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 245 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.67 | 44.5 |
| ARMY TABLE | rule | 4.00 | 2.67 | 33.8 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 3.00 | 107.6 |
| CHARGE NOW FIRST | rule | 2.33 | 2.33 | 47.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 23.3 |
| REFUSING RETIRES | rule | 0.33 | 0.67 | 17.9 |
| SUPPORT NARROWED | rule | - | 1.00 | 26.2 |
| JOINT CHARGE NOW | rule | - | 0.67 | 32.4 |
| FALLBACK | gate | - | 0.33 | 11.4 |
| MARCH ODDS | rule | 0.33 | - | 26.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 81.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 4.2 |
| RULE SWITCHED OFF | gate | - | 0.33 | 7.1 |

### Plans: chf-efd8067-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 89% | 803 | 416 | 52% |
| Mine | move | 32.0 | 94% | 1740 | 0 | 0% |
| Mine | shoot | 6.3 | 68% | 251 | 372 | 148% |
| Mine | support | 0.3 | 0% | 0 | 0 | - |
| Opponent | charge | 5.3 | 50% | 780 | 762 | 98% |
| Opponent | move | 30.3 | 88% | 1509 | 0 | 0% |
| Opponent | shoot | 6.0 | 28% | 619 | 195 | 32% |
| Opponent | support | 1.0 | 67% | 21 | 0 | 0% |

### Battle groups: chf-efd8067-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 81 (7) | 81 | 0 | 28 | 0% | 1.7 | 20 (4) | 179 (2) | 70 (1) | 81 (7) | - |
| Mine | Clean-up | 1 | 150 (1) | 85 | 65 | 0 | 0% | 2.0 | 150 (1) | - | - | 150 (1) | - |
| Mine | Fast Hammer | 14 | 84 (14) | 18 | 66 | 41 | 36% | 2.8 | 65 (7) | 60 (5) | 199 (2) | 81 (9) | 89 (5) |
| Mine | Shooter | 4 | 10 (4) | 10 | 0 | 26 | 0% | 1.0 | 13 (3) | 0 (1) | - | 13 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 7 | 92 (7) | 0 | 92 | 56 | 0% | 2.7 | - | 172 (4) | 16 (3) | 154 (5) | 0 (2) |
| Opponent | Character | 4 | 76 (4) | 76 | 0 | 14 | 0% | 1.8 | 0 (1) | 0 (1) | 129 (2) | 25 (1) | 99 (3) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 80 | 25% | 4.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 49 (4) | 22 | 27 | 52 | 25% | 1.3 | 0 (1) | 51 (2) | 120 (1) | 51 (2) | 47 (2) |
| Opponent | Hammer | 8 | 8 (8) | 8 | 0 | 103 | 12% | 2.1 | 0 (3) | 18 (4) | 0 (1) | 0 (4) | 16 (4) |
| Opponent | Holder | 3 | 219 (3) | 0 | 219 | 0 | 0% | 3.7 | 219 (3) | - | - | 450 (1) | 114 (2) |
| Opponent | Shooter | 4 | 37 (4) | 26 | 11 | 21 | 25% | 1.0 | 0 (1) | 53 (1) | 57 (2) | 15 (3) | 102 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 33% | 1.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: chf-efd8067-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 159 | 163 | 2.7 | 1.0 | 61 | 0 | +61 | 1 of 8 | 8 of 8 | - | +61 |
| Opponent | Ogre Kingdoms | 1 | 0 | 123 | 3.0 | 1.0 | 41 | 0 | +41 | 1 of 3 | 0 of 3 | - | +41 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1240 | 6.0 | 1.2 | 207 | 32 | +174 | 2 of 6 | 5 of 6 | -195 | +248 |
| Opponent | Wood Elf Realms | 1 | 417 | 0 | 2.0 | 1.0 | 0 | 130 | -130 | 2 of 2 | 0 of 2 | - | -130 |
| **Opponent** | all armies | 3 | 139 | 454 | 3.7 | 1.1 | 124 | 41 | +83 | 5 of 11 | 5 of 11 | -195 | +110 |

### Effective charges: chf-efd8067-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 1 (net +0) | 1 (net +70) | 2 (net +51) | 1 (net +66) | 3 | 20% (1 of 5) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +0) | 0 | 0 | 5 (net +209) | 0 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 2 | 2 (net -130) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 143 | 251 | +0 | 20 | 72 | -52 | -36.0 |
| Mine | 76-89% | 1 | 247 | 70 | +70 | 70 | 0 | +70 | +28.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 151 | 66 | +66 | 66 | 30 | +36 | +23.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 500 | 71 | +51 | 65 | 0 | +65 | +13.1 |
| Mine | No odds | 3 | 493 | 117 | +83 | 83 | 21 | +62 | +12.7 |
| Mine | All fights | 8 | 377 | 110 | +61 | 67 | 21 | +47 | +12.3 |
| Opponent | Long shot (under 50%) | 2 | 114 | 494 | -130 | 0 | 139 | -139 | -122.4 |
| Opponent | Effective (55-75%) | 2 | 260 | 204 | +0 | 71 | 0 | +71 | +27.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 475 | 260 | +209 | 248 | 39 | +209 | +44.0 |
| Opponent | No odds | 2 | 34 | 133 | +62 | 62 | 48 | +14 | +41.2 |
| Opponent | All fights | 11 | 290 | 269 | +83 | 137 | 52 | +85 | +29.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p44 | move | 24 | 7 (29%) | 5 (21%) | 5 (21%) | 12 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

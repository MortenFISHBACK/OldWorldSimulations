# Doctrine scorecard: chf-efd8067-p2

### Scorecard: chf-efd8067-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 4 | 5 | 1 | 6 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 250 |
| L0319 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.5 | 5.5 | 0.7 | 4.3 | 0.0 | 0.0 | 0.0 | 196.7 |
| **Average** | | | Opponent | 0% | 2.5 | 2.0 | 1.3 | 1.3 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: chf-efd8067-p2

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 10% (1 of 10) | 0% (0 of 13) | 4% (1 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | - | 33% (1 of 3); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 40% (2 of 5); on the table 40% | 100% (3 of 3); on the table 100% | 62% (5 of 8); on the table 62% |
| Magic missiles tried each own turn | 50%+ | 40% (17 of 42) | 21% (5 of 24) | 33% (22 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (17 of 42) | 21% (5 of 24) | 33% (22 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (6 of 10) | - | 60% (6 of 10) |
| Points that never fought | lower | 40% (2296 of 5797) | 79% (4748 of 6000) | 60% (7044 of 11797) |
|   infantry points that never fought | lower | 32% (435 of 1374) | 42% (350 of 842) | 35% (785 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (14 of 20) | 56% (15 of 27) | 62% (29 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.3 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (2570 of 4039) | 57% (3158 of 5515) | 60% (5728 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (64%) | 0.3 (5%) | 5.7 (39%) |
| MARCHED: its unit marched | 2.0 (24%) | 0.0 (0%) | 2.0 (14%) |
| REAR RANK: in a rear rank | 1.0 (12%) | 4.7 (74%) | 5.7 (39%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (21%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 2.0 | 3.0 | 7.3 | 0.3 |
| not cast | 2.0 | 7.0 | 14.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (14%) | 5.7 (39%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 4.7 (67%) | 5.7 (39%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (6%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.3 (19%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 67% (4 of 6) | 0% (0 of 3) | 44% (4 of 9) |
| the unit moved after it | 25% (1 of 4) | - | 25% (1 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | - | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (24 of 35) | 69% (57 of 83) | 69% (81 of 118) |
|   cavalry | - | 71% (12 of 17) | 71% (12 of 17) |
|   character | - | 67% (8 of 12) | 67% (8 of 12) |
|   chariot | 45% (5 of 11) | 100% (12 of 12) | 74% (17 of 23) |
|   infantry | - | 43% (13 of 30) | 43% (13 of 30) |
|   monster | - | 100% (12 of 12) | 100% (12 of 12) |
|   war machine | 79% (19 of 24) | - | 79% (19 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (27%) | 4.3 (50%) | 5.3 (43%) |
| IN COMBAT: it fought this turn or the last | 0.7 (18%) | 0.3 (4%) | 1.0 (8%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 0.3 (9%) | 2.3 (27%) | 2.7 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (9%) | 1.3 (15%) | 1.7 (14%) |
| OTHER BAR | 0.7 (18%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 2.7 | 59% | 5.5 pts | 31 pts |
| character | 2.7 | 0.3 | 88% | 0.8 pts | 2 pts |
| chariot | 5.7 | 6.7 | 35% | 26.3 pts | 149 pts |
| infantry | 4.3 | 3.3 | 46% | 7.5 pts | 32 pts |
| monster | 4.0 | 1.7 | 75% | 5.8 pts | 23 pts |
| war machine | 6.7 | 3.3 | 75% | 7.4 pts | 49 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 3.0 | 1.8 |
| Charges that made contact a game | 0.7 | 1.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.08 declared, 0.08 contact (24 units) | 0.31 declared, 0.14 contact (29 units) | 0.21 declared, 0.11 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character in a unit | 100% (6 of 6) | 71% (5 of 7) | - | 85% (11 of 13) |
| Character on its own | 100% (2 of 2) | 0% (0 of 1) | 50% (1 of 2) | 60% (3 of 5) |
| Chariot | 0% (0 of 2) | 100% (2 of 2) | - | 50% (2 of 4) |
| Infantry | 20% (1 of 5) | 0% (0 of 3) | - | 12% (1 of 8) |
| Monster | 0% (0 of 2) | 100% (1 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 40% (2 of 5); on the table 40% | 57% (17 of 30) | 36% | 58% (7 of 12) | 100% (4 of 4); 8.0 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 47% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 79% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 82% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 76% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 0% (0) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: chf-efd8067-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 0% (0 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (14 of 22) | 73% (11 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (4 of 4) |
| Strategy | Joined characters whose unit fought | 89% (8 of 9) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 4.3 | 1.3 |
| Movement | Points that never moved of their own | 196.7 | 0.0 |
| Movement | Fights charged into per game | 0.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +57 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 19.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (5 of 5) | 16% (9 of 57) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (12 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 74.0 |
| Magic | Magic missiles cast | 1.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 5.7 | 4.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 60.7 | 374.7 |
| Combat | Points run down | 0.0 | 58.7 |
| Combat | Net points per charged fight, damage counted | +70 | +173 |
| Combat | Net per 100 charger points, damage counted | +106.0 | +109.1 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +57 | +243 |
| Combat | Net points per supported fight / lone fight | - / +57 | - / +243 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 3 of 4 |
| Game | Points lost | 547.0 | 120.7 |
| Game | VP from objectives | 383.3 | 1146.7 |
| Game | Lone holders (player turns) | 3.5 | 2.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1191 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 668
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 19.0 | -321.9 | 0.0 | 315.3 | 36.7 | +453.2 | 0.0 | 83.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.3 | +0.3 | 0.0 | 0.0 | 1.3 | +177.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +18.0 | 73.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.7 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.3 | +141.2 | 0.0 | 0.0 | 0.7 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +14.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +65.6 | 0.0 | 85.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -1.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.6 | 0.0 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -0.7 | 0.0 | 0.0 | 0.3 | -25.3 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.7 | -110.6 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -353.1 | 0.0 | 320.0 | 18.3 | -503.4 | 0.0 | 83.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 38.0 | 0.0 | 1.0 | +0.0 | 45.7 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 15.0 | +0.0 | 0.0 | 174.0 | 9.3 | +0.0 | 0.0 | 36.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +249.8 | 0.0 | 0.0 | 1.0 | +114.3 | 0.0 | 0.0 |
| COVER ONCE | 5.7 | -329.0 | 0.0 | 120.7 | 6.0 | -124.4 | 0.0 | 79.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.3 | +16.8 | 0.0 | 0.0 | 7.3 | +57.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +4.2 | 38.0 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +0.4 | 38.0 | 0.0 | 1.3 | +1.4 | 45.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 45.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| FALLS SHORT | 13.7 | +323.1 | 0.0 | 74.0 | 5.0 | +102.6 | 0.0 | 0.0 |
| FEATURE BUFFS | 10.0 | +495.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 91.3 | +7127.3 | 148.0 | 922.0 | 97.0 | +8105.3 | 313.3 | 275.3 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 282.7 | 2.0 | +0.0 | 0.0 | 41.7 |
| FOCUS FIRE | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +53.7 | 0.0 | 56.7 | 0.3 | +8.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.7 | +18.5 | 38.0 | 0.0 | 1.7 | +15.8 | 45.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 206.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.9 | 0.0 | 206.7 | - | - | - | - |
| GOAL WALK | 10.0 | +1391.6 | 0.0 | 117.3 | 15.0 | +2098.9 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +0.7 | 0.0 | 206.7 | 1.7 | +65.6 | 45.7 | 0.0 |
| HALF WHEN STILL FLEEING | 0.7 | -1.7 | 38.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 28.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 320.0 | 3.3 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.3 | -46.8 | 0.0 | 56.7 | 6.0 | -140.7 | 0.0 | 34.0 |
| HIS ONE QUARTER | 7.0 | +0.0 | 0.0 | 224.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 20.0 | +0.0 | 0.0 | 204.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 6.0 | +0.0 | 0.0 | 83.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 57.7 | +2003.2 | 0.0 | 452.0 | 56.3 | +2009.5 | 0.0 | 104.7 |
| HIS SHOTS BY HIS RUN | 51.0 | +940.0 | 0.0 | 800.7 | 46.0 | +1489.2 | 0.0 | 93.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| HOLD ODDS | 29.7 | +0.0 | 0.0 | 121.3 | 21.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.7 | +1348.2 | 0.0 | 60.7 | 12.3 | +1392.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -0.9 | 38.0 | 0.0 | 0.3 | -2.9 | 0.0 | 0.0 |
| IDLE COST | 14.7 | -99.3 | 0.0 | 91.3 | 3.3 | -49.0 | 0.0 | 18.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -0.1 | 28.3 | 0.0 |
| KEEP FALLS | 0.3 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +11.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 41.7 | 103.3 | 3.3 | +0.0 | 160.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +1.8 | 38.0 | 0.0 | 0.7 | +2.3 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +0.5 | 0.0 | 0.0 | 4.0 | -41.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +198.0 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +151.1 | 0.0 | 0.0 | 1.0 | +61.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +1.9 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.0 | +160.2 | 0.0 | 160.0 | 1.3 | +8.8 | 0.0 | 11.3 |
| MEETS IN TIME | 2.7 | +208.0 | 0.0 | 0.0 | 2.7 | +252.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +355.5 | 0.0 | 0.0 | 5.3 | +75.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +207.8 | 0.0 | 0.0 | 5.0 | +56.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.0 | -178.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.7 | +642.8 | 0.0 | 206.7 | 8.0 | +412.6 | 0.0 | 34.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +260.3 | 0.0 | 30.3 | 11.3 | +479.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +193.2 | 0.0 | 0.0 | 8.7 | +469.8 | 34.7 | 34.0 |
| NO CHAFF EDGES | 0.7 | +33.4 | 0.0 | 0.0 | 0.3 | +4.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -10.9 | 38.0 | 0.0 | 1.7 | -53.2 | 45.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +8.2 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 3.7 | -539.5 | 0.0 | 103.3 | 5.0 | -160.5 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 2.0 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -44.0 | 0.0 | 160.0 | 6.3 | -113.5 | 0.0 | 11.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +1.4 | 28.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +69.4 | 0.0 | 60.7 | 5.3 | +12.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -28.5 | 0.0 | 0.0 | 1.7 | -45.4 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +35.4 | 17.3 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -16.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 43.0 | +169.6 | 18.3 | 795.3 | 43.3 | +111.5 | 126.0 | 211.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -1299.6 | 0.0 | 206.7 | 6.3 | -304.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | -0.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.0 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.0 | +793.6 | 38.0 | 241.3 | 15.7 | +2490.4 | 17.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 3.3 | +44.4 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +9.5 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +275.5 | 0.0 | 28.3 | 3.0 | +139.1 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 5.7 | +16.4 | 0.0 | 113.3 | 2.0 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -23.6 | 0.0 | 0.0 | 2.7 | -34.9 | 0.0 | 34.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +9.8 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | +11.1 | 38.0 | 0.0 | 1.3 | -30.9 | 45.7 | 0.0 |
| RUN DOWN | 0.7 | -9.1 | 38.0 | 0.0 | 1.7 | -8.9 | 45.7 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | +6.5 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -22.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +6.5 | 0.0 | 0.0 | 1.0 | +8.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 2.0 | -42.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +10.5 | 0.0 | 0.0 | 1.3 | +10.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +236.6 | 0.0 | 0.0 | 1.3 | +43.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 51.7 | +137.3 | 0.0 | 594.0 | 37.3 | -321.8 | 0.0 | 116.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.7 | +170.1 | 0.0 | 103.3 | 19.3 | +414.3 | 0.0 | 38.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +246.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 9.3 | +0.0 | 0.0 | 291.7 | 7.7 | +0.0 | 0.0 | 29.7 |
| STAND AND SHOOT | 0.3 | -1.9 | 38.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.7 | +0.0 | 110.0 | 74.0 | 34.7 | +0.0 | 267.7 | 45.3 |
| STAY WORTH | 17.3 | -70.8 | 110.0 | 0.0 | 24.0 | +187.7 | 176.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +2.6 | 38.3 | 0.0 |
| STRONG ENOUGH TO HOLD | 1.3 | -24.6 | 0.0 | 0.0 | 0.7 | -31.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +999.4 | 0.0 | 413.3 | 3.3 | +27.7 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 38.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 8.3 | +999.4 | 0.0 | 413.3 | 3.3 | +27.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +11.8 | 0.0 | 0.0 | 1.7 | +23.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | +0.2 | 38.0 | 0.0 | 0.7 | +0.7 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 30.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 30.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.7 | +0.0 | 0.0 | 162.0 | 4.0 | +0.0 | 0.0 | 41.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 131.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 404.3 | 45.3 | +0.0 | 0.0 | 132.0 |
| TIED UP BY THE SUM | 0.3 | +5.8 | 38.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 8.7 | +151.5 | 0.0 | 164.0 | 48.0 | +523.5 | 0.0 | 159.0 |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 11.3 |
| WAR ENGINE JOBS | - | - | - | - | 5.0 | +0.0 | 198.3 | 0.0 |
| WHO FIGHTS | 0.3 | -1.2 | 38.0 | 0.0 | 0.7 | +4.1 | 28.3 | 0.0 |
| WHO HITS BACK | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.7 | -25.3 | 0.0 | 0.0 | 2.3 | -101.7 | 0.0 | 83.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.1 | 28.3 | 0.0 |
| WHOLE FIGHT REACTION | 2.0 | +69.4 | 11.3 | 45.7 | 0.7 | +4.0 | 0.0 | 38.0 |
| WOUNDS ON THE RANKS | 7.3 | +386.8 | 0.0 | 0.0 | 3.3 | +279.2 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 167 | 167 | 115 | 38.33 | +665 | +5.8 |
| HIS SHOTS BY HIS RUN | 291 | 277 | 90 | 30.00 | +1104 | +12.3 |
| HIS SHOT LIST | 342 | 334 | 86 | 28.67 | +990 | +11.5 |
| HOLDER ASSIGNMENT | 75 | 75 | 71 | 23.67 | +4804 | +67.7 |
| SHOT RISK POINTS | 267 | 262 | 54 | 18.00 | +1037 | +19.2 |
| DEPLOY BY FIGURES | 50 | 50 | 32 | 10.67 | +425 | +13.3 |
| GOAL WALK | 75 | 75 | 31 | 10.33 | +3130 | +101.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -2100 | -80.8 |
| MOVE TO CHARGE COMPUTED | 44 | 40 | 25 | 8.33 | +1577 | +63.1 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +7 | +0.3 |
| FIVE ACTION | 565 | 551 | 20 | 6.67 | +1645 | +82.3 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 20 | 6.67 | -4812 | -240.6 |
| TIME ON OUR SIDE | 170 | 142 | 20 | 6.67 | +58 | +2.9 |
| QUARTER ODDS | 95 | 92 | 17 | 5.67 | +1420 | +83.5 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 35 | 31 | 15 | 5.00 | +752 | +50.2 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 16 | 16 | 10 | 3.33 | +684 | +68.4 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 32 | 32 | 9 | 3.00 | +472 | +52.5 |
| SUPPORT ADDS | 35 | 28 | 8 | 2.67 | +231 | +28.9 |
| SUPPORT WORKED OUT | 35 | 28 | 8 | 2.67 | +231 | +28.9 |
| FEATURE BUFFS | 30 | 30 | 7 | 2.33 | +110 | +15.7 |
| MARCH CHECK | 8 | 8 | 7 | 2.33 | +289 | +41.3 |
| MAX FOR POSITIONING | 22 | 19 | 7 | 2.33 | +13 | +1.8 |
| STAY WORTH | 124 | 105 | 7 | 2.33 | +47 | +6.7 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +17 | +2.8 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -222 | -37.0 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -8 | -1.3 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 6 | 2.00 | +133 | +22.2 |
| SET UP BY THE SET | 6 | 6 | 6 | 2.00 | +130 | +21.7 |
| CASTING BLOCK | 6 | 6 | 5 | 1.67 | +76 | +15.3 |
| CHARGE LOSSES | 108 | 105 | 5 | 1.67 | +73 | +14.6 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 37 | 37 | 4 | 1.33 | +73 | +18.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +595 | +148.8 |
| SCOUT BY DROPS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 4 | 1.33 | +341 | +85.3 |
| SHOTS IN THE MOVE | 84 | 63 | 4 | 1.33 | +126 | +31.5 |
| BACKS UP THE FIGHT | 5 | 5 | 3 | 1.00 | +297 | +98.9 |
| FALLS SHORT | 56 | 34 | 3 | 1.00 | +96 | +32.2 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +187 | +62.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +505 | +168.2 |
| MISSILES IN THE MOVE | 35 | 26 | 3 | 1.00 | +299 | +99.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| NO CHAFF EDGES | 3 | 3 | 3 | 1.00 | +115 | +38.3 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +138 | +46.1 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 8 | 8 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 23 | 3 | 3 | 1.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 15 | 15 | 2 | 0.67 | +0 | +0.2 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 3 | 2 | 0.67 | +7 | +3.6 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -3 | -1.5 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +18 | +8.9 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOUR ROUNDS | 7 | 7 | 2 | 0.67 | +19 | +9.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +175 | +87.5 |
| NEARER NOT NEEDED | 49 | 44 | 2 | 0.67 | +89 | +44.4 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +7 | +3.6 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -12 | -6.2 |
| RISK BY ARC | 5 | 5 | 2 | 0.67 | +19 | +9.6 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +45 | +22.7 |
| WHOLE FIGHT DANGER | 12 | 12 | 2 | 0.67 | +88 | +44.0 |
| WHOLE FIGHT REACTION | 8 | 8 | 2 | 0.67 | +9 | +4.6 |
| COVER ONCE | 35 | 19 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +12 | +12.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| IDLE COST | 54 | 38 | 1 | 0.33 | +29 | +28.6 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +34 | +33.7 |
| MANOEUVRE | 18 | 18 | 1 | 0.33 | +3 | +3.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -3 | -3.3 |
| ONE FIGHT FORMULA | 35 | 20 | 1 | 0.33 | +1 | +1.3 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +95 | +94.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -50 | -50.3 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 1 | 0.33 | -2 | -1.9 |
| REDIRECT COUNTER | 18 | 17 | 1 | 0.33 | +47 | +47.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +30 | +29.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 13 | 13 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +8 | +7.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +12 | +12.2 |
| WAR ENGINE JOBS | 15 | 15 | 1 | 0.33 | -83 | -82.8 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +7 | +7.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | -4 | -4.3 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 73 | 72 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 60 | 56 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 18 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 152 | 151 | 0 | 0.00 | - | - |
| HONEST WORTH | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 36 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 40 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 17 | 15 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 36 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 51 | 50 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 190 | 183 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 6 | 6 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE FIGHT MOVES | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 29 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 257 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.33 | 85.1 |
| ARMY TABLE | rule | 3.00 | 3.67 | 78.5 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 2.67 | 240.6 |
| HOLDER ASSIGNMENT | rule | 1.67 | 0.67 | 34.5 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 1.3 |
| ONE PROMISE A TARGET | rule | 0.33 | 1.00 | 63.3 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 6.2 |
| AFTERMATH BAND | gate | 0.33 | - | 4.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 54.7 |
| CHAFF PASSED | rule | - | 0.33 | 3.1 |
| MARCH OF THE TABLE | rule | 0.33 | - | 3.3 |
| NO REASON | gate | - | 0.33 | 83.7 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 50.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.9 |
| WAR ENGINE JOBS | rule | - | 0.33 | 82.8 |
| WHO HITS BACK | rule | 0.33 | - | 4.3 |

### Plans: chf-efd8067-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 40 | 38 | 95% |
| Mine | move | 36.3 | 93% | 2791 | 0 | 0% |
| Mine | shoot | 5.7 | 65% | 312 | 132 | 42% |
| Mine | support | 0.7 | 50% | 8 | 0 | 0% |
| Opponent | charge | 1.3 | 50% | 72 | 57 | 80% |
| Opponent | move | 38.0 | 96% | 2579 | 0 | 0% |
| Opponent | shoot | 4.0 | 42% | 260 | 54 | 21% |

### Battle groups: chf-efd8067-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 0 (11) | 0 | 0 | 17 | 27% | 3.1 | - | 1 (5) | 0 (4) | 1 (9) | - |
| Mine | Clean-up | 3 | 164 (3) | 0 | 164 | 60 | 100% | - | 204 (2) | - | 99 (1) | 164 (3) | - |
| Mine | Fast Hammer | 9 | 19 (9) | 19 | 0 | 60 | 89% | 5.0 | 30 (6) | 0 (1) | 0 (2) | 25 (7) | 0 (2) |
| Mine | Hammer | 9 | 35 (9) | 9 | 26 | 40 | 0% | 3.3 | 7 (2) | 47 (5) | 34 (2) | 35 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 30 | 50% | 3.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 8 | 223 (8) | 0 | 223 | 31 | 38% | 3.0 | 94 (3) | 473 (4) | 0 (1) | 248 (7) | 0 (1) |
| Opponent | Character | 7 | 60 (7) | 60 | 0 | 0 | 29% | 2.0 | 149 (2) | 34 (3) | 6 (2) | 13 (5) | 150 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 31 (10) | 21 | 10 | 6 | 30% | 2.4 | 36 (5) | 30 (3) | 20 (2) | 42 (7) | 15 (3) |
| Opponent | Shooter | 4 | 86 (4) | 0 | 86 | 22 | 0% | 1.8 | 30 (2) | 300 (1) | 26 (1) | 86 (4) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: chf-efd8067-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 57 | 1.0 | 1.0 | 57 | 0 | +57 | 0 of 2 | 2 of 2 | - | +57 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 0 | 38 | 0.7 | 1.0 | 57 | 0 | +57 | 0 of 2 | 2 of 2 | - | +57 |
| Opponent | Ogre Kingdoms | 1 | 274 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 839 | 1.0 | 1.0 | 839 | 0 | +839 | 1 of 1 | 1 of 1 | - | +839 |
| Opponent | Wood Elf Realms | 1 | 0 | 167 | 2.0 | 1.0 | 84 | 0 | +84 | 1 of 2 | 1 of 2 | - | +84 |
| **Opponent** | all armies | 3 | 91 | 335 | 1.3 | 1.0 | 252 | 8 | +243 | 3 of 4 | 2 of 4 | - | +243 |

### Effective charges: chf-efd8067-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +57) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 1 (net +115) | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 66 | 96 | +57 | 76 | 6 | +70 | +106.0 |
| Mine | All fights | 2 | 66 | 96 | +57 | 76 | 6 | +70 | +106.0 |
| Opponent | 76-89% | 1 | 125 | 272 | +115 | 133 | 107 | +26 | +20.8 |
| Opponent | No odds | 3 | 170 | 251 | +286 | 357 | 135 | +222 | +130.8 |
| Opponent | All fights | 4 | 158 | 256 | +243 | 301 | 128 | +173 | +109.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p2 | move | 21 | 5 (24%) | 1 (5%) | 1 (5%) | 15 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

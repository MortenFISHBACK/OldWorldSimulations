# Doctrine scorecard: chf-efd8067-p18

### Scorecard: chf-efd8067-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 8 | - | 3 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 170 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.7 | 2.0 | 1.0 | 0.7 | 0.0 | 0.0 | 0.0 | 236.7 |
| **Average** | | | Opponent | 0% | 5.0 | 3.0 | 2.0 | 2.3 | 0.3 | 0.0 | 0.0 | 78.0 |

### KPIs: chf-efd8067-p18

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (8 of 13) | 0% (0 of 14) | 30% (8 of 27) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | 100% (5 of 5); on the table 100% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (6 of 8); on the table 88% | 83% (5 of 6); on the table 100% | 79% (11 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 31% (15 of 48) | 17% (2 of 12) | 28% (17 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (15 of 39) | 20% (2 of 10) | 35% (17 of 49) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 59% (3547 of 5997) | 57% (3447 of 5998) | 58% (6994 of 11995) |
|   infantry points that never fought | lower | 58% (919 of 1591) | 90% (1027 of 1147) | 71% (1946 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 60% (12 of 20) | 61% (33 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 0.7 uses a game | 100% (1 of 1); 1.7 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3383 of 5667) | 65% (3362 of 5186) | 62% (6745 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (52%) | 0.0 (0%) | 5.7 (40%) |
| MARCHED: its unit marched | 1.7 (15%) | 0.7 (20%) | 2.3 (16%) |
| CHARGED: its unit charged | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 3.0 (27%) | 0.3 (10%) | 3.3 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (10%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 0.3 (10%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (50%) | 1.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 2.3 | 5.7 | 0.7 | 2.3 |
| not cast | 2.3 | 3.7 | 14.3 | 3.3 | 13.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (36%) | 5.7 (40%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.3 (16%) | 1.0 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 3.3 (23%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 2.0 (55%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (90%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (79 of 127) | 59% (41 of 69) | 61% (120 of 196) |
|   cavalry | - | 75% (9 of 12) | 75% (9 of 12) |
|   character | 100% (9 of 9) | 50% (9 of 18) | 67% (18 of 27) |
|   chariot | 67% (10 of 15) | 100% (2 of 2) | 71% (12 of 17) |
|   infantry | 49% (24 of 49) | 50% (15 of 30) | 49% (39 of 79) |
|   monster | 75% (9 of 12) | 86% (6 of 7) | 79% (15 of 19) |
|   war machine | 64% (27 of 42) | - | 64% (27 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (12%) | 4.7 (50%) | 6.7 (26%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (11%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 2.3 (15%) | 0.3 (4%) | 2.7 (11%) |
| MOVED: a war machine that moved | 1.7 (10%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET IN RANGE | 2.3 (15%) | 2.3 (25%) | 4.7 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.0 (31%) | 1.0 (11%) | 6.0 (24%) |
| SHELTERED: the target was sheltered | 1.3 (8%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 2.7 | 67% | 5.6 pts | 34 pts |
| character | 6.3 | 2.0 | 68% | 4.5 pts | 28 pts |
| chariot | 4.0 | 3.3 | 42% | 22.5 pts | 90 pts |
| infantry | 15.0 | 5.0 | 73% | 5.9 pts | 88 pts |
| monster | 8.0 | 2.3 | 88% | 3.7 pts | 30 pts |
| war machine | 9.0 | 12.3 | 41% | 48.9 pts | 440 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 4.7 | 4.0 |
| Charges that made contact a game | 2.3 | 3.7 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.00 declared, 1.33 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.75 declared, 1.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.15 contact (20 units) | 0.39 declared, 0.29 contact (31 units) | 0.31 declared, 0.24 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Character in a unit | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Character on its own | - | 67% (2 of 3) | 60% (3 of 5) | 62% (5 of 8) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 80% (4 of 5) | - | 71% (5 of 7) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 75% (3 of 4); on the table 100% | 25% (6 of 24) | 76% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 75% (3 of 4); on the table 75% | 38% (9 of 24) | 25% | 40% (4 of 10) | 50% (1 of 2); 2.0 uses a game | 100% (1 of 1); 2.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 94% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 20% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 83% (5 of 6); on the table 100% | - | 59% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 50% (2) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 60% (6 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (22 of 58) | 60% (12 of 20) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (1 of 5) | - |
| Strategy | Joined characters whose unit fought | 33% (3 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 236.7 | 78.0 |
| Movement | Fights charged into per game | 1.7 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +599 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 1 of 6, net +135 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +60 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +30 | 5 of 6, net +111 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (25 of 54) | 54% (22 of 41) |
| Shooting | Points destroyed by shooting units | 82.0 | 0.0 |
| Shooting | War machine shots | 9.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (11 of 27) | - |
| Shooting | Points destroyed by war machines | 78.0 | 41.7 |
| Magic | Magic missiles cast | 3.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 22% (2 of 9) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 1.0 | 1.0 |
| Magic | Wounds caused by other spells | 3.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.7 / 1.0 / 0.3 | 3.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 268.0 | 123.0 |
| Combat | Points run down | 0.0 | 45.0 |
| Combat | Net points per charged fight, damage counted | +142 | +46 |
| Combat | Net per 100 charger points, damage counted | +39.9 | +18.9 |
| Combat | First round won (charged fights) | 100% | 56% |
| Combat | Net points per charged fight | +144 | +76 |
| Combat | Net points per supported fight / lone fight | +30 / +220 | +30 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 3 of 9 |
| Game | Points lost | 286.0 | 456.3 |
| Game | VP from objectives | 690.0 | 760.0 |
| Game | Lone holders (player turns) | 3.7 | 5.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +258 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 742
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +57.2 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| ARMY TABLE | 11.3 | +123.9 | 0.0 | 69.3 | 19.0 | +346.1 | 0.0 | 269.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +111.3 | 0.0 | 0.0 | 0.7 | +4.4 | 0.0 | 15.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 9.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.3 | +295.3 | 356.3 | 125.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.7 | +197.2 | 59.7 | 0.0 | 0.7 | +66.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +43.2 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | 0.3 | +0.7 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 199.7 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1.0 | +13.6 | 40.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.7 | -526.4 | 0.0 | 0.0 | 23.0 | -704.7 | 0.0 | 646.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 79.7 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 439.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 88.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.0 | -406.5 | 0.0 | 79.7 | 5.7 | -435.7 | 0.0 | 199.7 |
| DEFENSIVE ARMY | 3.3 | +0.0 | 0.0 | 208.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -2.1 | 199.7 | 0.0 | 1.3 | -24.4 | 104.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | -60.4 | 0.0 | 41.7 | 8.3 | +44.5 | 0.0 | 61.7 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +2.4 | 34.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +98.7 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | -7.6 | 274.7 | 0.0 | 2.3 | +9.6 | 145.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 239.7 | 0.0 | 3.3 | +0.0 | 225.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 30.0 | +283.3 | 0.0 | 465.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +6.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +11.5 | 20.0 | 0.0 | 1.3 | +2.2 | 45.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 61.7 |
| FIVE ACTION | 98.7 | +5558.1 | 1363.7 | 478.7 | 99.3 | +5218.9 | 378.0 | 994.3 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 211.0 |
| FOLLOW UP WEIGHED | 1.7 | +243.6 | 0.0 | 0.0 | 1.3 | +198.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +128.6 | 314.7 | 0.0 | 3.7 | +246.8 | 225.3 | 15.0 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 11.3 |
| FRIEND CHARGES FIRST | 0.3 | -13.9 | 15.0 | 0.0 | 0.3 | -8.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.7 | 0.0 | 0.0 | 1.3 | -2.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -15.6 | 40.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +519.3 | 0.0 | 0.0 | 19.0 | +1658.1 | 0.0 | 123.3 |
| GUN FIGURES | 2.7 | +2.1 | 0.0 | 0.0 | 0.7 | +35.3 | 41.7 | 123.3 |
| GUN MASK | 3.3 | +208.0 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | +4.2 | 199.7 | 0.0 | 0.7 | +0.1 | 69.3 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 78.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.3 | +0.0 | 114.3 | 15.0 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 399.3 |
| HIS CHARGE DENIED | 0.3 | +80.1 | 199.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 399.3 |
| HIS MOVE AND SHOT | 4.0 | -19.9 | 0.0 | 0.0 | 19.0 | -171.1 | 0.0 | 73.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 399.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.0 | +866.1 | 0.0 | 69.3 | 63.0 | +5919.7 | 0.0 | 384.0 |
| HIS SHOTS BY HIS RUN | 33.0 | +348.3 | 0.0 | 69.3 | 54.3 | +1295.4 | 0.0 | 781.7 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +97.0 | 145.7 | 0.0 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 0.0 | 20.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 11.3 | +1265.2 | 0.0 | 0.0 | 13.7 | +1424.5 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -56.1 | 115.0 | 0.0 | 2.7 | -87.2 | 145.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +42.1 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 22.3 | -306.5 | 0.0 | 37.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 1.3 | +26.0 | 40.0 | 0.0 | 1.7 | +56.4 | 149.0 | 15.0 |
| JOINT LOOK BACK | 0.3 | +4.3 | 20.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +12.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +10.8 | 0.0 | 0.0 | 1.3 | +97.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 0.0 | 504.0 | 4.7 | +0.0 | 133.3 | 15.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.0 | +8.0 | 69.3 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -4.5 | 219.7 | 0.0 | 1.7 | +1.3 | 114.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 2.7 | +37.4 | 0.0 | 211.0 |
| MANOEUVRE | 1.3 | +14.9 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +15.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +206.4 | 0.0 | 0.0 | 0.3 | +48.7 | 0.0 | 0.0 |
| MARCH CHECK | 2.3 | +102.2 | 0.0 | 0.0 | 0.7 | +26.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | +120.2 | 0.0 | 0.0 | 0.7 | +7.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 1.7 | +29.2 | 0.0 | 0.0 | 3.3 | +63.4 | 0.0 | 211.0 |
| MEETS IN TIME | 3.7 | +358.9 | 0.0 | 0.0 | 4.7 | +505.4 | 0.0 | 61.7 |
| MISSILES IN THE MOVE | 8.0 | +176.8 | 0.0 | 0.0 | 2.3 | +103.1 | 0.0 | 199.7 |
| MISSILES NEXT TURN | 11.3 | +105.4 | 0.0 | 0.0 | 3.0 | +58.7 | 0.0 | 199.7 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 9.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +127.4 | 0.0 | 0.0 | 3.7 | +269.3 | 0.0 | 15.0 |
| NEARER NOT NEEDED | 7.3 | +356.3 | 0.0 | 0.0 | 4.7 | +229.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +255.0 | 15.0 | 0.0 | 3.0 | +467.9 | 0.0 | 15.0 |
| NO CHAFF EDGES | 3.0 | +51.6 | 30.0 | 69.3 | 1.7 | +48.0 | 41.7 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -47.1 | 115.0 | 0.0 | 3.3 | -302.1 | 225.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.3 | -323.3 | 0.0 | 0.0 | 3.3 | -44.8 | 0.0 | 11.3 |
| OGRE LOADER SECOND SHOT | 2.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -31.9 | 0.0 | 34.7 | 6.7 | -167.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.7 | -17.4 | 149.0 | 15.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +14.0 | 0.0 | 0.0 | 4.7 | +127.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -18.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +6.5 | 15.0 | 0.0 | 0.7 | +37.8 | 41.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.0 | +35.2 | 121.3 | 0.0 |
| PLAN RESULT | 44.0 | +922.9 | 399.3 | 365.7 | 45.3 | +492.9 | 237.3 | 696.3 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +7.7 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -174.1 | 0.0 | 0.0 | 5.3 | -32.6 | 0.0 | 15.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -2.1 | 0.0 | 0.0 | 1.7 | -16.1 | 0.0 | 15.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.7 | -18.9 | 0.0 | 0.0 |
| QUARTER ODDS | 7.3 | +398.7 | 0.0 | 152.7 | 13.0 | +1165.7 | 145.7 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +18.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +140.1 | 0.0 | 60.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 6.3 | +30.7 | 0.0 | 63.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -68.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +9.3 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +73.0 | 299.7 | 0.0 | 3.7 | -175.1 | 225.3 | 15.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -16.9 | 45.0 | 0.0 |
| RUN DOWN | - | - | - | - | 2.7 | -27.3 | 183.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -0.0 | 0.0 | 0.0 | 0.3 | -33.9 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +13.5 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -66.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -10.9 | 0.0 | 0.0 | 2.7 | -52.0 | 0.0 | 18.0 |
| SET UP BY THE SET | 0.7 | +10.9 | 0.0 | 0.0 | 3.7 | +3.1 | 0.0 | 18.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +37.4 | 0.0 | 211.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 204.7 | 7.3 | +0.0 | 0.0 | 78.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +91.9 | 156.0 | 0.0 | 1.3 | +15.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.4 | 15.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 19.0 | -185.6 | 0.0 | 0.0 | 45.3 | +759.5 | 0.0 | 752.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.7 | +1679.2 | 0.0 | 204.7 | 13.3 | +180.4 | 0.0 | 201.3 |
| SPELL WORTH | - | - | - | - | 3.7 | +47.4 | 199.7 | 199.7 |
| SPELLS IN THE FIGHT | 1.7 | +4.2 | 80.0 | 0.0 | 0.3 | -4.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 82.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -15.6 | 104.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 8.7 | +0.0 | 152.7 | 156.0 |
| STANDS STILL | 56.3 | +0.0 | 1049.0 | 409.3 | 32.7 | +0.0 | 152.7 | 171.0 |
| STAY WORTH | 41.7 | +217.3 | 710.0 | 284.7 | 24.7 | +171.7 | 152.7 | 357.3 |
| STRIKE BY THE ODDS | 0.3 | +3.7 | 15.0 | 0.0 | 1.0 | +20.6 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 2.0 | -3.5 | 0.0 | 40.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +0.1 | 34.7 | 0.0 |
| SUPPORT ADDS | - | - | - | - | 0.7 | +128.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 45.0 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 0.7 | +128.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +17.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.3 | +1.3 | 279.7 | 0.0 | 2.0 | +18.1 | 104.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -16.7 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 73.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 75.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 75.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 239.3 | 47.7 | +0.0 | 0.0 | 489.7 |
| TIED UP BY THE SUM | 1.7 | +186.2 | 95.0 | 0.0 | 0.3 | +41.9 | 41.7 | 0.0 |
| TIME ON OUR SIDE | 46.0 | +601.2 | 44.7 | 169.7 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +0.4 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 90.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 1.3 | -23.3 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | -2.6 | 40.0 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -241.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +12.3 | 79.7 | 15.0 |
| WHOLE FIGHT REACTION | 3.3 | +194.7 | 15.0 | 156.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.7 | +91.3 | 0.0 | 0.0 | 2.0 | +63.8 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 288 | 280 | 93 | 31.00 | +4185 | +45.0 |
| ARMY TABLE | 91 | 91 | 76 | 25.33 | +1531 | +20.1 |
| HIS SHOTS BY HIS RUN | 262 | 254 | 71 | 23.67 | +1026 | +14.5 |
| HOLDER ASSIGNMENT | 75 | 75 | 69 | 23.00 | +4177 | +60.5 |
| GOAL WALK | 84 | 84 | 34 | 11.33 | +2011 | +59.1 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -1105 | -34.5 |
| SHOT RISK POINTS | 193 | 193 | 30 | 10.00 | +2194 | +73.1 |
| DEPLOY BY FIGURES | 54 | 54 | 29 | 9.67 | +367 | +12.6 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| STAY WORTH | 199 | 174 | 22 | 7.33 | +82 | +3.7 |
| FIVE ACTION | 594 | 579 | 21 | 7.00 | +790 | +37.6 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 138 | 114 | 16 | 5.33 | +100 | +6.3 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 15 | 5.00 | -620 | -41.3 |
| THE TABLE AGAIN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CAST JOB | 22 | 22 | 14 | 4.67 | +199 | +14.2 |
| IDLE COST | 67 | 39 | 13 | 4.33 | +123 | +9.5 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +1148 | +88.3 |
| FOUR ROUNDS | 21 | 21 | 12 | 4.00 | +422 | +35.2 |
| NO CHAFF EDGES | 14 | 14 | 12 | 4.00 | +181 | +15.1 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 10 | 3.33 | +88 | +8.8 |
| CHARGE LOSSES | 122 | 122 | 9 | 3.00 | +869 | +96.5 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1326 | +147.3 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +247 | +27.5 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 16 | 13 | 9 | 3.00 | +636 | +70.7 |
| NEXT CHARGE BY LIST | 17 | 14 | 9 | 3.00 | +705 | +78.3 |
| COVER ONCE | 50 | 36 | 7 | 2.33 | +299 | +42.7 |
| FALLS SHORT | 90 | 65 | 7 | 2.33 | +40 | +5.7 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1166 | +166.5 |
| MARCH CHECK | 9 | 8 | 7 | 2.33 | +146 | +20.9 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +10 | +1.4 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +324 | +53.9 |
| MISSILES IN THE MOVE | 31 | 22 | 6 | 2.00 | +180 | +30.0 |
| QUARTER ODDS | 61 | 61 | 6 | 2.00 | +701 | +116.8 |
| RISK BY ARC | 20 | 20 | 6 | 2.00 | +84 | +14.0 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 2.00 | +122 | +20.3 |
| WOUNDS ON THE RANKS | 23 | 23 | 6 | 2.00 | +63 | +10.5 |
| EVASIVE BY THE ODDS | 6 | 6 | 5 | 1.67 | +284 | +56.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +765 | +153.1 |
| SHOTS IN THE MOVE | 129 | 101 | 5 | 1.67 | +311 | +62.2 |
| GUN MASK | 10 | 10 | 4 | 1.33 | +257 | +64.2 |
| HIS MOVE AND SHOT | 69 | 69 | 4 | 1.33 | +19 | +4.8 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MAX FOR POSITIONING | 15 | 14 | 4 | 1.33 | +5 | +1.2 |
| SET UP BY THE SET | 13 | 13 | 4 | 1.33 | +117 | +29.3 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +73 | +18.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| BACKS UP THE FIGHT | 4 | 3 | 3 | 1.00 | +121 | +40.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 3 | 1.00 | +43 | +14.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +8 | +2.7 |
| HIS TURN DENIED | 6 | 6 | 3 | 1.00 | +124 | +41.4 |
| NEARER NOT NEEDED | 36 | 34 | 3 | 1.00 | +147 | +48.9 |
| PROMISE KNOWS THE FIGHT | 9 | 8 | 3 | 1.00 | -55 | -18.2 |
| REDIRECT COUNTER | 9 | 6 | 3 | 1.00 | +18 | +6.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +210 | +105.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +21 | +10.5 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +360 | +180.0 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +44 | +22.2 |
| ONE OBJECTIVE FORMULA | 27 | 21 | 2 | 0.67 | +40 | +20.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -56 | -27.9 |
| SCOUT BY DROPS | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS AFTER THE MOVES | 26 | 26 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -132 | -65.9 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.3 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -13 | -6.6 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +95 | +47.7 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.33 | -3 | -3.4 |
| EXACT ROUND | 13 | 13 | 1 | 0.33 | +15 | +15.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +43 | +43.1 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +25 | +24.7 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +43 | +43.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +217 | +217.2 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -39 | -38.9 |
| OPENS UP IN FULL | 3 | 3 | 1 | 0.33 | +15 | +15.2 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +32 | +32.5 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +23 | +23.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +73 | +72.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +28 | +27.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +7 | +6.6 |
| SET UP TOGETHER | 8 | 4 | 1 | 0.33 | +24 | +24.5 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| SURE REACH TOGETHER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| THE FIGHT MOVES | 13 | 13 | 1 | 0.33 | +31 | +30.9 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | -1 | -0.8 |
| WHOLE FIGHT REACTION | 10 | 10 | 1 | 0.33 | +8 | +7.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 25 | 25 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 64 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 10 | 10 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 20 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 5 | 5 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 30 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 16 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 5 | 5 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 77 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 29 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 26 | 0 | 0.00 | - | - |
| STANDS STILL | 267 | 259 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 6 | 6 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 3.00 | 37.0 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 1.33 | 41.3 |
| ARMY TABLE | rule | 1.33 | 2.00 | 36.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 27.2 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 18.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 0.33 | 18.2 |
| RULE SWITCHED OFF | gate | 0.67 | - | 15.5 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 65.9 |
| WAR ENGINE JOBS | rule | 0.67 | - | 6.6 |
| AFTERMATH BAND | gate | - | 0.33 | 0.8 |
| CHARGE NOW FIRST | rule | - | 0.33 | 3.4 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 38.9 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 163.9 |
| WHO HITS BACK | rule | - | 0.33 | 0.8 |

### Plans: chf-efd8067-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 112 | 109 | 97% |
| Mine | move | 25.0 | 100% | 1197 | 0 | 0% |
| Mine | shoot | 16.7 | 64% | 1024 | 814 | 79% |
| Opponent | charge | 3.7 | 64% | 480 | 401 | 83% |
| Opponent | move | 35.3 | 92% | 1901 | 0 | 0% |
| Opponent | shoot | 6.0 | 39% | 303 | 92 | 30% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: chf-efd8067-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 33% | 100% | 0% | - | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 42 (12) | 42 | 0 | 0 | 25% | 3.0 | 123 (3) | 5 (5) | 7 (4) | 56 (8) | 5 (4) |
| Mine | Clean-up | 1 | 70 (1) | 0 | 70 | 0 | 0% | 6.0 | - | - | 70 (1) | 70 (1) | - |
| Mine | Fast Hammer | 3 | 127 (3) | 10 | 116 | 29 | 33% | 2.0 | - | 101 (2) | 172 (1) | 178 (2) | 0 (1) |
| Mine | Hammer | 8 | 17 (8) | 0 | 17 | 15 | 38% | 2.4 | - | 11 (6) | 38 (2) | 11 (6) | 36 (2) |
| Mine | Shooter | 6 | 141 (6) | 35 | 106 | 33 | 0% | 1.3 | 0 (1) | 262 (2) | 107 (3) | 141 (6) | - |
| Mine | War machine | 8 | 22 (8) | 22 | 0 | 23 | 0% | 1.2 | 187 (1) | 0 (1) | 0 (6) | - | 22 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Chaff | 11 | 118 (11) | 0 | 118 | 55 | 45% | 3.3 | 0 (4) | 600 (1) | 114 (6) | 118 (11) | - |
| Opponent | Character | 6 | 15 (6) | 15 | 0 | 24 | 0% | 2.3 | 18 (5) | 0 (1) | - | 38 (3) | 0 (3) |
| Opponent | Clean-up | 4 | 48 (4) | 41 | 7 | 0 | 25% | 1.7 | - | 123 (1) | 23 (3) | 60 (2) | 35 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 19 (10) | 15 | 3 | 32 | 30% | 2.0 | 34 (2) | 5 (6) | 45 (2) | 21 (8) | 0 (2) |
| Opponent | Holder | 1 | 101 (1) | 0 | 101 | 0 | 100% | - | - | 101 (1) | - | 101 (1) | - |
| Opponent | Shooter | 1 | 225 (1) | 0 | 225 | 0 | 0% | 1.0 | - | 225 (1) | - | 225 (1) | - |

### Charged fights: chf-efd8067-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 240 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 0 | 719 | 5.0 | 1.4 | 144 | 0 | +144 | 1 of 5 | 5 of 5 | +30 | +220 |
| **Mine** | all armies | 3 | 160 | 240 | 1.7 | 1.4 | 144 | 0 | +144 | 1 of 5 | 5 of 5 | +30 | +220 |
| Opponent | Ogre Kingdoms | 1 | 125 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 135 | 3.0 | 1.3 | 45 | 15 | +30 | 2 of 3 | 1 of 3 | -45 | +68 |
| Opponent | Wood Elf Realms | 1 | 0 | 598 | 4.0 | 1.2 | 150 | 0 | +150 | 1 of 4 | 4 of 4 | +104 | +165 |
| **Opponent** | all armies | 3 | 42 | 244 | 3.0 | 1.2 | 81 | 5 | +76 | 3 of 9 | 5 of 9 | +30 | +90 |

### Effective charges: chf-efd8067-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 1 (net +599) | 0 | 0 | 1 (net +0) | 1 (net +60) | 2 (net +30) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 1 (net +135) | 0 | 0 | 1 (net -45) | 1 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +150) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: chf-efd8067-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 369 | 499 | +599 | 599 | 53 | +546 | +148.0 |
| Mine | 76-89% | 1 | 205 | 329 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 252 | 194 | +30 | 108 | 56 | +52 | +20.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 703 | 60 | +60 | 60 | 0 | +60 | +8.5 |
| Mine | All fights | 5 | 356 | 255 | +144 | 175 | 33 | +142 | +39.9 |
| Opponent | Effective (55-75%) | 1 | 110 | 135 | +135 | 135 | 0 | +135 | +122.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 296 | 189 | +111 | 147 | 99 | +48 | +16.2 |
| Opponent | No odds | 3 | 208 | 209 | +0 | 26 | 12 | +14 | +6.9 |
| Opponent | All fights | 9 | 246 | 190 | +76 | 105 | 59 | +46 | +18.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p18 | move | 14 | 5 (36%) | 5 (36%) | 1 (7%) | 8 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

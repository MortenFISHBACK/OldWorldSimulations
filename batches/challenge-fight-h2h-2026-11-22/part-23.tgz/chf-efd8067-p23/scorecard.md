# Doctrine scorecard: chf-efd8067-p23

### Scorecard: chf-efd8067-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 11 | - | 1 | 2 | 0 | 0 | 0 | 200 |
| L2131 | 1 | 1 | Opponent | no | 1 | 4 | 2 | 2 | 1 | 0 | 0 | 340 |
| L2235 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L2429 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 205 |
| **Average** | | | Mine | 67% | 6.0 | 2.0 | 1.0 | 1.3 | 0.0 | 0.0 | 0.0 | 123.3 |
| **Average** | | | Opponent | 33% | 0.5 | 2.7 | 3.0 | 1.7 | 0.3 | 0.0 | 0.0 | 228.3 |

### KPIs: chf-efd8067-p23

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (2 of 16) | 0% (0 of 14) | 7% (2 of 30) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 100% | 100% (6 of 6); on the table 100% | 92% (12 of 13); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 75% (9 of 12); on the table 83% | 100% (7 of 7); on the table 100% | 84% (16 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (3 of 7) | - | 43% (3 of 7) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (6 of 9) | 57% (8 of 14) | 61% (14 of 23) |
| Points that never fought | lower | 23% (1386 of 5997) | 48% (2863 of 5999) | 35% (4249 of 11996) |
|   infantry points that never fought | lower | 59% (981 of 1675) | 53% (689 of 1306) | 56% (1670 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (14 of 21) | 61% (19 of 31) | 63% (33 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3271 of 4866) | 55% (3263 of 5884) | 61% (6534 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (33%) | - | 1.0 (33%) |
| MARCHED: its unit marched | 0.3 (11%) | - | 0.3 (11%) |
| IN COMBAT: engaged in combat | 0.7 (22%) | - | 0.7 (22%) |
| GONE: slain | 1.0 (33%) | - | 1.0 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 0.7 | 1.0 | 1.0 | 2.0 |
| not cast | 3.3 | 7.3 | 1.0 | 3.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (45%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| GONE: slain | 2.0 (60%) | 2.0 (27%) | 0.0 (0%) | 1.0 (33%) | 3.0 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 2.0 (27%) | 1.0 (100%) | 0.0 (0%) | 2.0 (9%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (28 of 55) | 35% (11 of 31) | 45% (39 of 86) |
|   cavalry | 75% (6 of 8) | 40% (6 of 15) | 52% (12 of 23) |
|   character | 0% (0 of 12) | 17% (2 of 12) | 8% (2 of 24) |
|   chariot | 83% (5 of 6) | - | 83% (5 of 6) |
|   infantry | 59% (17 of 29) | 75% (3 of 4) | 61% (20 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (11%) | 2.7 (40%) | 3.7 (23%) |
| CHARGED: it charged | 2.3 (26%) | 2.0 (30%) | 4.3 (28%) |
| IN COMBAT: it fought this turn or the last | 1.3 (15%) | 0.0 (0%) | 1.3 (9%) |
| NO TARGET IN RANGE | 3.0 (33%) | 2.0 (30%) | 5.0 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (15%) | 0.0 (0%) | 1.3 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 1.3 | 91% | 3.5 pts | 27 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 7.0 | 5.0 | 62% | 21.0 pts | 147 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 3.3 | 3.8 |
| Charges that made contact a game | 2.7 | 3.3 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.29 contact (28 units) | 0.38 declared, 0.38 contact (24 units) | 0.42 declared, 0.33 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 100% (4 of 4) | - | 70% (7 of 10) |
| Character in a unit | 100% (2 of 2) | - | 100% (2 of 2) | 100% (4 of 4) |
| Character on its own | 60% (3 of 5) | 100% (2 of 2) | 17% (1 of 6) | 46% (6 of 13) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 100% (4 of 4) | - | 73% (11 of 15) |
| Monster | 20% (1 of 5) | 100% (1 of 1) | - | 33% (2 of 6) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 27% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 67% (4 of 6); on the table 67% | - | 25% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 100% | 17% (1 of 6) | 17% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (6 of 6); on the table 100% | - | 52% | 53% (10 of 19) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 40% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 67% (4) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: chf-efd8067-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 80% (8 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (1 of 3) | 25% (2 of 8) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 123.3 | 228.3 |
| Movement | Fights charged into per game | 2.3 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 9, net +778 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 1 of 9, net +229 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 6, net +98 | 2 of 9, net +91 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +165 | 4 of 9, net +220 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (8 of 29) | 64% (7 of 11) |
| Shooting | Points destroyed by shooting units | 38.0 | 21.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | - |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.3 / 0.0 / 0.7 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 109.7 | 1076.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +112 | +241 |
| Combat | Net per 100 charger points, damage counted | +31.0 | +72.5 |
| Combat | First round won (charged fights) | 86% | 90% |
| Combat | Net points per charged fight | +117 | +242 |
| Combat | Net points per supported fight / lone fight | +53 / +128 | - / +242 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 7 | 4 of 10 |
| Game | Points lost | 964.7 | 607.3 |
| Game | VP from objectives | 666.7 | 556.7 |
| Game | Lone holders (player turns) | 6.0 | 0.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -423 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1572
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: chf-efd8067-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +46.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 21.7 | +201.7 | 0.0 | 593.3 | 17.0 | +150.7 | 0.0 | 273.3 |
| BACKS UP THE FIGHT | 1.3 | +50.5 | 0.0 | 0.0 | 0.7 | +56.4 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -10.7 | 41.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +2.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +47.9 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +29.0 | 0.0 | 0.0 | 0.3 | +17.9 | 0.0 | 41.7 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.7 | +29.7 | 131.0 | 0.0 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.7 | +3.0 | 131.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +9.0 | 38.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.7 | -200.0 | 0.0 | 85.0 | 11.3 | -306.5 | 0.0 | 356.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 357.3 | 118.7 | 2.3 | +0.0 | 436.3 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 188.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 38.7 | 48.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +46.3 | 0.0 | 91.3 |
| COVER ONCE | 8.0 | -546.2 | 0.0 | 364.0 | 5.3 | -262.0 | 0.0 | 78.7 |
| DENIED BY THE FIGHT | 0.7 | -3.7 | 83.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +55.2 | 0.0 | 0.0 | 7.3 | +60.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.7 | 131.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +35.5 | 161.7 | 118.7 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.0 | +229.3 | 81.3 | 83.7 |
| EXACT ROUND | 1.7 | +34.3 | 174.3 | 53.7 | 1.3 | +13.8 | 273.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.0 | +0.8 | 218.7 | 53.7 | 1.3 | +0.0 | 248.0 | 0.0 |
| FALLS SHORT | 10.0 | +44.7 | 0.0 | 460.3 | 11.7 | +170.3 | 0.0 | 332.0 |
| FEATURE BUFFS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +5.8 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +2.2 | 131.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +2.1 | 0.0 | 38.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 18.3 | 0.3 | +0.0 | 0.0 | 52.7 |
| FIVE ACTION | 75.0 | +4729.9 | 588.3 | 1477.7 | 74.0 | +4236.0 | 567.3 | 1178.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 135.3 | 5.0 | +0.0 | 0.0 | 264.0 |
| FOCUS FIRE | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.7 | +192.9 | 0.0 | 0.0 | 1.3 | +375.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +173.6 | 512.7 | 142.7 | 3.3 | +275.7 | 567.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 48.3 | 2.0 | +0.0 | 0.0 | 234.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -9.7 | 75.7 | 0.0 | 0.3 | -18.6 | 131.0 | 0.0 |
| GOAL WALK | 8.3 | +596.2 | 0.0 | 394.7 | 9.7 | +490.9 | 0.0 | 122.0 |
| GUN FIGURES | 0.7 | +3.5 | 38.7 | 43.3 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | -3.0 | 0.0 | 0.0 | 1.0 | +1.3 | 131.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 174.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.3 | +0.0 | 0.0 | 151.3 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 48.3 | 6.3 | +0.0 | 0.0 | 318.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 48.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -8.1 | 0.0 | 18.3 | 3.7 | -19.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 40.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 24.0 | +0.0 | 0.0 | 522.0 | 12.0 | +0.0 | 0.0 | 154.7 |
| HIS RANDOM MOVER COMES | 5.0 | +0.0 | 0.0 | 85.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.0 | +445.3 | 0.0 | 870.7 | 30.3 | +848.3 | 0.0 | 630.0 |
| HIS SHOTS BY HIS RUN | 24.3 | +234.0 | 0.0 | 448.0 | 24.0 | +321.8 | 0.0 | 612.7 |
| HIS TURN DENIED | 1.0 | +27.3 | 121.3 | 0.0 | 0.3 | +2.0 | 24.0 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 84.7 | 10.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.3 | +708.5 | 0.0 | 60.7 | 5.7 | +320.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -110.3 | 471.0 | 118.7 | 3.0 | -109.0 | 410.7 | 0.0 |
| IDLE COST | 4.0 | -68.9 | 0.0 | 364.0 | 9.7 | -117.9 | 0.0 | 235.7 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOIN BY POINTS | 0.3 | +8.6 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | -19.0 | 83.3 | 24.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 48.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +24.5 | 0.0 | 0.0 | 0.7 | +11.3 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 48.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 197.7 | 240.0 | 2.3 | +0.0 | 24.0 | 135.0 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +3.5 | 83.3 | 0.0 | 1.0 | -1.4 | 131.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +12.4 | 0.0 | 0.0 | 1.3 | +26.5 | 0.0 | 77.3 |
| MANOEUVRE | 0.7 | +12.0 | 0.0 | 0.0 | 1.0 | -9.7 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +8.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +148.4 | 0.0 | 156.7 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -0.7 | 0.0 | 156.7 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +20.0 | 0.0 | 40.7 | 1.7 | +47.5 | 0.0 | 77.3 |
| MEETS IN TIME | 5.3 | +209.8 | 0.0 | 0.0 | 3.3 | +63.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +44.1 | 0.0 | 0.0 | 2.7 | +24.7 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 2.3 | +26.3 | 0.0 | 156.7 | 2.3 | +12.7 | 0.0 | 52.7 |
| MISSILES ON ONE TARGET | 0.7 | -15.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 24.0 | 21.7 | 1.3 | +0.0 | 0.0 | 52.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 91.3 |
| MOVE TO CHARGE COMPUTED | 5.3 | +524.3 | 0.0 | 40.0 | 5.0 | +281.2 | 0.0 | 38.7 |
| NEARER NOT NEEDED | 9.7 | +389.5 | 0.0 | 131.0 | 5.0 | +205.9 | 0.0 | 99.3 |
| NEXT CHARGE BY LIST | 3.7 | +354.9 | 0.0 | 0.0 | 3.7 | +240.7 | 0.0 | 38.7 |
| NO CHAFF EDGES | 3.3 | +89.9 | 315.3 | 0.0 | 6.7 | +146.4 | 215.7 | 151.7 |
| NO DOUBLE ROUNDS | 3.7 | -128.7 | 437.0 | 118.7 | 2.7 | -156.9 | 473.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | -11.3 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -132.7 | 126.3 | 159.7 | 2.3 | -79.5 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -63.6 | 0.0 | 0.0 | 5.3 | -97.3 | 0.0 | 77.3 |
| ONE JOINT FIGURE | 0.3 | +3.8 | 41.7 | 24.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.7 | +43.3 | 0.0 | 0.0 | 2.0 | -18.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -34.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +26.8 | 74.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 3.0 | +76.2 | 356.0 | 0.0 | 0.7 | +23.4 | 197.3 | 0.0 |
| OVERRUNS AWAY | 1.3 | +2.1 | 117.3 | 0.0 | 0.7 | +4.7 | 105.7 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +505.6 | 151.3 | 1417.0 | 36.3 | +586.9 | 89.0 | 909.7 |
| PROMISE BY ITS OWN SUM | 8.7 | -359.4 | 0.0 | 40.0 | 7.7 | -238.5 | 0.0 | 38.7 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 14.3 | +2045.0 | 125.0 | 57.3 | 17.7 | +2523.9 | 76.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 3.0 | +29.4 | 0.0 | 96.7 | 4.7 | +75.0 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +19.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +89.8 | 0.0 | 123.7 | 0.7 | +23.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +25.7 | 0.0 | 103.0 | - | - | - | - |
| REDIRECT WEIGHED | 0.3 | +8.4 | 34.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.7 | -285.2 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 41.7 |
| RESERVE FALL BACK | 1.0 | +8.5 | 0.0 | 64.7 | 0.3 | +1.1 | 0.0 | 52.7 |
| RISK BY ARC | 4.3 | +52.2 | 512.7 | 142.7 | 3.0 | -9.2 | 513.7 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -14.7 | 93.3 | 65.0 | - | - | - | - |
| RUN DOWN | 3.3 | -24.5 | 403.0 | 118.7 | 0.3 | -1.1 | 0.0 | 0.0 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 1.0 | +65.0 | 126.3 | 65.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -127.5 | 0.0 | 152.7 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +112.5 | 0.0 | 152.7 | - | - | - | - |
| SET UP TOGETHER | 1.7 | +16.2 | 0.0 | 0.0 | 1.3 | +26.5 | 0.0 | 77.3 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +54.0 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +18.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 84.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +143.9 | 41.7 | 0.0 | 1.3 | +11.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.3 | 34.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 14.0 | -87.3 | 0.0 | 295.3 | 13.7 | -31.7 | 0.0 | 437.7 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.0 | +144.2 | 0.0 | 150.3 | 3.3 | +43.8 | 0.0 | 174.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +54.0 | 0.0 | 0.0 |
| SPELL WORTH | 2.7 | +58.4 | 413.3 | 413.3 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +5.9 | 233.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 238.3 | 8.3 | +0.0 | 0.0 | 38.7 |
| STAND AND SHOOT | 0.7 | -2.6 | 74.7 | 0.0 | 0.3 | -0.2 | 40.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 76.0 |
| STANDS STILL | 26.3 | +0.0 | 75.7 | 378.0 | 30.0 | +0.0 | 0.0 | 481.3 |
| STAY WORTH | 7.7 | +40.5 | 34.0 | 104.0 | 3.7 | +26.8 | 0.0 | 52.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +33.0 | 155.0 | 41.7 |
| STRONG ENOUGH TO HOLD | 1.7 | -31.1 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 48.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.0 | +89.6 | 0.0 | 147.7 | 5.0 | +150.3 | 0.0 | 116.0 |
| SUPPORT WORKED OUT | 7.0 | +89.6 | 0.0 | 147.7 | 5.0 | +150.3 | 0.0 | 116.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 65.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.0 | +15.3 | 245.0 | 118.7 | 1.0 | -0.1 | 196.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 171.7 | 2.3 | +0.0 | 0.0 | 117.3 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 171.7 | 1.3 | +0.0 | 0.0 | 75.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.7 | +0.0 | 0.0 | 610.0 | 32.7 | +0.0 | 0.0 | 552.3 |
| TIED UP BY THE SUM | 3.7 | +372.2 | 471.0 | 118.7 | 0.7 | +84.4 | 60.7 | 0.0 |
| TIME ON OUR SIDE | 26.0 | +271.7 | 0.0 | 359.0 | 20.3 | +159.8 | 0.0 | 410.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 77.3 |
| WHO FIGHTS | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +82.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -140.4 | 0.0 | 48.3 | 1.7 | -163.6 | 0.0 | 83.3 |
| WHOLE FIGHT GAIN | 0.3 | +27.2 | 41.7 | 24.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 0.7 | +396.3 | 0.0 | 0.0 | 0.7 | +42.8 | 0.0 | 74.7 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 156.7 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +2.1 | 0.0 | 0.0 | 0.7 | +23.2 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 116 | 116 | 90 | 30.00 | +974 | +10.8 |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +2650 | +56.4 |
| HIS SHOT LIST | 178 | 167 | 42 | 14.00 | +604 | +14.4 |
| HIS SHOTS BY HIS RUN | 145 | 138 | 29 | 9.67 | +201 | +6.9 |
| NO CHAFF EDGES | 30 | 28 | 25 | 8.33 | +542 | +21.7 |
| DEPLOY BY FIGURES | 47 | 47 | 24 | 8.00 | +212 | +8.8 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -637 | -27.7 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 21 | 7.00 | -1793 | -85.4 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 31 | 24 | 20 | 6.67 | +360 | +18.0 |
| FIVE ACTION | 447 | 429 | 19 | 6.33 | +298 | +15.7 |
| GOAL WALK | 54 | 50 | 18 | 6.00 | +865 | +48.0 |
| TIME ON OUR SIDE | 139 | 125 | 15 | 5.00 | +20 | +1.3 |
| NEXT CHARGE BY LIST | 22 | 18 | 14 | 4.67 | +339 | +24.2 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 14 | 4.67 | +313 | +22.4 |
| MEETS IN TIME | 26 | 26 | 12 | 4.00 | +505 | +42.0 |
| FOUR ROUNDS | 23 | 19 | 11 | 3.67 | +277 | +25.1 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1704 | +189.3 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +63 | +7.0 |
| SUPPORT ADDS | 36 | 34 | 9 | 3.00 | +271 | +30.1 |
| SUPPORT WORKED OUT | 36 | 34 | 9 | 3.00 | +271 | +30.1 |
| IDLE COST | 41 | 28 | 8 | 2.67 | +55 | +6.9 |
| TIED UP BY THE SUM | 13 | 9 | 8 | 2.67 | +300 | +37.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 34 | 32 | 7 | 2.33 | +30 | +4.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 96 | 95 | 6 | 2.00 | +635 | +105.8 |
| CAST JOB | 6 | 6 | 5 | 1.67 | +1 | +0.2 |
| NEARER NOT NEEDED | 44 | 42 | 5 | 1.67 | +183 | +36.7 |
| SHOT RISK POINTS | 83 | 79 | 5 | 1.67 | +72 | +14.5 |
| THE ROW IN ITS ORDER | 18 | 5 | 5 | 1.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 9 | 9 | 4 | 1.33 | +638 | +159.5 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +107 | +26.8 |
| MAIN BODY KEEPS ITS BAND | 4 | 4 | 4 | 1.33 | +206 | +51.6 |
| OPENS UP IN FULL | 11 | 8 | 4 | 1.33 | +52 | +13.0 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +29 | +7.2 |
| RISK BY ARC | 22 | 18 | 4 | 1.33 | +131 | +32.7 |
| BACKS UP THE FIGHT | 6 | 4 | 3 | 1.00 | +50 | +16.6 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +141 | +46.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MAX FOR POSITIONING | 12 | 10 | 3 | 1.00 | +6 | +1.9 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +195 | +65.0 |
| SET UP BY THE SET | 3 | 3 | 3 | 1.00 | +224 | +74.8 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +220 | +73.2 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +63 | +31.5 |
| CHARGE NOW FIRST | 16 | 16 | 2 | 0.67 | -100 | -50.1 |
| COVER ONCE | 40 | 26 | 2 | 0.67 | +0 | +0.2 |
| EXACT ROUND | 9 | 8 | 2 | 0.67 | +11 | +5.7 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -57 | -28.4 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -104 | -52.0 |
| REDIRECT COUNTER | 11 | 10 | 2 | 0.67 | +3 | +1.6 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +99 | +49.5 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +129 | +64.5 |
| WHOLE FIGHT DANGER | 12 | 12 | 2 | 0.67 | +21 | +10.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +139 | +139.3 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -32 | -32.2 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE IN THE FIGHT | 2 | 2 | 1 | 0.33 | +92 | +91.6 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +27 | +26.9 |
| CHARGE LOSSES | 63 | 63 | 1 | 0.33 | +1 | +0.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -142 | -142.4 |
| EDGE GIVE GROUND | 3 | 2 | 1 | 0.33 | +84 | +84.2 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +6 | +6.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +56 | +55.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +24 | +24.1 |
| HONEST WORTH | 21 | 17 | 1 | 0.33 | +3 | +2.7 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOIN BY POINTS | 1 | 1 | 1 | 0.33 | +26 | +25.9 |
| LOST AFTER ESCAPE | 6 | 5 | 1 | 0.33 | +5 | +5.1 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +36 | +36.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +24 | +24.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -445 | -445.1 |
| MISSILES IN THE MOVE | 13 | 11 | 1 | 0.33 | +4 | +3.5 |
| NO DOUBLE ROUNDS | 19 | 15 | 1 | 0.33 | +3 | +2.7 |
| ONE OBJECTIVE FORMULA | 20 | 14 | 1 | 0.33 | +40 | +40.0 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +4 | +3.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +25 | +25.2 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -26 | -25.6 |
| SCOUT BY DROPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 40 | 37 | 1 | 0.33 | +4 | +3.5 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +22 | +22.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +20 | +19.5 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 8 | 0 | 0.00 | - | - |
| FALLS SHORT | 65 | 55 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 37 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 108 | 106 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 17 | 17 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 30 | 30 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 12 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 8 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 222 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 7 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 7 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 169 | 164 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE FIGHT MOVES | 9 | 7 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 199 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 3.33 | 85.4 |
| ARMY TABLE | rule | 3.00 | 3.00 | 40.0 |
| JOB FIRST | gate | 3.67 | 2.33 | 24.7 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 17.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 52.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 50.1 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 2.5 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 52.0 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 32.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 142.4 |
| FIGHT ORDER BAND | gate | 0.33 | - | 1.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 76.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 445.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 1.8 |
| REFUSING RETIRES | rule | - | 0.33 | 25.6 |
| RESERVE FALL BACK | rule | 0.33 | - | 29.3 |
| TURN GATE | gate | 0.33 | - | 33.9 |

### Plans: chf-efd8067-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 85% | 614 | 477 | 78% |
| Mine | move | 31.7 | 89% | 1405 | 0 | 0% |
| Mine | shoot | 1.0 | 33% | 35 | 28 | 82% |
| Mine | support | 0.7 | 100% | 27 | 0 | 0% |
| Opponent | charge | 3.0 | 89% | 365 | 517 | 142% |
| Opponent | join | 0.3 | 100% | 37 | 0 | 0% |
| Opponent | move | 31.0 | 92% | 1234 | 0 | 0% |
| Opponent | shoot | 2.0 | 33% | 136 | 70 | 51% |

### Battle groups: chf-efd8067-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 22% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 19 (5) | 0 | 19 | 81 | 20% | 2.2 | 0 (2) | 23 (2) | 42 (1) | 0 (2) | 29 (3) |
| Mine | Character | 7 | 33 (7) | 33 | 0 | 63 | 14% | 2.5 | 31 (4) | 29 (1) | - | 71 (2) | 12 (3) |
| Mine | Clean-up | 1 | 127 (1) | 127 | 0 | 100 | 0% | 4.0 | 127 (1) | - | - | 127 (1) | - |
| Mine | Fast Hammer | 4 | 33 (4) | 33 | 0 | 88 | 0% | 3.0 | 36 (3) | 0 (1) | - | 68 (2) | 0 (2) |
| Mine | Hammer | 5 | 7 (5) | 7 | 0 | 33 | 20% | 2.5 | 0 (1) | 0 (2) | 22 (2) | 0 (3) | 21 (2) |
| Mine | Holder | 7 | 41 (7) | 0 | 41 | 29 | 43% | 3.8 | 121 (2) | 15 (4) | 0 (1) | 80 (4) | 0 (3) |
| Mine | Shooter | 5 | 193 (5) | 81 | 112 | 63 | 0% | 1.0 | 164 (1) | 245 (2) | 155 (2) | 49 (3) | 436 (2) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 44 | 0% | 1.2 | 0 (3) | - | - | - | 0 (3) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Character | 8 | 89 (8) | 89 | 0 | 16 | 38% | 2.8 | 209 (3) | 44 (4) | - | 40 (5) | 169 (2) |
| Opponent | Clean-up | 1 | 132 (1) | 132 | 0 | 0 | 0% | 5.0 | 132 (1) | - | - | - | 132 (1) |
| Opponent | Fast Hammer | 5 | 8 (5) | 8 | 0 | 55 | 40% | 2.3 | 0 (2) | 14 (3) | - | 0 (1) | 10 (4) |
| Opponent | Hammer | 10 | 57 (10) | 57 | 0 | 38 | 10% | 3.3 | 60 (6) | 68 (3) | 0 (1) | 76 (6) | 15 (4) |
| Opponent | Holder | 4 | 24 (4) | 0 | 24 | 0 | 75% | 6.0 | - | 45 (2) | 0 (1) | - | 29 (3) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |

### Charged fights: chf-efd8067-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 114 | 689 | 6.0 | 1.2 | 115 | 12 | +103 | 0 of 6 | 5 of 6 | +53 | +113 |
| Mine | Vampire Counts | 1 | 0 | 205 | 1.0 | 1.0 | 205 | 0 | +205 | 0 of 1 | 1 of 1 | - | +205 |
| **Mine** | all armies | 3 | 77 | 298 | 2.3 | 1.1 | 128 | 10 | +117 | 0 of 7 | 6 of 7 | +53 | +128 |
| Opponent | Warriors of Chaos | 2 | 32 | 1052 | 3.5 | 1.0 | 300 | 0 | +300 | 3 of 7 | 6 of 7 | - | +300 |
| Opponent | Wood Elf Realms | 1 | 0 | 444 | 3.0 | 1.0 | 148 | 42 | +106 | 1 of 3 | 3 of 3 | - | +106 |
| **Opponent** | all armies | 3 | 22 | 849 | 3.3 | 1.0 | 255 | 13 | +242 | 4 of 10 | 9 of 10 | - | +242 |

### Effective charges: chf-efd8067-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 0 | 4 (net +98) | 1 (net +125) | 1 | 0% (0 of 5) |
| Mine | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +205) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 7 | 1 (net +778) | 0 | 1 (net +229) | 0 | 1 (net +60) | 3 (net +210) | 1 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 1 (net -54) | 1 (net +122) | 1 (net +250) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 178 | 165 | +165 | 165 | 49 | +116 | +65.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 439 | 114 | +98 | 130 | 18 | +112 | +25.5 |
| Mine | No odds | 1 | 411 | 102 | +102 | 102 | 0 | +102 | +24.8 |
| Mine | All fights | 7 | 360 | 127 | +117 | 136 | 24 | +112 | +31.0 |
| Opponent | Long shot (under 50%) | 1 | 494 | 343 | +778 | 778 | 0 | +778 | +157.5 |
| Opponent | Effective (55-75%) | 1 | 365 | 129 | +229 | 247 | 0 | +247 | +67.7 |
| Opponent | 76-89% | 1 | 126 | 72 | -54 | 72 | 126 | -54 | -42.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 309 | 230 | +220 | 232 | 14 | +218 | +70.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 496 | 66 | +91 | 91 | 0 | +91 | +18.3 |
| Opponent | No odds | 1 | 116 | 222 | +405 | 559 | 171 | +388 | +334.1 |
| Opponent | All fights | 10 | 333 | 182 | +242 | 276 | 35 | +241 | +72.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p23 | move | 17 | 4 (24%) | 2 (12%) | 5 (29%) | 8 (47%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

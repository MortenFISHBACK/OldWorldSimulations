# Doctrine scorecard: chf-efd8067-p48

### Scorecard: chf-efd8067-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 3 | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | - | 1 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 5 | 0 | 0 | 0 | 250 |
| L3033 | 3 | 1 | Mine | yes | 13 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 6 | 1 | 7 | 2 | 0 | 0 | 0 | 38 |
| **Average** | | | Mine | 33% | 8.0 | 4.5 | 2.3 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 67% | 3.0 | 2.0 | 4.3 | 2.7 | 0.0 | 0.0 | 0.0 | 96.0 |

### KPIs: chf-efd8067-p48

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 35% (6 of 17) | 19% (6 of 32) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 25% (1 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 75% | 100% (5 of 5); on the table 100% | 67% (6 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 33% (6 of 18) | 43% (18 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (12 of 21) | 46% (6 of 13) | 53% (18 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 27% (1595 of 5999) | 37% (2194 of 6000) | 32% (3789 of 11999) |
|   infantry points that never fought | lower | 34% (262 of 780) | 45% (860 of 1918) | 42% (1122 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 72% (13 of 18) | 65% (22 of 34) | 67% (35 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2920 of 4808) | 56% (3364 of 5962) | 58% (6284 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (50%) | 2.3 (58%) | 4.3 (54%) |
| MARCHED: its unit marched | 0.3 (8%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.0 (0%) | 0.3 (4%) |
| GONE: slain | 0.7 (17%) | 1.7 (42%) | 2.3 (29%) |
| STUPIDITY: Stupidity | 0.7 (17%) | 0.0 (0%) | 0.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 2.3 | 1.0 | 6.0 | 1.0 | 0.0 |
| not cast | 5.3 | 0.7 | 5.0 | 8.0 | 5.0 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 4.3 (54%) | 2.0 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (19%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.7 (31%) | 0.0 (0%) | 1.7 (33%) | 2.3 (29%) | 2.3 (47%) | 1.7 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (50%) | 0.0 (0%) | 3.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.7 a game | 0.5 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 50% (1 of 2) | 67% (2 of 3) |
| the unit moved after it | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 6) | 61% (56 of 92) | 57% (56 of 98) |
|   cavalry | - | 67% (28 of 42) | 67% (28 of 42) |
|   character | 0% (0 of 6) | 47% (7 of 15) | 33% (7 of 21) |
|   infantry | - | 60% (21 of 35) | 60% (21 of 35) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (17%) | 4.3 (36%) | 4.7 (33%) |
| CHARGED: it charged | 0.7 (33%) | 4.7 (39%) | 5.3 (38%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (50%) | 0.7 (6%) | 1.7 (12%) |
| NO TARGET IN RANGE | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (6%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.0 (8%) | 1.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.7 | 3.3 | 83% | 3.8 pts | 53 pts |
| character | 2.3 | 1.3 | 43% | 13.9 pts | 32 pts |
| infantry | 8.7 | 5.3 | 62% | 4.7 pts | 41 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 6.7 | 5.7 |
| Charges that made contact a game | 2.3 | 5.0 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | - | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.25 contact (20 units) | 0.65 declared, 0.48 contact (31 units) | 0.63 declared, 0.39 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 73% (8 of 11) | 100% (2 of 2) | 100% (1 of 1) | 79% (11 of 14) |
| Character in a unit | 100% (2 of 2) | 100% (5 of 5) | 0% (0 of 1) | 88% (7 of 8) |
| Character on its own | 100% (3 of 3) | 100% (1 of 1) | 0% (0 of 5) | 44% (4 of 9) |
| Infantry | 67% (8 of 12) | 67% (2 of 3) | - | 67% (10 of 15) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 0% (0 of 2); on the table 100% | 50% (12 of 24) | 33% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | - | 14% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 100% (5 of 5); on the table 100% | 33% (6 of 18) | 37% | 65% (22 of 34) | 50% (2 of 4); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (8) | 67% (2) | 59% (10) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.67 | 3.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 2.00 | 0.67 | 2.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: chf-efd8067-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 45% (5 of 11) | 71% (10 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 44% (4 of 9) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 43% (3 of 7) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 0.0 | 96.0 |
| Movement | Fights charged into per game | 2.0 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 3 of 11, net -88 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 11, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +0 | 2 of 11, net +129 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +249 | 5 of 11, net +131 |
| Shooting | Shots by shooting units (incl. breath weapons) | - | 19.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 43% (25 of 58) |
| Shooting | Points destroyed by shooting units | 0.0 | 72.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | - | 3.3 |
| Magic | Points destroyed by magic (all spells) | 6.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.0 / 0.7 | 0.3 / 1.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 399.3 | 422.0 |
| Combat | Points run down | 38.0 | 23.3 |
| Combat | Net points per charged fight, damage counted | +177 | +75 |
| Combat | Net per 100 charger points, damage counted | +46.6 | +24.7 |
| Combat | First round won (charged fights) | 100% | 79% |
| Combat | Net points per charged fight | +146 | +64 |
| Combat | Net points per supported fight / lone fight | +140 / +147 | +147 / +58 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 5 of 14 |
| Game | Points lost | 645.7 | 549.3 |
| Game | VP from objectives | 593.3 | 810.0 |
| Game | Lone holders (player turns) | 8.0 | 3.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -257 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1195
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: chf-efd8067-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +19.6 | 0.0 | 0.0 |
| ARMY TABLE | 21.3 | +153.8 | 0.0 | 537.3 | 33.0 | +490.3 | 0.0 | 260.7 |
| BACKS UP THE FIGHT | 1.0 | +55.5 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -4.5 | 20.0 | 0.0 |
| CAST JOB | 1.3 | +5.7 | 76.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +13.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 78.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 4.0 | +125.8 | 0.0 | 30.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 2.7 | -2.7 | 0.0 | 38.0 |
| CHALLENGE BY POINTS | 0.7 | +20.5 | 0.0 | 101.3 | 1.7 | +131.8 | 0.0 | 0.0 |
| CHALLENGE IN THE FIGHT | 1.3 | -26.5 | 0.0 | 57.7 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -20.6 | 57.7 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 1.0 | -5.7 | 0.0 | 0.0 | 0.7 | -42.5 | 20.0 | 0.0 |
| CHARGE LOSSES | 23.7 | -677.4 | 0.0 | 782.0 | 13.0 | -535.7 | 0.0 | 76.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 57.7 | - | - | - | - |
| CHARGE NOW FIRST | 2.0 | +0.0 | 129.0 | 175.0 | 2.7 | +0.0 | 244.3 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.0 | +0.0 | 0.0 | 213.7 | 8.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +13.1 | 0.0 | 0.0 | 0.7 | +48.3 | 0.0 | 78.0 |
| COVER ONCE | 9.7 | -813.3 | 0.0 | 337.7 | 14.7 | -534.4 | 0.0 | 84.7 |
| DENIED BY THE FIGHT | 1.3 | -5.1 | 114.0 | 159.0 | 0.3 | -2.9 | 57.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +59.8 | 0.0 | 0.0 | 9.3 | -113.8 | 0.0 | 34.7 |
| DUEL STOPS AT THE KILL | 0.7 | -10.0 | 0.0 | 0.0 | 0.3 | -47.7 | 0.0 | 0.0 |
| EXACT ROUND | 3.0 | -16.7 | 258.0 | 159.0 | 3.0 | +26.2 | 261.7 | 42.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.7 | +19.6 | 274.3 | 216.7 | 2.7 | +0.0 | 309.7 | 42.0 |
| FALLS SHORT | 23.3 | +295.7 | 0.0 | 327.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +41.5 | 131.3 | 99.3 | 0.3 | +5.4 | 57.7 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.7 | +27.9 | 0.0 | 38.0 |
| FIVE ACTION | 79.7 | +5655.7 | 403.3 | 1637.3 | 98.7 | +7218.0 | 601.3 | 578.0 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 394.3 | 10.0 | +0.0 | 0.0 | 69.3 |
| FOLLOW UP WEIGHED | 0.7 | +38.5 | 0.0 | 0.0 | 1.3 | +93.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +236.4 | 327.3 | 216.7 | 5.0 | +353.5 | 511.3 | 42.0 |
| FREED FROM HIS FIGHT | 4.7 | +0.0 | 0.0 | 118.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -6.3 | 101.3 | 0.0 |
| GOAL WALK | 7.7 | +999.6 | 0.0 | 124.0 | 21.7 | +1634.7 | 0.0 | 76.0 |
| HALF WHEN STILL FLEEING | 1.0 | -2.1 | 38.0 | 16.7 | 1.3 | +0.1 | 81.0 | 42.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 118.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 93.3 | 25.0 | 0.3 | +0.0 | 0.0 | 42.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 93.3 | 25.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 16.7 | +0.0 | 0.0 | 658.0 | 11.0 | +0.0 | 0.0 | 76.0 |
| HIS CHARGE DENIED | 1.0 | +48.1 | 114.0 | 101.3 | 0.3 | +17.3 | 57.7 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 92.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 8.3 | +0.0 | 0.0 | 186.0 | 6.3 | +0.0 | 0.0 | 38.0 |
| HIS MOVE AND SHOT | 6.7 | -58.4 | 0.0 | 62.0 | 1.0 | -1.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.0 | +0.0 | 0.0 | 121.3 | 6.7 | +0.0 | 0.0 | 222.7 |
| HIS OWN BEST MOVE | 12.0 | +0.0 | 0.0 | 186.0 | 10.7 | +0.0 | 0.0 | 166.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 63.7 | +1215.3 | 0.0 | 851.0 | 33.0 | +282.8 | 0.0 | 222.7 |
| HIS SHOTS BY HIS RUN | 64.7 | +892.7 | 0.0 | 1276.3 | 28.3 | +177.3 | 0.0 | 194.7 |
| HIS TURN DENIED | 0.7 | +8.0 | 69.3 | 57.7 | 0.3 | +3.2 | 20.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 198.7 | 10.7 | +0.0 | 0.0 | 76.0 |
| HOLDER ASSIGNMENT | 10.0 | +578.4 | 0.0 | 99.3 | 7.3 | +535.1 | 0.0 | 76.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.0 | -137.4 | 242.7 | 216.7 | 4.3 | -187.7 | 488.7 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| IDLE COST | 16.7 | -191.6 | 0.0 | 75.0 | - | - | - | - |
| JOINT CHARGE NOW | 1.7 | +24.9 | 207.3 | 126.3 | 1.3 | -1.1 | 120.7 | 42.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.0 | 57.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +25.3 | 0.0 | 0.0 | 0.7 | +40.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 189.0 | 249.7 | 2.0 | +0.0 | 0.0 | 209.3 |
| LONG SHOT | 0.3 | +0.8 | 0.0 | 0.0 | 1.0 | +11.2 | 120.7 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +10.6 | 169.3 | 99.3 | 1.3 | -0.1 | 81.0 | 42.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -12.6 | 0.0 | 45.3 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 82.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +64.4 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.9 | 0.0 | 0.0 | 1.0 | +45.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +3.7 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -100.3 | 0.0 | 0.0 | 0.3 | -23.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +33.1 | 0.0 | 25.0 | 1.3 | +18.0 | 0.0 | 6.3 |
| MEETS IN TIME | 3.3 | +190.8 | 0.0 | 0.0 | 5.0 | +92.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +11.6 | 0.0 | 20.0 | 5.7 | +203.4 | 0.0 | 69.3 |
| MISSILES NEXT TURN | 5.0 | +12.5 | 0.0 | 20.0 | 5.3 | +106.7 | 0.0 | 69.3 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -9.6 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +686.6 | 0.0 | 0.0 | 7.3 | +473.5 | 0.0 | 212.0 |
| NEARER NOT NEEDED | 8.0 | +321.4 | 0.0 | 138.0 | 7.7 | +323.7 | 0.0 | 46.7 |
| NEXT CHARGE BY LIST | 4.0 | +565.7 | 0.0 | 0.0 | 6.3 | +410.8 | 0.0 | 170.0 |
| NO CHAFF EDGES | 1.3 | +75.2 | 69.3 | 0.0 | 3.3 | +79.3 | 199.0 | 91.3 |
| NO DOUBLE ROUNDS | 4.3 | -247.1 | 327.3 | 216.7 | 3.7 | -157.3 | 432.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 22.7 | - | - | - | - |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -2.5 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -80.6 | 6.3 | 38.3 | 5.3 | -214.1 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +1.5 | 84.7 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -93.6 | 0.0 | 25.0 | 7.0 | -121.8 | 0.0 | 80.0 |
| ONE JOINT FIGURE | 1.7 | +2.0 | 207.3 | 41.7 | 0.3 | +13.2 | 0.0 | 42.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -58.0 | 0.0 | 66.7 | 3.0 | -130.7 | 0.0 | 38.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.7 | +18.6 | 69.3 | 0.0 | 1.0 | +17.5 | 101.3 | 0.0 |
| OVERRUNS AWAY | 2.3 | +27.5 | 137.7 | 25.0 | - | - | - | - |
| PATHS CROSS | 0.3 | -3.9 | 0.0 | 0.0 | 1.0 | +24.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -19.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 42.3 | +253.5 | 236.7 | 1166.0 | 45.3 | +435.0 | 292.3 | 501.3 |
| PRIZE BY WORTH | 0.3 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -35.9 | 0.0 | 0.0 | 15.7 | -638.9 | 0.0 | 42.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -0.5 | 0.0 | 0.0 | 1.0 | -5.0 | 0.0 | 34.7 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -41.7 | 0.0 | 0.0 |
| QUARTER ODDS | 20.3 | +2603.2 | 69.3 | 766.7 | 27.7 | +2830.2 | 228.7 | 348.7 |
| REDIRECT COUNTER | 5.3 | +328.2 | 0.0 | 124.3 | 1.0 | -8.9 | 0.0 | 12.7 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 97.7 | 1.3 | +0.0 | 0.0 | 12.7 |
| REDIRECT WEIGHED | 1.3 | +0.0 | 0.0 | 101.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 4.0 | -133.8 | 0.0 | 42.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 57.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +25.3 | 0.0 | 49.0 | 0.3 | +2.9 | 0.0 | 0.0 |
| RISK BY ARC | 4.3 | -68.9 | 289.3 | 216.7 | 3.3 | +119.5 | 390.0 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -2.9 | 44.3 | 16.7 | - | - | - | - |
| RUN DOWN | 4.3 | -99.1 | 321.0 | 216.7 | 0.7 | -2.2 | 81.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | -0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.7 | -75.0 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +5.2 | 12.7 | 32.7 | 0.3 | +30.1 | 16.7 | 0.0 |
| SET CREDITED ONCE | 5.7 | -192.4 | 0.0 | 96.7 | 0.3 | -4.9 | 0.0 | 6.3 |
| SET UP BY THE SET | 8.0 | +125.8 | 38.0 | 194.7 | 1.0 | +4.9 | 0.0 | 6.3 |
| SET UP TOGETHER | 0.7 | +1.6 | 0.0 | 16.7 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 15.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +24.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -0.8 | 38.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 44.3 | -359.1 | 0.0 | 833.0 | 11.0 | +100.1 | 0.0 | 34.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 18.0 | +226.9 | 0.0 | 149.3 |
| SPELL WORTH | 2.0 | +3.2 | 0.0 | 0.0 | 0.7 | +2.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 267.7 | 7.7 | +0.0 | 0.0 | 104.0 |
| STAND AND SHOOT | 1.0 | -12.9 | 116.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 76.0 | 0.0 | - | - | - | - |
| STANDS STILL | 11.3 | +0.0 | 76.0 | 284.7 | 38.7 | +0.0 | 90.0 | 19.0 |
| STAY WORTH | 0.7 | +1.8 | 76.0 | 0.0 | 11.3 | +49.5 | 0.0 | 84.0 |
| STRIKE BY THE ODDS | 1.0 | +3.5 | 63.3 | 49.0 | 0.3 | +0.8 | 0.0 | 46.7 |
| STRONG ENOUGH TO HOLD | 1.7 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN ONCE | - | - | - | - | 0.3 | -0.2 | 57.7 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +718.1 | 0.0 | 156.7 | 7.3 | +370.1 | 0.0 | 96.7 |
| SUPPORT NARROWED | 1.3 | +0.0 | 129.0 | 49.3 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +718.1 | 0.0 | 156.7 | 7.3 | +370.1 | 0.0 | 96.7 |
| SURE REACH TOGETHER | 0.3 | +5.6 | 0.0 | 0.0 | 0.7 | +4.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 62.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.7 | +47.1 | 122.7 | 74.3 | 1.0 | +0.2 | 108.0 | 42.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -98.3 | 0.0 | 42.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 69.3 |
| THE ROW KEEPS ITS WAY | 6.7 | +0.0 | 0.0 | 46.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 46.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 715.3 | 46.0 | +0.0 | 0.0 | 250.7 |
| TIED UP BY THE SUM | 1.0 | +65.9 | 50.7 | 117.3 | 1.7 | +224.4 | 180.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 54.3 | +508.8 | 0.0 | 122.7 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 135.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +2.5 | 46.7 | 25.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | -13.8 | 91.0 | 32.7 | 1.0 | -6.8 | 110.3 | 0.0 |
| WHO HITS BACK | 0.3 | +28.3 | 0.0 | 25.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -270.9 | 0.0 | 230.0 | 3.3 | -444.7 | 0.0 | 76.0 |
| WHOLE FIGHT GAIN | 0.7 | +17.3 | 84.7 | 0.0 | 0.3 | +3.3 | 0.0 | 42.0 |
| WHOLE FIGHT REACTION | 1.3 | +94.4 | 34.7 | 56.0 | 3.3 | +168.6 | 207.7 | 173.0 |
| WOUNDS ON THE RANKS | 8.3 | +329.7 | 0.0 | 0.0 | 1.7 | +10.8 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 163 | 163 | 118 | 39.33 | +2019 | +17.1 |
| HIS SHOT LIST | 290 | 277 | 54 | 18.00 | +204 | +3.8 |
| HOLDER ASSIGNMENT | 52 | 52 | 46 | 15.33 | +2585 | +56.2 |
| FIVE ACTION | 535 | 511 | 31 | 10.33 | +1140 | +36.8 |
| HIS SHOTS BY HIS RUN | 279 | 272 | 31 | 10.33 | +244 | +7.9 |
| DEPLOY BY FIGURES | 49 | 49 | 30 | 10.00 | +280 | +9.3 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -884 | -32.7 |
| QUARTER ODDS | 144 | 138 | 27 | 9.00 | +2085 | +77.2 |
| HARD STAY DROPPED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 74 | 74 | 25 | 8.33 | -2024 | -81.0 |
| TIME ON OUR SIDE | 163 | 125 | 25 | 8.33 | +60 | +2.4 |
| GOAL WALK | 88 | 86 | 23 | 7.67 | +1608 | +69.9 |
| MOVE TO CHARGE COMPUTED | 41 | 34 | 23 | 7.67 | +1385 | +60.2 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| SHOT RISK POINTS | 166 | 163 | 17 | 5.67 | +108 | +6.4 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 27 | 15 | 5.00 | +1142 | +76.1 |
| COVER ONCE | 73 | 47 | 14 | 4.67 | +122 | +8.7 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 29 | 27 | 12 | 4.00 | +582 | +48.5 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +71 | +7.9 |
| NO CHAFF EDGES | 14 | 13 | 9 | 3.00 | +355 | +39.5 |
| CHAFF PASSED | 8 | 8 | 8 | 2.67 | -8 | -1.0 |
| MEETS IN TIME | 25 | 25 | 8 | 2.67 | +212 | +26.5 |
| CHAFF IN THE MOVE | 12 | 12 | 7 | 2.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +457 | +65.3 |
| IDLE COST | 50 | 37 | 7 | 2.33 | +25 | +3.6 |
| SUPPORT ADDS | 34 | 30 | 7 | 2.33 | +118 | +16.9 |
| SUPPORT WORKED OUT | 34 | 30 | 7 | 2.33 | +118 | +16.9 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +395 | +65.8 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| SET UP BY THE SET | 27 | 27 | 6 | 2.00 | +466 | +77.8 |
| CHARGE LOSSES | 110 | 110 | 5 | 1.67 | +570 | +113.9 |
| MAX FOR POSITIONING | 10 | 10 | 5 | 1.67 | +6 | +1.3 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 5 | 1.67 | -17 | -3.3 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +158 | +31.5 |
| TIED UP BY THE SUM | 8 | 6 | 5 | 1.67 | +163 | +32.7 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +197 | +49.2 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +61 | +15.2 |
| RISK BY ARC | 23 | 21 | 4 | 1.33 | +56 | +14.1 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +13 | +3.2 |
| WHOLE FIGHT REACTION | 14 | 14 | 4 | 1.33 | +110 | +27.5 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 18 | 16 | 3 | 1.00 | +4 | +1.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +196 | +65.3 |
| NEARER NOT NEEDED | 47 | 44 | 3 | 1.00 | +113 | +37.8 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +84 | +28.2 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +106 | +35.3 |
| WOUNDS ON THE RANKS | 30 | 30 | 3 | 1.00 | +22 | +7.3 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +5 | +2.6 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.67 | +84 | +41.9 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 4 | 3 | 2 | 0.67 | +92 | +45.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -12 | -6.0 |
| ONE JOINT FIGURE | 6 | 6 | 2 | 0.67 | +24 | +11.8 |
| REDIRECT COUNTER | 19 | 15 | 2 | 0.67 | +124 | +62.0 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | -13 | -6.7 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +10 | +4.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +15 | +7.3 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +112 | +56.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +59 | +58.9 |
| BACKS UP THE FIGHT | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +34 | +33.8 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -113 | -113.1 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 19 | 19 | 1 | 0.33 | +24 | +23.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +21 | +20.8 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +13 | +12.9 |
| HONEST WORTH | 25 | 23 | 1 | 0.33 | +28 | +27.9 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.1 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +10 | +10.2 |
| LOST AFTER ESCAPE | 12 | 12 | 1 | 0.33 | +12 | +12.5 |
| MISSILES IN THE MOVE | 27 | 18 | 1 | 0.33 | +31 | +30.8 |
| OVERRUNS AWAY | 7 | 6 | 1 | 0.33 | +2 | +2.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -59 | -59.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +22 | +21.7 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -123 | -123.3 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 1 | 0.33 | +30 | +29.6 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -3 | -2.9 |
| THE FIGHT MOVES | 11 | 11 | 1 | 0.33 | +12 | +12.5 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +11 | +10.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +13 | +12.9 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 9 | 6 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALLS SHORT | 70 | 60 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 63 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 32 | 30 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 24 | 22 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 83 | 83 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 44 | 41 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 44 | 41 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 68 | 62 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 24 | 22 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 33 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 26 | 16 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 5 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 18 | 18 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 5 | 5 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 54 | 35 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 56 | 52 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 150 | 139 | 0 | 0.00 | - | - |
| STAY WORTH | 36 | 26 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 14 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 258 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 5.00 | 34.3 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 6.67 | 81.0 |
| ARMY TABLE | rule | 1.00 | 4.00 | 35.3 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 1.00 | 3.3 |
| CHAFF PASSED | rule | - | 1.33 | 2.0 |
| JOINT CHARGE NOW | rule | 0.67 | 0.67 | 27.7 |
| MAIN BODY KEEPS ITS BAND | rule | - | 1.00 | 48.8 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 6.0 |
| PATHS CROSS | rule | 0.33 | 0.33 | 6.4 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 6.7 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 113.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 5.4 |
| NO REASON | gate | 0.33 | - | 18.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 59.2 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 123.3 |
| RULE SWITCHED OFF | gate | - | 0.33 | 7.3 |
| SUPPORT NARROWED | rule | 0.33 | - | 2.9 |

### Plans: chf-efd8067-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 80% | 292 | 253 | 87% |
| Mine | join | 2.7 | 100% | 97 | 0 | 0% |
| Mine | move | 34.0 | 93% | 2071 | 0 | 0% |
| Mine | shoot | 0.3 | 0% | 2 | 0 | 0% |
| Mine | support | 2.0 | 100% | 27 | 0 | 0% |
| Opponent | charge | 3.7 | 100% | 673 | 384 | 57% |
| Opponent | move | 38.7 | 94% | 2289 | 0 | 0% |
| Opponent | shoot | 3.0 | 44% | 162 | 50 | 31% |

### Battle groups: chf-efd8067-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 25% | 100% | 0% | - | 0% | 0% | 25% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 67% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 78 (9) | 25 | 53 | 56 | 56% | 3.8 | 80 (7) | 0 (1) | 132 (1) | 70 (8) | 132 (1) |
| Mine | Character | 10 | 55 (10) | 55 | 0 | 4 | 30% | 4.6 | 20 (8) | 179 (2) | - | 20 (5) | 87 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Fast Hammer | 8 | 22 (8) | 2 | 20 | 42 | 38% | 4.4 | 0 (3) | 51 (3) | 41 (2) | 0 (2) | 33 (6) |
| Mine | Hammer | 2 | 38 (2) | 0 | 38 | 100 | 0% | 5.0 | 69 (1) | 0 (1) | - | - | 38 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 35 | 0% | 2.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 51 (7) | 51 | 0 | 16 | 0% | 1.9 | 20 (3) | 100 (2) | - | 69 (3) | 48 (2) |
| Opponent | Clean-up | 2 | 143 (2) | 32 | 111 | 0 | 0% | 3.0 | - | 143 (2) | - | - | 143 (2) |
| Opponent | Fast Hammer | 5 | 27 (5) | 0 | 27 | 53 | 0% | 1.0 | 57 (2) | 0 (2) | 0 (1) | 0 (2) | 46 (3) |
| Opponent | Hammer | 11 | 16 (11) | 16 | 0 | 20 | 55% | 5.0 | 0 (4) | 19 (6) | 60 (1) | 28 (4) | 10 (7) |
| Opponent | Shooter | 8 | 37 (8) | 19 | 18 | 39 | 0% | 1.6 | 0 (1) | 53 (4) | 30 (3) | - | 37 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | - | - | - |

### Charged fights: chf-efd8067-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 133 | 1.0 | 1.5 | 133 | 0 | +133 | 0 of 2 | 2 of 2 | +140 | +126 |
| Mine | Warriors of Chaos | 1 | 19 | 608 | 4.0 | 1.0 | 152 | 0 | +152 | 1 of 4 | 4 of 4 | - | +152 |
| **Mine** | all armies | 3 | 6 | 291 | 2.0 | 1.2 | 146 | 0 | +146 | 1 of 6 | 6 of 6 | +140 | +147 |
| Opponent | Wood Elf Realms | 3 | 73 | 524 | 4.7 | 1.1 | 112 | 48 | +64 | 5 of 14 | 11 of 14 | +147 | +58 |

### Effective charges: chf-efd8067-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +140) | 1 | 0% (0 of 1) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 (net +304) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 14 | 3 (net -88) | 0 | 1 (net +0) | 0 | 2 (net +129) | 5 (net +131) | 3 | 9% (1 of 11) |

### Charged fights, damage counted: chf-efd8067-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 265 | 191 | +249 | 249 | 0 | +249 | +94.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 717 | 236 | +0 | 152 | 0 | +152 | +21.2 |
| Mine | No odds | 2 | 382 | 72 | +63 | 81 | 0 | +81 | +21.1 |
| Mine | All fights | 6 | 380 | 159 | +146 | 177 | 0 | +177 | +46.6 |
| Opponent | Long shot (under 50%) | 3 | 114 | 238 | -88 | 102 | 111 | -10 | -8.5 |
| Opponent | Effective (55-75%) | 1 | 499 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 365 | 170 | +131 | 135 | 4 | +132 | +36.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 499 | 64 | +129 | 129 | 0 | +129 | +25.9 |
| Opponent | No odds | 3 | 201 | 271 | +84 | 196 | 140 | +57 | +28.2 |
| Opponent | All fights | 14 | 305 | 206 | +64 | 131 | 55 | +75 | +24.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p48 | move | 15 | 5 (33%) | 4 (27%) | 1 (7%) | 9 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

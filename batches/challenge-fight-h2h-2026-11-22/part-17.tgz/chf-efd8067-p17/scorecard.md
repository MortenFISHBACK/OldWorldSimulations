# Doctrine scorecard: chf-efd8067-p17

### Scorecard: chf-efd8067-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 3 | 0 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 15 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 2 | 2 | 0 | 0 | 0 | 166 |
| L0827 | 5 | 1 | Opponent | yes | - | 1 | 1 | 5 | 0 | 0 | 0 | 75 |
| **Average** | | | Mine | 33% | 2.5 | 4.0 | 2.3 | 1.3 | 0.0 | 0.0 | 0.0 | 340.3 |
| **Average** | | | Opponent | 67% | 7.5 | 1.5 | 0.3 | 2.7 | 0.0 | 0.0 | 0.0 | 231.7 |

### KPIs: chf-efd8067-p17

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 65% (11 of 17) | 0% (0 of 16) | 33% (11 of 33) |
| Winner chose to follow up after the loser gave ground |  | 56% (5 of 9); on the table 56% | 75% (3 of 4); on the table 100% | 62% (8 of 13); on the table 69% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 45% (5 of 11); on the table 45% | 75% (3 of 4); on the table 100% | 53% (8 of 15); on the table 60% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 44% (16 of 36) | 50% (21 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 47% (16 of 34) | 52% (21 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 76% (4541 of 5999) | 77% (4627 of 5998) | 76% (9168 of 11997) |
|   infantry points that never fought | lower | 96% (932 of 968) | 67% (743 of 1113) | 80% (1675 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (17 of 30) | 72% (18 of 25) | 64% (35 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 1.7 uses a game | 100% (3 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.7 uses a game | 0% (0 of 2); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2741 of 5378) | 71% (3701 of 5181) | 61% (6442 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (35%) | 2.3 (33%) |
| MARCHED: its unit marched | 0.0 (0%) | 2.0 (30%) | 2.0 (29%) |
| CHARGED: its unit charged | 0.3 (100%) | 1.7 (25%) | 2.0 (29%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (10%) | 0.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 2.0 | 4.3 | 7.0 | 1.7 | 0.3 |
| not cast | 3.0 | 0.0 | 1.7 | 7.0 | 2.3 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.7 (40%) | 2.3 (33%) | 0.7 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 2.0 (29%) | 0.7 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | - | 0.0 (0%) | 2.0 (29%) | 0.7 (29%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.3 (20%) | 0.7 (10%) | 0.3 (14%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 1.0 (33%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | - | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 27.3 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.3 a game | 2.2 a game |
| stood (cast and not dispelled) | - | 69% (9 of 13) | 69% (9 of 13) |
| the unit moved after it | - | 78% (7 of 9) | 78% (7 of 9) |
| it charged on its next turn | - | 11% (1 of 9) | 11% (1 of 9) |
| the enemy charged it first | - | 0% (0 of 9) | 0% (0 of 9) |
| it fought by the end of its next turn | - | 0% (0 of 9) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 9) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | - | 89% (8 of 9) | 89% (8 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (57 of 88) | 68% (17 of 25) | 65% (74 of 113) |
|   cavalry | 74% (14 of 19) | - | 74% (14 of 19) |
|   chariot | 67% (8 of 12) | 78% (7 of 9) | 71% (15 of 21) |
|   infantry | 58% (7 of 12) | 45% (5 of 11) | 52% (12 of 23) |
|   war machine | 62% (28 of 45) | 100% (5 of 5) | 66% (33 of 50) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (10%) | 1.0 (38%) | 2.0 (15%) |
| CHARGED: it charged | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (12%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.7 (16%) | 0.0 (0%) | 1.7 (13%) |
| MOVED: a war machine that moved | 3.0 (29%) | 0.0 (0%) | 3.0 (23%) |
| NO TARGET IN RANGE | 1.3 (13%) | 1.3 (50%) | 2.7 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (13%) | 0.0 (0%) | 1.3 (10%) |
| SHELTERED: the target was sheltered | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.7 | 6.0 | 69% | 16.6 pts | 161 pts |
| chariot | 5.0 | 1.3 | 87% | 14.0 pts | 70 pts |
| infantry | 4.0 | 1.7 | 58% | 19.4 pts | 78 pts |
| war machine | 11.7 | 11.7 | 49% | 26.3 pts | 306 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 3.7 | 3.5 |
| Charges that made contact a game | 2.7 | 1.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.25 contact (4 units) | 1.00 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.36 contact (22 units) | 0.33 declared, 0.14 contact (21 units) | 0.37 declared, 0.26 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 67% (2 of 3) | 100% (1 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (9 of 9) | - | 100% (1 of 1) | 100% (10 of 10) |
| Character on its own | 50% (1 of 2) | 50% (1 of 2) | 33% (1 of 3) | 43% (3 of 7) |
| Chariot | 100% (3 of 3) | 0% (0 of 2) | - | 60% (3 of 5) |
| Infantry | 33% (1 of 3) | 100% (1 of 1) | 50% (1 of 2) | 50% (3 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 62% (8 of 13) | - | - | 62% (8 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 45% (5 of 11); on the table 45% | 83% (5 of 6) | 76% | 57% (17 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | - | 42% (10 of 24) | 82% | 40% (4 of 10) | 100% (2 of 2); 2.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 50% (3 of 6) | 64% | 89% (8 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 86% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 50% (3) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: chf-efd8067-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 40% (4 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (14 of 44) | 47% (7 of 15) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | - |
| Strategy | Joined characters whose unit fought | 14% (1 of 7) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 14% (1 of 7) | 29% (2 of 7) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 1.3 | 2.7 |
| Movement | Points that never moved of their own | 340.3 | 231.7 |
| Movement | Fights charged into per game | 2.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 3, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +27 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +0 | 2 of 3, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (14 of 30) | 50% (6 of 12) |
| Shooting | Points destroyed by shooting units | 100.7 | 0.0 |
| Shooting | War machine shots | 9.3 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 18% (5 of 28) | 0% (0 of 5) |
| Shooting | Points destroyed by war machines | 205.7 | 41.7 |
| Magic | Magic missiles cast | 1.3 | 4.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 58% (7 of 12) |
| Magic | Wounds caused by magic missiles | 1.0 | 4.7 |
| Magic | Points destroyed by magic (all spells) | 21.7 | 84.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 167.0 | 43.3 |
| Combat | Points run down | 0.0 | 41.7 |
| Combat | Net points per charged fight, damage counted | +83 | +41 |
| Combat | Net per 100 charger points, damage counted | +42.2 | +15.4 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +84 | +43 |
| Combat | Net points per supported fight / lone fight | - / +84 | +0 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 8 | 2 of 3 |
| Game | Points lost | 298.0 | 674.7 |
| Game | VP from objectives | 773.3 | 586.7 |
| Game | Lone holders (player turns) | 2.5 | 7.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +500 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 973
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: chf-efd8067-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +84.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.0 | -273.2 | 0.0 | 0.0 | 18.0 | +45.1 | 0.0 | 323.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 41.7 | 0.7 | +0.0 | 0.0 | 55.0 |
| BACKS UP THE FIGHT | 1.3 | +43.2 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.0 | +272.6 | 240.7 | 171.7 | 1.7 | +179.8 | 85.0 | 220.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.7 | -31.0 | 30.7 | 0.0 | 0.3 | +0.0 | 41.7 | 0.0 |
| CAST JOB | 2.0 | +86.5 | 140.0 | 0.0 | 1.0 | +7.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +61.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +6.6 | 0.0 | 0.0 | 0.3 | -12.6 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +32.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.3 | -461.5 | 0.0 | 109.3 | 17.3 | -1277.7 | 0.0 | 700.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 100.0 | 0.0 | 2.0 | +0.0 | 83.3 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 197.7 |
| CONVEYANCE SEARCH | - | - | - | - | 3.7 | +325.7 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -368.2 | 0.0 | 88.3 | 7.3 | -392.6 | 0.0 | 243.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -2.8 | 41.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | -27.3 | 0.0 | 41.7 | 7.0 | +33.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +8.0 | 43.3 | 0.0 |
| EXACT ROUND | 2.7 | +6.3 | 104.3 | 0.0 | 3.7 | -5.7 | 126.7 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +13.9 | 99.7 | 0.0 | 3.7 | +3.5 | 126.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +5.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.3 | +326.7 | 0.0 | 331.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +5.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.0 | 68.0 | 0.0 | 2.0 | +139.5 | 0.0 | 0.0 |
| FIVE ACTION | 89.7 | +5802.2 | 1668.3 | 542.7 | 79.0 | +4158.2 | 296.7 | 1650.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 73.7 |
| FOLLOW UP WEIGHED | 1.0 | +107.5 | 0.0 | 0.0 | 0.7 | +208.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +235.1 | 118.0 | 0.0 | 3.7 | +351.7 | 126.7 | 0.0 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 135.0 |
| FRIEND SHOOTS FIRST | 2.7 | -134.0 | 0.0 | 0.0 | 0.7 | -4.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -21.7 | 0.0 | 0.0 |
| GOAL WALK | 8.7 | +614.9 | 0.0 | 109.3 | 15.7 | +1270.3 | 0.0 | 375.3 |
| GUN FIGURES | 2.7 | +39.7 | 84.0 | 0.0 | 1.0 | +54.6 | 0.0 | 43.3 |
| GUN MASK | 0.7 | +27.5 | 0.0 | 0.0 | 1.7 | -15.2 | 0.0 | 111.3 |
| HALF WHEN STILL FLEEING | 0.3 | -0.9 | 0.0 | 0.0 | 0.7 | -0.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 42.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 65.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 109.3 | 11.7 | +0.0 | 0.0 | 610.3 |
| HIS CHARGE DENIED | 0.7 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 90.0 | 3.0 | +0.0 | 0.0 | 30.7 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.0 | -112.8 | 0.0 | 0.0 | 3.0 | -63.8 | 0.0 | 234.3 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 65.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.3 | +865.1 | 0.0 | 199.3 | 45.0 | +2539.7 | 0.0 | 503.7 |
| HIS SHOTS BY HIS RUN | 23.7 | +529.5 | 0.0 | 109.3 | 41.7 | +1246.9 | 0.0 | 1055.7 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +190.3 | 83.3 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 109.3 | 14.3 | +0.0 | 0.0 | 280.7 |
| HOLDER ASSIGNMENT | 10.3 | +1043.0 | 0.0 | 54.7 | 9.3 | +862.7 | 0.0 | 140.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -73.1 | 118.0 | 0.0 | 3.7 | -115.7 | 126.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +50.6 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.0 | -149.5 | 0.0 | 221.0 |
| JOINT CHARGE NOW | 0.3 | +2.4 | 0.0 | 0.0 | 1.0 | -20.1 | 41.7 | 0.0 |
| KEEP FALLS | 0.7 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +2.5 | 0.0 | 0.0 | 1.0 | +47.3 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 30.7 | 0.0 | 2.7 | +0.0 | 0.0 | 30.7 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.9 | 51.0 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.7 | +11.5 | 0.0 | 0.0 | 1.7 | +17.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +14.6 | 0.0 | 18.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.0 | +71.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +25.1 | 0.0 | 55.7 |
| MARCH OF THE TABLE | - | - | - | - | 1.3 | +40.6 | 0.0 | 55.7 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +13.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +34.9 | 0.0 | 0.0 | 5.7 | +243.1 | 0.0 | 31.7 |
| MEETS IN TIME | 4.0 | +381.0 | 0.0 | 0.0 | 3.0 | +174.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +61.3 | 0.0 | 0.0 | 6.3 | +110.4 | 0.0 | 109.7 |
| MISSILES NEXT TURN | 1.3 | +28.5 | 0.0 | 0.0 | 9.0 | +100.7 | 0.0 | 165.3 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 31.7 | 36.3 |
| MOVE SPELL SPOT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.7 | +531.5 | 0.0 | 0.0 | 6.7 | +519.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +313.3 | 0.0 | 0.0 | 4.0 | +146.5 | 0.0 | 30.7 |
| NEXT CHARGE BY LIST | 5.7 | +482.2 | 96.7 | 0.0 | 4.0 | +358.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.0 | +28.4 | 0.0 | 0.0 | 2.0 | +44.5 | 126.7 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -51.6 | 118.0 | 0.0 | 2.7 | -103.2 | 126.7 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.7 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -272.6 | 0.0 | 41.7 | 4.0 | -170.2 | 0.0 | 128.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.0 | +73.2 | 41.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -84.6 | 0.0 | 0.0 | 5.3 | -111.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +19.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -44.8 | 0.0 | 54.7 | 4.3 | +69.9 | 0.0 | 140.3 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.3 | +29.2 | 0.0 | 0.0 | 1.3 | +29.2 | 126.7 | 0.0 |
| OVERRUNS AWAY | 1.3 | +35.5 | 50.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.3 | +932.5 | 683.0 | 273.0 | 41.3 | +296.7 | 128.3 | 1034.7 |
| PRIZE BY WORTH | 0.7 | +62.8 | 48.3 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.7 | -235.7 | 0.0 | 0.0 | 8.0 | -68.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -40.4 | 0.0 | 0.0 | 1.0 | -49.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.3 | -16.7 | 236.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.3 | +1516.6 | 126.3 | 0.0 | 10.7 | +923.9 | 0.0 | 122.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +5.5 | 0.0 | 263.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +24.1 | 0.0 | 0.0 | 1.7 | +133.9 | 0.0 | 50.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 13.7 |
| REDIRECT WEIGHED | 0.7 | +18.6 | 48.3 | 0.0 | 1.0 | +0.2 | 15.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +0.7 | 0.0 | 18.0 |
| RISK BY ARC | 3.0 | +23.2 | 118.0 | 0.0 | 1.7 | -53.0 | 126.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -5.3 | 0.0 | 0.0 |
| RUN DOWN | 2.0 | -7.7 | 100.0 | 0.0 | 2.0 | -9.2 | 126.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -17.8 | 48.3 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -18.0 | 0.0 | 0.0 | 1.3 | -50.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +36.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -11.4 | 0.0 | 0.0 | 1.0 | -50.0 | 0.0 | 15.0 |
| SET UP BY THE SET | 1.7 | +46.7 | 0.0 | 0.0 | 1.7 | +4.6 | 0.0 | 15.0 |
| SET UP TOGETHER | 1.7 | +11.5 | 0.0 | 0.0 | 1.7 | +17.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +78.7 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +56.4 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.3 | +0.0 | 0.0 | 171.7 | 4.3 | +0.0 | 0.0 | 220.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +56.9 | 131.7 | 0.0 | 3.3 | +89.1 | 83.3 | 21.7 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 15.7 | -71.5 | 0.0 | 109.3 | 31.7 | -218.3 | 0.0 | 987.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.7 | +931.4 | 0.0 | 271.3 | 5.3 | +343.5 | 0.0 | 308.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 1.3 | +259.8 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +0.5 | 0.0 | 0.0 | 5.0 | +42.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.7 | 18.3 | 0.0 | 1.0 | +9.7 | 85.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 203.0 |
| STAND AND SHOOT | 0.3 | -6.2 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 90.0 |
| STANDS STILL | 53.7 | +0.0 | 1550.3 | 433.3 | 21.3 | +0.0 | 170.0 | 690.7 |
| STAY WORTH | 34.0 | +393.6 | 1068.0 | 170.0 | 7.0 | +83.5 | 86.7 | 726.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +2.7 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +194.8 | 0.0 | 0.0 | 3.7 | +152.3 | 0.0 | 27.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 18.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +194.8 | 0.0 | 0.0 | 3.7 | +152.3 | 0.0 | 27.3 |
| SURE REACH TOGETHER | 1.3 | +16.8 | 0.0 | 0.0 | 1.0 | +8.2 | 0.0 | 42.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 54.7 | 2.3 | +0.0 | 0.0 | 13.7 |
| THE FIGHT MOVES | 0.7 | -0.1 | 68.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.3 | -163.7 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 30.7 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 48.7 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 122.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 140.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.3 | +0.0 | 0.0 | 226.3 | 38.3 | +0.0 | 0.0 | 693.7 |
| TIED UP BY THE SUM | 1.0 | +67.2 | 32.0 | 0.0 | 1.0 | +127.7 | 85.0 | 0.0 |
| TIME ON OUR SIDE | 37.0 | +502.5 | 0.0 | 84.7 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | +33.8 | 0.0 | 0.0 | 1.3 | -50.5 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.7 | +68.9 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.7 | +11.8 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -128.2 | 0.0 | 0.0 | 4.3 | -400.8 | 0.0 | 236.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.7 | +43.8 | 0.0 | 85.0 | 1.7 | +33.7 | 0.0 | 100.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +36.5 | 0.0 | 0.0 | 3.7 | +105.0 | 0.0 | 222.7 |

### Rule changes: chf-efd8067-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 75 | 75 | 53 | 17.67 | -496 | -9.4 |
| HIS SHOT LIST | 217 | 209 | 52 | 17.33 | +820 | +15.8 |
| HOLDER ASSIGNMENT | 59 | 59 | 52 | 17.33 | +4651 | +89.4 |
| HIS SHOTS BY HIS RUN | 196 | 188 | 37 | 12.33 | +624 | +16.9 |
| FIVE ACTION | 506 | 491 | 32 | 10.67 | +1607 | +50.2 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1328 | -49.2 |
| MOVE TO CHARGE COMPUTED | 40 | 34 | 26 | 8.67 | +929 | +35.7 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +417 | +16.7 |
| TIME ON OUR SIDE | 111 | 93 | 24 | 8.00 | +45 | +1.9 |
| SHOT RISK POINTS | 142 | 135 | 19 | 6.33 | +451 | +23.8 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 29 | 25 | 18 | 6.00 | +608 | +33.8 |
| GOAL WALK | 73 | 71 | 17 | 5.67 | +1495 | +88.0 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 14 | 4.67 | -913 | -65.2 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 11 | 3.67 | +583 | +53.0 |
| QUARTER ODDS | 90 | 85 | 11 | 3.67 | +788 | +71.6 |
| COVER ONCE | 41 | 25 | 10 | 3.33 | +132 | +13.2 |
| IDLE COST | 45 | 32 | 10 | 3.33 | +64 | +6.4 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 9 | 3.00 | +76 | +8.5 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 9 | 3.00 | +82 | +9.1 |
| CHARGE LOSSES | 92 | 85 | 8 | 2.67 | +244 | +30.5 |
| CHARGE NOW FIRST | 10 | 10 | 8 | 2.67 | -496 | -61.9 |
| FOUR ROUNDS | 21 | 18 | 7 | 2.33 | +460 | +65.7 |
| SHOTS IN THE MOVE | 75 | 56 | 7 | 2.33 | +287 | +41.0 |
| FALLS SHORT | 70 | 47 | 6 | 2.00 | +59 | +9.9 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +1185 | +197.6 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +949 | +189.8 |
| MAX FOR POSITIONING | 25 | 22 | 5 | 1.67 | +6 | +1.2 |
| NO CHAFF EDGES | 9 | 9 | 5 | 1.67 | +131 | +26.2 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +17 | +3.3 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +927 | +185.4 |
| STAY WORTH | 123 | 107 | 5 | 1.67 | +48 | +9.5 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +382 | +76.3 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 4 | 1.33 | +0 | +0.0 |
| GUN MASK | 7 | 7 | 4 | 1.33 | +90 | +22.6 |
| HIS MOVE AND SHOT | 27 | 25 | 4 | 1.33 | +119 | +29.8 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -53 | -13.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +150 | +37.4 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -122 | -30.4 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -50 | -12.6 |
| WHOLE FIGHT DANGER | 18 | 16 | 4 | 1.33 | +111 | +27.8 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +253 | +84.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +214 | +71.2 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +220 | +73.2 |
| RISK BY ARC | 14 | 13 | 3 | 1.00 | +137 | +45.7 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +8 | +2.7 |
| WHOLE FIGHT REACTION | 10 | 10 | 3 | 1.00 | +33 | +11.1 |
| WOUNDS ON THE RANKS | 17 | 17 | 3 | 1.00 | +59 | +19.6 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.67 | -93 | -46.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 8 | 6 | 2 | 0.67 | +25 | +12.7 |
| HARD STAY DROPPED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 6 | 2 | 0.67 | +110 | +54.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +167 | +83.7 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +44 | +21.9 |
| ONE FIGHT FORMULA | 31 | 12 | 2 | 0.67 | +68 | +33.8 |
| ONE OBJECTIVE FORMULA | 26 | 18 | 2 | 0.67 | +164 | +81.9 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +188 | +94.2 |
| REDIRECT COUNTER | 6 | 4 | 2 | 0.67 | +199 | +99.5 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 10 | 9 | 2 | 0.67 | +83 | +41.4 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 18 | 17 | 2 | 0.67 | +225 | +112.7 |
| SUPPORT WORKED OUT | 18 | 17 | 2 | 0.67 | +225 | +112.7 |
| SURE REACH TOGETHER | 7 | 7 | 2 | 0.67 | +6 | +2.8 |
| BACKS UP THE FIGHT | 6 | 5 | 1 | 0.33 | +16 | +16.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 29 | 29 | 1 | 0.33 | +56 | +56.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +14 | +14.2 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +98 | +97.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -114 | -114.2 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.33 | +15 | +15.1 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +0 | +0.4 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 24 | 17 | 1 | 0.33 | +22 | +22.4 |
| NEARER NOT NEEDED | 33 | 30 | 1 | 0.33 | +68 | +68.0 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +53 | +52.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -3.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +2 | +2.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +7 | +7.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +110 | +110.3 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -32 | -31.5 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 4 | 1 | 0.33 | +10 | +10.4 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 19 | 17 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 16 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 28 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 21 | 19 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 18 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 19 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 15 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | not checked | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 11 | 6 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 10 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 10 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 59 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 225 | 218 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE FIGHT MOVES | 3 | 2 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 230 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 8 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.33 | 52.4 |
| ARMY TABLE | rule | 2.00 | 3.33 | 64.4 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.33 | 65.2 |
| CHARGE NOW FIRST | rule | 1.33 | 1.33 | 61.9 |
| MARCH OF THE TABLE | rule | - | 1.33 | 30.4 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 12.6 |
| CARRIES OUT SET-UP | rule | 0.67 | - | 46.5 |
| JOINT CHARGE NOW | rule | - | 0.67 | 79.8 |
| NO REASON | gate | - | 0.67 | 9.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 114.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 3.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 31.5 |

### Plans: chf-efd8067-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 231 | 115 | 50% |
| Mine | join | 0.7 | 100% | 9 | 0 | 0% |
| Mine | move | 24.0 | 99% | 1188 | 0 | 0% |
| Mine | shoot | 13.0 | 72% | 912 | 817 | 90% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 3.3 | 40% | 540 | 207 | 38% |
| Opponent | join | 2.3 | 100% | 94 | 0 | 0% |
| Opponent | move | 30.0 | 89% | 1531 | 0 | 0% |
| Opponent | shoot | 5.0 | 20% | 186 | 90 | 48% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: chf-efd8067-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 60% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | Character | 12 | 14 (12) | 14 | 0 | 6 | 75% | 2.7 | 0 (3) | 22 (7) | 13 (2) | 8 (5) | 21 (7) |
| Mine | Fast Hammer | 5 | 62 (5) | 33 | 29 | 0 | 40% | 2.0 | 54 (3) | 71 (2) | - | 62 (5) | - |
| Mine | Hammer | 4 | 42 (4) | 14 | 28 | 0 | 50% | 1.0 | 0 (1) | 60 (3) | - | 34 (2) | 49 (2) |
| Mine | Shooter | 5 | 79 (5) | 44 | 35 | 24 | 0% | 1.4 | 9 (2) | 0 (1) | 184 (2) | 104 (4) | 0 (1) |
| Mine | War machine | 11 | 35 (11) | 35 | 0 | 46 | 9% | 1.3 | 0 (2) | 43 (9) | - | 0 (2) | 43 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 59 | 100% | - | 0 (3) | 0 (1) | 0 (1) | 0 (5) | - |
| Opponent | Character | 10 | 26 (10) | 26 | 0 | 6 | 50% | 2.6 | 0 (3) | 0 (4) | 72 (2) | 22 (7) | 45 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 25 (6) | 0 | 25 | 38 | 67% | 2.0 | 3 (4) | 78 (2) | - | 65 (3) | 0 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 55 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 69 | 25% | 2.7 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Opponent | Holder | 4 | 105 (4) | 0 | 105 | 42 | 25% | 3.3 | - | 88 (2) | 117 (2) | 105 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | War machine | 2 | 38 (2) | 38 | 0 | 100 | 0% | 1.0 | 76 (1) | 0 (1) | - | - | 38 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (3) | - |

### Charged fights: chf-efd8067-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 328 | 223 | 2.7 | 1.0 | 84 | 0 | +84 | 0 of 8 | 8 of 8 | - | +84 |
| Opponent | Grand Cathay | 1 | 379 | 130 | 1.0 | 1.0 | 130 | 0 | +130 | 0 of 1 | 1 of 1 | - | +130 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 2 of 2 | 2 of 2 | +0 | +0 |
| **Opponent** | all armies | 3 | 126 | 43 | 1.0 | 1.3 | 43 | 0 | +43 | 2 of 3 | 3 of 3 | +0 | +65 |

### Effective charges: chf-efd8067-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 8 | 0 | 0 | 0 | 2 (net +207) | 2 (net +27) | 3 (net +0) | 1 | 0% (0 of 7) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +130) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |

### Charged fights, damage counted: chf-efd8067-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 189 | 102 | +207 | 207 | 0 | +207 | +109.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 185 | 161 | +0 | 25 | 21 | +5 | +2.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 227 | 48 | +27 | 27 | 0 | +27 | +11.9 |
| Mine | No odds | 1 | 181 | 145 | +200 | 225 | 45 | +180 | +99.4 |
| Mine | All fights | 8 | 196 | 116 | +84 | 96 | 13 | +83 | +42.2 |
| Opponent | Effective (55-75%) | 1 | 186 | 202 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 302 | 198 | +65 | 87 | 26 | +61 | +20.1 |
| Opponent | All fights | 3 | 264 | 199 | +43 | 58 | 18 | +41 | +15.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p17 | move | 19 | 8 (42%) | 5 (26%) | 1 (5%) | 10 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

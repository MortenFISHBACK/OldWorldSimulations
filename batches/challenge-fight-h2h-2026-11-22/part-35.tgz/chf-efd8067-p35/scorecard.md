# Doctrine scorecard: chf-efd8067-p35

### Scorecard: chf-efd8067-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 3 | 6 | 0 | 2 | 0 | 0 | 0 | 410 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 55 |
| L2231 | 5 | 1 | Opponent | no | - | 3 | 4 | 2 | 0 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 3 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 110 |
| **Average** | | | Mine | 67% | 3.0 | 3.7 | 0.7 | 1.7 | 1.0 | 0.0 | 0.0 | 155.0 |
| **Average** | | | Opponent | 0% | 0.5 | 2.3 | 4.0 | 2.3 | 0.0 | 0.0 | 0.0 | 93.3 |

### KPIs: chf-efd8067-p35

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (3 of 15) | 0% (0 of 18) | 9% (3 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 100% (6 of 6); on the table 100% | 100% (12 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 100% | 100% (6 of 6); on the table 100% | 93% (13 of 14); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 44% (8 of 18) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (3 of 5) | 50% (8 of 16) | 52% (11 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 33% (2 of 6) | 53% (9 of 17) |
| Points that never fought | lower | 32% (1945 of 5999) | 41% (2440 of 6000) | 37% (4385 of 11999) |
|   infantry points that never fought | lower | 68% (1051 of 1552) | 30% (314 of 1035) | 53% (1365 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (9 of 19) | 70% (21 of 30) | 61% (30 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 50% (1 of 2); 1.7 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 39% (1743 of 4484) | 60% (3342 of 5546) | 51% (5085 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (67%) | 2.3 (70%) | 3.0 (69%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (10%) | 0.3 (8%) |
| IN COMBAT: engaged in combat | 0.3 (33%) | 0.0 (0%) | 0.3 (8%) |
| FLEEING: fleeing | 0.0 (0%) | 0.7 (20%) | 0.7 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 1.7 | 2.0 | 3.7 | 1.3 | 0.7 |
| not cast | 3.3 | 0.3 | 0.0 | 4.3 | 0.7 | 15.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | - | 3.0 (69%) | 0.7 (100%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | - | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | - | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | - | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) |
| STUPIDITY: Stupidity | 0.7 (20%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (80%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 14.0 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.0 a game | 1.0 a game |
| stood (cast and not dispelled) | - | 67% (4 of 6) | 67% (4 of 6) |
| the unit moved after it | - | 0% (0 of 4) | 0% (0 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (67 of 117) | 65% (22 of 34) | 59% (89 of 151) |
|   cavalry | 67% (12 of 18) | 73% (11 of 15) | 70% (23 of 33) |
|   character | 0% (0 of 23) | 0% (0 of 6) | 0% (0 of 29) |
|   chariot | 91% (10 of 11) | - | 91% (10 of 11) |
|   infantry | 69% (45 of 65) | 85% (11 of 13) | 72% (56 of 78) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (14%) | 1.3 (33%) | 3.7 (18%) |
| CHARGED: it charged | 3.0 (18%) | 1.7 (42%) | 4.7 (23%) |
| IN COMBAT: it fought this turn or the last | 2.0 (12%) | 1.0 (25%) | 3.0 (15%) |
| NO TARGET IN RANGE | 4.7 (28%) | 0.0 (0%) | 4.7 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (10%) | 0.0 (0%) | 1.7 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (18%) | 0.0 (0%) | 3.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.0 | 1.7 | 86% | 4.0 pts | 48 pts |
| chariot | 3.3 | 0.3 | 90% | 2.3 pts | 8 pts |
| infantry | 20.3 | 6.0 | 80% | 7.7 pts | 156 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 6.7 | 5.7 |
| Charges that made contact a game | 3.0 | 5.7 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.28 contact (32 units) | 0.72 declared, 0.60 contact (25 units) | 0.56 declared, 0.42 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (1 of 1) | 100% (1 of 1) | 67% (6 of 9) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | 0% (0 of 2) | 57% (4 of 7) |
| Character on its own | 50% (2 of 4) | - | 17% (1 of 6) | 30% (3 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 73% (8 of 11) | 0% (0 of 1) | - | 67% (8 of 12) |
| Monster | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | - | 50% (3 of 6) | 32% | 56% (5 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 88% (7 of 8); on the table 100% | - | 33% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 56% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 27% | 75% (9 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 39% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (5) | 67% (4) | 60% (9) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: chf-efd8067-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 58% (7 of 12) | 47% (7 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (13 of 25) | 25% (2 of 8) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 50% (2 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (5 of 5) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 1.7 | 2.3 |
| Movement | Points that never moved of their own | 155.0 | 93.3 |
| Movement | Fights charged into per game | 2.7 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 3 of 11, net +139 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net -195 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +0 | 2 of 11, net +30 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 7, net +95 | 4 of 11, net +132 |
| Shooting | Shots by shooting units (incl. breath weapons) | 22.3 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 24% (16 of 67) | 50% (11 of 22) |
| Shooting | Points destroyed by shooting units | 42.0 | 23.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Wounds caused by other spells | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 78.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.0 / 0.7 / 0.0 | 3.3 / 1.7 / 0.0 / 1.0 |
| Combat | Points destroyed in combat | 372.3 | 554.0 |
| Combat | Points run down | 36.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +26 | +66 |
| Combat | Net per 100 charger points, damage counted | +11.1 | +21.5 |
| Combat | First round won (charged fights) | 62% | 79% |
| Combat | Net points per charged fight | +20 | +70 |
| Combat | Net points per supported fight / lone fight | +0 / +23 | +194 / +36 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 8 of 14 |
| Game | Points lost | 645.7 | 529.7 |
| Game | VP from objectives | 1050.0 | 470.0 |
| Game | Lone holders (player turns) | 3.0 | 0.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +682 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1175
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: chf-efd8067-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +90.3 | 0.0 | 180.0 | - | - | - | - |
| ARMY TABLE | 27.7 | +295.8 | 0.0 | 174.7 | 25.3 | +38.8 | 0.0 | 169.3 |
| BACKS UP THE FIGHT | 0.7 | +43.5 | 0.0 | 0.0 | 2.0 | +135.9 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +0.8 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST FACING | - | - | - | - | 0.3 | +29.7 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.7 | -203.2 | 83.3 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.7 | +7.4 | 48.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +19.2 | 0.0 | 0.0 | 1.3 | +23.9 | 0.0 | 48.0 |
| CHALLENGE IN THE FIGHT | 1.3 | -19.0 | 41.7 | 24.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -0.8 | 0.0 | 24.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.7 | -154.2 | 62.0 | 65.0 | 0.3 | -9.9 | 0.0 | 15.0 |
| CHARGE LOSSES | 17.0 | -462.0 | 0.0 | 561.7 | 24.0 | -888.9 | 0.0 | 352.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 140.0 | 105.7 | 3.3 | +0.0 | 385.3 | 53.7 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.7 | +0.0 | 0.0 | 162.3 | 11.0 | +0.0 | 0.0 | 142.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 135.0 | 1.0 | +0.0 | 90.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 2.0 | +276.7 | 41.7 | 0.0 |
| COVER ONCE | 11.3 | -792.6 | 0.0 | 148.3 | 6.3 | -242.2 | 0.0 | 100.7 |
| DEFENSIVE FLOOR | 0.3 | -21.3 | 62.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.6 | 36.7 | 0.0 | 0.7 | -0.6 | 65.0 | 55.3 |
| DEPLOY BY FIGURES | 8.7 | +49.0 | 0.0 | 0.0 | 7.3 | +77.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -0.9 | 41.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +24.3 | 124.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +20.4 | 0.0 | 125.7 |
| EXACT ROUND | 2.3 | +98.6 | 180.7 | 129.7 | 4.3 | +17.0 | 634.0 | 131.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +36.5 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 180.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.7 | +21.9 | 218.7 | 129.7 | 2.7 | +4.0 | 283.3 | 104.3 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 0.0 | 23.7 | +298.2 | 0.0 | 186.3 |
| FEATURE BUFFS | 1.3 | +1.6 | 0.0 | 48.0 | 0.7 | +2.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +3.6 | 41.7 | 0.0 | 1.0 | +50.2 | 70.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 34.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 105.7 | +8552.1 | 774.3 | 1003.0 | 86.3 | +4314.1 | 1568.7 | 976.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 65.0 | 4.7 | +0.0 | 0.0 | 41.7 |
| FOLLOW UP WEIGHED | 1.7 | +357.8 | 0.0 | 180.0 | 2.3 | +331.7 | 0.0 | 80.7 |
| FOUR ROUNDS | 4.7 | +187.4 | 337.3 | 129.7 | 6.3 | +350.1 | 921.0 | 146.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 48.3 | 3.7 | +0.0 | 0.0 | 40.0 |
| FRIEND SHOOTS FIRST | 1.3 | -20.4 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.8 | 0.0 | 0.0 | 0.3 | -3.0 | 65.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.7 | -0.7 | 0.0 | 64.7 | - | - | - | - |
| GOAL WALK | 9.7 | +1178.2 | 0.0 | 0.0 | 12.0 | +555.6 | 0.0 | 77.3 |
| GUN FIGURES | 1.3 | +0.0 | 31.7 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | -1.2 | 103.7 | 40.7 | 1.0 | -0.3 | 42.3 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 24.0 | 2.3 | +0.0 | 0.0 | 36.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 48.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 180.0 | 41.7 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 65.0 | 38.7 |
| HIS CHARGE BY HIS RUN | 10.0 | +0.0 | 0.0 | 515.0 | 12.0 | +0.0 | 0.0 | 233.3 |
| HIS CHARGE DENIED | 0.3 | +1.2 | 62.0 | 0.0 | 2.0 | +134.4 | 490.0 | 80.3 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 93.3 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 260.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -32.3 | 0.0 | 225.0 | 6.3 | -69.9 | 0.0 | 143.3 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 110.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 260.0 | 4.7 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 48.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.0 | +432.3 | 0.0 | 492.3 | 52.0 | +953.9 | 0.0 | 800.7 |
| HIS SHOTS BY HIS RUN | 33.0 | +524.3 | 0.0 | 533.7 | 50.7 | +546.5 | 0.0 | 702.7 |
| HIS TURN DENIED | 1.0 | +6.3 | 36.7 | 65.0 | 1.7 | +32.5 | 108.7 | 16.7 |
| HOLD ODDS | 23.3 | +0.0 | 0.0 | 180.0 | 10.7 | +0.0 | 0.0 | 124.0 |
| HOLDER ASSIGNMENT | 16.3 | +1119.6 | 0.0 | 132.0 | 7.7 | +779.6 | 0.0 | 62.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -112.0 | 275.3 | 0.0 | 4.3 | -137.5 | 316.0 | 16.7 |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 17.0 | -163.6 | 0.0 | 80.3 |
| JOINT CHARGE NOW | 2.3 | -6.7 | 239.0 | 24.0 | 1.7 | +290.4 | 360.0 | 58.3 |
| JOINT ON THE TABLE | 0.3 | +52.6 | 62.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 62.0 |
| LANE BY FIGURES | 1.3 | +41.4 | 0.0 | 0.0 | 0.7 | +2.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.0 | +0.0 | 303.7 | 1321.0 | 2.7 | +0.0 | 266.7 | 168.7 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | -4.6 | 62.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +4.9 | 177.0 | 105.7 | 3.3 | +0.6 | 357.7 | 80.3 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +10.2 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +6.4 | 0.0 | 0.0 | 1.7 | -23.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | +114.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +31.0 | 0.0 | 0.0 | 3.0 | +59.3 | 0.0 | 15.0 |
| MEETS IN TIME | 4.0 | +218.7 | 0.0 | 0.0 | 4.0 | +488.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +48.3 | 0.0 | 0.0 | 6.3 | +83.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +33.4 | 0.0 | 0.0 | 6.3 | +60.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 24.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +1122.4 | 0.0 | 260.0 | 8.7 | +653.5 | 0.0 | 30.0 |
| NEARER NOT NEEDED | 14.0 | +571.9 | 0.0 | 0.0 | 9.3 | +403.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 6.3 | +688.7 | 0.0 | 130.0 | 7.0 | +505.1 | 0.0 | 30.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.3 | -21.9 | 65.0 | 0.0 |
| NO CHAFF EDGES | 4.7 | +160.3 | 213.3 | 65.0 | 5.0 | +149.1 | 553.7 | 123.7 |
| NO DOUBLE ROUNDS | 4.0 | -158.3 | 275.3 | 105.7 | 5.3 | -304.5 | 561.0 | 112.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -65.0 | 0.0 | 46.0 | 3.0 | -59.3 | 180.0 | 34.0 |
| ONE CHALLENGE TEST | 0.3 | -0.8 | 0.0 | 24.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -96.0 | 0.0 | 150.0 | 5.7 | -71.6 | 0.0 | 15.0 |
| ONE JOINT FIGURE | 0.3 | +21.4 | 0.0 | 24.0 | 1.0 | +58.8 | 180.0 | 58.3 |
| ONE OBJECTIVE FORMULA | 8.3 | -121.4 | 0.0 | 86.0 | 2.0 | +33.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +8.6 | 20.0 | 0.0 |
| OPENS UP IN FULL | 3.3 | +109.3 | 213.3 | 65.0 | 1.7 | +36.1 | 313.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +4.8 | 98.7 | 40.7 | 1.3 | +10.5 | 276.7 | 16.7 |
| PATHS CROSS | - | - | - | - | 0.7 | -2.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 49.3 | +420.2 | 132.3 | 988.0 | 44.7 | +917.0 | 791.0 | 872.7 |
| PRIZE BY WORTH | 0.3 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 13.0 | -682.4 | 0.0 | 130.0 | 8.7 | -214.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | -2.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| QUARTER ODDS | 26.3 | +2440.3 | 171.7 | 213.0 | 21.7 | +2209.9 | 483.7 | 190.3 |
| RANDOM MOVE BY FIGURES | 3.7 | +154.0 | 0.0 | 263.3 | 2.0 | +0.4 | 0.0 | 226.7 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +168.5 | 0.0 | 46.0 | 1.0 | +10.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 22.0 | 3.3 | +0.0 | 0.0 | 30.0 |
| REDIRECT WEIGHED | 0.3 | +21.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -6.0 | 0.0 | 30.0 |
| RESERVE FALL BACK | 1.7 | +20.5 | 0.0 | 0.0 | 1.0 | +152.3 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +22.1 | 280.7 | 129.7 | 5.7 | -38.4 | 901.0 | 146.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -14.8 | 73.3 | 65.0 | 0.3 | -2.8 | 0.0 | 0.0 |
| RUN DOWN | 3.3 | -52.0 | 156.7 | 105.7 | 1.7 | -5.8 | 96.7 | 16.7 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.8 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +18.3 | 0.0 | 0.0 | 1.3 | +163.8 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +31.7 | 0.0 | 40.7 | 0.7 | +24.4 | 180.0 | 34.0 |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -9.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -4.6 | 0.0 | 0.0 | 2.7 | +68.7 | 96.7 | 0.0 |
| SET UP TOGETHER | 0.7 | +10.2 | 0.0 | 0.0 | 1.3 | +6.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 20.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +67.4 | 99.0 | 0.0 | 1.0 | +7.5 | 81.3 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -7.3 | 180.0 | 15.0 |
| SHOT RISK POINTS | 24.0 | -161.6 | 0.0 | 359.7 | 30.7 | -352.9 | 0.0 | 288.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.7 | +375.4 | 0.0 | 128.3 | 7.0 | +106.1 | 0.0 | 36.7 |
| SPELL WORTH | 0.7 | +2.7 | 0.0 | 0.0 | 3.3 | +3.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 280.0 | 7.3 | +0.0 | 0.0 | 223.3 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -12.8 | 110.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 46.7 | 0.0 |
| STANDS STILL | 44.7 | +0.0 | 437.0 | 181.3 | 27.0 | +0.0 | 647.7 | 190.0 |
| STAY WORTH | 15.7 | +161.0 | 254.0 | 60.0 | 8.3 | -155.6 | 141.3 | 0.0 |
| STRIKE BY THE ODDS | 1.7 | +106.7 | 117.3 | 605.0 | 0.7 | +4.5 | 46.7 | 30.0 |
| STRONG ENOUGH TO HOLD | 1.3 | -3.5 | 0.0 | 0.0 | 0.7 | -25.4 | 0.0 | 62.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -0.1 | 180.0 | 34.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 48.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +453.2 | 0.0 | 0.0 | 10.7 | +630.8 | 0.0 | 73.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 40.7 | 0.7 | +0.0 | 65.0 | 38.7 |
| SUPPORT WORKED OUT | 5.7 | +453.2 | 0.0 | 0.0 | 10.7 | +630.8 | 0.0 | 73.3 |
| SURE REACH TOGETHER | 1.3 | +10.5 | 0.0 | 88.3 | 3.7 | +42.9 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 38.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | +0.7 | 41.7 | 40.7 | 1.3 | +0.4 | 202.0 | 41.7 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.3 | +0.0 | 0.0 | 305.0 | 39.0 | +0.0 | 0.0 | 282.0 |
| TIED UP BY THE SUM | 2.0 | +257.6 | 140.0 | 0.0 | 1.7 | +169.8 | 205.3 | 0.0 |
| TIME ON OUR SIDE | 51.7 | +451.3 | 113.3 | 251.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -14.6 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +43.5 | 360.0 | 68.0 |
| WHO FIGHTS | 0.3 | +8.8 | 0.0 | 65.0 | 1.0 | +1.0 | 70.3 | 15.0 |
| WHO GETS IN | 1.0 | -30.8 | 165.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +51.7 | 0.0 | 42.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.0 | 180.0 | 34.0 |
| WHOLE FIGHT DANGER | 4.3 | -310.8 | 0.0 | 345.0 | 2.3 | -504.3 | 0.0 | 56.7 |
| WHOLE FIGHT GAIN | 0.3 | +22.4 | 0.0 | 24.0 | 1.0 | +66.1 | 180.0 | 58.3 |
| WHOLE FIGHT REACTION | 1.3 | +98.1 | 31.7 | 0.0 | 2.3 | +182.2 | 129.7 | 36.7 |
| WOUNDS ON THE RANKS | 1.3 | +4.6 | 0.0 | 0.0 | 7.0 | +109.0 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 159 | 159 | 124 | 41.33 | +1092 | +8.8 |
| HOLDER ASSIGNMENT | 72 | 72 | 65 | 21.67 | +2894 | +44.5 |
| FIVE ACTION | 576 | 558 | 44 | 14.67 | +2373 | +53.9 |
| HIS SHOT LIST | 282 | 272 | 43 | 14.33 | +472 | +11.0 |
| HIS SHOTS BY HIS RUN | 251 | 240 | 43 | 14.33 | +414 | +9.6 |
| MOVE TO CHARGE COMPUTED | 56 | 51 | 35 | 11.67 | +1081 | +30.9 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 48 | 48 | 27 | 9.00 | +251 | +9.3 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -373 | -13.8 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 65 | 65 | 25 | 8.33 | -2690 | -107.6 |
| NEXT CHARGE BY LIST | 40 | 37 | 23 | 7.67 | +750 | +32.6 |
| QUARTER ODDS | 144 | 142 | 18 | 6.00 | +1057 | +58.7 |
| NO CHAFF EDGES | 29 | 27 | 17 | 5.67 | +530 | +31.2 |
| SUPPORT ADDS | 49 | 48 | 17 | 5.67 | +849 | +49.9 |
| SUPPORT WORKED OUT | 49 | 48 | 17 | 5.67 | +849 | +49.9 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 65 | 65 | 15 | 5.00 | +690 | +46.0 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 12 | 12 | 12 | 4.00 | +2068 | +172.4 |
| JOINT CHARGE NOW | 12 | 12 | 12 | 4.00 | +851 | +71.0 |
| MEETS IN TIME | 24 | 24 | 11 | 3.67 | +567 | +51.5 |
| SHOT RISK POINTS | 164 | 160 | 11 | 3.67 | +94 | +8.5 |
| FOUR ROUNDS | 33 | 28 | 10 | 3.33 | +313 | +31.3 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 9 | 3.00 | +463 | +51.5 |
| TIME ON OUR SIDE | 155 | 133 | 9 | 3.00 | +4 | +0.5 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +518 | +64.8 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 8 | 2.67 | +47 | +5.8 |
| SURE REACH TOGETHER | 15 | 15 | 8 | 2.67 | +42 | +5.2 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SEARCH SPOT | 7 | 7 | 7 | 2.33 | +546 | +78.0 |
| STRIKE BY THE ODDS | 7 | 7 | 7 | 2.33 | +230 | +32.8 |
| TIED UP BY THE SUM | 11 | 9 | 7 | 2.33 | +276 | +39.4 |
| CHARGE LOSSES | 123 | 119 | 6 | 2.00 | +64 | +10.6 |
| CHARGE NOW FIRST | 17 | 17 | 6 | 2.00 | -260 | -43.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +131 | +21.9 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +1361 | +226.8 |
| NEARER NOT NEEDED | 70 | 68 | 6 | 2.00 | +205 | +34.1 |
| CAST JOB | 8 | 8 | 5 | 1.67 | +6 | +1.3 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +129 | +25.9 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 57 | 27 | 5 | 1.67 | +6 | +1.3 |
| RISK BY ARC | 29 | 24 | 5 | 1.67 | +105 | +21.0 |
| BACKS UP THE FIGHT | 8 | 6 | 4 | 1.33 | +41 | +10.3 |
| COVER ONCE | 53 | 35 | 4 | 1.33 | +27 | +6.7 |
| EVASIVE BY THE ODDS | 11 | 11 | 4 | 1.33 | +7 | +1.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| PROMISE KNOWS THE FIGHT | 17 | 14 | 4 | 1.33 | -7 | -1.9 |
| SCOUTS HUNT GUNS ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +168 | +42.0 |
| SET UP BY THE SET | 9 | 9 | 4 | 1.33 | +247 | +61.8 |
| WOUNDS ON THE RANKS | 25 | 25 | 4 | 1.33 | +38 | +9.4 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 20 | 17 | 3 | 1.00 | +138 | +46.0 |
| HIS TURN DENIED | 8 | 8 | 3 | 1.00 | +70 | +23.4 |
| MAX FOR POSITIONING | 12 | 12 | 3 | 1.00 | +13 | +4.3 |
| SCOUT BY DROPS | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| SHOTS IN THE MOVE | 80 | 58 | 3 | 1.00 | +50 | +16.6 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | -92 | -30.8 |
| CARRIES OUT SET-UP | 2 | 2 | 2 | 0.67 | -610 | -304.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +10 | +5.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 76 | 62 | 2 | 0.67 | +2 | +1.2 |
| FIGHT TO THE END | 5 | 4 | 2 | 0.67 | +60 | +30.2 |
| MISSILES IN THE MOVE | 23 | 16 | 2 | 0.67 | +28 | +14.2 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +146 | +72.9 |
| OPENS UP IN FULL | 15 | 13 | 2 | 0.67 | +12 | +5.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -8 | -3.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +112 | +56.2 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -44 | -21.8 |
| THE ROW IN ITS ORDER | 10 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +135 | +67.3 |
| WHOLE FIGHT REACTION | 11 | 11 | 2 | 0.67 | +48 | +23.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +271 | +270.9 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BEST FACING | 1 | 1 | 1 | 0.33 | +89 | +89.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +109 | +109.4 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 7 | 7 | 1 | 0.33 | +76 | +75.9 |
| HIS MOVE AND SHOT | 29 | 28 | 1 | 0.33 | +13 | +13.4 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +158 | +158.0 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +29 | +29.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +14 | +14.0 |
| MISSILES NEXT TURN | 24 | 18 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 28 | 24 | 1 | 0.33 | +0 | +0.5 |
| OVERRUNS AWAY | 7 | 6 | 1 | 0.33 | +8 | +8.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.8 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +40 | +39.5 |
| REDIRECT COUNTER | 14 | 10 | 1 | 0.33 | +13 | +13.1 |
| SET UP TOGETHER | 6 | 4 | 1 | 0.33 | +15 | +15.2 |
| SHOTS AFTER THE MOVES | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -44 | -43.9 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +8 | +8.1 |
| WHOLE FIGHT DANGER | 20 | 20 | 1 | 0.33 | +24 | +24.2 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +17 | +17.0 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 74 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 14 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 7 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 49 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 102 | 102 | 0 | 0.00 | - | - |
| HONEST WORTH | 23 | 20 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 18 | 15 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 282 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 215 | 208 | 0 | 0.00 | - | - |
| STAY WORTH | 72 | 64 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 6 | 6 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | not checked | - | - | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE FIGHT MOVES | 7 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 262 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 14 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |

### Off best figure: chf-efd8067-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 2.67 | 107.6 |
| JOB FIRST | gate | 5.00 | 2.67 | 14.9 |
| ARMY TABLE | rule | 1.00 | 4.00 | 76.2 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 43.4 |
| HOLDER ASSIGNMENT | rule | 1.67 | - | 22.1 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 1.9 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 118.8 |
| CARRIES OUT SET-UP | rule | 0.67 | - | 304.8 |
| NO REASON | gate | 0.67 | - | 2.9 |
| SUPPORT NARROWED | rule | - | 0.67 | 21.8 |
| FIGHT ORDER BAND | gate | 0.33 | - | 1.4 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.5 |
| PATHS CROSS | rule | - | 0.33 | 68.1 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 1.8 |
| RULE SWITCHED OFF | gate | - | 0.33 | 23.8 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 43.9 |
| WHO GETS IN | rule | 0.33 | - | 280.5 |

### Plans: chf-efd8067-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 390 | 174 | 45% |
| Mine | move | 40.0 | 96% | 2370 | 0 | 0% |
| Mine | shoot | 6.3 | 37% | 772 | 247 | 32% |
| Opponent | charge | 5.0 | 53% | 765 | 666 | 87% |
| Opponent | join | 2.7 | 100% | 91 | 0 | 0% |
| Opponent | move | 34.3 | 94% | 1801 | 0 | 0% |
| Opponent | shoot | 2.3 | 57% | 60 | 251 | 418% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: chf-efd8067-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 22 (6) | 0 | 22 | 65 | 17% | 1.4 | 0 (1) | 0 (3) | 74 (2) | 43 (3) | 0 (3) |
| Mine | Character | 6 | 35 (6) | 35 | 0 | 35 | 0% | 4.0 | 52 (2) | 26 (2) | 16 (1) | 52 (2) | 25 (3) |
| Mine | Clean-up | 1 | 805 (1) | 0 | 805 | 0 | 100% | - | - | 805 (1) | - | - | 805 (1) |
| Mine | Fast Hammer | 6 | 57 (6) | 57 | 0 | 50 | 50% | 3.0 | 0 (3) | 89 (3) | - | 54 (4) | 60 (2) |
| Mine | Hammer | 5 | 59 (5) | 16 | 43 | 55 | 0% | 2.4 | 0 (3) | 131 (2) | - | 102 (3) | 11 (2) |
| Mine | Holder | 8 | 86 (8) | 0 | 86 | 20 | 25% | 2.3 | 204 (2) | 82 (4) | 0 (2) | 204 (2) | 50 (6) |
| Mine | Shooter | 5 | 0 (5) | 0 | 0 | 14 | 0% | 2.2 | 0 (2) | 0 (3) | - | 0 (3) | 0 (2) |
| Mine | Wizard | 4 | 36 (4) | 36 | 0 | 0 | 0% | 1.5 | 0 (2) | 0 (1) | 56 (1) | 0 (3) | 56 (1) |
| Opponent | Chaff | 4 | 108 (4) | 58 | 50 | 19 | 75% | 5.0 | 144 (3) | - | 0 (1) | 144 (3) | 0 (1) |
| Opponent | Character | 11 | 60 (11) | 60 | 0 | 7 | 27% | 3.0 | 28 (3) | 69 (5) | 76 (3) | 100 (5) | 26 (6) |
| Opponent | Fast Hammer | 6 | 27 (6) | 22 | 5 | 25 | 33% | 2.2 | 0 (1) | 31 (4) | 38 (1) | 44 (2) | 22 (4) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 67 | 12% | 3.6 | - | 0 (7) | 0 (1) | 0 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 65 | 33% | 5.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 27 (3) | 19 | 8 | 30 | 0% | 1.0 | - | 0 (1) | 40 (2) | 0 (2) | 71 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: chf-efd8067-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 236 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Mine | Tomb Kings of Khemri | 2 | 63 | 274 | 3.5 | 1.0 | 78 | 56 | +23 | 1 of 7 | 4 of 7 | - | +23 |
| **Mine** | all armies | 3 | 121 | 183 | 2.7 | 1.1 | 69 | 49 | +20 | 1 of 8 | 5 of 8 | +0 | +23 |
| Opponent | Vampire Counts | 1 | 0 | 495 | 4.0 | 1.2 | 124 | 11 | +112 | 2 of 4 | 3 of 4 | +145 | +102 |
| Opponent | Warriors of Chaos | 1 | 0 | 127 | 4.0 | 1.0 | 32 | 59 | -27 | 2 of 4 | 3 of 4 | - | -27 |
| Opponent | Wood Elf Realms | 1 | 70 | 861 | 6.0 | 1.3 | 144 | 38 | +106 | 4 of 6 | 5 of 6 | +219 | +49 |
| **Opponent** | all armies | 3 | 23 | 494 | 4.7 | 1.2 | 106 | 36 | +70 | 8 of 14 | 11 of 14 | +194 | +36 |

### Effective charges: chf-efd8067-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net -195) | 0 | 1 (net +0) | 4 (net +119) | 1 | 17% (1 of 6) |
| Opponent | Vampire Counts | 4 | 1 (net +95) | 0 | 0 | 0 | 1 (net +0) | 1 (net +210) | 1 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 4 | 1 (net -116) | 0 | 0 | 1 (net +72) | 0 | 1 (net +55) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 6 | 1 (net +438) | 1 (net +0) | 0 | 0 | 1 (net +60) | 2 (net +130) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: chf-efd8067-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 195 | 201 | -195 | 0 | 195 | -195 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 241 | 141 | +95 | 110 | 16 | +94 | +39.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 116 | +0 | 58 | 0 | +58 | +13.5 |
| Mine | No odds | 1 | 72 | 116 | -122 | 0 | 122 | -122 | -169.4 |
| Mine | All fights | 8 | 238 | 142 | +20 | 76 | 49 | +26 | +11.1 |
| Opponent | Long shot (under 50%) | 3 | 262 | 286 | +139 | 227 | 107 | +119 | +45.6 |
| Opponent | 50-54% | 1 | 624 | 440 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 116 | 72 | +72 | 72 | 0 | +72 | +62.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 232 | 132 | +132 | 132 | 10 | +121 | +52.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 485 | 76 | +30 | 32 | 0 | +32 | +6.7 |
| Opponent | No odds | 3 | 293 | 332 | -33 | 64 | 82 | -18 | -6.2 |
| Opponent | All fights | 14 | 307 | 217 | +70 | 110 | 44 | +66 | +21.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p35 | move | 26 | 7 (27%) | 5 (19%) | 6 (23%) | 13 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

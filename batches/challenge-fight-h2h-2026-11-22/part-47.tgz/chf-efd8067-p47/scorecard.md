# Doctrine scorecard: chf-efd8067-p47

### Scorecard: chf-efd8067-p47

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 9 | - | 0 | 1 | 0 | 0 | 0 | 200 |
| L2131 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 2 | 4 | 0 | 2 | 0 | 0 | 0 | 140 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 4.5 | 2.5 | 1.3 | 1.3 | 0.0 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 1.0 | 4.0 | 2.0 | 2.7 | 0.3 | 0.0 | 0.0 | 103.3 |

### KPIs: chf-efd8067-p47

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (2 of 16) | 0% (0 of 15) | 6% (2 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 100% (4 of 4); on the table 100% | 100% (11 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 3); on the table 0% | 0% (0 of 1); on the table 0% | 0% (0 of 4); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 64% (7 of 11); on the table 64% | 67% (4 of 6); on the table 67% | 65% (11 of 17); on the table 65% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | - | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (5 of 11) | - | 45% (5 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (6 of 9) | 47% (7 of 15) | 54% (13 of 24) |
| Points that never fought | lower | 56% (3369 of 5997) | 70% (4181 of 5999) | 63% (7550 of 11996) |
|   infantry points that never fought | lower | 54% (911 of 1675) | 81% (1061 of 1306) | 66% (1972 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 76% (16 of 21) | 77% (24 of 31) | 77% (40 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 85% (4145 of 4866) | 74% (4372 of 5884) | 79% (8517 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (57%) | - | 1.3 (57%) |
| GONE: slain | 0.3 (14%) | - | 0.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (29%) | - | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 8.7 | 2.0 | 1.7 | 1.7 | 0.7 |
| not cast | 1.3 | 6.0 | 0.3 | 2.3 | 23.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (67%) | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) |
| GONE: slain | 0.3 (25%) | 0.7 (11%) | 0.0 (0%) | 0.3 (14%) | 1.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.3 (22%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (75%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.7 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 0% (0 of 4) | 0% (0 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (41 of 58) | 51% (18 of 35) | 63% (59 of 93) |
|   cavalry | 89% (8 of 9) | 50% (8 of 16) | 64% (16 of 25) |
|   character | 0% (0 of 9) | 33% (4 of 12) | 19% (4 of 21) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 80% (24 of 30) | 86% (6 of 7) | 81% (30 of 37) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (24%) | 2.0 (35%) | 3.3 (29%) |
| CHARGED: it charged | 1.3 (24%) | 1.3 (24%) | 2.7 (24%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.3 (6%) | 0.7 (6%) |
| NO TARGET IN RANGE | 2.3 (41%) | 1.7 (29%) | 4.0 (35%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (6%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.3 | 2.3 | 82% | 3.6 pts | 33 pts |
| character | 1.3 | 0.7 | 50% | 2.5 pts | 3 pts |
| chariot | 3.0 | 0.3 | 89% | 1.9 pts | 6 pts |
| infantry | 11.0 | 7.3 | 55% | 12.4 pts | 136 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 2.3 | 2.7 |
| Charges that made contact a game | 2.0 | 1.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | - | 1.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.21 contact (28 units) | 0.29 declared, 0.17 contact (24 units) | 0.29 declared, 0.19 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 75% (3 of 4) | 50% (1 of 2) | 100% (2 of 2) | 75% (6 of 8) |
| Character on its own | 67% (2 of 3) | - | 83% (5 of 6) | 78% (7 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 91% (10 of 11) | 100% (4 of 4) | - | 93% (14 of 15) |
| Monster | 40% (2 of 5) | 100% (1 of 1) | - | 50% (3 of 6) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 50% (2 of 4); on the table 50% | 50% (3 of 6) | 57% | 67% (6 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 33% | - | 75% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 37% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 67% (4 of 6); on the table 67% | - | 63% | 79% (15 of 19) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 84% | 75% (9 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p47, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 25% (1) | 29% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.33 | 1.00 |

### Quality by phase: chf-efd8067-p47

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (4 of 11) | 44% (4 of 9) |
| Strategy | Support requests answered (helper made contact too) | 33% (1 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 100% (4 of 4) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.7 | 0.3 |
| Movement | Idle units | 1.3 | 2.7 |
| Movement | Points that never moved of their own | 66.7 | 103.3 |
| Movement | Fights charged into per game | 1.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net -72 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +465 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +114 | 2 of 3, net +144 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | 1 of 3, net +470 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 6.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 20% (9 of 44) | 21% (4 of 19) |
| Shooting | Points destroyed by shooting units | 76.0 | 45.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | - |
| Magic | Wounds caused by magic missiles | 3.3 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 38.7 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.0 / 0.7 / 0.0 / 0.0 | 0.0 / 1.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 155.0 | 427.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +101 | +157 |
| Combat | Net per 100 charger points, damage counted | +33.5 | +39.2 |
| Combat | First round won (charged fights) | 60% | 75% |
| Combat | Net points per charged fight | +79 | +190 |
| Combat | Net points per supported fight / lone fight | -235 / +158 | - / +190 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 1 of 4 |
| Game | Points lost | 596.0 | 404.3 |
| Game | VP from objectives | 800.0 | 406.7 |
| Game | Lone holders (player turns) | 4.5 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +276 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1000
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p47

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 24.7 | +272.2 | 0.0 | 658.7 | 23.7 | +179.8 | 0.0 | 351.3 |
| BACKS UP THE FIGHT | 0.3 | +66.0 | 0.0 | 0.0 | 0.3 | +28.5 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +5.1 | 310.0 | 313.3 | 1.7 | +2.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -1.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +3.3 | 0.0 | 76.3 | 0.7 | +23.5 | 0.0 | 155.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | +14.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.0 | -359.2 | 0.0 | 123.0 | 19.7 | -627.4 | 0.0 | 500.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 286.3 | 76.3 | 0.7 | +0.0 | 176.7 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 74.7 | 8.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 38.7 | 48.3 | 1.0 | +0.0 | 194.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +150.5 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -607.0 | 0.0 | 156.7 | 8.0 | -458.6 | 0.0 | 159.7 |
| DENIED BY THE FIGHT | 0.3 | -3.5 | 46.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +55.2 | 0.0 | 0.0 | 7.3 | +60.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +3.7 | 93.3 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.3 | +604.3 | 24.0 | 83.7 |
| EXACT ROUND | 2.0 | +28.2 | 193.0 | 154.7 | 1.0 | +34.7 | 233.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 1.0 | +0.0 | 0.0 | 37.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 193.0 | 178.7 | 1.3 | +0.0 | 233.0 | 0.0 |
| FALLS SHORT | 10.0 | +34.8 | 0.0 | 176.7 | 16.7 | +190.8 | 0.0 | 280.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +5.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -26.5 | 0.0 | 78.3 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.3 | +0.9 | 0.0 | 38.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 48.0 | - | - | - | - |
| FIVE ACTION | 87.0 | +5570.9 | 930.0 | 1127.3 | 83.0 | +4289.3 | 397.0 | 1255.3 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 32.0 | 7.0 | +0.0 | 0.0 | 385.7 |
| FOLLOW UP WEIGHED | 1.7 | +252.4 | 0.0 | 37.3 | 1.0 | +329.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +29.8 | 286.3 | 178.7 | 2.0 | +199.5 | 253.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 72.3 | 3.0 | +0.0 | 0.0 | 454.0 |
| FRIEND CHARGES FIRST | 0.3 | -72.8 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.0 | -76.1 | 68.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.3 | +769.2 | 0.0 | 0.0 | 10.0 | +538.6 | 0.0 | 38.7 |
| GUN FIGURES | 0.7 | +3.5 | 38.7 | 43.3 | - | - | - | - |
| HALF WHEN STILL FLEEING | - | - | - | - | 0.7 | -0.2 | 76.3 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 764.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 48.3 | 13.0 | +0.0 | 0.0 | 462.0 |
| HIS CHARGE DENIED | 0.7 | +65.2 | 0.0 | 78.3 | - | - | - | - |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 24.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 477.3 |
| HIS MOVE AND SHOT | 5.3 | -25.3 | 0.0 | 24.0 | 5.0 | -21.3 | 0.0 | 68.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 139.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 40.0 | 7.0 | +0.0 | 0.0 | 632.3 |
| HIS RANDOM MOVE | 24.3 | +0.0 | 0.0 | 362.0 | 14.0 | +0.0 | 0.0 | 154.7 |
| HIS RANDOM MOVER COMES | 7.7 | +0.0 | 0.0 | 187.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.3 | +534.9 | 0.0 | 120.0 | 34.0 | +850.2 | 0.0 | 613.0 |
| HIS SHOTS BY HIS RUN | 31.7 | +313.5 | 0.0 | 240.0 | 34.0 | +471.9 | 0.0 | 892.3 |
| HIS TURN DENIED | 0.7 | +6.4 | 46.7 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 24.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.7 | +793.8 | 0.0 | 24.0 | 6.7 | +360.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -65.6 | 131.3 | 78.3 | 2.0 | -75.8 | 253.0 | 0.0 |
| IDLE COST | 4.0 | -68.4 | 0.0 | 156.7 | 10.0 | -136.5 | 0.0 | 114.3 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 1.3 | +575.8 | 0.0 | 102.3 | - | - | - | - |
| JOINT ON THE TABLE | 0.3 | +297.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +24.5 | 0.0 | 0.0 | 0.7 | +11.3 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 310.0 | 391.7 | 5.3 | +0.0 | 468.0 | 596.3 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +0.6 | 0.0 | 78.3 | 0.7 | +0.2 | 76.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +13.2 | 0.0 | 0.0 | 1.3 | +26.5 | 0.0 | 77.3 |
| MANOEUVRE | 1.0 | -5.7 | 0.0 | 0.0 | 1.0 | -12.9 | 0.0 | 41.7 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +79.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -32.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +34.0 | 0.0 | 0.0 | 2.3 | +60.3 | 0.0 | 77.3 |
| MEETS IN TIME | 5.3 | +209.8 | 0.0 | 0.0 | 3.3 | +63.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +62.5 | 0.0 | 156.7 | 3.0 | +34.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +31.6 | 0.0 | 156.7 | 3.0 | +21.1 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.7 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 42.0 | 38.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -20.7 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.0 | +534.7 | 0.0 | 40.0 | 5.7 | +314.5 | 0.0 | 742.7 |
| NEARER NOT NEEDED | 10.0 | +398.8 | 0.0 | 24.0 | 5.3 | +224.8 | 0.0 | 46.7 |
| NEXT CHARGE BY LIST | 4.7 | +546.6 | 378.0 | 313.3 | 5.3 | +286.8 | 0.0 | 587.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -1.5 | 0.0 | 24.0 | 0.3 | -10.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +85.9 | 118.7 | 13.7 | 4.7 | +118.4 | 308.0 | 42.0 |
| NO DOUBLE ROUNDS | 3.0 | -122.1 | 286.3 | 154.7 | 1.3 | -112.9 | 176.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | -58.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -157.3 | 46.7 | 48.0 | 3.3 | -82.0 | 0.0 | 193.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -96.6 | 0.0 | 37.3 | 6.3 | -100.2 | 0.0 | 354.0 |
| ONE JOINT FIGURE | 1.0 | +106.1 | 0.0 | 102.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.3 | -68.1 | 0.0 | 0.0 | 2.7 | -1.7 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.3 | +47.0 | 84.7 | 0.0 | 1.0 | +20.2 | 233.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +3.8 | 201.7 | 76.3 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -3.1 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 41.7 | +530.2 | 298.7 | 1147.0 | 39.0 | +321.8 | 204.7 | 745.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 156.7 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -257.4 | 0.0 | 40.0 | 10.0 | -315.3 | 0.0 | 658.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 68.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 155.0 |
| PROMISE SHOT AWAY | 0.7 | -3.9 | 68.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.7 | +2102.1 | 196.7 | 304.3 | 23.7 | +2579.0 | 281.0 | 310.0 |
| RANDOM MOVE BY FIGURES | 3.0 | +45.3 | 0.0 | 96.7 | 5.0 | +71.4 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +71.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.0 | +131.7 | 0.0 | 80.0 | 0.3 | +8.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +0.0 | 0.0 | 196.0 | - | - | - | - |
| REDIRECT WEIGHED | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -58.5 | 0.0 | 0.0 | 1.3 | -36.3 | 0.0 | 394.0 |
| RESERVE FALL BACK | 1.7 | +40.3 | 0.0 | 24.0 | 1.0 | +31.5 | 0.0 | 76.0 |
| RISK BY ARC | 2.7 | -24.9 | 286.3 | 100.3 | 2.0 | -1.2 | 253.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -14.6 | 93.3 | 0.0 | - | - | - | - |
| RUN DOWN | 2.3 | -12.8 | 131.3 | 78.3 | 0.3 | -5.2 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -0.7 | 34.0 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 1.0 | +119.5 | 84.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -17.4 | 0.0 | 24.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +15.9 | 0.0 | 24.0 | - | - | - | - |
| SET UP TOGETHER | 1.7 | +13.5 | 0.0 | 0.0 | 1.3 | +26.5 | 0.0 | 77.3 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +19.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 156.7 | 2.7 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +83.3 | 136.0 | 0.0 | 0.7 | +1.9 | 48.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -2.2 | 0.0 | 24.0 | - | - | - | - |
| SHOT RISK POINTS | 19.0 | -154.1 | 0.0 | 192.0 | 19.7 | -98.9 | 0.0 | 539.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +299.3 | 0.0 | 163.3 | 5.7 | +80.1 | 0.0 | 122.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +19.3 | 0.0 | 0.0 |
| SPELL WORTH | 4.7 | +123.2 | 313.3 | 313.3 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.7 | -16.0 | 155.0 | 76.3 | 0.7 | -6.5 | 156.7 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 123.3 | 8.7 | +0.0 | 0.0 | 235.7 |
| STAND AND SHOOT | 0.3 | -1.7 | 0.0 | 0.0 | 0.3 | -0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 35.7 | +0.0 | 643.7 | 497.7 | 31.3 | +0.0 | 144.0 | 287.0 |
| STAY WORTH | 10.3 | +76.5 | 41.7 | 91.3 | 4.7 | +24.1 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | 0.3 | -23.0 | 0.0 | 0.0 | 0.7 | -13.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 48.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.7 | +92.5 | 0.0 | 0.0 | 6.7 | +215.3 | 0.0 | 116.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 6.7 | +92.5 | 0.0 | 0.0 | 6.7 | +215.3 | 0.0 | 116.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +20.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | +0.9 | 93.3 | 0.0 | 1.0 | -0.1 | 233.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 37.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 426.0 | 38.0 | +0.0 | 0.0 | 627.7 |
| TIED UP BY THE SUM | 1.7 | +186.4 | 131.3 | 0.0 | 0.3 | +42.6 | 20.0 | 0.0 |
| TIME ON OUR SIDE | 28.7 | +334.2 | 0.0 | 211.3 | 17.7 | +159.8 | 0.0 | 155.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 77.3 |
| WHO GETS IN | 1.0 | +583.1 | 0.0 | 78.3 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +36.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.0 | -266.9 | 0.0 | 123.0 | 4.3 | -372.5 | 0.0 | 310.0 |
| WHOLE FIGHT GAIN | 0.7 | +14.5 | 0.0 | 102.3 | - | - | - | - |
| WHOLE FIGHT REACTION | 0.7 | +27.3 | 0.0 | 0.0 | 1.0 | +63.0 | 78.3 | 38.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.7 | +148.3 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p47

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 145 | 145 | 89 | 29.67 | +1144 | +12.9 |
| HIS SHOT LIST | 193 | 179 | 54 | 18.00 | +490 | +9.1 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +2968 | +55.0 |
| HIS SHOTS BY HIS RUN | 197 | 186 | 44 | 14.67 | +359 | +8.2 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 10.33 | +0 | +0.0 |
| FIVE ACTION | 510 | 488 | 26 | 8.67 | +997 | +38.3 |
| DEPLOY BY FIGURES | 47 | 47 | 24 | 8.00 | +212 | +8.8 |
| GOAL WALK | 55 | 51 | 24 | 8.00 | +1430 | +59.6 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 32 | 26 | 23 | 7.67 | +598 | +26.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -718 | -31.2 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 23 | 7.67 | -1718 | -74.7 |
| NEXT CHARGE BY LIST | 30 | 27 | 19 | 6.33 | +598 | +31.5 |
| NO CHAFF EDGES | 22 | 21 | 16 | 5.33 | +431 | +26.9 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| QUARTER ODDS | 130 | 125 | 14 | 4.67 | +1210 | +86.4 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 24 | 24 | 13 | 4.33 | +350 | +26.9 |
| SHOT RISK POINTS | 116 | 111 | 13 | 4.33 | +141 | +10.8 |
| TIME ON OUR SIDE | 139 | 115 | 13 | 4.33 | +20 | +1.5 |
| MEETS IN TIME | 26 | 26 | 12 | 4.00 | +505 | +42.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SUPPORT ADDS | 40 | 38 | 9 | 3.00 | +72 | +8.1 |
| SUPPORT WORKED OUT | 40 | 38 | 9 | 3.00 | +72 | +8.1 |
| CHARGE LOSSES | 101 | 97 | 8 | 2.67 | +36 | +4.5 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1746 | +218.2 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +216 | +26.9 |
| COVER ONCE | 50 | 31 | 7 | 2.33 | +126 | +17.9 |
| FOUR ROUNDS | 16 | 14 | 7 | 2.33 | +354 | +50.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 42 | 27 | 5 | 1.67 | +10 | +2.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +1728 | +431.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +107 | +26.8 |
| MAIN BODY KEEPS ITS BAND | 4 | 4 | 4 | 1.33 | +206 | +51.6 |
| MAX FOR POSITIONING | 14 | 13 | 4 | 1.33 | +7 | +1.8 |
| ONE OBJECTIVE FORMULA | 27 | 22 | 4 | 1.33 | +123 | +30.7 |
| STAY WORTH | 45 | 33 | 4 | 1.33 | +29 | +7.2 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 4 | 4 | 1.33 | +142 | +35.5 |
| CAST JOB | 7 | 7 | 3 | 1.00 | +0 | +0.1 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +80 | +26.7 |
| EVASIVE BY THE ODDS | 7 | 7 | 3 | 1.00 | +1742 | +580.5 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +358 | +119.5 |
| SHOTS AFTER THE MOVES | 9 | 9 | 3 | 1.00 | +0 | +0.0 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | +1749 | +583.1 |
| WHOLE FIGHT DANGER | 28 | 25 | 3 | 1.00 | +43 | +14.5 |
| EXACT ROUND | 9 | 9 | 2 | 0.67 | +121 | +60.4 |
| NEARER NOT NEEDED | 46 | 44 | 2 | 0.67 | +81 | +40.5 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -11 | -5.6 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -12 | -5.9 |
| REDIRECT COUNTER | 13 | 12 | 2 | 0.67 | +11 | +5.3 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +80 | +39.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 2 | 0.67 | +5 | +2.6 |
| STRONG ENOUGH TO HOLD | 3 | 3 | 2 | 0.67 | +15 | +7.3 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -4 | -4.4 |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 1 | 0.33 | +37 | +37.4 |
| FALLS SHORT | 80 | 66 | 1 | 0.33 | +21 | +21.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| HONEST WORTH | 13 | 11 | 1 | 0.33 | +2 | +1.9 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +894 | +893.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +239 | +238.6 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +42 | +41.8 |
| NO DOUBLE ROUNDS | 13 | 11 | 1 | 0.33 | +2 | +1.9 |
| OPENS UP IN FULL | 7 | 6 | 1 | 0.33 | +19 | +19.4 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +92 | +91.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +43 | +43.1 |
| REFORMS TO MEET IT | 8 | 5 | 1 | 0.33 | +18 | +17.6 |
| RISK BY ARC | 14 | 12 | 1 | 0.33 | +2 | +1.9 |
| SCOUT BY DROPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| SHOTS IN THE MOVE | 63 | 41 | 1 | 0.33 | +18 | +18.4 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -29 | -29.2 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +62 | +61.7 |
| WHOLE FIGHT REACTION | 5 | 5 | 1 | 0.33 | +1 | +0.8 |
| WOUNDS ON THE RANKS | 5 | 5 | 1 | 0.33 | +101 | +100.8 |
| BACKS UP THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 11 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 9 | 9 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 11 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 70 | 66 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 31 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 38 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 115 | 112 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 28 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 84 | 84 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 13 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 242 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 6 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 21 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 201 | 194 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE FIGHT MOVES | 6 | 5 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 236 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p47

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 4.33 | 74.7 |
| JOB FIRST | gate | 3.67 | 2.67 | 34.0 |
| ARMY TABLE | rule | 1.67 | 3.00 | 45.6 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.00 | 22.6 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 2.5 |
| NO REASON | gate | 0.67 | - | 17.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 5.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 5.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 17.6 |
| CHAFF PASSED | rule | - | 0.33 | 4.4 |
| JOINT CHARGE NOW | rule | 0.33 | - | 21.9 |
| RESERVE FALL BACK | rule | 0.33 | - | 20.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 29.2 |

### Plans: chf-efd8067-p47

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 60% | 826 | 309 | 37% |
| Mine | join | 0.7 | 100% | 26 | 0 | 0% |
| Mine | move | 34.7 | 92% | 1607 | 0 | 0% |
| Mine | shoot | 2.7 | 88% | 315 | 221 | 70% |
| Mine | support | 0.3 | 100% | 46 | 0 | 0% |
| Opponent | charge | 1.3 | 50% | 208 | 196 | 94% |
| Opponent | join | 0.3 | 100% | 37 | 0 | 0% |
| Opponent | move | 34.7 | 94% | 1464 | 0 | 0% |
| Opponent | shoot | 2.7 | 75% | 130 | 126 | 96% |

### Battle groups: chf-efd8067-p47

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 17% | 0% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p47

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 38 (5) | 0 | 38 | 81 | 20% | 2.2 | 0 (2) | 91 (2) | 0 (1) | 0 (2) | 59 (3) |
| Mine | Character | 7 | 33 (7) | 33 | 0 | 43 | 29% | 2.2 | 44 (6) | 0 (1) | - | 0 (2) | 45 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 17 (4) | 17 | 0 | 9 | 75% | 1.0 | 19 (3) | 0 (1) | - | 36 (2) | 0 (2) |
| Mine | Hammer | 5 | 7 (5) | 7 | 0 | 33 | 20% | 2.5 | 0 (1) | 0 (2) | 22 (2) | 0 (3) | 21 (2) |
| Mine | Holder | 7 | 35 (7) | 0 | 35 | 45 | 29% | 4.4 | 121 (2) | 6 (3) | 0 (1) | 67 (4) | 0 (2) |
| Mine | Shooter | 5 | 282 (5) | 120 | 163 | 44 | 0% | 1.0 | 1067 (1) | 100 (2) | 105 (2) | 317 (3) | 224 (2) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Character | 8 | 45 (8) | 45 | 0 | 24 | 50% | 2.2 | 107 (4) | 0 (4) | - | 0 (5) | 84 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 25 (5) | 8 | 17 | 14 | 60% | 1.0 | 61 (2) | 0 (3) | - | 0 (1) | 32 (4) |
| Opponent | Hammer | 10 | 42 (10) | 42 | 0 | 23 | 30% | 3.1 | 55 (6) | 19 (3) | 0 (1) | 60 (6) | 0 (4) |
| Opponent | Holder | 4 | 24 (4) | 0 | 24 | 0 | 75% | 6.0 | - | 45 (2) | 0 (1) | - | 29 (3) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 70 | 0% | 1.3 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |

### Charged fights: chf-efd8067-p47

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 228 | 239 | 3.0 | 1.0 | 80 | 24 | +56 | 0 of 3 | 2 of 3 | - | +56 |
| Mine | Vampire Counts | 1 | 0 | 465 | 2.0 | 1.5 | 232 | 118 | +115 | 2 of 2 | 1 of 2 | -235 | +465 |
| **Mine** | all armies | 3 | 115 | 235 | 1.7 | 1.2 | 141 | 61 | +79 | 2 of 5 | 3 of 5 | -235 | +158 |
| Opponent | Warriors of Chaos | 2 | 32 | 380 | 2.0 | 1.0 | 190 | 0 | +190 | 1 of 4 | 3 of 4 | - | +190 |
| Opponent | Wood Elf Realms | 1 | 144 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 70 | 253 | 1.3 | 1.0 | 190 | 0 | +190 | 1 of 4 | 3 of 4 | - | +190 |

### Effective charges: chf-efd8067-p47

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 3 | 1 (net -72) | 0 | 0 | 0 | 1 (net +114) | 0 | 1 | 0% (0 of 2) |
| Mine | Vampire Counts | 2 | 0 | 0 | 1 (net +465) | 1 (net -235) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 2 (net +144) | 1 (net +470) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p47

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 72 | 102 | -72 | 0 | 96 | -96 | -133.3 |
| Mine | Effective (55-75%) | 1 | 129 | 365 | +465 | 465 | 0 | +465 | +360.5 |
| Mine | 76-89% | 1 | 440 | 494 | -235 | 0 | 235 | -235 | -53.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 102 | +114 | 114 | 0 | +114 | +26.5 |
| Mine | No odds | 1 | 431 | 125 | +125 | 280 | 25 | +255 | +59.2 |
| Mine | All fights | 5 | 301 | 238 | +79 | 172 | 71 | +101 | +33.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 494 | 470 | +470 | 470 | 0 | +470 | +95.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 494 | 94 | +144 | 147 | 0 | +147 | +29.8 |
| Opponent | No odds | 1 | 120 | 92 | +0 | 18 | 154 | -136 | -113.2 |
| Opponent | All fights | 4 | 400 | 188 | +190 | 196 | 39 | +157 | +39.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p47 | move | 23 | 2 (9%) | 0 (0%) | 1 (4%) | 20 (87%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

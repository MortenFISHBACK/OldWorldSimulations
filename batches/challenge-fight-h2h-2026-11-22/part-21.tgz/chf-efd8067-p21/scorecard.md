# Doctrine scorecard: chf-efd8067-p21

### Scorecard: chf-efd8067-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 2 | 2 | 9 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 1 | 3 | 0 | 1 | 0 | 0 | 0 | 280 |
| L1629 | 3 | 1 | Opponent | no | 7 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | no | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.5 | 2.0 | 4.0 | 0.7 | 0.0 | 0.0 | 0.0 | 93.3 |
| **Average** | | | Opponent | 33% | 3.5 | 1.7 | 4.0 | 2.3 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: chf-efd8067-p21

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 17) | 0% (0 of 15) | 3% (1 of 32) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (3 of 3); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (3 of 6); on the table 50% | 50% (2 of 4); on the table 50% | 50% (5 of 10); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 64% (7 of 11); on the table 64% | 71% (5 of 7); on the table 71% | 67% (12 of 18); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 56% (5 of 9) | 56% (5 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 86% (6 of 7) | 86% (6 of 7) |
| Points that never fought | lower | 43% (2558 of 6000) | 41% (2487 of 5999) | 42% (5045 of 11999) |
|   infantry points that never fought | lower | 84% (1114 of 1332) | 79% (675 of 855) | 82% (1789 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (10 of 20) | 76% (19 of 25) | 64% (29 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2276 of 5135) | 63% (3437 of 5430) | 54% (5713 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (29%) | 0.7 (29%) |
| MARCHED: its unit marched | - | 0.7 (29%) | 0.7 (29%) |
| FLEEING: fleeing | - | 0.3 (14%) | 0.3 (14%) |
| GONE: slain | - | 0.7 (29%) | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.0 | 0.7 | 1.7 | 0.7 |
| not cast | 6.3 | 1.0 | 1.3 | 2.3 | 19.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (16%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (79%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (46 of 86) | 0% (0 of 7) | 49% (46 of 93) |
|   cavalry | 67% (2 of 3) | 0% (0 of 5) | 25% (2 of 8) |
|   character | 50% (6 of 12) | 0% (0 of 2) | 43% (6 of 14) |
|   chariot | 17% (1 of 6) | - | 17% (1 of 6) |
|   infantry | 58% (21 of 36) | - | 58% (21 of 36) |
|   monster | 29% (5 of 17) | - | 29% (5 of 17) |
|   war machine | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (28%) | 1.0 (43%) | 4.7 (30%) |
| CHARGED: it charged | 2.0 (15%) | 0.3 (14%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 2.0 (15%) | 0.0 (0%) | 2.0 (13%) |
| NO TARGET IN RANGE | 2.0 (15%) | 1.0 (43%) | 3.0 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 2.7 (20%) | 0.0 (0%) | 2.7 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.3 | 0.7 | 86% | 8.1 pts | 19 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 12.0 | 1.7 | 89% | 4.2 pts | 51 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.7 | 3.0 | 64% | 34.3 pts | 126 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 4.3 | 4.8 |
| Charges that made contact a game | 4.7 | 3.3 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 3.00 declared, 3.00 contact (1 units) | 0.80 declared, 0.80 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.75 declared, 0.65 contact (20 units) | 0.45 declared, 0.32 contact (22 units) | 0.60 declared, 0.48 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 67% (2 of 3) | 0% (0 of 2) | 70% (7 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 100% (2 of 2) | 33% (3 of 9) | 62% (10 of 16) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 57% (4 of 7) | 33% (1 of 3) | - | 50% (5 of 10) |
| Monster | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (2 of 4); on the table 50% | - | 48% | 29% (2 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 64% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 80% (4 of 5); on the table 80% | - | 16% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (4 of 6); on the table 67% | 67% (4 of 6) | 28% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 48% | 79% (15 of 19) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 73% (8) | 67% (10) |
| ...free all their last turn and able to turn (per game) | 0.00 | 2.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (8 of 13) | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (11 of 24) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 93.3 | 113.3 |
| Movement | Fights charged into per game | 4.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 9 | 2 of 6, net +202 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 9, net +154 | 1 of 6, net +83 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 9, net +171 | 2 of 6, net +70 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (14 of 36) | 100% (3 of 3) |
| Shooting | Points destroyed by shooting units | 56.7 | 0.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (8 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.7 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 292.0 | 236.3 |
| Combat | Points run down | 108.3 | 193.0 |
| Combat | Net points per charged fight, damage counted | +112 | +167 |
| Combat | Net per 100 charger points, damage counted | +31.2 | +59.8 |
| Combat | First round won (charged fights) | 100% | 56% |
| Combat | Net points per charged fight | +113 | +141 |
| Combat | Net points per supported fight / lone fight | +205 / +105 | +83 / +148 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 13 | 4 of 9 |
| Game | Points lost | 431.7 | 828.0 |
| Game | VP from objectives | 783.3 | 463.3 |
| Game | Lone holders (player turns) | 1.5 | 3.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +630 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1260
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +80.2 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.0 | +231.1 | 0.0 | 47.0 | 20.3 | -226.2 | 0.0 | 255.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +10.4 | 0.0 | 0.0 | 0.7 | +3.3 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +159.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -54.7 | 68.3 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +5.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +60.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.7 | +26.6 | 0.0 | 85.0 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 1.3 | -38.2 | 91.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -23.1 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -9.4 | 67.0 | 0.0 | 0.7 | +4.4 | 47.0 | 16.7 |
| CHARGE LOSSES | 8.0 | -285.5 | 0.0 | 0.0 | 11.3 | -1030.0 | 0.0 | 587.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 47.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 383.7 | 0.0 | 1.7 | +0.0 | 74.7 | 62.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 343.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 47.0 | 0.0 |
| COVER ONCE | 6.7 | -399.1 | 0.0 | 0.0 | 8.7 | -1129.2 | 0.0 | 78.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -6.1 | 135.0 | 0.0 |
| DEPLOY BY FIGURES | 6.3 | -5.6 | 0.0 | 0.0 | 6.3 | +70.2 | 0.0 | 15.0 |
| DUEL STOPS AT THE KILL | 0.3 | -64.7 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +123.2 | 163.0 | 0.0 | 0.3 | +0.7 | 35.7 | 0.0 |
| EXACT ROUND | 2.7 | +11.8 | 272.7 | 135.0 | 2.3 | +4.6 | 328.0 | 62.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 47.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.0 | +1.4 | 271.7 | 135.0 | 3.3 | +3.1 | 252.7 | 78.7 |
| FALLS SHORT | - | - | - | - | 19.0 | +225.6 | 0.0 | 393.3 |
| FEATURE BUFFS | 0.7 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | 0.3 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +43.1 | 209.7 | 62.0 |
| FIRE AND FLEE | 0.3 | +1.6 | 0.0 | 26.7 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 56.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 83.3 | +8481.5 | 1264.7 | 415.3 | 71.7 | +3889.6 | 466.0 | 1256.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 287.0 |
| FOLLOW UP WEIGHED | 0.7 | +61.0 | 0.0 | 47.0 | 1.0 | +10.9 | 0.0 | 56.7 |
| FOUR ROUNDS | 4.7 | +393.6 | 466.7 | 135.0 | 4.3 | +266.1 | 466.0 | 78.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 150.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -28.6 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -20.2 | 0.0 | 135.0 | 0.7 | -15.5 | 135.0 | 0.0 |
| GOAL WALK | 8.7 | +899.5 | 0.0 | 0.0 | 5.3 | +540.3 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.0 | -0.6 | 116.3 | 0.0 | 1.3 | -6.6 | 162.7 | 62.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 130.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 166.3 | 16.7 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 135.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 530.3 |
| HIS CHARGE DENIED | 0.3 | +12.2 | 38.7 | 0.0 | 0.7 | +61.0 | 135.0 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 55.3 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 68.7 |
| HIS MOVE AND SHOT | 1.0 | -21.0 | 0.0 | 53.3 | 0.7 | -2.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 96.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 68.7 |
| HIS RANDOM MOVE | 7.0 | +0.0 | 0.0 | 53.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 7.7 | +77.7 | 0.0 | 47.0 | 31.3 | +809.2 | 0.0 | 768.7 |
| HIS SHOTS BY HIS RUN | 12.3 | +85.8 | 0.0 | 53.3 | 33.0 | +1102.5 | 0.0 | 1114.7 |
| HIS TURN DENIED | 0.3 | +10.5 | 65.0 | 0.0 | 0.3 | +3.9 | 27.7 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 53.3 | 7.3 | +0.0 | 0.0 | 147.0 |
| HOLDER ASSIGNMENT | 9.0 | +903.6 | 0.0 | 26.7 | 5.0 | +383.2 | 0.0 | 107.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -129.1 | 302.3 | 135.0 | 3.7 | -182.9 | 466.0 | 62.0 |
| IDLE COST | - | - | - | - | 14.0 | -194.2 | 0.0 | 189.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +11.3 | 55.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 1.0 | +81.8 | 0.0 | 0.0 | 1.0 | +16.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 71.7 | 368.3 | 4.0 | +0.0 | 47.0 | 186.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 67.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | +1.0 | 156.3 | 0.0 | 2.3 | +20.7 | 237.3 | 62.0 |
| MAKE SURE TOGETHER | 0.7 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | -0.5 | 0.0 | 0.0 | 1.0 | +14.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +18.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +25.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -8.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 2.3 | +39.0 | 0.0 | 0.0 | 3.7 | +77.8 | 0.0 | 31.7 |
| MEETS IN TIME | 3.7 | +208.2 | 0.0 | 0.0 | 2.0 | +143.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +36.7 | 0.0 | 0.0 | 3.0 | +28.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.3 | +23.3 | 0.0 | 0.0 | 4.0 | +32.1 | 0.0 | 65.0 |
| MOVE ORDER | 2.3 | +0.0 | 26.7 | 0.0 | 2.7 | +0.0 | 40.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +750.8 | 0.0 | 0.0 | 9.3 | +932.2 | 0.0 | 98.3 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.3 | +430.2 | 0.0 | 116.7 | 5.7 | +254.2 | 0.0 | 135.0 |
| NEXT CHARGE BY LIST | 4.7 | +495.6 | 0.0 | 0.0 | 6.3 | +690.3 | 0.0 | 30.0 |
| NO CHAFF EDGES | 3.7 | +84.8 | 180.3 | 135.0 | 2.3 | +84.8 | 224.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.7 | -182.0 | 466.7 | 135.0 | 3.0 | -157.3 | 225.0 | 62.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 40.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.7 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 2.0 | -105.8 | 0.0 | 0.0 | 5.7 | -189.5 | 166.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -204.4 | 0.0 | 0.0 | 7.0 | -111.2 | 0.0 | 186.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -1.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.0 | +12.1 | 0.0 | 26.7 | 2.0 | +59.4 | 0.0 | 40.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +10.6 | 27.7 | 0.0 |
| OPENS UP IN FULL | 1.0 | +25.2 | 121.7 | 135.0 | 1.3 | +59.7 | 225.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +81.5 | 163.0 | 135.0 | 1.0 | +48.1 | 240.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +10.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +1223.3 | 257.0 | 674.7 | 39.7 | +338.9 | 397.3 | 1054.3 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +67.8 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -248.5 | 0.0 | 0.0 | 9.0 | -309.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | -13.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -7.3 | 0.0 | 0.0 |
| QUARTER ODDS | 23.3 | +2738.2 | 318.0 | 0.0 | 17.0 | +1656.2 | 337.0 | 249.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.3 | +138.7 | 0.0 | 226.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +9.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +92.1 | 0.0 | 53.3 | 3.3 | +332.7 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 26.7 | 0.7 | +25.5 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +38.1 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -81.9 | 0.0 | 0.0 | 1.0 | -17.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.3 | +0.0 | 0.0 | 27.7 | - | - | - | - |
| RISK BY ARC | 3.7 | +74.6 | 303.0 | 135.0 | 4.0 | +41.2 | 331.0 | 78.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | 0.7 | -13.0 | 132.0 | 0.0 | 1.3 | -46.4 | 91.0 | 16.7 |
| RUN DOWN | 3.0 | -110.9 | 375.0 | 0.0 | 3.3 | -71.2 | 466.0 | 62.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +10.1 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.3 | 0.0 | 0.0 | 0.7 | +36.4 | 166.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +117.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -15.7 | 0.0 | 0.0 | 1.7 | -81.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +11.2 | 0.0 | 0.0 | 3.0 | +112.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 62.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +15.4 | 0.0 | 0.0 | 0.7 | +118.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -13.6 | 136.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.3 | -100.3 | 0.0 | 53.3 | 12.7 | -158.3 | 0.0 | 470.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 11.0 | +574.1 | 0.0 | 62.3 | 1.0 | +90.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +15.4 | 0.0 | 0.0 | 2.0 | +15.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -16.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 47.0 | 9.0 | +0.0 | 0.0 | 173.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -5.0 | 54.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 32.0 | +0.0 | 798.0 | 124.7 | 15.7 | +0.0 | 0.0 | 501.0 |
| STAY WORTH | 16.0 | +105.5 | 577.3 | 0.0 | 0.7 | +4.3 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +29.4 | 0.0 | 166.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.7 | +1105.3 | 0.0 | 47.0 | 9.0 | +569.6 | 0.0 | 153.3 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 78.7 |
| SUPPORT WORKED OUT | 7.7 | +1105.3 | 0.0 | 47.0 | 9.0 | +569.6 | 0.0 | 153.3 |
| SURE REACH TOGETHER | 1.0 | +4.5 | 0.0 | 0.0 | 1.3 | +17.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE FIGHT MOVES | 2.0 | +15.5 | 203.0 | 0.0 | 2.0 | +56.6 | 229.7 | 62.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 68.3 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 115.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.7 | +0.0 | 0.0 | 116.7 | 36.0 | +0.0 | 0.0 | 495.0 |
| TIED UP BY THE SUM | 3.7 | +431.4 | 351.7 | 135.0 | 1.7 | +193.6 | 137.0 | 0.0 |
| TIME ON OUR SIDE | 36.0 | +474.6 | 30.0 | 170.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 47.0 | 4.3 | +0.0 | 0.0 | 33.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -93.1 | 426.7 | 0.0 |
| WHO FIGHTS | 0.7 | -6.6 | 96.0 | 0.0 | 0.7 | +29.8 | 0.0 | 62.0 |
| WHO HITS BACK | 1.7 | +240.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +26.7 | 213.3 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -168.9 | 0.0 | 0.0 | 3.7 | -587.7 | 0.0 | 325.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +5.8 | 27.7 | 0.0 |
| WHOLE FIGHT REACTION | 2.7 | +289.0 | 78.7 | 216.0 | 2.3 | +102.4 | 0.0 | 266.7 |
| WOUNDS ON THE RANKS | 2.3 | +14.2 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 134.0 |

### Rule changes: chf-efd8067-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 133 | 133 | 82 | 27.33 | +245 | +3.0 |
| HOLDER ASSIGNMENT | 42 | 42 | 39 | 13.00 | +2323 | +59.6 |
| FIVE ACTION | 465 | 448 | 31 | 10.33 | +2323 | +74.9 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOT LIST | 117 | 114 | 24 | 8.00 | +207 | +8.6 |
| DEPLOY BY FIGURES | 38 | 38 | 23 | 7.67 | +208 | +9.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -886 | -38.5 |
| PROMISE BY ITS OWN SUM | 57 | 57 | 22 | 7.33 | -1673 | -76.0 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| SUPPORT ADDS | 50 | 48 | 21 | 7.00 | +1387 | +66.0 |
| SUPPORT WORKED OUT | 50 | 48 | 21 | 7.00 | +1387 | +66.0 |
| MOVE TO CHARGE COMPUTED | 50 | 43 | 20 | 6.67 | +1214 | +60.7 |
| HIS SHOTS BY HIS RUN | 136 | 127 | 15 | 5.00 | +611 | +40.7 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 33 | 32 | 15 | 5.00 | +1075 | +71.7 |
| NO CHAFF EDGES | 18 | 18 | 14 | 4.67 | +326 | +23.3 |
| TIED UP BY THE SUM | 16 | 15 | 13 | 4.33 | +470 | +36.2 |
| QUARTER ODDS | 121 | 116 | 12 | 4.00 | +1612 | +134.4 |
| FOUR ROUNDS | 27 | 24 | 11 | 3.67 | +658 | +59.8 |
| GOAL WALK | 42 | 42 | 10 | 3.33 | +488 | +48.8 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 8 | 2.67 | +423 | +52.9 |
| TIME ON OUR SIDE | 108 | 92 | 8 | 2.67 | +19 | +2.4 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 42 | 31 | 6 | 2.00 | +47 | +7.9 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +295 | +49.2 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 6 | 2.00 | +416 | +69.3 |
| RISK BY ARC | 23 | 21 | 6 | 2.00 | +205 | +34.1 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +80 | +15.9 |
| COVER ONCE | 46 | 28 | 5 | 1.67 | +110 | +22.1 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +215 | +43.1 |
| MAX FOR POSITIONING | 18 | 17 | 5 | 1.67 | +31 | +6.2 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 5 | 1.67 | +40 | +8.1 |
| SHOT RISK POINTS | 63 | 56 | 5 | 1.67 | +43 | +8.7 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +427 | +85.4 |
| BACKS UP THE FIGHT | 4 | 4 | 4 | 1.33 | +8 | +2.1 |
| CHARGE LOSSES | 58 | 54 | 4 | 1.33 | +178 | +44.5 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 7 | 6 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 3 | 1.00 | +88 | +29.4 |
| OPENS UP IN FULL | 7 | 7 | 3 | 1.00 | +46 | +15.2 |
| OVERRUNS AWAY | 7 | 6 | 3 | 1.00 | +100 | +33.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +73 | +24.3 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +771 | +257.1 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +125 | +41.6 |
| SET UP BY THE SET | 12 | 11 | 3 | 1.00 | +263 | +87.6 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 10 | 10 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 21 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 15 | 15 | 3 | 1.00 | +77 | +25.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +241 | +120.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 14 | 14 | 2 | 0.67 | -110 | -54.9 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 57 | 42 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +34 | +16.9 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +45 | +22.3 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -77 | -38.3 |
| NO DOUBLE ROUNDS | 23 | 21 | 2 | 0.67 | +14 | +7.0 |
| PROMISE KNOWS THE FIGHT | 8 | 7 | 2 | 0.67 | -40 | -20.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +42 | +21.2 |
| WHOLE FIGHT DANGER | 19 | 19 | 2 | 0.67 | +40 | +19.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +57 | +56.8 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -164 | -164.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -20 | -20.3 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.33 | +149 | +149.0 |
| EXACT ROUND | 15 | 14 | 1 | 0.33 | +0 | +0.1 |
| FEATURE BUFFS | 2 | 2 | 1 | 0.33 | +4 | +4.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +9 | +9.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| LOST AFTER ESCAPE | 12 | 11 | 1 | 0.33 | +5 | +5.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 42 | 25 | 1 | 0.33 | +47 | +46.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -18 | -17.6 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +5 | +5.2 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +30 | +30.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -7 | -7.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +203 | +203.3 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +80 | +80.4 |
| REDIRECT COUNTER | 12 | 12 | 1 | 0.33 | +94 | +93.5 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -7 | -6.7 |
| STAY WORTH | 50 | 43 | 1 | 0.33 | +1 | +0.7 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +88 | +88.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -28 | -27.9 |
| WOUNDS ON THE RANKS | 10 | 10 | 1 | 0.33 | +1 | +0.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 11 | 11 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 76 | 75 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 18 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 45 | 41 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 5 | 5 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 42 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 21 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 64 | 64 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 20 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 12 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 48 | 46 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 12 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 232 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 7 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 33 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 36 | 22 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 143 | 140 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE FIGHT MOVES | 12 | 11 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 224 | not checked | - | - | - | - |
| WAITS AGAIN | 20 | 18 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.00 | 5.00 | 63.8 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 3.00 | 76.0 |
| JOB FIRST | gate | 1.67 | 4.00 | 39.7 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 36.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 54.9 |
| MARCH OF THE TABLE | rule | - | 0.67 | 38.3 |
| NO REASON | gate | - | 0.67 | 91.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 20.0 |
| AFTERMATH BAND | gate | - | 0.33 | 2.5 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 164.1 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 20.3 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.2 |
| JOINT CHARGE NOW | rule | - | 0.33 | 31.1 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 9.5 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 17.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 7.2 |
| REFUSING RETIRES | rule | 0.33 | - | 6.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 14.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 27.9 |

### Plans: chf-efd8067-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 77% | 721 | 448 | 62% |
| Mine | move | 26.0 | 96% | 2287 | 0 | 0% |
| Mine | shoot | 7.3 | 73% | 612 | 775 | 127% |
| Opponent | charge | 4.0 | 58% | 423 | 339 | 80% |
| Opponent | join | 3.7 | 91% | 161 | 0 | 0% |
| Opponent | move | 30.3 | 88% | 1598 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 119 | 0 | 0% |
| Opponent | support | 0.7 | 50% | 13 | 0 | 0% |

### Battle groups: chf-efd8067-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 50% | 60% | 40% | 50% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 24 (3) | 24 | 0 | 0 | 0% | 3.0 | 24 (3) | - | - | 24 (3) | - |
| Mine | Chaff | 2 | 38 (2) | 0 | 38 | 100 | 0% | 1.5 | 75 (1) | 0 (1) | - | 75 (1) | 0 (1) |
| Mine | Character | 8 | 71 (8) | 71 | 0 | 38 | 12% | 3.1 | 78 (3) | 80 (4) | 0 (1) | 109 (5) | 0 (3) |
| Mine | Clean-up | 1 | 154 (1) | 0 | 154 | 0 | 100% | - | 154 (1) | - | - | 154 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 44 (4) | 44 | 0 | 0 | 25% | 1.7 | 58 (3) | 28 (1) | - | 58 (3) | 28 (1) |
| Mine | Hammer | 3 | 7 (3) | 7 | 0 | 0 | 33% | 1.0 | - | 7 (3) | - | 0 (1) | 9 (2) |
| Mine | Shooter | 6 | 55 (6) | 2 | 53 | 12 | 0% | 2.3 | 4 (2) | 99 (4) | - | 85 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 39 | 40% | 2.7 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 51 (10) | 51 | 0 | 34 | 30% | 3.3 | 128 (4) | 24 (4) | 0 (1) | 94 (7) | 22 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 16 (6) | 16 | 0 | 43 | 17% | 2.8 | 18 (3) | 14 (3) | - | 15 (4) | 20 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 54 | 40% | 2.7 | 59 (3) | 0 (2) | - | 46 (4) | 0 (1) |
| Opponent | Holder | 4 | 6 (4) | 0 | 6 | 83 | 25% | 4.7 | 0 (1) | 9 (3) | - | - | 6 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 44 | 33% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: chf-efd8067-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 286 | 974 | 8.0 | 1.0 | 122 | 0 | +122 | 2 of 8 | 8 of 8 | - | +122 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 205 | 2.0 | 1.5 | 102 | 0 | +102 | 0 of 2 | 2 of 2 | +205 | +0 |
| Mine | Lizardmen | 1 | 0 | 291 | 3.0 | 1.0 | 97 | 0 | +97 | 0 of 3 | 3 of 3 | - | +97 |
| **Mine** | all armies | 3 | 95 | 490 | 4.3 | 1.1 | 113 | 0 | +113 | 2 of 13 | 13 of 13 | +205 | +105 |
| Opponent | Vampire Counts | 1 | 0 | 1128 | 8.0 | 1.1 | 141 | 6 | +135 | 4 of 8 | 4 of 8 | +83 | +142 |
| Opponent | Warriors of Chaos | 2 | 0 | 94 | 0.5 | 1.0 | 187 | 0 | +187 | 0 of 1 | 1 of 1 | - | +187 |
| **Opponent** | all armies | 3 | 0 | 438 | 3.0 | 1.1 | 146 | 6 | +141 | 4 of 9 | 5 of 9 | +83 | +148 |

### Effective charges: chf-efd8067-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 0 | 0 | 1 (net +120) | 5 (net +171) | 2 | 0% (0 of 6) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 1 (net +205) | 0 | 1 | 0% (0 of 1) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 2 (net +146) | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 8 | 2 (net +202) | 1 (net +0) | 0 | 0 | 1 (net +83) | 2 (net +70) | 2 | 0% (0 of 6) |

### Charged fights, damage counted: chf-efd8067-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 344 | 171 | +171 | 179 | 0 | +179 | +51.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 414 | 108 | +154 | 170 | 46 | +123 | +29.9 |
| Mine | No odds | 4 | 320 | 128 | +0 | 17 | 0 | +17 | +5.3 |
| Mine | All fights | 13 | 358 | 138 | +113 | 126 | 14 | +112 | +31.2 |
| Opponent | Long shot (under 50%) | 2 | 328 | 402 | +202 | 202 | 0 | +202 | +61.6 |
| Opponent | 50-54% | 1 | 186 | 185 | +0 | 74 | 0 | +74 | +39.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 215 | 158 | +70 | 114 | 0 | +114 | +53.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 521 | 83 | +83 | 83 | 0 | +83 | +15.9 |
| Opponent | No odds | 3 | 242 | 205 | +212 | 277 | 39 | +239 | +98.6 |
| Opponent | All fights | 9 | 280 | 222 | +141 | 180 | 13 | +167 | +59.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p21 | move | 31 | 6 (19%) | 5 (16%) | 5 (16%) | 20 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

# Doctrine scorecard: chf-efd8067-p12

### Scorecard: chf-efd8067-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 3 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 8 | 3 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 109 |
| **Average** | | | Mine | 33% | 4.0 | 3.7 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 2.0 | 4.0 | 0.7 | 2.3 | 0.0 | 0.0 | 0.0 | 93.0 |

### KPIs: chf-efd8067-p12

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 83% (5 of 6); on the table 100% | 91% (10 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 100% | 75% (6 of 8); on the table 88% | 79% (11 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 100% (6 of 6) | 50% (3 of 6) | 75% (9 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (6 of 6) | 50% (3 of 6) | 75% (9 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 57% (4 of 7) | 62% (8 of 13) |
| Points that never fought | lower | 63% (3781 of 5998) | 50% (2986 of 5998) | 56% (6767 of 11996) |
|   infantry points that never fought | lower | 57% (511 of 902) | 67% (717 of 1072) | 62% (1228 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 81% (21 of 26) | 73% (33 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3142 of 5038) | 80% (4279 of 5360) | 71% (7421 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (100%) | 1.0 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.0 | 1.0 | 3.0 | 0.0 | 0.3 |
| not cast | 3.7 | 0.0 | 3.0 | 1.0 | 2.0 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.0 (100%) | 2.0 (100%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (9%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (82%) | - | 2.7 (89%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | - | 0% (0 of 3) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 27% (3 of 11) | 65% (24 of 37) | 56% (27 of 48) |
|   cavalry | 60% (3 of 5) | 78% (7 of 9) | 71% (10 of 14) |
|   character | 0% (0 of 6) | 38% (6 of 16) | 27% (6 of 22) |
|   infantry | - | 92% (11 of 12) | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (25%) | 2.0 (46%) | 2.7 (38%) |
| CHARGED: it charged | 1.3 (50%) | 0.7 (15%) | 2.0 (29%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (23%) | 1.0 (14%) |
| NO TARGET IN RANGE | 0.7 (25%) | 0.0 (0%) | 0.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |
| STUPIDITY | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.0 | 88% | 1.6 pts | 9 pts |
| character | 2.0 | 0.3 | 83% | 12.2 pts | 24 pts |
| infantry | 5.7 | 1.0 | 94% | 9.7 pts | 55 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 7.3 | 1.3 | 4.3 |
| Charges that made contact a game | 4.0 | 1.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 0.25 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.20 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.77 declared, 0.50 contact (22 units) | 0.17 declared, 0.13 contact (23 units) | 0.47 declared, 0.31 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (3 of 7) | 80% (4 of 5) | 0% (0 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (5 of 5) | 100% (3 of 3) | 100% (1 of 1) | 100% (9 of 9) |
| Character on its own | 50% (1 of 2) | - | 71% (5 of 7) | 67% (6 of 9) |
| Infantry | 71% (5 of 7) | 0% (0 of 1) | - | 62% (5 of 8) |
| Monster | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 80% (4 of 5); on the table 100% | 100% (6 of 6) | 67% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 86% (6 of 7); on the table 100% | 50% (3 of 6) | 58% | 76% (19 of 25) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 50% | - | 29% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 62% (5) | 64% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: chf-efd8067-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 45% (9 of 20) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 1) | 22% (2 of 9) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 1.3 | 0.0 |
| Movement | Idle units | 2.7 | 2.3 |
| Movement | Points that never moved of their own | 0.0 | 93.0 |
| Movement | Fights charged into per game | 3.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +577 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 1, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +46 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +0 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 54% (13 of 24) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | - | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 123.7 | 83.3 |
| Combat | Points run down | 254.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +123 | +70 |
| Combat | Net per 100 charger points, damage counted | +44.5 | +20.6 |
| Combat | First round won (charged fights) | 78% | 67% |
| Combat | Net points per charged fight | +120 | +73 |
| Combat | Net points per supported fight / lone fight | +64 / +136 | - / +73 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 0 of 3 |
| Game | Points lost | 241.7 | 420.0 |
| Game | VP from objectives | 456.7 | 580.0 |
| Game | Lone holders (player turns) | 4.0 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +55 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 662
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +31.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.0 | +233.6 | 0.0 | 338.0 | 23.0 | -91.6 | 0.0 | 373.7 |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 2.0 | +20.9 | 0.0 | 0.0 | 0.3 | +42.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.7 | +0.0 | 57.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +2.2 | 0.0 | 0.0 | 0.7 | +51.4 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +54.6 | 0.0 | 0.0 | 1.0 | +9.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.7 | +23.2 | 0.0 | 68.3 | 0.7 | +3.9 | 0.0 | 93.3 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | +3.3 | 68.3 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +50.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -213.7 | 0.0 | 430.7 | 6.0 | -195.1 | 0.0 | 180.7 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 127.7 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 17.3 | +0.0 | 0.0 | 107.7 | 12.7 | +0.0 | 0.0 | 190.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 1.0 | +0.0 | 30.3 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 6.3 | -473.0 | 0.0 | 107.7 | 7.0 | -228.3 | 0.0 | 90.3 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -1.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +76.7 | 0.0 | 0.0 | 7.3 | -20.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +5.8 | 65.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 5.0 | +12.0 | 240.7 | 15.0 | 0.3 | -3.4 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 6.0 | +21.0 | 333.3 | 15.0 | 1.3 | +11.5 | 78.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 22.3 | +271.3 | 0.0 | 225.3 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +9.3 | 0.0 | 0.0 | 2.0 | +15.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +8.0 | 95.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 85.7 | +3834.6 | 363.7 | 495.7 | 93.3 | +5714.0 | 159.7 | 612.0 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 10.0 | 9.3 | +0.0 | 0.0 | 215.7 |
| FOLLOW UP WEIGHED | 1.7 | +248.7 | 0.0 | 0.0 | 1.0 | +88.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 7.3 | +328.0 | 363.7 | 15.0 | 1.3 | +31.2 | 78.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -24.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -2.4 | 32.7 | 0.0 | 0.3 | -11.6 | 68.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -0.3 | 0.0 | 15.0 | - | - | - | - |
| GOAL WALK | 10.0 | +854.8 | 0.0 | 430.7 | 13.7 | +1702.3 | 0.0 | 190.0 |
| HALF WHEN STILL FLEEING | 2.3 | -7.4 | 173.0 | 15.0 | 1.0 | -0.8 | 68.3 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 57.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 215.3 | 5.3 | +0.0 | 0.0 | 180.7 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 0.0 | 19.0 | +0.0 | 0.0 | 60.7 |
| HIS RANDOM MOVER COMES | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.0 | +587.0 | 0.0 | 127.7 | 14.7 | +211.1 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 22.7 | +159.5 | 0.0 | 480.7 | 7.3 | +350.1 | 0.0 | 60.7 |
| HIS TURN DENIED | 1.0 | +5.1 | 0.0 | 15.0 | 0.3 | +7.2 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 215.3 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +827.4 | 0.0 | 107.7 | 10.0 | +948.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.0 | -172.5 | 248.3 | 0.0 | 1.3 | -35.3 | 78.3 | 0.0 |
| IDLE COST | 22.0 | -325.0 | 0.0 | 0.0 | - | - | - | - |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 2.7 | +107.6 | 205.7 | 15.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.3 | -4.0 | 0.0 | 15.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +18.4 | 0.0 | 0.0 | 1.0 | +19.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 195.3 | 136.7 | 5.3 | +0.0 | 0.0 | 1102.0 |
| LOST AFTER ESCAPE | 4.0 | +7.8 | 268.0 | 15.0 | 1.0 | +1.0 | 68.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -63.1 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 4.7 | +59.7 | 0.0 | 0.0 | 0.3 | +11.7 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +79.7 | 0.0 | 0.0 | 4.0 | +69.5 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +231.2 | 0.0 | 0.0 | 3.3 | +136.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +4.5 | 0.0 | 0.0 | 2.3 | +49.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +4.2 | 0.0 | 0.0 | 3.0 | +27.3 | 0.0 | 0.0 |
| MOVE ORDER | 3.3 | +0.0 | 107.7 | 107.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.3 | +483.4 | 0.0 | 0.0 | 7.3 | +755.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +328.2 | 0.0 | 0.0 | 7.3 | +335.9 | 0.0 | 32.7 |
| NEXT CHARGE BY LIST | 8.7 | +403.1 | 0.0 | 0.0 | 4.7 | +504.9 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.3 | +83.6 | 32.7 | 68.3 | 1.3 | +9.6 | 68.3 | 0.0 |
| NO DOUBLE ROUNDS | 5.0 | -144.4 | 248.3 | 0.0 | 1.0 | -43.3 | 78.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +18.6 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | -31.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -66.5 | 0.0 | 0.0 | 6.7 | -294.9 | 68.3 | 30.3 |
| ONE CHALLENGE TEST | 1.0 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -59.1 | 0.0 | 0.0 | 7.0 | -119.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.7 | +27.0 | 173.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | +3.7 | 0.0 | 107.7 | 5.0 | -18.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -12.0 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.3 | +83.4 | 30.3 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 2.7 | +104.4 | 63.0 | 0.0 | 0.7 | +7.1 | 68.3 | 0.0 |
| OVERRUNS AWAY | 2.0 | +12.7 | 30.3 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.3 | +10.8 | 0.0 | 0.0 | 0.3 | +45.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 43.7 | +219.2 | 345.0 | 266.7 | 44.3 | +139.3 | 159.7 | 587.0 |
| PRIZE BY WORTH | 0.7 | +40.8 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.0 | -123.1 | 0.0 | 0.0 | 14.0 | -926.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 7.7 | +712.9 | 0.0 | 45.0 | 8.3 | +684.8 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +34.2 | 0.0 | 0.0 | 2.3 | +5.7 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +337.1 | 0.0 | 25.0 | 3.0 | +117.9 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 10.0 | 3.0 | +0.0 | 0.0 | 9.0 |
| REDIRECT WEIGHED | 0.7 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.3 | -86.5 | 0.0 | 0.0 | 0.3 | -32.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 30.3 |
| RISK BY ARC | 4.0 | +130.9 | 95.7 | 0.0 | 1.0 | +5.3 | 78.3 | 0.0 |
| ROUNDS AFTER TERROR | 3.0 | -18.7 | 123.0 | 0.0 | 0.3 | -4.8 | 0.0 | 0.0 |
| RUN DOWN | 7.0 | -40.5 | 363.7 | 15.0 | 1.3 | -10.0 | 78.3 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.7 | -101.7 | 0.0 | 0.0 | 1.3 | -30.7 | 0.0 | 18.0 |
| SEARCH SPOT | 0.7 | +35.6 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +71.1 | 0.0 | 0.0 | 0.7 | +63.1 | 68.3 | 0.0 |
| SET CREDITED ONCE | 6.0 | -106.1 | 0.0 | 0.0 | 2.0 | -13.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 8.7 | +135.9 | 0.0 | 0.0 | 5.3 | -6.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 4.7 | +59.7 | 0.0 | 0.0 | 1.0 | +14.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 9.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 2.3 | +4.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 21.0 | -113.1 | 0.0 | 460.7 | 11.0 | +35.3 | 0.0 | 60.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.0 | +11.9 | 0.0 | 0.0 | 8.3 | +82.2 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 16.0 | +0.0 | 0.0 | 35.0 | 10.3 | +0.0 | 0.0 | 254.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| STANDS STILL | 14.0 | +0.0 | 0.0 | 0.0 | 44.0 | +0.0 | 81.3 | 65.3 |
| STAY WORTH | 0.7 | +2.3 | 0.0 | 0.0 | 9.7 | +30.9 | 81.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +1.8 | 15.0 | 57.7 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.3 | +103.5 | 0.0 | 107.7 | 8.0 | +691.3 | 0.0 | 65.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +103.5 | 0.0 | 107.7 | 8.0 | +691.3 | 0.0 | 65.3 |
| SURE REACH TOGETHER | 2.7 | +15.9 | 0.0 | 0.0 | 1.7 | +28.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.7 | +21.2 | 160.3 | 0.0 | 0.3 | +0.0 | 68.3 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 10.0 | 1.3 | +0.0 | 0.0 | 57.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 240.3 | 47.0 | +0.0 | 0.0 | 315.0 |
| TIED UP BY THE SUM | 3.0 | +454.9 | 65.3 | 0.0 | 0.7 | +118.5 | 68.3 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 67.7 | +641.8 | 0.0 | 371.3 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -22.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -7.4 | 115.3 | 0.0 | - | - | - | - |
| WHO GETS IN | 1.7 | -2.5 | 205.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +45.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -58.9 | 0.0 | 0.0 | 3.3 | -171.3 | 0.0 | 180.7 |
| WHOLE FIGHT GAIN | 1.3 | +23.2 | 173.0 | 15.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.0 | +31.1 | 0.0 | 10.0 | 2.7 | +371.9 | 15.0 | 57.7 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: chf-efd8067-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 129 | 129 | 86 | 28.67 | +806 | +9.4 |
| HOLDER ASSIGNMENT | 57 | 57 | 54 | 18.00 | +3695 | +68.4 |
| OFF BEST | 39 | 39 | 39 | 13.00 | -1084 | -27.8 |
| FIVE ACTION | 537 | 501 | 37 | 12.33 | +1966 | +53.1 |
| PROMISE BY ITS OWN SUM | 78 | 78 | 36 | 12.00 | -3148 | -87.4 |
| TIME ON OUR SIDE | 203 | 172 | 34 | 11.33 | +35 | +1.0 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +127 | +5.3 |
| HIS SHOT LIST | 161 | 144 | 21 | 7.00 | +45 | +2.1 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 71 | 71 | 15 | 5.00 | +1442 | +96.1 |
| HIS SHOTS BY HIS RUN | 90 | 84 | 15 | 5.00 | +125 | +8.4 |
| IDLE COST | 66 | 47 | 15 | 5.00 | +157 | +10.5 |
| FOUR ROUNDS | 26 | 24 | 12 | 4.00 | +401 | +33.4 |
| SET UP BY THE SET | 42 | 41 | 12 | 4.00 | +495 | +41.2 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +575 | +52.3 |
| MOVE TO CHARGE COMPUTED | 56 | 35 | 11 | 3.67 | +312 | +28.4 |
| SUPPORT ADDS | 37 | 34 | 11 | 3.67 | +397 | +36.1 |
| SUPPORT WORKED OUT | 37 | 34 | 11 | 3.67 | +397 | +36.1 |
| COVER ONCE | 40 | 32 | 10 | 3.33 | +72 | +7.2 |
| QUARTER ODDS | 48 | 42 | 9 | 3.00 | +546 | +60.7 |
| TIED UP BY THE SUM | 11 | 9 | 9 | 3.00 | +255 | +28.3 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1013 | +126.6 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +323 | +40.3 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 8 | 2.67 | +120 | +14.9 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +81 | +11.6 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1184 | +169.2 |
| MAX FOR POSITIONING | 26 | 22 | 7 | 2.33 | +13 | +1.8 |
| NEXT CHARGE BY LIST | 40 | 31 | 7 | 2.33 | +266 | +38.0 |
| NO CHAFF EDGES | 11 | 9 | 7 | 2.33 | +228 | +32.6 |
| SHOT RISK POINTS | 96 | 86 | 7 | 2.33 | +37 | +5.3 |
| SURE REACH TOGETHER | 13 | 12 | 7 | 2.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 17 | 17 | 7 | 2.33 | +214 | +30.6 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 2.00 | +1 | +0.1 |
| CHARGE NOW FIRST | 13 | 13 | 6 | 2.00 | -357 | -59.5 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +113 | +18.8 |
| RISK BY ARC | 15 | 13 | 6 | 2.00 | +171 | +28.5 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| OPENS UP IN FULL | 10 | 8 | 5 | 1.67 | +134 | +26.8 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +168 | +33.6 |
| WHO GETS IN | 5 | 5 | 5 | 1.67 | -8 | -1.5 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +15 | +3.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 67 | 51 | 4 | 1.33 | +7 | +1.8 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| REFUSING RETIRES | 5 | 5 | 4 | 1.33 | -14 | -3.6 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +403 | +100.7 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HONEST WORTH | 22 | 20 | 3 | 1.00 | +103 | +34.3 |
| NEARER NOT NEEDED | 46 | 43 | 3 | 1.00 | +112 | +37.4 |
| OPENS UP | 4 | 4 | 3 | 1.00 | +101 | +33.6 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +107 | +35.8 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 55 | 48 | 2 | 0.67 | +20 | +10.1 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -36 | -18.0 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +122 | +61.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +49 | +24.5 |
| SET CREDITED ONCE | 24 | 23 | 2 | 0.67 | +7 | +3.5 |
| SET UP TOGETHER | 17 | 14 | 2 | 0.67 | +13 | +6.5 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +6 | +2.8 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -14 | -6.9 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +128 | +64.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +93 | +92.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.9 |
| BACKS UP THE FIGHT | 7 | 4 | 1 | 0.33 | +126 | +125.5 |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +151 | +151.4 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 15 | 13 | 1 | 0.33 | +1 | +0.6 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +53 | +53.3 |
| ONE FIGHT FORMULA | 35 | 10 | 1 | 0.33 | +32 | +32.3 |
| ONE JOINT FIGURE | 5 | 5 | 1 | 0.33 | +22 | +22.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| REDIRECT COUNTER | 22 | 18 | 1 | 0.33 | +60 | +59.9 |
| RUN DOWN | 25 | 23 | 1 | 0.33 | +27 | +27.1 |
| SCOUT BY DROPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 28 | 24 | 1 | 0.33 | +24 | +24.1 |
| THE FIGHT MOVES | 9 | 8 | 1 | 0.33 | +10 | +9.8 |
| THE ROW IN ITS ORDER | 35 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +41 | +41.4 |
| WHOLE FIGHT REACTION | 11 | 11 | 1 | 0.33 | +28 | +28.2 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CHALLENGE IN THE FIGHT | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 90 | 89 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 16 | 16 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 20 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 10 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 93 | 89 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 14 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 101 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 15 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 16 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 28 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 20 | 6 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 17 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 79 | 69 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 174 | 160 | 0 | 0.00 | - | - |
| STAY WORTH | 31 | 23 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 263 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 11 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 8.00 | 87.4 |
| JOB FIRST | gate | 5.67 | 5.00 | 24.9 |
| ARMY TABLE | rule | 3.33 | 3.67 | 77.9 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 59.5 |
| REFUSING RETIRES | rule | 0.67 | 0.67 | 3.6 |
| JOINT CHARGE NOW | rule | 1.00 | - | 27.9 |
| NO REASON | gate | - | 1.00 | 40.0 |
| WHO GETS IN | rule | 1.00 | - | 27.9 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 10.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 18.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 12.3 |
| SUPPORT NARROWED | rule | 0.67 | - | 6.9 |
| FALLBACK | gate | - | 0.33 | 83.3 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 21.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 2.7 |
| SET UP BY THE SET | rule | 0.33 | - | 1.1 |
| TURN GATE | gate | - | 0.33 | 58.3 |

### Plans: chf-efd8067-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 38% | 473 | 219 | 46% |
| Mine | join | 2.0 | 100% | 75 | 0 | 0% |
| Mine | move | 35.7 | 97% | 1316 | 0 | 0% |
| Mine | support | 1.7 | 100% | 0 | 0 | 0% |
| Opponent | charge | 1.0 | 100% | 71 | 99 | 138% |
| Opponent | join | 2.7 | 100% | 139 | 0 | 0% |
| Opponent | move | 37.3 | 98% | 1880 | 0 | 0% |
| Opponent | shoot | 2.0 | 17% | 151 | 41 | 27% |
| Opponent | support | 1.3 | 75% | 0 | 0 | - |

### Battle groups: chf-efd8067-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 23% | 33% | 67% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 44% | 75% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 61 (9) | 33 | 29 | 14 | 67% | 5.3 | 70 (4) | 0 (3) | 111 (2) | 77 (7) | 0 (2) |
| Mine | Character | 9 | 4 (9) | 4 | 0 | 0 | 44% | 5.0 | 0 (2) | 6 (6) | 0 (1) | 8 (4) | 0 (5) |
| Mine | Clean-up | 3 | 205 (3) | 174 | 30 | 25 | 0% | 2.7 | - | 153 (1) | 236 (2) | 141 (2) | 310 (1) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 4 | 23 (4) | 9 | 13 | 18 | 75% | 3.0 | 0 (1) | 44 (2) | 0 (1) | 39 (1) | 14 (3) |
| Mine | Hammer | 2 | 6 (2) | 0 | 6 | 66 | 100% | - | - | 6 (2) | - | 0 (1) | 9 (1) |
| Mine | Holder | 1 | 282 (1) | 0 | 282 | 0 | 0% | 4.0 | 282 (1) | - | - | 282 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.7 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 218 (3) | 0 | 218 | 22 | 67% | 6.0 | 0 (1) | 386 (1) | 0 (1) | 218 (3) | - |
| Opponent | Character | 10 | 9 (10) | 9 | 0 | 16 | 50% | 2.4 | 15 (6) | 0 (4) | - | 0 (5) | 15 (5) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 38 (5) | 0 | 38 | 44 | 80% | 1.0 | 0 (3) | - | 86 (2) | 84 (3) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 11 (6) | 0 | 11 | 33 | 0% | 4.0 | - | 14 (4) | 0 (2) | 0 (3) | 24 (3) |
| Opponent | Holder | 6 | 21 (6) | 0 | 21 | 15 | 67% | 1.5 | 24 (2) | 84 (1) | - | 84 (1) | 24 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: chf-efd8067-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 518 | 3.0 | 1.5 | 172 | 8 | +165 | 3 of 6 | 4 of 6 | +64 | +216 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 3.0 | 1.0 | 30 | 0 | +30 | 0 of 3 | 3 of 3 | - | +30 |
| **Mine** | all armies | 3 | 0 | 375 | 3.0 | 1.3 | 125 | 5 | +120 | 3 of 9 | 7 of 9 | +64 | +136 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 327 | 3.0 | 1.0 | 109 | 36 | +73 | 0 of 3 | 2 of 3 | - | +73 |
| **Opponent** | all armies | 3 | 0 | 109 | 1.0 | 1.0 | 109 | 36 | +73 | 0 of 3 | 2 of 3 | - | +73 |

### Effective charges: chf-efd8067-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 6 | 1 (net +577) | 0 | 0 | 2 (net +64) | 0 | 1 (net +0) | 2 | 0% (0 of 4) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 2 (net +46) | 0 | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |

### Charged fights, damage counted: chf-efd8067-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 186 | 479 | +577 | 577 | 0 | +577 | +310.2 |
| Mine | 76-89% | 3 | 150 | 159 | +43 | 76 | 29 | +47 | +31.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 186 | 285 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 494 | 91 | +46 | 68 | 27 | +41 | +8.3 |
| Mine | No odds | 2 | 333 | 144 | +142 | 181 | 30 | +151 | +45.4 |
| Mine | All fights | 9 | 275 | 190 | +120 | 145 | 22 | +123 | +44.5 |
| Opponent | Effective (55-75%) | 1 | 27 | 85 | +0 | 0 | 9 | -9 | -33.3 |
| Opponent | No odds | 2 | 500 | 164 | +110 | 164 | 54 | +110 | +22.0 |
| Opponent | All fights | 3 | 342 | 137 | +73 | 109 | 39 | +70 | +20.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p12 | move | 19 | 5 (26%) | 3 (16%) | 4 (21%) | 10 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

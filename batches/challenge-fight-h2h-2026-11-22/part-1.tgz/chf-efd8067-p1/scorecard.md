# Doctrine scorecard: chf-efd8067-p1

### Scorecard: chf-efd8067-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 9 | 5 | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | yes | 2 | 6 | 4 | 2 | 0 | 0 | 0 | 117 |
| L0135 | 3 | 1 | Mine | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.7 | 5.0 | 0.0 | 2.0 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 33% | 0.7 | 4.0 | 2.3 | 4.3 | 0.0 | 0.0 | 0.0 | 95.7 |

### KPIs: chf-efd8067-p1

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 15) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 50% (2 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 39% (35 of 90) | 29% (7 of 24) | 37% (42 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (35 of 88) | 29% (7 of 24) | 38% (42 of 112) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (3 of 4) | 75% (3 of 4) |
| Points that never fought | lower | 81% (4602 of 5700) | 86% (5077 of 5899) | 83% (9679 of 11599) |
|   infantry points that never fought | lower | 79% (2124 of 2703) | 100% (1219 of 1219) | 85% (3343 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (10 of 15) | 64% (16 of 25) | 65% (26 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.3 uses a game | 75% (3 of 4); 4.0 uses a game | 86% (6 of 7); 4.2 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (5 of 5); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2656 of 4077) | 60% (2938 of 4883) | 62% (5594 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 14.0 (76%) | 5.3 (94%) | 19.3 (81%) |
| MARCHED: its unit marched | 3.0 (16%) | 0.3 (6%) | 3.3 (14%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 11.7 | 3.0 | 10.0 | 14.0 | 0.3 |
| not cast | 6.3 | 7.0 | 6.0 | 24.0 | 43.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (48%) | 1.0 (17%) | 19.3 (81%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (89%) | 3.7 (52%) | 5.0 (83%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 43.3 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.3 a game | 2.3 a game | 5.3 a game |
| stood (cast and not dispelled) | 60% (15 of 25) | 29% (2 of 7) | 53% (17 of 32) |
| the unit moved after it | 87% (13 of 15) | 0% (0 of 2) | 76% (13 of 17) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 2) | 6% (1 of 17) |
| it fought by the end of its next turn | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| none of these (no charge, no fight, no charge escaped) | 93% (14 of 15) | 100% (2 of 2) | 94% (16 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (18 of 30) | 60% (50 of 84) | 60% (68 of 114) |
|   cavalry | - | 67% (12 of 18) | 67% (12 of 18) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | - | 83% (10 of 12) | 83% (10 of 12) |
|   infantry | 60% (18 of 30) | 30% (9 of 30) | 45% (27 of 60) |
|   monster | - | 100% (12 of 12) | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (67%) | 3.3 (29%) | 6.0 (39%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |
| FLEEING: it fled or was fleeing | 0.3 (8%) | 0.7 (6%) | 1.0 (7%) |
| NO TARGET IN RANGE | 1.0 (25%) | 5.7 (50%) | 6.7 (43%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 3.3 | 53% | 5.4 pts | 27 pts |
| character | 2.3 | 2.7 | 57% | 9.1 pts | 21 pts |
| chariot | 3.3 | 7.3 | 40% | 16.4 pts | 55 pts |
| infantry | 9.7 | 4.3 | 76% | 6.0 pts | 58 pts |
| monster | 4.0 | 1.7 | 75% | 3.1 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 2.7 | 1.5 |
| Charges that made contact a game | 0.0 | 1.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.07 declared, 0.00 contact (15 units) | 0.23 declared, 0.13 contact (31 units) | 0.17 declared, 0.09 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | - | - | 33% (1 of 3) |
| Character in a unit | 80% (4 of 5) | 89% (8 of 9) | - | 86% (12 of 14) |
| Character on its own | - | 100% (2 of 2) | 0% (0 of 1) | 67% (2 of 3) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 60% (3 of 5) | 43% (3 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (1 of 2); on the table 100% | 39% (42 of 108) | 83% | 67% (14 of 21) | 100% (5 of 5); 5.5 uses a game | 67% (2 of 3); 0.5 uses a game | 100% (5 of 5); 1.2 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | - | 72% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 95% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | - | 50% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 17% (3 of 18) | 38% (9 of 24) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 86% (6 of 7) |
| Strategy | Joined characters whose unit fought | 17% (3 of 18) | 0% (0 of 6) |
| Strategy | Lone characters that fought | - | 0% (0 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 4.3 |
| Movement | Points that never moved of their own | 36.7 | 95.7 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 2 of 4, net -24 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 4, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 4, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | 16.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (11 of 20) | 38% (19 of 50) |
| Shooting | Points destroyed by shooting units | 0.0 | 44.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 8.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (6 of 24) | 80% (4 of 5) |
| Magic | Wounds caused by magic missiles | 17.7 | 5.7 |
| Magic | Points destroyed by magic (all spells) | 186.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.3 / 0.7 / 0.3 / 0.0 | 2.3 / 2.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 34.0 | 40.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +73 |
| Combat | Net per 100 charger points, damage counted | - | +56.3 |
| Combat | First round won (charged fights) | - | 40% |
| Combat | Net points per charged fight | - | +19 |
| Combat | Net points per supported fight / lone fight | - / - | - / +19 |
| Combat | Charged fights on a top-3 enemy unit | - | 1 of 5 |
| Game | Points lost | 174.7 | 237.3 |
| Game | VP from objectives | 776.7 | 916.7 |
| Game | Lone holders (player turns) | 4.7 | 0.7 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -59 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 412
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 9.7 | +376.8 | 0.0 | 87.3 | 21.0 | -31.2 | 0.0 | 41.7 |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +13.6 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -9.1 | 25.7 | 0.0 |
| CAST JOB | - | - | - | - | 2.7 | +16.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 4.3 | +343.8 | 68.0 | 0.0 | 1.3 | +23.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +45.1 | 0.0 | 62.3 | 1.7 | +33.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.9 | 0.0 | 25.7 | - | - | - | - |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -0.9 | 25.7 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.7 | -15.7 | 0.0 | 68.0 |
| CHARGE LOSSES | 15.7 | -311.5 | 0.0 | 43.3 | 13.3 | -367.6 | 0.0 | 209.3 |
| CHARGE NOW FIRST | - | - | - | - | 1.3 | +0.0 | 61.7 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 124.3 | 14.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 6.0 | +2017.2 | 0.0 | 0.0 | 2.3 | +96.1 | 0.0 | 0.0 |
| COVER ONCE | 2.7 | -63.9 | 0.0 | 21.7 | 5.0 | -129.7 | 0.0 | 41.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -3.8 | 21.7 | 68.0 |
| DEPLOY BY FIGURES | 6.0 | +24.3 | 0.0 | 0.0 | 9.3 | -119.9 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +9.4 | 21.7 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | -0.0 | 40.0 | 34.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.0 | +0.0 | 44.0 | 34.0 |
| FALLS SHORT | 4.3 | +97.5 | 0.0 | 18.3 | 21.3 | +247.0 | 0.0 | 118.0 |
| FEATURE BUFFS | 14.7 | +379.6 | 0.0 | 138.3 | 1.0 | +34.4 | 0.0 | 0.0 |
| FIGHT LIFT | 0.3 | +1.2 | 34.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.0 | -0.6 | 18.3 | 68.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 55.0 | +8990.1 | 151.3 | 392.7 | 117.0 | +5027.1 | 388.7 | 584.7 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 2.0 | +8.8 | 87.3 | 68.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -10.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.6 | 0.0 | 18.3 | - | - | - | - |
| GOAL WALK | 3.7 | +1208.5 | 0.0 | 0.0 | 2.7 | +94.8 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 3.3 | +36.5 | 94.7 | 0.0 |
| HALF WHEN STILL FLEEING | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 41.7 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 34.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 43.3 | 9.0 | +0.0 | 0.0 | 174.7 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 36.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -34.5 | 0.0 | 0.0 | 6.0 | -110.3 | 0.0 | 92.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 94.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 36.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.3 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 28.7 | +484.5 | 0.0 | 241.0 | 50.0 | +2541.3 | 0.0 | 280.7 |
| HIS SHOTS BY HIS RUN | 30.7 | +413.4 | 0.0 | 219.3 | 55.7 | +1731.5 | 0.0 | 433.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +28.1 | 21.7 | 68.0 |
| HOLD ODDS | 36.7 | +0.0 | 0.0 | 320.0 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.7 | +1786.0 | 0.0 | 83.3 | 14.0 | +1207.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 2.0 | -46.2 | 87.3 | 68.0 |
| IDLE COST | 3.0 | -104.7 | 0.0 | 0.0 | 20.7 | -183.2 | 0.0 | 177.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -11.4 | 18.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 117.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.7 | +0.4 | 40.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +3.1 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +18.7 | 0.0 | 0.0 | 1.7 | -1.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +27.6 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +95.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -14.1 | 0.0 | 0.0 | 0.7 | -88.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +3.0 | 0.0 | 0.0 | 1.0 | +2.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +271.9 | 0.0 | 0.0 | 8.0 | +263.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.7 | +968.1 | 0.0 | 0.0 | 6.0 | +88.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.7 | +463.3 | 0.0 | 0.0 | 6.7 | +74.7 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 3.0 | -66.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 21.7 | 1.7 | +0.0 | 0.0 | 17.3 |
| MOVE SPELL IN RANGE | - | - | - | - | 2.0 | +175.6 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -158.5 | 0.0 | 0.0 | 2.0 | -79.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.7 | +198.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +401.2 | 0.0 | 21.7 | 5.7 | +273.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 5.3 | +220.2 | 69.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -7.8 | 18.3 | 0.0 |
| NO CHAFF EDGES | 1.3 | +11.9 | 0.0 | 51.3 | 2.7 | +101.6 | 87.3 | 34.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.0 | -21.7 | 87.3 | 68.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.0 | -5.9 | 0.0 | 0.0 | 1.3 | -1.6 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -60.0 | 0.0 | 18.3 | 5.0 | -127.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -31.1 | 0.0 | 40.0 | 4.3 | -68.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -12.9 | 18.3 | 34.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +269.5 | 0.0 | 83.3 | 4.3 | +15.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -28.2 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +2.1 | 83.3 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +36.3 | 21.7 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 0.3 | +36.3 | 21.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +1.1 | 18.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -24.9 | 0.0 | 17.3 |
| PLAN RESULT | 24.0 | +61.8 | 98.3 | 276.3 | 52.7 | +155.2 | 229.0 | 433.0 |
| PROMISE BY ITS OWN SUM | 0.3 | +0.0 | 0.0 | 0.0 | 8.0 | -164.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | -0.9 | 0.0 | 0.0 |
| QUARTER ODDS | 8.3 | +1385.5 | 41.7 | 181.3 | 22.3 | +2040.5 | 196.3 | 106.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.3 | +60.0 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +14.9 | 0.0 | 18.3 | - | - | - | - |
| REDIRECT COUNTER | 1.7 | -42.9 | 0.0 | 25.7 | 2.7 | +92.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +19.3 | 0.0 | 18.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.7 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -12.4 | 40.0 | 68.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.3 | -6.4 | 87.3 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -1.2 | 25.7 | 0.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +9.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -69.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +99.7 | 0.0 | 0.0 | 1.0 | +21.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -1.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -0.3 | 0.0 | 18.3 | 1.3 | +0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +3.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 43.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +253.5 | 83.3 | 0.0 | 1.3 | +16.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.7 | 21.7 | 0.0 |
| SHOT RISK POINTS | 26.3 | -269.5 | 0.0 | 211.3 | 51.7 | +485.8 | 0.0 | 433.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.0 | +108.4 | 0.0 | 108.3 | 16.0 | +153.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 1.0 | +483.7 | 0.0 | 0.0 | 0.3 | +58.0 | 0.0 | 0.0 |
| SPELL WORTH | 2.3 | +11.1 | 34.0 | 0.0 | 2.7 | +38.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 47.3 | 5.7 | +0.0 | 0.0 | 70.3 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -3.9 | 43.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 7.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 20.7 | +0.0 | 151.3 | 196.3 | 51.7 | +0.0 | 301.3 | 258.0 |
| STAY WORTH | 11.7 | +123.6 | 68.0 | 195.0 | 24.3 | +104.9 | 254.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.1 | 0.0 | 34.0 |
| STRONG ENOUGH TO HOLD | 1.0 | -13.6 | 0.0 | 0.0 | 1.3 | -0.9 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.7 | -3.7 | 0.0 | 68.0 |
| SURE REACH TOGETHER | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.7 | +0.4 | 40.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 53.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 17.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 26.7 | +0.0 | 0.0 | 196.3 | 57.0 | +0.0 | 0.0 | 230.0 |
| TIME ON OUR SIDE | 22.0 | +469.1 | 0.0 | 124.0 | 26.7 | +214.8 | 43.3 | 0.0 |
| WAITS AGAIN | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -65.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.4 | 18.3 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +87.4 | 68.0 | 65.7 | 0.3 | +4.7 | 0.0 | 17.3 |
| WOUNDS ON THE RANKS | 8.3 | +318.5 | 0.0 | 0.0 | 1.3 | +65.5 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 236 | 233 | 88 | 29.33 | +1359 | +15.4 |
| HOLDER ASSIGNMENT | 86 | 86 | 81 | 27.00 | +4183 | +51.6 |
| HIS SHOTS BY HIS RUN | 259 | 256 | 80 | 26.67 | +942 | +11.8 |
| ARMY TABLE | 92 | 92 | 68 | 22.67 | +975 | +14.3 |
| SHOT RISK POINTS | 234 | 234 | 66 | 22.00 | +2209 | +33.5 |
| HARD STAY DROPPED | 30 | 30 | 30 | 10.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 46 | 46 | 27 | 9.00 | +317 | +11.7 |
| FIVE ACTION | 516 | 505 | 27 | 9.00 | +1186 | +43.9 |
| TIME ON OUR SIDE | 146 | 127 | 27 | 9.00 | +174 | +6.5 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -562 | -24.4 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| MEETS IN TIME | 33 | 33 | 18 | 6.00 | +281 | +15.6 |
| CASTING BLOCK | 17 | 17 | 17 | 5.67 | +300 | +17.7 |
| QUARTER ODDS | 92 | 91 | 15 | 5.00 | +1829 | +122.0 |
| NEXT CHARGE BY LIST | 16 | 15 | 13 | 4.33 | +261 | +20.1 |
| MOVE TO CHARGE COMPUTED | 14 | 13 | 12 | 4.00 | +235 | +19.6 |
| NO CHAFF EDGES | 12 | 12 | 12 | 4.00 | +340 | +28.4 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 12 | 4.00 | -493 | -41.1 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 10 | 10 | 10 | 3.33 | +764 | +76.4 |
| STAY WORTH | 108 | 90 | 10 | 3.33 | +66 | +6.6 |
| GOAL WALK | 19 | 19 | 9 | 3.00 | +726 | +80.6 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 71 | 57 | 7 | 2.33 | +155 | +22.2 |
| MISSILES IN THE MOVE | 41 | 30 | 7 | 2.33 | +1178 | +168.3 |
| CAST JOB | 8 | 8 | 6 | 2.00 | +1 | +0.1 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FEATURE BUFFS | 47 | 47 | 6 | 2.00 | +50 | +8.3 |
| SCOUTS HUNT GUNS ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 6 | 2.00 | +354 | +58.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 6 | 5 | 1.67 | +43 | +8.5 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 29 | 29 | 5 | 1.67 | +184 | +36.8 |
| FALLS SHORT | 77 | 65 | 4 | 1.33 | +192 | +48.0 |
| ONE OBJECTIVE FORMULA | 36 | 26 | 4 | 1.33 | +296 | +74.0 |
| SCOUT BY DROPS | 7 | 7 | 4 | 1.33 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 3 | 1.00 | +83 | +27.5 |
| MARCH CHECK | 4 | 3 | 3 | 1.00 | +130 | +43.5 |
| RANDOM MOVE BY FIGURES | 4 | 4 | 3 | 1.00 | +180 | +60.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +362 | +120.7 |
| SET UP BY THE SET | 5 | 5 | 3 | 1.00 | +4 | +1.3 |
| SHOTS IN THE MOVE | 66 | 46 | 3 | 1.00 | +28 | +9.5 |
| THE ROW IN ITS ORDER | 12 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LOSSES | 87 | 87 | 2 | 0.67 | +70 | +34.9 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -96 | -48.0 |
| COVER ONCE | 23 | 14 | 2 | 0.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 5 | 5 | 2 | 0.67 | +2 | +1.2 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +16 | +8.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +91 | +45.6 |
| MAX FOR POSITIONING | 5 | 5 | 2 | 0.67 | +2 | +0.9 |
| NEARER NOT NEEDED | 42 | 40 | 2 | 0.67 | +88 | +44.2 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -85 | -42.3 |
| RESERVE MOVE SPELL | 2 | 2 | 2 | 0.67 | +26 | +13.1 |
| SHOTS AFTER THE MOVES | 11 | 11 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 1 | 1 | 1 | 0.33 | +8 | +8.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -27 | -27.3 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +49 | +48.9 |
| FOUR ROUNDS | 6 | 5 | 1 | 0.33 | +10 | +10.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -1.9 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -34 | -34.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +55 | +55.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -6 | -6.1 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.33 | +82 | +82.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| OPENS A LANE | 3 | 1 | 1 | 0.33 | +1 | +1.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -75 | -74.6 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -3 | -2.6 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +2 | +1.8 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +10 | +10.4 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | not checked | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 65 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 18 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 1 | 1 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 9 | 9 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 33 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 166 | 165 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 17 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 32 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 9 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 230 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 13 | 7 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 23 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 217 | 209 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 7 | 7 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 4.33 | 27.1 |
| PROMISE BY ITS OWN SUM | rule | - | 4.00 | 41.1 |
| ARMY TABLE | rule | 0.67 | 3.00 | 41.1 |
| HOLDER ASSIGNMENT | rule | 1.67 | 2.00 | 15.9 |
| MAIN BODY KEEPS ITS BAND | rule | 0.67 | 0.33 | 26.7 |
| CHARGE NOW FIRST | rule | - | 0.67 | 48.0 |
| NO REASON | gate | - | 0.67 | 8.8 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 42.3 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 27.3 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 1.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.2 |
| MARCH OF THE TABLE | rule | - | 0.33 | 6.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 74.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 2.6 |
| REFUSING RETIRES | rule | - | 0.33 | 2.4 |
| SET UP BY THE SET | rule | - | 0.33 | 1.3 |

### Plans: chf-efd8067-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 18.7 | 93% | 2605 | 0 | 0% |
| Mine | shoot | 5.0 | 20% | 936 | 62 | 7% |
| Mine | support | 0.3 | 0% | 19 | 0 | 0% |
| Opponent | charge | 1.0 | 33% | 8 | 18 | 221% |
| Opponent | move | 45.0 | 94% | 1537 | 0 | 0% |
| Opponent | shoot | 5.7 | 47% | 339 | 137 | 40% |
| Opponent | support | 1.0 | 100% | 4 | 0 | 0% |

### Battle groups: chf-efd8067-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 0% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Mine | Character | 18 | 21 (18) | 21 | 0 | 0 | 22% | 2.0 | 61 (3) | 23 (6) | 6 (9) | 35 (6) | 14 (12) |
| Mine | Hammer | 6 | 30 (6) | 2 | 28 | 0 | 83% | 3.0 | 126 (1) | 9 (2) | 13 (3) | 62 (2) | 14 (4) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 67 | 67% | 4.0 | 156 (1) | 39 (1) | 0 (1) | 156 (1) | 19 (2) |
| Mine | Shooter | 6 | 100 (6) | 0 | 100 | 67 | 0% | 1.8 | 231 (2) | 35 (4) | - | 120 (5) | 0 (1) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 13 | 50% | 3.0 | 0 (2) | 261 (4) | - | 202 (5) | 0 (1) |
| Opponent | Character | 8 | 3 (8) | 3 | 0 | 0 | 25% | 2.5 | 8 (2) | 0 (6) | - | 5 (5) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 43 (7) | 9 | 34 | 26 | 71% | 1.0 | 84 (4) | 0 (1) | 0 (2) | 61 (5) | 0 (2) |
| Opponent | Hammer | 13 | 38 (13) | 12 | 27 | 23 | 38% | 1.9 | - | 37 (7) | 40 (6) | 53 (7) | 9 (6) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 3 | 71 (3) | 21 | 49 | 0 | 0% | 1.7 | 89 (2) | 27 (1) | - | 89 (2) | 27 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: chf-efd8067-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 186 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 0 | 197 | 4.0 | 1.0 | 49 | 0 | +49 | 0 of 4 | 2 of 4 | - | +49 |
| Opponent | Wood Elf Realms | 1 | 132 | 0 | 1.0 | 1.0 | 0 | 102 | -102 | 1 of 1 | 0 of 1 | - | -102 |
| **Opponent** | all armies | 3 | 44 | 66 | 1.7 | 1.0 | 39 | 20 | +19 | 1 of 5 | 2 of 5 | - | +19 |

### Effective charges: chf-efd8067-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Ogre Kingdoms | 4 | 1 (net +55) | 0 | 0 | 0 | 1 (net +77) | 1 (net +65) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 1 | 1 (net -102) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 2 | 68 | 446 | -24 | 181 | 108 | +73 | +107.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 185 | 65 | +65 | 65 | 0 | +65 | +35.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 297 | 77 | +77 | 77 | 16 | +60 | +20.4 |
| Opponent | No odds | 1 | 34 | 77 | +0 | 121 | 26 | +95 | +280.1 |
| Opponent | All fights | 5 | 130 | 222 | +19 | 125 | 52 | +73 | +56.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p1 | move | 11 | 2 (18%) | 2 (18%) | 0 (0%) | 9 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

# Doctrine scorecard: chf-efd8067-p42

### Scorecard: chf-efd8067-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 8 | - | 3 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 662 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 5 | 0 | 0 | 0 | 251 |
| L1026 | 6 | 1 | Mine | no | 10 | 2 | 1 | 0 | 1 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.7 | 2.0 | 0.3 | 0.3 | 0.7 | 0.0 | 0.0 | 400.7 |
| **Average** | | | Opponent | 0% | 2.7 | 3.0 | 3.7 | 3.3 | 0.3 | 0.0 | 0.0 | 161.7 |

### KPIs: chf-efd8067-p42

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 77% (10 of 13) | 0% (0 of 13) | 38% (10 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 0% (0 of 1); on the table 0% | 60% (3 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 31% (15 of 48) | 0% (0 of 12) | 25% (15 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (15 of 35) | 0% (0 of 10) | 33% (15 of 45) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 50% (3015 of 5997) | 74% (4428 of 5998) | 62% (7443 of 11995) |
|   infantry points that never fought | lower | 33% (521 of 1591) | 90% (1027 of 1147) | 57% (1548 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (22 of 34) | 50% (10 of 20) | 59% (32 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 0.3 uses a game | 100% (1 of 1); 1.7 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3590 of 5667) | 46% (2361 of 5186) | 55% (5951 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (45%) | 0.3 (8%) | 5.3 (36%) |
| MARCHED: its unit marched | 1.0 (9%) | 1.0 (25%) | 2.0 (13%) |
| CHARGED: its unit charged | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 1.7 (15%) | 0.7 (17%) | 2.3 (16%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| GONE: slain | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (42%) | 1.7 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 5.0 | 0.7 | 1.7 |
| not cast | 2.0 | 5.0 | 15.0 | 3.3 | 14.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (27%) | 5.3 (36%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (13%) | 0.3 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.3 (16%) | 0.3 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (40%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.7 (13%) | 1.3 (9%) | 0.7 (20%) | 1.7 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (13%) | 1.3 (9%) | 0.7 (20%) | 1.7 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.3 (72%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (81 of 125) | 59% (41 of 69) | 63% (122 of 194) |
|   cavalry | - | 83% (10 of 12) | 83% (10 of 12) |
|   character | 100% (8 of 8) | 50% (9 of 18) | 65% (17 of 26) |
|   chariot | 76% (13 of 17) | 100% (2 of 2) | 79% (15 of 19) |
|   infantry | 53% (26 of 49) | 47% (14 of 30) | 51% (40 of 79) |
|   monster | 60% (6 of 10) | 86% (6 of 7) | 71% (12 of 17) |
|   war machine | 68% (28 of 41) | - | 68% (28 of 41) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (11%) | 5.0 (54%) | 6.7 (28%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (7%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 2.3 (16%) | 0.3 (4%) | 2.7 (11%) |
| MOVED: a war machine that moved | 1.3 (9%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET IN RANGE | 2.3 (16%) | 2.3 (25%) | 4.7 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.0 (34%) | 1.0 (11%) | 6.0 (25%) |
| SHELTERED: the target was sheltered | 1.0 (7%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 0.7 | 90% | 0.8 pts | 5 pts |
| character | 6.0 | 1.3 | 78% | 2.5 pts | 15 pts |
| chariot | 5.0 | 2.7 | 60% | 10.6 pts | 53 pts |
| infantry | 15.0 | 5.3 | 71% | 4.8 pts | 73 pts |
| monster | 6.3 | 2.3 | 84% | 4.7 pts | 30 pts |
| war machine | 9.3 | 10.7 | 54% | 40.2 pts | 375 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 4.0 | 3.0 |
| Charges that made contact a game | 1.0 | 3.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 0.67 contact (3 units) | 2.00 declared, 2.00 contact (1 units) | 1.50 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (20 units) | 0.29 declared, 0.23 contact (31 units) | 0.22 declared, 0.16 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| Character on its own | 100% (1 of 1) | 67% (2 of 3) | 20% (1 of 5) | 44% (4 of 9) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 0% (0 of 2) | 80% (4 of 5) | - | 57% (4 of 7) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 75% (3 of 4); on the table 100% | 33% (8 of 24) | 58% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 29% (7 of 24) | 35% | 50% (5 of 10) | 50% (1 of 2); 1.0 uses a game | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 94% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 64% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 64% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 0% (0) | 25% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (20 of 54) | 54% (13 of 24) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 71% (5 of 7) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.3 | 3.3 |
| Movement | Points that never moved of their own | 400.7 | 161.7 |
| Movement | Fights charged into per game | 0.7 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 6, net +254 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 6, net +490 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +60 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +60 | 2 of 6, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (25 of 54) | 49% (20 of 41) |
| Shooting | Points destroyed by shooting units | 82.0 | 0.0 |
| Shooting | War machine shots | 9.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (14 of 28) | - |
| Shooting | Points destroyed by war machines | 78.0 | 41.7 |
| Magic | Magic missiles cast | 2.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (3 of 8) | - |
| Magic | Wounds caused by magic missiles | 3.0 | 1.0 |
| Magic | Wounds caused by other spells | 2.7 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 15.0 | 144.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.7 / 0.7 | 2.7 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 40.0 | 145.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +60 | +199 |
| Combat | Net per 100 charger points, damage counted | +13.8 | +87.1 |
| Combat | First round won (charged fights) | 100% | 44% |
| Combat | Net points per charged fight | +60 | +189 |
| Combat | Net points per supported fight / lone fight | +60 / +60 | - / +189 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 4 of 9 |
| Game | Points lost | 685.7 | 276.7 |
| Game | VP from objectives | 673.3 | 750.0 |
| Game | Lone holders (player turns) | 3.7 | 2.7 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -528 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 962
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.0 | +211.9 | 0.0 | 462.7 | 21.0 | +284.0 | 0.0 | 269.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 144.7 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +24.1 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 15.0 |
| CANNON PLANNED TARGET | 8.3 | +233.6 | 347.3 | 125.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.7 | +76.6 | 15.0 | 123.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +41.9 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | 1.0 | +3.9 | 0.0 | 365.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -6.8 | 75.7 | 0.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.7 | +3.0 | 40.0 | 0.0 | 0.7 | +16.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -321.4 | 0.0 | 428.0 | 20.0 | -616.9 | 0.0 | 246.7 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 522.7 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -1.7 | 75.7 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 40.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 12.7 | -375.6 | 0.0 | 460.0 | 4.3 | -300.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -18.8 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | -60.4 | 0.0 | 41.7 | 8.3 | +44.5 | 0.0 | 61.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -44.3 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +10.9 | 75.7 | 0.0 |
| EXACT ROUND | 1.3 | +0.7 | 75.0 | 144.7 | 1.3 | +73.4 | 447.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 40.0 | 0.0 | 2.3 | +19.0 | 378.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 32.7 | +280.4 | 0.0 | 261.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +6.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.0 | 20.0 | 0.0 | 1.7 | +3.6 | 255.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 61.7 |
| FIVE ACTION | 97.7 | +4402.2 | 1083.3 | 1888.0 | 100.0 | +4742.3 | 1135.7 | 553.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 390.7 | 3.7 | +0.0 | 0.0 | 11.3 |
| FOCUS FIRE | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +28.6 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +80.6 | 115.0 | 144.7 | 3.0 | +346.7 | 522.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 11.3 |
| FRIEND CHARGES FIRST | 0.3 | -13.9 | 15.0 | 123.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -0.7 | 0.0 | 123.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +14.4 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -15.6 | 40.0 | 0.0 | 0.3 | -5.1 | 0.0 | 0.0 |
| GOAL WALK | 7.7 | +455.6 | 0.0 | 0.0 | 18.7 | +1722.1 | 0.0 | 123.3 |
| GUN FIGURES | 3.3 | +3.2 | 0.0 | 0.0 | 0.7 | +35.3 | 41.7 | 123.3 |
| GUN MASK | 2.7 | +119.9 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | - | - | - | - | 0.3 | -0.0 | 75.7 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 75.7 | 4.0 | +0.0 | 0.0 | 78.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.3 | +0.0 | 0.0 | 428.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 8.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -10.2 | 0.0 | 104.0 | 17.3 | -144.0 | 0.0 | 55.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 69.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +941.7 | 0.0 | 305.3 | 60.0 | +4785.2 | 0.0 | 357.3 |
| HIS SHOTS BY HIS RUN | 33.7 | +299.2 | 0.0 | 797.0 | 54.7 | +1240.0 | 0.0 | 382.3 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +27.9 | 179.3 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 69.3 | 18.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.3 | +1343.6 | 0.0 | 34.7 | 13.3 | +1398.1 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -48.5 | 115.0 | 144.7 | 2.7 | -140.4 | 522.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +42.1 | 0.0 | 267.7 | - | - | - | - |
| IDLE COST | - | - | - | - | 21.7 | -334.6 | 0.0 | 15.0 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | -5.8 | 40.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -8.7 | 0.0 | 0.0 |
| JOINT LOOK BACK | 0.3 | +4.3 | 20.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +10.8 | 0.0 | 0.0 | 1.3 | +97.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 0.0 | 319.0 | 4.3 | +0.0 | 342.7 | 15.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +1.3 | 75.7 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.0 | 20.0 | 0.0 | 1.3 | +1.8 | 255.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +8.5 | 0.0 | 11.3 |
| MANOEUVRE | 1.3 | +17.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +82.5 | 0.0 | 0.0 | 0.3 | +53.4 | 0.0 | 0.0 |
| MARCH CHECK | 2.7 | +130.5 | 0.0 | 0.0 | 0.7 | +26.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -46.5 | 0.0 | 0.0 | 0.7 | +7.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 1.7 | +28.0 | 0.0 | 390.7 | 2.0 | +38.7 | 0.0 | 11.3 |
| MEETS IN TIME | 3.7 | +358.9 | 0.0 | 0.0 | 4.7 | +505.4 | 0.0 | 61.7 |
| MISSILES IN THE MOVE | 8.0 | +123.3 | 0.0 | 390.7 | 1.7 | +36.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.0 | +88.7 | 0.0 | 390.7 | 2.3 | +25.3 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.3 | +59.3 | 0.0 | 123.0 | 3.0 | +138.6 | 0.0 | 15.0 |
| NEARER NOT NEEDED | 7.0 | +332.3 | 0.0 | 0.0 | 4.7 | +229.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +54.0 | 15.0 | 246.0 | 2.7 | +135.6 | 0.0 | 15.0 |
| NO CHAFF EDGES | 2.7 | +42.3 | 30.0 | 438.7 | 2.0 | +9.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -28.9 | 115.0 | 144.7 | 2.7 | -223.1 | 522.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.7 | -181.7 | 0.0 | 164.7 | 3.0 | -67.9 | 0.0 | 11.3 |
| OGRE LOADER SECOND SHOT | 2.3 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +4.8 | 75.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -28.5 | 0.0 | 123.0 | 5.0 | -109.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +50.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.7 | -24.0 | 0.0 | 34.7 | 4.0 | +120.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -23.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +15.5 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +6.5 | 15.0 | 144.7 | 0.7 | +17.1 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.0 | +44.0 | 447.0 | 0.0 |
| PLAN RESULT | 45.0 | +733.4 | 395.0 | 1106.7 | 45.3 | +762.1 | 672.3 | 270.3 |
| PROMISE BY ITS OWN SUM | 8.3 | -189.7 | 0.0 | 246.0 | 2.0 | -1.6 | 0.0 | 15.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | -0.4 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 15.0 |
| QUARTER ODDS | 6.3 | +284.3 | 0.0 | 270.7 | 12.7 | +1240.1 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +188.9 | 0.0 | 60.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.3 | +0.0 | 0.0 | 35.3 |
| REFORMS TO MEET IT | 0.3 | -32.2 | 0.0 | 123.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +51.5 | 100.0 | 0.0 | 2.3 | -140.4 | 522.7 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -33.7 | 289.3 | 0.0 |
| RUN DOWN | - | - | - | - | 2.0 | -30.2 | 378.0 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +13.5 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -114.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -16.5 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | -29.5 | 144.7 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +8.5 | 0.0 | 11.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.0 | +0.0 | 0.0 | 311.0 | 9.3 | +0.0 | 0.0 | 78.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +85.2 | 156.0 | 0.0 | 1.3 | +8.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.4 | 15.0 | 144.7 | 0.7 | -7.2 | 151.3 | 0.0 |
| SHOT RISK POINTS | 17.7 | -146.1 | 0.0 | 428.0 | 38.3 | -514.3 | 0.0 | 326.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 30.0 | +1185.9 | 0.0 | 345.7 | 13.3 | +173.1 | 0.0 | 201.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +49.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +2.4 | 80.0 | 0.0 | 0.7 | +0.0 | 267.7 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 192.3 | 6.3 | +0.0 | 0.0 | 73.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -6.9 | 75.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 83.3 | 156.0 |
| STANDS STILL | 56.0 | +0.0 | 968.3 | 981.0 | 36.3 | +0.0 | 613.0 | 171.0 |
| STAY WORTH | 43.7 | +288.4 | 674.0 | 933.0 | 27.0 | +187.3 | 613.0 | 357.3 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +6.8 | 20.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 2.0 | -3.5 | 0.0 | 40.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -0.1 | 75.7 | 0.0 |
| SUPPORT ADDS | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +10.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.7 | 0.0 | 144.7 | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +0.2 | 80.0 | 0.0 | 1.7 | +78.9 | 255.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 123.0 | 3.7 | +0.0 | 0.0 | 73.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 61.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 61.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 771.0 | 49.3 | +0.0 | 0.0 | 276.7 |
| TIED UP BY THE SUM | 1.7 | +186.2 | 95.0 | 144.7 | - | - | - | - |
| TIME ON OUR SIDE | 48.0 | +599.5 | 0.0 | 1203.3 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -0.5 | 40.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.3 | -99.5 | 0.0 | 104.0 | 0.7 | -5.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +14.7 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 4.0 | +584.9 | 0.0 | 522.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +69.8 | 0.0 | 0.0 | 2.0 | +63.8 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 105 | 105 | 88 | 29.33 | +1652 | +18.8 |
| HIS SHOT LIST | 283 | 274 | 83 | 27.67 | +2032 | +24.5 |
| HIS SHOTS BY HIS RUN | 265 | 254 | 73 | 24.33 | +860 | +11.8 |
| HOLDER ASSIGNMENT | 77 | 77 | 71 | 23.67 | +4024 | +56.7 |
| GOAL WALK | 79 | 79 | 35 | 11.67 | +2250 | +64.3 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -749 | -23.4 |
| DEPLOY BY FIGURES | 54 | 54 | 29 | 9.67 | +367 | +12.6 |
| STAY WORTH | 212 | 189 | 28 | 9.33 | +64 | +2.3 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| SHOT RISK POINTS | 168 | 166 | 21 | 7.00 | +621 | +29.6 |
| IDLE COST | 65 | 44 | 18 | 6.00 | +260 | +14.5 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 144 | 125 | 17 | 5.67 | +72 | +4.2 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 16 | 5.33 | -574 | -35.9 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| FIVE ACTION | 593 | 573 | 14 | 4.67 | +465 | +33.2 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +1148 | +88.3 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NO CHAFF EDGES | 14 | 14 | 12 | 4.00 | +132 | +11.0 |
| CAST JOB | 14 | 14 | 11 | 3.67 | +116 | +10.5 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CHARGE LOSSES | 113 | 109 | 9 | 3.00 | +504 | +56.0 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 15 | 15 | 9 | 3.00 | +268 | +29.8 |
| MOVE TO CHARGE COMPUTED | 16 | 11 | 9 | 3.00 | +197 | +21.9 |
| QUARTER ODDS | 57 | 55 | 9 | 3.00 | +768 | +85.3 |
| MARCH CHECK | 10 | 9 | 8 | 2.67 | +171 | +21.4 |
| NEXT CHARGE BY LIST | 14 | 11 | 8 | 2.67 | +188 | +23.5 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 8 | 2.67 | +79 | +9.8 |
| COVER ONCE | 51 | 37 | 7 | 2.33 | +68 | +9.7 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1166 | +166.5 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +13 | +1.8 |
| FALLS SHORT | 98 | 77 | 6 | 2.00 | +38 | +6.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +324 | +53.9 |
| WOUNDS ON THE RANKS | 21 | 21 | 6 | 2.00 | +63 | +10.5 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +408 | +81.5 |
| MAX FOR POSITIONING | 11 | 10 | 5 | 1.67 | +6 | +1.3 |
| MISSILES IN THE MOVE | 29 | 23 | 5 | 1.67 | +81 | +16.2 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +54 | +10.8 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +14 | +3.5 |
| GUN MASK | 8 | 8 | 4 | 1.33 | +132 | +32.9 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -8 | -2.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| RISK BY ARC | 12 | 12 | 4 | 1.33 | +22 | +5.4 |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 4 | 1.33 | +4 | +1.1 |
| SHOTS IN THE MOVE | 130 | 107 | 4 | 1.33 | +38 | +9.5 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 3 | 1.00 | +43 | +14.3 |
| CHAFF IN THE MOVE | 6 | 5 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 5 | 5 | 3 | 1.00 | +53 | +17.7 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 26 | 26 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 12 | 12 | 3 | 1.00 | +235 | +78.4 |
| BACKS UP THE FIGHT | 3 | 2 | 2 | 0.67 | +14 | +6.9 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -25 | -12.6 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +86 | +42.9 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +55 | +27.5 |
| HIS MOVE AND SHOT | 69 | 65 | 2 | 0.67 | +8 | +4.2 |
| HUNT IN PAIRS | 2 | 2 | 2 | 0.67 | +70 | +34.9 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +360 | +180.0 |
| ONE OBJECTIVE FORMULA | 26 | 23 | 2 | 0.67 | +43 | +21.4 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -71 | -35.5 |
| PROMISE KNOWS THE FIGHT | 8 | 5 | 2 | 0.67 | -1 | -0.6 |
| REDIRECT COUNTER | 10 | 8 | 2 | 0.67 | +53 | +26.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +11 | +5.6 |
| SCOUT BY DROPS | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +20 | +10.2 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.3 |
| THE FIGHT MOVES | 9 | 9 | 2 | 0.67 | +125 | +62.4 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -13 | -6.6 |
| WHOLE FIGHT DANGER | 15 | 13 | 2 | 0.67 | +212 | +106.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.9 |
| CANNON PLANNED TARGET | 25 | 25 | 1 | 0.33 | +23 | +22.6 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +10 | +10.3 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +36 | +35.5 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -39 | -38.9 |
| NEARER NOT NEEDED | 35 | 33 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +76 | +75.7 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +32 | +32.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -11 | -10.8 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +7 | +6.6 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +85 | +85.3 |
| SET UP TOGETHER | 2 | 1 | 1 | 0.33 | +24 | +24.5 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -110 | -109.6 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 65 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 4 | 4 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 49 | 41 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 14 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 10 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 40 | 29 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| REAL GROUND | 10 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 8 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 27 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 277 | 268 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 6 | 6 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 275 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 2.67 | 23.3 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 0.33 | 35.9 |
| ARMY TABLE | rule | 1.33 | 3.00 | 31.2 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 26.2 |
| CHARGE NOW FIRST | rule | - | 0.67 | 12.6 |
| JOINT CHARGE NOW | rule | 0.67 | - | 8.7 |
| NO REASON | gate | 0.67 | - | 17.5 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 35.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 0.6 |
| WAR ENGINE JOBS | rule | 0.67 | - | 6.6 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 38.9 |
| REFUSING RETIRES | rule | - | 0.33 | 10.8 |
| RULE SWITCHED OFF | gate | - | 0.33 | 37.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 109.6 |

### Plans: chf-efd8067-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 85 | 83 | 98% |
| Mine | join | 0.7 | 100% | 9 | 0 | 0% |
| Mine | move | 27.0 | 96% | 1277 | 0 | 0% |
| Mine | shoot | 15.3 | 57% | 698 | 650 | 93% |
| Opponent | charge | 2.3 | 86% | 296 | 519 | 175% |
| Opponent | move | 34.3 | 92% | 1650 | 0 | 0% |
| Opponent | shoot | 7.3 | 45% | 318 | 243 | 77% |
| Opponent | support | 1.3 | 100% | 27 | 0 | 0% |

### Battle groups: chf-efd8067-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 100% | 0% | - | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 7 (12) | 7 | 0 | 63 | 25% | 3.2 | 14 (3) | 5 (5) | 0 (3) | 8 (7) | 5 (4) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast Hammer | 3 | 152 (3) | 10 | 142 | 29 | 33% | 2.0 | - | 101 (2) | 244 (1) | 215 (2) | 0 (1) |
| Mine | Hammer | 8 | 15 (8) | 0 | 15 | 24 | 12% | 3.1 | - | 9 (6) | 38 (2) | 11 (6) | 29 (2) |
| Mine | Shooter | 6 | 150 (6) | 39 | 111 | 33 | 0% | 1.3 | 0 (1) | 276 (2) | 116 (3) | 150 (6) | - |
| Mine | War machine | 8 | 22 (8) | 22 | 0 | 35 | 0% | 1.2 | 187 (1) | 0 (1) | 0 (6) | - | 22 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Chaff | 11 | 118 (11) | 0 | 118 | 47 | 55% | 3.2 | 0 (4) | 600 (1) | 114 (6) | 118 (11) | - |
| Opponent | Character | 6 | 52 (6) | 52 | 0 | 0 | 0% | 2.8 | 59 (5) | 0 (1) | - | 49 (3) | 54 (3) |
| Opponent | Clean-up | 4 | 31 (4) | 31 | 0 | 0 | 25% | 1.7 | - | 123 (1) | 0 (3) | 60 (2) | 0 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 33 (10) | 30 | 3 | 32 | 40% | 2.0 | 34 (2) | 25 (6) | 58 (2) | 23 (8) | 114 (2) |
| Opponent | Holder | 1 | 101 (1) | 0 | 101 | 0 | 100% | - | - | 101 (1) | - | 101 (1) | - |
| Opponent | Shooter | 1 | 225 (1) | 0 | 225 | 0 | 0% | 1.0 | - | 225 (1) | - | 225 (1) | - |

### Charged fights: chf-efd8067-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 240 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 45 | 120 | 2.0 | 1.5 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | +60 | +60 |
| **Mine** | all armies | 3 | 175 | 40 | 0.7 | 1.5 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | +60 | +60 |
| Opponent | Ogre Kingdoms | 1 | 125 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 434 | 504 | 3.0 | 1.0 | 168 | 0 | +168 | 2 of 3 | 2 of 3 | - | +168 |
| Opponent | Wood Elf Realms | 1 | 0 | 1194 | 4.0 | 1.0 | 298 | 0 | +298 | 2 of 4 | 2 of 4 | - | +298 |
| **Opponent** | all armies | 3 | 186 | 566 | 3.0 | 1.0 | 189 | 0 | +189 | 4 of 9 | 4 of 9 | - | +189 |

### Effective charges: chf-efd8067-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 1 (net +60) | 1 (net +60) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 1 (net +504) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 4 | 2 (net +254) | 0 | 1 (net +477) | 0 | 0 | 1 (net +208) | 0 | 25% (1 of 4) |

### Charged fights, damage counted: chf-efd8067-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 167 | 60 | +60 | 60 | 0 | +60 | +35.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 703 | 60 | +60 | 60 | 0 | +60 | +8.5 |
| Mine | All fights | 2 | 435 | 60 | +60 | 60 | 0 | +60 | +13.8 |
| Opponent | Long shot (under 50%) | 2 | 304 | 199 | +254 | 261 | 0 | +261 | +85.9 |
| Opponent | Effective (55-75%) | 2 | 110 | 181 | +490 | 579 | 69 | +510 | +465.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 304 | 219 | +104 | 104 | 0 | +104 | +34.2 |
| Opponent | No odds | 3 | 208 | 209 | +0 | 26 | 12 | +14 | +6.9 |
| Opponent | All fights | 9 | 229 | 203 | +189 | 218 | 19 | +199 | +87.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p42 | move | 14 | 0 (0%) | 0 (0%) | 3 (21%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

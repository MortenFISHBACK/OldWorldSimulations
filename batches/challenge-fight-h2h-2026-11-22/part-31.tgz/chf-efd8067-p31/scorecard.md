# Doctrine scorecard: chf-efd8067-p31

### Scorecard: chf-efd8067-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 1 | 4 | 1 | 0 | 1 | 0 | 0 | 884 |
| L1114 | 4 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 1 | 5 | 1 | 3 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 14 | 3 | 7 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.0 | 3.5 | 3.0 | 0.0 | 0.3 | 0.0 | 0.0 | 404.7 |
| **Average** | | | Opponent | 0% | 4.3 | 3.0 | 3.0 | 1.3 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: chf-efd8067-p31

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 44% (7 of 16) | 0% (0 of 15) | 23% (7 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (4 of 8); on the table 50% | 100% (3 of 3); on the table 100% | 64% (7 of 11); on the table 64% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (4 of 8); on the table 50% | 67% (4 of 6); on the table 83% | 57% (8 of 14); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 38% (25 of 66) | 11% (2 of 18) | 32% (27 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (25 of 54) | 11% (2 of 18) | 38% (27 of 72) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (6 of 9) | 67% (6 of 9) |
| Points that never fought | lower | 45% (2703 of 5998) | 63% (3795 of 5998) | 54% (6498 of 11996) |
|   infantry points that never fought | lower | 77% (559 of 730) | 81% (737 of 913) | 79% (1296 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 68% (19 of 28) | 58% (31 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 6.7 uses a game | 0% (0 of 1); 0.0 uses a game | 88% (7 of 8); 3.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 1.0 uses a game | 33% (2 of 6); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 37% (2076 of 5614) | 68% (3992 of 5828) | 53% (6068 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (20%) | 3.3 (62%) | 6.0 (32%) |
| MARCHED: its unit marched | 5.3 (39%) | 2.0 (38%) | 7.3 (39%) |
| CHARGED: its unit charged | 1.3 (10%) | 0.0 (0%) | 1.3 (7%) |
| IN COMBAT: engaged in combat | 4.0 (29%) | 0.0 (0%) | 4.0 (21%) |
| STUPIDITY: Stupidity | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 5.7 | 3.3 | 9.0 | 2.3 | 1.7 |
| not cast | 0.3 | 6.3 | 0.7 | 19.0 | 5.7 | 34.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.7 (89%) | 0.0 (0%) | 6.0 (32%) | 1.3 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (39%) | 1.3 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) | 0.7 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (21%) | 0.7 (12%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 1.7 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 33.3 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 3.3 a game | 1.7 a game |
| stood (cast and not dispelled) | - | 60% (6 of 10) | 60% (6 of 10) |
| the unit moved after it | - | 50% (3 of 6) | 50% (3 of 6) |
| it charged on its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| the enemy charged it first | - | 17% (1 of 6) | 17% (1 of 6) |
| it fought by the end of its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 6) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | - | 83% (5 of 6) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 85% (39 of 46) | 31% (9 of 29) | 64% (48 of 75) |
|   cavalry | - | 27% (3 of 11) | 27% (3 of 11) |
|   character | - | 0% (0 of 12) | 0% (0 of 12) |
|   chariot | 89% (8 of 9) | - | 89% (8 of 9) |
|   infantry | 75% (9 of 12) | 100% (6 of 6) | 83% (15 of 18) |
|   war machine | 88% (22 of 25) | - | 88% (22 of 25) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (29%) | 1.7 (25%) | 2.3 (26%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (25%) | 1.7 (19%) |
| FLEEING: it fled or was fleeing | 0.7 (29%) | 0.0 (0%) | 0.7 (7%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (4%) |
| MOVED: a war machine that moved | 0.7 (29%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.7 (40%) | 2.7 (30%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (5%) | 0.3 (4%) |
| OTHER BAR | 0.3 (14%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 0.7 | 75% | 10.4 pts | 28 pts |
| infantry | 10.0 | 3.7 | 73% | 9.9 pts | 99 pts |
| war machine | 8.3 | 4.3 | 72% | 17.2 pts | 143 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 3.7 | 3.7 |
| Charges that made contact a game | 2.3 | 2.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 0.86 contact (7 units) | 0.00 declared, 0.00 contact (2 units) | 0.89 declared, 0.67 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.10 contact (10 units) | 0.52 declared, 0.33 contact (21 units) | 0.45 declared, 0.26 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 2) | 40% (6 of 15) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 100% (4 of 4) | 20% (1 of 5) | 33% (2 of 6) | 47% (7 of 15) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 67% (4 of 6) | 0% (0 of 2) | - | 50% (4 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 50% (4 of 8); on the table 50% | 38% (25 of 66) | 45% | 48% (12 of 25) | 100% (7 of 7); 6.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 55% | 44% (4 of 9) | 0.0 uses a game | 33% (2 of 6); 3.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 100% | 0% (0 of 6) | 62% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 73% | 92% (11 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (2) | 50% (3) | 38% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: chf-efd8067-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 64% (7 of 11) | 50% (5 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (14 of 39) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 67% (2 of 3) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 0.0 | 1.3 |
| Movement | Points that never moved of their own | 404.7 | 56.7 |
| Movement | Fights charged into per game | 2.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +143 | 3 of 6, net +325 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +88 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +89 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (6 of 17) | 56% (5 of 9) |
| Shooting | Points destroyed by shooting units | 0.0 | 50.0 |
| Shooting | War machine shots | 7.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (8 of 23) | - |
| Shooting | Points destroyed by war machines | 56.7 | 0.0 |
| Magic | Magic missiles cast | 5.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 24% (4 of 17) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 7.0 | - |
| Magic | Wounds caused by other spells | 2.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 159.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 0.7 / 1.0 | 2.0 / 1.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 167.3 | 191.0 |
| Combat | Points run down | 48.0 | 98.7 |
| Combat | Net points per charged fight, damage counted | +87 | +156 |
| Combat | Net per 100 charger points, damage counted | +35.9 | +55.8 |
| Combat | First round won (charged fights) | 86% | 71% |
| Combat | Net points per charged fight | +84 | +163 |
| Combat | Net points per supported fight / lone fight | - / +84 | - / +163 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 4 of 7 |
| Game | Points lost | 454.7 | 431.3 |
| Game | VP from objectives | 593.3 | 560.0 |
| Game | Lone holders (player turns) | 5.0 | 4.3 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -13 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 886
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.3 | +337.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.0 | +127.4 | 0.0 | 100.0 | 20.7 | +119.0 | 0.0 | 81.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 220.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 1.0 | +8.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -68.7 | 0.0 | 0.0 |
| BOMBING RUN | 0.3 | +20.8 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.3 | +264.7 | 95.3 | 330.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -9.0 | 20.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.0 | +163.8 | 295.3 | 0.0 | 0.3 | +4.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +2.3 | 0.0 | 0.0 | 1.7 | +39.2 | 0.0 | 79.7 |
| CHALLENGE IN THE FIGHT | 1.3 | -2.2 | 188.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -16.9 | 136.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.3 | -9.4 | 136.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -994.6 | 0.0 | 210.0 | 27.3 | -943.4 | 0.0 | 594.3 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 206.7 | 0.0 | 0.7 | +0.0 | 136.0 | 0.0 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 261.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 3.3 | +346.2 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -329.2 | 0.0 | 55.0 | 9.7 | -684.6 | 0.0 | 195.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -10.3 | 55.0 | 0.0 |
| DEPLOY BY FIGURES | 4.7 | -28.4 | 0.0 | 0.0 | 5.7 | +153.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.0 | -84.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +12.7 | 47.7 | 0.0 | 0.3 | +9.9 | 55.0 | 0.0 |
| EXACT ROUND | 2.3 | +27.8 | 134.7 | 0.0 | 2.0 | +9.8 | 110.0 | 20.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +4.3 | 167.7 | 0.0 | 2.7 | +0.6 | 191.0 | 20.0 |
| FALLS SHORT | - | - | - | - | 23.3 | +269.5 | 0.0 | 402.0 |
| FIGHT TO THE END | 1.0 | +16.9 | 86.7 | 0.0 | 1.0 | +4.9 | 136.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 78.0 | +4724.9 | 862.3 | 1242.0 | 74.0 | +5894.8 | 246.0 | 1012.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 162.7 |
| FOLLOW UP WEIGHED | 1.3 | +268.3 | 0.0 | 0.0 | 1.0 | +50.1 | 0.0 | 20.0 |
| FOUR ROUNDS | 3.7 | +245.1 | 269.0 | 0.0 | 3.7 | +337.8 | 246.0 | 20.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 242.7 |
| FRIEND SHOOTS FIRST | 0.7 | -14.2 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -9.5 | 95.7 | 0.0 | 0.3 | -5.7 | 0.0 | 0.0 |
| GOAL WALK | 0.7 | +25.6 | 0.0 | 0.0 | 16.3 | +2568.9 | 0.0 | 173.3 |
| GUN MASK | 1.3 | +83.1 | 0.0 | 100.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.7 | +2.4 | 95.7 | 0.0 | 1.7 | +5.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 5.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 242.7 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 110.0 | 14.0 | +0.0 | 0.0 | 469.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +61.2 | 0.0 | 20.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 472.0 | 8.3 | +0.0 | 0.0 | 244.7 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -13.2 | 0.0 | 0.0 | 7.3 | -64.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 11.7 | +136.9 | 0.0 | 472.0 | 58.3 | +2543.8 | 0.0 | 910.0 |
| HIS SHOTS BY HIS RUN | 15.7 | +204.5 | 0.0 | 472.0 | 53.3 | +1877.9 | 0.0 | 701.3 |
| HIS TURN DENIED | 0.3 | +1.2 | 0.0 | 0.0 | 1.3 | +85.1 | 55.0 | 0.0 |
| HOLD ODDS | 9.0 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +871.7 | 0.0 | 0.0 | 10.0 | +986.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -105.9 | 269.0 | 0.0 | 2.7 | -165.0 | 110.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +6.1 | 0.0 | 0.0 | 0.7 | +27.7 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +81.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 16.0 | -285.7 | 0.0 | 166.7 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | -55.3 | 136.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +18.9 | 0.0 | 0.0 | 0.7 | +18.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 90.3 | 136.0 | 2.3 | +0.0 | 0.0 | 99.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +11.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | -2.4 | 134.3 | 0.0 | 2.7 | -4.7 | 136.0 | 20.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +1.5 | 0.0 | 0.0 | 3.0 | +61.9 | 0.0 | 53.7 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | -2.0 | 0.0 | 48.0 |
| MARCH AT ESCAPER | 0.3 | +1.7 | 0.0 | 0.0 | 1.0 | +9.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 2.3 | +62.5 | 0.0 | 0.0 | 0.3 | +35.6 | 0.0 | 38.7 |
| MARCH CHECK | 2.7 | +118.3 | 0.0 | 0.0 | 1.3 | +63.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.3 | +65.5 | 0.0 | 0.0 | 0.3 | +5.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.3 | -18.9 | 0.0 | 0.0 | 1.3 | +71.5 | 0.0 | 38.7 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.0 | +96.3 | 0.0 | 0.0 | 4.3 | +93.3 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +347.8 | 0.0 | 0.0 | 2.3 | +358.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 12.7 | +309.7 | 0.0 | 0.0 | 2.0 | +15.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 15.7 | +221.1 | 0.0 | 0.0 | 5.7 | +19.8 | 0.0 | 38.7 |
| MISSILES ON ONE TARGET | 0.3 | -21.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +457.0 | 0.0 | 0.0 | 3.3 | +353.5 | 0.0 | 77.3 |
| NEARER NOT NEEDED | 4.7 | +206.1 | 0.0 | 0.0 | 5.7 | +244.4 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 7.0 | +582.9 | 33.3 | 0.0 | 2.0 | +251.0 | 0.0 | 77.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -5.7 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +77.8 | 215.3 | 0.0 | 1.0 | +37.4 | 55.0 | 50.3 |
| NO DOUBLE ROUNDS | 2.3 | -75.8 | 195.3 | 0.0 | 2.7 | -94.0 | 246.0 | 20.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | +7.9 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -151.4 | 0.0 | 55.0 | 4.0 | -140.0 | 0.0 | 86.7 |
| OGRE LOADER SECOND SHOT | 5.0 | +39.1 | 0.0 | 110.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.7 | -6.8 | 88.7 | 0.0 | 0.3 | +6.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -136.6 | 0.0 | 0.0 | 6.3 | -93.8 | 0.0 | 125.0 |
| ONE JOINT FIGURE | 0.3 | -12.1 | 0.0 | 0.0 | 0.7 | +12.9 | 136.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | +12.5 | 0.0 | 0.0 | 3.7 | +64.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.0 | +34.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.7 | +44.0 | 167.7 | 0.0 | 0.7 | +29.5 | 55.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +14.7 | 110.0 | 0.0 |
| OWN CAST FIRST | 1.0 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -71.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 35.0 | +771.5 | 282.0 | 757.0 | 39.0 | +301.4 | 320.0 | 744.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -126.0 | 0.0 | 0.0 | 4.3 | -41.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | -23.2 | 33.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.0 | +1378.5 | 202.3 | 220.0 | 12.0 | +1995.0 | 0.0 | 77.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +40.9 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.7 | +206.3 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -135.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 53.7 |
| RISK BY ARC | 3.0 | +184.9 | 221.3 | 0.0 | 3.3 | -157.1 | 246.0 | 20.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -73.1 | 110.0 | 0.0 |
| RUN DOWN | 1.0 | -4.9 | 127.7 | 0.0 | 3.0 | -50.3 | 191.0 | 20.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +12.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +18.7 | 0.0 | 0.0 | 1.0 | -68.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +1.7 | 0.0 | 0.0 | 3.7 | +110.7 | 0.0 | 53.7 |
| SHOOTERS ON THE TABLE | 12.3 | +0.0 | 0.0 | 330.0 | 3.7 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +114.2 | 107.3 | 0.0 | 2.0 | +12.6 | 0.0 | 82.0 |
| SHOT OR CHARGE | 1.0 | -14.3 | 53.7 | 0.0 | 0.3 | -1.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 7.7 | -64.3 | 0.0 | 100.0 | 38.0 | +138.6 | 0.0 | 740.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +648.3 | 0.0 | 435.0 | 2.7 | +58.9 | 0.0 | 41.0 |
| SPELL WORTH | 1.7 | +4.7 | 0.0 | 0.0 | 2.0 | +38.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | -17.2 | 20.0 | 0.0 | 0.7 | -23.5 | 0.0 | 20.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 134.0 |
| STAND AND SHOOT | 0.3 | -0.3 | 41.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 82.0 |
| STANDS STILL | 41.7 | +0.0 | 593.3 | 1142.0 | 18.7 | +0.0 | 0.0 | 264.0 |
| STAY WORTH | 25.7 | -120.6 | 355.0 | 660.0 | 2.0 | +22.3 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +8.3 | 55.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +4.3 | 0.0 | 55.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +167.4 | 0.0 | 0.0 | 1.0 | +211.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 41.0 | 0.0 | 1.0 | +0.0 | 136.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +167.4 | 0.0 | 0.0 | 1.0 | +211.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +29.7 | 0.0 | 50.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.3 | 0.0 | 48.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.0 | +8.9 | 134.3 | 0.0 | 2.7 | +101.1 | 191.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 38.7 | 16.7 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.3 | +0.0 | 0.0 | 566.0 | 36.7 | +0.0 | 0.0 | 437.0 |
| TIED UP BY THE SUM | 2.0 | +214.3 | 221.3 | 0.0 | 0.3 | +40.9 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 34.7 | +519.0 | 77.3 | 508.0 | 3.7 | +38.6 | 0.0 | 246.3 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -33.8 | 40.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +32.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -1.3 | 20.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.0 | -905.8 | 0.0 | 110.0 | 0.7 | -53.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.3 | +136.4 | 136.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.7 | +582.9 | 20.0 | 246.0 | 1.3 | +43.6 | 0.0 | 175.3 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +182.0 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 89 | 89 | 68 | 22.67 | +1234 | +18.1 |
| HOLDER ASSIGNMENT | 53 | 53 | 48 | 16.00 | +3535 | +73.7 |
| HIS SHOT LIST | 210 | 204 | 40 | 13.33 | +569 | +14.2 |
| FIVE ACTION | 456 | 441 | 39 | 13.00 | +3919 | +100.5 |
| HIS SHOTS BY HIS RUN | 207 | 201 | 30 | 10.00 | +841 | +28.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -874 | -33.6 |
| GOAL WALK | 51 | 51 | 25 | 8.33 | +3589 | +143.6 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 137 | 131 | 19 | 6.33 | +204 | +10.8 |
| FOUR ROUNDS | 22 | 21 | 17 | 5.67 | +643 | +37.8 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| CAST JOB | 19 | 19 | 15 | 5.00 | +153 | +10.2 |
| MOVE TO CHARGE COMPUTED | 32 | 28 | 15 | 5.00 | +437 | +29.2 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +117 | +7.8 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 15 | 5.00 | +67 | +4.4 |
| CHARGE LOSSES | 115 | 109 | 13 | 4.33 | +1326 | +102.0 |
| DEPLOY BY FIGURES | 31 | 31 | 12 | 4.00 | +186 | +15.5 |
| NEXT CHARGE BY LIST | 27 | 27 | 12 | 4.00 | +424 | +35.3 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 12 | 4.00 | -504 | -42.0 |
| TIME ON OUR SIDE | 115 | 94 | 12 | 4.00 | +46 | +3.8 |
| COVER ONCE | 49 | 27 | 10 | 3.33 | +90 | +9.0 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 31 | 31 | 9 | 3.00 | +36 | +4.0 |
| QUARTER ODDS | 75 | 75 | 9 | 3.00 | +712 | +79.2 |
| MARCH BY THE SUM | 8 | 8 | 8 | 2.67 | +294 | +36.8 |
| SUPPORT ADDS | 11 | 11 | 8 | 2.67 | +259 | +32.4 |
| SUPPORT WORKED OUT | 11 | 11 | 8 | 2.67 | +259 | +32.4 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +124 | +17.7 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +955 | +136.5 |
| MARCH CHECK | 12 | 12 | 7 | 2.33 | +94 | +13.4 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SET UP BY THE SET | 8 | 8 | 7 | 2.33 | +112 | +16.0 |
| CHARGE NOW FIRST | 12 | 12 | 6 | 2.00 | -331 | -55.2 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +112 | +18.6 |
| MEETS IN TIME | 16 | 16 | 6 | 2.00 | +223 | +37.1 |
| NO CHAFF EDGES | 11 | 10 | 6 | 2.00 | +154 | +25.7 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 6 | 2.00 | -70 | -11.7 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 6 | 2.00 | +123 | +20.4 |
| RISK BY ARC | 19 | 18 | 6 | 2.00 | +127 | +21.1 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -213 | -42.6 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +1014 | +253.5 |
| IDLE COST | 48 | 29 | 4 | 1.33 | +52 | +13.1 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -166 | -41.5 |
| MISSILES IN THE MOVE | 44 | 27 | 4 | 1.33 | +135 | +33.6 |
| ONE OBJECTIVE FORMULA | 18 | 13 | 4 | 1.33 | +39 | +9.8 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +233 | +58.3 |
| SCOUT BY DROPS | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| SUPPORT NARROWED | 6 | 6 | 4 | 1.33 | -311 | -77.8 |
| THE FIGHT MOVES | 14 | 14 | 4 | 1.33 | +50 | +12.6 |
| TIED UP BY THE SUM | 7 | 6 | 4 | 1.33 | +48 | +12.1 |
| WHOLE FIGHT DANGER | 14 | 14 | 4 | 1.33 | +650 | +162.4 |
| WHOLE FIGHT GAIN | 4 | 4 | 4 | 1.33 | +217 | +54.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES NEXT TURN | 64 | 43 | 3 | 1.00 | +30 | +10.1 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +104 | +34.6 |
| OWN CAST FIRST | 3 | 3 | 3 | 1.00 | -9 | -2.9 |
| REFUSING RETIRES | 3 | 3 | 3 | 1.00 | +184 | +61.4 |
| SET UP TOGETHER | 15 | 6 | 3 | 1.00 | +86 | +28.7 |
| STAY WORTH | 83 | 74 | 3 | 1.00 | +3 | +1.1 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 1.00 | +3 | +0.9 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 13 | 12 | 2 | 0.67 | +24 | +12.1 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +83 | +41.6 |
| HUNT IN PAIRS | 4 | 3 | 2 | 0.67 | +2 | +1.1 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| NEARER NOT NEEDED | 31 | 28 | 2 | 0.67 | +42 | +21.2 |
| OPENS UP IN FULL | 7 | 6 | 2 | 0.67 | +29 | +14.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +37 | +18.7 |
| SHOTS AFTER THE MOVES | 17 | 17 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 50 | 33 | 2 | 0.67 | +19 | +9.6 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +25 | +12.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 12 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKUP TARGETS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +62 | +62.5 |
| CANNON PLANNED TARGET | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -27 | -27.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 1 | 0.33 | +56 | +56.1 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +36 | +36.5 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 70 | 52 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +6 | +6.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -3 | -3.0 |
| GUN MASK | 4 | 4 | 1 | 0.33 | +73 | +72.9 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +138 | +138.1 |
| HONEST WORTH | 19 | 18 | 1 | 0.33 | +35 | +35.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +7 | +6.8 |
| LOST AFTER ESCAPE | 15 | 15 | 1 | 0.33 | +0 | +0.3 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ONE CHALLENGE TEST | 3 | 3 | 1 | 0.33 | +0 | +0.3 |
| ONE FIGHT FORMULA | 35 | 18 | 1 | 0.33 | +144 | +143.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -214 | -213.7 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +12.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +69 | +69.2 |
| WOUNDS ON THE RANKS | 10 | 9 | 1 | 0.33 | +45 | +44.6 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 16 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 10 | 10 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 41 | 41 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 35 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 3 | 3 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 12 | not checked | - | - | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 222 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 48 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 181 | 174 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 216 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT REACTION | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 3.33 | 36.7 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 0.67 | 42.0 |
| ARMY TABLE | rule | 0.67 | 2.67 | 38.7 |
| CHARGE NOW FIRST | rule | 2.00 | - | 55.2 |
| PROMISE KNOWS THE FIGHT | rule | 1.67 | - | 13.9 |
| MARCH OF THE TABLE | rule | 1.00 | 0.33 | 53.2 |
| SUPPORT NARROWED | rule | 0.67 | 0.67 | 77.8 |
| JOINT CHARGE NOW | rule | - | 1.00 | 55.3 |
| OWN CAST FIRST | rule | 1.00 | - | 2.9 |
| AFTERMATH BAND | gate | - | 0.33 | 3.0 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 27.0 |
| FRIENDS SHOTS CHECKED | rule | - | 0.33 | 3.0 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 49.0 |
| NO REASON | gate | 0.33 | - | 27.2 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 43.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 213.7 |
| REFUSING RETIRES | rule | - | 0.33 | 3.7 |
| TURN GATE | gate | - | 0.33 | 0.7 |

### Plans: chf-efd8067-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 50% | 374 | 207 | 55% |
| Mine | move | 21.0 | 97% | 1121 | 0 | 0% |
| Mine | shoot | 10.7 | 53% | 653 | 564 | 86% |
| Opponent | charge | 3.3 | 50% | 393 | 285 | 73% |
| Opponent | join | 3.7 | 100% | 199 | 0 | 0% |
| Opponent | move | 31.0 | 90% | 2340 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 43 | 16 | 38% |

### Packages: hunt the guns, chf-efd8067-p31

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 57 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 170 |

### Battle groups: chf-efd8067-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 26 (9) | 26 | 0 | 13 | 0% | 2.3 | 51 (3) | 19 (6) | - | 7 (5) | 40 (4) |
| Mine | Clean-up | 2 | 90 (2) | 0 | 90 | 0 | 0% | 3.0 | 0 (1) | 170 (1) | - | 90 (2) | - |
| Mine | Fast Hammer | 4 | 27 (4) | 0 | 27 | 55 | 0% | 1.8 | 25 (1) | 35 (2) | 0 (1) | 31 (3) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Shooter | 4 | 64 (4) | 30 | 34 | 0 | 0% | 3.0 | 89 (1) | 71 (2) | 0 (1) | 68 (2) | 60 (2) |
| Mine | War machine | 6 | 17 (6) | 17 | 0 | 67 | 0% | 1.2 | 103 (1) | 0 (4) | 0 (1) | 103 (1) | 0 (5) |
| Mine | Wizard | 3 | 54 (3) | 54 | 0 | 0 | 0% | 2.7 | 79 (2) | 31 (1) | - | 79 (2) | 31 (1) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Character | 10 | 20 (10) | 20 | 0 | 6 | 60% | 2.2 | 0 (4) | 43 (5) | 0 (1) | 34 (6) | 0 (4) |
| Opponent | Fast Hammer | 9 | 66 (9) | 33 | 33 | 38 | 56% | 2.8 | 0 (1) | 83 (7) | 0 (1) | 83 (6) | 30 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 63 | 33% | 2.5 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Holder | 5 | 50 (5) | 0 | 50 | 17 | 80% | 4.0 | 11 (2) | 95 (2) | 15 (1) | 17 (2) | 72 (3) |
| Opponent | Shooter | 1 | 85 (1) | 85 | 0 | 0 | 0% | 1.0 | - | 85 (1) | - | 85 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |

### Charged fights: chf-efd8067-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 216 | 195 | 2.3 | 1.0 | 84 | 0 | +84 | 1 of 7 | 6 of 7 | - | +84 |
| Opponent | High Elf Realms | 1 | 150 | 1034 | 4.0 | 1.0 | 258 | 0 | +258 | 2 of 4 | 2 of 4 | - | +258 |
| Opponent | Vampire Counts | 1 | 0 | 165 | 2.0 | 1.0 | 82 | 30 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 50 | 400 | 2.3 | 1.0 | 171 | 9 | +163 | 4 of 7 | 5 of 7 | - | +163 |

### Effective charges: chf-efd8067-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 1 (net +143) | 0 | 0 | 1 (net +0) | 2 (net +88) | 3 (net +89) | 0 | 0% (0 of 7) |
| Opponent | High Elf Realms | 4 | 2 (net +517) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 2 | 1 (net -60) | 0 | 0 | 1 (net +165) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 233 | 143 | +143 | 143 | 0 | +143 | +61.4 |
| Mine | 76-89% | 1 | 205 | 470 | +0 | 0 | 68 | -68 | -33.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 228 | 143 | +89 | 134 | 0 | +134 | +58.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 287 | 88 | +88 | 93 | 28 | +66 | +22.9 |
| Mine | All fights | 7 | 242 | 174 | +84 | 105 | 18 | +87 | +35.9 |
| Opponent | Long shot (under 50%) | 3 | 233 | 350 | +325 | 378 | 60 | +318 | +136.3 |
| Opponent | 76-89% | 2 | 138 | 199 | +82 | 82 | 19 | +63 | +45.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 165 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 489 | 171 | +0 | 11 | 0 | +11 | +2.2 |
| Opponent | All fights | 7 | 279 | 255 | +163 | 187 | 31 | +156 | +55.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p31 | move | 23 | 4 (17%) | 4 (17%) | 3 (13%) | 16 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

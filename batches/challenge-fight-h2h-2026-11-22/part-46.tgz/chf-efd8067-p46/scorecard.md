# Doctrine scorecard: chf-efd8067-p46

### Scorecard: chf-efd8067-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 5 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 490 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.7 | 2.5 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 163.3 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 3.0 | 2.3 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: chf-efd8067-p46

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 18) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 100% | 100% (4 of 4); on the table 100% | 89% (8 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 43% (3 of 7); on the table 43% | 50% (4 of 8); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 100% | 54% (7 of 13); on the table 54% | 63% (12 of 19); on the table 68% |
| Magic missiles tried each own turn | 50%+ | 54% (13 of 24) | 75% (9 of 12) | 61% (22 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 68% (13 of 19) | 75% (9 of 12) | 71% (22 of 31) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 30% (3 of 10) | 50% (1 of 2) | 33% (4 of 12) |
| Points that never fought | lower | 24% (1463 of 5999) | 33% (1998 of 5999) | 29% (3461 of 11998) |
|   infantry points that never fought | lower | 35% (352 of 993) | 38% (302 of 793) | 37% (654 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 68% (13 of 19) | 68% (28 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3433 of 5151) | 55% (2742 of 4976) | 61% (6175 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 1.0 (21%) |
| MARCHED: its unit marched | 1.3 (36%) | 0.0 (0%) | 1.3 (29%) |
| CHARGED: its unit charged | 0.7 (18%) | 0.0 (0%) | 0.7 (14%) |
| IN COMBAT: engaged in combat | 1.0 (27%) | 0.0 (0%) | 1.0 (21%) |
| GONE: slain | 0.7 (18%) | 0.0 (0%) | 0.7 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.7 | 7.3 | 0.3 | 1.7 |
| not cast | 8.0 | 6.3 | 4.7 | 3.7 | 30.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 1.0 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 0.3 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 1.0 (21%) | 0.3 (9%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.3 (9%) | 0.3 (1%) |
| GONE: slain | 0.7 (8%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (45%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.3 (92%) | 5.7 (89%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.3 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.7 a game | 1.8 a game |
| stood (cast and not dispelled) | 83% (5 of 6) | 40% (2 of 5) | 64% (7 of 11) |
| the unit moved after it | 0% (0 of 5) | 100% (2 of 2) | 29% (2 of 7) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| the enemy charged it first | 20% (1 of 5) | 0% (0 of 2) | 14% (1 of 7) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | 100% (2 of 2) | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 40% (26 of 65) | 22% (2 of 9) | 38% (28 of 74) |
|   cavalry | - | 50% (2 of 4) | 50% (2 of 4) |
|   character | 100% (6 of 6) | 0% (0 of 5) | 55% (6 of 11) |
|   chariot | 42% (5 of 12) | - | 42% (5 of 12) |
|   infantry | 17% (6 of 35) | - | 17% (6 of 35) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (13%) | 0.7 (29%) | 2.3 (15%) |
| CHARGED: it charged | 0.3 (3%) | 0.7 (29%) | 1.0 (7%) |
| IN COMBAT: it fought this turn or the last | 1.7 (13%) | 0.3 (14%) | 2.0 (13%) |
| NO TARGET IN RANGE | 5.0 (38%) | 0.7 (29%) | 5.7 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 2.0 (15%) | 0.0 (0%) | 2.0 (13%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (13%) | 0.0 (0%) | 1.7 (11%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.0 | 1.7 | 0% | 26.0 pts | 26 pts |
| character | 2.0 | 1.3 | 83% | 2.0 pts | 4 pts |
| chariot | 1.7 | 1.7 | 60% | 19.0 pts | 32 pts |
| infantry | 2.0 | 1.3 | 67% | 5.1 pts | 10 pts |
| monster | 3.0 | 0.7 | 89% | 0.7 pts | 2 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 4.3 | 4.7 |
| Charges that made contact a game | 3.7 | 3.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.37 contact (27 units) | 0.48 declared, 0.36 contact (25 units) | 0.50 declared, 0.37 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 67% (2 of 3) | 0% (0 of 2) | 56% (5 of 9) |
| Character in a unit | 80% (4 of 5) | 100% (1 of 1) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 100% (3 of 3) | 100% (2 of 2) | 40% (2 of 5) | 70% (7 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 100% (1 of 1) | 100% (3 of 3) | - | 100% (4 of 4) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 83% (5 of 6) | 62% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 50% (1 of 2); on the table 100% | 33% (4 of 12) | 0% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 12% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 45% (5 of 11); on the table 45% | 75% (9 of 12) | 32% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 36% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (2) | 50% (4) | 33% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 73% (8 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (3 of 8) | 0% (0 of 6) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.3 | 2.3 |
| Movement | Points that never moved of their own | 163.3 | 56.7 |
| Movement | Fights charged into per game | 3.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 8, net +0 | 2 of 9, net -93 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +0 | 1 of 9, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 8, net +55 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 8, net +186 | 4 of 9, net +219 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (18 of 26) | 0% (0 of 4) |
| Shooting | Points destroyed by shooting units | 0.0 | 21.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 56% (5 of 9) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 2.0 | - |
| Magic | Wounds caused by other spells | 1.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 1.3 / 0.0 | 1.7 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 451.3 | 350.3 |
| Combat | Points run down | 68.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +71 | +69 |
| Combat | Net per 100 charger points, damage counted | +35.8 | +29.7 |
| Combat | First round won (charged fights) | 64% | 50% |
| Combat | Net points per charged fight | +87 | +44 |
| Combat | Net points per supported fight / lone fight | - / +87 | - / +44 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 11 | 3 of 10 |
| Game | Points lost | 447.3 | 469.7 |
| Game | VP from objectives | 773.3 | 533.3 |
| Game | Lone holders (player turns) | 1.7 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +239 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 917
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 22.0 | +51.2 | 0.0 | 64.0 | 21.7 | +697.9 | 0.0 | 220.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 3.0 | +94.3 | 0.0 | 22.7 | 1.3 | +28.9 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +68.3 | 0.0 | 0.0 | 2.3 | +7.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +34.1 | 0.0 | 0.0 | 0.7 | +13.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +28.8 | 0.0 | 0.0 | 0.7 | +4.1 | 0.0 | 16.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -12.4 | 0.0 | 68.3 |
| CHARACTERS BY THEIR POINTS | 0.7 | -35.5 | 0.0 | 0.0 | 1.0 | -78.4 | 64.0 | 68.3 |
| CHARGE LOSSES | 6.7 | -386.7 | 0.0 | 206.3 | 10.7 | -222.5 | 0.0 | 33.3 |
| CHARGE NOT DECLARED | 1.0 | +0.0 | 80.0 | 0.0 | 0.3 | +0.0 | 85.0 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 25.0 | 11.3 | 2.3 | +0.0 | 219.0 | 130.3 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 64.0 | 16.7 | +0.0 | 0.0 | 80.0 |
| COMBAT PIVOT | 1.3 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.0 | +242.9 | 0.0 | 0.0 | 1.3 | +30.1 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -57.2 | 0.0 | 21.7 | 3.0 | -227.6 | 0.0 | 16.7 |
| DEFENSIVE FLOOR | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.4 | 0.0 | 68.3 |
| DEPLOY BY FIGURES | 7.3 | -91.2 | 0.0 | 0.0 | 6.7 | +43.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.3 | 64.0 | 0.0 |
| EXACT ROUND | 2.0 | +4.8 | 25.0 | 11.3 | 2.3 | +16.0 | 163.3 | 124.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 73.0 | 0.0 | 3.3 | +4.9 | 149.0 | 147.0 |
| FALLS SHORT | - | - | - | - | 23.0 | +306.7 | 0.0 | 250.3 |
| FEATURE BUFFS | 1.7 | +63.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +9.1 | 0.0 | 11.3 | 2.0 | +14.3 | 0.0 | 147.0 |
| FIVE ACTION | 90.3 | +6891.2 | 135.0 | 921.7 | 83.0 | +5621.0 | 340.7 | 862.3 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 85.7 | 2.3 | +0.0 | 0.0 | 18.0 |
| FOLLOW UP WEIGHED | 1.0 | +131.6 | 0.0 | 0.0 | 1.3 | +283.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +162.6 | 135.0 | 11.3 | 4.3 | +176.2 | 297.3 | 209.0 |
| FREED FROM HIS FIGHT | 24.0 | +0.0 | 0.0 | 213.7 | 2.7 | +0.0 | 0.0 | 16.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -39.3 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -111.6 | 0.0 | 0.0 | 1.0 | -2.0 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -5.3 | 33.0 | 0.0 | 0.7 | -2.4 | 0.0 | 62.0 |
| GOAL WALK | 14.0 | +1066.1 | 0.0 | 107.7 | 11.3 | +1448.7 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | +0.6 | 0.0 | 11.3 | 1.7 | -6.4 | 78.3 | 85.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 10.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 206.3 | 3.0 | +0.0 | 0.0 | 33.3 |
| HIS CHARGE DENIED | 0.3 | +0.9 | 15.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 134.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -1.0 | 0.0 | 0.0 | 3.0 | -21.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 149.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 128.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 8.3 | +78.8 | 0.0 | 304.7 | 46.7 | +1109.2 | 0.0 | 540.0 |
| HIS SHOTS BY HIS RUN | 16.3 | +64.1 | 0.0 | 220.7 | 31.7 | +379.7 | 0.0 | 93.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +1.0 | 0.0 | 68.3 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 256.0 | 9.3 | +0.0 | 0.0 | 286.7 |
| HOLDER ASSIGNMENT | 11.0 | +940.8 | 0.0 | 128.0 | 6.3 | +517.9 | 0.0 | 143.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -55.5 | 135.0 | 11.3 | 4.0 | -91.2 | 297.3 | 140.7 |
| IDLE COST | - | - | - | - | 14.7 | -186.1 | 0.0 | 76.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +3.0 | 0.0 | 62.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.9 | 0.0 | 0.0 | 1.3 | +43.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.3 | +0.0 | 322.0 | 78.3 | 9.7 | +0.0 | 148.3 | 160.0 |
| LONG SHOT | 0.7 | +3.0 | 15.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -0.5 | 0.0 | 11.3 | 2.7 | +33.3 | 78.3 | 147.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.5 | 0.0 | 15.0 |
| MANOEUVRE | 1.3 | -1.3 | 0.0 | 64.0 | 1.3 | -0.2 | 0.0 | 143.3 |
| MARCH AT ESCAPER | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +55.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +12.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +19.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -79.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +14.3 | 0.0 | 0.0 | 3.3 | +100.4 | 0.0 | 30.0 |
| MEETS IN TIME | 4.7 | +279.3 | 0.0 | 0.0 | 2.7 | +216.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +149.4 | 0.0 | 0.0 | 3.3 | +9.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +77.3 | 0.0 | 0.0 | 3.3 | +4.9 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 64.0 | 5.0 | +0.0 | 0.0 | 25.0 |
| MOVE SPELL IN RANGE | 2.0 | +56.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.7 | -63.6 | 128.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.7 | +897.0 | 0.0 | 0.0 | 9.7 | +633.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +278.1 | 0.0 | 0.0 | 5.7 | +203.9 | 0.0 | 62.0 |
| NEXT CHARGE BY LIST | 5.0 | +719.4 | 0.0 | 0.0 | 5.7 | +449.1 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.0 | +67.9 | 117.0 | 0.0 | 1.0 | +5.1 | 64.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -60.1 | 120.0 | 11.3 | 3.3 | -114.1 | 297.3 | 192.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -2.2 | 0.0 | 0.0 | 2.0 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -136.2 | 0.0 | 0.0 | 3.7 | -190.6 | 0.0 | 16.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -53.7 | 0.0 | 21.7 | 6.0 | -172.8 | 0.0 | 158.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -4.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +58.4 | 0.0 | 128.0 | 3.7 | -28.2 | 0.0 | 143.3 |
| ONE PROMISE A TARGET | 1.3 | -84.1 | 0.0 | 0.0 | 1.0 | +52.2 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +27.3 | 15.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.0 | +58.7 | 102.0 | 0.0 | 0.3 | +3.9 | 64.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +65.1 | 33.0 | 0.0 | 1.0 | +4.5 | 0.0 | 68.3 |
| PATHS CROSS | - | - | - | - | 0.3 | +23.6 | 0.0 | 0.0 |
| PLAN RESULT | 43.3 | +109.4 | 0.0 | 582.3 | 42.0 | +287.6 | 70.0 | 851.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 62.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -482.8 | 0.0 | 0.0 | 14.3 | -320.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 8.0 | -199.8 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.3 | -2.1 | 0.0 | 16.7 |
| PURSUES BIG PREY | 0.3 | -62.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.7 | +2640.9 | 80.0 | 406.3 | 19.7 | +2506.2 | 185.7 | 16.7 |
| RANDOM MOVE BY FIGURES | 3.3 | +2.0 | 0.0 | 140.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +128.1 | 0.0 | 0.0 | 5.0 | +356.0 | 0.0 | 45.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +0.0 | 0.0 | 22.7 | 4.0 | +0.0 | 0.0 | 30.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 62.0 |
| REFORMS TO MEET IT | 0.3 | -6.6 | 0.0 | 0.0 | 1.3 | -41.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 280.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +5.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +55.6 | 73.0 | 11.3 | 3.7 | +55.7 | 134.0 | 209.0 |
| RISK ON THE WAY | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.7 | -43.5 | 142.3 | 78.7 |
| RUN DOWN | 0.3 | -1.3 | 0.0 | 0.0 | 3.3 | -48.6 | 227.3 | 192.3 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -47.5 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +42.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +62.4 | 70.0 | 62.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -0.3 | 0.0 | 0.0 | 3.3 | -541.0 | 0.0 | 286.7 |
| SET UP BY THE SET | 1.0 | +38.7 | 0.0 | 0.0 | 5.3 | +447.2 | 0.0 | 322.7 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.5 | 0.0 | 15.0 |
| SET-UP MISSED | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +17.9 | 0.0 | 21.7 | 0.7 | +2.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 4.0 | -6.3 | 0.0 | 44.3 | 26.3 | +23.6 | 0.0 | 250.7 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.3 | +128.8 | 0.0 | 21.7 | 1.0 | +17.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +9.6 | 0.0 | 0.0 | 2.0 | +18.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -20.7 | 85.0 | 0.0 |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 374.0 | 12.7 | +0.0 | 0.0 | 352.3 |
| STAND AND SHOOT | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 32.3 | +0.0 | 0.0 | 300.0 | 19.0 | +0.0 | 43.3 | 154.0 |
| STAY WORTH | 10.0 | +59.9 | 0.0 | 21.7 | 0.7 | +0.8 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 1.3 | +74.3 | 286.7 | 0.0 | 1.3 | +13.5 | 0.0 | 85.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.0 | -3.4 | 0.0 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +97.8 | 0.0 | 213.0 | 10.0 | +301.9 | 0.0 | 184.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 11.3 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +97.8 | 0.0 | 213.0 | 10.0 | +301.9 | 0.0 | 184.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.7 | +45.6 | 0.0 | 253.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | +1.1 | 0.0 | 11.3 | 1.7 | +41.6 | 142.3 | 68.3 |
| THE PROMISE ADDS | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 75.3 | 6.0 | +0.0 | 0.0 | 25.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.0 | +0.0 | 0.0 | 261.0 | 41.0 | +0.0 | 0.0 | 183.3 |
| TIED UP BY THE SUM | 1.0 | +101.6 | 58.0 | 0.0 | 0.7 | +88.9 | 70.0 | 62.0 |
| TIME ON OUR SIDE | 46.7 | +431.1 | 0.0 | 140.3 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 286.7 |
| WHAT THE JOINER ADDS | 0.7 | +3.1 | 0.0 | 0.0 | 1.0 | -11.4 | 0.0 | 62.0 |
| WHO FIGHTS | 0.7 | +4.2 | 0.0 | 0.0 | 1.3 | +9.8 | 78.3 | 124.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +5.3 | 0.0 | 62.0 |
| WHO HITS BACK | 0.3 | +45.0 | 0.0 | 0.0 | 0.3 | +30.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +9.3 | 0.0 | 62.0 |
| WHOLE FIGHT DANGER | 4.7 | -376.1 | 0.0 | 206.3 | 1.0 | -29.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.0 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.0 | +312.9 | 85.0 | 142.3 | 0.3 | +7.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.7 | +17.3 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 131 | 131 | 78 | 26.00 | +1932 | +24.8 |
| LEGAL CHARGES ONLY | 54 | 54 | 54 | 18.00 | +0 | +0.0 |
| FIVE ACTION | 520 | 502 | 49 | 16.33 | +2891 | +59.0 |
| HOLDER ASSIGNMENT | 52 | 52 | 49 | 16.33 | +2618 | +53.4 |
| HIS SHOT LIST | 165 | 155 | 37 | 12.33 | +256 | +6.9 |
| QUARTER ODDS | 133 | 127 | 30 | 10.00 | +2364 | +78.8 |
| PROMISE BY ITS OWN SUM | 69 | 69 | 27 | 9.00 | -2409 | -89.2 |
| DEPLOY BY FIGURES | 42 | 42 | 26 | 8.67 | +278 | +10.7 |
| HIS SHOTS BY HIS RUN | 144 | 140 | 25 | 8.33 | +93 | +3.7 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 49 | 43 | 24 | 8.00 | +844 | +35.1 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -981 | -49.0 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| GOAL WALK | 76 | 73 | 18 | 6.00 | +1435 | +79.7 |
| TIME ON OUR SIDE | 140 | 118 | 15 | 5.00 | +48 | +3.2 |
| CAST JOB | 15 | 15 | 14 | 4.67 | +67 | +4.8 |
| NEXT CHARGE BY LIST | 32 | 31 | 14 | 4.67 | +655 | +46.8 |
| FOUR ROUNDS | 23 | 23 | 12 | 4.00 | +282 | +23.5 |
| IDLE COST | 44 | 32 | 12 | 4.00 | +77 | +6.4 |
| SHOT RISK POINTS | 91 | 87 | 11 | 3.67 | +84 | +7.6 |
| NO CHAFF EDGES | 12 | 12 | 10 | 3.33 | +113 | +11.3 |
| MEETS IN TIME | 22 | 22 | 9 | 3.00 | +676 | +75.2 |
| SUPPORT ADDS | 43 | 41 | 9 | 3.00 | +316 | +35.1 |
| SUPPORT WORKED OUT | 43 | 41 | 9 | 3.00 | +316 | +35.1 |
| PROMISE KNOWS THE FIGHT | 32 | 29 | 8 | 2.67 | -599 | -74.9 |
| STRIKE BY THE ODDS | 8 | 8 | 8 | 2.67 | +264 | +32.9 |
| FALLS SHORT | 69 | 53 | 7 | 2.33 | +40 | +5.7 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1244 | +177.7 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -96 | -13.7 |
| RISK BY ARC | 19 | 19 | 7 | 2.33 | +112 | +15.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 11 | 11 | 5 | 1.67 | -221 | -44.3 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +150 | +29.9 |
| BACKS UP THE FIGHT | 13 | 12 | 4 | 1.33 | +173 | +43.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +98 | +24.6 |
| CHARGE LOSSES | 52 | 50 | 4 | 1.33 | +349 | +87.3 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 1.33 | -885 | -221.2 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 17 | 17 | 4 | 1.33 | +2 | +0.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 4 | 1.33 | +11 | +2.7 |
| REDIRECT COUNTER | 28 | 26 | 4 | 1.33 | +52 | +13.1 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +118 | +29.4 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +37 | +12.3 |
| EXACT ROUND | 13 | 13 | 3 | 1.00 | +14 | +4.7 |
| FACES WHAT IT FOLLOWS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REFUSING RETIRES | 6 | 6 | 3 | 1.00 | -25 | -8.3 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +128 | +42.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +13 | +4.3 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 5 | 5 | 2 | 0.67 | +2 | +1.2 |
| FIGHT TO THE END | 11 | 11 | 2 | 0.67 | +51 | +25.6 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +9 | +4.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +165 | +82.6 |
| MISSILES NEXT TURN | 22 | 13 | 2 | 0.67 | +3 | +1.6 |
| NEARER NOT NEEDED | 37 | 32 | 2 | 0.67 | +116 | +57.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +95 | +47.6 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +17 | +8.4 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +187 | +93.6 |
| SET UP BY THE SET | 19 | 17 | 2 | 0.67 | +348 | +174.1 |
| SURE REACH TOGETHER | 8 | 7 | 2 | 0.67 | +4 | +1.8 |
| WHO FIGHTS | 6 | 6 | 2 | 0.67 | +10 | +5.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +106 | +53.2 |
| WHOLE FIGHT | 3 | 3 | 2 | 0.67 | +5 | +2.7 |
| WHOLE FIGHT DANGER | 17 | 17 | 2 | 0.67 | +37 | +18.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +55 | +55.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +26 | +26.1 |
| LOST AFTER ESCAPE | 12 | 12 | 1 | 0.33 | +44 | +44.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -59 | -59.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE FIGHT FORMULA | 32 | 15 | 1 | 0.33 | +73 | +72.7 |
| ONE OBJECTIVE FORMULA | 24 | 18 | 1 | 0.33 | +108 | +107.9 |
| OPENS UP IN FULL | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +179 | +179.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +71 | +70.9 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +16 | +16.2 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +24 | +23.7 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -188 | -187.8 |
| ROUNDS AFTER TERROR | 8 | 8 | 1 | 0.33 | +2 | +2.2 |
| THE FIGHT MOVES | 8 | 8 | 1 | 0.33 | +6 | +6.1 |
| THE ROW IN ITS ORDER | 33 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +16 | +15.9 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 83 | 80 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| COVER ONCE | 15 | 10 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 80 | 77 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 9 | 9 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 34 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 22 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 14 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 85 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 22 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 22 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 256 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 11 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 19 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 31 | 16 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 70 | 59 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 154 | 148 | 0 | 0.00 | - | - |
| STAY WORTH | 32 | 23 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 3 | 3 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 13 | 11 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 240 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.33 | 89.2 |
| ARMY TABLE | rule | 4.00 | 2.33 | 55.6 |
| JOB FIRST | gate | 2.00 | 2.67 | 52.7 |
| PROMISE KNOWS THE FIGHT | rule | 2.33 | - | 85.6 |
| CHARGE NOW FIRST | rule | 0.33 | 1.33 | 44.3 |
| ONE PROMISE A TARGET | rule | 1.33 | 0.33 | 52.6 |
| CHARGE NOT DECLARED | rule | 1.00 | 0.33 | 221.2 |
| REFUSING RETIRES | rule | 0.33 | 0.67 | 8.3 |
| NO REASON | gate | 0.67 | - | 6.5 |
| AFTERMATH BAND | gate | - | 0.33 | 2.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 183.1 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.5 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 20.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 7.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 59.4 |
| PURSUES BIG PREY | rule | 0.33 | - | 187.8 |
| RULE SWITCHED OFF | gate | - | 0.33 | 41.6 |

### Plans: chf-efd8067-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 305 | 105 | 35% |
| Mine | move | 39.3 | 95% | 2267 | 0 | 0% |
| Mine | shoot | 1.0 | 33% | 33 | 4 | 12% |
| Opponent | charge | 4.0 | 58% | 466 | 252 | 54% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 33.3 | 95% | 2108 | 0 | 0% |
| Opponent | shoot | 1.3 | 75% | 183 | 36 | 19% |
| Opponent | support | 0.7 | 100% | 2 | 0 | 0% |

### Battle groups: chf-efd8067-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 5.0 | 40% | 67% | 33% | 0% | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 99 (7) | 0 | 99 | 10 | 57% | 4.7 | 145 (4) | 0 (1) | 0 (2) | 112 (6) | 0 (1) |
| Mine | Character | 6 | 37 (6) | 37 | 0 | 15 | 0% | 2.5 | 50 (2) | 0 (2) | 103 (1) | 80 (3) | 0 (2) |
| Mine | Clean-up | 2 | 65 (2) | 0 | 65 | 83 | 0% | 5.0 | 0 (1) | 78 (1) | - | 0 (1) | 78 (1) |
| Mine | Fast Hammer | 1 | 169 (1) | 169 | 0 | 0 | 0% | 3.0 | 169 (1) | - | - | 169 (1) | - |
| Mine | Hammer | 11 | 33 (11) | 21 | 12 | 30 | 0% | 2.7 | 0 (3) | 96 (4) | 0 (4) | 15 (9) | 92 (2) |
| Mine | Holder | 2 | 53 (2) | 0 | 53 | 0 | 50% | 2.0 | - | 343 (1) | 0 (1) | 53 (2) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 3.7 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 17 | 0% | 3.5 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 18 (9) | 0 | 18 | 32 | 56% | 3.0 | 0 (7) | 100 (2) | - | 24 (7) | 0 (2) |
| Opponent | Character | 10 | 38 (10) | 38 | 0 | 15 | 30% | 3.9 | 71 (5) | 0 (4) | - | 62 (4) | 22 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 8 | 41 (8) | 20 | 20 | 53 | 12% | 3.7 | 64 (2) | 36 (5) | 0 (1) | 44 (4) | 38 (4) |
| Opponent | Hammer | 2 | 24 (2) | 0 | 24 | 0 | 0% | 3.5 | - | 0 (1) | 37 (1) | 0 (1) | 37 (1) |
| Opponent | Holder | 1 | 76 (1) | 76 | 0 | 0 | 0% | 5.0 | - | - | 76 (1) | 76 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.7 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: chf-efd8067-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 45 | 3.0 | 1.0 | 15 | 0 | +15 | 1 of 3 | 2 of 3 | - | +15 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1073 | 7.0 | 1.0 | 153 | 22 | +131 | 0 of 7 | 5 of 7 | - | +131 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 0 | 373 | 3.7 | 1.0 | 102 | 14 | +87 | 1 of 11 | 7 of 11 | - | +87 |
| Opponent | Vampire Counts | 2 | 0 | 245 | 3.5 | 1.0 | 70 | 34 | +36 | 3 of 7 | 3 of 7 | - | +36 |
| Opponent | Warriors of Chaos | 1 | 65 | 387 | 3.0 | 1.0 | 129 | 68 | +61 | 0 of 3 | 2 of 3 | - | +61 |
| **Opponent** | all armies | 3 | 22 | 292 | 3.3 | 1.0 | 88 | 44 | +44 | 3 of 10 | 5 of 10 | - | +44 |

### Effective charges: chf-efd8067-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net +45) | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +0) | 0 | 3 (net +58) | 1 (net +186) | 2 | 20% (1 of 5) |
| Mine | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 7 | 2 (net -93) | 0 | 1 (net +0) | 0 | 0 | 3 (net +163) | 1 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 2 (net -102) | 0 | 1 (net +387) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 144 | 232 | +0 | 49 | 116 | -67 | -46.3 |
| Mine | Effective (55-75%) | 1 | 60 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 350 | 186 | +186 | 186 | 0 | +186 | +53.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 337 | 55 | +55 | 55 | 0 | +55 | +16.3 |
| Mine | No odds | 3 | 48 | 97 | +186 | 238 | 67 | +171 | +355.9 |
| Mine | All fights | 11 | 199 | 122 | +87 | 110 | 39 | +71 | +35.8 |
| Opponent | Long shot (under 50%) | 2 | 186 | 241 | -93 | 83 | 104 | -20 | -11.0 |
| Opponent | Effective (55-75%) | 1 | 186 | 235 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 2 | 264 | 197 | -102 | 49 | 111 | -61 | -23.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 300 | 186 | +219 | 227 | 0 | +227 | +75.5 |
| Opponent | No odds | 1 | 50 | 297 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 10 | 234 | 215 | +44 | 117 | 48 | +69 | +29.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p46 | move | 17 | 4 (24%) | 4 (24%) | 1 (6%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

# Doctrine scorecard: chf-efd8067-p32

### Scorecard: chf-efd8067-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | yes | 3 | 6 | 3 | 3 | 0 | 0 | 0 | 375 |
| L1431 | 3 | 1 | Mine | yes | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | yes | 4 | - | 2 | 0 | 4 | 0 | 0 | 340 |
| **Average** | | | Mine | 67% | 6.0 | 2.0 | 3.0 | 0.3 | 0.0 | 0.0 | 0.0 | 147.3 |
| **Average** | | | Opponent | 100% | 3.5 | 3.5 | 2.3 | 2.7 | 1.3 | 0.0 | 0.0 | 238.3 |

### KPIs: chf-efd8067-p32

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 11) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 25% (1 of 4); on the table 50% | 67% (6 of 9); on the table 78% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (7 of 7); on the table 100% | 43% (3 of 7); on the table 57% | 71% (10 of 14); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 11% (2 of 18) | 17% (4 of 24) | 14% (6 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 20% (2 of 10) | 18% (4 of 22) | 19% (6 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 57% (4 of 7) | 57% (4 of 7) |
| Points that never fought | lower | 33% (1987 of 6000) | 28% (1661 of 6000) | 30% (3648 of 12000) |
|   infantry points that never fought | lower | 56% (731 of 1315) | 20% (185 of 921) | 41% (916 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (11 of 25) | 78% (25 of 32) | 63% (36 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 50% (1 of 2); 0.7 uses a game | 75% (3 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 60% (6 of 10); 3.3 uses a game | 0.0 uses a game | 60% (6 of 10); 1.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2468 of 5720) | 77% (4485 of 5830) | 60% (6953 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (25%) | 1.0 (15%) | 2.3 (19%) |
| MARCHED: its unit marched | 1.0 (19%) | 1.0 (15%) | 2.0 (17%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.0 (19%) | 0.3 (5%) | 1.3 (11%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.0 (60%) | 4.0 (33%) |
| FLEEING: fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.3 (25%) | 0.3 (5%) | 1.7 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.7 | 2.3 | 2.0 | 0.0 | 2.3 |
| not cast | 3.0 | 2.3 | 3.7 | 12.0 | 2.0 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 2.3 (19%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (17%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (14%) | 0.7 (18%) | 1.3 (11%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (67%) | 0.0 (0%) | 2.0 (55%) | 4.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (11%) | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) | 0.0 (0%) | 1.3 (6%) |
| GONE: slain | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 1.7 (14%) | 1.3 (67%) | 4.7 (22%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (22%) | 0.0 (0%) | 0.7 (18%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.0 a game | 1.2 a game |
| stood (cast and not dispelled) | 57% (4 of 7) | - | 57% (4 of 7) |
| the unit moved after it | 75% (3 of 4) | - | 75% (3 of 4) |
| it charged on its next turn | 25% (1 of 4) | - | 25% (1 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (68 of 98) | 59% (13 of 22) | 68% (81 of 120) |
|   cavalry | 83% (10 of 12) | 64% (7 of 11) | 74% (17 of 23) |
|   character | 31% (10 of 32) | 33% (2 of 6) | 32% (12 of 38) |
|   infantry | 80% (24 of 30) | 80% (4 of 5) | 80% (28 of 35) |
|   war machine | 100% (24 of 24) | - | 100% (24 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (43%) | 2.3 (78%) | 6.7 (51%) |
| CHARGED: it charged | 3.0 (30%) | 0.3 (11%) | 3.3 (26%) |
| FLEEING: it fled or was fleeing | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.3 (11%) | 0.7 (5%) |
| NO TARGET IN RANGE | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.7 | 1.0 | 91% | 3.4 pts | 36 pts |
| character | 6.3 | 1.0 | 84% | 3.6 pts | 23 pts |
| infantry | 16.3 | 4.0 | 84% | 6.2 pts | 101 pts |
| war machine | 8.0 | 6.0 | 54% | 23.8 pts | 190 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.3 | 2.7 | 4.5 |
| Charges that made contact a game | 4.7 | 1.7 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | - | 1.00 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.73 declared, 0.55 contact (22 units) | 0.35 declared, 0.22 contact (23 units) | 0.53 declared, 0.38 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (5 of 15) | 100% (2 of 2) | - | 41% (7 of 17) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | 75% (3 of 4) | 75% (3 of 4) | 43% (3 of 7) | 60% (9 of 15) |
| Infantry | 75% (9 of 12) | 50% (1 of 2) | - | 71% (10 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (7 of 7); on the table 100% | 11% (2 of 18) | 33% | 44% (11 of 25) | 100% (2 of 2); 3.3 uses a game | 60% (6 of 10); 3.3 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 33% | 100% (8 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 4); on the table 25% | 33% (2 of 6) | 0% | 67% (8 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 50% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 59% (10 of 17) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (16 of 40) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | 67% (4 of 6) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | - | 80% (4 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.7 |
| Movement | Points that never moved of their own | 147.3 | 238.3 |
| Movement | Fights charged into per game | 3.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 8, net +0 | 2 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 8, net +120 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +132 | 0 of 4 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (16 of 44) | 79% (11 of 14) |
| Shooting | Points destroyed by shooting units | 93.3 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (12 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 4.0 | - |
| Magic | Wounds caused by other spells | 5.7 | - |
| Magic | Points destroyed by magic (all spells) | 119.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 2.0 / 0.0 | 1.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 288.7 | 330.0 |
| Combat | Points run down | 437.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +122 | +52 |
| Combat | Net per 100 charger points, damage counted | +30.5 | +20.9 |
| Combat | First round won (charged fights) | 70% | 80% |
| Combat | Net points per charged fight | +149 | +12 |
| Combat | Net points per supported fight / lone fight | +175 / +142 | - / +12 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 10 | 4 of 5 |
| Game | Points lost | 296.7 | 1025.0 |
| Game | VP from objectives | 853.3 | 376.7 |
| Game | Lone holders (player turns) | 6.0 | 3.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1305 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1322
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +367.8 | 0.0 | 0.0 |
| ARMY TABLE | 30.0 | +418.4 | 0.0 | 47.7 | 21.0 | +84.7 | 0.0 | 209.0 |
| ASSAILMENT BY POINTS | 0.7 | +2.0 | 0.0 | 333.3 | - | - | - | - |
| BACKS UP THE FIGHT | 3.3 | +273.6 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | 0.7 | +1.2 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 36.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +64.4 | 73.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +13.1 | 46.7 | 0.0 | 0.7 | +45.6 | 333.3 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +5.4 | 0.0 | 0.0 | 1.0 | +13.2 | 0.0 | 116.7 |
| CHALLENGE IN THE FIGHT | 1.3 | -134.1 | 116.7 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.4 | 116.7 | 0.0 | 0.3 | -1.4 | 0.0 | 48.0 |
| CHARACTERS BY THEIR POINTS | 1.0 | -238.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.7 | -492.9 | 0.0 | 47.7 | 21.0 | -1620.7 | 0.0 | 821.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 4.0 | +0.0 | 508.7 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 120.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +135.8 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 6.0 | -319.9 | 0.0 | 0.0 | 4.7 | -432.5 | 0.0 | 120.3 |
| DENIED BY THE FIGHT | 1.7 | -12.9 | 346.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.7 | -7.2 | 0.0 | 0.0 | 7.0 | +48.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +1.4 | 46.7 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.5 | 0.0 | 116.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 6.3 | +2632.0 | 115.7 | 42.0 |
| EXACT ROUND | 2.3 | +17.1 | 463.3 | 0.0 | 0.7 | +12.3 | 282.3 | 38.7 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 166.7 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.0 | +3.7 | 314.0 | 0.0 | 1.3 | +0.0 | 282.3 | 86.7 |
| FALLS SHORT | - | - | - | - | 17.7 | +328.4 | 0.0 | 448.7 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +124.0 | 116.7 | 0.0 | 0.3 | +0.4 | 0.0 | 48.0 |
| FIRE AND FLEE | - | - | - | - | 0.7 | +18.7 | 0.0 | 76.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 100.3 | +8074.9 | 1772.7 | 510.3 | 58.0 | +3014.4 | 615.7 | 1412.0 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +219.9 | 0.0 | 166.7 | 0.3 | +27.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.0 | +334.2 | 898.0 | 0.0 | 1.7 | +145.8 | 282.3 | 86.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 320.0 |
| FRIEND CHARGES FIRST | 0.3 | -18.4 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -9.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +3.1 | 0.0 | 47.7 | - | - | - | - |
| GIVES UP | 0.3 | -5.4 | 116.7 | 0.0 | - | - | - | - |
| GOAL WALK | 6.0 | +529.2 | 0.0 | 0.0 | 11.3 | +690.4 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | +0.0 | 77.3 | 0.0 | 1.0 | +0.4 | 115.7 | 48.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 152.7 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 782.7 |
| HIS CHARGE DENIED | 1.7 | +29.7 | 583.3 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 83.7 |
| HIS MOVE AND SHOT | 6.3 | -44.7 | 0.0 | 47.7 | 4.7 | -20.5 | 0.0 | 171.3 |
| HIS ONE QUARTER | 6.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 134.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 381.0 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 47.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +930.6 | 0.0 | 510.3 | 36.3 | +720.1 | 0.0 | 943.3 |
| HIS SHOTS BY HIS RUN | 36.0 | +733.9 | 0.0 | 510.3 | 44.7 | +944.9 | 0.0 | 1152.0 |
| HIS TURN DENIED | 1.3 | +70.9 | 159.3 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 339.3 |
| HOLDER ASSIGNMENT | 9.3 | +574.9 | 0.0 | 0.0 | 5.0 | +303.8 | 0.0 | 169.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -157.0 | 314.7 | 0.0 | 1.0 | -8.0 | 115.7 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +189.9 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +197.7 | 166.7 | 38.7 |
| IDLE COST | - | - | - | - | 9.7 | -130.6 | 0.0 | 80.3 |
| JOINT CHARGE NOW | 3.0 | -21.2 | 736.7 | 0.0 | 0.3 | -22.3 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +30.7 | 116.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 167.3 |
| LANE BY FIGURES | 1.3 | +134.5 | 0.0 | 0.0 | 0.7 | +21.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 391.3 | 166.7 | 4.7 | +0.0 | 0.0 | 908.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +5.8 | 38.0 | 0.0 | 0.3 | +7.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +0.6 | 350.7 | 0.0 | 1.0 | -1.4 | 115.7 | 48.0 |
| LOST CHARGE | 0.7 | -3.0 | 153.3 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +10.5 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.0 | +32.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.2 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +74.3 | 0.0 | 83.7 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +19.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -14.2 | 0.0 | 0.0 | 1.7 | +539.7 | 0.0 | 83.7 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.3 | +63.1 | 0.0 | 0.0 | 0.7 | +23.1 | 0.0 | 42.0 |
| MEETS IN TIME | 2.7 | +193.0 | 0.0 | 0.0 | 3.7 | +48.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +66.5 | 0.0 | 0.0 | 5.0 | +166.9 | 0.0 | 77.3 |
| MISSILES NEXT TURN | 5.3 | +40.1 | 0.0 | 0.0 | 6.3 | +110.0 | 0.0 | 122.3 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 11.3 | +1296.8 | 0.0 | 0.0 | 6.0 | +369.6 | 0.0 | 297.3 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +251.4 | 0.0 | 0.0 | 4.7 | +215.1 | 0.0 | 78.0 |
| NEXT CHARGE BY LIST | 7.0 | +928.1 | 0.0 | 0.0 | 4.0 | +245.3 | 0.0 | 180.0 |
| NO CHAFF EDGES | 4.7 | +171.5 | 170.0 | 166.7 | 1.3 | +14.6 | 0.0 | 161.3 |
| NO DOUBLE ROUNDS | 4.7 | -389.0 | 548.0 | 0.0 | 1.3 | -73.0 | 282.3 | 86.7 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +57.9 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -149.4 | 0.0 | 0.0 | 2.0 | -92.5 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 1.3 | -2.5 | 194.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 77.3 |
| ONE FIGHT FORMULA | 7.7 | -145.3 | 0.0 | 0.0 | 4.0 | -87.9 | 0.0 | 167.3 |
| ONE JOINT FIGURE | 1.7 | +120.6 | 583.3 | 0.0 | 0.3 | +15.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -11.9 | 0.0 | 0.0 | 2.0 | +3.6 | 0.0 | 86.0 |
| ONE PROMISE A TARGET | 0.3 | -24.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.3 | +25.2 | 40.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +36.0 | 239.3 | 0.0 | 0.3 | +0.8 | 166.7 | 38.7 |
| PATHS CROSS | - | - | - | - | 0.3 | +20.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -5.1 | 0.0 | 83.7 |
| PLAN RESULT | 44.3 | +1574.0 | 450.0 | 493.3 | 29.0 | +429.5 | 115.7 | 1034.0 |
| PROMISE BY ITS OWN SUM | 11.0 | -481.3 | 0.0 | 0.0 | 6.0 | -79.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 3.3 | -4.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -26.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 33.7 | +3441.0 | 530.7 | 462.7 | 13.3 | +2107.4 | 115.7 | 268.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.3 | +7.9 | 0.0 | 226.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +35.3 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.3 | -140.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 134.7 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +10.4 | 0.0 | 0.0 |
| RISK BY ARC | 5.3 | +98.6 | 820.7 | 0.0 | 1.0 | +21.6 | 166.7 | 86.7 |
| ROUNDS AFTER TERROR | 0.7 | -11.8 | 0.0 | 0.0 | 0.3 | -2.3 | 115.7 | 0.0 |
| RUN DOWN | 5.0 | -256.1 | 664.7 | 0.0 | 1.0 | -5.6 | 166.7 | 86.7 |
| SAME CHARGE LATER | 0.3 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -90.8 | 0.0 | 0.0 | 0.7 | -14.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +193.3 | 0.0 | 0.0 | 0.7 | +22.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 2.3 | +40.0 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +130.3 | 226.7 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -32.1 | 154.7 | 0.0 | 0.3 | -11.2 | 166.7 | 38.7 |
| SHOT RISK POINTS | 23.0 | -281.6 | 0.0 | 279.0 | 21.3 | -472.5 | 0.0 | 664.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.3 | +579.9 | 0.0 | 115.7 | 3.3 | +106.1 | 0.0 | 121.3 |
| SPELL SETS UP CHARGE | 0.3 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.3 | +101.9 | 0.0 | 0.0 | 1.7 | +31.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 2.3 | +20.4 | 423.3 | 0.0 | 0.7 | -10.0 | 166.7 | 38.7 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 47.7 | 9.7 | +0.0 | 0.0 | 364.0 |
| STAND AND SHOOT | 1.0 | -15.1 | 112.7 | 0.0 | 0.7 | -3.5 | 115.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 83.7 |
| STANDS STILL | 49.0 | +0.0 | 874.7 | 231.3 | 13.7 | +0.0 | 333.3 | 363.3 |
| STAY WORTH | 35.3 | +110.6 | 258.0 | 0.0 | 5.0 | +46.3 | 0.0 | 36.7 |
| STOPS | - | - | - | - | 0.3 | +2.6 | 166.7 | 38.7 |
| STRIKE BY THE ODDS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.0 | +756.7 | 0.0 | 47.7 | 5.7 | +271.3 | 0.0 | 167.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 7.0 | +756.7 | 0.0 | 47.7 | 5.7 | +271.3 | 0.0 | 167.3 |
| SURE REACH TOGETHER | 3.0 | +25.0 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | -5.7 | 0.0 | 83.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 3.3 | +159.5 | 705.3 | 0.0 | 0.3 | +0.3 | 0.0 | 48.0 |
| THE PROMISE ADDS | 0.7 | -26.6 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 231.3 | 27.0 | +0.0 | 0.0 | 529.3 |
| TIED UP BY THE SUM | 1.7 | +174.8 | 124.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 38.3 | +449.6 | 38.0 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| WHO FIGHTS | 1.0 | +1.0 | 193.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.0 | +163.5 | 0.0 | 166.7 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -59.7 | 0.0 | 0.0 | 4.3 | -898.3 | 0.0 | 379.3 |
| WHOLE FIGHT GAIN | 1.7 | +152.7 | 583.3 | 0.0 | 0.3 | +22.3 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +396.5 | 78.7 | 282.3 | 3.3 | +558.1 | 0.0 | 281.7 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.0 | +212.8 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 153 | 153 | 106 | 35.33 | +1563 | +14.7 |
| HIS SHOT LIST | 204 | 197 | 53 | 17.67 | +573 | +10.8 |
| HIS SHOTS BY HIS RUN | 242 | 231 | 46 | 15.33 | +507 | +11.0 |
| HOLDER ASSIGNMENT | 43 | 43 | 38 | 12.67 | +2345 | +61.7 |
| FIVE ACTION | 475 | 461 | 26 | 8.67 | +1231 | +47.4 |
| LEGAL CHARGES ONLY | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| QUARTER ODDS | 141 | 137 | 25 | 8.33 | +3324 | +133.0 |
| SHOT RISK POINTS | 133 | 123 | 25 | 8.33 | +591 | +23.7 |
| DEPLOY BY FIGURES | 41 | 41 | 24 | 8.00 | +227 | +9.5 |
| MOVE TO CHARGE COMPUTED | 52 | 42 | 24 | 8.00 | +808 | +33.7 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -726 | -36.3 |
| NEXT CHARGE BY LIST | 33 | 30 | 18 | 6.00 | +668 | +37.1 |
| PROMISE BY ITS OWN SUM | 51 | 51 | 16 | 5.33 | -1683 | -105.2 |
| NO CHAFF EDGES | 18 | 18 | 15 | 5.00 | +497 | +33.2 |
| CHARGE LOSSES | 116 | 107 | 14 | 4.67 | +2087 | +149.1 |
| FOUR ROUNDS | 23 | 23 | 12 | 4.00 | +464 | +38.7 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 19 | 19 | 11 | 3.67 | +4620 | +420.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 115 | 95 | 11 | 3.67 | +78 | +7.0 |
| JOINT CHARGE NOW | 10 | 10 | 10 | 3.33 | -130 | -13.1 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SUPPORT ADDS | 38 | 36 | 9 | 3.00 | +368 | +40.9 |
| SUPPORT WORKED OUT | 38 | 36 | 9 | 3.00 | +368 | +40.9 |
| GOAL WALK | 52 | 52 | 8 | 2.67 | +801 | +100.2 |
| RISK BY ARC | 19 | 19 | 7 | 2.33 | +324 | +46.3 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +56 | +9.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +466 | +77.8 |
| MEETS IN TIME | 19 | 19 | 6 | 2.00 | +162 | +27.0 |
| STAY WORTH | 121 | 99 | 6 | 2.00 | +99 | +16.5 |
| FALLS SHORT | 53 | 49 | 5 | 1.67 | +32 | +6.4 |
| BACKS UP THE FIGHT | 10 | 7 | 4 | 1.33 | +204 | +50.9 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +20 | +5.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +741 | +185.3 |
| MISSILES IN THE MOVE | 28 | 22 | 4 | 1.33 | +27 | +6.9 |
| ONE JOINT FIGURE | 6 | 6 | 4 | 1.33 | +102 | +25.4 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 4 | 1.33 | +24 | +6.0 |
| REFUSING RETIRES | 7 | 7 | 4 | 1.33 | -112 | -28.1 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +59 | +14.9 |
| WHOLE FIGHT GAIN | 6 | 6 | 4 | 1.33 | +102 | +25.4 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 9 | 9 | 3 | 1.00 | +48 | +15.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +303 | +101.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +46 | +15.4 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +5 | +1.7 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SET UP BY THE SET | 5 | 5 | 3 | 1.00 | +725 | +241.6 |
| SURE REACH TOGETHER | 10 | 8 | 3 | 1.00 | +19 | +6.2 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +325 | +108.5 |
| WHOLE FIGHT REACTION | 17 | 17 | 3 | 1.00 | +173 | +57.7 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +1103 | +551.6 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| CHARGE NOW FIRST | 13 | 13 | 2 | 0.67 | -96 | -47.9 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 5 | 2 | 0.67 | +116 | +57.8 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.67 | +56 | +28.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 29 | 18 | 2 | 0.67 | +7 | +3.4 |
| PROMISE KNOWS THE FIGHT | 11 | 7 | 2 | 0.67 | -13 | -6.7 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +31 | +15.7 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 77 | 48 | 2 | 0.67 | +26 | +13.2 |
| THE FIGHT MOVES | 11 | 11 | 2 | 0.67 | +116 | +57.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -4 | -4.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 32 | 20 | 1 | 0.33 | +18 | +18.5 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +60 | +60.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +18 | +18.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +9 | +9.3 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.33 | +0 | +0.5 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +57 | +56.6 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +92 | +92.2 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +5 | +5.0 |
| MARCH CHECK | 5 | 5 | 1 | 0.33 | +48 | +47.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -60 | -59.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 30 | 27 | 1 | 0.33 | +29 | +28.7 |
| NO DOUBLE ROUNDS | 18 | 18 | 1 | 0.33 | +53 | +53.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +65 | +65.1 |
| ONE CHALLENGE TEST | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 17 | 11 | 1 | 0.33 | +7 | +7.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -75 | -74.8 |
| OPENS UP IN FULL | 4 | 4 | 1 | 0.33 | +15 | +14.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +62 | +62.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -15 | -15.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +298 | +298.5 |
| RUN DOWN | 18 | 18 | 1 | 0.33 | +53 | +53.2 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +11 | +10.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SPELLS IN THE FIGHT | 9 | 9 | 1 | 0.33 | +0 | +0.5 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -17 | -17.0 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +0 | +0.5 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 36 | 36 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 17 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 18 | 16 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 77 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 33 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 42 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 40 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 65 | 65 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 16 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 28 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 220 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 188 | 186 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 222 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 11 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 20 | 20 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.00 | 35.6 |
| ARMY TABLE | rule | 3.67 | 2.00 | 35.7 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 1.00 | 105.2 |
| JOINT CHARGE NOW | rule | 1.67 | 0.33 | 63.0 |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 19.1 |
| REFUSING RETIRES | rule | 0.67 | 0.33 | 37.4 |
| CHARGE NOW FIRST | rule | 0.67 | - | 47.9 |
| NO REASON | gate | 0.67 | - | 42.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 6.7 |
| CHAFF PASSED | rule | 0.33 | - | 4.0 |
| MARCH OF THE TABLE | rule | - | 0.33 | 59.7 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 74.8 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 15.3 |
| SWIFTSTRIDE BY POINTS | rule | - | 0.33 | 17.0 |

### Plans: chf-efd8067-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.3 | 62% | 555 | 816 | 147% |
| Mine | move | 29.7 | 97% | 2488 | 0 | 0% |
| Mine | shoot | 9.3 | 79% | 258 | 757 | 294% |
| Opponent | charge | 1.0 | 100% | 57 | 263 | 463% |
| Opponent | join | 1.0 | 100% | 42 | 0 | 0% |
| Opponent | move | 25.7 | 91% | 1375 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 42 | 167 | 394% |

### Packages: hunt the guns, chf-efd8067-p32

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 593 | 570 | 100% | 18 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 593 | 570 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: chf-efd8067-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 34 (8) | 34 | 0 | 29 | 0% | 2.5 | 69 (3) | 20 (5) | - | 95 (2) | 18 (6) |
| Mine | Clean-up | 2 | 85 (2) | 0 | 85 | 0 | 0% | 1.5 | - | 85 (2) | - | 85 (2) | - |
| Mine | Fast Hammer | 8 | 167 (8) | 129 | 38 | 12 | 38% | 3.8 | 47 (4) | 290 (4) | - | 63 (3) | 231 (5) |
| Mine | Holder | 2 | 57 (2) | 25 | 33 | 0 | 50% | 1.0 | 57 (2) | - | - | 57 (2) | - |
| Mine | Shooter | 5 | 41 (5) | 41 | 0 | 0 | 0% | 1.0 | 57 (3) | 16 (2) | - | 51 (4) | 0 (1) |
| Mine | War machine | 4 | 20 (4) | 20 | 0 | 0 | 0% | 1.0 | 0 (2) | 39 (2) | - | 0 (2) | 39 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 24 (9) | 24 | 0 | 56 | 0% | 2.8 | 0 (5) | 70 (3) | - | 0 (4) | 58 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 100% | - | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 21 (3) | 0 | 21 | 36 | 0% | 2.7 | 21 (3) | - | - | 95 (1) | 0 (2) |
| Opponent | Hammer | 8 | 36 (8) | 36 | 0 | 44 | 38% | 3.0 | 0 (4) | 102 (3) | 0 (1) | 61 (4) | 0 (4) |
| Opponent | Holder | 3 | 29 (3) | 0 | 29 | 100 | 0% | 4.3 | - | 0 (1) | 42 (2) | 21 (1) | 34 (2) |
| Opponent | Shooter | 3 | 16 (3) | 0 | 16 | 100 | 0% | 1.0 | - | 53 (1) | 0 (2) | - | 16 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 4.0 | 0 (2) | - | - | - | 0 (2) |

### Charged fights: chf-efd8067-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 213 | 710 | 3.3 | 1.4 | 213 | 64 | +149 | 5 of 10 | 7 of 10 | +175 | +142 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 144 | -144 | 2 of 2 | 2 of 2 | - | -144 |
| Opponent | Wood Elf Realms | 1 | 0 | 347 | 2.0 | 1.0 | 174 | 0 | +174 | 2 of 2 | 1 of 2 | - | +174 |
| **Opponent** | all armies | 3 | 0 | 116 | 1.7 | 1.0 | 69 | 58 | +12 | 4 of 5 | 4 of 5 | - | +12 |

### Effective charges: chf-efd8067-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 10 | 1 (net +0) | 0 | 2 (net +0) | 2 (net +287) | 1 (net +120) | 2 (net +132) | 2 | 25% (2 of 8) |
| Opponent | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 1 (net -288) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 1 (net +0) | 0 | 0 | 1 (net +347) | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | +0 | 79 | 229 | -149 | -37.4 |
| Mine | Effective (55-75%) | 2 | 489 | 201 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 2 | 658 | 230 | +287 | 361 | 100 | +261 | +39.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 270 | 128 | +132 | 132 | 0 | +132 | +49.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 489 | 120 | +120 | 120 | 0 | +120 | +24.5 |
| Mine | No odds | 2 | 143 | 186 | +264 | 585 | 352 | +233 | +162.8 |
| Mine | All fights | 10 | 401 | 195 | +149 | 236 | 113 | +122 | +30.5 |
| Opponent | Long shot (under 50%) | 2 | 120 | 421 | +0 | 0 | 9 | -9 | -7.4 |
| Opponent | 76-89% | 2 | 322 | 212 | +30 | 204 | 144 | +60 | +18.6 |
| Opponent | No odds | 1 | 350 | 230 | +0 | 156 | 0 | +156 | +44.7 |
| Opponent | All fights | 5 | 247 | 299 | +12 | 113 | 61 | +52 | +20.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p32 | move | 26 | 5 (19%) | 4 (15%) | 5 (19%) | 16 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

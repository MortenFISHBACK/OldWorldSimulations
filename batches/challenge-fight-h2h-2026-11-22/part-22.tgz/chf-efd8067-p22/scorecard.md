# Doctrine scorecard: chf-efd8067-p22

### Scorecard: chf-efd8067-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 77 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 235 |
| L1927 | 1 | 1 | Opponent | no | 9 | 2 | 5 | 2 | 0 | 0 | 0 | 50 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.3 | 2.5 | 2.3 | 0.7 | 0.0 | 0.0 | 0.0 | 104.0 |
| **Average** | | | Opponent | 0% | 3.7 | 2.3 | 3.3 | 2.3 | 0.3 | 0.0 | 0.0 | 73.3 |

### KPIs: chf-efd8067-p22

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 18) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 100% (7 of 7); on the table 100% | 100% (12 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (6 of 6); on the table 100% | 83% (10 of 12); on the table 83% | 89% (16 of 18); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 42% (10 of 24) | 42% (5 of 12) | 42% (15 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (10 of 18) | 50% (5 of 10) | 54% (15 of 28) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (5 of 10) | 50% (1 of 2) | 50% (6 of 12) |
| Points that never fought | lower | 28% (1705 of 5999) | 33% (1950 of 5999) | 30% (3655 of 11998) |
|   infantry points that never fought | lower | 61% (604 of 993) | 70% (553 of 793) | 65% (1157 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 41% (9 of 22) | 47% (9 of 19) | 44% (18 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2279 of 5151) | 38% (1868 of 4976) | 41% (4147 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (21%) | 1.3 (57%) | 2.3 (33%) |
| MARCHED: its unit marched | 1.7 (36%) | 0.0 (0%) | 1.7 (24%) |
| IN COMBAT: engaged in combat | 0.7 (14%) | 0.3 (14%) | 1.0 (14%) |
| GONE: slain | 0.0 (0%) | 0.3 (14%) | 0.3 (5%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (29%) | 0.0 (0%) | 1.3 (19%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (14%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 4.0 | 5.0 | 0.3 | 2.7 |
| not cast | 8.0 | 6.0 | 7.0 | 3.7 | 29.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 2.3 (33%) | 1.7 (45%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (24%) | 0.3 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (6%) | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.0 (25%) | 0.3 (6%) | 0.3 (5%) | 0.3 (9%) | 1.0 (3%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (12%) | 0.7 (11%) | 1.3 (19%) | 0.0 (0%) | 1.7 (6%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 1.3 (36%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (62%) | 4.7 (78%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 1.7 a game | 2.0 a game |
| stood (cast and not dispelled) | 57% (4 of 7) | 60% (3 of 5) | 58% (7 of 12) |
| the unit moved after it | 0% (0 of 4) | 100% (3 of 3) | 43% (3 of 7) |
| it charged on its next turn | 0% (0 of 4) | 0% (0 of 3) | 0% (0 of 7) |
| the enemy charged it first | 25% (1 of 4) | 0% (0 of 3) | 14% (1 of 7) |
| it fought by the end of its next turn | 0% (0 of 4) | 0% (0 of 3) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | 0% (0 of 3) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | 100% (3 of 3) | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (38 of 60) | 0% (0 of 7) | 57% (38 of 67) |
|   cavalry | - | 0% (0 of 2) | 0% (0 of 2) |
|   character | 100% (6 of 6) | 0% (0 of 5) | 55% (6 of 11) |
|   chariot | 71% (5 of 7) | - | 71% (5 of 7) |
|   infantry | 54% (19 of 35) | - | 54% (19 of 35) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (32%) | 0.3 (14%) | 2.7 (28%) |
| CHARGED: it charged | 0.3 (5%) | 0.7 (29%) | 1.0 (10%) |
| IN COMBAT: it fought this turn or the last | 1.7 (23%) | 0.3 (14%) | 2.0 (21%) |
| NO TARGET IN RANGE | 3.0 (41%) | 1.0 (43%) | 4.0 (41%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 2.0 | 1.0 | 83% | 15.8 pts | 32 pts |
| chariot | 1.7 | 1.0 | 60% | 23.8 pts | 40 pts |
| infantry | 6.3 | 3.0 | 63% | 11.8 pts | 75 pts |
| monster | 2.7 | 1.3 | 75% | 2.6 pts | 7 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.0 | 4.3 |
| Charges that made contact a game | 2.0 | 3.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.75 contact (4 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.37 declared, 0.19 contact (27 units) | 0.46 declared, 0.33 contact (24 units) | 0.41 declared, 0.25 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 67% (2 of 3) | 0% (0 of 2) | 44% (4 of 9) |
| Character in a unit | 67% (2 of 3) | - | 100% (1 of 1) | 75% (3 of 4) |
| Character on its own | 20% (1 of 5) | 33% (1 of 3) | 20% (1 of 5) | 23% (3 of 13) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 25% (1 of 4) | 0% (0 of 1) | - | 20% (1 of 5) |
| Monster | 100% (1 of 1) | 67% (2 of 3) | - | 75% (3 of 4) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | - | 83% (5 of 6) | 44% | 57% (4 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 6% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 36% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 82% (9 of 11); on the table 82% | 42% (5 of 12) | 30% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 38% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (3) | 0% (0) | 21% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 54% (7 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 11) | 0% (0 of 1) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 100% (2 of 2) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 67% (8 of 12) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 104.0 | 73.3 |
| Movement | Fights charged into per game | 2.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +0 | 2 of 8, net -10 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 3, net +162 | 1 of 8, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 4 of 8, net +284 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (21 of 38) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 20.0 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 2.7 | - |
| Magic | Wounds caused by other spells | 2.0 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 62.0 | 11.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 1.0 / 0.0 | 1.3 / 0.0 / 1.7 / 0.3 |
| Combat | Points destroyed in combat | 315.3 | 161.3 |
| Combat | Points run down | 68.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +43 | +97 |
| Combat | Net per 100 charger points, damage counted | +24.2 | +41.9 |
| Combat | First round won (charged fights) | 50% | 60% |
| Combat | Net points per charged fight | +39 | +110 |
| Combat | Net points per supported fight / lone fight | - / +39 | -275 / +153 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 4 of 10 |
| Game | Points lost | 749.7 | 502.3 |
| Game | VP from objectives | 636.7 | 780.0 |
| Game | Lone holders (player turns) | 1.3 | 3.7 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -441 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1252
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +13.9 | 0.0 | 0.0 |
| ARMY TABLE | 24.0 | +482.4 | 0.0 | 128.3 | 21.0 | +585.4 | 0.0 | 372.7 |
| ASSAILMENT BY POINTS | 0.3 | +3.1 | 0.0 | 108.7 | 1.0 | +2.9 | 0.0 | 126.7 |
| BACKS UP THE FIGHT | 3.3 | +108.2 | 0.0 | 11.3 | 5.7 | +193.4 | 0.0 | 83.3 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +71.4 | 62.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +52.2 | 0.0 | 35.0 | 3.7 | +141.2 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | +17.9 | 0.0 | 16.7 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.7 | -28.9 | 114.3 | 68.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -17.3 | 0.0 | 0.0 | 0.3 | -14.2 | 0.0 | 68.3 |
| CHARACTERS BY THEIR POINTS | 0.3 | -35.0 | 0.0 | 0.0 | 1.3 | -70.5 | 114.3 | 130.3 |
| CHARGE LIST READ AGAIN | 0.3 | +19.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.3 | -256.5 | 0.0 | 240.0 | 14.7 | -824.9 | 0.0 | 197.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 20.0 | 11.3 | 2.3 | +0.0 | 262.7 | 0.0 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 70.0 |
| COMBAT PIVOT | 1.3 | +0.0 | 0.0 | 193.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.3 | +298.1 | 0.0 | 0.0 | 1.7 | +39.1 | 0.0 | 0.0 |
| COVER ONCE | 5.7 | -243.4 | 0.0 | 21.7 | 4.0 | -138.0 | 0.0 | 121.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.1 | 0.0 | 16.7 |
| DEPLOY BY FIGURES | 7.3 | -91.2 | 0.0 | 0.0 | 6.7 | +43.3 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | -1.3 | 0.0 | 11.3 | 2.7 | +28.3 | 185.0 | 16.7 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 35.0 | 0.0 | 3.0 | +0.0 | 123.3 | 68.3 |
| FALLS SHORT | - | - | - | - | 20.7 | +245.8 | 0.0 | 173.7 |
| FEATURE BUFFS | 1.0 | +23.6 | 0.0 | 78.3 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +19.7 | 0.0 | 11.3 | 1.3 | +60.6 | 114.3 | 0.0 |
| FIVE ACTION | 86.3 | +7343.4 | 221.0 | 926.0 | 79.0 | +6570.0 | 392.7 | 965.7 |
| FLANK NOT WEIGHED | 14.3 | +0.0 | 0.0 | 137.7 | 4.3 | +0.0 | 0.0 | 16.7 |
| FOLLOW UP WEIGHED | 0.3 | +52.1 | 0.0 | 0.0 | 2.3 | +457.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +152.7 | 35.0 | 29.7 | 5.0 | +456.3 | 392.7 | 147.0 |
| FREED FROM HIS FIGHT | 17.0 | +0.0 | 0.0 | 123.3 | 3.3 | +0.0 | 0.0 | 50.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -5.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -38.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.5 | 15.0 | 0.0 | 0.7 | -2.7 | 11.7 | 0.0 |
| GOAL WALK | 15.3 | +1112.9 | 0.0 | 89.7 | 13.0 | +1329.9 | 0.0 | 0.0 |
| GUN FIGURES | 6.0 | +12.2 | 20.0 | 145.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.1 | 0.0 | 11.3 | 1.3 | -0.3 | 85.0 | 68.3 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 8.0 | +0.0 | 0.0 | 123.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 62.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 16.7 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 240.0 | 7.0 | +0.0 | 0.0 | 73.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +9.8 | 0.0 | 16.7 |
| HIS CHARGE LIST | 11.0 | +0.0 | 0.0 | 379.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 123.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | - | - | - | - | 1.7 | -14.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 170.0 | 3.0 | +0.0 | 0.0 | 62.0 |
| HIS OWN BEST MOVE | 8.3 | +0.0 | 0.0 | 123.3 | 9.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 11.7 | +92.9 | 0.0 | 43.3 | 34.7 | +737.3 | 0.0 | 450.7 |
| HIS SHOTS BY HIS RUN | 12.0 | +64.6 | 0.0 | 321.3 | 33.0 | +448.1 | 0.0 | 499.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +2.5 | 0.0 | 68.3 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 496.7 | 12.7 | +0.0 | 0.0 | 124.0 |
| HOLDER ASSIGNMENT | 11.3 | +929.2 | 0.0 | 248.3 | 7.7 | +675.6 | 0.0 | 62.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -34.5 | 35.0 | 11.3 | 4.0 | -126.9 | 392.7 | 0.0 |
| IDLE COST | - | - | - | - | 15.0 | -187.2 | 0.0 | 98.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +97.7 | 0.0 | 78.7 |
| JOINT KNOWS CHALLENGE | 0.3 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.9 | 0.0 | 0.0 | 1.3 | +43.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.3 | +0.0 | 218.3 | 140.0 | 8.7 | +0.0 | 377.7 | 76.7 |
| LONG SHOT | 0.3 | -1.3 | 20.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.7 | 0.0 | 11.3 | 2.0 | +3.4 | 85.0 | 68.3 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 11.7 | 1.3 | -18.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +28.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +42.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +103.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -197.0 | 0.0 | 0.0 | 0.3 | +29.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +39.5 | 0.0 | 0.0 | 3.0 | +112.0 | 0.0 | 41.7 |
| MEETS IN TIME | 4.7 | +279.3 | 0.0 | 0.0 | 2.7 | +216.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +157.6 | 0.0 | 114.3 | 2.3 | +5.7 | 0.0 | 20.0 |
| MISSILES NEXT TURN | 4.0 | +82.1 | 0.0 | 114.3 | 3.0 | +4.2 | 0.0 | 20.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.0 | +54.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.0 | -82.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +790.2 | 0.0 | 123.3 | 11.7 | +775.2 | 0.0 | 83.3 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.3 | +343.7 | 0.0 | 114.3 | 6.0 | +257.7 | 0.0 | 82.0 |
| NEXT CHARGE BY LIST | 6.7 | +684.2 | 62.0 | 0.0 | 6.7 | +556.3 | 0.0 | 83.3 |
| NO CHAFF EDGES | 3.0 | +64.5 | 20.0 | 22.7 | 2.0 | +87.8 | 23.3 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -72.3 | 35.0 | 11.3 | 4.7 | -202.4 | 371.0 | 147.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -2.3 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -127.3 | 0.0 | 21.7 | 3.0 | -186.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -57.0 | 0.0 | 114.3 | 5.0 | -135.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +18.0 | 0.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 5.0 | -85.1 | 0.0 | 170.0 | 3.7 | -48.4 | 0.0 | 62.0 |
| ONE PROMISE A TARGET | 1.3 | -61.3 | 62.0 | 0.0 | 2.0 | -101.9 | 0.0 | 83.3 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +27.3 | 15.0 | 0.0 | 0.3 | +14.9 | 21.7 | 0.0 |
| OPENS UP IN FULL | 0.7 | +33.1 | 15.0 | 0.0 | 1.0 | +33.8 | 45.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +64.7 | 15.0 | 0.0 | 0.7 | +10.8 | 81.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +23.6 | 0.0 | 0.0 |
| PLAN RESULT | 41.7 | +93.7 | 82.0 | 830.3 | 41.0 | +231.3 | 397.7 | 611.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +19.2 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.7 | -397.5 | 0.0 | 123.3 | 15.7 | -402.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 6.7 | -151.7 | 0.0 | 123.3 | 5.0 | +0.0 | 0.0 | 83.3 |
| QUARTER ODDS | 23.7 | +3027.8 | 186.0 | 401.7 | 22.7 | +3224.6 | 118.3 | 399.7 |
| RANDOM MOVE BY FIGURES | 3.3 | +89.6 | 0.0 | 140.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | -36.9 | 0.0 | 46.7 | 1.7 | +214.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.3 | +119.0 | 0.0 | 23.3 | 4.7 | +439.0 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.3 | +23.3 | 0.0 | 76.3 | 5.7 | +276.6 | 0.0 | 15.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -13.2 | 0.0 | 0.0 | 1.0 | -5.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 114.3 | 1.0 | +0.0 | 0.0 | 68.3 |
| RISK BY ARC | 1.3 | +17.7 | 15.0 | 11.3 | 2.3 | -57.0 | 115.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -28.8 | 85.0 | 62.0 |
| RUN DOWN | - | - | - | - | 4.0 | -28.3 | 301.0 | 85.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -101.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.3 | 0.0 | 0.0 | 1.0 | +45.8 | 0.0 | 0.0 |
| SELF MOVE SPELL | 1.3 | -2.8 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -8.3 | 0.0 | 0.0 | 0.7 | -1.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +5.1 | 0.0 | 0.0 | 3.3 | -193.7 | 78.3 | 62.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +22.9 | 0.0 | 41.7 |
| SET-UP ANY TARGET | 0.3 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 1.0 | +95.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 11.7 | 3.7 | +0.0 | 0.0 | 40.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +78.8 | 124.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 2.3 | -6.4 | 0.0 | 0.0 | 27.0 | -86.6 | 0.0 | 306.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 11.0 | +206.7 | 0.0 | 145.0 | 0.3 | +7.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +4.4 | 0.0 | 0.0 | 1.7 | +11.1 | 60.0 | 60.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +4.7 | 85.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.3 | +0.0 | 0.0 | 385.7 | 12.3 | +0.0 | 0.0 | 272.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -3.2 | 21.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 40.0 |
| STANDS STILL | 27.7 | +0.0 | 186.0 | 346.7 | 18.3 | +0.0 | 0.0 | 367.3 |
| STAY WORTH | 8.3 | +45.8 | 62.0 | 145.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.2 | 0.0 | 62.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -2.7 | 0.0 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.7 | +113.3 | 0.0 | 0.0 | 7.0 | +656.3 | 0.0 | 136.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.7 | +113.3 | 0.0 | 0.0 | 7.0 | +656.3 | 0.0 | 136.7 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +16.9 | 0.0 | 102.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.7 | +0.8 | 0.0 | 11.3 | 2.3 | +254.6 | 199.3 | 85.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 62.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 106.7 | 3.3 | +0.0 | 0.0 | 62.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 106.7 | 1.7 | +0.0 | 0.0 | 62.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.3 | +0.0 | 0.0 | 345.0 | 41.0 | +0.0 | 0.0 | 449.3 |
| TIED UP BY THE SUM | 0.7 | +50.8 | 15.0 | 0.0 | 2.3 | +244.9 | 115.0 | 0.0 |
| TIME ON OUR SIDE | 41.3 | +442.8 | 0.0 | 292.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -35.5 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +90.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -248.0 | 0.0 | 240.0 | 2.0 | -545.1 | 0.0 | 73.3 |
| WHOLE FIGHT REACTION | 3.0 | +307.8 | 68.3 | 130.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +52.2 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 135 | 135 | 83 | 27.67 | +2159 | +26.0 |
| HOLDER ASSIGNMENT | 57 | 57 | 54 | 18.00 | +3141 | +58.2 |
| LEGAL CHARGES ONLY | 51 | 51 | 51 | 17.00 | +0 | +0.0 |
| FIVE ACTION | 496 | 481 | 40 | 13.33 | +1885 | +47.1 |
| REDIRECT FOR A FRIEND IN REACH | 33 | 33 | 32 | 10.67 | +199 | +6.2 |
| HIS SHOT LIST | 139 | 130 | 30 | 10.00 | +94 | +3.1 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 29 | 9.67 | -2399 | -82.7 |
| HIS SHOTS BY HIS RUN | 135 | 129 | 28 | 9.33 | +120 | +4.3 |
| DEPLOY BY FIGURES | 42 | 42 | 26 | 8.67 | +278 | +10.7 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 59 | 50 | 24 | 8.00 | +828 | +34.5 |
| QUARTER ODDS | 139 | 139 | 22 | 7.33 | +1609 | +73.1 |
| GOAL WALK | 85 | 79 | 20 | 6.67 | +1372 | +68.6 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -942 | -49.6 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 40 | 37 | 13 | 4.33 | +505 | +38.8 |
| NO CHAFF EDGES | 15 | 15 | 13 | 4.33 | +391 | +30.0 |
| BACKS UP THE FIGHT | 27 | 26 | 12 | 4.00 | +341 | +28.4 |
| SUPPORT ADDS | 35 | 35 | 12 | 4.00 | +1082 | +90.2 |
| SUPPORT WORKED OUT | 35 | 35 | 12 | 4.00 | +1082 | +90.2 |
| CHAFF IN THE MOVE | 15 | 14 | 11 | 3.67 | +168 | +15.2 |
| TIME ON OUR SIDE | 124 | 102 | 11 | 3.67 | +56 | +5.1 |
| IDLE COST | 45 | 31 | 10 | 3.33 | +96 | +9.6 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 3.33 | -490 | -49.0 |
| FOUR ROUNDS | 21 | 21 | 9 | 3.00 | +778 | +86.5 |
| MEETS IN TIME | 22 | 22 | 9 | 3.00 | +676 | +75.2 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1527 | +190.9 |
| PROMISE KNOWS THE FIGHT | 35 | 31 | 7 | 2.33 | -432 | -61.7 |
| SHOT RISK POINTS | 88 | 83 | 7 | 2.33 | +36 | +5.2 |
| CAST JOB | 8 | 8 | 6 | 2.00 | +91 | +15.2 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +269 | +44.8 |
| TIED UP BY THE SUM | 9 | 9 | 6 | 2.00 | +146 | +24.3 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 60 | 55 | 5 | 1.67 | +403 | +80.6 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +150 | +29.9 |
| SET UP BY THE SET | 16 | 16 | 5 | 1.67 | +579 | +115.8 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +18 | +4.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 62 | 47 | 4 | 1.33 | +38 | +9.4 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 16 | 16 | 4 | 1.33 | +5 | +1.1 |
| REDIRECT COUNTER | 30 | 25 | 4 | 1.33 | +247 | +61.7 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +141 | +35.3 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 4 | 1.33 | +24 | +6.1 |
| SURE REACH TOGETHER | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 29 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -1 | -0.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +55 | +18.4 |
| CHARGE NOW FIRST | 10 | 10 | 3 | 1.00 | -167 | -55.8 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +293 | +97.8 |
| MISSILES NEXT TURN | 21 | 11 | 3 | 1.00 | +3 | +1.1 |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 3 | 1.00 | +0 | +0.0 |
| REFUSING RETIRES | 5 | 5 | 3 | 1.00 | -45 | -14.9 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 17 | 17 | 3 | 1.00 | +270 | +90.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 29 | 16 | 2 | 0.67 | +7 | +3.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +86 | +43.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -309 | -154.7 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +188 | +93.8 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +58 | +28.9 |
| WHOLE FIGHT REACTION | 9 | 9 | 2 | 0.67 | +15 | +7.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +42 | +41.7 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +57 | +57.4 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -74 | -74.3 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +45 | +45.1 |
| MARCH CHECK | 4 | 2 | 1 | 0.33 | +7 | +6.5 |
| MISSILES IN THE MOVE | 17 | 7 | 1 | 0.33 | +45 | +45.0 |
| MOVE SPELL IN RANGE | 6 | 1 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE FIGHT FORMULA | 28 | 13 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP IN FULL | 5 | 5 | 1 | 0.33 | +8 | +8.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +71 | +70.9 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +58 | +57.7 |
| RISK BY ARC | 11 | 11 | 1 | 0.33 | +18 | +18.2 |
| SHOTS IN THE MOVE | 34 | 17 | 1 | 0.33 | +7 | +6.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| THE FIGHT MOVES | 9 | 9 | 1 | 0.33 | +402 | +402.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +207 | +207.0 |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 75 | 74 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 10 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 56 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 61 | 58 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 18 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 29 | 26 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 36 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 33 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 5 | 5 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 49 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 17 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| NEARER NOT NEEDED | 43 | 38 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 26 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 23 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 71 | 59 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 138 | 135 | 0 | 0.00 | - | - |
| STAY WORTH | 26 | 19 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 13 | 9 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 238 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 7.00 | 82.7 |
| JOB FIRST | gate | 3.00 | 2.67 | 52.6 |
| ARMY TABLE | rule | 3.33 | 1.67 | 40.2 |
| ONE PROMISE A TARGET | rule | 1.33 | 2.00 | 49.0 |
| PROMISE KNOWS THE FIGHT | rule | 1.67 | - | 90.9 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 55.8 |
| REFUSING RETIRES | rule | 0.67 | 0.33 | 14.9 |
| MARCH OF THE TABLE | rule | 0.67 | - | 154.7 |
| AFTERMATH BAND | gate | 0.33 | - | 4.7 |
| CHAFF PASSED | rule | 0.33 | - | 1.0 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 74.3 |
| FALLBACK | gate | - | 0.33 | 42.6 |

### Plans: chf-efd8067-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 222 | 40 | 18% |
| Mine | move | 37.0 | 95% | 2310 | 0 | 0% |
| Mine | shoot | 2.0 | 33% | 210 | 54 | 26% |
| Mine | support | 0.7 | 50% | 12 | 0 | 0% |
| Opponent | charge | 4.3 | 69% | 810 | 231 | 29% |
| Opponent | join | 3.0 | 89% | 119 | 0 | 0% |
| Opponent | move | 32.0 | 97% | 2425 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 0 | 0 | - |
| Opponent | support | 1.3 | 100% | 105 | 0 | 0% |

### Battle groups: chf-efd8067-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 31% | 80% | 0% | - | 0% | 0% | 0% | 80% | 20% |
| Opponent | REDIRECT COUNTER | 4.7 | 50% | 57% | 43% | 0% | 75% | 0% | 0% | 25% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 143 (7) | 0 | 143 | 27 | 14% | 4.3 | 132 (4) | 450 (1) | 0 (2) | 102 (6) | 450 (1) |
| Mine | Character | 6 | 50 (6) | 50 | 0 | 23 | 17% | 1.6 | - | 26 (3) | 79 (1) | 50 (2) | 35 (2) |
| Mine | Clean-up | 2 | 26 (2) | 0 | 26 | 0 | 100% | - | 0 (1) | 31 (1) | - | 0 (1) | 31 (1) |
| Mine | Fast Hammer | 1 | 3 (1) | 3 | 0 | 100 | 0% | 2.0 | 3 (1) | - | - | 3 (1) | - |
| Mine | Hammer | 11 | 42 (11) | 30 | 12 | 46 | 9% | 3.0 | 10 (3) | 60 (4) | 47 (4) | 54 (9) | 0 (2) |
| Mine | Holder | 2 | 25 (2) | 25 | 0 | 15 | 0% | 3.5 | - | 0 (1) | 30 (1) | 25 (2) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 2.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 4 | 2 (4) | 2 | 0 | 53 | 25% | 2.3 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 27 (9) | 3 | 24 | 59 | 33% | 3.7 | 4 (7) | 133 (2) | - | 37 (7) | 0 (2) |
| Opponent | Character | 10 | 39 (10) | 39 | 0 | 7 | 20% | 3.9 | 39 (5) | 39 (5) | - | 57 (5) | 22 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 8 | 99 (8) | 65 | 34 | 30 | 25% | 3.2 | 64 (2) | 132 (5) | 0 (1) | 141 (4) | 57 (4) |
| Opponent | Hammer | 2 | 12 (2) | 0 | 12 | 34 | 50% | 2.0 | - | 0 (1) | 19 (1) | 0 (1) | 19 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Wizard | 4 | 3 (4) | 3 | 0 | 62 | 0% | 1.8 | 4 (3) | 0 (1) | - | 4 (2) | 0 (2) |

### Charged fights: chf-efd8067-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 246 | 325 | 4.0 | 1.0 | 81 | 8 | +73 | 1 of 4 | 2 of 4 | - | +73 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 28 | -28 | 0 of 2 | 1 of 2 | - | -28 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 82 | 108 | 2.0 | 1.0 | 54 | 15 | +39 | 1 of 6 | 3 of 6 | - | +39 |
| Opponent | Vampire Counts | 2 | 0 | 908 | 4.0 | 1.1 | 227 | 64 | +163 | 4 of 8 | 5 of 8 | -275 | +226 |
| Opponent | Warriors of Chaos | 1 | 35 | 0 | 2.0 | 1.0 | 0 | 102 | -102 | 0 of 2 | 1 of 2 | - | -102 |
| **Opponent** | all armies | 3 | 12 | 605 | 3.3 | 1.1 | 182 | 72 | +110 | 4 of 10 | 6 of 10 | -275 | +153 |

### Effective charges: chf-efd8067-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +325) | 0 | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 8 | 1 (net +185) | 0 | 0 | 1 (net -275) | 0 | 4 (net +284) | 2 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 2 | 1 (net -205) | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 297 | 380 | +0 | 158 | 116 | +43 | +14.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 300 | 52 | +162 | 162 | 0 | +162 | +54.1 |
| Mine | No odds | 3 | 60 | 102 | -30 | 3 | 39 | -36 | -60.1 |
| Mine | All fights | 6 | 180 | 132 | +39 | 82 | 39 | +43 | +24.2 |
| Opponent | Long shot (under 50%) | 2 | 196 | 191 | -10 | 96 | 102 | -7 | -3.4 |
| Opponent | 76-89% | 1 | 110 | 350 | -275 | 0 | 275 | -275 | -250.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 272 | 216 | +284 | 298 | 47 | +251 | +92.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 365 | 35 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 2 | 186 | 289 | +130 | 248 | 118 | +130 | +69.6 |
| Opponent | All fights | 10 | 232 | 221 | +110 | 188 | 90 | +97 | +41.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p22 | move | 17 | 3 (18%) | 3 (18%) | 2 (12%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

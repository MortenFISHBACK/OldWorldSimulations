# Doctrine scorecard: chf-efd8067-p27

### Scorecard: chf-efd8067-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 726 |
| L0421 | 1 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 500 |
| L0508 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 613 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 877 |
| **Average** | | | Mine | 0% | 4.0 | 2.0 | 1.3 | 1.7 | 0.0 | 0.0 | 0.0 | 204.3 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 701.0 |

### KPIs: chf-efd8067-p27

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 100% (5 of 5) | 31% (5 of 16) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | 33% (2 of 6) | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (2 of 9) | 33% (2 of 6) | 27% (4 of 15) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 86% (5164 of 5998) | 86% (5182 of 5999) | 86% (10346 of 11997) |
|   infantry points that never fought | lower | 87% (1239 of 1424) | 86% (1464 of 1703) | 86% (2703 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 58% (15 of 26) | 61% (30 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (1 of 1); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3625 of 5120) | 60% (2828 of 4677) | 66% (6453 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (50%) | 1.3 (100%) | 3.0 (64%) |
| MARCHED: its unit marched | 0.7 (20%) | 0.0 (0%) | 0.7 (14%) |
| GONE: slain | 1.0 (30%) | 0.0 (0%) | 1.0 (21%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 0.0 | 1.3 | 1.7 | 0.0 |
| not cast | 3.3 | 4.0 | 4.7 | 2.3 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (58%) | 3.0 (64%) | 0.7 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.7 (29%) | 0.0 (0%) |
| GONE: slain | 1.0 (30%) | 1.0 (25%) | 1.0 (21%) | 1.0 (43%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (70%) | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (43 of 79) | 69% (76 of 110) | 63% (119 of 189) |
|   cavalry | 50% (6 of 12) | 42% (5 of 12) | 46% (11 of 24) |
|   character | 85% (11 of 13) | 65% (15 of 23) | 72% (26 of 36) |
|   chariot | 38% (9 of 24) | 64% (9 of 14) | 47% (18 of 38) |
|   infantry | 33% (4 of 12) | 47% (7 of 15) | 41% (11 of 27) |
|   war machine | 72% (13 of 18) | 87% (40 of 46) | 83% (53 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (36%) | 0.7 (6%) | 5.0 (21%) |
| CHARGED: it charged | 0.3 (3%) | 0.3 (3%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (6%) | 0.7 (3%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| NO TARGET IN RANGE | 3.3 (28%) | 4.3 (38%) | 7.7 (33%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (28%) | 4.0 (35%) | 7.3 (31%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 0.3 (3%) | 1.0 (4%) |
| OTHER BAR | 0.0 (0%) | 0.7 (6%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.7 | 88% | 1.9 pts | 10 pts |
| character | 8.7 | 2.7 | 81% | 7.0 pts | 61 pts |
| chariot | 6.0 | 4.7 | 72% | 18.6 pts | 112 pts |
| infantry | 7.0 | 2.3 | 81% | 14.0 pts | 98 pts |
| war machine | 17.7 | 16.0 | 57% | 24.4 pts | 432 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 0.3 | 0.8 |
| Charges that made contact a game | 0.7 | 0.0 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.09 contact (22 units) | 0.04 declared, 0.00 contact (23 units) | 0.11 declared, 0.04 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 0% (0 of 1) | - | 0% (0 of 4) |
| Character in a unit | 89% (8 of 9) | 100% (2 of 2) | 100% (1 of 1) | 92% (11 of 12) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 100% (2 of 2) | 86% (6 of 7) |
| Chariot | 0% (0 of 2) | 80% (4 of 5) | - | 57% (4 of 7) |
| Infantry | 50% (4 of 8) | 40% (2 of 5) | 100% (1 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 50% (2 of 4) | - | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 79% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 88% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 82% | 56% (5 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 50% (1) | 50% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 65% (17 of 26) | 63% (31 of 49) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 18% (2 of 11) |
| Strategy | Lone characters that fought | 12% (1 of 8) | 0% (0 of 4) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.7 | 3.3 |
| Movement | Points that never moved of their own | 204.3 | 701.0 |
| Movement | Fights charged into per game | 0.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +0 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (15 of 30) | 72% (26 of 36) |
| Shooting | Points destroyed by shooting units | 118.3 | 193.3 |
| Shooting | War machine shots | 4.3 | 13.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 15% (2 of 13) | 62% (25 of 40) |
| Shooting | Points destroyed by war machines | 103.3 | 192.7 |
| Magic | Magic missiles cast | 0.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 0.3 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.0 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 21.7 |
| Combat | Points run down | 0.0 | 113.0 |
| Combat | Net points per charged fight, damage counted | +110 | - |
| Combat | Net per 100 charger points, damage counted | +34.0 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +72 | - |
| Combat | Net points per supported fight / lone fight | - / +72 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 2 of 2 | - |
| Game | Points lost | 485.7 | 386.7 |
| Game | VP from objectives | 956.7 | 800.0 |
| Game | Lone holders (player turns) | 4.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -9 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 872
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.3 | +228.1 | 0.0 | 0.0 | 9.7 | +118.6 | 0.0 | 43.3 |
| ARTILLERY RE-ROLL WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +2.9 | 113.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 45.0 | 0.0 | 1.3 | +0.0 | 116.7 | 0.0 |
| CANNON PLANNED TARGET | 4.3 | +75.2 | 281.7 | 158.3 | 13.3 | +430.4 | 926.3 | 146.7 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -25.9 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +19.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | -56.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 21.3 | -977.7 | 0.0 | 386.7 | 10.7 | -373.8 | 0.0 | 118.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 166.7 | 113.0 | - | - | - | - |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 70.0 |
| COVER ONCE | 3.7 | -197.2 | 0.0 | 0.0 | 1.3 | -221.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +9.9 | 0.0 | 31.7 | 9.0 | -42.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +56.3 | 70.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +10.6 | 70.0 | 113.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 113.0 | - | - | - | - |
| FALLS SHORT | 12.3 | +151.1 | 0.0 | 193.3 | 6.0 | +117.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.7 | +5707.7 | 1116.7 | 946.3 | 99.0 | +5233.3 | 2208.7 | 933.3 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +57.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +41.9 | 70.0 | 113.0 | 0.3 | +112.6 | 113.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -43.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 12.0 | +1267.4 | 0.0 | 43.3 | 4.7 | +327.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +18.0 | 48.3 | 0.0 | 1.3 | +42.1 | 0.0 | 21.7 |
| GUN MASK | 1.3 | -10.9 | 0.0 | 0.0 | 1.3 | +48.4 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | -4.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.7 | +0.0 | 0.0 | 386.7 | 2.7 | +0.0 | 0.0 | 118.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.1 | 113.0 | 0.0 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 386.7 | - | - | - | - |
| HIS MOVE AND SHOT | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | -48.9 | 0.0 | 48.3 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 386.7 | - | - | - | - |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 6.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 53.3 | +2537.4 | 0.0 | 86.7 | 46.3 | +1072.8 | 0.0 | 311.7 |
| HIS SHOTS BY HIS RUN | 41.0 | +603.1 | 0.0 | 516.7 | 27.7 | +731.3 | 0.0 | 208.3 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 0.0 | 18.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +920.4 | 0.0 | 0.0 | 10.7 | +925.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -35.3 | 70.0 | 113.0 | - | - | - | - |
| HUNT IN PAIRS | 0.3 | +35.7 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 10.7 | -164.8 | 0.0 | 236.7 | 4.0 | -32.4 | 0.0 | 65.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +55.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -12.4 | 113.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| LOST CHARGE | 0.3 | -0.2 | 70.0 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +18.3 | 0.0 | 0.0 | 1.3 | -3.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +48.9 | 0.0 | 193.3 | - | - | - | - |
| MARCH CHECK | 0.7 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +56.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +25.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -18.5 | 0.0 | 193.3 | - | - | - | - |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.3 | +83.3 | 0.0 | 193.3 | - | - | - | - |
| MEETS IN TIME | 2.7 | +296.6 | 0.0 | 0.0 | 4.3 | +181.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +46.1 | 0.0 | 0.0 | 1.7 | +22.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +44.2 | 0.0 | 193.3 | 1.3 | +10.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| MOVE SPELL IN RANGE | 3.0 | +48.5 | 0.0 | 193.3 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.0 | -95.1 | 0.0 | 193.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.3 | +366.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +224.2 | 0.0 | 0.0 | 5.7 | +249.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +298.1 | 0.0 | 0.0 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1.0 | -93.1 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 0.7 | +23.5 | 0.0 | 113.0 | 1.0 | +2.2 | 0.0 | 96.7 |
| NO DOUBLE ROUNDS | 1.3 | -45.2 | 70.0 | 113.0 | 0.3 | -76.1 | 113.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +101.2 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -208.9 | 0.0 | 95.0 | 1.0 | -30.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -109.2 | 0.0 | 193.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 1.3 | +53.3 | 0.0 | 0.0 | 4.0 | -48.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.7 | +23.5 | 0.0 | 113.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +9.3 | 70.0 | 113.0 | - | - | - | - |
| OWN CAST FIRST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -8.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.0 | +500.8 | 405.0 | 751.0 | 45.3 | +1081.5 | 1079.7 | 608.3 |
| PROMISE BY ITS OWN SUM | 6.3 | -254.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.7 | +2618.8 | 463.3 | 0.0 | 31.7 | +2125.8 | 0.0 | 301.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +37.7 | 0.0 | 333.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +40.8 | 0.0 | 21.7 | 0.7 | +20.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -1.3 | 70.0 | 113.0 | 0.3 | -3.0 | 113.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.0 | -15.5 | 0.0 | 113.0 | 0.3 | -22.3 | 113.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +57.8 | 70.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +36.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 158.3 | 16.0 | +0.0 | 0.0 | 146.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +95.7 | 193.3 | 0.0 | 1.3 | +14.2 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.1 | 113.0 | 0.0 |
| SHOT RISK POINTS | 30.3 | +398.1 | 0.0 | 86.7 | 23.3 | +134.0 | 0.0 | 295.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +500.8 | 0.0 | 158.3 | 22.7 | +954.7 | 0.0 | 256.7 |
| SPELL WORTH | - | - | - | - | 2.7 | +12.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 166.7 |
| STAND AND SHOOT | 0.3 | -6.4 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 39.3 | +0.0 | 1046.7 | 316.7 | 65.7 | +0.0 | 2095.7 | 636.7 |
| STAY WORTH | 28.3 | +566.7 | 766.7 | 475.0 | 42.3 | +392.9 | 1209.3 | 490.0 |
| SUPPORT ADDS | 0.7 | +36.1 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 0.7 | +36.1 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +21.2 | 0.0 | 193.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | -0.0 | 70.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.7 | +0.0 | 0.0 | 43.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.7 | +0.0 | 0.0 | 43.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 416.7 | 46.3 | +0.0 | 0.0 | 211.7 |
| TIED UP BY THE SUM | 0.7 | +77.3 | 0.0 | 113.0 | - | - | - | - |
| TIME ON OUR SIDE | 14.7 | +207.1 | 0.0 | 21.7 | 32.7 | +311.8 | 386.7 | 0.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.3 | +0.0 | 193.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 6.0 | -248.3 | 0.0 | 386.7 | 1.3 | -162.7 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 0.3 | +11.4 | 0.0 | 113.0 | 1.0 | +62.5 | 113.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +292.8 | 0.0 | 0.0 | 5.3 | +130.1 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 299 | 294 | 65 | 21.67 | +1262 | +19.4 |
| HOLDER ASSIGNMENT | 61 | 61 | 58 | 19.33 | +2594 | +44.7 |
| ARMY TABLE | 84 | 84 | 54 | 18.00 | +507 | +9.4 |
| SHOT RISK POINTS | 161 | 160 | 36 | 12.00 | +1285 | +35.7 |
| HIS SHOTS BY HIS RUN | 206 | 199 | 33 | 11.00 | +261 | +7.9 |
| DEPLOY BY FIGURES | 53 | 53 | 29 | 9.67 | +502 | +17.3 |
| TIME ON OUR SIDE | 142 | 125 | 23 | 7.67 | +81 | +3.5 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| GOAL WALK | 50 | 50 | 19 | 6.33 | +1028 | +54.1 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -717 | -44.8 |
| IDLE COST | 44 | 35 | 15 | 5.00 | +79 | +5.3 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 53 | 53 | 11 | 3.67 | +4 | +0.4 |
| FIVE ACTION | 581 | 573 | 11 | 3.67 | +415 | +37.8 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| QUARTER ODDS | 181 | 180 | 10 | 3.33 | +318 | +31.8 |
| CHARGE LOSSES | 96 | 95 | 9 | 3.00 | +390 | +43.3 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 9 | 3.00 | -764 | -84.9 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +437 | +54.6 |
| MOVE TO CHARGE COMPUTED | 13 | 11 | 8 | 2.67 | +412 | +51.6 |
| STAY WORTH | 212 | 193 | 8 | 2.67 | +166 | +20.7 |
| WOUNDS ON THE RANKS | 22 | 22 | 8 | 2.67 | +173 | +21.6 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 111 | 84 | 7 | 2.33 | +407 | +58.1 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 10 | 9 | 6 | 2.00 | +412 | +68.8 |
| WHOLE FIGHT DANGER | 22 | 22 | 6 | 2.00 | +72 | +12.0 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 5 | 1.67 | +148 | +29.5 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +165 | +41.3 |
| NO CHAFF EDGES | 5 | 4 | 4 | 1.33 | +51 | +12.8 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +113 | +28.3 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| MANOEUVRE | 10 | 10 | 3 | 1.00 | +55 | +18.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +146 | +48.8 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 3 | 3 | 1.00 | +22 | +7.2 |
| FALLS SHORT | 55 | 46 | 2 | 0.67 | +40 | +20.1 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +171 | +85.5 |
| GUN MASK | 8 | 8 | 2 | 0.67 | +33 | +16.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| SET UP BY THE SET | 2 | 2 | 2 | 0.67 | +167 | +83.5 |
| SHOTS AFTER THE MOVES | 24 | 24 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 4 | 4 | 2 | 0.67 | +44 | +22.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -78 | -77.7 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +24 | +23.7 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 1 | 0.33 | -31 | -30.6 |
| COVER ONCE | 15 | 12 | 1 | 0.33 | +2 | +1.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +30 | +30.5 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOUR ROUNDS | 5 | 4 | 1 | 0.33 | +182 | +182.4 |
| HIS MOVE AND SHOT | 15 | 15 | 1 | 0.33 | +0 | +0.2 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +28 | +28.1 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -144 | -144.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -78 | -77.7 |
| MAX FOR POSITIONING | 7 | 6 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 5 | 4 | 1 | 0.33 | +30 | +30.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +167 | +167.4 |
| ONE FIGHT FORMULA | 14 | 9 | 1 | 0.33 | +2 | +1.7 |
| ONE OBJECTIVE FORMULA | 16 | 9 | 1 | 0.33 | +38 | +37.8 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -8 | -7.7 |
| OPENS UP IN FULL | 2 | 1 | 1 | 0.33 | +45 | +44.7 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -11 | -10.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -26 | -26.3 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +68 | +68.3 |
| RISK BY ARC | 4 | 3 | 1 | 0.33 | +30 | +30.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +173 | +173.3 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT ADDS | 3 | 3 | 1 | 0.33 | +1 | +0.6 |
| SUPPORT WORKED OUT | 3 | 3 | 1 | 0.33 | +1 | +0.6 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +45 | +44.7 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 26 | 26 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 30 | 30 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 16 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 18 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 98 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 3 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH CHECK | 2 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 9 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 12 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| NEARER NOT NEEDED | 33 | 31 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 74 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 19 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 315 | 310 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE FIGHT MOVES | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 17 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 274 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.00 | 0.33 | 44.0 |
| JOB FIRST | gate | 4.33 | 1.00 | 44.8 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | - | 84.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 23.1 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 77.7 |
| CHARGE NOW FIRST | rule | 0.33 | - | 30.6 |
| MARCH ODDS | rule | 0.33 | - | 144.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 77.7 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 7.7 |
| OWN CAST FIRST | rule | 0.33 | - | 10.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 26.3 |

### Plans: chf-efd8067-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 128 | 70 | 55% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 32.0 | 97% | 1763 | 0 | 0% |
| Mine | shoot | 7.7 | 65% | 460 | 431 | 94% |
| Opponent | charge | 0.3 | 100% | 74 | 113 | 154% |
| Opponent | join | 1.7 | 100% | 58 | 0 | 0% |
| Opponent | move | 29.0 | 93% | 1289 | 0 | 0% |
| Opponent | shoot | 14.3 | 77% | 633 | 969 | 153% |

### Battle groups: chf-efd8067-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 8 (11) | 8 | 0 | 48 | 27% | 3.2 | 23 (5) | 0 (2) | 0 (3) | 0 (6) | 17 (4) |
| Mine | Clean-up | 2 | 150 (2) | 0 | 150 | 0 | 50% | 2.0 | 150 (2) | - | - | 150 (2) | - |
| Mine | Hammer | 8 | 27 (8) | 16 | 11 | 4 | 12% | 3.0 | 0 (2) | 33 (6) | - | 55 (5) | 0 (3) |
| Mine | Holder | 5 | 61 (5) | 0 | 61 | 0 | 80% | 3.0 | 36 (2) | 77 (3) | - | 108 (1) | 48 (4) |
| Mine | Shooter | 1 | 54 (1) | 0 | 54 | 0 | 0% | 1.0 | 54 (1) | - | - | - | 54 (1) |
| Mine | War machine | 5 | 65 (5) | 65 | 0 | 60 | 0% | 1.0 | 46 (4) | 142 (1) | - | - | 65 (5) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Character | 13 | 38 (13) | 38 | 0 | 3 | 46% | 2.1 | 57 (9) | 0 (3) | 0 (1) | 49 (9) | 0 (4) |
| Opponent | Clean-up | 2 | 66 (2) | 0 | 66 | 0 | 100% | - | - | 66 (2) | - | 66 (2) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 8 | 47 (8) | 29 | 18 | 27 | 25% | 2.0 | 96 (3) | 16 (2) | 18 (3) | 47 (8) | - |
| Opponent | Holder | 3 | 95 (3) | 0 | 95 | 0 | 100% | - | - | 147 (2) | 0 (1) | 130 (1) | 80 (2) |
| Opponent | Shooter | 4 | 73 (4) | 0 | 73 | 26 | 25% | 1.7 | - | 73 (4) | - | 73 (4) | - |
| Opponent | War machine | 9 | 58 (9) | 58 | 0 | 49 | 11% | 1.0 | 58 (9) | - | - | 0 (1) | 68 (8) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: chf-efd8067-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 178 | 105 | 1.0 | 1.0 | 105 | 32 | +72 | 2 of 2 | 2 of 2 | - | +72 |
| Mine | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 222 | 70 | 0.7 | 1.0 | 105 | 32 | +72 | 2 of 2 | 2 of 2 | - | +72 |
| Opponent | Dwarfen Mountain Holds | 1 | 580 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 578 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 386 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: chf-efd8067-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 310 | 239 | +0 | 149 | 133 | +17 | +5.3 |
| Mine | No odds | 1 | 339 | 210 | +145 | 318 | 113 | +204 | +60.2 |
| Mine | All fights | 2 | 324 | 224 | +72 | 233 | 123 | +110 | +34.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p27 | move | 13 | 3 (23%) | 2 (15%) | 1 (8%) | 9 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: chf-efd8067-p11

### Scorecard: chf-efd8067-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 5 | - | 0 | 1 | 0 | 0 | 0 | 410 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 3 | 1 | 2 | 2 | 0 | 0 | 757 |
| L2335 | 1 | 1 | Mine | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 110 |
| **Average** | | | Mine | 67% | 3.5 | 3.0 | 1.7 | 1.0 | 0.3 | 0.0 | 0.0 | 136.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 2.0 | 2.3 | 0.7 | 0.0 | 0.0 | 289.0 |

### KPIs: chf-efd8067-p11

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (2 of 16) | 0% (0 of 18) | 6% (2 of 34) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (5 of 5); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 44% (8 of 18) | 54% (13 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 50% (8 of 16) | 59% (13 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (6 of 10) | 33% (2 of 6) | 50% (8 of 16) |
| Points that never fought | lower | 51% (3039 of 5999) | 34% (2037 of 6000) | 42% (5076 of 11999) |
|   infantry points that never fought | lower | 79% (1220 of 1552) | 42% (439 of 1035) | 64% (1659 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 73% (22 of 30) | 69% (34 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2724 of 4484) | 66% (3647 of 5546) | 64% (6371 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (100%) | 2.7 (80%) | 3.0 (82%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (10%) | 0.3 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (10%) | 0.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.7 | 0.7 | 1.0 | 4.3 | 0.3 | 0.0 |
| not cast | 2.3 | 1.3 | 1.0 | 3.7 | 1.7 | 16.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 3.0 (82%) | 1.7 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (25%) | 0.3 (33%) | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (25%) | 0.3 (33%) | 0.3 (9%) | 0.0 (0%) | 1.0 (6%) |
| STUPIDITY: Stupidity | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (86%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 33% (1 of 3) | 33% (1 of 3) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (75 of 114) | 69% (22 of 32) | 66% (97 of 146) |
|   cavalry | 96% (23 of 24) | 88% (14 of 16) | 92% (37 of 40) |
|   character | 0% (0 of 19) | 17% (1 of 6) | 4% (1 of 25) |
|   chariot | 100% (10 of 10) | - | 100% (10 of 10) |
|   infantry | 69% (42 of 61) | 70% (7 of 10) | 69% (49 of 71) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (15%) | 2.0 (60%) | 4.0 (24%) |
| CHARGED: it charged | 2.0 (15%) | 1.0 (30%) | 3.0 (18%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.3 (10%) | 1.0 (6%) |
| NO TARGET IN RANGE | 5.3 (41%) | 0.0 (0%) | 5.3 (33%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (23%) | 0.0 (0%) | 3.0 (18%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 17.7 | 2.3 | 87% | 2.9 pts | 52 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 0.3 | 91% | 3.5 pts | 13 pts |
| infantry | 19.0 | 7.0 | 77% | 7.5 pts | 142 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.3 | 4.3 |
| Charges that made contact a game | 2.7 | 4.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.25 contact (32 units) | 0.60 declared, 0.48 contact (25 units) | 0.44 declared, 0.35 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | 100% (1 of 1) | 100% (1 of 1) | 78% (7 of 9) |
| Character in a unit | 100% (4 of 4) | - | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 75% (3 of 4) | 100% (1 of 1) | 43% (3 of 7) | 58% (7 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 64% (7 of 11) | 0% (0 of 1) | - | 58% (7 of 12) |
| Monster | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | - | 83% (5 of 6) | 64% | 78% (7 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 0% (0 of 1); on the table 0% | - | 44% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 83% (5 of 6) | 51% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 26% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 25% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 57% (4) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: chf-efd8067-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 78% (7 of 9) | 47% (7 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 62% (15 of 24) | 45% (5 of 11) |
| Strategy | Support requests answered (helper made contact too) | - | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 80% (8 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 136.7 | 289.0 |
| Movement | Fights charged into per game | 2.3 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 2 of 11, net +28 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +664 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 7, net +127 | 1 of 11, net +145 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 7 | 6 of 11, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 27.0 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (23 of 81) | 32% (7 of 22) |
| Shooting | Points destroyed by shooting units | 38.7 | 23.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.0 / 0.0 / 0.0 | 3.7 / 0.7 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 316.0 | 376.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +232 | +112 |
| Combat | Net per 100 charger points, damage counted | +54.9 | +41.3 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +210 | +117 |
| Combat | Net points per supported fight / lone fight | +116 / +225 | +76 / +126 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 4 of 11 |
| Game | Points lost | 541.7 | 729.0 |
| Game | VP from objectives | 956.7 | 606.7 |
| Game | Lone holders (player turns) | 3.5 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +617 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1271
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +0.5 | 0.0 | 65.0 | - | - | - | - |
| ARMY TABLE | 29.0 | +233.8 | 0.0 | 359.7 | 27.7 | +296.4 | 0.0 | 366.3 |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +4.2 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST FACING | - | - | - | - | 0.3 | +29.7 | 0.0 | 38.7 |
| CARRIES OUT SET-UP | 0.7 | -88.8 | 38.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 3.0 | +38.8 | 130.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +32.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 2.3 | +57.7 | 0.0 | 46.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | -0.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.4 | 0.0 | 30.7 | 1.3 | +66.5 | 0.0 | 174.7 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -0.2 | 30.7 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | -139.0 | 83.7 | 65.0 | - | - | - | - |
| CHARGE LOSSES | 21.3 | -560.2 | 0.0 | 708.0 | 27.7 | -1706.7 | 0.0 | 779.3 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 334.7 | 130.0 | 3.0 | +0.0 | 288.3 | 77.3 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.0 | +0.0 | 0.0 | 138.3 | 6.7 | +0.0 | 0.0 | 36.7 |
| COMBAT PIVOT | 1.0 | +0.0 | 83.7 | 70.0 | 0.3 | +0.0 | 70.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +86.2 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -510.7 | 0.0 | 265.7 | 8.7 | -315.9 | 0.0 | 199.7 |
| DENIED BY THE FIGHT | 0.3 | -0.6 | 36.7 | 0.0 | 0.7 | -0.7 | 0.0 | 38.7 |
| DEPLOY BY FIGURES | 8.7 | +49.0 | 0.0 | 0.0 | 7.3 | +77.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.0 | 41.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +28.7 | 65.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.7 | +8.7 | 20.0 | 0.0 |
| EXACT ROUND | 1.7 | +78.8 | 179.0 | 130.0 | 4.0 | +10.6 | 277.3 | 38.7 |
| FACES THE THREAT | - | - | - | - | 0.3 | +36.5 | 0.0 | 38.7 |
| FALL BACK GOOD ORDER | 2.7 | +20.2 | 239.3 | 130.0 | 4.0 | +0.0 | 291.3 | 38.7 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 0.0 | 23.3 | +324.6 | 0.0 | 295.3 |
| FEATURE BUFFS | 2.7 | +17.2 | 0.0 | 40.0 | 1.3 | +4.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +54.7 | 70.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 52.7 |
| FIVE ACTION | 108.3 | +9731.5 | 1007.7 | 1350.0 | 91.3 | +4360.1 | 785.3 | 1228.7 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 195.3 | 9.0 | +0.0 | 0.0 | 194.3 |
| FOLLOW UP WEIGHED | 1.3 | +88.4 | 0.0 | 0.0 | 2.0 | +267.5 | 0.0 | 38.7 |
| FOUR ROUNDS | 3.3 | +242.0 | 337.7 | 130.0 | 5.3 | +275.9 | 458.0 | 38.7 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 109.7 | 8.7 | +0.0 | 0.0 | 161.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -84.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -19.3 | 77.3 | 0.0 | 1.0 | -6.0 | 0.0 | 0.0 |
| GOAL WALK | 11.7 | +1359.3 | 0.0 | 0.0 | 11.7 | +588.4 | 0.0 | 83.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | -1.3 | 80.3 | 0.0 | 1.0 | -0.1 | 52.3 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 65.0 | 2.0 | +0.0 | 0.0 | 74.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 109.7 | 7.0 | +0.0 | 0.0 | 161.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 643.0 | 15.3 | +0.0 | 0.0 | 555.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +72.7 | 65.0 | 38.7 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 20.0 | 4.7 | +0.0 | 0.0 | 56.7 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 160.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -15.8 | 0.0 | 130.0 | 7.7 | -130.3 | 0.0 | 140.3 |
| HIS ONE QUARTER | 11.0 | +0.0 | 0.0 | 85.3 | 10.0 | +0.0 | 0.0 | 207.3 |
| HIS OWN BEST MOVE | 12.0 | +0.0 | 0.0 | 207.3 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 48.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.0 | +515.7 | 0.0 | 792.0 | 53.7 | +972.2 | 0.0 | 888.7 |
| HIS SHOTS BY HIS RUN | 39.7 | +498.0 | 0.0 | 697.3 | 59.3 | +698.1 | 0.0 | 972.0 |
| HIS TURN DENIED | 0.3 | +5.2 | 36.7 | 0.0 | 1.3 | +19.0 | 60.0 | 0.0 |
| HOLD ODDS | 26.3 | +0.0 | 0.0 | 181.3 | 13.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.3 | +1206.7 | 0.0 | 70.7 | 8.3 | +819.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -113.9 | 254.0 | 0.0 | 5.0 | -107.3 | 458.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +7.9 | 0.0 | 88.3 | - | - | - | - |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 16.0 | -153.3 | 0.0 | 80.3 |
| JOINT CHARGE NOW | 0.7 | -29.7 | 38.7 | 0.0 | 0.7 | +2.8 | 61.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +41.4 | 0.0 | 0.0 | 0.7 | +2.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 179.0 | 60.0 | 3.3 | +0.0 | 200.3 | 119.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +2.4 | 38.3 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +4.1 | 205.7 | 65.0 | 1.7 | +0.1 | 70.7 | 38.7 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -18.8 | 0.0 | 18.3 | 2.7 | -7.7 | 0.0 | 83.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +30.1 | 0.0 | 65.0 | 3.3 | +45.6 | 0.0 | 161.0 |
| MEETS IN TIME | 4.0 | +218.7 | 0.0 | 0.0 | 4.0 | +488.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +66.0 | 0.0 | 0.0 | 6.3 | +93.9 | 0.0 | 258.7 |
| MISSILES NEXT TURN | 1.7 | +30.8 | 0.0 | 0.0 | 6.3 | +69.6 | 0.0 | 258.7 |
| MOVE ORDER | 1.7 | +0.0 | 22.0 | 42.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -5.0 | 0.0 | 182.7 |
| MOVE TO CHARGE COMPUTED | 9.7 | +982.2 | 0.0 | 176.7 | 11.3 | +689.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 15.7 | +667.7 | 0.0 | 20.0 | 9.3 | +432.3 | 0.0 | 256.7 |
| NEXT CHARGE BY LIST | 6.7 | +514.9 | 116.0 | 46.7 | 8.7 | +636.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | 0.3 | -0.2 | 65.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +56.2 | 301.0 | 130.0 | 5.3 | +149.7 | 263.3 | 41.7 |
| NO DOUBLE ROUNDS | 3.0 | -157.4 | 299.0 | 130.0 | 4.7 | -166.3 | 396.7 | 38.7 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +1.7 | 0.0 | 38.7 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -307.9 | 0.0 | 193.7 | 4.0 | -99.7 | 0.0 | 83.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -165.0 | 0.0 | 130.0 | 7.3 | -79.1 | 0.0 | 77.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +2.3 | 30.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.7 | -47.8 | 0.0 | 70.7 | 2.7 | -20.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -21.2 | 0.0 | 46.7 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +51.0 | 75.3 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 2.7 | +84.0 | 337.7 | 130.0 | 1.0 | +38.0 | 178.3 | 0.0 |
| OVERRUNS AWAY | 1.3 | +14.1 | 125.3 | 130.0 | 1.7 | +15.4 | 248.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | -2.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 50.0 | +464.9 | 172.7 | 953.3 | 45.0 | +483.3 | 519.3 | 949.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 12.7 | -946.0 | 0.0 | 390.0 | 12.3 | -101.7 | 0.0 | 0.0 |
| PROMISE HOLDS THE SPOT | 0.3 | +34.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.3 | -1.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.7 | +3323.2 | 233.0 | 210.7 | 27.0 | +2547.8 | 277.0 | 366.7 |
| RANDOM MOVE BY FIGURES | 3.3 | +120.9 | 0.0 | 263.3 | 2.0 | +0.4 | 0.0 | 226.7 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +19.1 | 0.0 | 22.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +254.8 | 0.0 | 60.7 | 1.0 | +5.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +32.4 | 0.0 | 22.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -1.7 | 0.0 | 0.0 | 2.3 | -1.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | -68.0 | 203.7 | 130.0 | 4.3 | -114.7 | 396.7 | 38.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -24.6 | 159.0 | 65.0 | 1.3 | -2.1 | 83.0 | 0.0 |
| RUN DOWN | 3.0 | -62.4 | 281.0 | 130.0 | 2.3 | -1.5 | 167.3 | 0.0 |
| SAME CHARGE LATER | 0.7 | -22.9 | 77.3 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.8 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +54.4 | 0.0 | 0.0 | 1.0 | +2.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -10.2 | 0.0 | 0.0 | 0.7 | -11.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +10.2 | 0.0 | 0.0 | 2.3 | +46.1 | 20.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +7.7 | 0.0 | 0.0 | 1.3 | +10.5 | 0.0 | 122.3 |
| SET-UP MISSED | - | - | - | - | 0.3 | +18.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 22.0 | 5.0 | +0.0 | 0.0 | 74.7 |
| SHOOTS FROM THE BEST SPOT | 5.7 | +136.5 | 116.0 | 20.0 | 1.7 | +7.0 | 44.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -3.8 | 95.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 27.7 | -240.7 | 0.0 | 598.7 | 34.0 | -502.5 | 0.0 | 472.0 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.0 | +471.2 | 0.0 | 128.0 | 7.3 | +71.7 | 0.0 | 127.3 |
| SPELL WORTH | 0.7 | +0.5 | 0.0 | 0.0 | 3.7 | +3.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 236.7 | 6.0 | +0.0 | 0.0 | 217.7 |
| STAND AND SHOOT | 0.3 | -3.2 | 36.7 | 0.0 | 1.3 | -3.2 | 136.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.3 | +0.0 | 670.0 | 335.0 | 23.0 | +0.0 | 327.3 | 362.0 |
| STAY WORTH | 18.7 | +65.7 | 360.7 | 42.0 | 10.7 | +48.6 | 153.3 | 240.0 |
| STRIKE BY THE ODDS | 0.3 | +79.3 | 83.7 | 65.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | 1.7 | -5.1 | 0.0 | 0.0 | 1.0 | -29.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 48.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +782.7 | 0.0 | 63.3 | 7.7 | +548.0 | 0.0 | 36.7 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 18.3 | 38.7 |
| SUPPORT WORKED OUT | 8.3 | +782.7 | 0.0 | 63.3 | 7.7 | +548.0 | 0.0 | 36.7 |
| SURE REACH TOGETHER | 1.0 | +14.3 | 0.0 | 65.0 | 3.3 | +31.6 | 0.0 | 161.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 38.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 20.0 | 2.3 | +0.0 | 0.0 | 41.7 |
| THE FIGHT MOVES | 1.3 | +6.0 | 120.3 | 130.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 86.7 | 3.7 | +0.0 | 0.0 | 122.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 86.7 | 2.3 | +0.0 | 0.0 | 167.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.0 | +0.0 | 0.0 | 489.3 | 42.7 | +0.0 | 0.0 | 494.0 |
| TIED UP BY THE SUM | 1.0 | +128.2 | 78.3 | 65.0 | 2.3 | +228.3 | 273.3 | 0.0 |
| TIME ON OUR SIDE | 52.0 | +484.1 | 226.7 | 592.3 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +1.0 | 0.0 | 83.7 |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +8.1 | 83.7 | 65.0 | 0.3 | -0.2 | 20.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +118.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.7 | -373.2 | 0.0 | 363.0 | 3.3 | -1139.0 | 0.0 | 474.7 |
| WHOLE FIGHT GAIN | 0.3 | +5.3 | 0.0 | 0.0 | 0.3 | +2.7 | 30.7 | 0.0 |
| WHOLE FIGHT REACTION | 1.3 | +57.5 | 0.0 | 70.7 | 1.0 | +107.4 | 65.0 | 159.0 |
| WOUNDS ON THE RANKS | 3.0 | +9.6 | 0.0 | 0.0 | 5.7 | +56.6 | 0.0 | 334.7 |

### Rule changes: chf-efd8067-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 170 | 170 | 113 | 37.67 | +1598 | +14.1 |
| HOLDER ASSIGNMENT | 74 | 74 | 67 | 22.33 | +2966 | +44.3 |
| FIVE ACTION | 599 | 573 | 54 | 18.00 | +3330 | +61.7 |
| HIS SHOT LIST | 305 | 289 | 41 | 13.67 | +552 | +13.5 |
| HIS SHOTS BY HIS RUN | 297 | 277 | 40 | 13.33 | +474 | +11.8 |
| MOVE TO CHARGE COMPUTED | 63 | 51 | 35 | 11.67 | +996 | +28.5 |
| QUARTER ODDS | 167 | 159 | 33 | 11.00 | +2040 | +61.8 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 31 | 10.33 | -3143 | -101.4 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 46 | 41 | 30 | 10.00 | +916 | +30.5 |
| DEPLOY BY FIGURES | 48 | 48 | 27 | 9.00 | +251 | +9.3 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -1223 | -47.0 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +64 | +3.2 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| SUPPORT ADDS | 48 | 46 | 18 | 6.00 | +1194 | +66.3 |
| SUPPORT WORKED OUT | 48 | 46 | 18 | 6.00 | +1194 | +66.3 |
| NO CHAFF EDGES | 24 | 24 | 16 | 5.33 | +409 | +25.6 |
| GOAL WALK | 70 | 70 | 15 | 5.00 | +736 | +49.1 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 15 | 5.00 | +101 | +6.7 |
| FOUR ROUNDS | 26 | 24 | 12 | 4.00 | +400 | +33.4 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 24 | 24 | 11 | 3.67 | +567 | +51.5 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 3.33 | +1068 | +106.8 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 8 | 2.67 | +364 | +45.5 |
| TIME ON OUR SIDE | 156 | 135 | 8 | 2.67 | +10 | +1.2 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 18 | 18 | 7 | 2.33 | -344 | -49.1 |
| SEARCH SPOT | 7 | 7 | 7 | 2.33 | +170 | +24.3 |
| TIED UP BY THE SUM | 10 | 10 | 7 | 2.33 | +409 | +58.5 |
| CHARGE LOSSES | 147 | 139 | 6 | 2.00 | +1138 | +189.6 |
| COVER ONCE | 56 | 37 | 6 | 2.00 | +115 | +19.1 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +131 | +21.9 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +1361 | +226.8 |
| SHOT RISK POINTS | 185 | 177 | 6 | 2.00 | +24 | +4.0 |
| CAST JOB | 9 | 9 | 5 | 1.67 | +92 | +18.3 |
| CHAFF IN THE MOVE | 9 | 8 | 5 | 1.67 | +74 | +14.9 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +200 | +40.1 |
| IDLE COST | 54 | 26 | 5 | 1.67 | +10 | +2.0 |
| MISSILES IN THE MOVE | 24 | 18 | 5 | 1.67 | +89 | +17.8 |
| NEARER NOT NEEDED | 75 | 73 | 5 | 1.67 | +128 | +25.6 |
| WHOLE FIGHT DANGER | 30 | 30 | 5 | 1.67 | +50 | +10.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 8 | 8 | 4 | 1.33 | +8 | +1.9 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -81 | -20.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| SCOUTS HUNT GUNS ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 100 | 74 | 4 | 1.33 | +67 | +16.7 |
| STAY WORTH | 88 | 73 | 4 | 1.33 | +9 | +2.3 |
| SURE REACH TOGETHER | 13 | 13 | 4 | 1.33 | +34 | +8.5 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -1 | -0.3 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 7 | 5 | 3 | 1.00 | -6 | -1.9 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +18 | +6.2 |
| RISK BY ARC | 19 | 18 | 3 | 1.00 | +44 | +14.6 |
| SCOUT BY DROPS | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| SET UP BY THE SET | 10 | 10 | 3 | 1.00 | +295 | +98.3 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +49 | +24.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 75 | 59 | 2 | 0.67 | +5 | +2.4 |
| FIGHT TO THE END | 2 | 2 | 2 | 0.67 | +60 | +30.2 |
| MAX FOR POSITIONING | 17 | 16 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -64 | -31.9 |
| OPENS UP IN FULL | 11 | 11 | 2 | 0.67 | +45 | +22.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -8 | -3.9 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -44 | -21.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BEST FACING | 1 | 1 | 1 | 0.33 | +89 | +89.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -266 | -266.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 17 | 16 | 1 | 0.33 | +158 | +158.4 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +109 | +109.4 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +76 | +75.6 |
| HIS MOVE AND SHOT | 33 | 31 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +18 | +17.5 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +7 | +7.1 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +14 | +14.0 |
| MISSILES NEXT TURN | 24 | 19 | 1 | 0.33 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +2 | +2.1 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +40 | +39.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +104 | +104.0 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +6 | +6.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +50 | +50.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -14 | -13.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +1 | +1.4 |
| SHOTS AFTER THE MOVES | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +158 | +158.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| THE ROW IN ITS ORDER | 11 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +354 | +353.9 |
| WHOLE FIGHT GAIN | 2 | 1 | 1 | 0.33 | +7 | +7.4 |
| WOUNDS ON THE RANKS | 26 | 26 | 1 | 0.33 | +5 | +5.0 |
| BACKS UP THE FIGHT | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 18 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 53 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 34 | 33 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 7 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 26 | 25 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 84 | 79 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 63 | 58 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 61 | 52 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 46 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 118 | 117 | 0 | 0.00 | - | - |
| HONEST WORTH | 23 | 21 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 15 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 12 | 12 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 23 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 39 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 34 | 27 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 9 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 285 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 17 | 13 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 14 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 4 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 199 | 187 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 8 | 8 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 4 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 278 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 13 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 6.33 | 4.00 | 101.4 |
| JOB FIRST | gate | 3.67 | 3.67 | 51.7 |
| ARMY TABLE | rule | 2.67 | 3.33 | 24.7 |
| CHARGE NOW FIRST | rule | 1.67 | 0.67 | 49.1 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 1.9 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 3.0 |
| JOINT CHARGE NOW | rule | 0.67 | - | 44.6 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 31.9 |
| RULE SWITCHED OFF | gate | 0.67 | - | 28.8 |
| SUPPORT NARROWED | rule | - | 0.67 | 21.8 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 266.4 |
| CHAFF PASSED | rule | - | 0.33 | 0.7 |
| FALLBACK | gate | 0.33 | - | 7.5 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.5 |
| NO REASON | gate | - | 0.33 | 21.6 |
| PATHS CROSS | rule | - | 0.33 | 68.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 2.6 |
| REFUSING RETIRES | rule | 0.33 | - | 13.9 |

### Plans: chf-efd8067-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 426 | 202 | 47% |
| Mine | move | 41.7 | 94% | 3104 | 0 | 0% |
| Mine | shoot | 6.0 | 50% | 548 | 263 | 48% |
| Mine | support | 0.3 | 100% | 11 | 0 | 0% |
| Opponent | charge | 4.3 | 85% | 458 | 418 | 91% |
| Opponent | join | 2.3 | 86% | 91 | 0 | 0% |
| Opponent | move | 35.3 | 94% | 1645 | 0 | 0% |
| Opponent | shoot | 2.7 | 12% | 238 | 65 | 27% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: chf-efd8067-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 14% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 111 (6) | 29 | 82 | 48 | 0% | 1.5 | 0 (1) | 54 (3) | 273 (2) | 157 (3) | 60 (3) |
| Mine | Character | 6 | 50 (6) | 50 | 0 | 0 | 17% | 3.4 | 23 (2) | 91 (2) | 0 (2) | 23 (2) | 71 (4) |
| Mine | Clean-up | 1 | 439 (1) | 0 | 439 | 0 | 100% | - | - | 439 (1) | - | - | 439 (1) |
| Mine | Fast Hammer | 6 | 122 (6) | 122 | 0 | 71 | 33% | 3.5 | 28 (3) | 176 (3) | - | 194 (4) | 24 (2) |
| Mine | Hammer | 5 | 56 (5) | 0 | 56 | 55 | 20% | 1.8 | 0 (3) | 125 (2) | - | 76 (3) | 35 (2) |
| Mine | Holder | 8 | 96 (8) | 0 | 96 | 15 | 25% | 2.3 | 224 (2) | 92 (4) | 0 (2) | 224 (2) | 56 (6) |
| Mine | Shooter | 5 | 0 (5) | 0 | 0 | 44 | 0% | 2.8 | 0 (2) | 0 (3) | - | 0 (3) | 0 (2) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.5 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 4 | 60 (4) | 23 | 38 | 0 | 75% | 3.0 | 81 (3) | - | 0 (1) | 81 (3) | 0 (1) |
| Opponent | Character | 11 | 30 (11) | 30 | 0 | 41 | 27% | 3.2 | 10 (3) | 16 (5) | 60 (2) | 52 (4) | 22 (6) |
| Opponent | Fast Hammer | 6 | 35 (6) | 35 | 0 | 33 | 17% | 2.8 | 0 (1) | 50 (4) | 0 (1) | 0 (2) | 46 (4) |
| Opponent | Hammer | 8 | 13 (8) | 13 | 0 | 68 | 12% | 3.0 | - | 15 (7) | 0 (1) | 17 (6) | 0 (2) |
| Opponent | Holder | 3 | 48 (3) | 48 | 0 | 0 | 67% | 5.0 | 0 (1) | 74 (2) | - | - | 48 (3) |
| Opponent | Shooter | 3 | 69 (3) | 19 | 49 | 62 | 0% | 1.0 | - | 0 (1) | 100 (2) | 0 (2) | 179 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: chf-efd8067-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 58 | 832 | 3.5 | 1.1 | 238 | 28 | +210 | 1 of 7 | 7 of 7 | +116 | +225 |
| **Mine** | all armies | 3 | 39 | 554 | 2.3 | 1.1 | 238 | 28 | +210 | 1 of 7 | 7 of 7 | +116 | +225 |
| Opponent | Vampire Counts | 1 | 0 | 712 | 6.0 | 1.2 | 119 | 0 | +119 | 1 of 6 | 6 of 6 | +92 | +124 |
| Opponent | Warriors of Chaos | 1 | 72 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 70 | 576 | 4.0 | 1.2 | 144 | 0 | +144 | 2 of 4 | 4 of 4 | +60 | +172 |
| **Opponent** | all armies | 3 | 47 | 429 | 3.7 | 1.2 | 117 | 0 | +117 | 4 of 11 | 11 of 11 | +76 | +126 |

### Effective charges: chf-efd8067-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +664) | 1 (net +170) | 5 (net +127) | 0 | 0 | 14% (1 of 7) |
| Opponent | Vampire Counts | 6 | 1 (net +55) | 0 | 0 | 0 | 1 (net +145) | 4 (net +128) | 0 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 0 | 2 (net +93) | 0 | 2 (net +195) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: chf-efd8067-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 195 | 201 | +664 | 859 | 195 | +664 | +340.5 |
| Mine | 76-89% | 1 | 411 | 170 | +170 | 170 | 0 | +170 | +41.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 471 | 119 | +127 | 182 | 24 | +159 | +33.6 |
| Mine | All fights | 7 | 423 | 138 | +210 | 277 | 45 | +232 | +54.9 |
| Opponent | Long shot (under 50%) | 2 | 80 | 125 | +28 | 28 | 0 | +28 | +34.2 |
| Opponent | 76-89% | 2 | 352 | 60 | +93 | 93 | 0 | +93 | +26.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 276 | 150 | +150 | 156 | 14 | +141 | +51.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 145 | +145 | 145 | 0 | +145 | +30.8 |
| Opponent | All fights | 11 | 272 | 129 | +117 | 120 | 8 | +112 | +41.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p11 | move | 27 | 4 (15%) | 3 (11%) | 7 (26%) | 16 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

# Doctrine scorecard: chf-efd8067-p7

### Scorecard: chf-efd8067-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | yes | 18 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 1 | 4 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 7 | 5 | 1 | 3 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 12 | 2 | 6 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 10.3 | 2.7 | 3.7 | 0.0 | 0.0 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 4.3 | 3.0 | 1.3 | 1.7 | 1.3 | 0.0 | 0.0 | 56.7 |

### KPIs: chf-efd8067-p7

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (10 of 16) | 0% (0 of 16) | 31% (10 of 32) |
| Winner chose to follow up after the loser gave ground |  | 92% (11 of 12); on the table 92% | 100% (1 of 1); on the table 100% | 92% (12 of 13); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 85% (11 of 13); on the table 85% | 100% (3 of 3); on the table 100% | 88% (14 of 16); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 27% (18 of 66) | 17% (3 of 18) | 25% (21 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (18 of 39) | 30% (3 of 10) | 43% (21 of 49) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 43% (2591 of 5998) | 47% (2817 of 5998) | 45% (5408 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 61% (560 of 913) | 79% (1290 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 36% (9 of 25) | 71% (20 of 28) | 55% (29 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 4.7 uses a game | 0% (0 of 1); 0.0 uses a game | 75% (6 of 8); 2.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 17% (1 of 6); 0.3 uses a game | 17% (1 of 6); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 31% (1757 of 5614) | 69% (4042 of 5828) | 51% (5799 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (19%) | 1.0 (20%) | 4.0 (19%) |
| MARCHED: its unit marched | 2.7 (17%) | 1.3 (27%) | 4.0 (19%) |
| CHARGED: its unit charged | 1.3 (8%) | 0.0 (0%) | 1.3 (6%) |
| IN COMBAT: engaged in combat | 7.7 (48%) | 1.0 (20%) | 8.7 (41%) |
| GONE: slain | 1.3 (8%) | 1.7 (33%) | 3.0 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 3.3 | 1.3 | 7.0 | 1.3 | 5.3 |
| not cast | 0.7 | 8.7 | 2.7 | 21.0 | 6.7 | 30.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (50%) | 0.0 (0%) | 4.0 (19%) | 1.0 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (19%) | 1.0 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) | 0.7 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.7 (19%) | 1.0 (38%) | 8.7 (41%) | 1.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.3 (50%) | 2.3 (27%) | 1.7 (62%) | 3.0 (14%) | 0.7 (10%) | 8.3 (27%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 2.0 (30%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 67% (2 of 3) | 67% (2 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 85% (45 of 53) | 50% (11 of 22) | 75% (56 of 75) |
|   cavalry | - | 67% (6 of 9) | 67% (6 of 9) |
|   character | - | 0% (0 of 7) | 0% (0 of 7) |
|   chariot | 80% (8 of 10) | - | 80% (8 of 10) |
|   infantry | 83% (10 of 12) | 83% (5 of 6) | 83% (15 of 18) |
|   war machine | 87% (27 of 31) | - | 87% (27 of 31) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (12%) | 0.7 (18%) | 1.0 (16%) |
| CHARGED: it charged | 0.7 (25%) | 0.7 (18%) | 1.3 (21%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (9%) | 0.3 (5%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (18%) | 0.7 (11%) |
| MOVED: a war machine that moved | 1.3 (50%) | 0.0 (0%) | 1.3 (21%) |
| NO TARGET IN RANGE | 0.3 (12%) | 0.0 (0%) | 0.3 (5%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (27%) | 1.0 (16%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (9%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 1.3 | 50% | 24.0 pts | 64 pts |
| infantry | 9.0 | 4.3 | 63% | 14.1 pts | 127 pts |
| war machine | 9.7 | 10.3 | 52% | 33.9 pts | 327 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 2.3 | 3.5 |
| Charges that made contact a game | 3.3 | 2.3 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.43 declared, 1.14 contact (7 units) | 0.00 declared, 0.00 contact (2 units) | 1.11 declared, 0.89 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.20 contact (10 units) | 0.35 declared, 0.35 contact (20 units) | 0.37 declared, 0.30 contact (30 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 2) | 47% (7 of 15) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 0% (0 of 6) | 57% (4 of 7) | 50% (9 of 18) |
| Chariot | 0% (0 of 2) | - | - | 0% (0 of 2) |
| Infantry | 50% (3 of 6) | 50% (1 of 2) | - | 50% (4 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 85% (11 of 13); on the table 85% | 27% (18 of 66) | 43% | 36% (9 of 25) | 86% (6 of 7); 4.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 38% | 67% (6 of 9) | 0.0 uses a game | 17% (1 of 6); 1.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 28% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 74% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 78% (7) | 60% (9) |
| ...free all their last turn and able to turn (per game) | 0.00 | 2.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 62% (8 of 13) | 100% (5 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (17 of 51) | 100% (4 of 4) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | - |
| Strategy | Lone characters that fought | 88% (7 of 8) | 55% (6 of 11) |
| Movement | Charges halted short of contact | 1.0 | 0.0 |
| Movement | Idle units | 0.0 | 1.7 |
| Movement | Points that never moved of their own | 165.0 | 56.7 |
| Movement | Fights charged into per game | 3.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 9, net +0 | 1 of 4, net -60 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 9, net +196 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 9, net +58 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 9, net -84 | 1 of 4, net -151 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (4 of 18) | 58% (7 of 12) |
| Shooting | Points destroyed by shooting units | 255.3 | 50.0 |
| Shooting | War machine shots | 9.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (9 of 27) | - |
| Shooting | Points destroyed by war machines | 95.3 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (4 of 12) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 4.7 | - |
| Magic | Wounds caused by other spells | 1.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 230.3 | 72.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.0 / 2.0 / 0.7 | 1.7 / 0.0 / 2.0 / 0.0 |
| Combat | Points destroyed in combat | 278.7 | 178.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +61 | +22 |
| Combat | Net per 100 charger points, damage counted | +20.0 | +7.9 |
| Combat | First round won (charged fights) | 90% | 50% |
| Combat | Net points per charged fight | +40 | -8 |
| Combat | Net points per supported fight / lone fight | - / +40 | -60 / +3 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 10 | 5 of 6 |
| Game | Points lost | 300.3 | 1061.0 |
| Game | VP from objectives | 956.7 | 263.3 |
| Game | Lone holders (player turns) | 10.3 | 4.3 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1500 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1361
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +117.0 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 38.7 |
| ARMY TABLE | 7.0 | +77.2 | 0.0 | 0.0 | 23.7 | +641.4 | 0.0 | 196.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +3.1 | 0.0 | 123.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 1.3 | +301.9 | 0.0 | 166.7 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +6.2 | 0.0 | 0.0 |
| BOMBING RUN | 1.0 | +91.0 | 400.3 | 50.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 120.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +283.6 | 570.3 | 55.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.0 | +164.2 | 276.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 166.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.3 | +9.0 | 0.0 | 0.0 | 2.0 | +75.2 | 0.0 | 125.0 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -143.1 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +5.3 | 0.0 | 0.0 | 0.3 | +31.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 9.7 | -769.2 | 0.0 | 100.0 | 26.3 | -1418.1 | 0.0 | 1333.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 306.7 | 195.3 | 0.3 | +0.0 | 0.0 | 38.7 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 304.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 195.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +330.7 | 166.7 | 166.7 |
| COVER ONCE | 4.3 | -292.4 | 0.0 | 55.0 | 12.3 | -997.5 | 0.0 | 343.0 |
| DENIED BY THE FIGHT | 0.7 | -6.6 | 48.0 | 123.0 | 1.0 | -2.9 | 55.0 | 53.7 |
| DEPLOY BY FIGURES | 4.7 | -28.4 | 0.0 | 0.0 | 5.7 | +153.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -19.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +9.9 | 55.0 | 53.7 |
| EXACT ROUND | 2.7 | +25.6 | 157.0 | 0.0 | 2.0 | +2.2 | 55.0 | 112.3 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.3 | +3.6 | 223.3 | 195.3 | 2.0 | +0.2 | 0.0 | 58.7 |
| FALLS SHORT | - | - | - | - | 27.7 | +246.4 | 0.0 | 731.3 |
| FIGHT TO THE END | 1.7 | +19.5 | 136.7 | 72.3 | 1.3 | +14.7 | 0.0 | 38.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| FIVE ACTION | 76.7 | +6729.2 | 2899.3 | 505.3 | 68.0 | +4167.2 | 155.0 | 1649.0 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 621.7 |
| FOLLOW UP WEIGHED | 2.7 | +513.1 | 0.0 | 72.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +416.3 | 374.3 | 195.3 | 2.3 | +150.6 | 55.0 | 112.3 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 132.7 |
| FRIEND SHOOTS FIRST | 0.7 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +7.7 | 0.0 | 123.0 | - | - | - | - |
| GIVES UP | 0.3 | -3.5 | 47.7 | 0.0 | 0.3 | -4.1 | 55.0 | 53.7 |
| GOAL WALK | 1.7 | +97.5 | 0.0 | 0.0 | 16.3 | +2542.6 | 0.0 | 173.3 |
| GUN MASK | 1.0 | +242.8 | 0.0 | 100.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | +0.1 | 181.3 | 72.3 | 1.0 | -2.5 | 0.0 | 38.7 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 8.0 | +0.0 | 0.0 | 16.7 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 72.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 20.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 19.0 | +0.0 | 0.0 | 1155.7 |
| HIS CHARGE DENIED | 0.7 | +39.3 | 48.0 | 123.0 | 1.0 | +124.8 | 0.0 | 20.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 100.0 | 5.0 | +0.0 | 0.0 | 40.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 166.7 |
| HIS MOVE AND SHOT | 1.0 | -30.8 | 0.0 | 0.0 | 8.7 | -197.5 | 0.0 | 673.7 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 166.7 |
| HIS RANDOM MOVE | 7.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 10.7 | +157.7 | 0.0 | 200.0 | 57.7 | +3117.2 | 0.0 | 1469.7 |
| HIS SHOTS BY HIS RUN | 11.3 | +159.9 | 0.0 | 200.0 | 51.3 | +1855.6 | 0.0 | 1356.3 |
| HIS TURN DENIED | 0.3 | +24.4 | 0.0 | 0.0 | 0.3 | +12.8 | 55.0 | 53.7 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 11.0 | +1118.8 | 0.0 | 0.0 | 8.0 | +798.3 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -136.9 | 326.3 | 195.3 | 2.3 | -88.1 | 55.0 | 112.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +13.7 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +81.0 | 0.0 | 38.7 |
| IDLE COST | - | - | - | - | 14.7 | -226.2 | 0.0 | 471.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +17.7 | 0.0 | 20.0 |
| KEEP FALLS | 0.3 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +18.9 | 0.0 | 0.0 | 0.7 | +18.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 484.3 | 535.3 | 5.7 | +0.0 | 267.7 | 818.3 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.7 | +0.2 | 267.7 | 195.3 | 2.0 | +1.0 | 0.0 | 58.7 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +1.6 | 0.0 | 0.0 | 3.0 | +219.7 | 0.0 | 214.7 |
| MANOEUVRE | 1.0 | +0.1 | 0.0 | 50.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.3 | +8.0 | 0.0 | 134.0 |
| MARCH BY THE SUM | 2.0 | +121.4 | 0.0 | 0.0 | 0.7 | +37.4 | 0.0 | 38.7 |
| MARCH CHECK | 2.3 | +106.4 | 0.0 | 0.0 | 1.0 | +44.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.3 | +58.7 | 0.0 | 0.0 | 0.7 | +36.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.3 | +81.5 | 0.0 | 0.0 | 1.7 | -28.5 | 0.0 | 172.7 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +99.9 | 0.0 | 0.0 | 2.3 | +108.8 | 0.0 | 166.7 |
| MEETS IN TIME | 3.0 | +347.8 | 0.0 | 0.0 | 2.3 | +358.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.7 | +286.3 | 0.0 | 0.0 | 1.0 | +9.7 | 0.0 | 166.7 |
| MISSILES NEXT TURN | 13.3 | +198.7 | 0.0 | 0.0 | 3.7 | +16.0 | 0.0 | 272.3 |
| MISSILES ON ONE TARGET | 0.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 38.7 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 166.7 |
| MOVE TO CHARGE COMPUTED | 6.0 | +440.3 | 0.0 | 0.0 | 5.7 | +787.2 | 0.0 | 166.7 |
| NEARER NOT NEEDED | 4.3 | +194.9 | 0.0 | 0.0 | 4.7 | +189.3 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 4.7 | +412.4 | 0.0 | 0.0 | 5.7 | +645.6 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.3 | +64.0 | 183.7 | 195.3 | 0.7 | +1.0 | 123.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.3 | -237.4 | 354.3 | 195.3 | 2.3 | -88.6 | 55.0 | 112.3 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +22.3 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| OFF BEST | 5.7 | -277.6 | 47.7 | 55.0 | 6.0 | -240.6 | 0.0 | 77.3 |
| OGRE LOADER SECOND SHOT | 6.0 | +56.3 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -196.4 | 0.0 | 50.0 | 7.0 | -127.5 | 0.0 | 259.0 |
| ONE JOINT FIGURE | 0.3 | -12.5 | 0.0 | 72.3 | 0.7 | -30.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +68.8 | 0.0 | 0.0 | 3.7 | -75.1 | 0.0 | 20.0 |
| ONE PROMISE A TARGET | 1.0 | -6.3 | 0.0 | 0.0 | 1.3 | -119.6 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 2.0 | +49.3 | 86.3 | 195.3 | 0.3 | +0.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +72.7 | 20.0 | 123.0 | 1.0 | +14.9 | 55.0 | 73.7 |
| PATHS CROSS | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -71.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 34.7 | +1513.8 | 1447.3 | 401.0 | 36.0 | +216.7 | 587.7 | 1657.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 41.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -107.4 | 0.0 | 0.0 | 7.3 | -239.7 | 0.0 | 166.7 |
| PROMISE KNOWS THE FIGHT | 1.7 | -12.6 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 166.7 |
| PROMISE READS THE TABLE | 0.3 | -23.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +1963.4 | 747.3 | 0.0 | 9.7 | +821.0 | 0.0 | 402.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +40.6 | 0.0 | 113.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +21.3 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -58.2 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 4.3 | +146.1 | 374.3 | 195.3 | 2.0 | -37.4 | 55.0 | 112.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -16.1 | 55.0 | 53.7 |
| RUN DOWN | 2.7 | -20.7 | 223.3 | 123.0 | 2.3 | -46.1 | 55.0 | 112.3 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +3.7 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +45.5 | 0.0 | 0.0 | 0.7 | +12.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +2.0 | 47.7 | 0.0 | 0.7 | +31.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 5.3 | -570.8 | 0.0 | 20.0 |
| SET UP BY THE SET | 1.7 | +8.5 | 0.0 | 0.0 | 6.0 | +490.9 | 262.0 | 20.0 |
| SET UP TOGETHER | 1.0 | +1.6 | 0.0 | 0.0 | 3.7 | +222.5 | 0.0 | 214.7 |
| SHOOTERS ON THE TABLE | 16.3 | +0.0 | 0.0 | 55.0 | 2.3 | +0.0 | 0.0 | 105.7 |
| SHOOTS FROM THE BEST SPOT | 5.7 | +74.2 | 504.0 | 0.0 | 0.3 | +16.9 | 0.0 | 67.0 |
| SHOT OR CHARGE | 0.3 | -3.4 | 38.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 7.7 | -167.8 | 0.0 | 200.0 | 38.7 | +598.9 | 0.0 | 1251.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +1028.0 | 0.0 | 155.0 | 4.3 | +121.4 | 0.0 | 207.7 |
| SPELL WORTH | 1.7 | +20.5 | 0.0 | 0.0 | 1.7 | +50.4 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 1.0 | -20.4 | 50.3 | 72.3 | 0.3 | -3.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 50.0 | 10.3 | +0.0 | 0.0 | 405.7 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 42.7 | +0.0 | 2525.0 | 110.0 | 16.3 | +0.0 | 100.0 | 326.7 |
| STAY WORTH | 34.7 | +94.4 | 1534.3 | 265.0 | 3.7 | +15.2 | 0.0 | 207.7 |
| STOPS | - | - | - | - | 0.3 | +0.4 | 0.0 | 38.7 |
| STRIKE BY THE ODDS | 0.3 | +1.2 | 20.0 | 0.0 | 0.3 | +2.6 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +127.8 | 0.0 | 0.0 | 3.7 | +220.7 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 123.0 | 0.3 | +0.0 | 0.0 | 20.0 |
| SUPPORT WORKED OUT | 1.7 | +127.8 | 0.0 | 0.0 | 3.7 | +220.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +5.2 | 0.0 | 0.0 | 0.7 | +33.5 | 0.0 | 41.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.7 | +2.2 | 267.7 | 195.3 | 1.7 | -3.1 | 55.0 | 92.3 |
| THE PROMISE ADDS | 0.3 | -23.7 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 38.7 | 67.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 50.0 | 2.3 | +0.0 | 0.0 | 41.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 50.0 | 1.7 | +0.0 | 0.0 | 41.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.3 | +0.0 | 0.0 | 155.0 | 32.0 | +0.0 | 0.0 | 750.3 |
| TIED UP BY THE SUM | 2.0 | +242.2 | 97.3 | 123.0 | - | - | - | - |
| TIME ON OUR SIDE | 27.3 | +451.7 | 77.3 | 100.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 1.0 | +0.6 | 0.0 | 166.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.3 | +23.4 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +9.4 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.1 | 50.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +78.9 | 0.0 | 0.0 | 0.3 | +24.0 | 0.0 | 53.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -487.0 | 0.0 | 0.0 | 2.3 | -334.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +28.9 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.7 | +199.9 | 112.3 | 55.0 | 2.3 | +59.9 | 123.0 | 223.3 |
| WOUNDS ON THE RANKS | 2.7 | +65.3 | 0.0 | 0.0 | 3.0 | +128.5 | 0.0 | 259.0 |

### Rule changes: chf-efd8067-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 92 | 92 | 71 | 23.67 | +1920 | +27.0 |
| HOLDER ASSIGNMENT | 57 | 57 | 52 | 17.33 | +2903 | +55.8 |
| FIVE ACTION | 434 | 412 | 42 | 14.00 | +4734 | +112.7 |
| HIS SHOT LIST | 205 | 194 | 41 | 13.67 | +1026 | +25.0 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1555 | -44.4 |
| GOAL WALK | 54 | 54 | 25 | 8.33 | +3505 | +140.2 |
| CHARGE LOSSES | 108 | 101 | 22 | 7.33 | +3073 | +139.7 |
| SHOT RISK POINTS | 139 | 130 | 20 | 6.67 | +496 | +24.8 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 18 | 18 | 18 | 6.00 | +169 | +9.4 |
| HIS SHOTS BY HIS RUN | 188 | 178 | 17 | 5.67 | +307 | +18.1 |
| MOVE TO CHARGE COMPUTED | 35 | 27 | 16 | 5.33 | +648 | +40.5 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 14 | 4.67 | -1041 | -74.4 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 14 | 4.67 | +37 | +2.6 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 27 | 13 | 4.33 | +641 | +49.3 |
| DEPLOY BY FIGURES | 31 | 31 | 12 | 4.00 | +186 | +15.5 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CAST JOB | 18 | 18 | 10 | 3.33 | +212 | +21.2 |
| CHALLENGE BY POINTS | 10 | 10 | 10 | 3.33 | +253 | +25.3 |
| QUARTER ODDS | 74 | 70 | 10 | 3.33 | +1060 | +106.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1540 | +171.1 |
| TIME ON OUR SIDE | 82 | 61 | 9 | 3.00 | +34 | +3.8 |
| FOUR ROUNDS | 21 | 18 | 8 | 2.67 | +310 | +38.7 |
| MARCH BY THE SUM | 8 | 8 | 8 | 2.67 | +476 | +59.5 |
| MARCH CHECK | 10 | 10 | 8 | 2.67 | +144 | +18.0 |
| SET UP BY THE SET | 23 | 23 | 8 | 2.67 | +606 | +75.8 |
| MAX FOR POSITIONING | 23 | 22 | 7 | 2.33 | +61 | +8.7 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -377 | -53.9 |
| SUPPORT ADDS | 16 | 16 | 7 | 2.33 | +219 | +31.3 |
| SUPPORT WORKED OUT | 16 | 16 | 7 | 2.33 | +219 | +31.3 |
| COVER ONCE | 50 | 30 | 6 | 2.00 | +50 | +8.2 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +112 | +18.6 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 2.00 | -287 | -47.8 |
| MEETS IN TIME | 16 | 16 | 6 | 2.00 | +223 | +37.1 |
| NO CHAFF EDGES | 12 | 11 | 6 | 2.00 | +46 | +7.6 |
| RISK BY ARC | 19 | 16 | 6 | 2.00 | +114 | +18.9 |
| WHOLE FIGHT DANGER | 15 | 13 | 6 | 2.00 | +737 | +122.8 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 15 | 14 | 5 | 1.67 | -38 | -7.6 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +122 | +24.3 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +205 | +41.1 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 5 | 5 | 4 | 1.33 | +222 | +55.5 |
| IDLE COST | 44 | 22 | 4 | 1.33 | +47 | +11.7 |
| ONE FIGHT FORMULA | 42 | 23 | 4 | 1.33 | +160 | +39.9 |
| SCOUT BY DROPS | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 1.00 | +273 | +91.0 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -380 | -126.7 |
| FALLS SHORT | 83 | 62 | 3 | 1.00 | +9 | +3.1 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +53 | +17.7 |
| ONE OBJECTIVE FORMULA | 24 | 16 | 3 | 1.00 | +76 | +25.4 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +173 | +57.6 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +101 | +33.5 |
| SHOTS IN THE MOVE | 62 | 41 | 3 | 1.00 | +13 | +4.5 |
| STAY WORTH | 115 | 101 | 3 | 1.00 | +14 | +4.7 |
| THE ROW IN ITS ORDER | 11 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +175 | +58.3 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +354 | +176.8 |
| BACKS UP THE FIGHT | 4 | 3 | 2 | 0.67 | +137 | +68.4 |
| HIS MOVE AND SHOT | 29 | 28 | 2 | 0.67 | +3 | +1.3 |
| HONEST WORTH | 20 | 17 | 2 | 0.67 | +2 | +0.8 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MISSILES IN THE MOVE | 38 | 25 | 2 | 0.67 | +47 | +23.6 |
| OVERRUNS AWAY | 6 | 5 | 2 | 0.67 | +205 | +102.4 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +10 | +4.8 |
| SET UP TOGETHER | 14 | 5 | 2 | 0.67 | +97 | +48.4 |
| SHOTS AFTER THE MOVES | 19 | 19 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.3 |
| CANNON PLANNED TARGET | 27 | 27 | 1 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 14 | 13 | 1 | 0.33 | +1 | +1.1 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 16 | 13 | 1 | 0.33 | +0 | +0.5 |
| FIGHT TO THE END | 9 | 6 | 1 | 0.33 | +1 | +1.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +23 | +23.2 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +73 | +72.9 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +0 | +0.2 |
| MISSILES NEXT TURN | 51 | 30 | 1 | 0.33 | +5 | +5.4 |
| NEARER NOT NEEDED | 27 | 24 | 1 | 0.33 | +52 | +52.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +48 | +48.1 |
| OPENS UP IN FULL | 7 | 6 | 1 | 0.33 | +0 | +0.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -214 | -213.7 |
| REFORMS TO MEET IT | 3 | 3 | 1 | 0.33 | +6 | +5.6 |
| RUN DOWN | 15 | 12 | 1 | 0.33 | +64 | +64.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| SPELLS IN THE FIGHT | 4 | 3 | 1 | 0.33 | +1 | +1.1 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -33 | -32.9 |
| SURE REACH TOGETHER | 4 | 3 | 1 | 0.33 | +38 | +37.7 |
| THE FIGHT MOVES | 13 | 10 | 1 | 0.33 | +0 | +0.5 |
| THE PROMISE ADDS | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +26 | +25.6 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | not checked | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 52 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 47 | 43 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 24 | 22 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 73 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 73 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 14 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 20 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 212 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 16 | 16 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 56 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 35 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 177 | 171 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 199 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | not checked | - | - | - | - |
| WHOLE FIGHT REACTION | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.67 | 44.5 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.67 | 74.4 |
| ARMY TABLE | rule | 0.33 | 2.67 | 51.3 |
| MARCH OF THE TABLE | rule | 1.00 | 0.67 | 57.4 |
| ONE PROMISE A TARGET | rule | 0.33 | 1.33 | 80.3 |
| NO REASON | gate | - | 1.33 | 22.9 |
| RULE SWITCHED OFF | gate | 1.33 | - | 65.3 |
| CHARGE NOW FIRST | rule | 1.00 | - | 126.7 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 12.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 27.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 69.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 213.7 |
| SET UP BY THE SET | rule | - | 0.33 | 26.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 32.9 |

### Plans: chf-efd8067-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 67% | 485 | 329 | 68% |
| Mine | move | 17.3 | 98% | 1223 | 0 | 0% |
| Mine | shoot | 13.3 | 65% | 1180 | 1185 | 100% |
| Opponent | charge | 2.0 | 50% | 176 | 130 | 74% |
| Opponent | join | 3.0 | 89% | 143 | 0 | 0% |
| Opponent | move | 29.7 | 92% | 2134 | 0 | 0% |
| Opponent | shoot | 1.3 | 75% | 86 | 87 | 101% |

### Packages: hunt the guns, chf-efd8067-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 95 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 286 |

### Battle groups: chf-efd8067-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 65 (9) | 65 | 0 | 26 | 11% | 2.0 | 56 (3) | 67 (6) | - | 24 (5) | 93 (4) |
| Mine | Clean-up | 2 | 90 (2) | 0 | 90 | 0 | 0% | 3.5 | 0 (1) | 170 (1) | - | 90 (2) | - |
| Mine | Fast Hammer | 4 | 113 (4) | 75 | 38 | 15 | 0% | 1.8 | 25 (1) | 157 (2) | 173 (1) | 103 (3) | 173 (1) |
| Mine | Holder | 1 | 88 (1) | 0 | 88 | 0 | 0% | 2.0 | 88 (1) | - | - | 88 (1) | - |
| Mine | Shooter | 4 | 134 (4) | 50 | 84 | 0 | 0% | 2.8 | 35 (2) | 584 (1) | 31 (1) | 248 (2) | 22 (2) |
| Mine | War machine | 6 | 29 (6) | 29 | 0 | 17 | 0% | 1.2 | 173 (1) | 0 (4) | 0 (1) | 173 (1) | 0 (5) |
| Mine | Wizard | 3 | 33 (3) | 33 | 0 | 0 | 33% | 1.5 | 35 (2) | 31 (1) | - | 35 (2) | 31 (1) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Character | 10 | 22 (10) | 22 | 0 | 51 | 30% | 2.6 | 24 (3) | 30 (5) | 0 (1) | 37 (6) | 0 (3) |
| Opponent | Fast Hammer | 9 | 19 (9) | 11 | 8 | 85 | 22% | 2.4 | 0 (1) | 23 (7) | 0 (1) | 27 (6) | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 63 | 33% | 2.5 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Holder | 5 | 67 (5) | 0 | 67 | 17 | 100% | - | 11 (2) | 142 (2) | 0 (1) | 9 (2) | 108 (3) |
| Opponent | Shooter | 1 | 85 (1) | 85 | 0 | 0 | 0% | 1.0 | - | 85 (1) | - | 85 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | - | - | - |

### Charged fights: chf-efd8067-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 581 | 256 | 3.3 | 1.0 | 77 | 37 | +40 | 4 of 10 | 9 of 10 | - | +40 |
| Opponent | High Elf Realms | 1 | 150 | 0 | 2.0 | 1.0 | 0 | 76 | -76 | 2 of 2 | 1 of 2 | - | -76 |
| Opponent | Vampire Counts | 1 | 217 | 165 | 3.0 | 1.3 | 55 | 20 | +35 | 2 of 3 | 1 of 3 | -60 | +82 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 122 | 55 | 2.0 | 1.2 | 28 | 35 | -8 | 5 of 6 | 3 of 6 | -60 | +3 |

### Effective charges: chf-efd8067-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 10 | 1 (net +0) | 0 | 2 (net +196) | 1 (net +0) | 2 (net +58) | 3 (net -84) | 1 | 22% (2 of 9) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net -151) | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 3 | 1 (net -60) | 0 | 0 | 1 (net +165) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 217 | 285 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 2 | 306 | 247 | +196 | 196 | 27 | +169 | +55.4 |
| Mine | 76-89% | 1 | 334 | 470 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 320 | 148 | -84 | 153 | 131 | +22 | +6.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 352 | 88 | +58 | 58 | 26 | +32 | +9.0 |
| Mine | No odds | 1 | 233 | 143 | +143 | 143 | 0 | +143 | +61.4 |
| Mine | All fights | 10 | 306 | 201 | +40 | 111 | 50 | +61 | +20.0 |
| Opponent | Long shot (under 50%) | 1 | 110 | 217 | -60 | 0 | 60 | -60 | -54.5 |
| Opponent | 76-89% | 2 | 138 | 199 | +82 | 160 | 0 | +160 | +115.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 233 | -151 | 116 | 151 | -34 | -7.1 |
| Opponent | No odds | 2 | 387 | 346 | +0 | 0 | 48 | -48 | -12.3 |
| Opponent | All fights | 6 | 275 | 257 | -8 | 73 | 51 | +22 | +7.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p7 | move | 24 | 5 (21%) | 4 (17%) | 1 (4%) | 18 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

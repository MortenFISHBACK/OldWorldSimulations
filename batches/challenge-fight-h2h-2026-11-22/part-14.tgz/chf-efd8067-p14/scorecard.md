# Doctrine scorecard: chf-efd8067-p14

### Scorecard: chf-efd8067-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 4 | 0 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 790 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 6 | 0 | 1 | 2 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 1100 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 245 |
| **Average** | | | Mine | 33% | 0.5 | 4.0 | 0.0 | 3.3 | 0.3 | 0.0 | 0.0 | 686.7 |
| **Average** | | | Opponent | 67% | 4.5 | 4.0 | 1.7 | 1.7 | 0.7 | 0.0 | 0.0 | 123.3 |

### KPIs: chf-efd8067-p14

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (4 of 12) | 0% (0 of 15) | 15% (4 of 27) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 100% | 100% (4 of 4); on the table 100% | 71% (5 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 100% | 80% (4 of 5); on the table 100% | 70% (7 of 10); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 22% (8 of 36) | 17% (1 of 6) | 21% (9 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 24% (8 of 33) | 50% (1 of 2) | 26% (9 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (1 of 1) | - | 100% (1 of 1) |
| Points that never fought | lower | 56% (3301 of 5897) | 69% (4151 of 5999) | 63% (7452 of 11896) |
|   infantry points that never fought | lower | 48% (686 of 1437) | 100% (938 of 938) | 68% (1624 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 50% (10 of 20) | 55% (23 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (2 of 4); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2582 of 4484) | 46% (2148 of 4648) | 52% (4730 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (71%) | 0.0 (0%) | 6.7 (61%) |
| MARCHED: its unit marched | 1.7 (18%) | 0.3 (20%) | 2.0 (18%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.7 (7%) | 1.3 (80%) | 2.0 (18%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.7 | 3.0 | 0.3 | 0.7 |
| not cast | 0.0 | 2.3 | 11.0 | 1.7 | 7.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (18%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.7 (61%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.0 (18%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (29%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 2.0 (18%) | 1.3 (80%) | 2.7 (36%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (45%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 60% (3 of 5) | - | 60% (3 of 5) |
| the unit moved after it | 100% (3 of 3) | - | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (47 of 62) | 44% (56 of 126) | 55% (103 of 188) |
|   cavalry | - | 60% (12 of 20) | 60% (12 of 20) |
|   character | - | 0% (0 of 23) | 0% (0 of 23) |
|   chariot | 53% (10 of 19) | 50% (3 of 6) | 52% (13 of 25) |
|   infantry | - | 56% (33 of 59) | 56% (33 of 59) |
|   war machine | 86% (37 of 43) | 44% (8 of 18) | 74% (45 of 61) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.0 (9%) | 2.0 (7%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (13%) | 3.0 (11%) |
| IN COMBAT: it fought this turn or the last | 1.0 (20%) | 1.3 (6%) | 2.3 (8%) |
| MOVED: a war machine that moved | 1.0 (20%) | 0.7 (3%) | 1.7 (6%) |
| NO TARGET IN RANGE | 1.3 (27%) | 12.0 (51%) | 13.3 (47%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (33%) | 2.0 (9%) | 3.7 (13%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.7 (7%) | 1.7 (6%) |
| OTHER BAR | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.0 | 79% | 3.8 pts | 18 pts |
| chariot | 4.7 | 4.0 | 50% | 22.7 pts | 106 pts |
| infantry | 13.0 | 3.0 | 79% | 5.2 pts | 68 pts |
| war machine | 15.3 | 15.7 | 70% | 18.1 pts | 277 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 6.0 | 3.2 |
| Charges that made contact a game | 0.0 | 3.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.00 contact (20 units) | 0.60 declared, 0.37 contact (30 units) | 0.38 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Character in a unit | 75% (3 of 4) | 0% (0 of 2) | - | 50% (3 of 6) |
| Character on its own | 50% (1 of 2) | - | 40% (2 of 5) | 43% (3 of 7) |
| Chariot | - | 75% (3 of 4) | - | 75% (3 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 67% (6 of 9) | 100% (2 of 2) | - | 73% (8 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 33% (1 of 3); on the table 100% | 42% (5 of 12) | 19% | 17% (1 of 6) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 12% (3 of 24) | 74% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Empire of Man | 1 | - | 17% (1 of 6) | 85% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 100% | - | 61% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (3) | - | 33% (3) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: chf-efd8067-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | - | 43% (6 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 73% (36 of 49) | 74% (25 of 34) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 83% (5 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 1.7 |
| Movement | Points that never moved of their own | 686.7 | 123.3 |
| Movement | Fights charged into per game | 0.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 7, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 7, net +133 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.3 | 16.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (4 of 10) | 24% (12 of 50) |
| Shooting | Points destroyed by shooting units | 126.7 | 65.0 |
| Shooting | War machine shots | 12.7 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (11 of 38) | 50% (4 of 8) |
| Shooting | Points destroyed by war machines | 117.0 | 103.3 |
| Magic | Magic missiles cast | 1.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 2.3 | 1.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 24.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.7 / 0.0 | 4.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 235.3 | 225.3 |
| Combat | Points run down | 0.0 | 45.7 |
| Combat | Net points per charged fight, damage counted | - | +27 |
| Combat | Net per 100 charger points, damage counted | - | +7.2 |
| Combat | First round won (charged fights) | - | 56% |
| Combat | Net points per charged fight | - | +12 |
| Combat | Net points per supported fight / lone fight | - / - | -198 / +72 |
| Combat | Charged fights on a top-3 enemy unit | - | 5 of 9 |
| Game | Points lost | 547.0 | 462.0 |
| Game | VP from objectives | 380.0 | 913.3 |
| Game | Lone holders (player turns) | 0.5 | 4.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -534 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1009
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.3 | +95.4 | 0.0 | 34.7 | 24.3 | +410.1 | 0.0 | 262.7 |
| ARTILLERY RE-ROLL WEIGHED | 8.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +93.3 | 0.0 | 60.7 | 0.3 | +13.4 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.9 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | -541.7 | 0.0 | 65.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 253.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.3 | +165.0 | 464.0 | 36.7 | 3.0 | +99.5 | 516.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.7 | -35.2 | 63.3 | 0.0 |
| CAST JOB | 2.0 | +19.2 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +50.5 | 48.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +3.7 | 0.0 | 0.0 | 0.7 | +44.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -98.4 | 0.0 | 170.3 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 2.0 | -47.4 | 0.0 | 235.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.0 | -704.8 | 0.0 | 328.0 | 15.7 | -575.6 | 0.0 | 398.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 264.3 | 130.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 145.3 | 13.7 | +0.0 | 0.0 | 24.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +332.8 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.7 | -555.1 | 0.0 | 187.7 | 3.3 | -88.4 | 0.0 | 93.7 |
| DEPLOY BY FIGURES | 8.7 | -2.7 | 0.0 | 0.0 | 8.0 | -36.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | -0.5 | 0.0 | 0.0 | 5.3 | +12.1 | 341.7 | 130.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.3 | +11.6 | 243.7 | 300.3 |
| FALLS SHORT | 9.3 | +180.3 | 0.0 | 72.7 | 14.7 | +133.3 | 0.0 | 246.0 |
| FEATURE BUFFS | 6.0 | +73.3 | 0.0 | 54.0 | 3.0 | +43.2 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.7 | +12.9 | 163.3 | 170.3 |
| FIVE ACTION | 88.7 | +3474.4 | 1670.0 | 844.7 | 114.7 | +8316.2 | 2174.0 | 981.7 |
| FLANK NOT WEIGHED | 12.0 | +0.0 | 0.0 | 93.3 | 1.3 | +0.0 | 0.0 | 93.7 |
| FOLLOW UP WEIGHED | 0.7 | +104.4 | 0.0 | 0.0 | 1.0 | +116.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +4.3 | 0.0 | 0.0 | 6.0 | +325.1 | 341.7 | 300.3 |
| FREED FROM HIS FIGHT | 6.0 | +0.0 | 0.0 | 148.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -5.3 | 0.0 | 0.0 | 1.0 | -0.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.6 | 0.0 | 0.0 | 0.3 | -0.9 | 31.7 | 0.0 |
| GOAL WALK | 10.0 | +719.0 | 0.0 | 88.7 | 20.0 | +2780.1 | 0.0 | 51.3 |
| GUN FIGURES | 0.7 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.7 | +23.3 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +5.9 | 60.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 206.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 91.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 63.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 121.3 | 4.7 | +0.0 | 0.0 | 347.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +27.1 | 63.3 | 0.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 167.3 | - | - | - | - |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 60.7 | 4.0 | +0.0 | 0.0 | 93.7 |
| HIS MOVE AND SHOT | 4.3 | -28.7 | 0.0 | 0.0 | 3.3 | -47.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 60.7 | 5.0 | +0.0 | 0.0 | 46.7 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 60.7 | 5.0 | +0.0 | 0.0 | 93.7 |
| HIS RANDOM MOVE | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.7 | +1638.5 | 0.0 | 564.7 | 65.0 | +1954.4 | 0.0 | 633.3 |
| HIS SHOTS BY HIS RUN | 34.7 | +350.2 | 0.0 | 537.7 | 39.0 | +394.1 | 0.0 | 493.0 |
| HIS TURN DENIED | 0.3 | +0.6 | 0.0 | 0.0 | 0.7 | +8.7 | 0.0 | 65.0 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 108.0 | 26.7 | +0.0 | 0.0 | 121.7 |
| HOLDER ASSIGNMENT | 7.0 | +712.6 | 0.0 | 27.0 | 17.0 | +1457.9 | 0.0 | 73.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -1.5 | 0.0 | 0.0 | 4.3 | -191.7 | 313.3 | 235.3 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +68.7 | 0.0 | 0.0 |
| IDLE COST | 5.7 | -58.2 | 0.0 | 45.7 | 13.0 | -190.6 | 0.0 | 93.7 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | +143.8 | 63.3 | 170.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +27.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +61.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 0.0 | 235.0 | 5.7 | +0.0 | 255.3 | 511.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 0.0 | 0.0 | 1.7 | -5.7 | 87.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +4.8 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | -9.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +97.2 | 0.0 | 55.3 | 3.7 | +47.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.9 | 0.0 | 0.0 | 2.3 | +241.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +92.8 | 0.0 | 27.0 | 0.3 | +15.6 | 0.0 | 126.7 |
| MISSILES NEXT TURN | 5.0 | +72.6 | 0.0 | 27.0 | 0.7 | +15.5 | 0.0 | 126.7 |
| MOVE ORDER | 1.3 | +0.0 | 17.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +224.0 | 0.0 | 117.3 | 2.7 | +192.9 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +348.2 | 0.0 | 30.3 | 12.0 | +465.2 | 0.0 | 49.7 |
| NEXT CHARGE BY LIST | 3.3 | +246.0 | 0.0 | 117.3 | 3.3 | +241.4 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.7 | +26.6 | 235.3 | 45.7 | 4.3 | +90.0 | 176.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 5.0 | -254.8 | 278.3 | 300.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -317.8 | 0.0 | 82.3 | 4.7 | -89.6 | 103.3 | 89.0 |
| OGRE LOADER SECOND SHOT | 4.0 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.0 | -25.4 | 0.0 | 58.7 | 4.7 | -119.4 | 0.0 | 93.7 |
| ONE JOINT FIGURE | - | - | - | - | 2.3 | +239.4 | 63.3 | 235.3 |
| ONE OBJECTIVE FORMULA | 5.0 | +229.8 | 0.0 | 27.0 | 7.3 | +235.0 | 0.0 | 24.0 |
| ONE PROMISE A TARGET | 0.7 | -24.8 | 0.0 | 0.0 | 0.3 | -12.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +46.7 | 45.7 | 65.0 |
| OPENS UP IN FULL | - | - | - | - | 2.7 | +71.4 | 193.3 | 65.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +2.2 | 27.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| PLAN RESULT | 39.0 | +982.8 | 831.3 | 630.3 | 51.3 | +838.5 | 1191.7 | 1007.7 |
| PRIZE BY WORTH | - | - | - | - | 1.0 | +67.8 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -409.4 | 0.0 | 174.0 | 6.3 | -143.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | -12.5 | 0.0 | 117.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 19.3 | +1083.1 | 46.7 | 60.7 | 20.7 | +1981.4 | 126.7 | 93.3 |
| RANDOM MOVE BY FIGURES | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +14.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.0 | +119.6 | 0.0 | 55.3 | 1.7 | +66.3 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 28.3 | 5.3 | +23.7 | 0.0 | 24.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -0.8 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 170.3 |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +59.1 | 0.0 | 48.0 |
| RISK BY ARC | 0.3 | +9.6 | 0.0 | 0.0 | 5.0 | +70.0 | 313.3 | 235.3 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -19.2 | 58.7 | 235.3 |
| RUN DOWN | - | - | - | - | 3.0 | -9.5 | 181.7 | 235.3 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.2 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +11.8 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +10.7 | 0.0 | 0.0 | 1.0 | +44.1 | 120.7 | 65.0 |
| SET CREDITED ONCE | 0.7 | -19.3 | 0.0 | 0.0 | 0.3 | -53.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +6.3 | 0.0 | 0.0 | 2.0 | +9.5 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +10.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 140.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +41.2 | 0.0 | 0.0 | 1.3 | +6.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -0.7 | 95.0 | 0.0 |
| SHOT RISK POINTS | 24.3 | +135.4 | 0.0 | 441.3 | 28.3 | -141.9 | 0.0 | 539.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +688.5 | 0.0 | 140.0 | 22.7 | +382.8 | 0.0 | 73.7 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 104.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 48.0 | 0.0 | 6.0 | +0.0 | 206.7 | 0.0 |
| STANDS STILL | 55.7 | +0.0 | 1670.0 | 604.0 | 52.7 | +0.0 | 1832.3 | 46.7 |
| STAY WORTH | 32.7 | -395.9 | 1322.0 | 346.7 | 36.3 | +376.8 | 1662.3 | 73.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +31.8 | 38.3 | 65.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -3.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.0 | +670.7 | 0.0 | 152.0 | 2.7 | +67.1 | 0.0 | 23.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 27.0 | 0.0 |
| SUPPORT WORKED OUT | 10.0 | +670.7 | 0.0 | 152.0 | 2.7 | +67.1 | 0.0 | 23.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 23.3 |
| THE FIGHT MOVES | - | - | - | - | 1.3 | +73.7 | 27.0 | 170.3 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 30.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 422.3 | 51.3 | +0.0 | 0.0 | 340.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.7 | +127.5 | 90.0 | 65.0 |
| TIME ON OUR SIDE | 22.0 | +256.7 | 0.0 | 443.7 | 24.3 | +193.1 | 0.0 | 48.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 253.3 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 2.0 | -179.4 | 63.3 | 0.0 |
| WHO HITS BACK | 0.3 | +182.3 | 0.0 | 0.0 | 0.3 | +61.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -437.0 | 0.0 | 0.0 | 2.0 | -61.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.1 | 31.7 | 0.0 |
| WHOLE FIGHT REACTION | 4.0 | +1176.8 | 300.3 | 150.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.0 | +76.1 | 0.0 | 0.0 | 3.0 | +84.7 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 338 | 327 | 75 | 25.00 | +930 | +12.4 |
| ARMY TABLE | 98 | 98 | 71 | 23.67 | +1321 | +18.6 |
| HOLDER ASSIGNMENT | 72 | 72 | 64 | 21.33 | +2958 | +46.2 |
| HIS SHOTS BY HIS RUN | 221 | 211 | 38 | 12.67 | +170 | +4.5 |
| DEPLOY BY FIGURES | 50 | 50 | 35 | 11.67 | +596 | +17.0 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1222 | -43.7 |
| ARTILLERY RE-ROLL WEIGHED | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| GOAL WALK | 90 | 89 | 27 | 9.00 | +1579 | +58.5 |
| REDIRECT FOR A FRIEND IN REACH | 26 | 26 | 26 | 8.67 | +60 | +2.3 |
| SHOT RISK POINTS | 158 | 151 | 25 | 8.33 | +410 | +16.4 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 23 | 7.67 | -1659 | -72.1 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 139 | 123 | 21 | 7.00 | +38 | +1.8 |
| FIVE ACTION | 610 | 590 | 16 | 5.33 | +751 | +47.0 |
| NO CHAFF EDGES | 18 | 17 | 15 | 5.00 | +305 | +20.3 |
| MAX FOR POSITIONING | 26 | 24 | 14 | 4.67 | +21 | +1.5 |
| MOVE TO CHARGE COMPUTED | 20 | 13 | 12 | 4.00 | +302 | +25.2 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +20 | +1.7 |
| FOUR ROUNDS | 19 | 15 | 11 | 3.67 | +350 | +31.8 |
| STAY WORTH | 207 | 193 | 11 | 3.67 | +32 | +2.9 |
| CANNON PLANNED TARGET | 43 | 43 | 10 | 3.33 | -3 | -0.3 |
| NEXT CHARGE BY LIST | 20 | 15 | 9 | 3.00 | +252 | +28.0 |
| CHARGE LOSSES | 98 | 93 | 8 | 2.67 | +183 | +22.9 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 120 | 117 | 7 | 2.33 | +640 | +91.5 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +431 | +71.9 |
| MEETS IN TIME | 17 | 17 | 6 | 2.00 | +366 | +61.0 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +177 | +29.6 |
| SHOTS IN THE MOVE | 116 | 86 | 6 | 2.00 | +638 | +106.3 |
| SUPPORT ADDS | 38 | 34 | 6 | 2.00 | +223 | +37.1 |
| SUPPORT WORKED OUT | 38 | 34 | 6 | 2.00 | +223 | +37.1 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 72 | 60 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +661 | +132.2 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +619 | +123.7 |
| OPENS UP IN FULL | 8 | 7 | 5 | 1.67 | +73 | +14.6 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +109 | +21.7 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +61 | +15.2 |
| COVER ONCE | 36 | 18 | 4 | 1.33 | +163 | +40.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +184 | +46.0 |
| ONE OBJECTIVE FORMULA | 37 | 31 | 4 | 1.33 | +166 | +41.4 |
| RISK BY ARC | 16 | 12 | 4 | 1.33 | +65 | +16.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +164 | +41.1 |
| WHOLE FIGHT REACTION | 12 | 12 | 4 | 1.33 | +16 | +4.0 |
| EXACT ROUND | 17 | 13 | 3 | 1.00 | +62 | +20.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 56 | 30 | 3 | 1.00 | +18 | +5.9 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -112 | -37.4 |
| PRIZE BY WORTH | 3 | 3 | 3 | 1.00 | +204 | +67.8 |
| REDIRECT COUNTER | 20 | 14 | 3 | 1.00 | +71 | +23.7 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 3 | 1.00 | +2 | +0.5 |
| STRIKE BY THE ODDS | 4 | 4 | 3 | 1.00 | +108 | +36.0 |
| SUPPORT NARROWED | 4 | 4 | 3 | 1.00 | -54 | -17.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +0 | +0.2 |
| CHARGE NOW FIRST | 9 | 9 | 2 | 0.67 | -40 | -19.9 |
| FEATURE BUFFS | 27 | 27 | 2 | 0.67 | +24 | +12.0 |
| MISSILES IN THE MOVE | 13 | 8 | 2 | 0.67 | +19 | +9.6 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +44 | +21.9 |
| PROMISE KNOWS THE FIGHT | 7 | 3 | 2 | 0.67 | -37 | -18.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +80 | +40.2 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +39 | +19.6 |
| THE FIGHT MOVES | 4 | 4 | 2 | 0.67 | +102 | +50.8 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +624 | +312.1 |
| WHOLE FIGHT DANGER | 13 | 13 | 2 | 0.67 | +65 | +32.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +18 | +17.9 |
| BACKS UP THE FIGHT | 3 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -106 | -105.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +10 | +10.5 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +43 | +43.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 4 | 1 | 0.33 | +66 | +66.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -5 | -4.6 |
| HIS CHARGE DENIED | 3 | 2 | 1 | 0.33 | +54 | +54.0 |
| HONEST WORTH | 14 | 11 | 1 | 0.33 | +27 | +27.1 |
| HUNT IN PAIRS | 1 | 1 | 1 | 0.33 | +176 | +176.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +81 | +81.2 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +3 | +2.9 |
| MISSILES NEXT TURN | 17 | 13 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 57 | 56 | 1 | 0.33 | +59 | +59.3 |
| ONE FIGHT FORMULA | 23 | 9 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 7 | 5 | 1 | 0.33 | +36 | +35.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| RANDOM MOVE BY FIGURES | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| SET UP BY THE SET | 8 | 8 | 1 | 0.33 | +2 | +1.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOTS AFTER THE MOVES | 27 | 27 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 6 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 5 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 51 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 12 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 134 | 134 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 15 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 8 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT BY DROPS | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 86 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | not checked | - | - | - | - |
| STANDS FOR A REASON | 22 | 22 | 0 | 0.00 | - | - |
| STANDS STILL | 325 | 313 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 16 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 22 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 278 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 21 | 21 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 3.33 | 28.7 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 2.33 | 72.1 |
| ARMY TABLE | rule | 0.33 | 2.00 | 71.4 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 21.1 |
| NO REASON | gate | - | 1.00 | 53.4 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 37.4 |
| SUPPORT NARROWED | rule | 0.33 | 0.67 | 17.9 |
| CHARGE NOW FIRST | rule | - | 0.67 | 19.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 18.6 |
| AFTERMATH BAND | gate | - | 0.33 | 4.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 397.9 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 2.6 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 105.5 |
| CHAFF PASSED | rule | - | 0.33 | 1.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.33 | 4.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 37.7 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.33 | 1.6 |

### Plans: chf-efd8067-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 17 | 0 | 0% |
| Mine | move | 25.0 | 89% | 1136 | 0 | 0% |
| Mine | shoot | 13.3 | 65% | 712 | 983 | 138% |
| Mine | support | 0.3 | 100% | 0 | 0 | 0% |
| Opponent | charge | 4.3 | 77% | 452 | 227 | 50% |
| Opponent | move | 37.0 | 96% | 2699 | 0 | 0% |
| Opponent | shoot | 9.7 | 72% | 431 | 611 | 142% |
| Opponent | support | 0.3 | 100% | 12 | 0 | 0% |

### Battle groups: chf-efd8067-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.0 | 7% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 50% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 50 (7) | 50 | 0 | 19 | 29% | 3.0 | 0 (1) | 64 (4) | 0 (1) | 0 (1) | 55 (5) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 0 (5) | 0 | 0 | 84 | 80% | 5.0 | - | 0 (1) | 0 (4) | 0 (3) | 0 (2) |
| Mine | Hammer | 9 | 32 (9) | 21 | 10 | 36 | 11% | 2.6 | 0 (1) | 48 (6) | 10 (2) | 31 (5) | 32 (4) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 8 | 30 (8) | 30 | 0 | 9 | 0% | 1.0 | 0 (5) | 32 (2) | 201 (1) | 0 (3) | 50 (5) |
| Mine | Wizard | 5 | 23 (5) | 23 | 0 | 0 | 40% | 5.0 | 0 (3) | 107 (1) | 0 (1) | 0 (2) | 38 (3) |
| Opponent | Chaff | 5 | 50 (5) | 24 | 26 | 21 | 20% | 1.0 | 122 (2) | 0 (2) | 0 (1) | 50 (5) | - |
| Opponent | Character | 8 | 26 (8) | 26 | 0 | 48 | 50% | 3.0 | 34 (3) | 15 (3) | 28 (2) | 27 (5) | 25 (3) |
| Opponent | Clean-up | 3 | 108 (3) | 0 | 108 | 28 | 67% | 6.0 | 150 (2) | 0 (1) | - | 150 (2) | 0 (1) |
| Opponent | Fast Hammer | 7 | 12 (7) | 10 | 2 | 14 | 71% | 4.0 | 0 (3) | 20 (4) | - | 18 (3) | 7 (4) |
| Opponent | Holder | 10 | 65 (10) | 14 | 51 | 10 | 10% | 1.4 | 34 (3) | 48 (3) | 116 (4) | 71 (5) | 56 (5) |
| Opponent | Shooter | 1 | 174 (1) | 50 | 124 | 0 | 0% | 3.0 | - | 174 (1) | - | - | 174 (1) |
| Opponent | War machine | 3 | 83 (3) | 83 | 0 | 0 | 0% | 1.0 | 83 (3) | - | - | 0 (2) | 248 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: chf-efd8067-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 2 | 366 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 268 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 310 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | +0 | - |
| Opponent | Tomb Kings of Khemri | 2 | 98 | 406 | 4.0 | 1.1 | 102 | 88 | +13 | 4 of 8 | 5 of 8 | -396 | +72 |
| **Opponent** | all armies | 3 | 168 | 271 | 3.0 | 1.2 | 90 | 78 | +12 | 5 of 9 | 5 of 9 | -198 | +72 |

### Effective charges: chf-efd8067-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 4 (net -35) | 1 (net +0) | 1 (net +133) | 2 | 0% (0 of 6) |

### Charged fights, damage counted: chf-efd8067-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 299 | 314 | +0 | 0 | 160 | -160 | -53.7 |
| Opponent | 76-89% | 4 | 446 | 209 | -35 | 155 | 140 | +15 | +3.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 81 | +133 | 176 | 0 | +176 | +90.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 84 | +0 | 48 | 0 | +48 | +11.1 |
| Opponent | No odds | 2 | 318 | 291 | +58 | 155 | 98 | +58 | +18.1 |
| Opponent | All fights | 9 | 372 | 211 | +12 | 128 | 102 | +27 | +7.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p14 | move | 14 | 5 (36%) | 2 (14%) | 0 (0%) | 9 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

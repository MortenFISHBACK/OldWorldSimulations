# Doctrine scorecard: chf-efd8067-p28

### Scorecard: chf-efd8067-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 473 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 675 |
| L0612 | 6 | 1 | Opponent | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 773 |
| L0628 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 3.0 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 640.3 |
| **Average** | | | Opponent | 0% | 4.0 | 6.0 | 0.0 | 2.0 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: chf-efd8067-p28

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 93% (13 of 14) | 0% (0 of 14) | 46% (13 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 47% (14 of 30) | 47% (14 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 48% (14 of 29) | 48% (14 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 85% (5077 of 6000) | 97% (5796 of 5998) | 91% (10873 of 11998) |
|   infantry points that never fought | lower | 89% (1993 of 2232) | 100% (694 of 694) | 92% (2687 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (18 of 27) | 61% (14 of 23) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2575 of 4232) | 67% (3870 of 5787) | 64% (6445 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (19%) | 1.0 (19%) |
| MARCHED: its unit marched | - | 3.0 (56%) | 3.0 (56%) |
| CHARGED: its unit charged | - | 0.3 (6%) | 0.3 (6%) |
| GONE: slain | - | 0.3 (6%) | 0.3 (6%) |
| STUPIDITY: Stupidity | - | 0.7 (12%) | 0.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.7 | 4.7 | 1.0 | 0.0 |
| not cast | 2.3 | 2.3 | 5.3 | 3.0 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (71%) | 1.0 (19%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.0 (56%) | 1.3 (44%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.3 (11%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.7 (29%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (88%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (140 of 208) | 93% (13 of 14) | 69% (153 of 222) |
|   cavalry | 53% (9 of 17) | 50% (1 of 2) | 53% (10 of 19) |
|   character | 88% (29 of 33) | - | 88% (29 of 33) |
|   infantry | 44% (24 of 55) | - | 44% (24 of 55) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 76% (69 of 91) | 100% (12 of 12) | 79% (81 of 103) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.3 (24%) | 0.0 (0%) | 5.3 (23%) |
| CHARGED: it charged | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 8.0 (35%) | 0.3 (100%) | 8.3 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.7 (21%) | 0.0 (0%) | 4.7 (20%) |
| SHELTERED: the target was sheltered | 1.7 (7%) | 0.0 (0%) | 1.7 (7%) |
| STUPIDITY | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.0 | 70% | 14.2 pts | 47 pts |
| character | 9.7 | 5.3 | 69% | 14.1 pts | 136 pts |
| infantry | 15.7 | 4.7 | 74% | 11.8 pts | 184 pts |
| monster | 3.0 | 0.3 | 89% | 13.0 pts | 39 pts |
| war machine | 27.3 | 17.0 | 70% | 21.5 pts | 589 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 1.0 | 0.8 |
| Charges that made contact a game | 0.7 | 0.7 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (21 units) | 0.15 declared, 0.08 contact (13 units) | 0.12 declared, 0.09 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 75% (6 of 8) | 67% (2 of 3) | - | 73% (8 of 11) |
| Character on its own | - | 100% (4 of 4) | 67% (2 of 3) | 86% (6 of 7) |
| Infantry | 43% (3 of 7) | 50% (3 of 6) | - | 46% (6 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 85% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 56% (10 of 18) | 100% | 33% (3 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 92% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 98% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: chf-efd8067-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 59% (47 of 80) | 56% (9 of 16) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 25% (3 of 12) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 2.0 |
| Movement | Points that never moved of their own | 640.3 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 2, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +161 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 24.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (42 of 72) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 199.7 | 0.0 |
| Shooting | War machine shots | 23.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (47 of 69) | 8% (1 of 12) |
| Shooting | Points destroyed by war machines | 119.0 | 98.3 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 38% (3 of 8) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 3.7 / 1.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 67.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +249 | +0 |
| Combat | Net per 100 charger points, damage counted | +144.9 | +0.0 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +101 | +0 |
| Combat | Net points per supported fight / lone fight | - / +101 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 0 of 2 |
| Game | Points lost | 205.0 | 389.7 |
| Game | VP from objectives | 703.3 | 473.3 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +468 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 595
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 5.0 | -170.7 | 0.0 | 0.0 | 14.0 | +320.6 | 0.0 | 74.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 31.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 144.7 | 38.3 | - | - | - | - |
| CANNON PLANNED TARGET | 19.0 | +457.3 | 1210.7 | 166.7 | 4.0 | +183.0 | 138.3 | 110.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +22.5 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +34.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 53.7 |
| CHALLENGE IN THE FIGHT | 0.3 | -1.1 | 53.7 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +9.0 | 53.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.0 | -195.5 | 0.0 | 0.0 | 24.7 | -1275.6 | 0.0 | 627.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 356.7 | 0.0 | 0.3 | +0.0 | 0.0 | 53.7 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 10.7 | -870.3 | 0.0 | 0.0 | 4.0 | -114.3 | 0.0 | 326.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 12.7 | -143.8 | 0.0 | 20.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +1.0 | 13.7 | 0.0 | 1.0 | -3.3 | 31.7 | 53.7 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 13.7 | 0.0 | 1.0 | +0.1 | 31.7 | 53.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 23.3 | +275.1 | 0.0 | 326.3 |
| FEATURE BUFFS | 0.7 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| FIVE ACTION | 132.3 | +6049.4 | 3884.0 | 476.7 | 68.7 | +1884.6 | 268.3 | 1059.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 289.3 |
| FOLLOW UP WEIGHED | 0.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +38.3 | 67.3 | 0.0 | 1.0 | +10.6 | 31.7 | 53.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.7 | -58.1 | 0.0 | 0.0 |
| GOAL WALK | 5.0 | +322.7 | 0.0 | 0.0 | 5.0 | +465.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +1.8 | 37.0 | 38.3 | - | - | - | - |
| GUN MASK | 4.7 | +53.5 | 0.0 | 0.0 | 2.0 | +82.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 434.0 |
| HIS CHARGE DENIED | 0.3 | +12.7 | 53.7 | 0.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 14.3 | +0.0 | 0.0 | 63.3 | 7.7 | +0.0 | 0.0 | 263.7 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 263.7 |
| HIS MOVE AND SHOT | 7.0 | -45.9 | 0.0 | 0.0 | 6.7 | -65.5 | 0.0 | 408.3 |
| HIS ONE QUARTER | - | - | - | - | 0.3 | +0.0 | 0.0 | 119.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 263.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.0 | +1042.9 | 0.0 | 143.3 | 46.3 | +4270.5 | 0.0 | 785.3 |
| HIS SHOTS BY HIS RUN | 30.0 | +552.3 | 0.0 | 80.0 | 41.7 | +1286.1 | 0.0 | 785.3 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.7 | +1094.1 | 0.0 | 0.0 | 8.0 | +996.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -23.0 | 67.3 | 0.0 | 1.0 | -11.2 | 31.7 | 53.7 |
| IDLE COST | - | - | - | - | 17.0 | -357.7 | 0.0 | 326.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 27.3 | 0.0 | 1.7 | +0.0 | 0.0 | 134.7 |
| LONG SHOT | 0.3 | -0.4 | 53.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +98.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | -19.7 | 0.0 | 0.0 | 2.0 | +9.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.7 | +87.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +137.6 | 0.0 | 144.7 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +46.1 | 0.0 | 144.7 |
| MARCH OVER CASTS | - | - | - | - | 2.3 | +52.0 | 0.0 | 144.7 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 3.3 | +27.3 | 0.0 | 289.3 |
| MEETS IN TIME | 9.0 | +209.9 | 0.0 | 20.0 | 2.0 | +354.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 7.3 | +51.4 | 0.0 | 144.7 |
| MISSILES NEXT TURN | - | - | - | - | 9.7 | +54.1 | 0.0 | 289.3 |
| MODEL FACING | 3.0 | +980.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +47.7 | 0.0 | 0.0 | 3.0 | +135.9 | 0.0 | 144.7 |
| NEARER NOT NEEDED | 5.0 | +230.6 | 0.0 | 0.0 | 4.3 | +173.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +11.6 | 0.0 | 0.0 | 2.0 | +104.7 | 0.0 | 144.7 |
| NO CHAFF EDGES | 0.7 | +0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -12.1 | 67.3 | 0.0 | 1.0 | -6.6 | 31.7 | 53.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -288.7 | 13.7 | 31.7 | 5.7 | -180.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.7 | +7.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -10.9 | 0.0 | 0.0 | 4.7 | -109.2 | 0.0 | 326.3 |
| ONE OBJECTIVE FORMULA | 5.3 | +67.4 | 0.0 | 0.0 | 2.3 | -153.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -7.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +9.7 | 40.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +24.6 | 0.0 | 0.0 |
| PLAN RESULT | 58.3 | +1969.5 | 1361.3 | 298.3 | 32.0 | +134.8 | 20.0 | 846.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -137.5 | 0.0 | 0.0 | 6.7 | -32.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.3 | -30.5 | 0.0 | 0.0 |
| QUARTER ODDS | 17.3 | +1100.1 | 1190.0 | 0.0 | 3.0 | +754.9 | 0.0 | 119.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +41.0 | 0.0 | 0.0 | 0.7 | +24.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 13.7 |
| REFORMS TO MEET IT | 0.7 | -10.4 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | +20.2 | 13.7 | 0.0 | 0.7 | +30.0 | 0.0 | 53.7 |
| RUN DOWN | 0.3 | -3.4 | 13.7 | 0.0 | 0.7 | -0.6 | 0.0 | 53.7 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +15.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.1 | 13.7 | 0.0 | 0.3 | +3.4 | 0.0 | 53.7 |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -155.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +2.9 | 0.0 | 0.0 | 4.7 | +138.4 | 0.0 | 74.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +103.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 27.7 | +0.0 | 0.0 | 166.7 | 6.3 | +0.0 | 0.0 | 110.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +123.5 | 289.3 | 0.0 | 0.7 | +5.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 21.3 | +322.6 | 0.0 | 80.0 | 28.7 | -746.5 | 0.0 | 337.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 37.3 | +1835.9 | 0.0 | 166.7 | 4.3 | +207.4 | 0.0 | 147.0 |
| SPELL WORTH | - | - | - | - | 5.7 | +149.6 | 289.3 | 289.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.5 | 31.7 | 0.0 |
| SPOT AS THE GAME MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 195.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 0.0 | 144.7 |
| STANDS STILL | 101.3 | +0.0 | 3816.7 | 476.7 | 17.3 | +0.0 | 236.7 | 220.0 |
| STAY WORTH | 58.7 | +154.0 | 2234.7 | 175.0 | 10.0 | +97.7 | 236.7 | 165.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.7 | -24.4 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +175.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +175.3 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +44.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.7 | +0.7 | 31.7 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 56.3 | +0.0 | 0.0 | 166.7 | 34.7 | +0.0 | 0.0 | 436.3 |
| TIED UP BY THE SUM | 0.3 | +12.1 | 13.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 58.3 | +583.6 | 363.3 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 144.7 |
| WHO FIGHTS | 0.3 | -0.2 | 13.7 | 0.0 | 0.7 | +3.2 | 0.0 | 53.7 |
| WHOLE FIGHT DANGER | 0.7 | -13.3 | 0.0 | 0.0 | 1.3 | -115.0 | 0.0 | 289.3 |
| WHOLE FIGHT REACTION | 0.7 | +31.2 | 0.0 | 31.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +70.2 | 0.0 | 0.0 | 5.3 | +799.2 | 0.0 | 119.0 |

### Rule changes: chf-efd8067-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 256 | 250 | 89 | 29.67 | +2416 | +27.1 |
| HOLDER ASSIGNMENT | 56 | 56 | 52 | 17.33 | +3796 | +73.0 |
| HIS SHOTS BY HIS RUN | 215 | 201 | 51 | 17.00 | +744 | +14.6 |
| ARMY TABLE | 57 | 57 | 49 | 16.33 | +379 | +7.7 |
| SHOT RISK POINTS | 150 | 147 | 37 | 12.33 | +886 | +24.0 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1407 | -39.1 |
| DEPLOY BY FIGURES | 51 | 51 | 32 | 10.67 | +306 | +9.6 |
| TIME ON OUR SIDE | 175 | 158 | 32 | 10.67 | +125 | +3.9 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| IDLE COST | 51 | 38 | 16 | 5.33 | +252 | +15.7 |
| MEETS IN TIME | 33 | 33 | 14 | 4.67 | +432 | +30.9 |
| GOAL WALK | 30 | 30 | 13 | 4.33 | +1324 | +101.8 |
| THE TABLE AGAIN | 35 | 35 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 35 | 35 | 12 | 4.00 | -510 | -42.5 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +24 | +2.2 |
| WOUNDS ON THE RANKS | 25 | 25 | 11 | 3.67 | +367 | +33.4 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 44 | 36 | 10 | 3.33 | +10 | +1.0 |
| FIVE ACTION | 603 | 588 | 10 | 3.33 | +213 | +21.3 |
| MOVE TO CHARGE COMPUTED | 17 | 13 | 10 | 3.33 | +227 | +22.7 |
| CHARGE LOSSES | 104 | 103 | 9 | 3.00 | +606 | +67.4 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +2940 | +326.7 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 7 | 2.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 69 | 69 | 5 | 1.67 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +262 | +52.5 |
| NEXT CHARGE BY LIST | 8 | 8 | 5 | 1.67 | +170 | +34.0 |
| SHOTS IN THE MOVE | 125 | 106 | 5 | 1.67 | +198 | +39.5 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 70 | 62 | 4 | 1.33 | +63 | +15.8 |
| FOUR ROUNDS | 5 | 4 | 4 | 1.33 | +48 | +11.9 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 4 | 1.33 | +71 | +17.7 |
| SUPPORT ADDS | 8 | 8 | 4 | 1.33 | +23 | +5.6 |
| SUPPORT WORKED OUT | 8 | 8 | 4 | 1.33 | +23 | +5.6 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +532 | +177.2 |
| MARCH CHECK | 4 | 3 | 3 | 1.00 | +209 | +69.6 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NO CHAFF EDGES | 3 | 3 | 3 | 1.00 | +2 | +0.6 |
| ONE OBJECTIVE FORMULA | 23 | 20 | 3 | 1.00 | +32 | +10.6 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +74 | +24.6 |
| SURE REACH TOGETHER | 5 | 5 | 3 | 1.00 | +11 | +3.7 |
| THE ROW IN ITS ORDER | 10 | 3 | 3 | 1.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -63 | -31.7 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +35 | +17.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MAX FOR POSITIONING | 10 | 10 | 2 | 0.67 | +2 | +0.8 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -24 | -11.9 |
| QUARTER ODDS | 61 | 61 | 2 | 0.67 | +12 | +5.8 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +29 | +14.3 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +25 | +12.7 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 1 | 0.33 | +26 | +25.5 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +110 | +109.7 |
| GUN MASK | 20 | 20 | 1 | 0.33 | +17 | +17.4 |
| HONEST WORTH | 5 | 4 | 1 | 0.33 | +0 | +0.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| MANOEUVRE | 13 | 13 | 1 | 0.33 | +29 | +28.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -138 | -138.2 |
| MISSILES IN THE MOVE | 22 | 16 | 1 | 0.33 | +1 | +1.3 |
| MISSILES NEXT TURN | 29 | 24 | 1 | 0.33 | +3 | +3.1 |
| NEARER NOT NEEDED | 28 | 26 | 1 | 0.33 | +37 | +37.4 |
| NO DOUBLE ROUNDS | 5 | 4 | 1 | 0.33 | +0 | +0.5 |
| ONE FIGHT FORMULA | 20 | 16 | 1 | 0.33 | +0 | +0.0 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +26 | +26.5 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 5 | 5 | 1 | 0.33 | +42 | +41.9 |
| RISK BY ARC | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +48 | +47.7 |
| SET UP BY THE SET | 15 | 13 | 1 | 0.33 | +57 | +57.4 |
| WHO FIGHTS | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 44 | 39 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 3 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 38 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 66 | 66 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 41 | 41 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 1 | 1 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 29 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 78 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 102 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 25 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 356 | 352 | 0 | 0.00 | - | - |
| STAY WORTH | 206 | 191 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 273 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 4.67 | 41.8 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.00 | 42.5 |
| ARMY TABLE | rule | 2.33 | 1.33 | 57.7 |
| RULE SWITCHED OFF | gate | - | 1.00 | 18.9 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 31.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 24.2 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 11.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 138.2 |
| NO REASON | gate | 0.33 | - | 13.2 |

### Plans: chf-efd8067-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 67 | 67 | 101% |
| Mine | join | 2.0 | 100% | 70 | 0 | 0% |
| Mine | move | 34.7 | 98% | 1190 | 0 | 0% |
| Mine | shoot | 21.0 | 56% | 1036 | 1902 | 184% |
| Opponent | charge | 0.7 | 0% | 7 | 14 | 215% |
| Opponent | join | 2.0 | 100% | 93 | 0 | 0% |
| Opponent | move | 25.3 | 95% | 872 | 0 | 0% |
| Opponent | shoot | 3.3 | 50% | 148 | 120 | 81% |
| Opponent | support | 0.7 | 100% | 15 | 0 | 0% |

### Battle groups: chf-efd8067-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 100% | 100% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 8 (13) | 8 | 0 | 0 | 31% | 2.6 | 16 (5) | 0 (7) | 0 (1) | 9 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | - | 0 (3) | 0 (1) | 0 (4) | - |
| Mine | Fast | 3 | 73 (3) | 73 | 0 | 27 | 33% | 1.0 | - | 275 (1) | 0 (2) | 73 (3) | - |
| Mine | Hammer | 4 | 93 (4) | 7 | 87 | 0 | 50% | 2.0 | 17 (1) | 147 (3) | - | 93 (4) | - |
| Mine | Holder | 2 | 215 (2) | 118 | 98 | 0 | 0% | 1.5 | 0 (1) | 427 (1) | - | 427 (1) | 0 (1) |
| Mine | Shooter | 6 | 55 (6) | 5 | 50 | 0 | 17% | 3.8 | 122 (2) | 0 (1) | 9 (3) | 68 (5) | 0 (1) |
| Mine | War machine | 17 | 21 (17) | 21 | 0 | 30 | 12% | 1.4 | 0 (4) | 38 (9) | 0 (4) | 0 (3) | 26 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 67% | 1.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 18 | 70% | 1.0 | 0 (2) | 5 (5) | 0 (2) | 3 (8) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 8 (3) | 0 | 8 | 30 | 100% | - | - | 13 (2) | 0 (1) | 11 (2) | 0 (1) |
| Opponent | Holder | 6 | 81 (6) | 0 | 81 | 10 | 67% | 1.5 | - | 81 (6) | - | 125 (4) | 7 (2) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 50 | 0% | 1.0 | - | 109 (1) | 70 (1) | - | 89 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: chf-efd8067-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 319 | 67 | 0.7 | 1.0 | 101 | 0 | +101 | 0 of 2 | 2 of 2 | - | +101 |
| Opponent | Grand Cathay | 1 | 355 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 0 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 118 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 1 | - | +0 |

### Effective charges: chf-efd8067-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +161) | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 239 | 161 | +161 | 184 | 104 | +81 | +33.8 |
| Mine | No odds | 1 | 105 | 41 | +41 | 418 | 0 | +418 | +397.7 |
| Mine | All fights | 2 | 172 | 101 | +101 | 301 | 52 | +249 | +144.9 |
| Opponent | Long shot (under 50%) | 1 | 41 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 470 | 95 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 2 | 256 | 78 | +0 | 0 | 0 | +0 | +0.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p28 | move | 13 | 1 (8%) | 1 (8%) | 1 (8%) | 11 (85%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

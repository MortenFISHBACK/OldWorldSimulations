# Doctrine scorecard: chf-efd8067-p24

### Scorecard: chf-efd8067-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 3 | 0 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 1 | 0 | 0 | 38 |
| **Average** | | | Mine | 33% | 6.0 | 3.3 | 1.0 | 2.0 | 0.3 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 67% | 0.0 | 2.7 | 3.0 | 2.3 | 0.3 | 0.0 | 0.0 | 12.7 |

### KPIs: chf-efd8067-p24

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 31% (5 of 16) | 17% (5 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 86% (6 of 7); on the table 86% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 75% | 50% (1 of 2); on the table 100% | 33% (2 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 50% (3 of 6); on the table 83% | 80% (8 of 10); on the table 90% | 69% (11 of 16); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 28% (5 of 18) | 40% (17 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (12 of 21) | 33% (5 of 15) | 47% (17 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 32% (1914 of 5999) | 43% (2608 of 6000) | 38% (4522 of 11999) |
|   infantry points that never fought | lower | 52% (409 of 780) | 50% (959 of 1918) | 51% (1368 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (11 of 18) | 68% (23 of 34) | 65% (34 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2620 of 4808) | 61% (3608 of 5962) | 58% (6228 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (42%) | 1.7 (38%) | 3.3 (40%) |
| MARCHED: its unit marched | 0.3 (8%) | 1.3 (31%) | 1.7 (20%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.3 (8%) | 0.7 (8%) |
| GONE: slain | 0.7 (17%) | 0.7 (15%) | 1.3 (16%) |
| STUPIDITY: Stupidity | 1.0 (25%) | 0.0 (0%) | 1.0 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 2.0 | 3.3 | 5.7 | 1.0 | 0.7 |
| not cast | 5.3 | 0.7 | 2.7 | 8.3 | 5.0 | 23.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 3.3 (40%) | 1.7 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (20%) | 1.0 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (12%) | 0.0 (0%) | 0.7 (25%) | 1.3 (16%) | 1.3 (27%) | 1.7 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 1.0 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (50%) | 0.0 (0%) | 1.7 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (90%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 3.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 44% (4 of 9) | 50% (5 of 10) |
| the unit moved after it | 100% (1 of 1) | 25% (1 of 4) | 40% (2 of 5) |
| it charged on its next turn | 0% (0 of 1) | 25% (1 of 4) | 20% (1 of 5) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 75% (3 of 4) | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 60% (57 of 95) | 58% (57 of 99) |
|   cavalry | - | 59% (26 of 44) | 59% (26 of 44) |
|   character | 0% (0 of 4) | 59% (10 of 17) | 48% (10 of 21) |
|   infantry | - | 62% (21 of 34) | 62% (21 of 34) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (25%) | 7.3 (58%) | 7.7 (55%) |
| CHARGED: it charged | 0.7 (50%) | 3.0 (24%) | 3.7 (26%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.3 (11%) | 1.3 (10%) |
| NO TARGET IN RANGE | 0.3 (25%) | 0.7 (5%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 3.0 | 80% | 2.9 pts | 34 pts |
| character | 3.3 | 1.3 | 60% | 9.3 pts | 31 pts |
| infantry | 8.3 | 4.7 | 64% | 11.4 pts | 95 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.0 | 5.3 |
| Charges that made contact a game | 4.3 | 4.7 | 4.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | - | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | - | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.79 declared, 0.58 contact (19 units) | 0.48 declared, 0.45 contact (31 units) | 0.60 declared, 0.50 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 50% (1 of 2) | 100% (1 of 1) | 64% (9 of 14) |
| Character in a unit | 100% (4 of 4) | 60% (3 of 5) | 0% (0 of 1) | 70% (7 of 10) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 20% (1 of 5) | 43% (3 of 7) |
| Infantry | 67% (8 of 12) | 100% (3 of 3) | - | 73% (11 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 50% (2 of 4); on the table 100% | 50% (12 of 24) | 46% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | - | 4% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 80% (8 of 10); on the table 90% | 28% (5 of 18) | 43% | 68% (23 of 34) | 50% (2 of 4); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (6) | 83% (5) | 69% (11) |
| ...free all their last turn and able to turn (per game) | 1.67 | 1.00 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 71% (10 of 14) | 90% (9 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 3) | 36% (4 of 11) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 29% (2 of 7) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 100% (7 of 7) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 0.0 | 12.7 |
| Movement | Fights charged into per game | 3.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 9, net +0 | 0 of 10 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 2 of 10, net +93 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 9, net +110 | 2 of 10, net +148 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 9, net -15 | 4 of 10, net +68 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 19.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 46% (26 of 57) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (1 of 8) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.3 / 0.3 / 0.7 | 0.7 / 1.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 194.7 | 507.3 |
| Combat | Points run down | 38.0 | 23.3 |
| Combat | Net points per charged fight, damage counted | +40 | +94 |
| Combat | Net per 100 charger points, damage counted | +12.4 | +39.1 |
| Combat | First round won (charged fights) | 82% | 91% |
| Combat | Net points per charged fight | +38 | +104 |
| Combat | Net points per supported fight / lone fight | +122 / +19 | +22 / +122 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 11 | 2 of 11 |
| Game | Points lost | 580.0 | 364.3 |
| Game | VP from objectives | 516.7 | 673.3 |
| Game | Lone holders (player turns) | 6.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -354 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 944
- Games not ended: 0; findings 6, warnings 0

### Opponent rules: chf-efd8067-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +13.6 | 0.0 | 0.0 |
| ARMY TABLE | 15.3 | +264.3 | 0.0 | 84.7 | 43.7 | +27.9 | 0.0 | 38.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +0.5 | 0.0 | 0.0 | 0.7 | +8.7 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +2.3 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -4.8 | 20.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 34.0 | 0.0 | 0.3 | -1.2 | 23.3 | 0.0 |
| CAST JOB | 1.3 | +6.4 | 76.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 3.7 | +106.4 | 0.0 | 60.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 2.3 | -1.4 | 0.0 | 38.0 |
| CHALLENGE BY POINTS | 0.7 | +21.8 | 0.0 | 84.7 | 1.0 | +49.9 | 0.0 | 78.7 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.7 | +2.0 | 104.7 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +0.0 | 78.7 | 0.0 | 0.3 | +0.1 | 20.0 | 0.0 |
| CHARGE LOSSES | 24.7 | -748.8 | 0.0 | 295.3 | 17.0 | -502.7 | 0.0 | 110.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 34.7 | 0.0 | 0.3 | +0.0 | 23.3 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 277.0 | 146.7 | 2.3 | +0.0 | 244.3 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.0 | +0.0 | 0.0 | 160.3 | 8.3 | +0.0 | 0.0 | 69.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 95.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.3 | +13.1 | 0.0 | 0.0 | 3.0 | +178.1 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -652.7 | 0.0 | 82.0 | 11.7 | -409.4 | 0.0 | 118.7 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 1.3 | -4.3 | 114.0 | 84.7 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +59.8 | 0.0 | 0.0 | 9.3 | -113.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +5.3 | 78.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.3 | -12.9 | 362.0 | 109.7 | 2.3 | +23.3 | 145.3 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.3 | +8.5 | 350.0 | 188.3 | 1.3 | +0.0 | 202.7 | 0.0 |
| FALLS SHORT | 22.3 | +237.2 | 0.0 | 409.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +12.2 | 131.3 | 41.7 | 1.0 | +1.9 | 43.3 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +15.3 | 0.0 | 38.0 |
| FIVE ACTION | 79.0 | +4898.4 | 551.3 | 934.3 | 95.7 | +7107.4 | 338.0 | 489.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 170.3 | 7.3 | +0.0 | 0.0 | 34.0 |
| FOLLOW UP WEIGHED | 0.7 | +79.9 | 0.0 | 16.7 | 1.3 | +237.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.3 | +292.7 | 475.3 | 188.3 | 4.0 | +230.7 | 315.3 | 0.0 |
| FREED FROM HIS FIGHT | 8.7 | +0.0 | 0.0 | 245.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.0 | -8.6 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -48.7 | 34.7 | 0.0 | 0.7 | -3.3 | 23.3 | 0.0 |
| GOAL WALK | 7.0 | +639.9 | 0.0 | 124.0 | 19.0 | +1512.2 | 0.0 | 76.0 |
| HALF WHEN STILL FLEEING | 0.7 | -0.2 | 79.7 | 0.0 | 0.7 | -0.5 | 23.3 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 5.7 | +0.0 | 0.0 | 150.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 93.3 | 25.0 | - | - | - | - |
| HELPER UNSEEN | 0.7 | +0.0 | 93.3 | 25.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 16.0 | +0.0 | 0.0 | 295.3 | 13.7 | +0.0 | 0.0 | 110.0 |
| HIS CHARGE DENIED | 1.7 | +55.7 | 183.3 | 84.7 | - | - | - | - |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 235.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 62.0 | 5.7 | +0.0 | 0.0 | 38.0 |
| HIS MOVE AND SHOT | 5.3 | -51.1 | 0.0 | 190.0 | 3.7 | -8.3 | 0.0 | 34.0 |
| HIS ONE QUARTER | 8.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 62.0 | 10.7 | +0.0 | 0.0 | 234.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 59.0 | +1238.4 | 0.0 | 622.0 | 31.7 | +387.2 | 0.0 | 34.0 |
| HIS SHOTS BY HIS RUN | 58.7 | +677.7 | 0.0 | 680.7 | 23.7 | +230.3 | 0.0 | 76.0 |
| HIS TURN DENIED | 0.3 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 132.0 | 11.0 | +0.0 | 0.0 | 76.0 |
| HOLDER ASSIGNMENT | 9.0 | +525.6 | 0.0 | 66.0 | 7.3 | +560.0 | 0.0 | 76.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.7 | -152.7 | 390.7 | 188.3 | 4.0 | -104.0 | 315.3 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| IDLE COST | 17.7 | -249.5 | 0.0 | 152.7 | - | - | - | - |
| JOINT CHARGE NOW | 1.7 | +24.9 | 207.3 | 109.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 45.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +25.3 | 0.0 | 0.0 | 0.7 | +40.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 196.0 | 693.7 | 4.3 | +0.0 | 293.3 | 110.0 |
| LONG SHOT | 0.3 | +2.7 | 34.7 | 0.0 | 1.0 | +19.5 | 100.3 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +1.9 | 211.0 | 41.7 | 1.0 | +1.1 | 56.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +0.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 62.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +61.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +10.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +63.0 | 0.0 | 0.0 | 1.7 | +20.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 45.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +6.4 | 0.0 | 25.0 | 2.0 | +38.6 | 0.0 | 6.3 |
| MEETS IN TIME | 3.3 | +190.8 | 0.0 | 0.0 | 5.0 | +92.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +20.8 | 0.0 | 20.0 | 5.0 | +150.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +12.9 | 0.0 | 20.0 | 5.7 | +97.5 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 69.3 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -61.9 | 0.0 | 78.0 |
| MOVE TO CHARGE COMPUTED | 9.7 | +1215.8 | 0.0 | 0.0 | 8.0 | +480.2 | 0.0 | 196.7 |
| NEARER NOT NEEDED | 7.0 | +230.3 | 0.0 | 62.0 | 7.0 | +314.0 | 0.0 | 125.3 |
| NEXT CHARGE BY LIST | 6.7 | +1008.6 | 0.0 | 0.0 | 6.7 | +361.9 | 0.0 | 162.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -4.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.7 | +55.5 | 0.0 | 57.7 | 3.3 | +105.4 | 22.7 | 34.0 |
| NO DOUBLE ROUNDS | 5.3 | -209.9 | 475.3 | 188.3 | 3.3 | -148.0 | 300.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -2.4 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -110.7 | 0.0 | 15.0 | 7.0 | -350.6 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.5 | 84.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -111.0 | 0.0 | 120.0 | 6.3 | -134.3 | 0.0 | 72.7 |
| ONE JOINT FIGURE | 2.0 | +2.8 | 207.3 | 41.7 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.7 | -25.7 | 0.0 | 43.3 | 3.0 | +2.4 | 0.0 | 38.0 |
| ONE PROMISE A TARGET | 0.7 | -44.7 | 0.0 | 0.0 | 1.0 | -1.7 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 45.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +13.8 | 34.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.0 | +23.1 | 34.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.7 | +66.2 | 258.0 | 87.0 | - | - | - | - |
| PATHS CROSS | 0.3 | -3.9 | 0.0 | 0.0 | 0.7 | -0.3 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +436.3 | 159.3 | 991.3 | 43.0 | +431.2 | 274.7 | 442.0 |
| PRIZE BY WORTH | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -402.1 | 0.0 | 0.0 | 13.3 | -553.8 | 0.0 | 34.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.7 | -2.5 | 0.0 | 0.0 | 2.7 | -3.7 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -33.5 | 0.0 | 0.0 |
| QUARTER ODDS | 18.7 | +2354.4 | 112.7 | 110.7 | 27.0 | +3151.3 | 78.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 45.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +155.2 | 0.0 | 108.7 | 0.3 | -4.1 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 62.7 | 0.7 | +0.0 | 0.0 | 12.7 |
| REDIRECT WEIGHED | 1.3 | +0.0 | 0.0 | 84.7 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -25.6 | 0.0 | 0.0 | 1.7 | -52.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +11.5 | 0.0 | 0.0 | 0.7 | +92.7 | 0.0 | 0.0 |
| RISK BY ARC | 5.0 | -93.2 | 437.3 | 188.3 | 3.0 | +92.2 | 275.3 | 0.0 |
| RISK ON THE WAY | 2.0 | +0.0 | 0.0 | 45.3 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -9.1 | 38.0 | 0.0 | - | - | - | - |
| RUN DOWN | 5.0 | -47.8 | 441.3 | 188.3 | 0.7 | -9.0 | 56.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | -0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -58.1 | 0.0 | 60.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +3.2 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +9.1 | 34.7 | 0.0 | 0.3 | +7.8 | 15.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -3.8 | 0.0 | 0.0 | 0.7 | -10.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | -13.5 | 38.0 | 0.0 | 2.7 | +36.6 | 15.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +1.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +31.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 30.0 | 2.7 | +0.0 | 0.0 | 78.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +109.8 | 0.0 | 0.0 | 1.3 | +55.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.5 | 38.0 | 0.0 | 0.3 | -0.1 | 22.7 | 0.0 |
| SHOT RISK POINTS | 43.0 | -518.8 | 0.0 | 520.3 | 13.0 | +92.9 | 0.0 | 34.0 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +70.2 | 0.0 | 0.0 | 16.7 | +222.3 | 0.0 | 116.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +31.0 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +3.0 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 400.0 | 8.3 | +0.0 | 0.0 | 34.0 |
| STAND AND SHOOT | 0.7 | -5.8 | 46.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 76.0 | 0.0 | - | - | - | - |
| STANDS STILL | 14.0 | +0.0 | 76.0 | 124.0 | 36.0 | +0.0 | 22.7 | 182.7 |
| STAY WORTH | 0.7 | +1.8 | 76.0 | 0.0 | 14.0 | +77.4 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +1.9 | 0.0 | 23.3 | 0.7 | +1.7 | 0.0 | 81.3 |
| STRONG ENOUGH TO HOLD | 1.7 | -9.4 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.0 | +119.5 | 0.0 | 62.0 | 5.7 | +297.3 | 0.0 | 68.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 122.7 | 0.0 | 0.7 | +0.0 | 46.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +119.5 | 0.0 | 62.0 | 5.7 | +297.3 | 0.0 | 68.0 |
| SURE REACH TOGETHER | 0.7 | +6.2 | 0.0 | 0.0 | 0.7 | +5.6 | 0.0 | 34.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.7 | +6.7 | 201.3 | 0.0 | 1.7 | +2.4 | 155.7 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -33.5 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 22.7 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 32.7 | 5.3 | +0.0 | 0.0 | 34.0 |
| THE ROW KEEPS ITS WAY | 6.0 | +0.0 | 0.0 | 46.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 23.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.3 | +0.0 | 0.0 | 403.0 | 45.0 | +0.0 | 0.0 | 244.7 |
| TIED UP BY THE SUM | 2.7 | +356.8 | 233.3 | 146.7 | 0.3 | +41.9 | 15.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 50.0 | +524.4 | 0.0 | 270.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +2.5 | 46.7 | 25.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | -13.8 | 91.0 | 0.0 | 1.0 | -2.1 | 102.0 | 0.0 |
| WHO HITS BACK | 0.7 | +91.0 | 0.0 | 25.0 | 0.3 | +36.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -255.4 | 0.0 | 135.0 | 4.7 | -448.6 | 0.0 | 76.0 |
| WHOLE FIGHT GAIN | 0.7 | +17.3 | 84.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.0 | +111.8 | 0.0 | 56.0 | 1.7 | +34.4 | 84.7 | 169.7 |
| WOUNDS ON THE RANKS | 8.3 | +350.3 | 0.0 | 0.0 | 2.3 | +17.7 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 177 | 177 | 125 | 41.67 | +606 | +4.9 |
| HIS SHOT LIST | 272 | 259 | 56 | 18.67 | +468 | +8.4 |
| HOLDER ASSIGNMENT | 49 | 49 | 43 | 14.33 | +2706 | +62.9 |
| QUARTER ODDS | 137 | 130 | 39 | 13.00 | +2992 | +76.7 |
| HIS SHOTS BY HIS RUN | 247 | 234 | 37 | 12.33 | +374 | +10.1 |
| FIVE ACTION | 524 | 490 | 31 | 10.33 | +911 | +29.4 |
| DEPLOY BY FIGURES | 49 | 49 | 30 | 10.00 | +280 | +9.3 |
| LEGAL CHARGES ONLY | 30 | 30 | 30 | 10.00 | +0 | +0.0 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1384 | -46.1 |
| PROMISE BY ITS OWN SUM | 69 | 69 | 30 | 10.00 | -2868 | -95.6 |
| MOVE TO CHARGE COMPUTED | 53 | 44 | 29 | 9.67 | +1189 | +41.0 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| GOAL WALK | 78 | 76 | 24 | 8.00 | +1165 | +48.5 |
| TIME ON OUR SIDE | 150 | 112 | 21 | 7.00 | +32 | +1.5 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 40 | 35 | 19 | 6.33 | +939 | +49.4 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| NO CHAFF EDGES | 15 | 15 | 13 | 4.33 | +455 | +35.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 28 | 26 | 12 | 4.00 | +448 | +37.3 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOT RISK POINTS | 168 | 164 | 11 | 3.67 | +47 | +4.2 |
| COVER ONCE | 56 | 27 | 10 | 3.33 | +56 | +5.6 |
| WOUNDS ON THE RANKS | 32 | 32 | 9 | 3.00 | +112 | +12.5 |
| MEETS IN TIME | 25 | 25 | 8 | 2.67 | +212 | +26.5 |
| CHAFF PASSED | 7 | 7 | 7 | 2.33 | -4 | -0.6 |
| PROMISE KNOWS THE FIGHT | 16 | 13 | 7 | 2.33 | -18 | -2.6 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 7 | 2.33 | +158 | +22.6 |
| CHAFF IN THE MOVE | 11 | 11 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +951 | +158.4 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| SET UP BY THE SET | 12 | 11 | 6 | 2.00 | +141 | +23.5 |
| TIED UP BY THE SUM | 9 | 9 | 6 | 2.00 | +264 | +43.9 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +215 | +42.9 |
| IDLE COST | 53 | 40 | 5 | 1.67 | +48 | +9.6 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +75 | +14.9 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -140 | -27.9 |
| SUPPORT ADDS | 26 | 22 | 5 | 1.67 | +97 | +19.4 |
| SUPPORT WORKED OUT | 26 | 22 | 5 | 1.67 | +97 | +19.4 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +5 | +1.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 125 | 115 | 4 | 1.33 | +48 | +12.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +197 | +49.2 |
| MAX FOR POSITIONING | 11 | 11 | 4 | 1.33 | +6 | +1.5 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +254 | +63.4 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +313 | +78.2 |
| RISK BY ARC | 24 | 22 | 4 | 1.33 | +47 | +11.7 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NEARER NOT NEEDED | 42 | 40 | 3 | 1.00 | +76 | +25.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | -13 | -4.3 |
| REDIRECT COUNTER | 12 | 10 | 3 | 1.00 | +208 | +69.3 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +11 | +3.6 |
| THE ROW IN ITS ORDER | 24 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +282 | +94.1 |
| BACKS UP THE FIGHT | 4 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.67 | -35 | -17.6 |
| CHARGE NOW FIRST | 14 | 14 | 2 | 0.67 | -82 | -41.0 |
| EXACT ROUND | 17 | 16 | 2 | 0.67 | +2 | +1.1 |
| FALLS SHORT | 67 | 55 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +184 | +91.8 |
| OVERRUNS AWAY | 8 | 8 | 2 | 0.67 | +67 | +33.7 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -11 | -5.4 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +10 | +4.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +51 | +25.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SURE REACH TOGETHER | 4 | 4 | 2 | 0.67 | +1 | +0.7 |
| WHOLE FIGHT DANGER | 21 | 15 | 2 | 0.67 | +42 | +21.0 |
| WHOLE FIGHT REACTION | 8 | 8 | 2 | 0.67 | +24 | +12.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +41 | +40.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.6 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -4 | -3.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +46 | +45.8 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.33 | +13 | +12.9 |
| HONEST WORTH | 26 | 24 | 1 | 0.33 | +42 | +42.1 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -30 | -30.4 |
| ONE FIGHT FORMULA | 35 | 13 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 6 | 6 | 1 | 0.33 | +13 | +12.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| OPENS UP IN FULL | 3 | 3 | 1 | 0.33 | +27 | +27.3 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 1 | 0.33 | +30 | +29.6 |
| SET UP TOGETHER | 5 | 4 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 52 | 30 | 1 | 0.33 | +34 | +34.3 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| SUPPORT NARROWED | 5 | 5 | 1 | 0.33 | -40 | -40.1 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -9 | -8.6 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| WHO FIGHTS | 6 | 5 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +13 | +12.9 |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 16 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 43 | 39 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 26 | 24 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 89 | 79 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 36 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 59 | 50 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 77 | 77 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 26 | 18 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 26 | 24 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 23 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 255 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 9 | 9 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 58 | 54 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 150 | 132 | 0 | 0.00 | - | - |
| STAY WORTH | 44 | 34 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 6 | 6 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE FIGHT MOVES | 10 | 8 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 253 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 5 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 6.00 | 95.6 |
| JOB FIRST | gate | 3.00 | 5.67 | 46.8 |
| ARMY TABLE | rule | 1.00 | 6.33 | 74.1 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | 1.00 | 2.6 |
| NO REASON | gate | - | 1.33 | 41.6 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.67 | 35.1 |
| MAIN BODY KEEPS ITS BAND | rule | - | 1.00 | 48.8 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.33 | 17.6 |
| CHARGE NOW FIRST | rule | - | 0.67 | 41.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 3.9 |
| JOINT CHARGE NOW | rule | 0.67 | - | 28.9 |
| PATHS CROSS | rule | 0.33 | 0.33 | 6.4 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 5.4 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 3.6 |
| CHAFF PASSED | rule | - | 0.33 | 3.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 30.4 |
| SUPPORT NARROWED | rule | - | 0.33 | 40.1 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 8.6 |

### Plans: chf-efd8067-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.3 | 75% | 475 | 436 | 92% |
| Mine | join | 2.7 | 100% | 97 | 0 | 0% |
| Mine | move | 32.0 | 97% | 1461 | 0 | 0% |
| Mine | shoot | 0.7 | 0% | 20 | 0 | 0% |
| Mine | support | 1.3 | 75% | 27 | 0 | 0% |
| Opponent | charge | 3.7 | 91% | 420 | 315 | 75% |
| Opponent | move | 36.3 | 95% | 2288 | 0 | 0% |
| Opponent | shoot | 3.0 | 67% | 205 | 116 | 57% |

### Battle groups: chf-efd8067-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 45% | 60% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 0% | 100% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 114 (9) | 66 | 48 | 56 | 44% | 3.2 | 133 (7) | 0 (1) | 88 (1) | 117 (8) | 88 (1) |
| Mine | Character | 10 | 22 (10) | 22 | 0 | 2 | 20% | 4.1 | 25 (8) | 15 (2) | - | 28 (5) | 17 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Fast Hammer | 8 | 22 (8) | 9 | 13 | 42 | 25% | 3.5 | 26 (3) | 0 (3) | 41 (2) | 20 (2) | 23 (6) |
| Mine | Hammer | 2 | 36 (2) | 8 | 28 | 54 | 50% | 2.0 | 67 (1) | 0 (1) | - | - | 36 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 35 | 0% | 2.2 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 47 (7) | 47 | 0 | 10 | 0% | 1.6 | 42 (3) | 62 (3) | - | 72 (3) | 28 (3) |
| Opponent | Clean-up | 2 | 160 (2) | 77 | 83 | 0 | 0% | 2.5 | - | 160 (2) | - | - | 160 (2) |
| Opponent | Fast Hammer | 5 | 36 (5) | 0 | 36 | 15 | 0% | 1.2 | 76 (2) | 0 (2) | 0 (1) | 0 (2) | 62 (3) |
| Opponent | Hammer | 11 | 26 (11) | 26 | 0 | 16 | 55% | 4.0 | 45 (4) | 0 (6) | 114 (1) | 48 (4) | 15 (7) |
| Opponent | Shooter | 8 | 13 (8) | 0 | 13 | 42 | 0% | 1.8 | 0 (1) | 31 (4) | 0 (3) | - | 13 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |

### Charged fights: chf-efd8067-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 121 | 3.0 | 1.2 | 40 | 31 | +9 | 0 of 6 | 5 of 6 | +140 | -17 |
| Mine | Warriors of Chaos | 1 | 0 | 359 | 5.0 | 1.2 | 72 | 0 | +72 | 1 of 5 | 4 of 5 | +104 | +64 |
| **Mine** | all armies | 3 | 0 | 200 | 3.7 | 1.2 | 55 | 17 | +38 | 1 of 11 | 9 of 11 | +122 | +19 |
| Opponent | Wood Elf Realms | 3 | 0 | 501 | 3.7 | 1.3 | 137 | 33 | +104 | 2 of 11 | 10 of 11 | +22 | +122 |

### Effective charges: chf-efd8067-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 6 | 1 (net +0) | 0 | 0 | 0 | 2 (net +51) | 3 (net -15) | 0 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 1 (net +0) | 2 (net +170) | 0 | 2 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 11 | 0 | 1 (net +0) | 2 (net +93) | 1 (net -66) | 2 (net +148) | 4 (net +68) | 1 | 20% (2 of 10) |

### Charged fights, damage counted: chf-efd8067-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 479 | 208 | +0 | 61 | 0 | +61 | +12.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 126 | 130 | -15 | 47 | 62 | -15 | -12.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 580 | 142 | +110 | 115 | 15 | +100 | +17.3 |
| Mine | No odds | 2 | 136 | 64 | +10 | 10 | 0 | +10 | +7.0 |
| Mine | All fights | 11 | 318 | 129 | +38 | 62 | 22 | +40 | +12.4 |
| Opponent | 50-54% | 1 | 217 | 70 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 2 | 114 | 118 | +93 | 93 | 0 | +93 | +81.6 |
| Opponent | 76-89% | 1 | 108 | 98 | -66 | 168 | 234 | -66 | -61.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 213 | 112 | +68 | 108 | 31 | +76 | +35.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 624 | 52 | +148 | 182 | 0 | +182 | +29.2 |
| Opponent | No odds | 1 | 0 | 285 | +458 | 458 | 209 | +249 | - |
| Opponent | All fights | 11 | 241 | 113 | +104 | 146 | 52 | +94 | +39.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p24 | move | 19 | 1 (5%) | 1 (5%) | 2 (11%) | 16 (84%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

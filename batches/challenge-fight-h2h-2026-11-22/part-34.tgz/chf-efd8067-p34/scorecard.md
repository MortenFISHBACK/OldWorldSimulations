# Doctrine scorecard: chf-efd8067-p34

### Scorecard: chf-efd8067-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 5 | 3 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 11 | 2 | 6 | 2 | 0 | 0 | 0 | 278 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 4 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.5 | 3.0 | 3.0 | 0.3 | 0.3 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 7.5 | 2.0 | 6.3 | 1.7 | 0.3 | 0.0 | 0.0 | 92.7 |

### KPIs: chf-efd8067-p34

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 18) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 71% (5 of 7); on the table 71% | 77% (10 of 13); on the table 77% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 5); on the table 0% | 0% (0 of 5); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 42% (5 of 12); on the table 42% | 56% (10 of 18); on the table 56% |
| Magic missiles tried each own turn | 50%+ | 13% (4 of 30) | 50% (9 of 18) | 27% (13 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 20% (4 of 20) | 53% (9 of 17) | 35% (13 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 25% (2 of 8) | - | 25% (2 of 8) |
| Points that never fought | lower | 39% (2323 of 5999) | 29% (1746 of 5999) | 34% (4069 of 11998) |
|   infantry points that never fought | lower | 71% (701 of 993) | 56% (585 of 1037) | 63% (1286 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (12 of 22) | 56% (9 of 16) | 55% (21 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2861 of 5151) | 45% (2028 of 4500) | 51% (4889 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (27%) | 2.7 (89%) | 5.0 (43%) |
| MARCHED: its unit marched | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| IN COMBAT: engaged in combat | 2.3 (27%) | 0.3 (11%) | 2.7 (23%) |
| REAR RANK: in a rear rank | 1.7 (19%) | 0.0 (0%) | 1.7 (14%) |
| GONE: slain | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| NOT OFFERED: not in the cast list | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.7 | 0.3 | 4.3 | 2.3 |
| not cast | 7.0 | 1.3 | 5.7 | 11.7 | 17.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (23%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 5.0 (43%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (10%) | 0.0 (0%) | 0.3 (6%) | 2.7 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (29%) | 0.0 (0%) | 2.0 (35%) | 1.7 (14%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.7 (10%) | 0.0 (0%) | 0.3 (6%) | 1.0 (9%) | 1.0 (6%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (52%) | 0.0 (0%) | 3.0 (53%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 100% (1 of 1) | 100% (1 of 1) |
| the unit moved after it | - | 100% (1 of 1) | 100% (1 of 1) |
| it charged on its next turn | - | 100% (1 of 1) | 100% (1 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 0% (0 of 1) | 0% (0 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (32 of 58) | 51% (42 of 82) | 53% (74 of 140) |
|   cavalry | - | 89% (16 of 18) | 89% (16 of 18) |
|   character | 100% (6 of 6) | 0% (0 of 24) | 20% (6 of 30) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 29% (10 of 34) | 65% (26 of 40) | 49% (36 of 74) |
|   monster | 88% (7 of 8) | - | 88% (7 of 8) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (23%) | 2.7 (20%) | 4.7 (21%) |
| CHARGED: it charged | 0.3 (4%) | 2.7 (20%) | 3.0 (14%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |
| NO TARGET IN RANGE | 4.3 (50%) | 4.3 (32%) | 8.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (19%) | 2.0 (15%) | 3.7 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.7 | 69% | 5.6 pts | 30 pts |
| character | 2.0 | 0.7 | 67% | 10.8 pts | 22 pts |
| chariot | 3.0 | 0.7 | 78% | 6.2 pts | 19 pts |
| infantry | 15.0 | 1.7 | 89% | 1.6 pts | 24 pts |
| monster | 2.3 | 1.0 | 71% | 12.6 pts | 29 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 7.3 | 5.5 |
| Charges that made contact a game | 3.3 | 4.0 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.36 contact (28 units) | 0.69 declared, 0.38 contact (29 units) | 0.54 declared, 0.37 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 33% (1 of 3) | 50% (1 of 2) | 17% (1 of 6) | 27% (3 of 11) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (3 of 6) | - | - | 50% (3 of 6) |
| Monster | 75% (3 of 4) | 33% (1 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 52% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 17% (2 of 12) | 61% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 33% (2 of 6); on the table 33% | 17% (1 of 6) | 36% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (3 of 6); on the table 50% | 67% (8 of 12) | 15% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (6) | 100% (3) | 64% (9) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 45% (9 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 65% (13 of 20) | 17% (3 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 75% (3 of 4) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.3 | 1.7 |
| Movement | Points that never moved of their own | 225.0 | 92.7 |
| Movement | Fights charged into per game | 3.3 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +195 | 2 of 11, net -33 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 4 of 11, net +271 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 11, net -112 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 3 of 11, net +197 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (13 of 32) | 26% (11 of 42) |
| Shooting | Points destroyed by shooting units | 0.0 | 29.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 0.7 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.3 / 0.0 | 1.0 / 0.3 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 296.7 | 604.7 |
| Combat | Points run down | 0.0 | 100.3 |
| Combat | Net points per charged fight, damage counted | +13 | +134 |
| Combat | Net per 100 charger points, damage counted | +7.0 | +48.2 |
| Combat | First round won (charged fights) | 50% | 75% |
| Combat | Net points per charged fight | +15 | +140 |
| Combat | Net points per supported fight / lone fight | - / +15 | - / +140 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 10 | 5 of 12 |
| Game | Points lost | 825.0 | 296.7 |
| Game | VP from objectives | 443.3 | 950.0 |
| Game | Lone holders (player turns) | 2.5 | 7.5 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1131 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1122
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +61.3 | 0.0 | 0.0 | 0.7 | +68.6 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 1.0 | +166.8 | 0.0 | 0.0 |
| ARMY TABLE | 20.7 | +415.8 | 0.0 | 459.3 | 22.3 | +337.5 | 0.0 | 121.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 108.7 | 1.0 | +0.6 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +79.2 | 0.0 | 0.0 | 2.0 | +551.3 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +6.1 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -214.5 | 131.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.7 | -21.3 | 70.0 | 65.0 |
| CAST JOB | 1.0 | +17.6 | 0.0 | 0.0 | 2.0 | +10.1 | 22.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +22.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.3 | -102.1 | 262.0 | 65.0 |
| CHARGE LOSSES | 16.7 | -720.4 | 0.0 | 546.7 | 13.0 | -682.2 | 0.0 | 20.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 22.0 | 0.0 | 4.0 | +0.0 | 448.7 | 130.0 |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 249.0 | 15.3 | +0.0 | 0.0 | 30.0 |
| COMBAT PIVOT | 1.3 | +0.0 | 65.0 | 0.0 | 0.3 | +0.0 | 87.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +34.6 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -195.1 | 0.0 | 112.0 | 5.3 | -330.6 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -9.0 | 371.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +18.1 | 0.0 | 0.0 | 8.3 | +77.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -137.3 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 1.0 | +27.1 | 85.0 | 130.0 |
| ELIXIR WORTH | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +12.2 | 130.0 | 0.0 | 6.0 | +51.9 | 579.3 | 217.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 131.0 | 0.7 | +0.0 | 0.0 | 65.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 22.0 | 0.0 | 5.3 | +4.8 | 553.0 | 130.0 |
| FALLS SHORT | 3.7 | +27.6 | 0.0 | 55.0 | 15.3 | +142.1 | 0.0 | 38.7 |
| FEATURE BUFFS | 0.7 | +3.3 | 0.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.6 | 65.0 | 0.0 | 1.3 | +21.1 | 201.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 77.3 | +6984.1 | 445.3 | 1433.0 | 101.7 | +7334.7 | 1317.7 | 452.3 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 148.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.8 | 18.3 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +43.9 | 0.0 | 0.0 | 2.0 | +109.6 | 0.0 | 65.0 |
| FOUR ROUNDS | 1.0 | +58.1 | 152.0 | 0.0 | 7.3 | +533.7 | 780.3 | 217.0 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 487.3 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -3.3 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -36.4 | 131.0 | 0.0 |
| GOAL WALK | 8.7 | +824.3 | 0.0 | 85.0 | 6.7 | +965.6 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +144.4 | 0.0 | 61.7 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 65.0 | 0.0 | 1.3 | -0.8 | 100.3 | 65.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 5.0 | +0.0 | 0.0 | 487.3 | - | - | - | - |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 131.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 546.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 218.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -17.5 | 0.0 | 36.7 | 5.3 | -68.6 | 0.0 | 22.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 11.3 | 10.3 | +0.0 | 0.0 | 16.7 |
| HIS RANDOM MOVE | - | - | - | - | 12.7 | +0.0 | 0.0 | 63.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 4.0 | +0.0 | 0.0 | 30.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 36.0 | +435.2 | 0.0 | 1133.7 | 49.0 | +889.9 | 0.0 | 148.7 |
| HIS SHOTS BY HIS RUN | 38.7 | +203.7 | 0.0 | 1122.0 | 38.3 | +652.2 | 0.0 | 110.7 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +49.9 | 471.3 | 0.0 |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 60.0 | 14.7 | +0.0 | 0.0 | 20.0 |
| HOLDER ASSIGNMENT | 7.7 | +580.6 | 0.0 | 30.0 | 10.0 | +889.1 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -23.5 | 87.0 | 0.0 | 6.3 | -228.3 | 780.3 | 130.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +120.1 | 0.0 | 0.0 |
| IDLE COST | 2.3 | -71.0 | 0.0 | 0.0 | 12.7 | -197.8 | 0.0 | 15.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +66.5 | 200.7 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -15.7 | 131.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.5 | 0.0 | 0.0 | 1.3 | +61.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 109.0 | 440.7 | 1.3 | +0.0 | 142.7 | 49.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 65.0 | 0.0 | 3.0 | +2.1 | 293.0 | 65.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 100.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -2.7 | 0.0 | 126.0 | 0.7 | -5.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +61.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +221.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -37.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.0 | +213.2 | 0.0 | 0.0 | 3.0 | +109.9 | 0.0 | 31.7 |
| MEETS IN TIME | 4.3 | +196.4 | 0.0 | 0.0 | 3.3 | +171.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +21.1 | 0.0 | 0.0 | 3.0 | +15.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +58.7 | 0.0 | 0.0 | 4.3 | +17.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -8.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +452.6 | 0.0 | 11.3 | 9.3 | +1270.6 | 0.0 | 33.3 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.0 | +452.5 | 0.0 | 137.7 | 10.0 | +323.9 | 0.0 | 44.0 |
| NEXT CHARGE BY LIST | 5.7 | +468.8 | 0.0 | 0.0 | 7.3 | +921.7 | 0.0 | 16.7 |
| NO CHAFF EDGES | 2.3 | +44.9 | 87.0 | 271.0 | 4.7 | +130.3 | 693.3 | 85.0 |
| NO DOUBLE ROUNDS | 0.3 | -0.3 | 22.0 | 0.0 | 6.3 | -268.7 | 649.3 | 195.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -166.2 | 0.0 | 0.0 | 6.3 | -163.7 | 78.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -50.0 | 0.0 | 0.0 | 6.3 | -140.9 | 0.0 | 31.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +7.6 | 131.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -46.5 | 0.0 | 11.7 | 4.3 | +37.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -28.8 | 0.0 | 0.0 | 1.7 | -202.6 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +100.3 | 0.0 | 65.0 |
| OPENS UP IN FULL | 0.7 | +11.0 | 87.0 | 0.0 | 3.3 | +183.2 | 425.3 | 130.0 |
| OVERRUNS AWAY | 0.7 | +6.2 | 87.0 | 0.0 | 3.0 | +67.1 | 332.3 | 130.0 |
| OWN CAST FIRST | 0.7 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +337.2 | 439.0 | 1202.7 | 48.7 | +1021.3 | 552.3 | 480.3 |
| PRIZE BY WORTH | - | - | - | - | 1.3 | +120.5 | 0.0 | 65.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 87.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -90.5 | 0.0 | 0.0 | 13.0 | -791.1 | 0.0 | 22.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 15.0 | +1914.9 | 65.0 | 261.0 | 27.0 | +2975.9 | 479.3 | 87.0 |
| RANDOM MOVE BY FIGURES | 2.7 | +26.4 | 0.0 | 140.0 | - | - | - | - |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +267.6 | 0.0 | 25.7 | 2.7 | +64.8 | 0.0 | 37.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 92.0 | 3.7 | +0.0 | 0.0 | 59.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.7 | +32.1 | 61.7 | 65.0 |
| REFORMS TO MEET IT | 1.0 | -11.0 | 0.0 | 11.3 | 2.7 | -92.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.3 | +72.8 | 0.0 | 22.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +121.2 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +6.5 | 87.0 | 0.0 | 6.7 | -125.3 | 695.3 | 217.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.3 | -151.4 | 509.0 | 195.0 |
| RUN DOWN | - | - | - | - | 6.3 | -42.4 | 579.3 | 195.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.0 | +6.7 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -32.5 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +1.2 | 0.0 | 0.0 | 0.7 | +1.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +38.8 | 22.0 | 0.0 | 0.3 | +50.5 | 78.0 | 0.0 |
| SELF MOVE SPELL | 1.7 | -3.1 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -142.1 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.7 | +210.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +1.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +43.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 78.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +22.8 | 33.3 | 0.0 | 2.7 | +73.4 | 131.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -17.0 | 242.7 | 22.0 |
| SHOT RISK POINTS | 16.3 | -80.3 | 0.0 | 485.7 | 22.0 | +195.9 | 0.0 | 105.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.7 | +404.0 | 0.0 | 265.7 | 12.3 | +80.4 | 0.0 | 86.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +43.3 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 114.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -5.0 | 278.7 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 131.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 29.3 | +0.0 | 293.3 | 457.0 | 42.7 | +0.0 | 537.3 | 124.7 |
| STAY WORTH | 8.3 | +113.6 | 0.0 | 0.0 | 14.3 | +41.8 | 406.3 | 62.0 |
| STRIKE BY THE ODDS | 1.0 | +7.0 | 0.0 | 0.0 | 0.7 | -161.2 | 131.0 | 65.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.3 | +1192.2 | 0.0 | 328.7 | 5.0 | +242.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 9.3 | +1192.2 | 0.0 | 328.7 | 5.0 | +242.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +5.5 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.8 | 0.0 | 18.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 18.3 | 1.3 | +0.0 | 0.0 | 20.0 |
| THE FIGHT MOVES | - | - | - | - | 2.0 | +133.7 | 216.0 | 130.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 36.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 36.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.3 | +0.0 | 0.0 | 393.7 | 48.0 | +0.0 | 0.0 | 117.7 |
| TIED UP BY THE SUM | 0.3 | +29.6 | 22.0 | 0.0 | 1.7 | +155.1 | 151.0 | 65.0 |
| TIME ON OUR SIDE | 31.3 | +371.4 | 0.0 | 634.0 | 21.7 | +150.1 | 36.7 | 108.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 20.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | -46.0 | 260.0 | 0.0 | 0.7 | -45.8 | 262.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.7 | +17.1 | 100.3 | 130.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +83.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | +19.5 | 130.0 | 0.0 | 0.3 | +2.8 | 131.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.0 | -577.5 | 0.0 | 285.7 | 1.7 | -418.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 3.3 | +434.4 | 130.0 | 313.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.0 | +11.5 | 0.0 | 0.0 | 1.3 | +6.0 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 129 | 129 | 73 | 24.33 | +2255 | +30.9 |
| HOLDER ASSIGNMENT | 53 | 53 | 46 | 15.33 | +2569 | +55.9 |
| HIS SHOT LIST | 255 | 243 | 34 | 11.33 | +326 | +9.6 |
| QUARTER ODDS | 126 | 123 | 34 | 11.33 | +2961 | +87.1 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -990 | -34.1 |
| HIS SHOTS BY HIS RUN | 231 | 221 | 28 | 9.33 | +243 | +8.7 |
| THE TABLE AGAIN | 35 | 35 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 48 | 48 | 24 | 8.00 | +222 | +9.2 |
| FIVE ACTION | 537 | 518 | 24 | 8.00 | +2037 | +84.9 |
| MOVE TO CHARGE COMPUTED | 47 | 41 | 24 | 8.00 | +1332 | +55.5 |
| NEXT CHARGE BY LIST | 39 | 39 | 24 | 8.00 | +1330 | +55.4 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 159 | 139 | 23 | 7.67 | +87 | +3.8 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 17 | 5.67 | -2645 | -155.6 |
| SUPPORT ADDS | 43 | 42 | 14 | 4.67 | +884 | +63.2 |
| SUPPORT WORKED OUT | 43 | 42 | 14 | 4.67 | +884 | +63.2 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NO CHAFF EDGES | 21 | 19 | 13 | 4.33 | +276 | +21.2 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 13 | 4.33 | +167 | +12.8 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +668 | +60.8 |
| CHARGE LOSSES | 89 | 83 | 10 | 3.33 | +440 | +44.0 |
| GOAL WALK | 46 | 45 | 10 | 3.33 | +1346 | +134.6 |
| FOUR ROUNDS | 25 | 22 | 9 | 3.00 | +442 | +49.1 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 3.00 | -694 | -77.1 |
| SHOT RISK POINTS | 115 | 107 | 8 | 2.67 | +99 | +12.4 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +460 | +65.8 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +218 | +31.2 |
| SCOUTS HUNT GUNS ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 6 | 2.00 | +7 | +1.2 |
| MARCH CHECK | 7 | 7 | 6 | 2.00 | +442 | +73.6 |
| MAX FOR POSITIONING | 24 | 22 | 6 | 2.00 | +12 | +2.1 |
| NEARER NOT NEEDED | 63 | 51 | 6 | 2.00 | +150 | +24.9 |
| REDIRECT COUNTER | 21 | 21 | 6 | 2.00 | +318 | +52.9 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 45 | 29 | 5 | 1.67 | +49 | +9.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +190 | +38.0 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +801 | +160.1 |
| SCOUT BY DROPS | 7 | 7 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 69 | 58 | 5 | 1.67 | +152 | +30.5 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +2 | +0.5 |
| BACKS UP THE FIGHT | 8 | 6 | 4 | 1.33 | +525 | +131.3 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 15 | 15 | 4 | 1.33 | -118 | -29.4 |
| COVER ONCE | 35 | 22 | 4 | 1.33 | +40 | +10.0 |
| FACES WHAT IT FOLLOWS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PRIZE BY WORTH | 4 | 4 | 4 | 1.33 | +362 | +90.4 |
| RISK BY ARC | 22 | 19 | 4 | 1.33 | +16 | +4.0 |
| STRIKE BY THE ODDS | 5 | 5 | 4 | 1.33 | +133 | +33.3 |
| SUPPORT NARROWED | 4 | 4 | 4 | 1.33 | -783 | -195.8 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +389 | +129.8 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 1.00 | +500 | +166.8 |
| EXACT ROUND | 20 | 18 | 3 | 1.00 | +10 | +3.2 |
| FIGHT TO THE END | 5 | 5 | 3 | 1.00 | +34 | +11.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +199 | +66.5 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| OVERRUNS AWAY | 11 | 8 | 3 | 1.00 | +11 | +3.8 |
| SET UP BY THE SET | 5 | 5 | 3 | 1.00 | +600 | +200.1 |
| STAY WORTH | 68 | 62 | 3 | 1.00 | +21 | +7.1 |
| TIED UP BY THE SUM | 6 | 3 | 3 | 1.00 | +154 | +51.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +3 | +1.5 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 2 | 2 | 2 | 0.67 | -28 | -13.9 |
| OPENS A LANE | 2 | 2 | 2 | 0.67 | +8 | +4.1 |
| OPENS UP IN FULL | 12 | 10 | 2 | 0.67 | +31 | +15.6 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -3 | -1.7 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 2 | 0.67 | +79 | +39.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +8 | +4.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +268 | +134.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +10 | +5.0 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +2 | +1.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +222 | +111.1 |
| WHOLE FIGHT DANGER | 20 | 20 | 2 | 0.67 | +101 | +50.5 |
| WHOLE FIGHT REACTION | 10 | 10 | 2 | 0.67 | +81 | +40.6 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -64 | -64.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -208 | -208.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +10 | +9.9 |
| FALLS SHORT | 57 | 45 | 1 | 0.33 | +17 | +16.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.3 |
| HIS MOVE AND SHOT | 30 | 29 | 1 | 0.33 | +40 | +39.9 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +133 | +132.6 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | -26 | -26.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +186 | +185.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 20 | 17 | 1 | 0.33 | +44 | +43.9 |
| ONE FIGHT FORMULA | 34 | 25 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -30 | -30.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +364 | +363.5 |
| ROUNDS AFTER TERROR | 13 | 12 | 1 | 0.33 | +9 | +8.7 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +16 | +16.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| THE FIGHT MOVES | 6 | 5 | 1 | 0.33 | +1 | +1.4 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +1 | +1.4 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 70 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 15 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 14 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 49 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 38 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 79 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 18 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 14 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 8 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 34 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 11 | 11 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 38 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 216 | 209 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 247 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 5.33 | 37.1 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 4.33 | 155.6 |
| ONE PROMISE A TARGET | rule | 1.33 | 1.67 | 77.1 |
| ARMY TABLE | rule | 0.67 | 1.33 | 72.6 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 29.4 |
| SUPPORT NARROWED | rule | 1.33 | - | 195.8 |
| OWN CAST FIRST | rule | 0.67 | - | 1.7 |
| RULE SWITCHED OFF | gate | - | 0.67 | 29.2 |
| AFTERMATH BAND | gate | - | 0.33 | 1.7 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 64.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 208.0 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 2.5 |
| FALLBACK | gate | 0.33 | - | 0.9 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 1.7 |
| INFANTRY NOT BEHIND INFANTRY | rule | 0.33 | - | 26.0 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 27.9 |
| REFUSING RETIRES | rule | - | 0.33 | 30.0 |
| RESERVE FALL BACK | rule | - | 0.33 | 1.2 |

### Plans: chf-efd8067-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 62 | 87 | 141% |
| Mine | move | 31.0 | 91% | 2044 | 0 | 0% |
| Mine | shoot | 5.7 | 76% | 969 | 250 | 26% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 6.7 | 60% | 1223 | 771 | 63% |
| Opponent | join | 1.7 | 100% | 52 | 0 | 0% |
| Opponent | move | 36.0 | 96% | 1688 | 0 | 0% |
| Opponent | shoot | 4.3 | 69% | 316 | 250 | 79% |

### Battle groups: chf-efd8067-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 73 (1) | 73 | 0 | 0 | 0% | 5.0 | - | 73 (1) | - | - | 73 (1) |
| Mine | Chaff | 7 | 45 (7) | 0 | 45 | 76 | 29% | 3.0 | 66 (4) | 0 (3) | - | 58 (6) | 0 (1) |
| Mine | Character | 7 | 35 (7) | 35 | 0 | 25 | 14% | 3.2 | 40 (5) | 9 (1) | - | 37 (6) | - |
| Mine | Clean-up | 4 | 61 (4) | 35 | 27 | 6 | 0% | 4.2 | 66 (1) | 66 (2) | 0 (1) | 66 (1) | 57 (3) |
| Mine | Fast Hammer | 1 | 6 (1) | 6 | 0 | 115 | 0% | 3.0 | - | 6 (1) | - | - | 6 (1) |
| Mine | Hammer | 11 | 19 (11) | 4 | 15 | 58 | 18% | 1.7 | 35 (4) | 9 (6) | 0 (1) | 37 (4) | 8 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 4.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 59 | 0% | 2.3 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 8 | 81 (8) | 17 | 63 | 47 | 38% | 1.2 | 129 (3) | 52 (1) | 47 (4) | 129 (3) | 48 (5) |
| Opponent | Character | 8 | 89 (8) | 79 | 10 | 2 | 12% | 3.6 | 95 (6) | 71 (2) | - | 129 (3) | 77 (5) |
| Opponent | Clean-up | 4 | 6 (4) | 6 | 0 | 27 | 50% | 2.5 | 0 (3) | 24 (1) | - | 0 (3) | 24 (1) |
| Opponent | Fast Hammer | 7 | 38 (7) | 26 | 12 | 31 | 29% | 3.8 | 51 (3) | 27 (4) | - | 0 (2) | 55 (5) |
| Opponent | Holder | 4 | 159 (4) | 0 | 159 | 23 | 0% | 2.2 | 159 (4) | - | - | 350 (2) | 0 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.3 | - | 0 (2) | 0 (1) | - | 0 (3) |

### Charged fights: chf-efd8067-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 195 | 3.0 | 1.0 | 65 | 0 | +65 | 1 of 3 | 1 of 3 | - | +65 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 327 | 7.0 | 1.0 | 47 | 53 | -6 | 3 of 7 | 4 of 7 | - | -6 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 0 | 174 | 3.3 | 1.0 | 52 | 37 | +15 | 4 of 10 | 5 of 10 | - | +15 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 877 | 4.5 | 1.0 | 195 | 14 | +181 | 4 of 9 | 6 of 9 | - | +181 |
| Opponent | Vampire Counts | 1 | 0 | 245 | 3.0 | 1.0 | 82 | 64 | +18 | 1 of 3 | 3 of 3 | - | +18 |
| **Opponent** | all armies | 3 | 30 | 666 | 4.0 | 1.0 | 167 | 26 | +140 | 5 of 12 | 9 of 12 | - | +140 |

### Effective charges: chf-efd8067-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 1 (net +195) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 1 (net +195) | 0 | 0 | 6 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net -33) | 0 | 3 (net +306) | 0 | 0 | 3 (net +197) | 1 | 38% (3 of 8) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 1 (net +165) | 1 (net +0) | 1 (net -112) | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: chf-efd8067-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 40 | 195 | +195 | 195 | 0 | +195 | +487.5 |
| Mine | 76-89% | 1 | 350 | 195 | +195 | 195 | 0 | +195 | +55.7 |
| Mine | No odds | 8 | 180 | 172 | -30 | 17 | 50 | -33 | -18.1 |
| Mine | All fights | 10 | 183 | 177 | +15 | 53 | 40 | +13 | +7.0 |
| Opponent | Long shot (under 50%) | 2 | 130 | 194 | -33 | 0 | 33 | -33 | -25.3 |
| Opponent | Effective (55-75%) | 4 | 386 | 283 | +271 | 297 | 41 | +256 | +66.2 |
| Opponent | 76-89% | 1 | 254 | 38 | +0 | 19 | 0 | +19 | +7.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 232 | 175 | +197 | 202 | 26 | +176 | +75.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 147 | 35 | -112 | 46 | 147 | -101 | -68.7 |
| Opponent | No odds | 1 | 431 | 185 | +185 | 205 | 0 | +205 | +47.6 |
| Opponent | All fights | 12 | 278 | 192 | +140 | 172 | 38 | +134 | +48.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p34 | move | 21 | 8 (38%) | 4 (19%) | 2 (10%) | 11 (52%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

# Doctrine scorecard: chf-efd8067-p38

### Scorecard: chf-efd8067-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 4 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 790 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 6 | 0 | 1 | 2 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 790 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 257 |
| **Average** | | | Mine | 67% | 1.5 | 4.0 | 1.0 | 3.0 | 0.3 | 0.0 | 0.0 | 583.3 |
| **Average** | | | Opponent | 67% | 1.5 | 4.0 | 2.0 | 1.7 | 0.7 | 0.0 | 0.0 | 127.3 |

### KPIs: chf-efd8067-p38

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (3 of 12) | 0% (0 of 15) | 11% (3 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 100% (7 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 22% (8 of 36) | 17% (1 of 6) | 21% (9 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (8 of 32) | 50% (1 of 2) | 26% (9 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (1 of 1) | - | 100% (1 of 1) |
| Points that never fought | lower | 55% (3248 of 5897) | 67% (4030 of 5999) | 61% (7278 of 11896) |
|   infantry points that never fought | lower | 54% (770 of 1437) | 94% (883 of 938) | 70% (1653 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 50% (10 of 20) | 55% (23 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 25% (1 of 4); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2462 of 4484) | 46% (2148 of 4648) | 50% (4610 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (68%) | 0.0 (0%) | 6.3 (58%) |
| MARCHED: its unit marched | 1.7 (18%) | 0.3 (20%) | 2.0 (18%) |
| IN COMBAT: engaged in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| GONE: slain | 0.7 (7%) | 1.3 (80%) | 2.0 (18%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 3.0 | 0.3 | 0.7 |
| not cast | 0.0 | 2.7 | 11.0 | 1.7 | 7.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.3 (58%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.0 (18%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (25%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.3 (12%) | 2.0 (18%) | 1.3 (80%) | 2.7 (36%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.7 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (55%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 50% (2 of 4) | - | 50% (2 of 4) |
| the unit moved after it | 100% (2 of 2) | - | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (45 of 59) | 56% (68 of 122) | 62% (113 of 181) |
|   cavalry | - | 68% (13 of 19) | 68% (13 of 19) |
|   character | - | 0% (0 of 20) | 0% (0 of 20) |
|   chariot | 50% (9 of 18) | 83% (5 of 6) | 58% (14 of 24) |
|   infantry | - | 71% (42 of 59) | 71% (42 of 59) |
|   war machine | 88% (36 of 41) | 44% (8 of 18) | 75% (44 of 59) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (7%) | 2.3 (13%) | 2.7 (12%) |
| CHARGED: it charged | 0.3 (7%) | 2.0 (11%) | 2.3 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (7%) | 0.7 (4%) | 1.0 (4%) |
| MOVED: a war machine that moved | 0.7 (14%) | 0.7 (4%) | 1.3 (6%) |
| NO TARGET IN RANGE | 1.3 (29%) | 7.3 (41%) | 8.7 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (4%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (36%) | 2.3 (13%) | 4.0 (18%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.7 (9%) | 1.7 (7%) |
| OTHER BAR | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.7 | 87% | 3.2 pts | 16 pts |
| chariot | 5.0 | 4.0 | 53% | 21.2 pts | 106 pts |
| infantry | 17.0 | 5.3 | 75% | 6.1 pts | 104 pts |
| war machine | 15.0 | 15.7 | 69% | 18.5 pts | 277 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 4.3 | 3.0 |
| Charges that made contact a game | 1.3 | 2.3 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.20 contact (20 units) | 0.43 declared, 0.23 contact (30 units) | 0.36 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Character in a unit | 75% (3 of 4) | 50% (1 of 2) | - | 67% (4 of 6) |
| Character on its own | 50% (1 of 2) | - | 40% (2 of 5) | 43% (3 of 7) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 67% (6 of 9) | 100% (2 of 2) | - | 73% (8 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (2 of 2); on the table 100% | 50% (6 of 12) | 16% | 33% (2 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 8% (2 of 24) | 74% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Empire of Man | 1 | - | 17% (1 of 6) | 85% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (3 of 3); on the table 100% | - | 58% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 0% (0) | 17% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 30% (3 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 69% (33 of 48) | 78% (29 of 37) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 80% (4 of 5) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 1.7 |
| Movement | Points that never moved of their own | 583.3 | 127.3 |
| Movement | Fights charged into per game | 1.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 2 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +66 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 1 of 4, net +81 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 21.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (3 of 9) | 27% (17 of 63) |
| Shooting | Points destroyed by shooting units | 126.7 | 96.7 |
| Shooting | War machine shots | 12.3 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (11 of 37) | 50% (4 of 8) |
| Shooting | Points destroyed by war machines | 117.0 | 103.3 |
| Magic | Magic missiles cast | 1.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.0 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 24.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.7 / 0.0 | 4.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 298.0 | 225.3 |
| Combat | Points run down | 0.0 | 36.7 |
| Combat | Net points per charged fight, damage counted | +118 | +34 |
| Combat | Net per 100 charger points, damage counted | +88.7 | +10.4 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +125 | +61 |
| Combat | Net points per supported fight / lone fight | - / +125 | +0 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 4 of 6 |
| Game | Points lost | 586.7 | 508.0 |
| Game | VP from objectives | 350.0 | 910.0 |
| Game | Lone holders (player turns) | 1.5 | 1.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -532 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1095
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +135.0 | 0.0 | 83.7 | 28.0 | +400.0 | 0.0 | 434.7 |
| ARTILLERY RE-ROLL WEIGHED | 7.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 1.3 | +99.3 | 0.0 | 117.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.9 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 253.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.0 | +165.0 | 464.0 | 36.7 | 3.0 | +99.5 | 516.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -66.7 | 31.7 | 0.0 |
| CAST JOB | 0.7 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +53.7 | 129.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +11.3 | 0.0 | 0.0 | 0.7 | +44.0 | 0.0 | 44.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.3 | -93.0 | 0.0 | 340.7 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -647.7 | 0.0 | 426.0 | 17.3 | -585.9 | 0.0 | 398.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 22.0 | 0.0 | 3.7 | +0.0 | 343.0 | 381.7 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 110.0 | 12.7 | +0.0 | 0.0 | 24.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +152.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.3 | -545.7 | 0.0 | 362.3 | 5.7 | -161.1 | 0.0 | 93.7 |
| DEPLOY BY FIGURES | 8.7 | -2.7 | 0.0 | 0.0 | 8.0 | -36.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +15.1 | 62.7 | 0.0 | 3.3 | +43.9 | 304.3 | 130.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 211.0 | 0.0 | 3.7 | +7.0 | 287.0 | 470.7 |
| FALLS SHORT | 8.3 | +182.2 | 0.0 | 118.0 | 14.3 | +126.2 | 0.0 | 246.0 |
| FEATURE BUFFS | 6.0 | +71.9 | 0.0 | 54.0 | 2.7 | +33.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 0.0 | 0.0 | 1.3 | +83.9 | 135.0 | 340.7 |
| FIVE ACTION | 88.7 | +3128.4 | 1937.7 | 1222.0 | 115.0 | +8679.4 | 2863.0 | 1358.7 |
| FLANK NOT WEIGHED | 11.7 | +0.0 | 0.0 | 125.0 | 2.0 | +0.0 | 0.0 | 134.3 |
| FOLLOW UP WEIGHED | 1.0 | +19.2 | 0.0 | 0.0 | 0.7 | +101.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +56.0 | 233.0 | 0.0 | 4.3 | +383.3 | 332.3 | 470.7 |
| FREED FROM HIS FIGHT | 5.7 | +0.0 | 0.0 | 73.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.2 | 0.0 | 0.0 | 1.0 | -0.4 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -2.7 | 0.0 | 0.0 | 0.3 | -5.0 | 31.7 | 0.0 |
| GIVES UP ITS SCREEN | 0.7 | -3.2 | 40.7 | 0.0 | - | - | - | - |
| GOAL WALK | 10.0 | +719.0 | 0.0 | 54.0 | 20.0 | +2780.1 | 0.0 | 51.3 |
| GUN FIGURES | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.7 | +23.3 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.7 | +0.2 | 40.7 | 0.0 | 1.7 | +6.2 | 63.3 | 170.3 |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 310.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.7 | +0.0 | 0.0 | 219.3 | 5.3 | +0.0 | 0.0 | 347.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +1.2 | 17.3 | 0.0 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 123.3 | - | - | - | - |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 93.7 |
| HIS MOVE AND SHOT | 5.0 | -44.8 | 0.0 | 0.0 | 4.0 | -52.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 63.3 | 5.3 | +0.0 | 0.0 | 90.7 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 34.7 | 6.0 | +0.0 | 0.0 | 93.7 |
| HIS RANDOM MOVE | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +1569.9 | 0.0 | 735.3 | 60.7 | +1838.7 | 0.0 | 677.3 |
| HIS SHOTS BY HIS RUN | 35.3 | +418.0 | 0.0 | 579.0 | 41.0 | +458.4 | 0.0 | 571.7 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 108.0 | 25.7 | +0.0 | 0.0 | 121.7 |
| HOLDER ASSIGNMENT | 6.7 | +598.8 | 0.0 | 27.0 | 17.3 | +1362.7 | 0.0 | 73.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -18.2 | 62.7 | 0.0 | 3.3 | -100.5 | 332.3 | 300.3 |
| IDLE COST | 7.7 | -53.1 | 0.0 | 52.0 | 13.7 | -197.8 | 0.0 | 117.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +42.3 | 0.0 | 170.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +27.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +61.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 170.3 | 103.3 | 3.0 | +0.0 | 93.3 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.2 | 40.7 | 0.0 | 2.0 | -5.9 | 90.3 | 235.3 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 2.0 | +9.7 | 0.0 | 22.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | -9.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +42.9 | 0.0 | 55.3 | 3.3 | +40.7 | 0.0 | 40.7 |
| MEETS IN TIME | 3.3 | +197.9 | 0.0 | 0.0 | 2.3 | +241.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +106.8 | 0.0 | 27.0 | 0.3 | +15.6 | 0.0 | 126.7 |
| MISSILES NEXT TURN | 5.0 | +77.4 | 0.0 | 27.0 | 0.7 | +15.5 | 0.0 | 126.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +269.2 | 0.0 | 186.7 | 3.3 | +284.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +342.7 | 0.0 | 88.7 | 12.3 | +478.4 | 0.0 | 49.7 |
| NEXT CHARGE BY LIST | 5.7 | +224.5 | 0.0 | 186.7 | 3.3 | +260.3 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.0 | +3.8 | 0.0 | 17.3 | 3.7 | +104.7 | 235.3 | 365.3 |
| NO DOUBLE ROUNDS | 0.3 | -2.2 | 0.0 | 0.0 | 4.3 | -169.9 | 332.3 | 470.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -146.3 | 170.3 | 36.7 | 3.3 | -35.2 | 103.3 | 24.0 |
| OGRE LOADER SECOND SHOT | 4.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -21.2 | 0.0 | 34.7 | 6.0 | -141.2 | 0.0 | 134.3 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +171.6 | 0.0 | 340.7 |
| ONE OBJECTIVE FORMULA | 4.7 | +196.5 | 0.0 | 27.0 | 8.7 | +16.8 | 0.0 | 24.0 |
| ONE PROMISE A TARGET | 1.3 | -23.8 | 0.0 | 63.0 | 0.3 | -12.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +19.3 | 0.0 | 65.0 |
| OPENS UP IN FULL | - | - | - | - | 2.0 | +47.1 | 198.7 | 300.3 |
| OVERRUNS AWAY | 0.3 | +3.5 | 0.0 | 0.0 | 1.0 | +10.4 | 81.0 | 65.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.0 | +1158.9 | 723.7 | 809.7 | 51.0 | +1022.7 | 1156.7 | 1133.0 |
| PRIZE BY WORTH | - | - | - | - | 1.0 | +48.2 | 0.0 | 65.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -185.9 | 0.0 | 60.7 | 8.0 | -215.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2.3 | -12.2 | 0.0 | 117.3 | - | - | - | - |
| QUARTER ODDS | 18.3 | +1200.1 | 22.0 | 63.3 | 21.7 | +2331.6 | 68.3 | 90.7 |
| RANDOM MOVE BY FIGURES | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +22.1 | 0.0 | 0.0 | 0.7 | +14.4 | 0.0 | 44.0 |
| REDIRECT COUNTER | 4.3 | +141.8 | 0.0 | 55.3 | 2.0 | +43.7 | 0.0 | 64.7 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +35.9 | 0.0 | 56.3 | 5.0 | +23.7 | 0.0 | 171.3 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +53.9 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -6.1 | 0.0 | 0.0 | 1.7 | -10.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +20.6 | 0.0 | 110.7 |
| RISK BY ARC | 1.3 | +36.1 | 192.3 | 0.0 | 3.3 | +12.6 | 332.3 | 405.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -10.0 | 90.3 | 235.3 |
| RUN DOWN | - | - | - | - | 3.0 | -7.8 | 172.3 | 470.7 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.2 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +5.5 | 170.3 | 0.0 | 0.7 | +41.1 | 131.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -19.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +5.1 | 0.0 | 0.0 | 1.7 | -0.7 | 17.3 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +15.4 | 0.0 | 22.0 |
| SET-UP ANY TARGET | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 243.3 | 13.0 | +0.0 | 0.0 | 40.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +51.1 | 0.0 | 0.0 | 2.0 | +32.2 | 56.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -2.0 | 49.0 | 0.0 |
| SHOT RISK POINTS | 27.0 | +146.4 | 0.0 | 491.3 | 31.3 | -190.3 | 0.0 | 583.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +669.2 | 0.0 | 243.3 | 27.3 | +464.2 | 0.0 | 199.0 |
| SPELL SETS UP CHARGE | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 147.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 48.0 | 0.0 | 6.0 | +0.0 | 516.7 | 0.0 |
| STANDS STILL | 49.7 | +0.0 | 1704.7 | 862.0 | 52.3 | +0.0 | 2530.7 | 162.7 |
| STAY WORTH | 34.0 | -409.6 | 1403.3 | 346.7 | 38.3 | +389.5 | 2211.7 | 239.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +85.3 | 76.7 | 405.7 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +108.3 | 0.0 | 60.7 | 2.0 | +58.5 | 0.0 | 23.3 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 27.0 | 65.0 |
| SUPPORT WORKED OUT | 4.0 | +108.3 | 0.0 | 60.7 | 2.0 | +58.5 | 0.0 | 23.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 1.7 | +157.0 | 90.3 | 405.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 104.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 23.3 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 574.3 | 52.3 | +0.0 | 0.0 | 444.0 |
| TIED UP BY THE SUM | 0.3 | +26.0 | 22.0 | 0.0 | 2.0 | +177.6 | 140.7 | 130.0 |
| TIME ON OUR SIDE | 22.7 | +256.7 | 0.0 | 577.3 | 24.3 | +207.6 | 56.7 | 210.7 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 253.3 | 206.7 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +4.5 | 340.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.3 | -25.1 | 63.3 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 170.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -360.9 | 0.0 | 63.3 | 2.0 | -61.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.4 | 0.0 | 170.3 |
| WHOLE FIGHT REACTION | 3.0 | +777.9 | 365.3 | 140.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.7 | +90.8 | 0.0 | 0.0 | 2.3 | +80.1 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 119 | 119 | 86 | 28.67 | +1391 | +16.2 |
| HIS SHOT LIST | 320 | 312 | 74 | 24.67 | +774 | +10.5 |
| HOLDER ASSIGNMENT | 72 | 72 | 64 | 21.33 | +3084 | +48.2 |
| DEPLOY BY FIGURES | 50 | 50 | 35 | 11.67 | +596 | +17.0 |
| HIS SHOTS BY HIS RUN | 229 | 221 | 32 | 10.67 | +174 | +5.4 |
| SHOT RISK POINTS | 175 | 167 | 31 | 10.33 | +471 | +15.2 |
| GOAL WALK | 90 | 89 | 27 | 9.00 | +1579 | +58.5 |
| ARTILLERY RE-ROLL WEIGHED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 28 | 28 | 26 | 8.67 | +97 | +3.7 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -545 | -23.7 |
| FIVE ACTION | 611 | 595 | 21 | 7.00 | +524 | +25.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 29 | 24 | 17 | 5.67 | +401 | +23.6 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 17 | 5.67 | -1205 | -70.9 |
| TIME ON OUR SIDE | 141 | 125 | 17 | 5.67 | +58 | +3.4 |
| NEXT CHARGE BY LIST | 27 | 24 | 15 | 5.00 | +342 | +22.8 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +4 | +0.3 |
| CANNON PLANNED TARGET | 42 | 42 | 11 | 3.67 | -3 | -0.2 |
| QUARTER ODDS | 120 | 115 | 11 | 3.67 | +652 | +59.2 |
| FOUR ROUNDS | 18 | 14 | 10 | 3.33 | +296 | +29.6 |
| MAX FOR POSITIONING | 19 | 18 | 10 | 3.33 | +6 | +0.6 |
| NO CHAFF EDGES | 14 | 13 | 10 | 3.33 | +252 | +25.2 |
| CHARGE LOSSES | 105 | 97 | 9 | 3.00 | +186 | +20.7 |
| STAY WORTH | 217 | 199 | 9 | 3.00 | +25 | +2.8 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 48 | 30 | 6 | 2.00 | +249 | +41.5 |
| MEETS IN TIME | 17 | 17 | 6 | 2.00 | +366 | +61.0 |
| ONE OBJECTIVE FORMULA | 40 | 32 | 6 | 2.00 | +272 | +45.3 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +362 | +72.4 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +619 | +123.7 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -109 | -21.8 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 5 | 1.67 | +9 | +1.8 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +5 | +1.2 |
| CHAFF IN THE MOVE | 5 | 5 | 4 | 1.33 | +67 | +16.7 |
| CHARGE NOW FIRST | 12 | 12 | 4 | 1.33 | -181 | -45.3 |
| EXACT ROUND | 14 | 12 | 4 | 1.33 | +32 | +8.0 |
| IDLE COST | 64 | 36 | 4 | 1.33 | +31 | +7.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +184 | +46.0 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +62 | +15.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +140 | +34.9 |
| SHOTS IN THE MOVE | 127 | 94 | 4 | 1.33 | +633 | +158.3 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +256 | +64.0 |
| TIED UP BY THE SUM | 7 | 5 | 4 | 1.33 | +46 | +11.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +127 | +42.3 |
| MISSILES IN THE MOVE | 12 | 8 | 3 | 1.00 | +55 | +18.3 |
| PRIZE BY WORTH | 3 | 3 | 3 | 1.00 | +145 | +48.2 |
| PROMISE KNOWS THE FIGHT | 7 | 5 | 3 | 1.00 | -36 | -12.2 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +606 | +202.0 |
| RISK BY ARC | 14 | 10 | 3 | 1.00 | +24 | +8.1 |
| SHOTS AFTER THE MOVES | 28 | 28 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 18 | 16 | 3 | 1.00 | +109 | +36.4 |
| SUPPORT WORKED OUT | 18 | 16 | 3 | 1.00 | +109 | +36.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 68 | 57 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 26 | 26 | 2 | 0.67 | +24 | +12.0 |
| FIGHT TO THE END | 5 | 3 | 2 | 0.67 | +152 | +76.0 |
| ONE FIGHT FORMULA | 26 | 13 | 2 | 0.67 | +0 | +0.0 |
| OPENS UP IN FULL | 6 | 5 | 2 | 0.67 | +18 | +9.2 |
| REDIRECT COUNTER | 19 | 14 | 2 | 0.67 | +25 | +12.6 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +31 | +15.5 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -7 | -3.3 |
| THE FIGHT MOVES | 5 | 4 | 2 | 0.67 | +152 | +76.0 |
| WHOLE FIGHT DANGER | 15 | 15 | 2 | 0.67 | +64 | +32.1 |
| WHOLE FIGHT REACTION | 9 | 9 | 2 | 0.67 | +0 | +0.2 |
| BACKS UP THE FIGHT | 4 | 2 | 1 | 0.33 | +7 | +7.1 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -200 | -200.3 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +43 | +43.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +81 | +81.2 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +3 | +2.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +34 | +34.0 |
| MISSILES NEXT TURN | 17 | 13 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 57 | 56 | 1 | 0.33 | +62 | +62.3 |
| NO DOUBLE ROUNDS | 14 | 11 | 1 | 0.33 | +150 | +150.4 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +40 | +40.4 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +8 | +8.3 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +14 | +13.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -12 | -12.5 |
| RANDOM MOVE BY FIGURES | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +35 | +35.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STAND AND SHOOT | 2 | 2 | 1 | 0.33 | +1 | +0.7 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| THE ROW IN ITS ORDER | 26 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 34 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 129 | 129 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 273 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT BY DROPS | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 89 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 34 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 306 | 299 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 17 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 281 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 15 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 4 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 21 | 20 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 24.2 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.00 | 70.9 |
| ARMY TABLE | rule | 0.67 | 2.00 | 64.0 |
| HOLDER ASSIGNMENT | rule | - | 1.67 | 11.5 |
| ONE PROMISE A TARGET | rule | 1.33 | 0.33 | 21.8 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 45.3 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 12.2 |
| SUPPORT NARROWED | rule | - | 0.67 | 3.3 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 2.6 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 200.3 |
| CHAFF PASSED | rule | - | 0.33 | 1.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.1 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.33 | 1.6 |
| NO REASON | gate | 0.33 | - | 31.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 12.5 |
| RULE SWITCHED OFF | gate | - | 0.33 | 4.6 |

### Plans: chf-efd8067-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 55 | 201 | 366% |
| Mine | move | 24.3 | 89% | 835 | 0 | 0% |
| Mine | shoot | 13.3 | 60% | 694 | 958 | 138% |
| Mine | support | 1.0 | 100% | 18 | 0 | 0% |
| Opponent | charge | 3.3 | 60% | 545 | 265 | 49% |
| Opponent | move | 36.7 | 95% | 2818 | 0 | 0% |
| Opponent | shoot | 10.7 | 78% | 522 | 757 | 145% |
| Opponent | support | 0.3 | 100% | 12 | 0 | 0% |

### Battle groups: chf-efd8067-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 8% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 51 (7) | 51 | 0 | 11 | 14% | 3.0 | 0 (1) | 66 (4) | 0 (1) | 0 (1) | 57 (5) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 37 (5) | 37 | 0 | 58 | 60% | 5.0 | - | 0 (1) | 45 (4) | 0 (3) | 89 (2) |
| Mine | Hammer | 9 | 41 (9) | 28 | 13 | 36 | 11% | 2.5 | 0 (1) | 63 (6) | 10 (2) | 31 (5) | 54 (4) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 8 | 30 (8) | 30 | 0 | 19 | 0% | 1.0 | 9 (5) | 0 (2) | 201 (1) | 15 (3) | 40 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 22 | 60% | 4.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 5 | 26 (5) | 0 | 26 | 75 | 20% | 1.0 | 62 (2) | 0 (2) | 0 (1) | 26 (5) | - |
| Opponent | Character | 8 | 36 (8) | 36 | 0 | 48 | 50% | 2.8 | 46 (3) | 16 (3) | 43 (2) | 35 (5) | 38 (3) |
| Opponent | Clean-up | 3 | 108 (3) | 0 | 108 | 28 | 67% | 6.0 | 150 (2) | 0 (1) | - | 150 (2) | 0 (1) |
| Opponent | Fast Hammer | 7 | 15 (7) | 13 | 2 | 14 | 71% | 4.0 | 0 (3) | 25 (4) | - | 18 (3) | 12 (4) |
| Opponent | Holder | 10 | 53 (10) | 14 | 39 | 10 | 0% | 1.8 | 34 (3) | 32 (3) | 93 (4) | 51 (5) | 56 (5) |
| Opponent | Shooter | 1 | 191 (1) | 50 | 141 | 0 | 0% | 3.0 | - | 191 (1) | - | - | 191 (1) |
| Opponent | War machine | 3 | 83 (3) | 83 | 0 | 0 | 0% | 1.0 | 83 (3) | - | - | 0 (2) | 248 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: chf-efd8067-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 633 | 3.0 | 1.0 | 211 | 66 | +145 | 1 of 3 | 3 of 3 | - | +145 |
| Mine | Chaos Dwarfs | 2 | 366 | 33 | 0.5 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| **Mine** | all armies | 3 | 268 | 233 | 1.3 | 1.0 | 175 | 50 | +125 | 1 of 4 | 4 of 4 | - | +125 |
| Opponent | Empire of Man | 1 | 310 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | +0 | - |
| Opponent | Tomb Kings of Khemri | 2 | 145 | 280 | 2.5 | 1.0 | 112 | 39 | +73 | 3 of 5 | 3 of 5 | - | +73 |
| **Opponent** | all armies | 3 | 200 | 187 | 2.0 | 1.2 | 94 | 32 | +61 | 4 of 6 | 3 of 6 | +0 | +73 |

### Effective charges: chf-efd8067-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 2 (net +61) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net +0) | 0 | 0 | 1 (net +170) | 0 | 1 (net +81) | 2 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 68 | 64 | +61 | 74 | 13 | +60 | +88.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | No odds | 1 | 85 | 411 | +312 | 511 | 226 | +285 | +335.1 |
| Mine | All fights | 4 | 133 | 151 | +125 | 181 | 63 | +118 | +88.7 |
| Opponent | Long shot (under 50%) | 2 | 355 | 293 | +0 | 0 | 80 | -80 | -22.6 |
| Opponent | 76-89% | 1 | 431 | 170 | +170 | 170 | 0 | +170 | +39.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 81 | +81 | 81 | 0 | +81 | +41.5 |
| Opponent | No odds | 2 | 318 | 291 | +58 | 155 | 98 | +58 | +18.1 |
| Opponent | All fights | 6 | 328 | 236 | +61 | 94 | 59 | +34 | +10.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p38 | move | 17 | 5 (29%) | 3 (18%) | 1 (6%) | 11 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

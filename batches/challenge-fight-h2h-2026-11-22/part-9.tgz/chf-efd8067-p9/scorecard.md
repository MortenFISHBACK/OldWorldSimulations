# Doctrine scorecard: chf-efd8067-p9

### Scorecard: chf-efd8067-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 9 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 2 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 8 | 0 | 0 | 0 | 0 | 72 |
| **Average** | | | Mine | 33% | 4.5 | 2.5 | 2.3 | 0.7 | 0.7 | 0.0 | 0.0 | 33.3 |
| **Average** | | | Opponent | 67% | 2.0 | 2.3 | 4.7 | 2.3 | 0.7 | 0.0 | 0.0 | 24.0 |

### KPIs: chf-efd8067-p9

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 33% (2 of 6); on the table 33% | 33% (2 of 6); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 44% (4 of 9); on the table 56% | 62% (8 of 13); on the table 69% |
| Magic missiles tried each own turn | 50%+ | - | 78% (14 of 18) | 78% (14 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 89% (8 of 9) | 89% (8 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 39% (2337 of 6000) | 41% (2472 of 5999) | 40% (4809 of 11999) |
|   infantry points that never fought | lower | 61% (812 of 1332) | 63% (529 of 834) | 62% (1341 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (14 of 20) | 47% (8 of 17) | 59% (22 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3297 of 5135) | 39% (1789 of 4600) | 52% (5086 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.3 (25%) | 0.3 (25%) |
| IN COMBAT: engaged in combat | - | 0.7 (50%) | 0.7 (50%) |
| GONE: slain | - | 0.3 (25%) | 0.3 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.0 | 1.0 | 4.7 | 0.0 | 3.3 |
| not cast | 5.7 | 2.0 | 1.0 | 1.3 | 2.0 | 24.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.3 (25%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (12%) | 0.3 (17%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 1.3 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (82%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (45 of 83) | 59% (20 of 34) | 56% (65 of 117) |
|   cavalry | 40% (4 of 10) | 75% (6 of 8) | 56% (10 of 18) |
|   character | 44% (4 of 9) | 0% (0 of 8) | 24% (4 of 17) |
|   chariot | 50% (3 of 6) | - | 50% (3 of 6) |
|   infantry | 63% (22 of 35) | 78% (14 of 18) | 68% (36 of 53) |
|   monster | 45% (5 of 11) | - | 45% (5 of 11) |
|   war machine | 58% (7 of 12) | - | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (29%) | 0.3 (7%) | 4.0 (23%) |
| CHARGED: it charged | 1.3 (11%) | 1.7 (36%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 1.0 (8%) | 0.0 (0%) | 1.0 (6%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 3.0 (24%) | 1.7 (36%) | 4.7 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (8%) | 0.3 (7%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (11%) | 0.7 (14%) | 2.0 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.7 | 60% | 3.2 pts | 11 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 19.0 | 4.3 | 79% | 7.1 pts | 134 pts |
| monster | 1.7 | 0.3 | 80% | 9.8 pts | 16 pts |
| war machine | 2.3 | 0.7 | 86% | 5.4 pts | 12 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 7.3 | 5.3 |
| Charges that made contact a game | 3.0 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 2.50 declared, 1.50 contact (2 units) | 1.25 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.41 contact (22 units) | 0.68 declared, 0.36 contact (25 units) | 0.57 declared, 0.38 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 50% (1 of 2) | 0% (0 of 2) | 43% (3 of 7) |
| Character in a unit | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 44% (4 of 9) | 54% (7 of 13) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 67% (4 of 6) | 100% (2 of 2) | - | 75% (6 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 35% | 57% (4 of 7) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 64% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | - | - | 17% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 67% | - | 35% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 50% (3 of 6); on the table 50% | 78% (14 of 18) | 44% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 83% (5) | 60% (3) | 73% (8) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.67 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (6 of 6) | 35% (7 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 19% (3 of 16) | 0% (0 of 8) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 33.3 | 24.0 |
| Movement | Fights charged into per game | 3.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 8, net +30 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 6, net -5 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 6, net -104 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 6 | 5 of 8, net +221 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (27 of 44) | 42% (10 of 24) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (2 of 7) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 44% (4 of 9) |
| Magic | Wounds caused by magic missiles | 1.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 26.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.0 / 0.0 | 2.7 / 0.0 / 1.3 / 0.0 |
| Combat | Points destroyed in combat | 195.3 | 410.3 |
| Combat | Points run down | 0.0 | 137.3 |
| Combat | Net points per charged fight, damage counted | -65 | +138 |
| Combat | Net per 100 charger points, damage counted | -20.5 | +43.6 |
| Combat | First round won (charged fights) | 67% | 91% |
| Combat | Net points per charged fight | -53 | +132 |
| Combat | Net points per supported fight / lone fight | - / -53 | +0 / +145 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 9 | 2 of 11 |
| Game | Points lost | 890.0 | 274.0 |
| Game | VP from objectives | 410.0 | 903.3 |
| Game | Lone holders (player turns) | 4.5 | 2.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1149 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1164
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: chf-efd8067-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 1.0 | +52.8 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | +307.7 | 0.0 | 601.0 | 22.3 | +142.8 | 0.0 | 114.0 |
| BACKS UP THE FIGHT | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 1.0 | +3.5 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 2.3 | +44.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 1.3 | -4.1 | 178.7 | 0.0 |
| CAST JOB | 1.0 | +8.2 | 0.0 | 0.0 | 2.3 | +11.1 | 20.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +103.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +69.0 | 0.0 | 235.7 | - | - | - | - |
| CHALLENGE IN THE FIGHT | - | - | - | - | 1.3 | -112.7 | 151.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.1 | 20.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.7 | -12.7 | 20.0 | 0.0 | 1.0 | -17.1 | 185.0 | 0.0 |
| CHARGE LOSSES | 15.3 | -629.7 | 0.0 | 439.7 | 9.7 | -444.9 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 20.0 | 186.3 | 4.3 | +0.0 | 267.0 | 0.0 |
| CLEAR LANE AHEAD | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 47.0 | 19.0 | +0.0 | 0.0 | 56.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 15.7 | -581.3 | 0.0 | 119.3 | 8.3 | -613.8 | 0.0 | 20.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -7.6 | 55.3 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -35.2 | 0.0 | 0.0 | 6.7 | +23.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -83.7 | 0.0 | 0.0 | 1.3 | -110.6 | 151.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +36.5 | 20.0 | 0.0 | 0.3 | +45.4 | 144.0 | 0.0 |
| EXACT ROUND | 1.3 | +12.2 | 30.0 | 46.7 | 5.3 | +18.6 | 562.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 42.0 | 321.3 | 6.3 | +15.5 | 447.0 | 16.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 0.7 | +9.8 | 0.0 | 0.0 | 21.3 | +313.4 | 0.0 | 84.0 |
| FEATURE BUFFS | 3.3 | +86.9 | 0.0 | 27.7 | 1.3 | +29.9 | 0.0 | 22.0 |
| FIGHT TO THE END | 0.3 | +57.0 | 0.0 | 0.0 | 1.0 | +5.1 | 27.7 | 0.0 |
| FIVE ACTION | 82.0 | +4988.6 | 130.3 | 1606.7 | 95.7 | +6773.6 | 1147.7 | 452.0 |
| FLANK NOT WEIGHED | 13.0 | +0.0 | 0.0 | 414.0 | 5.0 | +0.0 | 0.0 | 22.0 |
| FOLLOW UP WEIGHED | 1.0 | +104.3 | 0.0 | 164.0 | 0.7 | +22.1 | 0.0 | 15.0 |
| FOUR ROUNDS | 2.7 | +294.1 | 92.0 | 348.0 | 7.7 | +326.8 | 741.0 | 16.7 |
| FREED FROM HIS FIGHT | 10.0 | +0.0 | 0.0 | 183.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -6.3 | 0.0 | 0.0 | 0.3 | -15.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.7 | -13.0 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -21.9 | 22.0 | 135.0 | 1.3 | -12.1 | 133.0 | 16.7 |
| GOAL WALK | 11.7 | +913.7 | 0.0 | 116.7 | 3.3 | +299.3 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | +0.3 | 0.0 | 0.0 | 2.7 | -3.0 | 240.3 | 16.7 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 30.0 | 26.7 | 1.0 | +0.0 | 61.7 | 16.7 |
| HELPER UNSEEN | 0.7 | +0.0 | 30.0 | 26.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.3 | +0.0 | 0.0 | 384.3 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 13.0 | +0.0 | 0.0 | 178.7 | 9.7 | +0.0 | 0.0 | 45.3 |
| HIS LEGAL MOVES | 9.7 | +0.0 | 0.0 | 166.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -13.4 | 0.0 | 0.0 | 9.0 | -139.2 | 0.0 | 30.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 53.3 | 3.0 | +0.0 | 0.0 | 33.3 |
| HIS OWN BEST MOVE | 14.3 | +0.0 | 0.0 | 166.3 | 11.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.7 | +238.8 | 0.0 | 781.0 | 42.0 | +1008.8 | 0.0 | 110.0 |
| HIS SHOTS BY HIS RUN | 22.3 | +96.7 | 0.0 | 653.0 | 37.7 | +437.8 | 0.0 | 114.0 |
| HIS TURN DENIED | 0.7 | +1.1 | 42.0 | 135.0 | 3.3 | +83.9 | 205.3 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 55.3 | 18.7 | +0.0 | 0.0 | 252.0 |
| HOLDER ASSIGNMENT | 8.7 | +677.3 | 0.0 | 27.7 | 11.7 | +805.4 | 0.0 | 166.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -98.0 | 92.0 | 328.0 | 6.7 | -276.5 | 694.0 | 0.0 |
| IDLE COST | 0.3 | -5.1 | 0.0 | 0.0 | 15.3 | -173.2 | 0.0 | 40.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | -69.8 | 0.0 | 0.0 | 2.0 | +33.0 | 181.7 | 16.7 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +38.1 | 58.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.3 | 0.0 | 0.0 | 1.0 | +42.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 50.0 | 423.3 | 10.3 | +0.0 | 356.7 | 338.3 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.4 | 0.0 | 0.0 | 4.3 | +5.1 | 268.0 | 16.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +8.1 | 0.0 | 0.0 | 3.3 | +39.7 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +15.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +21.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +40.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +48.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +23.8 | 0.0 | 0.0 | 7.0 | +144.3 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +240.1 | 0.0 | 0.0 | 4.3 | +151.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +45.2 | 0.0 | 0.0 | 4.0 | +23.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +41.5 | 0.0 | 0.0 | 4.3 | +28.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 58.3 | 171.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +492.4 | 0.0 | 183.3 | 10.7 | +737.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.3 | +436.5 | 0.0 | 55.3 | 8.7 | +328.1 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 5.0 | +285.4 | 0.0 | 183.3 | 8.0 | +635.9 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.7 | +24.9 | 42.0 | 421.3 | 3.3 | +89.9 | 474.7 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -82.3 | 35.0 | 213.0 | 7.0 | -211.3 | 679.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -258.4 | 0.0 | 53.3 | 2.7 | -41.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 144.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -130.5 | 0.0 | 91.7 | 6.7 | -141.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +13.6 | 15.0 | 26.7 | 1.3 | -4.4 | 123.3 | 16.7 |
| ONE OBJECTIVE FORMULA | 5.0 | +16.9 | 0.0 | 27.7 | 5.3 | -93.5 | 0.0 | 102.0 |
| ONE PROMISE A TARGET | 1.0 | -41.8 | 0.0 | 0.0 | 1.7 | -86.0 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.3 | +83.1 | 55.3 | 0.0 |
| OPENS UP IN FULL | 0.7 | +15.2 | 42.0 | 301.3 | 4.0 | +150.0 | 471.7 | 0.0 |
| OVERRUNS AWAY | 1.0 | +4.3 | 52.0 | 161.7 | 2.0 | +41.3 | 155.7 | 0.0 |
| PATHS CROSS | 0.3 | +7.2 | 0.0 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -14.2 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +197.7 | 80.0 | 1579.7 | 48.0 | +394.3 | 532.3 | 334.3 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +24.0 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 17.3 | -465.3 | 0.0 | 183.3 | 9.3 | -228.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | +0.0 | 0.0 | 183.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -3.1 | 0.0 | 0.0 | 1.0 | -1.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 58.3 | 20.0 |
| QUARTER ODDS | 21.0 | +1693.3 | 0.0 | 518.0 | 26.3 | +3394.6 | 329.0 | 204.0 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +38.6 | 0.0 | 26.7 | 4.7 | +413.9 | 0.0 | 22.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 3.0 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -63.0 | 0.0 | 0.0 | 2.3 | -40.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +22.9 | 0.0 | 26.7 | 0.3 | +6.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +41.8 | 92.0 | 348.0 | 5.0 | -165.8 | 388.7 | 16.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.3 | -79.3 | 431.3 | 16.7 |
| RUN DOWN | - | - | - | - | 6.0 | -68.5 | 506.0 | 16.7 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -8.2 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -47.5 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +17.0 | 0.0 | 0.0 | 0.7 | +5.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +66.7 | 0.0 | 0.0 | 0.7 | +84.7 | 27.7 | 0.0 |
| SELF MOVE SPELL | 2.0 | +114.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -40.8 | 0.0 | 53.3 | 2.3 | -32.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.0 | +69.5 | 0.0 | 53.3 | 5.3 | +46.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +8.1 | 0.0 | 0.0 | 3.3 | +39.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +7.2 | 23.3 | 0.0 | 0.7 | +4.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 11.0 | -81.9 | 0.0 | 136.3 | 28.7 | -110.3 | 0.0 | 132.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +373.8 | 0.0 | 117.0 | 8.0 | +39.2 | 0.0 | 84.0 |
| SPELL WORTH | 1.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.7 | 0.0 | 0.0 | 0.3 | +2.9 | 144.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 453.0 | 8.3 | +0.0 | 0.0 | 51.7 |
| STAND AND SHOOT | 0.3 | -0.2 | 22.0 | 135.0 | 3.0 | -50.0 | 298.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.0 | +0.0 | 38.3 | 211.0 | 22.7 | +0.0 | 406.7 | 73.3 |
| STAY WORTH | 8.3 | +73.5 | 0.0 | 0.0 | 8.0 | +22.0 | 290.0 | 42.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +5.8 | 26.7 | 15.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -9.2 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.0 | +144.8 | 0.0 | 0.0 | 5.3 | +266.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 15.0 | 26.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 5.0 | +144.8 | 0.0 | 0.0 | 5.3 | +266.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +3.7 | 0.0 | 0.0 | 1.0 | +11.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 26.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | -1.1 | 35.0 | 26.7 | 4.0 | +48.3 | 458.7 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 144.0 | 3.3 | +0.0 | 23.3 | 106.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 61.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 522.7 | 47.7 | +0.0 | 0.0 | 217.7 |
| TIED UP BY THE SUM | 0.7 | +78.8 | 42.0 | 301.3 | 3.3 | +394.1 | 219.0 | 0.0 |
| TIME ON OUR SIDE | 34.3 | +491.5 | 0.0 | 494.0 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -7.1 | 30.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -2.8 | 15.0 | 46.7 | 1.0 | +4.6 | 61.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +42.6 | 0.0 | 15.0 |
| WHOLE FIGHT | 0.3 | -2.1 | 15.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 6.0 | -546.7 | 0.0 | 384.3 | 2.0 | -202.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +69.8 | 0.0 | 0.0 | 1.3 | +131.6 | 123.3 | 16.7 |
| WHOLE FIGHT REACTION | 3.7 | +126.1 | 0.0 | 307.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.0 | +38.5 | 0.0 | 0.0 | 3.3 | +65.2 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 130 | 130 | 86 | 28.67 | +1486 | +17.3 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +3322 | +58.3 |
| HIS SHOT LIST | 224 | 213 | 42 | 14.00 | +237 | +5.7 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 80 | 80 | 35 | 11.67 | -2081 | -59.4 |
| FIVE ACTION | 533 | 501 | 31 | 10.33 | +1353 | +43.6 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -899 | -36.0 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 180 | 171 | 20 | 6.67 | +91 | +4.6 |
| MOVE TO CHARGE COMPUTED | 62 | 48 | 19 | 6.33 | +346 | +18.2 |
| DEPLOY BY FIGURES | 42 | 42 | 17 | 5.67 | +216 | +12.7 |
| QUARTER ODDS | 142 | 137 | 16 | 5.33 | +1302 | +81.4 |
| MEETS IN TIME | 25 | 25 | 15 | 5.00 | +893 | +59.5 |
| NEXT CHARGE BY LIST | 39 | 35 | 13 | 4.33 | +225 | +17.3 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 25 | 23 | 12 | 4.00 | +50 | +4.2 |
| SET UP BY THE SET | 28 | 26 | 11 | 3.67 | +41 | +3.7 |
| COVER ONCE | 72 | 45 | 10 | 3.33 | +153 | +15.3 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 31 | 27 | 9 | 3.00 | +330 | +36.7 |
| SHOT RISK POINTS | 119 | 115 | 9 | 3.00 | +36 | +4.0 |
| CHAFF IN THE MOVE | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 17 | 17 | 8 | 2.67 | -505 | -63.2 |
| GOAL WALK | 45 | 45 | 8 | 2.67 | +512 | +64.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 2.67 | -383 | -47.9 |
| IDLE COST | 47 | 40 | 7 | 2.33 | +29 | +4.2 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | -110 | -15.8 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +236 | +33.7 |
| SUPPORT ADDS | 31 | 28 | 7 | 2.33 | +223 | +31.9 |
| SUPPORT WORKED OUT | 31 | 28 | 7 | 2.33 | +223 | +31.9 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 6 | 2.00 | +4 | +0.7 |
| NO CHAFF EDGES | 15 | 14 | 6 | 2.00 | +110 | +18.4 |
| TIED UP BY THE SUM | 12 | 10 | 6 | 2.00 | +319 | +53.1 |
| WHOLE FIGHT DANGER | 24 | 24 | 6 | 2.00 | +221 | +36.8 |
| WOUNDS ON THE RANKS | 13 | 13 | 6 | 2.00 | +166 | +27.7 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +379 | +75.8 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +374 | +74.8 |
| NEARER NOT NEEDED | 60 | 58 | 5 | 1.67 | +170 | +33.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 75 | 72 | 4 | 1.33 | +217 | +54.3 |
| RISK BY ARC | 23 | 19 | 4 | 1.33 | +109 | +27.3 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +82 | +20.4 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| TIME ON OUR SIDE | 103 | 76 | 4 | 1.33 | +8 | +1.9 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 1.00 | +159 | +52.9 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +207 | +69.0 |
| FEATURE BUFFS | 14 | 14 | 3 | 1.00 | +22 | +7.3 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT COUNTER | 18 | 16 | 3 | 1.00 | +119 | +39.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +87 | +29.1 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +454 | +151.4 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 3 | 1.00 | +2 | +0.8 |
| SURE REACH TOGETHER | 5 | 5 | 3 | 1.00 | +4 | +1.2 |
| THE ROW IN ITS ORDER | 21 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -16 | -8.1 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +114 | +57.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +47 | +23.4 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +32 | +15.8 |
| OPENS UP | 4 | 3 | 2 | 0.67 | +87 | +43.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +16 | +7.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +258 | +128.9 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +50 | +25.0 |
| WHOLE FIGHT GAIN | 5 | 5 | 2 | 0.67 | +224 | +112.0 |
| CANNON PLANNED TARGET | 7 | 7 | 1 | 0.33 | -26 | -26.4 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.33 | -12 | -12.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -83 | -83.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 66 | 55 | 1 | 0.33 | +0 | +0.0 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +114 | +114.4 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +65 | +64.9 |
| MISSILES IN THE MOVE | 21 | 14 | 1 | 0.33 | +26 | +25.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 37 | 16 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP IN FULL | 14 | 12 | 1 | 0.33 | +12 | +12.1 |
| OVERRUNS AWAY | 9 | 8 | 1 | 0.33 | +1 | +1.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -43 | -42.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +72 | +71.9 |
| PROMISE READS THE TABLE | 5 | 5 | 1 | 0.33 | -5 | -4.8 |
| SHOTS IN THE MOVE | 69 | 44 | 1 | 0.33 | +12 | +12.3 |
| STAY WORTH | 49 | 37 | 1 | 0.33 | +0 | +0.1 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -3 | -2.8 |
| THE FIGHT MOVES | 16 | 14 | 1 | 0.33 | +99 | +98.7 |
| WHOLE FIGHT REACTION | 11 | 11 | 1 | 0.33 | +13 | +13.1 |
| BACKS UP THE FIGHT | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 90 | 85 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 5 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 20 | 18 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 20 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 47 | 40 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 10 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 33 | 31 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 5 | 5 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 68 | 65 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 46 | 40 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 31 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 76 | 63 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 12 | 9 | 0 | 0.00 | - | - |
| HOLD ODDS | 104 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 27 | 23 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 15 | 11 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 17 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 26 | 22 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 6 | 6 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 257 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 13 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 15 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 12 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 11 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 27 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 16 | 16 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 49 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 10 | 8 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 152 | 145 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 9.00 | 2.67 | 59.4 |
| JOB FIRST | gate | 4.00 | 2.00 | 33.9 |
| ARMY TABLE | rule | 1.33 | 2.67 | 38.3 |
| CHARGE NOW FIRST | rule | 0.67 | 2.00 | 63.2 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.67 | 54.8 |
| JOINT CHARGE NOW | rule | 0.33 | 1.33 | 83.7 |
| RULE SWITCHED OFF | gate | 1.33 | - | 55.6 |
| NO REASON | gate | - | 0.67 | 32.5 |
| AFTERMATH BAND | gate | 0.33 | - | 1.4 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 26.4 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 12.1 |
| CHAFF PASSED | rule | 0.33 | - | 16.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 83.1 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 8.5 |
| PATHS CROSS | rule | - | 0.33 | 6.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 42.7 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 4.8 |
| SET UP BY THE SET | rule | - | 0.33 | 12.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 2.8 |

### Plans: chf-efd8067-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 75% | 302 | 106 | 35% |
| Mine | move | 30.3 | 93% | 1615 | 0 | 0% |
| Mine | shoot | 4.7 | 36% | 279 | 92 | 33% |
| Opponent | charge | 6.3 | 47% | 810 | 360 | 44% |
| Opponent | join | 2.3 | 100% | 91 | 0 | 0% |
| Opponent | move | 35.3 | 96% | 1534 | 0 | 0% |
| Opponent | shoot | 2.3 | 29% | 273 | 35 | 13% |
| Opponent | support | 1.7 | 100% | 0 | 0 | - |

### Battle groups: chf-efd8067-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 14% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 28 (2) | 28 | 0 | 100 | 0% | 2.0 | 28 (2) | - | - | - | 28 (2) |
| Mine | Character | 8 | 9 (8) | 9 | 0 | 48 | 12% | 3.0 | 14 (5) | 0 (3) | - | 11 (7) | 0 (1) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 66 (4) | 27 | 39 | 46 | 0% | 3.2 | - | 66 (4) | - | 181 (1) | 34 (3) |
| Mine | Hammer | 4 | 0 (4) | 0 | 0 | 39 | 50% | 1.0 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Mine | Shooter | 6 | 18 (6) | 0 | 18 | 52 | 0% | 1.7 | 95 (1) | 0 (3) | 0 (2) | 29 (4) | 0 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 5.0 | - | - | - | - | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 12 (8) | 12 | 0 | 30 | 62% | 3.3 | 24 (4) | 0 (4) | - | 35 (3) | 0 (5) |
| Opponent | Character | 9 | 61 (9) | 61 | 0 | 4 | 33% | 3.8 | 22 (5) | 116 (3) | 0 (1) | 44 (5) | 101 (4) |
| Opponent | Clean-up | 2 | 20 (2) | 20 | 0 | 0 | 100% | - | 31 (1) | 0 (1) | - | 20 (2) | - |
| Opponent | Fast Hammer | 10 | 54 (10) | 40 | 14 | 18 | 20% | 3.0 | 26 (3) | 125 (4) | 19 (3) | 96 (6) | 18 (4) |
| Opponent | Hammer | 1 | 135 (1) | 135 | 0 | 0 | 0% | 2.0 | - | - | 135 (1) | - | 135 (1) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 31 | 0% | 2.0 | - | 225 (2) | 0 (1) | 141 (3) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 52 (5) | 52 | 0 | 30 | 20% | 1.8 | 16 (3) | 0 (1) | 278 (1) | 20 (2) | 106 (3) |

### Charged fights: chf-efd8067-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 250 | 4.0 | 1.0 | 62 | 15 | +48 | 2 of 4 | 2 of 4 | - | +48 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| Mine | Lizardmen | 1 | 0 | 196 | 3.0 | 1.0 | 65 | 301 | -236 | 0 of 3 | 2 of 3 | - | -236 |
| **Mine** | all armies | 3 | 0 | 164 | 3.0 | 1.0 | 55 | 107 | -53 | 2 of 9 | 6 of 9 | - | -53 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 759 | 5.0 | 1.0 | 152 | 0 | +152 | 0 of 5 | 5 of 5 | - | +152 |
| Opponent | Vampire Counts | 2 | 40 | 394 | 3.0 | 1.2 | 131 | 16 | +115 | 2 of 6 | 5 of 6 | +0 | +138 |
| **Opponent** | all armies | 3 | 27 | 515 | 3.7 | 1.1 | 141 | 9 | +132 | 2 of 11 | 10 of 11 | +0 | +145 |

### Effective charges: chf-efd8067-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 1 (net -60) | 1 (net +250) | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 2 (net +22) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 2 (net -104) | 0 | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +185) | 0 | 2 (net +200) | 2 | 0% (0 of 3) |
| Opponent | Vampire Counts | 6 | 1 (net +30) | 0 | 0 | 1 (net +0) | 0 | 3 (net +236) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: chf-efd8067-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 73 | 45 | -5 | 15 | 20 | -5 | -6.8 |
| Mine | 76-89% | 1 | 432 | 60 | +250 | 250 | 0 | +250 | +57.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 402 | 63 | -104 | 98 | 202 | -104 | -26.0 |
| Mine | No odds | 3 | 464 | 345 | -166 | 65 | 268 | -204 | -43.9 |
| Mine | All fights | 9 | 317 | 151 | -53 | 76 | 141 | -65 | -20.5 |
| Opponent | Long shot (under 50%) | 1 | 50 | 277 | +30 | 80 | 50 | +30 | +60.0 |
| Opponent | 76-89% | 2 | 190 | 130 | +92 | 98 | 5 | +94 | +49.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 343 | 211 | +221 | 236 | 0 | +236 | +68.8 |
| Opponent | No odds | 3 | 450 | 175 | +43 | 61 | 19 | +43 | +9.5 |
| Opponent | All fights | 11 | 318 | 193 | +132 | 149 | 11 | +138 | +43.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p9 | move | 26 | 7 (27%) | 6 (23%) | 4 (15%) | 15 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

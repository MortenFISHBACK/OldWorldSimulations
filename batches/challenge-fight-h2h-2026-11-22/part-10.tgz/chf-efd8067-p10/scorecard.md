# Doctrine scorecard: chf-efd8067-p10

### Scorecard: chf-efd8067-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 5 | 3 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 11 | 2 | 6 | 2 | 0 | 0 | 0 | 278 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 485 |
| L2025 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.5 | 3.0 | 3.3 | 0.3 | 0.7 | 0.0 | 0.0 | 246.7 |
| **Average** | | | Opponent | 67% | 7.0 | 2.3 | 4.7 | 1.7 | 0.3 | 0.0 | 0.0 | 92.7 |

### KPIs: chf-efd8067-p10

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 18) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (7 of 7); on the table 100% | 100% (11 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 17% (1 of 6); on the table 33% | 17% (1 of 6); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 62% (8 of 13); on the table 69% | 71% (12 of 17); on the table 76% |
| Magic missiles tried each own turn | 50%+ | 33% (10 of 30) | 50% (9 of 18) | 40% (19 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (10 of 22) | 53% (9 of 17) | 49% (19 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (3 of 5) | - | 60% (3 of 5) |
| Points that never fought | lower | 39% (2323 of 5999) | 46% (2742 of 5999) | 42% (5065 of 11998) |
|   infantry points that never fought | lower | 71% (701 of 993) | 56% (585 of 1037) | 63% (1286 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 56% (9 of 16) | 58% (22 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3071 of 5151) | 49% (2190 of 4500) | 55% (5261 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (20%) | 2.0 (67%) | 3.3 (34%) |
| MARCHED: its unit marched | 0.7 (10%) | 0.7 (22%) | 1.3 (14%) |
| IN COMBAT: engaged in combat | 1.7 (25%) | 0.3 (11%) | 2.0 (21%) |
| REAR RANK: in a rear rank | 1.7 (25%) | 0.0 (0%) | 1.7 (17%) |
| GONE: slain | 1.0 (15%) | 0.0 (0%) | 1.0 (10%) |
| NOT OFFERED: not in the cast list | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 0.7 | 1.3 | 6.3 | 1.7 |
| not cast | 6.3 | 1.3 | 4.7 | 9.7 | 18.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 3.3 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 2.0 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (32%) | 0.0 (0%) | 2.0 (43%) | 1.7 (17%) | 0.0 (0%) |
| GONE: slain | 0.7 (11%) | 0.0 (0%) | 0.3 (7%) | 1.0 (10%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (58%) | 0.0 (0%) | 2.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 100% (4 of 4) | 100% (4 of 4) |
| the unit moved after it | - | 50% (2 of 4) | 50% (2 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 50% (29 of 58) | 51% (42 of 82) | 51% (71 of 140) |
|   cavalry | - | 89% (16 of 18) | 89% (16 of 18) |
|   character | 100% (6 of 6) | 0% (0 of 24) | 20% (6 of 30) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 21% (7 of 34) | 65% (26 of 40) | 45% (33 of 74) |
|   monster | 88% (7 of 8) | - | 88% (7 of 8) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (14%) | 2.7 (20%) | 4.0 (17%) |
| CHARGED: it charged | 0.3 (3%) | 2.7 (20%) | 3.0 (13%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.0 (52%) | 4.3 (32%) | 9.3 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 2.3 (24%) | 2.0 (15%) | 4.3 (19%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (3%) | 0.7 (5%) | 1.0 (4%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.7 | 69% | 5.6 pts | 30 pts |
| character | 2.0 | 0.7 | 67% | 10.8 pts | 22 pts |
| chariot | 3.0 | 0.7 | 78% | 6.2 pts | 19 pts |
| infantry | 14.0 | 1.7 | 88% | 1.7 pts | 24 pts |
| monster | 2.3 | 1.0 | 71% | 12.6 pts | 29 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.7 | 5.5 |
| Charges that made contact a game | 4.0 | 4.0 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.43 contact (28 units) | 0.63 declared, 0.40 contact (30 units) | 0.55 declared, 0.41 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 0% (0 of 3) | - | 0% (0 of 3) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | 100% (1 of 1) | 100% (4 of 4) |
| Character on its own | 33% (1 of 3) | 33% (1 of 3) | 33% (2 of 6) | 33% (4 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 75% (3 of 4) | 67% (2 of 3) | - | 71% (5 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 52% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 67% (8 of 12) | 61% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 33% (2 of 6); on the table 33% | 17% (1 of 6) | 36% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 86% (6 of 7); on the table 100% | 67% (8 of 12) | 65% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 64% (7) | 100% (5) | 75% (12) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.67 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 42% (8 of 19) |
| Strategy | Shoot objectives carried out (shot that target) | 62% (13 of 21) | 20% (3 of 15) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.3 | 1.7 |
| Movement | Points that never moved of their own | 246.7 | 92.7 |
| Movement | Fights charged into per game | 4.0 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 4, net +98 | 3 of 11, net +48 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net -35 | 4 of 11, net +239 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 11 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | 4 of 11, net +148 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (9 of 29) | 26% (11 of 42) |
| Shooting | Points destroyed by shooting units | 0.0 | 29.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (3 of 8) | 0% (0 of 7) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.0 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.3 / 0.0 | 1.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 231.0 | 593.0 |
| Combat | Points run down | 0.0 | 124.7 |
| Combat | Net points per charged fight, damage counted | -1 | +154 |
| Combat | Net per 100 charger points, damage counted | -0.6 | +63.5 |
| Combat | First round won (charged fights) | 50% | 67% |
| Combat | Net points per charged fight | +10 | +156 |
| Combat | Net points per supported fight / lone fight | - / +10 | - / +156 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 12 | 6 of 12 |
| Game | Points lost | 837.7 | 231.0 |
| Game | VP from objectives | 506.7 | 810.0 |
| Game | Lone holders (player turns) | 2.5 | 7.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1077 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1069
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 1.0 | +166.8 | 0.0 | 0.0 |
| ARMY TABLE | 20.0 | +343.2 | 0.0 | 508.0 | 25.0 | +306.5 | 0.0 | 88.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 108.7 | - | - | - | - |
| BACKS UP THE FIGHT | 1.3 | +12.5 | 0.0 | 25.3 | 2.3 | +1829.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +6.1 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -214.5 | 131.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -21.3 | 0.0 | 65.0 |
| CAST JOB | 1.7 | +39.1 | 15.0 | 0.0 | 0.7 | +8.4 | 22.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +22.7 | 0.0 | 0.0 | 1.7 | +148.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +6.0 | 0.0 | 0.0 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -127.0 | 131.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.3 | -151.4 | 262.0 | 65.0 |
| CHARGE LOSSES | 13.0 | -734.4 | 0.0 | 546.7 | 15.0 | -302.6 | 0.0 | 20.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 22.0 | 0.0 | 4.0 | +0.0 | 367.0 | 130.0 |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 237.3 | 11.3 | +0.0 | 0.0 | 15.0 |
| COMBAT PIVOT | 1.3 | +0.0 | 65.0 | 0.0 | 0.3 | +0.0 | 87.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +62.7 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -395.2 | 0.0 | 100.3 | 5.7 | -329.7 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -8.7 | 240.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +18.1 | 0.0 | 0.0 | 8.3 | +77.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -137.3 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 1.0 | +27.1 | 85.0 | 130.0 |
| ELIXIR WORTH | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +13.6 | 130.0 | 11.7 | 6.0 | +43.5 | 580.3 | 217.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 131.0 | 0.7 | +0.0 | 0.0 | 65.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 22.0 | 0.0 | 4.7 | +4.8 | 484.0 | 130.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.7 | +27.6 | 0.0 | 55.0 | 16.0 | +131.1 | 0.0 | 37.0 |
| FEATURE BUFFS | 0.7 | +3.3 | 0.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.6 | 65.0 | 0.0 | 2.3 | +148.6 | 262.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 79.0 | +6587.0 | 427.0 | 1355.3 | 104.0 | +9341.2 | 1248.7 | 419.0 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 148.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.8 | 18.3 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +316.1 | 0.0 | 65.0 |
| FOUR ROUNDS | 1.7 | +103.0 | 152.0 | 11.7 | 6.7 | +523.7 | 711.3 | 217.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 487.3 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -13.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -25.7 | 131.0 | 0.0 |
| GOAL WALK | 8.7 | +800.7 | 0.0 | 85.0 | 8.0 | +991.1 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +144.4 | 0.0 | 61.7 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 65.0 | 0.0 | 1.3 | -1.2 | 244.0 | 65.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 487.3 | - | - | - | - |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 131.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 546.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 218.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -13.3 | 0.0 | 36.7 | 5.7 | -66.8 | 0.0 | 22.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 50.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 11.3 | 12.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.3 | +0.0 | 0.0 | 15.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.7 | +0.0 | 0.0 | 15.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.0 | +406.6 | 0.0 | 1091.0 | 55.0 | +1037.0 | 0.0 | 147.0 |
| HIS SHOTS BY HIS RUN | 35.0 | +195.5 | 0.0 | 1052.0 | 39.3 | +644.6 | 0.0 | 79.0 |
| HIS TURN DENIED | 0.3 | +0.4 | 0.0 | 11.7 | 1.7 | +50.1 | 471.3 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 36.7 | 17.0 | +0.0 | 0.0 | 20.0 |
| HOLDER ASSIGNMENT | 7.3 | +553.6 | 0.0 | 18.3 | 11.0 | +930.1 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -23.5 | 87.0 | 0.0 | 5.7 | -191.2 | 711.3 | 130.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +120.1 | 0.0 | 0.0 |
| IDLE COST | 2.3 | -71.0 | 0.0 | 0.0 | 12.3 | -178.9 | 0.0 | 15.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +52.2 | 200.7 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -15.7 | 131.0 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.5 | 0.0 | 0.0 | 1.3 | +61.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 109.0 | 429.0 | 7.0 | +0.0 | 236.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +26.4 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 65.0 | 0.0 | 2.7 | +2.2 | 305.7 | 65.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 100.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +2.9 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -18.8 | 0.0 | 126.0 | 0.3 | -5.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +22.7 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +163.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -19.1 | 0.0 | 0.0 | 1.3 | +26.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +216.5 | 0.0 | 11.7 | 3.7 | +108.5 | 0.0 | 15.0 |
| MEETS IN TIME | 4.3 | +196.4 | 0.0 | 0.0 | 3.3 | +171.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +89.3 | 0.0 | 0.0 | 2.3 | +13.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +60.4 | 0.0 | 0.0 | 4.3 | +17.6 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -8.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.3 | +440.8 | 0.0 | 60.0 | 10.3 | +2536.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.0 | +459.1 | 0.0 | 126.0 | 9.7 | +326.4 | 0.0 | 44.0 |
| NEXT CHARGE BY LIST | 5.3 | +311.2 | 0.0 | 48.7 | 8.0 | +1296.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 1.0 | +30.5 | 87.0 | 131.0 | 5.0 | +132.3 | 693.3 | 85.0 |
| NO DOUBLE ROUNDS | 0.7 | -7.0 | 22.0 | 11.7 | 5.7 | -254.8 | 567.7 | 195.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -422.8 | 0.0 | 0.0 | 6.0 | -90.8 | 78.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.3 | -60.3 | 0.0 | 11.7 | 7.3 | -131.6 | 0.0 | 15.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +16.2 | 131.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -48.8 | 0.0 | 0.0 | 3.7 | +56.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 2.7 | -39.3 | 0.0 | 25.3 | 1.3 | -559.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +100.3 | 0.0 | 65.0 |
| OPENS UP IN FULL | 0.7 | +11.0 | 87.0 | 0.0 | 3.0 | +178.2 | 425.3 | 130.0 |
| OVERRUNS AWAY | 0.7 | +6.2 | 87.0 | 0.0 | 2.7 | +66.8 | 320.7 | 130.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 38.0 | +246.4 | 390.0 | 1158.0 | 50.0 | +927.1 | 540.7 | 447.0 |
| PRIZE BY WORTH | - | - | - | - | 1.0 | +120.2 | 0.0 | 65.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 11.7 | 0.7 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -855.8 | 0.0 | 0.0 | 13.7 | -1773.4 | 0.0 | 22.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 4.0 | -2.1 | 0.0 | 50.7 | 3.0 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1529.5 | 65.0 | 346.7 | 29.3 | +3038.9 | 492.0 | 87.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +138.1 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +123.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.7 | +335.2 | 0.0 | 37.3 | 3.0 | +61.9 | 0.0 | 37.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +0.0 | 0.0 | 103.7 | 4.7 | +166.1 | 0.0 | 59.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.3 | +32.1 | 61.7 | 65.0 |
| REFORMS TO MEET IT | 1.7 | -66.9 | 0.0 | 34.7 | 2.3 | -72.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +70.9 | 0.0 | 22.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +121.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +25.0 | 87.0 | 11.7 | 5.7 | -137.6 | 613.7 | 217.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -136.9 | 521.7 | 195.0 |
| RUN DOWN | - | - | - | - | 5.0 | -38.5 | 580.3 | 195.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.0 | +6.7 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -32.5 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +11.5 | 0.0 | 0.0 | 0.7 | +1.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +38.8 | 22.0 | 0.0 | 0.3 | +50.5 | 78.0 | 0.0 |
| SELF MOVE SPELL | 1.7 | -3.1 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -85.6 | 0.0 | 15.0 |
| SET UP BY THE SET | - | - | - | - | 2.7 | +67.7 | 0.0 | 15.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +3.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +54.5 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 1.0 | +116.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 78.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +55.7 | 0.0 | 0.0 | 1.7 | +21.5 | 131.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -17.0 | 242.7 | 22.0 |
| SHOT RISK POINTS | 13.3 | -71.1 | 0.0 | 485.7 | 25.3 | +214.7 | 0.0 | 57.0 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.3 | +351.2 | 0.0 | 265.7 | 12.3 | +80.4 | 0.0 | 86.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +54.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -6.4 | 0.0 | 11.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 127.3 | 8.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -5.0 | 278.7 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 131.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 36.7 | +0.0 | 275.0 | 356.0 | 40.7 | +0.0 | 537.3 | 123.0 |
| STAY WORTH | 8.0 | +119.1 | 15.0 | 0.0 | 13.7 | +33.8 | 406.3 | 62.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | -158.7 | 131.0 | 65.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.7 | +1175.5 | 0.0 | 317.0 | 4.3 | +208.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 8.7 | +1175.5 | 0.0 | 317.0 | 4.3 | +208.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +5.5 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.8 | 0.0 | 18.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 18.3 | 1.7 | +0.0 | 0.0 | 20.0 |
| THE FIGHT MOVES | - | - | - | - | 1.7 | +167.4 | 216.0 | 130.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 36.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 36.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.0 | +0.0 | 0.0 | 407.3 | 49.7 | +0.0 | 0.0 | 101.0 |
| TIED UP BY THE SUM | 0.3 | +29.6 | 22.0 | 0.0 | 2.0 | +229.2 | 151.0 | 65.0 |
| TIME ON OUR SIDE | 33.3 | +371.4 | 0.0 | 622.3 | 21.7 | +150.1 | 36.7 | 108.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 20.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 2.0 | -30.3 | 260.0 | 0.0 | 0.7 | +20.3 | 262.0 | 0.0 |
| WHO FIGHTS | 0.3 | +1.5 | 0.0 | 11.7 | 1.7 | +17.1 | 100.3 | 130.0 |
| WHOLE FIGHT | 1.0 | +19.5 | 130.0 | 0.0 | 0.3 | +2.8 | 131.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -600.7 | 0.0 | 285.7 | 0.7 | -16.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.7 | +380.4 | 130.0 | 314.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +10.0 | 0.0 | 0.0 | 1.7 | +13.9 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 135 | 135 | 72 | 24.00 | +1825 | +25.3 |
| HOLDER ASSIGNMENT | 55 | 55 | 48 | 16.00 | +2300 | +47.9 |
| HIS SHOT LIST | 270 | 249 | 36 | 12.00 | +350 | +9.7 |
| FIVE ACTION | 549 | 522 | 34 | 11.33 | +1747 | +51.4 |
| LEGAL CHARGES ONLY | 32 | 32 | 32 | 10.67 | +0 | +0.0 |
| QUARTER ODDS | 142 | 136 | 32 | 10.67 | +2332 | +72.9 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1541 | -51.4 |
| HIS SHOTS BY HIS RUN | 223 | 209 | 29 | 9.67 | +245 | +8.4 |
| MOVE TO CHARGE COMPUTED | 56 | 45 | 28 | 9.33 | +1226 | +43.8 |
| PROMISE BY ITS OWN SUM | 69 | 69 | 27 | 9.00 | -7887 | -292.1 |
| REDIRECT FOR A FRIEND IN REACH | 27 | 27 | 26 | 8.67 | +4 | +0.1 |
| TIME ON OUR SIDE | 165 | 143 | 26 | 8.67 | +56 | +2.2 |
| DEPLOY BY FIGURES | 48 | 48 | 24 | 8.00 | +222 | +9.2 |
| THE TABLE AGAIN | 35 | 35 | 24 | 8.00 | +0 | +0.0 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 40 | 37 | 22 | 7.33 | +1086 | +49.4 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 12 | 12 | 12 | 4.00 | -1796 | -149.6 |
| SUPPORT ADDS | 39 | 39 | 12 | 4.00 | +849 | +70.7 |
| SUPPORT WORKED OUT | 39 | 39 | 12 | 4.00 | +849 | +70.7 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +668 | +60.8 |
| NO CHAFF EDGES | 18 | 16 | 10 | 3.33 | +249 | +24.9 |
| CHARGE LOSSES | 84 | 78 | 9 | 3.00 | +438 | +48.7 |
| GOAL WALK | 50 | 49 | 9 | 3.00 | +1258 | +139.8 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +948 | +118.5 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 8 | 2.67 | +23 | +2.9 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 25 | 22 | 7 | 2.33 | +401 | +57.2 |
| MAX FOR POSITIONING | 26 | 25 | 7 | 2.33 | +12 | +1.8 |
| SCOUTS HUNT GUNS ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOT RISK POINTS | 116 | 108 | 7 | 2.33 | +87 | +12.4 |
| REDIRECT COUNTER | 23 | 23 | 6 | 2.00 | +318 | +52.9 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +213 | +35.5 |
| BACKS UP THE FIGHT | 11 | 8 | 5 | 1.67 | +103 | +20.6 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +190 | +38.0 |
| PROMISE KNOWS THE FIGHT | 21 | 13 | 5 | 1.67 | -6 | -1.3 |
| SCOUT BY DROPS | 7 | 7 | 5 | 1.67 | +0 | +0.0 |
| SET UP BY THE SET | 8 | 8 | 5 | 1.67 | +178 | +35.6 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 4 | 1.33 | +7 | +1.7 |
| COVER ONCE | 41 | 24 | 4 | 1.33 | +40 | +10.0 |
| FIGHT TO THE END | 8 | 8 | 4 | 1.33 | +306 | +76.5 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +156 | +39.1 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +403 | +100.8 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +800 | +199.9 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +39 | +9.8 |
| SHOTS IN THE MOVE | 65 | 54 | 4 | 1.33 | +75 | +18.8 |
| SUPPORT NARROWED | 4 | 4 | 4 | 1.33 | -783 | -195.8 |
| TIED UP BY THE SUM | 7 | 4 | 4 | 1.33 | +168 | +42.1 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 1.00 | +500 | +166.8 |
| CHARGE NOW FIRST | 15 | 15 | 3 | 1.00 | -83 | -27.5 |
| EXACT ROUND | 22 | 20 | 3 | 1.00 | +3 | +1.0 |
| FACES WHAT IT FOLLOWS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 44 | 26 | 3 | 1.00 | +11 | +3.7 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -22 | -7.4 |
| NEARER NOT NEEDED | 62 | 48 | 3 | 1.00 | +99 | +32.9 |
| OVERRUNS AWAY | 10 | 7 | 3 | 1.00 | +11 | +3.8 |
| PRIZE BY WORTH | 3 | 3 | 3 | 1.00 | +361 | +120.2 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 3 | 1.00 | +414 | +138.1 |
| RISK BY ARC | 21 | 18 | 3 | 1.00 | +16 | +5.3 |
| STAY WORTH | 65 | 59 | 3 | 1.00 | +24 | +8.0 |
| CAST JOB | 7 | 7 | 2 | 0.67 | +57 | +28.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +18 | +9.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 2 | 2 | 2 | 0.67 | -28 | -13.9 |
| OPENS A LANE | 2 | 2 | 2 | 0.67 | +8 | +4.1 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 2 | 0.67 | +4 | +1.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +268 | +134.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +10 | +5.0 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +120 | +60.0 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +2 | +1.0 |
| THE FIGHT MOVES | 5 | 4 | 2 | 0.67 | +196 | +97.8 |
| WHAT THE JOINER ADDS | 8 | 8 | 2 | 0.67 | +29 | +14.3 |
| WHOLE FIGHT DANGER | 16 | 15 | 2 | 0.67 | +101 | +50.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -64 | -64.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -208 | -208.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +10 | +9.9 |
| FALLS SHORT | 59 | 45 | 1 | 0.33 | +17 | +16.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.3 |
| HIS MOVE AND SHOT | 27 | 27 | 1 | 0.33 | +40 | +39.9 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +133 | +132.6 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | -26 | -26.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +68 | +68.2 |
| MISSILES NEXT TURN | 28 | 12 | 1 | 0.33 | +2 | +2.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| NO DOUBLE ROUNDS | 19 | 16 | 1 | 0.33 | +44 | +43.9 |
| ONE FIGHT FORMULA | 38 | 25 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP IN FULL | 11 | 9 | 1 | 0.33 | +27 | +26.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -30 | -30.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +364 | +363.5 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +1 | +1.4 |
| WHOLE FIGHT REACTION | 8 | 8 | 1 | 0.33 | +19 | +18.9 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 14 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 46 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 59 | 55 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 25 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 5 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| HONEST WORTH | 19 | 16 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 12 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 33 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 12 | 12 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 232 | 220 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 254 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 14 | 13 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 5.00 | 292.1 |
| JOB FIRST | gate | 3.67 | 4.67 | 58.9 |
| ONE PROMISE A TARGET | rule | 2.67 | 1.33 | 149.6 |
| ARMY TABLE | rule | 0.67 | 2.00 | 52.0 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 1.5 |
| SUPPORT NARROWED | rule | 1.33 | - | 195.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 27.5 |
| FALLBACK | gate | 0.33 | 0.33 | 3.8 |
| MARCH OF THE TABLE | rule | - | 0.67 | 11.1 |
| NO REASON | gate | - | 0.67 | 29.2 |
| AFTERMATH BAND | gate | - | 0.33 | 1.7 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 64.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 208.0 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 2.5 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 1.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 24.0 |
| INFANTRY NOT BEHIND INFANTRY | rule | 0.33 | - | 26.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 42.9 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 27.9 |
| REFUSING RETIRES | rule | - | 0.33 | 30.0 |
| RESERVE FALL BACK | rule | - | 0.33 | 1.2 |

### Plans: chf-efd8067-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 70 | 87 | 124% |
| Mine | move | 31.7 | 93% | 1942 | 0 | 0% |
| Mine | shoot | 5.0 | 73% | 911 | 159 | 17% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 6.0 | 67% | 1158 | 685 | 59% |
| Opponent | join | 2.3 | 100% | 97 | 0 | 0% |
| Opponent | move | 37.7 | 97% | 2106 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 259 | 243 | 94% |
| Opponent | support | 0.3 | 100% | 69 | 0 | 0% |

### Battle groups: chf-efd8067-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 14% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 73 (1) | 73 | 0 | 0 | 0% | 5.0 | - | 73 (1) | - | - | 73 (1) |
| Mine | Chaff | 7 | 45 (7) | 0 | 45 | 76 | 29% | 3.0 | 66 (4) | 0 (3) | - | 58 (6) | 0 (1) |
| Mine | Character | 7 | 25 (7) | 25 | 0 | 25 | 14% | 3.0 | 28 (5) | 9 (1) | - | 26 (6) | - |
| Mine | Clean-up | 4 | 67 (4) | 35 | 32 | 13 | 0% | 5.0 | 66 (1) | 79 (2) | 0 (1) | 66 (1) | 68 (3) |
| Mine | Fast Hammer | 1 | 6 (1) | 6 | 0 | 115 | 0% | 3.0 | - | 6 (1) | - | - | 6 (1) |
| Mine | Hammer | 11 | 20 (11) | 2 | 18 | 58 | 18% | 1.7 | 45 (4) | 2 (6) | 0 (1) | 48 (4) | 2 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 5.7 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 59 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 8 | 69 (8) | 17 | 52 | 47 | 38% | 1.2 | 100 (3) | 52 (1) | 47 (4) | 100 (3) | 48 (5) |
| Opponent | Character | 8 | 72 (8) | 72 | 0 | 0 | 38% | 4.4 | 97 (6) | 0 (2) | - | 135 (3) | 53 (5) |
| Opponent | Clean-up | 4 | 39 (4) | 39 | 0 | 0 | 50% | 2.5 | 53 (3) | 0 (1) | - | 53 (3) | 0 (1) |
| Opponent | Fast Hammer | 7 | 34 (7) | 26 | 7 | 31 | 43% | 3.8 | 51 (3) | 18 (4) | - | 0 (2) | 48 (5) |
| Opponent | Holder | 4 | 159 (4) | 0 | 159 | 23 | 0% | 2.2 | 159 (4) | - | - | 350 (2) | 0 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 9 (3) | 9 | 0 | 0 | 0% | 1.3 | - | 12 (2) | 0 (1) | - | 9 (3) |

### Charged fights: chf-efd8067-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 195 | 3.0 | 1.0 | 65 | 0 | +65 | 1 of 3 | 1 of 3 | - | +65 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 327 | 7.0 | 1.0 | 47 | 53 | -6 | 3 of 7 | 4 of 7 | - | -6 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 18 | -18 | 0 of 2 | 1 of 2 | - | -18 |
| **Mine** | all armies | 3 | 0 | 174 | 4.0 | 1.0 | 44 | 34 | +10 | 4 of 12 | 6 of 12 | - | +10 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 877 | 4.5 | 1.0 | 195 | 14 | +181 | 4 of 9 | 6 of 9 | - | +181 |
| Opponent | Vampire Counts | 1 | 0 | 248 | 3.0 | 1.0 | 83 | 0 | +83 | 2 of 3 | 2 of 3 | - | +83 |
| **Opponent** | all armies | 3 | 30 | 667 | 4.0 | 1.0 | 167 | 10 | +156 | 6 of 12 | 8 of 12 | - | +156 |

### Effective charges: chf-efd8067-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 1 (net +195) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 1 (net +195) | 0 | 0 | 6 | 0% (0 of 1) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 1 (net -35) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net -33) | 0 | 3 (net +306) | 0 | 0 | 3 (net +197) | 1 | 38% (3 of 8) |
| Opponent | Vampire Counts | 3 | 1 (net +210) | 0 | 1 (net +38) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: chf-efd8067-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 38 | 171 | +98 | 98 | 88 | +10 | +26.7 |
| Mine | Effective (55-75%) | 1 | 35 | 211 | -35 | 70 | 35 | +35 | +101.0 |
| Mine | 76-89% | 1 | 350 | 195 | +195 | 195 | 0 | +195 | +55.7 |
| Mine | No odds | 8 | 180 | 172 | -30 | 17 | 50 | -33 | -18.1 |
| Mine | All fights | 12 | 159 | 177 | +10 | 50 | 51 | -1 | -0.6 |
| Opponent | Long shot (under 50%) | 3 | 172 | 199 | +48 | 89 | 54 | +36 | +20.8 |
| Opponent | Effective (55-75%) | 4 | 279 | 240 | +239 | 254 | 15 | +239 | +85.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 211 | 184 | +148 | 164 | 20 | +144 | +68.3 |
| Opponent | No odds | 1 | 431 | 185 | +185 | 205 | 0 | +205 | +47.6 |
| Opponent | All fights | 12 | 242 | 206 | +156 | 179 | 25 | +154 | +63.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p10 | move | 18 | 6 (33%) | 3 (17%) | 3 (17%) | 9 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

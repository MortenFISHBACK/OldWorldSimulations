# Doctrine scorecard: chf-efd8067-p5

### Scorecard: chf-efd8067-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 516 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 2 | 2 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 15 | 2 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 236 |
| L0823 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 4 | 2 | 0 | 0 | 66 |
| **Average** | | | Mine | 0% | 7.3 | 2.0 | 1.3 | 1.0 | 0.0 | 0.0 | 0.0 | 385.3 |
| **Average** | | | Opponent | 33% | 1.3 | 2.3 | 3.3 | 2.7 | 1.3 | 0.0 | 0.0 | 100.7 |

### KPIs: chf-efd8067-p5

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 65% (11 of 17) | 0% (0 of 15) | 34% (11 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 71% (5 of 7); on the table 71% | 80% (8 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 0% (0 of 12) | 33% (8 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (8 of 12) | 0% (0 of 8) | 40% (8 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 63% (3749 of 5998) | 57% (3406 of 6000) | 60% (7155 of 11998) |
|   infantry points that never fought | lower | 89% (638 of 715) | 62% (886 of 1418) | 71% (1524 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (18 of 30) | 55% (12 of 22) | 58% (30 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (3110 of 5389) | 39% (1984 of 5023) | 49% (5094 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (50%) | 2.7 (67%) | 3.3 (62%) |
| MARCHED: its unit marched | 0.3 (25%) | 0.0 (0%) | 0.3 (6%) |
| CHARGED: its unit charged | 0.3 (25%) | 0.0 (0%) | 0.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (33%) | 1.3 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.7 | 2.7 | 0.3 | 0.3 |
| not cast | 3.7 | 0.3 | 5.3 | 1.7 | 11.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 3.3 (62%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (20%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (36%) | 0.0 (0%) | 1.3 (25%) | 1.3 (80%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (74%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (65 of 81) | 61% (50 of 82) | 71% (115 of 163) |
|   cavalry | 75% (9 of 12) | 50% (3 of 6) | 67% (12 of 18) |
|   character | - | 44% (7 of 16) | 44% (7 of 16) |
|   chariot | 83% (5 of 6) | - | 83% (5 of 6) |
|   infantry | 94% (17 of 18) | 74% (40 of 54) | 79% (57 of 72) |
|   monster | - | 0% (0 of 6) | 0% (0 of 6) |
|   war machine | 76% (34 of 45) | - | 76% (34 of 45) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (25%) | 2.0 (19%) | 3.3 (21%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (28%) | 3.0 (19%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.7 (6%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.0 (19%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 4.3 (41%) | 4.3 (27%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (38%) | 0.7 (6%) | 2.7 (17%) |
| SHELTERED: the target was sheltered | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 2.3 | 80% | 7.1 pts | 60 pts |
| character | 2.3 | 1.0 | 57% | 23.3 pts | 54 pts |
| chariot | 1.7 | 0.3 | 80% | 6.5 pts | 11 pts |
| infantry | 27.3 | 10.3 | 74% | 8.2 pts | 224 pts |
| war machine | 11.3 | 11.7 | 59% | 31.0 pts | 351 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 6.3 | 4.0 |
| Charges that made contact a game | 1.0 | 2.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.66 declared, 0.28 contact (29 units) | 0.45 declared, 0.22 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | - | 50% (6 of 12) |
| Character in a unit | 100% (4 of 4) | - | 0% (0 of 1) | 80% (4 of 5) |
| Character on its own | 100% (5 of 5) | 100% (1 of 1) | 17% (1 of 6) | 58% (7 of 12) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 60% (6 of 10) | - | - | 60% (6 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (3 of 3); on the table 100% | 67% (8 of 12) | 63% | 60% (18 of 30) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 67% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 68% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 50% | 0% (0 of 6) | 35% | 70% (7 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 0% (0) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.00 | 1.00 |

### Quality by phase: chf-efd8067-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 33% (5 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (19 of 49) | 91% (10 of 11) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 75% (3 of 4) |
| Strategy | Lone characters that fought | 40% (4 of 10) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 1.0 | 2.7 |
| Movement | Points that never moved of their own | 385.3 | 100.7 |
| Movement | Fights charged into per game | 1.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 2, net +154 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 6, net +202 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 3 of 6, net +190 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 17.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (13 of 33) | 51% (26 of 51) |
| Shooting | Points destroyed by shooting units | 129.0 | 0.0 |
| Shooting | War machine shots | 11.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (18 of 34) | - |
| Shooting | Points destroyed by war machines | 129.7 | 0.0 |
| Magic | Magic missiles cast | 2.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (1 of 8) | - |
| Magic | Wounds caused by magic missiles | 3.0 | - |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 41.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.7 / 0.0 / 0.0 | 1.3 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 78.7 | 145.0 |
| Combat | Points run down | 24.0 | 88.7 |
| Combat | Net points per charged fight, damage counted | +33 | +144 |
| Combat | Net per 100 charger points, damage counted | +20.1 | +65.6 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +40 | +179 |
| Combat | Net points per supported fight / lone fight | - / +40 | - / +179 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 6 of 8 |
| Game | Points lost | 720.7 | 574.7 |
| Game | VP from objectives | 753.3 | 680.0 |
| Game | Lone holders (player turns) | 7.3 | 1.3 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -113 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1295
- Games not ended: 0; findings 5, warnings 0

### Opponent rules: chf-efd8067-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.3 | +294.8 | 0.0 | 325.7 | 20.0 | +642.6 | 0.0 | 322.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +29.6 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +1.4 | 0.0 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | -95.9 | 67.3 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 185.0 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 10.3 | +414.5 | 769.7 | 343.3 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -46.5 | 34.7 | 0.0 | 0.3 | -24.3 | 25.7 | 0.0 |
| CAST JOB | 1.7 | +62.6 | 48.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -4.3 | 0.0 | 0.0 | 0.7 | -6.2 | 45.0 | 22.0 |
| CHALLENGE BY POINTS | 1.0 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE IN THE FIGHT | - | - | - | - | 1.0 | -8.4 | 134.7 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 2.3 | +8.5 | 202.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +112.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -650.4 | 0.0 | 311.3 | 15.3 | -829.4 | 0.0 | 592.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 24.0 | 0.0 | 3.7 | +0.0 | 372.7 | 0.0 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.0 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 96.3 |
| COVER ONCE | 13.7 | -631.1 | 0.0 | 327.7 | 9.7 | -448.6 | 0.0 | 180.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -12.4 | 186.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | -94.6 | 0.0 | 0.0 | 7.3 | +17.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -4.8 | 134.7 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +36.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +2.6 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | -27.0 | 199.0 | 63.0 | 3.3 | +25.6 | 388.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +15.4 | 199.0 | 63.0 | 4.7 | +20.4 | 486.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 20.7 | +227.3 | 0.0 | 200.3 |
| FEATURE BUFFS | 0.7 | +12.3 | 0.0 | 0.0 | 1.0 | +20.4 | 0.0 | 22.0 |
| FIGHT TO THE END | 0.7 | +0.0 | 102.7 | 0.0 | 0.3 | -2.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 58.3 | 25.7 | - | - | - | - |
| FIVE ACTION | 98.3 | +7502.2 | 2464.3 | 1507.7 | 78.7 | +6743.2 | 574.7 | 1268.7 |
| FLANK NOT WEIGHED | 10.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 61.7 |
| FOLLOW UP WEIGHED | 0.7 | +127.5 | 0.0 | 0.0 | 1.0 | +74.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +72.8 | 199.0 | 63.0 | 5.3 | +340.2 | 574.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 134.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 3.0 | -29.4 | 0.0 | 176.7 | - | - | - | - |
| GIVES UP | 0.7 | -6.8 | 96.3 | 63.0 | 0.3 | -2.6 | 41.7 | 0.0 |
| GOAL WALK | 2.0 | +163.5 | 0.0 | 0.0 | 15.7 | +1341.2 | 0.0 | 416.0 |
| GROUND FLIERS | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +18.1 | 87.0 | 88.3 | - | - | - | - |
| GUN MASK | 2.7 | +23.0 | 0.0 | 176.7 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | -0.4 | 24.0 | 0.0 | 1.3 | -0.5 | 160.3 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 88.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 134.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 61.7 | 63.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 134.7 | 10.0 | +0.0 | 0.0 | 288.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 120.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 191.7 |
| HIS MOVE AND SHOT | 5.3 | -69.0 | 0.0 | 176.7 | 2.7 | -35.6 | 0.0 | 144.3 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 69.3 |
| HIS OWN BEST MOVE | 11.7 | +0.0 | 0.0 | 176.7 | 6.7 | +0.0 | 0.0 | 191.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.0 | +1057.1 | 0.0 | 311.3 | 50.7 | +2744.5 | 0.0 | 836.7 |
| HIS SHOTS BY HIS RUN | 39.7 | +860.8 | 0.0 | 437.3 | 48.7 | +1862.8 | 0.0 | 1066.7 |
| HIS TURN DENIED | 0.3 | +7.3 | 0.0 | 0.0 | 3.0 | +175.7 | 444.3 | 0.0 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 51.3 | 16.3 | +0.0 | 0.0 | 162.0 |
| HOLDER ASSIGNMENT | 14.3 | +1312.7 | 0.0 | 93.0 | 11.3 | +1064.5 | 0.0 | 70.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -20.6 | 199.0 | 63.0 | 4.0 | -202.4 | 507.3 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +51.1 | 0.0 | 126.7 |
| IDLE COST | - | - | - | - | 13.3 | -197.7 | 0.0 | 451.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -40.7 | 134.7 | 0.0 |
| KEEP FALLS | 0.3 | +19.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 24.0 |
| LANE BY FIGURES | 0.7 | +20.1 | 0.0 | 0.0 | 0.7 | +27.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 113.3 | 0.0 | 3.3 | +0.0 | 88.3 | 144.7 |
| LONE CHARACTER SAFE SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -2.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -0.3 | 164.3 | 63.0 | 1.3 | +0.7 | 160.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 2.3 | +75.0 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | -36.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +60.0 | 0.0 | 0.0 | 0.3 | +18.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -4.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +116.2 | 0.0 | 0.0 | 1.3 | +6.0 | 0.0 | 71.3 |
| MEETS IN TIME | 4.0 | +390.9 | 0.0 | 0.0 | 4.3 | +232.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +120.3 | 0.0 | 0.0 | 2.7 | +34.1 | 0.0 | 72.0 |
| MISSILES NEXT TURN | 3.0 | +75.3 | 0.0 | 0.0 | 2.7 | +23.6 | 0.0 | 72.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 36.0 |
| MOVE TO CHARGE COMPUTED | 9.3 | +593.1 | 0.0 | 176.7 | 5.0 | +564.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +301.3 | 0.0 | 25.7 | 9.3 | +437.1 | 0.0 | 58.0 |
| NEXT CHARGE BY LIST | 5.3 | +352.4 | 0.0 | 0.0 | 4.0 | +489.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.0 | +35.4 | 34.7 | 0.0 | 3.0 | +120.2 | 367.7 | 140.3 |
| NO DOUBLE ROUNDS | 1.7 | -32.7 | 199.0 | 63.0 | 4.7 | -237.2 | 574.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 24.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -177.5 | 0.0 | 67.3 | 3.3 | -114.5 | 67.3 | 22.0 |
| ONE FIGHT FORMULA | 5.3 | -100.1 | 0.0 | 0.0 | 4.0 | -99.0 | 0.0 | 58.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +68.0 | 67.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -53.5 | 0.0 | 93.0 | 4.3 | -40.9 | 0.0 | 46.0 |
| ONE PROMISE A TARGET | 1.0 | -61.5 | 0.0 | 0.0 | 0.7 | -39.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.6 | 69.3 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +25.4 | 51.3 | 0.0 |
| OPENS UP IN FULL | 0.3 | +1.1 | 34.7 | 0.0 | 2.7 | +122.9 | 356.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +51.5 | 176.3 | 0.0 |
| PATHS CROSS | 0.3 | +12.2 | 0.0 | 0.0 | 0.3 | +28.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -13.3 | 0.0 | 0.0 |
| PLAN RESULT | 47.0 | +1266.4 | 933.0 | 1019.0 | 37.3 | +454.8 | 276.7 | 638.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +17.5 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -124.9 | 0.0 | 0.0 | 6.7 | -174.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2.0 | -1.8 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -5.2 | 0.0 | 88.3 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.9 | 24.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 25.3 | +2902.2 | 302.7 | 320.7 | 18.0 | +2560.9 | 290.3 | 82.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +61.0 | 0.0 | 34.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 34.7 |
| REDIRECT WEIGHED | 0.7 | +0.5 | 0.0 | 0.0 | 0.7 | +34.0 | 63.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -8.6 | 0.0 | 176.7 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +77.9 | 199.0 | 63.0 | 3.7 | -218.8 | 440.0 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -32.2 | 311.0 | 0.0 |
| RUN DOWN | 1.3 | -5.3 | 137.3 | 0.0 | 4.0 | -76.4 | 444.7 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +13.5 | 0.0 | 22.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 22.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 2.0 | +98.6 | 0.0 | 88.3 | 0.3 | +2.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +7.7 | 67.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -54.8 | 0.0 | 0.0 | 0.7 | -25.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -3.7 | 61.7 | 63.0 | 1.3 | -1.3 | 0.0 | 24.0 |
| SET UP TOGETHER | 2.3 | +75.0 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.7 | +0.0 | 0.0 | 425.7 | 4.0 | +0.0 | 0.0 | 36.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +42.6 | 0.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -12.7 | 104.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 25.3 | -318.9 | 0.0 | 176.7 | 32.7 | +1202.8 | 0.0 | 711.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.3 | +1081.4 | 0.0 | 659.3 | 15.3 | +330.7 | 0.0 | 142.0 |
| SPELL WORTH | 1.7 | +7.3 | 0.0 | 0.0 | 2.7 | +44.2 | 36.0 | 156.0 |
| SPELLS IN THE FIGHT | 0.7 | -4.8 | 96.3 | 63.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 114.0 | 8.0 | +0.0 | 0.0 | 165.3 |
| STAND AND SHOOT | 1.0 | -13.0 | 102.7 | 0.0 | 1.3 | -14.6 | 227.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 56.0 | +0.0 | 2265.3 | 1216.7 | 17.0 | +0.0 | 0.0 | 72.0 |
| STAY WORTH | 35.3 | +77.7 | 1237.3 | 612.7 | 11.7 | +41.9 | 0.0 | 183.3 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +13.2 | 67.3 | 0.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -13.5 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +6.4 | 63.0 | 61.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +82.0 | 0.0 | 0.0 | 2.0 | +59.3 | 0.0 | 12.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +82.0 | 0.0 | 0.0 | 2.0 | +59.3 | 0.0 | 12.7 |
| SURE REACH TOGETHER | 1.7 | +39.3 | 0.0 | 0.0 | 0.7 | +6.9 | 0.0 | 99.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 24.0 |
| THE FIGHT MOVES | 1.3 | +8.7 | 164.3 | 63.0 | 2.0 | +45.7 | 202.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 61.7 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 58.3 |
| THE STEP BACK IS MADE | - | - | - | - | 0.7 | +0.0 | 0.0 | 58.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.7 | +0.0 | 0.0 | 710.7 | 35.3 | +0.0 | 0.0 | 634.3 |
| TIED UP BY THE SUM | 0.3 | +33.2 | 34.7 | 0.0 | 2.3 | +275.9 | 258.7 | 0.0 |
| TIME ON OUR SIDE | 36.7 | +464.5 | 0.0 | 214.7 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 24.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +14.7 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | +5.2 | 164.3 | 63.0 | 1.0 | -12.7 | 130.3 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -70.2 | 0.0 | 134.7 | 2.3 | -225.1 | 0.0 | 240.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +48.8 | 67.3 | 0.0 |
| WHOLE FIGHT REACTION | 5.3 | +190.7 | 0.0 | 456.3 | 1.3 | +85.2 | 0.0 | 137.3 |
| WOUNDS ON THE RANKS | 5.0 | +89.7 | 0.0 | 0.0 | 2.0 | +60.3 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 115 | 115 | 73 | 24.33 | +2192 | +30.0 |
| HIS SHOT LIST | 272 | 263 | 70 | 23.33 | +1223 | +17.5 |
| HOLDER ASSIGNMENT | 77 | 77 | 70 | 23.33 | +4797 | +68.5 |
| HIS SHOTS BY HIS RUN | 265 | 259 | 36 | 12.00 | +832 | +23.1 |
| DEPLOY BY FIGURES | 51 | 51 | 29 | 9.67 | +407 | +14.0 |
| FIVE ACTION | 531 | 516 | 29 | 9.67 | +2030 | +70.0 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -876 | -31.3 |
| MOVE TO CHARGE COMPUTED | 43 | 39 | 27 | 9.00 | +1225 | +45.4 |
| SHOT RISK POINTS | 174 | 168 | 27 | 9.00 | +1065 | +39.4 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 110 | 101 | 22 | 7.33 | +127 | +5.8 |
| NEXT CHARGE BY LIST | 28 | 27 | 21 | 7.00 | +1111 | +52.9 |
| QUARTER ODDS | 130 | 123 | 21 | 7.00 | +2854 | +135.9 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| GOAL WALK | 53 | 51 | 14 | 4.67 | +1180 | +84.3 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +516 | +39.7 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 13 | 4.33 | -898 | -69.1 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 21 | 18 | 11 | 3.67 | +385 | +35.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| COVER ONCE | 70 | 49 | 10 | 3.33 | +256 | +25.6 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 100 | 96 | 6 | 2.00 | +749 | +124.8 |
| MAX FOR POSITIONING | 14 | 11 | 6 | 2.00 | +70 | +11.6 |
| NO CHAFF EDGES | 12 | 10 | 6 | 2.00 | +228 | +38.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 141 | 128 | 6 | 2.00 | +100 | +16.6 |
| CAST JOB | 5 | 5 | 5 | 1.67 | +68 | +13.5 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +604 | +120.9 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +518 | +103.5 |
| MISSILES IN THE MOVE | 16 | 12 | 5 | 1.67 | +111 | +22.2 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -303 | -60.7 |
| SEARCH SPOT | 7 | 7 | 5 | 1.67 | +302 | +60.3 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 5 | 1.67 | +31 | +6.2 |
| TIED UP BY THE SUM | 8 | 7 | 5 | 1.67 | +303 | +60.6 |
| WHOLE FIGHT REACTION | 20 | 20 | 5 | 1.67 | +59 | +11.7 |
| CANNON PLANNED TARGET | 31 | 31 | 4 | 1.33 | +50 | +12.4 |
| CHARGE NOW FIRST | 12 | 12 | 4 | 1.33 | -186 | -46.4 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +142 | +35.4 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +592 | +148.1 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 7 | 7 | 4 | 1.33 | +45 | +11.2 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -32 | -10.6 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +87 | +29.1 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -122 | -40.7 |
| NEARER NOT NEEDED | 50 | 50 | 3 | 1.00 | +88 | +29.3 |
| ONE OBJECTIVE FORMULA | 32 | 26 | 3 | 1.00 | +60 | +20.0 |
| PROMISE KNOWS THE FIGHT | 8 | 7 | 3 | 1.00 | -5 | -1.8 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +138 | +46.0 |
| SHOTS IN THE MOVE | 113 | 82 | 3 | 1.00 | +99 | +32.9 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +40 | +13.3 |
| CARRIES OUT SET-UP | 2 | 2 | 2 | 0.67 | -212 | -106.1 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 7 | 6 | 2 | 0.67 | +40 | +20.0 |
| HIS TURN DENIED | 10 | 8 | 2 | 0.67 | +14 | +6.9 |
| IDLE COST | 40 | 19 | 2 | 0.67 | +1 | +0.3 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +237 | +118.3 |
| NO DOUBLE ROUNDS | 19 | 16 | 2 | 0.67 | +146 | +73.2 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +40 | +20.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +122 | +61.2 |
| REDIRECT COUNTER | 7 | 3 | 2 | 0.67 | +18 | +9.1 |
| RISK BY ARC | 16 | 13 | 2 | 0.67 | +45 | +22.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOTS AFTER THE MOVES | 26 | 26 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 15 | 13 | 2 | 0.67 | +47 | +23.7 |
| SUPPORT WORKED OUT | 15 | 13 | 2 | 0.67 | +47 | +23.7 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +40 | +20.0 |
| BACKS UP THE FIGHT | 2 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +337 | +336.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +102 | +102.2 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 15 | 14 | 1 | 0.33 | +10 | +10.1 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 19 | 16 | 1 | 0.33 | +12 | +11.7 |
| FRIEND SHOOTS FIRST | 9 | 8 | 1 | 0.33 | +24 | +24.0 |
| GUN MASK | 8 | 8 | 1 | 0.33 | +3 | +3.2 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 17 | 14 | 1 | 0.33 | +9 | +9.4 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +114 | +114.3 |
| MISSILES NEXT TURN | 17 | 14 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 28 | 13 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP IN FULL | 9 | 6 | 1 | 0.33 | +57 | +57.0 |
| OVERRUNS AWAY | 5 | 3 | 1 | 0.33 | +80 | +79.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -40 | -39.9 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +53 | +52.6 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +23 | +23.2 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +19 | +19.2 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -135 | -134.9 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CHALLENGE IN THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 43 | 40 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 62 | 51 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 15 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 6 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 12 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 52 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 114 | 112 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 9 | not checked | - | - | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 253 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 68 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 219 | 215 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE FIGHT MOVES | 10 | 9 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 2 | not checked | - | - | - | - |
| THE TABLE BINDS | 252 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 7 | 7 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 7 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 21 | 21 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 2.33 | 31.9 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.00 | 69.1 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 32.3 |
| ARMY TABLE | rule | 1.33 | 0.67 | 21.2 |
| ONE PROMISE A TARGET | rule | 1.00 | 0.67 | 60.7 |
| CHARGE NOW FIRST | rule | - | 1.33 | 46.4 |
| CHAFF PASSED | rule | 0.33 | 0.67 | 10.6 |
| NO REASON | gate | - | 1.00 | 23.6 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 1.8 |
| CARRIES OUT SET-UP | rule | 0.33 | 0.33 | 106.1 |
| JOINT CHARGE NOW | rule | - | 0.67 | 84.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 65.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 0.7 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 6.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 39.9 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 134.9 |
| TURN GATE | gate | 0.33 | - | 3.7 |

### Plans: chf-efd8067-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 73 | 83 | 115% |
| Mine | join | 3.7 | 100% | 42 | 0 | 0% |
| Mine | move | 27.7 | 96% | 1723 | 0 | 0% |
| Mine | shoot | 14.3 | 63% | 1193 | 1183 | 99% |
| Opponent | charge | 3.7 | 73% | 714 | 368 | 52% |
| Opponent | move | 30.7 | 89% | 2062 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 180 | 87 | 48% |

### Battle groups: chf-efd8067-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 7 (12) | 7 | 0 | 18 | 58% | 3.4 | 0 (5) | 14 (4) | 0 (1) | 11 (5) | 0 (5) |
| Mine | Clean-up | 1 | 273 (1) | 0 | 273 | 0 | 100% | - | - | 273 (1) | - | 273 (1) | - |
| Mine | Fast Hammer | 8 | 44 (8) | 24 | 19 | 53 | 25% | 2.2 | 113 (2) | 27 (6) | - | 92 (4) | 0 (4) |
| Mine | Hammer | 2 | 57 (2) | 0 | 57 | 42 | 50% | 1.0 | - | 0 (1) | 97 (1) | 97 (1) | 0 (1) |
| Mine | Shooter | 5 | 166 (5) | 39 | 127 | 33 | 0% | 1.0 | 166 (5) | - | - | 166 (5) | - |
| Mine | War machine | 10 | 41 (10) | 41 | 0 | 51 | 0% | 1.0 | 41 (10) | - | - | 98 (1) | 34 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 100 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (4) | - |
| Opponent | Character | 9 | 47 (9) | 47 | 0 | 9 | 44% | 1.8 | - | 39 (6) | 91 (2) | 75 (2) | 38 (6) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 28 | 100% | - | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Fast Hammer | 5 | 39 (5) | 39 | 0 | 75 | 20% | 3.0 | 156 (1) | 0 (1) | 0 (3) | 0 (3) | 80 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (3) | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 67% | 6.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Holder | 3 | 47 (3) | 0 | 47 | 0 | 0% | 2.0 | 0 (1) | 68 (2) | - | 75 (2) | 0 (1) |
| Opponent | Shooter | 7 | 90 (7) | 0 | 90 | 31 | 0% | 2.0 | 108 (2) | 105 (4) | 38 (1) | 80 (3) | 101 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |

### Charged fights: chf-efd8067-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 300 | 103 | 1.0 | 1.0 | 103 | 63 | +40 | 2 of 3 | 3 of 3 | - | +40 |
| Opponent | Lizardmen | 1 | 0 | 391 | 2.0 | 1.0 | 196 | 0 | +196 | 1 of 2 | 2 of 2 | - | +196 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 569 | 2.0 | 1.0 | 284 | 0 | +284 | 2 of 2 | 2 of 2 | - | +284 |
| Opponent | Wood Elf Realms | 1 | 0 | 471 | 4.0 | 1.0 | 118 | 0 | +118 | 3 of 4 | 4 of 4 | - | +118 |
| **Opponent** | all armies | 3 | 0 | 477 | 2.7 | 1.0 | 179 | 0 | +179 | 6 of 8 | 8 of 8 | - | +179 |

### Effective charges: chf-efd8067-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 0 | 2 (net +154) | 0 | 0 | 0 | 1 | 100% (2 of 2) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 0 | 1 (net +202) | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +284) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: chf-efd8067-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 150 | 154 | +154 | 154 | 10 | +144 | +96.0 |
| Mine | No odds | 1 | 189 | 185 | -189 | 0 | 189 | -189 | -100.0 |
| Mine | All fights | 3 | 163 | 164 | +40 | 103 | 70 | +33 | +20.1 |
| Opponent | Effective (55-75%) | 1 | 224 | 380 | +0 | 109 | 20 | +88 | +39.4 |
| Opponent | 76-89% | 1 | 104 | 238 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 212 | 181 | +190 | 194 | 16 | +178 | +84.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 399 | 125 | +202 | 266 | 342 | -76 | -19.0 |
| Opponent | No odds | 2 | 200 | 214 | +330 | 330 | 26 | +304 | +152.4 |
| Opponent | All fights | 8 | 220 | 214 | +179 | 202 | 58 | +144 | +65.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p5 | move | 19 | 4 (21%) | 3 (16%) | 4 (21%) | 11 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

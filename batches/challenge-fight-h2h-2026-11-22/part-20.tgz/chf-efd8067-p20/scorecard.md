# Doctrine scorecard: chf-efd8067-p20

### Scorecard: chf-efd8067-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 70 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 1 | 6 | 2 | 1 | 0 | 0 | 72 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 284 |
| **Average** | | | Mine | 0% | 8.5 | 2.3 | 4.0 | 1.3 | 0.0 | 0.0 | 0.0 | 23.3 |
| **Average** | | | Opponent | 50% | 0.0 | 2.3 | 3.0 | 1.3 | 0.3 | 0.0 | 0.0 | 118.7 |

### KPIs: chf-efd8067-p20

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | - | 83% (5 of 6); on the table 83% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 50% | 83% (10 of 12); on the table 83% | 75% (12 of 16); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | - | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (4 of 13) | - | 31% (4 of 13) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 33% (1964 of 6000) | 44% (2658 of 6000) | 39% (4622 of 12000) |
|   infantry points that never fought | lower | 0% (0 of 923) | 65% (752 of 1159) | 36% (752 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (13 of 26) | 79% (19 of 24) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 50% (1 of 2); 0.3 uses a game | 67% (2 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 3.0 uses a game | 0.0 uses a game | 43% (6 of 14); 1.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (2109 of 5860) | 67% (3413 of 5131) | 50% (5522 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (21%) | - | 1.0 (21%) |
| MARCHED: its unit marched | 1.3 (29%) | - | 1.3 (29%) |
| CHARGED: its unit charged | 0.7 (14%) | - | 0.7 (14%) |
| IN COMBAT: engaged in combat | 1.7 (36%) | - | 1.7 (36%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.3 | 3.3 | 1.3 | 3.0 |
| not cast | 3.7 | 7.7 | 4.7 | 4.7 | 25.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (26%) | 0.7 (14%) | 1.0 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.7 (36%) | 1.7 (36%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (18%) | 0.7 (9%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.3 (36%) | 1.3 (17%) | 1.3 (29%) | 0.0 (0%) | 3.0 (12%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (45%) | 3.3 (43%) | 0.0 (0%) | 0.0 (0%) | 3.3 (13%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (63%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 100% (10 of 10) | - | 100% (10 of 10) |
| the unit moved after it | 50% (5 of 10) | - | 50% (5 of 10) |
| it charged on its next turn | 0% (0 of 10) | - | 0% (0 of 10) |
| the enemy charged it first | 20% (2 of 10) | - | 20% (2 of 10) |
| it fought by the end of its next turn | 10% (1 of 10) | - | 10% (1 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 10) | - | 0% (0 of 10) |
| none of these (no charge, no fight, no charge escaped) | 80% (8 of 10) | - | 80% (8 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (42 of 79) | 56% (59 of 106) | 55% (101 of 185) |
|   cavalry | 54% (7 of 13) | 100% (18 of 18) | 81% (25 of 31) |
|   character | 21% (7 of 33) | 21% (4 of 19) | 21% (11 of 52) |
|   chariot | - | 71% (5 of 7) | 71% (5 of 7) |
|   infantry | 81% (17 of 21) | 45% (24 of 53) | 55% (41 of 74) |
|   monster | - | 89% (8 of 9) | 89% (8 of 9) |
|   war machine | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (27%) | 1.7 (11%) | 5.0 (18%) |
| CHARGED: it charged | 5.3 (43%) | 2.7 (17%) | 8.0 (29%) |
| IN COMBAT: it fought this turn or the last | 1.3 (11%) | 1.0 (6%) | 2.3 (8%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 1.3 (11%) | 6.3 (40%) | 7.7 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 1.0 (6%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (3%) | 2.3 (15%) | 2.7 (10%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.0 | 2.0 | 86% | 7.6 pts | 91 pts |
| character | 5.7 | 0.7 | 88% | 2.1 pts | 12 pts |
| chariot | 1.7 | 0.7 | 80% | 9.8 pts | 16 pts |
| infantry | 19.3 | 5.3 | 79% | 7.0 pts | 135 pts |
| monster | 3.0 | 1.0 | 67% | 10.5 pts | 31 pts |
| war machine | 3.7 | 0.7 | 82% | 8.7 pts | 32 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.7 | 5.3 | 6.0 |
| Charges that made contact a game | 4.3 | 3.7 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.00 declared, 1.33 contact (3 units) | - | 2.00 declared, 1.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.39 contact (23 units) | 0.48 declared, 0.33 contact (33 units) | 0.54 declared, 0.36 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (11 of 17) | - | - | 65% (11 of 17) |
| Character on its own | - | 80% (4 of 5) | 0% (0 of 8) | 31% (4 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 90% (9 of 10) | 0% (0 of 1) | - | 82% (9 of 11) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 50% (2 of 4); on the table 50% | 22% (4 of 18) | 33% | 50% (13 of 26) | 100% (1 of 1); 1.3 uses a game | 43% (6 of 14); 3.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | - | 60% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 71% (5 of 7); on the table 71% | - | 27% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 46% | 83% (10 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (5) | 86% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.67 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (12 of 18) | 67% (8 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (6 of 22) | 55% (12 of 22) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.3 | 1.3 |
| Movement | Points that never moved of their own | 23.3 | 118.7 |
| Movement | Fights charged into per game | 3.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 11 | 1 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 11, net -37 | 1 of 8, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 11, net +79 | 1 of 8, net +123 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 11 | 3 of 8, net +90 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 20.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (24 of 35) | 58% (36 of 62) |
| Shooting | Points destroyed by shooting units | 0.0 | 41.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 82% (9 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | - |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 137.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.0 / 1.7 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 135.3 | 200.7 |
| Combat | Points run down | 328.7 | 59.0 |
| Combat | Net points per charged fight, damage counted | +36 | +65 |
| Combat | Net per 100 charger points, damage counted | +8.2 | +24.4 |
| Combat | First round won (charged fights) | 91% | 70% |
| Combat | Net points per charged fight | +48 | +52 |
| Combat | Net points per supported fight / lone fight | +0 / +52 | +0 / +57 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 11 | 4 of 10 |
| Game | Points lost | 484.3 | 1027.0 |
| Game | VP from objectives | 823.3 | 650.0 |
| Game | Lone holders (player turns) | 8.5 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +687 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1511
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +13.4 | 0.0 | 0.0 | 0.3 | +8.8 | 0.0 | 22.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| ARMY TABLE | 23.0 | -73.6 | 0.0 | 468.7 | 26.7 | +354.9 | 0.0 | 996.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 1.3 | +0.1 | 0.0 | 139.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +12.5 | 0.0 | 22.7 |
| CHAFF PASSED | 1.0 | -3.9 | 0.0 | 54.0 | - | - | - | - |
| CHALLENGE BY POINTS | 2.3 | +133.8 | 0.0 | 252.0 | 0.3 | +16.7 | 0.0 | 41.7 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 1.0 | -3.1 | 154.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +20.6 | 52.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 21.0 | -972.6 | 0.0 | 531.3 | 20.0 | -800.7 | 0.0 | 701.3 |
| CHARGE NOW FIRST | 4.0 | +0.0 | 539.7 | 0.0 | 4.0 | +0.0 | 195.0 | 268.7 |
| CLEAR LANE AHEAD | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 59.0 | 19.0 | +0.0 | 0.0 | 299.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 23.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.7 | +169.6 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.0 | -491.4 | 0.0 | 41.0 | 4.3 | -402.4 | 0.0 | 78.0 |
| DENIED BY THE FIGHT | 1.3 | -5.8 | 178.3 | 0.0 | 1.0 | -3.0 | 54.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -63.7 | 0.0 | 0.0 | 8.3 | +31.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.0 | 41.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +10.0 | 41.7 | 0.0 | 0.7 | +29.9 | 54.0 | 0.0 |
| EVASIVE BY THE ODDS | 1.3 | +128.0 | 0.0 | 0.0 | 2.7 | +1156.5 | 159.0 | 0.0 |
| EXACT ROUND | 4.3 | +23.6 | 547.3 | 118.0 | 3.0 | +65.4 | 41.0 | 101.3 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 23.3 |
| FALL BACK GOOD ORDER | 3.7 | +45.5 | 423.7 | 59.0 | 3.0 | +6.9 | 59.0 | 0.0 |
| FALLS SHORT | 2.3 | +22.9 | 0.0 | 41.0 | 17.7 | +158.5 | 0.0 | 358.0 |
| FEATURE BUFFS | 0.3 | +1.5 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +23.0 | 41.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 41.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 85.0 | +6161.5 | 791.3 | 1372.0 | 91.3 | +5891.6 | 318.0 | 2295.3 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 98.0 | 10.3 | +0.0 | 0.0 | 233.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.7 | +127.8 | 0.0 | 23.3 |
| FOUR ROUNDS | 6.0 | +401.9 | 663.7 | 118.0 | 4.7 | +387.8 | 195.0 | 101.3 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 108.0 | 4.0 | +0.0 | 0.0 | 83.3 |
| FRIEND CHARGES FIRST | 0.3 | -15.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.7 | -33.3 | 0.0 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.4 | 0.0 | 0.0 | 0.7 | -20.0 | 0.0 | 0.0 |
| GOAL WALK | 9.0 | +563.2 | 0.0 | 100.7 | 9.3 | +639.5 | 0.0 | 614.7 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 41.0 | 123.3 |
| GUN MASK | 0.7 | +25.9 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.0 | -0.1 | 125.7 | 0.0 | 1.3 | -3.5 | 59.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 42.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 108.0 | 1.3 | +0.0 | 0.0 | 83.3 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 22.0 | 59.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 272.0 | 12.7 | +0.0 | 0.0 | 617.7 |
| HIS CHARGE DENIED | 0.3 | +11.2 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 100.7 | 4.7 | +0.0 | 0.0 | 174.7 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 136.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -47.6 | 0.0 | 129.7 | 7.0 | -60.6 | 0.0 | 34.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 54.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 136.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 51.7 | +1893.2 | 0.0 | 1095.0 | 46.3 | +1054.0 | 0.0 | 1063.0 |
| HIS SHOTS BY HIS RUN | 49.7 | +1201.3 | 0.0 | 940.3 | 46.7 | +770.4 | 0.0 | 1022.7 |
| HIS TURN DENIED | 3.0 | +48.6 | 364.3 | 118.0 | 1.0 | +11.9 | 54.0 | 0.0 |
| HOLD ODDS | 17.7 | +0.0 | 0.0 | 82.0 | 11.3 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 9.7 | +956.6 | 0.0 | 41.0 | 8.7 | +736.5 | 0.0 | 74.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -203.6 | 426.0 | 118.0 | 4.0 | -162.3 | 195.0 | 78.0 |
| IDLE COST | 1.3 | -32.7 | 0.0 | 0.0 | 13.3 | -159.5 | 0.0 | 318.7 |
| JOINT CHARGE NOW | 0.7 | -52.7 | 64.0 | 59.0 | 1.0 | +1.1 | 0.0 | 23.3 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +46.1 | 0.0 | 0.0 | 1.0 | +34.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 23.3 | 91.3 | 4.0 | +0.0 | 154.7 | 34.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -14.0 | 44.0 | 118.0 | 0.7 | +0.0 | 0.0 | 167.3 |
| LOST AFTER ESCAPE | 1.3 | +0.1 | 125.7 | 0.0 | 1.7 | +3.6 | 59.0 | 23.3 |
| MAKE SURE TOGETHER | 2.3 | +25.2 | 0.0 | 41.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +4.2 | 0.0 | 0.0 | 1.7 | +1.1 | 0.0 | 75.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 115.7 |
| MARCH BY THE SUM | 0.7 | +17.1 | 0.0 | 0.0 | 0.3 | +3.6 | 0.0 | 115.7 |
| MARCH CHECK | - | - | - | - | 0.3 | +10.2 | 0.0 | 115.7 |
| MARCH OF THE TABLE | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +149.0 | 0.0 | 0.0 | 0.3 | -26.9 | 0.0 | 115.7 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +59.4 | 0.0 | 95.0 | 1.0 | +36.2 | 0.0 | 22.0 |
| MEETS IN TIME | 3.0 | +80.0 | 0.0 | 0.0 | 4.0 | +131.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +42.5 | 0.0 | 108.0 | 0.7 | +19.7 | 0.0 | 168.3 |
| MISSILES NEXT TURN | 5.3 | +29.7 | 0.0 | 108.0 | 1.0 | +17.5 | 0.0 | 284.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 61.7 | 115.7 |
| MOVE SPELL SPOT | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.7 | +913.8 | 0.0 | 0.0 | 6.7 | +815.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +238.6 | 0.0 | 41.0 | 9.3 | +289.8 | 0.0 | 90.7 |
| NEXT CHARGE BY LIST | 7.7 | +896.3 | 83.7 | 0.0 | 6.0 | +762.8 | 0.0 | 156.0 |
| NO CHAFF EDGES | 8.7 | +367.4 | 510.0 | 41.0 | 4.3 | +93.1 | 254.0 | 244.0 |
| NO DOUBLE ROUNDS | 6.0 | -188.4 | 663.7 | 118.0 | 4.7 | -366.4 | 195.0 | 101.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -37.8 | 0.0 | 0.0 | 4.7 | -291.9 | 0.0 | 61.7 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.3 | -172.2 | 0.0 | 41.0 | 3.7 | -68.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +5.0 | 22.0 | 59.0 | 1.0 | +7.9 | 0.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 6.0 | +79.1 | 0.0 | 41.0 | 4.7 | -286.5 | 0.0 | 74.7 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +15.2 | 38.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 3.7 | +217.4 | 472.0 | 0.0 | 3.0 | +85.5 | 195.0 | 78.0 |
| OVERRUNS AWAY | 2.7 | +50.9 | 304.0 | 118.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +921.0 | 223.3 | 880.0 | 44.3 | +463.5 | 82.0 | 1322.3 |
| PRIZE BY WORTH | 1.0 | +79.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -367.4 | 0.0 | 0.0 | 10.0 | -341.2 | 0.0 | 123.3 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.3 | -70.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -3.1 | 82.0 | 0.0 |
| QUARTER ODDS | 13.3 | +1581.0 | 178.0 | 231.0 | 16.0 | +1890.0 | 113.0 | 107.3 |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +310.6 | 0.0 | 55.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 22.0 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.0 | -10.0 | 0.0 | 0.0 | 2.0 | -46.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 41.7 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +9.5 | 0.0 | 0.0 |
| RISK BY ARC | 5.3 | -57.3 | 629.7 | 118.0 | 4.0 | -14.2 | 195.0 | 101.3 |
| ROUNDS AFTER TERROR | 1.0 | +7.4 | 90.7 | 0.0 | 1.7 | -33.8 | 41.0 | 0.0 |
| RUN DOWN | 4.3 | -23.1 | 529.7 | 0.0 | 4.0 | -14.1 | 154.0 | 23.3 |
| SAME CHARGE LATER | 1.3 | -33.9 | 83.7 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +0.3 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -43.4 | 0.0 | 11.3 |
| SEARCH SPOT | - | - | - | - | 0.7 | +13.9 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +128.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -25.6 | 0.0 | 0.0 | 0.7 | -43.2 | 0.0 | 22.0 |
| SET UP BY THE SET | 0.7 | +14.3 | 0.0 | 0.0 | 1.3 | +12.9 | 0.0 | 22.0 |
| SET UP TOGETHER | 2.3 | +25.2 | 0.0 | 41.0 | 1.7 | +26.8 | 0.0 | 22.0 |
| SET-UP ANY TARGET | 1.0 | +118.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 59.0 | 8.0 | +0.0 | 0.0 | 256.3 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +41.9 | 127.7 | 0.0 | 4.0 | +225.5 | 0.0 | 156.0 |
| SHOT OR CHARGE | 0.3 | -7.5 | 83.7 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 27.7 | -351.5 | 0.0 | 638.0 | 24.7 | -286.7 | 0.0 | 524.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +246.4 | 0.0 | 349.0 | 21.3 | +550.4 | 0.0 | 697.3 |
| SPELL SETS UP CHARGE | 1.3 | +199.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +44.7 | 0.0 | 0.0 | 0.3 | +3.6 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 1.3 | +20.2 | 203.7 | 0.0 | 0.7 | -29.0 | 0.0 | 23.3 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 41.0 | 7.7 | +0.0 | 0.0 | 266.3 |
| STAND AND SHOOT | 2.7 | -23.5 | 318.3 | 59.0 | 1.7 | -15.6 | 82.0 | 101.3 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 167.3 |
| STANDS STILL | 34.7 | +0.0 | 127.7 | 463.0 | 34.3 | +0.0 | 123.0 | 832.0 |
| STAY WORTH | 18.7 | +31.9 | 0.0 | 182.0 | 19.7 | +310.8 | 123.0 | 706.3 |
| SUPPORT ADDS | 0.7 | +57.4 | 0.0 | 54.0 | 3.0 | +268.6 | 0.0 | 152.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 41.0 | 234.0 |
| SUPPORT WORKED OUT | 0.7 | +57.4 | 0.0 | 54.0 | 3.0 | +268.6 | 0.0 | 152.0 |
| SURE REACH TOGETHER | 1.0 | +6.9 | 0.0 | 0.0 | 0.7 | +7.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 41.0 | 2.3 | +0.0 | 0.0 | 33.3 |
| THE FIGHT MOVES | 1.7 | +32.7 | 178.0 | 0.0 | 1.3 | +30.2 | 95.0 | 23.3 |
| THE PROMISE ADDS | 0.7 | -59.4 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 41.0 | 4.3 | +0.0 | 0.0 | 314.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 47.7 | 2.7 | +0.0 | 0.0 | 83.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 237.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 627.0 | 43.3 | +0.0 | 0.0 | 1091.3 |
| TIED UP BY THE SUM | 3.0 | +447.9 | 321.3 | 0.0 | 1.7 | +249.8 | 195.0 | 78.0 |
| TIME ON OUR SIDE | 40.0 | +498.6 | 0.0 | 710.0 | 14.0 | +134.1 | 0.0 | 714.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 22.0 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | -5.7 | 86.0 | 118.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +51.1 | 0.0 | 59.0 | 0.7 | +72.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -478.6 | 0.0 | 190.0 | 3.0 | -427.8 | 0.0 | 383.0 |
| WHOLE FIGHT GAIN | 0.3 | +26.1 | 22.0 | 59.0 | 0.7 | +41.5 | 0.0 | 23.3 |
| WHOLE FIGHT REACTION | 4.0 | +382.7 | 124.0 | 123.0 | 2.7 | +52.0 | 0.0 | 395.3 |

### Rule changes: chf-efd8067-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 149 | 149 | 105 | 35.00 | +1745 | +16.6 |
| HIS SHOT LIST | 294 | 284 | 83 | 27.67 | +1041 | +12.5 |
| HIS SHOTS BY HIS RUN | 289 | 278 | 73 | 24.33 | +714 | +9.8 |
| HOLDER ASSIGNMENT | 55 | 55 | 52 | 17.33 | +2938 | +56.5 |
| FIVE ACTION | 529 | 515 | 37 | 12.33 | +1887 | +51.0 |
| DEPLOY BY FIGURES | 49 | 49 | 28 | 9.33 | +268 | +9.6 |
| NEXT CHARGE BY LIST | 41 | 38 | 28 | 9.33 | +1567 | +56.0 |
| NO CHAFF EDGES | 39 | 39 | 28 | 9.33 | +666 | +23.8 |
| MOVE TO CHARGE COMPUTED | 46 | 41 | 26 | 8.67 | +1343 | +51.7 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| GOAL WALK | 55 | 55 | 22 | 7.33 | +904 | +41.1 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -989 | -45.0 |
| PROMISE BY ITS OWN SUM | 57 | 57 | 22 | 7.33 | -2126 | -96.6 |
| SHOT RISK POINTS | 157 | 151 | 18 | 6.00 | +372 | +20.6 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 88 | 86 | 16 | 5.33 | +1215 | +75.9 |
| TIME ON OUR SIDE | 162 | 140 | 16 | 5.33 | +55 | +3.4 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 15 | 5.00 | +85 | +5.6 |
| CHARGE NOW FIRST | 24 | 24 | 13 | 4.33 | -531 | -40.9 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 14 | 14 | 13 | 4.33 | +416 | +32.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 123 | 118 | 12 | 4.00 | +1088 | +90.6 |
| CLEAR LANE AHEAD | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 32 | 30 | 12 | 4.00 | +339 | +28.3 |
| MEETS IN TIME | 21 | 21 | 9 | 3.00 | +103 | +11.4 |
| CHALLENGE BY POINTS | 8 | 8 | 8 | 2.67 | +452 | +56.5 |
| EVASIVE BY THE ODDS | 12 | 12 | 8 | 2.67 | +2697 | +337.1 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +242 | +34.6 |
| OPENS UP IN FULL | 20 | 20 | 7 | 2.33 | +146 | +20.9 |
| STAY WORTH | 115 | 102 | 7 | 2.33 | +512 | +73.2 |
| SUPPORT ADDS | 11 | 11 | 7 | 2.33 | +286 | +40.8 |
| SUPPORT WORKED OUT | 11 | 11 | 7 | 2.33 | +286 | +40.8 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +383 | +76.7 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -155 | -31.0 |
| PROMISE READS THE TABLE | 7 | 7 | 5 | 1.67 | -170 | -34.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 109 | 83 | 5 | 1.67 | +205 | +41.0 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 1.33 | +0 | +0.1 |
| CANNON PLANNED TARGET | 11 | 11 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 44 | 27 | 4 | 1.33 | +8 | +2.0 |
| MAX FOR POSITIONING | 16 | 15 | 4 | 1.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 32 | 27 | 4 | 1.33 | +97 | +24.4 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +14 | +4.6 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -12 | -3.9 |
| COVER ONCE | 34 | 20 | 3 | 1.00 | +30 | +10.1 |
| FALL BACK GOOD ORDER | 20 | 18 | 3 | 1.00 | +21 | +7.2 |
| FALLS SHORT | 60 | 52 | 3 | 1.00 | +32 | +10.8 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +62 | +20.7 |
| PRIZE BY WORTH | 3 | 3 | 3 | 1.00 | +238 | +79.5 |
| RISK BY ARC | 28 | 26 | 3 | 1.00 | +104 | +34.7 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SET UP TOGETHER | 12 | 7 | 3 | 1.00 | +47 | +15.7 |
| SUPPORT NARROWED | 5 | 5 | 3 | 1.00 | -78 | -26.2 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +228 | +76.1 |
| WHOLE FIGHT DANGER | 22 | 22 | 3 | 1.00 | +204 | +67.9 |
| WHOLE FIGHT REACTION | 20 | 20 | 3 | 1.00 | +143 | +47.7 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +67 | +33.3 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +22 | +11.2 |
| EXACT ROUND | 22 | 20 | 2 | 0.67 | +45 | +22.4 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +4 | +2.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +21 | +10.6 |
| NEARER NOT NEEDED | 46 | 44 | 2 | 0.67 | +74 | +37.2 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -10 | -4.8 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +128 | +64.2 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -27 | -13.3 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +28 | +14.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +42 | +20.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +386 | +193.2 |
| SURE REACH TOGETHER | 5 | 4 | 2 | 0.67 | +3 | +1.3 |
| THE ROW IN ITS ORDER | 20 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +18 | +17.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.6 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +52 | +52.3 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 12 | 12 | 1 | 0.33 | +16 | +15.7 |
| HONEST WORTH | 26 | 24 | 1 | 0.33 | +1 | +1.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -81 | -81.1 |
| NO DOUBLE ROUNDS | 32 | 30 | 1 | 0.33 | +52 | +52.3 |
| ONE FIGHT FORMULA | 33 | 15 | 1 | 0.33 | +3 | +3.3 |
| OVERRUNS AWAY | 8 | 8 | 1 | 0.33 | +60 | +59.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -4.2 |
| SAME CHARGE LATER | 4 | 4 | 1 | 0.33 | +4 | +4.4 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +16 | +15.7 |
| BACKS UP THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 82 | 81 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 44 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 24 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 66 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 29 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 13 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 49 | 43 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 87 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 13 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 4 | 4 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 256 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 25 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 24 | 24 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 44 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 13 | 12 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 207 | 202 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE FIGHT MOVES | 9 | 8 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 243 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 4.00 | 96.6 |
| JOB FIRST | gate | 2.67 | 3.67 | 48.0 |
| CHARGE NOW FIRST | rule | 2.33 | 2.00 | 40.9 |
| ARMY TABLE | rule | 2.33 | 1.67 | 28.5 |
| CHAFF PASSED | rule | 1.00 | - | 3.9 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 89.8 |
| PROMISE READS THE TABLE | rule | 1.00 | - | 58.4 |
| SUPPORT NARROWED | rule | - | 1.00 | 26.2 |
| NO REASON | gate | - | 0.67 | 32.6 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 4.8 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 13.3 |
| FALLBACK | gate | - | 0.33 | 11.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 49.6 |
| MARCH OF THE TABLE | rule | 0.33 | - | 81.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 4.2 |

### Plans: chf-efd8067-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 80% | 1066 | 584 | 55% |
| Mine | move | 29.3 | 95% | 1512 | 0 | 0% |
| Mine | shoot | 6.7 | 55% | 340 | 336 | 99% |
| Opponent | charge | 4.0 | 42% | 695 | 315 | 45% |
| Opponent | move | 33.0 | 89% | 1677 | 0 | 0% |
| Opponent | shoot | 6.7 | 25% | 520 | 148 | 29% |
| Opponent | support | 0.7 | 50% | 4 | 0 | 0% |

### Battle groups: chf-efd8067-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 27% | 33% | 33% | 100% | 50% | 0% | 50% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 83 (7) | 83 | 0 | 0 | 14% | 1.7 | 25 (4) | 165 (2) | 98 (1) | 83 (7) | - |
| Mine | Clean-up | 1 | 65 (1) | 0 | 65 | 0 | 0% | 4.0 | 65 (1) | - | - | 65 (1) | - |
| Mine | Fast Hammer | 14 | 71 (14) | 14 | 57 | 48 | 36% | 2.4 | 35 (7) | 69 (5) | 199 (2) | 64 (9) | 84 (5) |
| Mine | Shooter | 4 | 10 (4) | 10 | 0 | 74 | 0% | 1.0 | 13 (3) | 0 (1) | - | 13 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 7 | 109 (7) | 0 | 109 | 56 | 0% | 2.7 | - | 190 (4) | 33 (3) | 168 (5) | 21 (2) |
| Opponent | Character | 4 | 68 (4) | 68 | 0 | 14 | 0% | 2.5 | 0 (1) | 41 (1) | 97 (2) | 89 (1) | 58 (3) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 80 | 25% | 4.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 42 | 0% | 2.5 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Hammer | 8 | 8 (8) | 8 | 0 | 95 | 25% | 1.8 | 0 (3) | 18 (4) | 0 (1) | 0 (4) | 16 (4) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 0 | 0% | 2.3 | 141 (3) | - | - | 450 (1) | 0 (2) |
| Opponent | Shooter | 4 | 44 (4) | 0 | 44 | 21 | 25% | 1.0 | 0 (1) | 211 (1) | 0 (2) | 59 (3) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 33% | 1.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: chf-efd8067-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 137 | 233 | 3.7 | 1.2 | 64 | 16 | +48 | 1 of 11 | 10 of 11 | +0 | +52 |
| Opponent | Ogre Kingdoms | 1 | 0 | 123 | 3.0 | 1.0 | 41 | 0 | +41 | 1 of 3 | 0 of 3 | - | +41 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 162 | 5.0 | 1.2 | 32 | 14 | +18 | 2 of 5 | 5 of 5 | +0 | +23 |
| Opponent | Wood Elf Realms | 1 | 123 | 300 | 2.0 | 1.0 | 150 | 0 | +150 | 1 of 2 | 2 of 2 | - | +150 |
| **Opponent** | all armies | 3 | 41 | 195 | 3.3 | 1.1 | 58 | 7 | +52 | 4 of 10 | 7 of 10 | +0 | +57 |

### Effective charges: chf-efd8067-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 11 | 0 | 0 | 3 (net -37) | 0 | 8 (net +79) | 0 | 0 | 27% (3 of 11) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 2 (net +46) | 0 | 0% (0 of 5) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +123) | 1 (net +177) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 166 | 128 | -37 | 29 | 83 | -54 | -32.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 543 | 98 | +79 | 83 | 13 | +70 | +12.9 |
| Mine | All fights | 11 | 440 | 106 | +48 | 68 | 32 | +36 | +8.2 |
| Opponent | Long shot (under 50%) | 1 | 70 | 400 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 90 | 177 | +0 | 133 | 0 | +133 | +147.5 |
| Opponent | 76-89% | 2 | 292 | 230 | +0 | 58 | 16 | +41 | +14.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 457 | 246 | +90 | 151 | 55 | +96 | +21.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 123 | +123 | 123 | 0 | +123 | +24.6 |
| Opponent | No odds | 2 | 34 | 133 | +62 | 62 | 48 | +14 | +41.2 |
| Opponent | All fights | 10 | 268 | 216 | +52 | 95 | 29 | +65 | +24.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p20 | move | 22 | 7 (32%) | 6 (27%) | 7 (32%) | 8 (36%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

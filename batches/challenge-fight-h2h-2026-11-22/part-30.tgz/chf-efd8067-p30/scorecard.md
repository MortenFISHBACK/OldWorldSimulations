# Doctrine scorecard: chf-efd8067-p30

### Scorecard: chf-efd8067-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 11 | 3 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 45 |
| L0930 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 10 | 3 | 0 | 0 | 1 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 6 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 3.3 | 3.0 | 0.0 | 1.0 | 0.3 | 0.0 | 0.0 | 210.0 |
| **Average** | | | Opponent | 0% | 6.7 | 2.5 | 1.3 | 2.7 | 0.3 | 0.0 | 0.0 | 143.3 |

### KPIs: chf-efd8067-p30

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 64% (9 of 14) | 0% (0 of 12) | 35% (9 of 26) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Magic missiles tried each own turn | 50%+ | 42% (20 of 48) | 33% (4 of 12) | 40% (24 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (20 of 41) | 44% (4 of 9) | 48% (24 of 50) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 86% (5158 of 5997) | 91% (5434 of 5999) | 88% (10592 of 11996) |
|   infantry points that never fought | lower | 82% (1298 of 1591) | 90% (1487 of 1660) | 86% (2785 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (22 of 34) | 65% (15 of 23) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 100% (2 of 2); 3.3 uses a game | 100% (4 of 4); 3.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3713 of 5667) | 67% (3456 of 5150) | 66% (7169 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (39%) | 1.7 (62%) | 5.3 (44%) |
| MARCHED: its unit marched | 3.0 (32%) | 0.0 (0%) | 3.0 (25%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| GONE: slain | 1.7 (18%) | 1.0 (38%) | 2.7 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 4.3 | 1.0 | 8.0 | 0.3 | 0.3 |
| not cast | 1.0 | 3.3 | 1.0 | 12.0 | 1.7 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (80%) | 0.0 (0%) | 5.3 (44%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (25%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (100%) | 0.3 (10%) | 1.0 (100%) | 2.7 (22%) | 0.3 (20%) | 3.0 (15%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 100% (3 of 3) | 100% (3 of 3) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (82 of 123) | 74% (40 of 54) | 69% (122 of 177) |
|   character | 100% (8 of 8) | 50% (6 of 12) | 70% (14 of 20) |
|   chariot | 72% (13 of 18) | 67% (4 of 6) | 71% (17 of 24) |
|   infantry | 53% (27 of 51) | 75% (18 of 24) | 60% (45 of 75) |
|   monster | 50% (2 of 4) | - | 50% (2 of 4) |
|   war machine | 76% (32 of 42) | 100% (12 of 12) | 81% (44 of 54) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (29%) | 1.3 (29%) | 5.3 (29%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (21%) | 1.0 (5%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.7 (12%) | 0.0 (0%) | 1.7 (9%) |
| NO TARGET IN RANGE | 3.3 (24%) | 1.7 (36%) | 5.0 (27%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (17%) | 0.7 (14%) | 3.0 (16%) |
| SHELTERED: the target was sheltered | 1.0 (7%) | 0.0 (0%) | 1.0 (5%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 6.0 | 0.7 | 89% | 1.6 pts | 9 pts |
| chariot | 5.7 | 2.0 | 82% | 14.9 pts | 85 pts |
| infantry | 19.0 | 12.3 | 63% | 10.6 pts | 201 pts |
| monster | 1.0 | 0.3 | 67% | 10.1 pts | 10 pts |
| war machine | 15.0 | 14.7 | 58% | 32.3 pts | 485 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 1.3 | 1.0 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.17 declared, 0.09 contact (23 units) | 0.09 declared, 0.05 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Character in a unit | 86% (6 of 7) | 100% (2 of 2) | 100% (1 of 1) | 90% (9 of 10) |
| Character on its own | - | 50% (2 of 4) | 33% (1 of 3) | 43% (3 of 7) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 29% (4 of 14) | 75% (3 of 4) | - | 39% (7 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 33% (8 of 24) | 88% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 50% (12 of 24) | 82% | 60% (6 of 10) | 100% (2 of 2); 10.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 88% | 50% (4 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 67% (4 of 6) | 93% | 78% (7 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 91% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 2) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (18 of 50) | 65% (15 of 23) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | - |
| Strategy | Joined characters whose unit fought | 12% (1 of 8) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 25% (1 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.7 |
| Movement | Points that never moved of their own | 210.0 | 143.3 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 1, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (27 of 50) | 61% (19 of 31) |
| Shooting | Points destroyed by shooting units | 83.0 | 41.7 |
| Shooting | War machine shots | 10.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (21 of 32) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 391.7 | 0.0 |
| Magic | Magic missiles cast | 4.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 54% (7 of 13) | 100% (3 of 3) |
| Magic | Wounds caused by magic missiles | 7.3 | 3.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 79.0 | 220.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.3 / 0.3 | 2.3 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 20.0 |
| Combat | Points run down | 0.0 | 90.7 |
| Combat | Net points per charged fight, damage counted | +0 | +81 |
| Combat | Net per 100 charger points, damage counted | +0.0 | +38.6 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +0 | +82 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +82 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 0 of 2 |
| Game | Points lost | 415.7 | 622.7 |
| Game | VP from objectives | 783.3 | 783.3 |
| Game | Lone holders (player turns) | 3.3 | 6.7 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +181 VP
- Points traded per game (both sides' losses): 1038
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.3 | +123.3 | 0.0 | 151.3 | 24.3 | +687.4 | 0.0 | 578.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +32.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 50.3 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 10.3 | +406.9 | 872.7 | 83.3 | 4.0 | +249.1 | 469.3 | 0.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 48.3 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +47.9 | 100.7 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 1.3 | +196.1 | 289.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| CHAFF PASSED | 2.0 | -2.7 | 0.0 | 41.7 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.0 | -632.4 | 0.0 | 510.0 | 32.3 | -1662.9 | 0.0 | 1813.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 48.3 | 0.0 | 0.7 | +0.0 | 110.3 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 151.3 | 10.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +177.1 | 266.7 | 266.7 |
| COVER ONCE | 10.0 | -735.1 | 0.0 | 125.3 | 4.7 | -110.8 | 0.0 | 65.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -10.2 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +4.6 | 0.0 | 41.7 | 7.0 | +32.4 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +3.9 | 0.0 | 108.0 |
| EXACT ROUND | 0.7 | +10.3 | 48.3 | 0.0 | 0.3 | +2.4 | 15.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +15.2 | 125.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 27.7 | +293.7 | 0.0 | 642.7 |
| FEATURE BUFFS | 2.7 | +9.1 | 0.0 | 0.0 | 2.0 | +33.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 102.0 | +9235.2 | 5084.7 | 828.0 | 98.7 | +6370.8 | 1368.3 | 2237.3 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 90.7 | 3.0 | +0.0 | 0.0 | 159.7 |
| FOUR ROUNDS | 0.7 | +23.4 | 48.3 | 0.0 | 1.0 | +85.9 | 125.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 151.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -16.8 | 0.0 | 0.0 | 0.7 | -9.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.3 | +363.8 | 0.0 | 151.3 | 14.7 | +2076.1 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +189.5 | 159.7 | 0.0 | 2.0 | +0.4 | 0.0 | 0.0 |
| GUN MASK | 3.3 | +428.2 | 0.0 | 0.0 | 1.3 | +61.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 151.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 510.0 | 13.7 | +0.0 | 0.0 | 680.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -57.9 | 0.0 | 0.0 | 9.0 | -207.6 | 0.0 | 837.3 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 289.3 | 6.7 | +0.0 | 0.0 | 162.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 65.3 |
| HIS RANDOM MOVE | 17.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +1093.9 | 0.0 | 661.3 | 80.3 | +6624.1 | 0.0 | 2081.0 |
| HIS SHOTS BY HIS RUN | 37.0 | +685.9 | 0.0 | 510.0 | 59.3 | +1738.8 | 0.0 | 1982.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +10.6 | 34.7 | 0.0 |
| HOLD ODDS | 24.0 | +0.0 | 0.0 | 0.0 | 26.7 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 13.3 | +1404.4 | 0.0 | 0.0 | 15.3 | +1460.1 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -29.6 | 48.3 | 0.0 | 1.0 | -34.8 | 125.3 | 0.0 |
| HUNT IN PAIRS | 1.3 | +431.0 | 0.0 | 144.7 | - | - | - | - |
| IDLE COST | - | - | - | - | 14.3 | -288.8 | 0.0 | 734.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.1 | 0.0 | 0.0 | 0.7 | +37.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 0.0 | 34.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | +0.1 | 34.7 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +17.4 | 0.0 | 0.0 | 1.0 | +27.6 | 0.0 | 0.0 |
| MANOEUVRE | 3.3 | +37.0 | 0.0 | 0.0 | 3.3 | +7.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +101.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 4.0 | +426.2 | 0.0 | 144.7 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | +94.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +217.7 | 0.0 | 144.7 | 1.3 | +46.1 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +429.5 | 0.0 | 0.0 | 2.7 | +345.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.7 | +306.2 | 0.0 | 144.7 | 3.3 | +217.6 | 0.0 | 108.0 |
| MISSILES NEXT TURN | 13.3 | +219.3 | 0.0 | 144.7 | 4.3 | +97.8 | 0.0 | 320.7 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.7 | -23.0 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 174.7 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 3.7 | +242.6 | 0.0 | 0.0 | 4.0 | +393.1 | 0.0 | 65.3 |
| NEARER NOT NEEDED | 11.7 | +564.7 | 0.0 | 34.7 | 9.3 | +398.9 | 0.0 | 32.7 |
| NEXT CHARGE BY LIST | 2.3 | +121.8 | 0.0 | 0.0 | 4.7 | +488.0 | 0.0 | 65.3 |
| NO CHAFF EDGES | - | - | - | - | 0.7 | +16.6 | 75.7 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -4.3 | 48.3 | 0.0 | 0.7 | -45.6 | 110.3 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -115.5 | 0.0 | 0.0 | 3.0 | -86.1 | 0.0 | 166.0 |
| OGRE LOADER SECOND SHOT | 2.3 | +65.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -56.1 | 0.0 | 0.0 | 4.7 | -128.1 | 0.0 | 83.0 |
| ONE OBJECTIVE FORMULA | 6.0 | +115.2 | 0.0 | 0.0 | 6.7 | +94.9 | 0.0 | 32.7 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +6.7 | 130.7 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +15.8 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.3 | +15.8 | 0.0 | 0.0 | 0.3 | +10.5 | 75.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +9.2 | 0.0 | 0.0 | 1.0 | +68.0 | 125.3 | 0.0 |
| OWN CAST FIRST | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -13.7 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +1438.2 | 1555.0 | 669.0 | 44.3 | +608.6 | 455.0 | 1167.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +70.2 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -301.2 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -5.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 18.3 | +1987.5 | 525.3 | 372.7 | 18.0 | +1313.5 | 569.3 | 439.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +160.3 | 0.0 | 193.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -4.9 | 0.0 | 0.0 | 0.7 | -36.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | -20.1 | 0.0 | 0.0 | 1.0 | -151.8 | 125.3 | 0.0 |
| RUN DOWN | 0.3 | -0.1 | 48.3 | 0.0 | 0.7 | -3.7 | 110.3 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +78.2 | 0.0 | 0.0 | 0.3 | +7.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -152.6 | 0.0 | 289.3 | 1.3 | -92.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +150.0 | 0.0 | 289.3 | 2.0 | +32.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +17.4 | 0.0 | 0.0 | 1.0 | +27.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 15.3 | +0.0 | 0.0 | 83.3 | 7.3 | +0.0 | 0.0 | 54.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +638.3 | 1334.3 | 0.0 | 1.7 | +27.1 | 83.3 | 108.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -8.8 | 15.0 | 0.0 |
| SHOT RISK POINTS | 15.3 | -212.2 | 0.0 | 510.0 | 44.0 | -61.6 | 0.0 | 1677.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 30.0 | +2095.4 | 0.0 | 269.3 | 14.0 | +788.1 | 0.0 | 401.0 |
| SPELL WORTH | - | - | - | - | 3.0 | +48.6 | 266.7 | 266.7 |
| SPELLS IN THE FIGHT | 0.3 | +4.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 144.7 | 11.0 | +0.0 | 0.0 | 262.7 |
| STAND AND SHOOT | 0.3 | -4.9 | 0.0 | 0.0 | 0.7 | -3.6 | 110.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 586.0 |
| STANDS STILL | 50.7 | +0.0 | 5036.3 | 166.7 | 37.3 | +0.0 | 1243.0 | 698.7 |
| STAY WORTH | 41.3 | +140.3 | 2112.7 | 235.3 | 20.3 | +572.6 | 772.0 | 320.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +2.8 | 20.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -0.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +188.9 | 0.0 | 0.0 | 4.0 | +133.1 | 0.0 | 32.7 |
| SUPPORT WORKED OUT | 2.3 | +188.9 | 0.0 | 0.0 | 4.0 | +133.1 | 0.0 | 32.7 |
| SURE REACH TOGETHER | 0.3 | +1.2 | 0.0 | 0.0 | 1.0 | +22.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.3 | +1.6 | 34.7 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 75.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 75.7 | 3.7 | +0.0 | 0.0 | 131.3 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 81.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 414.0 | 46.3 | +0.0 | 0.0 | 1022.0 |
| TIED UP BY THE SUM | 0.3 | +27.9 | 0.0 | 0.0 | 0.7 | +101.0 | 110.3 | 0.0 |
| TIME ON OUR SIDE | 38.3 | +558.7 | 0.0 | 186.0 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +22.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -34.8 | 0.0 | 0.0 | 3.3 | -245.6 | 0.0 | 295.3 |
| WHOLE FIGHT REACTION | 1.3 | +149.7 | 0.0 | 125.3 | 0.3 | +16.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +69.2 | 0.0 | 0.0 | 1.7 | +70.8 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 128 | 128 | 97 | 32.33 | +2270 | +23.4 |
| HIS SHOT LIST | 344 | 335 | 88 | 29.33 | +2478 | +28.2 |
| HOLDER ASSIGNMENT | 86 | 86 | 77 | 25.67 | +4772 | +62.0 |
| HIS SHOTS BY HIS RUN | 289 | 282 | 64 | 21.33 | +1193 | +18.6 |
| SHOT RISK POINTS | 178 | 173 | 31 | 10.33 | +990 | +31.9 |
| DEPLOY BY FIGURES | 46 | 46 | 29 | 9.67 | +567 | +19.6 |
| GOAL WALK | 66 | 66 | 24 | 8.00 | +1974 | +82.3 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -605 | -30.2 |
| TIME ON OUR SIDE | 115 | 99 | 17 | 5.67 | +45 | +2.6 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 16 | 5.33 | +856 | +53.5 |
| MOVE TO CHARGE COMPUTED | 23 | 22 | 13 | 4.33 | +651 | +50.1 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 13 | 4.33 | -904 | -69.5 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 148 | 145 | 12 | 4.00 | +940 | +78.3 |
| FIVE ACTION | 602 | 590 | 12 | 4.00 | +452 | +37.7 |
| QUARTER ODDS | 109 | 107 | 11 | 3.67 | +1047 | +95.2 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MARCH CHECK | 12 | 12 | 9 | 3.00 | +323 | +35.9 |
| NEXT CHARGE BY LIST | 21 | 21 | 9 | 3.00 | +425 | +47.2 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +481 | +53.4 |
| STAY WORTH | 185 | 164 | 9 | 3.00 | +115 | +12.7 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SUPPORT ADDS | 19 | 18 | 8 | 2.67 | +561 | +70.1 |
| SUPPORT WORKED OUT | 19 | 18 | 8 | 2.67 | +561 | +70.1 |
| IDLE COST | 43 | 39 | 7 | 2.33 | +53 | +7.5 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1246 | +177.9 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +196 | +27.9 |
| CHAFF PASSED | 6 | 6 | 6 | 2.00 | -8 | -1.3 |
| GUN MASK | 14 | 14 | 6 | 2.00 | +715 | +119.2 |
| SET UP BY THE SET | 14 | 14 | 6 | 2.00 | +398 | +66.2 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MANOEUVRE | 20 | 20 | 5 | 1.67 | +175 | +34.9 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +760 | +152.1 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +53 | +13.3 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +147 | +36.7 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 132 | 101 | 4 | 1.33 | +50 | +12.4 |
| THE ROW IN ITS ORDER | 26 | 4 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 4 | 1.33 | +68 | +16.9 |
| COVER ONCE | 44 | 33 | 3 | 1.00 | +174 | +58.1 |
| FOUR ROUNDS | 5 | 5 | 3 | 1.00 | +127 | +42.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +305 | +101.6 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -133 | -44.3 |
| NEARER NOT NEEDED | 63 | 59 | 3 | 1.00 | +69 | +23.1 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +772 | +257.4 |
| SURE REACH TOGETHER | 4 | 3 | 3 | 1.00 | +23 | +7.8 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +157 | +52.4 |
| CANNON PLANNED TARGET | 43 | 43 | 2 | 0.67 | +111 | +55.5 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +3 | +1.4 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -73 | -36.3 |
| FALLS SHORT | 83 | 69 | 2 | 0.67 | +50 | +24.8 |
| HUNT IN PAIRS | 4 | 4 | 2 | 0.67 | +497 | +248.3 |
| ONE OBJECTIVE FORMULA | 38 | 24 | 2 | 0.67 | +44 | +21.8 |
| PROMISE READS THE TABLE | 3 | 3 | 2 | 0.67 | +102 | +51.1 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +44 | +21.8 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +258 | +128.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| WHOLE FIGHT DANGER | 18 | 18 | 2 | 0.67 | +14 | +7.0 |
| WHOLE FIGHT REACTION | 5 | 5 | 2 | 0.67 | +61 | +30.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -5 | -4.7 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 45 | 32 | 1 | 0.33 | +1 | +0.9 |
| NO CHAFF EDGES | 2 | 2 | 1 | 0.33 | +18 | +18.3 |
| ONE FIGHT FORMULA | 24 | 15 | 1 | 0.33 | +1 | +0.9 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +33 | +33.2 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -6 | -6.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +211 | +210.7 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -28 | -28.0 |
| SET UP TOGETHER | 7 | 6 | 1 | 0.33 | +18 | +17.5 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +60 | +59.7 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 54 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 14 | 14 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 38 | 38 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 24 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 52 | 50 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 152 | 152 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 19 | 17 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 53 | 41 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 11 | 11 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 68 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 264 | 254 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 274 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 2.33 | 32.5 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | - | 69.5 |
| ARMY TABLE | rule | 1.67 | 2.33 | 110.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 24.2 |
| CHAFF PASSED | rule | 1.33 | - | 2.0 |
| MARCH OF THE TABLE | rule | 1.00 | - | 44.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 36.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 24.0 |
| AFTERMATH BAND | gate | 0.33 | - | 4.7 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 21.2 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 4.7 |
| OWN CAST FIRST | rule | 0.33 | - | 6.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 41.0 |
| REFUSING RETIRES | rule | - | 0.33 | 28.0 |

### Plans: chf-efd8067-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 52 | 48 | 93% |
| Mine | move | 29.3 | 97% | 1811 | 0 | 0% |
| Mine | shoot | 13.7 | 73% | 1303 | 1390 | 107% |
| Opponent | charge | 0.7 | 100% | 81 | 110 | 137% |
| Opponent | move | 37.3 | 96% | 2483 | 0 | 0% |
| Opponent | shoot | 6.3 | 63% | 584 | 498 | 85% |

### Deployment: positions vs output by unit type: chf-efd8067-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 14 (10) | 14 | 0 | 29 | 40% | 3.0 | 15 (4) | 15 (5) | 0 (1) | 22 (6) | 0 (4) |
| Mine | Clean-up | 3 | 93 (3) | 0 | 93 | 0 | 67% | 3.0 | - | 92 (2) | 95 (1) | 93 (3) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 3.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 32 | 50% | 1.3 | 0 (2) | 0 (4) | - | 0 (4) | 0 (2) |
| Mine | Shooter | 6 | 152 (6) | 66 | 87 | 17 | 0% | 1.3 | 47 (2) | 216 (3) | 173 (1) | 164 (5) | 94 (1) |
| Mine | War machine | 8 | 109 (8) | 109 | 0 | 23 | 0% | 1.8 | - | 147 (3) | 89 (5) | - | 109 (8) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 25 | 25% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Chaff | 2 | 144 (2) | 0 | 144 | 0 | 100% | - | - | 144 (2) | - | 257 (1) | 0 (1) |
| Opponent | Character | 8 | 36 (8) | 36 | 0 | 39 | 50% | 2.0 | 47 (1) | 0 (4) | 117 (3) | 43 (7) | 0 (1) |
| Opponent | Clean-up | 2 | 221 (2) | 0 | 221 | 0 | 100% | - | - | 221 (2) | - | 221 (2) | - |
| Opponent | Fast Hammer | 6 | 40 (6) | 0 | 40 | 41 | 83% | 3.0 | - | 29 (4) | 72 (2) | 56 (5) | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 5 | 23 (5) | 7 | 17 | 32 | 40% | 2.3 | - | 0 (2) | 39 (3) | 0 (4) | 121 (1) |
| Opponent | Holder | 4 | 8 (4) | 0 | 8 | 23 | 100% | - | - | 15 (2) | 0 (1) | 0 (2) | 27 (1) |
| Opponent | Shooter | 4 | 48 (4) | 48 | 0 | 35 | 0% | 1.8 | - | 0 (1) | 56 (3) | 48 (4) | - |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 0 | 0% | 1.0 | - | - | 89 (2) | 179 (1) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: chf-efd8067-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 640 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 382 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 554 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 1 | 352 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| Opponent | Skaven | 1 | 434 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 0 of 1 | - | +60 |
| **Opponent** | all armies | 3 | 262 | 55 | 0.7 | 1.0 | 82 | 0 | +82 | 0 of 2 | 1 of 2 | - | +82 |

### Effective charges: chf-efd8067-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +104) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 369 | 145 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 1 | 369 | 145 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 104 | +104 | 104 | 0 | +104 | +42.1 |
| Opponent | No odds | 1 | 173 | 189 | +60 | 145 | 86 | +58 | +33.6 |
| Opponent | All fights | 2 | 210 | 146 | +82 | 124 | 43 | +81 | +38.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p30 | move | 16 | 1 (6%) | 1 (6%) | 4 (25%) | 11 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

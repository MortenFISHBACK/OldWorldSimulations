# Doctrine scorecard: chf-efd8067-p29

### Scorecard: chf-efd8067-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 564 |
| L0717 | 3 | 1 | Opponent | yes | 6 | 2 | 5 | 0 | 2 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 11 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 236 |
| L0823 | 1 | 1 | Mine | no | 13 | 5 | 1 | 1 | 0 | 0 | 0 | 551 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 2 | 0 | 0 | 66 |
| **Average** | | | Mine | 0% | 8.0 | 3.0 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 428.3 |
| **Average** | | | Opponent | 33% | 2.0 | 2.3 | 2.3 | 2.0 | 1.3 | 0.0 | 0.0 | 100.7 |

### KPIs: chf-efd8067-p29

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 76% (13 of 17) | 0% (0 of 15) | 41% (13 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 100% (6 of 6); on the table 100% | 90% (9 of 10); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 17% (2 of 12) | 38% (9 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 64% (7 of 11) | 25% (2 of 8) | 47% (9 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 60% (3603 of 5998) | 39% (2314 of 6000) | 49% (5917 of 11998) |
|   infantry points that never fought | lower | 48% (344 of 715) | 62% (875 of 1418) | 57% (1219 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (17 of 30) | 45% (10 of 22) | 52% (27 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 1.7 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (2874 of 5389) | 36% (1831 of 5023) | 45% (4705 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (60%) | 2.0 (40%) |
| MARCHED: its unit marched | 1.0 (60%) | 0.0 (0%) | 1.0 (20%) |
| CHARGED: its unit charged | 0.3 (20%) | 0.0 (0%) | 0.3 (7%) |
| IN COMBAT: engaged in combat | 0.3 (20%) | 0.0 (0%) | 0.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (40%) | 1.3 (27%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 1.7 | 3.0 | 0.3 | 1.0 |
| not cast | 5.3 | 0.3 | 5.0 | 1.7 | 11.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 2.0 (40%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (20%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (25%) | 0.0 (0%) | 1.3 (27%) | 1.3 (80%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.7 (97%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (66 of 83) | 53% (46 of 86) | 66% (112 of 169) |
|   cavalry | 82% (9 of 11) | 43% (3 of 7) | 67% (12 of 18) |
|   character | - | 47% (7 of 15) | 47% (7 of 15) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 83% (20 of 24) | 64% (34 of 53) | 70% (54 of 77) |
|   monster | - | 18% (2 of 11) | 18% (2 of 11) |
|   war machine | 77% (33 of 43) | - | 77% (33 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (35%) | 1.3 (10%) | 3.3 (18%) |
| CHARGED: it charged | 0.0 (0%) | 3.3 (25%) | 3.3 (18%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.3 (24%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.7 (50%) | 6.7 (35%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (29%) | 0.3 (2%) | 2.0 (11%) |
| SHELTERED: the target was sheltered | 0.7 (12%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.3 | 81% | 3.9 pts | 27 pts |
| character | 2.3 | 0.3 | 86% | 7.8 pts | 18 pts |
| chariot | 1.3 | 0.3 | 75% | 8.1 pts | 11 pts |
| infantry | 23.7 | 6.3 | 79% | 5.8 pts | 137 pts |
| monster | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 11.0 | 14.7 | 45% | 34.3 pts | 377 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 7.0 | 4.7 |
| Charges that made contact a game | 1.3 | 3.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.17 contact (23 units) | 0.69 declared, 0.28 contact (29 units) | 0.50 declared, 0.23 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 33% (1 of 3) | - | 58% (7 of 12) |
| Character in a unit | 60% (3 of 5) | - | 100% (1 of 1) | 67% (4 of 6) |
| Character on its own | 50% (2 of 4) | 100% (1 of 1) | 17% (1 of 6) | 36% (4 of 11) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 0% (0 of 3) | 0% (0 of 1) | 0% (0 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 60% (6 of 10) | - | - | 60% (6 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 75% (3 of 4); on the table 100% | 58% (7 of 12) | 60% | 57% (17 of 30) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 38% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 43% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 35% | 50% (5 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 100% (2) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.67 | 0.00 | 1.67 |

### Quality by phase: chf-efd8067-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 25% (4 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (16 of 48) | 86% (6 of 7) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 428.3 | 100.7 |
| Movement | Fights charged into per game | 1.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net -189 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 1 of 4, net -180 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +88 | 2 of 4, net +190 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (19 of 34) | 65% (32 of 49) |
| Shooting | Points destroyed by shooting units | 132.3 | 15.0 |
| Shooting | War machine shots | 11.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (15 of 33) | - |
| Shooting | Points destroyed by war machines | 158.0 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (2 of 7) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 3.7 | 4.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 148.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 0.7 / 0.0 | 1.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 146.7 | 281.0 |
| Combat | Points run down | 6.3 | 119.7 |
| Combat | Net points per charged fight, damage counted | +94 | +84 |
| Combat | Net per 100 charger points, damage counted | +50.3 | +26.5 |
| Combat | First round won (charged fights) | 75% | 71% |
| Combat | Net points per charged fight | -4 | +120 |
| Combat | Net points per supported fight / lone fight | - / -4 | -90 / +205 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 7 of 7 |
| Game | Points lost | 720.3 | 705.3 |
| Game | VP from objectives | 1033.3 | 973.3 |
| Game | Lone holders (player turns) | 8.0 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +19 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1426
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: chf-efd8067-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +10.8 | 0.0 | 0.0 | 0.3 | +74.8 | 0.0 | 23.3 |
| ARMY TABLE | 18.3 | -148.7 | 0.0 | 200.0 | 23.0 | +628.6 | 0.0 | 327.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 85.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +299.7 | 647.3 | 381.7 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.3 | +211.2 | 324.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +4.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -1.7 | 0.0 | 22.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -40.1 | 0.0 | 63.0 | 1.7 | -105.3 | 0.0 | 23.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.7 | +58.5 | 0.0 | 23.3 |
| CHARGE LOSSES | 15.3 | -639.7 | 0.0 | 362.0 | 11.7 | -944.4 | 0.0 | 598.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 36.7 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 197.0 | 126.0 | 2.0 | +0.0 | 149.7 | 0.0 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 58.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 126.7 | 0.3 | +0.0 | 0.0 | 65.0 |
| COVER ONCE | 13.0 | -604.6 | 0.0 | 331.0 | 7.0 | -385.1 | 0.0 | 189.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -6.0 | 126.7 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | -94.6 | 0.0 | 0.0 | 7.3 | +17.1 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +2.6 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +22.0 | 123.0 | 63.0 | 4.7 | +108.6 | 458.0 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +24.9 | 0.0 | 126.0 | 4.0 | +3.4 | 333.0 | 0.0 |
| FALLBACK BY WORTH | 1.0 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| FALLS SHORT | 2.7 | +12.5 | 0.0 | 0.0 | 15.0 | +175.2 | 0.0 | 163.3 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +1.1 | 0.0 | 22.0 |
| FIGHT TO THE END | 0.7 | +8.9 | 0.0 | 63.0 | 0.3 | +7.3 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 58.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 99.0 | +7151.9 | 2249.0 | 1776.7 | 76.3 | +6216.4 | 706.7 | 1078.7 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 271.3 | 4.0 | +0.0 | 0.0 | 94.7 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +303.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +118.0 | 123.0 | 126.0 | 6.0 | +364.4 | 458.0 | 23.3 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 126.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 3.3 | -179.5 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -19.2 | 86.7 | 0.0 |
| GOAL WALK | 2.3 | +197.6 | 0.0 | 63.0 | 18.0 | +1506.6 | 0.0 | 292.7 |
| GUN FIGURES | 1.0 | +18.1 | 87.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.0 | +163.3 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | - | - | - | - | 1.0 | +0.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 63.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 23.3 |
| HIS CHARGE BY HIS RUN | 10.0 | +0.0 | 0.0 | 189.7 | 7.7 | +0.0 | 0.0 | 444.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +2.7 | 126.7 | 0.0 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 36.3 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 172.3 | 2.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 5.3 | -100.0 | 0.0 | 0.0 | 1.3 | -6.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 290.0 | 4.7 | +0.0 | 0.0 | 72.7 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 299.0 | 4.3 | +0.0 | 0.0 | 65.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.0 | +1124.5 | 0.0 | 299.0 | 40.3 | +2205.8 | 0.0 | 568.3 |
| HIS SHOTS BY HIS RUN | 38.7 | +844.2 | 0.0 | 734.3 | 46.3 | +1744.5 | 0.0 | 888.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +93.4 | 130.0 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 109.3 | 17.7 | +0.0 | 0.0 | 66.0 |
| HOLDER ASSIGNMENT | 13.7 | +1424.1 | 0.0 | 54.7 | 12.7 | +1136.7 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -37.6 | 123.0 | 63.0 | 4.7 | -209.6 | 331.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +27.5 | 0.0 | 0.0 |
| IDLE COST | 0.3 | -1.3 | 0.0 | 0.0 | 12.0 | -176.6 | 0.0 | 339.0 |
| JOINT CHARGE NOW | 0.7 | +3.3 | 116.7 | 0.0 | 1.3 | +306.0 | 0.0 | 23.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.7 | +139.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +20.1 | 0.0 | 0.0 | 0.7 | +27.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 88.3 | 189.7 | 3.0 | +0.0 | 126.7 | 196.0 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +12.7 | 0.0 | 0.0 | 0.7 | -16.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -0.1 | 58.3 | 126.0 | 1.3 | -0.1 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 3.0 | +53.7 | 0.0 | 0.0 | 0.7 | +4.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | -20.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +84.4 | 0.0 | 126.7 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -58.4 | 0.0 | 126.7 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +121.6 | 0.0 | 126.7 | 1.3 | +19.3 | 0.0 | 65.0 |
| MEETS IN TIME | 4.0 | +390.9 | 0.0 | 0.0 | 4.3 | +232.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +140.8 | 0.0 | 0.0 | 2.3 | +36.4 | 0.0 | 141.3 |
| MISSILES NEXT TURN | 3.0 | +87.7 | 0.0 | 126.7 | 3.0 | +37.3 | 0.0 | 141.3 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 30.0 | 2.3 | +0.0 | 36.3 | 36.0 |
| MOVE TO CHARGE COMPUTED | 6.7 | +508.5 | 0.0 | 126.7 | 4.7 | +298.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +337.8 | 0.0 | 0.0 | 7.7 | +347.1 | 0.0 | 58.0 |
| NEXT CHARGE BY LIST | 5.0 | +411.6 | 0.0 | 0.0 | 3.0 | +251.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -40.0 | 0.0 | 0.0 | 0.3 | -10.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.7 | +13.1 | 0.0 | 0.0 | 4.7 | +163.9 | 253.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -43.0 | 64.7 | 126.0 | 6.0 | -230.7 | 458.0 | 23.3 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.7 | +0.0 | 0.0 | 30.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 281.7 | - | - | - | - |
| OFF BEST | 6.7 | -257.0 | 0.0 | 183.3 | 4.7 | -166.5 | 41.7 | 127.7 |
| ONE FIGHT FORMULA | 6.3 | -154.8 | 0.0 | 54.7 | 3.0 | -72.6 | 0.0 | 58.3 |
| ONE JOINT FIGURE | 0.3 | +17.1 | 0.0 | 63.0 | 1.3 | +74.8 | 0.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 4.7 | +17.1 | 0.0 | 0.0 | 5.3 | -41.3 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -26.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 4.0 | +162.9 | 253.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +3.1 | 45.0 | 0.0 |
| PATHS CROSS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +28.7 | 0.0 | 0.0 |
| PLAN RESULT | 48.0 | +1718.3 | 708.0 | 1237.7 | 36.7 | +360.1 | 226.3 | 722.0 |
| PRIZE BY WORTH | - | - | - | - | 0.7 | +46.3 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -111.1 | 0.0 | 126.7 | 8.0 | -150.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 26.7 | +2763.5 | 0.0 | 526.0 | 16.7 | +2362.4 | 332.7 | 72.7 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +125.3 | 0.0 | 28.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 28.3 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +58.0 | 63.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -12.3 | 0.0 | 0.0 | 0.7 | -5.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | -0.6 | 116.7 | 126.0 | 5.0 | -208.9 | 458.0 | 23.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -29.2 | 43.3 | 0.0 |
| RUN DOWN | 1.3 | -4.3 | 6.3 | 126.0 | 3.7 | -21.4 | 359.7 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +13.5 | 0.0 | 22.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 22.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +3.8 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.8 | 6.3 | 0.0 | 0.7 | +49.3 | 41.7 | 0.0 |
| SET CREDITED ONCE | 1.0 | -12.2 | 0.0 | 63.0 | 1.3 | -80.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | -13.2 | 0.0 | 63.0 | 2.3 | +21.9 | 0.0 | 65.0 |
| SET UP TOGETHER | 3.3 | +67.4 | 0.0 | 0.0 | 0.7 | +4.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 441.7 | 2.7 | +0.0 | 0.0 | 36.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +51.9 | 0.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -57.8 | 175.0 | 83.3 | 0.3 | -0.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 17.0 | -330.6 | 0.0 | 236.0 | 27.7 | +1031.8 | 0.0 | 750.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.3 | +861.7 | 0.0 | 481.3 | 13.0 | +239.8 | 0.0 | 163.3 |
| SPELL WORTH | 0.3 | +2.7 | 28.3 | 28.3 | 2.3 | +27.6 | 99.3 | 219.3 |
| SPELLS IN THE FIGHT | 0.7 | +5.4 | 116.7 | 0.0 | 0.7 | +15.9 | 126.7 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 189.7 | 6.3 | +0.0 | 0.0 | 100.7 |
| STAND AND SHOOT | 0.7 | -4.5 | 0.0 | 0.0 | 0.7 | -3.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 57.0 | +0.0 | 2126.0 | 979.3 | 13.0 | +0.0 | 248.7 | 72.0 |
| STAY WORTH | 32.7 | +144.5 | 1500.7 | 609.3 | 12.3 | +112.4 | 248.7 | 36.0 |
| STRIKE BY THE ODDS | 0.3 | +0.1 | 0.0 | 63.0 | 0.7 | +43.1 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.3 | +192.7 | 0.0 | 36.7 | 1.0 | +46.2 | 0.0 | 72.7 |
| SUPPORT WORKED OUT | 3.3 | +192.7 | 0.0 | 36.7 | 1.0 | +46.2 | 0.0 | 72.7 |
| SURE REACH TOGETHER | 2.0 | +45.9 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 54.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +10.4 | 116.7 | 63.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -32.7 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 189.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 855.3 | 33.3 | +0.0 | 0.0 | 527.7 |
| TIED UP BY THE SUM | 1.3 | +85.2 | 123.0 | 63.0 | 3.3 | +403.5 | 294.7 | 0.0 |
| TIME ON OUR SIDE | 33.7 | +394.1 | 0.0 | 351.7 | 3.3 | +39.6 | 0.0 | 58.3 |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +16.3 | 0.0 | 63.0 | 0.7 | +27.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -147.6 | 0.0 | 126.0 | 3.3 | -332.4 | 0.0 | 233.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +62.7 | 0.0 | 23.3 |
| WHOLE FIGHT REACTION | 5.3 | +251.3 | 0.0 | 397.7 | 0.7 | +51.3 | 0.0 | 6.3 |
| WOUNDS ON THE RANKS | 5.3 | +159.1 | 0.0 | 0.0 | 1.7 | +19.2 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 124 | 124 | 83 | 27.67 | +1847 | +22.3 |
| HOLDER ASSIGNMENT | 79 | 79 | 72 | 24.00 | +4112 | +57.1 |
| HIS SHOT LIST | 238 | 233 | 64 | 21.33 | +1066 | +16.7 |
| HIS SHOTS BY HIS RUN | 255 | 250 | 41 | 13.67 | +514 | +12.5 |
| FIVE ACTION | 526 | 515 | 38 | 12.67 | +2316 | +60.9 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1270 | -37.4 |
| QUARTER ODDS | 130 | 126 | 30 | 10.00 | +2073 | +69.1 |
| DEPLOY BY FIGURES | 51 | 51 | 29 | 9.67 | +407 | +14.0 |
| GOAL WALK | 61 | 60 | 22 | 7.33 | +1557 | +70.8 |
| MOVE TO CHARGE COMPUTED | 34 | 31 | 21 | 7.00 | +904 | +43.1 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 111 | 101 | 19 | 6.33 | +21 | +1.1 |
| COVER ONCE | 60 | 44 | 15 | 5.00 | +451 | +30.1 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 24 | 21 | 15 | 5.00 | +881 | +58.7 |
| CHARGE LOSSES | 81 | 80 | 14 | 4.67 | +2017 | +144.1 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +516 | +39.7 |
| PROMISE BY ITS OWN SUM | 39 | 39 | 13 | 4.33 | -784 | -60.3 |
| SHOT RISK POINTS | 134 | 129 | 12 | 4.00 | +490 | +40.8 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 14 | 12 | 10 | 3.33 | +524 | +52.4 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| NO CHAFF EDGES | 16 | 16 | 7 | 2.33 | +133 | +19.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +928 | +154.6 |
| MAX FOR POSITIONING | 15 | 13 | 6 | 2.00 | +45 | +7.4 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 12 | 12 | 6 | 2.00 | -89 | -14.8 |
| WHOLE FIGHT DANGER | 13 | 13 | 6 | 2.00 | +1078 | +179.6 |
| CAST JOB | 7 | 7 | 5 | 1.67 | +192 | +38.4 |
| CHARGE NOW FIRST | 13 | 13 | 5 | 1.67 | -233 | -46.6 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +911 | +182.2 |
| FOUR ROUNDS | 25 | 23 | 5 | 1.67 | +152 | +30.4 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +518 | +103.5 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +625 | +125.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +31 | +6.3 |
| STAY WORTH | 135 | 120 | 5 | 1.67 | +47 | +9.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +142 | +35.4 |
| MISSILES IN THE MOVE | 14 | 11 | 4 | 1.33 | +163 | +40.7 |
| REDIRECT COUNTER | 7 | 6 | 4 | 1.33 | +118 | +29.4 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 7 | 6 | 4 | 1.33 | +55 | +13.9 |
| WHOLE FIGHT REACTION | 18 | 18 | 4 | 1.33 | +8 | +2.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 3 | 1.00 | +130 | +43.4 |
| IDLE COST | 37 | 21 | 3 | 1.00 | +23 | +7.8 |
| NO DOUBLE ROUNDS | 24 | 22 | 3 | 1.00 | +41 | +13.5 |
| OPENS UP IN FULL | 12 | 12 | 3 | 1.00 | +91 | +30.3 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +86 | +28.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +160 | +53.2 |
| SHOTS IN THE MOVE | 106 | 76 | 3 | 1.00 | +130 | +43.2 |
| SUPPORT ADDS | 13 | 12 | 3 | 1.00 | +132 | +44.0 |
| SUPPORT WORKED OUT | 13 | 12 | 3 | 1.00 | +132 | +44.0 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +257 | +128.4 |
| CANNON PLANNED TARGET | 29 | 29 | 2 | 0.67 | +50 | +24.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +176 | +87.8 |
| HIS TURN DENIED | 5 | 4 | 2 | 0.67 | +6 | +2.9 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.67 | +418 | +208.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +253 | +126.6 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +139 | +69.4 |
| RISK BY ARC | 21 | 20 | 2 | 0.67 | +33 | +16.3 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +12 | +6.1 |
| SET UP TOGETHER | 12 | 8 | 2 | 0.67 | +34 | +16.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOTS AFTER THE MOVES | 23 | 23 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +9 | +4.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -5 | -5.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.4 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -140 | -139.9 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 19 | 17 | 1 | 0.33 | +21 | +20.6 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 53 | 44 | 1 | 0.33 | +6 | +5.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIEND SHOOTS FIRST | 10 | 10 | 1 | 0.33 | +24 | +24.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| HIS MOVE AND SHOT | 20 | 20 | 1 | 0.33 | +1 | +0.6 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| NEARER NOT NEEDED | 48 | 48 | 1 | 0.33 | +31 | +31.4 |
| ONE FIGHT FORMULA | 28 | 16 | 1 | 0.33 | +3 | +2.7 |
| ONE JOINT FIGURE | 5 | 5 | 1 | 0.33 | +12 | +12.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -78 | -78.4 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -19 | -19.2 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +12 | +12.1 |
| BACKS UP THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 17 | 15 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 48 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 15 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 53 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 31 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 109 | 109 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 18 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 14 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 30 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 63 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 31 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 210 | 204 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 5 | 5 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 21 | 21 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 3.33 | 40.3 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 3.00 | 60.3 |
| ARMY TABLE | rule | 2.67 | 1.00 | 64.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.33 | 31.2 |
| CHARGE NOW FIRST | rule | 0.33 | 1.33 | 46.6 |
| RULE SWITCHED OFF | gate | - | 1.33 | 25.0 |
| CHAFF PASSED | rule | - | 0.33 | 5.0 |
| CHARGE LIST READ AGAIN | rule | - | 0.33 | 96.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 139.9 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.7 |
| JOINT CHARGE NOW | rule | 0.33 | - | 56.8 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 6.6 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 78.4 |
| SET UP BY THE SET | rule | - | 0.33 | 195.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 19.2 |

### Plans: chf-efd8067-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 315 | 180 | 57% |
| Mine | join | 3.3 | 80% | 60 | 0 | 0% |
| Mine | move | 28.3 | 96% | 1794 | 0 | 0% |
| Mine | shoot | 14.0 | 74% | 892 | 1539 | 173% |
| Opponent | charge | 4.0 | 50% | 787 | 249 | 32% |
| Opponent | move | 30.7 | 90% | 2070 | 0 | 0% |
| Opponent | shoot | 2.0 | 83% | 220 | 111 | 50% |

### Battle groups: chf-efd8067-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 14% | 100% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 35 (12) | 35 | 0 | 25 | 58% | 2.4 | 0 (5) | 55 (6) | 21 (1) | 34 (7) | 39 (5) |
| Mine | Clean-up | 1 | 327 (1) | 0 | 327 | 0 | 100% | - | - | 327 (1) | - | 327 (1) | - |
| Mine | Fast Hammer | 8 | 49 (8) | 6 | 43 | 44 | 38% | 2.8 | 0 (2) | 60 (6) | - | 99 (4) | 2 (4) |
| Mine | Hammer | 2 | 83 (2) | 36 | 47 | 0 | 0% | 1.5 | - | 0 (1) | 143 (1) | 143 (1) | 0 (1) |
| Mine | Shooter | 5 | 70 (5) | 0 | 70 | 35 | 0% | 1.0 | 70 (5) | - | - | 70 (5) | - |
| Mine | War machine | 10 | 63 (10) | 63 | 0 | 60 | 0% | 1.0 | 63 (10) | - | - | 242 (1) | 42 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 89 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (4) | - |
| Opponent | Character | 9 | 51 (9) | 51 | 0 | 9 | 11% | 3.0 | - | 66 (6) | 22 (2) | 36 (2) | 67 (6) |
| Opponent | Clean-up | 3 | 17 (3) | 17 | 0 | 100 | 67% | 2.0 | 30 (2) | 0 (1) | - | 17 (3) | - |
| Opponent | Fast Hammer | 5 | 5 (5) | 5 | 0 | 63 | 20% | 3.0 | 22 (1) | 0 (1) | 0 (3) | 0 (3) | 11 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (3) | - | - | 0 (3) |
| Opponent | Hammer | 3 | 16 (3) | 16 | 0 | 61 | 0% | 3.0 | - | 24 (2) | 0 (1) | - | 16 (3) |
| Opponent | Holder | 3 | 47 (3) | 0 | 47 | 0 | 0% | 2.3 | 0 (1) | 68 (2) | - | 75 (2) | 0 (1) |
| Opponent | Shooter | 7 | 123 (7) | 0 | 123 | 44 | 14% | 1.7 | 217 (2) | 135 (4) | 25 (1) | 80 (3) | 171 (4) |
| Opponent | Wizard | 1 | 37 (1) | 37 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: chf-efd8067-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 438 | 58 | 1.3 | 1.0 | 44 | 47 | -4 | 1 of 4 | 3 of 4 | - | -4 |
| Opponent | Lizardmen | 1 | 0 | 758 | 3.0 | 1.3 | 253 | 0 | +253 | 3 of 3 | 2 of 3 | +0 | +379 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 350 | 3.0 | 1.3 | 117 | 88 | +28 | 3 of 3 | 2 of 3 | -180 | +132 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 15 | 369 | 2.3 | 1.3 | 158 | 38 | +120 | 7 of 7 | 5 of 7 | -90 | +205 |

### Effective charges: chf-efd8067-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 4 | 1 (net -189) | 0 | 1 (net +0) | 0 | 0 | 2 (net +88) | 0 | 25% (1 of 4) |
| Opponent | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +380) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net -180) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |

### Charged fights, damage counted: chf-efd8067-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 189 | 224 | -189 | 194 | 243 | -49 | -26.0 |
| Mine | Effective (55-75%) | 1 | 189 | 236 | +0 | 202 | 0 | +202 | +107.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 185 | 140 | +88 | 153 | 42 | +111 | +60.2 |
| Mine | All fights | 4 | 187 | 185 | -4 | 176 | 82 | +94 | +50.3 |
| Opponent | Long shot (under 50%) | 1 | 268 | 238 | +0 | 89 | 62 | +27 | +10.1 |
| Opponent | Effective (55-75%) | 1 | 265 | 371 | -180 | 227 | 265 | -38 | -14.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 422 | 322 | +190 | 190 | 140 | +50 | +11.8 |
| Opponent | No odds | 3 | 277 | 214 | +214 | 256 | 91 | +165 | +59.8 |
| Opponent | All fights | 7 | 315 | 271 | +120 | 209 | 126 | +84 | +26.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p29 | move | 12 | 5 (42%) | 5 (42%) | 4 (33%) | 3 (25%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

# Doctrine scorecard: chf-efd8067-p36

### Scorecard: chf-efd8067-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 0 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 8 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 353 |
| **Average** | | | Mine | 33% | 4.0 | 3.7 | 2.0 | 3.3 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 4.0 | 4.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 174.3 |

### KPIs: chf-efd8067-p36

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 100% | 100% (4 of 4); on the table 100% | 90% (9 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 100% | - | 67% (2 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 90% | 100% (4 of 4); on the table 100% | 79% (11 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 50% (3 of 6) | 50% (6 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (3 of 6) | 60% (3 of 5) | 55% (6 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 43% (3 of 7) | 54% (7 of 13) |
| Points that never fought | lower | 64% (3819 of 5998) | 61% (3658 of 5998) | 62% (7477 of 11996) |
|   infantry points that never fought | lower | 63% (565 of 902) | 69% (738 of 1072) | 66% (1303 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 81% (21 of 26) | 73% (33 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2857 of 5038) | 80% (4278 of 5360) | 69% (7135 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (100%) | 0.7 (67%) | 1.7 (83%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (33%) | 0.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.0 | 0.7 | 2.0 | 0.0 | 0.0 |
| not cast | 2.7 | 0.0 | 3.3 | 2.0 | 2.0 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.7 (83%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (12%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (88%) | - | 3.0 (90%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.3 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 0% (0 of 2) | - | 0% (0 of 2) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 10% (1 of 10) | 62% (26 of 42) | 52% (27 of 52) |
|   cavalry | 20% (1 of 5) | 75% (9 of 12) | 59% (10 of 17) |
|   character | 0% (0 of 5) | 33% (6 of 18) | 26% (6 of 23) |
|   infantry | - | 92% (11 of 12) | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (33%) | 2.0 (38%) | 3.0 (36%) |
| CHARGED: it charged | 1.0 (33%) | 1.7 (31%) | 2.7 (32%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.3 (25%) | 1.3 (16%) |
| NO TARGET IN RANGE | 1.0 (33%) | 0.0 (0%) | 1.0 (12%) |
| STUPIDITY | 0.0 (0%) | 0.3 (6%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 0.3 | 95% | 0.9 pts | 6 pts |
| character | 2.0 | 0.3 | 83% | 12.2 pts | 24 pts |
| infantry | 5.7 | 1.3 | 76% | 8.5 pts | 48 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 2.0 | 3.8 |
| Charges that made contact a game | 3.3 | 1.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.58 declared, 0.33 contact (24 units) | 0.26 declared, 0.13 contact (23 units) | 0.43 declared, 0.23 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 80% (4 of 5) | 0% (0 of 1) | 62% (8 of 13) |
| Character in a unit | 100% (5 of 5) | 100% (3 of 3) | 100% (1 of 1) | 100% (9 of 9) |
| Character on its own | 50% (1 of 2) | - | 57% (4 of 7) | 56% (5 of 9) |
| Infantry | 71% (5 of 7) | 0% (0 of 1) | - | 62% (5 of 8) |
| Monster | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 75% (6 of 8); on the table 100% | 50% (3 of 6) | 71% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 83% (5 of 6); on the table 83% | 50% (3 of 6) | 56% | 76% (19 of 25) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 65% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 60% (6) | 69% (9) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.67 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 1.33 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: chf-efd8067-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 43% (6 of 14) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | - | 29% (2 of 7) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 1.0 | 0.3 |
| Movement | Idle units | 3.3 | 2.7 |
| Movement | Points that never moved of their own | 0.0 | 174.3 |
| Movement | Fights charged into per game | 3.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 8, net -22 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 8, net +46 | 2 of 3, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +36 | 1 of 3, net +205 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 42% (11 of 26) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 69.0 | 55.7 |
| Combat | Points run down | 183.0 | 68.3 |
| Combat | Net points per charged fight, damage counted | +94 | +102 |
| Combat | Net per 100 charger points, damage counted | +37.7 | +20.4 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | +71 | +109 |
| Combat | Net points per supported fight / lone fight | - / +71 | - / +109 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 10 | 0 of 3 |
| Game | Points lost | 241.7 | 252.0 |
| Game | VP from objectives | 440.0 | 590.0 |
| Game | Lone holders (player turns) | 4.0 | 4.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -62 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 494
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 24.0 | +127.1 | 0.0 | 404.3 | 19.7 | +262.9 | 0.0 | 305.3 |
| BACKS UP THE FIGHT | 1.3 | +12.4 | 0.0 | 0.0 | 0.3 | +42.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.3 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -10.7 | 0.0 | 0.0 | 0.3 | -8.9 | 40.7 | 0.0 |
| CAST JOB | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +59.6 | 0.0 | 0.0 | 3.3 | +75.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +13.7 | 0.0 | 68.3 | 0.7 | +4.4 | 0.0 | 30.3 |
| CHALLENGE IN THE FIGHT | 1.0 | +1.2 | 36.3 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.7 | -209.4 | 0.0 | 798.3 | 4.7 | -176.8 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 321.0 | 0.0 | 2.0 | +0.0 | 109.0 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 20.3 | +0.0 | 0.0 | 107.7 | 13.0 | +0.0 | 0.0 | 222.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.3 | -395.0 | 0.0 | 244.3 | 9.0 | -447.2 | 0.0 | 157.0 |
| DEPLOY BY FIGURES | 7.0 | +76.7 | 0.0 | 0.0 | 7.3 | -20.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +1.0 | 32.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 4.3 | +1.7 | 288.3 | 15.0 | 1.0 | +3.2 | 81.3 | 0.0 |
| FALL BACK GOOD ORDER | 5.0 | +21.9 | 233.0 | 15.0 | 1.7 | +0.0 | 200.3 | 0.0 |
| FALLS SHORT | 25.7 | +244.3 | 0.0 | 347.3 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +9.3 | 0.0 | 0.0 | 2.0 | +15.1 | 0.0 | 230.7 |
| FIGHT TO THE END | 0.7 | +8.0 | 152.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 87.7 | +3835.2 | 321.0 | 901.7 | 87.7 | +6505.3 | 230.3 | 619.3 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 228.0 | 6.0 | +0.0 | 0.0 | 221.7 |
| FOLLOW UP WEIGHED | 2.0 | +187.5 | 0.0 | 0.0 | 1.7 | +116.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.7 | +317.9 | 321.0 | 15.0 | 2.0 | +58.2 | 200.3 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 115.3 |
| FRIEND CHARGES FIRST | 0.3 | -8.2 | 0.0 | 68.3 | 0.7 | -29.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 11.7 | +973.5 | 0.0 | 567.3 | 13.7 | +1700.7 | 0.0 | 420.7 |
| GROUND FLIERS | - | - | - | - | 0.3 | +9.9 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.7 | -6.8 | 0.0 | 15.0 | 0.3 | -0.3 | 40.7 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 583.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -13.6 | 0.0 | 136.7 | 1.3 | -37.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 72.7 |
| HIS RANDOM MOVER COMES | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.3 | +676.3 | 0.0 | 482.3 | 18.3 | +279.3 | 0.0 | 60.7 |
| HIS SHOTS BY HIS RUN | 25.7 | +212.6 | 0.0 | 886.7 | 7.7 | +270.7 | 0.0 | 0.0 |
| HIS TURN DENIED | 0.3 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 296.7 | 19.7 | +0.0 | 0.0 | 461.3 |
| HOLDER ASSIGNMENT | 8.7 | +790.4 | 0.0 | 148.3 | 11.0 | +983.7 | 0.0 | 115.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -176.0 | 321.0 | 0.0 | 1.7 | -63.2 | 159.7 | 0.0 |
| IDLE COST | 22.3 | -322.1 | 0.0 | 218.0 | - | - | - | - |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 2.0 | +163.3 | 0.0 | 15.0 | 0.7 | -8.6 | 81.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +18.4 | 0.0 | 0.0 | 1.0 | +19.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 32.7 | 40.7 | 5.7 | +0.0 | 15.0 | 95.0 |
| LOST AFTER ESCAPE | 2.3 | +7.2 | 131.3 | 15.0 | 0.7 | +0.4 | 109.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 2.0 | -110.0 | 0.0 | 65.3 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 2.7 | +14.0 | 0.0 | 0.0 | 1.0 | +12.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +51.8 | 0.0 | 0.0 | 3.7 | +90.3 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +231.2 | 0.0 | 0.0 | 3.3 | +136.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +4.3 | 0.0 | 0.0 | 2.0 | +32.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +3.3 | 0.0 | 0.0 | 3.0 | +27.3 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 107.7 | 107.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.3 | +442.9 | 0.0 | 68.3 | 7.3 | +796.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +276.0 | 0.0 | 0.0 | 8.0 | +352.4 | 0.0 | 123.0 |
| NEXT CHARGE BY LIST | 7.3 | +259.0 | 0.0 | 68.3 | 5.3 | +663.1 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +93.5 | 65.3 | 0.0 | 1.3 | +25.2 | 149.7 | 36.3 |
| NO DOUBLE ROUNDS | 4.3 | -147.4 | 321.0 | 15.0 | 2.0 | -45.3 | 200.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | -8.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -47.9 | 0.0 | 0.0 | 4.0 | -184.6 | 0.0 | 32.7 |
| ONE CHALLENGE TEST | 1.0 | +3.1 | 30.3 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -57.6 | 0.0 | 40.7 | 6.3 | -121.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | -15.0 | 0.0 | 15.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.3 | -78.3 | 0.0 | 107.7 | 5.3 | +6.2 | 0.0 | 115.3 |
| ONE PROMISE A TARGET | 1.0 | +2.6 | 0.0 | 0.0 | 0.7 | -12.0 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +54.1 | 30.3 | 0.0 | 0.3 | +34.1 | 0.0 | 0.0 |
| OPENS UP IN FULL | 2.0 | +78.1 | 95.7 | 0.0 | 1.3 | +56.3 | 149.7 | 0.0 |
| OVERRUNS AWAY | 1.7 | +24.3 | 120.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.7 | +74.2 | 0.0 | 0.0 | 1.3 | +37.7 | 0.0 | 57.7 |
| PLAN RESULT | 44.0 | +276.2 | 164.0 | 375.7 | 44.0 | +106.5 | 50.7 | 504.0 |
| PRIZE BY WORTH | 0.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.0 | -269.3 | 0.0 | 0.0 | 13.7 | -884.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 3.0 | -0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 8.0 | +689.3 | 0.0 | 15.0 | 6.7 | +963.1 | 30.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +6.4 | 0.0 | 0.0 | 2.3 | +2.2 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -14.9 | 0.0 | 0.0 | 2.3 | +43.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +383.5 | 0.0 | 10.0 | 3.7 | +102.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +2.1 | 0.0 | 25.0 | 4.7 | +100.7 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.0 | -51.3 | 0.0 | 0.0 | 0.7 | -62.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 36.3 |
| RISK BY ARC | 4.0 | +114.0 | 226.0 | 15.0 | 0.7 | +4.9 | 78.3 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -8.4 | 32.7 | 0.0 | 0.7 | -16.5 | 81.3 | 0.0 |
| RUN DOWN | 5.3 | -40.7 | 284.7 | 15.0 | 2.0 | -11.7 | 200.3 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -84.8 | 0.0 | 0.0 | 1.0 | -23.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +34.5 | 0.0 | 0.0 | 0.7 | +0.2 | 0.0 | 0.0 |
| SECOND LOOK | 1.0 | +116.2 | 90.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 4.3 | -71.1 | 0.0 | 0.0 | 1.0 | -5.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 7.0 | +18.7 | 0.0 | 0.0 | 4.0 | -15.6 | 0.0 | 57.7 |
| SET UP TOGETHER | 2.7 | +14.0 | 0.0 | 0.0 | 2.0 | +13.8 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.7 | +4.9 | 30.0 | 0.0 |
| SHOT RISK POINTS | 18.3 | -155.7 | 0.0 | 635.7 | 10.7 | -23.7 | 0.0 | 60.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.3 | +26.3 | 0.0 | 0.0 | 8.7 | +83.6 | 0.0 | 0.0 |
| SPELL WORTH | 3.3 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 14.0 | +0.0 | 0.0 | 88.3 | 8.7 | +0.0 | 0.0 | 152.7 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 15.7 | +0.0 | 0.0 | 0.0 | 45.3 | +0.0 | 30.0 | 166.0 |
| STAY WORTH | 0.7 | +2.3 | 0.0 | 0.0 | 10.0 | +54.8 | 0.0 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 5.3 | +258.9 | 0.0 | 148.3 | 6.0 | +716.8 | 0.0 | 57.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 5.3 | +258.9 | 0.0 | 148.3 | 6.0 | +716.8 | 0.0 | 57.7 |
| SURE REACH TOGETHER | 0.7 | +2.7 | 0.0 | 0.0 | 0.7 | +12.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 57.7 |
| THE FIGHT MOVES | 2.7 | +80.9 | 221.7 | 0.0 | 0.3 | +0.2 | 68.3 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 119.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 68.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 443.3 | 44.3 | +0.0 | 0.0 | 252.0 |
| TIED UP BY THE SUM | 2.3 | +335.8 | 132.0 | 0.0 | 0.7 | +116.0 | 109.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 61.7 | +579.8 | 0.0 | 508.3 |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 81.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 2.7 | -66.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +7.7 | 36.3 | 0.0 | - | - | - | - |
| WHO GETS IN | 1.3 | +100.9 | 0.0 | 0.0 | 0.7 | -8.6 | 81.3 | 0.0 |
| WHO HITS BACK | 0.7 | +100.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 1.3 | +48.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -92.3 | 0.0 | 162.7 | 2.0 | -139.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +7.3 | 0.0 | 15.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.3 | +21.4 | 0.0 | 91.3 | 1.3 | +36.9 | 15.0 | 65.3 |

### Rule changes: chf-efd8067-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 131 | 131 | 89 | 29.67 | +954 | +10.7 |
| HOLDER ASSIGNMENT | 59 | 59 | 56 | 18.67 | +3723 | +66.5 |
| FIVE ACTION | 526 | 500 | 44 | 14.67 | +2485 | +56.5 |
| PROMISE BY ITS OWN SUM | 77 | 77 | 35 | 11.67 | -3462 | -98.9 |
| LEGAL CHARGES ONLY | 33 | 33 | 33 | 11.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 185 | 154 | 31 | 10.33 | +38 | +1.2 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOT LIST | 188 | 176 | 28 | 9.33 | +159 | +5.7 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -697 | -26.8 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +127 | +5.3 |
| REDIRECT FOR A FRIEND IN REACH | 29 | 29 | 24 | 8.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 100 | 95 | 18 | 6.00 | +429 | +23.8 |
| SHOT RISK POINTS | 87 | 81 | 18 | 6.00 | +407 | +22.6 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 76 | 76 | 15 | 5.00 | +1436 | +95.7 |
| IDLE COST | 67 | 48 | 13 | 4.33 | +127 | +9.8 |
| FOUR ROUNDS | 23 | 21 | 12 | 4.00 | +354 | +29.5 |
| MOVE TO CHARGE COMPUTED | 50 | 33 | 12 | 4.00 | +244 | +20.4 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 3.67 | +912 | +82.9 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +575 | +52.3 |
| SUPPORT ADDS | 34 | 33 | 11 | 3.67 | +484 | +44.0 |
| SUPPORT WORKED OUT | 34 | 33 | 11 | 3.67 | +484 | +44.0 |
| CHAFF IN THE MOVE | 17 | 16 | 9 | 3.00 | +22 | +2.5 |
| COVER ONCE | 49 | 34 | 9 | 3.00 | +144 | +16.0 |
| NEXT CHARGE BY LIST | 38 | 32 | 9 | 3.00 | +469 | +52.1 |
| NO CHAFF EDGES | 12 | 11 | 9 | 3.00 | +271 | +30.1 |
| PATHS CROSS | 9 | 9 | 9 | 3.00 | +336 | +37.3 |
| QUARTER ODDS | 44 | 42 | 9 | 3.00 | +797 | +88.6 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +464 | +58.0 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1184 | +169.2 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +26 | +3.7 |
| TIED UP BY THE SUM | 9 | 9 | 7 | 2.33 | +164 | +23.5 |
| CHARGE NOW FIRST | 16 | 16 | 6 | 2.00 | -338 | -56.4 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +113 | +18.8 |
| RISK BY ARC | 14 | 14 | 6 | 2.00 | +181 | +30.2 |
| SET UP BY THE SET | 33 | 33 | 6 | 2.00 | +178 | +29.7 |
| WHO GETS IN | 6 | 6 | 6 | 2.00 | +277 | +46.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +54 | +10.9 |
| MAX FOR POSITIONING | 20 | 18 | 5 | 1.67 | +13 | +2.7 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -28 | -5.6 |
| OPENS UP IN FULL | 10 | 9 | 5 | 1.67 | +101 | +20.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 49 | 43 | 4 | 1.33 | +247 | +61.8 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 16 | 4 | 1.33 | +252 | +63.0 |
| FALLS SHORT | 77 | 61 | 3 | 1.00 | +29 | +9.7 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS MOVE AND SHOT | 11 | 11 | 3 | 1.00 | +7 | +2.3 |
| NEARER NOT NEEDED | 45 | 41 | 3 | 1.00 | +120 | +40.1 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +104 | +34.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +348 | +116.2 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +1 | +0.3 |
| SURE REACH TOGETHER | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 2 | 0.67 | -59 | -29.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 21 | 20 | 2 | 0.67 | +19 | +9.7 |
| OPENS UP | 4 | 4 | 2 | 0.67 | +47 | +23.7 |
| REDIRECT COUNTER | 24 | 20 | 2 | 0.67 | +146 | +72.8 |
| SHOTS IN THE MOVE | 30 | 24 | 2 | 0.67 | +45 | +22.7 |
| STAY WORTH | 32 | 24 | 2 | 0.67 | +46 | +23.2 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -14 | -6.9 |
| WHAT THE JOINER ADDS | 8 | 8 | 2 | 0.67 | +46 | +22.9 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +248 | +123.9 |
| WHOLE FIGHT REACTION | 8 | 8 | 2 | 0.67 | +73 | +36.3 |
| BACKS UP THE FIGHT | 5 | 5 | 1 | 0.33 | +126 | +125.5 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 20 | 18 | 1 | 0.33 | +32 | +31.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 11 | 5 | 1 | 0.33 | +23 | +23.4 |
| NO DOUBLE ROUNDS | 19 | 17 | 1 | 0.33 | +34 | +33.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| PROMISE KNOWS THE FIGHT | 16 | 7 | 1 | 0.33 | -0 | -0.1 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +31 | +30.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -7 | -7.2 |
| RUN DOWN | 22 | 20 | 1 | 0.33 | +27 | +27.1 |
| SCOUT BY DROPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SET UP TOGETHER | 14 | 9 | 1 | 0.33 | +10 | +9.8 |
| SHOTS AFTER THE MOVES | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 4 | 4 | 1 | 0.33 | +23 | +22.9 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CHALLENGE IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 100 | 99 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 16 | 15 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 7 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 6 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 30 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 46 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 81 | 76 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 14 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 103 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 11 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 26 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 16 | 16 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 68 | 59 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 183 | 178 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE FIGHT MOVES | 9 | 9 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 31 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| WAITS AGAIN | 21 | 19 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 7.33 | 98.9 |
| JOB FIRST | gate | 4.33 | 3.67 | 23.1 |
| ARMY TABLE | rule | 3.00 | 1.67 | 91.4 |
| CHARGE NOW FIRST | rule | 0.67 | 1.33 | 56.4 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.67 | 17.8 |
| CARRIES OUT SET-UP | rule | 0.33 | 0.33 | 29.4 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 36.2 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 10.9 |
| PATHS CROSS | rule | - | 0.67 | 11.3 |
| SUPPORT NARROWED | rule | 0.67 | - | 6.9 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.8 |
| JOINT CHARGE NOW | rule | - | 0.33 | 50.0 |
| REFUSING RETIRES | rule | - | 0.33 | 7.2 |
| TURN GATE | gate | - | 0.33 | 143.4 |
| WHO GETS IN | rule | - | 0.33 | 50.0 |

### Plans: chf-efd8067-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 43% | 588 | 276 | 47% |
| Mine | join | 2.0 | 100% | 75 | 0 | 0% |
| Mine | move | 35.7 | 97% | 1291 | 0 | 0% |
| Mine | support | 1.7 | 100% | 2 | 0 | 0% |
| Opponent | charge | 1.0 | 67% | 104 | 106 | 102% |
| Opponent | join | 2.7 | 100% | 139 | 0 | 0% |
| Opponent | move | 37.0 | 96% | 2124 | 0 | 0% |
| Opponent | shoot | 1.7 | 0% | 211 | 0 | 0% |
| Opponent | support | 1.7 | 100% | 7 | 0 | 0% |

### Battle groups: chf-efd8067-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 23% | 33% | 0% | - | 0% | 0% | 33% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 9% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 29 (9) | 0 | 29 | 14 | 78% | 4.5 | 0 (4) | 0 (3) | 111 (2) | 36 (7) | 0 (2) |
| Mine | Character | 9 | 8 (9) | 8 | 0 | 0 | 67% | 5.0 | 0 (2) | 12 (6) | 0 (1) | 8 (4) | 9 (5) |
| Mine | Clean-up | 3 | 129 (3) | 93 | 36 | 25 | 0% | 3.0 | - | 246 (1) | 58 (2) | 207 (2) | 0 (1) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 4 | 23 (4) | 10 | 13 | 18 | 50% | 4.0 | 0 (1) | 44 (2) | 0 (1) | 39 (1) | 14 (3) |
| Mine | Hammer | 2 | 6 (2) | 0 | 6 | 66 | 100% | - | - | 6 (2) | - | 0 (1) | 9 (1) |
| Mine | Holder | 1 | 247 (1) | 0 | 247 | 0 | 0% | 5.0 | 247 (1) | - | - | 247 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 1.0 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 218 (3) | 0 | 218 | 0 | 67% | 6.0 | 0 (1) | 386 (1) | 0 (1) | 218 (3) | - |
| Opponent | Character | 10 | 13 (10) | 13 | 0 | 0 | 60% | 1.8 | 3 (6) | 27 (4) | - | 26 (5) | 3 (5) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 41 (5) | 0 | 41 | 44 | 60% | 2.5 | 0 (3) | - | 94 (2) | 91 (3) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 7 (6) | 0 | 7 | 33 | 17% | 3.8 | - | 10 (4) | 0 (2) | 0 (3) | 16 (3) |
| Opponent | Holder | 6 | 26 (6) | 0 | 26 | 0 | 67% | 1.5 | 84 (1) | 36 (2) | - | 84 (1) | 36 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: chf-efd8067-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 278 | 3.5 | 1.0 | 79 | 6 | +73 | 4 of 7 | 5 of 7 | - | +73 |
| Mine | Warriors of Chaos | 1 | 0 | 200 | 3.0 | 1.0 | 67 | 0 | +67 | 0 of 3 | 3 of 3 | - | +67 |
| **Mine** | all armies | 3 | 0 | 252 | 3.3 | 1.0 | 76 | 4 | +71 | 4 of 10 | 8 of 10 | - | +71 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 327 | 3.0 | 1.0 | 109 | 0 | +109 | 0 of 3 | 3 of 3 | - | +109 |
| **Opponent** | all armies | 3 | 0 | 109 | 1.0 | 1.0 | 109 | 0 | +109 | 0 of 3 | 3 of 3 | - | +109 |

### Effective charges: chf-efd8067-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 7 | 2 (net -22) | 0 | 0 | 0 | 1 (net +0) | 2 (net +0) | 2 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +91) | 1 (net +109) | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 0 | 2 (net +61) | 1 (net +205) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 116 | 337 | -22 | 28 | 65 | -37 | -32.1 |
| Mine | 76-89% | 1 | 205 | 109 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 147 | 291 | +36 | 116 | 11 | +105 | +71.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 482 | 80 | +46 | 74 | 0 | +74 | +15.2 |
| Mine | No odds | 2 | 328 | 136 | +278 | 278 | 0 | +278 | +84.6 |
| Mine | All fights | 10 | 250 | 209 | +71 | 111 | 16 | +94 | +37.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 205 | +205 | 205 | 0 | +205 | +41.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 500 | 122 | +61 | 61 | 11 | +50 | +10.1 |
| Opponent | All fights | 3 | 500 | 150 | +109 | 109 | 7 | +102 | +20.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p36 | move | 19 | 3 (16%) | 1 (5%) | 2 (11%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

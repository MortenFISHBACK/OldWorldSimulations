# Doctrine scorecard: chf-efd8067-p25

### Scorecard: chf-efd8067-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 9 | 5 | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | yes | 2 | 6 | 4 | 2 | 0 | 0 | 0 | 117 |
| L0135 | 3 | 1 | Mine | no | 14 | 2 | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 4 | 0 | 0 | 0 | 126 |
| **Average** | | | Mine | 0% | 7.7 | 3.5 | 0.0 | 2.0 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 33% | 2.0 | 4.0 | 1.7 | 4.3 | 0.0 | 0.0 | 0.0 | 137.7 |

### KPIs: chf-efd8067-p25

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 16) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 33% (30 of 90) | 38% (9 of 24) | 34% (39 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (30 of 86) | 38% (9 of 24) | 35% (39 of 110) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (3 of 4) | 75% (3 of 4) |
| Points that never fought | lower | 81% (4602 of 5700) | 84% (4967 of 5899) | 82% (9569 of 11599) |
|   infantry points that never fought | lower | 79% (2124 of 2703) | 91% (1109 of 1219) | 82% (3233 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (10 of 15) | 72% (18 of 25) | 70% (28 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.3 uses a game | 75% (3 of 4); 4.0 uses a game | 86% (6 of 7); 4.2 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 1.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (5 of 5); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2656 of 4077) | 73% (3547 of 4883) | 69% (6203 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 14.3 (72%) | 4.7 (93%) | 19.0 (76%) |
| MARCHED: its unit marched | 3.7 (18%) | 0.3 (7%) | 4.0 (16%) |
| CHARGED: its unit charged | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 1.3 (7%) | 0.0 (0%) | 1.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 13.0 | 3.3 | 9.7 | 13.0 | 0.7 |
| not cast | 5.0 | 6.7 | 6.3 | 25.0 | 43.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (45%) | 1.0 (16%) | 19.0 (76%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (100%) | 3.7 (55%) | 5.3 (84%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 42.7 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.3 a game | 2.3 a game | 5.3 a game |
| stood (cast and not dispelled) | 64% (16 of 25) | 29% (2 of 7) | 56% (18 of 32) |
| the unit moved after it | 88% (14 of 16) | 0% (0 of 2) | 78% (14 of 18) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 2) | 0% (0 of 18) |
| the enemy charged it first | 6% (1 of 16) | 0% (0 of 2) | 6% (1 of 18) |
| it fought by the end of its next turn | 0% (0 of 16) | 0% (0 of 2) | 0% (0 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 2) | 0% (0 of 18) |
| none of these (no charge, no fight, no charge escaped) | 94% (15 of 16) | 100% (2 of 2) | 94% (17 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (21 of 31) | 60% (45 of 75) | 62% (66 of 106) |
|   cavalry | - | 67% (8 of 12) | 67% (8 of 12) |
|   character | - | 75% (9 of 12) | 75% (9 of 12) |
|   chariot | - | 83% (10 of 12) | 83% (10 of 12) |
|   infantry | 68% (21 of 31) | 22% (6 of 27) | 47% (27 of 58) |
|   monster | - | 100% (12 of 12) | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (60%) | 2.3 (23%) | 4.3 (32%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| FLEEING: it fled or was fleeing | 0.3 (10%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.0 (30%) | 6.3 (63%) | 7.3 (55%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.7 | 64% | 4.4 pts | 16 pts |
| character | 3.0 | 3.0 | 56% | 8.0 pts | 24 pts |
| chariot | 3.3 | 7.3 | 40% | 16.4 pts | 55 pts |
| infantry | 9.7 | 4.3 | 72% | 8.8 pts | 85 pts |
| monster | 4.0 | 1.7 | 75% | 3.1 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.0 | 1.5 |
| Charges that made contact a game | 0.7 | 1.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.13 contact (15 units) | 0.16 declared, 0.10 contact (31 units) | 0.17 declared, 0.11 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | - | - | 33% (1 of 3) |
| Character in a unit | 80% (4 of 5) | 88% (7 of 8) | - | 85% (11 of 13) |
| Character on its own | - | 100% (3 of 3) | 100% (1 of 1) | 100% (4 of 4) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 80% (4 of 5) | 43% (3 of 7) | - | 58% (7 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 34% (37 of 108) | 83% | 67% (14 of 21) | 100% (5 of 5); 5.5 uses a game | 67% (2 of 3); 0.8 uses a game | 100% (5 of 5); 1.2 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | - | 72% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 89% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: chf-efd8067-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (5 of 18) | 40% (8 of 20) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | 88% (7 of 8) |
| Strategy | Joined characters whose unit fought | 17% (3 of 18) | 0% (0 of 5) |
| Strategy | Lone characters that fought | - | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 4.3 |
| Movement | Points that never moved of their own | 36.7 | 137.7 |
| Movement | Fights charged into per game | 0.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 3, net +55 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 3, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 3, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.7 | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (8 of 23) | 40% (18 of 45) |
| Shooting | Points destroyed by shooting units | 38.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 7.3 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (7 of 22) | 71% (5 of 7) |
| Magic | Wounds caused by magic missiles | 18.0 | 5.7 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 275.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.7 / 0.7 / 0.3 / 0.0 | 2.7 / 2.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 40.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +27 | +63 |
| Combat | Net per 100 charger points, damage counted | +3.3 | +45.5 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +0 | +49 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +49 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 0 of 4 |
| Game | Points lost | 127.3 | 331.0 |
| Game | VP from objectives | 806.7 | 736.7 |
| Game | Lone holders (player turns) | 7.7 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +291 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 458
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 9.7 | +291.6 | 0.0 | 87.3 | 22.3 | +106.7 | 0.0 | 254.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -8.2 | 25.7 | 0.0 |
| CAST JOB | - | - | - | - | 2.7 | +16.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 4.0 | +558.0 | 76.0 | 0.0 | 1.3 | +23.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +45.1 | 0.0 | 62.3 | 1.7 | +33.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.9 | 0.0 | 25.7 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -528.8 | 0.0 | 43.3 | 16.3 | -423.0 | 0.0 | 418.7 |
| CHARGE NOW FIRST | - | - | - | - | 1.3 | +0.0 | 61.7 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 21.7 | 16.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 6.3 | +1734.1 | 0.0 | 0.0 | 2.3 | +96.1 | 0.0 | 0.0 |
| COVER ONCE | 3.7 | -118.3 | 0.0 | 21.7 | 5.3 | -173.4 | 0.0 | 112.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -2.0 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | +24.3 | 0.0 | 0.0 | 9.3 | -119.9 | 0.0 | 83.3 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +9.9 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 0.7 | +3.3 | 40.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 0.7 | +0.0 | 44.0 | 0.0 |
| FALLS SHORT | 4.3 | +97.5 | 0.0 | 18.3 | 22.7 | +221.2 | 0.0 | 298.7 |
| FEATURE BUFFS | 13.7 | +338.2 | 0.0 | 138.3 | 1.0 | +34.4 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +0.1 | 18.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 55.7 | +9651.3 | 301.3 | 298.0 | 115.7 | +4492.2 | 359.7 | 870.7 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 36.7 |
| FOLLOW UP WEIGHED | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 1.3 | -16.8 | 65.7 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -10.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.6 | 0.0 | 18.3 | - | - | - | - |
| GOAL WALK | 3.7 | +1059.7 | 0.0 | 0.0 | 2.7 | +95.6 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 3.3 | +36.5 | 94.7 | 0.0 |
| HALF WHEN STILL FLEEING | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 136.7 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 43.3 | 11.3 | +0.0 | 0.0 | 278.7 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 36.7 | 2.7 | +0.0 | 0.0 | 76.0 |
| HIS MOVE AND SHOT | 2.7 | -40.1 | 0.0 | 36.7 | 7.7 | -128.7 | 0.0 | 206.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 94.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 36.7 | 4.3 | +0.0 | 0.0 | 76.0 |
| HIS RANDOM MOVE | 6.3 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.0 | +431.5 | 0.0 | 189.7 | 54.0 | +2692.4 | 0.0 | 500.0 |
| HIS SHOTS BY HIS RUN | 30.3 | +388.4 | 0.0 | 168.0 | 58.0 | +2375.8 | 0.0 | 514.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +17.9 | 21.7 | 0.0 |
| HOLD ODDS | 37.0 | +0.0 | 0.0 | 320.0 | 16.7 | +0.0 | 0.0 | 105.3 |
| HOLDER ASSIGNMENT | 15.7 | +1827.2 | 0.0 | 83.3 | 11.7 | +1082.4 | 0.0 | 52.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.3 | -17.5 | 65.7 | 0.0 |
| IDLE COST | 3.0 | -104.7 | 0.0 | 0.0 | 20.3 | -167.5 | 0.0 | 214.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -11.4 | 18.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 117.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.7 | +0.4 | 40.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 2.0 | +7.2 | 0.0 | 42.0 |
| MANOEUVRE | 1.7 | +22.9 | 0.0 | 0.0 | 1.7 | +1.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +31.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +20.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 1.0 | +74.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +6.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -96.6 | 0.0 | 0.0 | 0.7 | -28.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +9.8 | 0.0 | 18.3 | 1.7 | +5.1 | 0.0 | 42.0 |
| MEETS IN TIME | 3.0 | +271.9 | 0.0 | 0.0 | 8.0 | +263.9 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 7.0 | +933.1 | 0.0 | 0.0 | 6.0 | +83.9 | 0.0 | 105.3 |
| MISSILES NEXT TURN | 7.7 | +512.9 | 0.0 | 0.0 | 6.7 | +72.8 | 0.0 | 105.3 |
| MISSILES ON ONE TARGET | 3.3 | -140.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 21.7 | 2.3 | +0.0 | 38.0 | 17.3 |
| MOVE SPELL IN RANGE | - | - | - | - | 2.0 | +175.6 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.7 | -210.3 | 0.0 | 0.0 | 2.0 | -79.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 2.7 | +117.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +407.0 | 0.0 | 21.7 | 4.3 | +195.9 | 0.0 | 52.7 |
| NEXT CHARGE BY LIST | - | - | - | - | 3.3 | +124.5 | 43.3 | 0.0 |
| NO CHAFF EDGES | 0.7 | +0.1 | 0.0 | 51.3 | 2.0 | +44.8 | 40.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.3 | -15.2 | 65.7 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.0 | -5.9 | 0.0 | 0.0 | 0.7 | -1.5 | 0.0 | 0.0 |
| OFF BEST | 2.0 | -57.0 | 0.0 | 18.3 | 3.7 | -191.8 | 0.0 | 80.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -30.5 | 0.0 | 40.0 | 4.0 | -98.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -12.8 | 18.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.7 | +285.7 | 0.0 | 83.3 | 3.7 | -16.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -28.2 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +1.1 | 18.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.7 | -108.7 | 0.0 | 17.3 |
| PLAN RESULT | 24.0 | +160.4 | 244.0 | 207.3 | 51.7 | +141.1 | 192.3 | 578.7 |
| PROMISE BY ITS OWN SUM | 0.3 | +0.0 | 0.0 | 0.0 | 6.7 | -125.6 | 0.0 | 84.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 9.7 | +1426.4 | 76.0 | 138.0 | 22.7 | +1878.0 | 138.0 | 98.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.3 | +60.0 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +14.9 | 0.0 | 18.3 | - | - | - | - |
| REDIRECT COUNTER | 1.3 | -43.5 | 0.0 | 0.0 | 2.7 | +92.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +19.3 | 0.0 | 36.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +11.6 | 0.0 | 52.7 |
| RESERVE MOVE SPELL | 1.3 | +128.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 0.7 | -2.3 | 18.3 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -6.3 | 65.7 | 0.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +9.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -69.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +118.1 | 0.0 | 0.0 | 1.0 | +21.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -189.1 | 0.0 | 84.0 |
| SET UP BY THE SET | 0.3 | -0.3 | 0.0 | 18.3 | 2.3 | +132.0 | 0.0 | 84.0 |
| SET UP TOGETHER | - | - | - | - | 2.3 | +7.7 | 0.0 | 42.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 21.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +396.2 | 73.3 | 0.0 | 2.0 | +18.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.7 | 21.7 | 0.0 |
| SHOT RISK POINTS | 23.7 | -241.4 | 0.0 | 123.3 | 57.0 | +851.0 | 0.0 | 606.0 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.7 | +213.5 | 0.0 | 86.7 | 14.7 | +195.8 | 0.0 | 265.3 |
| SPELL SETS UP CHARGE | 1.0 | +483.7 | 0.0 | 0.0 | 0.3 | +58.0 | 0.0 | 0.0 |
| SPELL WORTH | 2.3 | +16.7 | 0.0 | 0.0 | 3.3 | +54.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 47.3 | 5.7 | +0.0 | 0.0 | 70.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.3 | 21.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 0.0 | 84.0 |
| STANDS STILL | 21.0 | +0.0 | 301.3 | 153.0 | 48.3 | +0.0 | 294.0 | 238.7 |
| STAY WORTH | 8.3 | +171.5 | 152.0 | 130.0 | 21.0 | +127.4 | 246.7 | 226.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +2.6 | 0.0 | 36.7 |
| STRONG ENOUGH TO HOLD | 1.0 | -13.6 | 0.0 | 0.0 | 1.3 | -0.9 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +55.7 | 0.0 | 0.0 | 0.7 | +62.7 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +55.7 | 0.0 | 0.0 | 0.7 | +62.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.0 | 0.0 | 18.3 | 0.7 | +0.5 | 0.0 | 42.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.7 | +0.4 | 40.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 11.3 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 17.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 26.3 | +0.0 | 0.0 | 149.0 | 56.7 | +0.0 | 0.0 | 407.0 |
| TIME ON OUR SIDE | 19.0 | +465.4 | 0.0 | 98.3 | 26.7 | +214.8 | 43.3 | 0.0 |
| WAITS AGAIN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -290.1 | 0.0 | 0.0 | 1.0 | -60.1 | 0.0 | 112.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.4 | 18.3 | 0.0 |
| WHOLE FIGHT REACTION | 2.0 | +65.0 | 0.0 | 65.7 | 0.3 | +4.7 | 0.0 | 17.3 |
| WOUNDS ON THE RANKS | 8.7 | +248.5 | 0.0 | 0.0 | 1.3 | +129.7 | 0.0 | 105.3 |

### Rule changes: chf-efd8067-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 243 | 238 | 88 | 29.33 | +1313 | +14.9 |
| HIS SHOTS BY HIS RUN | 265 | 262 | 80 | 26.67 | +1465 | +18.3 |
| HOLDER ASSIGNMENT | 82 | 82 | 77 | 25.67 | +4348 | +56.5 |
| SHOT RISK POINTS | 242 | 239 | 70 | 23.33 | +2405 | +34.4 |
| ARMY TABLE | 96 | 96 | 66 | 22.00 | +1064 | +16.1 |
| HARD STAY DROPPED | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 46 | 46 | 27 | 9.00 | +317 | +11.7 |
| TIME ON OUR SIDE | 137 | 118 | 26 | 8.67 | +168 | +6.5 |
| FIVE ACTION | 514 | 503 | 22 | 7.33 | +1044 | +47.4 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| MEETS IN TIME | 33 | 33 | 18 | 6.00 | +281 | +15.6 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -746 | -43.9 |
| QUARTER ODDS | 97 | 96 | 15 | 5.00 | +1030 | +68.7 |
| CASTING BLOCK | 16 | 16 | 14 | 4.67 | +428 | +30.6 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 10 | 10 | 10 | 3.33 | +764 | +76.4 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| GOAL WALK | 19 | 19 | 9 | 3.00 | +718 | +79.8 |
| NEXT CHARGE BY LIST | 10 | 10 | 9 | 3.00 | +141 | +15.7 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 9 | 3.00 | -377 | -41.9 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 9 | 3.00 | +591 | +65.6 |
| MOVE TO CHARGE COMPUTED | 8 | 8 | 8 | 2.67 | +138 | +17.3 |
| NO CHAFF EDGES | 8 | 8 | 8 | 2.67 | +135 | +16.8 |
| IDLE COST | 70 | 61 | 7 | 2.33 | +160 | +22.9 |
| MISSILES IN THE MOVE | 39 | 30 | 7 | 2.33 | +1174 | +167.6 |
| CAST JOB | 8 | 8 | 6 | 2.00 | +1 | +0.1 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 88 | 74 | 6 | 2.00 | +21 | +3.6 |
| WOUNDS ON THE RANKS | 30 | 30 | 6 | 2.00 | +324 | +53.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 6 | 5 | 1.67 | +43 | +8.5 |
| FALLS SHORT | 81 | 69 | 5 | 1.67 | +169 | +33.9 |
| FEATURE BUFFS | 44 | 44 | 5 | 1.67 | +35 | +7.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 8 | 8 | 5 | 1.67 | +3 | +0.6 |
| SHOTS IN THE MOVE | 64 | 43 | 5 | 1.67 | +90 | +18.0 |
| CHARGE LOSSES | 102 | 102 | 4 | 1.33 | +145 | +36.3 |
| MANOEUVRE | 10 | 10 | 4 | 1.33 | +84 | +20.9 |
| NEARER NOT NEEDED | 38 | 36 | 4 | 1.33 | +175 | +43.8 |
| ONE OBJECTIVE FORMULA | 37 | 27 | 4 | 1.33 | +296 | +74.0 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +386 | +96.5 |
| SCOUT BY DROPS | 7 | 7 | 4 | 1.33 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +417 | +104.3 |
| SET UP BY THE SET | 8 | 8 | 4 | 1.33 | +21 | +5.2 |
| RANDOM MOVE BY FIGURES | 4 | 4 | 3 | 1.00 | +180 | +60.0 |
| THE ROW IN ITS ORDER | 11 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -96 | -48.0 |
| COVER ONCE | 27 | 19 | 2 | 0.67 | +5 | +2.5 |
| MARCH CHECK | 3 | 2 | 2 | 0.67 | +92 | +46.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -20 | -10.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -85 | -42.3 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -326 | -163.1 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +8 | +4.0 |
| SUPPORT ADDS | 10 | 10 | 2 | 0.67 | +27 | +13.6 |
| SUPPORT WORKED OUT | 10 | 10 | 2 | 0.67 | +27 | +13.6 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -24 | -24.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +49 | +48.9 |
| FOUR ROUNDS | 4 | 3 | 1 | 0.33 | +10 | +10.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -1.9 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +2 | +1.8 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -34 | -34.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +55 | +55.3 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +61 | +60.6 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.33 | +82 | +82.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| OPENS A LANE | 1 | 1 | 1 | 0.33 | +1 | +1.4 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +35 | +34.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +10 | +10.4 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 2 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 16 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 1 | 1 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 71 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 16 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 31 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 161 | 161 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 32 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 10 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 4 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 227 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 12 | 6 | 0 | 0.00 | - | - |
| RISK BY ARC | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 35 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 34 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 208 | 202 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 7 | 7 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 249 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 13 | 13 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.67 | 3.33 | 40.2 |
| ARMY TABLE | rule | 0.67 | 2.67 | 41.6 |
| PROMISE BY ITS OWN SUM | rule | - | 3.00 | 41.9 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.00 | 18.8 |
| MAIN BODY KEEPS ITS BAND | rule | 0.67 | 0.33 | 26.7 |
| CHARGE NOW FIRST | rule | - | 0.67 | 48.0 |
| MARCH OF THE TABLE | rule | - | 0.67 | 10.0 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 42.3 |
| PIVOT GUARDS FLANK | rule | - | 0.67 | 163.1 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 24.5 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 1.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.2 |
| REFUSING RETIRES | rule | - | 0.33 | 2.4 |
| RULE SWITCHED OFF | gate | - | 0.33 | 141.7 |

### Plans: chf-efd8067-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 19.0 | 95% | 2670 | 0 | 0% |
| Mine | shoot | 4.7 | 43% | 1189 | 160 | 13% |
| Mine | support | 0.3 | 0% | 19 | 0 | 0% |
| Opponent | charge | 0.7 | 50% | 7 | 21 | 307% |
| Opponent | move | 45.0 | 93% | 1494 | 0 | 0% |
| Opponent | shoot | 5.0 | 60% | 317 | 120 | 38% |
| Opponent | support | 1.0 | 100% | 4 | 0 | 0% |

### Battle groups: chf-efd8067-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 50% | 0% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Mine | Character | 18 | 28 (18) | 28 | 0 | 0 | 28% | 1.7 | 100 (3) | 23 (6) | 6 (9) | 55 (6) | 14 (12) |
| Mine | Hammer | 6 | 28 (6) | 0 | 28 | 0 | 83% | 2.0 | 114 (1) | 9 (2) | 13 (3) | 56 (2) | 14 (4) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 33 | 67% | 4.0 | 156 (1) | 39 (1) | 0 (1) | 156 (1) | 19 (2) |
| Mine | Shooter | 6 | 152 (6) | 29 | 123 | 50 | 0% | 1.8 | 231 (2) | 113 (4) | - | 148 (5) | 175 (1) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 13 | 50% | 3.0 | 0 (2) | 261 (4) | - | 202 (5) | 0 (1) |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 0 | 25% | 2.2 | 0 (1) | 0 (7) | - | 0 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 5 (7) | 0 | 5 | 72 | 71% | 1.0 | 10 (4) | 0 (1) | 0 (2) | 7 (5) | 0 (2) |
| Opponent | Hammer | 13 | 38 (13) | 12 | 27 | 13 | 38% | 1.8 | - | 37 (7) | 40 (6) | 53 (7) | 9 (6) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 3 | 89 (3) | 15 | 74 | 62 | 0% | 1.7 | 128 (2) | 0 (1) | - | 128 (2) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: chf-efd8067-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 314 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 0 | 197 | 4.0 | 1.0 | 49 | 0 | +49 | 0 of 4 | 2 of 4 | - | +49 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 18 | 66 | 1.3 | 1.0 | 49 | 0 | +49 | 0 of 4 | 2 of 4 | - | +49 |

### Effective charges: chf-efd8067-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Ogre Kingdoms | 4 | 1 (net +55) | 0 | 0 | 0 | 1 (net +77) | 1 (net +65) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: chf-efd8067-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 2 | 836 | 102 | +0 | 55 | 28 | +27 | +3.3 |
| Mine | All fights | 2 | 836 | 102 | +0 | 55 | 28 | +27 | +3.3 |
| Opponent | Long shot (under 50%) | 1 | 34 | 55 | +55 | 55 | 26 | +30 | +86.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 185 | 65 | +65 | 65 | 0 | +65 | +35.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 297 | 77 | +77 | 77 | 16 | +60 | +20.4 |
| Opponent | No odds | 1 | 34 | 77 | +0 | 121 | 26 | +95 | +280.1 |
| Opponent | All fights | 4 | 138 | 68 | +49 | 79 | 17 | +63 | +45.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p25 | move | 12 | 2 (17%) | 2 (17%) | 0 (0%) | 10 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

# Doctrine scorecard: chf-efd8067-p43

### Scorecard: chf-efd8067-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 3.0 | 0.7 | 0.7 | 0.0 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 0.5 | 2.5 | 1.0 | 3.0 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: chf-efd8067-p43

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (6 of 15) | 0% (0 of 10) | 24% (6 of 25) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% | 60% (3 of 5); on the table 60% |
| Magic missiles tried each own turn | 50%+ | 39% (28 of 72) | 33% (6 of 18) | 38% (34 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (28 of 57) | 33% (6 of 18) | 45% (34 of 75) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 66% (3958 of 5998) | 64% (3821 of 6000) | 65% (7779 of 11998) |
|   infantry points that never fought | lower | 100% (730 of 730) | 68% (532 of 782) | 83% (1262 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 72% (18 of 25) | 77% (20 of 26) | 75% (38 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 6.7 uses a game | 50% (1 of 2); 0.3 uses a game | 78% (7 of 9); 3.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (4005 of 5614) | 80% (4491 of 5644) | 75% (8496 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (32%) | 1.3 (33%) | 6.0 (32%) |
| MARCHED: its unit marched | 5.0 (34%) | 0.0 (0%) | 5.0 (27%) |
| IN COMBAT: engaged in combat | 2.3 (16%) | 0.0 (0%) | 2.3 (12%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (42%) | 1.7 (9%) |
| GONE: slain | 2.7 (18%) | 0.0 (0%) | 2.7 (14%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 3.0 | 0.7 | 11.3 | 1.3 | 1.0 |
| not cast | 1.3 | 13.0 | 5.3 | 18.7 | 2.7 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.0 (54%) | 0.3 (6%) | 6.0 (32%) | 0.3 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.0 (27%) | 0.7 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 2.3 (12%) | 1.0 (38%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (15%) | 2.0 (38%) | 1.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 2.7 (21%) | 0.0 (0%) | 2.7 (14%) | 0.0 (0%) | 3.0 (11%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (3%) | 0.3 (6%) | 0.3 (2%) | 0.0 (0%) | 0.7 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) | 0.7 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (100%) | 0.3 (3%) | 2.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (38 of 47) | 49% (41 of 84) | 60% (79 of 131) |
|   cavalry | - | 50% (11 of 22) | 50% (11 of 22) |
|   character | - | 50% (6 of 12) | 50% (6 of 12) |
|   chariot | 75% (9 of 12) | 67% (8 of 12) | 71% (17 of 24) |
|   infantry | 83% (10 of 12) | 23% (6 of 26) | 42% (16 of 38) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 83% (19 of 23) | - | 83% (19 of 23) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (22%) | 3.7 (26%) | 4.3 (25%) |
| CHARGED: it charged | 0.7 (22%) | 1.0 (7%) | 1.7 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (11%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.3 (11%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.3 (37%) | 5.3 (31%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 2.7 (19%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 1.0 (33%) | 0.0 (0%) | 1.0 (6%) |
| OTHER BAR | 0.0 (0%) | 1.3 (9%) | 1.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.3 | 75% | 4.2 pts | 22 pts |
| character | 2.0 | 1.7 | 50% | 34.3 pts | 69 pts |
| chariot | 5.7 | 5.0 | 59% | 23.0 pts | 130 pts |
| infantry | 8.0 | 1.7 | 79% | 2.8 pts | 23 pts |
| monster | 3.7 | 1.3 | 73% | 13.5 pts | 49 pts |
| war machine | 7.0 | 5.7 | 57% | 23.9 pts | 167 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 1.7 | 2.0 |
| Charges that made contact a game | 1.7 | 1.0 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | - | 0.50 declared, 0.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 2.00 contact (1 units) | - | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.00 contact (9 units) | 0.19 declared, 0.12 contact (26 units) | 0.20 declared, 0.09 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | - | 50% (2 of 4) | 50% (5 of 10) |
| Character in a unit | 50% (1 of 2) | 100% (3 of 3) | 100% (1 of 1) | 83% (5 of 6) |
| Character on its own | 100% (1 of 1) | 86% (6 of 7) | 75% (3 of 4) | 83% (10 of 12) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 62% (5 of 8) | - | - | 62% (5 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 50% (1 of 2); on the table 50% | 39% (28 of 72) | 66% | 72% (18 of 25) | 86% (6 of 7); 6.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 86% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 49% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | 50% (3 of 6) | 56% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 33% (1) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 71% (5 of 7) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (9 of 34) | 67% (12 of 18) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 50% (4 of 8) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 3.0 |
| Movement | Points that never moved of their own | 275.0 | 0.0 |
| Movement | Fights charged into per game | 1.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +1058 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +0 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (8 of 19) | 50% (21 of 42) |
| Shooting | Points destroyed by shooting units | 11.3 | 55.0 |
| Shooting | War machine shots | 7.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (12 of 21) | - |
| Shooting | Points destroyed by war machines | 0.0 | 123.0 |
| Magic | Magic missiles cast | 6.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (5 of 20) | 100% (4 of 4) |
| Magic | Wounds caused by magic missiles | 7.7 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 46.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.3 / 0.3 / 0.3 | 1.3 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 95.0 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +322 | -97 |
| Combat | Net per 100 charger points, damage counted | +92.5 | -44.2 |
| Combat | First round won (charged fights) | 50% | 0% |
| Combat | Net points per charged fight | +327 | -91 |
| Combat | Net points per supported fight / lone fight | +1058 / +83 | - / -91 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 2 of 3 |
| Game | Points lost | 288.0 | 535.3 |
| Game | VP from objectives | 930.0 | 683.3 |
| Game | Lone holders (player turns) | 0.0 | 0.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +563 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 823
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +19.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.3 | -59.9 | 0.0 | 0.0 | 25.0 | +610.9 | 0.0 | 321.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 165.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.3 | +6.7 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| BOMBING RUN | 1.7 | +45.1 | 53.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.7 | +83.0 | 0.0 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| CAST JOB | 6.3 | +164.0 | 753.3 | 246.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +23.7 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +9.2 | 0.0 | 0.0 |
| CHALLENGE IN THE FIGHT | 1.3 | -93.3 | 41.7 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.7 | -17.1 | 0.0 | 0.0 | 0.7 | -48.5 | 0.0 | 42.0 |
| CHARGE LOSSES | 25.7 | -701.4 | 0.0 | 246.0 | 22.7 | -853.4 | 0.0 | 298.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +80.7 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -427.8 | 0.0 | 0.0 | 4.7 | -269.9 | 0.0 | 130.0 |
| DENIED BY THE FIGHT | 0.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -83.3 | 0.0 | 110.0 | 7.3 | +61.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 41.7 | 0.0 | 0.3 | -9.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +25.4 | 0.0 | 177.3 |
| EXACT ROUND | 1.0 | +22.7 | 0.0 | 0.0 | 1.0 | +64.7 | 0.0 | 42.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.5 | 41.7 | 0.0 | 1.3 | +0.4 | 0.0 | 42.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.0 | +60.5 | 0.0 | 123.0 | 12.3 | +179.7 | 0.0 | 209.7 |
| FEATURE BUFFS | 2.7 | +82.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +4.1 | 41.7 | 0.0 | 0.3 | +2.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 79.0 | +5151.6 | 994.3 | 932.0 | 90.3 | +4556.7 | 822.0 | 484.7 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +25.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +45.0 | 41.7 | 0.0 | 1.3 | +174.5 | 0.0 | 42.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.3 | -28.8 | 329.3 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +20.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.3 | +652.7 | 0.0 | 246.0 | 11.3 | +1110.7 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 2.3 | +0.0 | 123.0 | 0.0 |
| GUN MASK | 2.0 | +47.3 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | -1.8 | 41.7 | 0.0 | 0.7 | -2.7 | 0.0 | 42.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 176.7 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 121.3 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 8.3 | -91.9 | 0.0 | 0.0 | 9.7 | -82.3 | 0.0 | 154.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.7 | +1210.3 | 0.0 | 246.0 | 64.3 | +2793.2 | 0.0 | 442.7 |
| HIS SHOTS BY HIS RUN | 39.0 | +852.7 | 0.0 | 246.0 | 43.3 | +1010.6 | 0.0 | 442.7 |
| HIS TURN DENIED | 0.7 | +12.6 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 21.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 38.0 |
| HOLDER ASSIGNMENT | 12.3 | +1050.4 | 0.0 | 0.0 | 9.0 | +1034.2 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -74.3 | 41.7 | 0.0 | 1.0 | -48.7 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +138.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 3.7 | -54.0 | 0.0 | 123.0 | 9.7 | -179.6 | 0.0 | 41.7 |
| JOINT CHARGE NOW | 1.0 | +536.8 | 0.0 | 0.0 | 0.3 | -18.7 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +37.9 | 0.0 | 0.0 | 0.3 | +25.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 53.0 | 0.0 | 2.0 | +0.0 | 0.0 | 41.7 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | -5.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +0.8 | 41.7 | 0.0 | 1.0 | +5.8 | 0.0 | 42.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +8.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | -0.7 | 0.0 | 0.0 | 2.3 | -7.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +76.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +126.2 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -42.0 | 0.0 | 0.0 | 0.3 | +55.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +58.5 | 0.0 | 0.0 | 2.0 | +87.4 | 0.0 | 11.3 |
| MEETS IN TIME | 1.7 | +156.8 | 0.0 | 0.0 | 2.7 | +164.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +189.7 | 0.0 | 246.0 | 4.0 | +38.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 14.3 | +156.7 | 0.0 | 246.0 | 4.7 | +40.7 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -10.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.3 | -126.6 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +324.6 | 0.0 | 0.0 | 2.3 | +105.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +167.6 | 0.0 | 0.0 | 6.3 | +280.6 | 0.0 | 38.0 |
| NEXT CHARGE BY LIST | 4.7 | +320.3 | 340.7 | 0.0 | 2.3 | +105.4 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.0 | +40.5 | 0.0 | 0.0 | 1.0 | +17.4 | 0.0 | 42.0 |
| NO DOUBLE ROUNDS | 1.7 | -48.5 | 41.7 | 0.0 | 1.3 | -52.2 | 0.0 | 42.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.3 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -87.5 | 0.0 | 0.0 | 4.3 | -143.0 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 4.7 | +29.5 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -77.5 | 0.0 | 0.0 | 1.3 | -18.9 | 0.0 | 41.7 |
| ONE JOINT FIGURE | 1.0 | +147.2 | 0.0 | 0.0 | 0.7 | +136.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.0 | -144.9 | 0.0 | 0.0 | 4.3 | -250.0 | 0.0 | 38.0 |
| ONE PROMISE A TARGET | 0.7 | -1.7 | 329.3 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +11.2 | 41.7 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 34.0 | +888.5 | 682.0 | 233.0 | 40.3 | +489.8 | 0.0 | 465.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.0 | -214.1 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.3 | +0.0 | 329.3 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.7 | -5.9 | 329.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -10.9 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 2.0 | -27.7 | 0.0 | 110.0 | - | - | - | - |
| QUARTER ODDS | 15.3 | +1755.5 | 125.0 | 0.0 | 12.3 | +1205.1 | 0.0 | 167.3 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +110.8 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.3 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.0 | -67.8 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +33.7 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +63.9 | 41.7 | 0.0 | 1.0 | -84.1 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -23.7 | 0.0 | 0.0 |
| RUN DOWN | 1.7 | -11.6 | 41.7 | 0.0 | 1.3 | -39.4 | 0.0 | 42.0 |
| SAME CHARGE LATER | 0.3 | -5.2 | 164.7 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +8.2 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -49.7 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | -6.1 | 0.0 | 0.0 | 1.7 | +34.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -0.5 | 0.0 | 0.0 | 1.3 | -7.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +25.1 | 83.3 | 0.0 | 2.0 | +38.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +8.6 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 42.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +19.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.3 | +0.0 | 0.0 | 343.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +4.7 | 0.0 | 0.0 | 2.7 | +21.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 26.3 | -480.1 | 0.0 | 246.0 | 35.7 | -241.6 | 0.0 | 349.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +498.7 | 0.0 | 220.0 | 15.0 | +437.8 | 0.0 | 80.0 |
| SPELL WORTH | 0.7 | +3.7 | 0.0 | 0.0 | 2.3 | +16.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -6.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 246.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 37.3 | +0.0 | 952.7 | 686.0 | 38.7 | +0.0 | 822.0 | 288.7 |
| STAY WORTH | 26.0 | +245.6 | 589.3 | 906.0 | 20.7 | +126.2 | 822.0 | 80.0 |
| STRIKE BY THE ODDS | 0.7 | +10.2 | 0.0 | 0.0 | 0.7 | +3.4 | 0.0 | 42.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -6.6 | 0.0 | 0.0 | 0.7 | -7.7 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +68.2 | 0.0 | 0.0 | 5.7 | +204.8 | 0.0 | 22.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 83.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +68.2 | 0.0 | 0.0 | 5.7 | +204.8 | 0.0 | 22.7 |
| SURE REACH TOGETHER | 3.0 | +22.1 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +29.4 | 0.0 | 329.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +30.9 | 41.7 | 0.0 | 1.0 | +2.2 | 0.0 | 42.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 11.3 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.7 | +0.0 | 0.0 | 466.0 | 43.7 | +0.0 | 0.0 | 221.3 |
| TIED UP BY THE SUM | 0.7 | +32.1 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 21.7 | +363.6 | 0.0 | 123.0 | 37.0 | +314.5 | 110.0 | 11.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -22.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +8.1 | 0.0 | 42.0 |
| WHO HITS BACK | 0.3 | +22.4 | 0.0 | 0.0 | 0.3 | +64.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -86.1 | 0.0 | 0.0 | 2.7 | -335.5 | 0.0 | 93.3 |
| WHOLE FIGHT GAIN | 1.0 | +45.4 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.7 | +302.2 | 53.3 | 0.0 | 1.3 | +119.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 12.0 | +299.9 | 0.0 | 0.0 | 5.0 | +208.9 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 300 | 289 | 85 | 28.33 | +1989 | +23.4 |
| ARMY TABLE | 103 | 103 | 76 | 25.33 | +1621 | +21.3 |
| HOLDER ASSIGNMENT | 64 | 64 | 58 | 19.33 | +3516 | +60.6 |
| HIS SHOTS BY HIS RUN | 247 | 234 | 50 | 16.67 | +696 | +13.9 |
| SHOT RISK POINTS | 186 | 178 | 29 | 9.67 | +669 | +23.1 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -692 | -30.1 |
| DEPLOY BY FIGURES | 40 | 40 | 21 | 7.00 | +360 | +17.1 |
| TIME ON OUR SIDE | 176 | 150 | 19 | 6.33 | +105 | +5.5 |
| CHARGE LOSSES | 145 | 140 | 18 | 6.00 | +472 | +26.2 |
| CAST JOB | 19 | 19 | 17 | 5.67 | +190 | +11.1 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| GOAL WALK | 44 | 44 | 16 | 5.33 | +2239 | +140.0 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 14 | 14 | 14 | 4.67 | +89 | +6.3 |
| FIVE ACTION | 508 | 493 | 13 | 4.33 | +701 | +54.0 |
| NEXT CHARGE BY LIST | 21 | 19 | 13 | 4.33 | +465 | +35.7 |
| MOVE TO CHARGE COMPUTED | 20 | 16 | 12 | 4.00 | +402 | +33.5 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 36 | 36 | 11 | 3.67 | -642 | -58.4 |
| WOUNDS ON THE RANKS | 51 | 51 | 11 | 3.67 | +200 | +18.2 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| QUARTER ODDS | 83 | 81 | 10 | 3.33 | +765 | +76.5 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SET UP BY THE SET | 14 | 14 | 10 | 3.33 | +136 | +13.6 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| STAY WORTH | 140 | 129 | 9 | 3.00 | +119 | +13.3 |
| NO CHAFF EDGES | 9 | 9 | 8 | 2.67 | +160 | +20.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +26 | +3.3 |
| MEETS IN TIME | 13 | 13 | 7 | 2.33 | +64 | +9.2 |
| FOUR ROUNDS | 11 | 11 | 6 | 2.00 | +283 | +47.2 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -83 | -13.8 |
| SHOTS AFTER THE MOVES | 20 | 20 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 21 | 21 | 6 | 2.00 | +131 | +21.9 |
| SUPPORT WORKED OUT | 21 | 21 | 6 | 2.00 | +131 | +21.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| BOMBING RUN | 5 | 5 | 5 | 1.67 | +135 | +27.1 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 61 | 51 | 5 | 1.67 | +33 | +6.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +191 | +38.3 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +230 | +45.9 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 40 | 28 | 4 | 1.33 | +50 | +12.5 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +1554 | +388.6 |
| MAIN BODY KEEPS ITS BAND | 4 | 4 | 4 | 1.33 | +537 | +134.3 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +231 | +57.9 |
| MAX FOR POSITIONING | 21 | 17 | 4 | 1.33 | +11 | +2.7 |
| ONE OBJECTIVE FORMULA | 34 | 31 | 4 | 1.33 | +159 | +39.8 |
| PROMISE KNOWS THE FIGHT | 6 | 5 | 4 | 1.33 | -18 | -4.4 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +105 | +26.2 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +41 | +10.3 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +3 | +1.0 |
| COVER ONCE | 35 | 19 | 3 | 1.00 | +91 | +30.4 |
| ONE JOINT FIGURE | 5 | 5 | 3 | 1.00 | +162 | +54.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +122 | +40.7 |
| SHOTS IN THE MOVE | 81 | 66 | 3 | 1.00 | +18 | +6.0 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 6 | 6 | 2 | 0.67 | +12 | +6.2 |
| EXACT ROUND | 6 | 6 | 2 | 0.67 | +90 | +45.2 |
| FEATURE BUFFS | 8 | 8 | 2 | 0.67 | +9 | +4.6 |
| HIS MOVE AND SHOT | 54 | 53 | 2 | 0.67 | +10 | +5.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -95 | -47.7 |
| MISSILES IN THE MOVE | 45 | 29 | 2 | 0.67 | +11 | +5.7 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -5 | -2.6 |
| PROMISE READS THE TABLE | 4 | 4 | 2 | 0.67 | -6 | -2.9 |
| REDIRECT COUNTER | 10 | 7 | 2 | 0.67 | +40 | +19.8 |
| SCOUT BY DROPS | 8 | 8 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +88 | +44.1 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +83 | +41.3 |
| WAR ENGINE JOBS | 3 | 3 | 2 | 0.67 | -67 | -33.6 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +182 | +90.8 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +26 | +12.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +59 | +58.9 |
| CANNON PLANNED TARGET | 17 | 17 | 1 | 0.33 | -3 | -3.2 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +28 | +27.6 |
| FALL BACK GOOD ORDER | 9 | 9 | 1 | 0.33 | +0 | +0.2 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +0 | +0.2 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +77 | +77.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +60 | +60.2 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +29 | +29.3 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +0 | +0.2 |
| LOST AFTER ESCAPE | 9 | 9 | 1 | 0.33 | +0 | +0.2 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -6 | -5.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +21 | +20.9 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +32 | +32.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STUBBORN ONCE | 1 | 1 | 1 | 0.33 | +15 | +15.4 |
| SURE REACH TOGETHER | 9 | 8 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -67 | -66.7 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +133 | +133.0 |
| WHOLE FIGHT REACTION | 9 | 9 | 1 | 0.33 | +38 | +38.5 |
| BACKS UP THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 38 | 37 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 64 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 99 | 99 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 12 | 12 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 57 | 39 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEARER NOT NEEDED | 30 | 27 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 223 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 4 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 52 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 24 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 228 | 218 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE FIGHT MOVES | 7 | 7 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 241 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.00 | 25.4 |
| ARMY TABLE | rule | 1.67 | 2.00 | 49.9 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | - | 58.4 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 13.8 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 17.7 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 4.4 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 34.7 |
| MARCH OF THE TABLE | rule | 0.67 | - | 47.7 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 2.6 |
| PROMISE READS THE TABLE | rule | 0.67 | - | 2.9 |
| SET UP BY THE SET | rule | - | 0.67 | 11.9 |
| WAR ENGINE JOBS | rule | 0.67 | - | 33.6 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 3.2 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.33 | 3.7 |
| OWN CAST FIRST | rule | 0.33 | - | 5.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 8.1 |
| RULE SWITCHED OFF | gate | - | 0.33 | 132.7 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 66.7 |

### Plans: chf-efd8067-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 17% | 622 | 252 | 41% |
| Mine | move | 21.7 | 100% | 1612 | 0 | 0% |
| Mine | shoot | 10.3 | 45% | 518 | 637 | 123% |
| Opponent | charge | 1.0 | 0% | 35 | 40 | 114% |
| Opponent | move | 33.7 | 95% | 1734 | 0 | 0% |
| Opponent | shoot | 5.0 | 47% | 249 | 450 | 181% |
| Opponent | support | 0.7 | 50% | 1 | 0 | 0% |

### Battle groups: chf-efd8067-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 16 (12) | 16 | 0 | 13 | 17% | 2.8 | 106 (1) | 4 (9) | 0 (1) | 5 (7) | 31 (4) |
| Mine | Fast Hammer | 4 | 8 (4) | 8 | 0 | 0 | 25% | 1.7 | 11 (2) | 7 (2) | - | 13 (3) | 0 (1) |
| Mine | Holder | 5 | 145 (5) | 0 | 145 | 0 | 40% | 3.0 | - | 145 (5) | - | 237 (3) | 0 (2) |
| Mine | Shooter | 2 | 79 (2) | 18 | 62 | 0 | 0% | 1.0 | 124 (1) | 35 (1) | - | 79 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 50 | 0% | 1.2 | 0 (1) | 0 (3) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 188 (6) | 0 | 188 | 26 | 67% | 3.5 | 0 (3) | 1250 (1) | 0 (2) | 265 (5) | 0 (1) |
| Opponent | Character | 7 | 8 (7) | 8 | 0 | 29 | 14% | 2.0 | 0 (1) | 16 (3) | 0 (1) | 22 (3) | 0 (2) |
| Opponent | Clean-up | 3 | 28 (3) | 0 | 28 | 36 | 67% | 2.0 | - | 28 (3) | - | 0 (2) | 79 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 34 (4) | 0 | 34 | 55 | 25% | 2.0 | 209 (1) | 0 (1) | 12 (2) | 39 (3) | 0 (1) |
| Opponent | Hammer | 8 | 24 (8) | 24 | 0 | 16 | 25% | 2.5 | 61 (3) | 0 (1) | 0 (4) | 49 (4) | 0 (4) |
| Opponent | Holder | 1 | 243 (1) | 0 | 243 | 0 | 0% | 6.0 | - | 243 (1) | - | 243 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 50% | 1.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: chf-efd8067-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 58 | 436 | 1.3 | 1.2 | 327 | 0 | +327 | 2 of 4 | 2 of 4 | +1058 | +83 |
| Opponent | Ogre Kingdoms | 1 | 534 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 120 | -120 | 2 of 2 | 0 of 2 | - | -120 |
| **Opponent** | all armies | 3 | 178 | 0 | 1.0 | 1.0 | 0 | 91 | -91 | 2 of 3 | 0 of 3 | - | -91 |

### Effective charges: chf-efd8067-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 4 | 1 (net +1058) | 0 | 1 (net +0) | 1 (net +250) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 2 | 0 | 1 (net -126) | 0 | 1 (net -114) | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: chf-efd8067-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 584 | 494 | +1058 | 1188 | 54 | +1134 | +194.1 |
| Mine | Effective (55-75%) | 1 | 233 | 251 | +0 | 29 | 181 | -152 | -65.2 |
| Mine | 76-89% | 1 | 369 | 125 | +250 | 250 | 0 | +250 | +67.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 205 | 111 | +0 | 56 | 0 | +56 | +27.1 |
| Mine | All fights | 4 | 348 | 245 | +327 | 381 | 59 | +322 | +92.5 |
| Opponent | 50-54% | 1 | 126 | 358 | -126 | 0 | 126 | -126 | -100.0 |
| Opponent | 76-89% | 1 | 499 | 358 | -114 | 0 | 131 | -131 | -26.3 |
| Opponent | No odds | 1 | 34 | 150 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 3 | 220 | 289 | -91 | 0 | 97 | -97 | -44.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p43 | move | 9 | 3 (33%) | 2 (22%) | 0 (0%) | 6 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

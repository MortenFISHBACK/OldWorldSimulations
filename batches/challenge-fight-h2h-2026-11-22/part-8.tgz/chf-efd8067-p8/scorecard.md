# Doctrine scorecard: chf-efd8067-p8

### Scorecard: chf-efd8067-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | yes | 3 | 5 | 3 | 3 | 0 | 0 | 0 | 375 |
| L1431 | 3 | 1 | Mine | yes | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 0 | 3 | 0 | 0 | 562 |
| **Average** | | | Mine | 67% | 0.5 | 2.0 | 3.0 | 0.7 | 0.0 | 0.0 | 0.0 | 147.3 |
| **Average** | | | Opponent | 67% | 1.5 | 3.0 | 2.7 | 2.7 | 1.0 | 0.0 | 0.0 | 312.3 |

### KPIs: chf-efd8067-p8

Rules off - Mine only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 13) | 4% (1 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (3 of 3); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 11% (2 of 18) | 17% (4 of 24) | 14% (6 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (2 of 9) | 19% (4 of 21) | 20% (6 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (5 of 8) | 62% (5 of 8) |
| Points that never fought | lower | 45% (2724 of 6000) | 38% (2276 of 6000) | 42% (5000 of 12000) |
|   infantry points that never fought | lower | 69% (908 of 1315) | 33% (301 of 921) | 54% (1209 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (11 of 25) | 88% (28 of 32) | 68% (39 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 10% (1 of 10); 0.7 uses a game | 0.0 uses a game | 10% (1 of 10); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2488 of 5720) | 90% (5272 of 5830) | 67% (7760 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (19%) | 1.0 (15%) | 2.0 (17%) |
| MARCHED: its unit marched | 1.0 (19%) | 0.7 (10%) | 1.7 (14%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.0 (19%) | 0.3 (5%) | 1.3 (11%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.0 (60%) | 4.0 (33%) |
| GONE: slain | 1.3 (25%) | 0.0 (0%) | 1.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (12%) | 0.7 (10%) | 1.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.7 | 2.0 | 2.0 | 0.0 | 2.0 |
| not cast | 3.3 | 2.3 | 4.0 | 12.0 | 2.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 2.0 (17%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (14%) | 0.7 (17%) | 1.3 (11%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (60%) | 0.0 (0%) | 2.0 (50%) | 4.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 1.3 (11%) | 1.3 (67%) | 5.0 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.0 (0%) | 0.7 (17%) | 1.3 (11%) | 0.0 (0%) | 1.3 (6%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (20%) | 0.0 (0%) | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.7 (62%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 50% (3 of 6) | - | 50% (3 of 6) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (59 of 91) | 59% (13 of 22) | 64% (72 of 113) |
|   cavalry | 43% (3 of 7) | 64% (7 of 11) | 56% (10 of 18) |
|   character | 27% (8 of 30) | 33% (2 of 6) | 28% (10 of 36) |
|   infantry | 80% (24 of 30) | 80% (4 of 5) | 80% (28 of 35) |
|   war machine | 100% (24 of 24) | - | 100% (24 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (41%) | 2.0 (67%) | 6.3 (46%) |
| CHARGED: it charged | 3.3 (31%) | 0.3 (11%) | 3.7 (27%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.3 (11%) | 1.0 (7%) |
| NO TARGET IN RANGE | 1.3 (12%) | 0.0 (0%) | 1.3 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 0.3 (11%) | 1.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.0 | 89% | 6.5 pts | 39 pts |
| character | 4.7 | 1.0 | 79% | 4.8 pts | 23 pts |
| infantry | 16.7 | 4.7 | 80% | 7.7 pts | 128 pts |
| war machine | 8.0 | 5.3 | 58% | 19.2 pts | 153 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.3 | 2.7 | 4.5 |
| Charges that made contact a game | 3.3 | 1.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | - | 1.00 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.73 declared, 0.36 contact (22 units) | 0.35 declared, 0.17 contact (23 units) | 0.53 declared, 0.27 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (7 of 15) | 100% (2 of 2) | - | 53% (9 of 17) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | 75% (3 of 4) | 75% (3 of 4) | 57% (4 of 7) | 67% (10 of 15) |
| Infantry | 75% (9 of 12) | 50% (1 of 2) | - | 71% (10 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 67% (2 of 3); on the table 67% | 11% (2 of 18) | 45% | 44% (11 of 25) | 100% (2 of 2); 3.3 uses a game | 10% (1 of 10); 0.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 33% | 100% (8 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 6% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 75% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 20% (1) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 53% (8 of 15) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (13 of 37) | 0% (0 of 5) |
| Strategy | Support requests answered (helper made contact too) | 60% (3 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | - | 80% (4 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 147.3 | 312.3 |
| Movement | Fights charged into per game | 2.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +0 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +446 | 1 of 2, net +330 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +204 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (13 of 35) | 71% (10 of 14) |
| Shooting | Points destroyed by shooting units | 75.3 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (12 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 4.0 | - |
| Magic | Wounds caused by other spells | 3.0 | - |
| Magic | Points destroyed by magic (all spells) | 80.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 1.7 / 0.0 | 1.3 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 390.3 | 166.7 |
| Combat | Points run down | 38.0 | 41.0 |
| Combat | Net points per charged fight, damage counted | +194 | +59 |
| Combat | Net per 100 charger points, damage counted | +43.9 | +33.1 |
| Combat | First round won (charged fights) | 86% | 25% |
| Combat | Net points per charged fight | +168 | +10 |
| Combat | Net points per supported fight / lone fight | +350 / +137 | - / +10 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 7 | 3 of 4 |
| Game | Points lost | 341.0 | 947.7 |
| Game | VP from objectives | 833.3 | 336.7 |
| Game | Lone holders (player turns) | 0.5 | 1.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1095 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1289
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: chf-efd8067-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 24.7 | -79.7 | 0.0 | 82.0 | 20.3 | +69.8 | 0.0 | 361.0 |
| ASSAILMENT BY POINTS | 0.7 | +2.9 | 0.0 | 333.3 | - | - | - | - |
| BACKS UP THE FIGHT | 2.3 | +147.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | 0.7 | +1.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 36.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +36.6 | 73.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +13.1 | 46.7 | 0.0 | 0.7 | +4.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +3.0 | 0.0 | 0.0 | 1.0 | +71.4 | 0.0 | 116.7 |
| CHALLENGE IN THE FIGHT | - | - | - | - | 0.3 | -7.3 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.4 | 116.7 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1.0 | -181.6 | 131.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.7 | -474.3 | 0.0 | 174.3 | 18.3 | -1480.5 | 0.0 | 814.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 4.3 | +0.0 | 713.3 | 0.0 | 0.7 | +0.0 | 207.7 | 77.3 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 150.0 |
| CONVEYANCE SEARCH | 1.3 | +119.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 6.3 | -321.4 | 0.0 | 41.0 | 4.0 | -410.3 | 0.0 | 114.0 |
| DENIED BY THE FIGHT | 1.3 | -11.9 | 229.3 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | -7.2 | 0.0 | 0.0 | 7.0 | +48.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | +23.5 | 83.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +33.2 | 142.7 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.5 | 0.0 | 116.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 5.7 | +2004.9 | 0.0 | 42.0 |
| EXACT ROUND | 2.0 | +26.1 | 489.7 | 0.0 | 0.7 | +16.8 | 166.7 | 38.7 |
| FALL BACK GOOD ORDER | 2.7 | +3.7 | 314.0 | 0.0 | 1.3 | +0.0 | 341.0 | 77.3 |
| FALLS SHORT | - | - | - | - | 17.3 | +281.7 | 0.0 | 617.7 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.8 | 116.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.7 | +18.7 | 0.0 | 76.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 98.3 | +6975.5 | 1629.3 | 348.7 | 60.0 | +3128.8 | 341.0 | 1476.7 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 77.3 |
| FOCUS FIRE | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +330.2 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 6.0 | +377.2 | 1025.3 | 0.0 | 1.7 | +70.9 | 341.0 | 77.3 |
| FREED FROM HIS FIGHT | - | - | - | - | 5.0 | +0.0 | 0.0 | 96.0 |
| FRIEND CHARGES FIRST | 0.3 | -18.4 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.0 | -9.2 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -6.0 | 116.7 | 0.0 | - | - | - | - |
| GOAL WALK | 5.3 | +400.9 | 0.0 | 0.0 | 11.7 | +712.1 | 0.0 | 167.3 |
| GUN FIGURES | 0.7 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 41.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 5.3 | +0.0 | 0.0 | 144.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 133.3 | 13.0 | +0.0 | 0.0 | 678.7 |
| HIS CHARGE DENIED | 1.7 | +30.6 | 583.3 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -29.5 | 0.0 | 0.0 | 2.0 | -6.2 | 0.0 | 76.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 190.7 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 238.7 |
| HIS RANDOM MOVE | 10.3 | +0.0 | 0.0 | 82.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 41.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 28.7 | +772.2 | 0.0 | 348.7 | 36.7 | +787.7 | 0.0 | 999.3 |
| HIS SHOTS BY HIS RUN | 29.7 | +692.6 | 0.0 | 174.3 | 43.0 | +856.7 | 0.0 | 1210.0 |
| HIS TURN DENIED | 1.3 | +70.9 | 159.3 | 0.0 | 0.3 | +1.4 | 133.3 | 0.0 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 124.0 |
| HOLDER ASSIGNMENT | 9.7 | +669.3 | 0.0 | 0.0 | 4.3 | +288.3 | 0.0 | 86.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -146.6 | 442.0 | 0.0 | 1.3 | -14.9 | 174.3 | 38.7 |
| HUNT RESULT | - | - | - | - | 0.3 | +209.6 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +224.0 | 166.7 | 38.7 |
| IDLE COST | - | - | - | - | 9.3 | -131.7 | 0.0 | 164.0 |
| JOINT CHARGE NOW | 2.3 | -18.1 | 659.3 | 0.0 | 0.3 | -26.4 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +31.6 | 116.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 48.0 |
| LANE BY FIGURES | 1.3 | +134.5 | 0.0 | 0.0 | 0.7 | +21.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 257.0 | 456.3 | 5.0 | +0.0 | 0.0 | 944.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +5.8 | 38.0 | 0.0 | 0.3 | +7.2 | 133.3 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +0.7 | 317.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| LOST CHARGE | 0.7 | -3.0 | 153.3 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +6.7 | 0.0 | 133.3 | - | - | - | - |
| MANOEUVRE | 1.0 | -1.5 | 0.0 | 0.0 | 0.7 | +5.2 | 0.0 | 40.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +21.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.2 | 0.0 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +54.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +13.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -14.2 | 0.0 | 0.0 | 1.3 | +316.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| MAX FOR POSITIONING | 1.3 | +43.1 | 0.0 | 133.3 | 1.0 | +26.4 | 0.0 | 42.0 |
| MEETS IN TIME | 2.7 | +193.0 | 0.0 | 0.0 | 3.7 | +48.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +66.5 | 0.0 | 133.3 | 5.0 | +125.9 | 0.0 | 148.7 |
| MISSILES NEXT TURN | 5.3 | +40.1 | 0.0 | 133.3 | 6.0 | +98.5 | 0.0 | 148.7 |
| MOVE ORDER | 2.0 | +0.0 | 82.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 10.3 | +1197.8 | 0.0 | 0.0 | 4.3 | +217.3 | 0.0 | 238.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +286.3 | 0.0 | 0.0 | 4.3 | +183.2 | 0.0 | 86.0 |
| NEXT CHARGE BY LIST | 8.0 | +1050.7 | 0.0 | 0.0 | 2.3 | +84.6 | 0.0 | 161.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.6 | 0.0 | 48.0 |
| NO CHAFF EDGES | 4.0 | +136.0 | 222.0 | 0.0 | 1.7 | +25.6 | 500.0 | 38.7 |
| NO DOUBLE ROUNDS | 4.7 | -333.6 | 675.3 | 0.0 | 1.3 | -85.5 | 341.0 | 77.3 |
| NO LATE CUT | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +57.9 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -156.5 | 0.0 | 0.0 | 3.7 | -160.9 | 0.0 | 161.0 |
| ONE CHALLENGE TEST | 0.3 | -5.4 | 116.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 48.0 |
| ONE FIGHT FORMULA | 5.0 | -116.3 | 0.0 | 133.3 | 3.7 | -95.7 | 0.0 | 251.0 |
| ONE JOINT FIGURE | 1.7 | +120.6 | 583.3 | 0.0 | 0.3 | +14.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +1.1 | 0.0 | 0.0 | 1.3 | -3.3 | 0.0 | 38.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.0 | +9.8 | 148.7 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | 2.0 | +52.8 | 287.3 | 0.0 | 0.7 | +2.3 | 166.7 | 38.7 |
| PATHS CROSS | - | - | - | - | 0.3 | +20.7 | 0.0 | 0.0 |
| PLAN RESULT | 44.3 | +1611.3 | 572.3 | 474.3 | 30.3 | +390.5 | 384.3 | 1068.7 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +26.6 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -314.3 | 0.0 | 0.0 | 5.3 | -105.7 | 0.0 | 77.3 |
| PROMISE KNOWS THE FIGHT | 3.0 | -4.5 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -3.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 31.7 | +2938.7 | 134.7 | 0.0 | 15.0 | +2199.7 | 0.0 | 230.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +42.1 | 0.0 | 170.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +35.3 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 38.7 |
| REFORMS TO MEET IT | 2.7 | -103.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 48.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +10.4 | 0.0 | 0.0 |
| RISK BY ARC | 5.3 | +48.1 | 977.3 | 0.0 | 1.3 | +31.4 | 341.0 | 77.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| ROUNDS AFTER TERROR | 1.0 | -27.2 | 196.7 | 0.0 | - | - | - | - |
| RUN DOWN | 5.0 | -148.6 | 792.0 | 0.0 | 1.3 | -3.4 | 341.0 | 77.3 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| SECOND LOOK | 1.0 | +72.0 | 48.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +0.1 | 0.0 | 0.0 | 0.7 | -10.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +29.6 | 0.0 | 133.3 | 0.3 | +0.3 | 0.0 | 48.0 |
| SET-UP ANY TARGET | 0.3 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +8.9 | 134.7 | 0.0 | 1.3 | +8.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -38.1 | 202.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 17.0 | -348.8 | 0.0 | 348.7 | 19.7 | -392.3 | 0.0 | 582.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.0 | +417.0 | 0.0 | 133.3 | 3.3 | +103.3 | 0.0 | 121.3 |
| SPELL SETS UP CHARGE | 0.3 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.0 | +95.5 | 133.3 | 133.3 | 1.7 | +31.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 2.0 | +16.3 | 394.0 | 0.0 | 0.7 | -14.0 | 300.0 | 38.7 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 334.0 |
| STAND AND SHOOT | 1.0 | -15.1 | 112.7 | 0.0 | 1.0 | -3.5 | 174.3 | 38.7 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 52.7 | +0.0 | 604.0 | 0.0 | 14.7 | +0.0 | 0.0 | 384.0 |
| STAY WORTH | 34.0 | +115.8 | 306.0 | 133.3 | 5.3 | +45.5 | 0.0 | 36.7 |
| STOPS | - | - | - | - | 0.3 | +19.0 | 166.7 | 38.7 |
| STRIKE BY THE ODDS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +463.0 | 0.0 | 0.0 | 6.0 | +522.6 | 0.0 | 167.3 |
| SUPPORT WORKED OUT | 3.7 | +463.0 | 0.0 | 0.0 | 6.0 | +522.6 | 0.0 | 167.3 |
| SURE REACH TOGETHER | 3.7 | +25.9 | 0.0 | 133.3 | 0.7 | +3.0 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 3.7 | +18.9 | 846.3 | 0.0 | 0.3 | -0.2 | 166.7 | 38.7 |
| THE PROMISE ADDS | 0.3 | -3.2 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 40.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.0 | +0.0 | 0.0 | 174.3 | 27.3 | +0.0 | 0.0 | 659.7 |
| TIED UP BY THE SUM | 2.3 | +203.3 | 197.7 | 0.0 | 0.7 | +73.0 | 41.0 | 38.7 |
| TIME ON OUR SIDE | 39.3 | +452.2 | 38.0 | 307.7 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -63.6 | 333.3 | 77.3 |
| WHO FIGHTS | 1.0 | +0.4 | 154.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +83.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +40.5 | 166.7 | 38.7 |
| WHOLE FIGHT DANGER | 1.0 | -57.4 | 0.0 | 0.0 | 3.7 | -1001.0 | 0.0 | 469.3 |
| WHOLE FIGHT GAIN | 1.7 | +152.7 | 583.3 | 0.0 | 0.3 | +26.4 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +258.6 | 78.7 | 174.3 | 3.7 | +181.0 | 0.0 | 404.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.7 | +204.1 | 0.0 | 167.3 |

### Rule changes: chf-efd8067-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 135 | 135 | 98 | 32.67 | +570 | +5.8 |
| HIS SHOT LIST | 196 | 186 | 44 | 14.67 | +545 | +12.4 |
| HIS SHOTS BY HIS RUN | 218 | 209 | 39 | 13.00 | +543 | +13.9 |
| HOLDER ASSIGNMENT | 42 | 42 | 37 | 12.33 | +2575 | +69.6 |
| FIVE ACTION | 475 | 460 | 27 | 9.00 | +1321 | +48.9 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 41 | 41 | 24 | 8.00 | +227 | +9.5 |
| QUARTER ODDS | 140 | 136 | 24 | 8.00 | +2574 | +107.3 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -952 | -47.6 |
| MOVE TO CHARGE COMPUTED | 44 | 35 | 19 | 6.33 | +837 | +44.1 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 18 | 6.00 | -1260 | -70.0 |
| SHOT RISK POINTS | 110 | 102 | 18 | 6.00 | +542 | +30.1 |
| NEXT CHARGE BY LIST | 31 | 28 | 15 | 5.00 | +783 | +52.2 |
| NO CHAFF EDGES | 17 | 17 | 14 | 4.67 | +460 | +32.8 |
| TIME ON OUR SIDE | 118 | 105 | 14 | 4.67 | +78 | +5.5 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 96 | 89 | 12 | 4.00 | +1096 | +91.3 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOUR ROUNDS | 23 | 23 | 10 | 3.33 | +296 | +29.6 |
| EVASIVE BY THE ODDS | 17 | 17 | 9 | 3.00 | +3620 | +402.2 |
| GOAL WALK | 51 | 51 | 8 | 2.67 | +616 | +77.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | -133 | -16.7 |
| TIED UP BY THE SUM | 9 | 9 | 8 | 2.67 | +216 | +27.0 |
| STAY WORTH | 118 | 106 | 7 | 2.33 | +106 | +15.1 |
| SUPPORT ADDS | 29 | 27 | 7 | 2.33 | +518 | +74.1 |
| SUPPORT WORKED OUT | 29 | 27 | 7 | 2.33 | +518 | +74.1 |
| FALLS SHORT | 52 | 46 | 6 | 2.00 | +30 | +4.9 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +466 | +77.8 |
| MEETS IN TIME | 19 | 19 | 6 | 2.00 | +162 | +27.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +223 | +44.6 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 5 | 1.67 | +126 | +25.3 |
| RISK BY ARC | 20 | 20 | 5 | 1.67 | +155 | +31.0 |
| WHOLE FIGHT GAIN | 6 | 6 | 5 | 1.67 | +170 | +33.9 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +25 | +6.3 |
| ONE JOINT FIGURE | 6 | 6 | 4 | 1.33 | +107 | +26.7 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +991 | +330.2 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +303 | +101.0 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +5 | +1.7 |
| MISSILES IN THE MOVE | 28 | 20 | 3 | 1.00 | +16 | +5.4 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +464 | +154.6 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +216 | +72.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +8 | +2.7 |
| SURE REACH TOGETHER | 13 | 11 | 3 | 1.00 | +19 | +6.2 |
| WHOLE FIGHT REACTION | 18 | 18 | 3 | 1.00 | +146 | +48.7 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.4 |
| BACKS UP THE FIGHT | 7 | 5 | 2 | 0.67 | +37 | +18.4 |
| CHARGE NOW FIRST | 15 | 15 | 2 | 0.67 | -66 | -33.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.67 | +56 | +28.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 6 | 6 | 2 | 0.67 | +17 | +8.3 |
| IDLE COST | 28 | 15 | 2 | 0.67 | +6 | +3.1 |
| MANOEUVRE | 5 | 5 | 2 | 0.67 | +16 | +7.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +44 | +22.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -39 | -19.7 |
| NEARER NOT NEEDED | 30 | 28 | 2 | 0.67 | +101 | +50.5 |
| PROMISE KNOWS THE FIGHT | 11 | 7 | 2 | 0.67 | -13 | -6.7 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +31 | +15.7 |
| SET UP BY THE SET | 5 | 5 | 2 | 0.67 | +10 | +4.8 |
| SHOTS AFTER THE MOVES | 16 | 16 | 2 | 0.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -4 | -4.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| COVER ONCE | 31 | 19 | 1 | 0.33 | +3 | +3.0 |
| DUEL STOPS AT THE KILL | 2 | 2 | 1 | 0.33 | +8 | +8.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +34 | +34.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +18 | +18.5 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +57 | +56.6 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +95 | +94.8 |
| MARCH CHECK | 4 | 4 | 1 | 0.33 | +48 | +47.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +65 | +65.1 |
| ONE OBJECTIVE FORMULA | 16 | 12 | 1 | 0.33 | +3 | +3.0 |
| OPENS UP IN FULL | 4 | 4 | 1 | 0.33 | +8 | +8.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +62 | +62.1 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +80 | +79.8 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -5 | -5.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 67 | 52 | 1 | 0.33 | +2 | +1.6 |
| SPELLS IN THE FIGHT | 8 | 8 | 1 | 0.33 | +3 | +3.1 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE FIGHT MOVES | 12 | 12 | 1 | 0.33 | +8 | +8.5 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +3 | +3.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +202 | +202.3 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +102 | +102.4 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 31 | 31 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 12 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 16 | 11 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 63 | 63 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 17 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 224 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 42 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 202 | 200 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 220 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 9 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 14 | 14 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.33 | 2.67 | 59.6 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 2.00 | 70.0 |
| JOB FIRST | gate | 2.33 | 3.33 | 43.0 |
| HOLDER ASSIGNMENT | rule | 1.67 | - | 15.7 |
| JOINT CHARGE NOW | rule | 1.33 | 0.33 | 71.4 |
| CHARGE NOW FIRST | rule | 0.67 | - | 33.1 |
| MARCH OF THE TABLE | rule | - | 0.67 | 19.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 6.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 169.8 |
| CHAFF PASSED | rule | 0.33 | - | 4.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 3.1 |
| NO REASON | gate | - | 0.33 | 19.1 |
| REFUSING RETIRES | rule | - | 0.33 | 5.0 |
| RULE SWITCHED OFF | gate | 0.33 | - | 33.0 |

### Plans: chf-efd8067-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 6.0 | 67% | 781 | 939 | 120% |
| Mine | move | 28.3 | 98% | 2034 | 0 | 0% |
| Mine | shoot | 10.0 | 67% | 374 | 672 | 180% |
| Opponent | charge | 1.3 | 100% | 119 | 390 | 329% |
| Opponent | join | 1.7 | 80% | 73 | 0 | 0% |
| Opponent | move | 25.7 | 91% | 1435 | 0 | 0% |
| Opponent | shoot | 1.7 | 0% | 32 | 0 | 0% |

### Packages: hunt the guns, chf-efd8067-p8

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 672 | 629 | 100% | 18 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 672 | 629 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: chf-efd8067-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 77 (8) | 77 | 0 | 30 | 0% | 2.5 | 69 (3) | 80 (5) | - | 95 (2) | 71 (6) |
| Mine | Clean-up | 2 | 98 (2) | 0 | 98 | 50 | 50% | 2.0 | - | 98 (2) | - | 98 (2) | - |
| Mine | Fast Hammer | 8 | 64 (8) | 21 | 43 | 0 | 75% | 3.5 | 47 (4) | 82 (4) | - | 63 (3) | 65 (5) |
| Mine | Holder | 2 | 57 (2) | 25 | 33 | 0 | 50% | 1.0 | 57 (2) | - | - | 57 (2) | - |
| Mine | Shooter | 5 | 35 (5) | 35 | 0 | 0 | 0% | 1.0 | 47 (3) | 16 (2) | - | 43 (4) | 0 (1) |
| Mine | War machine | 4 | 20 (4) | 20 | 0 | 0 | 0% | 1.0 | 0 (2) | 39 (2) | - | 0 (2) | 39 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 21 (9) | 21 | 0 | 50 | 0% | 2.8 | 0 (5) | 41 (4) | - | 0 (4) | 36 (5) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 100% | - | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 21 (3) | 0 | 21 | 36 | 0% | 2.7 | 21 (3) | - | - | 95 (1) | 0 (2) |
| Opponent | Hammer | 8 | 13 (8) | 13 | 0 | 35 | 38% | 3.6 | 0 (4) | 36 (3) | 0 (1) | 0 (4) | 31 (4) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Shooter | 3 | 16 (3) | 0 | 16 | 100 | 0% | 1.0 | - | 53 (1) | 0 (2) | - | 16 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |

### Charged fights: chf-efd8067-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 156 | 524 | 2.3 | 1.4 | 225 | 57 | +168 | 3 of 7 | 6 of 7 | +350 | +137 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 500 | 2.0 | 1.0 | 250 | 230 | +20 | 2 of 2 | 0 of 2 | - | +20 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 0 | 167 | 1.3 | 1.0 | 125 | 115 | +10 | 3 of 4 | 1 of 4 | - | +10 |

### Effective charges: chf-efd8067-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 1 (net +0) | 0 | 1 (net +446) | 2 (net +87) | 0 | 2 (net +204) | 1 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 1 (net +330) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | +0 | 79 | 229 | -149 | -37.4 |
| Mine | Effective (55-75%) | 1 | 489 | 201 | +446 | 446 | 0 | +446 | +91.2 |
| Mine | 76-89% | 2 | 658 | 230 | +87 | 499 | 230 | +269 | +40.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 199 | 142 | +204 | 204 | 15 | +189 | +95.2 |
| Mine | No odds | 1 | 489 | 144 | +144 | 144 | 0 | +144 | +29.4 |
| Mine | All fights | 7 | 442 | 205 | +168 | 297 | 103 | +194 | +43.9 |
| Opponent | Long shot (under 50%) | 1 | 125 | 342 | +0 | 57 | 18 | +39 | +31.3 |
| Opponent | Effective (55-75%) | 1 | 116 | 500 | +330 | 500 | 170 | +330 | +284.5 |
| Opponent | No odds | 2 | 235 | 360 | -145 | 78 | 145 | -67 | -28.4 |
| Opponent | All fights | 4 | 178 | 390 | +10 | 178 | 119 | +59 | +33.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p8 | move | 19 | 2 (11%) | 2 (11%) | 3 (16%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

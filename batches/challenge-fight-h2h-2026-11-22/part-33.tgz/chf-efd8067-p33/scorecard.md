# Doctrine scorecard: chf-efd8067-p33

### Scorecard: chf-efd8067-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 4 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 141 |
| L1723 | 1 | 1 | Opponent | yes | 1 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.0 | 2.5 | 2.7 | 0.7 | 0.3 | 0.0 | 0.0 | 80.3 |
| **Average** | | | Opponent | 67% | 1.0 | 2.3 | 5.7 | 2.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: chf-efd8067-p33

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 89% (8 of 9); on the table 89% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (3 of 6); on the table 50% | 50% (3 of 6); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 75% (12 of 16); on the table 75% | 78% (14 of 18); on the table 78% |
| Magic missiles tried each own turn | 50%+ | - | 67% (12 of 18) | 67% (12 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (6 of 9) | 67% (6 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 32% (1910 of 6000) | 38% (2307 of 5999) | 35% (4217 of 11999) |
|   infantry points that never fought | lower | 71% (947 of 1332) | 79% (660 of 834) | 74% (1607 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (14 of 20) | 47% (8 of 17) | 59% (22 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (3614 of 5135) | 35% (1611 of 4600) | 54% (5225 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (50%) | 1.0 (50%) |
| IN COMBAT: engaged in combat | - | 0.3 (17%) | 0.3 (17%) |
| GONE: slain | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 1.3 | 4.0 | 0.0 | 3.0 |
| not cast | 6.0 | 2.3 | 0.7 | 2.0 | 2.0 | 25.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 1.0 (50%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (6%) | 0.3 (14%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (6%) | 0.3 (14%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 3.3 (13%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (78%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.7 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 49% (36 of 74) | 62% (23 of 37) | 53% (59 of 111) |
|   cavalry | 40% (4 of 10) | 75% (6 of 8) | 56% (10 of 18) |
|   character | 30% (3 of 10) | 0% (0 of 11) | 14% (3 of 21) |
|   chariot | 17% (1 of 6) | - | 17% (1 of 6) |
|   infantry | 62% (18 of 29) | 94% (17 of 18) | 74% (35 of 47) |
|   monster | 43% (3 of 7) | - | 43% (3 of 7) |
|   war machine | 58% (7 of 12) | - | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (21%) | 0.7 (14%) | 3.3 (19%) |
| CHARGED: it charged | 2.3 (18%) | 2.0 (43%) | 4.3 (25%) |
| IN COMBAT: it fought this turn or the last | 2.0 (16%) | 0.0 (0%) | 2.0 (12%) |
| MOVED: a war machine that moved | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 2.3 (18%) | 0.7 (14%) | 3.0 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (8%) | 0.3 (7%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (13%) | 1.0 (21%) | 2.7 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.0 | 73% | 6.6 pts | 24 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 18.3 | 5.0 | 82% | 5.3 pts | 97 pts |
| monster | 1.0 | 0.3 | 67% | 16.3 pts | 16 pts |
| war machine | 2.3 | 0.7 | 86% | 5.4 pts | 12 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 7.3 | 6.0 |
| Charges that made contact a game | 4.7 | 5.0 | 4.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 1.50 declared, 1.00 contact (2 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.59 contact (22 units) | 0.76 declared, 0.52 contact (25 units) | 0.68 declared, 0.55 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (2 of 2) | 50% (1 of 2) | 57% (4 of 7) |
| Character in a unit | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 33% (3 of 9) | 46% (6 of 13) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 0% | 57% (4 of 7) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 64% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | - | - | 31% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 33% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 75% (9 of 12); on the table 75% | 67% (12 of 18) | 41% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 70% (7) | 70% (7) | 70% (14) |
| ...free all their last turn and able to turn (per game) | 1.67 | 1.67 | 3.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 1.33 | 2.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 73% (8 of 11) | 42% (8 of 19) |
| Strategy | Shoot objectives carried out (shot that target) | 15% (3 of 20) | 0% (0 of 7) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 88% (7 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.0 |
| Movement | Points that never moved of their own | 80.3 | 0.0 |
| Movement | Fights charged into per game | 4.3 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 10, net +0 | 2 of 11, net -25 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 10, net +30 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 10, net +63 | 2 of 11, net +129 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 10, net +54 | 3 of 11, net +493 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (19 of 33) | 62% (15 of 24) |
| Shooting | Points destroyed by shooting units | 0.0 | 24.0 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (2 of 7) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 6) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Wounds caused by other spells | 0.3 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 53.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.7 / 0.3 / 0.0 | 2.7 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 241.7 | 642.7 |
| Combat | Points run down | 0.0 | 173.7 |
| Combat | Net points per charged fight, damage counted | +12 | +179 |
| Combat | Net per 100 charger points, damage counted | +3.7 | +56.7 |
| Combat | First round won (charged fights) | 77% | 69% |
| Combat | Net points per charged fight | +18 | +165 |
| Combat | Net points per supported fight / lone fight | -395 / +52 | +150 / +167 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 13 | 3 of 13 |
| Game | Points lost | 965.3 | 261.7 |
| Game | VP from objectives | 430.0 | 806.7 |
| Game | Lone holders (player turns) | 3.0 | 1.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1193 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1227
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +45.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +28.7 | 0.0 | 0.0 |
| ARMY TABLE | 17.3 | +128.9 | 0.0 | 293.7 | 26.3 | +379.8 | 0.0 | 160.7 |
| ASSAILMENT BY POINTS | - | - | - | - | 1.3 | +5.3 | 0.0 | 63.3 |
| BACKS UP THE FIGHT | - | - | - | - | 2.7 | +99.0 | 0.0 | 89.3 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +5.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -12.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.3 | +44.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -55.0 | 45.0 | 0.0 |
| CAST JOB | 1.7 | +12.5 | 0.0 | 0.0 | 1.0 | +14.4 | 26.7 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 131.7 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +105.1 | 0.0 | 15.0 |
| CHAFF PASSED | 1.0 | -1.2 | 0.0 | 155.7 | 0.3 | -0.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +29.5 | 0.0 | 119.3 | 0.3 | +9.1 | 0.0 | 0.0 |
| CHALLENGE IN THE FIGHT | 1.0 | -16.3 | 0.0 | 453.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.7 | -26.9 | 0.0 | 321.3 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1.3 | +22.5 | 0.0 | 453.0 | 0.7 | -2.9 | 90.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -418.0 | 0.0 | 654.3 | 9.3 | -191.2 | 0.0 | 66.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 47.0 | 0.0 | 3.7 | +0.0 | 450.3 | 0.0 |
| CLEAR LANE AHEAD | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 84.0 | 24.0 | +0.0 | 0.0 | 151.7 |
| COMBAT PIVOT | 1.0 | +0.0 | 45.0 | 131.7 | 0.3 | +0.0 | 160.7 | 0.0 |
| COVER ONCE | 18.3 | -760.9 | 0.0 | 265.3 | 8.3 | -544.3 | 0.0 | 20.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 0.7 | -11.4 | 90.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -35.2 | 0.0 | 0.0 | 6.7 | +23.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -75.7 | 90.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.2 | 27.7 | 0.0 |
| EXACT ROUND | 2.7 | +13.3 | 96.3 | 26.7 | 5.7 | +32.2 | 620.3 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +0.0 | 90.3 | 453.0 | 6.0 | +24.5 | 636.7 | 16.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.0 | +291.9 | 0.0 | 139.0 |
| FEATURE BUFFS | 2.7 | +64.5 | 0.0 | 0.0 | 1.0 | +23.9 | 0.0 | 22.0 |
| FIGHT TO THE END | 2.0 | +72.8 | 25.0 | 292.3 | 0.3 | +0.3 | 42.0 | 0.0 |
| FIVE ACTION | 80.0 | +4616.2 | 223.3 | 1730.0 | 93.7 | +5940.8 | 847.0 | 590.7 |
| FLANK NOT WEIGHED | 13.3 | +0.0 | 0.0 | 382.0 | 4.7 | +0.0 | 0.0 | 71.7 |
| FOLLOW UP WEIGHED | 0.7 | +97.4 | 0.0 | 0.0 | 2.3 | +222.0 | 0.0 | 15.0 |
| FOUR ROUNDS | 4.3 | +393.2 | 138.3 | 479.7 | 7.3 | +314.5 | 738.0 | 16.7 |
| FREED FROM HIS FIGHT | 12.3 | +0.0 | 0.0 | 431.7 | 3.0 | +0.0 | 0.0 | 15.0 |
| FRIEND CHARGES FIRST | 0.3 | -6.3 | 0.0 | 0.0 | 0.3 | -15.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -11.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -28.5 | 23.3 | 160.7 | 1.0 | -4.6 | 58.3 | 16.7 |
| GOAL WALK | 11.7 | +942.4 | 0.0 | 116.7 | 3.3 | +299.3 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 2.0 | +13.4 | 0.0 | 453.0 | 2.3 | -7.2 | 184.7 | 16.7 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 7.7 | +0.0 | 0.0 | 248.3 | 2.0 | +0.0 | 0.0 | 15.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 30.0 | 26.7 | 0.7 | +0.0 | 0.0 | 16.7 |
| HELPER UNSEEN | 0.7 | +0.0 | 30.0 | 26.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 522.7 | 6.0 | +0.0 | 0.0 | 66.7 |
| HIS CHARGE DENIED | 0.7 | +36.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 234.0 | 9.3 | +0.0 | 0.0 | 58.0 |
| HIS LEGAL MOVES | 11.3 | +0.0 | 0.0 | 179.7 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -15.5 | 0.0 | 179.7 | 6.3 | -81.8 | 0.0 | 136.7 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 53.3 | 3.3 | +0.0 | 0.0 | 36.0 |
| HIS OWN BEST MOVE | 14.7 | +0.0 | 0.0 | 179.7 | 11.7 | +0.0 | 0.0 | 23.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.0 | +234.7 | 0.0 | 698.7 | 42.3 | +1213.8 | 0.0 | 299.3 |
| HIS SHOTS BY HIS RUN | 17.3 | +142.8 | 0.0 | 544.7 | 36.3 | +544.6 | 0.0 | 339.0 |
| HIS TURN DENIED | 0.3 | +0.7 | 0.0 | 0.0 | 2.3 | +30.5 | 259.0 | 0.0 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 216.0 | 14.0 | +0.0 | 0.0 | 108.0 |
| HOLDER ASSIGNMENT | 9.3 | +671.5 | 0.0 | 135.7 | 9.0 | +648.3 | 0.0 | 64.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -174.3 | 138.3 | 479.7 | 6.3 | -226.0 | 738.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.0 | -191.6 | 0.0 | 40.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +113.4 | 0.0 | 292.3 | 1.7 | +75.2 | 132.0 | 16.7 |
| JOINT KNOWS CHALLENGE | 0.7 | -21.5 | 0.0 | 292.3 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.3 | 0.0 | 0.0 | 1.0 | +42.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 35.0 | 1169.0 | 9.0 | +0.0 | 1182.7 | 175.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -13.8 | 0.0 | 453.0 | 4.0 | +8.2 | 358.7 | 16.7 |
| LOST CHARGE | 0.3 | -0.9 | 0.0 | 160.7 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +1.8 | 0.0 | 27.7 | 2.3 | +17.3 | 0.0 | 15.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 42.0 | 1.0 | +21.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +22.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +46.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +15.4 | 0.0 | 27.7 | 6.7 | +147.9 | 0.0 | 55.0 |
| MEETS IN TIME | 4.0 | +240.1 | 0.0 | 0.0 | 4.3 | +151.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +34.6 | 0.0 | 131.7 | 3.7 | +25.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +40.9 | 0.0 | 131.7 | 4.3 | +28.6 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 22.0 | 22.0 |
| MOVE TO CHARGE COMPUTED | 10.7 | +543.1 | 0.0 | 241.7 | 13.0 | +977.9 | 0.0 | 112.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.0 | +426.1 | 0.0 | 208.3 | 6.3 | +254.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.3 | +398.9 | 0.0 | 241.7 | 10.3 | +735.5 | 24.0 | 38.3 |
| NO CHAFF EDGES | 2.7 | +78.1 | 62.0 | 58.3 | 4.0 | +131.5 | 333.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -152.8 | 123.3 | 348.0 | 5.3 | -181.6 | 487.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 131.7 | - | - | - | - |
| OFF BEST | 4.7 | -195.1 | 23.3 | 53.3 | 3.0 | -65.1 | 24.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -115.0 | 0.0 | 150.0 | 6.3 | -114.6 | 0.0 | 40.0 |
| ONE JOINT FIGURE | 0.3 | +0.2 | 15.0 | 26.7 | 1.7 | +34.3 | 90.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 5.7 | -11.0 | 0.0 | 135.7 | 4.3 | -158.4 | 0.0 | 42.0 |
| ONE PROMISE A TARGET | 1.3 | -57.7 | 0.0 | 0.0 | 1.7 | -53.8 | 24.0 | 38.3 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.7 | +31.8 | 42.0 | 0.0 | 2.7 | +82.7 | 309.0 | 0.0 |
| OVERRUNS AWAY | 2.0 | +17.4 | 113.3 | 26.7 | 1.3 | +19.1 | 87.0 | 0.0 |
| PATHS CROSS | 0.3 | +7.2 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +275.3 | 115.0 | 1628.3 | 47.3 | +583.2 | 516.3 | 403.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 13.7 | -316.4 | 0.0 | 183.3 | 10.3 | -257.2 | 0.0 | 74.3 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.7 | +0.0 | 0.0 | 241.7 | 3.7 | +0.0 | 0.0 | 89.3 |
| PROMISE READS THE TABLE | 1.0 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.3 | +1657.8 | 18.0 | 399.0 | 22.7 | +2756.0 | 263.0 | 232.7 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +38.6 | 0.0 | 26.7 | 4.7 | +420.2 | 0.0 | 62.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 2.7 | +0.0 | 0.0 | 35.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +38.7 | 58.3 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -90.5 | 0.0 | 0.0 | 3.3 | -76.3 | 0.0 | 23.3 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 292.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +22.9 | 0.0 | 26.7 | - | - | - | - |
| RISK BY ARC | 4.0 | +64.3 | 138.3 | 319.0 | 5.7 | -64.7 | 445.3 | 16.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -48.6 | 414.0 | 16.7 |
| RUN DOWN | - | - | - | - | 5.3 | -46.8 | 503.0 | 16.7 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -47.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +3.5 | 0.0 | 0.0 | 0.3 | +4.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +10.6 | 23.3 | 0.0 | 1.0 | +160.8 | 129.3 | 0.0 |
| SELF MOVE SPELL | 1.7 | +164.1 | 0.0 | 263.3 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -1.3 | 0.0 | 53.3 | 1.0 | -19.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | -15.0 | 0.0 | 53.3 | 4.7 | +32.3 | 0.0 | 46.7 |
| SET UP TOGETHER | 1.0 | +1.8 | 0.0 | 27.7 | 2.7 | +17.5 | 0.0 | 30.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 72.7 | 3.3 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +49.6 | 20.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.9 | 58.3 | 0.0 |
| SHOT RISK POINTS | 9.7 | -83.5 | 0.0 | 291.3 | 30.3 | -51.6 | 0.0 | 316.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +269.6 | 0.0 | 288.3 | 8.3 | +53.2 | 0.0 | 84.0 |
| SPELL WORTH | 1.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.7 | -6.3 | 0.0 | 0.0 | 0.3 | +7.1 | 160.7 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 100.3 | 8.7 | +0.0 | 0.0 | 40.0 |
| STAND AND SHOOT | 0.3 | -0.6 | 22.0 | 0.0 | 1.7 | -26.2 | 182.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 30.3 | +0.0 | 85.0 | 518.7 | 18.3 | +0.0 | 109.0 | 106.7 |
| STAY WORTH | 7.0 | +64.5 | 0.0 | 27.7 | 5.7 | +24.0 | 24.0 | 22.0 |
| STRIKE BY THE ODDS | 0.7 | +15.4 | 0.0 | 292.3 | 0.7 | +9.5 | 187.3 | 15.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -9.2 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +59.9 | 0.0 | 0.0 | 6.7 | +364.2 | 0.0 | 66.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 40.0 | 26.7 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +59.9 | 0.0 | 0.0 | 6.7 | +364.2 | 0.0 | 66.0 |
| SURE REACH TOGETHER | 0.3 | +2.9 | 0.0 | 0.0 | 2.3 | +19.9 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 26.7 | 2.7 | +0.0 | 0.0 | 15.0 |
| THE FIGHT MOVES | 2.3 | -0.4 | 40.0 | 348.0 | 2.3 | +37.7 | 260.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 65.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.0 | +0.0 | 0.0 | 601.7 | 46.7 | +0.0 | 0.0 | 287.0 |
| TIED UP BY THE SUM | 1.0 | +105.2 | 65.3 | 0.0 | 3.0 | +307.5 | 327.0 | 0.0 |
| TIME ON OUR SIDE | 36.3 | +518.3 | 0.0 | 790.0 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -7.1 | 30.0 | 0.0 | 1.3 | -77.8 | 321.3 | 0.0 |
| WHO FIGHTS | 0.7 | -4.4 | 15.0 | 26.7 | 1.0 | +15.7 | 42.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +51.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -2.1 | 15.0 | 0.0 | 0.7 | +53.1 | 160.7 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -294.3 | 0.0 | 416.3 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.7 | +53.6 | 0.0 | 292.3 | 1.3 | +43.4 | 90.0 | 16.7 |
| WHOLE FIGHT REACTION | 2.7 | +168.0 | 0.0 | 183.3 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.7 | +51.5 | 0.0 | 0.0 |

### Rule changes: chf-efd8067-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 131 | 131 | 97 | 32.33 | +1636 | +16.9 |
| HOLDER ASSIGNMENT | 55 | 55 | 51 | 17.00 | +2870 | +56.3 |
| LEGAL CHARGES ONLY | 48 | 48 | 48 | 16.00 | +0 | +0.0 |
| HIS SHOT LIST | 223 | 211 | 34 | 11.33 | +226 | +6.6 |
| PROMISE BY ITS OWN SUM | 72 | 72 | 29 | 9.67 | -1721 | -59.3 |
| FIVE ACTION | 521 | 492 | 28 | 9.33 | +1160 | +41.4 |
| HIS SHOTS BY HIS RUN | 161 | 158 | 26 | 8.67 | +130 | +5.0 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 71 | 59 | 23 | 7.67 | +606 | +26.4 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -781 | -33.9 |
| NEXT CHARGE BY LIST | 53 | 48 | 19 | 6.33 | +476 | +25.1 |
| DEPLOY BY FIGURES | 42 | 42 | 17 | 5.67 | +216 | +12.7 |
| FOUR ROUNDS | 35 | 31 | 15 | 5.00 | +788 | +52.5 |
| MEETS IN TIME | 25 | 25 | 15 | 5.00 | +893 | +59.5 |
| NO CHAFF EDGES | 20 | 19 | 15 | 5.00 | +387 | +25.8 |
| QUARTER ODDS | 120 | 114 | 15 | 5.00 | +1003 | +66.9 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOT RISK POINTS | 120 | 116 | 12 | 4.00 | +83 | +6.9 |
| COVER ONCE | 80 | 52 | 11 | 3.67 | +242 | +22.0 |
| MAX FOR POSITIONING | 25 | 25 | 10 | 3.33 | +43 | +4.3 |
| SET UP BY THE SET | 22 | 20 | 10 | 3.33 | +169 | +16.9 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +958 | +106.4 |
| GOAL WALK | 45 | 45 | 9 | 3.00 | +614 | +68.2 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 3.00 | -334 | -37.1 |
| TIED UP BY THE SUM | 12 | 10 | 9 | 3.00 | +334 | +37.1 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 2.67 | +0 | +0.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 54 | 42 | 7 | 2.33 | +29 | +4.2 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +566 | +80.8 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +236 | +33.7 |
| SUPPORT ADDS | 26 | 23 | 7 | 2.33 | +236 | +33.8 |
| SUPPORT WORKED OUT | 26 | 23 | 7 | 2.33 | +236 | +33.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 6 | 2.00 | +32 | +5.4 |
| CHARGE LOSSES | 61 | 61 | 5 | 1.67 | +157 | +31.4 |
| CHARGE NOW FIRST | 15 | 15 | 5 | 1.67 | -136 | -27.2 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +374 | +74.8 |
| OPENS UP IN FULL | 10 | 9 | 5 | 1.67 | +101 | +20.2 |
| SECOND LOOK | 5 | 5 | 5 | 1.67 | +514 | +102.8 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +0 | +0.1 |
| TIME ON OUR SIDE | 109 | 79 | 5 | 1.67 | +49 | +9.7 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +16 | +4.0 |
| BACKS UP THE FIGHT | 8 | 5 | 4 | 1.33 | +21 | +5.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -5 | -1.2 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| REDIRECT COUNTER | 18 | 17 | 4 | 1.33 | +299 | +74.7 |
| RISK BY ARC | 29 | 25 | 4 | 1.33 | +146 | +36.4 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +75 | +18.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +116 | +38.6 |
| FACES WHAT IT FOLLOWS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NEARER NOT NEEDED | 52 | 49 | 3 | 1.00 | +80 | +26.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +21 | +7.0 |
| SURE REACH TOGETHER | 8 | 8 | 3 | 1.00 | +8 | +2.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +135 | +67.6 |
| FALLS SHORT | 63 | 50 | 2 | 0.67 | +3 | +1.6 |
| FIGHT TO THE END | 7 | 6 | 2 | 0.67 | +156 | +78.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +63 | +31.4 |
| NO DOUBLE ROUNDS | 27 | 24 | 2 | 0.67 | +85 | +42.7 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +301 | +150.7 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +69 | +34.3 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +24 | +12.2 |
| SHOTS IN THE MOVE | 61 | 38 | 2 | 0.67 | +9 | +4.4 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -8 | -4.2 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 6 | 6 | 2 | 0.67 | +53 | +26.3 |
| WHOLE FIGHT GAIN | 6 | 5 | 2 | 0.67 | +148 | +73.9 |
| WOUNDS ON THE RANKS | 8 | 8 | 2 | 0.67 | +56 | +28.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +86 | +86.0 |
| CANNON PLANNED TARGET | 7 | 7 | 1 | 0.33 | -26 | -26.4 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -165 | -164.9 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -83 | -83.1 |
| EXACT ROUND | 25 | 22 | 1 | 0.33 | +22 | +22.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +19 | +19.3 |
| HIS MOVE AND SHOT | 26 | 26 | 1 | 0.33 | +5 | +5.1 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +6 | +6.5 |
| MISSILES IN THE MOVE | 19 | 13 | 1 | 0.33 | +26 | +25.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 40 | 21 | 1 | 0.33 | +17 | +17.1 |
| ONE JOINT FIGURE | 6 | 5 | 1 | 0.33 | +58 | +57.9 |
| OVERRUNS AWAY | 10 | 9 | 1 | 0.33 | +1 | +1.3 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -5 | -4.8 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -3 | -3.2 |
| ROUNDS AFTER TERROR | 12 | 10 | 1 | 0.33 | +4 | +4.1 |
| RUN DOWN | 16 | 14 | 1 | 0.33 | +4 | +4.1 |
| THE FIGHT MOVES | 14 | 12 | 1 | 0.33 | +58 | +57.9 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -5 | -4.8 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +148 | +148.4 |
| WHOLE FIGHT | 3 | 3 | 1 | 0.33 | +48 | +48.5 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHALLENGE IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 6 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 105 | 100 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 27 | 23 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 46 | 38 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 13 | 11 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 29 | 26 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 55 | 51 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 55 | 51 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 79 | 72 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 8 | 6 | 0 | 0.00 | - | - |
| HOLD ODDS | 86 | 86 | 0 | 0.00 | - | - |
| HONEST WORTH | 32 | 28 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 18 | 15 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 30 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 255 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 16 | 10 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 18 | 18 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 11 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 27 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 16 | 16 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 45 | 38 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 146 | 137 | 0 | 0.00 | - | - |
| STAY WORTH | 38 | 28 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 245 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 8 | 8 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 6.00 | 3.67 | 59.3 |
| JOB FIRST | gate | 3.00 | 2.67 | 34.6 |
| ARMY TABLE | rule | 2.00 | 3.00 | 28.2 |
| ONE PROMISE A TARGET | rule | 1.00 | 1.67 | 41.8 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 27.2 |
| NO REASON | gate | 1.33 | - | 31.1 |
| CHAFF PASSED | rule | 0.33 | 0.33 | 2.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 50.0 |
| SUPPORT NARROWED | rule | 0.67 | - | 4.2 |
| AFTERMATH BAND | gate | 0.33 | - | 1.4 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 26.4 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 164.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 83.1 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 8.5 |
| PATHS CROSS | rule | - | 0.33 | 6.0 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 4.8 |
| REFUSING RETIRES | rule | 0.33 | - | 3.2 |
| RULE SWITCHED OFF | gate | - | 0.33 | 67.6 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 4.8 |

### Plans: chf-efd8067-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 73% | 408 | 188 | 46% |
| Mine | move | 28.3 | 94% | 1307 | 0 | 0% |
| Mine | shoot | 5.7 | 35% | 283 | 88 | 31% |
| Opponent | charge | 6.3 | 68% | 993 | 506 | 51% |
| Opponent | join | 2.3 | 100% | 91 | 0 | 0% |
| Opponent | move | 35.7 | 95% | 1346 | 0 | 0% |
| Opponent | shoot | 1.3 | 50% | 82 | 78 | 94% |
| Opponent | support | 1.7 | 100% | 0 | 0 | - |

### Battle groups: chf-efd8067-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 14% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 28 (2) | 28 | 0 | 100 | 0% | 2.0 | 28 (2) | - | - | - | 28 (2) |
| Mine | Character | 8 | 11 (8) | 11 | 0 | 51 | 12% | 3.0 | 18 (5) | 0 (3) | - | 14 (7) | 0 (1) |
| Mine | Clean-up | 1 | 125 (1) | 125 | 0 | 0 | 0% | 4.0 | 125 (1) | - | - | 125 (1) | - |
| Mine | Fast Hammer | 4 | 58 (4) | 26 | 32 | 52 | 0% | 2.8 | - | 58 (4) | - | 151 (1) | 33 (3) |
| Mine | Hammer | 4 | 0 (4) | 0 | 0 | 39 | 50% | 1.0 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Mine | Shooter | 6 | 36 (6) | 0 | 36 | 74 | 0% | 1.7 | 95 (1) | 8 (3) | 58 (2) | 58 (4) | 0 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 18 (8) | 0 | 18 | 45 | 62% | 3.7 | 36 (4) | 0 (4) | - | 52 (3) | 0 (5) |
| Opponent | Character | 9 | 91 (9) | 91 | 0 | 2 | 22% | 3.7 | 58 (5) | 139 (3) | 0 (1) | 113 (5) | 38 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 10 | 49 (10) | 42 | 7 | 12 | 20% | 3.2 | 65 (3) | 43 (4) | 29 (3) | 17 (6) | 76 (4) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 147 (3) | 38 | 109 | 31 | 0% | 2.3 | - | 175 (2) | 100 (1) | 147 (3) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 25 (5) | 25 | 0 | 30 | 40% | 1.3 | 33 (3) | 0 (1) | 0 (1) | 40 (2) | 0 (3) |

### Charged fights: chf-efd8067-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 319 | 7.0 | 1.1 | 46 | 56 | -11 | 4 of 7 | 4 of 7 | -395 | +53 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| Mine | Lizardmen | 1 | 0 | 266 | 4.0 | 1.0 | 66 | 0 | +66 | 0 of 4 | 4 of 4 | - | +66 |
| **Mine** | all armies | 3 | 0 | 210 | 4.3 | 1.1 | 48 | 30 | +18 | 4 of 13 | 10 of 13 | -395 | +52 |
| Opponent | Tomb Kings of Khemri | 1 | 72 | 709 | 5.0 | 1.2 | 142 | 0 | +142 | 0 of 5 | 4 of 5 | +175 | +134 |
| Opponent | Vampire Counts | 2 | 80 | 740 | 4.0 | 1.1 | 185 | 6 | +179 | 3 of 8 | 5 of 8 | +126 | +186 |
| **Opponent** | all armies | 3 | 77 | 730 | 4.3 | 1.2 | 168 | 4 | +165 | 3 of 13 | 9 of 13 | +150 | +167 |

### Effective charges: chf-efd8067-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 1 (net +0) | 0 | 2 (net +38) | 2 (net -198) | 0 | 1 (net +54) | 1 | 33% (2 of 6) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 2 (net +22) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 0 | 2 (net +63) | 0 | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +310) | 2 (net +129) | 0 | 2 | 0% (0 of 3) |
| Opponent | Vampire Counts | 8 | 2 (net -25) | 1 (net +0) | 0 | 2 (net +0) | 0 | 3 (net +493) | 0 | 0% (0 of 8) |

### Charged fights, damage counted: chf-efd8067-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 497 | 471 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 4 | 179 | 159 | +30 | 30 | 10 | +20 | +11.2 |
| Mine | 76-89% | 2 | 630 | 380 | -198 | 0 | 198 | -198 | -31.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 115 | 54 | +54 | 54 | 0 | +54 | +47.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 405 | 63 | +63 | 103 | 58 | +45 | +11.2 |
| Mine | No odds | 3 | 304 | 67 | +110 | 110 | 0 | +110 | +36.1 |
| Mine | All fights | 13 | 332 | 173 | +18 | 55 | 42 | +12 | +3.7 |
| Opponent | Long shot (under 50%) | 2 | 50 | 387 | -25 | 20 | 25 | -5 | -10.0 |
| Opponent | 50-54% | 1 | 186 | 199 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 3 | 189 | 148 | +103 | 133 | 0 | +133 | +70.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 441 | 278 | +493 | 493 | 0 | +493 | +111.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 656 | 129 | +129 | 129 | 0 | +129 | +19.7 |
| Opponent | No odds | 2 | 313 | 158 | +70 | 104 | 0 | +104 | +33.1 |
| Opponent | All fights | 13 | 316 | 217 | +165 | 183 | 4 | +179 | +56.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p33 | move | 28 | 7 (25%) | 4 (14%) | 6 (21%) | 15 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

# Doctrine scorecard: chf-efd8067-p40

### Scorecard: chf-efd8067-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 735 |
| L0528 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 882 |
| L0616 | 4 | 1 | Opponent | no | 8 | 4 | 1 | 1 | 0 | 0 | 0 | 280 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 275 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.5 | 3.0 | 1.7 | 2.0 | 0.0 | 0.0 | 0.0 | 630.7 |
| **Average** | | | Opponent | 0% | 4.0 | 3.5 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 93.3 |

### KPIs: chf-efd8067-p40

Rules off - Opponent only: CHALLENGE IN THE FIGHT.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 13) | 48% (12 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 20% (1 of 5) | 20% (1 of 5) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (10 of 12) | 83% (10 of 12) |
| Points that never fought | lower | 91% (5458 of 6000) | 83% (4985 of 5999) | 87% (10443 of 11999) |
|   infantry points that never fought | lower | 81% (1810 of 2232) | 91% (657 of 720) | 84% (2467 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (19 of 27) | 71% (15 of 21) | 71% (34 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2742 of 4232) | 73% (3950 of 5415) | 69% (6692 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (60%) | 1.0 (60%) |
| MARCHED: its unit marched | - | 0.3 (20%) | 0.3 (20%) |
| GONE: slain | - | 0.3 (20%) | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.7 | 0.0 | 0.3 | 0.0 |
| not cast | 2.3 | 2.0 | 1.7 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (50%) | 1.0 (60%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.3 (17%) | 0.3 (20%) | 1.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (75%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (147 of 201) | 31% (10 of 32) | 67% (157 of 233) |
|   cavalry | 53% (10 of 19) | 30% (3 of 10) | 45% (13 of 29) |
|   character | 82% (27 of 33) | 0% (0 of 12) | 60% (27 of 45) |
|   infantry | 69% (33 of 48) | 0% (0 of 2) | 66% (33 of 50) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 78% (69 of 89) | 88% (7 of 8) | 78% (76 of 97) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (20%) | 3.0 (41%) | 6.7 (26%) |
| CHARGED: it charged | 1.7 (9%) | 0.3 (5%) | 2.0 (8%) |
| IN COMBAT: it fought this turn or the last | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.3 (30%) | 3.3 (45%) | 8.7 (34%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.0 (28%) | 0.3 (5%) | 5.3 (21%) |
| SHELTERED: the target was sheltered | 0.7 (4%) | 0.3 (5%) | 1.0 (4%) |
| OTHER BAR | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 2.3 | 57% | 10.1 pts | 47 pts |
| character | 9.0 | 7.7 | 59% | 15.7 pts | 141 pts |
| infantry | 21.3 | 10.3 | 62% | 13.7 pts | 291 pts |
| monster | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.3 | 18.3 | 58% | 23.9 pts | 607 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 1.7 | 2.3 |
| Charges that made contact a game | 0.7 | 1.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.10 contact (21 units) | 0.25 declared, 0.15 contact (20 units) | 0.34 declared, 0.12 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 83% (5 of 6) | 0% (0 of 1) | - | 71% (5 of 7) |
| Character on its own | 100% (1 of 1) | 75% (3 of 4) | 75% (3 of 4) | 78% (7 of 9) |
| Infantry | 71% (5 of 7) | 50% (3 of 6) | - | 62% (8 of 13) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 91% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 68% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 91% | 80% (12 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (chf-efd8067-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: chf-efd8067-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 17% (1 of 6) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 75% (68 of 91) | 25% (2 of 8) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 22% (2 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 630.7 | 93.3 |
| Movement | Fights charged into per game | 0.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net +0 | 1 of 3, net +186 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 3, net +60 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 3, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 27.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (43 of 81) | 33% (1 of 3) |
| Shooting | Points destroyed by shooting units | 303.3 | 0.0 |
| Shooting | War machine shots | 23.0 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (39 of 69) | 14% (1 of 7) |
| Shooting | Points destroyed by war machines | 300.7 | 111.7 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 82.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +8 | +133 |
| Combat | Net per 100 charger points, damage counted | +13.6 | +56.4 |
| Combat | First round won (charged fights) | 50% | 100% |
| Combat | Net points per charged fight | +0 | +144 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +144 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 3 |
| Game | Points lost | 314.0 | 943.3 |
| Game | VP from objectives | 490.0 | 356.7 |
| Game | Lone holders (player turns) | 2.5 | 4.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +875 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1257
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: chf-efd8067-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 6.0 | +188.9 | 0.0 | 0.0 | 16.3 | +234.7 | 0.0 | 208.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 1.3 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 119.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 21.3 | +160.6 | 1721.7 | 0.0 | 1.7 | +87.8 | 105.0 | 66.7 |
| CANNON SIGHT KEPT | 4.0 | +0.0 | 0.0 | 60.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +60.4 | 0.0 | 47.3 |
| CHALLENGE BY POINTS | 0.3 | +17.3 | 0.0 | 62.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 62.0 | 0.0 |
| CHARACTER GUNS | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.3 | -197.9 | 0.0 | 186.7 | 23.7 | -1261.5 | 0.0 | 1530.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 62.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 144.0 | 157.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -5.1 | 62.0 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 126.7 | 11.0 | +0.0 | 0.0 | 117.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -585.3 | 0.0 | 0.0 | 3.7 | -217.2 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -4.2 | 124.0 | 157.0 |
| DEPLOY BY FIGURES | 10.7 | -119.8 | 0.0 | 21.7 | 6.0 | +70.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.4 | 62.0 | 157.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +7.2 | 62.0 | 0.0 |
| EXACT ROUND | 2.0 | +5.2 | 0.0 | 0.0 | 1.0 | +2.9 | 40.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.1 | 10.0 | 0.0 | 0.3 | +0.0 | 20.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 13.7 | +296.6 | 0.0 | 539.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 127.0 | +5677.9 | 4048.7 | 394.0 | 68.3 | +2748.7 | 554.0 | 2173.7 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 254.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +96.7 | 0.0 | 157.0 |
| FOUR ROUNDS | 3.0 | +31.0 | 10.0 | 0.0 | 1.7 | +63.2 | 164.0 | 157.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.7 | -25.0 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | - | - | - | - | 13.3 | +1150.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +5.0 | 46.3 | 0.0 | - | - | - | - |
| GUN MASK | 3.7 | +47.9 | 0.0 | 0.0 | 1.7 | +56.9 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | -0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 82.0 | 0.0 |
| HARD STAY DROPPED | 5.0 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 20.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 40.0 | 11.0 | +0.0 | 0.0 | 154.7 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 80.0 | 22.7 | +0.0 | 0.0 | 139.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -26.9 | 0.0 | 40.0 | 7.0 | -70.8 | 0.0 | 10.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 40.0 | 4.7 | +0.0 | 0.0 | 80.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.0 | +926.5 | 0.0 | 80.0 | 58.3 | +5128.4 | 0.0 | 1856.7 |
| HIS SHOTS BY HIS RUN | 11.3 | +157.7 | 0.0 | 226.7 | 44.3 | +1105.4 | 0.0 | 1810.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +26.2 | 124.0 | 157.0 |
| HOLD ODDS | 6.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 1077.3 |
| HOLDER ASSIGNMENT | 8.3 | +1037.6 | 0.0 | 0.0 | 7.0 | +760.2 | 0.0 | 538.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -9.1 | 10.0 | 0.0 | 1.3 | -54.9 | 102.0 | 157.0 |
| IDLE COST | - | - | - | - | 19.3 | -386.2 | 0.0 | 468.0 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 329.3 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +67.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 62.0 | 0.7 | +0.0 | 62.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 62.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.8 | 0.0 | 0.0 | 0.7 | +0.0 | 82.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 62.0 | 157.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | -5.8 | 0.0 | 0.0 | 1.7 | -0.8 | 0.0 | 119.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +19.0 | 0.0 | 119.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +3.1 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| MEETS IN TIME | 6.3 | +318.2 | 0.0 | 0.0 | 3.3 | +286.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 1.0 | +4.2 | 0.0 | 119.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +3.9 | 0.0 | 238.0 |
| MODEL FACING | 4.7 | +1052.8 | 0.0 | 40.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 37.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +310.5 | 0.0 | 40.0 | 2.3 | +124.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +213.1 | 0.0 | 0.0 | 1.7 | +71.7 | 0.0 | 119.0 |
| NEXT CHARGE BY LIST | 2.7 | +100.2 | 0.0 | 0.0 | 2.3 | +124.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.7 | +6.1 | 0.0 | 62.0 | 2.3 | +35.9 | 62.0 | 167.0 |
| NO DOUBLE ROUNDS | 2.7 | -42.0 | 10.0 | 0.0 | 1.7 | -45.9 | 164.0 | 157.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 10.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.9 | 0.0 | 117.0 |
| OFF BEST | 7.0 | -222.7 | 0.0 | 0.0 | 3.0 | -76.8 | 0.0 | 77.3 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -2.7 | 62.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -40.6 | 0.0 | 41.7 | 4.0 | -84.9 | 0.0 | 46.3 |
| ONE JOINT FIGURE | 0.7 | -8.0 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | +2.3 | 0.0 | 0.0 | 2.0 | -21.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +3.2 | 62.0 | 157.0 |
| OVERRUNS AWAY | 0.7 | +2.8 | 0.0 | 0.0 | 1.3 | +73.1 | 144.0 | 157.0 |
| PLAN RESULT | 56.0 | +1982.5 | 2277.7 | 412.7 | 33.0 | +199.4 | 195.3 | 1125.3 |
| PRIZE BY WORTH | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.7 | -214.8 | 0.0 | 40.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 2.0 | -15.4 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -40.1 | 80.0 | 33.3 |
| QUARTER ODDS | 12.0 | +963.1 | 474.0 | 106.7 | 8.0 | +1147.1 | 173.3 | 106.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +73.3 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +23.0 | 0.0 | 21.7 | 0.7 | +9.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 33.7 |
| REDIRECT WEIGHED | 1.3 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -48.1 | 0.0 | 40.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +45.1 | 0.0 | 26.7 |
| RISK BY ARC | 2.3 | +60.7 | 10.0 | 0.0 | 1.3 | -108.5 | 144.0 | 157.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -5.2 | 82.0 | 157.0 |
| RUN DOWN | 2.7 | -15.2 | 10.0 | 0.0 | 1.3 | -4.4 | 164.0 | 157.0 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.3 | -174.5 | 0.0 | 47.3 |
| SEARCH SPOT | 0.3 | +7.6 | 0.0 | 20.0 | - | - | - | - |
| SECOND LOOK | 1.0 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 3.7 | -112.1 | 0.0 | 0.0 | 0.3 | -8.7 | 0.0 | 26.7 |
| SET UP BY THE SET | 3.7 | +109.0 | 0.0 | 0.0 | 0.7 | +6.3 | 0.0 | 26.7 |
| SET UP TOGETHER | 1.0 | +2.3 | 0.0 | 0.0 | 0.7 | +0.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 30.0 | +0.0 | 0.0 | 62.0 | 2.7 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +10.3 | 0.0 | 0.0 | 1.0 | +5.3 | 20.0 | 26.7 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -4.1 | 10.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 17.3 | +639.7 | 0.0 | 226.7 | 37.0 | -713.8 | 0.0 | 1585.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 41.7 | +1234.5 | 0.0 | 135.3 | 3.7 | +226.0 | 0.0 | 93.3 |
| SPELL WORTH | - | - | - | - | 1.7 | +29.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 41.7 | 7.3 | +0.0 | 0.0 | 166.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -42.2 | 124.0 | 157.0 |
| STANDS STILL | 95.3 | +0.0 | 4038.7 | 270.7 | 15.0 | +0.0 | 390.0 | 213.3 |
| STAY WORTH | 76.3 | +406.3 | 2432.7 | 157.3 | 7.3 | +230.2 | 303.3 | 226.7 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -6.7 | 0.0 | 329.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 2.0 | +16.8 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 37.0 |
| THE FIGHT MOVES | 0.7 | +3.4 | 0.0 | 0.0 | 1.0 | +6.8 | 144.0 | 157.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 20.0 | 4.3 | +0.0 | 0.0 | 252.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 178.3 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 164.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 53.7 | +0.0 | 0.0 | 123.7 | 31.0 | +0.0 | 0.0 | 1008.3 |
| TIED UP BY THE SUM | 1.0 | +28.2 | 0.0 | 0.0 | 1.0 | +111.1 | 82.0 | 157.0 |
| TIME ON OUR SIDE | 46.0 | +582.9 | 74.0 | 103.7 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -7.9 | 0.0 | 0.0 | 0.3 | +1.1 | 20.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 3.7 | -176.6 | 0.0 | 154.7 |
| WHOLE FIGHT REACTION | 1.7 | +74.4 | 157.0 | 164.0 | 3.0 | +57.8 | 0.0 | 20.0 |
| WOUNDS ON THE RANKS | 2.7 | +13.5 | 0.0 | 0.0 | 9.3 | +437.2 | 0.0 | 1134.7 |

### Rule changes: chf-efd8067-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 253 | 251 | 63 | 21.00 | +1822 | +28.9 |
| ARMY TABLE | 67 | 67 | 53 | 17.67 | +1102 | +20.8 |
| HOLDER ASSIGNMENT | 46 | 46 | 41 | 13.67 | +2909 | +71.0 |
| SHOT RISK POINTS | 163 | 161 | 39 | 13.00 | +1299 | +33.3 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -898 | -29.9 |
| HIS SHOTS BY HIS RUN | 167 | 165 | 27 | 9.00 | +683 | +25.3 |
| DEPLOY BY FIGURES | 50 | 50 | 26 | 8.67 | +480 | +18.5 |
| TIME ON OUR SIDE | 138 | 127 | 20 | 6.67 | +62 | +3.1 |
| CANNON PLANNED TARGET | 69 | 69 | 18 | 6.00 | -469 | -26.1 |
| FIVE ACTION | 586 | 573 | 18 | 6.00 | +376 | +20.9 |
| MOVE TO CHARGE COMPUTED | 29 | 24 | 18 | 6.00 | +377 | +20.9 |
| PROMISE BY ITS OWN SUM | 38 | 38 | 18 | 6.00 | -644 | -35.8 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +3158 | +225.6 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| IDLE COST | 58 | 42 | 10 | 3.33 | +215 | +21.5 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +220 | +22.0 |
| SET UP BY THE SET | 13 | 11 | 9 | 3.00 | +212 | +23.6 |
| MEETS IN TIME | 29 | 29 | 8 | 2.67 | +96 | +12.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOUR ROUNDS | 14 | 12 | 7 | 2.33 | +61 | +8.8 |
| GOAL WALK | 40 | 40 | 7 | 2.33 | +325 | +46.4 |
| NEXT CHARGE BY LIST | 15 | 12 | 7 | 2.33 | +259 | +36.9 |
| NO CHAFF EDGES | 9 | 8 | 7 | 2.33 | +103 | +14.8 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 60 | 60 | 6 | 2.00 | +346 | +57.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| GUN MASK | 16 | 15 | 5 | 1.67 | +100 | +20.1 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 136 | 110 | 5 | 1.67 | +80 | +16.1 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +133 | +26.6 |
| WHOLE FIGHT REACTION | 14 | 14 | 5 | 1.67 | +56 | +11.3 |
| CHARGE LOSSES | 93 | 93 | 4 | 1.33 | +544 | +136.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +204 | +50.9 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +111 | +27.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +135 | +33.8 |
| RISK BY ARC | 11 | 9 | 4 | 1.33 | +34 | +8.5 |
| STAY WORTH | 251 | 229 | 4 | 1.33 | +21 | +5.2 |
| SURE REACH TOGETHER | 7 | 5 | 4 | 1.33 | +9 | +2.1 |
| EXACT ROUND | 9 | 7 | 3 | 1.00 | +2 | +0.8 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +290 | +96.7 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +766 | +255.5 |
| OVERRUNS AWAY | 6 | 6 | 3 | 1.00 | +28 | +9.2 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +58 | +19.3 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 16 | 3 | 3 | 1.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 4 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -34 | -17.1 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +33 | +16.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -120 | -60.1 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| THE FIGHT MOVES | 5 | 4 | 2 | 0.67 | +11 | +5.5 |
| WOUNDS ON THE RANKS | 36 | 36 | 2 | 0.67 | +113 | +56.6 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +52 | +52.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +20 | +19.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -9 | -8.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| FALLS SHORT | 41 | 28 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| HIS MOVE AND SHOT | 29 | 29 | 1 | 0.33 | +2 | +2.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +15 | +14.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MAX FOR POSITIONING | 3 | 3 | 1 | 0.33 | +29 | +28.9 |
| NEARER NOT NEEDED | 19 | 18 | 1 | 0.33 | +30 | +29.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -29 | -29.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +11 | +11.2 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +23 | +22.8 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -13 | -13.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 1 | 1 | 0.33 | +0 | +0.4 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| COVER ONCE | 32 | 23 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 6 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 43 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 78 | 78 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 54 | 53 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 17 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 13 | 10 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 98 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 331 | 326 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 6 | 2 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 6 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 4 | not checked | - | - | - | - |
| THE TABLE BINDS | 254 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: chf-efd8067-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 2.67 | 32.0 |
| PROMISE BY ITS OWN SUM | rule | 6.00 | - | 35.8 |
| CANNON PLANNED TARGET | rule | 3.33 | - | 49.0 |
| ARMY TABLE | rule | - | 2.00 | 3.3 |
| NO REASON | gate | 1.00 | - | 6.7 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 17.1 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 60.1 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 8.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 19.2 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 46.7 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 29.2 |
| RULE SWITCHED OFF | gate | - | 0.33 | 45.8 |
| SUPPORT NARROWED | rule | 0.33 | - | 13.3 |

### Plans: chf-efd8067-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 29% | 116 | 45 | 39% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 27.3 | 94% | 674 | 0 | 0% |
| Mine | shoot | 25.7 | 77% | 1491 | 1938 | 130% |
| Opponent | charge | 1.3 | 75% | 42 | 139 | 328% |
| Opponent | move | 28.0 | 93% | 1070 | 0 | 0% |
| Opponent | shoot | 2.0 | 33% | 260 | 61 | 23% |
| Opponent | support | 1.7 | 60% | 20 | 0 | 0% |

### Battle groups: chf-efd8067-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: chf-efd8067-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 22 (13) | 22 | 0 | 0 | 38% | 2.1 | 0 (1) | 25 (9) | 23 (3) | 27 (10) | 0 (3) |
| Mine | Clean-up | 4 | 22 (4) | 22 | 0 | 10 | 50% | 1.0 | 0 (1) | 232 (1) | 0 (2) | 38 (3) | 0 (1) |
| Mine | Hammer | 5 | 145 (5) | 63 | 81 | 0 | 40% | 3.0 | - | 212 (3) | 66 (2) | 145 (5) | - |
| Mine | Shooter | 10 | 39 (10) | 0 | 39 | 30 | 0% | 1.7 | 0 (1) | 67 (5) | 0 (4) | 49 (8) | 0 (2) |
| Mine | War machine | 17 | 55 (17) | 55 | 0 | 20 | 12% | 1.4 | 0 (3) | 103 (5) | 44 (9) | 0 (3) | 66 (14) |
| Opponent | Chaff | 5 | 23 (5) | 0 | 23 | 100 | 80% | 2.0 | 0 (2) | 38 (2) | 0 (1) | 0 (4) | 75 (1) |
| Opponent | Character | 8 | 10 (8) | 10 | 0 | 50 | 75% | 5.0 | 0 (2) | 29 (2) | 22 (1) | 21 (3) | 0 (2) |
| Opponent | Clean-up | 2 | 86 (2) | 0 | 86 | 0 | 50% | 6.0 | - | 86 (2) | - | 86 (2) | - |
| Opponent | Fast Hammer | 4 | 25 (4) | 0 | 25 | 76 | 100% | - | 0 (1) | 50 (1) | 16 (2) | 25 (4) | - |
| Opponent | Hammer | 4 | 25 (4) | 25 | 0 | 0 | 50% | 4.5 | - | 0 (2) | 47 (2) | 25 (4) | - |
| Opponent | Holder | 2 | 12 (2) | 0 | 12 | 100 | 100% | - | 0 (1) | 27 (1) | - | 12 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | War machine | 2 | 168 (2) | 168 | 0 | 50 | 0% | 1.0 | - | 168 (2) | - | - | 168 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 85 | 0% | 2.5 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: chf-efd8067-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 604 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Kingdom of Bretonnia | 1 | 335 | 246 | 2.0 | 1.0 | 123 | 0 | +123 | 1 of 2 | 2 of 2 | - | +123 |
| Opponent | Warriors of Chaos | 2 | 0 | 93 | 0.5 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| **Opponent** | all armies | 3 | 112 | 144 | 1.0 | 1.0 | 144 | 0 | +144 | 2 of 3 | 3 of 3 | - | +144 |

### Effective charges: chf-efd8067-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +60) | 0 | 0 | 1 (net +186) | 0 | 50% (1 of 2) |
| Opponent | Warriors of Chaos | 1 | 1 (net +186) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: chf-efd8067-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 60 | 135 | +0 | 15 | 0 | +15 | +25.0 |
| Mine | All fights | 2 | 55 | 152 | +0 | 8 | 0 | +8 | +13.6 |
| Opponent | Long shot (under 50%) | 1 | 63 | 186 | +186 | 186 | 0 | +186 | +295.2 |
| Opponent | Effective (55-75%) | 1 | 275 | 60 | +60 | 60 | 0 | +60 | +21.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 371 | 186 | +186 | 186 | 32 | +154 | +41.5 |
| Opponent | All fights | 3 | 236 | 144 | +144 | 144 | 11 | +133 | +56.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| chf-efd8067-p40 | move | 18 | 3 (17%) | 1 (6%) | 2 (11%) | 13 (72%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

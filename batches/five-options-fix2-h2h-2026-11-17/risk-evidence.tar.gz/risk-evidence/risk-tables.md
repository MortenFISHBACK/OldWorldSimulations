71 games

## 1. Risk of the picked job: claimed v points lost in the enemy turn after (per game)

| Side | Job | picks | claimed risk | lost | claimed: enemy charges / shots / lost-charge | lost when charged-fought / shot / magic / other |
| --- | --- | --- | --- | --- | --- | --- |
| new | ALL | 2794 | 1736 | 449 | 518 / 1404 / 31 | 204 / 171 / 59 / 15 |
| new | other | 2065 | 1139 | 323 | 364 / 1024 / 25 | 147 / 112 / 53 / 11 |
| new | shoot | 634 | 539 | 100 | 154 / 380 / 5 | 42 / 48 / 5 / 4 |
| new | charge | 74 | 57 | 23 | 0 / 0 / 0 | 12 / 11 / 0 / 0 |
| new | join | 21 | 2 | 4 | 0 / 0 / 0 | 3 / 0 / 1 / 0 |
| simpler | ALL | 2911 | 684 | 376 | 0 / 0 / 0 | 130 / 174 / 55 / 17 |
| simpler | advance | 1081 | 226 | 109 | 0 / 0 / 0 | 29 / 57 / 21 / 2 |
| simpler | shoot | 700 | 244 | 81 | 0 / 0 / 0 | 25 / 53 / 3 / 0 |
| simpler | hold | 483 | 91 | 41 | 0 / 0 / 0 | 13 / 16 / 11 / 1 |
| simpler | close-in | 387 | 83 | 75 | 0 / 0 / 0 | 13 / 39 / 11 / 13 |
| simpler | charge | 242 | 34 | 67 | 0 / 0 / 0 | 50 / 6 / 9 / 1 |
| simpler | join | 18 | 5 | 3 | 0 / 0 / 0 | 0 / 3 / 0 / 0 |

(simpler side logs only the total risk, no split; 'other' = lost with no enemy action on the unit logged, e.g. panic, flee, combat it was already in)

## 2. Passed-over charges, new side (90 options not taken)

| Term | median | mean |
| --- | --- | --- |
| worth | +14.2 | +16.3 |
| gain | +32.5 | +55.0 |
| fight | +53.1 | +68.9 |
| second term (wears-down / kills-count / together) | +18.1 | +43.8 |
| other-costs | -50.7 | -59.1 |
| after | -2.7 | +1.5 |
| risk | +13.7 | +38.7 |
| risk: enemy charges | +0.0 | +2.8 |
| risk: shots | +4.4 | +30.4 |
| risk: lost-charge | +0.0 | +0.0 |

At or below zero: 26; of those above zero without the 'after' term: 6; above zero without the risk: 13; fight term alone above zero: 20
Picked instead: {'move': 33, 'march': 24, 'charge': 18, 'stand': 8, 'shoot': 7}

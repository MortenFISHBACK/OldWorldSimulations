# Doctrine scorecard: ja-opp-f9a8036-p1

### Scorecard: ja-opp-f9a8036-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 5 | 0 | 0 | 0 | 30 |
| L0118 | 4 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 436 |
| L0135 | 3 | 1 | Mine | no | 5 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 8 | 2 | 1 | 3 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 7 | 5 | 1 | 0 | 0 | 0 | 0 | 220 |
| L0319 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 190 |
| L0421 | 1 | 1 | Mine | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 190 |
| L0508 | 4 | 1 | Opponent | no | 3 | 6 | 1 | 4 | 0 | 0 | 0 | 45 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 1 | 0 | 0 | 586 |
| L0612 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 215 |
| L0628 | 4 | 1 | Opponent | no | 3 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 484 |
| L0717 | 3 | 1 | Opponent | yes | 2 | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 5 | 1 | 2 | 1 | 1 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 295 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 125 |
| L0913 | 1 | 1 | Opponent | no | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 70 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 349 |
| L0930 | 6 | 1 | Opponent | no | 11 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 2 | 5 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | yes | 6 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| L1114 | 4 | 1 | Mine | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 361 |
| L1114 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Opponent | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 8 | 1 | 5 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 2 | 6 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 1 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 7 | 4 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 613 |
| L1431 | 3 | 1 | Mine | no | 5 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 1 | 0 | 2 | 0 | 0 | 456 |
| L1527 | 3 | 1 | Mine | no | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 3 | 3 | 5 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 17% | 3.6 | 2.5 | 1.8 | 1.0 | 0.2 | 0.0 | 0.0 | 158.6 |
| **Average** | | | Opponent | 17% | 2.5 | 2.8 | 2.4 | 1.9 | 0.4 | 0.0 | 0.0 | 109.0 |

### KPIs: ja-opp-f9a8036-p1

Rules off - Mine only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 25 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 37% (46 of 123) | 4% (4 of 114) | 21% (50 of 237) |
| Winner chose to follow up after the loser gave ground |  | 72% (23 of 32); on the table 81% | 88% (23 of 26); on the table 88% | 79% (46 of 58); on the table 84% |
| Winner chose to pursue after the loser fell back in good order |  | 77% (10 of 13); on the table 77% | 80% (12 of 15); on the table 80% | 79% (22 of 28); on the table 79% |
| Winner chose to pursue after the loser fled |  | 71% (10 of 14); on the table 71% | 93% (13 of 14); on the table 93% | 82% (23 of 28); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 73% (43 of 59); on the table 78% | 87% (48 of 55); on the table 87% | 80% (91 of 114); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 44% (126 of 288) | 31% (50 of 162) | 39% (176 of 450) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (126 of 244) | 38% (50 of 130) | 47% (176 of 374) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 47% (22 of 47) | 46% (25 of 54) |
| Points that never fought | lower | 46% (22841 of 49488) | 51% (25619 of 49893) | 49% (48460 of 99381) |
|   infantry points that never fought | lower | 52% (6434 of 12386) | 72% (6827 of 9544) | 60% (13261 of 21930) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (110 of 206) | 63% (134 of 212) | 58% (244 of 418) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 3.1 uses a game | 82% (14 of 17); 1.8 uses a game | 89% (33 of 37); 2.4 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.8 uses a game | 50% (4 of 8); 0.2 uses a game | 58% (14 of 24); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (7 of 15); 0.3 uses a game | 40% (4 of 10); 0.2 uses a game | 44% (11 of 25); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (18900 of 41798) | 61% (27044 of 44239) | 53% (45944 of 86037) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (36%) | 1.9 (42%) | 4.2 (39%) |
| MARCHED: its unit marched | 1.5 (23%) | 1.0 (21%) | 2.5 (23%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.0 (0%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.6 (24%) | 0.6 (12%) | 2.1 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 0.1 (2%) | 0.6 (12%) | 0.7 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (4%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (1%) | 0.4 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 2.0 | 2.0 | 7.0 | 0.6 | 2.1 |
| not cast | 3.0 | 3.4 | 3.2 | 11.0 | 2.0 | 23.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (51%) | 0.4 (11%) | 4.2 (39%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (23%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (6%) | 0.4 (14%) | 2.1 (19%) | 0.7 (35%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.5 (15%) | 0.5 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.3 (11%) | 0.3 (8%) | 0.2 (6%) | 0.7 (6%) | 0.0 (0%) | 1.9 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (1%) | 0.0 (0%) | 0.2 (2%) | 0.1 (6%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) | 0.4 (3%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.1 (1%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (72%) | 0.4 (11%) | 1.7 (52%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.9 a game | 1.2 a game |
| stood (cast and not dispelled) | 81% (29 of 36) | 67% (12 of 18) | 76% (41 of 54) |
| the unit moved after it | 59% (17 of 29) | 75% (9 of 12) | 63% (26 of 41) |
| it charged on its next turn | 0% (0 of 29) | 0% (0 of 12) | 0% (0 of 41) |
| the enemy charged it first | 7% (2 of 29) | 8% (1 of 12) | 7% (3 of 41) |
| it fought by the end of its next turn | 7% (2 of 29) | 8% (1 of 12) | 7% (3 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (5 of 29) | 0% (0 of 12) | 12% (5 of 41) |
| none of these (no charge, no fight, no charge escaped) | 76% (22 of 29) | 92% (11 of 12) | 80% (33 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (473 of 722) | 63% (262 of 418) | 64% (735 of 1140) |
|   cavalry | 42% (22 of 53) | 65% (50 of 77) | 55% (72 of 130) |
|   character | 72% (81 of 113) | 51% (35 of 68) | 64% (116 of 181) |
|   chariot | 64% (42 of 66) | 83% (20 of 24) | 69% (62 of 90) |
|   infantry | 64% (126 of 197) | 61% (104 of 171) | 62% (230 of 368) |
|   monster | 59% (13 of 22) | 52% (11 of 21) | 56% (24 of 43) |
|   war machine | 70% (189 of 271) | 74% (42 of 57) | 70% (231 of 328) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (25%) | 1.6 (26%) | 4.1 (25%) |
| CHARGED: it charged | 0.8 (8%) | 1.0 (17%) | 1.8 (11%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (1%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.4 (6%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.6 (16%) | 0.6 (9%) | 2.2 (13%) |
| NO TARGET IN RANGE | 1.8 (18%) | 1.6 (26%) | 3.5 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.2 (3%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (16%) | 0.8 (12%) | 2.4 (15%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (1%) | 0.2 (1%) |
| OTHER BAR | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 0.9 | 82% | 5.0 pts | 20 pts |
| character | 5.4 | 2.9 | 70% | 8.3 pts | 45 pts |
| chariot | 2.5 | 2.1 | 63% | 16.7 pts | 42 pts |
| infantry | 14.2 | 5.8 | 72% | 9.3 pts | 132 pts |
| monster | 1.3 | 0.4 | 81% | 8.0 pts | 10 pts |
| war machine | 9.2 | 6.8 | 64% | 20.7 pts | 191 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 4.5 | 3.9 |
| Charges that made contact a game | 2.7 | 3.0 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.32 declared, 1.00 contact (19 units) | 0.50 declared, 0.50 contact (10 units) | 1.03 declared, 0.83 contact (29 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.83 declared, 0.50 contact (6 units) | 0.71 declared, 0.43 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.30 contact (161 units) | 0.52 declared, 0.34 contact (195 units) | 0.45 declared, 0.33 contact (356 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (20 of 56) | 60% (6 of 10) | 50% (3 of 6) | 40% (29 of 72) |
| Character in a unit | 85% (34 of 40) | 60% (15 of 25) | 33% (1 of 3) | 74% (50 of 68) |
| Character on its own | 84% (21 of 25) | 38% (9 of 24) | 35% (12 of 34) | 51% (42 of 83) |
| Chariot | 100% (12 of 12) | 50% (5 of 10) | - | 77% (17 of 22) |
| Infantry | 49% (30 of 61) | 34% (11 of 32) | 50% (1 of 2) | 44% (42 of 95) |
| Monster | 71% (10 of 14) | 100% (5 of 5) | - | 79% (15 of 19) |
| Monstrous | 86% (6 of 7) | 70% (7 of 10) | - | 76% (13 of 17) |
| War Machines | 85% (35 of 41) | 100% (1 of 1) | - | 86% (36 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 69% (11 of 16); on the table 75% | 51% (70 of 138) | 46% | 48% (16 of 33) | 100% (9 of 9); 6.0 uses a game | 100% (3 of 3); 1.7 uses a game | 67% (6 of 9); 1.0 uses a game |
| Chaos Dwarfs | 3 | 33% (1 of 3); on the table 67% | 25% (6 of 24) | 42% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 75% (6 of 8); on the table 75% | - | 61% | 68% (28 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 57% (4 of 7); on the table 71% | 61% (22 of 36) | 59% | 69% (44 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 76% (16 of 21); on the table 76% | 31% (33 of 108) | 39% | 45% (20 of 44) | 92% (11 of 12); 7.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 89% (25 of 28); on the table 89% | 10% (3 of 30) | 44% | 41% (20 of 49) | 100% (5 of 5); 4.2 uses a game | 56% (10 of 18); 2.3 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 22% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 64% | 86% (12 of 14) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (2 of 2); on the table 100% | 58% (14 of 24) | 54% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 42% (5 of 12) | 58% | 89% (16 of 18) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 56% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 80% (4 of 5); on the table 80% | 25% (6 of 24) | 46% | 70% (14 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 75% (3 of 4); on the table 75% | 33% (6 of 18) | 48% | 68% (25 of 37) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 100% (9 of 9); on the table 100% | 46% (11 of 24) | 39% | 50% (23 of 46) | 40% (2 of 5); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-opp-f9a8036-p1, 25 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (18) | 55% (23) | 48% (41) |
| ...free all their last turn and able to turn (per game) | 0.52 | 0.56 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.20 | 0.04 | 0.24 |
| ...with the charger already in that arc before they moved (per game) | 0.48 | 0.48 | 0.96 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.16 | 0.28 | 0.44 |

### Quality by phase: ja-opp-f9a8036-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (44 of 76) | 51% (48 of 95) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (148 of 316) | 46% (49 of 106) |
| Strategy | Support requests answered (helper made contact too) | 100% (5 of 5) | 75% (6 of 8) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (8 of 13) | 67% (8 of 12) |
| Strategy | Joined characters whose unit fought | 44% (23 of 52) | 41% (17 of 41) |
| Strategy | Lone characters that fought | 70% (38 of 54) | 64% (34 of 53) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 158.6 | 109.0 |
| Movement | Fights charged into per game | 2.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 54, net +37 | 19 of 59, net +34 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 54, net +55 | 8 of 59, net +106 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 54, net +78 | 3 of 59, net +86 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 of 54, net +84 | 15 of 59, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.8 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (150 of 296) | 41% (94 of 230) |
| Shooting | Points destroyed by shooting units | 86.3 | 24.4 |
| Shooting | War machine shots | 7.6 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (99 of 189) | 60% (25 of 42) |
| Shooting | Points destroyed by war machines | 65.7 | 3.8 |
| Magic | Magic missiles cast | 3.2 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (27 of 81) | 44% (14 of 32) |
| Magic | Wounds caused by magic missiles | 8.3 | 2.4 |
| Magic | Wounds caused by other spells | 1.8 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 111.3 | 63.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.6 / 0.9 / 0.2 | 1.7 / 0.6 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 268.0 | 246.5 |
| Combat | Points run down | 38.5 | 67.4 |
| Combat | Net points per charged fight, damage counted | +82 | +70 |
| Combat | Net per 100 charger points, damage counted | +30.2 | +28.2 |
| Combat | First round won (charged fights) | 74% | 70% |
| Combat | Net points per charged fight | +90 | +72 |
| Combat | Net points per supported fight / lone fight | +52 / +96 | +185 / +59 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 58 | 34 of 67 |
| Game | Points lost | 537.0 | 694.2 |
| Game | VP from objectives | 739.6 | 608.8 |
| Game | Lone holders (player turns) | 3.6 | 2.5 |

- Mine won / drew / lost: 13 / 5 / 7 of 25 ended games (of 25); mean margin (Mine - Opponent) +260 VP
- The side that went first won 8 of 20 games with a winner
- Points traded per game (both sides' losses): 1231
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-opp-f9a8036-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +42.5 | 0.0 | 28.6 | 0.1 | +15.1 | 0.0 | 22.8 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.1 | +6.8 | 0.0 | 8.7 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 17.0 | 0.6 | +0.0 | 0.0 | 5.2 |
| BACKUP TARGETS | 0.2 | +2.3 | 0.0 | 15.7 | 0.3 | +1.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.0 | +0.8 | 1.8 | 0.0 | 0.1 | -1.8 | 8.4 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -2.2 | 6.3 | 0.0 | 0.2 | -24.6 | 7.3 | 10.8 |
| BOMBING RUN | 0.1 | +4.9 | 5.8 | 6.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 104.0 | 21.2 | 0.2 | +0.0 | 16.3 | 5.0 |
| CANNON PLANNED TARGET | 6.7 | +116.6 | 455.8 | 121.2 | 1.6 | +31.7 | 34.0 | 27.2 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 7.8 | 0.0 |
| CAST JOB | 0.5 | +15.2 | 35.3 | 22.0 | 0.2 | +0.4 | 0.0 | 21.6 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +17.4 | 2.7 | 0.0 | 0.1 | +2.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 38.8 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +2.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +7.9 | 0.0 | 0.0 | 0.8 | +26.7 | 0.0 | 8.0 |
| CHAFF PASSED | 0.7 | -1.3 | 0.0 | 10.4 | 0.3 | -0.1 | 0.0 | 9.4 |
| CHARACTER GUNS | 0.9 | +0.0 | 0.0 | 12.0 | 0.8 | +0.0 | 0.0 | 8.9 |
| CHARGE LOSSES | 6.3 | -236.3 | 0.0 | 157.2 | 7.2 | -365.2 | 0.0 | 156.9 |
| CHARGE NOT DECLARED | 0.8 | +0.0 | 95.7 | 42.5 | 0.6 | +0.0 | 34.8 | 16.2 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 223.9 | 33.2 | 2.2 | +0.0 | 202.3 | 45.7 |
| CHARGER SLAIN LOST | 0.5 | -20.5 | 36.8 | 8.4 | 0.3 | -8.8 | 24.3 | 23.6 |
| CHEAP HELPER | 0.1 | +0.0 | 7.4 | 4.2 | - | - | - | - |
| CHEAPEST HOLDER | 0.2 | -1.1 | 5.7 | 7.3 | 0.2 | -9.9 | 20.0 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 57.6 | 26.4 | 0.2 | +0.0 | 0.0 | 48.3 |
| CONVEYANCE SEARCH | 0.7 | +53.1 | 0.0 | 0.0 | 0.5 | +42.3 | 18.8 | 18.8 |
| COVER ONCE | 7.4 | -605.2 | 0.0 | 140.8 | 5.3 | -314.8 | 0.0 | 78.3 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 14.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.4 | +1.0 | 0.0 | 10.0 | 7.6 | +80.0 | 0.0 | 51.7 |
| EDGE GIVE GROUND | 0.1 | +3.9 | 9.1 | 0.0 | 0.2 | +4.4 | 46.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.8 | +5.7 | 177.6 | 27.6 | 3.0 | +14.3 | 247.0 | 64.7 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| FALLS SHORT | 3.6 | +68.1 | 0.0 | 45.8 | 18.3 | +261.7 | 0.0 | 234.6 |
| FEATURE BUFFS | 2.2 | +72.1 | 0.0 | 37.7 | 0.5 | +9.9 | 0.0 | 2.2 |
| FIGHT TO THE END | 0.8 | +29.9 | 79.7 | 15.8 | 1.5 | +82.8 | 134.5 | 67.1 |
| FIRE IN ORDER | 0.2 | +0.0 | 9.2 | 6.5 | 0.3 | +0.0 | 17.8 | 16.9 |
| FIVE ACTION | 47.2 | +2812.1 | 1044.9 | 699.6 | 42.5 | +2676.3 | 446.6 | 662.8 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 161.0 | 4.7 | +0.0 | 0.0 | 93.8 |
| FOCUS FIRE | 0.1 | +1.7 | 5.0 | 0.0 | 0.1 | +0.9 | 1.8 | 7.4 |
| FOLLOW UP WEIGHED | 0.8 | +159.2 | 0.0 | 0.0 | 0.6 | +115.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +295.8 | 320.8 | 52.8 | 3.8 | +357.2 | 304.2 | 95.7 |
| FRIEND CHARGES FIRST | 0.0 | -2.5 | 0.0 | 0.0 | 0.2 | -39.5 | 0.0 | 6.0 |
| FRIEND SHOOTS FIRST | 0.3 | -12.3 | 0.0 | 11.2 | 0.2 | -5.9 | 0.0 | 2.6 |
| FRIENDS SHOTS CHECKED | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 5.0 |
| GIVES UP | 0.4 | -3.5 | 11.5 | 0.0 | 0.0 | -0.0 | 5.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +9.0 | 27.7 | 4.6 | 0.9 | +21.9 | 14.2 | 37.0 |
| GUN MASK | 1.2 | +28.5 | 0.0 | 14.3 | 0.2 | +4.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 16.8 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 84.4 | 2.6 | +0.0 | 0.0 | 92.8 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 18.8 | 7.8 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 24.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +12.6 | 44.1 | 0.0 | 0.4 | +8.3 | 28.2 | 6.4 |
| HIS CHARGE LIST | 1.8 | +0.0 | 0.0 | 18.9 | 3.5 | +0.0 | 0.0 | 31.7 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 66.5 | 3.5 | +0.0 | 0.0 | 57.0 |
| HIS MOVE AND SHOT | 1.4 | -17.5 | 0.0 | 36.5 | 2.4 | -59.8 | 0.0 | 67.7 |
| HIS RANDOM MOVE | 4.1 | +0.0 | 0.0 | 42.1 | 0.9 | +0.0 | 0.0 | 9.6 |
| HIS SHOT LIST | 17.7 | +579.9 | 0.0 | 222.5 | 24.4 | +1288.2 | 0.0 | 383.0 |
| HIS TURN DENIED | 1.2 | +29.7 | 160.2 | 29.6 | 2.5 | +177.4 | 166.4 | 55.2 |
| HOLDER AT DEPLOYMENT | 1.0 | +181.0 | 0.0 | 0.0 | 1.1 | +191.9 | 0.0 | 9.1 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -96.8 | 276.8 | 44.3 | 3.1 | -135.6 | 271.0 | 65.8 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | - | - | - | - | 0.4 | +15.4 | 0.0 | 2.8 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +35.8 | 0.0 | 2.4 | 0.0 | +24.5 | 0.0 | 0.0 |
| IDLE COST | 2.4 | -27.1 | 0.0 | 6.4 | 9.6 | -166.0 | 0.0 | 132.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.6 | +37.9 | 55.8 | 27.8 |
| JOINT KNOWS CHALLENGE | 0.1 | -4.9 | 0.0 | 0.0 | 0.2 | -3.5 | 52.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.0 | +1.2 | 8.4 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.6 | +25.9 | 0.0 | 0.0 | 0.6 | +39.2 | 0.0 | 24.0 |
| LEGAL CHARGES ONLY | 5.9 | +0.0 | 180.8 | 161.9 | 5.0 | +0.0 | 153.2 | 399.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +61.0 | 0.0 | 0.0 | 0.2 | +29.6 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.7 | 32.2 | 11.2 | 0.3 | +0.0 | 17.7 | 8.5 |
| LOST CHARGE | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.0 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.1 | +0.3 | 0.0 | 13.9 | 0.2 | +0.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +4.4 | 0.0 | 43.2 | 1.6 | +32.2 | 0.0 | 29.6 |
| MARCH AT ESCAPER | 0.0 | +2.2 | 0.0 | 0.0 | 0.2 | +0.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +14.2 | 0.0 | 0.0 | 0.4 | +14.4 | 0.0 | 0.0 |
| MARCH CHECK | 1.6 | +68.7 | 0.0 | 3.2 | 1.4 | +78.0 | 0.0 | 17.8 |
| MARCH OVER CASTS | 0.9 | +32.3 | 0.0 | 0.0 | 0.7 | +35.8 | 0.0 | 8.6 |
| MAX FOR POSITIONING | 6.1 | +103.8 | 0.0 | 54.4 | 6.2 | +77.4 | 0.0 | 102.1 |
| MISSILES IN THE MOVE | 5.8 | +262.8 | 0.0 | 41.5 | 3.9 | +64.7 | 0.0 | 71.3 |
| MISSILES NEXT TURN | 6.8 | +162.1 | 0.0 | 41.5 | 4.6 | +46.1 | 0.0 | 79.9 |
| MODEL FACING | 0.4 | +99.3 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -49.6 | 0.0 | 0.0 | 0.3 | -18.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 38.8 |
| MOVE TO CHARGE COMPUTED | 3.8 | +479.7 | 0.0 | 55.2 | 4.4 | +551.4 | 0.0 | 27.2 |
| MOVES UNITS SPELL | 0.1 | +4.7 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.8 | +268.0 | 0.0 | 71.8 | 4.5 | +245.9 | 0.0 | 65.8 |
| NEEDED THERE | 0.0 | +5.6 | 8.4 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 6.1 | -223.7 | 15.6 | 64.0 | 6.0 | -207.1 | 10.8 | 45.3 |
| NEXT OBJECTIVE NEARER | 7.2 | -324.0 | 84.5 | 88.2 | 9.4 | -494.1 | 28.0 | 126.5 |
| NO DOUBLE ROUNDS | 2.2 | -114.7 | 210.2 | 39.2 | 3.1 | -127.5 | 258.9 | 95.7 |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 3.8 |
| NOT TURNED | 0.2 | +0.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.9 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -2.7 | 0.0 | 0.0 | 0.6 | -16.3 | 0.0 | 8.8 |
| ONE CHARGE A CHARGER | 2.2 | +0.0 | 0.0 | 49.0 | 3.2 | +0.0 | 0.0 | 45.5 |
| ONE FIGHT FORMULA | 6.2 | -122.3 | 0.0 | 91.8 | 6.0 | -127.2 | 0.0 | 94.9 |
| ONE OBJECTIVE FORMULA | 3.8 | -29.2 | 0.0 | 96.5 | 3.4 | +14.3 | 0.0 | 17.8 |
| ONE TARGET A SHOOTER | 15.4 | +376.4 | 0.0 | 215.4 | 22.0 | +784.8 | 0.0 | 328.6 |
| OPENS A LANE | 0.1 | +0.3 | 3.4 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +5.0 | 4.6 | 0.0 | 0.1 | +5.5 | 4.4 | 0.0 |
| OVERRUNS AWAY | 0.6 | +19.3 | 86.2 | 0.0 | 0.5 | +17.8 | 58.8 | 14.9 |
| PATHS CROSS | 3.5 | +93.1 | 0.0 | 80.8 | 4.5 | +132.8 | 0.0 | 22.4 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.9 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 11.9 |
| PLAN RESULT | 41.4 | +968.9 | 564.0 | 849.0 | 38.4 | +440.8 | 193.3 | 910.8 |
| RANDOM MOVE BY FIGURES | 0.3 | +5.8 | 0.0 | 6.8 | 1.9 | +39.2 | 0.0 | 59.4 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.3 | 0.0 | 3.2 | 0.5 | -18.5 | 0.0 | 5.0 |
| REDIRECT COUNTER | 1.4 | +79.3 | 0.0 | 40.2 | 3.6 | +217.6 | 0.0 | 59.8 |
| REDIRECT WEIGHED | 0.2 | +5.5 | 14.2 | 0.0 | 0.2 | +2.4 | 5.0 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -29.9 | 0.0 | 0.0 | 0.5 | -19.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 6.3 |
| RESERVE FALL BACK | 0.5 | +25.2 | 0.0 | 11.4 | 0.3 | +35.0 | 0.0 | 10.6 |
| RESTRAINS TO SHOOT | 0.1 | +5.8 | 0.0 | 0.0 | 0.0 | +1.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +20.7 | 252.2 | 40.4 | 2.5 | +1.1 | 252.3 | 60.2 |
| RISK BY HIS FIGURE | 12.5 | -186.0 | 0.0 | 287.6 | 13.8 | -253.7 | 0.0 | 282.5 |
| RUN DOWN | 2.0 | -16.9 | 170.3 | 15.2 | 3.0 | -26.3 | 242.2 | 62.6 |
| SAME CHARGE LATER | 0.3 | -4.9 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.0 | 0.0 | 0.0 | 0.1 | -2.8 | 0.0 | 2.2 |
| SEARCH SPOT | 5.3 | +267.7 | 0.0 | 78.8 | 7.3 | +281.9 | 0.0 | 135.6 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +21.7 | 0.0 | 0.0 | 0.5 | +0.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.3 | 0.0 | 13.9 | 0.6 | +18.9 | 0.0 | 8.8 |
| SET-UP ANY TARGET | 0.2 | +20.6 | 0.0 | 0.0 | 0.2 | +27.4 | 18.8 | 18.8 |
| SET-UP MISSED | 0.1 | +4.9 | 0.0 | 0.0 | 0.0 | +1.9 | 5.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 2.2 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +32.9 | 40.2 | 0.0 | 0.6 | +27.2 | 12.6 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -7.4 | 52.7 | 18.4 | 0.1 | -1.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.0 | +96.7 | 0.0 | 159.7 | 15.6 | -55.7 | 0.0 | 271.0 |
| SHOTS IN THE MOVE | 19.2 | +653.6 | 0.0 | 294.6 | 10.7 | +285.4 | 0.0 | 197.5 |
| SPELL SETS UP CHARGE | 0.2 | +65.4 | 0.0 | 0.0 | 0.2 | +27.4 | 18.8 | 18.8 |
| SPELL WORTH | 1.0 | +13.4 | 46.7 | 46.7 | 2.4 | +55.0 | 118.0 | 132.4 |
| SPELLS IN THE FIGHT | 1.0 | -9.6 | 133.9 | 46.0 | 0.6 | -0.3 | 33.4 | 23.6 |
| STAND AND SHOOT | 0.4 | -4.0 | 40.3 | 0.0 | 0.9 | -11.6 | 26.3 | 20.4 |
| STANDS FOR A REASON | 0.0 | +0.0 | 1.4 | 0.0 | 0.6 | +0.0 | 0.0 | 45.6 |
| STANDS STILL | 18.2 | +0.0 | 714.3 | 288.4 | 8.7 | +0.0 | 142.4 | 143.4 |
| STAY WORTH | 21.4 | +3.0 | 467.3 | 270.9 | 10.9 | +97.4 | 102.3 | 170.7 |
| STOPS | 0.1 | +0.7 | 0.0 | 2.4 | 0.0 | +0.1 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 76.5 | 9.2 | 1.4 | +0.0 | 60.6 | 43.3 |
| SURE REACH TOGETHER | 0.4 | +5.7 | 0.0 | 2.2 | 0.4 | +6.7 | 0.0 | 6.6 |
| THE DEARER SUM KEEPS ITS PLAN | 4.4 | +0.0 | 0.0 | 74.0 | 4.2 | +0.0 | 0.0 | 18.5 |
| THE PROMISE ADDS | 0.5 | -36.6 | 7.4 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.6 | +66.1 | 52.3 | 20.8 | 0.5 | +46.6 | 47.0 | 0.0 |
| TIME ON OUR SIDE | 24.8 | +433.0 | 5.7 | 327.0 | 6.4 | +87.9 | 0.0 | 88.7 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 6.6 | 1.5 | +0.0 | 0.0 | 9.3 |
| WAR ENGINE CHARGES | 0.0 | +20.2 | 0.0 | 12.4 | - | - | - | - |
| WAR ENGINE JOBS | 0.0 | +0.0 | 8.4 | 0.0 | 0.0 | +0.0 | 0.0 | 7.4 |
| WHO HITS BACK | 0.4 | +19.6 | 0.0 | 0.0 | 0.4 | +36.9 | 0.0 | 34.8 |
| WHOLE FIGHT | 0.4 | +8.8 | 20.6 | 2.4 | 0.1 | +2.9 | 7.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +6.9 | 8.4 | 3.4 | 0.0 | +0.2 | 0.0 | 5.0 |
| WIDER SPREAD | 2.0 | -6.2 | 233.0 | 41.6 | 2.7 | +4.0 | 162.6 | 73.0 |
| WOUNDS ON THE RANKS | 1.5 | +51.2 | 0.0 | 56.7 | 1.9 | +172.4 | 0.0 | 35.9 |

### Rule changes: ja-opp-f9a8036-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1051 | 1051 | 330 | 13.20 | +5884 | +17.8 |
| SEARCH SPOT | 314 | 314 | 298 | 11.92 | +13742 | +46.1 |
| LEGAL CHARGES ONLY | 272 | 272 | 272 | 10.88 | +0 | +0.0 |
| DEPLOY BY FIGURES | 401 | 401 | 252 | 10.08 | +3917 | +15.5 |
| FIVE ACTION | 2241 | 2241 | 248 | 9.92 | +9397 | +37.9 |
| ONE TARGET A SHOOTER | 933 | 933 | 243 | 9.72 | +3324 | +13.7 |
| PATHS CROSS | 200 | 200 | 200 | 8.00 | +5647 | +28.2 |
| MOVE TO CHARGE COMPUTED | 206 | 206 | 138 | 5.52 | +8949 | +64.8 |
| SHOT RISK POINTS | 641 | 641 | 113 | 4.52 | +3597 | +31.8 |
| TIME ON OUR SIDE | 781 | 685 | 99 | 3.96 | +364 | +3.7 |
| FOUR ROUNDS | 170 | 170 | 85 | 3.40 | +5447 | +64.1 |
| MAX FOR POSITIONING | 308 | 305 | 70 | 2.80 | +157 | +2.2 |
| SHOTS IN THE MOVE | 747 | 711 | 60 | 2.40 | +1223 | +20.4 |
| COVER ONCE | 316 | 236 | 54 | 2.16 | +815 | +15.1 |
| NEXT OBJECTIVE NEARER | 415 | 415 | 54 | 2.16 | +805 | +14.9 |
| MARCH CHECK | 74 | 74 | 52 | 2.08 | +1126 | +21.7 |
| HARD STAY DROPPED | 47 | 47 | 47 | 1.88 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 44 | 44 | 44 | 1.76 | +0 | +0.0 |
| CANNON SIGHT KEPT | 43 | 43 | 43 | 1.72 | +0 | +0.0 |
| ADVANCE LANE KEPT | 40 | 40 | 40 | 1.60 | +0 | +0.0 |
| CHARGE LOSSES | 337 | 337 | 39 | 1.56 | +3552 | +91.1 |
| RISK BY HIS FIGURE | 657 | 657 | 39 | 1.56 | +4414 | +113.2 |
| SHOOTS FROM THE BEST SPOT | 45 | 45 | 38 | 1.52 | +211 | +5.5 |
| RISK BY ARC | 118 | 118 | 37 | 1.48 | +1011 | +27.3 |
| CANNON PLANNED TARGET | 206 | 206 | 36 | 1.44 | -213 | -5.9 |
| MANOEUVRE | 65 | 65 | 36 | 1.44 | +1009 | +28.0 |
| MISSILES IN THE MOVE | 244 | 205 | 35 | 1.40 | +1109 | +31.7 |
| CHARGE NOT DECLARED | 33 | 33 | 33 | 1.32 | -5527 | -167.5 |
| FOLLOW UP WEIGHED | 33 | 33 | 33 | 1.32 | +6864 | +208.0 |
| NEXT CHARGE BY LIST | 302 | 302 | 32 | 1.28 | +684 | +21.4 |
| IDLE COST | 302 | 235 | 30 | 1.20 | +199 | +6.6 |
| LANE BY FIGURES | 30 | 30 | 30 | 1.20 | +1627 | +54.2 |
| CHARGE NOW FIRST | 96 | 96 | 29 | 1.16 | -1775 | -61.2 |
| CHAFF PASSED | 26 | 26 | 26 | 1.04 | -36 | -1.4 |
| FALLS SHORT | 548 | 467 | 26 | 1.04 | +442 | +17.0 |
| LONE WIZARD KEPT IN | 26 | 26 | 26 | 1.04 | +2265 | +87.1 |
| HIS TURN DENIED | 93 | 93 | 25 | 1.00 | +1375 | +55.0 |
| HOLDER AT DEPLOYMENT | 53 | 53 | 25 | 1.00 | +1078 | +43.1 |
| HOLDS AMBUSHERS | 25 | 25 | 25 | 1.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 54 | 54 | 25 | 1.00 | +1126 | +45.0 |
| REDIRECT COUNTER | 124 | 103 | 25 | 1.00 | +1475 | +59.0 |
| ONE OBJECTIVE FORMULA | 181 | 161 | 24 | 0.96 | +1110 | +46.3 |
| TIED UP BY THE SUM | 29 | 29 | 24 | 0.96 | +709 | +29.5 |
| OFF BEST | 22 | 22 | 22 | 0.88 | -477 | -21.7 |
| WOUNDS ON THE RANKS | 84 | 84 | 22 | 0.88 | +835 | +37.9 |
| RESERVE FALL BACK | 20 | 20 | 20 | 0.80 | +1504 | +75.2 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.76 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.76 | +38 | +2.0 |
| FEATURE BUFFS | 68 | 68 | 18 | 0.72 | +284 | +15.8 |
| MARCH BY THE SUM | 18 | 18 | 18 | 0.72 | +715 | +39.7 |
| WHO HITS BACK | 18 | 18 | 18 | 0.72 | +736 | +40.9 |
| NEARER NOT NEEDED | 256 | 255 | 16 | 0.64 | +635 | +39.7 |
| STAY WORTH | 807 | 781 | 16 | 0.64 | +156 | +9.7 |
| COMBAT PIVOT | 15 | 15 | 15 | 0.60 | +0 | +0.0 |
| SCOUT WAITS | 15 | 15 | 15 | 0.60 | +0 | +0.0 |
| AFTERMATH IN POINTS | 13 | 13 | 13 | 0.52 | +1439 | +110.7 |
| CAST JOB | 17 | 17 | 13 | 0.52 | +62 | +4.8 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.52 | +0 | +0.0 |
| ONE FIGHT FORMULA | 306 | 164 | 13 | 0.52 | +57 | +4.4 |
| SURE REACH TOGETHER | 21 | 21 | 12 | 0.48 | +25 | +2.1 |
| CHAFF IN THE MOVE | 24 | 24 | 10 | 0.40 | +198 | +19.9 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.40 | +309 | +30.9 |
| FIGHT TO THE END | 59 | 59 | 9 | 0.36 | +575 | +63.9 |
| GUN MASK | 34 | 34 | 9 | 0.36 | +201 | +22.3 |
| MODEL FACING | 9 | 9 | 9 | 0.36 | +2483 | +275.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.32 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 7 | 0.28 | +22 | +3.1 |
| FALL BACK GOOD ORDER | 119 | 119 | 6 | 0.24 | +147 | +24.5 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.24 | +181 | +30.2 |
| SPELLS IN THE FIGHT | 41 | 41 | 5 | 0.20 | +199 | +39.8 |
| STUCK PIVOT | 5 | 5 | 5 | 0.20 | +0 | +0.0 |
| SUPPORT NARROWED | 59 | 59 | 5 | 0.20 | -104 | -20.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.16 | -208 | -52.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.16 | +0 | +0.0 |
| FOCUS FIRE | 4 | 4 | 4 | 0.16 | +66 | +16.4 |
| HIS MOVE AND SHOT | 95 | 95 | 4 | 0.16 | +48 | +12.0 |
| HONEST WORTH | 135 | 135 | 4 | 0.16 | +128 | +32.0 |
| JOINT CHARGE NOW | 15 | 15 | 4 | 0.16 | +328 | +81.9 |
| MISSILES NEXT TURN | 284 | 222 | 4 | 0.16 | +63 | +15.8 |
| OVERRUNS AWAY | 27 | 27 | 4 | 0.16 | +161 | +40.3 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.16 | -117 | -29.2 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.16 | +191 | +47.6 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 0.12 | +170 | +56.5 |
| BOMBING RUN | 3 | 3 | 3 | 0.12 | +123 | +40.9 |
| HIS CHARGE DENIED | 18 | 18 | 3 | 0.12 | +108 | +35.9 |
| HUNT IN PAIRS | 10 | 7 | 3 | 0.12 | +63 | +20.9 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.12 | +43 | +14.2 |
| WHOLE FIGHT | 12 | 12 | 3 | 0.12 | +48 | +16.1 |
| WIDER SPREAD | 118 | 118 | 3 | 0.12 | +36 | +11.9 |
| CATCH ODDS | 2 | 2 | 2 | 0.08 | -27 | -13.6 |
| DEFENSIVE ARMY | 5 | 5 | 2 | 0.08 | -32 | -16.1 |
| FALLBACK BY WORTH | 6 | 6 | 2 | 0.08 | +65 | +32.6 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.08 | +94 | +46.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| OPENS UP | 5 | 5 | 2 | 0.08 | +63 | +31.7 |
| REFUSING RETIRES | 9 | 9 | 2 | 0.08 | -0 | -0.1 |
| SET UP TOGETHER | 17 | 16 | 2 | 0.08 | +161 | +80.7 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.08 | +103 | +51.3 |
| EDGE GIVE GROUND | 9 | 9 | 1 | 0.04 | +2 | +2.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.04 | +4 | +4.5 |
| KILLS COUNT | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| LONG SHOT | 13 | 13 | 1 | 0.04 | +1 | +0.6 |
| NEEDED THERE | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 134 | 134 | 1 | 0.04 | +40 | +40.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.04 | +54 | +54.0 |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 1 | 0.04 | +20 | +20.0 |
| RUN DOWN | 125 | 125 | 1 | 0.04 | +0 | +0.1 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.04 | +445 | +445.5 |
| WAR ENGINE JOBS | 2 | 2 | 1 | 0.04 | -27 | -26.8 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 12 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 7 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARACTER GUNS | 41 | 41 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 19 | 19 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 10 | 10 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 225 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 5 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 10 | 10 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 46 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 121 | 121 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 132 | 132 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 187 | 187 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 125 | 125 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 40 | 40 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT TURNED | 11 | 11 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 27 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 135 | 135 | 0 | 0.00 | - | - |
| OPENS A LANE | 8 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 1994 | trace | - | - | - | - |
| REFORMS TO MEET IT | 36 | 36 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 13 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 12 | 12 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 86 | not checked | - | - | - | - |
| STAND AND SHOOT | 33 | 33 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 674 | 674 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 214 | not checked | - | - | - | - |
| THE PROMISE ADDS | 12 | 12 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 19 | not checked | - | - | - | - |
| WAITS AGAIN | 72 | 72 | 0 | 0.00 | - | - |

### Off best figure: ja-opp-f9a8036-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.68 | 0.56 | 182.7 |
| CHARGE NOW FIRST | rule | 0.52 | 0.60 | 63.4 |
| PATHS CROSS | rule | 0.48 | 0.64 | 17.7 |
| JOB FIRST | gate | 0.08 | 0.44 | 29.4 |
| CANNON PLANNED TARGET | rule | 0.32 | 0.08 | 29.1 |
| CHAFF PASSED | rule | 0.24 | 0.08 | 4.4 |
| SUPPORT NARROWED | rule | - | 0.20 | 20.9 |
| BEST PRIZE | rule | 0.04 | 0.12 | 52.0 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 29.2 |
| AFTERMATH BAND | gate | 0.04 | 0.08 | 3.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.04 | 12.7 |
| CATCH ODDS | rule | - | 0.08 | 13.6 |
| DEFENSIVE ARMY | rule | 0.08 | - | 16.1 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 12.9 |
| FIGHT ORDER BAND | gate | 0.04 | - | 3.6 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.04 | 12.6 |
| REDIRECT WEIGHED | rule | - | 0.04 | 92.3 |
| RULE SWITCHED OFF | gate | 0.04 | - | 30.0 |
| WAR ENGINE JOBS | rule | 0.04 | - | 26.8 |
| WHO HITS BACK | rule | - | 0.04 | 2.2 |

### Plans: ja-opp-f9a8036-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.4 | 61% | 399 | 243 | 61% |
| Mine | join | 0.3 | 100% | 5 | 0 | 0% |
| Mine | move | 28.2 | 95% | 1851 | 0 | 0% |
| Mine | shoot | 10.4 | 59% | 325 | 726 | 223% |
| Mine | support | 0.1 | 100% | 1 | 0 | 0% |
| Opponent | charge | 3.0 | 62% | 587 | 292 | 50% |
| Opponent | join | 0.8 | 95% | 32 | 0 | 0% |
| Opponent | move | 30.9 | 92% | 1562 | 0 | 0% |
| Opponent | shoot | 3.2 | 56% | 137 | 149 | 109% |
| Opponent | support | 0.5 | 75% | 0 | 0 | 0% |

### Packages: hunt the guns, ja-opp-f9a8036-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 447 | 0 | 0% | 4 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 100% | - | 612 | 11 | 0% | 71 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.6 | 3 | 0 | 0% | 0% | 33% | - | 502 | 4 | 0% | 19 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ja-opp-f9a8036-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.4 | 26% | 67% | 0% | - | 33% | 0% | 0% | 44% | 22% |
| Opponent | REDIRECT COUNTER | 3.6 | 19% | 59% | 6% | 0% | 44% | 0% | 12% | 38% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-opp-f9a8036-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 13 | 47 (13) | 10 | 37 | 48 | 54% | 2.7 | 110 (4) | 0 (4) | 0 (5) | 61 (11) | 0 (2) |
| Mine | Character | 93 | 48 (93) | 46 | 3 | 21 | 13% | 2.7 | 66 (31) | 30 (39) | 54 (17) | 57 (52) | 42 (35) |
| Mine | Clean-up | 11 | 57 (11) | 23 | 34 | 39 | 36% | 3.0 | 49 (6) | 99 (4) | 0 (1) | 79 (8) | 23 (3) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 73 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 32 | 45 (32) | 23 | 22 | 39 | 16% | 3.0 | 66 (20) | 19 (7) | 22 (5) | 46 (20) | 42 (12) |
| Mine | Hammer | 37 | 48 (37) | 16 | 31 | 23 | 22% | 2.9 | 96 (12) | 31 (22) | 0 (3) | 52 (25) | 39 (12) |
| Mine | Holder | 17 | 81 (17) | 12 | 69 | 30 | 59% | 4.1 | 114 (5) | 75 (11) | 0 (1) | 114 (9) | 43 (8) |
| Mine | Shooter | 37 | 98 (37) | 38 | 60 | 35 | 8% | 1.8 | 97 (11) | 96 (21) | 107 (5) | 137 (25) | 31 (12) |
| Mine | War machine | 54 | 28 (54) | 28 | 0 | 50 | 2% | 1.7 | 34 (23) | 24 (24) | 21 (7) | 0 (6) | 31 (48) |
| Mine | Wizard | 13 | 54 (13) | 54 | 0 | 16 | 0% | 3.5 | 71 (7) | 0 (2) | 0 (1) | 88 (4) | 36 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 41 | 67 (41) | 11 | 56 | 48 | 49% | 2.8 | 86 (11) | 95 (17) | 18 (13) | 80 (32) | 14 (9) |
| Opponent | Character | 79 | 36 (79) | 36 | 0 | 34 | 29% | 2.7 | 11 (22) | 53 (38) | 36 (12) | 43 (46) | 31 (26) |
| Opponent | Clean-up | 9 | 63 (9) | 46 | 16 | 34 | 33% | 2.5 | 0 (2) | 89 (6) | 0 (1) | 38 (8) | 205 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 35 | 33 (35) | 19 | 13 | 37 | 37% | 3.1 | 38 (10) | 37 (22) | 0 (3) | 44 (18) | 20 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 19 | 80% | 5.0 | 0 (3) | - | 0 (2) | 0 (3) | 0 (2) |
| Opponent | Hammer | 51 | 31 (51) | 22 | 9 | 47 | 29% | 3.0 | 28 (14) | 36 (23) | 25 (14) | 24 (30) | 42 (21) |
| Opponent | Holder | 26 | 71 (26) | 9 | 62 | 25 | 58% | 3.2 | 39 (6) | 128 (14) | 4 (6) | 71 (15) | 71 (11) |
| Opponent | Shooter | 25 | 77 (25) | 16 | 60 | 32 | 16% | 1.9 | 61 (8) | 99 (12) | 35 (5) | 67 (15) | 90 (10) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 13 | 7 (13) | 7 | 0 | 53 | 8% | 1.5 | 12 (7) | 0 (4) | 0 (2) | 0 (2) | 8 (11) |
| Opponent | Wizard | 15 | 27 (15) | 27 | 0 | 14 | 20% | 2.5 | 0 (4) | 51 (8) | 0 (2) | 32 (10) | 14 (4) |

### Charged fights: ja-opp-f9a8036-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 298 | 190 | 2.0 | 1.2 | 95 | 17 | +78 | 1 of 10 | 9 of 10 | +92 | +74 |
| Mine | Chaos Dwarfs | 3 | 98 | 446 | 3.7 | 1.4 | 122 | 28 | +93 | 6 of 11 | 7 of 11 | +178 | +75 |
| Mine | Dwarfen Mountain Holds | 4 | 349 | 10 | 1.2 | 1.6 | 8 | 37 | -28 | 2 of 5 | 2 of 5 | -61 | +20 |
| Mine | Empire of Man | 5 | 259 | 39 | 1.4 | 1.0 | 28 | 27 | +1 | 0 of 7 | 5 of 7 | - | +1 |
| Mine | Grand Cathay | 4 | 397 | 366 | 3.5 | 1.1 | 104 | 0 | +104 | 7 of 14 | 9 of 14 | +60 | +108 |
| Mine | High Elf Realms | 4 | 130 | 519 | 2.8 | 1.0 | 189 | 0 | +189 | 5 of 11 | 11 of 11 | - | +189 |
| **Mine** | all armies | 25 | 263 | 242 | 2.3 | 1.2 | 104 | 15 | +90 | 21 of 58 | 43 of 58 | +52 | +96 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 17 | -17 | 1 of 3 | 2 of 3 | - | -17 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 160 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 373 | 683 | 5.0 | 1.6 | 137 | 41 | +96 | 5 of 5 | 5 of 5 | +342 | -68 |
| Opponent | High Elf Realms | 2 | 62 | 755 | 4.0 | 1.1 | 189 | 37 | +152 | 2 of 8 | 7 of 8 | +561 | +94 |
| Opponent | Lizardmen | 1 | 0 | 625 | 4.0 | 1.0 | 156 | 0 | +156 | 2 of 4 | 4 of 4 | - | +156 |
| Opponent | Ogre Kingdoms | 2 | 42 | 42 | 3.0 | 1.0 | 14 | 15 | -1 | 2 of 6 | 3 of 6 | - | -1 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 424 | 3.5 | 1.1 | 121 | 16 | +106 | 2 of 7 | 5 of 7 | +347 | +65 |
| Opponent | Skaven | 2 | 68 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 380 | 1171 | 4.0 | 1.0 | 293 | 0 | +293 | 3 of 4 | 2 of 4 | - | +293 |
| Opponent | Vampire Counts | 3 | 209 | 94 | 2.3 | 1.0 | 40 | 0 | +40 | 2 of 7 | 4 of 7 | - | +40 |
| Opponent | Warriors of Chaos | 4 | 0 | 271 | 2.0 | 1.0 | 136 | 126 | +10 | 6 of 8 | 5 of 8 | - | +10 |
| Opponent | Wood Elf Realms | 4 | 103 | 253 | 3.2 | 1.2 | 78 | 55 | +23 | 8 of 13 | 8 of 13 | -99 | +59 |
| **Opponent** | all armies | 25 | 92 | 292 | 2.7 | 1.1 | 109 | 37 | +72 | 34 of 67 | 47 of 67 | +185 | +59 |

### Effective charges: ja-opp-f9a8036-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 1 (net +126) | 1 (net +185) | 1 (net +0) | 2 (net +62) | 0 | 5 (net +69) | 0 | 10% (1 of 10) |
| Mine | Chaos Dwarfs | 11 | 3 (net +32) | 0 | 1 (net -310) | 2 (net +375) | 1 (net +145) | 2 (net +58) | 2 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +20) | 0 | 1 (net -183) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 7 | 1 (net -189) | 0 | 1 (net +175) | 2 (net +10) | 0 | 3 (net +0) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 14 | 1 (net +229) | 1 (net +0) | 3 (net +40) | 3 (net +154) | 2 (net +60) | 2 (net +160) | 2 | 25% (3 of 12) |
| Mine | High Elf Realms | 11 | 0 | 0 | 5 (net +135) | 3 (net +231) | 1 (net +45) | 2 (net +332) | 0 | 45% (5 of 11) |
| Opponent | Beastmen Brayherds | 3 | 2 (net -26) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 5 | 0 | 1 (net +278) | 1 (net +0) | 1 (net +0) | 0 | 2 (net +100) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 8 | 1 (net -151) | 0 | 0 | 4 (net +278) | 0 | 2 (net +52) | 1 | 0% (0 of 7) |
| Opponent | Lizardmen | 4 | 0 | 0 | 1 (net +170) | 1 (net +77) | 0 | 2 (net +189) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 6 | 3 (net +28) | 0 | 2 (net +0) | 0 | 0 | 0 | 1 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 7 | 2 (net +118) | 0 | 0 | 1 (net +230) | 1 (net +110) | 1 (net +162) | 2 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net +388) | 0 | 1 (net +395) | 1 (net +0) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 7 | 3 (net +0) | 0 | 2 (net +141) | 1 (net +0) | 0 | 1 (net +0) | 0 | 29% (2 of 7) |
| Opponent | Warriors of Chaos | 8 | 1 (net +240) | 0 | 0 | 0 | 0 | 5 (net +169) | 2 | 0% (0 of 6) |
| Opponent | Wood Elf Realms | 13 | 5 (net -98) | 1 (net -97) | 1 (net +0) | 2 (net +160) | 2 (net +74) | 0 | 2 | 9% (1 of 11) |

### Charged fights, damage counted: ja-opp-f9a8036-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 186 | 198 | +37 | 88 | 98 | -10 | -5.5 |
| Mine | 50-54% | 2 | 149 | 328 | +92 | 92 | 0 | +92 | +62.1 |
| Mine | Effective (55-75%) | 12 | 269 | 261 | +55 | 91 | 36 | +55 | +20.6 |
| Mine | 76-89% | 14 | 300 | 129 | +149 | 160 | 12 | +148 | +49.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 206 | 178 | +84 | 120 | 35 | +85 | +41.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 574 | 78 | +78 | 78 | 0 | +78 | +13.5 |
| Mine | No odds | 4 | 315 | 186 | +110 | 110 | 32 | +78 | +24.9 |
| Mine | All fights | 58 | 270 | 184 | +90 | 115 | 33 | +82 | +30.2 |
| Opponent | Long shot (under 50%) | 19 | 174 | 252 | +34 | 99 | 73 | +26 | +14.9 |
| Opponent | 50-54% | 2 | 412 | 252 | +90 | 256 | 135 | +121 | +29.3 |
| Opponent | Effective (55-75%) | 8 | 242 | 175 | +106 | 124 | 4 | +120 | +49.4 |
| Opponent | 76-89% | 12 | 265 | 215 | +145 | 160 | 24 | +136 | +51.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 314 | 170 | +113 | 144 | 30 | +114 | +36.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 491 | 86 | +86 | 86 | 83 | +3 | +0.6 |
| Opponent | No odds | 8 | 136 | 284 | -66 | 98 | 146 | -48 | -35.5 |
| Opponent | All fights | 67 | 247 | 214 | +72 | 127 | 58 | +70 | +28.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-opp-f9a8036-p1 | move | 231 | 55 (24%) | 40 (17%) | 27 (12%) | 149 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524, L1224, L1527 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: ja-mine-f9a8036-p3

### Scorecard: ja-mine-f9a8036-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 165 |
| L0126 | 6 | 1 | Mine | yes | 18 | - | 0 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 9 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 5 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 0 | 1 | 0 | 0 | 0 | 165 |
| L0327 | 3 | 1 | Mine | yes | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0327 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 0 | 0 | 1 | 0 | 0 | 70 |
| L0429 | 3 | 1 | Mine | yes | 9 | 3 | 4 | 0 | 0 | 0 | 0 | 310 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 305 |
| L0516 | 6 | 1 | Opponent | no | 13 | 6 | 1 | 1 | 0 | 0 | 0 | 80 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 233 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 1 | 0 | 0 | 343 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 12 | 2 | 4 | 0 | 1 | 0 | 0 | 125 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 3 | 0 | 0 | 0 | 0 | 515 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0725 | 5 | 1 | Opponent | yes | - | 4 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 175 |
| L0815 | 5 | 1 | Opponent | no | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 130 |
| L0831 | 3 | 1 | Opponent | no | 7 | 4 | 1 | 2 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 265 |
| L0922 | 4 | 1 | Opponent | yes | 4 | 2 | 1 | 3 | 3 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1030 | 4 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 285 |
| L1122 | 6 | 1 | Mine | no | 3 | 4 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1122 | 6 | 1 | Opponent | no | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 12 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 307 |
| L1327 | 1 | 1 | Mine | no | 14 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 75 |
| L1422 | 6 | 1 | Mine | no | 8 | 2 | 5 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 8 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 4 | 5 | 5 | 1 | 0 | 0 | 0 | 115 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 36% | 6.3 | 3.5 | 2.0 | 1.0 | 0.2 | 0.0 | 0.0 | 150.0 |
| **Average** | | | Opponent | 23% | 4.5 | 2.7 | 2.7 | 1.7 | 0.4 | 0.0 | 0.0 | 108.0 |

### KPIs: ja-mine-f9a8036-p3

Rules off - Opponent only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 25 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (32 of 111) | 1% (1 of 122) | 14% (33 of 233) |
| Winner chose to follow up after the loser gave ground |  | 76% (29 of 38); on the table 79% | 92% (24 of 26); on the table 92% | 83% (53 of 64); on the table 84% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (2 of 4); on the table 50% | 78% (7 of 9); on the table 78% | 69% (9 of 13); on the table 69% |
| Winner chose to pursue after the loser fled |  | 75% (12 of 16); on the table 81% | 91% (10 of 11); on the table 91% | 81% (22 of 27); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 74% (43 of 58); on the table 78% | 89% (41 of 46); on the table 89% | 81% (84 of 104); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 28% (81 of 288) | 33% (57 of 174) | 30% (138 of 462) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (81 of 203) | 46% (57 of 125) | 42% (138 of 328) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (6 of 8) | 62% (20 of 32) | 65% (26 of 40) |
| Points that never fought | lower | 41% (20205 of 48695) | 49% (24250 of 49992) | 45% (44455 of 98687) |
|   infantry points that never fought | lower | 43% (4554 of 10506) | 55% (5492 of 10076) | 49% (10046 of 20582) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (121 of 202) | 68% (127 of 188) | 64% (248 of 390) |
| Bound items with a magic missile used (at least once a game) |  | 91% (21 of 23); 2.5 uses a game | 71% (10 of 14); 1.5 uses a game | 84% (31 of 37); 2.0 uses a game |
| Bound items with another spell used |  | 64% (9 of 14); 0.8 uses a game | 67% (4 of 6); 0.2 uses a game | 65% (13 of 20); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (8 of 17); 0.3 uses a game | 33% (3 of 9); 0.1 uses a game | 42% (11 of 26); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (22467 of 42125) | 66% (29090 of 43797) | 60% (51557 of 85922) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (26%) | 1.5 (32%) | 3.6 (28%) |
| MARCHED: its unit marched | 2.0 (25%) | 1.1 (23%) | 3.1 (24%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.1 (3%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.9 (23%) | 1.1 (24%) | 3.0 (23%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.0 (1%) | 0.3 (2%) |
| FLEEING: fleeing | 0.2 (2%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.5 (6%) | 0.6 (14%) | 1.1 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (10%) | 0.2 (3%) | 1.0 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.4 | 2.9 | 5.5 | 0.7 | 2.0 |
| not cast | 3.4 | 1.5 | 4.5 | 13.0 | 2.9 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (59%) | 0.3 (6%) | 3.6 (28%) | 0.5 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.1 (24%) | 0.6 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (5%) | 0.8 (17%) | 3.0 (23%) | 0.5 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.7 (16%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (3%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 0.4 (13%) | 0.0 (0%) | 0.4 (10%) | 1.1 (9%) | 0.2 (8%) | 0.9 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (19%) | 0.4 (24%) | 0.5 (11%) | 1.0 (7%) | 0.1 (3%) | 2.1 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (8%) | 0.1 (2%) | 0.2 (1%) | 0.9 (30%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (61%) | 0.0 (0%) | 1.8 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.9 a game | 1.1 a game | 1.5 a game |
| stood (cast and not dispelled) | 51% (22 of 43) | 41% (9 of 22) | 48% (31 of 65) |
| the unit moved after it | 86% (19 of 22) | 89% (8 of 9) | 87% (27 of 31) |
| it charged on its next turn | 5% (1 of 22) | 0% (0 of 9) | 3% (1 of 31) |
| the enemy charged it first | 9% (2 of 22) | 0% (0 of 9) | 6% (2 of 31) |
| it fought by the end of its next turn | 0% (0 of 22) | 0% (0 of 9) | 0% (0 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 22) | 0% (0 of 9) | 0% (0 of 31) |
| none of these (no charge, no fight, no charge escaped) | 86% (19 of 22) | 100% (9 of 9) | 90% (28 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (411 of 615) | 55% (267 of 486) | 62% (678 of 1101) |
|   cavalry | 71% (34 of 48) | 75% (54 of 72) | 73% (88 of 120) |
|   character | 56% (50 of 89) | 24% (21 of 86) | 41% (71 of 175) |
|   chariot | 66% (53 of 80) | 59% (22 of 37) | 64% (75 of 117) |
|   infantry | 67% (90 of 134) | 59% (110 of 188) | 62% (200 of 322) |
|   monster | 82% (9 of 11) | 57% (4 of 7) | 72% (13 of 18) |
|   war machine | 69% (175 of 253) | 58% (56 of 96) | 66% (231 of 349) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (23%) | 1.5 (17%) | 3.4 (20%) |
| CHARGED: it charged | 1.1 (13%) | 1.4 (16%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (5%) | 0.4 (5%) | 0.9 (5%) |
| MOVED: a war machine that moved | 1.9 (23%) | 0.9 (10%) | 2.8 (16%) |
| NO TARGET IN RANGE | 1.0 (12%) | 1.6 (18%) | 2.6 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.3 (4%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 2.2 (25%) | 3.5 (21%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.3 | 81% | 6.5 pts | 38 pts |
| character | 3.3 | 1.2 | 80% | 6.9 pts | 23 pts |
| chariot | 3.0 | 1.6 | 67% | 15.8 pts | 48 pts |
| infantry | 12.0 | 3.6 | 76% | 8.5 pts | 102 pts |
| monster | 0.9 | 0.1 | 86% | 4.7 pts | 4 pts |
| war machine | 9.4 | 8.7 | 61% | 27.9 pts | 263 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.0 | 4.1 |
| Charges that made contact a game | 2.8 | 3.4 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.05 declared, 0.86 contact (22 units) | 0.89 declared, 0.74 contact (19 units) | 0.98 declared, 0.80 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 1.33 declared, 0.50 contact (6 units) | 1.29 declared, 0.57 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.34 contact (149 units) | 0.53 declared, 0.36 contact (187 units) | 0.47 declared, 0.35 contact (336 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (35 of 52) | 70% (7 of 10) | 86% (6 of 7) | 70% (48 of 69) |
| Character in a unit | 87% (26 of 30) | 70% (7 of 10) | 100% (1 of 1) | 83% (34 of 41) |
| Character on its own | 89% (16 of 18) | 56% (19 of 34) | 40% (19 of 47) | 55% (54 of 99) |
| Chariot | 100% (9 of 9) | 75% (9 of 12) | - | 86% (18 of 21) |
| Infantry | 52% (29 of 56) | 38% (10 of 26) | 100% (4 of 4) | 50% (43 of 86) |
| Monster | 62% (10 of 16) | 67% (2 of 3) | - | 63% (12 of 19) |
| Monstrous | 75% (3 of 4) | 100% (6 of 6) | - | 90% (9 of 10) |
| War Machines | 67% (29 of 43) | 50% (1 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 28% (27 of 96) | 26% | 45% (10 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 81% (13 of 16); on the table 88% | 39% (14 of 36) | 45% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 72% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 60% (6 of 10); on the table 70% | 47% (14 of 30) | 40% | 61% (36 of 59) | 0.0 uses a game | 50% (1 of 2); 1.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 73% (11 of 15); on the table 73% | 30% (57 of 192) | 50% | 62% (46 of 74) | 83% (15 of 18); 6.5 uses a game | 75% (3 of 4); 0.5 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 79% (15 of 19); on the table 79% | 5% (2 of 42) | 33% | 63% (34 of 54) | 89% (8 of 9); 3.6 uses a game | 58% (7 of 12); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (1 of 1); on the table 100% | - | 46% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 3% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 67% (4 of 6) | 61% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 3 | 88% (7 of 8); on the table 88% | 33% (2 of 6) | 41% | 60% (9 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 100% (9 of 9); on the table 100% | 47% (17 of 36) | 53% | 64% (18 of 28) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 73% (8 of 11); on the table 73% | 0% (0 of 6) | 46% | 70% (23 of 33) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 73% | 77% (17 of 22) | 33% (1 of 3); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-mine-f9a8036-p3, 25 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (25) | 49% (21) | 48% (46) |
| ...free all their last turn and able to turn (per game) | 0.60 | 0.56 | 1.16 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.24 | 0.00 | 0.24 |
| ...with the charger already in that arc before they moved (per game) | 0.40 | 0.36 | 0.76 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.32 | 0.40 |

### Quality by phase: ja-mine-f9a8036-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.4 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 66% (51 of 77) | 47% (52 of 110) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (144 of 321) | 49% (60 of 122) |
| Strategy | Support requests answered (helper made contact too) | 67% (4 of 6) | 73% (8 of 11) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 70% (7 of 10) | 100% (4 of 4) |
| Strategy | Joined characters whose unit fought | 47% (20 of 43) | 35% (8 of 23) |
| Strategy | Lone characters that fought | 72% (41 of 57) | 67% (46 of 69) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 150.0 | 108.0 |
| Movement | Fights charged into per game | 2.5 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 61, net -113 | 16 of 71, net +48 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 61, net +230 | 10 of 71, net -24 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 61, net +57 | 9 of 71, net -14 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 61, net +91 | 15 of 71, net +98 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (134 of 252) | 43% (103 of 237) |
| Shooting | Points destroyed by shooting units | 49.8 | 33.7 |
| Shooting | War machine shots | 7.0 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (87 of 175) | 43% (26 of 61) |
| Shooting | Points destroyed by war machines | 67.6 | 31.8 |
| Magic | Magic missiles cast | 2.0 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (21 of 50) | 38% (13 of 34) |
| Magic | Wounds caused by magic missiles | 3.7 | 2.5 |
| Magic | Wounds caused by other spells | 2.9 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 89.4 | 37.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 0.9 / 0.2 | 2.0 / 0.2 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 244.4 | 219.0 |
| Combat | Points run down | 100.0 | 64.7 |
| Combat | Net points per charged fight, damage counted | +66 | +44 |
| Combat | Net per 100 charger points, damage counted | +23.0 | +14.7 |
| Combat | First round won (charged fights) | 83% | 68% |
| Combat | Net points per charged fight | +59 | +38 |
| Combat | Net points per supported fight / lone fight | +181 / +42 | -30 / +47 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 63 | 30 of 75 |
| Game | Points lost | 519.3 | 599.5 |
| Game | VP from objectives | 567.2 | 681.2 |
| Game | Lone holders (player turns) | 6.3 | 4.5 |

- Mine won / drew / lost: 9 / 7 / 9 of 25 ended games (of 25); mean margin (Mine - Opponent) +22 VP
- The side that went first won 11 of 18 games with a winner
- Points traded per game (both sides' losses): 1119
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-mine-f9a8036-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 4.9 | 1.0 | +0.0 | 0.0 | 8.0 |
| AFTERMATH IN POINTS | 0.3 | +54.3 | 0.0 | 4.6 | 0.1 | +0.7 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.2 | +15.5 | 0.0 | 4.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 32.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.3 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 4.6 |
| BLOWS WHERE AIMED | 0.1 | -3.3 | 6.3 | 0.0 | 0.1 | -12.1 | 12.9 | 0.0 |
| BOMBING RUN | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 6.0 | 0.1 | +0.0 | 0.0 | 6.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 35.2 | 4.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 7.0 | +96.4 | 262.5 | 136.2 | 2.0 | +61.0 | 72.6 | 28.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +21.3 | 38.4 | 3.4 | 0.3 | +10.8 | 33.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +38.3 | 5.4 | 12.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 43.6 | 0.5 | +0.0 | 0.0 | 25.4 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.1 | +4.2 | 0.0 | 8.8 | 0.4 | +14.0 | 0.0 | 6.2 |
| CHAFF PASSED | 0.4 | -1.1 | 0.0 | 0.0 | 0.2 | -0.6 | 10.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.4 |
| CHARGE LOSSES | 4.9 | -225.0 | 0.0 | 116.2 | 5.9 | -346.4 | 0.0 | 147.3 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 23.2 | 2.4 | 0.6 | +0.0 | 21.3 | 7.8 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 230.3 | 13.5 | 2.1 | +0.0 | 166.4 | 44.8 |
| CHARGER SLAIN LOST | 0.3 | -5.9 | 37.6 | 4.5 | 0.4 | -13.9 | 14.1 | 15.8 |
| CHEAPEST HOLDER | 0.2 | -2.3 | 0.0 | 0.0 | 0.3 | -12.8 | 20.6 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 21.1 | 21.2 | 0.2 | +0.0 | 17.0 | 6.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +135.7 | 31.4 | 29.4 | 0.6 | +17.6 | 16.9 | 27.8 |
| COVER ONCE | 8.7 | -638.1 | 0.0 | 141.1 | 6.3 | -450.5 | 0.0 | 118.1 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.8 | +2.0 | 0.0 | 8.2 | 7.4 | +56.4 | 0.0 | 49.5 |
| EDGE GIVE GROUND | 0.2 | +10.7 | 22.6 | 0.0 | 0.1 | +7.4 | 12.9 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.2 | +15.1 | 225.1 | 16.4 | 3.0 | +16.2 | 200.9 | 106.3 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 8.6 |
| FALLS SHORT | 3.8 | +74.6 | 0.0 | 112.2 | 17.6 | +219.8 | 0.0 | 210.7 |
| FEATURE BUFFS | 1.5 | +36.4 | 0.0 | 20.6 | 0.8 | +15.3 | 0.0 | 4.4 |
| FIGHT LIFT | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.2 | +19.0 | 93.3 | 23.1 | 2.0 | +141.8 | 122.3 | 82.4 |
| FIRE IN ORDER | 0.3 | +0.0 | 18.6 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 45.5 | +2549.7 | 833.5 | 593.6 | 44.6 | +2811.3 | 497.8 | 610.4 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 111.4 | 4.8 | +0.0 | 0.0 | 77.6 |
| FOCUS FIRE | 0.1 | +6.6 | 8.2 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +149.2 | 0.0 | 0.0 | 0.7 | +217.9 | 0.0 | 22.8 |
| FOUR ROUNDS | 3.1 | +301.0 | 311.4 | 40.4 | 4.2 | +544.6 | 266.3 | 127.0 |
| FRIEND CHARGES FIRST | 0.1 | -27.3 | 0.0 | 0.0 | 0.4 | -28.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -15.8 | 0.0 | 0.0 | 0.2 | -16.4 | 0.0 | 4.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +10.3 | 0.0 | 0.0 | 0.1 | +8.4 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.8 | 14.2 | 0.0 | 0.3 | -7.6 | 35.4 | 22.8 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.5 | 0.0 | 1.8 |
| GROUND FLIERS | 0.1 | +4.2 | 0.0 | 0.0 | 0.0 | +2.1 | 0.0 | 0.0 |
| GUN FIGURES | 1.1 | +4.8 | 29.9 | 12.4 | 0.3 | +1.9 | 8.4 | 0.0 |
| GUN MASK | 0.9 | +22.6 | 0.0 | 0.0 | 0.6 | +16.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 12.4 | 0.7 | +0.0 | 0.0 | 16.3 |
| HE SHOOTS OR CHARGES | 1.8 | +0.0 | 0.0 | 64.3 | 2.8 | +0.0 | 0.0 | 72.4 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.4 | +10.1 | 34.8 | 0.0 | 0.3 | +15.6 | 22.4 | 31.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 50.2 | 3.8 | +0.0 | 0.0 | 86.5 |
| HIS LEGAL MOVES | 4.2 | +0.0 | 0.0 | 103.5 | 3.6 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.8 | -26.1 | 0.0 | 26.0 | 2.1 | -53.0 | 0.0 | 58.2 |
| HIS RANDOM MOVE | 2.6 | +0.0 | 0.0 | 32.4 | 0.9 | +0.0 | 0.0 | 3.2 |
| HIS SHOT LIST | 17.1 | +705.2 | 0.0 | 275.4 | 25.0 | +1546.5 | 0.0 | 310.0 |
| HIS TURN DENIED | 1.1 | +32.2 | 64.7 | 40.4 | 2.4 | +107.6 | 162.2 | 84.5 |
| HOLDER AT DEPLOYMENT | 0.7 | +121.7 | 0.0 | 0.0 | 0.9 | +151.3 | 0.0 | 3.2 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -106.7 | 251.0 | 24.8 | 3.6 | -164.1 | 245.1 | 81.2 |
| HUNT IN PAIRS | 0.3 | +9.7 | 0.0 | 0.0 | 0.4 | +20.3 | 0.0 | 7.8 |
| HUNT RESULT | - | - | - | - | 0.1 | +14.9 | 0.0 | 6.4 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +18.2 | 8.4 | 6.4 |
| IDLE COST | 1.6 | -22.1 | 0.0 | 29.0 | 11.4 | -196.3 | 0.0 | 100.5 |
| JOINT CHARGE NOW | 0.6 | +3.4 | 37.3 | 6.8 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -7.9 | 10.4 | 0.0 | 0.2 | -3.5 | 0.0 | 17.2 |
| KEEP FALLS | 0.2 | +2.0 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +21.5 | 0.0 | 0.0 | 1.2 | +61.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 213.2 | 156.6 | 5.7 | +0.0 | 248.1 | 412.8 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +46.2 | 0.0 | 3.8 | 0.5 | +35.7 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.9 | 11.1 | 0.0 | 0.2 | -1.3 | 12.6 | 9.5 |
| LOST CHARGE | 0.0 | -0.5 | 0.0 | 0.0 | 0.1 | -0.1 | 3.6 | 2.5 |
| LURE BY WHAT IT DRAWS | 0.0 | -5.2 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +4.0 | 0.0 | 25.4 | 0.2 | +4.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.6 | +19.3 | 0.0 | 26.4 | 1.4 | +34.8 | 0.0 | 9.8 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +48.7 | 0.0 | 0.0 | 0.3 | +5.6 | 0.0 | 8.0 |
| MARCH CHECK | 0.8 | +61.1 | 0.0 | 13.0 | 1.1 | +43.6 | 0.0 | 18.3 |
| MARCH OVER CASTS | 1.0 | +66.0 | 0.0 | 0.0 | 0.6 | +43.0 | 0.0 | 23.7 |
| MAX FOR POSITIONING | 7.0 | +90.6 | 0.0 | 129.9 | 6.3 | +85.6 | 0.0 | 110.8 |
| MISSILES IN THE MOVE | 5.7 | +203.6 | 0.0 | 97.2 | 4.0 | +61.4 | 0.0 | 62.7 |
| MISSILES NEXT TURN | 7.0 | +138.1 | 0.0 | 106.5 | 4.9 | +40.4 | 0.0 | 84.6 |
| MODEL FACING | 0.2 | +46.1 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.3 | +7.6 | 0.0 | 15.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -32.4 | 0.0 | 15.2 | 0.1 | -5.3 | 0.0 | 9.4 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 3.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +649.7 | 0.0 | 59.6 | 4.6 | +720.9 | 0.0 | 19.6 |
| MOVES UNITS SPELL | 0.2 | +5.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +231.4 | 0.0 | 50.1 | 3.9 | +179.7 | 0.0 | 25.3 |
| NEEDED THERE | - | - | - | - | 0.1 | +75.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.1 | -109.6 | 13.9 | 74.4 | 6.1 | -169.3 | 18.8 | 40.9 |
| NEXT OBJECTIVE NEARER | 6.6 | -300.5 | 70.5 | 66.3 | 8.1 | -307.3 | 54.7 | 73.7 |
| NO DOUBLE ROUNDS | 2.4 | -106.0 | 206.7 | 25.2 | 3.4 | -173.9 | 226.3 | 82.7 |
| NO RALLY LEFT | 0.1 | +8.0 | 0.0 | 10.3 | 0.1 | +8.3 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 2.2 |
| NOT WORTH A CAST | 0.4 | -0.1 | 0.0 | 46.2 | 0.3 | -0.1 | 0.0 | 16.0 |
| OFF BEST | 0.3 | -1.6 | 0.0 | 0.0 | 0.7 | -29.9 | 0.0 | 24.7 |
| ONE CHARGE A CHARGER | 2.8 | +0.0 | 0.0 | 71.6 | 2.7 | +0.0 | 0.0 | 47.6 |
| ONE FIGHT FORMULA | 5.2 | -118.3 | 0.0 | 71.3 | 5.6 | -124.3 | 0.0 | 95.5 |
| ONE OBJECTIVE FORMULA | 3.8 | +18.8 | 0.0 | 53.3 | 3.7 | +26.1 | 0.0 | 34.1 |
| ONE TARGET A SHOOTER | 12.6 | +281.8 | 0.0 | 225.2 | 21.2 | +725.6 | 0.0 | 314.2 |
| OPENS A LANE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +1.2 | 37.6 | 0.0 |
| OPENS UP | 0.2 | +16.1 | 8.1 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +36.9 | 84.5 | 9.6 | 0.6 | +27.2 | 26.8 | 24.4 |
| PATHS CROSS | 3.4 | +101.1 | 0.0 | 44.2 | 5.2 | +217.7 | 0.0 | 17.3 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -1.8 | 0.0 | 0.0 |
| PLAN RESULT | 39.9 | +937.8 | 443.2 | 757.4 | 40.0 | +498.5 | 219.6 | 812.7 |
| RANDOM MOVE BY FIGURES | 0.3 | +2.8 | 0.0 | 20.4 | 1.3 | +17.5 | 0.0 | 74.4 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.0 | 0.0 | 0.0 | 0.2 | -8.4 | 0.0 | 4.4 |
| REDIRECT COUNTER | 1.8 | +119.5 | 0.0 | 41.0 | 2.8 | +286.5 | 0.0 | 47.2 |
| REDIRECT WEIGHED | 0.1 | +1.5 | 4.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.6 | -29.2 | 0.0 | 0.0 | 0.9 | -18.8 | 0.0 | 2.4 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +4.0 | 0.0 | 5.4 | 1.0 | +38.8 | 0.0 | 2.9 |
| RESTRAINS TO SHOOT | 0.1 | +6.4 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +43.6 | 208.6 | 40.4 | 2.8 | +16.4 | 199.4 | 97.4 |
| RISK BY HIS FIGURE | 13.2 | -175.9 | 0.0 | 245.0 | 13.0 | -255.1 | 0.0 | 268.0 |
| RUN DOWN | 2.0 | -22.7 | 147.1 | 40.4 | 3.1 | -46.6 | 189.0 | 76.5 |
| SAME CHARGE LATER | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -2.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -20.7 | 0.0 | 0.8 |
| SEARCH SPOT | 5.5 | +263.9 | 0.0 | 34.6 | 5.6 | +235.6 | 0.0 | 42.6 |
| SELF MOVE SPELL | 0.4 | +33.8 | 0.0 | 31.6 | 0.4 | +93.6 | 0.0 | 26.1 |
| SET UP TOGETHER | 0.4 | +4.0 | 0.0 | 25.4 | 0.3 | +5.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +10.5 | 0.0 | 0.0 | 0.1 | +26.7 | 0.0 | 8.4 |
| SET-UP MISSED | 0.2 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +27.7 | 53.8 | 6.5 | 0.7 | +19.3 | 34.3 | 4.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.5 | -48.0 | 40.1 | 13.9 | 0.3 | -8.0 | 7.2 | 1.8 |
| SHOT RISK POINTS | 8.7 | +27.6 | 0.0 | 184.0 | 13.8 | -0.5 | 0.0 | 217.7 |
| SHOTS IN THE MOVE | 17.5 | +638.5 | 0.0 | 256.3 | 12.0 | +326.7 | 0.0 | 116.2 |
| SPELL SETS UP CHARGE | 0.1 | +22.1 | 0.0 | 0.0 | 0.1 | +26.7 | 0.0 | 8.4 |
| SPELL WORTH | 1.1 | +18.3 | 0.0 | 14.2 | 2.4 | +45.1 | 118.0 | 105.5 |
| SPELLS IN THE FIGHT | 0.5 | +6.4 | 52.1 | 31.5 | 0.6 | -10.0 | 43.8 | 18.8 |
| STAND AND SHOOT | 0.4 | -2.8 | 49.6 | 9.6 | 0.5 | -6.0 | 36.5 | 4.1 |
| STANDS FOR A REASON | 0.1 | +0.0 | 2.2 | 0.0 | 0.6 | +0.0 | 4.2 | 15.7 |
| STANDS STILL | 19.2 | +0.0 | 522.1 | 233.6 | 9.6 | +0.0 | 214.1 | 117.3 |
| STAY WORTH | 19.7 | -22.9 | 251.0 | 171.4 | 11.2 | +65.4 | 107.8 | 41.5 |
| STOPS | - | - | - | - | 0.1 | +7.6 | 8.4 | 6.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 13.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.1 | +0.0 | 127.4 | 13.5 | 1.3 | +0.0 | 71.8 | 47.8 |
| SURE REACH TOGETHER | 0.3 | +10.3 | 0.0 | 11.8 | 0.8 | +8.7 | 0.0 | 6.3 |
| THE DEARER SUM KEEPS ITS PLAN | 4.0 | +0.0 | 0.0 | 55.2 | 5.1 | +0.0 | 0.0 | 17.3 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -13.1 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.8 | +82.7 | 64.3 | 0.0 | 0.7 | +76.2 | 53.9 | 3.0 |
| TIME ON OUR SIDE | 25.7 | +419.3 | 58.3 | 210.1 | 6.4 | +94.7 | 4.9 | 62.3 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 30.8 | 1.4 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +24.3 | 22.8 | 0.0 | 0.0 | +2.0 | 0.0 | 3.0 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.0 |
| WEARS DOWN | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.4 | +59.6 | 0.0 | 12.0 | 0.4 | +53.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +12.1 | 105.8 | 0.0 | 0.4 | +31.3 | 23.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +8.7 | 18.6 | 6.8 | 0.2 | +9.2 | 17.0 | 1.8 |
| WIDER SPREAD | 2.1 | -4.2 | 237.0 | 33.7 | 2.8 | -8.3 | 196.1 | 103.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 4.9 | 0.0 |
| WOUNDS ON THE RANKS | 0.9 | +24.1 | 0.0 | 0.0 | 1.0 | +32.4 | 0.0 | 37.8 |

### Rule changes: ja-mine-f9a8036-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1054 | 1054 | 311 | 12.44 | +8327 | +26.8 |
| SEARCH SPOT | 277 | 277 | 265 | 10.60 | +12489 | +47.1 |
| LEGAL CHARGES ONLY | 260 | 260 | 260 | 10.40 | +0 | +0.0 |
| DEPLOY BY FIGURES | 380 | 380 | 248 | 9.92 | +3898 | +15.7 |
| FIVE ACTION | 2253 | 2253 | 230 | 9.20 | +11822 | +51.4 |
| ONE TARGET A SHOOTER | 847 | 847 | 218 | 8.72 | +3212 | +14.7 |
| PATHS CROSS | 215 | 215 | 215 | 8.60 | +7972 | +37.1 |
| MOVE TO CHARGE COMPUTED | 215 | 215 | 147 | 5.88 | +15351 | +104.4 |
| TIME ON OUR SIDE | 802 | 696 | 122 | 4.88 | +597 | +4.9 |
| FOUR ROUNDS | 181 | 181 | 106 | 4.24 | +6981 | +65.9 |
| SHOT RISK POINTS | 563 | 563 | 88 | 3.52 | +3432 | +39.0 |
| MAX FOR POSITIONING | 334 | 324 | 70 | 2.80 | +337 | +4.8 |
| COVER ONCE | 375 | 294 | 69 | 2.76 | +1494 | +21.6 |
| ARTILLERY RE-ROLL WEIGHED | 65 | 65 | 65 | 2.60 | +0 | +0.0 |
| HARD STAY DROPPED | 64 | 64 | 64 | 2.56 | +0 | +0.0 |
| ADVANCE LANE KEPT | 51 | 51 | 51 | 2.04 | +0 | +0.0 |
| SHOTS IN THE MOVE | 736 | 696 | 50 | 2.00 | +1160 | +23.2 |
| LANE BY FIGURES | 48 | 48 | 48 | 1.92 | +2074 | +43.2 |
| RISK BY ARC | 126 | 126 | 45 | 1.80 | +852 | +18.9 |
| MANOEUVRE | 73 | 73 | 43 | 1.72 | +1551 | +36.1 |
| NEXT OBJECTIVE NEARER | 368 | 368 | 43 | 1.72 | +797 | +18.5 |
| CANNON PLANNED TARGET | 224 | 224 | 42 | 1.68 | -476 | -11.3 |
| CANNON SIGHT KEPT | 41 | 41 | 41 | 1.64 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 40 | 40 | 40 | 1.60 | +9177 | +229.4 |
| MARCH CHECK | 48 | 48 | 37 | 1.48 | +929 | +25.1 |
| IDLE COST | 325 | 263 | 35 | 1.40 | +431 | +12.3 |
| TIED UP BY THE SUM | 37 | 37 | 34 | 1.36 | +1263 | +37.2 |
| MISSILES IN THE MOVE | 243 | 198 | 32 | 1.28 | +779 | +24.3 |
| SHOOTS FROM THE BEST SPOT | 42 | 42 | 32 | 1.28 | +357 | +11.1 |
| FALLS SHORT | 535 | 472 | 31 | 1.24 | +113 | +3.7 |
| RESERVE FALL BACK | 30 | 30 | 30 | 1.20 | +1071 | +35.7 |
| CHARGE LOSSES | 269 | 269 | 28 | 1.12 | +3325 | +118.7 |
| HIS TURN DENIED | 89 | 89 | 27 | 1.08 | +697 | +25.8 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 1.08 | +2047 | +75.8 |
| RISK BY HIS FIGURE | 655 | 655 | 27 | 1.08 | +2989 | +110.7 |
| CHARGE NOT DECLARED | 26 | 26 | 26 | 1.04 | -4708 | -181.1 |
| NEXT CHARGE BY LIST | 280 | 280 | 26 | 1.04 | +1228 | +47.2 |
| RANDOM MOVE BY FIGURES | 40 | 40 | 26 | 1.04 | +510 | +19.6 |
| MARCH BY THE SUM | 24 | 24 | 24 | 0.96 | +1356 | +56.5 |
| OFF BEST | 24 | 24 | 24 | 0.96 | -789 | -32.9 |
| REDIRECT COUNTER | 113 | 101 | 24 | 0.96 | +2601 | +108.4 |
| CHARGE NOW FIRST | 97 | 97 | 21 | 0.84 | -921 | -43.9 |
| HOLDS AMBUSHERS | 21 | 21 | 21 | 0.84 | +0 | +0.0 |
| WHO HITS BACK | 20 | 20 | 20 | 0.80 | +1547 | +77.3 |
| COMBAT PIVOT | 19 | 19 | 19 | 0.76 | +0 | +0.0 |
| FIGHT TO THE END | 80 | 80 | 19 | 0.76 | +1323 | +69.6 |
| CAST JOB | 28 | 28 | 18 | 0.72 | +158 | +8.8 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.72 | +35 | +1.9 |
| CHAFF PASSED | 16 | 16 | 16 | 0.64 | -43 | -2.7 |
| SCOUT WAITS | 16 | 16 | 16 | 0.64 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 189 | 163 | 15 | 0.60 | +446 | +29.8 |
| STAY WORTH | 772 | 743 | 15 | 0.60 | +113 | +7.5 |
| FEATURE BUFFS | 56 | 56 | 14 | 0.56 | +251 | +17.9 |
| HOLDER AT DEPLOYMENT | 40 | 40 | 14 | 0.56 | +668 | +47.7 |
| ONE FIGHT FORMULA | 270 | 138 | 12 | 0.48 | +42 | +3.5 |
| OVERRUNS AWAY | 26 | 26 | 11 | 0.44 | +314 | +28.5 |
| SURE REACH TOGETHER | 28 | 28 | 11 | 0.44 | +24 | +2.1 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.40 | +0 | +0.0 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.40 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.40 | +469 | +46.9 |
| NEARER NOT NEEDED | 215 | 209 | 10 | 0.40 | +464 | +46.4 |
| WOUNDS ON THE RANKS | 46 | 46 | 10 | 0.40 | +112 | +11.2 |
| AFTERMATH IN POINTS | 9 | 9 | 9 | 0.36 | +1375 | +152.8 |
| CHAFF IN THE MOVE | 14 | 14 | 9 | 0.36 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 128 | 128 | 9 | 0.36 | +201 | +22.3 |
| SUPPORT NARROWED | 60 | 60 | 9 | 0.36 | -148 | -16.5 |
| CASTING BLOCK | 10 | 10 | 7 | 0.28 | +74 | +10.5 |
| HIS MOVE AND SHOT | 97 | 97 | 7 | 0.28 | +184 | +26.3 |
| HONEST WORTH | 159 | 159 | 7 | 0.28 | +196 | +28.0 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.24 | +0 | +0.0 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.24 | +136 | +22.7 |
| AFTERMATH WITH FRIENDS | 5 | 5 | 5 | 0.20 | +389 | +77.7 |
| GUN MASK | 37 | 37 | 5 | 0.20 | +97 | +19.5 |
| KEEP FALLS | 5 | 5 | 5 | 0.20 | +136 | +27.1 |
| MODEL FACING | 5 | 5 | 5 | 0.20 | +1153 | +230.6 |
| NO RALLY LEFT | 5 | 5 | 5 | 0.20 | +245 | +49.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.20 | +0 | +0.0 |
| WHOLE FIGHT | 18 | 18 | 5 | 0.20 | +231 | +46.3 |
| WIDER SPREAD | 121 | 121 | 5 | 0.20 | +24 | +4.7 |
| CONTINUE AHEAD WEIGHED | 4 | 4 | 4 | 0.16 | +0 | +0.0 |
| OPENS UP | 4 | 4 | 4 | 0.16 | +159 | +39.8 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.16 | +139 | +34.7 |
| REFUSING RETIRES | 12 | 12 | 4 | 0.16 | -2 | -0.4 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.16 | +176 | +44.1 |
| STUCK PIVOT | 4 | 4 | 4 | 0.16 | +0 | +0.0 |
| WAR ENGINE CHARGES | 5 | 5 | 4 | 0.16 | +197 | +49.3 |
| WHOLE FIGHT GAIN | 10 | 10 | 4 | 0.16 | +42 | +10.5 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.12 | +0 | +0.1 |
| EDGE GIVE GROUND | 8 | 8 | 3 | 0.12 | +97 | +32.4 |
| HIS CHARGE DENIED | 17 | 17 | 3 | 0.12 | +31 | +10.2 |
| MISSILES NEXT TURN | 299 | 219 | 3 | 0.12 | +7 | +2.5 |
| NEEDED THERE | 3 | 3 | 3 | 0.12 | +0 | +0.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.08 | +166 | +82.8 |
| JOINT CHARGE NOW | 14 | 14 | 2 | 0.08 | +54 | +27.1 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.08 | -44 | -22.2 |
| WEARS DOWN | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.04 | +27 | +27.1 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| DEFENSIVE ARMY | 1 | 1 | 1 | 0.04 | -32 | -32.5 |
| HUNT IN PAIRS | 18 | 10 | 1 | 0.04 | +4 | +4.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 7 | 7 | 1 | 0.04 | +14 | +13.8 |
| NO DOUBLE ROUNDS | 145 | 145 | 1 | 0.04 | +8 | +8.0 |
| SET UP TOGETHER | 17 | 13 | 1 | 0.04 | +10 | +10.5 |
| SPELLS IN THE FIGHT | 26 | 26 | 1 | 0.04 | +4 | +4.5 |
| STOPS | 2 | 2 | 1 | 0.04 | +118 | +118.3 |
| THE PROMISE ADDS | 6 | 6 | 1 | 0.04 | +43 | +42.9 |
| WAR ENGINE JOBS | 6 | 6 | 1 | 0.04 | -68 | -68.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 10 | 6 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 17 | 17 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 17 | 17 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 11 | 11 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 256 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 17 | 17 | 0 | 0.00 | - | - |
| GIVES UP | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| GUN FIGURES | 35 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 115 | 115 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 187 | 187 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 194 | 194 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 86 | 86 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 13 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 41 | 41 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT TURNED | 10 | 10 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 17 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 139 | 139 | 0 | 0.00 | - | - |
| OPENS A LANE | 7 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 1997 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 37 | 37 | 0 | 0.00 | - | - |
| RUN DOWN | 129 | 129 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOT OR CHARGE | 20 | 20 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 87 | not checked | - | - | - | - |
| STAND AND SHOOT | 24 | 24 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 721 | 721 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 229 | not checked | - | - | - | - |
| THE PROMISED MOVE | 21 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 78 | 78 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ja-mine-f9a8036-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.56 | 0.52 | 30.9 |
| CHARGE NOT DECLARED | rule | 0.40 | 0.64 | 181.1 |
| CHARGE NOW FIRST | rule | 0.40 | 0.44 | 43.9 |
| JOB FIRST | gate | 0.04 | 0.52 | 42.3 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.08 | 65.9 |
| SUPPORT NARROWED | rule | 0.12 | 0.24 | 16.5 |
| CHAFF PASSED | rule | 0.12 | 0.16 | 6.1 |
| AFTERMATH BAND | gate | 0.16 | - | 3.3 |
| FRIENDS SHOTS CHECKED | rule | 0.12 | - | 3.3 |
| FALLBACK | gate | - | 0.08 | 7.4 |
| PIVOT GUARDS FLANK | rule | - | 0.08 | 22.2 |
| RULE SWITCHED OFF | gate | 0.08 | - | 9.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.04 | 149.0 |
| DEFENSIVE ARMY | rule | 0.04 | - | 32.5 |
| DEPLOY BY FIGURES | rule | - | 0.04 | 4.0 |
| FIGHT ORDER BAND | gate | - | 0.04 | 0.7 |
| REFUSING RETIRES | rule | - | 0.04 | 0.8 |
| WAR ENGINE JOBS | rule | 0.04 | - | 68.3 |

### Plans: ja-mine-f9a8036-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.5 | 66% | 395 | 284 | 72% |
| Mine | join | 0.2 | 100% | 7 | 0 | 0% |
| Mine | move | 26.0 | 94% | 1676 | 0 | 0% |
| Mine | shoot | 11.0 | 57% | 299 | 654 | 219% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | charge | 3.5 | 53% | 666 | 268 | 40% |
| Opponent | join | 1.0 | 96% | 51 | 0 | 0% |
| Opponent | move | 31.4 | 95% | 1670 | 0 | 0% |
| Opponent | shoot | 3.6 | 65% | 156 | 232 | 149% |
| Opponent | support | 0.4 | 80% | 0 | 0 | - |

### Packages: hunt the guns, ja-mine-f9a8036-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Opponent | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.0 | 227 | 186 | 100% | 76 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 80 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 131 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 25 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 99 | 94 | 100% | 15 |
| Warriors of Chaos | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 355 | 278 | 100% | 242 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |

### Battle groups: ja-mine-f9a8036-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 32% | 57% | 0% | - | 14% | 7% | 7% | 71% | 0% |
| Opponent | REDIRECT COUNTER | 2.8 | 17% | 100% | 25% | 0% | 0% | 0% | 56% | 44% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-mine-f9a8036-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 12 | 54 (12) | 17 | 37 | 34 | 50% | 3.7 | 0 (5) | 116 (6) | 0 (1) | 0 (7) | 125 (5) |
| Mine | Character | 90 | 50 (90) | 50 | 0 | 19 | 22% | 2.5 | 57 (35) | 43 (34) | 72 (13) | 59 (49) | 46 (33) |
| Mine | Clean-up | 10 | 101 (10) | 16 | 85 | 29 | 20% | 3.1 | 164 (4) | 66 (6) | - | 121 (7) | 15 (3) |
| Mine | Fast | 1 | 210 (1) | 210 | 0 | 100 | 0% | 3.0 | - | 210 (1) | - | 210 (1) | - |
| Mine | Fast Hammer | 36 | 31 (36) | 7 | 25 | 43 | 33% | 2.6 | 28 (19) | 24 (14) | 76 (3) | 36 (24) | 20 (12) |
| Mine | Hammer | 36 | 42 (36) | 29 | 13 | 22 | 14% | 2.5 | 41 (15) | 37 (17) | 75 (4) | 42 (24) | 41 (12) |
| Mine | Holder | 17 | 38 (17) | 0 | 38 | 21 | 47% | 3.6 | 42 (9) | 45 (6) | 0 (2) | 46 (10) | 24 (7) |
| Mine | Shooter | 29 | 59 (29) | 24 | 35 | 39 | 3% | 1.6 | 38 (8) | 63 (16) | 75 (5) | 72 (24) | 11 (5) |
| Mine | War machine | 50 | 30 (50) | 30 | 0 | 38 | 2% | 1.4 | 41 (21) | 22 (28) | 0 (1) | 39 (15) | 26 (35) |
| Mine | Wizard | 10 | 0 (10) | 0 | 0 | 14 | 10% | 3.4 | 0 (3) | 0 (3) | 0 (3) | 0 (2) | 0 (7) |
| Opponent | Chaff | 47 | 105 (47) | 7 | 99 | 53 | 45% | 3.1 | 102 (18) | 116 (22) | 71 (7) | 100 (35) | 123 (12) |
| Opponent | Character | 69 | 34 (69) | 34 | 0 | 24 | 22% | 2.6 | 36 (24) | 30 (30) | 53 (10) | 46 (34) | 24 (30) |
| Opponent | Clean-up | 13 | 48 (13) | 17 | 32 | 35 | 31% | 3.8 | 10 (6) | 99 (5) | 29 (2) | 86 (8) | 3 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 35 | 23 (35) | 16 | 7 | 42 | 43% | 2.6 | 3 (12) | 34 (20) | 34 (3) | 22 (19) | 25 (16) |
| Opponent | Hammer | 28 | 32 (28) | 22 | 10 | 40 | 29% | 3.4 | 15 (8) | 45 (15) | 14 (5) | 10 (18) | 70 (10) |
| Opponent | Holder | 29 | 70 (29) | 7 | 63 | 35 | 28% | 2.7 | 3 (8) | 148 (12) | 28 (9) | 81 (24) | 6 (5) |
| Opponent | Shooter | 19 | 42 (19) | 19 | 23 | 20 | 5% | 2.1 | 45 (8) | 46 (10) | 0 (1) | 52 (15) | 10 (4) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 5.5 | 0 (1) | 0 (2) | 0 (1) | - | 0 (4) |
| Opponent | War machine | 17 | 59 (17) | 59 | 0 | 26 | 0% | 1.9 | 15 (9) | 104 (7) | 100 (1) | 23 (4) | 67 (13) |
| Opponent | Wizard | 23 | 3 (23) | 3 | 0 | 47 | 17% | 2.2 | 11 (5) | 0 (8) | 0 (4) | 0 (4) | 6 (13) |

### Charged fights: ja-mine-f9a8036-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 42 | 25 | 1.0 | 1.2 | 25 | 13 | +12 | 2 of 4 | 3 of 4 | +60 | -4 |
| Mine | Chaos Dwarfs | 4 | 119 | 414 | 1.8 | 1.3 | 236 | 0 | +236 | 4 of 7 | 6 of 7 | +140 | +275 |
| Mine | Dwarfen Mountain Holds | 3 | 266 | 236 | 1.3 | 1.5 | 177 | 32 | +145 | 2 of 4 | 4 of 4 | +146 | +144 |
| Mine | Empire of Man | 5 | 342 | 142 | 2.0 | 1.1 | 71 | 136 | -65 | 4 of 10 | 6 of 10 | +499 | -128 |
| Mine | Grand Cathay | 5 | 335 | 181 | 4.2 | 1.0 | 43 | 32 | +12 | 3 of 21 | 17 of 21 | - | +12 |
| Mine | High Elf Realms | 4 | 86 | 467 | 4.2 | 1.1 | 110 | 0 | +110 | 6 of 17 | 16 of 17 | +160 | +103 |
| **Mine** | all armies | 25 | 207 | 238 | 2.5 | 1.1 | 94 | 35 | +59 | 21 of 63 | 52 of 63 | +181 | +42 |
| Opponent | Empire of Man | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 396 | 98 | 3.0 | 1.3 | 33 | 0 | +33 | 3 of 9 | 8 of 9 | +30 | +34 |
| Opponent | High Elf Realms | 3 | 0 | 121 | 2.7 | 1.1 | 45 | 43 | +2 | 3 of 8 | 7 of 8 | -347 | +52 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 190 | 2.5 | 1.4 | 76 | 0 | +76 | 2 of 5 | 3 of 5 | +142 | +32 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 241 | 3.0 | 1.0 | 80 | 326 | -246 | 1 of 3 | 3 of 3 | - | -246 |
| Opponent | Skaven | 1 | 105 | 0 | 1.0 | 1.0 | 0 | 38 | -38 | 1 of 1 | 0 of 1 | - | -38 |
| Opponent | Tomb Kings of Khemri | 3 | 156 | 424 | 4.0 | 1.1 | 106 | 36 | +70 | 8 of 12 | 8 of 12 | -431 | +116 |
| Opponent | Vampire Counts | 5 | 6 | 391 | 4.2 | 1.0 | 93 | 61 | +32 | 6 of 21 | 12 of 21 | +162 | +26 |
| Opponent | Warriors of Chaos | 4 | 11 | 156 | 2.2 | 1.0 | 69 | 42 | +27 | 3 of 9 | 5 of 9 | - | +27 |
| Opponent | Wood Elf Realms | 2 | 135 | 601 | 3.0 | 1.0 | 200 | 0 | +200 | 2 of 6 | 5 of 6 | - | +200 |
| **Opponent** | all armies | 25 | 103 | 253 | 3.0 | 1.1 | 84 | 46 | +38 | 30 of 75 | 51 of 75 | -30 | +47 |

### Effective charges: ja-mine-f9a8036-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -52) | 0 | 0 | 1 (net +40) | 0 | 1 (net +60) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 2 (net +369) | 2 (net +0) | 0 | 3 (net +305) | 0 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 0 | 2 (net +248) | 0 | 2 (net +41) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 10 | 4 (net -340) | 0 | 1 (net +499) | 1 (net +0) | 1 (net +0) | 3 (net +70) | 0 | 10% (1 of 10) |
| Mine | Grand Cathay | 21 | 3 (net -98) | 1 (net +0) | 2 (net -44) | 0 | 5 (net +65) | 10 (net +30) | 0 | 10% (2 of 21) |
| Mine | High Elf Realms | 17 | 2 (net +286) | 1 (net +0) | 0 | 3 (net +65) | 3 (net +62) | 7 (net +115) | 1 | 0% (0 of 16) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 9 | 1 (net +0) | 0 | 0 | 4 (net +34) | 4 (net +39) | 0 | 0 | 0% (0 of 9) |
| Opponent | High Elf Realms | 8 | 0 | 1 (net +0) | 1 (net -347) | 1 (net +135) | 1 (net +65) | 4 (net +40) | 0 | 12% (1 of 8) |
| Opponent | Kingdom of Bretonnia | 5 | 1 (net +0) | 1 (net +95) | 0 | 2 (net +142) | 0 | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +126) | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 1 (net -38) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 12 | 2 (net +120) | 0 | 1 (net +0) | 4 (net +108) | 1 (net -431) | 3 (net +150) | 1 | 9% (1 of 11) |
| Opponent | Vampire Counts | 21 | 9 (net +85) | 1 (net +0) | 3 (net -136) | 5 (net +101) | 1 (net +84) | 2 (net -134) | 0 | 14% (3 of 21) |
| Opponent | Warriors of Chaos | 9 | 2 (net -102) | 0 | 2 (net +157) | 2 (net +155) | 1 (net +0) | 1 (net +0) | 1 | 25% (2 of 8) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 2 (net +100) | 0 | 1 (net +0) | 3 (net +334) | 0 | 33% (2 of 6) |

### Charged fights, damage counted: ja-mine-f9a8036-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 213 | 283 | -113 | 93 | 200 | -107 | -50.2 |
| Mine | 50-54% | 2 | 365 | 334 | +0 | 127 | 196 | -69 | -19.0 |
| Mine | Effective (55-75%) | 5 | 339 | 252 | +230 | 303 | 85 | +219 | +64.6 |
| Mine | 76-89% | 9 | 311 | 215 | +81 | 104 | 6 | +98 | +31.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 245 | 170 | +91 | 116 | 15 | +101 | +41.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 371 | 67 | +57 | 70 | 17 | +53 | +14.3 |
| Mine | No odds | 2 | 499 | 240 | +55 | 147 | 0 | +147 | +29.5 |
| Mine | All fights | 63 | 287 | 194 | +59 | 120 | 54 | +66 | +23.0 |
| Opponent | Long shot (under 50%) | 16 | 250 | 264 | +48 | 111 | 47 | +64 | +25.6 |
| Opponent | 50-54% | 3 | 157 | 170 | +32 | 77 | 10 | +67 | +42.6 |
| Opponent | Effective (55-75%) | 10 | 198 | 274 | -24 | 68 | 98 | -30 | -15.2 |
| Opponent | 76-89% | 18 | 323 | 189 | +100 | 121 | 13 | +108 | +33.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 328 | 229 | +98 | 144 | 43 | +101 | +30.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 487 | 101 | -14 | 44 | 55 | -11 | -2.2 |
| Opponent | No odds | 4 | 265 | 274 | -222 | 66 | 304 | -238 | -89.6 |
| Opponent | All fights | 75 | 302 | 218 | +38 | 103 | 58 | +44 | +14.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-mine-f9a8036-p3 | move | 191 | 43 (23%) | 27 (14%) | 26 (14%) | 122 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L0311, L1519 |
| Horn of the Wild Hunt | Opponent | L0533 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

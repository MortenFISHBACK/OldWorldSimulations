# Doctrine scorecard: ja-mine-f9a8036-p2

### Scorecard: ja-mine-f9a8036-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 2 | 6 | 0 | 3 | 0 | 0 | 0 | 280 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 5 | 0 | 3 | 0 | 0 | 0 | 235 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 1 | 5 | 1 | 0 | 0 | 52 |
| L0222 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 760 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 70 |
| L0409 | 1 | 1 | Mine | no | 5 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 140 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 0 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 190 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 165 |
| L0528 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 160 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 340 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 1 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 776 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 4 | 5 | 0 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 260 |
| L0810 | 6 | 1 | Opponent | no | 24 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 561 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 2 | 4 | 4 | 3 | 1 | 0 | 0 | 268 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 599 |
| L0934 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | yes | 4 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 2 | 0 | 0 | 351 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 66 |
| **Average** | | | Mine | 24% | 2.9 | 3.1 | 1.4 | 1.6 | 0.2 | 0.0 | 0.0 | 211.5 |
| **Average** | | | Opponent | 29% | 3.8 | 2.8 | 2.4 | 2.0 | 0.2 | 0.0 | 0.0 | 123.4 |

### KPIs: ja-mine-f9a8036-p2

Rules off - Opponent only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 22 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 44% (44 of 99) | 14% (16 of 112) | 28% (60 of 211) |
| Winner chose to follow up after the loser gave ground |  | 71% (15 of 21); on the table 76% | 88% (28 of 32); on the table 91% | 81% (43 of 53); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | 60% (3 of 5); on the table 80% | 33% (1 of 3); on the table 33% | 50% (4 of 8); on the table 62% |
| Winner chose to pursue after the loser fled |  | 73% (8 of 11); on the table 73% | 59% (10 of 17); on the table 71% | 64% (18 of 28); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 70% (26 of 37); on the table 76% | 75% (39 of 52); on the table 81% | 73% (65 of 89); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 34% (92 of 270) | 24% (27 of 114) | 31% (119 of 384) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (92 of 203) | 31% (27 of 87) | 41% (119 of 290) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (4 of 7) | 47% (8 of 17) | 50% (12 of 24) |
| Points that never fought | lower | 56% (24480 of 43588) | 49% (21486 of 43992) | 52% (45966 of 87580) |
|   infantry points that never fought | lower | 62% (6925 of 11190) | 74% (6171 of 8375) | 67% (13096 of 19565) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (127 of 185) | 60% (102 of 169) | 65% (229 of 354) |
| Bound items with a magic missile used (at least once a game) |  | 88% (14 of 16); 2.2 uses a game | 89% (8 of 9); 1.0 uses a game | 88% (22 of 25); 1.6 uses a game |
| Bound items with another spell used |  | 67% (4 of 6); 0.4 uses a game | 50% (1 of 2); 0.0 uses a game | 62% (5 of 8); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (8 of 15); 0.4 uses a game | 33% (2 of 6); 0.1 uses a game | 48% (10 of 21); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (23278 of 36271) | 54% (20302 of 37344) | 59% (43580 of 73615) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (23%) | 0.7 (17%) | 2.5 (21%) |
| MARCHED: its unit marched | 2.2 (28%) | 1.2 (30%) | 3.4 (28%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.3 (7%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.6 (20%) | 1.0 (24%) | 2.5 (21%) |
| REAR RANK: in a rear rank | 0.5 (6%) | 0.2 (5%) | 0.7 (6%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 1.0 (13%) | 0.0 (1%) | 1.1 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.1 (3%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.5 | 1.2 | 5.4 | 0.3 | 1.4 |
| not cast | 2.1 | 3.4 | 3.5 | 12.0 | 2.1 | 17.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (53%) | 0.3 (9%) | 2.5 (21%) | 0.5 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.4 (28%) | 0.5 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (4%) | 0.5 (16%) | 2.5 (21%) | 0.7 (32%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (13%) | 0.5 (15%) | 0.5 (13%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (9%) | 0.1 (3%) | 0.2 (5%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.1 (4%) | 0.3 (9%) | 0.4 (12%) | 1.1 (9%) | 0.1 (4%) | 0.8 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (7%) | 0.1 (4%) | 0.2 (5%) | 0.5 (4%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.2 (9%) | 0.0 (1%) | 0.1 (3%) | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.3 (8%) | 0.1 (3%) | 0.2 (2%) | 0.1 (6%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (50%) | 0.1 (3%) | 1.2 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.4 a game | 0.7 a game |
| stood (cast and not dispelled) | 43% (10 of 23) | 78% (7 of 9) | 53% (17 of 32) |
| the unit moved after it | 60% (6 of 10) | 57% (4 of 7) | 59% (10 of 17) |
| it charged on its next turn | 0% (0 of 10) | 0% (0 of 7) | 0% (0 of 17) |
| the enemy charged it first | 10% (1 of 10) | 0% (0 of 7) | 6% (1 of 17) |
| it fought by the end of its next turn | 10% (1 of 10) | 0% (0 of 7) | 6% (1 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 10) | 0% (0 of 7) | 0% (0 of 17) |
| none of these (no charge, no fight, no charge escaped) | 90% (9 of 10) | 100% (7 of 7) | 94% (16 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (431 of 646) | 54% (328 of 604) | 61% (759 of 1250) |
|   cavalry | 65% (28 of 43) | 62% (52 of 84) | 63% (80 of 127) |
|   character | 76% (59 of 78) | 30% (24 of 79) | 53% (83 of 157) |
|   chariot | 56% (42 of 75) | 74% (31 of 42) | 62% (73 of 117) |
|   infantry | 59% (92 of 155) | 51% (119 of 235) | 54% (211 of 390) |
|   monster | 52% (11 of 21) | 58% (19 of 33) | 56% (30 of 54) |
|   war machine | 73% (199 of 274) | 63% (83 of 131) | 70% (282 of 405) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.4 (35%) | 2.8 (22%) | 6.2 (28%) |
| CHARGED: it charged | 0.5 (5%) | 1.6 (13%) | 2.1 (10%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.5 (4%) | 0.6 (3%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.1 (1%) | 0.7 (3%) |
| MOVED: a war machine that moved | 1.7 (18%) | 0.8 (7%) | 2.5 (11%) |
| NO TARGET IN RANGE | 0.7 (7%) | 2.8 (22%) | 3.5 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.7 (5%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (14%) | 2.0 (16%) | 3.4 (15%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.4 (3%) | 0.8 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.7 (6%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.2 | 82% | 5.2 pts | 29 pts |
| character | 4.0 | 2.5 | 66% | 15.2 pts | 61 pts |
| chariot | 3.3 | 1.9 | 67% | 16.9 pts | 56 pts |
| infantry | 13.6 | 4.2 | 77% | 5.7 pts | 77 pts |
| monster | 1.5 | 0.5 | 76% | 6.0 pts | 9 pts |
| war machine | 12.8 | 12.7 | 59% | 29.0 pts | 371 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.2 | 5.0 | 3.6 |
| Charges that made contact a game | 1.9 | 3.8 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.82 declared, 0.76 contact (17 units) | 1.80 declared, 1.40 contact (10 units) | 1.19 declared, 1.00 contact (27 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.67 declared, 1.33 contact (6 units) | 1.67 declared, 1.33 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.21 contact (140 units) | 0.47 declared, 0.34 contact (178 units) | 0.37 declared, 0.28 contact (318 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (16 of 32) | 50% (3 of 6) | 71% (5 of 7) | 53% (24 of 45) |
| Character in a unit | 86% (24 of 28) | 71% (5 of 7) | - | 83% (29 of 35) |
| Character on its own | 82% (14 of 17) | 65% (20 of 31) | 22% (7 of 32) | 51% (41 of 80) |
| Chariot | 60% (6 of 10) | 77% (10 of 13) | - | 70% (16 of 23) |
| Infantry | 57% (30 of 53) | 57% (13 of 23) | 67% (2 of 3) | 57% (45 of 79) |
| Monster | 53% (9 of 17) | 100% (3 of 3) | - | 60% (12 of 20) |
| Monstrous | 80% (4 of 5) | 100% (8 of 8) | - | 92% (12 of 13) |
| War Machines | 84% (48 of 57) | 100% (2 of 2) | - | 85% (50 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (4 of 5); on the table 80% | 31% (32 of 102) | 66% | 68% (15 of 22) | 83% (5 of 6); 5.8 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (3 of 4); on the table 75% | 58% (21 of 36) | 55% | 81% (26 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 75% (12 of 16); on the table 75% | - | 75% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 75% (9 of 12); on the table 92% | 40% (19 of 48) | 45% | 66% (50 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 80% (8 of 10); on the table 80% | 25% (34 of 138) | 52% | 54% (29 of 54) | 93% (13 of 14); 5.5 uses a game | 50% (1 of 2); 0.3 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 32% | 38% (3 of 8) | 100% (1 of 1); 6.0 uses a game | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 72% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 2 | 67% (2 of 3); on the table 67% | 0% (0 of 12) | 53% | 86% (12 of 14) | 100% (2 of 2); 3.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 33% (1 of 3); on the table 33% | 0% (0 of 6) | 50% | 78% (7 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 77% (10 of 13); on the table 85% | - | 43% | 30% (6 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 70% (7 of 10); on the table 70% | 50% (9 of 18) | 34% | 71% (12 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 67% (2 of 3); on the table 100% | 25% (3 of 12) | 37% | 68% (15 of 22) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 60% (3 of 5); on the table 80% | 17% (1 of 6) | 53% | 70% (14 of 20) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-mine-f9a8036-p2, 22 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (24) | 77% (17) | 60% (41) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.64 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.41 | 0.05 | 0.45 |
| ...with the charger already in that arc before they moved (per game) | 0.27 | 0.45 | 0.73 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.32 | 0.00 | 0.32 |

### Quality by phase: ja-mine-f9a8036-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 76% (35 of 46) | 54% (56 of 104) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (135 of 339) | 51% (95 of 188) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 69% (9 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (12 of 18) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 22% (8 of 37) | 20% (5 of 25) |
| Strategy | Lone characters that fought | 50% (30 of 60) | 70% (35 of 50) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.6 | 2.0 |
| Movement | Points that never moved of their own | 211.5 | 123.4 |
| Movement | Fights charged into per game | 1.7 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 34, net +253 | 15 of 68, net +92 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 34, net +135 | 14 of 68, net +92 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 34, net +80 | 5 of 68, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 of 34, net +92 | 11 of 68, net +180 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 12.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (100 of 243) | 35% (94 of 269) |
| Shooting | Points destroyed by shooting units | 128.9 | 41.4 |
| Shooting | War machine shots | 9.0 | 3.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (111 of 199) | 66% (55 of 83) |
| Shooting | Points destroyed by war machines | 54.1 | 55.1 |
| Magic | Magic missiles cast | 2.1 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 21% (10 of 47) | 19% (3 of 16) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.4 |
| Magic | Wounds caused by other spells | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 63.5 | 46.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.8 / 0.7 / 0.1 | 2.7 / 0.2 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 205.7 | 277.7 |
| Combat | Points run down | 23.4 | 103.8 |
| Combat | Net points per charged fight, damage counted | +95 | +110 |
| Combat | Net per 100 charger points, damage counted | +34.6 | +35.0 |
| Combat | First round won (charged fights) | 87% | 76% |
| Combat | Net points per charged fight | +100 | +110 |
| Combat | Net points per supported fight / lone fight | +396 / +74 | +164 / +101 |
| Combat | Charged fights on a top-3 enemy unit | 11 of 38 | 32 of 71 |
| Game | Points lost | 683.5 | 507.0 |
| Game | VP from objectives | 512.3 | 651.8 |
| Game | Lone holders (player turns) | 2.9 | 3.8 |

- Mine won / drew / lost: 7 / 3 / 12 of 22 ended games (of 22); mean margin (Mine - Opponent) -323 VP
- The side that went first won 8 of 19 games with a winner
- Points traded per game (both sides' losses): 1191
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-mine-f9a8036-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +83.8 | 0.0 | 46.2 | 0.2 | +28.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 85.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.3 | 0.0 | 3.9 | 0.2 | +1.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.8 | 3.9 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -64.9 | 31.1 | 3.3 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 160.6 | 0.0 | 0.5 | +0.0 | 49.5 | 0.0 |
| CANNON PLANNED TARGET | 8.5 | +280.8 | 555.0 | 192.3 | 3.4 | +76.1 | 202.3 | 30.0 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 2.7 | 0.6 | +0.0 | 0.0 | 4.5 |
| CAST JOB | 0.8 | +16.5 | 10.0 | 2.7 | 0.2 | +7.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 16.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +22.8 | 2.7 | 12.4 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +8.2 | 0.0 | 5.5 | 0.5 | +14.1 | 0.0 | 3.1 |
| CHAFF PASSED | 0.2 | -0.4 | 5.2 | 0.0 | 0.3 | -0.0 | 24.7 | 2.7 |
| CHARACTER GUNS | 0.9 | +0.0 | 0.0 | 11.4 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.7 | -279.3 | 0.0 | 208.5 | 6.5 | -429.0 | 0.0 | 187.7 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 21.0 | 39.9 | 0.4 | +0.0 | 33.8 | 6.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 155.9 | 72.5 | 2.5 | +0.0 | 318.5 | 44.4 |
| CHARGER SLAIN LOST | 0.0 | -0.2 | 6.3 | 2.7 | 0.4 | -8.5 | 58.2 | 2.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 30.2 | 0.0 |
| CHEAPEST HOLDER | 0.2 | -9.5 | 26.4 | 0.0 | 0.4 | -26.8 | 12.7 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 10.3 | 35.9 | 0.4 | +0.0 | 10.8 | 23.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +59.9 | 37.1 | 20.5 | 0.2 | +23.7 | 7.2 | 0.0 |
| COVER ONCE | 7.1 | -419.2 | 0.0 | 157.2 | 5.4 | -415.1 | 0.0 | 57.4 |
| DEPLOY BY FIGURES | 8.3 | -6.9 | 0.0 | 7.5 | 8.0 | +58.1 | 0.0 | 13.9 |
| EDGE GIVE GROUND | 0.0 | +14.7 | 15.0 | 0.0 | 0.3 | +8.8 | 53.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.5 | +4.5 | 165.6 | 77.0 | 3.7 | +12.6 | 406.6 | 59.0 |
| FALLBACK BY WORTH | 0.3 | +1.2 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 2.0 |
| FALLS SHORT | 6.6 | +110.4 | 0.0 | 107.7 | 16.5 | +226.3 | 0.0 | 241.2 |
| FEATURE BUFFS | 1.6 | +45.8 | 0.0 | 21.2 | 0.9 | +17.8 | 0.0 | 5.0 |
| FIGHT LIFT | 0.0 | +0.2 | 26.4 | 26.4 | - | - | - | - |
| FIGHT TO THE END | 0.9 | +17.2 | 77.0 | 35.6 | 2.0 | +109.4 | 243.7 | 47.8 |
| FIRE IN ORDER | 0.3 | +0.0 | 10.6 | 0.0 | 0.2 | +0.0 | 6.4 | 0.0 |
| FIVE ACTION | 47.3 | +2336.7 | 1041.0 | 851.8 | 51.1 | +2928.4 | 915.5 | 524.2 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 144.9 | 3.9 | +0.0 | 0.0 | 57.7 |
| FOCUS FIRE | 0.0 | +1.4 | 5.2 | 6.7 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.3 | +57.9 | 0.0 | 28.7 | 0.8 | +182.3 | 0.0 | 31.1 |
| FOUR ROUNDS | 2.1 | +219.8 | 216.4 | 79.4 | 4.6 | +476.3 | 546.8 | 62.3 |
| FRIEND CHARGES FIRST | 0.0 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -16.9 | 0.0 | 12.8 | 0.5 | -3.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +15.2 | 0.0 | 2.7 | 0.0 | -0.2 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -4.2 | 13.1 | 0.0 | 0.4 | -6.4 | 45.3 | 4.3 |
| GUN FIGURES | 1.5 | +21.2 | 34.1 | 38.2 | 1.0 | +20.1 | 2.7 | 8.4 |
| GUN MASK | 1.0 | +28.8 | 0.0 | 12.0 | 0.4 | +10.1 | 0.0 | 2.7 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 4.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.7 | +0.0 | 0.0 | 32.3 | 2.3 | +0.0 | 0.0 | 46.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.1 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 26.4 | 0.0 |
| HIS CHARGE DENIED | 0.1 | +5.5 | 16.7 | 5.5 | 0.5 | +20.0 | 2.4 | 11.5 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 56.0 | 3.5 | +0.0 | 0.0 | 61.5 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 73.9 | 3.5 | +0.0 | 0.0 | 6.0 |
| HIS MOVE AND SHOT | 1.5 | -15.6 | 0.0 | 25.8 | 2.3 | -38.2 | 0.0 | 52.3 |
| HIS RANDOM MOVE | 1.8 | +0.0 | 0.0 | 37.5 | 1.7 | +0.0 | 0.0 | 3.3 |
| HIS SHOT LIST | 20.2 | +812.4 | 0.0 | 328.0 | 28.2 | +1531.3 | 0.0 | 317.5 |
| HIS TURN DENIED | 1.1 | +36.0 | 125.3 | 30.3 | 2.7 | +155.6 | 353.1 | 45.5 |
| HOLDER AT DEPLOYMENT | 0.7 | +125.0 | 0.0 | 0.0 | 1.1 | +166.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.9 | -59.3 | 173.2 | 59.4 | 4.0 | -179.2 | 493.6 | 53.5 |
| HUNT IN PAIRS | 0.3 | +25.2 | 0.0 | 26.4 | 0.6 | +39.9 | 0.0 | 9.9 |
| HUNT RESULT | - | - | - | - | 0.1 | +49.3 | 0.0 | 5.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +56.5 | 24.3 | 0.0 |
| IDLE COST | 3.0 | -34.9 | 0.0 | 51.6 | 10.8 | -154.1 | 0.0 | 113.2 |
| JOINT CHARGE NOW | 0.3 | +20.7 | 46.5 | 29.3 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.0 | -3.4 | 18.5 | 0.0 | 0.2 | -23.2 | 24.7 | 3.3 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.5 | +23.3 | 0.0 | 0.0 | 0.9 | +50.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.5 | +0.0 | 167.8 | 262.4 | 6.3 | +0.0 | 276.7 | 243.4 |
| LONE CHARACTER SAFE SPOT | 0.2 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +53.3 | 0.0 | 0.0 | 0.5 | +39.5 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -2.1 | 18.5 | 0.0 | 0.3 | -0.8 | 26.4 | 2.9 |
| LOST CHARGE | 0.2 | -0.9 | 9.5 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -10.8 | 0.0 | 3.9 | 0.0 | -0.6 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +2.4 | 0.0 | 0.0 | 0.5 | +6.6 | 0.0 | 5.2 |
| MANOEUVRE | 0.7 | +9.8 | 0.0 | 22.5 | 1.2 | -2.8 | 0.0 | 32.2 |
| MARCH AT ESCAPER | 0.2 | +4.1 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +25.4 | 0.0 | 0.0 | 0.4 | +29.9 | 0.0 | 16.2 |
| MARCH CHECK | 1.4 | +68.5 | 0.0 | 20.0 | 1.0 | +45.3 | 0.0 | 24.1 |
| MARCH OVER CASTS | 1.0 | +55.4 | 0.0 | 9.3 | 0.8 | +64.2 | 0.0 | 23.4 |
| MAX FOR POSITIONING | 4.5 | +67.7 | 0.0 | 67.9 | 7.1 | +100.5 | 0.0 | 60.5 |
| MISSILES IN THE MOVE | 4.8 | +118.9 | 0.0 | 105.5 | 2.7 | +55.1 | 0.0 | 32.0 |
| MISSILES NEXT TURN | 6.4 | +89.9 | 0.0 | 98.8 | 3.8 | +46.0 | 0.0 | 55.4 |
| MODEL FACING | 0.5 | +85.8 | 0.0 | 2.7 | 0.2 | +48.3 | 0.0 | 2.7 |
| MOVE SPELL IN RANGE | 0.4 | +13.8 | 0.0 | 26.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -3.9 | 0.0 | 26.4 | 0.3 | -19.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 12.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.9 | +298.4 | 0.0 | 55.8 | 4.3 | +594.9 | 0.0 | 5.1 |
| MOVES UNITS SPELL | 0.1 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.2 | +241.0 | 0.0 | 62.9 | 4.8 | +282.6 | 0.0 | 44.4 |
| NEXT CHARGE BY LIST | 4.4 | -190.2 | 10.6 | 84.1 | 6.1 | -255.1 | 8.4 | 26.5 |
| NEXT OBJECTIVE NEARER | 7.0 | -313.9 | 76.2 | 77.7 | 9.4 | -546.3 | 24.8 | 100.0 |
| NO DOUBLE ROUNDS | 1.6 | -46.7 | 161.5 | 63.6 | 3.5 | -141.7 | 358.9 | 59.2 |
| NOT TURNED | 0.3 | +0.1 | 0.0 | 15.3 | - | - | - | - |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -18.5 | 0.0 | 0.0 | 0.2 | -12.3 | 0.0 | 9.5 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 79.6 | 2.2 | +0.0 | 0.0 | 44.3 |
| ONE FIGHT FORMULA | 4.2 | -67.6 | 0.0 | 109.6 | 6.1 | -143.7 | 0.0 | 56.7 |
| ONE OBJECTIVE FORMULA | 3.7 | +13.1 | 0.0 | 60.1 | 3.6 | -26.0 | 0.0 | 33.5 |
| ONE TARGET A SHOOTER | 17.0 | +443.3 | 0.0 | 291.2 | 22.4 | +782.9 | 0.0 | 135.7 |
| OPENS A LANE | 0.1 | +0.2 | 3.6 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| OPENS UP | 0.0 | +1.6 | 0.0 | 0.0 | 0.4 | +23.9 | 18.5 | 0.0 |
| OVERRUNS AWAY | 0.3 | +5.8 | 9.2 | 42.1 | 0.4 | +4.2 | 55.2 | 0.0 |
| PATHS CROSS | 3.7 | +154.2 | 0.0 | 27.2 | 5.5 | +160.1 | 0.0 | 35.8 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +4.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -1.1 | 0.0 | 6.3 |
| PLAN RESULT | 42.1 | +1175.5 | 531.6 | 998.7 | 44.4 | +773.1 | 455.1 | 730.5 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -20.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.3 | +4.7 | 0.0 | 23.2 | 0.8 | +20.8 | 0.0 | 35.2 |
| REDIRECT BY WHAT IT STOPS | 0.0 | -0.5 | 0.0 | 0.0 | 0.3 | -11.5 | 0.0 | 8.3 |
| REDIRECT COUNTER | 1.0 | +54.8 | 0.0 | 9.0 | 2.7 | +168.4 | 0.0 | 40.5 |
| REDIRECT WEIGHED | 0.1 | +6.2 | 6.6 | 2.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -16.6 | 0.0 | 29.1 | 1.0 | -10.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 9.5 | 0.1 | +0.0 | 0.0 | 23.2 |
| RESERVE FALL BACK | 0.4 | +13.8 | 0.0 | 0.0 | 0.9 | +38.8 | 0.0 | 15.3 |
| RESTRAINS TO SHOOT | 0.0 | +5.6 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +75.0 | 210.2 | 79.4 | 2.4 | -3.1 | 215.3 | 30.7 |
| RISK BY HIS FIGURE | 11.7 | -220.5 | 0.0 | 295.8 | 12.1 | -239.8 | 0.0 | 195.7 |
| RUN DOWN | 1.2 | -12.5 | 114.0 | 10.8 | 3.6 | -29.6 | 399.7 | 27.5 |
| SAME CHARGE LATER | 0.1 | -4.7 | 0.0 | 26.4 | 0.1 | -0.7 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +1.0 | 0.0 | 0.0 | 0.7 | +3.3 | 0.0 | 1.5 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 1.5 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -32.3 | 0.0 | 4.5 |
| SEARCH SPOT | 5.8 | +259.1 | 0.0 | 85.4 | 6.4 | +272.7 | 0.0 | 45.9 |
| SET UP TOGETHER | 0.2 | +2.5 | 0.0 | 0.0 | 0.8 | +6.9 | 0.0 | 5.2 |
| SET-UP MISSED | - | - | - | - | 0.0 | +10.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.4 | +1.1 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +37.5 | 49.5 | 12.0 | 0.4 | +6.8 | 13.4 | 38.6 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -12.3 | 27.8 | 2.7 | 0.3 | -17.6 | 35.4 | 0.0 |
| SHOT RISK POINTS | 9.5 | +33.1 | 0.0 | 203.7 | 15.5 | -123.2 | 0.0 | 260.9 |
| SHOTS IN THE MOVE | 20.0 | +924.9 | 0.0 | 378.3 | 16.7 | +478.8 | 0.0 | 160.1 |
| SPELL SETS UP CHARGE | 0.0 | +9.2 | 12.4 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.8 | +11.8 | 26.4 | 26.4 | 2.0 | +34.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.4 | +4.7 | 41.6 | 24.1 | 0.8 | -2.9 | 74.6 | 0.0 |
| STAND AND SHOOT | 0.6 | -7.4 | 52.5 | 12.2 | 0.7 | -12.1 | 71.7 | 12.6 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 6.4 | 0.8 | +0.0 | 10.4 | 43.5 |
| STANDS STILL | 22.5 | +0.0 | 824.6 | 401.1 | 14.6 | +0.0 | 353.5 | 154.3 |
| STAY WORTH | 24.1 | +58.9 | 386.6 | 389.5 | 18.8 | +171.5 | 234.4 | 123.3 |
| STOPS | - | - | - | - | 0.1 | +2.0 | 24.3 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 7.7 | - | - | - | - |
| SUPPORT NARROWED | 1.0 | +0.0 | 87.8 | 28.9 | 1.4 | +0.0 | 139.1 | 39.8 |
| SURE REACH TOGETHER | 0.3 | +0.8 | 0.0 | 0.0 | 0.7 | +6.2 | 0.0 | 2.7 |
| THE DEARER SUM KEEPS ITS PLAN | 4.3 | +0.0 | 0.0 | 36.5 | 5.6 | +0.0 | 0.0 | 18.1 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -70.0 | 58.4 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 26.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.6 | +50.1 | 56.8 | 23.6 | 0.4 | +49.5 | 45.5 | 0.0 |
| TIME ON OUR SIDE | 25.4 | +391.0 | 12.5 | 299.6 | 12.5 | +162.3 | 3.5 | 55.5 |
| TWO OR MORE ARRIVE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 47.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 11.4 | 0.0 |
| WHO HITS BACK | 0.3 | +58.8 | 0.0 | 38.0 | 0.4 | +75.2 | 0.0 | 2.7 |
| WHOLE FIGHT | 0.1 | -0.6 | 45.5 | 0.0 | 0.4 | +15.9 | 99.5 | 3.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +14.3 | 34.4 | 0.0 |
| WIDER SPREAD | 1.1 | -1.6 | 123.9 | 32.0 | 3.5 | -7.5 | 370.5 | 33.8 |
| WOUNDS ON THE RANKS | 2.0 | +48.3 | 0.0 | 24.7 | 1.5 | +140.0 | 0.0 | 84.5 |

### Rule changes: ja-mine-f9a8036-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1066 | 1066 | 349 | 15.86 | +7900 | +22.6 |
| ONE TARGET A SHOOTER | 866 | 866 | 267 | 12.14 | +3536 | +13.2 |
| SEARCH SPOT | 268 | 268 | 260 | 11.82 | +11701 | +45.0 |
| LEGAL CHARGES ONLY | 258 | 258 | 258 | 11.73 | +0 | +0.0 |
| DEPLOY BY FIGURES | 359 | 359 | 230 | 10.45 | +3605 | +15.7 |
| FIVE ACTION | 2165 | 2165 | 218 | 9.91 | +9091 | +41.7 |
| PATHS CROSS | 204 | 204 | 204 | 9.27 | +6916 | +33.9 |
| TIME ON OUR SIDE | 834 | 754 | 150 | 6.82 | +522 | +3.5 |
| SHOT RISK POINTS | 552 | 552 | 103 | 4.68 | +3425 | +33.2 |
| MOVE TO CHARGE COMPUTED | 157 | 157 | 94 | 4.27 | +8034 | +85.5 |
| FOUR ROUNDS | 148 | 148 | 74 | 3.36 | +5242 | +70.8 |
| MAX FOR POSITIONING | 257 | 255 | 62 | 2.82 | +191 | +3.1 |
| NEXT OBJECTIVE NEARER | 359 | 359 | 61 | 2.77 | +925 | +15.2 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 2.50 | +0 | +0.0 |
| COVER ONCE | 276 | 230 | 54 | 2.45 | +1034 | +19.2 |
| SHOTS IN THE MOVE | 808 | 778 | 53 | 2.41 | +1672 | +31.5 |
| CANNON SIGHT KEPT | 50 | 50 | 50 | 2.27 | +0 | +0.0 |
| CANNON PLANNED TARGET | 261 | 261 | 47 | 2.14 | -325 | -6.9 |
| HARD STAY DROPPED | 37 | 37 | 37 | 1.68 | +0 | +0.0 |
| CHARGE LOSSES | 289 | 289 | 36 | 1.64 | +4609 | +128.0 |
| MARCH CHECK | 53 | 53 | 35 | 1.59 | +754 | +21.5 |
| RISK BY HIS FIGURE | 524 | 524 | 34 | 1.55 | +4422 | +130.1 |
| ADVANCE LANE KEPT | 33 | 33 | 33 | 1.50 | +0 | +0.0 |
| FALLS SHORT | 509 | 433 | 33 | 1.50 | +159 | +4.8 |
| IDLE COST | 302 | 236 | 33 | 1.50 | +226 | +6.9 |
| LANE BY FIGURES | 32 | 32 | 32 | 1.45 | +1621 | +50.7 |
| CHARGE NOW FIRST | 92 | 92 | 31 | 1.41 | -1665 | -53.7 |
| STAY WORTH | 944 | 909 | 30 | 1.36 | +262 | +8.7 |
| RISK BY ARC | 95 | 95 | 29 | 1.32 | +505 | +17.4 |
| RESERVE FALL BACK | 28 | 28 | 28 | 1.27 | +1156 | +41.3 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 1.23 | +2043 | +75.7 |
| SHOOTS FROM THE BEST SPOT | 37 | 37 | 26 | 1.18 | +154 | +5.9 |
| FOLLOW UP WEIGHED | 25 | 25 | 25 | 1.14 | +5283 | +211.3 |
| HIS TURN DENIED | 83 | 83 | 25 | 1.14 | +837 | +33.5 |
| SCOUT WAITS | 24 | 24 | 24 | 1.09 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 77 | 77 | 24 | 1.09 | +559 | +23.3 |
| NEXT CHARGE BY LIST | 231 | 231 | 23 | 1.05 | +628 | +27.3 |
| MISSILES IN THE MOVE | 164 | 134 | 22 | 1.00 | +413 | +18.8 |
| COMBAT PIVOT | 21 | 21 | 21 | 0.95 | +0 | +0.0 |
| OFF BEST | 21 | 21 | 21 | 0.95 | -679 | -32.3 |
| HOLDS AMBUSHERS | 20 | 20 | 20 | 0.91 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 40 | 40 | 19 | 0.86 | +959 | +50.5 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.86 | +44 | +2.3 |
| CHARGE NOT DECLARED | 18 | 18 | 18 | 0.82 | -2413 | -134.0 |
| REDIRECT COUNTER | 81 | 70 | 18 | 0.82 | +1179 | +65.5 |
| MARCH BY THE SUM | 17 | 17 | 17 | 0.77 | +1218 | +71.6 |
| MANOEUVRE | 42 | 42 | 16 | 0.73 | +468 | +29.3 |
| MODEL FACING | 16 | 16 | 16 | 0.73 | +2950 | +184.3 |
| NEARER NOT NEEDED | 221 | 210 | 16 | 0.73 | +612 | +38.3 |
| WHO HITS BACK | 16 | 16 | 16 | 0.73 | +2147 | +134.2 |
| TIED UP BY THE SUM | 22 | 22 | 15 | 0.68 | +461 | +30.7 |
| ONE OBJECTIVE FORMULA | 162 | 138 | 14 | 0.64 | +440 | +31.5 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.64 | +0 | +0.0 |
| AFTERMATH IN POINTS | 13 | 13 | 13 | 0.59 | +2468 | +189.9 |
| CHAFF IN THE MOVE | 17 | 17 | 12 | 0.55 | +163 | +13.6 |
| CHAFF PASSED | 12 | 12 | 12 | 0.55 | -10 | -0.9 |
| ONE FIGHT FORMULA | 227 | 122 | 12 | 0.55 | +138 | +11.5 |
| RANDOM MOVE BY FIGURES | 24 | 24 | 12 | 0.55 | +561 | +46.8 |
| SURE REACH TOGETHER | 22 | 22 | 12 | 0.55 | +34 | +2.8 |
| FEATURE BUFFS | 56 | 56 | 11 | 0.50 | +183 | +16.6 |
| FIGHT TO THE END | 62 | 62 | 11 | 0.50 | +758 | +69.0 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.50 | +0 | +0.0 |
| HIS CHARGE DENIED | 14 | 14 | 9 | 0.41 | +228 | +25.3 |
| CAST JOB | 21 | 21 | 8 | 0.36 | +83 | +10.4 |
| GUN MASK | 30 | 30 | 8 | 0.36 | +154 | +19.3 |
| SUPPORT NARROWED | 54 | 54 | 8 | 0.36 | -149 | -18.6 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.32 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 7 | 0.32 | +98 | +14.0 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.32 | +331 | +47.3 |
| WIDER SPREAD | 101 | 101 | 7 | 0.32 | +40 | +5.8 |
| OPENS UP | 9 | 9 | 5 | 0.23 | +67 | +13.4 |
| WHOLE FIGHT GAIN | 6 | 6 | 5 | 0.23 | +62 | +12.4 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.18 | +0 | +0.0 |
| HUNT IN PAIRS | 19 | 6 | 4 | 0.18 | +317 | +79.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.18 | +0 | +0.0 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.18 | +204 | +51.0 |
| REFUSING RETIRES | 6 | 6 | 4 | 0.18 | -1 | -0.2 |
| SET UP TOGETHER | 22 | 18 | 4 | 0.18 | +78 | +19.4 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 0.14 | +145 | +48.2 |
| EDGE GIVE GROUND | 7 | 7 | 3 | 0.14 | +57 | +19.1 |
| FALL BACK GOOD ORDER | 115 | 115 | 3 | 0.14 | +45 | +14.9 |
| KEEP FALLS | 3 | 3 | 3 | 0.14 | +75 | +25.0 |
| OVERRUNS AWAY | 15 | 15 | 3 | 0.14 | +60 | +20.1 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.14 | -24 | -7.9 |
| BEST PRIZE | 2 | 2 | 2 | 0.09 | -34 | -16.8 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.09 | +0 | +0.1 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.09 | +0 | +0.0 |
| FALLBACK BY WORTH | 10 | 10 | 2 | 0.09 | +27 | +13.6 |
| HONEST WORTH | 130 | 130 | 2 | 0.09 | +11 | +5.6 |
| MISSILES NEXT TURN | 224 | 171 | 2 | 0.09 | +25 | +12.5 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.09 | +110 | +55.1 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.09 | +143 | +71.5 |
| RUN DOWN | 105 | 105 | 2 | 0.09 | +16 | +7.9 |
| SPELLS IN THE FIGHT | 26 | 26 | 2 | 0.09 | +19 | +9.4 |
| STUCK PIVOT | 2 | 2 | 2 | 0.09 | +0 | +0.0 |
| WHOLE FIGHT | 11 | 11 | 2 | 0.09 | +23 | +11.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.05 | +31 | +30.9 |
| JOINT CHARGE NOW | 6 | 6 | 1 | 0.05 | +19 | +18.6 |
| MOVE SPELL IN RANGE | 8 | 5 | 1 | 0.05 | +39 | +39.2 |
| NO DOUBLE ROUNDS | 111 | 111 | 1 | 0.05 | +26 | +26.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.05 | +99 | +99.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.05 | -443 | -442.8 |
| SAME CHARGE LATER | 5 | 5 | 1 | 0.05 | +0 | +0.3 |
| THE PROMISE ADDS | 15 | 15 | 1 | 0.05 | +24 | +23.8 |
| WAR ENGINE JOBS | 4 | 4 | 1 | 0.05 | -7 | -6.7 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 7 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 34 | 34 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 10 | 10 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 13 | 13 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 24 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 193 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 19 | 19 | 0 | 0.00 | - | - |
| GIVES UP | 13 | 13 | 0 | 0.00 | - | - |
| GUN FIGURES | 56 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 87 | 87 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 134 | 134 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 142 | 142 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 83 | 83 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 77 | 77 | 0 | 0.00 | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LONG SHOT | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 15 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 41 | 41 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT TURNED | 7 | 7 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 102 | 102 | 0 | 0.00 | - | - |
| OPENS A LANE | 6 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 1903 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 41 | 41 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 17 | 17 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 61 | not checked | - | - | - | - |
| STAND AND SHOOT | 29 | 29 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 23 | 23 | 0 | 0.00 | - | - |
| STANDS STILL | 817 | 817 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 218 | not checked | - | - | - | - |
| THE PROMISED MOVE | 19 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 59 | 59 | 0 | 0.00 | - | - |

### Off best figure: ja-mine-f9a8036-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.59 | 0.86 | 25.7 |
| CHARGE NOW FIRST | rule | 0.59 | 0.82 | 53.7 |
| CHARGE NOT DECLARED | rule | 0.41 | 0.41 | 134.0 |
| CANNON PLANNED TARGET | rule | 0.41 | 0.18 | 26.1 |
| JOB FIRST | gate | 0.45 | 0.09 | 22.7 |
| SUPPORT NARROWED | rule | 0.14 | 0.23 | 18.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | 0.09 | 93.4 |
| CHAFF PASSED | rule | 0.09 | 0.05 | 3.4 |
| PIVOT GUARDS FLANK | rule | - | 0.14 | 7.9 |
| BEST PRIZE | rule | - | 0.09 | 16.8 |
| FALLBACK | gate | 0.09 | - | 2.4 |
| AFTERMATH BAND | gate | - | 0.05 | 4.5 |
| FRIENDS SHOTS CHECKED | rule | - | 0.05 | 4.5 |
| PURSUES BIG PREY | rule | - | 0.05 | 442.8 |
| RULE SWITCHED OFF | gate | 0.05 | - | 22.4 |
| TURN GATE | gate | 0.05 | - | 0.9 |
| WAR ENGINE JOBS | rule | 0.05 | - | 6.7 |

### Plans: ja-mine-f9a8036-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 336 | 171 | 51% |
| Mine | join | 0.9 | 95% | 25 | 0 | 0% |
| Mine | move | 25.9 | 95% | 1345 | 0 | 0% |
| Mine | shoot | 13.2 | 61% | 505 | 1004 | 199% |
| Mine | support | 0.1 | 67% | 0 | 0 | - |
| Opponent | charge | 3.7 | 65% | 696 | 418 | 60% |
| Opponent | join | 0.2 | 100% | 9 | 0 | 0% |
| Opponent | move | 32.8 | 94% | 1597 | 0 | 0% |
| Opponent | shoot | 7.0 | 68% | 270 | 355 | 132% |
| Opponent | support | 0.6 | 79% | 1 | 0 | 0% |

### Packages: hunt the guns, ja-mine-f9a8036-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 51 |
| Opponent | 0.1 | 3 | 0 | 100% | 100% | 0% | 2.0 | 414 | 362 | 100% | 82 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 69 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 64 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 377 |
| Ogre Kingdoms | 1.0 | 2 | 0 | 100% | 100% | 0% | 2.0 | 512 | 435 | 100% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 218 | 215 | 100% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 300 |

### Battle groups: ja-mine-f9a8036-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 27% | 50% | 0% | - | 0% | 0% | 17% | 83% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 25% | 67% | 27% | 25% | 55% | 0% | 9% | 36% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-mine-f9a8036-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 0 (9) | 0 | 0 | 28 | 89% | 2.0 | 0 (3) | 0 (3) | 0 (3) | 0 (7) | 0 (2) |
| Mine | Character | 85 | 43 (85) | 43 | 0 | 37 | 25% | 2.8 | 58 (25) | 42 (27) | 46 (17) | 50 (46) | 49 (23) |
| Mine | Clean-up | 13 | 61 (13) | 12 | 49 | 35 | 62% | 3.2 | 0 (2) | 10 (8) | 157 (3) | 85 (10) | 0 (3) |
| Mine | Fast Hammer | 22 | 37 (22) | 13 | 24 | 25 | 23% | 2.9 | 16 (8) | 50 (9) | 51 (5) | 43 (16) | 15 (6) |
| Mine | Hammer | 40 | 23 (40) | 12 | 12 | 40 | 32% | 2.7 | 5 (6) | 31 (26) | 18 (8) | 20 (30) | 31 (10) |
| Mine | Holder | 16 | 58 (16) | 0 | 58 | 24 | 38% | 3.1 | 38 (4) | 76 (9) | 0 (3) | 103 (9) | 0 (7) |
| Mine | Shooter | 30 | 74 (30) | 26 | 48 | 38 | 0% | 1.9 | 29 (8) | 93 (19) | 85 (3) | 78 (27) | 39 (3) |
| Mine | War machine | 57 | 26 (57) | 26 | 0 | 47 | 5% | 1.3 | 19 (19) | 22 (18) | 35 (20) | 22 (10) | 27 (47) |
| Mine | Wizard | 12 | 9 (12) | 9 | 0 | 13 | 25% | 2.0 | 11 (5) | 0 (2) | 0 (2) | 0 (4) | 12 (5) |
| Opponent | Chaff | 51 | 74 (51) | 13 | 61 | 45 | 33% | 2.4 | 50 (15) | 124 (20) | 7 (16) | 88 (45) | 0 (6) |
| Opponent | Character | 59 | 67 (59) | 67 | 0 | 20 | 25% | 2.7 | 41 (21) | 56 (26) | 184 (7) | 67 (37) | 82 (17) |
| Opponent | Clean-up | 15 | 76 (15) | 31 | 45 | 32 | 53% | 2.4 | 19 (6) | 133 (9) | - | 83 (13) | 0 (2) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 25 | 34 (25) | 19 | 15 | 32 | 36% | 3.2 | 25 (6) | 37 (16) | 28 (3) | 30 (15) | 39 (10) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Hammer | 34 | 25 (34) | 19 | 6 | 39 | 32% | 2.9 | 11 (8) | 30 (23) | 0 (3) | 32 (21) | 17 (13) |
| Opponent | Holder | 23 | 85 (23) | 3 | 82 | 22 | 26% | 2.8 | 83 (5) | 90 (12) | 76 (6) | 78 (14) | 101 (9) |
| Opponent | Shooter | 21 | 43 (21) | 2 | 41 | 22 | 0% | 2.0 | 16 (7) | 90 (9) | 8 (5) | 41 (14) | 48 (7) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 24 | 40 (24) | 40 | 0 | 19 | 17% | 1.3 | 64 (11) | 32 (5) | 11 (8) | 15 (3) | 43 (21) |
| Opponent | Wizard | 16 | 9 (16) | 9 | 0 | 22 | 0% | 1.8 | 0 (6) | 13 (8) | - | 15 (6) | 0 (8) |

### Charged fights: ja-mine-f9a8036-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 95 | 85 | 1.0 | 1.0 | 85 | 60 | +24 | 2 of 4 | 3 of 4 | - | +24 |
| Mine | Chaos Dwarfs | 4 | 0 | 247 | 1.8 | 1.1 | 141 | 0 | +141 | 3 of 7 | 6 of 7 | +104 | +148 |
| Mine | Dwarfen Mountain Holds | 4 | 662 | 23 | 1.2 | 1.0 | 19 | 12 | +7 | 0 of 5 | 4 of 5 | - | +7 |
| Mine | Empire of Man | 5 | 113 | 47 | 1.0 | 1.0 | 47 | 0 | +47 | 2 of 5 | 5 of 5 | - | +47 |
| Mine | Grand Cathay | 4 | 458 | 492 | 3.0 | 1.1 | 164 | 0 | +164 | 4 of 12 | 11 of 12 | +758 | +110 |
| Mine | High Elf Realms | 1 | 0 | 455 | 5.0 | 1.4 | 91 | 0 | +91 | 0 of 5 | 4 of 5 | +325 | +32 |
| **Mine** | all armies | 22 | 246 | 186 | 1.7 | 1.1 | 107 | 8 | +100 | 11 of 38 | 33 of 38 | +396 | +74 |
| Opponent | Dwarfen Mountain Holds | 2 | 274 | 42 | 1.5 | 1.7 | 28 | 20 | +8 | 0 of 3 | 3 of 3 | +42 | -60 |
| Opponent | Empire of Man | 2 | 342 | 333 | 3.0 | 1.3 | 111 | 0 | +111 | 1 of 6 | 5 of 6 | +91 | +115 |
| Opponent | Grand Cathay | 2 | 324 | 550 | 5.5 | 1.1 | 100 | 0 | +100 | 2 of 11 | 11 of 11 | +95 | +100 |
| Opponent | Kingdom of Bretonnia | 1 | 165 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| Opponent | Ogre Kingdoms | 2 | 155 | 165 | 4.0 | 1.0 | 41 | 8 | +33 | 3 of 8 | 4 of 8 | - | +33 |
| Opponent | Skaven | 1 | 661 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 1 of 3 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 33 | 907 | 4.2 | 1.1 | 213 | 38 | +176 | 11 of 17 | 12 of 17 | +355 | +164 |
| Opponent | Vampire Counts | 3 | 0 | 447 | 4.0 | 1.2 | 112 | 47 | +65 | 7 of 12 | 10 of 12 | +63 | +65 |
| Opponent | Warriors of Chaos | 3 | 0 | 297 | 0.7 | 2.0 | 446 | 0 | +446 | 2 of 2 | 2 of 2 | +446 | - |
| Opponent | Wood Elf Realms | 2 | 0 | 626 | 3.5 | 1.1 | 179 | 34 | +145 | 3 of 7 | 4 of 7 | +0 | +169 |
| **Opponent** | all armies | 22 | 143 | 427 | 3.2 | 1.2 | 132 | 22 | +110 | 32 of 71 | 54 of 71 | +164 | +101 |

### Effective charges: ja-mine-f9a8036-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 1 (net -52) | 0 | 1 (net +0) | 0 | 1 (net +72) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 7 | 2 (net +254) | 0 | 0 | 0 | 1 (net +45) | 4 (net +109) | 0 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 2 (net +46) | 0 | 2 (net +0) | 1 | 0% (0 of 4) |
| Mine | Empire of Man | 5 | 0 | 0 | 0 | 0 | 0 | 3 (net +31) | 2 | 0% (0 of 3) |
| Mine | Grand Cathay | 12 | 3 (net +253) | 0 | 3 (net +135) | 0 | 3 (net +70) | 3 (net +198) | 0 | 25% (3 of 12) |
| Mine | High Elf Realms | 5 | 0 | 0 | 0 | 1 (net +70) | 4 (net +96) | 0 | 0 | 0% (0 of 5) |
| Opponent | Dwarfen Mountain Holds | 3 | 1 (net +85) | 0 | 0 | 2 (net -30) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 6 | 1 (net +0) | 0 | 0 | 2 (net +170) | 1 (net +91) | 1 (net +95) | 1 | 0% (0 of 5) |
| Opponent | Grand Cathay | 11 | 0 | 0 | 3 (net +144) | 7 (net +95) | 1 (net +0) | 0 | 0 | 27% (3 of 11) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 2 (net +52) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 5 (net +59) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 | 14% (1 of 7) |
| Opponent | Skaven | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 17 | 2 (net +282) | 0 | 6 (net +66) | 3 (net +176) | 1 (net +130) | 4 (net +342) | 1 | 38% (6 of 16) |
| Opponent | Vampire Counts | 12 | 1 (net -68) | 0 | 4 (net +114) | 6 (net +43) | 1 (net +126) | 0 | 0 | 33% (4 of 12) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +796) | 1 (net +95) | 0 | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 7 | 3 (net +165) | 0 | 0 | 0 | 0 | 4 (net +129) | 0 | 0% (0 of 7) |

### Charged fights, damage counted: ja-mine-f9a8036-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 354 | 353 | +253 | 304 | 48 | +256 | +72.4 |
| Mine | 50-54% | 1 | 52 | 186 | -52 | 16 | 52 | -36 | -70.2 |
| Mine | Effective (55-75%) | 3 | 369 | 207 | +135 | 157 | 0 | +157 | +42.5 |
| Mine | 76-89% | 4 | 134 | 87 | +41 | 41 | 28 | +13 | +9.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 | 222 | 169 | +92 | 119 | 22 | +98 | +44.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 389 | 79 | +80 | 80 | 21 | +59 | +15.1 |
| Mine | No odds | 4 | 260 | 140 | +41 | 124 | 94 | +30 | +11.5 |
| Mine | All fights | 38 | 276 | 166 | +100 | 128 | 32 | +95 | +34.6 |
| Opponent | Long shot (under 50%) | 15 | 164 | 235 | +92 | 121 | 31 | +91 | +55.3 |
| Opponent | Effective (55-75%) | 14 | 301 | 270 | +92 | 168 | 85 | +83 | +27.5 |
| Opponent | 76-89% | 23 | 340 | 172 | +114 | 155 | 35 | +120 | +35.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 333 | 182 | +180 | 194 | 15 | +179 | +53.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 661 | 108 | +88 | 88 | 12 | +76 | +11.5 |
| Opponent | No odds | 3 | 285 | 269 | +35 | 78 | 11 | +67 | +23.6 |
| Opponent | All fights | 71 | 314 | 206 | +110 | 149 | 38 | +110 | +35.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-mine-f9a8036-p2 | move | 169 | 35 (21%) | 27 (16%) | 22 (13%) | 112 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L0918, L1118 |
| Invocation of Nehek | Opponent | L0425, L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

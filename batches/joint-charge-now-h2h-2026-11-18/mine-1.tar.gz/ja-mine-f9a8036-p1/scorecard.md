# Doctrine scorecard: ja-mine-f9a8036-p1

### Scorecard: ja-mine-f9a8036-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 5 | 0 | 0 | 0 | 30 |
| L0118 | 4 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 436 |
| L0135 | 3 | 1 | Mine | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 8 | 2 | 1 | 3 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 7 | 5 | 1 | 0 | 0 | 0 | 0 | 220 |
| L0319 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 190 |
| L0421 | 1 | 1 | Mine | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 4 | 0 | 0 | 0 | 145 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 190 |
| L0508 | 4 | 1 | Opponent | no | 3 | 6 | 1 | 4 | 0 | 0 | 0 | 45 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 255 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | 4 | 0 | 0 | 0 | 0 | 0 | 403 |
| L0612 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 215 |
| L0628 | 4 | 1 | Opponent | no | 3 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 484 |
| L0717 | 3 | 1 | Opponent | yes | 2 | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 5 | 1 | 2 | 1 | 1 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 295 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 170 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 70 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 349 |
| L0930 | 6 | 1 | Opponent | no | 11 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 2 | 5 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | yes | 6 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| L1114 | 4 | 1 | Mine | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 361 |
| L1114 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Opponent | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 9 | 1 | 5 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 1 | 0 | 0 | 70 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 6 | 2 | 2 | 0 | 0 | 0 | 613 |
| L1431 | 3 | 1 | Mine | no | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 3 | - | 2 | 1 | 2 | 0 | 0 | 456 |
| L1527 | 3 | 1 | Mine | no | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 3 | 3 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 1 | 0 | 0 | 168 |
| L1723 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 132 |
| L1723 | 1 | 1 | Opponent | yes | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 4 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 3.3 | 2.8 | 2.0 | 1.0 | 0.2 | 0.0 | 0.0 | 148.9 |
| **Average** | | | Opponent | 25% | 2.4 | 2.8 | 2.8 | 1.9 | 0.3 | 0.0 | 0.0 | 89.4 |

### KPIs: ja-mine-f9a8036-p1

Rules off - Opponent only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 30 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (43 of 150) | 3% (4 of 138) | 16% (47 of 288) |
| Winner chose to follow up after the loser gave ground |  | 80% (37 of 46); on the table 85% | 91% (21 of 23); on the table 91% | 84% (58 of 69); on the table 87% |
| Winner chose to pursue after the loser fell back in good order |  | 64% (7 of 11); on the table 64% | 93% (13 of 14); on the table 93% | 80% (20 of 25); on the table 80% |
| Winner chose to pursue after the loser fled |  | 61% (11 of 18); on the table 67% | 89% (17 of 19); on the table 89% | 76% (28 of 37); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 73% (55 of 75); on the table 77% | 91% (51 of 56); on the table 91% | 81% (106 of 131); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 40% (127 of 318) | 32% (60 of 186) | 37% (187 of 504) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (127 of 275) | 41% (60 of 146) | 44% (187 of 421) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (6 of 15) | 43% (20 of 47) | 42% (26 of 62) |
| Points that never fought | lower | 42% (25073 of 59487) | 52% (31050 of 59891) | 47% (56123 of 119378) |
|   infantry points that never fought | lower | 49% (7095 of 14409) | 72% (8096 of 11241) | 59% (15191 of 25650) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (134 of 241) | 60% (144 of 239) | 58% (278 of 480) |
| Bound items with a magic missile used (at least once a game) |  | 100% (21 of 21); 2.7 uses a game | 82% (14 of 17); 1.6 uses a game | 92% (35 of 38); 2.1 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.6 uses a game | 38% (3 of 8); 0.2 uses a game | 46% (11 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 44% (8 of 18); 0.3 uses a game | 60% (6 of 10); 0.2 uses a game | 50% (14 of 28); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (24295 of 50144) | 57% (29678 of 51793) | 53% (53973 of 101937) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (41%) | 1.7 (40%) | 4.3 (41%) |
| MARCHED: its unit marched | 1.4 (21%) | 0.9 (21%) | 2.3 (21%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.0 (0%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.2 (18%) | 0.5 (11%) | 1.6 (15%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.1 (2%) | 0.5 (13%) | 0.6 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.3 (8%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.7 | 1.9 | 6.2 | 0.5 | 1.4 |
| not cast | 3.3 | 3.1 | 3.1 | 10.6 | 1.9 | 23.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (51%) | 0.3 (11%) | 4.3 (41%) | 0.5 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (21%) | 0.4 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.1 (2%) | 0.3 (10%) | 1.6 (15%) | 0.6 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (10%) | 0.4 (13%) | 0.6 (21%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.1 (2%) | 0.3 (9%) | 0.2 (8%) | 0.6 (6%) | 0.1 (5%) | 1.4 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.1 (4%) | 0.0 (1%) | 0.5 (5%) | 0.1 (5%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (7%) | 0.0 (0%) | 0.1 (1%) | 0.1 (5%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (76%) | 0.4 (12%) | 1.5 (48%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.9 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.9 a game | 1.1 a game |
| stood (cast and not dispelled) | 80% (32 of 40) | 59% (13 of 22) | 73% (45 of 62) |
| the unit moved after it | 53% (17 of 32) | 77% (10 of 13) | 60% (27 of 45) |
| it charged on its next turn | 0% (0 of 32) | 0% (0 of 13) | 0% (0 of 45) |
| the enemy charged it first | 9% (3 of 32) | 0% (0 of 13) | 7% (3 of 45) |
| it fought by the end of its next turn | 9% (3 of 32) | 0% (0 of 13) | 7% (3 of 45) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (6 of 32) | 0% (0 of 13) | 13% (6 of 45) |
| none of these (no charge, no fight, no charge escaped) | 72% (23 of 32) | 100% (13 of 13) | 80% (36 of 45) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (527 of 836) | 62% (337 of 540) | 63% (864 of 1376) |
|   cavalry | 48% (30 of 63) | 71% (75 of 105) | 62% (105 of 168) |
|   character | 69% (80 of 116) | 39% (37 of 96) | 55% (117 of 212) |
|   chariot | 69% (52 of 75) | 83% (19 of 23) | 72% (71 of 98) |
|   infantry | 61% (152 of 251) | 63% (151 of 238) | 62% (303 of 489) |
|   monster | 60% (29 of 48) | 52% (11 of 21) | 58% (40 of 69) |
|   war machine | 65% (184 of 283) | 77% (44 of 57) | 67% (228 of 340) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (20%) | 1.3 (19%) | 3.4 (20%) |
| CHARGED: it charged | 0.8 (7%) | 1.4 (21%) | 2.2 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.5 (7%) | 1.1 (6%) |
| MOVED: a war machine that moved | 1.5 (14%) | 0.4 (6%) | 1.9 (11%) |
| NO TARGET IN RANGE | 2.2 (21%) | 2.0 (30%) | 4.2 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.2 (3%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (19%) | 0.8 (12%) | 2.8 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 0.9 | 83% | 3.8 pts | 17 pts |
| character | 4.5 | 2.2 | 69% | 7.5 pts | 34 pts |
| chariot | 2.4 | 1.9 | 63% | 17.2 pts | 42 pts |
| infantry | 15.0 | 5.9 | 74% | 8.3 pts | 124 pts |
| monster | 1.6 | 0.5 | 80% | 8.5 pts | 14 pts |
| war machine | 7.6 | 5.7 | 64% | 21.5 pts | 163 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.5 | 5.1 | 4.3 |
| Charges that made contact a game | 2.8 | 3.6 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.10 declared, 0.80 contact (20 units) | 0.58 declared, 0.58 contact (12 units) | 0.91 declared, 0.72 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 1.25 declared, 0.88 contact (8 units) | 1.00 declared, 0.73 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.32 contact (205 units) | 0.56 declared, 0.38 contact (242 units) | 0.49 declared, 0.36 contact (447 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 41% (23 of 56) | 60% (9 of 15) | 50% (3 of 6) | 45% (35 of 77) |
| Character in a unit | 84% (38 of 45) | 69% (18 of 26) | 33% (1 of 3) | 77% (57 of 74) |
| Character on its own | 74% (20 of 27) | 50% (15 of 30) | 36% (17 of 47) | 50% (52 of 104) |
| Chariot | 93% (13 of 14) | 40% (4 of 10) | - | 71% (17 of 24) |
| Infantry | 45% (32 of 71) | 32% (11 of 34) | 50% (1 of 2) | 41% (44 of 107) |
| Monster | 61% (14 of 23) | 100% (8 of 8) | - | 71% (22 of 31) |
| Monstrous | 86% (6 of 7) | 64% (9 of 14) | - | 71% (15 of 21) |
| War Machines | 85% (35 of 41) | 100% (1 of 1) | - | 86% (36 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 76% (13 of 17); on the table 88% | 49% (67 of 138) | 39% | 52% (17 of 33) | 100% (9 of 9); 6.3 uses a game | 100% (3 of 3); 1.8 uses a game | 67% (6 of 9); 1.0 uses a game |
| Chaos Dwarfs | 3 | 75% (3 of 4); on the table 75% | 25% (6 of 24) | 57% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 73% (8 of 11); on the table 73% | - | 62% | 66% (27 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 56% (5 of 9); on the table 67% | 58% (21 of 36) | 56% | 69% (44 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 87% (13 of 15); on the table 87% | 29% (31 of 108) | 43% | 45% (20 of 44) | 100% (12 of 12); 7.2 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 75% (18 of 24); on the table 75% | 7% (2 of 30) | 43% | 41% (20 of 49) | 100% (5 of 5); 4.2 uses a game | 39% (7 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (6 of 6); on the table 100% | - | 14% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 18% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 86% (6 of 7); on the table 86% | 8% (1 of 12) | 53% | 81% (17 of 21) | 100% (3 of 3); 3.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 67% (2 of 3); on the table 67% | 42% (15 of 36) | 42% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 3 | 100% (1 of 1); on the table 100% | 33% (8 of 24) | 53% | 76% (19 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 4 | 85% (11 of 13); on the table 85% | 0% (0 of 12) | 35% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 83% (5 of 6); on the table 83% | 48% (20 of 42) | 54% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 100% (3 of 3); on the table 100% | 33% (6 of 18) | 50% | 68% (25 of 37) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 100% (8 of 8); on the table 100% | 42% (10 of 24) | 49% | 52% (24 of 46) | 40% (2 of 5); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-mine-f9a8036-p1, 30 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (26) | 60% (31) | 51% (57) |
| ...free all their last turn and able to turn (per game) | 0.63 | 0.63 | 1.27 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.07 | 0.23 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.53 | 1.07 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.27 | 0.23 | 0.50 |

### Quality by phase: ja-mine-f9a8036-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 60% (55 of 91) | 52% (69 of 132) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (162 of 349) | 51% (67 of 132) |
| Strategy | Support requests answered (helper made contact too) | 60% (6 of 10) | 73% (8 of 11) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (8 of 14) | 50% (6 of 12) |
| Strategy | Joined characters whose unit fought | 50% (27 of 54) | 35% (17 of 49) |
| Strategy | Lone characters that fought | 77% (53 of 69) | 64% (41 of 64) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 148.9 | 89.4 |
| Movement | Fights charged into per game | 2.5 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 67, net -41 | 25 of 88, net +78 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 67, net +60 | 18 of 88, net +114 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 67, net +69 | 8 of 88, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 67, net +45 | 17 of 88, net +182 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.1 | 10.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (189 of 362) | 40% (124 of 313) |
| Shooting | Points destroyed by shooting units | 86.3 | 28.5 |
| Shooting | War machine shots | 6.1 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (94 of 184) | 57% (25 of 44) |
| Shooting | Points destroyed by war machines | 51.3 | 6.7 |
| Magic | Magic missiles cast | 2.9 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (32 of 87) | 29% (12 of 41) |
| Magic | Wounds caused by magic missiles | 7.1 | 2.1 |
| Magic | Wounds caused by other spells | 0.9 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 76.1 | 26.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.6 / 0.5 / 0.2 | 2.0 / 0.5 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 207.6 | 343.4 |
| Combat | Points run down | 27.3 | 80.3 |
| Combat | Net points per charged fight, damage counted | +50 | +94 |
| Combat | Net per 100 charger points, damage counted | +19.2 | +35.4 |
| Combat | First round won (charged fights) | 73% | 71% |
| Combat | Net points per charged fight | +50 | +98 |
| Combat | Net points per supported fight / lone fight | +54 / +49 | +251 / +80 |
| Combat | Charged fights on a top-3 enemy unit | 23 of 74 | 45 of 97 |
| Game | Points lost | 612.2 | 557.1 |
| Game | VP from objectives | 655.3 | 680.0 |
| Game | Lone holders (player turns) | 3.3 | 2.4 |

- Mine won / drew / lost: 15 / 4 / 11 of 30 ended games (of 30); mean margin (Mine - Opponent) -119 VP
- The side that went first won 9 of 26 games with a winner
- Points traded per game (both sides' losses): 1169
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-mine-f9a8036-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +33.6 | 0.0 | 21.0 | 0.1 | +12.0 | 0.0 | 19.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +8.5 | 0.0 | 2.8 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.9 | +0.0 | 0.0 | 14.2 | 0.5 | +0.0 | 0.0 | 4.3 |
| BACKUP TARGETS | 0.3 | +1.3 | 0.0 | 10.9 | 0.3 | +1.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.4 | 8.5 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | +1.1 | 13.3 | 9.9 | 0.2 | -41.8 | 23.0 | 1.7 |
| BOMBING RUN | 0.1 | +4.1 | 4.8 | 5.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 57.2 | 13.8 | 0.2 | +0.0 | 13.7 | 4.2 |
| CANNON PLANNED TARGET | 5.1 | +84.6 | 341.7 | 102.2 | 1.3 | +24.9 | 22.2 | 16.3 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -10.6 | 3.7 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| CAST JOB | 0.5 | +17.8 | 39.3 | 36.4 | 0.2 | +0.8 | 6.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +45.6 | 20.3 | 0.0 | 0.1 | +2.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 16.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.5 | +18.7 | 0.0 | 12.5 | 0.8 | +22.7 | 0.0 | 8.5 |
| CHAFF PASSED | 0.7 | -1.5 | 6.5 | 17.3 | 0.4 | -1.2 | 0.0 | 11.8 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.5 | -267.6 | 0.0 | 184.2 | 6.9 | -322.3 | 0.0 | 161.8 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 31.8 | 29.6 | 0.8 | +0.0 | 54.8 | 13.1 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 204.8 | 13.2 | 2.3 | +0.0 | 241.0 | 43.2 |
| CHARGER SLAIN LOST | 0.6 | -25.2 | 62.4 | 6.8 | 0.4 | -7.8 | 67.2 | 10.2 |
| CHEAP HELPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.4 |
| CHEAPEST HOLDER | 0.3 | -14.7 | 30.5 | 0.0 | 0.2 | -7.4 | 20.7 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 43.3 | 25.0 | 0.4 | +0.0 | 32.7 | 28.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +51.9 | 6.2 | 0.0 | 0.5 | +43.7 | 0.0 | 0.0 |
| COVER ONCE | 7.7 | -584.4 | 0.0 | 180.7 | 5.7 | -356.7 | 0.0 | 84.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 2.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +5.7 | 0.0 | 8.3 | 7.6 | +82.0 | 0.0 | 43.1 |
| EDGE GIVE GROUND | 0.1 | +1.8 | 3.6 | 0.0 | 0.3 | +11.0 | 59.6 | 4.8 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +12.2 | 143.1 | 45.0 | 3.6 | +15.9 | 327.0 | 45.5 |
| FALLBACK BY WORTH | 0.2 | +0.2 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| FALLS SHORT | 4.1 | +69.9 | 0.0 | 85.6 | 18.1 | +245.1 | 0.0 | 212.9 |
| FEATURE BUFFS | 1.8 | +57.9 | 0.0 | 30.6 | 0.5 | +8.8 | 0.0 | 1.8 |
| FIGHT LIFT | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +49.5 | 67.2 | 19.1 | 1.8 | +89.5 | 170.0 | 49.8 |
| FIRE IN ORDER | 0.3 | +0.0 | 14.0 | 0.0 | 0.3 | +0.0 | 18.3 | 4.2 |
| FIVE ACTION | 47.1 | +2633.8 | 898.1 | 747.9 | 45.1 | +2850.6 | 562.1 | 555.1 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 212.7 | 4.8 | +0.0 | 0.0 | 95.5 |
| FOCUS FIRE | 0.1 | +1.4 | 4.2 | 0.0 | 0.1 | +0.8 | 1.5 | 6.2 |
| FOLLOW UP WEIGHED | 0.6 | +139.0 | 0.0 | 0.0 | 0.7 | +99.8 | 0.0 | 19.1 |
| FOUR ROUNDS | 3.0 | +312.8 | 273.3 | 56.5 | 4.2 | +462.8 | 386.3 | 60.1 |
| FRIEND CHARGES FIRST | 0.1 | -5.2 | 0.0 | 0.0 | 0.2 | -38.6 | 0.0 | 5.0 |
| FRIEND SHOOTS FIRST | 0.3 | -9.2 | 0.0 | 9.4 | 0.3 | -5.0 | 0.0 | 2.2 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +5.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -2.5 | 9.6 | 0.0 | 0.1 | -1.5 | 11.7 | 0.0 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +18.1 | 28.9 | 8.3 | 0.7 | +18.3 | 11.8 | 30.8 |
| GUN MASK | 1.0 | +24.1 | 0.0 | 18.1 | 0.2 | +4.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 13.3 | 1.0 | +0.0 | 0.0 | 14.0 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 86.4 | 2.7 | +0.0 | 0.0 | 91.5 |
| HELPER UNSEEN | 0.1 | +0.0 | 26.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.4 | +16.6 | 41.2 | 27.9 | 0.5 | +23.6 | 44.0 | 1.1 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 40.1 | 3.0 | +0.0 | 0.0 | 41.1 |
| HIS LEGAL MOVES | 4.1 | +0.0 | 0.0 | 85.9 | 4.1 | +0.0 | 0.0 | 31.7 |
| HIS MOVE AND SHOT | 1.5 | -21.9 | 0.0 | 52.7 | 2.5 | -55.8 | 0.0 | 35.8 |
| HIS RANDOM MOVE | 3.2 | +0.0 | 0.0 | 26.1 | 1.5 | +0.0 | 0.0 | 8.0 |
| HIS SHOT LIST | 17.7 | +511.1 | 0.0 | 270.3 | 23.1 | +1144.1 | 0.0 | 312.7 |
| HIS TURN DENIED | 1.2 | +28.2 | 95.2 | 19.9 | 2.4 | +159.3 | 185.5 | 23.5 |
| HOLDER AT DEPLOYMENT | 1.0 | +186.6 | 0.0 | 0.0 | 1.1 | +187.2 | 0.0 | 7.6 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.2 | -85.5 | 210.2 | 24.1 | 3.6 | -155.5 | 309.5 | 47.3 |
| HUNT DROPPED | 0.0 | +0.0 | 12.6 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +2.9 | 0.0 | 0.0 | 0.5 | +20.0 | 0.0 | 2.3 |
| HUNT KEPT | 0.1 | +0.2 | 12.6 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +13.8 | 12.6 | 0.0 | 0.1 | +4.7 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.2 | +74.0 | 25.3 | 0.0 | 0.1 | +25.8 | 3.3 | 1.5 |
| IDLE COST | 2.8 | -35.1 | 0.0 | 39.1 | 10.5 | -170.1 | 0.0 | 89.1 |
| JOINT CHARGE NOW | 0.6 | +44.4 | 76.5 | 8.7 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -3.3 | 13.3 | 0.0 | 0.2 | -6.4 | 27.2 | 4.8 |
| KEEP FALLS | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.0 | +0.6 | 2.6 | 0.0 |
| LANE BY FIGURES | 0.7 | +22.6 | 0.0 | 0.0 | 0.7 | +49.0 | 0.0 | 20.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 144.6 | 193.0 | 6.1 | +0.0 | 230.1 | 302.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +53.2 | 0.0 | 0.0 | 0.3 | +29.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.6 | 10.5 | 25.0 | 0.3 | -0.7 | 21.0 | 7.1 |
| LOST CHARGE | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -9.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.1 | +0.2 | 0.0 | 11.6 | 0.2 | +1.0 | 0.0 | 5.3 |
| MANOEUVRE | 1.0 | +5.3 | 0.0 | 41.9 | 1.4 | +20.2 | 0.0 | 21.8 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 0.0 | 0.2 | +0.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +10.6 | 0.0 | 0.0 | 0.3 | +8.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.5 | +60.3 | 0.0 | 21.0 | 1.3 | +75.7 | 0.0 | 7.5 |
| MARCH OVER CASTS | 0.9 | +28.4 | 0.0 | 13.1 | 0.7 | +50.2 | 0.0 | 7.2 |
| MAX FOR POSITIONING | 6.1 | +104.1 | 0.0 | 46.9 | 6.5 | +77.2 | 0.0 | 59.2 |
| MISSILES IN THE MOVE | 5.2 | +238.3 | 0.0 | 83.5 | 3.7 | +49.9 | 0.0 | 67.7 |
| MISSILES NEXT TURN | 6.2 | +143.0 | 0.0 | 98.3 | 4.1 | +35.3 | 0.0 | 67.9 |
| MODEL FACING | 0.3 | +96.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -37.5 | 0.0 | 0.0 | 0.2 | -15.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| MOVE TO CHARGE COMPUTED | 4.3 | +463.0 | 0.0 | 46.0 | 4.6 | +640.2 | 0.0 | 31.2 |
| MOVES UNITS SPELL | 0.1 | +4.1 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.8 | +297.0 | 0.0 | 84.3 | 4.9 | +243.5 | 0.0 | 83.7 |
| NEEDED THERE | - | - | - | - | 0.0 | +6.7 | 2.6 | 0.0 |
| NEXT CHARGE BY LIST | 6.2 | -205.9 | 16.2 | 77.5 | 6.2 | -220.1 | 9.0 | 28.8 |
| NEXT OBJECTIVE NEARER | 7.5 | -342.0 | 66.8 | 101.9 | 9.7 | -478.0 | 43.0 | 108.4 |
| NO DOUBLE ROUNDS | 2.3 | -110.5 | 189.3 | 53.7 | 3.3 | -163.7 | 329.3 | 58.6 |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.1 | 0.0 | 4.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.2 | 0.0 | 3.2 | 0.1 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -6.3 | 0.0 | 7.5 | 0.7 | -18.1 | 0.0 | 7.3 |
| ONE CHARGE A CHARGER | 3.1 | +0.0 | 0.0 | 85.5 | 3.5 | +0.0 | 0.0 | 54.8 |
| ONE FIGHT FORMULA | 5.9 | -110.2 | 0.0 | 81.3 | 6.3 | -137.2 | 0.0 | 75.6 |
| ONE OBJECTIVE FORMULA | 3.3 | -10.3 | 0.0 | 85.6 | 3.7 | +1.9 | 0.0 | 38.8 |
| ONE TARGET A SHOOTER | 16.2 | +340.4 | 0.0 | 254.1 | 21.7 | +723.2 | 0.0 | 271.7 |
| OPENS A LANE | 0.1 | +0.8 | 4.7 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +3.0 | 5.9 | 0.0 | 0.2 | +12.5 | 6.5 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.3 | 36.7 | 0.0 | 0.5 | +23.1 | 57.8 | 20.2 |
| PATHS CROSS | 3.5 | +102.1 | 0.0 | 51.6 | 4.9 | +189.0 | 0.0 | 32.4 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 0.0 |
| PLAN RESULT | 41.4 | +873.4 | 490.7 | 922.6 | 40.5 | +469.6 | 277.8 | 727.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +11.6 | 0.0 | 25.3 | 1.6 | +21.0 | 0.0 | 42.5 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.5 | 0.0 | 7.5 | 0.4 | -15.7 | 0.0 | 4.2 |
| REDIRECT COUNTER | 1.9 | +95.9 | 0.0 | 42.6 | 3.6 | +222.0 | 0.0 | 50.4 |
| REDIRECT WEIGHED | 0.1 | +2.7 | 7.0 | 0.0 | 0.2 | +0.4 | 13.7 | 1.5 |
| REFORMS TO MEET IT | 1.3 | -30.7 | 0.0 | 0.0 | 0.6 | -31.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +28.7 | 0.0 | 9.5 | 0.4 | +20.9 | 0.0 | 8.9 |
| RESTRAINS TO SHOOT | 0.1 | +1.0 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +36.5 | 232.5 | 38.6 | 2.6 | +7.2 | 206.9 | 37.4 |
| RISK BY HIS FIGURE | 13.6 | -219.7 | 0.0 | 366.6 | 14.5 | -220.7 | 0.0 | 278.7 |
| RUN DOWN | 1.8 | -15.6 | 138.0 | 29.9 | 3.2 | -30.3 | 263.0 | 46.8 |
| SAME CHARGE LATER | 0.3 | -6.0 | 1.8 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.5 | 0.0 | 1.2 | 0.1 | -8.5 | 0.0 | 0.0 |
| SEARCH SPOT | 5.2 | +227.0 | 0.0 | 57.7 | 6.7 | +259.0 | 0.0 | 87.9 |
| SECOND HUNTER | 0.1 | -0.1 | 12.6 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +18.1 | 0.0 | 0.0 | 0.4 | +0.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.2 | 0.0 | 11.6 | 0.7 | +3.9 | 0.0 | 12.6 |
| SET-UP ANY TARGET | 0.1 | +17.2 | 0.0 | 0.0 | 0.1 | +14.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +4.1 | 0.0 | 0.0 | 0.0 | +1.6 | 4.2 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +37.7 | 32.6 | 19.2 | 0.7 | +24.1 | 22.5 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -6.0 | 32.7 | 9.9 | 0.2 | -1.0 | 6.2 | 3.4 |
| SHOT RISK POINTS | 10.0 | +81.1 | 0.0 | 184.9 | 14.5 | -35.7 | 0.0 | 272.4 |
| SHOTS IN THE MOVE | 17.5 | +626.4 | 0.0 | 265.2 | 11.5 | +307.1 | 0.0 | 173.6 |
| SPELL SETS UP CHARGE | 0.2 | +54.5 | 0.0 | 0.0 | 0.1 | +19.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +12.9 | 78.6 | 71.5 | 2.1 | +47.0 | 21.9 | 33.9 |
| SPELLS IN THE FIGHT | 0.8 | -11.9 | 82.5 | 15.4 | 0.5 | +3.1 | 46.0 | 11.0 |
| STAND AND SHOOT | 0.4 | -5.0 | 39.1 | 0.0 | 0.9 | -11.2 | 50.1 | 7.2 |
| STANDS FOR A REASON | 0.0 | +0.0 | 1.1 | 0.0 | 0.6 | +0.0 | 0.0 | 33.3 |
| STANDS STILL | 17.9 | +0.0 | 624.8 | 282.8 | 9.2 | +0.0 | 135.5 | 84.6 |
| STAY WORTH | 18.8 | +8.0 | 389.1 | 225.2 | 11.0 | +99.4 | 64.2 | 151.0 |
| STOPS | 0.2 | +0.8 | 37.9 | 0.0 | 0.1 | +0.7 | 3.3 | 1.5 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.1 | +0.0 | 117.0 | 18.0 | 1.7 | +0.0 | 137.5 | 37.2 |
| SURE REACH TOGETHER | 0.3 | +4.1 | 0.0 | 4.8 | 0.5 | +4.0 | 0.0 | 5.5 |
| THE DEARER SUM KEEPS ITS PLAN | 4.3 | +0.0 | 0.0 | 36.9 | 4.7 | +0.0 | 0.0 | 31.4 |
| THE PROMISE ADDS | - | - | - | - | 0.4 | -26.2 | 19.8 | 9.9 |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 13.3 |
| TIED UP BY THE SUM | 0.6 | +62.7 | 59.3 | 2.8 | 0.6 | +55.5 | 41.9 | 0.0 |
| TIME ON OUR SIDE | 24.9 | +425.3 | 6.9 | 306.7 | 7.6 | +97.6 | 0.0 | 75.9 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 5.5 | 1.5 | +0.0 | 0.0 | 7.8 |
| WAR ENGINE CHARGES | 0.0 | +16.8 | 0.0 | 10.3 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 5.8 | 0.0 | 0.0 | +0.0 | 1.7 | 6.2 |
| WHO HITS BACK | 0.4 | +31.5 | 0.0 | 27.1 | 0.3 | +26.5 | 0.0 | 9.1 |
| WHOLE FIGHT | 0.4 | +18.4 | 48.3 | 0.0 | 0.2 | +3.6 | 25.4 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +8.1 | 4.8 | 8.7 | 0.2 | +20.1 | 29.0 | 1.5 |
| WIDER SPREAD | 2.2 | -2.4 | 186.5 | 47.3 | 3.1 | -2.7 | 266.8 | 31.5 |
| WOUNDS ON THE RANKS | 1.3 | +43.0 | 0.0 | 50.3 | 1.8 | +158.3 | 0.0 | 59.0 |

### Rule changes: ja-mine-f9a8036-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1225 | 1225 | 365 | 12.17 | +6493 | +17.8 |
| LEGAL CHARGES ONLY | 354 | 354 | 354 | 11.80 | +0 | +0.0 |
| SEARCH SPOT | 358 | 358 | 338 | 11.27 | +14580 | +43.1 |
| FIVE ACTION | 2766 | 2764 | 323 | 10.77 | +12229 | +37.9 |
| DEPLOY BY FIGURES | 476 | 476 | 293 | 9.77 | +4248 | +14.5 |
| ONE TARGET A SHOOTER | 1136 | 1136 | 273 | 9.10 | +3265 | +12.0 |
| PATHS CROSS | 252 | 252 | 252 | 8.40 | +8734 | +34.7 |
| MOVE TO CHARGE COMPUTED | 267 | 267 | 163 | 5.43 | +11894 | +73.0 |
| SHOT RISK POINTS | 736 | 736 | 130 | 4.33 | +3865 | +29.7 |
| TIME ON OUR SIDE | 976 | 869 | 128 | 4.27 | +414 | +3.2 |
| FOUR ROUNDS | 218 | 216 | 107 | 3.57 | +8043 | +75.2 |
| MAX FOR POSITIONING | 378 | 375 | 83 | 2.77 | +190 | +2.3 |
| COVER ONCE | 400 | 299 | 72 | 2.40 | +1349 | +18.7 |
| NEXT OBJECTIVE NEARER | 518 | 518 | 72 | 2.40 | +888 | +12.3 |
| SHOTS IN THE MOVE | 871 | 829 | 69 | 2.30 | +1848 | +26.8 |
| HARD STAY DROPPED | 60 | 60 | 60 | 2.00 | +0 | +0.0 |
| MARCH CHECK | 82 | 82 | 59 | 1.97 | +1183 | +20.0 |
| RISK BY HIS FIGURE | 842 | 842 | 59 | 1.97 | +6049 | +102.5 |
| CHARGE LOSSES | 403 | 403 | 55 | 1.83 | +4937 | +89.8 |
| ADVANCE LANE KEPT | 53 | 53 | 53 | 1.77 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 56 | 56 | 48 | 1.60 | +274 | +5.7 |
| MISSILES IN THE MOVE | 266 | 222 | 45 | 1.50 | +1481 | +32.9 |
| CANNON SIGHT KEPT | 44 | 44 | 44 | 1.47 | +0 | +0.0 |
| IDLE COST | 397 | 309 | 43 | 1.43 | +246 | +5.7 |
| LANE BY FIGURES | 42 | 42 | 42 | 1.40 | +2146 | +51.1 |
| RISK BY ARC | 142 | 140 | 42 | 1.40 | +1161 | +27.6 |
| ARTILLERY RE-ROLL WEIGHED | 41 | 41 | 41 | 1.37 | +0 | +0.0 |
| CANNON PLANNED TARGET | 194 | 194 | 40 | 1.33 | -311 | -7.8 |
| CHARGE NOT DECLARED | 40 | 40 | 40 | 1.33 | -6007 | -150.2 |
| FOLLOW UP WEIGHED | 38 | 38 | 38 | 1.27 | +7163 | +188.5 |
| MANOEUVRE | 72 | 72 | 35 | 1.17 | +864 | +24.7 |
| CHAFF PASSED | 34 | 34 | 34 | 1.13 | -82 | -2.4 |
| CHARGE NOW FIRST | 120 | 120 | 33 | 1.10 | -2049 | -62.1 |
| HOLDER AT DEPLOYMENT | 65 | 65 | 33 | 1.10 | +1476 | +44.7 |
| OFF BEST | 33 | 33 | 33 | 1.10 | -734 | -22.2 |
| LONE WIZARD KEPT IN | 31 | 31 | 31 | 1.03 | +2477 | +79.9 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 1.00 | +0 | +0.0 |
| RESERVE FALL BACK | 30 | 30 | 30 | 1.00 | +1487 | +49.6 |
| FALLS SHORT | 664 | 568 | 29 | 0.97 | +445 | +15.4 |
| NEXT CHARGE BY LIST | 371 | 371 | 29 | 0.97 | +663 | +22.9 |
| TIED UP BY THE SUM | 36 | 35 | 28 | 0.93 | +944 | +33.7 |
| HIS TURN DENIED | 106 | 105 | 27 | 0.90 | +1384 | +51.3 |
| ONE OBJECTIVE FORMULA | 211 | 186 | 26 | 0.87 | +1228 | +47.2 |
| RANDOM MOVE BY FIGURES | 62 | 62 | 26 | 0.87 | +978 | +37.6 |
| COMBAT PIVOT | 25 | 25 | 25 | 0.83 | +0 | +0.0 |
| REDIRECT COUNTER | 163 | 137 | 25 | 0.83 | +1744 | +69.8 |
| WOUNDS ON THE RANKS | 93 | 93 | 25 | 0.83 | +1120 | +44.8 |
| CASTER AWAY FROM SCREEN | 22 | 22 | 22 | 0.73 | +0 | +0.0 |
| SCOUT WAITS | 22 | 22 | 22 | 0.73 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.70 | +47 | +2.2 |
| STAY WORTH | 894 | 865 | 21 | 0.70 | +281 | +13.4 |
| MARCH BY THE SUM | 19 | 19 | 19 | 0.63 | +576 | +30.3 |
| WHO HITS BACK | 19 | 19 | 19 | 0.63 | +776 | +40.9 |
| FIRE IN ORDER | 18 | 18 | 18 | 0.60 | +0 | +0.0 |
| CHAFF IN THE MOVE | 38 | 37 | 17 | 0.57 | +109 | +6.4 |
| FIGHT TO THE END | 79 | 79 | 17 | 0.57 | +726 | +42.7 |
| CAST JOB | 21 | 21 | 16 | 0.53 | +130 | +8.1 |
| NEARER NOT NEEDED | 322 | 317 | 16 | 0.53 | +658 | +41.1 |
| FEATURE BUFFS | 67 | 67 | 15 | 0.50 | +269 | +18.0 |
| SURE REACH TOGETHER | 24 | 24 | 14 | 0.47 | +6 | +0.5 |
| AFTERMATH IN POINTS | 12 | 12 | 12 | 0.40 | +1366 | +113.8 |
| CASTING BLOCK | 12 | 12 | 12 | 0.40 | +197 | +16.4 |
| ONE FIGHT FORMULA | 364 | 194 | 12 | 0.40 | +49 | +4.1 |
| GUN MASK | 37 | 37 | 10 | 0.33 | +260 | +26.0 |
| HIS CHARGE DENIED | 27 | 27 | 9 | 0.30 | +498 | +55.3 |
| MODEL FACING | 9 | 9 | 9 | 0.30 | +2889 | +321.0 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.30 | +195 | +21.7 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.27 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 161 | 159 | 8 | 0.27 | +161 | +20.1 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.27 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.23 | +186 | +26.5 |
| STUCK PIVOT | 7 | 7 | 7 | 0.23 | +0 | +0.0 |
| SUPPORT NARROWED | 84 | 84 | 7 | 0.23 | -129 | -18.4 |
| WHOLE FIGHT GAIN | 10 | 10 | 7 | 0.23 | +394 | +56.3 |
| HONEST WORTH | 173 | 171 | 6 | 0.20 | +119 | +19.9 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.17 | +186 | +37.1 |
| HIS MOVE AND SHOT | 119 | 119 | 5 | 0.17 | +92 | +18.5 |
| HUNT IN PAIRS | 22 | 15 | 5 | 0.17 | +102 | +20.4 |
| JOINT CHARGE NOW | 19 | 19 | 5 | 0.17 | +346 | +69.1 |
| OPENS UP | 9 | 9 | 5 | 0.17 | +110 | +21.9 |
| FALLBACK BY WORTH | 14 | 14 | 4 | 0.13 | +78 | +19.5 |
| FOCUS FIRE | 4 | 4 | 4 | 0.13 | +66 | +16.4 |
| MISSILES NEXT TURN | 310 | 240 | 4 | 0.13 | +63 | +15.8 |
| NO DOUBLE ROUNDS | 168 | 166 | 4 | 0.13 | +170 | +42.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.13 | -81 | -20.2 |
| BEST PRIZE | 3 | 3 | 3 | 0.10 | -158 | -52.6 |
| BOMBING RUN | 3 | 3 | 3 | 0.10 | +123 | +40.9 |
| CHARGER SLAIN LOST | 30 | 30 | 3 | 0.10 | +45 | +15.1 |
| OVERRUNS AWAY | 26 | 25 | 3 | 0.10 | +102 | +33.9 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.10 | +77 | +25.8 |
| RUN DOWN | 150 | 148 | 3 | 0.10 | +2 | +0.6 |
| SPELLS IN THE FIGHT | 38 | 38 | 3 | 0.10 | +122 | +40.8 |
| WIDER SPREAD | 159 | 158 | 3 | 0.10 | +44 | +14.6 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.07 | +255 | +127.4 |
| CARRIES OUT COUNTER | 2 | 2 | 2 | 0.07 | -347 | -173.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.07 | -27 | -13.6 |
| DEFENSIVE ARMY | 4 | 4 | 2 | 0.07 | -32 | -16.1 |
| EDGE GIVE GROUND | 10 | 10 | 2 | 0.07 | +52 | +26.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.07 | +29 | +14.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.07 | +0 | +0.0 |
| REFUSING RETIRES | 7 | 7 | 2 | 0.07 | -0 | -0.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +17 | +16.9 |
| KILLS COUNT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 16 | 16 | 1 | 0.03 | +1 | +0.6 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| OPENS A LANE | 9 | 3 | 1 | 0.03 | +14 | +13.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.0 |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 1 | 0.03 | +20 | +20.0 |
| SET UP TOGETHER | 22 | 20 | 1 | 0.03 | +0 | +0.0 |
| SHOT OR CHARGE | 18 | 18 | 1 | 0.03 | +7 | +6.6 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +445 | +445.5 |
| WHOLE FIGHT | 17 | 17 | 1 | 0.03 | +6 | +5.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 17 | 7 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 12 | 11 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 39 | 39 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 15 | 15 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 296 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 12 | 12 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 61 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 152 | 152 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 159 | 159 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 246 | 246 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 142 | 142 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 9 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 47 | 47 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT TURNED | 15 | 15 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 197 | 197 | 0 | 0.00 | - | - |
| PLAN RESULT | 2458 | trace | - | - | - | - |
| REFORMS TO MEET IT | 58 | 58 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 93 | not checked | - | - | - | - |
| STAND AND SHOOT | 40 | 40 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 811 | 811 | 0 | 0.00 | - | - |
| STOPS | 8 | 8 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 269 | not checked | - | - | - | - |
| THE PROMISE ADDS | 11 | 11 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 24 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 87 | 87 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: ja-mine-f9a8036-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.57 | 0.70 | 166.2 |
| CHARGE NOW FIRST | rule | 0.47 | 0.60 | 64.0 |
| PATHS CROSS | rule | 0.43 | 0.60 | 21.4 |
| JOB FIRST | gate | 0.10 | 0.50 | 26.2 |
| CHAFF PASSED | rule | 0.27 | 0.17 | 6.2 |
| CANNON PLANNED TARGET | rule | 0.27 | 0.10 | 37.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.20 | 0.07 | 24.3 |
| SUPPORT NARROWED | rule | 0.07 | 0.17 | 18.4 |
| AFTERMATH BAND | gate | 0.03 | 0.10 | 3.8 |
| PIVOT GUARDS FLANK | rule | 0.07 | 0.07 | 20.2 |
| BEST PRIZE | rule | - | 0.10 | 52.6 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 173.4 |
| CATCH ODDS | rule | - | 0.07 | 13.6 |
| DEFENSIVE ARMY | rule | 0.07 | - | 16.1 |
| DEPLOY BY FIGURES | rule | - | 0.07 | 12.9 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.07 | 11.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.4 |
| REDIRECT WEIGHED | rule | - | 0.03 | 92.3 |
| RULE SWITCHED OFF | gate | 0.03 | - | 30.0 |
| WHO HITS BACK | rule | - | 0.03 | 3.9 |

### Plans: ja-mine-f9a8036-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.4 | 63% | 417 | 238 | 57% |
| Mine | join | 0.2 | 100% | 4 | 0 | 0% |
| Mine | move | 28.7 | 95% | 1724 | 0 | 0% |
| Mine | shoot | 9.7 | 58% | 342 | 635 | 185% |
| Mine | support | 0.4 | 83% | 4 | 0 | 0% |
| Opponent | charge | 3.5 | 64% | 614 | 355 | 58% |
| Opponent | join | 1.0 | 97% | 44 | 0 | 0% |
| Opponent | move | 32.4 | 94% | 1647 | 0 | 0% |
| Opponent | shoot | 3.1 | 50% | 142 | 115 | 81% |
| Opponent | support | 0.5 | 86% | 0 | 0 | 0% |

### Packages: hunt the guns, ja-mine-f9a8036-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 5 | 2 | 33% | 33% | 0% | 3.0 | 445 | 138 | 33% | 7 |
| Opponent | 0.1 | 2 | 0 | 50% | 50% | 50% | 2.0 | 387 | 71 | 50% | 46 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 1.2 | 6 | 2 | 25% | 25% | 25% | 3.0 | 487 | 106 | 25% | 40 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 162 | 131 | 100% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ja-mine-f9a8036-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 25% | 43% | 7% | 0% | 23% | 0% | 8% | 46% | 23% |
| Opponent | REDIRECT COUNTER | 3.6 | 17% | 44% | 11% | 0% | 19% | 0% | 19% | 56% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-mine-f9a8036-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 34 (2) | 34 | 0 | 46 | 50% | 3.0 | 34 (2) | - | - | 73 (1) | 0 (1) |
| Mine | Chaff | 22 | 39 (22) | 5 | 35 | 48 | 41% | 3.2 | 71 (9) | 18 (8) | 0 (5) | 46 (20) | 0 (2) |
| Mine | Character | 107 | 36 (107) | 33 | 2 | 28 | 12% | 2.8 | 39 (39) | 37 (41) | 38 (17) | 40 (57) | 35 (40) |
| Mine | Clean-up | 16 | 50 (16) | 11 | 38 | 51 | 31% | 3.4 | 63 (9) | 41 (6) | 0 (1) | 70 (11) | 25 (5) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 47 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 34 | 34 (34) | 16 | 17 | 41 | 24% | 2.7 | 53 (20) | 14 (9) | 22 (5) | 41 (21) | 25 (13) |
| Mine | Hammer | 52 | 38 (52) | 14 | 24 | 28 | 21% | 2.7 | 58 (20) | 30 (27) | 0 (5) | 39 (32) | 36 (20) |
| Mine | Holder | 17 | 69 (17) | 0 | 69 | 33 | 59% | 4.0 | 114 (5) | 58 (11) | 0 (1) | 112 (9) | 20 (8) |
| Mine | Shooter | 43 | 99 (43) | 40 | 59 | 35 | 5% | 2.0 | 98 (12) | 98 (26) | 107 (5) | 130 (27) | 53 (16) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 33 | 0% | 2.0 | 0 (3) | - | - | 0 (3) | - |
| Mine | War machine | 56 | 21 (56) | 21 | 0 | 48 | 2% | 1.7 | 18 (25) | 24 (24) | 21 (7) | 0 (8) | 24 (48) |
| Mine | Wizard | 16 | 49 (16) | 49 | 0 | 37 | 6% | 3.0 | 71 (9) | 0 (2) | 0 (1) | 104 (5) | 30 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 55 | 76 (55) | 17 | 59 | 45 | 44% | 2.7 | 90 (17) | 80 (23) | 55 (15) | 90 (38) | 46 (17) |
| Opponent | Character | 92 | 44 (92) | 44 | 0 | 21 | 28% | 2.7 | 26 (30) | 58 (44) | 49 (14) | 47 (56) | 43 (32) |
| Opponent | Clean-up | 15 | 26 (15) | 22 | 4 | 38 | 47% | 3.0 | 0 (4) | 41 (10) | 0 (1) | 19 (9) | 35 (6) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 47 | 44 (47) | 32 | 13 | 39 | 36% | 3.0 | 67 (15) | 41 (27) | 4 (5) | 40 (26) | 50 (21) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | - | 0 (2) | 0 (3) | 0 (2) |
| Opponent | Hammer | 51 | 37 (51) | 28 | 9 | 38 | 35% | 2.9 | 44 (14) | 38 (23) | 25 (14) | 31 (30) | 46 (21) |
| Opponent | Holder | 33 | 74 (33) | 9 | 65 | 19 | 42% | 2.9 | 58 (11) | 116 (17) | 0 (5) | 92 (18) | 54 (15) |
| Opponent | Shooter | 30 | 67 (30) | 16 | 51 | 26 | 13% | 2.1 | 50 (11) | 89 (14) | 35 (5) | 71 (17) | 62 (13) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 13 | 14 (13) | 14 | 0 | 47 | 8% | 1.3 | 12 (7) | 20 (4) | 0 (2) | 0 (2) | 16 (11) |
| Opponent | Wizard | 21 | 3 (21) | 3 | 0 | 17 | 19% | 2.4 | 0 (8) | 7 (10) | 0 (2) | 2 (12) | 7 (8) |

### Charged fights: ja-mine-f9a8036-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 282 | 155 | 2.2 | 1.2 | 71 | 20 | +50 | 0 of 11 | 9 of 11 | +92 | +41 |
| Mine | Chaos Dwarfs | 3 | 162 | 125 | 2.7 | 1.0 | 47 | 39 | +8 | 5 of 8 | 5 of 8 | - | +8 |
| Mine | Dwarfen Mountain Holds | 4 | 253 | 10 | 1.5 | 1.5 | 7 | 30 | -24 | 4 of 6 | 2 of 6 | +0 | -47 |
| Mine | Empire of Man | 5 | 289 | 39 | 1.4 | 1.0 | 28 | 27 | +1 | 0 of 7 | 5 of 7 | - | +1 |
| Mine | Grand Cathay | 4 | 280 | 366 | 3.0 | 1.0 | 122 | 0 | +122 | 5 of 12 | 9 of 12 | - | +122 |
| Mine | High Elf Realms | 4 | 170 | 418 | 3.2 | 1.1 | 129 | 31 | +98 | 5 of 13 | 12 of 13 | +144 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1010 | 5.0 | 1.4 | 202 | 0 | +202 | 2 of 5 | 5 of 5 | +398 | +153 |
| Mine | Lizardmen | 1 | 0 | 130 | 3.0 | 1.0 | 43 | 24 | +19 | 0 of 3 | 3 of 3 | - | +19 |
| Mine | Ogre Kingdoms | 1 | 265 | 132 | 5.0 | 1.2 | 26 | 147 | -121 | 1 of 5 | 3 of 5 | -297 | -77 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 30 | 214 | 193 | 2.5 | 1.1 | 78 | 29 | +50 | 23 of 74 | 54 of 74 | +54 | +49 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 17 | -17 | 1 of 3 | 2 of 3 | - | -17 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 189 | 2.0 | 1.0 | 94 | 0 | +94 | 1 of 2 | 2 of 2 | - | +94 |
| Opponent | Empire of Man | 1 | 160 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 291 | 408 | 5.0 | 1.0 | 82 | 76 | +6 | 5 of 5 | 3 of 5 | - | +6 |
| Opponent | High Elf Realms | 2 | 62 | 778 | 5.5 | 1.2 | 141 | 13 | +128 | 3 of 11 | 10 of 11 | +280 | +95 |
| Opponent | Lizardmen | 1 | 0 | 625 | 4.0 | 1.0 | 156 | 0 | +156 | 2 of 4 | 4 of 4 | - | +156 |
| Opponent | Ogre Kingdoms | 2 | 42 | 128 | 3.0 | 1.0 | 42 | 15 | +28 | 2 of 6 | 3 of 6 | - | +28 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 344 | 3.0 | 1.2 | 114 | 18 | +96 | 2 of 6 | 4 of 6 | +347 | +46 |
| Opponent | Skaven | 2 | 68 | 0 | 1.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | +0 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 156 | 960 | 4.8 | 1.2 | 202 | 14 | +188 | 10 of 19 | 15 of 19 | +315 | +155 |
| Opponent | Vampire Counts | 5 | 0 | 356 | 3.0 | 1.0 | 119 | 6 | +113 | 4 of 15 | 10 of 15 | - | +113 |
| Opponent | Warriors of Chaos | 4 | 0 | 309 | 2.2 | 1.0 | 137 | 125 | +12 | 6 of 9 | 6 of 9 | - | +12 |
| Opponent | Wood Elf Realms | 4 | 103 | 313 | 3.8 | 1.1 | 84 | 7 | +77 | 8 of 15 | 9 of 15 | +174 | +62 |
| **Opponent** | all armies | 30 | 61 | 394 | 3.2 | 1.1 | 122 | 24 | +98 | 45 of 97 | 69 of 97 | +251 | +80 |

### Effective charges: ja-mine-f9a8036-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 11 | 2 (net +156) | 0 | 2 (net -26) | 2 (net +62) | 0 | 4 (net +17) | 1 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 8 | 2 (net +0) | 0 | 1 (net -310) | 0 | 2 (net +128) | 3 (net +39) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 6 | 3 (net -61) | 0 | 0 | 1 (net +0) | 0 | 2 (net +20) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 7 | 1 (net -189) | 0 | 1 (net +175) | 2 (net +10) | 0 | 3 (net +0) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 12 | 2 (net +114) | 0 | 2 (net +60) | 3 (net +154) | 2 (net +60) | 2 (net +160) | 1 | 18% (2 of 11) |
| Mine | High Elf Realms | 13 | 1 (net -400) | 0 | 4 (net +143) | 1 (net +430) | 1 (net +45) | 6 (net +104) | 0 | 31% (4 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +211) | 2 (net +272) | 0 | 2 (net +127) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 3 | 0 | 0 | 1 (net -2) | 0 | 1 (net +60) | 0 | 1 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 5 | 1 (net -297) | 0 | 1 (net +66) | 0 | 0 | 1 (net -405) | 2 | 33% (1 of 3) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 3 | 2 (net -26) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +189) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 5 | 2 (net +14) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 11 | 0 | 0 | 0 | 7 (net +174) | 1 (net +45) | 2 (net +0) | 1 | 0% (0 of 10) |
| Opponent | Lizardmen | 4 | 0 | 0 | 1 (net +170) | 1 (net +77) | 0 | 2 (net +189) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 6 | 3 (net +85) | 0 | 2 (net +0) | 0 | 0 | 0 | 1 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 6 | 2 (net +118) | 0 | 0 | 1 (net +230) | 1 (net +110) | 0 | 2 | 0% (0 of 4) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 19 | 2 (net +388) | 1 (net -66) | 7 (net +158) | 5 (net +135) | 1 (net +90) | 3 (net +333) | 0 | 37% (7 of 19) |
| Opponent | Vampire Counts | 15 | 6 (net +9) | 0 | 5 (net +154) | 1 (net +0) | 1 (net +80) | 1 (net +540) | 1 | 36% (5 of 14) |
| Opponent | Warriors of Chaos | 9 | 1 (net +240) | 0 | 0 | 0 | 0 | 6 (net +166) | 2 | 0% (0 of 7) |
| Opponent | Wood Elf Realms | 15 | 6 (net +68) | 0 | 2 (net +0) | 2 (net +85) | 3 (net +54) | 0 | 2 | 15% (2 of 13) |

### Charged fights, damage counted: ja-mine-f9a8036-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 166 | 231 | -41 | 86 | 153 | -67 | -40.5 |
| Mine | Effective (55-75%) | 13 | 240 | 210 | +60 | 104 | 41 | +62 | +25.9 |
| Mine | 76-89% | 11 | 314 | 122 | +144 | 157 | 5 | +152 | +48.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 259 | 180 | +45 | 86 | 32 | +54 | +20.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 386 | 75 | +69 | 77 | 0 | +77 | +19.9 |
| Mine | No odds | 7 | 263 | 145 | +49 | 64 | 22 | +42 | +16.0 |
| Mine | All fights | 74 | 260 | 172 | +50 | 97 | 47 | +50 | +19.2 |
| Opponent | Long shot (under 50%) | 25 | 169 | 255 | +78 | 124 | 56 | +68 | +40.3 |
| Opponent | 50-54% | 1 | 431 | 405 | -66 | 231 | 305 | -74 | -17.2 |
| Opponent | Effective (55-75%) | 18 | 289 | 199 | +114 | 148 | 31 | +117 | +40.5 |
| Opponent | 76-89% | 19 | 308 | 198 | +125 | 135 | 41 | +95 | +30.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 314 | 202 | +182 | 205 | 17 | +188 | +59.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 405 | 86 | +61 | 65 | 0 | +65 | +16.0 |
| Opponent | No odds | 9 | 174 | 274 | -45 | 132 | 143 | -11 | -6.4 |
| Opponent | All fights | 97 | 266 | 213 | +98 | 142 | 48 | +94 | +35.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-mine-f9a8036-p1 | move | 268 | 60 (22%) | 43 (16%) | 39 (15%) | 169 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: ja-opp-f9a8036-p4

### Scorecard: ja-opp-f9a8036-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 1 | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0130 | 4 | 1 | Opponent | no | 8 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | - | 1 | 5 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 3 | 6 | 0 | 0 | 0 | 251 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 9 | - | 1 | 1 | 0 | 0 | 0 | 450 |
| L0315 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 1 | 0 | 0 | 790 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 310 |
| L0417 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 812 |
| L0520 | 4 | 1 | Opponent | no | 2 | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | - | 2 | 3 | 0 | 0 | 0 | 878 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 135 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 246 |
| L0624 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | - | 0 | 2 | 1 | 0 | 0 | 125 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 310 |
| L0819 | 3 | 1 | Opponent | yes | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 255 |
| L0835 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 140 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 382 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 13 | 2 | 6 | 0 | 0 | 0 | 0 | 291 |
| L1017 | 3 | 1 | Opponent | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 273 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 293 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | yes | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 336 |
| L1126 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1220 | 2 | 1 | Opponent | - | - | 1 | 0 | 4 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 247 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 6 | 2 | 2 | 0 | 0 | 0 | 247 |
| L1331 | 5 | 1 | Opponent | no | - | 2 | 0 | 1 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 1 | 8 | 3 | 1 | 0 | 0 | 130 |
| L1621 | 1 | 1 | Mine | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 4 | 1 | 0 | 0 | 860 |
| L1719 | 3 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | yes | 12 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 2 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 185 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 0 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 0 | 7 | 0 | 0 | 0 | 145 |
| **Average** | | | Mine | 23% | 3.8 | 3.1 | 1.6 | 1.6 | 0.2 | 0.0 | 0.0 | 268.7 |
| **Average** | | | Opponent | 36% | 3.4 | 2.2 | 3.0 | 2.8 | 0.3 | 0.0 | 0.0 | 84.2 |

### KPIs: ja-opp-f9a8036-p4

Rules off - Mine only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 29 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (41 of 141) | 0% (0 of 138) | 15% (41 of 279) |
| Winner chose to follow up after the loser gave ground |  | 86% (30 of 35); on the table 89% | 98% (39 of 40); on the table 100% | 92% (69 of 75); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (4 of 5); on the table 80% | 92% (11 of 12); on the table 92% | 88% (15 of 17); on the table 88% |
| Winner chose to pursue after the loser fled |  | 67% (14 of 21); on the table 67% | 71% (15 of 21); on the table 76% | 69% (29 of 42); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 79% (48 of 61); on the table 80% | 89% (65 of 73); on the table 92% | 84% (113 of 134); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 32% (81 of 252) | 30% (41 of 136) | 31% (122 of 388) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (81 of 192) | 41% (41 of 101) | 42% (122 of 293) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 68% (13 of 19) | 57% (44 of 77) | 59% (57 of 96) |
| Points that never fought | lower | 42% (23098 of 55494) | 44% (25319 of 57988) | 43% (48417 of 113482) |
|   infantry points that never fought | lower | 54% (6831 of 12663) | 72% (8306 of 11494) | 63% (15137 of 24157) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (148 of 229) | 58% (133 of 229) | 61% (281 of 458) |
| Bound items with a magic missile used (at least once a game) |  | 100% (21 of 21); 1.9 uses a game | 88% (7 of 8); 0.7 uses a game | 97% (28 of 29); 1.3 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.7 uses a game | 10% (2 of 20); 0.1 uses a game | 31% (11 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (10 of 18); 0.3 uses a game | 67% (8 of 12); 0.3 uses a game | 60% (18 of 30); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (27645 of 47310) | 51% (26228 of 51743) | 54% (53873 of 99053) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (34%) | 0.7 (20%) | 2.7 (29%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.8 (23%) | 2.1 (23%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (7%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.2 (21%) | 0.7 (21%) | 1.9 (21%) |
| REAR RANK: in a rear rank | 0.3 (6%) | 0.4 (12%) | 0.7 (8%) |
| GONE: slain | 0.8 (14%) | 0.5 (15%) | 1.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.1 | 2.4 | 4.2 | 0.4 | 2.0 |
| not cast | 2.5 | 2.8 | 3.6 | 9.2 | 1.9 | 21.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (52%) | 0.4 (11%) | 2.7 (29%) | 0.8 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (23%) | 0.4 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (5%) | 0.6 (17%) | 1.9 (21%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (8%) | 0.0 (0%) | 0.4 (12%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.4 (18%) | 0.4 (14%) | 0.6 (15%) | 1.3 (14%) | 0.1 (7%) | 2.2 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.6 (22%) | 0.0 (1%) | 0.1 (1%) | 0.1 (7%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (64%) | 0.1 (5%) | 1.6 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.5 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.9 a game | 1.3 a game |
| stood (cast and not dispelled) | 70% (31 of 44) | 60% (12 of 20) | 67% (43 of 64) |
| the unit moved after it | 74% (23 of 31) | 50% (6 of 12) | 67% (29 of 43) |
| it charged on its next turn | 0% (0 of 31) | 0% (0 of 12) | 0% (0 of 43) |
| the enemy charged it first | 23% (7 of 31) | 0% (0 of 12) | 16% (7 of 43) |
| it fought by the end of its next turn | 6% (2 of 31) | 8% (1 of 12) | 7% (3 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (4 of 31) | 8% (1 of 12) | 12% (5 of 43) |
| none of these (no charge, no fight, no charge escaped) | 65% (20 of 31) | 83% (10 of 12) | 70% (30 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (477 of 748) | 55% (252 of 457) | 60% (729 of 1205) |
|   cavalry | 57% (39 of 69) | 72% (60 of 83) | 65% (99 of 152) |
|   character | 67% (58 of 86) | 24% (28 of 118) | 42% (86 of 204) |
|   chariot | 61% (43 of 71) | 71% (20 of 28) | 64% (63 of 99) |
|   infantry | 51% (112 of 220) | 67% (114 of 170) | 58% (226 of 390) |
|   monster | 62% (24 of 39) | 36% (9 of 25) | 52% (33 of 64) |
|   war machine | 76% (201 of 263) | 64% (21 of 33) | 75% (222 of 296) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (25%) | 1.0 (14%) | 3.4 (21%) |
| CHARGED: it charged | 0.5 (5%) | 2.0 (28%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.1 (1%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.1 (11%) | 0.4 (5%) | 1.4 (9%) |
| NO TARGET IN RANGE | 1.9 (20%) | 1.8 (25%) | 3.7 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.3 (4%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (14%) | 1.1 (16%) | 2.4 (14%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 2.0 | 76% | 6.8 pts | 39 pts |
| character | 3.7 | 1.3 | 82% | 5.7 pts | 21 pts |
| chariot | 2.2 | 1.3 | 67% | 20.7 pts | 45 pts |
| infantry | 12.2 | 5.0 | 69% | 10.9 pts | 134 pts |
| monster | 1.2 | 0.3 | 86% | 3.1 pts | 4 pts |
| war machine | 7.7 | 6.4 | 65% | 22.2 pts | 170 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.8 | 5.6 | 4.2 |
| Charges that made contact a game | 2.1 | 3.8 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (16 units) | 1.25 declared, 0.75 contact (12 units) | 1.11 declared, 0.89 contact (28 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.43 declared, 0.29 contact (7 units) | 1.33 declared, 0.83 contact (12 units) | 1.00 declared, 0.63 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.22 contact (193 units) | 0.55 declared, 0.38 contact (238 units) | 0.45 declared, 0.31 contact (431 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (42 of 67) | 58% (7 of 12) | 75% (3 of 4) | 63% (52 of 83) |
| Character in a unit | 77% (20 of 26) | 71% (10 of 14) | 100% (1 of 1) | 76% (31 of 41) |
| Character on its own | 79% (23 of 29) | 42% (11 of 26) | 25% (14 of 56) | 43% (48 of 111) |
| Chariot | 77% (10 of 13) | 67% (8 of 12) | - | 72% (18 of 25) |
| Infantry | 55% (38 of 69) | 43% (10 of 23) | 60% (3 of 5) | 53% (51 of 97) |
| Monster | 77% (17 of 22) | 83% (10 of 12) | - | 79% (27 of 34) |
| Monstrous | 78% (7 of 9) | 69% (9 of 13) | - | 73% (16 of 22) |
| War Machines | 86% (37 of 43) | 50% (1 of 2) | - | 84% (38 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 60% (3 of 5); on the table 60% | 40% (41 of 102) | 46% | 64% (14 of 22) | 100% (6 of 6); 3.2 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (3 of 3); on the table 100% | 46% (11 of 24) | 31% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 70% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 60% (9 of 15); on the table 67% | 22% (4 of 18) | 48% | 73% (45 of 62) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 81% (17 of 21); on the table 81% | 29% (24 of 84) | 27% | 49% (18 of 37) | 100% (9 of 9); 6.8 uses a game | 100% (2 of 2); 1.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 92% (23 of 25); on the table 92% | 29% (10 of 35) | 47% | 54% (38 of 70) | 100% (7 of 7); 2.3 uses a game | 17% (5 of 30); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 33% (1 of 3); on the table 33% | - | 34% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (9 of 9); on the table 100% | 50% (3 of 6) | 29% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 58% | 86% (12 of 14) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 19% (8 of 42) | 33% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 5 | 25% (1 of 4); on the table 75% | 23% (8 of 35) | 59% | 75% (27 of 36) | 100% (2 of 2); 1.2 uses a game | 0.0 uses a game | 60% (3 of 5); 0.8 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 44% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 93% (13 of 14); on the table 93% | 29% (7 of 24) | 37% | 52% (12 of 23) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 100% (11 of 11); on the table 100% | 50% (3 of 6) | 32% | 56% (22 of 39) | 100% (1 of 1); 0.6 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| Wood Elf Realms | 4 | 88% (7 of 8); on the table 88% | 50% (3 of 6) | 42% | 70% (28 of 40) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-opp-f9a8036-p4, 29 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (26) | 38% (12) | 39% (38) |
| ...free all their last turn and able to turn (per game) | 0.66 | 0.31 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.03 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.48 | 0.21 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.00 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 0.10 | 0.28 |

### Quality by phase: ja-opp-f9a8036-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 48% (31 of 65) | 51% (72 of 140) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (144 of 343) | 52% (46 of 88) |
| Strategy | Support requests answered (helper made contact too) | 40% (2 of 5) | 57% (8 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 33% (4 of 12) |
| Strategy | Joined characters whose unit fought | 34% (12 of 35) | 33% (9 of 27) |
| Strategy | Lone characters that fought | 77% (55 of 71) | 81% (50 of 62) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.6 | 2.8 |
| Movement | Points that never moved of their own | 268.7 | 84.2 |
| Movement | Fights charged into per game | 1.9 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 45, net +66 | 23 of 86, net +102 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 45, net +0 | 16 of 86, net +235 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 45, net +67 | 7 of 86, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 45, net +108 | 20 of 86, net +191 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (133 of 295) | 41% (109 of 266) |
| Shooting | Points destroyed by shooting units | 83.5 | 54.9 |
| Shooting | War machine shots | 6.9 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (124 of 201) | 52% (11 of 21) |
| Shooting | Points destroyed by war machines | 44.6 | 0.0 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (17 of 61) | 16% (5 of 32) |
| Magic | Wounds caused by magic missiles | 4.9 | 1.6 |
| Magic | Wounds caused by other spells | 2.2 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 138.8 | 24.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.5 / 0.8 / 0.1 | 2.2 / 0.6 / 0.5 / 0.0 |
| Combat | Points destroyed in combat | 183.9 | 451.2 |
| Combat | Points run down | 52.1 | 131.6 |
| Combat | Net points per charged fight, damage counted | +52 | +137 |
| Combat | Net per 100 charger points, damage counted | +18.7 | +41.1 |
| Combat | First round won (charged fights) | 76% | 75% |
| Combat | Net points per charged fight | +62 | +143 |
| Combat | Net points per supported fight / lone fight | +386 / +37 | +337 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 17 of 55 | 50 of 101 |
| Game | Points lost | 788.3 | 561.3 |
| Game | VP from objectives | 626.6 | 593.1 |
| Game | Lone holders (player turns) | 3.8 | 3.4 |

- Mine won / drew / lost: 10 / 4 / 15 of 29 ended games (of 29); mean margin (Mine - Opponent) -197 VP
- The side that went first won 16 of 25 games with a winner
- Points traded per game (both sides' losses): 1350
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-opp-f9a8036-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 3.9 | 1.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +34.1 | 0.0 | 9.9 | 0.1 | +6.8 | 0.0 | 7.7 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.1 | +12.9 | 0.0 | 4.3 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 45.9 | - | - | - | - |
| BACKUP TARGETS | 0.2 | +0.4 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.0 | -0.8 | 0.0 | 0.0 | 0.4 | -24.8 | 19.6 | 0.0 |
| BLOWS WHERE AIMED | 0.0 | -5.9 | 0.0 | 0.0 | 0.4 | -61.7 | 20.5 | 7.7 |
| BOMBING RUN | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.9 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 78.7 | 0.0 | 0.1 | +0.0 | 16.2 | 0.0 |
| CANNON PLANNED TARGET | 6.3 | +212.1 | 311.3 | 107.1 | 0.6 | +32.1 | 54.2 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.4 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -6.5 | 8.1 | 7.7 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 4.7 | 0.0 | 0.1 | -20.7 | 4.9 | 0.0 |
| CAST JOB | 0.7 | +25.3 | 35.3 | 19.0 | 0.2 | +3.7 | 13.4 | 37.2 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +15.2 | 0.0 | 0.0 | 0.1 | +0.5 | 6.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 43.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +3.5 | 0.0 | 8.2 | 0.0 | +0.6 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +7.3 | 0.0 | 0.0 | 0.7 | +25.4 | 0.0 | 10.2 |
| CHAFF PASSED | 0.3 | -1.2 | 0.0 | 6.0 | 0.3 | -1.2 | 11.9 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.6 | -241.7 | 0.0 | 197.0 | 6.3 | -444.5 | 0.0 | 218.8 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 18.1 | 10.7 | 0.6 | +0.0 | 42.5 | 47.3 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 108.3 | 23.4 | 2.3 | +0.0 | 297.3 | 71.9 |
| CHARGER SLAIN LOST | 0.2 | -7.0 | 2.1 | 10.7 | 0.5 | -12.4 | 78.6 | 33.4 |
| CHEAP HELPER | 0.0 | +0.0 | 2.1 | 4.0 | - | - | - | - |
| CHEAPEST HOLDER | 0.3 | -31.5 | 9.3 | 0.0 | 0.1 | -4.9 | 14.0 | 5.2 |
| COMBAT PIVOT | 0.6 | +0.0 | 0.0 | 63.4 | 0.2 | +0.0 | 12.6 | 14.0 |
| CONVEYANCE SEARCH | 1.3 | +156.6 | 58.7 | 84.3 | 0.4 | +32.2 | 0.0 | 0.0 |
| COVER ONCE | 7.3 | -496.5 | 0.0 | 181.7 | 5.9 | -395.4 | 0.0 | 133.7 |
| DEPLOY BY FIGURES | 8.3 | +16.1 | 0.0 | 13.7 | 7.8 | +52.6 | 0.0 | 17.1 |
| EDGE GIVE GROUND | 0.0 | +0.2 | 5.5 | 0.0 | 0.1 | +1.4 | 17.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +4.7 | 0.0 | 12.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.6 | +3.5 | 117.3 | 66.7 | 3.8 | +5.7 | 367.6 | 69.1 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| FALLS SHORT | 2.8 | +43.0 | 0.0 | 22.0 | 18.3 | +236.1 | 0.0 | 257.1 |
| FEATURE BUFFS | 1.5 | +43.6 | 0.0 | 12.1 | 0.7 | +15.2 | 0.0 | 1.9 |
| FIGHT LIFT | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.6 | +4.9 | 27.1 | 29.4 | 1.9 | +134.4 | 227.6 | 41.2 |
| FIRE IN ORDER | 0.3 | +0.0 | 1.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 44.6 | +2431.7 | 718.8 | 799.5 | 45.6 | +2755.8 | 735.3 | 610.1 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 178.9 | 3.9 | +0.0 | 0.0 | 87.1 |
| FLEE LOSES BLESSING | 0.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| FOCUS FIRE | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.4 | +57.3 | 0.0 | 15.9 | 0.7 | +222.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.2 | +130.1 | 157.1 | 66.7 | 4.8 | +534.6 | 483.3 | 112.0 |
| FRIEND CHARGES FIRST | 0.0 | -2.3 | 0.0 | 0.0 | 0.2 | -7.5 | 10.7 | 0.0 |
| FRIEND SHOOTS FIRST | 0.2 | -6.8 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | +4.3 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.2 | 8.1 | 0.0 | 0.3 | -6.4 | 40.8 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.3 | 3.1 | 4.7 | - | - | - | - |
| GROUND FLIERS | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +22.1 | 24.5 | 93.1 | 0.6 | +6.0 | 20.4 | 6.7 |
| GUN MASK | 0.8 | +13.4 | 0.0 | 8.7 | 0.1 | +4.0 | 0.0 | 5.7 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 17.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.5 | +0.0 | 0.0 | 45.2 | 3.6 | +0.0 | 0.0 | 103.8 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +6.1 | 9.3 | 31.0 | 0.5 | +21.0 | 68.6 | 12.9 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 24.0 | 4.1 | +0.0 | 0.0 | 33.9 |
| HIS LEGAL MOVES | 3.9 | +0.0 | 0.0 | 77.6 | 3.8 | +0.0 | 0.0 | 91.4 |
| HIS MOVE AND SHOT | 1.7 | -32.4 | 0.0 | 50.2 | 1.8 | -48.1 | 0.0 | 64.0 |
| HIS RANDOM MOVE | 3.8 | +0.0 | 0.0 | 78.8 | 2.4 | +0.0 | 0.0 | 37.3 |
| HIS SHOT LIST | 15.8 | +469.9 | 0.0 | 291.9 | 26.6 | +1445.5 | 0.0 | 340.9 |
| HIS TURN DENIED | 0.9 | +33.8 | 93.4 | 8.1 | 2.8 | +162.7 | 258.3 | 80.0 |
| HOLDER AT DEPLOYMENT | 0.7 | +121.7 | 0.0 | 0.0 | 0.8 | +137.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.9 | -70.7 | 160.7 | 58.9 | 4.2 | -209.8 | 395.1 | 61.4 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.4 | +9.3 | 0.0 | 0.0 | 0.5 | +12.4 | 0.0 | 14.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +31.6 | 12.9 | 0.0 |
| HUNT THE GUNS | 0.0 | +8.0 | 0.0 | 0.0 | 0.1 | +38.8 | 18.6 | 0.0 |
| IDLE COST | 1.8 | -18.7 | 0.0 | 19.2 | 11.9 | -182.9 | 0.0 | 119.9 |
| JOINT CHARGE NOW | - | - | - | - | 1.1 | +55.0 | 108.5 | 11.6 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -14.7 | 22.2 | 4.3 |
| KEEP FALLS | 0.1 | +1.9 | 0.0 | 7.6 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +23.4 | 0.0 | 0.0 | 1.1 | +60.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.6 | +0.0 | 279.8 | 546.7 | 6.1 | +0.0 | 315.1 | 154.8 |
| LONE CHARACTER SAFE SPOT | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +25.3 | 0.0 | 0.0 | 0.2 | +23.2 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.1 | 3.7 | 0.0 | 0.1 | -2.1 | 3.9 | 7.7 |
| LURE BY WHAT IT DRAWS | 0.1 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +8.5 | 0.0 | 6.0 | 0.6 | +14.6 | 0.0 | 2.1 |
| MANOEUVRE | 1.1 | +5.4 | 0.0 | 26.2 | 1.3 | +13.6 | 0.0 | 7.3 |
| MARCH AT ESCAPER | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +12.1 | 0.0 | 0.0 | 0.2 | +14.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +41.3 | 0.0 | 43.4 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +52.8 | 0.0 | 52.3 | 0.4 | +26.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +72.7 | 0.0 | 124.8 | 5.5 | +76.9 | 0.0 | 101.2 |
| MISSILES IN THE MOVE | 4.3 | +186.9 | 0.0 | 171.3 | 2.2 | +36.4 | 0.0 | 73.1 |
| MISSILES NEXT TURN | 5.0 | +119.6 | 0.0 | 179.4 | 2.8 | +23.7 | 0.0 | 73.1 |
| MODEL FACING | 0.4 | +87.4 | 0.0 | 2.1 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.5 | +14.9 | 0.0 | 59.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -19.2 | 16.8 | 66.2 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 20.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.5 | +377.4 | 0.0 | 63.8 | 4.1 | +704.4 | 0.0 | 63.8 |
| MOVES UNITS SPELL | 0.1 | +4.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.4 | +196.0 | 0.0 | 55.1 | 5.0 | +269.6 | 0.0 | 17.8 |
| NEEDED THERE | 0.0 | +5.2 | 6.8 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.7 | -125.0 | 6.5 | 51.2 | 5.5 | -213.9 | 40.7 | 96.2 |
| NEXT OBJECTIVE NEARER | 6.8 | -293.6 | 31.9 | 81.4 | 8.8 | -431.3 | 34.7 | 51.7 |
| NO DOUBLE ROUNDS | 1.7 | -59.5 | 123.1 | 45.3 | 3.8 | -222.1 | 405.0 | 88.6 |
| NO RALLY LEFT | 0.0 | +1.1 | 0.0 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 5.3 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 41.4 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.5 | -5.5 | 0.0 | 10.7 | 0.5 | -28.6 | 0.0 | 6.8 |
| ONE CHARGE A CHARGER | 3.1 | +0.0 | 0.0 | 90.8 | 2.9 | +0.0 | 0.0 | 17.2 |
| ONE FIGHT FORMULA | 5.0 | -107.5 | 0.0 | 116.0 | 5.2 | -133.7 | 0.0 | 111.9 |
| ONE OBJECTIVE FORMULA | 3.4 | -34.3 | 0.0 | 68.6 | 2.6 | -30.9 | 0.0 | 7.7 |
| ONE TARGET A SHOOTER | 10.6 | +222.1 | 0.0 | 212.6 | 22.1 | +805.6 | 0.0 | 270.9 |
| OPENS A LANE | 0.1 | +0.3 | 4.3 | 0.0 | 0.2 | +4.4 | 68.2 | 0.0 |
| OPENS UP | 0.1 | +4.3 | 7.3 | 8.1 | 0.2 | +11.6 | 9.4 | 0.0 |
| OVERRUNS AWAY | 0.3 | +28.2 | 34.3 | 13.8 | 0.6 | +29.6 | 114.4 | 23.2 |
| PATHS CROSS | 3.0 | +122.6 | 0.0 | 50.6 | 5.2 | +204.3 | 0.0 | 29.8 |
| PERIAPT WORTH | 0.0 | +4.2 | 0.0 | 18.6 | 0.1 | +10.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.6 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| PLAN RESULT | 39.9 | +813.5 | 432.5 | 1180.4 | 40.8 | +571.6 | 393.2 | 815.4 |
| RANDOM MOVE BY FIGURES | 0.7 | +17.6 | 0.0 | 13.1 | 2.7 | +40.9 | 0.0 | 45.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +15.5 | 0.0 | 1.2 | 0.6 | -15.4 | 0.0 | 13.0 |
| REDIRECT COUNTER | 1.7 | +115.9 | 0.0 | 23.0 | 3.9 | +166.2 | 0.0 | 67.9 |
| REDIRECT WEIGHED | 0.3 | -0.8 | 0.0 | 10.7 | 0.4 | +3.0 | 21.2 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -41.4 | 0.0 | 14.5 | 0.7 | -19.2 | 0.0 | 42.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 12.6 | 0.3 | +0.0 | 0.0 | 11.8 |
| RESERVE FALL BACK | 0.2 | +7.9 | 0.0 | 5.5 | 0.4 | +16.1 | 0.0 | 3.7 |
| RESTRAINS TO SHOOT | 0.0 | +1.7 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 5.7 |
| RISK BY ARC | 1.6 | +34.9 | 110.3 | 46.9 | 3.1 | -23.3 | 357.7 | 93.0 |
| RISK BY HIS FIGURE | 12.3 | -192.1 | 0.0 | 371.3 | 14.0 | -225.7 | 0.0 | 246.1 |
| RUN DOWN | 1.6 | -11.4 | 100.0 | 46.4 | 3.7 | -37.3 | 349.9 | 70.6 |
| SAFER THAN THE JOB | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.1 | -0.4 | 0.0 | 4.0 | 0.2 | -4.5 | 2.7 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.8 | 0.0 | 0.0 | 0.3 | -26.7 | 0.0 | 2.4 |
| SEARCH SPOT | 5.7 | +257.2 | 0.0 | 126.1 | 5.9 | +267.7 | 0.0 | 46.2 |
| SELF MOVE SPELL | 0.2 | +26.5 | 0.0 | 0.0 | 0.6 | +48.5 | 0.0 | 11.2 |
| SET UP TOGETHER | 0.5 | +10.2 | 0.0 | 8.7 | 0.7 | +16.0 | 0.0 | 23.6 |
| SET-UP ANY TARGET | 0.2 | +27.1 | 30.3 | 30.3 | 0.1 | +11.6 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +2.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +104.2 | 80.9 | 56.7 | 0.6 | +18.2 | 45.3 | 4.2 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -6.3 | 25.4 | 13.9 | 0.3 | -4.4 | 48.8 | 6.8 |
| SHOT RISK POINTS | 7.3 | -8.9 | 0.0 | 180.9 | 15.3 | +89.5 | 0.0 | 312.4 |
| SHOTS IN THE MOVE | 16.3 | +821.6 | 0.0 | 349.7 | 8.0 | +261.2 | 0.0 | 102.4 |
| SPELL SETS UP CHARGE | 0.3 | +34.4 | 30.3 | 30.3 | 0.1 | +11.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +14.5 | 109.5 | 110.2 | 2.8 | +55.2 | 55.9 | 55.9 |
| SPELLS IN THE FIGHT | 0.5 | -0.4 | 67.1 | 3.1 | 1.2 | -24.1 | 102.1 | 66.9 |
| STAND AND SHOOT | 0.6 | -6.5 | 35.3 | 8.1 | 0.9 | -13.8 | 105.6 | 22.1 |
| STANDS FOR A REASON | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 18.8 | 22.3 |
| STANDS STILL | 19.1 | +0.0 | 561.8 | 275.4 | 9.0 | +0.0 | 252.0 | 137.1 |
| STAY WORTH | 20.0 | +94.3 | 400.1 | 279.2 | 7.7 | +61.0 | 142.3 | 100.9 |
| STOPS | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +8.7 | 18.6 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.9 | +0.0 | 58.3 | 35.2 | 1.4 | +0.0 | 164.4 | 51.0 |
| SURE REACH TOGETHER | 0.3 | +8.2 | 0.0 | 9.7 | 0.5 | +5.1 | 0.0 | 10.8 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 64.2 | 4.8 | +0.0 | 0.0 | 29.8 |
| THE PROMISE ADDS | 0.2 | -11.5 | 4.7 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 12.9 |
| TIED UP BY THE SUM | 0.4 | +36.5 | 31.6 | 18.8 | 0.8 | +95.7 | 73.9 | 0.0 |
| TIME ON OUR SIDE | 28.0 | +440.5 | 7.8 | 359.5 | 5.6 | +74.6 | 0.0 | 37.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.2 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 19.4 | 0.9 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +5.1 | 3.1 | 15.3 | 0.0 | +2.1 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.1 | +0.0 | 8.3 | 15.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.2 | +37.8 | 0.0 | 38.2 | 0.4 | +27.4 | 0.0 | 6.9 |
| WHOLE FIGHT | 0.1 | +0.0 | 8.9 | 0.0 | 0.4 | +11.1 | 56.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +8.3 | 4.7 | 0.0 | 0.3 | +19.1 | 19.9 | 6.4 |
| WIDER SPREAD | 1.2 | -3.4 | 101.9 | 46.3 | 3.4 | -9.5 | 354.1 | 70.7 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 6.9 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +22.3 | 0.0 | 16.9 | 0.7 | +57.6 | 0.0 | 4.7 |

### Rule changes: ja-opp-f9a8036-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 370 | 370 | 370 | 12.76 | +0 | +0.0 |
| HIS SHOT LIST | 1231 | 1231 | 360 | 12.41 | +8135 | +22.6 |
| SEARCH SPOT | 336 | 336 | 319 | 11.00 | +15221 | +47.7 |
| DEPLOY BY FIGURES | 466 | 466 | 311 | 10.72 | +4932 | +15.9 |
| FIVE ACTION | 2616 | 2610 | 267 | 9.21 | +10330 | +38.7 |
| PATHS CROSS | 239 | 239 | 239 | 8.24 | +9481 | +39.7 |
| ONE TARGET A SHOOTER | 947 | 947 | 237 | 8.17 | +2465 | +10.4 |
| TIME ON OUR SIDE | 973 | 877 | 161 | 5.55 | +599 | +3.7 |
| MOVE TO CHARGE COMPUTED | 220 | 220 | 127 | 4.38 | +11666 | +91.9 |
| SHOT RISK POINTS | 655 | 655 | 112 | 3.86 | +4363 | +39.0 |
| FOUR ROUNDS | 204 | 198 | 97 | 3.34 | +6406 | +66.0 |
| COVER ONCE | 385 | 303 | 74 | 2.55 | +1085 | +14.7 |
| HARD STAY DROPPED | 74 | 74 | 74 | 2.55 | +0 | +0.0 |
| MAX FOR POSITIONING | 306 | 302 | 70 | 2.41 | +142 | +2.0 |
| ADVANCE LANE KEPT | 64 | 64 | 64 | 2.21 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 96 | 96 | 57 | 1.97 | +1696 | +29.8 |
| SHOTS IN THE MOVE | 706 | 680 | 57 | 1.97 | +2357 | +41.4 |
| IDLE COST | 398 | 333 | 56 | 1.93 | +537 | +9.6 |
| LANE BY FIGURES | 51 | 51 | 51 | 1.76 | +2428 | +47.6 |
| NEXT OBJECTIVE NEARER | 453 | 453 | 46 | 1.59 | +515 | +11.2 |
| RISK BY HIS FIGURE | 763 | 763 | 44 | 1.52 | +4312 | +98.0 |
| CHARGE LOSSES | 318 | 318 | 40 | 1.38 | +4352 | +108.8 |
| ARTILLERY RE-ROLL WEIGHED | 39 | 39 | 39 | 1.34 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 52 | 52 | 38 | 1.31 | +893 | +23.5 |
| RISK BY ARC | 134 | 130 | 37 | 1.28 | +817 | +22.1 |
| MISSILES IN THE MOVE | 189 | 160 | 36 | 1.24 | +1130 | +31.4 |
| REDIRECT COUNTER | 163 | 132 | 36 | 1.24 | +2704 | +75.1 |
| MANOEUVRE | 69 | 69 | 33 | 1.14 | +728 | +22.0 |
| NEXT CHARGE BY LIST | 294 | 294 | 32 | 1.10 | +297 | +9.3 |
| FOLLOW UP WEIGHED | 31 | 31 | 31 | 1.07 | +8099 | +261.3 |
| CANNON SIGHT KEPT | 30 | 30 | 30 | 1.03 | +0 | +0.0 |
| TIED UP BY THE SUM | 35 | 34 | 29 | 1.00 | +1235 | +42.6 |
| HIS TURN DENIED | 108 | 106 | 28 | 0.97 | +993 | +35.5 |
| OFF BEST | 28 | 28 | 28 | 0.97 | -989 | -35.3 |
| CHARGE NOW FIRST | 99 | 99 | 27 | 0.93 | -1605 | -59.4 |
| STAY WORTH | 805 | 772 | 26 | 0.90 | +301 | +11.6 |
| FALLS SHORT | 613 | 531 | 25 | 0.86 | +57 | +2.3 |
| CHARGE NOT DECLARED | 24 | 24 | 24 | 0.83 | -2859 | -119.1 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.79 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 23 | 23 | 23 | 0.79 | +1407 | +61.2 |
| HOLDS AMBUSHERS | 22 | 22 | 22 | 0.76 | +0 | +0.0 |
| CANNON PLANNED TARGET | 202 | 202 | 21 | 0.72 | -335 | -16.0 |
| CHAFF IN THE MOVE | 30 | 26 | 20 | 0.69 | +72 | +3.6 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.69 | +612 | +30.6 |
| WHO HITS BACK | 20 | 20 | 20 | 0.69 | +921 | +46.1 |
| CAST JOB | 27 | 27 | 19 | 0.66 | +338 | +17.8 |
| MARCH CHECK | 31 | 31 | 19 | 0.66 | +244 | +12.8 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.62 | +0 | +0.0 |
| CHAFF PASSED | 18 | 18 | 18 | 0.62 | -69 | -3.8 |
| ONE OBJECTIVE FORMULA | 173 | 153 | 18 | 0.62 | +423 | +23.5 |
| RESERVE FALL BACK | 18 | 18 | 18 | 0.62 | +696 | +38.6 |
| MARCH BY THE SUM | 16 | 16 | 16 | 0.55 | +763 | +47.7 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.55 | +32 | +2.0 |
| SCOUT WAITS | 15 | 15 | 15 | 0.52 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 44 | 44 | 14 | 0.48 | +482 | +34.4 |
| SURE REACH TOGETHER | 24 | 24 | 14 | 0.48 | +127 | +9.1 |
| WOUNDS ON THE RANKS | 42 | 42 | 14 | 0.48 | +558 | +39.8 |
| BEST PRIZE | 12 | 12 | 12 | 0.41 | -820 | -68.3 |
| FIGHT TO THE END | 72 | 69 | 12 | 0.41 | +1187 | +98.9 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.38 | +1186 | +107.9 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.38 | +0 | +0.0 |
| MODEL FACING | 11 | 11 | 11 | 0.38 | +2533 | +230.3 |
| NEARER NOT NEEDED | 271 | 263 | 10 | 0.34 | +432 | +43.2 |
| OVERRUNS AWAY | 26 | 26 | 10 | 0.34 | +330 | +33.0 |
| SET UP TOGETHER | 36 | 25 | 10 | 0.34 | +224 | +22.4 |
| STUCK PIVOT | 10 | 10 | 10 | 0.34 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.31 | +0 | +0.0 |
| ONE FIGHT FORMULA | 296 | 159 | 8 | 0.28 | +24 | +3.0 |
| REFUSING RETIRES | 13 | 13 | 8 | 0.28 | -2 | -0.2 |
| SUPPORT NARROWED | 66 | 66 | 8 | 0.28 | -115 | -14.3 |
| FEATURE BUFFS | 64 | 64 | 7 | 0.24 | +122 | +17.4 |
| HIS CHARGE DENIED | 22 | 20 | 7 | 0.24 | +110 | +15.7 |
| JOINT CHARGE NOW | 32 | 32 | 7 | 0.24 | +666 | +95.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.24 | +138 | +19.7 |
| WHOLE FIGHT GAIN | 12 | 12 | 7 | 0.24 | +341 | +48.7 |
| CASTING BLOCK | 7 | 7 | 6 | 0.21 | +76 | +12.6 |
| GUN MASK | 28 | 28 | 6 | 0.21 | +201 | +33.5 |
| OPENS UP | 9 | 9 | 6 | 0.21 | +178 | +29.6 |
| HONEST WORTH | 178 | 173 | 5 | 0.17 | +62 | +12.3 |
| MISSILES NEXT TURN | 226 | 178 | 5 | 0.17 | +89 | +17.9 |
| NO DOUBLE ROUNDS | 159 | 155 | 5 | 0.17 | +159 | +31.8 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.17 | -112 | -22.3 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.17 | +245 | +48.9 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 0.14 | +374 | +93.5 |
| HUNT IN PAIRS | 26 | 12 | 4 | 0.14 | +55 | +13.8 |
| KEEP FALLS | 4 | 4 | 4 | 0.14 | +143 | +35.8 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.14 | +437 | +109.3 |
| SPELLS IN THE FIGHT | 49 | 46 | 4 | 0.14 | +53 | +13.2 |
| WIDER SPREAD | 135 | 130 | 4 | 0.14 | +20 | +4.9 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.10 | +0 | +0.1 |
| CARRIES OUT COUNTER | 4 | 4 | 3 | 0.10 | -205 | -68.5 |
| CARRIES OUT SET-UP | 5 | 5 | 3 | 0.10 | -601 | -200.3 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.10 | +0 | +0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.10 | +138 | +45.9 |
| HIS MOVE AND SHOT | 101 | 101 | 3 | 0.10 | +5 | +1.8 |
| OPENS A LANE | 8 | 6 | 3 | 0.10 | +20 | +6.6 |
| WHOLE FIGHT | 15 | 14 | 3 | 0.10 | +90 | +30.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.07 | +66 | +33.1 |
| FALL BACK GOOD ORDER | 154 | 151 | 2 | 0.07 | +1 | +0.4 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.07 | +120 | +60.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.07 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.07 | +37 | +18.3 |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 2 | 0.07 | +0 | +0.0 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.07 | +71 | +35.4 |
| BACKUP TARGETS | 16 | 10 | 1 | 0.03 | +0 | +0.4 |
| EDGE GIVE GROUND | 5 | 5 | 1 | 0.03 | +0 | +0.5 |
| FLEE LOSES BLESSING | 1 | 1 | 1 | 0.03 | +51 | +51.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +27 | +27.2 |
| FRIEND SHOOTS FIRST | 8 | 8 | 1 | 0.03 | +22 | +22.2 |
| GIVES UP | 15 | 13 | 1 | 0.03 | +3 | +3.3 |
| LONG SHOT | 7 | 6 | 1 | 0.03 | +0 | +0.3 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| RUN DOWN | 154 | 149 | 1 | 0.03 | +4 | +4.3 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +22 | +22.5 |
| STOPS | 5 | 5 | 1 | 0.03 | +76 | +76.3 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 13 | 12 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 49 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARACTER GUNS | 16 | 16 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 21 | 21 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 14 | 14 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 258 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 58 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 146 | 146 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 178 | 178 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 223 | 223 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 180 | 180 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 25 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 15 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT TURNED | 8 | 8 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 175 | 175 | 0 | 0.00 | - | - |
| PLAN RESULT | 2340 | trace | - | - | - | - |
| REFORMS TO MEET IT | 45 | 45 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 13 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 16 | 16 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 118 | not checked | - | - | - | - |
| STAND AND SHOOT | 43 | 43 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 813 | 813 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 242 | not checked | - | - | - | - |
| THE PROMISE ADDS | 6 | 6 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 20 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 8 | not checked | - | - | - | - |
| WAITS AGAIN | 71 | 71 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ja-opp-f9a8036-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.41 | 0.72 | 26.3 |
| CHARGE NOW FIRST | rule | 0.38 | 0.55 | 59.4 |
| CHARGE NOT DECLARED | rule | 0.24 | 0.59 | 119.1 |
| JOB FIRST | gate | 0.14 | 0.31 | 41.3 |
| BEST PRIZE | rule | 0.03 | 0.38 | 68.3 |
| CHAFF PASSED | rule | 0.10 | 0.24 | 6.9 |
| SUPPORT NARROWED | rule | 0.14 | 0.14 | 14.3 |
| CANNON PLANNED TARGET | rule | 0.21 | - | 57.0 |
| AFTERMATH BAND | gate | 0.07 | 0.10 | 3.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.03 | 85.6 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.03 | 22.3 |
| DEPLOY BY FIGURES | rule | 0.07 | 0.07 | 5.4 |
| REDIRECT WEIGHED | rule | 0.03 | 0.10 | 44.5 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.07 | 68.5 |
| CARRIES OUT SET-UP | rule | - | 0.10 | 200.3 |
| FIGHT ORDER BAND | gate | 0.10 | - | 2.0 |
| FALLBACK | gate | 0.03 | - | 1.1 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.7 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.5 |
| RULE SWITCHED OFF | gate | - | 0.03 | 1.1 |
| WHO HITS BACK | rule | - | 0.03 | 3.6 |

### Plans: ja-opp-f9a8036-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 58% | 175 | 139 | 79% |
| Mine | join | 0.3 | 100% | 5 | 0 | 0% |
| Mine | move | 27.4 | 93% | 1524 | 0 | 0% |
| Mine | shoot | 10.0 | 59% | 579 | 675 | 116% |
| Mine | support | 0.4 | 91% | 26 | 0 | 0% |
| Opponent | charge | 3.8 | 61% | 773 | 392 | 51% |
| Opponent | join | 0.3 | 100% | 16 | 0 | 0% |
| Opponent | move | 33.6 | 94% | 1674 | 0 | 0% |
| Opponent | shoot | 2.4 | 59% | 145 | 180 | 124% |
| Opponent | support | 0.8 | 77% | 1 | 0 | 0% |

### Packages: hunt the guns, ja-opp-f9a8036-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 231 | 0 | 0% | 15 |
| Opponent | 0.1 | 4 | 0 | 100% | 100% | 0% | 2.0 | 281 | 229 | 75% | 56 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 231 | 0 | 0% | 91 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 193 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.0 | 4 | 0 | 100% | 100% | 0% | 2.0 | 281 | 229 | 75% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 31 |

### Battle groups: ja-opp-f9a8036-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 30% | 60% | 13% | 0% | 15% | 0% | 0% | 85% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 23% | 69% | 23% | 33% | 40% | 0% | 10% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-opp-f9a8036-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 38 | 0% | 3.0 | 0 (4) | - | - | - | 0 (4) |
| Mine | Chaff | 18 | 39 (18) | 7 | 32 | 59 | 44% | 2.8 | 87 (7) | 11 (11) | - | 45 (16) | 0 (2) |
| Mine | Character | 93 | 41 (93) | 40 | 1 | 39 | 20% | 2.6 | 45 (33) | 35 (35) | 64 (10) | 52 (51) | 29 (27) |
| Mine | Clean-up | 21 | 78 (21) | 11 | 67 | 44 | 52% | 3.2 | 63 (9) | 121 (9) | 0 (3) | 104 (12) | 46 (9) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 0% | 3.5 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fast Hammer | 32 | 30 (32) | 12 | 19 | 46 | 25% | 2.4 | 29 (14) | 35 (13) | 18 (5) | 44 (15) | 19 (17) |
| Mine | Hammer | 54 | 29 (54) | 13 | 16 | 53 | 31% | 2.4 | 20 (22) | 36 (28) | 34 (4) | 34 (35) | 18 (19) |
| Mine | Holder | 19 | 44 (19) | 0 | 44 | 54 | 58% | 2.9 | 48 (7) | 59 (9) | 0 (3) | 77 (10) | 10 (9) |
| Mine | Shooter | 32 | 121 (32) | 56 | 65 | 27 | 3% | 2.1 | 82 (10) | 152 (15) | 91 (7) | 123 (23) | 112 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 24 (56) | 24 | 0 | 48 | 7% | 1.3 | 38 (31) | 8 (19) | 0 (6) | 102 (10) | 8 (46) |
| Mine | Wizard | 13 | 9 (13) | 9 | 0 | 52 | 8% | 3.0 | 0 (4) | 25 (6) | - | 26 (6) | 0 (4) |
| Opponent | Chaff | 53 | 49 (53) | 5 | 44 | 45 | 60% | 2.7 | 32 (24) | 71 (14) | 53 (15) | 54 (38) | 41 (15) |
| Opponent | Character | 75 | 67 (75) | 67 | 0 | 27 | 20% | 2.4 | 56 (26) | 81 (31) | 69 (10) | 57 (36) | 79 (31) |
| Opponent | Clean-up | 15 | 39 (15) | 27 | 13 | 7 | 53% | 3.6 | 32 (7) | 27 (5) | 72 (3) | 53 (11) | 22 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 41 | 37 (41) | 16 | 21 | 31 | 46% | 3.3 | 25 (9) | 49 (22) | 21 (10) | 43 (22) | 30 (19) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 41 | 50% | 1.6 | 0 (5) | 0 (4) | 0 (1) | 0 (2) | 0 (8) |
| Opponent | Hammer | 54 | 24 (54) | 17 | 8 | 33 | 41% | 3.0 | 2 (18) | 29 (24) | 42 (12) | 25 (34) | 23 (20) |
| Opponent | Holder | 23 | 63 (23) | 0 | 63 | 15 | 61% | 4.7 | 4 (7) | 87 (15) | 62 (1) | 116 (11) | 21 (12) |
| Opponent | Shooter | 38 | 61 (38) | 26 | 35 | 43 | 11% | 1.8 | 43 (13) | 90 (16) | 32 (9) | 55 (21) | 69 (17) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 6 | 67 (6) | 67 | 0 | 19 | 0% | 2.2 | 16 (3) | 141 (3) | - | 16 (3) | 141 (3) |
| Opponent | Wizard | 14 | 3 (14) | 3 | 0 | 22 | 14% | 3.0 | 0 (4) | 2 (4) | 0 (4) | 0 (6) | 2 (6) |

### Charged fights: ja-opp-f9a8036-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 250 | 24 | 0.5 | 1.0 | 49 | 0 | +49 | 0 of 2 | 2 of 2 | - | +49 |
| Mine | Chaos Dwarfs | 4 | 258 | 164 | 1.8 | 1.0 | 94 | 13 | +81 | 4 of 7 | 6 of 7 | - | +81 |
| Mine | Dwarfen Mountain Holds | 3 | 189 | 20 | 1.3 | 1.0 | 15 | 0 | +15 | 1 of 4 | 2 of 4 | - | +15 |
| Mine | Empire of Man | 5 | 246 | 17 | 0.6 | 1.0 | 28 | 0 | +28 | 0 of 3 | 3 of 3 | - | +28 |
| Mine | Grand Cathay | 4 | 450 | 374 | 4.5 | 1.2 | 83 | 9 | +74 | 3 of 18 | 16 of 18 | +319 | +43 |
| Mine | High Elf Realms | 4 | 430 | 28 | 2.0 | 1.0 | 14 | 8 | +7 | 3 of 8 | 6 of 8 | - | +7 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 467 | 5.0 | 1.0 | 93 | 0 | +93 | 2 of 5 | 4 of 5 | - | +93 |
| Mine | Lizardmen | 1 | 0 | 1017 | 3.0 | 1.7 | 339 | 0 | +339 | 2 of 3 | 3 of 3 | +454 | +110 |
| Mine | Ogre Kingdoms | 2 | 28 | 0 | 2.5 | 1.0 | 0 | 50 | -50 | 2 of 5 | 0 of 5 | - | -50 |
| Mine | Skaven | 1 | 265 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 29 | 267 | 138 | 1.9 | 1.1 | 73 | 10 | +62 | 17 of 55 | 42 of 55 | +386 | +37 |
| Opponent | Empire of Man | 1 | 60 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 140 | 547 | 3.6 | 1.1 | 152 | 8 | +144 | 9 of 18 | 14 of 18 | +94 | +150 |
| Opponent | Lizardmen | 2 | 290 | 570 | 3.5 | 1.0 | 163 | 0 | +163 | 3 of 7 | 6 of 7 | - | +163 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 1023 | 5.3 | 1.2 | 192 | 32 | +160 | 5 of 16 | 12 of 16 | +267 | +135 |
| Opponent | Skaven | 4 | 114 | 0 | 0.8 | 1.0 | 0 | 254 | -254 | 3 of 3 | 2 of 3 | - | -254 |
| Opponent | Tomb Kings of Khemri | 1 | 115 | 325 | 2.0 | 1.0 | 162 | 0 | +162 | 1 of 2 | 1 of 2 | - | +162 |
| Opponent | Vampire Counts | 4 | 72 | 745 | 5.2 | 1.1 | 142 | 2 | +140 | 9 of 21 | 15 of 21 | +225 | +126 |
| Opponent | Warriors of Chaos | 5 | 6 | 905 | 3.4 | 1.1 | 266 | 51 | +215 | 10 of 17 | 12 of 17 | +1373 | +143 |
| Opponent | Wood Elf Realms | 4 | 17 | 525 | 4.0 | 1.0 | 131 | 6 | +126 | 10 of 16 | 13 of 16 | - | +126 |
| **Opponent** | all armies | 29 | 79 | 582 | 3.5 | 1.1 | 167 | 24 | +143 | 50 of 101 | 76 of 101 | +337 | +124 |

### Effective charges: ja-opp-f9a8036-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +49) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 7 | 2 (net +157) | 0 | 1 (net +0) | 0 | 2 (net +46) | 2 (net +80) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +60) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +85) | 1 | 50% (1 of 2) |
| Mine | Grand Cathay | 18 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 5 (net +144) | 5 (net +66) | 3 (net +66) | 2 | 6% (1 of 16) |
| Mine | High Elf Realms | 8 | 2 (net +0) | 1 (net +0) | 1 (net +0) | 2 (net +27) | 0 | 1 (net +0) | 1 | 14% (1 of 7) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +210) | 0 | 0 | 1 (net +145) | 1 (net +112) | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +454) | 1 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 18 | 2 (net +263) | 1 (net -151) | 4 (net +262) | 2 (net +155) | 5 (net +66) | 2 (net +180) | 2 | 25% (4 of 16) |
| Opponent | Lizardmen | 7 | 1 (net +0) | 1 (net +165) | 1 (net +165) | 1 (net +310) | 0 | 3 (net +166) | 0 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 16 | 3 (net +74) | 0 | 0 | 2 (net +172) | 1 (net +0) | 2 (net +278) | 8 | 0% (0 of 8) |
| Opponent | Skaven | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net -762) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 1 (net +126) | 0 | 0 | 0 | 0 | 1 (net +199) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 21 | 7 (net +72) | 0 | 8 (net +142) | 2 (net +82) | 0 | 2 (net +516) | 2 | 42% (8 of 19) |
| Opponent | Warriors of Chaos | 17 | 4 (net +138) | 0 | 3 (net +473) | 2 (net -67) | 1 (net +77) | 4 (net +286) | 3 | 21% (3 of 14) |
| Opponent | Wood Elf Realms | 16 | 3 (net +137) | 1 (net +0) | 0 | 7 (net +114) | 0 | 5 (net +160) | 0 | 0% (0 of 16) |

### Charged fights, damage counted: ja-opp-f9a8036-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 264 | 319 | +66 | 79 | 40 | +39 | +14.9 |
| Mine | 50-54% | 2 | 226 | 171 | +0 | 73 | 82 | -10 | -4.3 |
| Mine | Effective (55-75%) | 5 | 232 | 131 | +0 | 41 | 89 | -48 | -20.7 |
| Mine | 76-89% | 8 | 339 | 144 | +115 | 154 | 64 | +91 | +26.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 308 | 168 | +108 | 145 | 8 | +138 | +44.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 395 | 83 | +67 | 67 | 31 | +36 | +9.1 |
| Mine | No odds | 10 | 140 | 150 | -6 | 24 | 37 | -13 | -9.5 |
| Mine | All fights | 55 | 278 | 168 | +62 | 91 | 39 | +52 | +18.7 |
| Opponent | Long shot (under 50%) | 23 | 253 | 288 | +102 | 173 | 65 | +108 | +42.6 |
| Opponent | 50-54% | 3 | 380 | 322 | +5 | 55 | 134 | -79 | -20.7 |
| Opponent | Effective (55-75%) | 16 | 375 | 220 | +235 | 257 | 58 | +199 | +53.1 |
| Opponent | 76-89% | 17 | 306 | 242 | +105 | 159 | 40 | +118 | +38.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 385 | 211 | +191 | 234 | 65 | +169 | +44.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 426 | 87 | +58 | 83 | 8 | +75 | +17.7 |
| Opponent | No odds | 15 | 321 | 179 | +152 | 174 | 9 | +165 | +51.4 |
| Opponent | All fights | 101 | 333 | 225 | +143 | 186 | 49 | +137 | +41.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-opp-f9a8036-p4 | move | 212 | 57 (27%) | 37 (17%) | 25 (12%) | 130 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Opponent | L0624, L1427 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

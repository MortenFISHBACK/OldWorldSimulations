# Doctrine scorecard: ja-mine-f9a8036-p4

### Scorecard: ja-mine-f9a8036-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 6 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 3 | 6 | 0 | 0 | 0 | 251 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 8 | - | 0 | 0 | 0 | 0 | 0 | 450 |
| L0315 | 3 | 1 | Opponent | no | 2 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 1 | 0 | 0 | 790 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 310 |
| L0417 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 56 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 812 |
| L0520 | 4 | 1 | Opponent | no | 2 | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | - | 2 | 3 | 0 | 0 | 0 | 878 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 135 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 246 |
| L0624 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 1 | 0 | 0 | 125 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 310 |
| L0819 | 3 | 1 | Opponent | yes | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 2 | 5 | 0 | 2 | 0 | 0 | 0 | 380 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 140 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 254 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 9 | 2 | 3 | 0 | 1 | 0 | 0 | 291 |
| L1017 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 1 | 0 | 0 | 273 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 293 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | yes | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1126 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 165 |
| L1220 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 1 | 0 | 0 | 210 |
| L1314 | 6 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | yes | 6 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 6 | 0 | 1 | 0 | 0 | 0 | 247 |
| L1331 | 5 | 1 | Opponent | no | - | 2 | 0 | 3 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 1 | 4 | 1 | 0 | 0 | 0 | 60 |
| L1621 | 1 | 1 | Mine | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 4 | 1 | 0 | 0 | 860 |
| **Average** | | | Mine | 28% | 3.1 | 3.3 | 1.7 | 1.3 | 0.3 | 0.0 | 0.0 | 274.1 |
| **Average** | | | Opponent | 33% | 3.1 | 2.1 | 2.6 | 2.3 | 0.3 | 0.0 | 0.0 | 99.8 |

### KPIs: ja-mine-f9a8036-p4

Rules off - Opponent only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 25 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 34% (41 of 122) | 0% (0 of 124) | 17% (41 of 246) |
| Winner chose to follow up after the loser gave ground |  | 81% (25 of 31); on the table 84% | 92% (33 of 36); on the table 94% | 87% (58 of 67); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 88% (7 of 8); on the table 88% | 93% (14 of 15); on the table 93% |
| Winner chose to pursue after the loser fled |  | 72% (13 of 18); on the table 72% | 68% (17 of 25); on the table 72% | 70% (30 of 43); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 80% (45 of 56); on the table 82% | 83% (57 of 69); on the table 86% | 82% (102 of 125); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 27% (64 of 239) | 23% (21 of 91) | 26% (85 of 330) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (64 of 166) | 30% (21 of 69) | 36% (85 of 235) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 56% (30 of 54) | 57% (37 of 65) |
| Points that never fought | lower | 40% (19251 of 48544) | 42% (21138 of 49989) | 41% (40389 of 98533) |
|   infantry points that never fought | lower | 53% (6199 of 11714) | 70% (7005 of 9981) | 61% (13204 of 21695) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (125 of 204) | 52% (100 of 192) | 57% (225 of 396) |
| Bound items with a magic missile used (at least once a game) |  | 100% (19 of 19); 1.7 uses a game | 100% (6 of 6); 0.8 uses a game | 100% (25 of 25); 1.2 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 25% (5 of 20); 0.2 uses a game | 39% (14 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (11 of 17); 0.4 uses a game | 67% (6 of 9); 0.2 uses a game | 65% (17 of 26); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (22588 of 41513) | 45% (19835 of 44447) | 49% (42423 of 85960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (30%) | 0.4 (14%) | 2.5 (26%) |
| MARCHED: its unit marched | 1.5 (22%) | 0.6 (20%) | 2.1 (21%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.5 (17%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 1.2 (17%) | 0.4 (13%) | 1.5 (16%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.4 (16%) | 0.7 (7%) |
| FLEEING: fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.2 (17%) | 0.5 (17%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (1%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.3 | 2.2 | 3.4 | 0.4 | 1.9 |
| not cast | 2.4 | 2.6 | 3.8 | 9.8 | 2.3 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (48%) | 0.6 (15%) | 2.5 (26%) | 0.8 (37%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (21%) | 0.5 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.2 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (6%) | 0.6 (17%) | 1.5 (16%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.2 (6%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (2%) | 0.0 (0%) | 0.2 (4%) | 0.3 (3%) | 0.1 (5%) | 0.4 (2%) |
| GONE: slain | 0.5 (21%) | 0.4 (14%) | 0.6 (17%) | 1.7 (17%) | 0.2 (9%) | 2.2 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (8%) | 0.1 (3%) | 0.3 (7%) | 0.3 (3%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.0 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.7 (26%) | 0.0 (1%) | 0.1 (1%) | 0.1 (5%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (64%) | 0.1 (3%) | 1.2 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.6 a game | 1.2 a game |
| stood (cast and not dispelled) | 68% (26 of 38) | 70% (7 of 10) | 69% (33 of 48) |
| the unit moved after it | 88% (23 of 26) | 71% (5 of 7) | 85% (28 of 33) |
| it charged on its next turn | 4% (1 of 26) | 0% (0 of 7) | 3% (1 of 33) |
| the enemy charged it first | 27% (7 of 26) | 0% (0 of 7) | 21% (7 of 33) |
| it fought by the end of its next turn | 8% (2 of 26) | 0% (0 of 7) | 6% (2 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 26) | 0% (0 of 7) | 0% (0 of 33) |
| none of these (no charge, no fight, no charge escaped) | 69% (18 of 26) | 100% (7 of 7) | 76% (25 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (433 of 661) | 55% (209 of 377) | 62% (642 of 1038) |
|   cavalry | 57% (41 of 72) | 74% (49 of 66) | 65% (90 of 138) |
|   character | 68% (50 of 74) | 18% (18 of 99) | 39% (68 of 173) |
|   chariot | 55% (38 of 69) | 69% (11 of 16) | 58% (49 of 85) |
|   infantry | 53% (88 of 165) | 72% (102 of 141) | 62% (190 of 306) |
|   monster | 69% (11 of 16) | 32% (7 of 22) | 47% (18 of 38) |
|   war machine | 77% (205 of 265) | 67% (22 of 33) | 76% (227 of 298) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (28%) | 0.8 (12%) | 3.4 (21%) |
| CHARGED: it charged | 0.6 (7%) | 2.2 (32%) | 2.8 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.2 (13%) | 0.5 (8%) | 1.7 (11%) |
| MOVED: a war machine that moved | 1.3 (14%) | 0.4 (6%) | 1.7 (11%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.4 (21%) | 3.0 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.3 (4%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (11%) | 0.9 (14%) | 1.9 (12%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (1%) | 0.2 (2%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.7 | 77% | 6.1 pts | 36 pts |
| character | 3.5 | 1.3 | 82% | 5.9 pts | 20 pts |
| chariot | 2.0 | 1.0 | 63% | 16.9 pts | 33 pts |
| infantry | 12.4 | 4.6 | 73% | 10.7 pts | 133 pts |
| monster | 0.9 | 0.1 | 87% | 5.7 pts | 5 pts |
| war machine | 9.1 | 7.9 | 63% | 23.1 pts | 209 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 6.2 | 4.6 |
| Charges that made contact a game | 2.3 | 4.2 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.07 declared, 0.80 contact (15 units) | 1.60 declared, 0.60 contact (10 units) | 1.28 declared, 0.72 contact (25 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 1.33 declared, 0.92 contact (12 units) | 1.06 declared, 0.78 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.27 contact (158 units) | 0.60 declared, 0.44 contact (202 units) | 0.49 declared, 0.36 contact (360 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (37 of 64) | 40% (4 of 10) | 75% (3 of 4) | 56% (44 of 78) |
| Character in a unit | 71% (15 of 21) | 64% (7 of 11) | 0% (0 of 1) | 67% (22 of 33) |
| Character on its own | 79% (19 of 24) | 45% (10 of 22) | 22% (11 of 50) | 42% (40 of 96) |
| Chariot | 57% (4 of 7) | 75% (9 of 12) | - | 68% (13 of 19) |
| Infantry | 52% (31 of 60) | 41% (9 of 22) | 60% (3 of 5) | 49% (43 of 87) |
| Monster | 74% (14 of 19) | 71% (5 of 7) | - | 73% (19 of 26) |
| Monstrous | 43% (3 of 7) | 80% (4 of 5) | - | 58% (7 of 12) |
| War Machines | 84% (36 of 43) | 50% (1 of 2) | - | 82% (37 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 28% (29 of 102) | 40% | 64% (14 of 22) | 100% (6 of 6); 2.5 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (5 of 5); on the table 100% | 29% (7 of 24) | 32% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 73% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 59% (10 of 17); on the table 65% | 33% (6 of 18) | 47% | 73% (45 of 62) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 80% (16 of 20); on the table 80% | 25% (21 of 84) | 30% | 38% (14 of 37) | 100% (9 of 9); 5.8 uses a game | 100% (2 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 89% (24 of 27); on the table 93% | 19% (7 of 36) | 43% | 53% (37 of 70) | 100% (7 of 7); 2.1 uses a game | 27% (8 of 30); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 33% (1 of 3); on the table 33% | - | 34% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | 50% (3 of 6) | 46% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 12) | 28% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 33% (1 of 3); on the table 67% | 17% (3 of 18) | 43% | 70% (16 of 23) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 14% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (11 of 11); on the table 100% | 25% (6 of 24) | 40% | 57% (13 of 23) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 100% (10 of 10); on the table 100% | 50% (3 of 6) | 41% | 49% (19 of 39) | 100% (1 of 1); 0.6 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| Wood Elf Realms | 3 | 50% (5 of 10); on the table 50% | - | 30% | 54% (15 of 28) | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (ja-mine-f9a8036-p4, 25 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (26) | 52% (16) | 45% (42) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.36 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.32 | 0.12 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.48 | 0.28 | 0.76 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.28 | 0.24 | 0.52 |

### Quality by phase: ja-mine-f9a8036-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 44% (32 of 72) | 51% (69 of 136) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (133 of 305) | 51% (41 of 81) |
| Strategy | Support requests answered (helper made contact too) | 57% (4 of 7) | 52% (11 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 42% (5 of 12) |
| Strategy | Joined characters whose unit fought | 35% (11 of 31) | 33% (6 of 18) |
| Strategy | Lone characters that fought | 73% (49 of 67) | 79% (44 of 56) |
| Movement | Charges halted short of contact | 0.2 | 0.5 |
| Movement | Idle units | 1.3 | 2.3 |
| Movement | Points that never moved of their own | 274.1 | 99.8 |
| Movement | Fights charged into per game | 2.1 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 47, net -20 | 22 of 82, net +75 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 47, net +67 | 18 of 82, net +191 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 47, net +50 | 9 of 82, net +157 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 47, net +86 | 17 of 82, net +188 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (117 of 247) | 48% (107 of 222) |
| Shooting | Points destroyed by shooting units | 98.0 | 64.7 |
| Shooting | War machine shots | 8.2 | 0.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (128 of 205) | 50% (11 of 22) |
| Shooting | Points destroyed by war machines | 42.1 | 0.0 |
| Magic | Magic missiles cast | 1.6 | 0.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 18% (7 of 40) | 25% (4 of 16) |
| Magic | Wounds caused by magic missiles | 4.2 | 1.0 |
| Magic | Wounds caused by other spells | 1.9 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 88.1 | 22.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.6 / 0.8 / 0.1 | 2.2 / 0.6 / 0.5 / 0.0 |
| Combat | Points destroyed in combat | 207.0 | 413.5 |
| Combat | Points run down | 44.5 | 165.0 |
| Combat | Net points per charged fight, damage counted | +48 | +138 |
| Combat | Net per 100 charger points, damage counted | +17.3 | +38.7 |
| Combat | First round won (charged fights) | 77% | 75% |
| Combat | Net points per charged fight | +54 | +138 |
| Combat | Net points per supported fight / lone fight | -146 / +66 | +318 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 13 of 53 | 43 of 89 |
| Game | Points lost | 854.9 | 538.4 |
| Game | VP from objectives | 547.2 | 660.4 |
| Game | Lone holders (player turns) | 3.1 | 3.1 |

- Mine won / drew / lost: 7 / 4 / 14 of 25 ended games (of 25); mean margin (Mine - Opponent) -469 VP
- The side that went first won 13 of 21 games with a winner
- Points traded per game (both sides' losses): 1393
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-mine-f9a8036-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +32.1 | 0.0 | 11.5 | 0.2 | +11.5 | 0.0 | 14.6 |
| ALREADY CARRIED | 0.2 | +0.0 | 12.9 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 34.4 | - | - | - | - |
| BACKUP TARGETS | 0.2 | +0.7 | 0.0 | 0.0 | 0.4 | +1.3 | 0.0 | 7.7 |
| BEST PRIZE | 0.1 | -7.5 | 2.6 | 0.0 | 0.3 | -32.6 | 19.8 | 20.0 |
| BLOWS WHERE AIMED | 0.1 | -16.3 | 7.4 | 29.9 | 0.5 | -77.7 | 80.4 | 8.9 |
| BOMBING RUN | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.1 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 54.2 | 14.8 | 0.1 | +0.0 | 26.4 | 0.0 |
| CANNON PLANNED TARGET | 7.3 | +220.5 | 234.8 | 132.0 | 0.7 | +37.2 | 62.9 | 0.0 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 4.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -7.6 | 15.2 | 8.9 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 5.4 | 0.0 | 0.0 | -15.2 | 9.2 | 0.0 |
| CAST JOB | 0.3 | +14.0 | 9.2 | 15.2 | 0.3 | +4.7 | 15.5 | 43.2 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.1 | +4.8 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 32.2 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.1 | 0.0 | 9.5 | 0.0 | +0.7 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +14.6 | 0.0 | 4.8 | 0.7 | +27.4 | 0.0 | 9.2 |
| CHAFF PASSED | 0.4 | -1.1 | 0.0 | 7.2 | 0.3 | -1.1 | 0.0 | 4.9 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.6 | -264.9 | 0.0 | 188.7 | 6.4 | -437.5 | 0.0 | 149.4 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 17.0 | 0.0 | 0.8 | +0.0 | 83.3 | 25.6 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 142.2 | 55.1 | 2.5 | +0.0 | 366.3 | 42.4 |
| CHARGER SLAIN LOST | 0.3 | -14.1 | 2.4 | 46.4 | 0.6 | -22.4 | 97.0 | 58.2 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 20.6 | 3.6 |
| CHEAPEST HOLDER | 0.4 | -44.3 | 10.8 | 3.4 | 0.1 | -20.9 | 30.8 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 0.0 | 23.4 | 0.3 | +0.0 | 14.6 | 33.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +146.3 | 88.7 | 93.8 | 0.3 | +17.7 | 4.4 | 0.0 |
| COVER ONCE | 8.5 | -559.7 | 0.0 | 233.3 | 6.9 | -472.4 | 0.0 | 98.0 |
| DEPLOY BY FIGURES | 8.3 | +1.7 | 0.0 | 4.0 | 7.7 | +64.6 | 0.0 | 15.5 |
| EDGE GIVE GROUND | 0.2 | +8.0 | 7.4 | 0.0 | 0.3 | +5.2 | 45.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.1 | +3.2 | 136.4 | 122.1 | 3.9 | +5.8 | 462.0 | 35.2 |
| FALLBACK BY WORTH | 0.3 | +0.9 | 0.0 | 7.0 | 0.3 | +0.0 | 0.0 | 1.1 |
| FALLS SHORT | 2.6 | +40.0 | 0.0 | 26.1 | 18.1 | +221.4 | 0.0 | 217.0 |
| FEATURE BUFFS | 1.6 | +51.1 | 0.0 | 29.0 | 0.9 | +18.1 | 0.0 | 16.2 |
| FIGHT LIFT | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.6 | +3.8 | 35.7 | 13.0 | 1.9 | +104.9 | 315.0 | 31.8 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 9.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 45.0 | +2369.3 | 588.8 | 895.1 | 45.4 | +2840.8 | 917.2 | 511.8 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 241.0 | 4.8 | +0.0 | 0.0 | 78.6 |
| FLEE LOSES BLESSING | 0.0 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| FOCUS FIRE | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.4 | +63.1 | 0.0 | 15.5 | 0.8 | +228.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.9 | +192.4 | 206.3 | 122.1 | 5.1 | +583.6 | 614.8 | 83.6 |
| FRIEND CHARGES FIRST | 0.0 | -2.7 | 0.0 | 0.0 | 0.3 | -13.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.2 | -9.0 | 0.0 | 0.0 | 0.1 | -0.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | -0.2 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.3 | 2.4 | 0.0 | 0.5 | -9.2 | 50.4 | 4.4 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -2.5 | 8.2 | 0.0 |
| GROUND FLIERS | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +1.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +16.0 | 23.8 | 78.2 | 0.5 | +2.8 | 2.9 | 5.2 |
| GUN MASK | 0.8 | +17.5 | 0.0 | 1.4 | 0.2 | +4.6 | 0.0 | 6.6 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 12.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.8 | +0.0 | 0.0 | 78.3 | 3.3 | +0.0 | 0.0 | 96.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +5.9 | 3.4 | 12.4 | 0.6 | +20.7 | 55.5 | 8.9 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 44.3 | 4.3 | +0.0 | 0.0 | 38.3 |
| HIS LEGAL MOVES | 3.9 | +0.0 | 0.0 | 98.1 | 3.9 | +0.0 | 0.0 | 58.4 |
| HIS MOVE AND SHOT | 1.3 | -25.0 | 0.0 | 39.9 | 2.0 | -42.9 | 0.0 | 37.8 |
| HIS RANDOM MOVE | 2.7 | +0.0 | 0.0 | 71.3 | 1.4 | +0.0 | 0.0 | 8.1 |
| HIS SHOT LIST | 15.2 | +468.7 | 0.0 | 275.0 | 26.7 | +1496.9 | 0.0 | 250.8 |
| HIS TURN DENIED | 1.1 | +43.5 | 102.2 | 55.0 | 2.8 | +178.3 | 339.8 | 56.4 |
| HOLDER AT DEPLOYMENT | 0.7 | +124.8 | 0.0 | 0.0 | 0.8 | +139.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -94.0 | 193.0 | 80.5 | 4.3 | -230.4 | 488.1 | 16.3 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 5.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +22.4 | 0.0 | 0.0 | 0.6 | +21.3 | 0.0 | 16.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +30.0 | 10.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +9.2 | 0.0 | 0.0 | 0.2 | +43.3 | 21.6 | 0.0 |
| IDLE COST | 1.7 | -16.6 | 0.0 | 29.0 | 12.4 | -198.2 | 0.0 | 90.2 |
| JOINT CHARGE NOW | 0.6 | +6.7 | 39.6 | 32.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -17.9 | 29.6 | 0.0 |
| KEEP FALLS | 0.2 | +2.6 | 0.0 | 8.8 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.0 | +0.5 | 7.6 | 0.0 |
| LANE BY FIGURES | 0.7 | +21.8 | 0.0 | 0.0 | 1.1 | +61.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.8 | +0.0 | 215.4 | 540.1 | 6.9 | +0.0 | 350.2 | 346.7 |
| LONE CHARACTER SAFE SPOT | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +26.2 | 0.0 | 0.0 | 0.2 | +22.7 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.3 | 4.3 | 0.0 | 0.2 | -2.3 | 0.0 | 8.9 |
| LURE BY WHAT IT DRAWS | 0.2 | -5.5 | 0.0 | 3.4 | - | - | - | - |
| MAKE SURE TOGETHER | 0.2 | +10.4 | 0.0 | 0.0 | 0.4 | +47.7 | 0.0 | 4.9 |
| MANOEUVRE | 1.2 | +3.6 | 0.0 | 37.3 | 1.2 | +16.9 | 0.0 | 8.4 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.4 | 0.0 | 0.0 | 0.2 | +16.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +41.4 | 0.0 | 50.4 | 0.2 | +12.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +70.0 | 0.0 | 31.2 | 0.3 | +2.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +98.2 | 0.0 | 143.5 | 6.0 | +84.2 | 0.0 | 84.9 |
| MISSILES IN THE MOVE | 3.8 | +176.0 | 0.0 | 180.3 | 2.0 | +39.8 | 0.0 | 21.6 |
| MISSILES NEXT TURN | 5.0 | +111.8 | 0.0 | 174.8 | 2.4 | +21.5 | 0.0 | 21.6 |
| MODEL FACING | 0.5 | +113.1 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.6 | +17.2 | 0.0 | 68.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -22.3 | 19.4 | 109.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 16.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.8 | +355.8 | 0.0 | 76.4 | 4.5 | +708.5 | 0.0 | 54.4 |
| MOVES UNITS SPELL | 0.1 | +4.7 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.2 | +176.4 | 0.0 | 59.9 | 4.7 | +258.9 | 0.0 | 27.8 |
| NEEDED THERE | - | - | - | - | 0.1 | +11.6 | 13.6 | 0.0 |
| NEXT CHARGE BY LIST | 5.4 | -143.8 | 12.8 | 65.3 | 6.0 | -298.0 | 24.3 | 78.3 |
| NEXT OBJECTIVE NEARER | 5.7 | -229.0 | 28.6 | 77.1 | 8.6 | -428.5 | 16.9 | 61.9 |
| NO DOUBLE ROUNDS | 2.2 | -88.7 | 167.8 | 93.2 | 3.9 | -198.0 | 453.5 | 63.6 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 5.2 | 0.2 | +0.0 | 0.0 | 6.2 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 33.8 | 0.1 | -6.0 | 0.0 | 0.0 |
| OFF BEST | 0.6 | -7.8 | 0.0 | 0.0 | 0.4 | -30.3 | 0.0 | 6.8 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 92.0 | 4.0 | +0.0 | 0.0 | 39.2 |
| ONE FIGHT FORMULA | 5.5 | -120.1 | 0.0 | 136.5 | 5.3 | -144.0 | 0.0 | 53.1 |
| ONE OBJECTIVE FORMULA | 3.4 | -25.2 | 0.0 | 76.2 | 2.8 | -29.3 | 0.0 | 30.1 |
| ONE TARGET A SHOOTER | 10.8 | +235.2 | 0.0 | 238.7 | 22.2 | +885.4 | 0.0 | 207.4 |
| OPENS A LANE | 0.2 | +2.1 | 12.2 | 7.0 | 0.3 | +5.5 | 80.9 | 0.0 |
| OPENS UP | 0.2 | +8.6 | 11.4 | 0.0 | 0.3 | +18.4 | 19.1 | 0.0 |
| OVERRUNS AWAY | 0.4 | +17.6 | 41.0 | 27.6 | 0.6 | +43.0 | 113.2 | 19.6 |
| PATHS CROSS | 3.0 | +139.8 | 0.0 | 58.7 | 5.2 | +186.2 | 0.0 | 43.7 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +7.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.3 | 0.0 | 12.4 | 0.0 | -0.3 | 0.0 | 0.0 |
| PLAN RESULT | 40.1 | +784.8 | 325.9 | 1275.1 | 41.0 | +686.7 | 572.3 | 770.0 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -3.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +17.7 | 0.0 | 6.8 | 2.2 | +36.2 | 0.0 | 53.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +21.0 | 0.0 | 1.4 | 0.7 | -19.5 | 0.0 | 11.6 |
| REDIRECT COUNTER | 1.8 | +100.1 | 0.0 | 41.0 | 4.2 | +165.9 | 0.0 | 73.4 |
| REDIRECT WEIGHED | 0.2 | -0.9 | 0.0 | 12.4 | 0.4 | +3.0 | 17.9 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -23.1 | 0.0 | 17.3 | 0.6 | -15.0 | 0.0 | 35.8 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 30.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +12.6 | 0.0 | 16.3 | 0.4 | +20.3 | 0.0 | 11.2 |
| RESTRAINS TO SHOOT | 0.1 | +9.0 | 0.0 | 0.0 | 0.2 | +7.6 | 0.0 | 6.6 |
| RISK BY ARC | 2.1 | +60.4 | 155.5 | 69.6 | 3.4 | -12.9 | 461.2 | 69.0 |
| RISK BY HIS FIGURE | 13.2 | -225.4 | 0.0 | 404.4 | 14.8 | -206.7 | 0.0 | 204.8 |
| RUN DOWN | 2.0 | -20.8 | 121.0 | 90.1 | 4.1 | -40.4 | 449.5 | 51.4 |
| SAME CHARGE LATER | 0.2 | -1.4 | 0.0 | 13.9 | 0.1 | -4.3 | 3.1 | 0.0 |
| SCOUT SPOT | 0.3 | +0.1 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.5 | 0.0 | 0.0 | 0.3 | -26.4 | 0.0 | 2.8 |
| SEARCH SPOT | 5.4 | +228.9 | 0.0 | 82.5 | 5.8 | +260.5 | 0.0 | 21.1 |
| SELF MOVE SPELL | 0.2 | +4.8 | 0.0 | 0.0 | 0.2 | +57.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +10.8 | 0.0 | 3.2 | 0.6 | +48.6 | 0.0 | 4.9 |
| SET-UP ANY TARGET | 0.2 | +24.9 | 28.1 | 19.0 | 0.1 | +13.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.6 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +9.6 | 15.5 | 20.4 | 0.6 | +17.6 | 60.4 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -7.1 | 26.2 | 0.0 | 0.4 | -5.7 | 53.1 | 0.0 |
| SHOT RISK POINTS | 7.1 | +1.2 | 0.0 | 177.3 | 16.0 | +89.4 | 0.0 | 243.6 |
| SHOTS IN THE MOVE | 17.0 | +810.6 | 0.0 | 397.4 | 8.4 | +287.7 | 0.0 | 125.3 |
| SPELL SETS UP CHARGE | 0.2 | +33.3 | 28.1 | 19.0 | 0.1 | +13.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +14.3 | 75.8 | 94.6 | 2.9 | +64.4 | 50.9 | 47.0 |
| SPELLS IN THE FIGHT | 0.5 | +4.7 | 55.5 | 23.6 | 1.4 | -17.2 | 158.0 | 48.5 |
| STAND AND SHOOT | 0.6 | -7.2 | 41.4 | 0.0 | 0.9 | -22.1 | 95.6 | 24.0 |
| STANDS FOR A REASON | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 32.9 |
| STANDS STILL | 18.9 | +0.0 | 382.4 | 291.0 | 8.8 | +0.0 | 274.0 | 124.9 |
| STAY WORTH | 20.8 | +34.7 | 301.3 | 309.5 | 7.3 | +54.6 | 141.3 | 113.9 |
| STOPS | 0.0 | +0.4 | 0.0 | 0.0 | 0.2 | +7.2 | 21.6 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 8.4 |
| SUPPORT NARROWED | 0.9 | +0.0 | 49.8 | 35.4 | 1.6 | +0.0 | 198.8 | 33.5 |
| SURE REACH TOGETHER | 0.4 | +9.5 | 0.0 | 11.2 | 0.7 | +20.5 | 0.0 | 9.6 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 73.0 | 4.8 | +0.0 | 0.0 | 43.7 |
| THE PROMISE ADDS | - | - | - | - | 0.4 | -19.1 | 70.1 | 0.0 |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.8 | +85.8 | 48.4 | 24.8 | 0.6 | +71.3 | 50.2 | 0.0 |
| TIME ON OUR SIDE | 27.8 | +447.2 | 7.2 | 325.3 | 5.3 | +76.5 | 0.0 | 43.3 |
| TWO OR MORE ARRIVE | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 11.7 | 0.9 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +4.3 | 0.0 | 12.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 7.9 | 24.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.2 | +35.7 | 0.0 | 14.6 | 0.4 | +42.1 | 0.0 | 6.0 |
| WHOLE FIGHT | 0.2 | +0.4 | 2.4 | 14.5 | 0.6 | +11.5 | 100.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +9.0 | 5.4 | 0.0 | 0.6 | +35.3 | 58.7 | 26.8 |
| WIDER SPREAD | 1.5 | -4.2 | 125.6 | 86.4 | 4.1 | -7.5 | 475.2 | 83.6 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 2.4 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.8 | +29.2 | 0.0 | 34.4 | 0.8 | +38.9 | 0.0 | 13.1 |

### Rule changes: ja-mine-f9a8036-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 343 | 343 | 343 | 13.72 | +0 | +0.0 |
| HIS SHOT LIST | 1048 | 1048 | 292 | 11.68 | +6632 | +22.7 |
| DEPLOY BY FIGURES | 399 | 399 | 264 | 10.56 | +4171 | +15.8 |
| SEARCH SPOT | 278 | 278 | 261 | 10.44 | +12236 | +46.9 |
| FIVE ACTION | 2262 | 2259 | 218 | 8.72 | +7975 | +36.6 |
| ONE TARGET A SHOOTER | 826 | 826 | 207 | 8.28 | +2455 | +11.9 |
| PATHS CROSS | 204 | 204 | 204 | 8.16 | +8151 | +40.0 |
| TIME ON OUR SIDE | 827 | 738 | 137 | 5.48 | +629 | +4.6 |
| MOVE TO CHARGE COMPUTED | 207 | 207 | 118 | 4.72 | +9655 | +81.8 |
| FOUR ROUNDS | 200 | 197 | 103 | 4.12 | +6255 | +60.7 |
| SHOT RISK POINTS | 576 | 576 | 96 | 3.84 | +3694 | +38.5 |
| COVER ONCE | 385 | 302 | 77 | 3.08 | +1300 | +16.9 |
| HARD STAY DROPPED | 61 | 61 | 61 | 2.44 | +0 | +0.0 |
| MAX FOR POSITIONING | 281 | 277 | 59 | 2.36 | +223 | +3.8 |
| SHOTS IN THE MOVE | 635 | 608 | 54 | 2.16 | +2310 | +42.8 |
| ADVANCE LANE KEPT | 52 | 52 | 52 | 2.08 | +0 | +0.0 |
| IDLE COST | 352 | 284 | 49 | 1.96 | +425 | +8.7 |
| LANE BY FIGURES | 46 | 46 | 46 | 1.84 | +2094 | +45.5 |
| RISK BY ARC | 138 | 137 | 46 | 1.84 | +790 | +17.2 |
| NEXT OBJECTIVE NEARER | 357 | 357 | 43 | 1.72 | +572 | +13.3 |
| ARTILLERY RE-ROLL WEIGHED | 40 | 40 | 40 | 1.60 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 65 | 65 | 37 | 1.48 | +1347 | +36.4 |
| CHARGE LOSSES | 274 | 274 | 32 | 1.28 | +3154 | +98.6 |
| REDIRECT COUNTER | 149 | 116 | 32 | 1.28 | +2276 | +71.1 |
| RISK BY HIS FIGURE | 702 | 702 | 32 | 1.28 | +3017 | +94.3 |
| CHARGE NOW FIRST | 101 | 101 | 31 | 1.24 | -1075 | -34.7 |
| FOLLOW UP WEIGHED | 31 | 31 | 31 | 1.24 | +7281 | +234.9 |
| MANOEUVRE | 60 | 60 | 31 | 1.24 | +731 | +23.6 |
| CANNON SIGHT KEPT | 30 | 30 | 30 | 1.20 | +0 | +0.0 |
| HIS TURN DENIED | 99 | 99 | 30 | 1.20 | +990 | +33.0 |
| TIED UP BY THE SUM | 36 | 35 | 30 | 1.20 | +1039 | +34.6 |
| MISSILES IN THE MOVE | 146 | 120 | 28 | 1.12 | +739 | +26.4 |
| CHARGE NOT DECLARED | 27 | 27 | 27 | 1.08 | -2892 | -107.1 |
| OFF BEST | 26 | 26 | 26 | 1.04 | -952 | -36.6 |
| CANNON PLANNED TARGET | 201 | 201 | 23 | 0.92 | -604 | -26.3 |
| NEXT CHARGE BY LIST | 284 | 284 | 23 | 0.92 | +244 | +10.6 |
| FALLS SHORT | 518 | 442 | 22 | 0.88 | +62 | +2.8 |
| SHOOTS FROM THE BEST SPOT | 33 | 33 | 22 | 0.88 | +163 | +7.4 |
| LONE WIZARD KEPT IN | 21 | 21 | 21 | 0.84 | +1222 | +58.2 |
| RESERVE FALL BACK | 21 | 21 | 21 | 0.84 | +821 | +39.1 |
| COMBAT PIVOT | 19 | 19 | 19 | 0.76 | +0 | +0.0 |
| HOLDS AMBUSHERS | 18 | 18 | 18 | 0.72 | +0 | +0.0 |
| CHAFF IN THE MOVE | 27 | 23 | 17 | 0.68 | +49 | +2.9 |
| SURE REACH TOGETHER | 26 | 26 | 17 | 0.68 | +313 | +18.4 |
| CHAFF PASSED | 16 | 16 | 16 | 0.64 | -57 | -3.5 |
| MARCH CHECK | 24 | 24 | 15 | 0.60 | +212 | +14.1 |
| STAY WORTH | 702 | 668 | 15 | 0.60 | +106 | +7.1 |
| SHOOTERS IN TWO RANKS | 14 | 14 | 14 | 0.56 | +27 | +1.9 |
| WHO HITS BACK | 14 | 14 | 14 | 0.56 | +1016 | +72.5 |
| CAST JOB | 15 | 15 | 13 | 0.52 | +210 | +16.1 |
| FIGHT TO THE END | 64 | 62 | 13 | 0.52 | +905 | +69.6 |
| MARCH BY THE SUM | 13 | 13 | 13 | 0.52 | +722 | +55.5 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.52 | +184 | +14.1 |
| MODEL FACING | 12 | 12 | 12 | 0.48 | +2828 | +235.7 |
| ONE OBJECTIVE FORMULA | 154 | 136 | 12 | 0.48 | +237 | +19.7 |
| OVERRUNS AWAY | 26 | 26 | 12 | 0.48 | +287 | +23.9 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.44 | +1089 | +99.0 |
| BEST PRIZE | 11 | 11 | 11 | 0.44 | -1230 | -111.9 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 0.44 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 36 | 36 | 11 | 0.44 | +451 | +41.0 |
| WOUNDS ON THE RANKS | 39 | 39 | 11 | 0.44 | +233 | +21.2 |
| OPENS UP | 13 | 13 | 10 | 0.40 | +244 | +24.4 |
| SUPPORT NARROWED | 61 | 61 | 10 | 0.40 | -109 | -10.9 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.36 | +0 | +0.0 |
| ONE FIGHT FORMULA | 270 | 136 | 9 | 0.36 | +24 | +2.6 |
| SCOUT WAITS | 9 | 9 | 9 | 0.36 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.36 | +0 | +0.0 |
| WIDER SPREAD | 139 | 137 | 9 | 0.36 | +48 | +5.4 |
| WHOLE FIGHT GAIN | 17 | 17 | 8 | 0.32 | +346 | +43.3 |
| FEATURE BUFFS | 61 | 61 | 7 | 0.28 | +156 | +22.3 |
| HIS CHARGE DENIED | 19 | 18 | 7 | 0.28 | +147 | +21.0 |
| NEARER NOT NEEDED | 223 | 216 | 7 | 0.28 | +294 | +42.0 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.28 | +413 | +59.0 |
| STUCK PIVOT | 7 | 7 | 7 | 0.28 | +0 | +0.0 |
| HIS MOVE AND SHOT | 83 | 83 | 6 | 0.24 | +63 | +10.6 |
| SET UP TOGETHER | 24 | 19 | 6 | 0.24 | +200 | +33.4 |
| GUN MASK | 25 | 25 | 5 | 0.20 | +225 | +45.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.20 | +156 | +31.1 |
| MOVES UNITS SPELL | 5 | 5 | 5 | 0.20 | +129 | +25.8 |
| NO DOUBLE ROUNDS | 153 | 151 | 5 | 0.20 | +175 | +35.0 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.20 | -39 | -7.8 |
| REFUSING RETIRES | 10 | 10 | 5 | 0.20 | -1 | -0.3 |
| HUNT IN PAIRS | 29 | 10 | 4 | 0.16 | +89 | +22.1 |
| JOINT CHARGE NOW | 16 | 16 | 4 | 0.16 | +116 | +28.9 |
| MISSILES NEXT TURN | 185 | 144 | 4 | 0.16 | +73 | +18.2 |
| SPELLS IN THE FIGHT | 48 | 47 | 4 | 0.16 | +98 | +24.5 |
| CASTING BLOCK | 3 | 3 | 3 | 0.12 | +29 | +9.8 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.12 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.12 | +16 | +5.4 |
| OPENS A LANE | 13 | 10 | 3 | 0.12 | +20 | +6.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.08 | +66 | +33.1 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.08 | +0 | +0.1 |
| CARRIES OUT COUNTER | 3 | 3 | 2 | 0.08 | -189 | -94.4 |
| HONEST WORTH | 169 | 167 | 2 | 0.08 | +55 | +27.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| NEEDED THERE | 3 | 3 | 2 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.08 | +194 | +97.0 |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 2 | 0.08 | +0 | +0.0 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.08 | +53 | +26.3 |
| BLOWS WHERE AIMED | 15 | 14 | 1 | 0.04 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.04 | -379 | -379.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| EDGE GIVE GROUND | 11 | 11 | 1 | 0.04 | +96 | +95.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.04 | +46 | +46.5 |
| FALLBACK BY WORTH | 15 | 15 | 1 | 0.04 | +22 | +22.5 |
| FLEE LOSES BLESSING | 1 | 1 | 1 | 0.04 | +51 | +51.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.04 | +27 | +27.2 |
| KILLS COUNT | 1 | 1 | 1 | 0.04 | +10 | +9.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.04 | -93 | -93.3 |
| RUN DOWN | 153 | 150 | 1 | 0.04 | +10 | +10.0 |
| STOPS | 5 | 5 | 1 | 0.04 | +1 | +1.2 |
| WAR ENGINE JOBS | 7 | 7 | 1 | 0.04 | -19 | -19.2 |
| WHOLE FIGHT | 19 | 18 | 1 | 0.04 | +43 | +43.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.04 | -3 | -3.3 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| BACKUP TARGETS | 15 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 23 | 23 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 14 | 14 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 40 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 151 | 150 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 256 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 14 | 13 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 43 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 127 | 127 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 173 | 173 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 195 | 195 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 103 | 103 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 8 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 16 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 15 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT TURNED | 13 | 13 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 21 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 174 | 174 | 0 | 0.00 | - | - |
| PLAN RESULT | 2027 | trace | - | - | - | - |
| REFORMS TO MEET IT | 39 | 39 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 9 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SHOT OR CHARGE | 15 | 15 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 99 | not checked | - | - | - | - |
| STAND AND SHOOT | 38 | 38 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 694 | 694 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 208 | not checked | - | - | - | - |
| THE PROMISE ADDS | 10 | 10 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 20 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 5 | not checked | - | - | - | - |
| WAITS AGAIN | 67 | 67 | 0 | 0.00 | - | - |

### Off best figure: ja-mine-f9a8036-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.48 | 0.84 | 25.7 |
| CHARGE NOW FIRST | rule | 0.48 | 0.72 | 35.8 |
| CHARGE NOT DECLARED | rule | 0.24 | 0.80 | 111.2 |
| BEST PRIZE | rule | 0.12 | 0.32 | 111.9 |
| JOB FIRST | gate | 0.12 | 0.28 | 46.4 |
| CHAFF PASSED | rule | 0.12 | 0.24 | 6.3 |
| SUPPORT NARROWED | rule | 0.16 | 0.20 | 12.1 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 87.3 |
| AFTERMATH BAND | gate | 0.16 | 0.08 | 3.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.20 | 0.04 | 76.1 |
| PIVOT GUARDS FLANK | rule | 0.16 | 0.04 | 7.8 |
| DEPLOY BY FIGURES | rule | 0.08 | 0.08 | 5.4 |
| REDIRECT WEIGHED | rule | 0.04 | 0.12 | 42.4 |
| FIGHT ORDER BAND | gate | 0.12 | - | 2.8 |
| CARRIES OUT COUNTER | rule | - | 0.08 | 94.4 |
| FRIENDS SHOTS CHECKED | rule | 0.08 | - | 2.6 |
| CARRIES OUT SET-UP | rule | - | 0.04 | 379.1 |
| FALLBACK | gate | 0.04 | - | 1.1 |
| FOLLOW UP WEIGHED | rule | 0.04 | - | 4.7 |
| PURSUES BIG PREY | rule | - | 0.04 | 93.3 |
| WAR ENGINE JOBS | rule | 0.04 | - | 19.2 |
| WHO HITS BACK | rule | - | 0.04 | 3.6 |
| WOUNDED STAYS OUT | rule | 0.04 | - | 3.3 |

### Plans: ja-mine-f9a8036-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.9 | 64% | 221 | 149 | 67% |
| Mine | join | 0.4 | 89% | 6 | 0 | 0% |
| Mine | move | 26.9 | 95% | 1568 | 0 | 0% |
| Mine | shoot | 10.7 | 60% | 444 | 636 | 143% |
| Mine | support | 0.3 | 88% | 30 | 0 | 0% |
| Opponent | charge | 4.6 | 57% | 708 | 494 | 70% |
| Opponent | join | 0.3 | 100% | 19 | 0 | 0% |
| Opponent | move | 32.8 | 93% | 1664 | 0 | 0% |
| Opponent | shoot | 2.4 | 62% | 138 | 193 | 140% |
| Opponent | support | 0.8 | 65% | 1 | 0 | 0% |

### Packages: hunt the guns, ja-mine-f9a8036-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 231 | 0 | 0% | 18 |
| Opponent | 0.2 | 4 | 0 | 75% | 75% | 0% | 2.0 | 271 | 187 | 75% | 61 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 231 | 0 | 0% | 91 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 290 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.0 | 4 | 0 | 75% | 75% | 0% | 2.0 | 271 | 187 | 75% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 81 |

### Battle groups: ja-mine-f9a8036-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 27% | 75% | 17% | 50% | 0% | 0% | 0% | 80% | 20% |
| Opponent | REDIRECT COUNTER | 4.2 | 19% | 85% | 40% | 25% | 0% | 0% | 33% | 58% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-mine-f9a8036-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 13 (9) | 0 | 13 | 56 | 67% | 3.0 | 0 (3) | 18 (6) | - | 15 (8) | 0 (1) |
| Mine | Character | 86 | 36 (86) | 36 | 0 | 43 | 21% | 2.6 | 47 (28) | 28 (30) | 34 (10) | 47 (45) | 19 (23) |
| Mine | Clean-up | 19 | 70 (19) | 15 | 55 | 49 | 37% | 3.5 | 63 (9) | 101 (7) | 0 (3) | 88 (11) | 48 (8) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 0% | 3.5 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fast Hammer | 31 | 37 (31) | 16 | 21 | 39 | 23% | 2.7 | 19 (14) | 57 (12) | 49 (5) | 51 (15) | 25 (16) |
| Mine | Hammer | 39 | 33 (39) | 16 | 17 | 59 | 31% | 2.7 | 31 (15) | 36 (22) | 0 (2) | 37 (28) | 21 (11) |
| Mine | Holder | 19 | 41 (19) | 3 | 39 | 49 | 42% | 3.3 | 41 (7) | 59 (9) | 0 (3) | 77 (9) | 14 (10) |
| Mine | Shooter | 26 | 112 (26) | 51 | 61 | 32 | 4% | 1.8 | 39 (6) | 141 (13) | 108 (7) | 115 (22) | 100 (4) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 22 (56) | 22 | 0 | 49 | 7% | 1.3 | 26 (31) | 13 (19) | 30 (6) | 64 (10) | 13 (46) |
| Mine | Wizard | 12 | 12 (12) | 12 | 0 | 27 | 25% | 2.9 | 0 (4) | 25 (6) | - | 26 (6) | 0 (4) |
| Opponent | Chaff | 50 | 66 (50) | 17 | 49 | 46 | 46% | 2.9 | 42 (24) | 85 (12) | 90 (14) | 75 (36) | 49 (14) |
| Opponent | Character | 64 | 64 (64) | 64 | 0 | 22 | 23% | 2.1 | 65 (21) | 62 (29) | 83 (8) | 60 (30) | 72 (28) |
| Opponent | Clean-up | 14 | 55 (14) | 34 | 22 | 7 | 50% | 3.3 | 36 (6) | 79 (5) | 50 (3) | 79 (10) | 28 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 35 | 44 (35) | 18 | 26 | 23 | 40% | 3.6 | 55 (7) | 55 (19) | 12 (9) | 46 (20) | 41 (15) |
| Opponent | Fragile | 9 | 0 (9) | 0 | 0 | 45 | 44% | 1.6 | 0 (4) | 0 (4) | 0 (1) | 0 (2) | 0 (7) |
| Opponent | Hammer | 38 | 38 (38) | 32 | 7 | 37 | 34% | 3.2 | 0 (12) | 47 (16) | 61 (10) | 51 (25) | 18 (13) |
| Opponent | Holder | 21 | 49 (21) | 0 | 49 | 26 | 71% | 4.2 | 4 (7) | 69 (13) | 62 (1) | 77 (11) | 24 (10) |
| Opponent | Shooter | 33 | 60 (33) | 22 | 38 | 48 | 12% | 1.7 | 47 (9) | 83 (15) | 32 (9) | 57 (19) | 63 (14) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 6 | 67 (6) | 67 | 0 | 19 | 0% | 2.2 | 16 (3) | 141 (3) | - | 16 (3) | 141 (3) |
| Opponent | Wizard | 10 | 9 (10) | 9 | 0 | 13 | 20% | 2.4 | 15 (3) | 9 (3) | 0 (2) | 11 (3) | 10 (5) |

### Charged fights: ja-mine-f9a8036-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 230 | 44 | 1.0 | 1.0 | 44 | 13 | +32 | 2 of 4 | 2 of 4 | - | +32 |
| Mine | Chaos Dwarfs | 4 | 86 | 191 | 2.2 | 1.0 | 85 | 0 | +85 | 2 of 9 | 8 of 9 | - | +85 |
| Mine | Dwarfen Mountain Holds | 3 | 189 | 20 | 1.0 | 1.0 | 20 | 0 | +20 | 0 of 3 | 2 of 3 | - | +20 |
| Mine | Empire of Man | 5 | 125 | 64 | 1.0 | 1.0 | 64 | 0 | +64 | 1 of 5 | 4 of 5 | - | +64 |
| Mine | Grand Cathay | 4 | 457 | 382 | 4.5 | 1.2 | 85 | 0 | +85 | 3 of 18 | 16 of 18 | +154 | +76 |
| Mine | High Elf Realms | 4 | 340 | 84 | 2.2 | 1.1 | 37 | 83 | -46 | 3 of 9 | 5 of 9 | -747 | +42 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 467 | 5.0 | 1.0 | 93 | 0 | +93 | 2 of 5 | 4 of 5 | - | +93 |
| **Mine** | all armies | 25 | 228 | 146 | 2.1 | 1.1 | 69 | 15 | +54 | 13 of 53 | 41 of 53 | -146 | +66 |
| Opponent | Empire of Man | 1 | 60 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 156 | 705 | 4.2 | 1.2 | 168 | 7 | +161 | 10 of 21 | 18 of 21 | +349 | +130 |
| Opponent | Lizardmen | 2 | 290 | 701 | 3.5 | 1.0 | 200 | 0 | +200 | 3 of 7 | 6 of 7 | - | +200 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 1282 | 6.0 | 1.3 | 214 | 17 | +196 | 3 of 6 | 4 of 6 | +286 | +151 |
| Opponent | Skaven | 3 | 24 | 126 | 1.3 | 1.0 | 95 | 190 | -96 | 4 of 4 | 3 of 4 | - | -96 |
| Opponent | Tomb Kings of Khemri | 1 | 314 | 236 | 5.0 | 1.0 | 47 | 86 | -39 | 2 of 5 | 3 of 5 | - | -39 |
| Opponent | Vampire Counts | 4 | 72 | 356 | 4.2 | 1.1 | 84 | 2 | +81 | 7 of 17 | 10 of 17 | +0 | +92 |
| Opponent | Warriors of Chaos | 5 | 6 | 877 | 3.0 | 1.1 | 292 | 58 | +234 | 9 of 15 | 12 of 15 | +864 | +137 |
| Opponent | Wood Elf Realms | 3 | 15 | 670 | 4.3 | 1.4 | 155 | 0 | +155 | 5 of 13 | 10 of 13 | +197 | +136 |
| **Opponent** | all armies | 25 | 87 | 586 | 3.6 | 1.2 | 165 | 26 | +138 | 43 of 89 | 67 of 89 | +318 | +107 |

### Effective charges: ja-mine-f9a8036-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 2 (net -26) | 0 | 0 | 0 | 0 | 2 (net +89) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 9 | 1 (net +405) | 0 | 0 | 0 | 2 (net +14) | 5 (net +45) | 1 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +60) | 0 | 33% (1 of 3) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +235) | 0 | 1 (net +85) | 1 | 25% (1 of 4) |
| Mine | Grand Cathay | 18 | 0 | 1 (net +0) | 1 (net +60) | 2 (net +46) | 5 (net +49) | 6 (net +152) | 3 | 7% (1 of 15) |
| Mine | High Elf Realms | 9 | 3 (net -249) | 0 | 2 (net +138) | 2 (net +0) | 1 (net +60) | 0 | 1 | 25% (2 of 8) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +210) | 0 | 0 | 1 (net +145) | 1 (net +112) | 2 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 21 | 1 (net +526) | 0 | 8 (net +91) | 2 (net +155) | 4 (net +78) | 5 (net +290) | 1 | 40% (8 of 20) |
| Opponent | Lizardmen | 7 | 1 (net +0) | 0 | 1 (net +165) | 2 (net +155) | 0 | 3 (net +309) | 0 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 6 | 2 (net +286) | 0 | 0 | 0 | 0 | 1 (net +255) | 3 | 0% (0 of 3) |
| Opponent | Skaven | 4 | 2 (net +0) | 0 | 0 | 1 (net +379) | 0 | 1 (net -762) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 5 | 2 (net -216) | 0 | 1 (net +60) | 1 (net +0) | 0 | 1 (net +176) | 0 | 20% (1 of 5) |
| Opponent | Vampire Counts | 17 | 7 (net +31) | 0 | 4 (net +125) | 4 (net +78) | 1 (net +352) | 0 | 1 | 25% (4 of 16) |
| Opponent | Warriors of Chaos | 15 | 4 (net +138) | 0 | 2 (net +710) | 2 (net -67) | 1 (net +77) | 5 (net +229) | 1 | 14% (2 of 14) |
| Opponent | Wood Elf Realms | 13 | 3 (net +68) | 0 | 2 (net +278) | 3 (net +194) | 3 (net +222) | 1 (net +0) | 1 | 17% (2 of 12) |

### Charged fights, damage counted: ja-mine-f9a8036-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 300 | 335 | -20 | 121 | 127 | -6 | -2.1 |
| Mine | 50-54% | 1 | 205 | 141 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 5 | 242 | 118 | +67 | 73 | 11 | +62 | +25.6 |
| Mine | 76-89% | 6 | 322 | 110 | +78 | 84 | 43 | +42 | +13.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 244 | 161 | +86 | 97 | 1 | +96 | +39.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 363 | 68 | +50 | 52 | 33 | +19 | +5.2 |
| Mine | No odds | 6 | 206 | 90 | +54 | 54 | 15 | +40 | +19.3 |
| Mine | All fights | 53 | 277 | 157 | +54 | 83 | 35 | +48 | +17.3 |
| Opponent | Long shot (under 50%) | 22 | 234 | 280 | +75 | 152 | 64 | +88 | +37.5 |
| Opponent | Effective (55-75%) | 18 | 328 | 194 | +191 | 210 | 33 | +177 | +54.0 |
| Opponent | 76-89% | 16 | 414 | 214 | +110 | 193 | 39 | +153 | +37.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 407 | 211 | +188 | 242 | 76 | +166 | +40.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 516 | 102 | +157 | 159 | 16 | +142 | +27.6 |
| Opponent | No odds | 7 | 348 | 184 | +122 | 123 | 37 | +86 | +24.7 |
| Opponent | All fights | 89 | 356 | 212 | +138 | 186 | 49 | +138 | +38.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-mine-f9a8036-p4 | move | 194 | 46 (24%) | 32 (16%) | 30 (15%) | 118 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819 |
| Invocation of Nehek | Opponent | L0624, L1427 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

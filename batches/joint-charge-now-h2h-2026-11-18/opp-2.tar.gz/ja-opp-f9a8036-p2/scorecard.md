# Doctrine scorecard: ja-opp-f9a8036-p2

### Scorecard: ja-opp-f9a8036-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 280 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 495 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 1 | 5 | 1 | 0 | 0 | 52 |
| L0222 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 760 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 70 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 3 | 2 | 2 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 95 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 95 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 340 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 1 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 708 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 4 | 5 | 0 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 260 |
| L0810 | 6 | 1 | Opponent | no | 24 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 525 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 2 | 4 | 4 | 3 | 1 | 0 | 0 | 268 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 599 |
| L0934 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | yes | 4 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 9 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 2 | 6 | 1 | 1 | 2 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 2 | 0 | 0 | 70 |
| L1323 | 3 | 1 | Opponent | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 1 | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 22% | 2.9 | 2.6 | 1.8 | 1.5 | 0.2 | 0.0 | 0.0 | 177.2 |
| **Average** | | | Opponent | 28% | 3.7 | 2.8 | 2.3 | 1.7 | 0.4 | 0.0 | 0.0 | 102.5 |

### KPIs: ja-opp-f9a8036-p2

Rules off - Mine only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 24 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 37% (41 of 111) | 13% (16 of 123) | 24% (57 of 234) |
| Winner chose to follow up after the loser gave ground |  | 79% (23 of 29); on the table 83% | 78% (28 of 36); on the table 81% | 78% (51 of 65); on the table 82% |
| Winner chose to pursue after the loser fell back in good order |  | 36% (4 of 11); on the table 45% | 75% (6 of 8); on the table 75% | 53% (10 of 19); on the table 58% |
| Winner chose to pursue after the loser fled |  | 85% (11 of 13); on the table 85% | 56% (9 of 16); on the table 62% | 69% (20 of 29); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 72% (38 of 53); on the table 75% | 72% (43 of 60); on the table 75% | 72% (81 of 113); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 32% (91 of 282) | 25% (28 of 114) | 30% (119 of 396) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (91 of 210) | 33% (28 of 86) | 40% (119 of 296) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (4 of 7) | 58% (11 of 19) | 58% (15 of 26) |
| Points that never fought | lower | 53% (25284 of 47588) | 48% (22805 of 47992) | 50% (48089 of 95580) |
|   infantry points that never fought | lower | 59% (6815 of 11544) | 70% (6410 of 9157) | 64% (13225 of 20701) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (133 of 203) | 59% (110 of 188) | 62% (243 of 391) |
| Bound items with a magic missile used (at least once a game) |  | 88% (14 of 16); 1.9 uses a game | 91% (10 of 11); 1.2 uses a game | 89% (24 of 27); 1.6 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.9 uses a game | 50% (1 of 2); 0.0 uses a game | 65% (13 of 20); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (8 of 15); 0.3 uses a game | 33% (2 of 6); 0.1 uses a game | 48% (10 of 21); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (24448 of 40271) | 53% (21695 of 41029) | 57% (46143 of 81300) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (24%) | 0.6 (16%) | 2.5 (21%) |
| MARCHED: its unit marched | 2.3 (29%) | 0.9 (26%) | 3.2 (28%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.4 (10%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 1.5 (19%) | 0.9 (26%) | 2.5 (21%) |
| REAR RANK: in a rear rank | 0.5 (6%) | 0.2 (5%) | 0.6 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (13%) | 0.1 (2%) | 1.1 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.2 (5%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.2 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 2.1 | 1.3 | 5.0 | 0.3 | 1.2 |
| not cast | 2.0 | 3.6 | 3.7 | 11.5 | 1.9 | 18.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (51%) | 0.3 (9%) | 2.5 (21%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.2 (28%) | 0.4 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.2 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (9%) | 0.3 (8%) | 0.7 (19%) | 2.5 (21%) | 0.6 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (13%) | 0.5 (13%) | 0.4 (11%) | 0.6 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.2 (13%) | 0.5 (14%) | 0.5 (15%) | 1.1 (10%) | 0.1 (7%) | 2.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (2%) | 0.1 (3%) | 0.2 (7%) | 0.5 (4%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.2 (9%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.2 (7%) | 0.1 (2%) | 0.2 (1%) | 0.2 (11%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (51%) | 0.1 (2%) | 1.2 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.5 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 58% (15 of 26) | 75% (9 of 12) | 63% (24 of 38) |
| the unit moved after it | 67% (10 of 15) | 56% (5 of 9) | 62% (15 of 24) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 9) | 0% (0 of 24) |
| the enemy charged it first | 20% (3 of 15) | 11% (1 of 9) | 17% (4 of 24) |
| it fought by the end of its next turn | 7% (1 of 15) | 0% (0 of 9) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 9) | 0% (0 of 24) |
| none of these (no charge, no fight, no charge escaped) | 80% (12 of 15) | 89% (8 of 9) | 83% (20 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (451 of 678) | 56% (378 of 680) | 61% (829 of 1358) |
|   cavalry | 66% (37 of 56) | 63% (66 of 105) | 64% (103 of 161) |
|   character | 71% (61 of 86) | 28% (24 of 87) | 49% (85 of 173) |
|   chariot | 56% (42 of 75) | 75% (40 of 53) | 64% (82 of 128) |
|   infantry | 61% (100 of 163) | 54% (143 of 266) | 57% (243 of 429) |
|   monster | 52% (11 of 21) | 61% (25 of 41) | 58% (36 of 62) |
|   war machine | 72% (200 of 277) | 62% (80 of 128) | 69% (280 of 405) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.2 (34%) | 2.8 (23%) | 6.1 (28%) |
| CHARGED: it charged | 0.6 (6%) | 1.5 (12%) | 2.1 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.5 (4%) | 0.6 (3%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.2 (2%) | 0.8 (3%) |
| MOVED: a war machine that moved | 1.7 (18%) | 1.0 (8%) | 2.6 (12%) |
| NO TARGET IN RANGE | 0.7 (7%) | 2.6 (21%) | 3.3 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.5 (4%) | 1.1 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (16%) | 2.4 (19%) | 3.9 (18%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.3 (3%) | 0.7 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.6 (5%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.9 | 1.6 | 81% | 5.8 pts | 40 pts |
| character | 3.8 | 2.2 | 70% | 14.7 pts | 56 pts |
| chariot | 3.4 | 2.3 | 65% | 20.2 pts | 69 pts |
| infantry | 14.2 | 5.3 | 74% | 7.5 pts | 106 pts |
| monster | 1.7 | 0.5 | 75% | 7.7 pts | 13 pts |
| war machine | 11.7 | 11.8 | 60% | 28.2 pts | 329 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.5 | 5.6 | 4.1 |
| Charges that made contact a game | 2.2 | 3.8 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.70 declared, 0.65 contact (20 units) | 2.00 declared, 1.40 contact (10 units) | 1.13 declared, 0.90 contact (30 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.60 declared, 1.20 contact (5 units) | 1.60 declared, 1.20 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.25 contact (156 units) | 0.54 declared, 0.36 contact (198 units) | 0.44 declared, 0.31 contact (354 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (23 of 47) | 33% (2 of 6) | 57% (4 of 7) | 48% (29 of 60) |
| Character in a unit | 89% (25 of 28) | 78% (7 of 9) | - | 86% (32 of 37) |
| Character on its own | 88% (15 of 17) | 62% (20 of 32) | 27% (10 of 37) | 52% (45 of 86) |
| Chariot | 50% (6 of 12) | 69% (9 of 13) | - | 60% (15 of 25) |
| Infantry | 52% (31 of 60) | 57% (13 of 23) | 67% (2 of 3) | 53% (46 of 86) |
| Monster | 59% (10 of 17) | 75% (3 of 4) | - | 62% (13 of 21) |
| Monstrous | 43% (3 of 7) | 90% (9 of 10) | - | 71% (12 of 17) |
| War Machines | 86% (49 of 57) | 100% (2 of 2) | - | 86% (51 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (4 of 4); on the table 100% | 24% (24 of 102) | 66% | 64% (14 of 22) | 83% (5 of 6); 5.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 83% | 61% (22 of 36) | 53% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 60% (9 of 15); on the table 60% | - | 76% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 79% (11 of 14); on the table 93% | 40% (19 of 48) | 48% | 67% (51 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 75% (6 of 8); on the table 75% | 25% (35 of 138) | 53% | 59% (32 of 54) | 93% (13 of 14); 5.8 uses a game | 50% (1 of 2); 0.3 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 3 | 50% (4 of 8); on the table 50% | 33% (6 of 18) | 24% | 38% (10 of 26) | 100% (1 of 1); 1.7 uses a game | 64% (9 of 14); 4.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 72% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 3 | 75% (3 of 4); on the table 75% | 0% (0 of 12) | 40% | 71% (15 of 21) | 100% (3 of 3); 3.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 33% (1 of 3); on the table 33% | 0% (0 of 6) | 50% | 78% (7 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 71% (12 of 17); on the table 76% | - | 42% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 60% (6 of 10); on the table 60% | 50% (9 of 18) | 34% | 71% (12 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (7 of 7); on the table 100% | 25% (3 of 12) | 30% | 41% (9 of 22) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 3 | 57% (4 of 7); on the table 71% | 17% (1 of 6) | 50% | 62% (20 of 32) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-opp-f9a8036-p2, 24 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (26) | 74% (20) | 57% (46) |
| ...free all their last turn and able to turn (per game) | 0.62 | 0.71 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.42 | 0.00 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.50 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ja-opp-f9a8036-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 70% (42 of 60) | 49% (60 of 123) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (134 of 347) | 45% (94 of 209) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 41% (7 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (12 of 20) | 50% (5 of 10) |
| Strategy | Joined characters whose unit fought | 20% (8 of 41) | 15% (4 of 26) |
| Strategy | Lone characters that fought | 48% (29 of 60) | 75% (40 of 53) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.5 | 1.7 |
| Movement | Points that never moved of their own | 177.2 | 102.5 |
| Movement | Fights charged into per game | 2.1 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 46, net -4 | 22 of 73, net +23 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 46, net +51 | 15 of 73, net +13 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 46, net +65 | 2 of 73, net +144 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 46, net +71 | 13 of 73, net +152 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.2 | 13.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (105 of 270) | 39% (126 of 324) |
| Shooting | Points destroyed by shooting units | 157.4 | 73.1 |
| Shooting | War machine shots | 8.3 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (106 of 200) | 59% (47 of 80) |
| Shooting | Points destroyed by war machines | 88.5 | 50.8 |
| Magic | Magic missiles cast | 2.0 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (7 of 49) | 28% (5 of 18) |
| Magic | Wounds caused by magic missiles | 3.9 | 1.2 |
| Magic | Wounds caused by other spells | 1.8 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 61.4 | 47.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.8 / 0.6 / 0.1 | 2.9 / 0.4 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 232.5 | 289.5 |
| Combat | Points run down | 38.3 | 94.5 |
| Combat | Net points per charged fight, damage counted | +54 | +64 |
| Combat | Net per 100 charger points, damage counted | +20.0 | +21.8 |
| Combat | First round won (charged fights) | 82% | 67% |
| Combat | Net points per charged fight | +44 | +56 |
| Combat | Net points per supported fight / lone fight | +22 / +45 | +51 / +56 |
| Combat | Charged fights on a top-3 enemy unit | 20 of 50 | 36 of 79 |
| Game | Points lost | 729.0 | 622.0 |
| Game | VP from objectives | 489.6 | 715.8 |
| Game | Lone holders (player turns) | 2.9 | 3.7 |

- Mine won / drew / lost: 9 / 3 / 12 of 24 ended games (of 24); mean margin (Mine - Opponent) -345 VP
- The side that went first won 10 of 21 games with a winner
- Points traded per game (both sides' losses): 1351
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-opp-f9a8036-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +77.6 | 0.0 | 32.7 | 0.3 | +24.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +21.9 | 0.0 | 29.4 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 74.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.4 | 0.0 | 3.5 | 0.2 | +1.5 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.0 | -0.5 | 3.5 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -1.6 | 24.7 | 0.0 | 0.5 | -83.5 | 10.5 | 70.0 |
| BOUND ASSAILMENT | 0.2 | +0.0 | 0.0 | 11.4 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 173.2 | 9.8 | 0.6 | +0.0 | 52.5 | 8.5 |
| CANNON PLANNED TARGET | 7.6 | +282.5 | 638.5 | 162.5 | 3.0 | +77.8 | 146.6 | 26.5 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 2.5 | 0.6 | +0.0 | 0.0 | 4.2 |
| CARRIES OUT SET-UP | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +18.4 | 29.1 | 2.5 | 0.2 | +7.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 14.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +25.6 | 6.9 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 16.7 | 0.4 | +0.0 | 0.0 | 16.9 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.4 | +13.0 | 0.0 | 5.0 | 0.4 | +11.0 | 0.0 | 2.8 |
| CHAFF PASSED | 0.4 | -1.1 | 15.4 | 7.4 | 0.2 | -0.1 | 18.4 | 2.5 |
| CHARACTER GUNS | 0.8 | +0.0 | 0.0 | 10.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.5 | -285.1 | 0.0 | 193.5 | 6.2 | -427.3 | 0.0 | 267.8 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 36.6 | 44.1 | 0.5 | +0.0 | 23.1 | 30.4 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 162.8 | 46.2 | 2.5 | +0.0 | 279.8 | 75.0 |
| CHARGER SLAIN LOST | 0.1 | -6.2 | 17.9 | 25.0 | 0.4 | -9.3 | 28.6 | 0.0 |
| CHEAPEST HOLDER | 0.2 | -11.4 | 4.4 | 0.0 | 0.4 | -23.5 | 11.7 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 8.8 | 0.3 | +0.0 | 10.4 | 28.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +63.8 | 28.0 | 35.4 | 0.3 | +75.2 | 6.6 | 16.9 |
| COVER ONCE | 7.1 | -432.4 | 0.0 | 184.6 | 5.8 | -387.1 | 0.0 | 92.1 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 25.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | -6.0 | 0.0 | 12.0 | 8.2 | +78.5 | 0.0 | 12.7 |
| EDGE GIVE GROUND | 0.1 | +14.0 | 18.5 | 0.0 | 0.3 | +10.3 | 58.4 | 23.8 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +11.0 | 189.9 | 67.0 | 3.8 | +9.0 | 308.0 | 138.9 |
| FALLBACK BY WORTH | 0.2 | +1.1 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 1.9 |
| FALLS SHORT | 7.3 | +127.2 | 0.0 | 102.8 | 16.5 | +225.8 | 0.0 | 267.1 |
| FEATURE BUFFS | 1.6 | +41.3 | 0.0 | 21.7 | 0.9 | +13.5 | 0.0 | 4.6 |
| FIGHT LIFT | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.1 | +18.8 | 114.4 | 24.3 | 1.9 | +83.7 | 161.5 | 90.1 |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 5.0 | - | - | - | - |
| FIRE IN ORDER | 0.4 | +0.0 | 16.8 | 14.5 | 0.2 | +0.0 | 5.9 | 0.0 |
| FIVE ACTION | 45.9 | +2600.6 | 1315.2 | 877.2 | 51.2 | +3182.0 | 840.9 | 707.2 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 153.5 | 4.4 | +0.0 | 0.0 | 118.1 |
| FOCUS FIRE | 0.0 | +1.3 | 4.8 | 6.1 | 0.0 | +0.3 | 0.0 | 4.2 |
| FOLLOW UP WEIGHED | 0.6 | +139.4 | 0.0 | 0.0 | 0.8 | +182.5 | 0.0 | 11.5 |
| FOUR ROUNDS | 2.4 | +273.1 | 211.8 | 73.2 | 5.1 | +480.9 | 462.5 | 138.9 |
| FRIEND CHARGES FIRST | 0.0 | -2.9 | 0.0 | 0.0 | 0.0 | -1.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -18.0 | 0.0 | 15.2 | 0.5 | -5.0 | 0.0 | 4.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +11.0 | 0.0 | 0.0 | 0.2 | +7.1 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.2 | 21.8 | 21.1 | 0.5 | -7.1 | 31.1 | 47.7 |
| GUN FIGURES | 1.7 | +21.4 | 47.6 | 44.8 | 1.3 | +23.0 | 32.1 | 23.1 |
| GUN MASK | 0.9 | +20.8 | 0.0 | 17.8 | 0.3 | +3.9 | 0.0 | 2.5 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 10.3 | 0.8 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 81.0 | 2.4 | +0.0 | 0.0 | 31.4 |
| HELPER UNSEEN | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +12.5 | 27.5 | 6.3 | 0.7 | +30.5 | 37.9 | 12.4 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 72.9 | 3.5 | +0.0 | 0.0 | 75.8 |
| HIS LEGAL MOVES | 3.2 | +0.0 | 0.0 | 60.1 | 3.4 | +0.0 | 0.0 | 38.6 |
| HIS MOVE AND SHOT | 1.8 | -31.0 | 0.0 | 58.7 | 2.3 | -37.4 | 0.0 | 44.9 |
| HIS RANDOM MOVE | 1.4 | +0.0 | 0.0 | 22.1 | 1.4 | +0.0 | 0.0 | 3.0 |
| HIS SHOT LIST | 20.2 | +909.2 | 0.0 | 367.2 | 28.2 | +1502.2 | 0.0 | 387.5 |
| HIS TURN DENIED | 1.4 | +80.5 | 90.5 | 42.6 | 3.0 | +176.8 | 310.3 | 103.1 |
| HOLDER AT DEPLOYMENT | 0.7 | +124.3 | 0.0 | 0.0 | 1.0 | +159.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.2 | -72.8 | 187.1 | 44.8 | 4.3 | -200.7 | 410.5 | 128.8 |
| HUNT IN PAIRS | 0.3 | +23.5 | 0.0 | 0.0 | 0.6 | +42.6 | 0.0 | 9.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +45.2 | 0.0 | 4.6 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +51.8 | 22.3 | 0.0 |
| IDLE COST | 3.8 | -48.6 | 0.0 | 73.0 | 10.2 | -140.2 | 0.0 | 138.2 |
| JOINT CHARGE NOW | - | - | - | - | 1.2 | +33.5 | 95.6 | 59.8 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -23.4 | 22.7 | 2.1 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 0.1 | +7.6 | 8.1 | 12.4 | - | - | - | - |
| LANE BY FIGURES | 0.6 | +29.1 | 0.0 | 0.0 | 0.9 | +48.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 251.5 | 244.4 | 6.5 | +0.0 | 309.8 | 291.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +48.9 | 0.0 | 0.0 | 0.4 | +36.2 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -2.0 | 8.1 | 7.6 | 0.4 | -1.0 | 12.2 | 2.6 |
| LOST CHARGE | 0.2 | -0.8 | 25.3 | 0.0 | 0.0 | -0.2 | 3.5 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -9.9 | 0.0 | 3.5 | 0.1 | -3.6 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +2.3 | 0.0 | 0.0 | 0.5 | +6.6 | 0.0 | 4.8 |
| MANOEUVRE | 0.8 | +8.9 | 0.0 | 20.6 | 1.2 | +11.2 | 0.0 | 23.8 |
| MARCH AT ESCAPER | 0.2 | +5.0 | 0.0 | 6.8 | 0.0 | +0.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +23.9 | 0.0 | 0.0 | 0.3 | +27.3 | 0.0 | 33.0 |
| MARCH CHECK | 1.2 | +56.7 | 0.0 | 7.0 | 0.9 | +37.3 | 0.0 | 14.9 |
| MARCH OVER CASTS | 1.0 | +39.5 | 0.0 | 28.8 | 0.7 | +85.2 | 0.0 | 39.5 |
| MAX FOR POSITIONING | 5.0 | +75.9 | 0.0 | 95.5 | 7.2 | +103.8 | 0.0 | 52.4 |
| MISSILES IN THE MOVE | 4.7 | +121.5 | 0.0 | 90.0 | 2.8 | +57.7 | 0.0 | 14.9 |
| MISSILES NEXT TURN | 6.2 | +89.2 | 0.0 | 108.7 | 3.8 | +48.0 | 0.0 | 72.5 |
| MODEL FACING | 0.5 | +103.4 | 0.0 | 2.5 | 0.4 | +108.3 | 0.0 | 2.5 |
| MOVE SPELL IN RANGE | 0.4 | +14.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -3.6 | 0.0 | 0.0 | 0.2 | -17.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 16.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.1 | +366.0 | 0.0 | 37.8 | 4.3 | +542.2 | 0.0 | 29.0 |
| MOVES UNITS SPELL | 0.1 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.2 | +261.5 | 0.0 | 58.2 | 4.8 | +287.1 | 0.0 | 40.4 |
| NEEDED THERE | 0.1 | +32.0 | 8.1 | 12.4 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.6 | -188.1 | 34.7 | 49.0 | 6.6 | -264.1 | 24.6 | 76.8 |
| NEXT OBJECTIVE NEARER | 6.9 | -318.3 | 193.8 | 111.1 | 9.5 | -571.2 | 102.8 | 85.9 |
| NO DOUBLE ROUNDS | 2.0 | -67.1 | 188.8 | 54.6 | 4.1 | -163.4 | 345.7 | 134.0 |
| NOT TURNED | 0.3 | -0.2 | 0.0 | 14.0 | - | - | - | - |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -19.3 | 0.0 | 0.0 | 0.2 | -12.3 | 0.0 | 8.7 |
| ONE CHARGE A CHARGER | 2.2 | +0.0 | 0.0 | 95.2 | 2.6 | +0.0 | 0.0 | 54.7 |
| ONE FIGHT FORMULA | 4.3 | -87.6 | 0.0 | 91.6 | 6.0 | -133.1 | 0.0 | 71.4 |
| ONE OBJECTIVE FORMULA | 3.6 | -6.1 | 0.0 | 72.8 | 3.7 | -21.9 | 0.0 | 25.0 |
| ONE TARGET A SHOOTER | 17.1 | +451.3 | 0.0 | 335.9 | 22.2 | +741.1 | 0.0 | 174.4 |
| OPENS A LANE | 0.2 | +0.4 | 53.2 | 7.8 | 0.2 | +1.8 | 21.2 | 0.0 |
| OPENS UP | 0.1 | +4.2 | 0.0 | 0.0 | 0.3 | +11.9 | 18.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +16.3 | 38.8 | 12.4 | 0.5 | +23.7 | 53.6 | 4.4 |
| PATHS CROSS | 3.6 | +174.6 | 0.0 | 51.7 | 5.3 | +204.7 | 0.0 | 47.0 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +4.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.4 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +1099.1 | 874.3 | 1038.6 | 44.5 | +823.4 | 422.9 | 911.9 |
| PURSUES BIG PREY | 0.0 | -0.6 | 0.0 | 3.5 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.3 | +3.9 | 0.0 | 21.2 | 0.8 | +26.6 | 0.0 | 32.3 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.1 | 0.0 | 0.0 | 0.2 | -10.6 | 0.0 | 7.6 |
| REDIRECT COUNTER | 1.4 | +77.3 | 0.0 | 25.1 | 3.3 | +249.0 | 0.0 | 39.7 |
| REDIRECT WEIGHED | 0.1 | +5.2 | 10.4 | 0.0 | 0.2 | +0.0 | 0.0 | 10.6 |
| REFORMS TO MEET IT | 0.8 | -14.5 | 0.0 | 0.0 | 0.8 | -11.1 | 0.0 | 4.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +11.8 | 0.0 | 0.0 | 0.9 | +39.5 | 0.0 | 16.0 |
| RESTRAINS TO SHOOT | 0.1 | +2.7 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +70.2 | 201.9 | 64.5 | 2.5 | -9.3 | 218.5 | 86.6 |
| RISK BY HIS FIGURE | 12.0 | -221.7 | 0.0 | 309.2 | 13.1 | -259.6 | 0.0 | 276.5 |
| RUN DOWN | 1.5 | -13.1 | 114.2 | 21.8 | 4.2 | -38.3 | 386.9 | 107.9 |
| SAME CHARGE LATER | 0.2 | -4.5 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 5.1 |
| SCOUT SPOT | 0.2 | +1.0 | 0.0 | 0.0 | 0.8 | +3.0 | 0.0 | 1.4 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 1.4 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -29.6 | 0.0 | 4.2 |
| SEARCH SPOT | 6.0 | +284.6 | 0.0 | 126.9 | 7.1 | +325.2 | 0.0 | 83.2 |
| SET UP TOGETHER | 0.2 | +2.4 | 0.0 | 0.0 | 0.8 | +6.9 | 0.0 | 4.8 |
| SET-UP MISSED | 0.0 | +9.7 | 0.0 | 0.0 | 0.1 | +15.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.4 | +1.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +50.9 | 50.1 | 11.0 | 0.8 | +13.9 | 17.4 | 45.2 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -15.7 | 33.6 | 0.0 | 0.5 | -28.8 | 32.5 | 4.4 |
| SHOT RISK POINTS | 10.1 | +35.4 | 0.0 | 220.2 | 14.8 | -49.6 | 0.0 | 344.3 |
| SHOTS IN THE MOVE | 19.8 | +1004.0 | 0.0 | 409.8 | 17.6 | +616.1 | 0.0 | 247.9 |
| SPELL WORTH | 0.7 | +9.8 | 33.3 | 33.3 | 2.2 | +40.2 | 93.7 | 93.7 |
| SPELLS IN THE FIGHT | 0.5 | +5.7 | 42.9 | 40.7 | 1.0 | -4.3 | 105.1 | 21.3 |
| STAND AND SHOOT | 0.5 | -6.1 | 27.1 | 6.3 | 1.0 | -13.5 | 92.8 | 35.3 |
| STANDS FOR A REASON | 0.3 | +0.0 | 5.1 | 5.9 | 0.7 | +0.0 | 9.5 | 39.8 |
| STANDS STILL | 20.5 | +0.0 | 1086.9 | 368.1 | 14.0 | +0.0 | 378.4 | 158.5 |
| STAY WORTH | 22.8 | +81.9 | 517.2 | 364.8 | 18.7 | +180.0 | 284.3 | 145.5 |
| STOPS | - | - | - | - | 0.1 | +1.9 | 22.3 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 7.1 | - | - | - | - |
| SUPPORT NARROWED | 1.2 | +0.0 | 101.9 | 42.6 | 1.5 | +0.0 | 110.0 | 63.1 |
| SURE REACH TOGETHER | 0.2 | +2.7 | 0.0 | 6.0 | 0.8 | +6.0 | 0.0 | 7.6 |
| THE DEARER SUM KEEPS ITS PLAN | 4.2 | +0.0 | 0.0 | 67.0 | 5.6 | +0.0 | 0.0 | 35.5 |
| THE PROMISE ADDS | 0.2 | -10.4 | 0.0 | 2.2 | - | - | - | - |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.6 | +59.0 | 51.6 | 20.5 | 0.5 | +57.5 | 53.1 | 0.0 |
| TIME ON OUR SIDE | 23.0 | +357.5 | 4.2 | 317.8 | 12.8 | +172.3 | 0.0 | 84.8 |
| WAITS AGAIN | 1.5 | +0.0 | 0.0 | 9.5 | 1.5 | +0.0 | 0.0 | 5.1 |
| WAR ENGINE JOBS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 10.4 | 0.0 |
| WHO HITS BACK | 0.2 | +35.6 | 0.0 | 14.5 | 0.4 | +66.8 | 0.0 | 37.9 |
| WHOLE FIGHT | 0.1 | +7.9 | 14.9 | 0.0 | 0.2 | +9.6 | 12.9 | 21.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.2 | +8.8 | 16.9 | 2.1 |
| WIDER SPREAD | 1.5 | -0.9 | 116.5 | 42.8 | 3.7 | -7.2 | 295.0 | 80.5 |
| WOUNDS ON THE RANKS | 1.6 | +62.4 | 0.0 | 11.3 | 1.5 | +130.0 | 0.0 | 77.5 |

### Rule changes: ja-opp-f9a8036-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1162 | 1162 | 377 | 15.71 | +9643 | +25.6 |
| SEARCH SPOT | 314 | 314 | 305 | 12.71 | +14635 | +48.0 |
| LEGAL CHARGES ONLY | 291 | 291 | 291 | 12.12 | +0 | +0.0 |
| DEPLOY BY FIGURES | 395 | 395 | 257 | 10.71 | +4020 | +15.6 |
| ONE TARGET A SHOOTER | 944 | 944 | 257 | 10.71 | +3491 | +13.6 |
| FIVE ACTION | 2329 | 2329 | 220 | 9.17 | +9044 | +41.1 |
| PATHS CROSS | 215 | 215 | 215 | 8.96 | +9103 | +42.3 |
| TIME ON OUR SIDE | 860 | 781 | 150 | 6.25 | +652 | +4.3 |
| MOVE TO CHARGE COMPUTED | 179 | 179 | 105 | 4.38 | +8983 | +85.6 |
| SHOT RISK POINTS | 598 | 598 | 97 | 4.04 | +3892 | +40.1 |
| FOUR ROUNDS | 181 | 181 | 82 | 3.42 | +5808 | +70.8 |
| MAX FOR POSITIONING | 293 | 291 | 70 | 2.92 | +142 | +2.0 |
| SHOTS IN THE MOVE | 896 | 861 | 67 | 2.79 | +2903 | +43.3 |
| NEXT OBJECTIVE NEARER | 393 | 393 | 63 | 2.62 | +882 | +14.0 |
| COVER ONCE | 308 | 258 | 60 | 2.50 | +1188 | +19.8 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 50 | 50 | 50 | 2.08 | +0 | +0.0 |
| CANNON PLANNED TARGET | 255 | 255 | 47 | 1.96 | -646 | -13.8 |
| CHARGE LOSSES | 306 | 306 | 44 | 1.83 | +5463 | +124.2 |
| HARD STAY DROPPED | 41 | 41 | 41 | 1.71 | +0 | +0.0 |
| ADVANCE LANE KEPT | 40 | 40 | 40 | 1.67 | +0 | +0.0 |
| RISK BY HIS FIGURE | 602 | 602 | 40 | 1.67 | +4895 | +122.4 |
| CHARGE NOW FIRST | 108 | 108 | 37 | 1.54 | -2164 | -58.5 |
| HIS TURN DENIED | 104 | 104 | 37 | 1.54 | +1796 | +48.5 |
| IDLE COST | 334 | 263 | 36 | 1.50 | +221 | +6.1 |
| LANE BY FIGURES | 36 | 36 | 36 | 1.50 | +1852 | +51.4 |
| FOLLOW UP WEIGHED | 35 | 35 | 35 | 1.46 | +7727 | +220.8 |
| SHOOTS FROM THE BEST SPOT | 49 | 49 | 34 | 1.42 | +455 | +13.4 |
| MARCH CHECK | 50 | 50 | 33 | 1.38 | +648 | +19.6 |
| STAY WORTH | 994 | 959 | 32 | 1.33 | +325 | +10.1 |
| RESERVE FALL BACK | 30 | 30 | 30 | 1.25 | +1231 | +41.0 |
| RISK BY ARC | 113 | 113 | 30 | 1.25 | +716 | +23.9 |
| FALLS SHORT | 571 | 490 | 29 | 1.21 | +150 | +5.2 |
| NEXT CHARGE BY LIST | 269 | 269 | 29 | 1.21 | +423 | +14.6 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 1.12 | +2043 | +75.7 |
| SCOUT WAITS | 27 | 27 | 27 | 1.12 | +0 | +0.0 |
| CHARGE NOT DECLARED | 26 | 26 | 26 | 1.08 | -3958 | -152.2 |
| REDIRECT COUNTER | 113 | 97 | 24 | 1.00 | +2136 | +89.0 |
| HOLDS AMBUSHERS | 21 | 21 | 21 | 0.88 | +0 | +0.0 |
| MISSILES IN THE MOVE | 179 | 146 | 21 | 0.88 | +415 | +19.8 |
| OFF BEST | 21 | 21 | 21 | 0.88 | -757 | -36.1 |
| WOUNDS ON THE RANKS | 74 | 74 | 21 | 0.88 | +597 | +28.4 |
| HOLDER AT DEPLOYMENT | 42 | 42 | 20 | 0.83 | +1014 | +50.7 |
| MANOEUVRE | 47 | 47 | 20 | 0.83 | +605 | +30.3 |
| MODEL FACING | 20 | 20 | 20 | 0.83 | +5081 | +254.1 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.83 | +45 | +2.2 |
| AFTERMATH IN POINTS | 18 | 18 | 18 | 0.75 | +2439 | +135.5 |
| COMBAT PIVOT | 18 | 18 | 18 | 0.75 | +0 | +0.0 |
| TIED UP BY THE SUM | 28 | 28 | 18 | 0.75 | +727 | +40.4 |
| MARCH BY THE SUM | 17 | 17 | 17 | 0.71 | +1229 | +72.3 |
| NEARER NOT NEEDED | 241 | 231 | 15 | 0.62 | +595 | +39.7 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 15 | 0.62 | +733 | +48.9 |
| WHO HITS BACK | 15 | 15 | 15 | 0.62 | +2104 | +140.3 |
| CHAFF IN THE MOVE | 19 | 19 | 14 | 0.58 | +224 | +16.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.58 | -29 | -2.1 |
| FIRE IN ORDER | 14 | 14 | 14 | 0.58 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.58 | +0 | +0.0 |
| SURE REACH TOGETHER | 24 | 24 | 14 | 0.58 | +34 | +2.4 |
| HIS CHARGE DENIED | 21 | 21 | 13 | 0.54 | +320 | +24.6 |
| CAST JOB | 26 | 26 | 12 | 0.50 | +139 | +11.6 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.50 | +436 | +36.3 |
| ONE OBJECTIVE FORMULA | 174 | 156 | 12 | 0.50 | +464 | +38.7 |
| FIGHT TO THE END | 72 | 72 | 11 | 0.46 | +593 | +53.9 |
| ONE FIGHT FORMULA | 249 | 134 | 11 | 0.46 | +131 | +11.9 |
| SUPPORT NARROWED | 65 | 65 | 11 | 0.46 | -198 | -18.0 |
| FEATURE BUFFS | 61 | 61 | 10 | 0.42 | +143 | +14.3 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.38 | +673 | +74.8 |
| GUN MASK | 30 | 30 | 8 | 0.33 | +163 | +20.3 |
| AFTERMATH WITH FRIENDS | 7 | 7 | 7 | 0.29 | +526 | +75.1 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.29 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 7 | 0.29 | +187 | +26.7 |
| HUNT IN PAIRS | 23 | 8 | 6 | 0.25 | +378 | +63.1 |
| JOINT CHARGE NOW | 30 | 30 | 6 | 0.25 | +135 | +22.5 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.21 | +1 | +0.2 |
| OVERRUNS AWAY | 18 | 18 | 5 | 0.21 | +404 | +80.7 |
| REFUSING RETIRES | 9 | 9 | 5 | 0.21 | -2 | -0.3 |
| SET UP TOGETHER | 23 | 18 | 5 | 0.21 | +85 | +17.0 |
| WIDER SPREAD | 124 | 124 | 5 | 0.21 | +20 | +4.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.17 | +0 | +0.0 |
| HONEST WORTH | 158 | 158 | 4 | 0.17 | +22 | +5.6 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.17 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.17 | +170 | +42.5 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.12 | +0 | +0.0 |
| EDGE GIVE GROUND | 9 | 9 | 3 | 0.12 | +57 | +19.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.12 | +75 | +25.0 |
| OPENS UP | 9 | 9 | 3 | 0.12 | +36 | +12.1 |
| SPELLS IN THE FIGHT | 35 | 35 | 3 | 0.12 | +31 | +10.5 |
| WHOLE FIGHT | 7 | 7 | 3 | 0.12 | +68 | +22.6 |
| WHOLE FIGHT GAIN | 5 | 5 | 3 | 0.12 | +103 | +34.5 |
| FALL BACK GOOD ORDER | 135 | 135 | 2 | 0.08 | +45 | +22.3 |
| FALLBACK BY WORTH | 10 | 10 | 2 | 0.08 | +27 | +13.6 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.08 | +13 | +6.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.08 | +38 | +18.8 |
| HIS MOVE AND SHOT | 98 | 98 | 2 | 0.08 | +6 | +3.2 |
| KILLS COUNT | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| MISSILES NEXT TURN | 242 | 185 | 2 | 0.08 | +25 | +12.5 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.08 | +110 | +55.1 |
| NEEDED THERE | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.08 | -9 | -4.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.04 | -29 | -28.6 |
| BLOWS WHERE AIMED | 14 | 14 | 1 | 0.04 | +4 | +3.7 |
| MOVE SPELL IN RANGE | 9 | 5 | 1 | 0.04 | +39 | +39.2 |
| NO DOUBLE ROUNDS | 146 | 146 | 1 | 0.04 | +4 | +3.9 |
| OPENS A LANE | 9 | 6 | 1 | 0.04 | +3 | +2.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.04 | +99 | +99.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.04 | -15 | -14.7 |
| RUN DOWN | 136 | 136 | 1 | 0.04 | +2 | +2.2 |
| STAND AND SHOOT | 36 | 36 | 1 | 0.04 | +6 | +5.8 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.04 | -7 | -6.7 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 10 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 41 | 41 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 32 | 32 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 13 | 13 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 14 | 14 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 222 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 24 | 24 | 0 | 0.00 | - | - |
| GIVES UP | 19 | 19 | 0 | 0.00 | - | - |
| GUN FIGURES | 72 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 108 | 108 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 149 | 149 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 158 | 158 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 66 | 66 | 0 | 0.00 | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LONG SHOT | 12 | 12 | 0 | 0.00 | - | - |
| LOST CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 16 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 40 | 40 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT TURNED | 8 | 8 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 114 | 114 | 0 | 0.00 | - | - |
| PLAN RESULT | 2061 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 37 | 37 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOT OR CHARGE | 23 | 23 | 0 | 0.00 | - | - |
| SPELL WORTH | 69 | not checked | - | - | - | - |
| STANDS FOR A REASON | 24 | 24 | 0 | 0.00 | - | - |
| STANDS STILL | 826 | 826 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 235 | not checked | - | - | - | - |
| THE PROMISE ADDS | 5 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 20 | not checked | - | - | - | - |
| WAITS AGAIN | 72 | 72 | 0 | 0.00 | - | - |

### Off best figure: ja-opp-f9a8036-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOW FIRST | rule | 0.75 | 0.79 | 58.5 |
| PATHS CROSS | rule | 0.50 | 0.79 | 30.4 |
| CHARGE NOT DECLARED | rule | 0.62 | 0.46 | 152.2 |
| CANNON PLANNED TARGET | rule | 0.33 | 0.17 | 55.1 |
| JOB FIRST | gate | 0.42 | 0.08 | 27.2 |
| SUPPORT NARROWED | rule | 0.25 | 0.21 | 18.0 |
| CHAFF PASSED | rule | 0.25 | 0.04 | 4.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.08 | 100.5 |
| FALLBACK | gate | 0.08 | - | 2.4 |
| PIVOT GUARDS FLANK | rule | - | 0.08 | 4.5 |
| REFUSING RETIRES | rule | 0.08 | - | 0.6 |
| BEST PRIZE | rule | - | 0.04 | 28.6 |
| DEPLOY BY FIGURES | rule | 0.04 | - | 9.9 |
| FIGHT ORDER BAND | gate | 0.04 | - | 1.3 |
| PURSUES BIG PREY | rule | 0.04 | - | 14.7 |
| RULE SWITCHED OFF | gate | 0.04 | - | 22.4 |
| TURN GATE | gate | 0.04 | - | 0.9 |
| WAR ENGINE JOBS | rule | 0.04 | - | 6.7 |

### Plans: ja-opp-f9a8036-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.4 | 55% | 494 | 188 | 38% |
| Mine | join | 0.8 | 95% | 23 | 0 | 0% |
| Mine | move | 25.5 | 94% | 1423 | 0 | 0% |
| Mine | shoot | 12.4 | 61% | 518 | 911 | 176% |
| Mine | support | 0.2 | 75% | 2 | 0 | 0% |
| Opponent | charge | 4.0 | 64% | 704 | 413 | 59% |
| Opponent | join | 0.2 | 100% | 8 | 0 | 0% |
| Opponent | move | 32.6 | 94% | 1684 | 0 | 0% |
| Opponent | shoot | 7.2 | 66% | 383 | 411 | 107% |
| Opponent | support | 0.5 | 77% | 0 | 0 | - |

### Packages: hunt the guns, ja-opp-f9a8036-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 42 |
| Opponent | 0.1 | 3 | 0 | 100% | 100% | 0% | 2.0 | 414 | 362 | 100% | 104 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 377 |
| Ogre Kingdoms | 0.7 | 2 | 0 | 100% | 100% | 0% | 2.0 | 512 | 435 | 100% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 218 | 215 | 100% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 366 |

### Battle groups: ja-opp-f9a8036-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.4 | 24% | 62% | 0% | - | 25% | 0% | 12% | 62% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 18% | 79% | 36% | 20% | 33% | 0% | 11% | 56% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-opp-f9a8036-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 0 (9) | 0 | 0 | 32 | 89% | 2.0 | 0 (3) | 0 (3) | 0 (3) | 0 (7) | 0 (2) |
| Mine | Character | 89 | 43 (89) | 43 | 0 | 37 | 27% | 2.5 | 84 (25) | 22 (31) | 34 (20) | 46 (53) | 54 (23) |
| Mine | Clean-up | 13 | 46 (13) | 0 | 46 | 31 | 54% | 3.3 | 0 (2) | 0 (8) | 130 (3) | 57 (10) | 18 (3) |
| Mine | Fast Hammer | 34 | 37 (34) | 15 | 22 | 55 | 18% | 2.9 | 32 (13) | 37 (14) | 46 (7) | 37 (22) | 36 (12) |
| Mine | Hammer | 40 | 32 (40) | 21 | 12 | 36 | 35% | 2.6 | 41 (6) | 30 (26) | 33 (8) | 21 (30) | 60 (10) |
| Mine | Holder | 16 | 56 (16) | 0 | 56 | 25 | 38% | 3.1 | 38 (4) | 84 (8) | 0 (3) | 117 (8) | 0 (7) |
| Mine | Shooter | 32 | 96 (32) | 46 | 50 | 38 | 0% | 1.8 | 27 (9) | 127 (20) | 112 (3) | 102 (27) | 66 (5) |
| Mine | War machine | 57 | 36 (57) | 36 | 0 | 47 | 4% | 1.4 | 9 (19) | 22 (18) | 72 (20) | 22 (10) | 39 (47) |
| Mine | Wizard | 12 | 13 (12) | 13 | 0 | 13 | 25% | 2.0 | 20 (5) | 0 (2) | 12 (4) | 9 (6) | 22 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 58 | 98 (58) | 31 | 67 | 38 | 28% | 2.5 | 99 (18) | 137 (22) | 34 (18) | 103 (52) | 70 (6) |
| Opponent | Character | 61 | 54 (61) | 54 | 0 | 34 | 21% | 2.9 | 29 (22) | 51 (28) | 134 (7) | 49 (39) | 69 (18) |
| Opponent | Clean-up | 15 | 65 (15) | 21 | 45 | 51 | 53% | 2.3 | 34 (6) | 97 (9) | - | 72 (13) | 0 (2) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 27 | 41 (27) | 24 | 16 | 41 | 37% | 2.4 | 56 (7) | 39 (16) | 23 (4) | 49 (16) | 27 (11) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | 0 (1) | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Hammer | 42 | 29 (42) | 26 | 4 | 39 | 33% | 2.5 | 18 (9) | 33 (28) | 26 (5) | 38 (26) | 17 (16) |
| Opponent | Holder | 23 | 106 (23) | 20 | 86 | 16 | 22% | 2.8 | 170 (5) | 97 (12) | 76 (6) | 103 (14) | 113 (9) |
| Opponent | Shooter | 24 | 70 (24) | 14 | 55 | 20 | 0% | 1.9 | 10 (7) | 155 (10) | 17 (7) | 78 (16) | 56 (8) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 24 | 36 (24) | 36 | 0 | 21 | 12% | 1.4 | 59 (11) | 32 (5) | 6 (8) | 15 (3) | 38 (21) |
| Opponent | Wizard | 18 | 8 (18) | 8 | 0 | 36 | 0% | 1.8 | 0 (7) | 18 (7) | 0 (1) | 18 (6) | 0 (9) |

### Charged fights: ja-opp-f9a8036-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 77 | 18 | 1.2 | 1.2 | 14 | 0 | +14 | 4 of 5 | 4 of 5 | +0 | +18 |
| Mine | Chaos Dwarfs | 4 | 64 | 343 | 2.0 | 1.0 | 171 | 0 | +171 | 4 of 8 | 7 of 8 | - | +171 |
| Mine | Dwarfen Mountain Holds | 4 | 858 | 8 | 1.2 | 1.0 | 6 | 0 | +6 | 0 of 5 | 5 of 5 | - | +6 |
| Mine | Empire of Man | 5 | 213 | 47 | 0.8 | 1.0 | 59 | 0 | +59 | 2 of 4 | 4 of 4 | - | +59 |
| Mine | Grand Cathay | 4 | 458 | 303 | 3.0 | 1.0 | 101 | 17 | +84 | 4 of 12 | 11 of 12 | - | +84 |
| Mine | High Elf Realms | 3 | 161 | 298 | 5.3 | 1.1 | 56 | 87 | -31 | 6 of 16 | 10 of 16 | +44 | -36 |
| **Mine** | all armies | 24 | 307 | 159 | 2.1 | 1.0 | 76 | 32 | +44 | 20 of 50 | 41 of 50 | +22 | +45 |
| Opponent | Dwarfen Mountain Holds | 2 | 240 | 0 | 1.0 | 1.0 | 0 | 52 | -52 | 0 of 2 | 1 of 2 | - | -52 |
| Opponent | Empire of Man | 2 | 310 | 288 | 3.0 | 1.0 | 96 | 38 | +58 | 2 of 6 | 5 of 6 | - | +58 |
| Opponent | Grand Cathay | 2 | 182 | 560 | 4.5 | 1.0 | 125 | 0 | +125 | 2 of 9 | 9 of 9 | - | +125 |
| Opponent | Kingdom of Bretonnia | 1 | 165 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| Opponent | Ogre Kingdoms | 3 | 144 | 110 | 3.7 | 1.1 | 30 | 43 | -13 | 5 of 11 | 4 of 11 | +0 | -14 |
| Opponent | Skaven | 1 | 661 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 1 of 3 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 318 | 612 | 4.0 | 1.2 | 153 | 56 | +97 | 10 of 16 | 12 of 16 | +56 | +107 |
| Opponent | Vampire Counts | 3 | 0 | 312 | 4.7 | 1.2 | 67 | 85 | -18 | 7 of 14 | 10 of 14 | +42 | -35 |
| Opponent | Warriors of Chaos | 3 | 0 | 131 | 1.7 | 1.4 | 79 | 0 | +79 | 3 of 5 | 3 of 5 | +113 | +70 |
| Opponent | Wood Elf Realms | 3 | 41 | 543 | 3.7 | 1.3 | 148 | 22 | +126 | 4 of 11 | 6 of 11 | +52 | +143 |
| **Opponent** | all armies | 24 | 172 | 314 | 3.3 | 1.2 | 95 | 40 | +56 | 36 of 79 | 53 of 79 | +51 | +56 |

### Effective charges: ja-opp-f9a8036-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 2 (net +36) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 8 | 3 (net +373) | 0 | 0 | 0 | 1 (net +45) | 4 (net +52) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 2 (net +15) | 0 | 2 (net +0) | 1 | 0% (0 of 4) |
| Mine | Empire of Man | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +46) | 2 | 0% (0 of 2) |
| Mine | Grand Cathay | 12 | 2 (net -102) | 0 | 4 (net +101) | 0 | 3 (net +70) | 3 (net +198) | 0 | 33% (4 of 12) |
| Mine | High Elf Realms | 16 | 5 (net -191) | 0 | 2 (net -50) | 2 (net +35) | 3 (net +67) | 3 (net +54) | 1 | 13% (2 of 15) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net -105) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 6 | 1 (net -227) | 0 | 1 (net +0) | 2 (net +170) | 0 | 1 (net +95) | 1 | 20% (1 of 5) |
| Opponent | Grand Cathay | 9 | 0 | 0 | 1 (net +265) | 8 (net +107) | 0 | 0 | 0 | 11% (1 of 9) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 2 (net +52) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 11 | 5 (net +59) | 0 | 2 (net +0) | 0 | 0 | 1 (net +0) | 3 | 25% (2 of 8) |
| Opponent | Skaven | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 16 | 2 (net +27) | 0 | 5 (net +62) | 2 (net -33) | 0 | 6 (net +210) | 1 | 33% (5 of 15) |
| Opponent | Vampire Counts | 14 | 5 (net -77) | 0 | 3 (net -158) | 3 (net +15) | 2 (net +144) | 0 | 1 | 23% (3 of 13) |
| Opponent | Warriors of Chaos | 5 | 1 (net +0) | 1 (net +186) | 2 (net +104) | 0 | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Wood Elf Realms | 11 | 6 (net +128) | 0 | 0 | 2 (net +0) | 0 | 3 (net +207) | 0 | 0% (0 of 11) |

### Charged fights, damage counted: ja-opp-f9a8036-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 289 | 350 | -4 | 126 | 113 | +14 | +4.7 |
| Mine | Effective (55-75%) | 6 | 311 | 226 | +51 | 152 | 89 | +63 | +20.4 |
| Mine | 76-89% | 6 | 194 | 130 | +17 | 47 | 3 | +45 | +23.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 232 | 169 | +71 | 102 | 27 | +75 | +32.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 351 | 75 | +65 | 65 | 0 | +65 | +18.5 |
| Mine | No odds | 4 | 277 | 155 | +68 | 85 | 26 | +59 | +21.2 |
| Mine | All fights | 50 | 270 | 197 | +44 | 100 | 46 | +54 | +20.0 |
| Opponent | Long shot (under 50%) | 22 | 184 | 256 | +23 | 102 | 80 | +22 | +12.0 |
| Opponent | 50-54% | 1 | 135 | 186 | +186 | 186 | 45 | +141 | +104.4 |
| Opponent | Effective (55-75%) | 15 | 359 | 284 | +13 | 135 | 111 | +24 | +6.6 |
| Opponent | 76-89% | 20 | 295 | 164 | +64 | 103 | 8 | +95 | +32.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 | 363 | 178 | +152 | 167 | 13 | +154 | +42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 750 | 144 | +144 | 144 | 31 | +113 | +15.1 |
| Opponent | No odds | 6 | 247 | 298 | -5 | 92 | 104 | -11 | -4.6 |
| Opponent | All fights | 79 | 293 | 225 | +56 | 121 | 57 | +64 | +21.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-opp-f9a8036-p2 | move | 180 | 35 (19%) | 27 (15%) | 24 (13%) | 121 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Invocation of Nehek | Opponent | L0425, L0827 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

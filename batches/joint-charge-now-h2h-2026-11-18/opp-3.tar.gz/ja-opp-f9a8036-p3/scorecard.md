# Doctrine scorecard: ja-opp-f9a8036-p3

### Scorecard: ja-opp-f9a8036-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 165 |
| L0126 | 6 | 1 | Mine | yes | 17 | - | 0 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 9 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 4 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Opponent | no | 3 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 5 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 165 |
| L0327 | 3 | 1 | Mine | yes | 5 | 4 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0327 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 0 | 0 | 1 | 0 | 0 | 70 |
| L0429 | 3 | 1 | Mine | yes | 7 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 423 |
| L0516 | 6 | 1 | Opponent | no | 13 | 6 | 2 | 1 | 0 | 0 | 0 | 80 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 233 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 1 | 0 | 0 | 448 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 250 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 507 |
| L0725 | 5 | 1 | Mine | no | - | 6 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0725 | 5 | 1 | Opponent | yes | - | 4 | 4 | 4 | 1 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 175 |
| L0815 | 5 | 1 | Opponent | no | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 130 |
| L0831 | 3 | 1 | Opponent | no | 6 | 4 | 2 | 1 | 3 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 382 |
| L0922 | 4 | 1 | Opponent | yes | 4 | 2 | 2 | 3 | 3 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 165 |
| L1030 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 285 |
| L1122 | 6 | 1 | Mine | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1122 | 6 | 1 | Opponent | no | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 12 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 1 | 0 | 0 | 307 |
| L1327 | 1 | 1 | Mine | no | 14 | 3 | 3 | 0 | 0 | 0 | 0 | 70 |
| L1327 | 1 | 1 | Opponent | no | 5 | 2 | 4 | 3 | 0 | 0 | 0 | 75 |
| L1422 | 6 | 1 | Mine | no | 7 | 2 | 7 | 0 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 12 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 4 | 5 | 3 | 1 | 0 | 0 | 0 | 115 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 5.5 | 3.3 | 2.1 | 1.0 | 0.2 | 0.0 | 0.0 | 156.8 |
| **Average** | | | Opponent | 23% | 4.4 | 2.7 | 2.6 | 1.8 | 0.5 | 0.0 | 0.0 | 107.6 |

### KPIs: ja-opp-f9a8036-p3

Rules off - Mine only: JOINT CHARGE NOW, AFTERMATH WITH FRIENDS; both sides: HIS FIGHT TOGETHER, SET UP BY THE SET.

Morten 2026-11-10; 25 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (33 of 108) | 2% (3 of 121) | 16% (36 of 229) |
| Winner chose to follow up after the loser gave ground |  | 79% (31 of 39); on the table 82% | 95% (18 of 19); on the table 100% | 84% (49 of 58); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (4 of 6); on the table 67% | 44% (4 of 9); on the table 44% | 53% (8 of 15); on the table 53% |
| Winner chose to pursue after the loser fled |  | 71% (17 of 24); on the table 75% | 69% (9 of 13); on the table 69% | 70% (26 of 37); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 75% (52 of 69); on the table 78% | 76% (31 of 41); on the table 78% | 75% (83 of 110); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 28% (82 of 288) | 30% (53 of 174) | 29% (135 of 462) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (82 of 204) | 43% (53 of 123) | 41% (135 of 327) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (6 of 8) | 58% (19 of 33) | 61% (25 of 41) |
| Points that never fought | lower | 42% (20291 of 48695) | 47% (23422 of 49992) | 44% (43713 of 98687) |
|   infantry points that never fought | lower | 42% (4382 of 10506) | 53% (5345 of 10076) | 47% (9727 of 20582) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (117 of 202) | 67% (126 of 188) | 62% (243 of 390) |
| Bound items with a magic missile used (at least once a game) |  | 91% (21 of 23); 2.5 uses a game | 79% (11 of 14); 1.6 uses a game | 86% (32 of 37); 2.1 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.7 uses a game | 67% (4 of 6); 0.2 uses a game | 60% (12 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (9 of 17); 0.4 uses a game | 33% (3 of 9); 0.1 uses a game | 46% (12 of 26); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (21465 of 42125) | 63% (27558 of 43797) | 57% (49023 of 85922) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (24%) | 1.6 (32%) | 3.5 (27%) |
| MARCHED: its unit marched | 2.3 (28%) | 1.1 (22%) | 3.4 (26%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.7 (21%) | 1.1 (22%) | 2.8 (21%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.0 (1%) | 0.3 (2%) |
| FLEEING: fleeing | 0.2 (2%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.6 (8%) | 0.6 (13%) | 1.3 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (10%) | 0.3 (6%) | 1.1 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.5 | 3.0 | 5.4 | 0.6 | 1.8 |
| not cast | 3.4 | 1.4 | 4.5 | 13.1 | 3.0 | 21.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.8 (57%) | 0.2 (4%) | 3.5 (27%) | 0.5 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.4 (26%) | 0.6 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (6%) | 0.6 (13%) | 2.8 (21%) | 0.6 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.7 (16%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (3%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 0.3 (10%) | 0.0 (0%) | 0.4 (9%) | 1.3 (10%) | 0.2 (8%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (20%) | 0.4 (26%) | 0.5 (12%) | 1.1 (8%) | 0.1 (3%) | 2.1 (10%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (9%) | 0.1 (2%) | 0.2 (1%) | 0.8 (27%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (62%) | 0.0 (0%) | 2.0 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.9 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.9 a game | 1.1 a game | 1.5 a game |
| stood (cast and not dispelled) | 47% (20 of 43) | 36% (8 of 22) | 43% (28 of 65) |
| the unit moved after it | 90% (18 of 20) | 88% (7 of 8) | 89% (25 of 28) |
| it charged on its next turn | 5% (1 of 20) | 0% (0 of 8) | 4% (1 of 28) |
| the enemy charged it first | 5% (1 of 20) | 0% (0 of 8) | 4% (1 of 28) |
| it fought by the end of its next turn | 0% (0 of 20) | 0% (0 of 8) | 0% (0 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 20) | 0% (0 of 8) | 0% (0 of 28) |
| none of these (no charge, no fight, no charge escaped) | 90% (18 of 20) | 100% (8 of 8) | 93% (26 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (411 of 613) | 56% (272 of 483) | 62% (683 of 1096) |
|   cavalry | 68% (30 of 44) | 78% (56 of 72) | 74% (86 of 116) |
|   character | 56% (50 of 89) | 22% (19 of 88) | 39% (69 of 177) |
|   chariot | 62% (50 of 81) | 61% (23 of 38) | 61% (73 of 119) |
|   infantry | 69% (90 of 131) | 62% (115 of 186) | 65% (205 of 317) |
|   monster | 73% (8 of 11) | 33% (2 of 6) | 59% (10 of 17) |
|   war machine | 71% (183 of 257) | 61% (57 of 93) | 69% (240 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (25%) | 1.6 (18%) | 3.6 (22%) |
| CHARGED: it charged | 0.9 (11%) | 1.3 (15%) | 2.2 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.3 (4%) | 0.8 (5%) |
| MOVED: a war machine that moved | 1.9 (23%) | 0.8 (10%) | 2.7 (16%) |
| NO TARGET IN RANGE | 1.0 (12%) | 1.8 (21%) | 2.7 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 2.0 (24%) | 3.2 (20%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.4 | 80% | 6.4 pts | 36 pts |
| character | 3.4 | 1.2 | 80% | 6.8 pts | 23 pts |
| chariot | 3.0 | 2.3 | 59% | 18.9 pts | 56 pts |
| infantry | 12.2 | 4.2 | 74% | 9.4 pts | 115 pts |
| monster | 0.6 | 0.2 | 73% | 9.0 pts | 5 pts |
| war machine | 9.8 | 8.9 | 62% | 25.8 pts | 252 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.4 | 4.6 | 4.0 |
| Charges that made contact a game | 2.9 | 3.2 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.95 declared, 0.82 contact (22 units) | 0.89 declared, 0.79 contact (19 units) | 0.93 declared, 0.80 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.67 contact (3 units) | 1.33 declared, 0.67 contact (6 units) | 1.56 declared, 1.00 contact (9 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.33 contact (150 units) | 0.48 declared, 0.33 contact (186 units) | 0.44 declared, 0.33 contact (336 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (30 of 52) | 60% (6 of 10) | 86% (6 of 7) | 61% (42 of 69) |
| Character in a unit | 86% (24 of 28) | 80% (8 of 10) | 100% (1 of 1) | 85% (33 of 39) |
| Character on its own | 90% (18 of 20) | 56% (19 of 34) | 30% (14 of 47) | 50% (51 of 101) |
| Chariot | 100% (9 of 9) | 75% (9 of 12) | - | 86% (18 of 21) |
| Infantry | 59% (33 of 56) | 38% (10 of 26) | 75% (3 of 4) | 53% (46 of 86) |
| Monster | 69% (11 of 16) | 33% (1 of 3) | - | 63% (12 of 19) |
| Monstrous | 100% (4 of 4) | 83% (5 of 6) | - | 90% (9 of 10) |
| War Machines | 72% (31 of 43) | 50% (1 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (7 of 7); on the table 100% | 27% (26 of 96) | 41% | 55% (12 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 76% (13 of 17); on the table 82% | 42% (15 of 36) | 43% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 75% (3 of 4); on the table 75% | - | 58% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 46% (6 of 13); on the table 62% | 37% (11 of 30) | 41% | 64% (38 of 59) | 0.0 uses a game | 50% (1 of 2); 1.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 74% (14 of 19); on the table 74% | 30% (58 of 192) | 47% | 62% (46 of 74) | 89% (16 of 18); 6.8 uses a game | 75% (3 of 4); 0.5 uses a game | 62% (5 of 8); 0.6 uses a game |
| High Elf Realms | 7 | 84% (16 of 19); on the table 84% | 10% (4 of 42) | 35% | 59% (32 of 54) | 89% (8 of 9); 3.7 uses a game | 50% (6 of 12); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (1 of 1); on the table 100% | - | 46% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 18% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 41% | 14% (1 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 3 | 67% (6 of 9); on the table 67% | 17% (1 of 6) | 46% | 60% (9 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 100% (5 of 5); on the table 100% | 44% (16 of 36) | 54% | 57% (16 of 28) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 67% (8 of 12); on the table 67% | 0% (0 of 6) | 35% | 67% (22 of 33) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 77% | 82% (18 of 22) | 33% (1 of 3); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ja-opp-f9a8036-p3, 25 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (25) | 62% (29) | 57% (54) |
| ...free all their last turn and able to turn (per game) | 0.52 | 0.76 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.16 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.40 | 0.56 | 0.96 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.40 | 0.48 |

### Quality by phase: ja-opp-f9a8036-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.4 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 68% (53 of 78) | 54% (57 of 105) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (147 of 329) | 48% (62 of 130) |
| Strategy | Support requests answered (helper made contact too) | 100% (6 of 6) | 50% (4 of 8) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 73% (8 of 11) | 100% (4 of 4) |
| Strategy | Joined characters whose unit fought | 38% (15 of 40) | 22% (5 of 23) |
| Strategy | Lone characters that fought | 77% (46 of 60) | 72% (50 of 69) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 156.8 | 107.6 |
| Movement | Fights charged into per game | 2.6 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 64, net -88 | 16 of 71, net +122 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 64, net +163 | 9 of 71, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 64, net +47 | 9 of 71, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 64, net +98 | 20 of 71, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (129 of 248) | 43% (101 of 235) |
| Shooting | Points destroyed by shooting units | 55.2 | 25.5 |
| Shooting | War machine shots | 7.3 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (91 of 183) | 44% (27 of 62) |
| Shooting | Points destroyed by war machines | 82.8 | 16.6 |
| Magic | Magic missiles cast | 2.0 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (18 of 50) | 32% (12 of 38) |
| Magic | Wounds caused by magic missiles | 3.8 | 2.7 |
| Magic | Wounds caused by other spells | 2.9 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 101.2 | 24.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.8 / 0.2 | 2.0 / 0.2 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 180.6 | 295.9 |
| Combat | Points run down | 148.2 | 59.6 |
| Combat | Net points per charged fight, damage counted | +74 | +65 |
| Combat | Net per 100 charger points, damage counted | +27.4 | +20.6 |
| Combat | First round won (charged fights) | 86% | 66% |
| Combat | Net points per charged fight | +70 | +68 |
| Combat | Net points per supported fight / lone fight | +97 / +66 | -22 / +76 |
| Combat | Charged fights on a top-3 enemy unit | 20 of 65 | 29 of 74 |
| Game | Points lost | 520.0 | 626.7 |
| Game | VP from objectives | 616.4 | 603.6 |
| Game | Lone holders (player turns) | 5.5 | 4.4 |

- Mine won / drew / lost: 11 / 5 / 9 of 25 ended games (of 25); mean margin (Mine - Opponent) +167 VP
- The side that went first won 11 of 20 games with a winner
- Points traded per game (both sides' losses): 1147
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ja-opp-f9a8036-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 4.9 | 1.0 | +0.0 | 0.0 | 8.0 |
| AFTERMATH IN POINTS | 0.3 | +60.0 | 0.0 | 15.0 | 0.0 | +1.6 | 0.0 | 7.6 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.1 | +13.3 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 27.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.3 | 0.0 | 12.4 | 0.2 | +0.8 | 0.0 | 4.6 |
| BEST PRIZE | - | - | - | - | 0.0 | -3.4 | 5.6 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -5.3 | 6.3 | 0.0 | 0.1 | -12.1 | 12.9 | 0.0 |
| BOMBING RUN | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 11.0 | 0.1 | +0.0 | 0.0 | 6.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 78.9 | 10.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 7.3 | +124.3 | 325.4 | 130.8 | 1.8 | +50.6 | 42.2 | 39.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +30.2 | 43.8 | 6.8 | 0.4 | +11.7 | 36.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +33.9 | 13.8 | 12.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 28.4 | 0.5 | +0.0 | 0.0 | 25.4 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.1 | +3.1 | 0.0 | 8.8 | 0.5 | +14.5 | 0.0 | 8.0 |
| CHAFF PASSED | 0.2 | -1.0 | 0.0 | 0.0 | 0.2 | -0.6 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 7.6 | 0.3 | +0.0 | 0.0 | 10.4 |
| CHARGE LOSSES | 4.9 | -227.1 | 0.0 | 138.6 | 5.8 | -334.9 | 0.0 | 136.1 |
| CHARGE NOT DECLARED | 0.5 | +0.0 | 39.8 | 7.0 | 1.0 | +0.0 | 43.1 | 17.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 229.5 | 37.0 | 2.3 | +0.0 | 210.5 | 32.0 |
| CHARGER SLAIN LOST | 0.3 | -24.8 | 28.8 | 10.2 | 0.4 | -6.6 | 22.0 | 23.7 |
| CHEAPEST HOLDER | 0.2 | -2.3 | 0.0 | 0.0 | 0.3 | -14.0 | 24.8 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 15.7 | 21.2 | 0.3 | +0.0 | 2.2 | 11.2 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.2 | +0.0 | 10.4 | 17.2 |
| CONVEYANCE SEARCH | 1.3 | +133.1 | 12.9 | 14.2 | 0.6 | +12.0 | 0.0 | 11.0 |
| COVER ONCE | 8.8 | -710.2 | 0.0 | 85.2 | 6.1 | -447.7 | 0.0 | 128.0 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.8 | +2.0 | 0.0 | 8.2 | 7.4 | +56.4 | 0.0 | 49.5 |
| EDGE GIVE GROUND | 0.2 | +8.0 | 36.6 | 0.0 | 0.2 | +7.5 | 35.6 | 17.2 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.0 | +13.2 | 212.7 | 16.5 | 2.9 | +9.6 | 234.4 | 88.6 |
| FALLBACK BY WORTH | - | - | - | - | 0.4 | +0.0 | 0.0 | 8.6 |
| FALLS SHORT | 4.2 | +81.6 | 0.0 | 68.8 | 17.4 | +220.5 | 0.0 | 230.2 |
| FEATURE BUFFS | 1.6 | +37.6 | 0.0 | 20.6 | 0.7 | +12.4 | 0.0 | 4.4 |
| FIGHT LIFT | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.2 | +17.3 | 96.2 | 23.2 | 1.9 | +127.7 | 157.7 | 60.5 |
| FIRE IN ORDER | 0.4 | +0.0 | 22.8 | 4.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 45.5 | +2666.8 | 920.4 | 589.6 | 44.4 | +2824.0 | 490.4 | 647.6 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 76.6 | 4.9 | +0.0 | 0.0 | 107.8 |
| FOCUS FIRE | 0.1 | +6.6 | 8.2 | 0.0 | 0.0 | +1.6 | 4.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +140.6 | 0.0 | 17.7 | 0.5 | +146.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +287.4 | 305.8 | 48.6 | 4.2 | +492.0 | 313.3 | 101.4 |
| FRIEND CHARGES FIRST | 0.1 | -27.3 | 0.0 | 0.0 | 0.3 | -27.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -13.4 | 0.0 | 0.0 | 0.2 | -16.4 | 0.0 | 4.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +13.5 | 0.0 | 7.6 | 0.1 | +5.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.2 | 12.6 | 0.0 | 0.2 | -2.6 | 12.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.5 | 0.0 | 1.8 |
| GROUND FLIERS | 0.1 | +4.3 | 0.0 | 0.0 | 0.0 | +2.1 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +10.4 | 27.9 | 12.4 | 0.4 | +1.5 | 8.4 | 10.6 |
| GUN MASK | 1.0 | +25.7 | 0.0 | 0.0 | 0.6 | +15.3 | 0.0 | 10.6 |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 16.3 |
| HE SHOOTS OR CHARGES | 1.9 | +0.0 | 0.0 | 71.0 | 2.4 | +0.0 | 0.0 | 49.3 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +10.8 | 34.8 | 23.4 | 0.4 | +22.1 | 34.9 | 8.2 |
| HIS CHARGE LIST | 3.8 | +0.0 | 0.0 | 45.1 | 3.7 | +0.0 | 0.0 | 79.6 |
| HIS LEGAL MOVES | 4.4 | +0.0 | 0.0 | 60.6 | 3.6 | +0.0 | 0.0 | 39.8 |
| HIS MOVE AND SHOT | 1.9 | -38.7 | 0.0 | 47.7 | 1.8 | -50.5 | 0.0 | 46.7 |
| HIS RANDOM MOVE | 2.6 | +0.0 | 0.0 | 20.0 | 0.9 | +0.0 | 0.0 | 1.6 |
| HIS SHOT LIST | 17.2 | +681.1 | 0.0 | 261.7 | 24.8 | +1588.1 | 0.0 | 387.2 |
| HIS TURN DENIED | 1.0 | +39.3 | 89.1 | 20.8 | 2.4 | +126.9 | 200.0 | 84.7 |
| HOLDER AT DEPLOYMENT | 0.7 | +121.7 | 0.0 | 0.0 | 0.9 | +151.3 | 0.0 | 3.2 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -105.2 | 280.0 | 31.8 | 3.6 | -171.9 | 284.2 | 50.0 |
| HUNT IN PAIRS | 0.2 | +7.3 | 0.0 | 0.0 | 0.4 | +20.3 | 0.0 | 7.8 |
| HUNT RESULT | 0.0 | +8.3 | 0.0 | 0.0 | 0.1 | +14.9 | 0.0 | 6.4 |
| HUNT THE GUNS | 0.1 | +20.0 | 10.0 | 0.0 | 0.1 | +18.2 | 8.4 | 6.4 |
| IDLE COST | 1.9 | -25.9 | 0.0 | 22.6 | 11.1 | -194.5 | 0.0 | 101.2 |
| JOINT CHARGE NOW | - | - | - | - | 0.8 | +50.1 | 40.9 | 23.2 |
| JOINT KNOWS CHALLENGE | 0.0 | -4.7 | 10.4 | 0.0 | 0.2 | -3.1 | 15.1 | 17.2 |
| KEEP FALLS | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +0.9 | 3.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +21.5 | 0.0 | 0.0 | 1.2 | +61.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.2 | +0.0 | 185.0 | 190.9 | 5.3 | +0.0 | 130.8 | 428.1 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +46.2 | 0.0 | 3.8 | 0.5 | +35.7 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -1.0 | 11.1 | 0.0 | 0.1 | +0.8 | 4.6 | 8.9 |
| LOST CHARGE | 0.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.0 | -5.2 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +4.0 | 0.0 | 25.4 | 0.2 | +4.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.6 | +19.6 | 0.0 | 34.6 | 1.2 | +30.2 | 0.0 | 12.3 |
| MARCH AT ESCAPER | 0.2 | +1.5 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +47.7 | 0.0 | 0.0 | 0.3 | +5.6 | 0.0 | 8.0 |
| MARCH CHECK | 1.0 | +66.3 | 0.0 | 16.2 | 1.0 | +35.4 | 0.0 | 18.3 |
| MARCH OVER CASTS | 1.3 | +92.3 | 0.0 | 18.6 | 0.6 | +39.7 | 0.0 | 23.7 |
| MAX FOR POSITIONING | 6.7 | +87.0 | 0.0 | 118.8 | 6.6 | +86.1 | 0.0 | 103.7 |
| MISSILES IN THE MOVE | 5.6 | +216.6 | 0.0 | 121.8 | 3.9 | +57.7 | 0.0 | 45.8 |
| MISSILES NEXT TURN | 7.0 | +144.0 | 0.0 | 132.0 | 4.9 | +40.5 | 0.0 | 76.2 |
| MODEL FACING | 0.2 | +46.1 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.3 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -30.6 | 0.0 | 0.0 | 0.1 | -5.3 | 0.0 | 9.4 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.9 | +629.2 | 0.0 | 37.9 | 4.8 | +737.0 | 0.0 | 41.1 |
| MOVES UNITS SPELL | 0.2 | +5.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.6 | +233.9 | 0.0 | 43.6 | 3.8 | +179.6 | 0.0 | 20.4 |
| NEEDED THERE | 0.1 | +12.3 | 3.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.1 | -104.8 | 13.9 | 42.8 | 6.4 | -206.9 | 17.2 | 96.5 |
| NEXT OBJECTIVE NEARER | 6.4 | -311.8 | 69.2 | 85.7 | 7.9 | -318.3 | 44.7 | 89.0 |
| NO DOUBLE ROUNDS | 2.5 | -111.7 | 226.3 | 48.6 | 3.3 | -159.6 | 253.9 | 80.7 |
| NO RALLY LEFT | 0.1 | +7.6 | 0.0 | 6.5 | - | - | - | - |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | -0.0 | 0.0 | 2.2 |
| NOT WORTH A CAST | 0.4 | -0.1 | 0.0 | 15.8 | 0.2 | -0.1 | 0.0 | 16.0 |
| OFF BEST | 0.1 | -1.2 | 0.0 | 0.0 | 0.6 | -21.3 | 0.0 | 7.8 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 66.1 | 3.0 | +0.0 | 0.0 | 53.7 |
| ONE FIGHT FORMULA | 5.5 | -127.7 | 0.0 | 90.5 | 5.8 | -133.6 | 0.0 | 107.1 |
| ONE OBJECTIVE FORMULA | 3.8 | +22.2 | 0.0 | 58.6 | 3.3 | -2.7 | 0.0 | 23.1 |
| ONE TARGET A SHOOTER | 13.0 | +298.3 | 0.0 | 161.4 | 20.8 | +750.7 | 0.0 | 325.8 |
| OPENS A LANE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +1.1 | 27.6 | 0.0 |
| OPENS UP | 0.2 | +16.7 | 9.3 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +22.5 | 60.4 | 9.6 | 0.6 | +29.6 | 31.2 | 23.8 |
| PATHS CROSS | 3.4 | +110.0 | 0.0 | 36.9 | 5.0 | +205.1 | 0.0 | 22.4 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.0 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 39.9 | +991.9 | 432.6 | 781.0 | 39.9 | +462.6 | 225.8 | 835.2 |
| RANDOM MOVE BY FIGURES | 0.3 | +2.8 | 0.0 | 20.4 | 1.3 | +17.8 | 0.0 | 44.0 |
| REDIRECT BY WHAT IT STOPS | 0.0 | -0.4 | 0.0 | 0.0 | 0.3 | -11.0 | 0.0 | 4.4 |
| REDIRECT COUNTER | 1.6 | +111.8 | 0.0 | 42.5 | 2.8 | +331.3 | 0.0 | 52.0 |
| REDIRECT WEIGHED | 0.2 | +1.5 | 4.4 | 0.0 | 0.1 | -3.4 | 5.6 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -30.1 | 0.0 | 0.0 | 0.7 | -17.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +4.5 | 0.0 | 5.4 | 1.0 | +39.0 | 0.0 | 7.9 |
| RESTRAINS TO SHOOT | 0.2 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.4 | +87.3 | 208.3 | 48.6 | 2.5 | +31.8 | 172.4 | 73.4 |
| RISK BY HIS FIGURE | 13.0 | -190.6 | 0.0 | 225.1 | 13.0 | -240.1 | 0.0 | 291.2 |
| RUN DOWN | 2.1 | -23.2 | 177.1 | 25.2 | 3.2 | -47.2 | 230.3 | 78.9 |
| SAME CHARGE LATER | 0.0 | -0.9 | 0.0 | 0.0 | 0.2 | -2.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -22.1 | 0.0 | 2.6 |
| SEARCH SPOT | 5.5 | +309.4 | 0.0 | 75.6 | 5.5 | +232.4 | 0.0 | 48.0 |
| SELF MOVE SPELL | 0.4 | +41.1 | 0.0 | 31.6 | 0.4 | +93.6 | 0.0 | 26.1 |
| SET UP TOGETHER | 0.4 | +4.0 | 0.0 | 25.4 | 0.4 | +6.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +13.7 | 0.0 | 0.0 | 0.1 | +26.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +46.9 | 57.4 | 6.5 | 0.7 | +14.9 | 36.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.4 | -23.7 | 38.2 | 13.9 | 0.3 | -5.2 | 15.4 | 8.4 |
| SHOT RISK POINTS | 9.0 | +64.6 | 0.0 | 220.5 | 14.0 | +42.5 | 0.0 | 219.2 |
| SHOTS IN THE MOVE | 17.4 | +731.7 | 0.0 | 263.0 | 11.7 | +318.7 | 0.0 | 164.5 |
| SPELL SETS UP CHARGE | 0.2 | +25.2 | 0.0 | 0.0 | 0.1 | +26.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +16.9 | 0.0 | 14.2 | 2.4 | +43.4 | 97.5 | 85.0 |
| SPELLS IN THE FIGHT | 0.5 | +7.0 | 57.8 | 22.0 | 0.6 | -10.3 | 40.7 | 42.8 |
| STAND AND SHOOT | 0.5 | -2.9 | 47.6 | 9.6 | 0.6 | -5.3 | 40.9 | 8.9 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 6.4 | 15.7 |
| STANDS STILL | 19.4 | +0.0 | 614.6 | 242.3 | 9.7 | +0.0 | 177.0 | 111.4 |
| STAY WORTH | 19.6 | -15.4 | 258.4 | 218.6 | 11.0 | +68.4 | 74.9 | 52.5 |
| STOPS | 0.1 | +5.1 | 10.0 | 0.0 | 0.1 | +7.6 | 8.4 | 6.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 13.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.4 | +0.0 | 124.4 | 37.0 | 1.3 | +0.0 | 88.1 | 46.8 |
| SURE REACH TOGETHER | 0.4 | +10.4 | 0.0 | 5.7 | 0.8 | +8.6 | 0.0 | 16.2 |
| THE DEARER SUM KEEPS ITS PLAN | 3.9 | +0.0 | 0.0 | 43.1 | 5.0 | +0.0 | 0.0 | 22.4 |
| THE PROMISE ADDS | 0.1 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.8 | +80.6 | 60.6 | 0.0 | 1.0 | +110.3 | 79.4 | 3.0 |
| TIME ON OUR SIDE | 25.0 | +415.3 | 37.0 | 233.5 | 7.0 | +100.6 | 0.0 | 65.1 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 26.4 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +19.0 | 22.8 | 0.0 | 0.0 | +2.0 | 0.0 | 3.0 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 7.4 | 12.4 | 0.0 | +0.0 | 0.0 | 3.0 |
| WHO HITS BACK | 0.3 | +91.4 | 0.0 | 14.2 | 0.4 | +41.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +2.8 | 69.6 | 0.0 | 0.2 | +16.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +9.9 | 15.8 | 2.4 | 0.2 | +8.2 | 11.4 | 1.8 |
| WIDER SPREAD | 1.9 | -6.7 | 211.1 | 37.5 | 2.9 | -8.5 | 220.2 | 80.7 |
| WOUNDS ON THE RANKS | 0.8 | +20.2 | 0.0 | 10.4 | 1.2 | +39.2 | 0.0 | 37.8 |

### Rule changes: ja-opp-f9a8036-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1049 | 1049 | 304 | 12.16 | +9772 | +32.1 |
| SEARCH SPOT | 275 | 275 | 264 | 10.56 | +13547 | +51.3 |
| DEPLOY BY FIGURES | 380 | 380 | 248 | 9.92 | +3898 | +15.7 |
| LEGAL CHARGES ONLY | 238 | 238 | 238 | 9.52 | +0 | +0.0 |
| FIVE ACTION | 2248 | 2248 | 227 | 9.08 | +12148 | +53.5 |
| ONE TARGET A SHOOTER | 846 | 846 | 214 | 8.56 | +3153 | +14.7 |
| PATHS CROSS | 211 | 211 | 211 | 8.44 | +7879 | +37.3 |
| MOVE TO CHARGE COMPUTED | 218 | 218 | 146 | 5.84 | +15106 | +103.5 |
| TIME ON OUR SIDE | 799 | 695 | 122 | 4.88 | +578 | +4.7 |
| FOUR ROUNDS | 181 | 181 | 101 | 4.04 | +7617 | +75.4 |
| SHOT RISK POINTS | 575 | 575 | 98 | 3.92 | +4475 | +45.7 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 2.72 | +0 | +0.0 |
| MAX FOR POSITIONING | 333 | 323 | 68 | 2.72 | +332 | +4.9 |
| COVER ONCE | 373 | 290 | 67 | 2.68 | +1344 | +20.1 |
| HARD STAY DROPPED | 67 | 67 | 67 | 2.68 | +0 | +0.0 |
| ADVANCE LANE KEPT | 51 | 51 | 51 | 2.04 | +0 | +0.0 |
| SHOTS IN THE MOVE | 729 | 693 | 50 | 2.00 | +1370 | +27.4 |
| LANE BY FIGURES | 48 | 48 | 48 | 1.92 | +2074 | +43.2 |
| RISK BY ARC | 124 | 124 | 47 | 1.88 | +859 | +18.3 |
| NEXT OBJECTIVE NEARER | 356 | 356 | 44 | 1.76 | +900 | +20.5 |
| MANOEUVRE | 69 | 69 | 43 | 1.72 | +1427 | +33.2 |
| CANNON PLANNED TARGET | 228 | 228 | 42 | 1.68 | -516 | -12.3 |
| CANNON SIGHT KEPT | 41 | 41 | 41 | 1.64 | +0 | +0.0 |
| TIED UP BY THE SUM | 45 | 45 | 41 | 1.64 | +1590 | +38.8 |
| SHOOTS FROM THE BEST SPOT | 49 | 49 | 38 | 1.52 | +429 | +11.3 |
| CHARGE NOT DECLARED | 37 | 37 | 37 | 1.48 | -6387 | -172.6 |
| FOLLOW UP WEIGHED | 37 | 37 | 37 | 1.48 | +7186 | +194.2 |
| MARCH CHECK | 48 | 48 | 37 | 1.48 | +810 | +21.9 |
| IDLE COST | 325 | 263 | 34 | 1.36 | +365 | +10.7 |
| FALLS SHORT | 539 | 472 | 33 | 1.32 | +108 | +3.3 |
| RESERVE FALL BACK | 31 | 31 | 31 | 1.24 | +1088 | +35.1 |
| MISSILES IN THE MOVE | 237 | 194 | 30 | 1.20 | +1048 | +34.9 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 1.08 | +2047 | +75.8 |
| CHARGE LOSSES | 269 | 269 | 26 | 1.04 | +3608 | +138.8 |
| NEXT CHARGE BY LIST | 286 | 286 | 26 | 1.04 | +1008 | +38.8 |
| RISK BY HIS FIGURE | 649 | 649 | 26 | 1.04 | +2738 | +105.3 |
| HIS TURN DENIED | 86 | 86 | 25 | 1.00 | +785 | +31.4 |
| RANDOM MOVE BY FIGURES | 41 | 41 | 25 | 1.00 | +517 | +20.7 |
| MARCH BY THE SUM | 24 | 24 | 24 | 0.96 | +1332 | +55.5 |
| REDIRECT COUNTER | 111 | 99 | 24 | 0.96 | +2507 | +104.4 |
| CAST JOB | 28 | 28 | 21 | 0.84 | +244 | +11.6 |
| CHARGE NOW FIRST | 107 | 107 | 21 | 0.84 | -884 | -42.1 |
| HOLDS AMBUSHERS | 21 | 21 | 21 | 0.84 | +0 | +0.0 |
| OFF BEST | 18 | 18 | 18 | 0.72 | -561 | -31.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.72 | +35 | +1.9 |
| WHO HITS BACK | 17 | 17 | 17 | 0.68 | +1992 | +117.1 |
| SCOUT WAITS | 16 | 16 | 16 | 0.64 | +0 | +0.0 |
| STAY WORTH | 764 | 737 | 16 | 0.64 | +123 | +7.7 |
| COMBAT PIVOT | 14 | 14 | 14 | 0.56 | +0 | +0.0 |
| FIRE IN ORDER | 14 | 14 | 14 | 0.56 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 40 | 40 | 14 | 0.56 | +668 | +47.7 |
| ONE OBJECTIVE FORMULA | 176 | 152 | 14 | 0.56 | +433 | +31.0 |
| FIGHT TO THE END | 76 | 76 | 13 | 0.52 | +1204 | +92.6 |
| NEARER NOT NEEDED | 210 | 204 | 13 | 0.52 | +552 | +42.5 |
| SURE REACH TOGETHER | 30 | 30 | 12 | 0.48 | +24 | +2.0 |
| CHAFF IN THE MOVE | 16 | 16 | 11 | 0.44 | +0 | +0.0 |
| FEATURE BUFFS | 58 | 58 | 11 | 0.44 | +195 | +17.7 |
| ONE FIGHT FORMULA | 283 | 140 | 11 | 0.44 | +55 | +5.0 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.40 | +0 | +0.0 |
| CHAFF PASSED | 9 | 9 | 9 | 0.36 | -41 | -4.6 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.36 | +464 | +51.6 |
| OVERRUNS AWAY | 26 | 26 | 9 | 0.36 | +294 | +32.6 |
| SUPPORT NARROWED | 66 | 66 | 9 | 0.36 | -127 | -14.1 |
| AFTERMATH IN POINTS | 8 | 8 | 8 | 0.32 | +1541 | +192.6 |
| FALL BACK GOOD ORDER | 123 | 123 | 8 | 0.32 | +162 | +20.3 |
| WOUNDS ON THE RANKS | 50 | 50 | 8 | 0.32 | +93 | +11.7 |
| CASTING BLOCK | 9 | 9 | 7 | 0.28 | +62 | +8.9 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.24 | +0 | +0.0 |
| HIS MOVE AND SHOT | 93 | 93 | 6 | 0.24 | +182 | +30.3 |
| HONEST WORTH | 157 | 157 | 6 | 0.24 | +163 | +27.1 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.24 | +136 | +22.7 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.24 | +563 | +93.8 |
| CONTINUE AHEAD WEIGHED | 5 | 5 | 5 | 0.20 | +0 | +0.0 |
| MODEL FACING | 5 | 5 | 5 | 0.20 | +1153 | +230.6 |
| OPENS UP | 6 | 6 | 5 | 0.20 | +169 | +33.7 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.20 | +0 | +0.0 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.16 | +0 | +0.1 |
| GUN MASK | 38 | 38 | 4 | 0.16 | +92 | +23.0 |
| HIS CHARGE DENIED | 19 | 19 | 4 | 0.16 | +35 | +8.8 |
| JOINT CHARGE NOW | 19 | 19 | 4 | 0.16 | +522 | +130.4 |
| KEEP FALLS | 4 | 4 | 4 | 0.16 | +120 | +30.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.16 | +218 | +54.5 |
| STUCK PIVOT | 4 | 4 | 4 | 0.16 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 9 | 9 | 4 | 0.16 | +142 | +35.4 |
| WIDER SPREAD | 121 | 121 | 4 | 0.16 | +22 | +5.5 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 0.12 | +332 | +110.8 |
| EDGE GIVE GROUND | 11 | 11 | 3 | 0.12 | +97 | +32.4 |
| FOCUS FIRE | 3 | 3 | 3 | 0.12 | +206 | +68.8 |
| MISSILES NEXT TURN | 298 | 219 | 3 | 0.12 | +7 | +2.5 |
| REFUSING RETIRES | 7 | 7 | 3 | 0.12 | -1 | -0.2 |
| WAR ENGINE CHARGES | 3 | 3 | 3 | 0.12 | +141 | +47.0 |
| KILLS COUNT | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.08 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 145 | 145 | 2 | 0.08 | +22 | +10.8 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.08 | +104 | +52.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.04 | -85 | -84.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.04 | +27 | +27.1 |
| DEFENSIVE ARMY | 1 | 1 | 1 | 0.04 | -32 | -32.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 8 | 7 | 1 | 0.04 | +14 | +13.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.04 | -32 | -32.2 |
| SET UP TOGETHER | 19 | 14 | 1 | 0.04 | +10 | +10.5 |
| SPELLS IN THE FIGHT | 29 | 29 | 1 | 0.04 | +4 | +4.5 |
| STOPS | 4 | 4 | 1 | 0.04 | +118 | +118.3 |
| WAR ENGINE JOBS | 7 | 7 | 1 | 0.04 | -68 | -68.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 10 | 6 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 18 | 18 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 12 | 12 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 256 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| GUN FIGURES | 34 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 107 | 107 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 187 | 187 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 200 | 200 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 87 | 87 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 15 | 8 | 0 | 0.00 | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 6 | 6 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 14 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 48 | 48 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT TURNED | 12 | 12 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 149 | 149 | 0 | 0.00 | - | - |
| OPENS A LANE | 7 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 1995 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 35 | 35 | 0 | 0.00 | - | - |
| RUN DOWN | 131 | 131 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOT OR CHARGE | 17 | 17 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 7 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STAND AND SHOOT | 28 | 28 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 727 | 727 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 222 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 23 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 75 | 75 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: ja-opp-f9a8036-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.48 | 0.96 | 177.4 |
| PATHS CROSS | rule | 0.48 | 0.48 | 33.1 |
| CHARGE NOW FIRST | rule | 0.36 | 0.48 | 42.1 |
| JOB FIRST | gate | - | 0.44 | 46.7 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.12 | 67.8 |
| SUPPORT NARROWED | rule | 0.20 | 0.12 | 15.8 |
| CHAFF PASSED | rule | 0.08 | 0.12 | 8.2 |
| FALLBACK | gate | - | 0.12 | 5.2 |
| RULE SWITCHED OFF | gate | 0.08 | - | 9.4 |
| AFTERMATH BAND | gate | - | 0.04 | 2.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.04 | - | 11.0 |
| BEST PRIZE | rule | - | 0.04 | 84.6 |
| DEFENSIVE ARMY | rule | 0.04 | - | 32.5 |
| DEPLOY BY FIGURES | rule | - | 0.04 | 4.0 |
| PIVOT GUARDS FLANK | rule | - | 0.04 | 32.2 |
| WAR ENGINE JOBS | rule | 0.04 | - | 68.3 |

### Plans: ja-opp-f9a8036-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 64% | 405 | 296 | 73% |
| Mine | join | 0.2 | 100% | 7 | 0 | 0% |
| Mine | move | 25.8 | 95% | 1665 | 0 | 0% |
| Mine | shoot | 11.0 | 61% | 384 | 696 | 181% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | charge | 3.2 | 49% | 707 | 255 | 36% |
| Opponent | join | 1.0 | 96% | 50 | 0 | 0% |
| Opponent | move | 31.4 | 95% | 1685 | 0 | 0% |
| Opponent | shoot | 3.7 | 58% | 155 | 210 | 136% |
| Opponent | support | 0.5 | 75% | 0 | 0 | - |

### Packages: hunt the guns, ja-opp-f9a8036-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 100% | 100% | 0% | 2.0 | 292 | 208 | 100% | 22 |
| Opponent | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.0 | 227 | 186 | 100% | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 80 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.3 | 2 | 1 | 100% | 100% | 0% | 2.0 | 292 | 208 | 100% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 25 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 144 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 99 | 94 | 100% | 15 |
| Warriors of Chaos | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 355 | 278 | 100% | 192 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |

### Battle groups: ja-opp-f9a8036-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 30% | 42% | 17% | 50% | 30% | 10% | 10% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 2.8 | 27% | 95% | 11% | 50% | 0% | 0% | 41% | 59% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ja-opp-f9a8036-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 12 | 21 (12) | 0 | 21 | 57 | 50% | 3.7 | 0 (5) | 44 (6) | 0 (1) | 0 (7) | 48 (5) |
| Mine | Character | 90 | 54 (90) | 53 | 1 | 21 | 21% | 2.5 | 56 (34) | 48 (33) | 84 (12) | 68 (47) | 43 (32) |
| Mine | Clean-up | 10 | 92 (10) | 15 | 77 | 50 | 20% | 3.1 | 139 (4) | 66 (6) | - | 109 (7) | 15 (3) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 36 | 40 (36) | 16 | 24 | 31 | 33% | 2.8 | 35 (19) | 40 (14) | 63 (3) | 48 (24) | 20 (12) |
| Mine | Hammer | 36 | 37 (36) | 24 | 13 | 27 | 14% | 2.5 | 34 (15) | 37 (17) | 57 (4) | 32 (24) | 46 (12) |
| Mine | Holder | 17 | 36 (17) | 0 | 36 | 13 | 53% | 3.4 | 39 (9) | 45 (6) | 0 (2) | 43 (10) | 24 (7) |
| Mine | Shooter | 29 | 65 (29) | 25 | 40 | 47 | 7% | 1.6 | 38 (8) | 73 (16) | 75 (5) | 65 (24) | 63 (5) |
| Mine | War machine | 50 | 34 (50) | 34 | 0 | 35 | 2% | 1.4 | 35 (21) | 34 (28) | 0 (1) | 30 (15) | 36 (35) |
| Mine | Wizard | 10 | 0 (10) | 0 | 0 | 14 | 40% | 2.5 | 0 (4) | 0 (3) | 0 (3) | 0 (2) | 0 (8) |
| Opponent | Chaff | 47 | 98 (47) | 5 | 93 | 48 | 49% | 2.8 | 102 (18) | 100 (22) | 71 (7) | 91 (35) | 120 (12) |
| Opponent | Character | 69 | 43 (69) | 43 | 0 | 23 | 22% | 2.6 | 32 (24) | 46 (31) | 75 (10) | 59 (35) | 28 (30) |
| Opponent | Clean-up | 13 | 52 (13) | 21 | 31 | 48 | 23% | 3.8 | 10 (6) | 102 (5) | 46 (2) | 93 (8) | 0 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 35 | 24 (35) | 15 | 9 | 43 | 46% | 2.7 | 20 (12) | 26 (20) | 34 (3) | 34 (19) | 12 (16) |
| Opponent | Hammer | 28 | 16 (28) | 6 | 10 | 42 | 32% | 3.2 | 0 (8) | 23 (15) | 14 (5) | 4 (18) | 36 (10) |
| Opponent | Holder | 29 | 77 (29) | 10 | 68 | 33 | 24% | 2.8 | 10 (7) | 144 (12) | 49 (10) | 87 (24) | 21 (5) |
| Opponent | Shooter | 19 | 33 (19) | 12 | 21 | 24 | 5% | 2.1 | 45 (8) | 28 (10) | 0 (1) | 44 (15) | 0 (4) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 5.5 | 0 (1) | 0 (2) | 0 (1) | - | 0 (4) |
| Opponent | War machine | 17 | 26 (17) | 26 | 0 | 46 | 0% | 1.9 | 15 (9) | 29 (7) | 100 (1) | 23 (4) | 27 (13) |
| Opponent | Wizard | 23 | 0 (23) | 0 | 0 | 41 | 13% | 2.4 | 0 (5) | 0 (7) | 0 (4) | 0 (4) | 0 (12) |

### Charged fights: ja-opp-f9a8036-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 122 | 25 | 0.8 | 1.0 | 33 | 17 | +16 | 1 of 3 | 2 of 3 | - | +16 |
| Mine | Chaos Dwarfs | 4 | 153 | 528 | 2.2 | 1.1 | 234 | 0 | +234 | 5 of 9 | 7 of 9 | +280 | +229 |
| Mine | Dwarfen Mountain Holds | 3 | 266 | 166 | 1.3 | 1.8 | 124 | 62 | +62 | 1 of 4 | 3 of 4 | -19 | +144 |
| Mine | Empire of Man | 5 | 459 | 296 | 2.4 | 1.2 | 123 | 40 | +83 | 5 of 12 | 11 of 12 | +166 | +56 |
| Mine | Grand Cathay | 5 | 302 | 188 | 4.8 | 1.0 | 39 | 28 | +12 | 3 of 24 | 20 of 24 | - | +12 |
| Mine | High Elf Realms | 4 | 70 | 264 | 3.2 | 1.1 | 81 | 16 | +65 | 5 of 13 | 13 of 13 | -60 | +76 |
| **Mine** | all armies | 25 | 239 | 247 | 2.6 | 1.1 | 95 | 25 | +70 | 20 of 65 | 56 of 65 | +97 | +66 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 284 | 214 | 3.7 | 1.1 | 58 | 0 | +58 | 4 of 11 | 9 of 11 | +0 | +64 |
| Opponent | High Elf Realms | 3 | 0 | 121 | 2.7 | 1.1 | 45 | 43 | +2 | 3 of 8 | 7 of 8 | -347 | +52 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 249 | 3.0 | 1.2 | 83 | 0 | +83 | 3 of 6 | 3 of 6 | +190 | +62 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 241 | 3.0 | 1.0 | 80 | 326 | -246 | 1 of 3 | 3 of 3 | - | -246 |
| Opponent | Skaven | 1 | 105 | 0 | 1.0 | 1.0 | 0 | 38 | -38 | 1 of 1 | 0 of 1 | - | -38 |
| Opponent | Tomb Kings of Khemri | 3 | 107 | 709 | 3.3 | 1.0 | 213 | 0 | +213 | 5 of 10 | 7 of 10 | - | +213 |
| Opponent | Vampire Counts | 5 | 6 | 533 | 4.0 | 1.1 | 133 | 29 | +104 | 4 of 20 | 12 of 20 | +9 | +121 |
| Opponent | Warriors of Chaos | 4 | 11 | 259 | 2.5 | 1.0 | 104 | 110 | -6 | 6 of 10 | 5 of 10 | - | -6 |
| Opponent | Wood Elf Realms | 2 | 105 | 260 | 2.5 | 1.0 | 104 | 0 | +104 | 2 of 5 | 3 of 5 | - | +104 |
| **Opponent** | all armies | 25 | 66 | 324 | 3.0 | 1.1 | 109 | 41 | +68 | 29 of 74 | 49 of 74 | -22 | +76 |

### Effective charges: ja-opp-f9a8036-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -52) | 0 | 1 (net +60) | 1 (net +40) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 9 | 1 (net +0) | 0 | 3 (net +330) | 0 | 0 | 5 (net +224) | 0 | 33% (3 of 9) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 0 | 2 (net +84) | 0 | 2 (net +41) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 12 | 2 (net -107) | 0 | 4 (net +250) | 2 (net +0) | 1 (net +0) | 3 (net +72) | 0 | 33% (4 of 12) |
| Mine | Grand Cathay | 24 | 3 (net -98) | 1 (net +0) | 3 (net -30) | 2 (net +68) | 6 (net +38) | 9 (net +33) | 0 | 12% (3 of 24) |
| Mine | High Elf Realms | 13 | 1 (net -143) | 0 | 1 (net +0) | 2 (net +0) | 3 (net +82) | 5 (net +127) | 1 | 8% (1 of 12) |
| Opponent | Grand Cathay | 11 | 1 (net +0) | 0 | 1 (net +0) | 5 (net +44) | 3 (net +22) | 1 (net +355) | 0 | 9% (1 of 11) |
| Opponent | High Elf Realms | 8 | 0 | 1 (net +0) | 1 (net -347) | 1 (net +135) | 1 (net +65) | 4 (net +40) | 0 | 12% (1 of 8) |
| Opponent | Kingdom of Bretonnia | 6 | 2 (net +59) | 2 (net +95) | 0 | 1 (net +190) | 0 | 1 (net +0) | 0 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +126) | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 1 (net -38) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 10 | 3 (net +342) | 0 | 0 | 3 (net +143) | 1 (net +123) | 3 (net +183) | 0 | 0% (0 of 10) |
| Opponent | Vampire Counts | 20 | 7 (net +151) | 0 | 4 (net +56) | 4 (net +84) | 3 (net +99) | 2 (net +87) | 0 | 20% (4 of 20) |
| Opponent | Warriors of Chaos | 10 | 1 (net -205) | 0 | 2 (net +62) | 0 | 0 | 6 (net +32) | 1 | 22% (2 of 9) |
| Opponent | Wood Elf Realms | 5 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +260) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: ja-opp-f9a8036-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 221 | 277 | -88 | 85 | 134 | -49 | -22.2 |
| Mine | 50-54% | 1 | 233 | 170 | +0 | 21 | 116 | -95 | -40.9 |
| Mine | Effective (55-75%) | 12 | 292 | 241 | +163 | 196 | 37 | +159 | +54.4 |
| Mine | 76-89% | 9 | 216 | 179 | +38 | 68 | 15 | +53 | +24.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 250 | 173 | +98 | 125 | 27 | +98 | +39.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 374 | 68 | +47 | 60 | 12 | +48 | +12.8 |
| Mine | No odds | 1 | 497 | 110 | +110 | 110 | 0 | +110 | +22.1 |
| Mine | All fights | 65 | 272 | 182 | +70 | 114 | 39 | +74 | +27.4 |
| Opponent | Long shot (under 50%) | 16 | 261 | 274 | +122 | 163 | 44 | +119 | +45.7 |
| Opponent | 50-54% | 3 | 234 | 175 | +63 | 95 | 10 | +85 | +36.4 |
| Opponent | Effective (55-75%) | 9 | 230 | 212 | +0 | 41 | 80 | -38 | -16.7 |
| Opponent | 76-89% | 14 | 290 | 178 | +94 | 107 | 41 | +66 | +22.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 356 | 243 | +104 | 200 | 77 | +123 | +34.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 477 | 83 | +61 | 72 | 0 | +72 | +15.0 |
| Opponent | No odds | 3 | 289 | 315 | -346 | 38 | 384 | -346 | -119.7 |
| Opponent | All fights | 74 | 315 | 214 | +68 | 129 | 64 | +65 | +20.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ja-opp-f9a8036-p3 | move | 207 | 50 (24%) | 36 (17%) | 24 (12%) | 133 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L0311, L1519 |
| Horn of the Wild Hunt | Opponent | L0533 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

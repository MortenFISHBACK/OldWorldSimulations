# Doctrine scorecard: hc-mine-31c41bf-p3

### Scorecard: hc-mine-31c41bf-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0126 | 6 | 1 | Opponent | no | 17 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 5 | 3 | 5 | 2 | 1 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 1 | 0 | 0 | 302 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 2 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0831 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 3 | 3 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 885 |
| L0922 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 1 | 0 | 0 | 564 |
| L1030 | 4 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 5 | 3 | 3 | 0 | 1 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | yes | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 72 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 543 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 3 | 1 | 4 | 1 | 0 | 0 | 114 |
| L1633 | 1 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 380 |
| L1731 | 3 | 1 | Mine | yes | 10 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 7 | 2 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 7 | 2 | 1 | 2 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 255 |
| L1932 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 3 | 0 | 6 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 6 | 0 | 2 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 8 | 2 | 0 | 0 | 0 | 60 |
| L2433 | 3 | 1 | Mine | no | 6 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 287 |
| L2832 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 6 | 3 | 1 | 3 | 0 | 0 | 0 | 380 |
| **Average** | | | Mine | 28% | 3.0 | 2.9 | 2.3 | 1.0 | 0.3 | 0.0 | 0.0 | 314.1 |
| **Average** | | | Opponent | 25% | 3.5 | 2.1 | 2.8 | 2.0 | 0.5 | 0.0 | 0.0 | 172.2 |

### KPIs: hc-mine-31c41bf-p3

Rules off - Opponent only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 170) | 13% (23 of 175) | 18% (61 of 345) |
| Winner chose to follow up after the loser gave ground |  | 98% (46 of 47); on the table 98% | 95% (37 of 39); on the table 97% | 97% (83 of 86); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 85% (11 of 13); on the table 92% | 83% (20 of 24); on the table 88% |
| Winner chose to pursue after the loser fled |  | 89% (33 of 37); on the table 92% | 66% (29 of 44); on the table 75% | 77% (62 of 81); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 93% (88 of 95); on the table 94% | 80% (77 of 96); on the table 86% | 86% (165 of 191); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 31% (105 of 342) | 42% (81 of 192) | 35% (186 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (105 of 210) | 57% (81 of 142) | 53% (186 of 352) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (10 of 19) | 60% (38 of 63) | 59% (48 of 82) |
| Points that never fought | lower | 38% (25806 of 68801) | 41% (29534 of 71990) | 39% (55340 of 140791) |
|   infantry points that never fought | lower | 46% (6524 of 14174) | 57% (8077 of 14220) | 51% (14601 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (155 of 272) | 60% (171 of 285) | 59% (326 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 2.0 uses a game | 79% (19 of 24); 2.0 uses a game | 88% (43 of 49); 2.0 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game | 25% (5 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 43% (6 of 14); 0.2 uses a game | 44% (15 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31401 of 59391) | 54% (34508 of 64043) | 53% (65909 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (17%) | 0.9 (31%) | 2.1 (22%) |
| MARCHED: its unit marched | 1.4 (21%) | 0.6 (18%) | 1.9 (20%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.7 (23%) | 2.0 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (4%) | 0.2 (7%) | 0.5 (5%) |
| GONE: slain | 1.9 (28%) | 0.4 (12%) | 2.2 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.1 | 1.5 | 5.2 | 0.9 | 1.4 |
| not cast | 4.4 | 1.4 | 4.7 | 9.7 | 2.4 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.8 (56%) | 0.2 (5%) | 2.1 (22%) | 0.4 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (20%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (4%) | 0.5 (11%) | 2.0 (20%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (5%) | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (10%) | 0.2 (4%) | 0.5 (5%) | 0.1 (3%) | 0.9 (5%) |
| GONE: slain | 1.5 (34%) | 0.2 (15%) | 1.6 (34%) | 2.2 (23%) | 0.3 (13%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (8%) | 0.3 (6%) | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.9 (36%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (49%) | 0.1 (8%) | 1.4 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 65% (20 of 31) | 71% (10 of 14) | 67% (30 of 45) |
| the unit moved after it | 60% (12 of 20) | 80% (8 of 10) | 67% (20 of 30) |
| it charged on its next turn | 0% (0 of 20) | 0% (0 of 10) | 0% (0 of 30) |
| the enemy charged it first | 35% (7 of 20) | 20% (2 of 10) | 30% (9 of 30) |
| it fought by the end of its next turn | 10% (2 of 20) | 10% (1 of 10) | 10% (3 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 15% (3 of 20) | 10% (1 of 10) | 13% (4 of 30) |
| none of these (no charge, no fight, no charge escaped) | 50% (10 of 20) | 70% (7 of 10) | 57% (17 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (532 of 775) | 60% (372 of 624) | 65% (904 of 1399) |
|   cavalry | 72% (44 of 61) | 66% (72 of 109) | 68% (116 of 170) |
|   character | 63% (67 of 106) | 28% (34 of 121) | 44% (101 of 227) |
|   chariot | 54% (51 of 95) | 62% (20 of 32) | 56% (71 of 127) |
|   infantry | 56% (115 of 206) | 66% (174 of 262) | 62% (289 of 468) |
|   monster | 53% (18 of 34) | 67% (4 of 6) | 55% (22 of 40) |
|   war machine | 87% (237 of 273) | 72% (68 of 94) | 83% (305 of 367) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (35%) | 1.5 (22%) | 3.9 (28%) |
| CHARGED: it charged | 0.7 (10%) | 1.5 (21%) | 2.2 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.2 (3%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.6 (8%) | 0.4 (6%) | 1.0 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.9 (14%) | 0.9 (13%) | 1.9 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (2%) | 0.5 (7%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (19%) | 1.3 (19%) | 2.6 (19%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.3 (4%) | 0.5 (3%) |
| OTHER BAR | 0.3 (5%) | 0.3 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 0.9 | 85% | 5.2 pts | 26 pts |
| character | 3.2 | 0.9 | 83% | 4.7 pts | 15 pts |
| chariot | 2.0 | 1.0 | 65% | 18.9 pts | 37 pts |
| infantry | 12.6 | 4.6 | 75% | 9.8 pts | 123 pts |
| monster | 0.8 | 0.3 | 72% | 11.7 pts | 9 pts |
| war machine | 8.8 | 7.4 | 61% | 23.5 pts | 206 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.6 | 4.8 |
| Charges that made contact a game | 2.9 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.69 declared, 0.58 contact (26 units) | 0.80 declared, 0.65 contact (20 units) | 0.74 declared, 0.61 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 1.29 declared, 0.86 contact (7 units) | 1.20 declared, 0.80 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.40 contact (222 units) | 0.64 declared, 0.46 contact (272 units) | 0.61 declared, 0.43 contact (494 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (43 of 77) | 53% (8 of 15) | 50% (5 of 10) | 55% (56 of 102) |
| Character in a unit | 79% (27 of 34) | 77% (10 of 13) | 38% (3 of 8) | 73% (40 of 55) |
| Character on its own | 70% (30 of 43) | 63% (27 of 43) | 31% (21 of 67) | 51% (78 of 153) |
| Chariot | 82% (9 of 11) | 67% (8 of 12) | - | 74% (17 of 23) |
| Infantry | 63% (44 of 70) | 52% (22 of 42) | 40% (2 of 5) | 58% (68 of 117) |
| Monster | 65% (22 of 34) | 86% (6 of 7) | - | 68% (28 of 41) |
| Monstrous | 70% (7 of 10) | 27% (3 of 11) | - | 48% (10 of 21) |
| War Machines | 63% (27 of 43) | 100% (2 of 2) | - | 64% (29 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (21 of 21); on the table 100% | 26% (25 of 96) | 32% | 73% (16 of 22) | 83% (5 of 6); 3.5 uses a game | 50% (1 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (10 of 10); on the table 100% | 47% (17 of 36) | 38% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 73% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (8 of 10); on the table 80% | 37% (11 of 30) | 48% | 64% (38 of 59) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 93% (14 of 15); on the table 100% | 39% (74 of 192) | 46% | 57% (42 of 74) | 89% (16 of 18); 7.4 uses a game | 0% (0 of 4); 0.0 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 92% (22 of 24); on the table 92% | 19% (8 of 42) | 34% | 54% (29 of 54) | 89% (8 of 9); 2.6 uses a game | 25% (3 of 12); 0.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 75% (3 of 4); on the table 75% | - | 51% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 39% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 13% | 43% (3 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 0% (0 of 12) | 6% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 60% (3 of 5); on the table 80% | 33% (4 of 12) | 56% | 86% (12 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 94% (15 of 16); on the table 94% | 17% (1 of 6) | 37% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 80% (24 of 30); on the table 87% | 43% (23 of 54) | 25% | 50% (23 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 78% (28 of 36); on the table 81% | 50% (15 of 30) | 37% | 58% (56 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 78% (7 of 9); on the table 100% | 42% (5 of 12) | 46% | 69% (43 of 62) | 82% (9 of 11); 5.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hc-mine-31c41bf-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (37) | 44% (31) | 43% (68) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.44 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.39 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.28 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.53 | 1.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.69 | 5.22 | 10.92 |

### Quality by phase: hc-mine-31c41bf-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (62 of 121) | 44% (73 of 166) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (179 of 402) | 48% (126 of 264) |
| Strategy | Close-in objectives charged next turn | 18% (23 of 131) | 18% (41 of 234) |
| Strategy | Support requests answered (helper made contact too) | 55% (6 of 11) | 37% (7 of 19) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 31% (4 of 13) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 31% (12 of 39) | 49% (21 of 43) |
| Strategy | Lone characters that fought | 76% (73 of 96) | 76% (69 of 91) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 314.1 | 172.2 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 80, net +104 | 21 of 104, net +161 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 80, net +111 | 22 of 104, net +116 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 80, net +73 | 12 of 104, net +73 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 80, net +29 | 22 of 104, net +185 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (146 of 319) | 47% (168 of 360) |
| Shooting | Points destroyed by shooting units | 78.6 | 32.0 |
| Shooting | War machine shots | 6.6 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (112 of 237) | 39% (31 of 79) |
| Shooting | Points destroyed by war machines | 57.4 | 19.2 |
| Magic | Magic missiles cast | 1.8 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (28 of 66) | 32% (16 of 50) |
| Magic | Wounds caused by magic missiles | 3.2 | 2.3 |
| Magic | Wounds caused by other spells | 1.1 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 91.7 | 56.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.4 / 0.2 | 1.9 / 0.1 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 301.4 | 415.2 |
| Combat | Points run down | 78.2 | 102.1 |
| Combat | Net points per charged fight, damage counted | +93 | +138 |
| Combat | Net per 100 charger points, damage counted | +33.7 | +45.5 |
| Combat | First round won (charged fights) | 79% | 73% |
| Combat | Net points per charged fight | +81 | +140 |
| Combat | Net points per supported fight / lone fight | +121 / +74 | +195 / +131 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 95 | 58 of 117 |
| Game | Points lost | 789.3 | 642.8 |
| Game | VP from objectives | 515.0 | 574.2 |
| Game | Lone holders (player turns) | 3.0 | 3.5 |

- Mine won / drew / lost: 12 / 8 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -201 VP
- The side that went first won 15 of 28 games with a winner
- Points traded per game (both sides' losses): 1432
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-mine-31c41bf-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.2 | -210.7 | 149.8 | 100.0 | 4.1 | -95.2 | 161.0 | 79.9 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 18.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.4 | 0.0 | 0.0 | 0.6 | +2.5 | 0.0 | 5.4 |
| BEST FACING | 0.4 | +6.0 | 0.0 | 12.9 | 0.4 | +7.2 | 0.0 | 27.7 |
| BEST FIRST | 1.2 | +48.5 | 37.2 | 16.5 | 1.0 | +62.8 | 28.1 | 43.9 |
| BEST OVERALL | 0.4 | +31.9 | 0.0 | 9.1 | 0.2 | +2.9 | 0.0 | 0.0 |
| BEST PREY | 0.6 | +33.4 | 10.1 | 2.9 | 0.7 | +27.5 | 11.1 | 23.2 |
| BEST PRIZE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -0.6 | 3.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.5 | 0.0 | 0.0 | 0.3 | -1.0 | 0.0 | 11.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 17.9 | 0.0 |
| BLOCKED WHEEL | 0.5 | +13.4 | 0.0 | 0.0 | 0.4 | +11.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -13.9 | 31.2 | 20.0 | 0.3 | -57.8 | 48.5 | 0.0 |
| BOMBING RUN | 0.1 | +0.6 | 0.0 | 8.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 61.8 | 7.2 | 0.1 | +0.0 | 1.4 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +142.2 | 368.6 | 77.6 | 1.2 | +52.2 | 46.5 | 11.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.8 | 15.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -1.5 | 22.2 | 6.0 | 0.1 | +0.0 | 6.9 | 5.5 |
| CAST JOB | 1.0 | +28.9 | 76.2 | 31.6 | 0.8 | +19.1 | 29.2 | 11.9 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +17.1 | 19.6 | 4.8 | 0.0 | +0.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 52.4 | 0.4 | +0.0 | 0.0 | 25.2 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +2.1 | 0.0 | 10.2 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +53.1 | 0.0 | 21.1 | 1.8 | +104.6 | 0.0 | 35.3 |
| CHAFF PASSED | 0.1 | -0.5 | 4.3 | 4.9 | 0.2 | -0.4 | 0.0 | 1.8 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 191.8 | 75.4 | 2.6 | +0.0 | 309.2 | 59.7 |
| CHARGE NOW WEIGHED | 0.5 | -41.4 | 15.3 | 9.9 | 0.4 | -23.5 | 4.1 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -17.4 | 43.4 | 21.2 | 0.6 | -17.6 | 50.7 | 12.1 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.8 | 10.9 | 11.0 | 0.2 | -0.2 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 7.6 | 44.9 | 0.4 | +0.0 | 20.9 | 23.9 |
| CONVEYANCE SEARCH | 0.4 | +45.4 | 23.3 | 30.9 | 0.3 | +21.4 | 4.4 | 14.1 |
| COVER ONCE | 8.4 | -652.5 | 0.0 | 170.3 | 5.8 | -401.4 | 0.0 | 144.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 16.0 | 4.8 | 0.2 | +0.0 | 3.2 | 7.2 |
| EDGE GIVE GROUND | 0.1 | +10.3 | 0.0 | 19.4 | 0.3 | +5.6 | 25.9 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +129.1 | 0.0 | 86.8 | 1.3 | +119.5 | 0.0 | 50.2 |
| FALLBACK BY WORTH | 3.7 | +28.3 | 0.0 | 45.2 | 5.4 | +43.6 | 0.0 | 63.2 |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.1 | 2.9 | 5.3 | - | - | - | - |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 111.6 | 4.8 | +0.0 | 0.0 | 140.0 |
| FOCUS FIRE | 0.0 | +0.3 | 1.8 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.6 | +95.0 | 0.0 | 36.8 | 0.9 | +137.5 | 0.0 | 54.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.2 | 0.0 | 33.7 | 0.1 | +5.3 | 0.0 | 2.8 |
| GIVES UP | 0.1 | -0.5 | 10.9 | 3.2 | 0.1 | -1.3 | 18.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.4 | 4.5 | 0.0 |
| GROUND FLIERS | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 12.0 | 0.0 | 0.0 | +0.0 | 15.1 | 0.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 20.2 | 0.0 | 0.3 | +0.0 | 14.7 | 10.9 |
| HILL BY ITS CHANCE | 0.3 | -49.2 | 0.0 | 1.8 | 0.4 | -53.5 | 0.0 | 6.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.8 | -74.7 | 255.4 | 82.2 | 9.3 | -233.6 | 666.0 | 153.5 |
| HORN WORTH | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +12.1 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 5.8 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.9 |
| HUNT IN PAIRS | 0.2 | +6.9 | 0.0 | 0.0 | 0.6 | +44.0 | 0.0 | 16.2 |
| HUNT KEPT | 0.3 | +9.5 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 2.9 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.9 |
| HUNT THE GUNS | 0.1 | +42.9 | 0.0 | 0.0 | 0.1 | +41.1 | 0.0 | 2.9 |
| IDLE COST | 14.9 | -256.7 | 0.0 | 165.2 | 18.8 | -329.6 | 0.0 | 240.5 |
| INVITES THE FIGHT | 1.4 | +16.8 | 47.8 | 32.9 | 0.5 | +4.1 | 37.9 | 15.3 |
| JOINT CHARGE PLAN | 0.1 | +10.1 | 10.9 | 0.0 | 0.2 | +8.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -9.1 | 71.7 | 0.0 |
| KEEP FALLS | 0.1 | +2.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 1.4 | 0.0 | +0.1 | 0.0 | 4.7 |
| KEEPS ITS TARGET | 1.3 | +38.3 | 101.6 | 43.0 | 2.2 | +67.5 | 255.9 | 22.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +63.3 | 161.6 | 35.1 | 2.1 | +108.3 | 210.4 | 29.6 |
| KILLS COUNT NEXT TURN | 1.7 | +51.1 | 36.8 | 32.8 | 7.7 | +278.6 | 302.3 | 179.9 |
| LONE CHARACTER SAFE SPOT | 0.3 | +10.6 | 8.4 | 2.9 | 0.4 | +20.7 | 15.5 | 22.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 1.5 | 0.0 | 0.4 | +0.0 | 16.6 | 27.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +4.2 | 25.1 | 7.8 | 0.2 | +0.7 | 14.4 | 4.9 |
| LOST CHARGE | 2.6 | -41.3 | 99.4 | 121.1 | 2.4 | -37.1 | 55.9 | 48.8 |
| LURE BY WHAT IT DRAWS | 0.1 | -4.9 | 0.0 | 0.0 | 0.3 | -43.2 | 0.0 | 9.5 |
| MAKE SURE TOGETHER | 0.8 | +116.6 | 69.0 | 30.8 | 0.9 | +106.5 | 51.5 | 20.6 |
| MANOEUVRE | 0.2 | +3.3 | 0.0 | 2.9 | 0.2 | +10.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 3.0 |
| MARCH CHECK | 0.6 | +15.5 | 0.0 | 14.1 | 0.6 | +23.9 | 0.0 | 18.0 |
| MARCH ODDS | 0.2 | +12.8 | 2.2 | 22.6 | 0.2 | +13.3 | 4.6 | 3.2 |
| MARCH OVER CASTS | 0.6 | +51.4 | 0.0 | 33.6 | 0.4 | +29.6 | 0.0 | 17.1 |
| MAX FOR POSITIONING | 5.3 | +54.7 | 0.0 | 129.1 | 7.2 | +99.6 | 0.0 | 137.8 |
| MEASURED NEXT CHARGE | 9.2 | -194.0 | 152.7 | 210.4 | - | - | - | - |
| MISSILES IN THE MOVE | 4.3 | +115.8 | 0.0 | 140.0 | 4.2 | +66.0 | 0.0 | 118.6 |
| MISSILES NEXT TURN | 5.2 | +75.2 | 0.0 | 190.4 | 5.1 | +51.8 | 0.0 | 117.5 |
| MODEL FACING | 0.1 | +18.9 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.6 | +23.2 | 0.0 | 17.4 | 0.6 | +22.1 | 0.0 | 26.1 |
| MOVE SPELL IN RANGE | 0.2 | +7.2 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -16.1 | 1.8 | 24.4 | 0.1 | -3.7 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 21.1 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 0.9 | +6.0 | 25.4 | 16.5 | 4.9 | +426.3 | 218.6 | 98.3 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +1.6 | 15.9 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -4.9 | 29.4 | 0.0 | 0.4 | -12.3 | 37.5 | 0.0 |
| NOT TURNED | 5.7 | +69.3 | 0.0 | 105.5 | 5.2 | +32.4 | 0.0 | 132.6 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 24.7 | 0.9 | -1.0 | 0.0 | 0.0 |
| OFF BEST | 15.9 | -553.0 | 15.6 | 312.9 | 15.8 | -822.4 | 0.0 | 242.6 |
| ONE FIGHT FORMULA | 8.6 | -141.4 | 36.7 | 225.0 | 8.6 | -202.8 | 26.8 | 211.4 |
| ONE OBJECTIVE FORMULA | 2.6 | -112.8 | 0.0 | 45.6 | 1.7 | -93.2 | 0.0 | 27.6 |
| OPENS A LANE | 0.1 | +0.7 | 10.8 | 0.0 | 0.2 | +0.7 | 17.1 | 6.5 |
| OPENS UP | 0.1 | +0.8 | 4.7 | 0.0 | 0.2 | +13.7 | 14.9 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.9 | 0.0 | 7.4 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +18.1 | 70.3 | 18.3 | 0.4 | +1.6 | 31.6 | 18.3 |
| PATHS CROSS | 2.0 | +102.8 | 0.0 | 11.0 | 2.3 | +185.6 | 0.0 | 23.9 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.4 | 0.0 | 6.5 | 0.1 | -1.7 | 0.0 | 6.1 |
| PLAN RESULT | 36.6 | +1264.6 | 1384.5 | 984.1 | 38.1 | +1323.4 | 1611.2 | 861.9 |
| PURSUES BIG PREY | 0.1 | -4.8 | 0.0 | 0.0 | 0.1 | -6.8 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 6.2 | 0.1 | +9.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +10.0 | 0.0 | 4.7 | 1.8 | +24.9 | 0.0 | 57.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -3.1 | 0.0 | 0.0 | 0.4 | -31.6 | 20.9 | 29.4 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -13.1 | 0.0 | 20.1 | 1.4 | -35.0 | 0.0 | 23.1 |
| REDIRECT COUNTER | 1.9 | +172.4 | 0.0 | 46.2 | 3.8 | +342.9 | 0.0 | 58.8 |
| REDIRECT WEIGHED | 0.3 | +3.6 | 7.8 | 18.2 | 0.5 | +2.3 | 11.1 | 13.8 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 25.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +20.6 | 0.0 | 21.6 | 0.9 | +36.8 | 0.0 | 10.4 |
| RESTRAINS TO SHOOT | 0.1 | +12.8 | 0.0 | 5.7 | 0.1 | +3.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +79.3 | 243.4 | 83.2 | 2.8 | +88.4 | 253.0 | 68.4 |
| RISK ONCE | 4.0 | +84.3 | 25.2 | 130.3 | 5.0 | +277.5 | 63.6 | 312.1 |
| RUN DOWN | 1.6 | -9.9 | 133.9 | 17.7 | - | - | - | - |
| SAFE SURE CHARGE | 0.0 | -0.8 | 0.0 | 0.0 | 0.1 | -2.2 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.8 | +59.8 | 0.0 | 25.7 | 0.5 | +24.4 | 0.0 | 9.6 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.8 | 0.0 | 0.9 | 0.3 | -27.0 | 0.0 | 2.7 |
| SEARCH SPOT | 2.0 | +80.3 | 0.0 | 38.6 | 2.5 | +133.5 | 0.0 | 59.9 |
| SELF MOVE SPELL | 0.2 | +36.0 | 0.0 | 51.0 | 0.2 | +65.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.1 | +123.9 | 76.9 | 32.4 | 1.8 | +197.9 | 66.6 | 34.4 |
| SET-UP ANY TARGET | 0.2 | +38.9 | 10.5 | 10.5 | 0.1 | +17.2 | 4.4 | 14.1 |
| SET-UP MISSED | 0.1 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +53.6 | 45.8 | 32.8 | 1.3 | +51.1 | 55.4 | 46.1 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 120.9 | 8.4 | 0.2 | +0.0 | 20.4 | 2.0 |
| SHOTS IN THE MOVE | 13.7 | +546.6 | 0.0 | 229.3 | 10.1 | +306.4 | 0.0 | 160.5 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.1 | 0.0 | 7.6 |
| SPELL SETS UP CHARGE | 0.2 | +51.0 | 21.1 | 21.1 | 0.1 | +17.2 | 4.4 | 14.1 |
| SPELL WORTH | 1.3 | +17.3 | 81.8 | 101.4 | 2.2 | +33.6 | 78.7 | 71.1 |
| SPELLS IN THE FIGHT | 0.3 | -0.9 | 66.6 | 13.0 | 0.5 | -5.1 | 96.5 | 13.4 |
| STABLE ROLE | 10.2 | +0.0 | 333.1 | 179.8 | 9.6 | +0.0 | 368.1 | 116.8 |
| STANDS TO CAST | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| STOPS | 0.1 | +3.0 | 0.0 | 0.0 | 0.0 | +1.3 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +16.6 | 0.0 | 28.0 | 0.5 | +29.0 | 0.0 | 7.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 6.3 | -65.9 | 353.9 | 141.1 | 6.4 | -46.3 | 355.4 | 94.8 |
| SUPPORTS | 4.6 | +69.3 | 219.8 | 83.7 | 4.1 | +47.2 | 137.3 | 36.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.6 | 0.0 | 0.0 | 0.2 | -4.0 | 10.1 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +6.5 | 7.9 | 22.6 | 1.1 | -9.6 | 21.8 | 16.1 |
| THROUGH LINE OF FIRE | 0.4 | +10.4 | 0.0 | 0.0 | 0.3 | +11.7 | 0.0 | 6.2 |
| TURN WORTH | 0.4 | -22.7 | 25.6 | 12.5 | 0.5 | -32.4 | 42.8 | 12.3 |
| TWO OR MORE ARRIVE | 0.2 | +1.9 | 29.8 | 1.2 | 0.6 | +4.4 | 22.9 | 28.4 |
| WAIT AFTER COSTS | 3.8 | -197.7 | 93.6 | 72.4 | 7.3 | -358.7 | 317.7 | 137.7 |
| WALKS TO THE FIGHT | 1.7 | +17.9 | 31.6 | 23.0 | 1.1 | +5.4 | 34.3 | 3.5 |
| WAR ENGINE CHARGES | 0.1 | +5.4 | 6.5 | 0.0 | 0.1 | +6.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 35.9 | 21.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.8 | +28.7 | 97.2 | 17.7 | 1.3 | +49.1 | 173.6 | 37.9 |
| WHO HITS BACK | 0.2 | +14.0 | 0.0 | 2.5 | 0.1 | +9.6 | 0.0 | 7.6 |
| WHOLE FIGHT | 0.2 | -6.7 | 48.2 | 0.0 | 0.4 | +15.0 | 70.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +5.9 | 9.0 | 3.4 | 0.5 | +43.9 | 103.8 | 5.8 |
| WIDER SPREAD | 1.9 | -4.5 | 194.4 | 44.2 | 2.8 | -8.0 | 276.5 | 30.5 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 4.2 | 0.0 |

### Rule changes: hc-mine-31c41bf-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1143 | 1143 | 1143 | 31.75 | -49513 | -43.3 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +10381 | +66.1 |
| SEARCH SPOT | 163 | 163 | 157 | 4.36 | +7709 | +49.1 |
| SUPPORTS | 314 | 314 | 123 | 3.42 | +1287 | +10.5 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +8949 | +76.5 |
| MOVE TO CHARGE | 210 | 210 | 116 | 3.22 | +5885 | +50.7 |
| KILLS COUNT NEXT TURN | 337 | 337 | 105 | 2.92 | +2899 | +27.6 |
| BEST FIRST | 80 | 80 | 80 | 2.22 | +4006 | +50.1 |
| COVER ONCE | 511 | 278 | 72 | 2.00 | +812 | +11.3 |
| WAIT AFTER COSTS | 398 | 398 | 71 | 1.97 | +1215 | +17.1 |
| ARTILLERY RE-ROLL WEIGHED | 69 | 69 | 69 | 1.92 | +0 | +0.0 |
| SHOTS IN THE MOVE | 857 | 578 | 67 | 1.86 | +1936 | +28.9 |
| MISSILES IN THE MOVE | 304 | 201 | 65 | 1.81 | +1227 | +18.9 |
| ADVANCE WORTH | 336 | 336 | 63 | 1.75 | +1556 | +24.7 |
| ONE FIGHT FORMULA | 619 | 366 | 61 | 1.69 | +242 | +4.0 |
| FALLBACK BY WORTH | 329 | 329 | 58 | 1.61 | +2587 | +44.6 |
| CHAFF IN THE MOVE | 97 | 95 | 57 | 1.58 | +1979 | +34.7 |
| RISK ONCE | 324 | 226 | 57 | 1.58 | +2243 | +39.3 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 53 | 53 | 53 | 1.47 | +8373 | +158.0 |
| SET UP TOGETHER | 106 | 93 | 52 | 1.44 | +4040 | +77.7 |
| SAFER THAN THE JOB | 49 | 49 | 49 | 1.36 | +3031 | +61.9 |
| RANDOM MOVE BY FIGURES | 82 | 82 | 48 | 1.33 | +1256 | +26.2 |
| RESERVE FALL BACK | 48 | 48 | 48 | 1.33 | +2066 | +43.0 |
| MEASURED NEXT CHARGE | 330 | 230 | 47 | 1.31 | +378 | +8.0 |
| IDLE COST | 1211 | 692 | 46 | 1.28 | +541 | +11.8 |
| SHOOTS FROM THE BEST SPOT | 92 | 92 | 46 | 1.28 | +1305 | +28.4 |
| REDIRECT COUNTER | 202 | 97 | 45 | 1.25 | +3208 | +71.3 |
| RISK BY ARC | 192 | 186 | 43 | 1.19 | +1121 | +26.1 |
| MARCH CHECK | 44 | 43 | 41 | 1.14 | +1553 | +37.9 |
| CANNON PLANNED TARGET | 248 | 248 | 40 | 1.11 | -922 | -23.0 |
| MOVE AND CAST | 40 | 40 | 40 | 1.11 | +1629 | +40.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MAX FOR POSITIONING | 453 | 282 | 38 | 1.06 | +136 | +3.6 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 144 | 143 | 35 | 0.97 | +1566 | +44.7 |
| WALKS TO THE FIGHT | 101 | 101 | 35 | 0.97 | +308 | +8.8 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +877 | +25.8 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1644 | +53.0 |
| CHARGE NOW WEIGHED | 30 | 30 | 30 | 0.83 | +2218 | +73.9 |
| REDIRECT WEIGHED | 29 | 29 | 29 | 0.81 | +1267 | +43.7 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| BEST FACING | 26 | 26 | 26 | 0.72 | +474 | +18.2 |
| INVITES THE FIGHT | 67 | 67 | 26 | 0.72 | +201 | +7.7 |
| MAKE SURE TOGETHER | 64 | 49 | 25 | 0.69 | +2543 | +101.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 25 | 25 | 25 | 0.69 | +796 | +31.9 |
| CAST JOB | 64 | 64 | 24 | 0.67 | +525 | +21.9 |
| BEST OVERALL | 20 | 20 | 20 | 0.56 | +1252 | +62.6 |
| KEEPS ITS TARGET | 127 | 127 | 19 | 0.53 | +347 | +18.3 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WAR ENGINE JOBS | 28 | 28 | 18 | 0.50 | -1130 | -62.8 |
| HONEST WORTH | 505 | 500 | 17 | 0.47 | +184 | +10.8 |
| CHARGE NOW FIRST | 166 | 166 | 16 | 0.44 | -830 | -51.9 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +148 | +9.3 |
| BEST PREY | 46 | 46 | 15 | 0.42 | +379 | +25.3 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -54 | -3.6 |
| SUPPORT NARROWED | 459 | 459 | 15 | 0.42 | -172 | -11.5 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +518 | +37.0 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +482 | +37.1 |
| MISSILES NEXT TURN | 368 | 236 | 13 | 0.36 | +36 | +2.8 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +701 | +58.4 |
| WEARS DOWN | 76 | 72 | 12 | 0.33 | +355 | +29.6 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -33 | -3.3 |
| LOST CHARGE | 180 | 180 | 10 | 0.28 | +376 | +37.6 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -202 | -20.2 |
| WHOLE FIGHT GAIN | 25 | 24 | 10 | 0.28 | +588 | +58.8 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 10 | 10 | 7 | 0.19 | +168 | +24.0 |
| HUNT IN PAIRS | 30 | 17 | 7 | 0.19 | +244 | +34.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -113 | -16.2 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +248 | +35.5 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +599 | +85.6 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 6 | 0.17 | -335 | -55.8 |
| SURE REACH TOGETHER | 60 | 47 | 6 | 0.17 | +40 | +6.7 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 13 | 13 | 5 | 0.14 | +184 | +36.9 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +162 | +32.3 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -416 | -83.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -102 | -25.4 |
| OPENS UP | 9 | 9 | 4 | 0.11 | +247 | +61.7 |
| REFUSING RETIRES | 22 | 22 | 4 | 0.11 | -1 | -0.2 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -68 | -22.6 |
| EDGE GIVE GROUND | 12 | 12 | 3 | 0.08 | +93 | +31.1 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +35 | +11.7 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +679 | +226.3 |
| OVERRUNS AWAY | 29 | 28 | 3 | 0.08 | +136 | +45.5 |
| SAFE SURE CHARGE | 3 | 3 | 3 | 0.08 | -105 | -34.8 |
| WAR ENGINE CHARGES | 6 | 6 | 3 | 0.08 | +138 | +46.1 |
| WHOLE FIGHT | 22 | 22 | 3 | 0.08 | +194 | +64.5 |
| BACKUP TARGETS | 31 | 15 | 2 | 0.06 | +2 | +1.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +22 | +11.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +41 | +20.6 |
| JOINT CHARGE PLAN | 11 | 11 | 2 | 0.06 | +194 | +97.0 |
| ONE OBJECTIVE FORMULA | 156 | 62 | 2 | 0.06 | +186 | +93.1 |
| RUN DOWN | 56 | 55 | 2 | 0.06 | +3 | +1.3 |
| SPELLS IN THE FIGHT | 31 | 30 | 2 | 0.06 | +112 | +56.2 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +51 | +25.4 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -107 | -53.5 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -64 | -63.8 |
| CARRIES OUT SET-UP | 12 | 12 | 1 | 0.03 | -53 | -52.6 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -8 | -7.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +10 | +10.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 22 | 20 | 1 | 0.03 | +47 | +46.7 |
| MOVE SPELL IN RANGE | 9 | 6 | 1 | 0.03 | +25 | +25.1 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +122 | +121.9 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +21 | +21.3 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +146 | +145.6 |
| REDIRECT BY WHAT IT STOPS | 77 | 77 | 1 | 0.03 | +4 | +4.0 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +5 | +4.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +15 | +15.0 |
| STOPS | 6 | 6 | 1 | 0.03 | +5 | +5.0 |
| TWO OR MORE ARRIVE | 29 | 27 | 1 | 0.03 | +3 | +3.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 19 | 18 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 33 | 32 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 24 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 364 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 13 | 13 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 27 | 27 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 12 | 12 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 393 | 393 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 5 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2686 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 19 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 126 | not checked | - | - | - | - |
| STABLE ROLE | 713 | 712 | 0 | 0.00 | - | - |
| TURN WORTH | 30 | 30 | 0 | 0.00 | - | - |
| WIDER SPREAD | 166 | 160 | 0 | 0.00 | - | - |

### Off best figure: hc-mine-31c41bf-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.31 | 14.44 | 42.8 |
| FALLBACK | gate | 0.56 | 0.67 | 54.8 |
| TURN GATE | gate | 0.56 | 0.33 | 60.4 |
| WAR ENGINE JOBS | rule | 0.42 | 0.08 | 62.8 |
| CHARGE NOW FIRST | rule | 0.22 | 0.22 | 51.9 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.08 | 74.0 |
| SUPPORT NARROWED | rule | 0.08 | 0.28 | 13.2 |
| AFTERMATH BAND | gate | 0.17 | 0.11 | 2.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.17 | 20.2 |
| CHAFF PASSED | rule | 0.08 | 0.17 | 3.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 9.7 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 16.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.06 | 30.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 33.9 |
| PATHS CROSS | rule | 0.08 | 0.06 | 57.5 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 83.2 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.06 | 83.7 |
| STOPS SHORT OF THE FLANK | rule | - | 0.11 | 10.2 |
| SUPPORT REQUEST | gate | 0.11 | - | 95.9 |
| BEST PRIZE | rule | - | 0.08 | 33.9 |
| CATCH ODDS | rule | 0.08 | - | 22.6 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 3.0 |
| REDIRECT WEIGHED | rule | - | 0.08 | 27.7 |
| RULE SWITCHED OFF | gate | - | 0.08 | 9.4 |
| SAFE SURE CHARGE | rule | 0.03 | 0.06 | 34.8 |
| BLOCKED WHEEL | rule | - | 0.06 | 16.2 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 5.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 12.6 |
| WHO HITS BACK | rule | 0.03 | 0.03 | 4.4 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 53.5 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 63.8 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 52.6 |
| CHARGE NOW WEIGHED | rule | 0.03 | - | 17.5 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 7.6 |
| FALLBACK BY WORTH | rule | - | 0.03 | 3.5 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.5 |
| MOVE AND CAST | rule | - | 0.03 | 6.0 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 98.4 |

### Plans: hc-mine-31c41bf-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.0 | 13% | 158 | 157 | 99% |
| Mine | charge | 2.8 | 60% | 176 | 273 | 155% |
| Mine | close in | 3.6 | 26% | 208 | 146 | 70% |
| Mine | hold | 4.9 | 37% | 290 | 0 | 0% |
| Mine | join | 0.5 | 89% | 20 | 0 | 0% |
| Mine | shoot | 9.3 | 60% | 246 | 689 | 280% |
| Mine | support | 5.4 | 89% | 51 | 0 | 0% |
| Opponent | advance | 10.9 | 18% | 155 | 309 | 200% |
| Opponent | charge | 4.0 | 59% | 371 | 441 | 119% |
| Opponent | close in | 6.5 | 24% | 418 | 203 | 49% |
| Opponent | hold | 4.0 | 30% | 297 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 35 | 0 | 0% |
| Opponent | shoot | 6.2 | 55% | 155 | 373 | 240% |
| Opponent | support | 5.7 | 87% | 49 | 0 | 0% |

### Packages: hunt the guns, hc-mine-31c41bf-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 0% | 0% | 0% | - | 423 | 0 | 0% | 30 |
| Opponent | 0.1 | 5 | 0 | 0% | 0% | 0% | - | 296 | 0 | 0% | 85 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 0% | 0% | 0% | - | 363 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 99 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 542 | 0 | 0% | 68 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 375 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 0% | 0% | 0% | - | 313 | 0 | 0% | 77 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 271 | 0 | 0% | 39 |

### Battle groups: hc-mine-31c41bf-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 31% | 90% | 14% | 33% | 11% | 0% | 6% | 83% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 20% | 78% | 22% | 33% | 29% | 0% | 10% | 57% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-mine-31c41bf-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 126 (1) | 126 | 0 | 100 | 0% | 6.0 | 126 (1) | - | - | - | 126 (1) |
| Mine | Chaff | 34 | 51 (34) | 14 | 37 | 62 | 35% | 2.6 | 64 (21) | 0 (4) | 35 (9) | 70 (24) | 13 (10) |
| Mine | Character | 118 | 41 (118) | 41 | 0 | 39 | 19% | 2.3 | 48 (40) | 48 (55) | 0 (3) | 50 (56) | 43 (42) |
| Mine | Clean-up | 18 | 44 (18) | 4 | 40 | 52 | 33% | 3.2 | 84 (3) | 32 (13) | 94 (2) | 63 (12) | 15 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 33 (44) | 22 | 11 | 46 | 23% | 3.0 | 30 (22) | 27 (14) | 52 (8) | 39 (30) | 23 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 36 (52) | 27 | 9 | 39 | 13% | 2.6 | 18 (14) | 40 (35) | 65 (3) | 45 (36) | 18 (16) |
| Mine | Holder | 25 | 49 (25) | 1 | 47 | 33 | 48% | 2.8 | 21 (7) | 59 (11) | 52 (7) | 68 (15) | 20 (10) |
| Mine | Shooter | 37 | 70 (37) | 37 | 33 | 57 | 0% | 2.0 | 13 (6) | 80 (29) | 77 (2) | 70 (21) | 70 (16) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 58 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 47 (52) | 47 | 0 | 32 | 2% | 1.0 | 55 (13) | 44 (36) | 55 (3) | 52 (13) | 45 (39) |
| Mine | Wizard | 17 | 13 (17) | 13 | 0 | 56 | 6% | 2.2 | 36 (4) | 0 (6) | 53 (1) | 17 (7) | 28 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 32 (68) | 9 | 23 | 36 | 47% | 2.9 | 28 (29) | 23 (11) | 39 (28) | 31 (48) | 34 (20) |
| Opponent | Character | 102 | 58 (102) | 58 | 0 | 32 | 17% | 2.3 | 52 (38) | 72 (49) | 28 (7) | 67 (54) | 55 (40) |
| Opponent | Clean-up | 11 | 90 (11) | 15 | 74 | 29 | 45% | 3.5 | 28 (4) | 114 (6) | 167 (1) | 59 (6) | 118 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 51 (60) | 27 | 24 | 41 | 32% | 2.9 | 46 (30) | 45 (20) | 85 (10) | 52 (28) | 51 (32) |
| Opponent | Fragile | 3 | 123 (3) | 123 | 0 | 67 | 0% | 2.0 | - | 92 (2) | 185 (1) | 92 (2) | 185 (1) |
| Opponent | Hammer | 50 | 29 (50) | 19 | 10 | 38 | 32% | 3.1 | 38 (17) | 27 (30) | 6 (3) | 39 (30) | 14 (20) |
| Opponent | Holder | 40 | 68 (40) | 27 | 41 | 28 | 40% | 2.5 | 12 (8) | 111 (20) | 40 (9) | 82 (33) | 35 (4) |
| Opponent | Shooter | 27 | 44 (27) | 22 | 22 | 36 | 7% | 1.2 | 63 (6) | 25 (19) | 260 (2) | 42 (16) | 47 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 54 (17) | 54 | 0 | 20 | 0% | 1.6 | 102 (3) | 36 (10) | 66 (4) | 28 (3) | 58 (14) |
| Opponent | Wizard | 32 | 7 (32) | 7 | 0 | 44 | 19% | 2.2 | 0 (14) | 3 (10) | 0 (2) | 2 (13) | 0 (13) |

### Charged fights: hc-mine-31c41bf-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 10 | 1.0 | 1.0 | 10 | 8 | +2 | 0 of 4 | 3 of 4 | - | +2 |
| Mine | Chaos Dwarfs | 4 | 271 | 376 | 3.5 | 1.2 | 107 | 0 | +107 | 6 of 14 | 13 of 14 | +159 | +99 |
| Mine | Dwarfen Mountain Holds | 3 | 597 | 34 | 0.7 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| Mine | Empire of Man | 5 | 376 | 115 | 1.6 | 1.2 | 72 | 13 | +59 | 4 of 8 | 6 of 8 | +132 | +35 |
| Mine | Grand Cathay | 5 | 380 | 233 | 2.8 | 1.1 | 83 | 30 | +53 | 5 of 14 | 12 of 14 | +0 | +57 |
| Mine | High Elf Realms | 4 | 214 | 589 | 3.2 | 1.2 | 181 | 9 | +172 | 6 of 13 | 10 of 13 | +354 | +139 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 712 | 3.0 | 1.0 | 237 | 0 | +237 | 0 of 3 | 2 of 3 | - | +237 |
| Mine | Lizardmen | 1 | 116 | 340 | 2.0 | 1.0 | 170 | 0 | +170 | 0 of 2 | 2 of 2 | - | +170 |
| Mine | Ogre Kingdoms | 1 | 116 | 365 | 3.0 | 1.3 | 122 | 41 | +80 | 2 of 3 | 2 of 3 | +80 | +80 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 675 | 10.0 | 1.3 | 68 | 32 | +35 | 4 of 10 | 6 of 10 | +49 | +29 |
| Mine | Skaven | 1 | 0 | 19 | 1.0 | 2.0 | 19 | 0 | +19 | 0 of 1 | 1 of 1 | +19 | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 435 | 5.0 | 1.3 | 87 | 9 | +78 | 2 of 10 | 7 of 10 | +80 | +78 |
| Mine | Vampire Counts | 2 | 171 | 49 | 4.0 | 1.0 | 12 | 36 | -24 | 0 of 8 | 7 of 8 | - | -24 |
| Mine | Warriors of Chaos | 2 | 52 | 304 | 1.5 | 1.0 | 203 | 77 | +125 | 1 of 3 | 2 of 3 | - | +125 |
| **Mine** | all armies | 36 | 228 | 262 | 2.6 | 1.2 | 99 | 18 | +81 | 30 of 95 | 75 of 95 | +121 | +74 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 476 | 317 | 3.0 | 1.1 | 106 | 48 | +58 | 5 of 9 | 3 of 9 | +0 | +65 |
| Opponent | High Elf Realms | 3 | 83 | 68 | 0.7 | 1.0 | 102 | 100 | +3 | 2 of 2 | 2 of 2 | - | +3 |
| Opponent | Kingdom of Bretonnia | 2 | 80 | 488 | 3.5 | 1.3 | 140 | 0 | +140 | 2 of 7 | 6 of 7 | +276 | +85 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 571 | 4.0 | 1.0 | 143 | 28 | +115 | 2 of 4 | 3 of 4 | - | +115 |
| Opponent | Skaven | 1 | 240 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 142 | 890 | 4.2 | 1.1 | 209 | 41 | +168 | 12 of 17 | 12 of 17 | +233 | +160 |
| Opponent | Vampire Counts | 6 | 70 | 862 | 5.3 | 1.2 | 162 | 26 | +136 | 17 of 32 | 23 of 32 | +202 | +124 |
| Opponent | Warriors of Chaos | 9 | 15 | 721 | 3.7 | 1.3 | 197 | 8 | +188 | 15 of 33 | 25 of 33 | +205 | +185 |
| Opponent | Wood Elf Realms | 6 | 114 | 227 | 2.0 | 1.1 | 113 | 30 | +83 | 3 of 12 | 10 of 12 | +60 | +85 |
| **Opponent** | all armies | 36 | 108 | 536 | 3.2 | 1.2 | 165 | 25 | +140 | 58 of 117 | 85 of 117 | +195 | +131 |

### Effective charges: hc-mine-31c41bf-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -30) | 0 | 0 | 1 (net +0) | 0 | 1 (net +40) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 14 | 0 | 1 (net +465) | 1 (net +0) | 5 (net +99) | 1 (net +233) | 6 (net +51) | 0 | 7% (1 of 14) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +65) | 1 (net +38) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Empire of Man | 8 | 2 (net +0) | 0 | 2 (net +104) | 1 (net +265) | 0 | 2 (net +0) | 1 | 29% (2 of 7) |
| Mine | Grand Cathay | 14 | 1 (net +0) | 3 (net +284) | 2 (net -108) | 1 (net +0) | 3 (net +45) | 3 (net -68) | 1 | 15% (2 of 13) |
| Mine | High Elf Realms | 13 | 2 (net +332) | 1 (net +0) | 1 (net +708) | 3 (net +121) | 2 (net +36) | 3 (net +103) | 1 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +608) | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +340) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 2 (net +138) | 0 | 0 | 0 | 1 | 100% (2 of 2) |
| Mine | Orc & Goblin Tribes | 10 | 0 | 0 | 1 (net -55) | 0 | 0 | 1 (net +137) | 8 | 50% (1 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +19) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +0) | 0 | 3 (net +113) | 3 (net +107) | 2 (net +60) | 1 (net +0) | 0 | 30% (3 of 10) |
| Mine | Vampire Counts | 8 | 1 (net -229) | 1 (net -60) | 1 (net +0) | 2 (net +0) | 1 (net +98) | 2 (net +0) | 0 | 12% (1 of 8) |
| Mine | Warriors of Chaos | 3 | 1 (net +28) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Grand Cathay | 9 | 2 (net -217) | 0 | 3 (net +0) | 3 (net +317) | 0 | 1 (net +0) | 0 | 33% (3 of 9) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 1 (net -199) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Kingdom of Bretonnia | 7 | 2 (net +82) | 0 | 0 | 1 (net +165) | 2 (net +134) | 1 (net +379) | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +286) | 2 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 17 | 3 (net +35) | 1 (net +511) | 5 (net +132) | 4 (net +352) | 2 (net +0) | 2 (net +88) | 0 | 29% (5 of 17) |
| Opponent | Vampire Counts | 32 | 9 (net +205) | 1 (net +0) | 5 (net +207) | 8 (net +77) | 4 (net +94) | 5 (net +96) | 0 | 16% (5 of 32) |
| Opponent | Warriors of Chaos | 33 | 4 (net +328) | 0 | 7 (net +187) | 8 (net +115) | 2 (net +83) | 9 (net +275) | 3 | 23% (7 of 30) |
| Opponent | Wood Elf Realms | 12 | 1 (net +395) | 0 | 1 (net -258) | 1 (net +287) | 1 (net +60) | 2 (net +0) | 6 | 17% (1 of 6) |

### Charged fights, damage counted: hc-mine-31c41bf-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 188 | 225 | +104 | 167 | 56 | +111 | +58.8 |
| Mine | 50-54% | 6 | 318 | 308 | +210 | 284 | 53 | +231 | +72.5 |
| Mine | Effective (55-75%) | 15 | 280 | 203 | +111 | 181 | 73 | +108 | +38.7 |
| Mine | 76-89% | 20 | 260 | 173 | +75 | 92 | 14 | +77 | +29.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 251 | 157 | +29 | 105 | 19 | +86 | +34.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 457 | 91 | +73 | 82 | 13 | +69 | +15.1 |
| Mine | No odds | 15 | 264 | 214 | +66 | 116 | 58 | +58 | +21.9 |
| Mine | All fights | 95 | 277 | 187 | +81 | 132 | 38 | +93 | +33.7 |
| Opponent | Long shot (under 50%) | 21 | 342 | 309 | +161 | 233 | 97 | +136 | +39.6 |
| Opponent | 50-54% | 2 | 268 | 268 | +256 | 297 | 4 | +293 | +109.7 |
| Opponent | Effective (55-75%) | 22 | 245 | 244 | +116 | 175 | 66 | +110 | +44.8 |
| Opponent | 76-89% | 25 | 334 | 239 | +174 | 204 | 30 | +174 | +52.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 319 | 223 | +185 | 241 | 36 | +205 | +64.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 431 | 90 | +73 | 76 | 1 | +75 | +17.4 |
| Opponent | No odds | 13 | 143 | 187 | +50 | 82 | 40 | +43 | +29.7 |
| Opponent | All fights | 117 | 304 | 229 | +140 | 186 | 47 | +138 | +45.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-mine-31c41bf-p3 | move | 341 | 77 (23%) | 52 (15%) | 47 (14%) | 217 (64%) |
| hc-mine-31c41bf-p3 | objective | 365 | 63 (17%) | 46 (13%) | 39 (11%) | 263 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

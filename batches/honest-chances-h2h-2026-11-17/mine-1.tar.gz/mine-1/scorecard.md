# Doctrine scorecard: hc-mine-31c41bf-p1

### Scorecard: hc-mine-31c41bf-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 5 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 5 | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 1 | 0 | 0 | 516 |
| L0135 | 3 | 1 | Mine | no | 3 | 4 | 2 | 2 | 0 | 0 | 0 | 442 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 0 | 3 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 6 | 4 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 7 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 1167 |
| L0628 | 4 | 1 | Opponent | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 4 | 3 | 1 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 2 | 0 | 0 | 315 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 970 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 2 | - | 1 | 3 | 1 | 0 | 0 | 1017 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 828 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1224 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 5 | 3 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 3 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 1 | 0 | 0 | 365 |
| L1527 | 3 | 1 | Mine | yes | 8 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 4 | 2 | 0 | 2 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 72 |
| L1823 | 5 | 1 | Mine | no | - | - | 4 | 1 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 3 | 0 | 0 | 72 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 161 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 185 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 2 | 2 | 0 | 0 | 860 |
| L2025 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 2 | 0 | 0 | 0 | 211 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 7 | 2 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 6 | 2 | 1 | 2 | 0 | 0 | 848 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 2 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 6 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 4 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 2.4 | 3.0 | 2.1 | 1.0 | 0.5 | 0.0 | 0.0 | 346.8 |
| **Average** | | | Opponent | 12% | 2.4 | 2.6 | 2.6 | 1.8 | 0.6 | 0.0 | 0.0 | 220.8 |

### KPIs: hc-mine-31c41bf-p1

Rules off - Opponent only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (56 of 173) | 5% (8 of 174) | 18% (64 of 347) |
| Winner chose to follow up after the loser gave ground |  | 100% (50 of 50); on the table 100% | 100% (41 of 41); on the table 100% | 100% (91 of 91); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (11 of 11); on the table 100% | 88% (14 of 16); on the table 94% | 93% (25 of 27); on the table 96% |
| Winner chose to pursue after the loser fled |  | 91% (29 of 32); on the table 94% | 82% (33 of 40); on the table 85% | 86% (62 of 72); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 97% (90 of 93); on the table 98% | 91% (88 of 97); on the table 93% | 94% (178 of 190); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 32% (105 of 330) | 28% (58 of 210) | 30% (163 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (105 of 242) | 35% (52 of 149) | 40% (157 of 391) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (21 of 34) | 50% (29 of 58) | 54% (50 of 92) |
| Points that never fought | lower | 35% (25145 of 71484) | 40% (29106 of 71889) | 38% (54251 of 143373) |
|   infantry points that never fought | lower | 43% (7295 of 16863) | 60% (8056 of 13348) | 51% (15351 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (162 of 279) | 58% (171 of 295) | 58% (333 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.9 uses a game | 75% (15 of 20); 1.3 uses a game | 83% (35 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.4 uses a game | 25% (2 of 8); 0.1 uses a game | 54% (13 of 24); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 42% (8 of 19); 0.2 uses a game | 75% (9 of 12); 0.2 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30933 of 59666) | 51% (31794 of 62699) | 51% (62727 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (40%) | 1.3 (30%) | 3.8 (36%) |
| MARCHED: its unit marched | 0.8 (13%) | 0.7 (16%) | 1.5 (14%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.1 (3%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.5 (11%) | 1.8 (17%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (10%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (16%) | 1.0 (24%) | 2.0 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.2 | 1.2 | 4.5 | 0.5 | 1.8 |
| not cast | 3.6 | 3.1 | 3.4 | 10.5 | 1.8 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (43%) | 0.4 (11%) | 3.8 (36%) | 0.6 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (14%) | 0.2 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (5%) | 0.3 (9%) | 1.8 (17%) | 0.4 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.3 (10%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (20%) | 0.8 (25%) | 0.8 (24%) | 2.0 (19%) | 0.1 (3%) | 3.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.2 (5%) | 0.2 (5%) | 0.1 (1%) | 0.1 (3%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (65%) | 0.2 (5%) | 1.4 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.9 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 70% (23 of 33) | 59% (10 of 17) | 66% (33 of 50) |
| the unit moved after it | 57% (13 of 23) | 80% (8 of 10) | 64% (21 of 33) |
| it charged on its next turn | 4% (1 of 23) | 0% (0 of 10) | 3% (1 of 33) |
| the enemy charged it first | 22% (5 of 23) | 0% (0 of 10) | 15% (5 of 33) |
| it fought by the end of its next turn | 17% (4 of 23) | 0% (0 of 10) | 12% (4 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (2 of 23) | 10% (1 of 10) | 9% (3 of 33) |
| none of these (no charge, no fight, no charge escaped) | 65% (15 of 23) | 90% (9 of 10) | 73% (24 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (570 of 929) | 57% (349 of 611) | 60% (919 of 1540) |
|   cavalry | 56% (50 of 90) | 65% (80 of 124) | 61% (130 of 214) |
|   character | 54% (68 of 125) | 34% (42 of 123) | 44% (110 of 248) |
|   chariot | 47% (47 of 99) | 67% (28 of 42) | 53% (75 of 141) |
|   infantry | 58% (180 of 312) | 55% (127 of 232) | 56% (307 of 544) |
|   monster | 59% (24 of 41) | 52% (13 of 25) | 56% (37 of 66) |
|   war machine | 77% (201 of 262) | 91% (59 of 65) | 80% (260 of 327) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.9 (29%) | 1.5 (20%) | 4.4 (25%) |
| CHARGED: it charged | 1.1 (11%) | 1.5 (21%) | 2.6 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.6 (8%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| NO TARGET IN RANGE | 1.8 (18%) | 1.8 (24%) | 3.5 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 1.0 (13%) | 1.6 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (18%) | 0.8 (11%) | 2.5 (15%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.9 | 83% | 4.1 pts | 21 pts |
| character | 3.4 | 0.6 | 89% | 3.5 pts | 12 pts |
| chariot | 2.1 | 1.1 | 71% | 10.6 pts | 23 pts |
| infantry | 12.4 | 4.5 | 73% | 10.0 pts | 124 pts |
| monster | 1.3 | 0.3 | 83% | 3.6 pts | 5 pts |
| war machine | 7.2 | 5.0 | 69% | 25.4 pts | 183 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.6 | 4.7 |
| Charges that made contact a game | 2.6 | 3.8 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.57 contact (21 units) | 0.43 declared, 0.29 contact (14 units) | 0.66 declared, 0.46 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.86 declared, 0.57 contact (7 units) | 2.00 declared, 1.29 contact (7 units) | 1.43 declared, 0.93 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.32 contact (247 units) | 0.66 declared, 0.45 contact (277 units) | 0.56 declared, 0.39 contact (524 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (41 of 70) | 57% (12 of 21) | 38% (3 of 8) | 57% (56 of 99) |
| Character in a unit | 88% (29 of 33) | 52% (12 of 23) | 67% (2 of 3) | 73% (43 of 59) |
| Character on its own | 87% (47 of 54) | 51% (19 of 37) | 24% (15 of 63) | 53% (81 of 154) |
| Chariot | 56% (9 of 16) | 60% (6 of 10) | - | 58% (15 of 26) |
| Infantry | 52% (46 of 89) | 39% (14 of 36) | 50% (1 of 2) | 48% (61 of 127) |
| Monster | 59% (19 of 32) | 90% (9 of 10) | - | 67% (28 of 42) |
| Monstrous | 64% (7 of 11) | 79% (11 of 14) | - | 72% (18 of 25) |
| War Machines | 73% (30 of 41) | 100% (1 of 1) | - | 74% (31 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 86% (12 of 14); on the table 93% | 28% (38 of 138) | 30% | 48% (16 of 33) | 89% (8 of 9); 3.7 uses a game | 100% (3 of 3); 1.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (4 of 4); on the table 100% | 33% (8 of 24) | 33% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (9 of 9); on the table 100% | - | 53% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (14 of 14); on the table 100% | 56% (20 of 36) | 47% | 62% (40 of 64) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 94% (15 of 16); on the table 94% | 25% (27 of 108) | 39% | 45% (20 of 44) | 100% (12 of 12); 8.8 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 100% (26 of 26); on the table 100% | 20% (6 of 30) | 32% | 41% (20 of 49) | 100% (5 of 5); 2.8 uses a game | 44% (8 of 18); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 75% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 86% (6 of 7); on the table 86% | - | 34% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 88% (7 of 8); on the table 88% | 8% (1 of 12) | 60% | 67% (14 of 21) | 33% (1 of 3); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (5 of 5); on the table 100% | 14% (5 of 36) | 12% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (8 of 8); on the table 100% | 43% (13 of 30) | 31% | 59% (20 of 34) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 91% (29 of 32); on the table 94% | 17% (2 of 12) | 32% | 37% (11 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (18 of 19); on the table 95% | 59% (32 of 54) | 44% | 58% (29 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 77% (10 of 13); on the table 85% | 13% (4 of 30) | 38% | 72% (53 of 74) | 100% (4 of 4); 2.4 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (13 of 13); on the table 100% | 23% (7 of 30) | 31% | 58% (38 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (hc-mine-31c41bf-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (32) | 45% (26) | 45% (58) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.42 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.08 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.28 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.11 | 0.94 | 3.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.75 | 0.83 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.31 | 5.11 | 10.42 |

### Quality by phase: hc-mine-31c41bf-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 50% (54 of 107) | 40% (67 of 166) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (186 of 464) | 51% (118 of 230) |
| Strategy | Close-in objectives charged next turn | 16% (18 of 110) | 16% (39 of 241) |
| Strategy | Support requests answered (helper made contact too) | 50% (9 of 18) | 52% (12 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (10 of 16) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 36% (16 of 44) | 43% (20 of 46) |
| Strategy | Lone characters that fought | 75% (77 of 102) | 74% (67 of 90) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 346.8 | 220.8 |
| Movement | Fights charged into per game | 2.4 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 72, net +143 | 9 of 96, net +76 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 72, net +18 | 25 of 96, net +150 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 72, net +67 | 5 of 96, net +121 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 72, net +112 | 30 of 96, net +238 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.2 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (185 of 403) | 42% (135 of 319) |
| Shooting | Points destroyed by shooting units | 100.1 | 29.8 |
| Shooting | War machine shots | 5.6 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (114 of 201) | 39% (23 of 59) |
| Shooting | Points destroyed by war machines | 56.8 | 11.8 |
| Magic | Magic missiles cast | 1.8 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (16 of 64) | 17% (7 of 42) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.1 |
| Magic | Wounds caused by other spells | 1.7 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 99.8 | 31.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.5 / 0.9 / 0.2 | 1.6 / 0.4 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 268.2 | 415.4 |
| Combat | Points run down | 101.5 | 195.3 |
| Combat | Net points per charged fight, damage counted | +93 | +141 |
| Combat | Net per 100 charger points, damage counted | +33.7 | +47.7 |
| Combat | First round won (charged fights) | 75% | 75% |
| Combat | Net points per charged fight | +94 | +140 |
| Combat | Net points per supported fight / lone fight | +193 / +81 | +161 / +137 |
| Combat | Charged fights on a top-3 enemy unit | 37 of 85 | 52 of 116 |
| Game | Points lost | 795.2 | 715.1 |
| Game | VP from objectives | 582.2 | 678.6 |
| Game | Lone holders (player turns) | 2.4 | 2.4 |

- Mine won / drew / lost: 15 / 4 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -214 VP
- The side that went first won 13 of 32 games with a winner
- Points traded per game (both sides' losses): 1510
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-mine-31c41bf-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 6.2 | -184.7 | 184.5 | 135.3 | 4.2 | -152.2 | 130.4 | 46.6 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 0.0 | 7.2 |
| BACKUP TARGETS | 0.2 | +0.3 | 0.0 | 0.0 | 0.6 | +4.2 | 0.0 | 5.4 |
| BEST FACING | 0.4 | +9.1 | 0.0 | 0.0 | 0.1 | +7.1 | 0.0 | 11.1 |
| BEST FIRST | 1.2 | +50.3 | 25.8 | 18.7 | 0.8 | +31.2 | 24.9 | 26.0 |
| BEST OVERALL | 0.2 | +10.2 | 0.0 | 0.0 | 0.2 | +6.2 | 0.0 | 11.1 |
| BEST PREY | 0.7 | +31.9 | 37.2 | 39.7 | 0.7 | +31.0 | 35.6 | 12.1 |
| BEST PRIZE | 0.1 | -3.5 | 0.0 | 0.0 | 0.1 | -8.8 | 3.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 15.0 | 0.2 | -1.2 | 0.0 | 24.2 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +2.3 | 3.5 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.0 | 0.0 | 0.1 | +0.0 | 6.1 | 0.0 |
| BLOCKED WHEEL | 0.2 | +7.3 | 0.0 | 0.0 | 0.2 | +4.7 | 0.0 | 7.9 |
| BLOWS WHERE AIMED | 0.3 | -35.0 | 40.2 | 38.5 | 0.2 | -15.3 | 43.8 | 2.5 |
| BOMBING RUN | 0.0 | +0.9 | 4.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 93.4 | 6.1 | 0.1 | +0.0 | 6.3 | 3.6 |
| CANNON PLANNED TARGET | 4.6 | +153.4 | 285.5 | 87.9 | 1.4 | +20.8 | 66.9 | 14.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 15.6 | 12.3 | 0.1 | +0.0 | 1.8 | 3.5 |
| CAST JOB | 1.2 | +48.8 | 103.3 | 40.7 | 0.9 | +13.6 | 23.9 | 25.7 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +48.0 | 46.2 | 10.9 | 0.3 | +8.1 | 4.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 30.2 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.1 | +66.5 | 0.0 | 31.6 | 1.4 | +84.9 | 0.0 | 52.7 |
| CHAFF PASSED | 0.3 | -0.4 | 5.4 | 0.0 | 0.3 | -0.7 | 4.9 | 12.6 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 201.2 | 64.5 | 2.6 | +0.0 | 292.8 | 61.1 |
| CHARGE NOW WEIGHED | 0.4 | -29.1 | 6.4 | 43.2 | 0.5 | -44.6 | 3.1 | 26.5 |
| CHARGER SLAIN LOST | 0.4 | -41.2 | 44.7 | 22.3 | 1.0 | -26.3 | 112.6 | 20.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 6.5 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.2 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 6.5 | 4.8 | 0.1 | +0.0 | 5.0 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 9.2 | 13.7 | 0.5 | +0.0 | 37.1 | 10.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.4 | +38.6 | 0.0 | 24.7 | 0.3 | +93.4 | 0.0 | 15.2 |
| COVER ONCE | 8.4 | -755.7 | 0.0 | 212.2 | 5.5 | -340.0 | 0.0 | 161.9 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 25.4 | 2.9 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +4.3 | 11.9 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +5.8 | 17.1 | 9.4 | 0.3 | +10.1 | 34.6 | 0.9 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +135.0 | 0.0 | 68.2 | 0.9 | +68.6 | 0.0 | 64.2 |
| FALLBACK BY WORTH | 4.2 | +41.8 | 0.0 | 58.1 | 5.3 | +79.0 | 0.0 | 48.3 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 140.6 | 4.1 | +0.0 | 0.0 | 111.8 |
| FOCUS FIRE | 0.0 | +0.5 | 3.1 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.5 | +53.0 | 0.0 | 42.2 | 0.6 | +95.1 | 0.0 | 25.9 |
| FRIENDS SHOTS CHECKED | 0.4 | +21.8 | 0.0 | 12.3 | 0.2 | +12.5 | 0.0 | 3.5 |
| GIVES UP | 0.1 | -1.4 | 17.5 | 0.0 | 0.2 | -1.7 | 29.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.8 | 7.8 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 6.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 10.5 | 3.1 | 0.4 | +0.0 | 17.9 | 6.4 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.2 | -65.5 | 281.1 | 108.2 | 9.8 | -196.4 | 539.2 | 148.2 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +11.7 | 10.4 | 3.2 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.5 | 3.2 |
| HUNT IN PAIRS | 0.3 | +15.2 | 0.0 | 15.7 | 0.6 | +31.3 | 0.0 | 5.4 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +4.9 | 6.9 | 3.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +17.0 | 6.9 | 9.3 |
| HUNT THE GUNS | 0.1 | +24.8 | 0.0 | 0.0 | 0.2 | +69.9 | 11.5 | 0.0 |
| IDLE COST | 15.1 | -250.1 | 0.0 | 148.3 | 18.6 | -282.4 | 0.0 | 199.6 |
| INVITES THE FIGHT | 1.8 | +21.8 | 53.2 | 41.1 | 0.9 | +5.8 | 37.3 | 3.5 |
| JOINT CHARGE PLAN | 0.2 | +13.1 | 7.3 | 5.2 | 0.4 | +13.9 | 0.0 | 11.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.5 | 10.5 | 0.0 |
| KEEP FALLS | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +32.5 | 124.1 | 36.5 | 2.3 | +69.2 | 187.0 | 25.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +53.3 | 106.7 | 43.8 | 1.8 | +120.2 | 125.9 | 34.2 |
| KILLS COUNT NEXT TURN | 1.8 | +65.3 | 66.8 | 88.0 | 6.8 | +254.2 | 290.6 | 140.5 |
| LONE CHARACTER SAFE SPOT | 0.4 | +7.8 | 4.7 | 15.0 | 0.6 | +31.2 | 8.4 | 28.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 1.5 | 16.1 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -4.1 | 20.9 | 5.5 | 0.6 | -4.1 | 34.7 | 15.3 |
| LOST CHARGE | 2.7 | -34.2 | 100.9 | 111.1 | 2.7 | -37.9 | 51.1 | 125.9 |
| LURE BY WHAT IT DRAWS | 0.2 | -12.0 | 0.0 | 3.1 | 0.2 | -26.2 | 0.0 | 23.6 |
| MAKE SURE TOGETHER | 0.4 | +21.9 | 15.9 | 0.0 | 1.2 | +66.8 | 5.8 | 18.4 |
| MANOEUVRE | 0.2 | +0.9 | 0.0 | 7.1 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +20.4 | 0.0 | 15.8 | 0.2 | +14.1 | 0.0 | 4.7 |
| MARCH ODDS | 0.2 | +10.2 | 16.5 | 0.0 | 0.2 | +13.1 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.6 | +50.8 | 0.0 | 15.0 | 0.4 | +48.0 | 0.0 | 23.3 |
| MAX FOR POSITIONING | 4.5 | +57.8 | 0.0 | 72.3 | 7.3 | +99.8 | 0.0 | 150.2 |
| MEASURED NEXT CHARGE | 8.9 | -188.8 | 122.6 | 170.4 | - | - | - | - |
| MISSILES IN THE MOVE | 4.4 | +189.7 | 0.0 | 69.1 | 3.6 | +59.9 | 0.0 | 111.9 |
| MISSILES NEXT TURN | 5.2 | +119.3 | 0.0 | 110.1 | 4.0 | +38.3 | 0.0 | 108.1 |
| MODEL FACING | 0.3 | +103.3 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 6.2 | 10.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +36.6 | 0.0 | 2.2 | 0.5 | +37.1 | 0.0 | 9.1 |
| MOVE SPELL IN RANGE | 0.2 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -67.4 | 0.0 | 26.9 | 0.1 | -1.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 0.6 | +4.8 | 17.7 | 1.8 | 5.4 | +333.0 | 199.7 | 109.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 3.5 | 0.0 | 0.0 | +0.0 | 4.9 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -3.5 | 11.7 | 2.0 | 0.2 | -7.5 | 13.0 | 0.0 |
| NOT TURNED | 5.3 | +73.9 | 0.0 | 118.2 | 5.1 | +66.8 | 0.0 | 113.6 |
| NOT WORTH A CAST | 1.0 | -0.7 | 0.0 | 59.4 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 15.8 | -606.2 | 21.4 | 259.0 | 16.4 | -727.8 | 16.5 | 236.8 |
| ONE FIGHT FORMULA | 8.1 | -136.6 | 33.9 | 200.1 | 8.6 | -163.8 | 24.8 | 180.5 |
| ONE OBJECTIVE FORMULA | 2.5 | -79.7 | 0.0 | 45.7 | 2.0 | -54.4 | 0.0 | 48.7 |
| OPENS A LANE | 0.2 | +0.6 | 56.4 | 6.2 | - | - | - | - |
| OPENS UP | 0.1 | +1.0 | 9.6 | 0.0 | 0.2 | +14.9 | 10.2 | 7.9 |
| OVERRUNS AWAY | 0.5 | +6.5 | 44.2 | 16.9 | 0.6 | +13.6 | 41.9 | 6.7 |
| PATHS CROSS | 2.0 | +114.2 | 0.0 | 2.5 | 2.6 | +138.7 | 0.0 | 47.8 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -5.8 | 0.0 | 2.4 | 0.1 | -3.5 | 0.0 | 10.0 |
| PLAN RESULT | 37.3 | +1532.9 | 1439.4 | 987.8 | 38.3 | +1159.4 | 1430.3 | 916.3 |
| PURSUES BIG PREY | 0.0 | -0.2 | 0.0 | 0.0 | 0.2 | -15.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +10.5 | 0.0 | 17.9 | 1.6 | +22.1 | 0.0 | 28.1 |
| RANDOM MOVER NO PROMISE | 0.0 | -2.5 | 0.0 | 0.0 | 0.3 | -12.9 | 8.9 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 1.0 | -17.4 | 0.0 | 28.5 | 0.8 | -20.2 | 0.0 | 22.0 |
| REDIRECT COUNTER | 1.8 | +114.2 | 0.0 | 31.0 | 3.4 | +298.7 | 0.0 | 64.7 |
| REDIRECT WEIGHED | 0.2 | +0.5 | 0.0 | 10.3 | 0.2 | +1.6 | 2.6 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 41.5 | 0.3 | +0.0 | 0.0 | 11.6 |
| RESERVE FALL BACK | 0.6 | +16.5 | 0.0 | 4.9 | 0.6 | +17.2 | 0.0 | 14.3 |
| RESTRAINS TO SHOOT | 0.1 | +1.9 | 0.0 | 6.5 | 0.1 | +4.8 | 0.0 | 21.8 |
| RISK BY ARC | 2.0 | +65.7 | 197.9 | 103.9 | 2.3 | +60.0 | 239.9 | 78.3 |
| RISK ONCE | 2.9 | +40.5 | 33.4 | 78.6 | 6.3 | +349.0 | 84.8 | 348.1 |
| RUN DOWN | 1.4 | -3.7 | 141.2 | 42.9 | - | - | - | - |
| SAFE SURE CHARGE | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.8 | +44.9 | 0.0 | 8.8 | 0.8 | +36.0 | 0.0 | 33.2 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.4 | 0.0 | 0.9 | 0.3 | -12.3 | 0.0 | 3.6 |
| SEARCH SPOT | 1.8 | +68.1 | 0.0 | 26.9 | 2.2 | +101.6 | 0.0 | 31.3 |
| SELF MOVE SPELL | 0.2 | +6.7 | 0.0 | 18.1 | 0.1 | -0.2 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.0 | +90.6 | 36.6 | 27.5 | 2.4 | +153.6 | 5.8 | 66.2 |
| SET-UP ANY TARGET | 0.2 | +16.7 | 0.0 | 0.0 | 0.1 | +3.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 1.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +106.9 | 148.7 | 8.0 | 0.8 | +43.7 | 25.4 | 24.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 154.8 | 14.8 | 0.1 | +0.0 | 25.3 | 1.8 |
| SHOTS IN THE MOVE | 14.5 | +620.0 | 0.0 | 213.3 | 8.6 | +230.8 | 0.0 | 143.4 |
| SPELL SETS UP CHARGE | 0.2 | +23.2 | 0.0 | 0.0 | 0.1 | +58.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +20.2 | 85.6 | 92.8 | 1.8 | +35.7 | 70.9 | 77.4 |
| SPELLS IN THE FIGHT | 0.5 | -1.4 | 62.6 | 13.3 | 0.5 | -9.1 | 54.4 | 15.3 |
| STABLE ROLE | 11.0 | +0.0 | 376.5 | 126.4 | 11.2 | +0.0 | 522.9 | 157.7 |
| STANDS TO CAST | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +4.2 | 8.1 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +29.6 | 0.0 | 3.5 | 0.4 | +9.5 | 0.0 | 4.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.1 | -59.5 | 274.1 | 87.5 | 7.9 | -60.4 | 469.2 | 59.0 |
| SUPPORTS | 3.8 | +63.3 | 166.2 | 44.1 | 5.4 | +60.6 | 224.9 | 34.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.2 | 2.1 | 0.0 | 0.1 | -4.3 | 15.0 | 0.0 |
| SURE REACH TOGETHER | 0.2 | -2.4 | 1.1 | 0.0 | 0.9 | +3.3 | 9.6 | 13.8 |
| THROUGH LINE OF FIRE | 0.4 | +17.9 | 0.0 | 0.0 | 0.2 | +16.4 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -22.0 | 34.7 | 4.2 | 0.1 | -10.5 | 7.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +2.2 | 8.6 | 7.8 | 0.7 | +4.4 | 0.0 | 16.3 |
| WAIT AFTER COSTS | 3.7 | -210.0 | 114.4 | 55.8 | 8.2 | -409.6 | 305.5 | 137.7 |
| WALKS TO THE FIGHT | 1.7 | +12.9 | 43.5 | 12.8 | 1.0 | +7.9 | 18.8 | 8.3 |
| WAR ENGINE CHARGES | 0.0 | +4.3 | 0.0 | 0.0 | 0.0 | +2.0 | 4.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 37.2 | 5.8 | 0.4 | +0.0 | 8.5 | 6.9 |
| WEARS DOWN | 0.8 | +61.6 | 144.2 | 51.1 | 1.2 | +36.9 | 156.9 | 33.4 |
| WHO HITS BACK | 0.1 | +2.0 | 0.0 | 14.5 | 0.3 | +28.6 | 0.0 | 15.3 |
| WHOLE FIGHT | 0.3 | +11.7 | 17.3 | 0.0 | 0.5 | +21.5 | 102.6 | 8.3 |
| WHOLE FIGHT GAIN | 0.3 | +25.7 | 24.4 | 8.1 | 0.6 | +47.0 | 43.5 | 7.6 |
| WIDER SPREAD | 2.0 | -1.7 | 206.2 | 76.6 | 3.4 | -6.8 | 342.4 | 71.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 2.3 | 0.0 |

### Rule changes: hc-mine-31c41bf-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1156 | 1156 | 1156 | 32.11 | -48023 | -41.5 |
| PATHS CROSS | 166 | 166 | 166 | 4.61 | +9106 | +54.9 |
| SEARCH SPOT | 144 | 144 | 141 | 3.92 | +6112 | +43.3 |
| SUPPORTS | 333 | 333 | 120 | 3.33 | +1333 | +11.1 |
| FACES THE THREAT | 110 | 110 | 110 | 3.06 | +7330 | +66.6 |
| MOVE TO CHARGE | 216 | 216 | 104 | 2.89 | +4356 | +41.9 |
| KILLS COUNT NEXT TURN | 310 | 310 | 98 | 2.72 | +3056 | +31.2 |
| FALLBACK BY WORTH | 341 | 341 | 89 | 2.47 | +4349 | +48.9 |
| WAIT AFTER COSTS | 426 | 426 | 88 | 2.44 | +1413 | +16.1 |
| RISK ONCE | 332 | 253 | 86 | 2.39 | +2643 | +30.7 |
| COVER ONCE | 502 | 264 | 85 | 2.36 | +1177 | +13.8 |
| SHOTS IN THE MOVE | 831 | 564 | 81 | 2.25 | +2382 | +29.4 |
| BEST FIRST | 69 | 69 | 69 | 1.92 | +2935 | +42.5 |
| ADVANCE WORTH | 374 | 374 | 62 | 1.72 | +1134 | +18.3 |
| CHAFF IN THE MOVE | 93 | 89 | 62 | 1.72 | +2265 | +36.5 |
| MEASURED NEXT CHARGE | 319 | 242 | 61 | 1.69 | +644 | +10.6 |
| MISSILES IN THE MOVE | 290 | 199 | 61 | 1.69 | +1737 | +28.5 |
| ONE FIGHT FORMULA | 602 | 388 | 59 | 1.64 | +395 | +6.7 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +2914 | +51.1 |
| SET UP TOGETHER | 120 | 104 | 56 | 1.56 | +3417 | +61.0 |
| SHOOTS FROM THE BEST SPOT | 112 | 112 | 55 | 1.53 | +2303 | +41.9 |
| REDIRECT COUNTER | 188 | 110 | 54 | 1.50 | +4650 | +86.1 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 92 | 92 | 50 | 1.39 | +1171 | +23.4 |
| INVITES THE FIGHT | 97 | 97 | 49 | 1.36 | +466 | +9.5 |
| IDLE COST | 1213 | 704 | 47 | 1.31 | +499 | +10.6 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| CANNON PLANNED TARGET | 213 | 213 | 42 | 1.17 | +104 | +2.5 |
| WALKS TO THE FIGHT | 96 | 96 | 42 | 1.17 | +224 | +5.3 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +1213 | +29.6 |
| KILLS COUNT | 121 | 119 | 40 | 1.11 | +2022 | +50.5 |
| FOLLOW UP WEIGHED | 39 | 39 | 39 | 1.08 | +5332 | +136.7 |
| RISK BY ARC | 156 | 153 | 37 | 1.03 | +900 | +24.3 |
| STOPS SHORT OF THE FLANK | 36 | 36 | 36 | 1.00 | +1405 | +39.0 |
| MAX FOR POSITIONING | 425 | 276 | 35 | 0.97 | +80 | +2.3 |
| MOVE AND CAST | 35 | 35 | 35 | 0.97 | +2652 | +75.8 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| CAST JOB | 78 | 78 | 33 | 0.92 | +1003 | +30.4 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +1960 | +63.2 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| KEEPS ITS TARGET | 122 | 122 | 28 | 0.78 | +556 | +19.9 |
| MARCH CHECK | 29 | 27 | 27 | 0.75 | +1530 | +56.7 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| MAKE SURE TOGETHER | 57 | 48 | 22 | 0.61 | +1228 | +55.8 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -37 | -1.9 |
| CHARGE NOW FIRST | 150 | 150 | 20 | 0.56 | -755 | -37.7 |
| HONEST WORTH | 505 | 503 | 20 | 0.56 | +131 | +6.6 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +1236 | +61.8 |
| BEST FACING | 19 | 19 | 19 | 0.53 | +582 | +30.6 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1233 | +64.9 |
| BLOCKED WHEEL | 18 | 18 | 18 | 0.50 | +434 | +24.1 |
| CASTING BLOCK | 27 | 27 | 18 | 0.50 | +754 | +41.9 |
| MISSILES NEXT TURN | 330 | 220 | 17 | 0.47 | +21 | +1.2 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -63 | -3.9 |
| WAR ENGINE JOBS | 30 | 30 | 16 | 0.44 | -676 | -42.3 |
| BEST OVERALL | 15 | 15 | 15 | 0.42 | +589 | +39.3 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +529 | +35.3 |
| WHOLE FIGHT GAIN | 34 | 31 | 15 | 0.42 | +795 | +53.0 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +804 | +57.4 |
| BEST PREY | 50 | 50 | 12 | 0.33 | +250 | +20.8 |
| HUNT IN PAIRS | 31 | 21 | 12 | 0.33 | +576 | +48.0 |
| MARCH ODDS | 13 | 13 | 12 | 0.33 | +206 | +17.2 |
| LOST CHARGE | 192 | 191 | 11 | 0.31 | +565 | +51.4 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +3720 | +338.2 |
| REFUSING RETIRES | 26 | 26 | 11 | 0.31 | -3 | -0.2 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SUPPORT NARROWED | 470 | 470 | 11 | 0.31 | -260 | -23.7 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -334 | -33.5 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +243 | +27.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WEARS DOWN | 72 | 69 | 8 | 0.22 | +788 | +98.5 |
| WHOLE FIGHT | 29 | 29 | 8 | 0.22 | +662 | +82.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -580 | -82.8 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -271 | -38.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -443 | -88.5 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 9 | 9 | 4 | 0.11 | +97 | +24.2 |
| MANOEUVRE | 8 | 8 | 4 | 0.11 | +45 | +11.1 |
| ONE OBJECTIVE FORMULA | 162 | 74 | 4 | 0.11 | +56 | +13.9 |
| OVERRUNS AWAY | 40 | 40 | 4 | 0.11 | +80 | +20.0 |
| BACKUP TARGETS | 27 | 13 | 3 | 0.08 | +0 | +0.1 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -56 | -18.8 |
| EDGE GIVE GROUND | 13 | 13 | 3 | 0.08 | +175 | +58.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +136 | +45.5 |
| OPENS UP | 11 | 11 | 3 | 0.08 | +128 | +42.8 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +100 | +33.4 |
| SURE REACH TOGETHER | 42 | 33 | 3 | 0.08 | +30 | +10.1 |
| CHARGER SLAIN LOST | 51 | 48 | 2 | 0.06 | +6 | +2.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +82 | +40.8 |
| JOINT CHARGE PLAN | 23 | 23 | 2 | 0.06 | +152 | +76.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +153 | +76.6 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -7 | -3.3 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +8 | +4.2 |
| WIDER SPREAD | 194 | 185 | 2 | 0.06 | +12 | +6.1 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +84 | +83.6 |
| BLOWS WHERE AIMED | 20 | 19 | 1 | 0.03 | +83 | +82.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -70 | -70.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +16 | +16.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +19 | +19.1 |
| GIVES UP ITS SCREEN | 3 | 3 | 1 | 0.03 | +5 | +5.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +15 | +15.4 |
| LONG SHOT | 36 | 34 | 1 | 0.03 | +2 | +1.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| RUN DOWN | 50 | 49 | 1 | 0.03 | +83 | +82.7 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -6 | -5.9 |
| TWO OR MORE ARRIVE | 36 | 30 | 1 | 0.03 | +4 | +4.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 13 | 13 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 332 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 24 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 37 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 15 | 15 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 15 | 15 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NEEDED THERE | 2 | 2 | 0 | 0.00 | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 375 | 375 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2721 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 65 | 65 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 107 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 36 | 31 | 0 | 0.00 | - | - |
| STABLE ROLE | 798 | 796 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: hc-mine-31c41bf-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.44 | 14.36 | 42.1 |
| FALLBACK | gate | 0.64 | 0.92 | 45.3 |
| TURN GATE | gate | 0.28 | 0.53 | 23.1 |
| CHARGE NOW FIRST | rule | 0.25 | 0.31 | 37.7 |
| WAR ENGINE JOBS | rule | 0.28 | 0.17 | 42.3 |
| SUPPORT NARROWED | rule | 0.08 | 0.22 | 23.7 |
| SUPPORT REQUEST | gate | 0.14 | 0.17 | 74.0 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.14 | 9.8 |
| CHAFF PASSED | rule | 0.06 | 0.22 | 3.7 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 33.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.14 | 14.4 |
| AFTERMATH BAND | gate | 0.08 | 0.11 | 3.3 |
| PURSUES BIG PREY | rule | 0.03 | 0.17 | 82.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.14 | 38.7 |
| BEST PRIZE | rule | 0.06 | 0.08 | 88.5 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 36.1 |
| FACES THE THREAT | rule | 0.08 | 0.06 | 8.8 |
| PATHS CROSS | rule | 0.03 | 0.11 | 11.6 |
| CATCH ODDS | rule | 0.08 | - | 18.8 |
| FIGHT ORDER BAND | gate | - | 0.08 | 2.5 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 4.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 87.7 |
| MOVE AND CAST | rule | 0.03 | 0.03 | 3.5 |
| RULE SWITCHED OFF | gate | - | 0.06 | 8.8 |
| SAFER THAN THE JOB | rule | - | 0.06 | 20.9 |
| CANNON PLANNED TARGET | rule | 0.03 | - | 51.0 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 70.2 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.9 |
| NO REASON | gate | 0.03 | - | 37.6 |
| SAFE SURE CHARGE | rule | 0.03 | - | 5.9 |
| STANDS TO CAST | rule | - | 0.03 | 9.0 |
| WHO HITS BACK | rule | - | 0.03 | 4.2 |

### Plans: hc-mine-31c41bf-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 17% | 204 | 257 | 126% |
| Mine | charge | 2.6 | 65% | 195 | 247 | 127% |
| Mine | close in | 3.1 | 30% | 147 | 103 | 70% |
| Mine | hold | 5.1 | 36% | 290 | 0 | 0% |
| Mine | join | 0.6 | 100% | 22 | 0 | 0% |
| Mine | shoot | 10.8 | 57% | 459 | 926 | 201% |
| Mine | support | 4.9 | 89% | 47 | 0 | 0% |
| Opponent | advance | 9.9 | 18% | 147 | 314 | 214% |
| Opponent | charge | 4.0 | 65% | 355 | 420 | 118% |
| Opponent | close in | 6.7 | 23% | 406 | 173 | 43% |
| Opponent | hold | 4.8 | 43% | 328 | 0 | 0% |
| Opponent | join | 1.1 | 95% | 49 | 0 | 0% |
| Opponent | shoot | 5.2 | 54% | 139 | 252 | 182% |
| Opponent | support | 6.6 | 91% | 68 | 0 | 0% |

### Packages: hunt the guns, hc-mine-31c41bf-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 450 | 0 | 0% | 12 |
| Opponent | 0.2 | 7 | 0 | 29% | 43% | 14% | 2.7 | 360 | 88 | 29% | 70 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.4 | 2 | 1 | 0% | 0% | 0% | - | 450 | 0 | 0% | 85 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 109 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 298 | 62 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 269 | 217 | 100% | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 50% | - | 514 | 22 | 0% | 24 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 3.0 | 312 | 113 | 50% | 21 |

### Battle groups: hc-mine-31c41bf-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 34% | 50% | 9% | 50% | 20% | 5% | 5% | 65% | 5% |
| Opponent | REDIRECT COUNTER | 3.4 | 19% | 78% | 13% | 33% | 30% | 0% | 15% | 45% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-mine-31c41bf-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 33% | 5.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 37 | 5 (37) | 3 | 3 | 42 | 43% | 2.1 | 3 (16) | 0 (9) | 12 (12) | 0 (24) | 13 (13) |
| Mine | Character | 123 | 48 (123) | 48 | 0 | 45 | 19% | 2.3 | 76 (37) | 44 (55) | 7 (8) | 59 (56) | 49 (44) |
| Mine | Clean-up | 24 | 39 (24) | 22 | 17 | 44 | 38% | 3.0 | 50 (9) | 33 (11) | 8 (4) | 69 (14) | 3 (10) |
| Mine | Fast | 4 | 45 (4) | 45 | 0 | 13 | 0% | 1.5 | 0 (1) | 0 (2) | 362 (1) | 45 (4) | - |
| Mine | Fast Hammer | 41 | 20 (41) | 8 | 12 | 52 | 24% | 2.9 | 30 (18) | 14 (12) | 10 (11) | 27 (28) | 8 (13) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 0% | 1.8 | - | 17 (4) | 0 (1) | 0 (1) | 17 (4) |
| Mine | Hammer | 58 | 35 (58) | 20 | 15 | 47 | 9% | 2.7 | 21 (10) | 37 (38) | 38 (10) | 42 (34) | 27 (24) |
| Mine | Holder | 25 | 88 (25) | 8 | 81 | 24 | 48% | 3.1 | 128 (8) | 79 (11) | 55 (5) | 120 (10) | 71 (14) |
| Mine | Shooter | 44 | 136 (44) | 65 | 71 | 39 | 2% | 1.7 | 44 (5) | 165 (32) | 102 (7) | 152 (24) | 118 (20) |
| Mine | Support | 5 | 50 (5) | 50 | 0 | 42 | 20% | 3.0 | - | 86 (2) | - | 86 (2) | - |
| Mine | War machine | 56 | 38 (56) | 38 | 0 | 46 | 5% | 1.3 | 61 (13) | 37 (37) | 0 (6) | 34 (11) | 40 (45) |
| Mine | Wizard | 23 | 17 (23) | 17 | 0 | 34 | 9% | 3.0 | 31 (6) | 12 (9) | 30 (2) | 70 (1) | 12 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 68 (66) | 14 | 55 | 38 | 42% | 2.8 | 101 (28) | 45 (16) | 46 (22) | 82 (48) | 32 (18) |
| Opponent | Character | 114 | 56 (114) | 56 | 0 | 34 | 23% | 2.6 | 62 (42) | 60 (56) | 36 (6) | 58 (69) | 64 (35) |
| Opponent | Clean-up | 16 | 51 (16) | 49 | 3 | 37 | 56% | 3.3 | 101 (5) | 10 (8) | 48 (3) | 92 (8) | 21 (8) |
| Opponent | Early | 1 | 1058 (1) | 1058 | 0 | 100 | 0% | 5.0 | - | 1058 (1) | - | 1058 (1) | - |
| Opponent | Fast Hammer | 58 | 64 (58) | 45 | 18 | 44 | 28% | 2.7 | 71 (25) | 47 (19) | 69 (14) | 58 (42) | 78 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 35 | 60% | 2.2 | 0 (3) | 0 (3) | 0 (4) | 0 (10) | - |
| Opponent | Hammer | 65 | 40 (65) | 34 | 6 | 46 | 22% | 2.7 | 54 (16) | 38 (42) | 16 (7) | 38 (40) | 44 (25) |
| Opponent | Holder | 40 | 63 (40) | 0 | 63 | 33 | 48% | 3.4 | 36 (9) | 89 (20) | 34 (10) | 119 (18) | 21 (21) |
| Opponent | Shooter | 30 | 66 (30) | 22 | 44 | 43 | 10% | 1.3 | 37 (7) | 85 (18) | 25 (5) | 55 (16) | 81 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 29 (13) | 29 | 0 | 36 | 0% | 1.2 | 0 (5) | 31 (5) | 77 (3) | 58 (3) | 21 (10) |
| Opponent | Wizard | 22 | 3 (22) | 3 | 0 | 26 | 9% | 1.9 | 1 (12) | 11 (5) | 3 (3) | 6 (11) | 0 (9) |

### Charged fights: hc-mine-31c41bf-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 210 | 22 | 1.0 | 1.0 | 22 | 33 | -11 | 1 of 5 | 3 of 5 | - | -11 |
| Mine | Chaos Dwarfs | 3 | 117 | 695 | 3.7 | 1.0 | 190 | 31 | +159 | 6 of 11 | 8 of 11 | - | +159 |
| Mine | Dwarfen Mountain Holds | 4 | 432 | 25 | 1.5 | 1.7 | 17 | 30 | -13 | 4 of 6 | 3 of 6 | -20 | +0 |
| Mine | Empire of Man | 5 | 320 | 217 | 1.6 | 1.1 | 135 | 34 | +101 | 1 of 8 | 7 of 8 | +83 | +104 |
| Mine | Grand Cathay | 4 | 770 | 370 | 2.8 | 1.1 | 135 | 20 | +115 | 5 of 11 | 9 of 11 | +522 | +74 |
| Mine | High Elf Realms | 4 | 159 | 620 | 4.0 | 1.2 | 155 | 46 | +109 | 7 of 16 | 12 of 16 | +181 | +92 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 349 | 3.0 | 1.0 | 116 | 0 | +116 | 1 of 3 | 3 of 3 | - | +116 |
| Mine | Lizardmen | 1 | 195 | 66 | 2.0 | 1.0 | 33 | 70 | -38 | 1 of 2 | 1 of 2 | - | -38 |
| Mine | Ogre Kingdoms | 1 | 195 | 195 | 4.0 | 1.0 | 49 | 81 | -32 | 3 of 4 | 1 of 4 | - | -32 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 66 | 4.0 | 1.0 | 16 | 80 | -64 | 3 of 4 | 2 of 4 | - | -64 |
| Mine | Skaven | 2 | 48 | 127 | 0.5 | 1.0 | 254 | 0 | +254 | 1 of 1 | 1 of 1 | - | +254 |
| Mine | Tomb Kings of Khemri | 2 | 160 | 1063 | 3.5 | 1.1 | 304 | 36 | +267 | 2 of 7 | 7 of 7 | +859 | +169 |
| Mine | Vampire Counts | 2 | 0 | 301 | 2.5 | 1.0 | 120 | 0 | +120 | 1 of 5 | 5 of 5 | - | +120 |
| Mine | Warriors of Chaos | 1 | 0 | 160 | 2.0 | 1.0 | 80 | 102 | -22 | 1 of 2 | 2 of 2 | - | -22 |
| **Mine** | all armies | 36 | 257 | 310 | 2.4 | 1.1 | 131 | 37 | +94 | 37 of 85 | 64 of 85 | +193 | +81 |
| Opponent | Beastmen Brayherds | 1 | 0 | 337 | 5.0 | 1.0 | 67 | 23 | +44 | 1 of 5 | 5 of 5 | - | +44 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 255 | 562 | 2.0 | 1.0 | 281 | 0 | +281 | 1 of 2 | 2 of 2 | - | +281 |
| Opponent | Grand Cathay | 1 | 235 | 604 | 4.0 | 1.5 | 151 | 0 | +151 | 3 of 4 | 4 of 4 | +128 | +159 |
| Opponent | High Elf Realms | 2 | 146 | 575 | 3.5 | 1.1 | 164 | 0 | +164 | 4 of 7 | 5 of 7 | +249 | +150 |
| Opponent | Lizardmen | 1 | 0 | 932 | 4.0 | 1.2 | 233 | 0 | +233 | 2 of 4 | 4 of 4 | +189 | +248 |
| Opponent | Ogre Kingdoms | 2 | 26 | 541 | 4.0 | 1.0 | 135 | 49 | +86 | 3 of 8 | 4 of 8 | - | +86 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 693 | 3.0 | 1.0 | 231 | 58 | +173 | 3 of 6 | 5 of 6 | - | +173 |
| Opponent | Skaven | 2 | 184 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 127 | 1175 | 5.5 | 1.2 | 214 | 28 | +186 | 9 of 22 | 19 of 22 | +220 | +176 |
| Opponent | Vampire Counts | 6 | 9 | 631 | 4.3 | 1.2 | 146 | 12 | +134 | 10 of 26 | 20 of 26 | +112 | +138 |
| Opponent | Warriors of Chaos | 7 | 0 | 351 | 1.6 | 1.0 | 223 | 32 | +191 | 9 of 11 | 6 of 11 | - | +191 |
| Opponent | Wood Elf Realms | 6 | 144 | 328 | 3.3 | 1.4 | 98 | 29 | +70 | 7 of 20 | 13 of 20 | +123 | +52 |
| **Opponent** | all armies | 36 | 73 | 527 | 3.2 | 1.2 | 163 | 23 | +140 | 52 of 116 | 87 of 116 | +161 | +137 |

### Effective charges: hc-mine-31c41bf-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -52) | 0 | 0 | 0 | 0 | 3 (net -2) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 11 | 1 (net +506) | 0 | 0 | 4 (net +143) | 0 | 5 (net +134) | 1 | 0% (0 of 10) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -60) | 0 | 0 | 1 (net +0) | 0 | 2 (net +50) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 8 | 1 (net +505) | 0 | 1 (net +0) | 2 (net +116) | 2 (net +76) | 2 (net -40) | 0 | 12% (1 of 8) |
| Mine | Grand Cathay | 11 | 2 (net +152) | 2 (net +346) | 1 (net +0) | 3 (net +39) | 1 (net +60) | 2 (net +46) | 0 | 9% (1 of 11) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 1 (net +0) | 2 (net +14) | 4 (net +172) | 0 | 7 (net +147) | 1 | 13% (2 of 15) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 2 (net +22) | 1 (net +304) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +66) | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -39) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +254) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 1 (net +859) | 1 (net +119) | 1 (net +286) | 1 (net +65) | 2 (net +137) | 1 | 17% (1 of 6) |
| Mine | Vampire Counts | 5 | 0 | 1 (net +173) | 0 | 2 (net +0) | 1 (net +144) | 1 (net +285) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net -205) | 0 | 1 (net +160) | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 5 | 0 | 0 | 3 (net +47) | 1 (net +15) | 0 | 1 (net +65) | 0 | 60% (3 of 5) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +562) | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +185) | 0 | 1 (net +128) | 2 (net +146) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 7 | 0 | 0 | 3 (net +163) | 1 (net +165) | 0 | 2 (net +134) | 1 | 50% (3 of 6) |
| Opponent | Lizardmen | 4 | 0 | 1 (net +238) | 0 | 0 | 1 (net +0) | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 2 (net +476) | 1 (net -301) | 0 | 2 (net +32) | 3 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 6 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +529) | 4 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 22 | 1 (net -70) | 0 | 5 (net +56) | 3 (net +69) | 1 (net +83) | 10 (net +255) | 2 | 25% (5 of 20) |
| Opponent | Vampire Counts | 26 | 2 (net -48) | 1 (net +195) | 5 (net +109) | 7 (net +72) | 2 (net +185) | 8 (net +234) | 1 | 20% (5 of 25) |
| Opponent | Warriors of Chaos | 11 | 1 (net +663) | 0 | 2 (net +296) | 2 (net +125) | 0 | 2 (net +418) | 4 | 29% (2 of 7) |
| Opponent | Wood Elf Realms | 20 | 2 (net +0) | 2 (net +17) | 4 (net +155) | 6 (net +33) | 1 (net +151) | 3 (net +124) | 2 | 22% (4 of 18) |

### Charged fights, damage counted: hc-mine-31c41bf-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 264 | 231 | +143 | 236 | 89 | +148 | +56.0 |
| Mine | 50-54% | 5 | 339 | 240 | +345 | 388 | 36 | +352 | +103.9 |
| Mine | Effective (55-75%) | 6 | 305 | 219 | +18 | 122 | 108 | +14 | +4.7 |
| Mine | 76-89% | 18 | 264 | 209 | +94 | 148 | 61 | +88 | +33.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 289 | 159 | +112 | 156 | 39 | +117 | +40.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 348 | 86 | +67 | 89 | 22 | +68 | +19.4 |
| Mine | No odds | 13 | 192 | 215 | -21 | 46 | 81 | -35 | -18.4 |
| Mine | All fights | 85 | 275 | 188 | +94 | 151 | 58 | +93 | +33.7 |
| Opponent | Long shot (under 50%) | 9 | 201 | 385 | +76 | 114 | 41 | +73 | +36.2 |
| Opponent | 50-54% | 4 | 370 | 221 | +117 | 180 | 83 | +98 | +26.3 |
| Opponent | Effective (55-75%) | 25 | 256 | 186 | +150 | 174 | 21 | +153 | +59.9 |
| Opponent | 76-89% | 23 | 258 | 144 | +58 | 110 | 29 | +81 | +31.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 355 | 228 | +238 | 289 | 59 | +231 | +64.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 640 | 126 | +121 | 132 | 3 | +129 | +20.1 |
| Opponent | No odds | 20 | 233 | 242 | +115 | 162 | 62 | +100 | +42.8 |
| Opponent | All fights | 116 | 294 | 212 | +140 | 183 | 42 | +141 | +47.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-mine-31c41bf-p1 | move | 358 | 79 (22%) | 63 (18%) | 50 (14%) | 229 (64%) |
| hc-mine-31c41bf-p1 | objective | 351 | 57 (16%) | 47 (13%) | 44 (13%) | 250 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

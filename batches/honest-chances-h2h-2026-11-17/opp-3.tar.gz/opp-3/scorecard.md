# Doctrine scorecard: hc-opp-31c41bf-p3

### Scorecard: hc-opp-31c41bf-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 15 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 8 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 3 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | no | - | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 2 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 3 | 2 | 2 | 1 | 0 | 0 | 532 |
| L0429 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 6 | 2 | 0 | 0 | 0 | 0 | 984 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 925 |
| L0725 | 5 | 1 | Mine | no | - | 6 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 762 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 9 | 2 | 1 | 4 | 2 | 0 | 0 | 927 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 925 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | no | - | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 749 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 19 | 3 | 1 | 0 | 0 | 0 | 0 | 479 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 250 |
| L1422 | 6 | 1 | Mine | no | 7 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | yes | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 317 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 250 |
| L1633 | 1 | 1 | Mine | no | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | yes | 0 | 1 | 5 | 2 | 1 | 0 | 0 | 613 |
| L1731 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 2 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 0 | 5 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 3 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 5 | 2 | 2 | 0 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 5 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | no | - | - | 0 | 6 | 1 | 0 | 0 | 407 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 257 |
| L2327 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 5 | 3 | 0 | 0 | 0 | 186 |
| L2433 | 3 | 1 | Mine | no | 0 | 5 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | 2 | 2 | 0 | 2 | 0 | 0 | 351 |
| L2832 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 2 | 1 | 4 | 1 | 2 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 8 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 19% | 3.4 | 3.0 | 2.0 | 1.1 | 0.4 | 0.0 | 0.0 | 338.4 |
| **Average** | | | Opponent | 22% | 3.7 | 2.1 | 2.7 | 1.9 | 0.6 | 0.0 | 0.0 | 233.2 |

### KPIs: hc-opp-31c41bf-p3

Rules off - Mine only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (39 of 176) | 8% (13 of 172) | 15% (52 of 348) |
| Winner chose to follow up after the loser gave ground |  | 98% (61 of 62); on the table 98% | 100% (38 of 38); on the table 100% | 99% (99 of 100); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 91% (10 of 11); on the table 91% | 83% (10 of 12); on the table 92% | 87% (20 of 23); on the table 91% |
| Winner chose to pursue after the loser fled |  | 79% (22 of 28); on the table 82% | 87% (27 of 31); on the table 90% | 83% (49 of 59); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 92% (93 of 101); on the table 93% | 93% (75 of 81); on the table 95% | 92% (168 of 182); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 27% (92 of 342) | 42% (80 of 192) | 32% (172 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (92 of 212) | 57% (80 of 140) | 49% (172 of 352) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 44% (7 of 16) | 45% (22 of 49) | 45% (29 of 65) |
| Points that never fought | lower | 36% (24865 of 68801) | 39% (27727 of 71990) | 37% (52592 of 140791) |
|   infantry points that never fought | lower | 43% (6150 of 14174) | 60% (8549 of 14220) | 52% (14699 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (157 of 272) | 58% (166 of 285) | 58% (323 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.5 uses a game | 88% (21 of 24); 1.9 uses a game | 88% (43 of 49); 1.7 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.2 uses a game | 33% (2 of 6); 0.2 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 36% (5 of 14); 0.1 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30869 of 59391) | 51% (32678 of 64043) | 51% (63547 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (20%) | 1.0 (32%) | 2.4 (24%) |
| MARCHED: its unit marched | 1.4 (21%) | 0.4 (13%) | 1.9 (19%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.8 (25%) | 0.5 (16%) | 2.2 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (11%) | 0.4 (4%) |
| GONE: slain | 1.6 (23%) | 0.6 (20%) | 2.2 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.1 | 1.8 | 4.8 | 0.8 | 1.6 |
| not cast | 4.2 | 1.5 | 4.4 | 10.1 | 2.5 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.6 (37%) | 0.4 (8%) | 2.4 (24%) | 0.5 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (19%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | 0.1 (7%) | 0.9 (20%) | 2.2 (22%) | 0.2 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (8%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (7%) | 0.1 (3%) | 0.4 (4%) | 0.0 (0%) | 0.8 (4%) |
| GONE: slain | 1.0 (23%) | 0.5 (31%) | 0.9 (20%) | 2.2 (22%) | 0.6 (22%) | 3.4 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.2 (7%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (6%) | 0.0 (1%) | 0.1 (1%) | 0.4 (17%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (54%) | 0.2 (11%) | 1.5 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.1 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.7 a game | 0.9 a game |
| stood (cast and not dispelled) | 51% (18 of 35) | 70% (14 of 20) | 58% (32 of 55) |
| the unit moved after it | 78% (14 of 18) | 86% (12 of 14) | 81% (26 of 32) |
| it charged on its next turn | 0% (0 of 18) | 7% (1 of 14) | 3% (1 of 32) |
| the enemy charged it first | 17% (3 of 18) | 7% (1 of 14) | 12% (4 of 32) |
| it fought by the end of its next turn | 6% (1 of 18) | 0% (0 of 14) | 3% (1 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (4 of 18) | 7% (1 of 14) | 16% (5 of 32) |
| none of these (no charge, no fight, no charge escaped) | 61% (11 of 18) | 79% (11 of 14) | 69% (22 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (520 of 754) | 59% (351 of 593) | 65% (871 of 1347) |
|   cavalry | 66% (45 of 68) | 59% (60 of 101) | 62% (105 of 169) |
|   character | 66% (70 of 106) | 31% (38 of 124) | 47% (108 of 230) |
|   chariot | 55% (54 of 98) | 57% (16 of 28) | 56% (70 of 126) |
|   infantry | 59% (112 of 189) | 66% (165 of 250) | 63% (277 of 439) |
|   monster | 47% (15 of 32) | 80% (4 of 5) | 51% (19 of 37) |
|   war machine | 86% (224 of 261) | 80% (68 of 85) | 84% (292 of 346) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (32%) | 1.2 (17%) | 3.2 (24%) |
| CHARGED: it charged | 0.9 (15%) | 1.6 (24%) | 2.5 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (10%) | 0.6 (8%) | 1.2 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (17%) | 1.3 (20%) | 2.4 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (4%) | 0.4 (7%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (15%) | 1.3 (19%) | 2.3 (17%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.2 (3%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.2 | 0.8 | 85% | 5.3 pts | 23 pts |
| character | 3.5 | 1.0 | 79% | 7.2 pts | 25 pts |
| chariot | 1.9 | 0.9 | 66% | 14.6 pts | 28 pts |
| infantry | 12.1 | 4.3 | 76% | 8.8 pts | 106 pts |
| monster | 0.7 | 0.3 | 72% | 13.5 pts | 9 pts |
| war machine | 8.4 | 8.3 | 61% | 29.7 pts | 251 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 5.2 | 4.4 |
| Charges that made contact a game | 2.9 | 3.8 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.96 declared, 0.85 contact (26 units) | 0.56 declared, 0.50 contact (18 units) | 0.80 declared, 0.70 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.50 contact (4 units) | 1.11 declared, 1.00 contact (9 units) | 1.00 declared, 0.85 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.36 contact (222 units) | 0.63 declared, 0.45 contact (262 units) | 0.55 declared, 0.41 contact (484 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (42 of 77) | 47% (7 of 15) | 60% (6 of 10) | 54% (55 of 102) |
| Character in a unit | 86% (30 of 35) | 80% (12 of 15) | 0% (0 of 4) | 78% (42 of 54) |
| Character on its own | 81% (34 of 42) | 41% (17 of 41) | 31% (22 of 71) | 47% (73 of 154) |
| Chariot | 64% (7 of 11) | 67% (8 of 12) | - | 65% (15 of 23) |
| Infantry | 64% (45 of 70) | 50% (21 of 42) | 40% (2 of 5) | 58% (68 of 117) |
| Monster | 62% (21 of 34) | 57% (4 of 7) | - | 61% (25 of 41) |
| Monstrous | 70% (7 of 10) | 45% (5 of 11) | - | 57% (12 of 21) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (18 of 18); on the table 100% | 25% (24 of 96) | 39% | 64% (14 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 82% (9 of 11); on the table 91% | 44% (16 of 36) | 43% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 81% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (5 of 6); on the table 83% | 30% (9 of 30) | 30% | 66% (39 of 59) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 75% (15 of 20); on the table 75% | 33% (63 of 192) | 42% | 55% (41 of 74) | 89% (16 of 18); 5.4 uses a game | 50% (2 of 4); 0.4 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 100% (14 of 14); on the table 100% | 26% (11 of 42) | 27% | 52% (28 of 54) | 89% (8 of 9); 3.1 uses a game | 17% (2 of 12); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (7 of 7); on the table 100% | - | 56% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 67% (4 of 6) | 8% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 50% | 29% (2 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (8 of 8); on the table 100% | 17% (2 of 12) | 1% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 0% (0 of 1); on the table 0% | 33% (4 of 12) | 65% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 100% (11 of 11); on the table 100% | 33% (2 of 6) | 30% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (22 of 25); on the table 96% | 28% (15 of 54) | 29% | 50% (23 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 98% (39 of 40); on the table 98% | 63% (19 of 30) | 30% | 59% (57 of 96) | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (11 of 11); on the table 100% | 25% (3 of 12) | 50% | 65% (40 of 62) | 82% (9 of 11); 4.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hc-opp-31c41bf-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (40) | 46% (32) | 46% (72) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.64 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.42 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.31 | 1.53 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.89 | 1.81 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 4.92 | 10.50 |

### Quality by phase: hc-opp-31c41bf-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 56% (63 of 112) | 52% (73 of 141) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (176 of 384) | 47% (112 of 239) |
| Strategy | Close-in objectives charged next turn | 14% (27 of 194) | 16% (30 of 185) |
| Strategy | Support requests answered (helper made contact too) | 58% (7 of 12) | 36% (8 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 60% (3 of 5) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 57% (4 of 7) |
| Strategy | Joined characters whose unit fought | 37% (16 of 43) | 32% (13 of 41) |
| Strategy | Lone characters that fought | 80% (74 of 92) | 75% (70 of 93) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 338.4 | 233.2 |
| Movement | Fights charged into per game | 2.5 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 83, net -97 | 24 of 106, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 83, net +34 | 19 of 106, net +150 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 83, net +178 | 10 of 106, net +76 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 83, net +37 | 34 of 106, net +86 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (142 of 326) | 51% (172 of 338) |
| Shooting | Points destroyed by shooting units | 45.3 | 24.9 |
| Shooting | War machine shots | 6.2 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (117 of 224) | 31% (25 of 80) |
| Shooting | Points destroyed by war machines | 73.1 | 30.1 |
| Magic | Magic missiles cast | 1.6 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (20 of 57) | 39% (22 of 57) |
| Magic | Wounds caused by magic missiles | 2.8 | 2.6 |
| Magic | Wounds caused by other spells | 1.9 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 77.2 | 52.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.3 / 0.8 / 0.1 | 2.0 / 0.3 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 368.5 | 459.9 |
| Combat | Points run down | 87.4 | 63.4 |
| Combat | Net points per charged fight, damage counted | +69 | +80 |
| Combat | Net per 100 charger points, damage counted | +22.6 | +28.4 |
| Combat | First round won (charged fights) | 79% | 72% |
| Combat | Net points per charged fight | +62 | +74 |
| Combat | Net points per supported fight / lone fight | +89 / +57 | +80 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 91 | 51 of 122 |
| Game | Points lost | 753.6 | 715.7 |
| Game | VP from objectives | 530.0 | 563.1 |
| Game | Lone holders (player turns) | 3.4 | 3.7 |

- Mine won / drew / lost: 16 / 6 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -77 VP
- The side that went first won 14 of 30 games with a winner
- Points traded per game (both sides' losses): 1469
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-opp-31c41bf-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.2 | -155.9 | 182.9 | 57.8 | 3.8 | -129.6 | 137.9 | 68.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 36.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.5 | +1.5 | 0.0 | 13.8 | 0.1 | +0.2 | 0.0 | 0.0 |
| BEST FACING | 0.3 | +9.3 | 0.0 | 7.2 | 0.4 | +17.7 | 0.0 | 15.0 |
| BEST FIRST | 1.3 | +47.0 | 39.8 | 32.6 | 1.0 | +76.5 | 30.7 | 32.8 |
| BEST OVERALL | 0.4 | +17.4 | 0.0 | 4.6 | 0.2 | +8.1 | 0.0 | 20.8 |
| BEST PREY | 0.3 | +15.0 | 5.1 | 2.4 | 0.7 | +24.0 | 23.2 | 33.2 |
| BEST PRIZE | 0.1 | -3.3 | 7.5 | 9.7 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | -0.8 | 0.0 | 0.0 | 0.2 | -0.8 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 7.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +5.5 | 0.0 | 0.0 | 0.2 | +4.1 | 0.0 | 5.4 |
| BLOWS WHERE AIMED | 0.4 | -52.9 | 24.2 | 18.6 | 0.3 | -53.5 | 27.4 | 15.9 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 69.0 | 8.1 | 0.1 | +0.0 | 14.4 | 2.8 |
| CANNON PLANNED TARGET | 5.4 | +113.6 | 393.8 | 127.8 | 1.4 | +62.3 | 77.1 | 29.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.2 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.1 | 2.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 28.4 | 6.0 | 0.1 | +0.0 | 9.9 | 0.0 |
| CAST JOB | 1.1 | +20.9 | 65.8 | 12.9 | 0.9 | +13.2 | 34.4 | 16.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +30.2 | 30.8 | 0.0 | 0.1 | +2.0 | 10.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 11.0 | 0.5 | +0.0 | 0.0 | 23.6 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +41.4 | 0.0 | 17.5 | 1.6 | +80.3 | 0.0 | 30.0 |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 5.6 | 0.2 | -0.3 | 3.5 | 2.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 149.5 | 95.3 | 1.9 | +0.0 | 237.1 | 72.6 |
| CHARGE NOW WEIGHED | 0.7 | -51.8 | 30.7 | 18.4 | 0.6 | -42.2 | 11.7 | 22.9 |
| CHARGER SLAIN LOST | 0.4 | -11.9 | 30.9 | 16.4 | 0.4 | -8.7 | 16.8 | 16.4 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.2 | 0.0 | 22.2 |
| CHEAP HELPER | 0.1 | +0.0 | 1.5 | 0.0 | 0.1 | +0.0 | 0.0 | 1.2 |
| COMBAT PIVOT | 0.3 | +0.0 | 6.5 | 30.4 | 0.4 | +0.0 | 47.1 | 23.6 |
| CONVEYANCE SEARCH | 0.7 | +114.0 | 10.6 | 20.4 | 0.3 | +21.4 | 5.3 | 5.3 |
| COVER ONCE | 8.1 | -549.4 | 0.0 | 175.7 | 6.0 | -412.3 | 0.0 | 127.8 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.7 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.7 | 3.2 | 1.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +5.2 | 27.0 | 0.0 | 0.4 | +4.4 | 18.7 | 22.2 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.3 | +94.9 | 0.0 | 65.1 | 1.5 | +121.2 | 0.0 | 71.7 |
| FALLBACK BY WORTH | 4.4 | +46.9 | 0.0 | 34.7 | 5.2 | +46.7 | 0.0 | 31.9 |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 75.8 | 4.9 | +0.0 | 0.0 | 138.6 |
| FOLLOW UP WEIGHED | 1.0 | +126.2 | 0.0 | 74.2 | 0.7 | +90.7 | 0.0 | 1.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +12.5 | 0.0 | 9.7 | 0.1 | +15.5 | 0.0 | 7.2 |
| GIVES UP | 0.1 | -0.8 | 12.9 | 3.2 | 0.1 | -1.2 | 10.0 | 9.6 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -3.1 | 6.2 | 1.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.5 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 20.3 | 16.2 | 0.2 | +0.0 | 28.9 | 11.0 |
| HILL BY ITS CHANCE | 0.2 | -16.2 | 0.0 | 0.0 | 0.4 | -50.8 | 0.0 | 7.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -153.5 | 488.4 | 187.9 | 4.3 | -114.0 | 330.7 | 108.5 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +8.7 | 3.5 | 2.9 | 0.2 | +5.6 | 6.9 | 6.1 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.9 |
| HUNT IN PAIRS | 0.5 | +19.7 | 0.0 | 20.0 | 0.5 | +46.7 | 0.0 | 8.5 |
| HUNT KEPT | 0.1 | +4.6 | 3.5 | 3.0 | 0.1 | +1.8 | 6.9 | 2.9 |
| HUNT RESULT | 0.1 | +5.8 | 0.0 | 1.5 | 0.1 | +15.0 | 4.6 | 6.1 |
| HUNT THE GUNS | 0.1 | +53.8 | 3.5 | 1.4 | 0.2 | +50.6 | 8.1 | 3.2 |
| IDLE COST | 15.1 | -257.8 | 0.0 | 144.1 | 19.0 | -336.2 | 0.0 | 247.5 |
| INVITES THE FIGHT | 1.1 | +6.7 | 54.6 | 10.9 | 0.8 | +9.7 | 33.8 | 16.3 |
| JOINT CHARGE PLAN | 0.1 | +13.8 | 0.0 | 0.0 | 0.3 | +13.8 | 0.0 | 2.9 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +54.2 | 135.7 | 33.0 | 1.8 | +52.5 | 78.5 | 50.4 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +65.7 | 113.6 | 32.8 | 1.7 | +94.7 | 173.4 | 64.4 |
| KILLS COUNT NEXT TURN | 5.3 | +199.1 | 255.8 | 114.3 | 3.6 | +112.3 | 137.3 | 147.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +12.8 | 10.4 | 4.5 | 0.2 | +1.1 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 13.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +9.0 | 23.3 | 3.4 | 0.3 | +3.0 | 2.3 | 12.1 |
| LOST CHARGE | 2.2 | -43.9 | 114.2 | 66.7 | 2.5 | -31.7 | 55.6 | 85.7 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.4 | 0.0 | 3.4 | 0.1 | -12.9 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 1.1 | +114.7 | 40.2 | 8.5 | 0.8 | +45.7 | 8.9 | 5.2 |
| MANOEUVRE | 0.3 | +4.5 | 0.0 | 9.6 | 0.3 | +10.2 | 0.0 | 1.1 |
| MARCH AT ESCAPER | 0.2 | +0.7 | 0.0 | 12.1 | - | - | - | - |
| MARCH CHECK | 0.4 | +27.7 | 0.0 | 16.0 | 0.7 | +39.9 | 0.0 | 26.2 |
| MARCH ODDS | 0.3 | +16.8 | 10.8 | 20.5 | 0.2 | +15.2 | 1.7 | 7.0 |
| MARCH OVER CASTS | 0.6 | +38.1 | 0.0 | 22.3 | 0.3 | +11.1 | 0.0 | 14.1 |
| MAX FOR POSITIONING | 6.6 | +96.9 | 0.0 | 151.2 | 5.8 | +57.1 | 0.0 | 97.6 |
| MEASURED NEXT CHARGE | - | - | - | - | 10.1 | -220.5 | 110.0 | 195.9 |
| MISSILES IN THE MOVE | 3.9 | +109.2 | 0.0 | 104.8 | 4.2 | +61.8 | 0.0 | 129.9 |
| MISSILES NEXT TURN | 5.0 | +78.8 | 0.0 | 127.1 | 4.8 | +46.1 | 0.0 | 129.9 |
| MODEL FACING | 0.1 | +48.4 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 24.9 | 10.6 | 0.2 | +0.0 | 8.9 | 0.0 |
| MOVE AND CAST | 0.2 | +10.9 | 0.0 | 0.0 | 0.5 | +17.6 | 0.0 | 6.4 |
| MOVE SPELL IN RANGE | 0.2 | +7.5 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -22.7 | 0.0 | 22.1 | 0.1 | -2.8 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 12.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 4.1 | +401.8 | 203.7 | 64.9 | 0.6 | +3.7 | 11.1 | 13.8 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +4.9 | 3.1 | 0.0 | 0.0 | +12.6 | 9.7 | 0.0 |
| NO RALLY LEFT | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -5.7 | 19.8 | 4.7 | 0.2 | -7.0 | 22.8 | 0.8 |
| NOT TURNED | 5.6 | +98.0 | 0.0 | 77.6 | 4.9 | +11.2 | 0.0 | 125.5 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 32.1 | 0.9 | -1.3 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -700.9 | 6.1 | 269.1 | 15.1 | -633.5 | 0.0 | 272.8 |
| ONE FIGHT FORMULA | 9.1 | -161.4 | 54.6 | 171.0 | 7.7 | -156.6 | 25.4 | 177.3 |
| ONE OBJECTIVE FORMULA | 2.6 | -85.1 | 0.0 | 31.0 | 1.9 | -104.1 | 0.0 | 32.4 |
| OPENS A LANE | 0.1 | +0.6 | 3.9 | 0.0 | 0.3 | +2.1 | 33.4 | 10.2 |
| OPENS UP | 0.2 | +16.0 | 12.1 | 0.0 | - | - | - | - |
| OVERRUN THREAT | 0.1 | +1.6 | 0.0 | 5.1 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +24.5 | 54.2 | 27.5 | 0.5 | +8.9 | 42.2 | 27.3 |
| PATHS CROSS | 2.2 | +143.7 | 0.0 | 29.1 | 2.2 | +132.2 | 0.0 | 7.5 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.7 | 0.0 | 1.4 | 0.1 | -1.5 | 0.0 | 0.0 |
| PLAN RESULT | 35.8 | +1143.2 | 1172.3 | 927.7 | 36.6 | +1095.5 | 1270.9 | 1000.1 |
| PURSUES BIG PREY | 0.0 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.3 | 0.0 | 4.7 | 0.0 | +1.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +3.5 | 0.0 | 14.2 | 1.4 | +22.4 | 0.0 | 70.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -11.1 | 0.0 | 4.7 | 0.4 | -21.2 | 6.5 | 28.1 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -9.5 | 0.0 | 12.2 | 1.2 | -35.4 | 0.0 | 25.2 |
| REDIRECT COUNTER | 1.7 | +108.4 | 0.0 | 29.2 | 3.6 | +328.7 | 0.0 | 65.5 |
| REDIRECT WEIGHED | 0.2 | -4.2 | 6.2 | 9.7 | 0.2 | +10.0 | 16.3 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 20.2 | 0.3 | +0.0 | 0.0 | 26.8 |
| RESERVE FALL BACK | 0.4 | +7.7 | 0.0 | 1.7 | 0.6 | +28.6 | 0.0 | 14.4 |
| RESTRAINS TO SHOOT | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.2 | +63.7 | 198.1 | 80.1 | 2.1 | +37.6 | 204.3 | 74.9 |
| RISK ONCE | 3.7 | +94.1 | 33.6 | 102.3 | 4.3 | +245.2 | 45.5 | 301.1 |
| RUN DOWN | - | - | - | - | 1.7 | -16.0 | 111.3 | 71.3 |
| SAFE SURE CHARGE | 0.0 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +50.7 | 0.0 | 13.6 | 0.9 | +64.8 | 0.0 | 9.6 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -17.1 | 0.0 | 1.9 | 0.5 | -37.6 | 0.0 | 1.6 |
| SEARCH SPOT | 2.0 | +77.9 | 0.0 | 13.5 | 2.1 | +111.3 | 0.0 | 35.9 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +48.4 | 0.0 | 32.9 | 0.2 | +58.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.6 | +146.3 | 58.8 | 30.5 | 2.1 | +220.2 | 33.7 | 56.3 |
| SET-UP ANY TARGET | 0.3 | +52.3 | 0.0 | 0.0 | 0.1 | +15.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +14.1 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +23.6 | 42.8 | 28.6 | 1.3 | +22.5 | 58.9 | 51.1 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 85.9 | 0.0 | 0.2 | +0.0 | 24.6 | 0.0 |
| SHOTS IN THE MOVE | 14.1 | +448.7 | 0.0 | 284.7 | 9.1 | +275.9 | 0.0 | 165.5 |
| SPELL CATCH ODDS | 0.0 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +119.0 | 10.6 | 10.6 | 0.1 | +15.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +23.2 | 43.6 | 53.4 | 2.1 | +33.0 | 145.4 | 122.9 |
| SPELLS IN THE FIGHT | 0.6 | -0.7 | 79.2 | 23.0 | 0.3 | -7.9 | 72.3 | 13.3 |
| STABLE ROLE | 10.4 | +0.0 | 353.4 | 171.8 | 9.2 | +0.0 | 335.2 | 135.7 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.0 | 0.0 | 3.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| STOPS | 0.1 | +3.6 | 3.5 | 1.5 | 0.1 | +3.1 | 4.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +15.4 | 0.0 | 4.5 | 0.4 | +15.0 | 0.0 | 27.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.5 | -63.8 | 221.9 | 156.6 | 6.7 | -52.1 | 410.4 | 158.3 |
| SUPPORTS | 4.1 | +74.4 | 111.9 | 66.3 | 4.6 | +53.9 | 258.2 | 62.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.5 | 3.8 | 0.0 | 0.1 | -1.0 | 5.2 | 3.8 |
| SURE REACH TOGETHER | 0.6 | +7.0 | 12.9 | 24.2 | 0.6 | -9.8 | 0.0 | 28.1 |
| THROUGH LINE OF FIRE | 0.4 | +25.2 | 0.0 | 0.0 | 0.3 | +17.1 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -7.3 | 6.6 | 0.0 | 0.2 | -11.0 | 17.5 | 3.1 |
| TWO OR MORE ARRIVE | 0.4 | +4.9 | 23.5 | 6.5 | 0.6 | +3.5 | 0.0 | 22.7 |
| WAIT AFTER COSTS | 7.3 | -346.8 | 321.6 | 89.2 | 2.2 | -104.1 | 64.6 | 30.0 |
| WALKS TO THE FIGHT | 1.7 | +15.8 | 34.5 | 7.4 | 0.9 | +4.2 | 19.8 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +11.1 | 5.2 | 13.8 | 0.1 | +7.3 | 2.4 | 3.8 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 40.8 | 24.7 | 0.1 | +0.0 | 4.7 | 3.8 |
| WEARS DOWN | 0.9 | +41.3 | 87.6 | 44.2 | 1.0 | +32.3 | 78.5 | 56.0 |
| WHO HITS BACK | 0.2 | +18.5 | 0.0 | 7.4 | 0.2 | +16.6 | 0.0 | 12.3 |
| WHOLE FIGHT | 0.1 | -1.7 | 9.8 | 13.9 | 0.4 | +9.7 | 83.3 | 14.2 |
| WHOLE FIGHT GAIN | 0.2 | +7.0 | 9.5 | 0.0 | 0.5 | +30.3 | 31.8 | 2.1 |
| WIDER SPREAD | 1.9 | -7.3 | 166.8 | 70.3 | 2.7 | -8.8 | 283.4 | 75.8 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 3.5 | 0.0 |

### Rule changes: hc-opp-31c41bf-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1125 | 1125 | 1125 | 31.25 | -48038 | -42.7 |
| PATHS CROSS | 158 | 158 | 158 | 4.39 | +9929 | +62.8 |
| SEARCH SPOT | 150 | 150 | 143 | 3.97 | +6812 | +47.6 |
| SUPPORTS | 314 | 314 | 128 | 3.56 | +1688 | +13.2 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +7780 | +76.3 |
| MOVE TO CHARGE | 169 | 169 | 101 | 2.81 | +6036 | +59.8 |
| BEST FIRST | 85 | 85 | 85 | 2.36 | +4446 | +52.3 |
| KILLS COUNT NEXT TURN | 321 | 321 | 82 | 2.28 | +2013 | +24.6 |
| FALLBACK BY WORTH | 345 | 345 | 73 | 2.03 | +3371 | +46.2 |
| SHOTS IN THE MOVE | 832 | 583 | 70 | 1.94 | +1623 | +23.2 |
| SAFER THAN THE JOB | 65 | 65 | 65 | 1.81 | +4155 | +63.9 |
| WAIT AFTER COSTS | 340 | 340 | 63 | 1.75 | +1050 | +16.7 |
| COVER ONCE | 508 | 269 | 62 | 1.72 | +665 | +10.7 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +7808 | +128.0 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| MEASURED NEXT CHARGE | 363 | 278 | 58 | 1.61 | +772 | +13.3 |
| SET UP TOGETHER | 132 | 117 | 58 | 1.61 | +4992 | +86.1 |
| ADVANCE WORTH | 326 | 326 | 56 | 1.56 | +874 | +15.6 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| ONE FIGHT FORMULA | 603 | 357 | 56 | 1.56 | +299 | +5.3 |
| MISSILES IN THE MOVE | 293 | 175 | 51 | 1.42 | +802 | +15.7 |
| CHARGE NOW WEIGHED | 49 | 49 | 49 | 1.36 | +2761 | +56.4 |
| REDIRECT COUNTER | 190 | 91 | 49 | 1.36 | +5194 | +106.0 |
| CHAFF IN THE MOVE | 85 | 81 | 48 | 1.33 | +1798 | +37.5 |
| CANNON PLANNED TARGET | 246 | 246 | 44 | 1.22 | -241 | -5.5 |
| RISK ONCE | 288 | 207 | 44 | 1.22 | +1730 | +39.3 |
| MAX FOR POSITIONING | 445 | 279 | 41 | 1.14 | +80 | +1.9 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| IDLE COST | 1226 | 691 | 39 | 1.08 | +523 | +13.4 |
| MARCH CHECK | 40 | 39 | 37 | 1.03 | +1809 | +48.9 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.00 | +1309 | +36.4 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 34 | 0.94 | +566 | +16.7 |
| KILLS COUNT | 108 | 107 | 33 | 0.92 | +1678 | +50.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| WALKS TO THE FIGHT | 92 | 92 | 33 | 0.92 | +220 | +6.7 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1094 | +36.5 |
| CAST JOB | 70 | 70 | 29 | 0.81 | +466 | +16.1 |
| RANDOM MOVE BY FIGURES | 65 | 65 | 29 | 0.81 | +934 | +32.2 |
| SHOT REPLANNED | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1025 | +38.0 |
| CHARGE NOW FIRST | 144 | 144 | 25 | 0.69 | -1206 | -48.2 |
| RISK BY ARC | 155 | 153 | 25 | 0.69 | +660 | +26.4 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 25 | 25 | 25 | 0.69 | +1524 | +61.0 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +970 | +40.4 |
| BEST OVERALL | 24 | 24 | 24 | 0.67 | +921 | +38.4 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| INVITES THE FIGHT | 67 | 67 | 23 | 0.64 | +190 | +8.2 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +344 | +16.4 |
| MANOEUVRE | 23 | 23 | 20 | 0.56 | +529 | +26.4 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +353 | +18.6 |
| HONEST WORTH | 455 | 455 | 18 | 0.50 | +89 | +4.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| LOST CHARGE | 170 | 170 | 17 | 0.47 | +228 | +13.4 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +1007 | +63.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +938 | +58.6 |
| MAKE SURE TOGETHER | 68 | 43 | 15 | 0.42 | +1375 | +91.7 |
| MISSILES NEXT TURN | 352 | 219 | 15 | 0.42 | +33 | +2.2 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +1126 | +75.0 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -58 | -4.2 |
| KEEPS ITS TARGET | 128 | 128 | 14 | 0.39 | +264 | +18.9 |
| WAR ENGINE JOBS | 34 | 34 | 14 | 0.39 | -545 | -38.9 |
| CASTING BLOCK | 17 | 17 | 12 | 0.33 | +428 | +35.7 |
| HUNT IN PAIRS | 36 | 25 | 12 | 0.33 | +736 | +61.4 |
| WEARS DOWN | 69 | 68 | 12 | 0.33 | +440 | +36.6 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -17 | -1.6 |
| REFUSING RETIRES | 21 | 21 | 10 | 0.28 | -2 | -0.2 |
| BEST PREY | 36 | 36 | 9 | 0.25 | +263 | +29.2 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OVERRUNS AWAY | 37 | 36 | 9 | 0.25 | +235 | +26.1 |
| SUPPORT NARROWED | 438 | 438 | 9 | 0.25 | -82 | -9.2 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -116 | -14.4 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE REACH TOGETHER | 45 | 35 | 8 | 0.22 | +57 | +7.1 |
| WHOLE FIGHT GAIN | 23 | 21 | 8 | 0.22 | +289 | +36.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +112 | +18.7 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 6 | 0.17 | -234 | -39.1 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +1742 | +348.5 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| EDGE GIVE GROUND | 20 | 19 | 4 | 0.11 | +34 | +8.4 |
| ONE OBJECTIVE FORMULA | 162 | 66 | 4 | 0.11 | +230 | +57.5 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +94 | +23.6 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -55 | -13.8 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -253 | -84.4 |
| HUNT ADVANCE | 12 | 12 | 3 | 0.08 | +94 | +31.2 |
| OPENS UP | 8 | 8 | 3 | 0.08 | +90 | +30.2 |
| RAIDS THE BAGGAGE | 3 | 3 | 3 | 0.08 | +331 | +110.2 |
| WAR ENGINE CHARGES | 7 | 7 | 3 | 0.08 | +81 | +26.9 |
| WHOLE FIGHT | 19 | 19 | 3 | 0.08 | +9 | +3.0 |
| WIDER SPREAD | 166 | 163 | 3 | 0.08 | +11 | +3.6 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +9 | +4.3 |
| OPENS A LANE | 14 | 7 | 2 | 0.06 | +7 | +3.4 |
| SPELLS IN THE FIGHT | 32 | 31 | 2 | 0.06 | +28 | +14.1 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +170 | +85.1 |
| STOPS | 5 | 5 | 2 | 0.06 | +66 | +33.2 |
| BACKUP TARGETS | 21 | 14 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 13 | 13 | 1 | 0.03 | -17 | -16.9 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +54 | +54.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +22 | +21.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| JOINT CHARGE PLAN | 15 | 15 | 1 | 0.03 | +113 | +112.7 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 25 | 24 | 1 | 0.03 | +9 | +8.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -79 | -79.0 |
| REDIRECT BY WHAT IT STOPS | 65 | 65 | 1 | 0.03 | +81 | +81.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +23 | +22.6 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -14 | -14.5 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +24 | +24.0 |
| TWO OR MORE ARRIVE | 35 | 34 | 1 | 0.03 | +8 | +8.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -62 | -62.3 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 23 | 23 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 29 | 27 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 35 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 357 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 14 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 20 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 378 | 378 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 57 | not checked | - | - | - | - |
| OVERRUN THREAT | 2 | not checked | - | - | - | - |
| PLAN RESULT | 2606 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| RUN DOWN | 62 | 62 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 124 | not checked | - | - | - | - |
| STABLE ROLE | 705 | 705 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: hc-opp-31c41bf-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.81 | 13.53 | 43.9 |
| FALLBACK | gate | 0.56 | 0.58 | 30.3 |
| TURN GATE | gate | 0.47 | 0.44 | 39.7 |
| CHARGE NOW FIRST | rule | 0.50 | 0.17 | 50.2 |
| WAR ENGINE JOBS | rule | 0.36 | 0.03 | 38.9 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.19 | 6.2 |
| AFTERMATH BAND | gate | 0.06 | 0.22 | 2.6 |
| SUPPORT NARROWED | rule | 0.11 | 0.14 | 9.2 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.06 | 58.2 |
| CHAFF PASSED | rule | 0.08 | 0.14 | 2.1 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.06 | 14.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.11 | 26.2 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 5.2 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 60.8 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 1.2 |
| LONE WIZARD HOLDS BACK | rule | 0.11 | 0.03 | 46.9 |
| PATHS CROSS | rule | 0.06 | 0.06 | 18.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.06 | 92.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 13.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 41.6 |
| BEST PRIZE | rule | 0.08 | - | 84.4 |
| FACES THE THREAT | rule | - | 0.08 | 3.8 |
| MARCH ODDS | rule | 0.06 | - | 2.2 |
| NO REASON | gate | - | 0.06 | 8.6 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 12.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 9.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 16.9 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 0.9 |
| PURSUES BIG PREY | rule | 0.03 | - | 79.0 |
| RULE SWITCHED OFF | gate | 0.03 | - | 15.1 |
| SAFE SURE CHARGE | rule | 0.03 | - | 14.5 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 62.3 |

### Plans: hc-opp-31c41bf-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 8.9 | 15% | 133 | 176 | 133% |
| Mine | charge | 2.2 | 72% | 241 | 232 | 96% |
| Mine | close in | 5.4 | 26% | 395 | 171 | 43% |
| Mine | hold | 5.3 | 34% | 311 | 0 | 0% |
| Mine | join | 0.4 | 85% | 8 | 0 | 0% |
| Mine | shoot | 8.8 | 56% | 157 | 564 | 359% |
| Mine | support | 4.8 | 92% | 66 | 0 | 0% |
| Opponent | advance | 12.0 | 15% | 164 | 311 | 189% |
| Opponent | charge | 3.6 | 50% | 303 | 319 | 105% |
| Opponent | close in | 5.1 | 19% | 263 | 144 | 55% |
| Opponent | hold | 3.7 | 34% | 247 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 33 | 0 | 0% |
| Opponent | shoot | 5.3 | 58% | 115 | 324 | 281% |
| Opponent | support | 6.1 | 88% | 44 | 0 | 0% |

### Packages: hunt the guns, hc-opp-31c41bf-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 3.0 | 388 | 42 | 0% | 38 |
| Opponent | 0.2 | 6 | 1 | 20% | 40% | 0% | 2.0 | 313 | 108 | 40% | 76 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 391 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 134 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 375 | 208 | 0% | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 16 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 283 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.3 | 2 | 1 | 0% | 0% | 0% | - | 385 | 0 | 0% | 12 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 100% | 0% | 2.0 | 320 | 269 | 100% | 50 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 271 | 0 | 0% | 39 |

### Battle groups: hc-opp-31c41bf-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 32% | 75% | 20% | 25% | 38% | 0% | 12% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 17% | 82% | 18% | 50% | 0% | 0% | 22% | 78% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-opp-31c41bf-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 58 (34) | 21 | 37 | 37 | 32% | 2.1 | 69 (21) | 0 (4) | 51 (9) | 82 (24) | 9 (10) |
| Mine | Character | 118 | 54 (118) | 53 | 1 | 36 | 17% | 2.4 | 51 (37) | 65 (54) | 49 (7) | 56 (57) | 62 (41) |
| Mine | Clean-up | 18 | 39 (18) | 6 | 32 | 46 | 39% | 2.6 | 83 (3) | 31 (13) | 21 (2) | 62 (12) | 3 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 33 (44) | 18 | 15 | 49 | 27% | 2.9 | 43 (22) | 21 (14) | 27 (8) | 35 (30) | 29 (14) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 100 | 33% | 3.5 | 10 (3) | - | - | 29 (1) | 0 (2) |
| Mine | Hammer | 52 | 49 (52) | 33 | 15 | 34 | 15% | 2.6 | 20 (14) | 52 (35) | 131 (3) | 51 (36) | 43 (16) |
| Mine | Holder | 25 | 38 (25) | 5 | 33 | 36 | 40% | 3.1 | 25 (7) | 51 (11) | 21 (6) | 64 (13) | 6 (11) |
| Mine | Shooter | 37 | 59 (37) | 30 | 29 | 59 | 5% | 1.9 | 29 (6) | 65 (29) | 57 (2) | 73 (22) | 37 (15) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | War machine | 52 | 42 (52) | 42 | 0 | 48 | 2% | 1.1 | 66 (13) | 29 (36) | 78 (3) | 49 (13) | 39 (39) |
| Mine | Wizard | 17 | 8 (17) | 8 | 0 | 42 | 12% | 2.3 | 0 (4) | 20 (8) | 3 (2) | 17 (7) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 41 (68) | 26 | 15 | 64 | 46% | 2.8 | 59 (29) | 25 (11) | 35 (28) | 54 (48) | 10 (20) |
| Opponent | Character | 102 | 58 (102) | 58 | 0 | 36 | 22% | 2.1 | 58 (38) | 65 (48) | 12 (6) | 64 (54) | 54 (38) |
| Opponent | Clean-up | 11 | 60 (11) | 15 | 46 | 20 | 18% | 4.1 | 28 (4) | 66 (6) | 148 (1) | 43 (6) | 76 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 40 (60) | 20 | 20 | 36 | 27% | 2.8 | 37 (30) | 36 (20) | 56 (10) | 44 (28) | 36 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.3 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 35 (50) | 24 | 11 | 48 | 34% | 2.6 | 21 (17) | 43 (30) | 0 (3) | 43 (30) | 22 (20) |
| Opponent | Holder | 40 | 63 (40) | 5 | 58 | 37 | 38% | 2.8 | 37 (7) | 79 (23) | 43 (9) | 75 (26) | 43 (13) |
| Opponent | Shooter | 27 | 49 (27) | 29 | 21 | 43 | 7% | 1.2 | 55 (6) | 45 (19) | 87 (2) | 70 (16) | 23 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 4.0 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 67 (17) | 67 | 0 | 40 | 0% | 1.5 | 0 (3) | 61 (10) | 115 (4) | 0 (3) | 78 (14) |
| Opponent | Wizard | 32 | 20 (32) | 20 | 0 | 28 | 22% | 1.8 | 10 (16) | 59 (9) | 0 (2) | 34 (17) | 0 (10) |

### Charged fights: hc-opp-31c41bf-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 61 | 79 | 1.2 | 1.2 | 63 | 0 | +63 | 0 of 5 | 5 of 5 | +150 | +41 |
| Mine | Chaos Dwarfs | 4 | 321 | 484 | 2.8 | 1.2 | 176 | 28 | +148 | 5 of 11 | 11 of 11 | +0 | +181 |
| Mine | Dwarfen Mountain Holds | 3 | 565 | 180 | 1.0 | 1.3 | 180 | 20 | +160 | 1 of 3 | 1 of 3 | +0 | +240 |
| Mine | Empire of Man | 5 | 270 | 222 | 1.6 | 1.1 | 139 | 35 | +104 | 3 of 8 | 7 of 8 | +663 | +24 |
| Mine | Grand Cathay | 5 | 347 | 318 | 3.8 | 1.1 | 84 | 20 | +64 | 7 of 19 | 16 of 19 | +0 | +68 |
| Mine | High Elf Realms | 4 | 100 | 462 | 3.0 | 1.2 | 154 | 0 | +154 | 4 of 12 | 11 of 12 | +55 | +187 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Lizardmen | 1 | 0 | 290 | 3.0 | 2.0 | 97 | 117 | -20 | 1 of 3 | 3 of 3 | -115 | +170 |
| Mine | Ogre Kingdoms | 1 | 232 | 170 | 4.0 | 1.0 | 42 | 46 | -4 | 1 of 4 | 2 of 4 | - | -4 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 200 | 4.0 | 1.0 | 50 | 0 | +50 | 1 of 4 | 4 of 4 | - | +50 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 33 | 256 | 2.5 | 1.4 | 102 | 0 | +102 | 0 of 5 | 4 of 5 | +162 | +62 |
| Mine | Vampire Counts | 2 | 0 | 696 | 4.5 | 1.2 | 155 | 88 | +66 | 4 of 9 | 6 of 9 | +173 | +53 |
| Mine | Warriors of Chaos | 2 | 10 | 195 | 3.5 | 1.0 | 56 | 324 | -268 | 1 of 7 | 2 of 7 | - | -268 |
| **Mine** | all armies | 36 | 196 | 286 | 2.5 | 1.2 | 113 | 51 | +62 | 28 of 91 | 72 of 91 | +89 | +57 |
| Opponent | Empire of Man | 1 | 569 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 221 | 163 | 2.7 | 1.2 | 61 | 71 | -10 | 5 of 8 | 3 of 8 | +0 | -13 |
| Opponent | High Elf Realms | 3 | 303 | 242 | 1.3 | 1.0 | 182 | 0 | +182 | 2 of 4 | 4 of 4 | - | +182 |
| Opponent | Kingdom of Bretonnia | 2 | 284 | 326 | 2.5 | 1.0 | 130 | 120 | +10 | 2 of 5 | 4 of 5 | - | +10 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 501 | 4.0 | 1.0 | 125 | 64 | +62 | 0 of 4 | 4 of 4 | - | +62 |
| Opponent | Skaven | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 50 | -50 | 1 of 2 | 0 of 2 | -100 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 42 | 636 | 4.2 | 1.1 | 150 | 73 | +76 | 10 of 17 | 14 of 17 | +266 | +64 |
| Opponent | Vampire Counts | 6 | 22 | 713 | 5.2 | 1.2 | 138 | 44 | +94 | 12 of 31 | 22 of 31 | +43 | +102 |
| Opponent | Warriors of Chaos | 9 | 9 | 460 | 3.8 | 1.0 | 122 | 19 | +103 | 13 of 34 | 25 of 34 | +162 | +101 |
| Opponent | Wood Elf Realms | 6 | 132 | 218 | 2.8 | 1.1 | 77 | 53 | +24 | 6 of 17 | 12 of 17 | +188 | +2 |
| **Opponent** | all armies | 36 | 108 | 406 | 3.4 | 1.1 | 120 | 46 | +74 | 51 of 122 | 88 of 122 | +80 | +73 |

### Effective charges: hc-opp-31c41bf-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net +22) | 0 | 0 | 1 (net +150) | 0 | 2 (net +60) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 11 | 0 | 0 | 3 (net -41) | 3 (net +280) | 1 (net +0) | 2 (net +200) | 2 | 33% (3 of 9) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +540) | 1 (net +0) | 0 | 1 (net -60) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 8 | 1 (net -281) | 1 (net +251) | 1 (net +125) | 1 (net +0) | 3 (net +245) | 1 (net +0) | 0 | 12% (1 of 8) |
| Mine | Grand Cathay | 19 | 1 (net +0) | 3 (net +142) | 1 (net +0) | 5 (net +84) | 1 (net +72) | 8 (net +37) | 0 | 5% (1 of 19) |
| Mine | High Elf Realms | 12 | 1 (net +104) | 0 | 1 (net +0) | 5 (net +52) | 5 (net +296) | 0 | 0 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Lizardmen | 3 | 1 (net -350) | 0 | 2 (net +145) | 0 | 0 | 0 | 0 | 67% (2 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 1 (net -185) | 1 (net +0) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +30) | 2 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 2 (net +60) | 0 | 2 (net +162) | 1 (net +66) | 0 | 40% (2 of 5) |
| Mine | Vampire Counts | 9 | 1 (net -736) | 1 (net -60) | 0 | 2 (net +260) | 2 (net +136) | 3 (net +200) | 0 | 0% (0 of 9) |
| Mine | Warriors of Chaos | 7 | 2 (net -196) | 0 | 0 | 0 | 1 (net -214) | 2 (net -386) | 2 | 0% (0 of 5) |
| Opponent | Grand Cathay | 8 | 1 (net -245) | 0 | 0 | 4 (net +54) | 0 | 1 (net -135) | 2 | 0% (0 of 6) |
| Opponent | High Elf Realms | 4 | 0 | 0 | 0 | 1 (net +260) | 1 (net +112) | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 5 | 1 (net +3) | 0 | 0 | 0 | 2 (net +0) | 2 (net +24) | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net +199) | 0 | 2 (net -64) | 1 | 0% (0 of 3) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net -100) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 17 | 4 (net -203) | 0 | 3 (net +176) | 2 (net +348) | 4 (net +103) | 3 (net +157) | 1 | 19% (3 of 16) |
| Opponent | Vampire Counts | 31 | 11 (net +94) | 1 (net +0) | 6 (net +111) | 3 (net +204) | 2 (net +115) | 7 (net +38) | 1 | 20% (6 of 30) |
| Opponent | Warriors of Chaos | 34 | 4 (net +63) | 0 | 8 (net +142) | 4 (net +54) | 1 (net +0) | 15 (net +135) | 2 | 25% (8 of 32) |
| Opponent | Wood Elf Realms | 17 | 2 (net +105) | 0 | 2 (net +260) | 2 (net -95) | 0 | 3 (net +125) | 8 | 22% (2 of 9) |

### Charged fights, damage counted: hc-opp-31c41bf-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 229 | 290 | -97 | 112 | 180 | -67 | -29.4 |
| Mine | 50-54% | 7 | 220 | 225 | +62 | 179 | 70 | +109 | +49.7 |
| Mine | Effective (55-75%) | 12 | 250 | 190 | +34 | 66 | 46 | +20 | +8.1 |
| Mine | 76-89% | 18 | 316 | 169 | +118 | 133 | 27 | +107 | +33.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 247 | 180 | +37 | 125 | 55 | +70 | +28.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 537 | 107 | +178 | 213 | 38 | +176 | +32.7 |
| Mine | No odds | 8 | 273 | 172 | +44 | 120 | 110 | +10 | +3.5 |
| Mine | All fights | 91 | 307 | 183 | +62 | 136 | 66 | +69 | +22.6 |
| Opponent | Long shot (under 50%) | 24 | 221 | 239 | +18 | 168 | 126 | +42 | +19.0 |
| Opponent | 50-54% | 1 | 60 | 85 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 19 | 283 | 231 | +150 | 180 | 44 | +136 | +48.0 |
| Opponent | 76-89% | 18 | 260 | 191 | +106 | 149 | 67 | +82 | +31.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 345 | 217 | +86 | 169 | 74 | +95 | +27.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 451 | 97 | +76 | 82 | 0 | +82 | +18.2 |
| Opponent | No odds | 16 | 159 | 144 | +6 | 100 | 62 | +38 | +23.6 |
| Opponent | All fights | 122 | 281 | 199 | +74 | 150 | 70 | +80 | +28.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-opp-31c41bf-p3 | move | 330 | 73 (22%) | 57 (17%) | 36 (11%) | 221 (67%) |
| hc-opp-31c41bf-p3 | objective | 379 | 56 (15%) | 40 (11%) | 44 (12%) | 279 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: hc-opp-31c41bf-p1

### Scorecard: hc-opp-31c41bf-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 6 | 3 | 0 | 1 | 1 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 4 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | no | 2 | 4 | 1 | 1 | 1 | 0 | 0 | 120 |
| L0135 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 110 |
| L0319 | 1 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 55 |
| L0405 | 3 | 1 | Mine | yes | 7 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 828 |
| L0612 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 1295 |
| L0628 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 4 | 1 | 0 | 0 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 3 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 605 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 4 | 3 | 2 | 1 | 2 | 0 | 0 | 317 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 420 |
| L0930 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 3 | 0 | 1 | 0 | 0 | 501 |
| L1131 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 0 | 1 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 317 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 156 |
| L1335 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 12 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 2 | 0 | 0 | 0 | 0 | 541 |
| L1527 | 3 | 1 | Mine | yes | 17 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 3 | 4 | 0 | 1 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | yes | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 4 | 0 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 5 | 2 | 1 | 1 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 10 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 1 | 3 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 657 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 60 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 7 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 1 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 3.1 | 2.6 | 2.3 | 1.2 | 0.3 | 0.0 | 0.0 | 282.4 |
| **Average** | | | Opponent | 18% | 2.1 | 2.5 | 2.6 | 1.8 | 0.2 | 0.0 | 0.0 | 180.3 |

### KPIs: hc-opp-31c41bf-p1

Rules off - Mine only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (50 of 172) | 2% (4 of 168) | 16% (54 of 340) |
| Winner chose to follow up after the loser gave ground |  | 98% (49 of 50); on the table 98% | 98% (51 of 52); on the table 100% | 98% (100 of 102); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 85% (11 of 13); on the table 92% | 100% (7 of 7); on the table 100% | 90% (18 of 20); on the table 95% |
| Winner chose to pursue after the loser fled |  | 88% (15 of 17); on the table 94% | 94% (29 of 31); on the table 94% | 92% (44 of 48); on the table 94% |
| Winner chose to follow up or pursue (all three) |  | 94% (75 of 80); on the table 96% | 97% (87 of 90); on the table 98% | 95% (162 of 170); on the table 97% |
| Magic missiles tried each own turn | 50%+ | 31% (101 of 330) | 27% (57 of 210) | 29% (158 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (101 of 250) | 35% (51 of 146) | 38% (152 of 396) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (20 of 28) | 48% (25 of 52) | 56% (45 of 80) |
| Points that never fought | lower | 40% (28264 of 71484) | 41% (29306 of 71889) | 40% (57570 of 143373) |
|   infantry points that never fought | lower | 50% (8504 of 16863) | 69% (9184 of 13348) | 59% (17688 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (157 of 279) | 58% (172 of 295) | 57% (329 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.8 uses a game | 65% (13 of 20); 1.1 uses a game | 76% (32 of 42); 1.4 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.7 uses a game | 0% (0 of 8); 0.0 uses a game | 33% (8 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31705 of 59666) | 54% (33792 of 62699) | 54% (65497 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.8 (44%) | 1.5 (36%) | 4.3 (41%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.5 (12%) | 1.4 (13%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.2 (4%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.2 (18%) | 0.7 (16%) | 1.9 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (8%) | 0.4 (3%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.7 (10%) | 0.8 (18%) | 1.4 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.1 | 1.2 | 4.4 | 0.6 | 1.4 |
| not cast | 4.1 | 3.1 | 3.5 | 10.6 | 1.8 | 22.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (47%) | 0.4 (13%) | 4.3 (41%) | 0.6 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (13%) | 0.1 (8%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (5%) | 0.3 (10%) | 1.9 (18%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.3 (10%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (6%) | 0.5 (2%) |
| GONE: slain | 0.7 (17%) | 0.7 (21%) | 0.8 (22%) | 1.4 (13%) | 0.2 (11%) | 3.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.2 (6%) | 0.2 (5%) | 0.3 (3%) | 0.0 (2%) | 1.1 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (5%) | 0.0 (1%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.6 (64%) | 0.3 (9%) | 1.3 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.2 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.4 a game | 0.7 a game |
| stood (cast and not dispelled) | 59% (19 of 32) | 54% (7 of 13) | 58% (26 of 45) |
| the unit moved after it | 42% (8 of 19) | 86% (6 of 7) | 54% (14 of 26) |
| it charged on its next turn | 5% (1 of 19) | 14% (1 of 7) | 8% (2 of 26) |
| the enemy charged it first | 5% (1 of 19) | 0% (0 of 7) | 4% (1 of 26) |
| it fought by the end of its next turn | 11% (2 of 19) | 0% (0 of 7) | 8% (2 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 19) | 14% (1 of 7) | 12% (3 of 26) |
| none of these (no charge, no fight, no charge escaped) | 74% (14 of 19) | 71% (5 of 7) | 73% (19 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (592 of 902) | 62% (394 of 631) | 64% (986 of 1533) |
|   cavalry | 60% (43 of 72) | 66% (88 of 134) | 64% (131 of 206) |
|   character | 58% (69 of 120) | 36% (43 of 119) | 47% (112 of 239) |
|   chariot | 49% (47 of 96) | 64% (27 of 42) | 54% (74 of 138) |
|   infantry | 58% (179 of 307) | 66% (160 of 243) | 62% (339 of 550) |
|   monster | 71% (24 of 34) | 62% (20 of 32) | 67% (44 of 66) |
|   war machine | 84% (230 of 273) | 92% (56 of 61) | 86% (286 of 334) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (30%) | 1.5 (23%) | 4.1 (27%) |
| CHARGED: it charged | 1.0 (12%) | 1.3 (19%) | 2.3 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.4 (6%) | 0.9 (6%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (22%) | 1.3 (20%) | 3.2 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (8%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.1 (17%) | 2.5 (17%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.2 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 0.9 | 85% | 2.9 pts | 16 pts |
| character | 3.6 | 1.0 | 84% | 4.1 pts | 15 pts |
| chariot | 2.1 | 1.4 | 65% | 14.1 pts | 29 pts |
| infantry | 13.4 | 4.8 | 75% | 8.3 pts | 111 pts |
| monster | 1.5 | 0.3 | 80% | 5.9 pts | 9 pts |
| war machine | 7.9 | 6.2 | 62% | 25.8 pts | 205 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.2 | 4.8 |
| Charges that made contact a game | 3.1 | 3.4 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.05 declared, 0.81 contact (21 units) | 0.46 declared, 0.23 contact (13 units) | 0.82 declared, 0.59 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.17 declared, 0.17 contact (6 units) | 1.00 declared, 0.62 contact (8 units) | 0.64 declared, 0.43 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.37 contact (247 units) | 0.63 declared, 0.41 contact (278 units) | 0.58 declared, 0.39 contact (525 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (38 of 70) | 67% (14 of 21) | 38% (3 of 8) | 56% (55 of 99) |
| Character in a unit | 78% (32 of 41) | 68% (17 of 25) | 50% (2 of 4) | 73% (51 of 70) |
| Character on its own | 80% (37 of 46) | 51% (18 of 35) | 39% (24 of 62) | 55% (79 of 143) |
| Chariot | 56% (9 of 16) | 60% (6 of 10) | - | 58% (15 of 26) |
| Infantry | 48% (43 of 89) | 42% (15 of 36) | 50% (1 of 2) | 46% (59 of 127) |
| Monster | 56% (18 of 32) | 60% (6 of 10) | - | 57% (24 of 42) |
| Monstrous | 55% (6 of 11) | 71% (10 of 14) | - | 64% (16 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 94% (16 of 17); on the table 100% | 26% (36 of 138) | 38% | 48% (16 of 33) | 78% (7 of 9); 4.3 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (4 of 4); on the table 100% | 46% (11 of 24) | 33% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (5 of 5); on the table 100% | - | 59% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 91% (10 of 11); on the table 91% | 50% (18 of 36) | 62% | 58% (37 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 100% (15 of 15); on the table 100% | 21% (23 of 108) | 39% | 52% (23 of 44) | 92% (11 of 12); 7.0 uses a game | 100% (1 of 1); 0.8 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 88% (14 of 16); on the table 94% | 13% (4 of 30) | 40% | 49% (24 of 49) | 100% (5 of 5); 3.0 uses a game | 11% (2 of 18); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 50% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (3 of 3); on the table 100% | - | 32% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | - | 25% (3 of 12) | 61% | 81% (17 of 21) | 33% (1 of 3); 0.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (4 of 4); on the table 100% | 22% (8 of 36) | 12% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 92% (11 of 12); on the table 92% | 50% (15 of 30) | 38% | 59% (20 of 34) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 94% (16 of 17); on the table 94% | 17% (2 of 12) | 40% | 40% (12 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (23 of 25); on the table 96% | 41% (22 of 54) | 35% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 100% (16 of 16); on the table 100% | 30% (9 of 30) | 26% | 66% (49 of 74) | 75% (3 of 4); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (21 of 21); on the table 100% | 23% (7 of 30) | 41% | 52% (34 of 66) | 33% (2 of 6); 0.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hc-opp-31c41bf-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (35) | 45% (33) | 46% (68) |
| ...free all their last turn and able to turn (per game) | 0.44 | 0.47 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.31 | 0.58 |
| ...with the charger already in that arc before they moved (per game) | 0.28 | 0.33 | 0.61 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.42 | 1.42 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.69 | 1.64 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.81 | 4.50 | 9.31 |

### Quality by phase: hc-opp-31c41bf-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 44% (55 of 126) | 40% (64 of 161) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (213 of 451) | 54% (139 of 259) |
| Strategy | Close-in objectives charged next turn | 10% (17 of 163) | 15% (28 of 182) |
| Strategy | Support requests answered (helper made contact too) | 62% (10 of 16) | 42% (10 of 24) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (6 of 12) | 75% (9 of 12) |
| Strategy | Joined characters whose unit fought | 37% (22 of 59) | 57% (26 of 46) |
| Strategy | Lone characters that fought | 79% (69 of 87) | 70% (63 of 90) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 282.4 | 180.3 |
| Movement | Fights charged into per game | 2.6 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 80, net -41 | 20 of 92, net +42 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 80, net +115 | 25 of 92, net +162 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 80, net +0 | 7 of 92, net +269 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 80, net +128 | 18 of 92, net +85 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (170 of 388) | 42% (154 of 367) |
| Shooting | Points destroyed by shooting units | 26.0 | 37.3 |
| Shooting | War machine shots | 6.4 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (114 of 230) | 38% (21 of 56) |
| Shooting | Points destroyed by war machines | 87.4 | 14.2 |
| Magic | Magic missiles cast | 1.8 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (24 of 66) | 45% (17 of 38) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.1 |
| Magic | Wounds caused by other spells | 1.2 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 87.1 | 31.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.4 / 0.5 / 0.2 | 1.6 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 312.1 | 403.1 |
| Combat | Points run down | 72.2 | 142.9 |
| Combat | Net points per charged fight, damage counted | +68 | +106 |
| Combat | Net per 100 charger points, damage counted | +23.5 | +40.1 |
| Combat | First round won (charged fights) | 71% | 66% |
| Combat | Net points per charged fight | +67 | +112 |
| Combat | Net points per supported fight / lone fight | +121 / +58 | +291 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 43 of 94 | 45 of 106 |
| Game | Points lost | 716.6 | 692.5 |
| Game | VP from objectives | 621.1 | 653.9 |
| Game | Lone holders (player turns) | 3.1 | 2.1 |

- Mine won / drew / lost: 13 / 7 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -44 VP
- The side that went first won 13 of 29 games with a winner
- Points traded per game (both sides' losses): 1409
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-opp-31c41bf-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 4.9 | -134.2 | 109.7 | 84.3 | 5.1 | -142.3 | 248.5 | 78.1 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.9 | +0.0 | 0.0 | 21.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.2 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| BEST FACING | 0.3 | +8.5 | 0.0 | 10.6 | 0.3 | +6.1 | 0.0 | 15.0 |
| BEST FIRST | 0.9 | +49.3 | 12.4 | 6.3 | 0.9 | +55.8 | 11.9 | 14.1 |
| BEST OVERALL | 0.3 | +18.5 | 0.0 | 8.9 | 0.2 | +4.8 | 0.0 | 7.0 |
| BEST PREY | 0.6 | +46.0 | 12.2 | 16.5 | 0.9 | +59.3 | 17.9 | 43.1 |
| BEST PRIZE | - | - | - | - | 0.1 | -2.5 | 3.1 | 4.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 0.0 | 0.3 | -2.3 | 0.0 | 31.1 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 2.9 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| BLOCKED WHEEL | 0.4 | +13.5 | 0.0 | 0.0 | 0.2 | +6.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.4 | -25.6 | 34.4 | 6.5 | 0.3 | -22.9 | 21.2 | 5.4 |
| BOMBING RUN | 0.1 | +4.4 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 108.9 | 11.1 | 0.1 | +0.0 | 0.0 | 3.6 |
| CANNON PLANNED TARGET | 5.1 | +110.4 | 302.2 | 70.0 | 1.3 | +20.1 | 32.4 | 34.2 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.1 | 5.4 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 10.9 | 10.6 | 0.1 | +0.0 | 10.8 | 3.5 |
| CAST JOB | 1.1 | +31.5 | 99.1 | 32.1 | 0.7 | +20.2 | 68.9 | 37.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +67.4 | 29.4 | 0.0 | 0.2 | +2.4 | 3.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 32.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.1 | +68.8 | 0.0 | 41.3 | 1.6 | +88.8 | 0.0 | 40.1 |
| CHAFF PASSED | 0.3 | -0.0 | 0.0 | 14.0 | 0.2 | -0.2 | 0.0 | 3.8 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 225.2 | 118.6 | 2.5 | +0.0 | 182.9 | 101.3 |
| CHARGE NOW WEIGHED | 0.3 | -16.0 | 12.8 | 0.0 | 0.2 | -5.6 | 2.1 | 1.4 |
| CHARGER SLAIN LOST | 0.6 | -24.0 | 65.0 | 49.8 | 0.7 | -22.3 | 59.7 | 12.5 |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.0 | 10.9 | 22.2 | 0.1 | -2.3 | 16.1 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 13.6 | 1.7 | 0.2 | +0.0 | 27.6 | 3.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 20.0 | 36.5 | 0.4 | +0.0 | 9.3 | 28.7 |
| CONVEYANCE SEARCH | 0.5 | +54.7 | 8.9 | 32.4 | 0.2 | +74.8 | 0.0 | 15.2 |
| COVER ONCE | 6.9 | -560.4 | 0.0 | 149.2 | 4.8 | -311.6 | 0.0 | 146.9 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 39.8 | 2.6 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.0 | 3.1 | 0.0 | 0.1 | +2.6 | 11.9 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.3 | 7.1 | 12.3 | 0.1 | +3.8 | 12.6 | 1.7 |
| ELIXIR WORTH | 0.0 | +0.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +127.2 | 0.0 | 30.4 | 1.4 | +93.9 | 0.0 | 61.0 |
| FALLBACK BY WORTH | 3.7 | +23.0 | 0.0 | 38.1 | 5.6 | +30.5 | 0.0 | 44.9 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.3 | 0.8 | 6.1 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 104.8 | 3.9 | +0.0 | 0.0 | 166.4 |
| FOLLOW UP WEIGHED | 0.9 | +103.6 | 0.0 | 37.9 | 0.8 | +113.7 | 0.0 | 32.8 |
| FRIENDS SHOTS CHECKED | 0.3 | +10.0 | 0.0 | 19.7 | 0.2 | +7.1 | 0.0 | 10.9 |
| GIVES UP | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.3 | 10.4 | 2.0 |
| GROUND FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.2 | 0.0 | 0.1 | +0.0 | 0.0 | 2.5 |
| HELPER UNSEEN | 0.2 | +0.0 | 27.4 | 24.1 | 0.4 | +0.0 | 27.6 | 26.6 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -18.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.3 | -133.0 | 424.9 | 169.4 | 5.5 | -114.1 | 298.0 | 88.8 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +7.4 | 4.6 | 4.8 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +17.4 | 0.0 | 0.0 | 0.4 | +18.8 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +1.7 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +11.1 | 0.0 | 0.0 | 0.1 | +10.8 | 4.6 | 1.9 |
| HUNT THE GUNS | 0.1 | +36.2 | 10.5 | 0.0 | 0.1 | +49.6 | 4.6 | 4.8 |
| IDLE COST | 14.9 | -250.1 | 0.0 | 199.2 | 18.2 | -281.4 | 0.0 | 240.3 |
| INVITES THE FIGHT | 1.4 | +11.8 | 44.6 | 30.9 | 1.2 | +11.2 | 95.9 | 12.9 |
| JOINT CHARGE PLAN | 0.2 | +9.4 | 21.8 | 5.2 | 0.3 | +12.4 | 0.0 | 3.2 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.3 | 13.2 | 10.6 | 0.1 | -1.9 | 3.1 | 1.2 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +33.3 | 143.8 | 42.6 | 1.6 | +46.7 | 87.3 | 33.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +58.9 | 88.8 | 99.1 | 1.9 | +126.8 | 130.4 | 61.8 |
| KILLS COUNT NEXT TURN | 4.4 | +179.5 | 213.9 | 124.3 | 3.0 | +152.3 | 101.1 | 59.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +8.8 | 10.9 | 2.4 | 0.4 | +22.4 | 10.4 | 22.5 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 7.1 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -5.6 | 27.8 | 2.8 | 0.7 | +3.9 | 31.2 | 5.2 |
| LOST CHARGE | 2.6 | -31.7 | 87.2 | 43.8 | 2.6 | -38.0 | 92.6 | 66.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -13.3 | 0.0 | 10.6 | 0.2 | -24.2 | 0.0 | 11.0 |
| MAKE SURE TOGETHER | 0.5 | +26.8 | 17.5 | 21.7 | 0.8 | +54.1 | 0.0 | 59.5 |
| MANOEUVRE | 0.1 | +3.9 | 0.0 | 0.0 | 0.2 | +10.0 | 0.0 | 10.3 |
| MARCH AT ESCAPER | 0.1 | +3.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +18.6 | 0.0 | 10.9 | 0.4 | +20.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +11.6 | 7.6 | 10.6 | 0.2 | +9.2 | 2.9 | 26.1 |
| MARCH OVER CASTS | 0.6 | +25.3 | 0.0 | 0.0 | 0.2 | +9.8 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 4.4 | +71.4 | 0.0 | 117.1 | 5.7 | +45.2 | 0.0 | 124.8 |
| MEASURED NEXT CHARGE | - | - | - | - | 10.7 | -259.6 | 231.7 | 298.3 |
| MISSILES IN THE MOVE | 4.1 | +166.7 | 0.0 | 92.2 | 3.6 | +60.5 | 0.0 | 90.8 |
| MISSILES NEXT TURN | 4.8 | +112.0 | 0.0 | 124.2 | 4.1 | +43.1 | 0.0 | 80.2 |
| MODEL FACING | 0.2 | +26.0 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 18.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +24.0 | 0.0 | 0.0 | 0.4 | +28.3 | 0.0 | 18.0 |
| MOVE SPELL IN RANGE | 0.2 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -75.2 | 0.0 | 26.9 | 0.1 | -0.2 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +224.0 | 180.5 | 93.8 | 1.4 | +7.4 | 26.4 | 30.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +5.9 | 3.1 | 0.0 |
| NO RALLY LEFT | 0.1 | +10.2 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -16.5 | 48.5 | 2.1 | 0.2 | -8.1 | 21.1 | 1.1 |
| NOT TURNED | 4.8 | +51.5 | 0.0 | 115.7 | 4.5 | +49.6 | 0.0 | 97.0 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 31.0 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.0 | -693.2 | 0.0 | 238.0 | 15.6 | -700.1 | 10.4 | 219.9 |
| ONE FIGHT FORMULA | 7.6 | -140.1 | 34.3 | 189.9 | 7.8 | -149.0 | 37.9 | 216.0 |
| ONE OBJECTIVE FORMULA | 2.2 | -68.6 | 0.0 | 37.1 | 1.9 | -42.8 | 0.0 | 32.9 |
| OPENS A LANE | 0.2 | +1.9 | 1.5 | 0.0 | 0.1 | +0.1 | 15.4 | 0.0 |
| OPENS UP | 0.1 | +4.1 | 6.1 | 0.0 | 0.1 | +0.6 | 5.2 | 0.0 |
| OVERRUN THREAT | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +12.9 | 39.1 | 18.9 | 0.6 | +7.8 | 15.1 | 27.0 |
| PATHS CROSS | 2.0 | +100.7 | 0.0 | 45.2 | 2.7 | +147.5 | 0.0 | 64.5 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 15.0 |
| PLAN RESULT | 37.1 | +1452.5 | 1269.6 | 799.4 | 38.7 | +1176.6 | 1265.4 | 929.8 |
| PURSUES BIG PREY | 0.1 | -5.1 | 0.0 | 12.3 | - | - | - | - |
| PURSUES ON | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.2 | +11.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +20.2 | 0.0 | 35.0 | 1.4 | +16.3 | 0.0 | 32.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.3 | 4.4 | 0.0 | 0.2 | -7.4 | 6.1 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -14.4 | 0.0 | 24.8 | 1.2 | -24.5 | 0.0 | 20.4 |
| REDIRECT COUNTER | 1.6 | +53.5 | 0.0 | 33.6 | 3.1 | +231.7 | 0.0 | 45.1 |
| REDIRECT WEIGHED | 0.2 | +0.9 | 2.6 | 1.4 | 0.4 | +5.1 | 7.4 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 6.1 | 0.4 | +0.0 | 0.0 | 6.2 |
| RESERVE FALL BACK | 0.6 | +17.4 | 0.0 | 13.9 | 0.7 | +15.9 | 0.0 | 10.6 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 8.2 | 0.1 | +5.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +98.3 | 210.6 | 116.8 | 2.6 | +57.1 | 223.0 | 74.2 |
| RISK ONCE | 2.4 | +42.9 | 14.4 | 62.1 | 4.8 | +278.1 | 37.1 | 265.2 |
| RUN DOWN | - | - | - | - | 2.6 | -16.5 | 161.6 | 73.2 |
| SAFE SURE CHARGE | 0.0 | -0.3 | 1.1 | 0.0 | 0.0 | -1.9 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +58.8 | 0.0 | 26.4 | 0.7 | +32.4 | 0.0 | 28.1 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.3 | 0.0 | 0.0 | 0.4 | -17.5 | 0.0 | 6.7 |
| SEARCH SPOT | 1.6 | +46.2 | 0.0 | 19.9 | 2.2 | +86.8 | 0.0 | 15.4 |
| SELF MOVE SPELL | 0.2 | +17.5 | 0.0 | 18.1 | 0.2 | +0.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +88.7 | 65.9 | 48.8 | 2.2 | +150.3 | 8.9 | 75.6 |
| SET-UP ANY TARGET | 0.2 | +11.4 | 0.0 | 11.2 | 0.1 | +11.2 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +76.8 | 81.1 | 10.9 | 1.1 | +21.1 | 55.1 | 10.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.4 | +0.0 | 53.7 | 13.8 | 0.3 | +0.0 | 34.0 | 0.0 |
| SHOTS IN THE MOVE | 14.6 | +538.8 | 0.0 | 199.4 | 10.2 | +224.2 | 0.0 | 115.3 |
| SPELL SETS UP CHARGE | 0.2 | +19.7 | 8.9 | 11.2 | 0.2 | +62.7 | 0.0 | 7.6 |
| SPELL WORTH | 0.9 | +14.4 | 98.8 | 95.3 | 1.6 | +35.6 | 81.8 | 91.7 |
| SPELLS IN THE FIGHT | 0.6 | -6.6 | 52.8 | 33.1 | 0.6 | -8.4 | 59.2 | 35.4 |
| STABLE ROLE | 10.5 | +0.0 | 382.6 | 167.9 | 11.8 | +0.0 | 394.3 | 133.2 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 10.9 | - | - | - | - |
| STAY WEIGHED | 0.2 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.3 | 10.5 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.6 | +22.8 | 0.0 | 30.4 | 0.2 | +4.5 | 0.0 | 26.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.7 | -48.3 | 329.1 | 81.1 | 7.6 | -53.2 | 341.3 | 120.8 |
| SUPPORTS | 3.0 | +48.3 | 169.9 | 43.0 | 5.3 | +57.9 | 198.8 | 63.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.0 | 2.3 | 8.6 | 0.1 | -0.8 | 4.7 | 0.0 |
| SURE REACH TOGETHER | 0.9 | -27.8 | 32.8 | 24.6 | 1.0 | +16.7 | 3.8 | 25.1 |
| THROUGH LINE OF FIRE | 0.5 | +26.4 | 0.0 | 0.0 | 0.2 | +9.2 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -5.5 | 13.0 | 1.4 | 0.2 | -8.4 | 18.5 | 5.4 |
| TWO OR MORE ARRIVE | 0.3 | +2.5 | 22.2 | 11.1 | 0.6 | +2.7 | 0.0 | 4.8 |
| WAIT AFTER COSTS | 6.7 | -335.0 | 280.8 | 144.9 | 3.6 | -201.8 | 149.5 | 46.9 |
| WALKS TO THE FIGHT | 1.6 | +11.5 | 41.7 | 12.3 | 1.1 | +9.7 | 27.2 | 3.5 |
| WAR ENGINE CHARGES | 0.1 | +3.4 | 10.7 | 0.0 | 0.0 | +1.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 17.9 | 15.8 | 0.4 | +0.0 | 11.7 | 9.2 |
| WEARS DOWN | 1.2 | +70.1 | 168.9 | 20.3 | 1.4 | +41.2 | 102.6 | 42.1 |
| WHO HITS BACK | 0.2 | +15.5 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.5 | +17.8 | 45.0 | 1.7 | 0.3 | +7.7 | 26.4 | 2.6 |
| WHOLE FIGHT GAIN | 0.3 | +22.4 | 43.8 | 20.6 | 0.6 | +31.0 | 62.0 | 8.7 |
| WIDER SPREAD | 2.4 | -8.1 | 267.1 | 98.3 | 3.2 | -9.0 | 266.6 | 85.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 3.1 | 0.0 | 0.0 | +0.0 | 1.1 | 0.0 |

### Rule changes: hc-opp-31c41bf-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1135 | 1135 | 1135 | 31.53 | -50160 | -44.2 |
| PATHS CROSS | 167 | 167 | 167 | 4.64 | +8935 | +53.5 |
| SEARCH SPOT | 137 | 137 | 134 | 3.72 | +4789 | +35.7 |
| SUPPORTS | 299 | 299 | 120 | 3.33 | +1248 | +10.4 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +7959 | +78.0 |
| SHOTS IN THE MOVE | 895 | 640 | 99 | 2.75 | +2449 | +24.7 |
| KILLS COUNT NEXT TURN | 265 | 265 | 98 | 2.72 | +3191 | +32.6 |
| COVER ONCE | 421 | 246 | 85 | 2.36 | +1458 | +17.2 |
| MOVE TO CHARGE | 169 | 169 | 82 | 2.28 | +2602 | +31.7 |
| ONE FIGHT FORMULA | 555 | 343 | 75 | 2.08 | +245 | +3.3 |
| SET UP TOGETHER | 120 | 110 | 70 | 1.94 | +3516 | +50.2 |
| RISK ONCE | 259 | 198 | 69 | 1.92 | +2751 | +39.9 |
| BEST FIRST | 68 | 68 | 68 | 1.89 | +3783 | +55.6 |
| ADVANCE WORTH | 359 | 359 | 67 | 1.86 | +1067 | +15.9 |
| CANNON PLANNED TARGET | 231 | 231 | 67 | 1.86 | -809 | -12.1 |
| CHAFF IN THE MOVE | 97 | 93 | 66 | 1.83 | +2327 | +35.3 |
| WAIT AFTER COSTS | 372 | 372 | 64 | 1.78 | +905 | +14.1 |
| FALLBACK BY WORTH | 333 | 333 | 62 | 1.72 | +1926 | +31.1 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +7822 | +128.2 |
| SAFER THAN THE JOB | 59 | 59 | 59 | 1.64 | +3285 | +55.7 |
| MEASURED NEXT CHARGE | 386 | 293 | 58 | 1.61 | +631 | +10.9 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| MISSILES IN THE MOVE | 276 | 175 | 51 | 1.42 | +1613 | +31.6 |
| INVITES THE FIGHT | 92 | 92 | 47 | 1.31 | +331 | +7.0 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1198 | +25.5 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 45 | 1.25 | +1313 | +29.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| REDIRECT COUNTER | 169 | 82 | 43 | 1.19 | +3652 | +84.9 |
| IDLE COST | 1190 | 677 | 42 | 1.17 | +463 | +11.0 |
| SHOOTS FROM THE BEST SPOT | 104 | 104 | 41 | 1.14 | +1023 | +25.0 |
| WALKS TO THE FIGHT | 97 | 97 | 40 | 1.11 | +191 | +4.8 |
| ARTILLERY RE-ROLL WEIGHED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RISK BY ARC | 170 | 160 | 38 | 1.06 | +1417 | +37.3 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| KILLS COUNT | 112 | 108 | 33 | 0.92 | +1384 | +41.9 |
| CAST JOB | 66 | 66 | 31 | 0.86 | +599 | +19.3 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +983 | +32.8 |
| MOVE AND CAST | 28 | 28 | 28 | 0.78 | +1883 | +67.3 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| CHARGE NOW FIRST | 171 | 171 | 27 | 0.75 | -1384 | -51.3 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MAKE SURE TOGETHER | 49 | 37 | 25 | 0.69 | +948 | +37.9 |
| MARCH CHECK | 28 | 26 | 25 | 0.69 | +1362 | +54.5 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +664 | +27.7 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +1280 | +53.3 |
| MAX FOR POSITIONING | 364 | 223 | 23 | 0.64 | +14 | +0.6 |
| BEST FACING | 22 | 22 | 22 | 0.61 | +526 | +23.9 |
| BLOCKED WHEEL | 22 | 22 | 22 | 0.61 | +703 | +32.0 |
| BEST PREY | 54 | 54 | 20 | 0.56 | +1025 | +51.2 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -7 | -0.3 |
| CHARGE NOW WEIGHED | 19 | 19 | 19 | 0.53 | +1011 | +53.2 |
| HONEST WORTH | 461 | 457 | 19 | 0.53 | +143 | +7.5 |
| BEST OVERALL | 18 | 18 | 18 | 0.50 | +840 | +46.6 |
| WAR ENGINE JOBS | 32 | 32 | 18 | 0.50 | -1499 | -83.3 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +618 | +36.3 |
| KEEPS ITS TARGET | 96 | 96 | 17 | 0.47 | +282 | +16.6 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -94 | -6.3 |
| CASTING BLOCK | 28 | 28 | 14 | 0.39 | +592 | +42.3 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MARCH ODDS | 13 | 13 | 13 | 0.36 | +106 | +8.1 |
| SUPPORT NARROWED | 441 | 441 | 13 | 0.36 | -175 | -13.4 |
| WEARS DOWN | 94 | 91 | 13 | 0.36 | +307 | +23.6 |
| WHOLE FIGHT GAIN | 32 | 27 | 13 | 0.36 | +408 | +31.4 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| WHO HITS BACK | 10 | 10 | 10 | 0.28 | +529 | +52.9 |
| MANOEUVRE | 12 | 12 | 9 | 0.25 | +501 | +55.6 |
| LOST CHARGE | 186 | 185 | 8 | 0.22 | +463 | +57.9 |
| MISSILES NEXT TURN | 323 | 198 | 8 | 0.22 | +16 | +2.0 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +934 | +116.8 |
| REFUSING RETIRES | 23 | 23 | 8 | 0.22 | -2 | -0.2 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WIDER SPREAD | 204 | 195 | 8 | 0.22 | +66 | +8.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +283 | +40.4 |
| SURE REACH TOGETHER | 67 | 52 | 7 | 0.19 | +5 | +0.7 |
| HUNT IN PAIRS | 23 | 13 | 6 | 0.17 | +305 | +50.8 |
| OVERRUNS AWAY | 39 | 38 | 6 | 0.17 | +64 | +10.8 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +265 | +44.2 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +312 | +52.1 |
| WHOLE FIGHT | 28 | 27 | 5 | 0.14 | +218 | +43.6 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +48 | +11.9 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +285 | +71.3 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -189 | -47.2 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -102 | -25.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -89 | -29.8 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +54 | +18.2 |
| JOINT CHARGE PLAN | 19 | 19 | 3 | 0.08 | +157 | +52.5 |
| LONG SHOT | 43 | 39 | 3 | 0.08 | -36 | -12.2 |
| ONE OBJECTIVE FORMULA | 149 | 60 | 3 | 0.08 | +85 | +28.4 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BLOWS WHERE AIMED | 24 | 23 | 2 | 0.06 | +272 | +136.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +160 | +79.8 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| HUNT ADVANCE | 7 | 7 | 2 | 0.06 | +57 | +28.4 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +9 | +4.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OPENS UP | 6 | 6 | 2 | 0.06 | +12 | +6.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +158 | +78.9 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -185 | -92.5 |
| RUN DOWN | 95 | 93 | 2 | 0.06 | +4 | +2.1 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -79 | -39.4 |
| SPELLS IN THE FIGHT | 43 | 41 | 2 | 0.06 | +9 | +4.6 |
| TWO OR MORE ARRIVE | 32 | 29 | 2 | 0.06 | +1 | +0.7 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -44 | -21.9 |
| BACKUP TARGETS | 18 | 9 | 1 | 0.03 | +0 | +0.0 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -4 | -4.0 |
| DEFENSIVE FLOOR | 4 | 3 | 1 | 0.03 | +22 | +21.8 |
| EDGE GIVE GROUND | 7 | 7 | 1 | 0.03 | +16 | +16.1 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +14 | +13.8 |
| REDIRECT BY WHAT IT STOPS | 69 | 69 | 1 | 0.03 | +16 | +15.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +4 | +3.9 |
| STOPS | 2 | 2 | 1 | 0.03 | +3 | +3.3 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +15 | +14.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 26 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 45 | 41 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 303 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 12 | 12 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 15 | 15 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 27 | 27 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 19 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 335 | 335 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OPENS A LANE | 13 | 6 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 2 | not checked | - | - | - | - |
| PLAN RESULT | 2727 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 803 | 801 | 0 | 0.00 | - | - |
| TURN WORTH | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: hc-opp-31c41bf-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.00 | 13.67 | 45.5 |
| FALLBACK | gate | 0.39 | 0.83 | 41.4 |
| TURN GATE | gate | 0.31 | 0.44 | 32.3 |
| CHARGE NOW FIRST | rule | 0.33 | 0.39 | 53.2 |
| CANNON PLANNED TARGET | rule | 0.56 | - | 45.9 |
| WAR ENGINE JOBS | rule | 0.33 | 0.17 | 83.3 |
| SUPPORT NARROWED | rule | 0.14 | 0.22 | 13.4 |
| SUPPORT REQUEST | gate | 0.06 | 0.22 | 30.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 14.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.19 | 14.4 |
| PATHS CROSS | rule | 0.11 | 0.06 | 21.1 |
| AFTERMATH BAND | gate | 0.03 | 0.11 | 2.1 |
| CHAFF PASSED | rule | 0.03 | 0.11 | 1.4 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 47.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 25.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 10.6 |
| BEST PRIZE | rule | - | 0.08 | 29.8 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 12.6 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 15.9 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 3.2 |
| SAFER THAN THE JOB | rule | - | 0.08 | 22.1 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 30.2 |
| PURSUES BIG PREY | rule | 0.06 | - | 92.5 |
| RULE SWITCHED OFF | gate | 0.06 | - | 19.8 |
| SAFE SURE CHARGE | rule | 0.03 | 0.03 | 39.4 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 1.1 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 21.9 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 4.0 |
| LONG SHOT | rule | - | 0.03 | 58.0 |
| NO REASON | gate | - | 0.03 | 13.8 |

### Plans: hc-opp-31c41bf-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.5 | 17% | 196 | 277 | 141% |
| Mine | charge | 2.9 | 56% | 272 | 251 | 92% |
| Mine | close in | 4.5 | 24% | 236 | 161 | 68% |
| Mine | hold | 5.6 | 38% | 341 | 0 | 0% |
| Mine | join | 0.5 | 94% | 20 | 0 | 0% |
| Mine | shoot | 10.0 | 62% | 344 | 764 | 222% |
| Mine | support | 4.0 | 85% | 33 | 0 | 0% |
| Opponent | advance | 11.8 | 16% | 224 | 343 | 153% |
| Opponent | charge | 4.0 | 58% | 273 | 370 | 135% |
| Opponent | close in | 5.1 | 25% | 204 | 164 | 80% |
| Opponent | hold | 4.4 | 37% | 302 | 0 | 0% |
| Opponent | join | 1.1 | 100% | 50 | 0 | 0% |
| Opponent | shoot | 5.6 | 54% | 110 | 299 | 272% |
| Opponent | support | 6.7 | 89% | 56 | 0 | 0% |

### Packages: hunt the guns, hc-opp-31c41bf-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 33% | 33% | 0% | 2.0 | 435 | 133 | 33% | 12 |
| Opponent | 0.1 | 5 | 0 | 0% | 20% | 20% | 2.0 | 357 | 78 | 20% | 87 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.6 | 3 | 0 | 33% | 33% | 0% | 2.0 | 435 | 133 | 33% | 85 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 281 | 0 | 0% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Warriors of Chaos | 0.4 | 3 | 0 | 0% | 33% | 33% | 2.0 | 392 | 129 | 33% | 41 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 62 |

### Battle groups: hc-opp-31c41bf-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 37% | 57% | 10% | 50% | 26% | 0% | 11% | 58% | 5% |
| Opponent | REDIRECT COUNTER | 3.1 | 18% | 75% | 25% | 40% | 13% | 0% | 20% | 60% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-opp-31c41bf-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 4.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Mine | Chaff | 37 | 30 (37) | 16 | 14 | 57 | 46% | 2.2 | 24 (16) | 17 (9) | 47 (12) | 46 (24) | 6 (13) |
| Mine | Character | 123 | 51 (123) | 51 | 0 | 36 | 19% | 2.4 | 81 (35) | 43 (60) | 45 (12) | 63 (62) | 48 (45) |
| Mine | Clean-up | 24 | 51 (24) | 8 | 44 | 27 | 42% | 3.3 | 42 (9) | 55 (11) | 85 (4) | 82 (14) | 15 (10) |
| Mine | Fast | 4 | 40 (4) | 40 | 0 | 34 | 0% | 1.5 | 0 (1) | 0 (2) | 317 (1) | 40 (4) | - |
| Mine | Fast Hammer | 41 | 45 (41) | 25 | 20 | 51 | 29% | 2.9 | 59 (18) | 47 (12) | 17 (11) | 56 (28) | 25 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 20 | 0% | 2.6 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 38 (58) | 21 | 16 | 41 | 10% | 2.5 | 23 (10) | 42 (38) | 35 (10) | 46 (34) | 29 (24) |
| Mine | Holder | 25 | 69 (25) | 2 | 67 | 38 | 48% | 3.5 | 94 (6) | 56 (15) | 94 (3) | 87 (10) | 59 (14) |
| Mine | Shooter | 44 | 85 (44) | 16 | 69 | 33 | 2% | 1.9 | 22 (5) | 108 (31) | 57 (8) | 113 (24) | 54 (20) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 47 (56) | 47 | 0 | 38 | 7% | 1.2 | 44 (13) | 42 (37) | 85 (6) | 17 (11) | 55 (45) |
| Mine | Wizard | 23 | 12 (23) | 12 | 0 | 36 | 17% | 2.7 | 0 (6) | 23 (9) | 0 (4) | 24 (5) | 4 (14) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 0 | 0% | 6.0 | - | 94 (1) | - | 94 (1) | - |
| Opponent | Chaff | 66 | 72 (66) | 31 | 42 | 41 | 47% | 2.7 | 103 (28) | 35 (16) | 65 (22) | 99 (48) | 0 (18) |
| Opponent | Character | 114 | 43 (114) | 43 | 0 | 39 | 22% | 2.4 | 51 (41) | 46 (55) | 22 (5) | 47 (68) | 48 (33) |
| Opponent | Clean-up | 16 | 61 (16) | 48 | 13 | 33 | 38% | 2.9 | 73 (5) | 62 (8) | 37 (3) | 81 (8) | 45 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 43 (58) | 26 | 18 | 48 | 31% | 2.8 | 53 (25) | 40 (19) | 27 (14) | 44 (42) | 41 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 43 | 30% | 2.0 | 0 (3) | 0 (3) | 0 (3) | 0 (9) | - |
| Opponent | Hammer | 65 | 44 (65) | 37 | 7 | 39 | 28% | 2.4 | 37 (16) | 49 (42) | 16 (7) | 46 (40) | 41 (25) |
| Opponent | Holder | 40 | 76 (40) | 23 | 52 | 18 | 48% | 3.2 | 13 (10) | 135 (18) | 27 (12) | 66 (23) | 91 (17) |
| Opponent | Shooter | 30 | 82 (30) | 38 | 43 | 27 | 3% | 1.5 | 77 (7) | 83 (18) | 82 (5) | 85 (16) | 77 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 29 (13) | 29 | 0 | 60 | 0% | 1.2 | 0 (5) | 31 (5) | 77 (3) | 58 (3) | 21 (10) |
| Opponent | Wizard | 22 | 26 (22) | 26 | 0 | 8 | 9% | 2.1 | 32 (13) | 40 (5) | 0 (3) | 47 (11) | 0 (10) |

### Charged fights: hc-opp-31c41bf-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 149 | 8 | 1.2 | 1.3 | 7 | 14 | -8 | 2 of 6 | 3 of 6 | +40 | -17 |
| Mine | Chaos Dwarfs | 3 | 148 | 874 | 4.3 | 1.3 | 202 | 68 | +133 | 6 of 13 | 11 of 13 | +122 | +137 |
| Mine | Dwarfen Mountain Holds | 4 | 154 | 110 | 1.8 | 1.3 | 63 | 69 | -6 | 4 of 7 | 2 of 7 | +10 | -12 |
| Mine | Empire of Man | 5 | 395 | 142 | 1.8 | 1.2 | 79 | 42 | +37 | 0 of 9 | 8 of 9 | +152 | +4 |
| Mine | Grand Cathay | 4 | 691 | 328 | 3.0 | 1.2 | 109 | 98 | +11 | 7 of 12 | 8 of 12 | +273 | -76 |
| Mine | High Elf Realms | 4 | 169 | 637 | 3.8 | 1.2 | 170 | 41 | +129 | 5 of 15 | 13 of 15 | +48 | +150 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 568 | 4.0 | 1.0 | 142 | 0 | +142 | 3 of 4 | 3 of 4 | - | +142 |
| Mine | Lizardmen | 1 | 0 | 390 | 4.0 | 1.0 | 98 | 35 | +62 | 4 of 4 | 3 of 4 | - | +62 |
| Mine | Ogre Kingdoms | 1 | 0 | 70 | 3.0 | 1.0 | 23 | 0 | +23 | 2 of 3 | 2 of 3 | - | +23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 66 | 4.0 | 1.0 | 16 | 28 | -11 | 3 of 4 | 2 of 4 | - | -11 |
| Mine | Skaven | 2 | 0 | 38 | 1.5 | 1.0 | 25 | 0 | +25 | 0 of 3 | 2 of 3 | - | +25 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 988 | 3.0 | 1.0 | 329 | 32 | +297 | 2 of 6 | 4 of 6 | - | +297 |
| Mine | Vampire Counts | 2 | 0 | 0 | 3.0 | 1.0 | 0 | 97 | -97 | 3 of 6 | 4 of 6 | - | -97 |
| Mine | Warriors of Chaos | 1 | 0 | 160 | 2.0 | 1.0 | 80 | 0 | +80 | 2 of 2 | 2 of 2 | - | +80 |
| **Mine** | all armies | 36 | 201 | 305 | 2.6 | 1.2 | 117 | 49 | +67 | 43 of 94 | 67 of 94 | +121 | +58 |
| Opponent | Beastmen Brayherds | 1 | 0 | 979 | 4.0 | 1.0 | 245 | 21 | +224 | 2 of 4 | 2 of 4 | - | +224 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 0 of 2 | 1 of 2 | - | +56 |
| Opponent | Empire of Man | 1 | 255 | 0 | 2.0 | 1.0 | 0 | 132 | -132 | 1 of 2 | 1 of 2 | - | -132 |
| Opponent | Grand Cathay | 1 | 340 | 313 | 2.0 | 1.5 | 156 | 0 | +156 | 1 of 2 | 1 of 2 | +313 | +0 |
| Opponent | High Elf Realms | 2 | 114 | 184 | 0.5 | 1.0 | 369 | 0 | +369 | 1 of 1 | 1 of 1 | - | +369 |
| Opponent | Lizardmen | 1 | 125 | 189 | 2.0 | 1.0 | 94 | 0 | +94 | 2 of 2 | 1 of 2 | - | +94 |
| Opponent | Ogre Kingdoms | 2 | 68 | 42 | 2.0 | 1.0 | 21 | 17 | +4 | 1 of 4 | 1 of 4 | - | +4 |
| Opponent | Orc & Goblin Tribes | 2 | 264 | 535 | 2.0 | 1.0 | 268 | 0 | +268 | 2 of 4 | 3 of 4 | - | +268 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 127 | 910 | 5.2 | 1.2 | 173 | 54 | +120 | 10 of 21 | 15 of 21 | +530 | +23 |
| Opponent | Vampire Counts | 6 | 37 | 353 | 4.7 | 1.2 | 76 | 42 | +34 | 11 of 28 | 19 of 28 | +101 | +19 |
| Opponent | Warriors of Chaos | 7 | 0 | 457 | 1.4 | 1.0 | 320 | 14 | +305 | 7 of 10 | 7 of 10 | - | +305 |
| Opponent | Wood Elf Realms | 6 | 107 | 483 | 4.3 | 1.2 | 111 | 9 | +102 | 7 of 26 | 18 of 26 | +287 | +58 |
| **Opponent** | all armies | 36 | 83 | 416 | 2.9 | 1.2 | 141 | 29 | +112 | 45 of 106 | 70 of 106 | +291 | +82 |

### Effective charges: hc-opp-31c41bf-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 1 (net +0) | 1 (net -85) | 1 (net +0) | 1 (net +40) | 1 (net +0) | 1 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 13 | 1 (net +506) | 0 | 1 (net +95) | 4 (net +167) | 2 (net -87) | 5 (net +128) | 0 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 7 | 2 (net +190) | 0 | 1 (net -360) | 1 (net -120) | 0 | 2 (net +30) | 1 | 17% (1 of 6) |
| Mine | Empire of Man | 9 | 1 (net -380) | 0 | 1 (net +234) | 2 (net +83) | 2 (net +35) | 3 (net +80) | 0 | 11% (1 of 9) |
| Mine | Grand Cathay | 12 | 3 (net -215) | 0 | 1 (net -532) | 4 (net +179) | 0 | 3 (net +168) | 1 | 9% (1 of 11) |
| Mine | High Elf Realms | 15 | 2 (net -79) | 0 | 3 (net +304) | 3 (net +28) | 1 (net +0) | 2 (net +344) | 4 | 27% (3 of 11) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +268) | 0 | 1 (net +300) | 1 (net +0) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +0) | 1 (net +195) | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 3 | 0% (0 of 1) |
| Mine | Skaven | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +38) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 6 | 1 (net +0) | 0 | 2 (net +526) | 1 (net +286) | 0 | 2 (net +222) | 0 | 33% (2 of 6) |
| Mine | Vampire Counts | 6 | 4 (net -145) | 0 | 0 | 2 (net +0) | 0 | 0 | 0 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +160) | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 4 | 1 (net -85) | 0 | 2 (net +104) | 1 (net +772) | 0 | 0 | 0 | 50% (2 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 1 (net +313) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 1 (net +369) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Lizardmen | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 4 | 2 (net +26) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 4 | 1 (net +583) | 0 | 0 | 0 | 0 | 1 (net +177) | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 21 | 1 (net -195) | 3 (net -14) | 7 (net +98) | 5 (net +130) | 1 (net +1214) | 4 (net +50) | 0 | 33% (7 of 21) |
| Opponent | Vampire Counts | 28 | 9 (net -17) | 0 | 5 (net +102) | 2 (net -116) | 4 (net +118) | 5 (net +69) | 3 | 20% (5 of 25) |
| Opponent | Warriors of Chaos | 10 | 1 (net +240) | 0 | 2 (net +640) | 1 (net +165) | 0 | 3 (net +127) | 3 | 29% (2 of 7) |
| Opponent | Wood Elf Realms | 26 | 3 (net +134) | 0 | 7 (net +188) | 8 (net +53) | 2 (net +98) | 4 (net +79) | 2 | 29% (7 of 24) |

### Charged fights, damage counted: hc-opp-31c41bf-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 270 | 270 | -41 | 152 | 165 | -13 | -4.8 |
| Mine | 50-54% | 1 | 52 | 297 | +0 | 183 | 57 | +126 | +242.9 |
| Mine | Effective (55-75%) | 14 | 265 | 176 | +115 | 205 | 105 | +100 | +37.8 |
| Mine | 76-89% | 21 | 289 | 199 | +95 | 119 | 16 | +103 | +35.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 275 | 191 | +128 | 148 | 29 | +118 | +43.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 506 | 106 | +0 | 83 | 114 | -31 | -6.1 |
| Mine | No odds | 14 | 267 | 200 | +37 | 96 | 59 | +37 | +13.8 |
| Mine | All fights | 94 | 290 | 199 | +67 | 138 | 70 | +68 | +23.5 |
| Opponent | Long shot (under 50%) | 20 | 187 | 314 | +42 | 117 | 74 | +42 | +22.6 |
| Opponent | 50-54% | 3 | 337 | 403 | -14 | 166 | 180 | -14 | -4.1 |
| Opponent | Effective (55-75%) | 25 | 313 | 219 | +162 | 196 | 43 | +153 | +48.8 |
| Opponent | 76-89% | 19 | 225 | 165 | +113 | 163 | 72 | +91 | +40.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 250 | 164 | +85 | 114 | 22 | +91 | +36.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 534 | 134 | +269 | 297 | 24 | +273 | +51.1 |
| Opponent | No odds | 14 | 201 | 181 | +104 | 131 | 39 | +92 | +45.6 |
| Opponent | All fights | 106 | 263 | 212 | +112 | 158 | 53 | +106 | +40.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-opp-31c41bf-p1 | move | 324 | 72 (22%) | 49 (15%) | 47 (15%) | 205 (63%) |
| hc-opp-31c41bf-p1 | objective | 345 | 45 (13%) | 31 (9%) | 57 (17%) | 243 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

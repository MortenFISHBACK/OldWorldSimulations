# Doctrine scorecard: hc-mine-31c41bf-p2

### Scorecard: hc-mine-31c41bf-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 4 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 2 | 3 | 5 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 7 | 2 | 0 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 958 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 5 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 966 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 8 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 2 | 3 | 1 | 4 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 982 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 0 | 0 | 2 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 14 | 2 | 8 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 768 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 3 | 0 | 0 | 0 | 305 |
| L1135 | 1 | 1 | Mine | yes | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 4 | 3 | 1 | 2 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 5 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 7 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 3 | 1 | 1 | 1 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 710 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 4 | - | 4 | 5 | 0 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 3 | 3 | 3 | 1 | 1 | 0 | 0 | 562 |
| L2235 | 3 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 5 | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 5 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 8 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 27% | 1.6 | 2.8 | 2.3 | 1.4 | 0.1 | 0.0 | 0.0 | 326.7 |
| **Average** | | | Opponent | 27% | 2.9 | 2.5 | 2.4 | 1.8 | 0.3 | 0.0 | 0.0 | 191.3 |

### KPIs: hc-mine-31c41bf-p2

Rules off - Opponent only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (41 of 165) | 15% (26 of 174) | 20% (67 of 339) |
| Winner chose to follow up after the loser gave ground |  | 96% (47 of 49); on the table 96% | 100% (60 of 60); on the table 100% | 98% (107 of 109); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 71% (5 of 7); on the table 71% | 86% (12 of 14); on the table 86% | 81% (17 of 21); on the table 81% |
| Winner chose to pursue after the loser fled |  | 83% (29 of 35); on the table 91% | 78% (21 of 27); on the table 78% | 81% (50 of 62); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 89% (81 of 91); on the table 92% | 92% (93 of 101); on the table 92% | 91% (174 of 192); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 35% (118 of 342) | 35% (55 of 156) | 35% (173 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (118 of 246) | 48% (55 of 115) | 48% (173 of 361) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (14 of 24) | 53% (26 of 49) | 55% (40 of 73) |
| Points that never fought | lower | 42% (30096 of 71583) | 46% (32989 of 71989) | 44% (63085 of 143572) |
|   infantry points that never fought | lower | 46% (7447 of 16324) | 71% (9922 of 14029) | 57% (17369 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (162 of 284) | 59% (176 of 297) | 58% (338 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 80% (16 of 20); 1.2 uses a game | 67% (12 of 18); 1.2 uses a game | 74% (28 of 38); 1.2 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (10 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32543 of 60231) | 54% (34222 of 63281) | 54% (66765 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (29%) | 0.7 (26%) | 2.6 (28%) |
| MARCHED: its unit marched | 1.1 (17%) | 0.4 (15%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.1 (5%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.1 (18%) | 0.2 (6%) | 1.3 (14%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (21%) | 0.8 (29%) | 2.1 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.9 | 1.2 | 4.8 | 0.5 | 1.3 |
| not cast | 3.8 | 3.1 | 3.8 | 9.0 | 1.8 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (52%) | 0.4 (12%) | 2.6 (28%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.2 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.1 (5%) | 0.4 (10%) | 1.3 (14%) | 0.1 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (11%) | 0.4 (12%) | 0.4 (12%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.9 (24%) | 0.4 (12%) | 1.0 (25%) | 2.1 (23%) | 0.6 (30%) | 3.9 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.2 (5%) | 0.2 (6%) | 0.4 (4%) | 0.1 (8%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.3 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (54%) | 0.1 (5%) | 1.2 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 67% (10 of 15) | 52% (13 of 25) | 58% (23 of 40) |
| the unit moved after it | 80% (8 of 10) | 46% (6 of 13) | 61% (14 of 23) |
| it charged on its next turn | 10% (1 of 10) | 0% (0 of 13) | 4% (1 of 23) |
| the enemy charged it first | 20% (2 of 10) | 8% (1 of 13) | 13% (3 of 23) |
| it fought by the end of its next turn | 10% (1 of 10) | 0% (0 of 13) | 4% (1 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 30% (3 of 10) | 0% (0 of 13) | 13% (3 of 23) |
| none of these (no charge, no fight, no charge escaped) | 50% (5 of 10) | 92% (12 of 13) | 74% (17 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (565 of 847) | 54% (435 of 810) | 60% (1000 of 1657) |
|   cavalry | 64% (46 of 72) | 62% (108 of 175) | 62% (154 of 247) |
|   character | 53% (57 of 107) | 26% (28 of 107) | 40% (85 of 214) |
|   chariot | 58% (58 of 100) | 59% (29 of 49) | 58% (87 of 149) |
|   infantry | 56% (150 of 266) | 53% (167 of 314) | 55% (317 of 580) |
|   monster | 48% (21 of 44) | 39% (14 of 36) | 44% (35 of 80) |
|   war machine | 90% (233 of 258) | 69% (89 of 129) | 83% (322 of 387) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (28%) | 2.2 (22%) | 4.5 (25%) |
| CHARGED: it charged | 1.0 (12%) | 1.9 (18%) | 2.9 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (5%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.3 (17%) | 1.9 (18%) | 3.2 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (10%) | 0.5 (5%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 2.5 (24%) | 3.8 (21%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| OTHER BAR | 0.1 (1%) | 0.6 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.2 | 84% | 4.8 pts | 31 pts |
| character | 2.5 | 1.0 | 70% | 10.6 pts | 26 pts |
| chariot | 2.4 | 0.9 | 73% | 12.3 pts | 30 pts |
| infantry | 12.2 | 4.6 | 72% | 10.2 pts | 124 pts |
| monster | 1.1 | 0.3 | 76% | 11.4 pts | 13 pts |
| war machine | 8.9 | 7.9 | 57% | 27.9 pts | 250 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.3 | 4.6 |
| Charges that made contact a game | 2.6 | 3.8 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.62 declared, 0.38 contact (24 units) | 0.18 declared, 0.09 contact (11 units) | 0.49 declared, 0.29 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.56 declared, 0.44 contact (9 units) | 1.33 declared, 1.17 contact (12 units) | 1.00 declared, 0.86 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.33 contact (245 units) | 0.59 declared, 0.42 contact (290 units) | 0.55 declared, 0.38 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 67% (12 of 18) | 58% (7 of 12) | 59% (61 of 103) |
| Character in a unit | 75% (24 of 32) | 78% (14 of 18) | 67% (2 of 3) | 75% (40 of 53) |
| Character on its own | 78% (31 of 40) | 61% (22 of 36) | 29% (18 of 63) | 51% (71 of 139) |
| Chariot | 65% (11 of 17) | 77% (10 of 13) | - | 70% (21 of 30) |
| Infantry | 52% (49 of 94) | 62% (21 of 34) | 0% (0 of 3) | 53% (70 of 131) |
| Monster | 48% (14 of 29) | 67% (6 of 9) | - | 53% (20 of 38) |
| Monstrous | 43% (6 of 14) | 57% (8 of 14) | - | 50% (14 of 28) |
| War Machines | 68% (39 of 57) | 100% (2 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 31% (32 of 102) | 36% | 55% (12 of 22) | 67% (4 of 6); 2.8 uses a game | 50% (1 of 2); 0.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (2 of 2); on the table 100% | 53% (19 of 36) | 60% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 83% (19 of 23); on the table 91% | - | 66% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 93% (13 of 14); on the table 100% | 29% (14 of 48) | 51% | 53% (40 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 77% (10 of 13); on the table 77% | 45% (62 of 138) | 56% | 54% (29 of 54) | 71% (10 of 14); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (10 of 10); on the table 100% | 17% (3 of 18) | 28% | 48% (16 of 33) | 100% (3 of 3); 2.8 uses a game | 57% (8 of 14); 3.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 93% (13 of 14); on the table 93% | - | 40% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 46% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (13 of 13); on the table 100% | 0% (0 of 18) | 37% | 71% (20 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 67% (6 of 9); on the table 67% | 22% (4 of 18) | 40% | 56% (14 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 100% (6 of 6); on the table 100% | - | 40% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 100% (19 of 19); on the table 100% | 35% (23 of 66) | 33% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 77% (17 of 22); on the table 77% | 39% (7 of 18) | 43% | 58% (42 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 96% (27 of 28); on the table 96% | 38% (9 of 24) | 42% | 60% (47 of 78) | 43% (3 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hc-mine-31c41bf-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (38) | 43% (24) | 47% (62) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.39 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.08 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.31 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.25 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.11 | 0.56 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.03 | 5.53 | 11.56 |

### Quality by phase: hc-mine-31c41bf-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (61 of 122) | 45% (85 of 189) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (163 of 399) | 49% (124 of 252) |
| Strategy | Close-in objectives charged next turn | 12% (13 of 112) | 16% (44 of 274) |
| Strategy | Support requests answered (helper made contact too) | 55% (6 of 11) | 42% (13 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (10 of 22) | 86% (12 of 14) |
| Strategy | Joined characters whose unit fought | 49% (25 of 51) | 21% (8 of 39) |
| Strategy | Lone characters that fought | 70% (66 of 94) | 74% (62 of 84) |
| Movement | Charges halted short of contact | 0.3 | 0.1 |
| Movement | Idle units | 1.4 | 1.8 |
| Movement | Points that never moved of their own | 326.7 | 191.3 |
| Movement | Fights charged into per game | 2.2 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 74, net +134 | 20 of 104, net +84 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 74, net +22 | 21 of 104, net +194 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 74, net +95 | 6 of 104, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 74, net +96 | 22 of 104, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 10.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (152 of 361) | 46% (172 of 374) |
| Shooting | Points destroyed by shooting units | 145.9 | 33.1 |
| Shooting | War machine shots | 6.5 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (123 of 233) | 47% (42 of 89) |
| Shooting | Points destroyed by war machines | 93.8 | 41.2 |
| Magic | Magic missiles cast | 2.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (25 of 73) | 43% (15 of 35) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.8 |
| Magic | Wounds caused by other spells | 1.6 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 70.8 | 19.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.8 / 0.6 / 0.1 | 1.9 / 0.4 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 219.4 | 400.0 |
| Combat | Points run down | 105.4 | 120.6 |
| Combat | Net points per charged fight, damage counted | +96 | +135 |
| Combat | Net per 100 charger points, damage counted | +39.8 | +52.7 |
| Combat | First round won (charged fights) | 72% | 78% |
| Combat | Net points per charged fight | +88 | +140 |
| Combat | Net points per supported fight / lone fight | +72 / +90 | +219 / +125 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 81 | 43 of 116 |
| Game | Points lost | 763.7 | 711.4 |
| Game | VP from objectives | 518.9 | 695.6 |
| Game | Lone holders (player turns) | 1.6 | 2.9 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -227 VP
- The side that went first won 14 of 29 games with a winner
- Points traded per game (both sides' losses): 1475
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-mine-31c41bf-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.7 | -163.8 | 278.4 | 115.5 | 4.4 | -138.2 | 153.1 | 74.3 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 25.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.2 | 0.0 | 0.0 | 0.8 | +6.4 | 0.0 | 31.1 |
| BEST FACING | 0.6 | +20.7 | 0.0 | 16.0 | 0.3 | +8.4 | 0.0 | 27.8 |
| BEST FIRST | 1.8 | +67.8 | 42.4 | 49.8 | 1.0 | +36.0 | 22.8 | 26.6 |
| BEST OVERALL | 0.4 | +15.3 | 0.0 | 20.5 | 0.3 | +15.7 | 0.0 | 33.6 |
| BEST PREY | 1.0 | +57.5 | 32.7 | 4.7 | 0.8 | +40.3 | 28.9 | 1.1 |
| BEST PRIZE | 0.1 | -22.9 | 7.1 | 0.0 | 0.1 | +2.8 | 11.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -1.4 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 12.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +8.8 | 0.0 | 9.0 | 0.6 | +7.4 | 0.0 | 5.2 |
| BLOWS WHERE AIMED | 0.3 | -5.9 | 60.5 | 6.2 | 0.3 | -54.4 | 22.6 | 11.4 |
| BOMBING RUN | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 18.6 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 139.7 | 19.6 | 0.3 | +0.0 | 26.0 | 9.2 |
| CANNON PLANNED TARGET | 5.0 | +174.1 | 549.2 | 95.7 | 2.0 | +101.6 | 95.1 | 8.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 4.2 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 11.3 | 0.0 | 0.3 | -3.5 | 36.1 | 15.4 |
| CAST JOB | 0.8 | +17.5 | 26.3 | 13.4 | 0.5 | +7.2 | 15.9 | 36.1 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +27.8 | 31.0 | 9.6 | 0.2 | +8.7 | 25.8 | 4.4 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 34.7 | 0.4 | +0.0 | 0.0 | 12.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +3.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.9 | +44.2 | 0.0 | 23.0 | 1.6 | +74.2 | 0.0 | 26.9 |
| CHAFF PASSED | 0.2 | -0.4 | 0.0 | 4.6 | 0.2 | -0.2 | 0.0 | 6.1 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 123.1 | 50.3 | 2.6 | +0.0 | 290.5 | 78.7 |
| CHARGE NOW WEIGHED | 0.5 | -38.6 | 8.8 | 2.8 | 0.3 | -53.0 | 20.2 | 26.3 |
| CHARGER SLAIN LOST | 0.4 | -6.3 | 65.5 | 15.0 | 0.7 | -17.9 | 68.4 | 23.4 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 14.7 | 3.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 1.7 | 46.8 | 0.3 | +0.0 | 11.0 | 14.2 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +39.7 | 22.2 | 32.1 | 0.6 | +56.7 | 43.9 | 66.9 |
| COVER ONCE | 9.2 | -682.4 | 0.0 | 212.8 | 6.6 | -516.9 | 0.0 | 139.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.6 | 3.2 | 1.2 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +6.0 | 12.2 | 2.5 | 0.6 | +12.7 | 43.6 | 13.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +96.3 | 0.0 | 59.4 | 1.2 | +86.5 | 0.0 | 54.7 |
| FALLBACK BY WORTH | 3.8 | +27.2 | 0.0 | 31.8 | 5.5 | +43.2 | 0.0 | 56.4 |
| FIGHT LIFT | 0.1 | +0.3 | 2.9 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.2 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 127.7 | 5.1 | +0.0 | 0.0 | 168.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +1.0 | 2.4 | 0.0 |
| FOLLOW UP WEIGHED | 0.4 | +58.6 | 0.0 | 21.1 | 1.0 | +129.5 | 0.0 | 43.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +7.1 | 0.0 | 7.4 | 0.3 | +15.0 | 0.0 | 10.4 |
| GIVES UP | 0.1 | -0.7 | 0.0 | 20.9 | 0.2 | -2.0 | 26.2 | 5.6 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 5.4 | 3.2 | 0.0 | -0.0 | 3.4 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.3 | 0.8 |
| HELPER UNSEEN | 0.4 | +0.0 | 45.1 | 20.1 | 0.2 | +0.0 | 24.3 | 1.7 |
| HILL BY ITS CHANCE | 0.5 | -47.8 | 0.0 | 0.0 | 0.6 | -54.2 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.5 | -80.0 | 244.4 | 97.1 | 11.1 | -204.0 | 758.2 | 303.3 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 3.2 | 0.4 | +3.8 | 27.1 | 3.1 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 3.5 | 3.1 |
| HUNT IN PAIRS | 0.5 | +42.1 | 0.0 | 6.5 | 0.4 | +28.6 | 0.0 | 23.5 |
| HUNT KEPT | 0.0 | +0.4 | 5.4 | 3.2 | 0.2 | +5.5 | 14.0 | 0.9 |
| HUNT RESULT | 0.0 | +0.0 | 5.4 | 0.0 | 0.4 | +50.2 | 16.1 | 6.8 |
| HUNT THE GUNS | 0.0 | +6.5 | 0.0 | 3.2 | 0.4 | +141.8 | 24.2 | 5.8 |
| IDLE COST | 15.1 | -245.1 | 0.0 | 176.0 | 19.7 | -325.2 | 0.0 | 324.8 |
| INVITES THE FIGHT | 1.2 | +8.7 | 107.1 | 25.3 | 0.6 | +7.1 | 26.8 | 13.9 |
| JOINT CHARGE PLAN | 0.1 | +1.0 | 11.3 | 3.1 | 0.1 | +2.7 | 0.0 | 7.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -3.5 | 19.4 | 30.1 |
| KEEP FALLS | 0.1 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.3 | 7.9 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +31.7 | 130.6 | 10.2 | 2.4 | +71.7 | 197.4 | 88.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +86.0 | 62.7 | 69.8 | 2.1 | +96.1 | 164.8 | 46.6 |
| KILLS COUNT NEXT TURN | 2.5 | +115.7 | 72.8 | 35.9 | 7.8 | +269.2 | 443.9 | 240.7 |
| LONE CHARACTER SAFE SPOT | 0.3 | +14.4 | 7.4 | 11.1 | 0.2 | +5.8 | 15.4 | 10.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 1.7 | 5.3 | 0.2 | +0.0 | 1.7 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +4.1 | 11.6 | 21.4 | 0.9 | -1.9 | 41.6 | 12.7 |
| LOST CHARGE | 2.2 | -40.3 | 80.2 | 72.8 | 2.3 | -40.6 | 67.9 | 104.5 |
| LURE BY WHAT IT DRAWS | 0.2 | -16.3 | 0.0 | 4.7 | 0.2 | -27.8 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 0.3 | +19.1 | 4.3 | 3.1 | 0.8 | +29.8 | 15.3 | 17.2 |
| MANOEUVRE | 0.1 | +0.3 | 0.0 | 2.7 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 9.6 |
| MARCH CHECK | 0.6 | +15.5 | 0.0 | 0.0 | 0.5 | +23.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.5 | +35.5 | 6.0 | 0.0 | 0.2 | +17.4 | 16.6 | 10.2 |
| MARCH OVER CASTS | 0.5 | +41.0 | 0.0 | 15.0 | 0.2 | +8.1 | 0.0 | 12.6 |
| MAX FOR POSITIONING | 5.2 | +59.1 | 0.0 | 96.8 | 6.4 | +92.6 | 0.0 | 196.5 |
| MEASURED NEXT CHARGE | 8.5 | -185.9 | 127.5 | 174.0 | - | - | - | - |
| MISSILES IN THE MOVE | 4.1 | +106.4 | 0.0 | 101.6 | 3.0 | +54.4 | 0.0 | 93.6 |
| MISSILES NEXT TURN | 4.9 | +76.7 | 0.0 | 116.6 | 3.4 | +41.4 | 0.0 | 135.7 |
| MODEL FACING | 0.3 | +66.0 | 0.0 | 3.3 | 0.2 | +66.5 | 0.0 | 5.0 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 11.3 | 0.0 | 0.1 | +0.0 | 19.9 | 5.7 |
| MOVE AND CAST | 0.5 | +16.8 | 0.0 | 16.2 | 0.2 | +13.5 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.2 | +9.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -3.6 | 0.0 | 0.0 | 0.1 | -2.6 | 3.5 | 6.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 22.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 0.6 | +4.3 | 10.6 | 13.8 | 6.1 | +322.5 | 306.6 | 164.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +2.1 | 0.8 | 0.0 | 0.0 | +3.7 | 0.0 | 7.0 |
| NO RALLY LEFT | 0.0 | +1.2 | 0.0 | 4.2 | 0.0 | +5.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -5.2 | 11.4 | 0.8 | 0.2 | -10.0 | 37.1 | 4.2 |
| NOT TURNED | 6.0 | +79.3 | 0.0 | 129.2 | 5.5 | +37.2 | 0.0 | 117.9 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 0.0 | 0.8 | -0.7 | 0.0 | 9.8 |
| OFF BEST | 14.8 | -523.7 | 20.9 | 271.1 | 17.7 | -864.3 | 6.6 | 326.8 |
| ONE FIGHT FORMULA | 8.1 | -130.9 | 68.6 | 191.3 | 8.6 | -173.3 | 15.4 | 289.9 |
| ONE OBJECTIVE FORMULA | 2.1 | -118.0 | 0.0 | 28.0 | 2.2 | -166.8 | 0.0 | 20.0 |
| OPENS A LANE | 0.2 | +0.4 | 6.6 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +1.4 | 4.4 | 0.0 | 0.1 | +4.7 | 4.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +4.8 | 27.3 | 3.4 | 0.6 | +9.5 | 47.7 | 18.8 |
| PATHS CROSS | 1.9 | +107.8 | 0.0 | 48.1 | 3.2 | +176.0 | 0.0 | 78.1 |
| PERIAPT WORTH | 0.0 | +2.4 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.8 | +1559.1 | 1642.0 | 957.5 | 41.8 | +1320.2 | 1362.3 | 1044.1 |
| PURSUES BIG PREY | - | - | - | - | 0.2 | -5.1 | 0.0 | 13.9 |
| PURSUES ON | 0.1 | +3.0 | 0.0 | 6.2 | 0.0 | -0.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +14.8 | 0.0 | 14.6 | 1.4 | +11.3 | 0.0 | 60.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.3 | 10.0 | 4.7 | 0.2 | -12.2 | 20.2 | 13.5 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -12.9 | 0.0 | 13.9 | 0.9 | -24.5 | 0.0 | 17.7 |
| REDIRECT COUNTER | 2.4 | +163.6 | 0.0 | 45.6 | 3.6 | +260.1 | 0.0 | 65.3 |
| REDIRECT WEIGHED | 0.2 | -9.3 | 6.0 | 0.0 | 0.3 | +6.1 | 15.2 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 5.9 | 0.2 | +0.0 | 0.0 | 13.7 |
| RESERVE FALL BACK | 0.4 | +9.8 | 0.0 | 2.2 | 1.1 | +20.4 | 0.0 | 30.9 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +67.4 | 204.7 | 69.2 | 3.5 | +73.8 | 364.2 | 115.8 |
| RISK ONCE | 4.4 | +185.9 | 38.2 | 158.0 | 3.5 | +109.3 | 33.5 | 233.8 |
| RUN DOWN | 1.9 | -3.2 | 136.8 | 73.0 | - | - | - | - |
| SAFE SURE CHARGE | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | -1.7 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +55.9 | 0.0 | 25.0 | 0.6 | +32.2 | 0.0 | 37.2 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -13.2 | 0.0 | 2.5 | 0.7 | -51.0 | 0.0 | 6.8 |
| SEARCH SPOT | 2.0 | +70.3 | 0.0 | 16.9 | 2.1 | +67.0 | 0.0 | 34.4 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.7 | 3.1 | 1.8 |
| SELF MOVE SPELL | 0.2 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +24.7 | 35.2 | 7.8 | 2.0 | +116.7 | 41.9 | 94.6 |
| SET-UP ANY TARGET | 0.1 | +18.8 | 0.0 | 0.0 | 0.1 | +9.0 | 0.0 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.1 | +7.5 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 1.1 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +64.0 | 81.1 | 16.2 | 0.8 | +31.4 | 30.7 | 11.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 193.8 | 25.9 | 0.3 | +0.0 | 60.6 | 6.2 |
| SHOTS IN THE MOVE | 13.5 | +578.6 | 0.0 | 272.6 | 11.7 | +426.2 | 0.0 | 130.4 |
| SPELL SETS UP CHARGE | 0.2 | +36.1 | 11.1 | 11.1 | 0.2 | +27.8 | 22.3 | 29.9 |
| SPELL WORTH | 0.9 | +15.9 | 65.6 | 59.4 | 1.6 | +21.3 | 61.9 | 61.9 |
| SPELLS IN THE FIGHT | 0.5 | +6.2 | 73.1 | 14.1 | 0.7 | -12.1 | 78.5 | 13.0 |
| STABLE ROLE | 11.2 | +0.0 | 422.0 | 165.8 | 12.5 | +0.0 | 322.6 | 127.8 |
| STANDS TO CAST | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +4.1 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +5.1 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.4 | 5.4 | 3.2 | 0.2 | +11.8 | 11.1 | 3.7 |
| STOPS SHORT OF THE FLANK | 0.4 | +12.4 | 0.0 | 9.6 | 0.2 | +11.3 | 0.0 | 18.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.9 | -67.7 | 341.5 | 102.0 | 7.7 | -63.5 | 370.4 | 75.1 |
| SUPPORTS | 4.9 | +67.8 | 204.8 | 43.2 | 5.1 | +67.9 | 181.7 | 43.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.3 | 0.0 | 0.0 | 0.2 | -8.1 | 26.8 | 0.0 |
| SURE REACH TOGETHER | 0.2 | -0.1 | 0.0 | 0.0 | 0.7 | -1.0 | 11.9 | 13.4 |
| THROUGH LINE OF FIRE | 0.3 | +5.4 | 0.0 | 5.3 | 0.4 | +6.8 | 0.0 | 3.5 |
| TURN WORTH | 0.2 | -14.8 | 23.8 | 9.6 | 0.3 | -14.5 | 18.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +2.1 | 8.2 | 3.1 | 0.3 | +1.4 | 0.0 | 7.6 |
| WAIT AFTER COSTS | 3.1 | -150.8 | 169.5 | 51.9 | 9.4 | -463.7 | 498.9 | 228.8 |
| WALKS TO THE FIGHT | 1.6 | +16.5 | 61.6 | 34.2 | 1.6 | +9.9 | 66.4 | 23.6 |
| WAR ENGINE CHARGES | 0.1 | +11.4 | 6.6 | 4.2 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 27.7 | 14.6 | 0.3 | +0.0 | 33.8 | 9.3 |
| WEARS DOWN | 1.1 | +38.0 | 131.3 | 4.6 | 1.7 | +44.6 | 217.3 | 70.7 |
| WHO HITS BACK | 0.2 | +12.4 | 0.0 | 8.0 | 0.2 | +15.5 | 0.0 | 17.7 |
| WHOLE FIGHT | 0.3 | +4.6 | 32.4 | 8.4 | 0.4 | +12.1 | 95.6 | 6.9 |
| WHOLE FIGHT GAIN | 0.2 | +17.1 | 17.1 | 8.2 | 0.9 | +70.5 | 59.0 | 12.2 |
| WIDER SPREAD | 2.3 | -4.5 | 215.3 | 80.8 | 3.3 | -1.9 | 342.7 | 84.6 |

### Rule changes: hc-mine-31c41bf-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1171 | 1171 | 1171 | 32.53 | -49964 | -42.7 |
| PATHS CROSS | 183 | 183 | 183 | 5.08 | +10215 | +55.8 |
| SUPPORTS | 359 | 359 | 168 | 4.67 | +1864 | +11.1 |
| SEARCH SPOT | 149 | 149 | 147 | 4.08 | +4941 | +33.6 |
| MOVE TO CHARGE | 240 | 240 | 130 | 3.61 | +3940 | +30.3 |
| KILLS COUNT NEXT TURN | 371 | 371 | 125 | 3.47 | +3624 | +29.0 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +6580 | +56.2 |
| BEST FIRST | 99 | 99 | 99 | 2.75 | +3735 | +37.7 |
| COVER ONCE | 569 | 349 | 89 | 2.47 | +1308 | +14.7 |
| SHOTS IN THE MOVE | 908 | 626 | 88 | 2.44 | +2564 | +29.1 |
| WAIT AFTER COSTS | 450 | 450 | 79 | 2.19 | +1563 | +19.8 |
| ADVANCE WORTH | 361 | 361 | 72 | 2.00 | +1388 | +19.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FALLBACK BY WORTH | 335 | 335 | 69 | 1.92 | +2534 | +36.7 |
| ONE FIGHT FORMULA | 601 | 360 | 68 | 1.89 | +295 | +4.3 |
| RISK ONCE | 283 | 202 | 61 | 1.69 | +1860 | +30.5 |
| SAFER THAN THE JOB | 60 | 60 | 60 | 1.67 | +3170 | +52.8 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| RESERVE FALL BACK | 55 | 55 | 55 | 1.53 | +1089 | +19.8 |
| IDLE COST | 1253 | 723 | 54 | 1.50 | +598 | +11.1 |
| CHAFF IN THE MOVE | 89 | 83 | 52 | 1.44 | +1121 | +21.6 |
| FOLLOW UP WEIGHED | 50 | 50 | 50 | 1.39 | +6768 | +135.4 |
| MISSILES IN THE MOVE | 254 | 174 | 50 | 1.39 | +1363 | +27.3 |
| WALKS TO THE FIGHT | 117 | 117 | 50 | 1.39 | +316 | +6.3 |
| MAX FOR POSITIONING | 419 | 267 | 48 | 1.33 | +153 | +3.2 |
| MEASURED NEXT CHARGE | 305 | 216 | 48 | 1.33 | +571 | +11.9 |
| RISK BY ARC | 206 | 200 | 45 | 1.25 | +1179 | +26.2 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SHOT REPLANNED | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SET UP TOGETHER | 92 | 76 | 41 | 1.14 | +2124 | +51.8 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 73 | 73 | 40 | 1.11 | +942 | +23.6 |
| CANNON PLANNED TARGET | 251 | 251 | 38 | 1.06 | +199 | +5.2 |
| KILLS COUNT | 130 | 130 | 38 | 1.06 | +1465 | +38.5 |
| MARCH CHECK | 39 | 37 | 37 | 1.03 | +1973 | +53.3 |
| REDIRECT COUNTER | 215 | 107 | 37 | 1.03 | +2514 | +67.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| BLOCKED WHEEL | 32 | 32 | 32 | 0.89 | +581 | +18.1 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| BEST FACING | 31 | 31 | 31 | 0.86 | +1046 | +33.8 |
| CHARGE NOW FIRST | 157 | 157 | 31 | 0.86 | -1285 | -41.5 |
| HONEST WORTH | 560 | 556 | 31 | 0.86 | +225 | +7.3 |
| BEST PREY | 63 | 63 | 28 | 0.78 | +947 | +33.8 |
| CHARGE NOW WEIGHED | 28 | 28 | 28 | 0.78 | +2986 | +106.6 |
| SHOOTS FROM THE BEST SPOT | 88 | 88 | 28 | 0.78 | +927 | +33.1 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1093 | +40.5 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MARCH ODDS | 26 | 26 | 26 | 0.72 | +274 | +10.5 |
| INVITES THE FIGHT | 64 | 64 | 25 | 0.69 | +206 | +8.3 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| THROUGH LINE OF FIRE | 25 | 25 | 25 | 0.69 | +436 | +17.4 |
| BEST OVERALL | 24 | 24 | 24 | 0.67 | +1115 | +46.5 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 0.58 | +852 | +40.6 |
| WHOLE FIGHT GAIN | 37 | 35 | 21 | 0.58 | +698 | +33.2 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +797 | +42.0 |
| WEARS DOWN | 101 | 95 | 19 | 0.53 | +489 | +25.7 |
| CASTING BLOCK | 25 | 25 | 18 | 0.50 | +637 | +35.4 |
| MODEL FACING | 18 | 18 | 18 | 0.50 | +4771 | +265.0 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | -186 | -10.3 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +641 | +37.7 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CAST JOB | 46 | 46 | 15 | 0.42 | +245 | +16.4 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MAKE SURE TOGETHER | 41 | 28 | 15 | 0.42 | +648 | +43.2 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -55 | -3.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -24 | -2.0 |
| HUNT IN PAIRS | 33 | 25 | 12 | 0.33 | +964 | +80.3 |
| REFUSING RETIRES | 22 | 22 | 12 | 0.33 | -5 | -0.4 |
| WAR ENGINE JOBS | 27 | 27 | 12 | 0.33 | -500 | -41.7 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| BEST PRIZE | 10 | 10 | 10 | 0.28 | -1078 | -107.8 |
| KEEPS ITS TARGET | 124 | 123 | 10 | 0.28 | +185 | +18.5 |
| MISSILES NEXT TURN | 301 | 196 | 9 | 0.25 | +51 | +5.6 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -302 | -33.5 |
| SUPPORT NARROWED | 526 | 526 | 8 | 0.22 | -166 | -20.8 |
| LOST CHARGE | 163 | 163 | 6 | 0.17 | +78 | +13.0 |
| MANOEUVRE | 10 | 10 | 6 | 0.17 | +42 | +7.0 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -184 | -30.7 |
| WHOLE FIGHT | 24 | 24 | 6 | 0.17 | +257 | +42.8 |
| WIDER SPREAD | 204 | 198 | 6 | 0.17 | +8 | +1.4 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| ONE OBJECTIVE FORMULA | 153 | 79 | 5 | 0.14 | +44 | +8.9 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -121 | -24.1 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +107 | +21.4 |
| CATCH ODDS | 4 | 4 | 4 | 0.11 | -71 | -17.8 |
| CONTINUE AHEAD WEIGHED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| HUNT ADVANCE | 16 | 16 | 4 | 0.11 | +36 | +9.0 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| OVERRUNS AWAY | 35 | 35 | 4 | 0.11 | +51 | +12.8 |
| SURE REACH TOGETHER | 32 | 24 | 4 | 0.11 | +2 | +0.6 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +122 | +40.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +142 | +47.2 |
| PURSUES ON | 3 | 3 | 3 | 0.08 | +103 | +34.5 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +237 | +79.0 |
| SPELLS IN THE FIGHT | 42 | 40 | 3 | 0.08 | +65 | +21.6 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -60 | -20.1 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +254 | +84.8 |
| STOPS | 10 | 10 | 3 | 0.08 | +74 | +24.6 |
| DEFENSIVE ARMY | 7 | 7 | 2 | 0.06 | -84 | -42.0 |
| EDGE GIVE GROUND | 26 | 25 | 2 | 0.06 | +38 | +18.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +13 | +6.5 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +87 | +43.5 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 2 | 0.06 | -49 | -24.5 |
| MOVE SPELL IN RANGE | 8 | 7 | 2 | 0.06 | +29 | +14.5 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +180 | +90.1 |
| OPENS UP | 6 | 6 | 2 | 0.06 | +23 | +11.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +209 | +104.6 |
| RUN DOWN | 68 | 68 | 2 | 0.06 | +3 | +1.6 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -69 | -34.6 |
| TWO OR MORE ARRIVE | 19 | 18 | 2 | 0.06 | +16 | +8.2 |
| BACKUP TARGETS | 35 | 16 | 1 | 0.03 | +14 | +14.1 |
| BLOWS WHERE AIMED | 21 | 17 | 1 | 0.03 | +3 | +3.2 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -125 | -125.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +38 | +37.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| LONG SHOT | 50 | 49 | 1 | 0.03 | +6 | +5.7 |
| REDIRECT BY WHAT IT STOPS | 50 | 50 | 1 | 0.03 | +4 | +3.6 |
| TURN WORTH | 20 | 19 | 1 | 0.03 | +3 | +3.0 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +148 | +147.5 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 44 | 44 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 41 | 38 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 390 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 37 | 37 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 15 | 15 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 416 | 416 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2830 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 33 | 33 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STABLE ROLE | 852 | 851 | 0 | 0.00 | - | - |

### Off best figure: hc-mine-31c41bf-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.50 | 15.89 | 43.6 |
| FALLBACK | gate | 0.47 | 0.83 | 29.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.50 | 42.8 |
| TURN GATE | gate | 0.44 | 0.36 | 47.8 |
| AFTERMATH BAND | gate | 0.14 | 0.28 | 2.3 |
| WAR ENGINE JOBS | rule | 0.17 | 0.14 | 45.5 |
| BEST PRIZE | rule | 0.14 | 0.14 | 107.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.19 | 33.5 |
| SUPPORT NARROWED | rule | 0.17 | 0.06 | 20.8 |
| SUPPORT REQUEST | gate | 0.06 | 0.14 | 76.6 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.03 | 13.6 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 6.5 |
| PURSUES BIG PREY | rule | - | 0.17 | 30.7 |
| REDIRECT WEIGHED | rule | 0.08 | 0.08 | 91.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 69.0 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 4.7 |
| PIVOT GUARDS FLANK | rule | 0.14 | - | 24.1 |
| CATCH ODDS | rule | 0.03 | 0.08 | 17.8 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.08 | 43.7 |
| FACES THE THREAT | rule | 0.11 | - | 13.6 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | 0.06 | 2.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 19.1 |
| PATHS CROSS | rule | 0.06 | 0.06 | 28.8 |
| REFUSING RETIRES | rule | 0.11 | - | 0.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.08 | 6.3 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.6 |
| DEFENSIVE ARMY | rule | - | 0.06 | 42.0 |
| NO REASON | gate | 0.06 | - | 31.6 |
| SAFE SURE CHARGE | rule | 0.03 | 0.03 | 34.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 13.8 |
| BLOCKED WHEEL | rule | - | 0.03 | 7.2 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 125.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 48.9 |
| MARCH ODDS | rule | - | 0.03 | 2.7 |
| PURSUES ON | rule | - | 0.03 | 4.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 16.4 |
| STANDS TO CAST | rule | - | 0.03 | 71.8 |

### Plans: hc-mine-31c41bf-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.2 | 17% | 234 | 313 | 134% |
| Mine | charge | 2.9 | 47% | 245 | 213 | 87% |
| Mine | close in | 3.1 | 22% | 86 | 113 | 132% |
| Mine | hold | 5.1 | 28% | 312 | 0 | 0% |
| Mine | join | 0.7 | 92% | 18 | 0 | 0% |
| Mine | shoot | 9.1 | 68% | 270 | 921 | 341% |
| Mine | support | 5.7 | 94% | 42 | 0 | 0% |
| Opponent | advance | 12.3 | 18% | 158 | 383 | 242% |
| Opponent | charge | 4.6 | 57% | 380 | 439 | 115% |
| Opponent | close in | 7.6 | 28% | 424 | 218 | 51% |
| Opponent | hold | 4.8 | 46% | 341 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 38 | 0 | 0% |
| Opponent | shoot | 5.4 | 51% | 208 | 281 | 135% |
| Opponent | support | 6.5 | 90% | 58 | 0 | 0% |

### Packages: hunt the guns, hc-mine-31c41bf-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 41 |
| Opponent | 0.4 | 16 | 0 | 19% | 50% | 0% | 2.8 | 319 | 113 | 38% | 117 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 198 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 232 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 40% | 60% | 0% | 2.7 | 473 | 191 | 20% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 312 |
| Tomb Kings of Khemri | 1.4 | 7 | 0 | 14% | 71% | 0% | 2.8 | 182 | 122 | 71% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 5 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 452 | 0 | 0% | 0 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 322 | 0 | 0% | 103 |

### Battle groups: hc-mine-31c41bf-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 34% | 43% | 3% | 0% | 7% | 0% | 14% | 76% | 3% |
| Opponent | REDIRECT COUNTER | 3.6 | 27% | 57% | 11% | 0% | 26% | 10% | 10% | 48% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-mine-31c41bf-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 100 | 20% | 3.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 34 | 41 (34) | 4 | 37 | 65 | 32% | 2.5 | 45 (19) | 74 (7) | 5 (8) | 57 (23) | 5 (11) |
| Mine | Character | 123 | 46 (123) | 46 | 0 | 31 | 21% | 2.5 | 42 (39) | 57 (52) | 9 (14) | 57 (48) | 38 (57) |
| Mine | Clean-up | 21 | 40 (21) | 5 | 35 | 69 | 48% | 2.9 | 15 (5) | 44 (13) | 87 (3) | 78 (13) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 61 (48) | 41 | 20 | 48 | 31% | 2.9 | 69 (23) | 33 (16) | 83 (9) | 77 (29) | 36 (19) |
| Mine | Fragile | 5 | 52 (5) | 52 | 0 | 40 | 0% | 2.8 | - | 87 (3) | 0 (2) | 52 (5) | - |
| Mine | Hammer | 57 | 35 (57) | 25 | 10 | 40 | 16% | 2.6 | 26 (18) | 43 (29) | 27 (10) | 34 (38) | 35 (19) |
| Mine | Holder | 28 | 29 (28) | 8 | 21 | 30 | 57% | 3.0 | 21 (11) | 49 (9) | 10 (8) | 39 (19) | 6 (9) |
| Mine | Shooter | 41 | 97 (41) | 43 | 54 | 40 | 5% | 1.4 | 81 (5) | 107 (30) | 60 (6) | 125 (25) | 53 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 59 | 59 (59) | 59 | 0 | 49 | 2% | 1.2 | 0 (10) | 80 (37) | 30 (12) | 11 (10) | 68 (49) |
| Mine | Wizard | 22 | 11 (22) | 11 | 0 | 60 | 14% | 2.7 | 10 (5) | 28 (6) | 10 (5) | 25 (3) | 14 (13) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 50% | 6.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 55 (76) | 26 | 28 | 46 | 36% | 2.4 | 68 (32) | 25 (19) | 67 (25) | 66 (54) | 29 (22) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 41 | 24% | 2.6 | 89 (42) | 38 (40) | 15 (7) | 54 (62) | 77 (27) |
| Opponent | Clean-up | 19 | 21 (19) | 7 | 14 | 28 | 47% | 2.7 | 0 (9) | 55 (10) | - | 28 (14) | 0 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 46 (48) | 35 | 11 | 40 | 25% | 2.7 | 60 (22) | 30 (16) | 44 (10) | 47 (28) | 45 (20) |
| Opponent | Fragile | 5 | 44 (5) | 44 | 0 | 46 | 40% | 2.0 | - | 57 (4) | 0 (1) | 67 (3) | 0 (2) |
| Opponent | Hammer | 70 | 30 (70) | 25 | 5 | 45 | 34% | 2.8 | 13 (17) | 27 (42) | 74 (11) | 25 (43) | 37 (27) |
| Opponent | Holder | 35 | 106 (35) | 10 | 96 | 13 | 34% | 3.3 | 89 (5) | 124 (23) | 52 (7) | 123 (25) | 59 (10) |
| Opponent | Shooter | 33 | 88 (33) | 18 | 71 | 16 | 6% | 1.7 | 142 (8) | 86 (19) | 31 (6) | 130 (22) | 25 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | War machine | 24 | 52 (24) | 52 | 0 | 18 | 8% | 1.5 | 50 (6) | 59 (14) | 33 (4) | 38 (3) | 54 (21) |
| Opponent | Wizard | 26 | 4 (26) | 4 | 0 | 51 | 8% | 1.5 | 0 (10) | 0 (6) | 14 (6) | 8 (8) | 2 (14) |

### Charged fights: hc-mine-31c41bf-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 108 | 242 | 1.5 | 1.2 | 162 | 0 | +162 | 2 of 6 | 6 of 6 | +120 | +170 |
| Mine | Chaos Dwarfs | 4 | 411 | 104 | 1.2 | 1.6 | 83 | 0 | +83 | 3 of 5 | 3 of 5 | +0 | +139 |
| Mine | Dwarfen Mountain Holds | 4 | 710 | 70 | 2.8 | 1.3 | 25 | 11 | +14 | 3 of 11 | 8 of 11 | +0 | +20 |
| Mine | Empire of Man | 5 | 734 | 71 | 0.8 | 1.0 | 89 | 0 | +89 | 2 of 4 | 3 of 4 | - | +89 |
| Mine | Grand Cathay | 4 | 145 | 598 | 3.0 | 1.0 | 199 | 12 | +187 | 4 of 12 | 8 of 12 | - | +187 |
| Mine | High Elf Realms | 4 | 100 | 327 | 2.2 | 1.1 | 145 | 29 | +117 | 5 of 9 | 7 of 9 | +0 | +131 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 869 | 3.0 | 1.3 | 290 | 0 | +290 | 1 of 3 | 3 of 3 | +664 | +102 |
| Mine | Lizardmen | 1 | 285 | 1234 | 3.0 | 1.0 | 411 | 0 | +411 | 1 of 3 | 2 of 3 | - | +411 |
| Mine | Ogre Kingdoms | 1 | 306 | 0 | 3.0 | 1.3 | 0 | 41 | -41 | 0 of 3 | 2 of 3 | -34 | -45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 349 | 5.0 | 1.2 | 70 | 11 | +59 | 1 of 5 | 4 of 5 | +45 | +62 |
| Mine | Skaven | 2 | 341 | 73 | 3.0 | 1.0 | 24 | 102 | -78 | 2 of 6 | 5 of 6 | - | -78 |
| Mine | Tomb Kings of Khemri | 1 | 102 | 485 | 4.0 | 1.0 | 121 | 156 | -35 | 2 of 4 | 2 of 4 | - | -35 |
| Mine | Vampire Counts | 3 | 81 | 160 | 2.7 | 1.1 | 60 | 131 | -71 | 5 of 8 | 3 of 8 | +0 | -81 |
| Mine | Warriors of Chaos | 1 | 0 | 806 | 2.0 | 1.0 | 403 | 0 | +403 | 0 of 2 | 2 of 2 | - | +403 |
| **Mine** | all armies | 36 | 311 | 280 | 2.2 | 1.1 | 125 | 37 | +88 | 31 of 81 | 58 of 81 | +72 | +90 |
| Opponent | Dwarfen Mountain Holds | 2 | 94 | 116 | 4.0 | 1.6 | 29 | 13 | +16 | 1 of 8 | 5 of 8 | +38 | -6 |
| Opponent | Empire of Man | 2 | 395 | 100 | 1.0 | 1.0 | 100 | 0 | +100 | 0 of 2 | 2 of 2 | - | +100 |
| Opponent | Grand Cathay | 2 | 510 | 564 | 2.0 | 1.2 | 282 | 0 | +282 | 2 of 4 | 4 of 4 | +562 | +189 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 0 | 281 | 5.3 | 1.2 | 53 | 29 | +23 | 3 of 16 | 10 of 16 | -36 | +37 |
| Opponent | Skaven | 1 | 45 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 148 | 840 | 4.0 | 1.1 | 210 | 62 | +149 | 7 of 16 | 12 of 16 | +450 | +129 |
| Opponent | Vampire Counts | 6 | 6 | 777 | 2.7 | 1.1 | 291 | 15 | +276 | 8 of 16 | 15 of 16 | +748 | +209 |
| Opponent | Warriors of Chaos | 8 | 0 | 393 | 2.6 | 1.2 | 150 | 1 | +148 | 12 of 21 | 16 of 21 | +208 | +130 |
| Opponent | Wood Elf Realms | 7 | 85 | 667 | 4.3 | 1.1 | 156 | 8 | +148 | 9 of 30 | 24 of 30 | +189 | +143 |
| **Opponent** | all armies | 36 | 94 | 510 | 3.2 | 1.2 | 158 | 18 | +140 | 43 of 116 | 90 of 116 | +219 | +125 |

### Effective charges: hc-mine-31c41bf-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 1 (net +511) | 0 | 2 (net +96) | 0 | 2 (net +36) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 5 | 1 (net +416) | 0 | 0 | 1 (net +0) | 0 | 3 (net +0) | 0 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 11 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 8 (net +20) | 1 | 10% (1 of 10) |
| Mine | Empire of Man | 4 | 1 (net +210) | 0 | 2 (net +0) | 0 | 0 | 1 (net +145) | 0 | 50% (2 of 4) |
| Mine | Grand Cathay | 12 | 3 (net +581) | 0 | 0 | 2 (net -75) | 3 (net +52) | 3 (net +151) | 1 | 0% (0 of 11) |
| Mine | High Elf Realms | 9 | 0 | 1 (net -115) | 2 (net +0) | 3 (net +202) | 1 (net +0) | 1 (net +702) | 1 | 25% (2 of 8) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 2 (net +102) | 0 | 0 | 1 (net +664) | 0 | 67% (2 of 3) |
| Mine | Lizardmen | 3 | 1 (net +913) | 0 | 0 | 1 (net +186) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 2 (net -45) | 0 | 0 | 1 (net -34) | 0 | 67% (2 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 1 (net +54) | 1 (net +190) | 2 | 33% (1 of 3) |
| Mine | Skaven | 6 | 1 (net -402) | 0 | 0 | 0 | 0 | 5 (net -13) | 0 | 0% (0 of 6) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net -431) | 0 | 1 (net -195) | 0 | 1 (net +360) | 1 (net +125) | 0 | 25% (1 of 4) |
| Mine | Vampire Counts | 8 | 4 (net -211) | 0 | 2 (net +0) | 1 (net +0) | 0 | 1 (net +274) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 2 | 0 | 1 (net +464) | 1 (net +342) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 8 | 3 (net +0) | 0 | 2 (net +40) | 3 (net +15) | 0 | 0 | 0 | 25% (2 of 8) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +110) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 1 (net +562) | 2 (net +132) | 0 | 1 (net +304) | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +120) | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 16 | 5 (net -6) | 0 | 3 (net -39) | 2 (net +22) | 0 | 5 (net +95) | 1 | 20% (3 of 15) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 16 | 3 (net +201) | 0 | 1 (net +0) | 5 (net +234) | 2 (net +15) | 3 (net +104) | 2 | 7% (1 of 14) |
| Opponent | Vampire Counts | 16 | 0 | 2 (net +176) | 6 (net +405) | 3 (net +283) | 1 (net +282) | 3 (net +167) | 1 | 40% (6 of 15) |
| Opponent | Warriors of Chaos | 21 | 5 (net +64) | 1 (net +0) | 5 (net +173) | 3 (net +221) | 0 | 5 (net +240) | 2 | 26% (5 of 19) |
| Opponent | Wood Elf Realms | 30 | 3 (net +265) | 1 (net +227) | 3 (net +83) | 11 (net +224) | 2 (net +22) | 5 (net +87) | 5 | 12% (3 of 25) |

### Charged fights, damage counted: hc-mine-31c41bf-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 264 | 398 | +134 | 295 | 188 | +107 | +40.3 |
| Mine | 50-54% | 4 | 189 | 306 | +215 | 244 | 55 | +188 | +99.7 |
| Mine | Effective (55-75%) | 14 | 265 | 207 | +22 | 61 | 26 | +35 | +13.3 |
| Mine | 76-89% | 10 | 301 | 186 | +83 | 159 | 34 | +124 | +41.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 202 | 165 | +96 | 149 | 34 | +115 | +56.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 320 | 69 | +95 | 95 | 0 | +95 | +29.8 |
| Mine | No odds | 7 | 197 | 146 | +33 | 73 | 38 | +35 | +17.6 |
| Mine | All fights | 81 | 242 | 208 | +88 | 151 | 55 | +96 | +39.8 |
| Opponent | Long shot (under 50%) | 20 | 234 | 202 | +84 | 144 | 75 | +69 | +29.5 |
| Opponent | 50-54% | 4 | 250 | 281 | +145 | 205 | 90 | +115 | +46.2 |
| Opponent | Effective (55-75%) | 21 | 286 | 200 | +194 | 223 | 24 | +199 | +69.4 |
| Opponent | 76-89% | 31 | 253 | 171 | +185 | 215 | 44 | +171 | +67.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 259 | 181 | +147 | 163 | 14 | +149 | +57.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 336 | 68 | +60 | 68 | 28 | +40 | +11.8 |
| Opponent | No odds | 12 | 210 | 144 | +53 | 90 | 17 | +73 | +34.9 |
| Opponent | All fights | 116 | 257 | 179 | +140 | 174 | 38 | +135 | +52.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-mine-31c41bf-p2 | move | 344 | 82 (24%) | 60 (17%) | 54 (16%) | 208 (60%) |
| hc-mine-31c41bf-p2 | objective | 386 | 57 (15%) | 42 (11%) | 50 (13%) | 279 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

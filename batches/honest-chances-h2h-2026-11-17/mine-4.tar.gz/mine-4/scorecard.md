# Doctrine scorecard: hc-mine-31c41bf-p4

### Scorecard: hc-mine-31c41bf-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 1 | 2 | 1 | 0 | 0 | 0 | 177 |
| L0130 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 8 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 4 | 6 | 1 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 10 | 4 | 2 | 0 | 1 | 0 | 0 | 1104 |
| L0315 | 3 | 1 | Opponent | yes | 7 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 12 | 2 | 5 | 0 | 0 | 0 | 0 | 98 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 6 | 5 | 0 | 0 | 0 | 107 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0520 | 4 | 1 | Opponent | no | 7 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 2 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | - | 3 | 3 | 0 | 0 | 0 | 984 |
| L0624 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 114 |
| L0926 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 40 |
| L1017 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 2 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 5 | 3 | 1 | 0 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | no | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 501 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 5 | 2 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 3 | - | 2 | 0 | 1 | 0 | 0 | 317 |
| L1314 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 300 |
| L1331 | 5 | 1 | Mine | no | - | - | 2 | 1 | 1 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 1 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 2 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 4 | 2 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 1 | 3 | 4 | 0 | 1 | 0 | 0 | 98 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 7 | 0 | 1 | 0 | 0 | 255 |
| L1819 | 1 | 1 | Mine | no | 1 | 4 | 6 | 0 | 2 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 110 |
| L2021 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 4 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 940 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 90 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 6 | 1 | 3 | 0 | 0 | 245 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 3 | 2 | 0 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 0 | 5 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 8 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 2.2 | 2.6 | 2.4 | 1.2 | 0.5 | 0.0 | 0.0 | 335.0 |
| **Average** | | | Opponent | 43% | 3.2 | 2.0 | 3.1 | 2.1 | 0.4 | 0.0 | 0.0 | 135.9 |

### KPIs: hc-mine-31c41bf-p4

Rules off - Opponent only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (33 of 163) | 1% (2 of 183) | 10% (35 of 346) |
| Winner chose to follow up after the loser gave ground |  | 98% (49 of 50); on the table 98% | 100% (64 of 64); on the table 100% | 99% (113 of 114); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 94% (17 of 18); on the table 100% | 93% (26 of 28); on the table 96% |
| Winner chose to pursue after the loser fled |  | 93% (27 of 29); on the table 97% | 69% (25 of 36); on the table 75% | 80% (52 of 65); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 96% (85 of 89); on the table 97% | 90% (106 of 118); on the table 92% | 92% (191 of 207); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 34% (90 of 268) | 29% (50 of 174) | 32% (140 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (90 of 190) | 39% (50 of 127) | 44% (140 of 317) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (24 of 42) | 59% (38 of 64) | 58% (62 of 106) |
| Points that never fought | lower | 37% (25459 of 67942) | 36% (26133 of 71984) | 37% (51592 of 139926) |
|   infantry points that never fought | lower | 45% (6901 of 15347) | 61% (8390 of 13804) | 52% (15291 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (168 of 270) | 53% (149 of 280) | 58% (317 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.6 uses a game | 89% (8 of 9); 0.7 uses a game | 87% (27 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.4 uses a game | 25% (5 of 20); 0.2 uses a game | 31% (11 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 74% (14 of 19); 0.4 uses a game | 73% (11 of 15); 0.3 uses a game | 74% (25 of 34); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (33015 of 57750) | 48% (30220 of 63347) | 52% (63235 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (30%) | 1.1 (32%) | 2.6 (31%) |
| MARCHED: its unit marched | 0.8 (16%) | 0.6 (19%) | 1.4 (17%) |
| CHARGED: its unit charged | 0.5 (10%) | 0.1 (3%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 0.8 (17%) | 0.8 (22%) | 1.6 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (3%) | 0.2 (3%) |
| GONE: slain | 0.7 (14%) | 0.4 (11%) | 1.1 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (11%) | 0.1 (2%) | 0.6 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.4 | 2.0 | 3.9 | 0.4 | 1.9 |
| not cast | 3.0 | 2.4 | 2.8 | 8.4 | 1.6 | 21.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (60%) | 0.2 (8%) | 2.6 (31%) | 0.3 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (17%) | 0.2 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.0 (1%) | 0.5 (19%) | 1.6 (19%) | 0.2 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.1 (5%) | 0.2 (9%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (8%) | 0.0 (1%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.8 (4%) |
| GONE: slain | 0.9 (30%) | 0.3 (11%) | 0.6 (20%) | 1.1 (13%) | 0.0 (2%) | 3.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (13%) | 0.1 (6%) | 0.2 (6%) | 0.6 (7%) | 0.1 (9%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.6 (39%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (41%) | 0.1 (3%) | 1.0 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.1 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 64% (28 of 44) | 59% (10 of 17) | 62% (38 of 61) |
| the unit moved after it | 79% (22 of 28) | 80% (8 of 10) | 79% (30 of 38) |
| it charged on its next turn | 11% (3 of 28) | 10% (1 of 10) | 11% (4 of 38) |
| the enemy charged it first | 14% (4 of 28) | 10% (1 of 10) | 13% (5 of 38) |
| it fought by the end of its next turn | 7% (2 of 28) | 10% (1 of 10) | 8% (3 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (4 of 28) | 0% (0 of 10) | 11% (4 of 38) |
| none of these (no charge, no fight, no charge escaped) | 71% (20 of 28) | 80% (8 of 10) | 74% (28 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (557 of 878) | 51% (275 of 544) | 59% (832 of 1422) |
|   cavalry | 57% (46 of 81) | 73% (79 of 108) | 66% (125 of 189) |
|   character | 48% (47 of 98) | 14% (18 of 131) | 28% (65 of 229) |
|   chariot | 52% (54 of 103) | 55% (11 of 20) | 53% (65 of 123) |
|   infantry | 60% (161 of 268) | 60% (140 of 233) | 60% (301 of 501) |
|   monster | 48% (26 of 54) | 24% (6 of 25) | 41% (32 of 79) |
|   war machine | 81% (223 of 274) | 78% (21 of 27) | 81% (244 of 301) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (23%) | 1.3 (17%) | 3.4 (21%) |
| CHARGED: it charged | 0.9 (10%) | 1.6 (21%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (6%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.0 (22%) | 1.9 (25%) | 3.9 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.5 (7%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (17%) | 1.6 (21%) | 3.1 (19%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.6 | 80% | 4.9 pts | 29 pts |
| character | 2.1 | 0.9 | 72% | 9.9 pts | 21 pts |
| chariot | 1.8 | 1.0 | 68% | 13.2 pts | 24 pts |
| infantry | 12.1 | 5.1 | 74% | 10.6 pts | 129 pts |
| monster | 1.0 | 0.2 | 83% | 2.3 pts | 2 pts |
| war machine | 6.8 | 4.7 | 73% | 23.2 pts | 157 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.3 | 5.1 |
| Charges that made contact a game | 2.8 | 4.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.53 declared, 0.35 contact (17 units) | 0.38 declared, 0.38 contact (16 units) | 0.45 declared, 0.36 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.62 contact (8 units) | 1.21 declared, 0.93 contact (14 units) | 1.05 declared, 0.82 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.35 contact (250 units) | 0.70 declared, 0.52 contact (289 units) | 0.61 declared, 0.44 contact (539 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (46 of 81) | 31% (5 of 16) | 50% (3 of 6) | 52% (54 of 103) |
| Character in a unit | 84% (27 of 32) | 71% (12 of 17) | 100% (1 of 1) | 80% (40 of 50) |
| Character on its own | 70% (23 of 33) | 64% (16 of 25) | 31% (24 of 77) | 47% (63 of 135) |
| Chariot | 60% (9 of 15) | 75% (9 of 12) | - | 67% (18 of 27) |
| Infantry | 52% (43 of 83) | 40% (10 of 25) | 50% (3 of 6) | 49% (56 of 114) |
| Monster | 53% (18 of 34) | 64% (9 of 14) | - | 56% (27 of 48) |
| Monstrous | 71% (10 of 14) | 64% (9 of 14) | - | 68% (19 of 28) |
| War Machines | 88% (38 of 43) | 100% (2 of 2) | - | 89% (40 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 26% (27 of 102) | 30% | 55% (12 of 22) | 100% (6 of 6); 3.0 uses a game | 50% (1 of 2); 0.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 88% (15 of 17); on the table 88% | 62% (15 of 24) | 29% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 60% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (10 of 10); on the table 100% | 72% (13 of 18) | 50% | 77% (48 of 62) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (9 of 9); on the table 100% | 37% (31 of 84) | 35% | 54% (20 of 37) | 89% (8 of 9); 6.8 uses a game | 50% (1 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 100% (25 of 25); on the table 100% | 17% (6 of 35) | 38% | 51% (36 of 70) | 100% (7 of 7); 3.4 uses a game | 23% (7 of 30); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 19% | 0% (0 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (19 of 19); on the table 100% | 100% (6 of 6) | 21% | 43% (9 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 61% | 93% (13 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (11 of 11); on the table 100% | 10% (4 of 42) | 12% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 71% (12 of 17); on the table 82% | 26% (11 of 42) | 49% | 67% (30 of 45) | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 100% (13 of 13); on the table 100% | 0% (0 of 6) | 31% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 87% (13 of 15); on the table 93% | 29% (17 of 59) | 31% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 87% (26 of 30); on the table 90% | 25% (3 of 12) | 33% | 47% (34 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 87% (20 of 23); on the table 87% | 83% (5 of 6) | 43% | 62% (35 of 56) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (hc-mine-31c41bf-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (59) | 38% (22) | 47% (81) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.22 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.36 | 0.25 | 0.61 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.14 | 0.58 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.44 | 0.92 | 2.36 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 0.64 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.69 | 5.39 | 10.08 |

### Quality by phase: hc-mine-31c41bf-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 45% (49 of 110) | 42% (81 of 192) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (173 of 402) | 45% (90 of 198) |
| Strategy | Close-in objectives charged next turn | 15% (14 of 91) | 14% (34 of 249) |
| Strategy | Support requests answered (helper made contact too) | 60% (9 of 15) | 38% (13 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 53% (9 of 17) | 100% (4 of 4) |
| Strategy | Joined characters whose unit fought | 47% (14 of 30) | 39% (15 of 38) |
| Strategy | Lone characters that fought | 72% (67 of 93) | 78% (61 of 78) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.2 | 2.1 |
| Movement | Points that never moved of their own | 335.0 | 135.9 |
| Movement | Fights charged into per game | 2.5 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 76, net +97 | 23 of 123, net +58 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 76, net +10 | 31 of 123, net +130 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 76, net +144 | 10 of 123, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 76, net +72 | 31 of 123, net +149 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (174 of 365) | 31% (93 of 301) |
| Shooting | Points destroyed by shooting units | 48.6 | 57.0 |
| Shooting | War machine shots | 6.2 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (143 of 223) | 19% (4 of 21) |
| Shooting | Points destroyed by war machines | 40.9 | 1.7 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (19 of 64) | 21% (7 of 34) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.1 |
| Magic | Wounds caused by other spells | 1.6 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 98.1 | 25.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.2 | 2.1 / 0.2 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 243.7 | 426.4 |
| Combat | Points run down | 76.8 | 157.6 |
| Combat | Net points per charged fight, damage counted | +75 | +101 |
| Combat | Net per 100 charger points, damage counted | +27.1 | +34.3 |
| Combat | First round won (charged fights) | 76% | 77% |
| Combat | Net points per charged fight | +70 | +108 |
| Combat | Net points per supported fight / lone fight | +153 / +58 | +189 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 90 | 64 of 144 |
| Game | Points lost | 880.6 | 607.9 |
| Game | VP from objectives | 490.6 | 541.9 |
| Game | Lone holders (player turns) | 2.2 | 3.2 |

- Mine won / drew / lost: 10 / 9 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -334 VP
- The side that went first won 10 of 27 games with a winner
- Points traded per game (both sides' losses): 1488
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-mine-31c41bf-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.8 | -161.7 | 100.7 | 112.2 | 4.3 | -184.4 | 169.6 | 42.4 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 33.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.3 | 0.0 | 0.0 | 0.6 | +3.1 | 0.0 | 7.9 |
| BEST FACING | 0.5 | +14.7 | 0.0 | 27.4 | 0.2 | +7.4 | 0.0 | 0.0 |
| BEST FIRST | 1.2 | +58.5 | 16.7 | 53.3 | 0.9 | +60.3 | 24.1 | 24.4 |
| BEST OVERALL | 0.2 | +11.0 | 0.0 | 8.6 | 0.2 | +10.3 | 0.0 | 0.0 |
| BEST PREY | 0.6 | +59.7 | 6.9 | 4.7 | 0.6 | +16.0 | 10.6 | 0.0 |
| BEST PRIZE | 0.1 | -4.1 | 3.8 | 4.5 | 0.1 | -1.3 | 5.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 16.6 | 0.2 | +0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.2 | +0.0 | 23.6 | 0.0 |
| BLOCKED WHEEL | 0.3 | +12.1 | 0.0 | 5.1 | 0.6 | +4.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -8.5 | 0.0 | 0.0 | 0.3 | -52.2 | 64.2 | 7.9 |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | 0.1 | +0.0 | 0.0 | 8.4 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 46.5 | 23.5 | 0.1 | +0.0 | 15.8 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +171.1 | 205.0 | 119.9 | 0.6 | +30.8 | 45.3 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.8 | 0.0 | 9.4 | 0.0 | +0.0 | 4.5 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 12.1 | 0.2 | +0.0 | 20.9 | 13.1 |
| CAST JOB | 0.9 | +35.0 | 16.9 | 16.7 | 0.4 | +7.5 | 26.9 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +26.0 | 14.8 | 17.9 | 0.1 | +0.9 | 4.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 21.0 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +70.6 | 0.0 | 19.4 | 1.9 | +90.9 | 0.0 | 35.5 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 183.1 | 112.3 | 2.8 | +0.0 | 362.1 | 55.6 |
| CHARGE NOW WEIGHED | 0.6 | -33.5 | 14.4 | 16.5 | 0.6 | -41.3 | 17.4 | 7.9 |
| CHARGER SLAIN LOST | 0.3 | -5.6 | 36.2 | 19.1 | 0.9 | -32.1 | 101.6 | 35.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.2 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 2.4 | 0.2 | +0.0 | 21.5 | 4.9 |
| COMBAT PIVOT | 0.5 | +0.0 | 19.5 | 68.6 | 0.6 | +0.0 | 89.0 | 40.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.8 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +67.4 | 14.1 | 9.9 | 0.4 | +66.5 | 11.1 | 11.1 |
| COVER ONCE | 7.1 | -342.1 | 0.0 | 259.0 | 6.2 | -445.7 | 0.0 | 59.3 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 1.0 | 0.0 | +0.0 | 4.0 | 1.5 |
| DEFENSIVE FLOOR | 0.1 | +1.1 | 8.4 | 0.0 | 0.0 | +2.0 | 3.1 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +13.9 | 24.4 | 2.5 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +71.1 | 0.0 | 60.8 | 0.9 | +76.7 | 0.0 | 14.1 |
| FALLBACK BY WORTH | 4.4 | +45.3 | 0.0 | 66.4 | 5.6 | +28.4 | 0.0 | 63.6 |
| FIGHT LIFT | 0.2 | +2.3 | 13.4 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.5 | 6.9 | 0.0 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 139.5 | 5.0 | +0.0 | 0.0 | 56.5 |
| FOCUS FIRE | 0.0 | +0.7 | 1.2 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.6 | +86.8 | 0.0 | 92.2 | 1.0 | +119.5 | 0.0 | 21.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.3 | 0.0 | 9.0 | 0.1 | +3.7 | 0.0 | 2.6 |
| GIVES UP | 0.1 | -0.2 | 7.1 | 0.0 | 0.1 | -0.5 | 3.4 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -2.3 | 2.2 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 22.7 | 1.8 |
| HELPER UNSEEN | 0.3 | +0.0 | 52.9 | 32.9 | 0.5 | +0.0 | 40.5 | 18.8 |
| HILL BY ITS CHANCE | 0.5 | -55.6 | 0.0 | 0.0 | 0.6 | -59.3 | 0.0 | 11.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.2 | -62.2 | 228.1 | 162.1 | 9.6 | -212.4 | 785.7 | 129.9 |
| HUNT ADVANCE | 0.1 | +0.1 | 5.3 | 0.0 | 0.1 | +2.5 | 0.0 | 1.7 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +5.7 | 0.0 | 16.1 | 0.4 | +20.7 | 0.0 | 15.8 |
| HUNT RESULT | 0.1 | +5.4 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 1.2 |
| HUNT THE GUNS | 0.1 | +11.6 | 5.3 | 0.0 | 0.2 | +48.1 | 0.0 | 2.9 |
| IDLE COST | 16.6 | -261.1 | 0.0 | 211.0 | 20.7 | -340.5 | 0.0 | 193.6 |
| INVITES THE FIGHT | 1.6 | +11.7 | 39.4 | 54.1 | 0.8 | +6.4 | 38.5 | 11.4 |
| JOINT CHARGE PLAN | 0.1 | +0.8 | 0.0 | 5.2 | 0.1 | +22.1 | 7.8 | 7.4 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.2 | 0.0 | 0.0 | 0.2 | -4.5 | 34.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 6.1 | 0.1 | +1.3 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.1 | +0.3 | 4.0 | 0.0 | 0.1 | +0.4 | 1.0 | 0.0 |
| KEEPS ITS TARGET | 0.9 | +27.5 | 88.9 | 22.4 | 2.1 | +63.3 | 248.1 | 14.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +65.6 | 90.5 | 74.3 | 2.0 | +111.6 | 214.0 | 34.1 |
| KILLS COUNT NEXT TURN | 2.3 | +70.7 | 103.0 | 41.3 | 6.6 | +241.1 | 346.1 | 93.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +19.8 | 1.7 | 2.5 | 0.3 | +9.5 | 5.8 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 1.7 | 0.0 | 0.3 | +0.0 | 5.2 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +2.5 | 12.4 | 9.6 | 0.6 | -0.9 | 50.9 | 4.8 |
| LOST CHARGE | 2.1 | -21.8 | 69.1 | 96.2 | 1.4 | -22.2 | 61.2 | 25.7 |
| LURE BY WHAT IT DRAWS | 0.3 | -20.4 | 0.0 | 3.2 | 0.1 | -16.2 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.4 | +43.8 | 0.0 | 29.4 | 0.9 | +54.7 | 40.9 | 17.8 |
| MANOEUVRE | 0.2 | +6.6 | 0.0 | 2.9 | 0.2 | +3.9 | 0.0 | 2.6 |
| MARCH AT ESCAPER | 0.1 | +1.4 | 0.0 | 4.5 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +26.5 | 0.0 | 0.0 | 0.3 | +12.5 | 0.0 | 11.7 |
| MARCH ODDS | 0.4 | +28.7 | 25.9 | 4.6 | 0.3 | +18.0 | 4.5 | 0.0 |
| MARCH OVER CASTS | 0.2 | +13.6 | 0.0 | 14.1 | 0.4 | +14.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +46.6 | 0.0 | 104.7 | 5.6 | +76.8 | 0.0 | 90.4 |
| MEASURED NEXT CHARGE | 7.3 | -159.0 | 113.1 | 227.3 | - | - | - | - |
| MISSILES IN THE MOVE | 4.2 | +123.0 | 0.0 | 99.4 | 2.4 | +40.3 | 0.0 | 38.2 |
| MISSILES NEXT TURN | 4.6 | +79.2 | 0.0 | 151.6 | 3.1 | +26.0 | 0.0 | 49.3 |
| MODEL FACING | 0.2 | +47.6 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.5 | 0.0 |
| MOVE AND CAST | 0.4 | +22.8 | 0.0 | 4.5 | 0.4 | +4.1 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.3 | +7.7 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -34.5 | 10.1 | 57.9 | 0.1 | -1.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 0.6 | +3.5 | 26.6 | 7.1 | 5.1 | +358.4 | 292.5 | 69.7 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.0 | 3.9 | 0.0 | 0.1 | +9.2 | 4.7 | 4.2 |
| NO RALLY LEFT | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -8.2 | 15.4 | 13.0 | 0.3 | -18.1 | 45.8 | 0.8 |
| NOT TURNED | 4.7 | +45.6 | 0.0 | 136.8 | 5.4 | +87.6 | 0.0 | 74.4 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 33.7 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.6 | -568.1 | 3.9 | 287.4 | 15.6 | -748.3 | 31.9 | 208.9 |
| ONE FIGHT FORMULA | 7.8 | -122.6 | 21.2 | 193.4 | 7.9 | -164.8 | 36.8 | 91.6 |
| ONE OBJECTIVE FORMULA | 2.3 | -148.1 | 0.0 | 25.9 | 2.0 | -122.2 | 0.0 | 46.1 |
| OPENS A LANE | 0.3 | +1.7 | 6.6 | 9.4 | - | - | - | - |
| OPENS UP | 0.0 | +0.5 | 3.0 | 0.0 | 0.1 | +13.1 | 4.9 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +4.6 | 28.5 | 17.8 | 0.5 | +3.8 | 62.7 | 20.3 |
| PATHS CROSS | 2.0 | +102.3 | 0.0 | 25.1 | 3.0 | +192.1 | 0.0 | 24.5 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +9.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 5.5 |
| PLAN RESULT | 37.8 | +1206.1 | 1446.4 | 1216.1 | 39.6 | +1313.9 | 1622.3 | 826.6 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -0.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 4.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 2.2 | 0.1 | +9.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +10.1 | 0.0 | 36.8 | 1.8 | +13.7 | 0.0 | 60.1 |
| RANDOM MOVER NO PROMISE | 0.2 | -7.1 | 15.6 | 4.0 | 0.2 | -9.3 | 1.0 | 9.9 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -24.2 | 0.0 | 18.5 | 1.5 | -43.4 | 0.0 | 22.3 |
| REDIRECT COUNTER | 2.4 | +143.4 | 0.0 | 38.1 | 3.6 | +194.3 | 0.0 | 64.1 |
| REDIRECT WEIGHED | 0.1 | -2.3 | 0.0 | 1.8 | 0.4 | +15.4 | 24.0 | 5.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 25.1 | 0.2 | +0.0 | 0.0 | 15.0 |
| RESERVE FALL BACK | 0.6 | +19.6 | 0.0 | 6.9 | 0.4 | +17.0 | 0.0 | 9.6 |
| RISK BY ARC | 2.2 | +79.3 | 222.0 | 140.2 | 2.9 | +64.6 | 332.6 | 53.5 |
| RISK ONCE | 2.0 | +32.6 | 19.3 | 86.7 | 4.1 | +106.3 | 108.8 | 92.1 |
| RUN DOWN | 1.6 | -5.9 | 140.0 | 75.3 | - | - | - | - |
| SAFER THAN THE JOB | 1.3 | +71.7 | 0.0 | 41.2 | 0.6 | +23.6 | 0.0 | 13.1 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.2 | 0.0 | 0.0 | 0.5 | -38.3 | 0.0 | 3.0 |
| SEARCH SPOT | 2.3 | +101.1 | 0.0 | 19.9 | 2.4 | +96.9 | 0.0 | 16.1 |
| SELF MOVE SPELL | 0.2 | +46.0 | 0.0 | 0.0 | 0.5 | +21.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +52.3 | 0.0 | 45.9 | 1.8 | +133.4 | 71.1 | 17.8 |
| SET-UP ANY TARGET | 0.5 | +46.1 | 5.1 | 0.0 | 0.1 | +34.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +53.2 | 97.0 | 24.2 | 1.1 | +22.7 | 51.5 | 3.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.2 | +0.0 | 34.2 | 10.7 | 0.4 | +0.0 | 64.6 | 0.0 |
| SHOTS IN THE MOVE | 14.6 | +548.5 | 0.0 | 302.3 | 7.4 | +223.5 | 0.0 | 60.3 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +53.5 | 5.1 | 0.0 | 0.2 | +58.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +18.7 | 84.3 | 95.5 | 2.3 | +41.6 | 109.2 | 109.2 |
| SPELLS IN THE FIGHT | 0.5 | -1.6 | 80.2 | 38.8 | 0.8 | -6.0 | 105.4 | 14.9 |
| STABLE ROLE | 11.1 | +0.0 | 464.5 | 212.0 | 10.4 | +0.0 | 389.3 | 152.0 |
| STAY WEIGHED | 0.1 | +11.1 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +1.7 | 0.0 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +20.5 | 0.0 | 11.3 | 0.3 | +7.2 | 0.0 | 3.9 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 7.0 | -58.2 | 555.6 | 150.8 | 7.7 | -70.4 | 376.1 | 89.1 |
| SUPPORTS | 5.2 | +68.8 | 397.0 | 51.2 | 5.5 | +73.5 | 141.6 | 66.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.2 | 7.6 | 0.0 | 0.0 | -0.7 | 5.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.6 | 0.0 | 6.9 | 0.8 | -0.2 | 8.9 | 14.0 |
| THROUGH LINE OF FIRE | 0.0 | +1.1 | 0.0 | 0.0 | 0.3 | +6.5 | 0.0 | 3.0 |
| TURN WORTH | 0.3 | -21.1 | 11.4 | 9.4 | 0.2 | -12.9 | 15.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.4 | 0.0 | 12.1 | 0.5 | +3.8 | 8.9 | 10.4 |
| WAIT AFTER COSTS | 3.9 | -166.9 | 98.4 | 71.1 | 8.0 | -418.0 | 471.4 | 113.4 |
| WALKS TO THE FIGHT | 2.0 | +13.1 | 40.7 | 27.6 | 1.0 | +7.5 | 55.1 | 11.2 |
| WAR ENGINE CHARGES | 0.1 | +1.4 | 7.1 | 5.1 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 54.0 | 27.5 | 0.1 | +0.0 | 2.2 | 4.0 |
| WEARS DOWN | 1.2 | +45.2 | 137.6 | 70.3 | 1.6 | +50.2 | 223.3 | 17.1 |
| WHO HITS BACK | 0.4 | +25.2 | 0.0 | 34.3 | 0.3 | +20.4 | 0.0 | 20.0 |
| WHOLE FIGHT | 0.3 | +18.1 | 39.1 | 16.4 | 0.6 | +25.5 | 89.4 | 2.0 |
| WHOLE FIGHT GAIN | 0.3 | +22.5 | 26.4 | 5.5 | 0.8 | +58.6 | 80.5 | 7.0 |
| WIDER SPREAD | 1.9 | -6.5 | 162.9 | 105.2 | 3.7 | -3.2 | 438.6 | 48.7 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 5.2 | 0.0 |

### Rule changes: hc-mine-31c41bf-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1085 | 1085 | 1085 | 30.14 | -47389 | -43.7 |
| PATHS CROSS | 180 | 180 | 180 | 5.00 | +10601 | +58.9 |
| SEARCH SPOT | 169 | 169 | 163 | 4.53 | +7126 | +43.7 |
| SUPPORTS | 383 | 383 | 157 | 4.36 | +1728 | +11.0 |
| KILLS COUNT NEXT TURN | 320 | 320 | 124 | 3.44 | +2780 | +22.4 |
| MOVE TO CHARGE | 205 | 205 | 110 | 3.06 | +5463 | +49.7 |
| FACES THE THREAT | 85 | 85 | 85 | 2.36 | +5320 | +62.6 |
| BEST FIRST | 79 | 79 | 79 | 2.19 | +4276 | +54.1 |
| WAIT AFTER COSTS | 429 | 429 | 79 | 2.19 | +1347 | +17.0 |
| COVER ONCE | 482 | 281 | 76 | 2.11 | +1223 | +16.1 |
| SHOTS IN THE MOVE | 792 | 598 | 71 | 1.97 | +1604 | +22.6 |
| SAFER THAN THE JOB | 69 | 69 | 69 | 1.92 | +3429 | +49.7 |
| FALLBACK BY WORTH | 358 | 358 | 66 | 1.83 | +2654 | +40.2 |
| ONE FIGHT FORMULA | 566 | 360 | 63 | 1.75 | +178 | +2.8 |
| RANDOM MOVE BY FIGURES | 106 | 106 | 62 | 1.72 | +857 | +13.8 |
| CHAFF IN THE MOVE | 105 | 103 | 60 | 1.67 | +1960 | +32.7 |
| REDIRECT COUNTER | 216 | 112 | 60 | 1.67 | +3567 | +59.4 |
| FOLLOW UP WEIGHED | 59 | 59 | 59 | 1.64 | +7427 | +125.9 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ADVANCE WORTH | 366 | 366 | 52 | 1.44 | +1204 | +23.2 |
| SET UP TOGETHER | 87 | 82 | 52 | 1.44 | +3233 | +62.2 |
| WALKS TO THE FIGHT | 108 | 108 | 47 | 1.31 | +178 | +3.8 |
| IDLE COST | 1342 | 772 | 46 | 1.28 | +609 | +13.2 |
| SHOOTS FROM THE BEST SPOT | 104 | 104 | 45 | 1.25 | +920 | +20.5 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 40 | 40 | 40 | 1.11 | +2485 | +62.1 |
| MISSILES IN THE MOVE | 235 | 162 | 39 | 1.08 | +835 | +21.4 |
| RESERVE FALL BACK | 39 | 39 | 39 | 1.08 | +1317 | +33.8 |
| RISK BY ARC | 184 | 179 | 39 | 1.08 | +1077 | +27.6 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 117 | 115 | 35 | 0.97 | +1841 | +52.6 |
| BLOCKED WHEEL | 32 | 32 | 32 | 0.89 | +597 | +18.6 |
| CANNON PLANNED TARGET | 195 | 195 | 31 | 0.86 | -360 | -11.6 |
| INVITES THE FIGHT | 83 | 83 | 31 | 0.86 | +167 | +5.4 |
| MEASURED NEXT CHARGE | 264 | 188 | 31 | 0.86 | +138 | +4.4 |
| RISK ONCE | 220 | 168 | 31 | 0.86 | +853 | +27.5 |
| HONEST WORTH | 497 | 493 | 30 | 0.83 | +246 | +8.2 |
| MAX FOR POSITIONING | 376 | 243 | 30 | 0.83 | +173 | +5.8 |
| CHARGE NOW FIRST | 162 | 162 | 29 | 0.81 | -1730 | -59.7 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +967 | +33.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +995 | +35.5 |
| MARCH CHECK | 28 | 27 | 26 | 0.72 | +1619 | +62.3 |
| WHO HITS BACK | 26 | 26 | 26 | 0.72 | +1184 | +45.5 |
| WHOLE FIGHT GAIN | 41 | 39 | 26 | 0.72 | +751 | +28.9 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +794 | +33.1 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +245 | +10.6 |
| MAKE SURE TOGETHER | 49 | 34 | 21 | 0.58 | +1238 | +58.9 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| KEEPS ITS TARGET | 109 | 109 | 20 | 0.56 | +397 | +19.8 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +949 | +49.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CAST JOB | 49 | 49 | 17 | 0.47 | +265 | +15.6 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| BEST PREY | 43 | 43 | 16 | 0.44 | +805 | +50.3 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | +2 | +0.1 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WAR ENGINE JOBS | 28 | 28 | 15 | 0.42 | -588 | -39.2 |
| BEST OVERALL | 14 | 14 | 14 | 0.39 | +764 | +54.6 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +503 | +38.7 |
| WEARS DOWN | 102 | 97 | 13 | 0.36 | +275 | +21.1 |
| THROUGH LINE OF FIRE | 12 | 12 | 12 | 0.33 | +274 | +22.8 |
| MANOEUVRE | 14 | 14 | 10 | 0.28 | +377 | +37.7 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -288 | -32.0 |
| CASTING BLOCK | 13 | 13 | 9 | 0.25 | +453 | +50.3 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 127 | 126 | 8 | 0.22 | +224 | +28.1 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +1713 | +214.2 |
| SUPPORT NARROWED | 529 | 529 | 8 | 0.22 | -61 | -7.6 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +255 | +36.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +278 | +46.4 |
| SURE REACH TOGETHER | 39 | 26 | 6 | 0.17 | +5 | +0.8 |
| WHOLE FIGHT | 31 | 29 | 6 | 0.17 | +316 | +52.6 |
| MISSILES NEXT TURN | 275 | 178 | 5 | 0.14 | +0 | +0.1 |
| ONE OBJECTIVE FORMULA | 155 | 77 | 5 | 0.14 | +162 | +32.4 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +462 | +92.5 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -58 | -11.6 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +435 | +87.1 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| CHAFF PASSED | 4 | 4 | 4 | 0.11 | -6 | -1.4 |
| LONG SHOT | 33 | 33 | 4 | 0.11 | -8 | -2.0 |
| REFUSING RETIRES | 14 | 14 | 4 | 0.11 | -2 | -0.5 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -142 | -35.6 |
| EDGE GIVE GROUND | 9 | 9 | 3 | 0.08 | +141 | +47.1 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +18 | +5.9 |
| HUNT IN PAIRS | 19 | 11 | 3 | 0.08 | +98 | +32.5 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| OPENS UP | 5 | 5 | 3 | 0.08 | +233 | +77.6 |
| OVERRUNS AWAY | 32 | 32 | 3 | 0.08 | +28 | +9.4 |
| WIDER SPREAD | 203 | 196 | 3 | 0.08 | +23 | +7.6 |
| BACKUP TARGETS | 29 | 15 | 2 | 0.06 | +2 | +0.8 |
| DEFENSIVE FLOOR | 3 | 3 | 2 | 0.06 | +23 | +11.4 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +428 | +214.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +53 | +26.5 |
| OPENS A LANE | 10 | 5 | 2 | 0.06 | +11 | +5.7 |
| TWO OR MORE ARRIVE | 26 | 25 | 2 | 0.06 | +15 | +7.6 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -90 | -45.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +32 | +32.1 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -29 | -29.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +31 | +31.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +25 | +24.9 |
| HUNT ADVANCE | 6 | 6 | 1 | 0.03 | +29 | +29.1 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 1 | 0.03 | -156 | -156.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -27 | -26.7 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +150 | +150.4 |
| RUN DOWN | 57 | 56 | 1 | 0.03 | +4 | +3.8 |
| SPELLS IN THE FIGHT | 46 | 44 | 1 | 0.03 | +0 | +0.0 |
| STOPS | 2 | 2 | 1 | 0.03 | +5 | +4.8 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +17 | +16.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 13 | 11 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 19 | 19 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 43 | 39 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 44 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 345 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 38 | 38 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 16 | 16 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 20 | 20 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 363 | 363 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 21 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2787 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 82 | 82 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 125 | not checked | - | - | - | - |
| STABLE ROLE | 774 | 774 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: hc-mine-31c41bf-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.28 | 13.81 | 45.6 |
| FALLBACK | gate | 0.50 | 0.92 | 28.3 |
| TURN GATE | gate | 0.36 | 0.53 | 26.3 |
| CHARGE NOW FIRST | rule | 0.25 | 0.56 | 59.7 |
| WAR ENGINE JOBS | rule | 0.36 | 0.06 | 39.2 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.03 | 41.3 |
| PATHS CROSS | rule | 0.08 | 0.19 | 12.0 |
| AFTERMATH BAND | gate | 0.19 | 0.06 | 2.4 |
| BEST PRIZE | rule | 0.11 | 0.14 | 32.0 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 8.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.17 | 64.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 14.9 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.06 | 3.7 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.06 | 11.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.03 | 35.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 3.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 50.2 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 35.0 |
| CHAFF PASSED | rule | - | 0.06 | 2.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 53.5 |
| FACES THE THREAT | rule | 0.06 | - | 4.3 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 45.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 29.4 |
| FIGHT ORDER BAND | gate | 0.03 | - | 0.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 1.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 1.3 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 156.0 |
| LONG SHOT | rule | - | 0.03 | 36.7 |
| MARCH ODDS | rule | - | 0.03 | 118.2 |
| MOVE AND CAST | rule | - | 0.03 | 218.6 |
| NO REASON | gate | 0.03 | - | 2.3 |
| PURSUES BIG PREY | rule | - | 0.03 | 26.7 |
| REDIRECT WEIGHED | rule | 0.03 | - | 54.5 |
| REFUSING RETIRES | rule | 0.03 | - | 1.4 |
| RULE SWITCHED OFF | gate | - | 0.03 | 3.7 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 72.6 |

### Plans: hc-mine-31c41bf-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.1 | 20% | 146 | 270 | 185% |
| Mine | charge | 2.7 | 60% | 175 | 238 | 136% |
| Mine | close in | 2.5 | 27% | 84 | 88 | 105% |
| Mine | hold | 5.2 | 31% | 304 | 0 | 0% |
| Mine | join | 0.6 | 95% | 10 | 0 | 0% |
| Mine | shoot | 9.6 | 51% | 351 | 610 | 174% |
| Mine | support | 6.1 | 91% | 52 | 0 | 0% |
| Opponent | advance | 11.3 | 14% | 133 | 309 | 233% |
| Opponent | charge | 4.6 | 57% | 372 | 519 | 139% |
| Opponent | close in | 6.9 | 28% | 424 | 250 | 59% |
| Opponent | hold | 4.4 | 26% | 320 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 27 | 0 | 0% |
| Opponent | shoot | 4.2 | 58% | 109 | 244 | 225% |
| Opponent | support | 7.4 | 91% | 62 | 0 | 0% |

### Packages: hunt the guns, hc-mine-31c41bf-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 50% | 0% | 2.0 | 210 | 98 | 50% | 7 |
| Opponent | 0.2 | 6 | 0 | 0% | 0% | 0% | - | 289 | 0 | 0% | 48 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 54 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 109 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 210 | 98 | 50% | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 0% | 0% | 0% | - | 325 | 0 | 0% | 26 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: hc-mine-31c41bf-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 31% | 70% | 19% | 40% | 18% | 0% | 18% | 59% | 5% |
| Opponent | REDIRECT COUNTER | 3.6 | 23% | 73% | 30% | 11% | 29% | 0% | 14% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-mine-31c41bf-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 17 (4) | 17 | 0 | 79 | 0% | 2.8 | - | 17 (4) | - | 0 (1) | 22 (3) |
| Mine | Chaff | 34 | 24 (34) | 8 | 16 | 56 | 26% | 2.2 | 13 (14) | 28 (7) | 33 (13) | 26 (22) | 21 (12) |
| Mine | Character | 106 | 42 (106) | 42 | 0 | 44 | 16% | 2.4 | 46 (31) | 44 (51) | 32 (6) | 29 (41) | 56 (47) |
| Mine | Clean-up | 22 | 60 (22) | 21 | 39 | 47 | 41% | 3.1 | 0 (2) | 86 (16) | 13 (4) | 94 (10) | 42 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 44 (41) | 35 | 9 | 53 | 15% | 2.4 | 47 (27) | 51 (9) | 14 (5) | 62 (25) | 18 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.7 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 34 (65) | 23 | 12 | 51 | 20% | 2.5 | 48 (13) | 32 (45) | 28 (7) | 43 (40) | 24 (25) |
| Mine | Holder | 31 | 102 (31) | 29 | 73 | 42 | 29% | 3.0 | 32 (7) | 168 (16) | 41 (8) | 168 (17) | 35 (14) |
| Mine | Shooter | 34 | 42 (34) | 15 | 27 | 57 | 6% | 1.6 | 4 (8) | 67 (21) | 0 (5) | 39 (25) | 52 (9) |
| Mine | Support | 1 | 38 (1) | 38 | 0 | 0 | 0% | 4.0 | - | - | 38 (1) | - | 38 (1) |
| Mine | War machine | 56 | 25 (56) | 25 | 0 | 54 | 4% | 1.4 | 0 (16) | 46 (30) | 12 (10) | 16 (9) | 27 (47) |
| Mine | Wizard | 17 | 4 (17) | 4 | 0 | 54 | 6% | 1.8 | 0 (3) | 10 (7) | 0 (1) | 0 (4) | 10 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 48 (75) | 39 | 9 | 55 | 41% | 2.9 | 19 (31) | 40 (17) | 85 (27) | 62 (56) | 0 (19) |
| Opponent | Character | 97 | 52 (97) | 52 | 0 | 29 | 25% | 2.1 | 60 (45) | 48 (39) | 39 (6) | 45 (52) | 63 (38) |
| Opponent | Clean-up | 11 | 68 (11) | 31 | 37 | 15 | 18% | 3.1 | 34 (3) | 46 (6) | 163 (2) | 47 (6) | 80 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 52 (60) | 34 | 17 | 33 | 28% | 2.9 | 43 (26) | 52 (25) | 90 (9) | 53 (39) | 49 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 62 | 29% | 2.2 | 0 (4) | 0 (8) | 0 (5) | 0 (13) | 0 (4) |
| Opponent | Hammer | 65 | 48 (65) | 34 | 13 | 35 | 34% | 2.9 | 29 (20) | 50 (38) | 93 (7) | 59 (41) | 31 (24) |
| Opponent | Holder | 29 | 35 (29) | 11 | 25 | 27 | 41% | 3.5 | 12 (10) | 44 (13) | 46 (6) | 51 (17) | 12 (12) |
| Opponent | Shooter | 33 | 110 (33) | 57 | 53 | 24 | 3% | 1.5 | 127 (9) | 105 (21) | 97 (3) | 119 (18) | 101 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 16 | 50% | 3.0 | 0 (4) | 0 (2) | - | 0 (3) | 0 (3) |
| Opponent | War machine | 6 | 38 (6) | 38 | 0 | 40 | 17% | 1.0 | 0 (3) | 92 (3) | - | 0 (3) | 92 (3) |
| Opponent | Wizard | 19 | 10 (19) | 10 | 0 | 29 | 11% | 1.8 | 3 (11) | 17 (4) | 0 (2) | 3 (11) | 16 (6) |

### Charged fights: hc-mine-31c41bf-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 262 | 145 | 1.8 | 1.0 | 83 | 36 | +47 | 2 of 7 | 4 of 7 | - | +47 |
| Mine | Chaos Dwarfs | 4 | 113 | 112 | 2.5 | 1.1 | 45 | 62 | -18 | 3 of 10 | 5 of 10 | +0 | -20 |
| Mine | Dwarfen Mountain Holds | 3 | 482 | 20 | 1.0 | 1.0 | 20 | 20 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| Mine | Empire of Man | 5 | 106 | 366 | 1.4 | 1.1 | 262 | 92 | +170 | 3 of 7 | 5 of 7 | +170 | +170 |
| Mine | Grand Cathay | 4 | 393 | 51 | 2.8 | 1.2 | 19 | 0 | +19 | 4 of 11 | 9 of 11 | +0 | +23 |
| Mine | High Elf Realms | 4 | 133 | 357 | 2.8 | 1.1 | 130 | 54 | +76 | 6 of 11 | 9 of 11 | +0 | +83 |
| Mine | Kingdom of Bretonnia | 1 | 251 | 1257 | 6.0 | 1.5 | 210 | 0 | +210 | 4 of 6 | 6 of 6 | +286 | +171 |
| Mine | Lizardmen | 1 | 0 | 1031 | 6.0 | 1.2 | 172 | 41 | +131 | 4 of 6 | 4 of 6 | +55 | +146 |
| Mine | Ogre Kingdoms | 2 | 63 | 128 | 3.0 | 1.0 | 42 | 46 | -3 | 2 of 6 | 3 of 6 | - | -3 |
| Mine | Skaven | 2 | 132 | 33 | 1.5 | 1.0 | 22 | 0 | +22 | 1 of 3 | 3 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 38 | 340 | 4.5 | 1.0 | 76 | 22 | +54 | 2 of 9 | 8 of 9 | - | +54 |
| Mine | Vampire Counts | 2 | 202 | 490 | 2.5 | 1.4 | 196 | 0 | +196 | 2 of 5 | 5 of 5 | +433 | +38 |
| Mine | Warriors of Chaos | 2 | 28 | 313 | 3.0 | 1.3 | 104 | 39 | +65 | 2 of 6 | 5 of 6 | +84 | +56 |
| **Mine** | all armies | 36 | 188 | 262 | 2.5 | 1.1 | 105 | 35 | +70 | 35 of 90 | 68 of 90 | +153 | +58 |
| Opponent | Empire of Man | 1 | 225 | 0 | 1.0 | 1.0 | 0 | 265 | -265 | 1 of 1 | 0 of 1 | - | -265 |
| Opponent | High Elf Realms | 5 | 254 | 698 | 3.8 | 1.1 | 184 | 8 | +176 | 12 of 19 | 13 of 19 | +451 | +143 |
| Opponent | Lizardmen | 2 | 237 | 868 | 3.5 | 1.0 | 248 | 33 | +214 | 4 of 7 | 7 of 7 | - | +214 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 632 | 4.0 | 1.2 | 158 | 5 | +154 | 3 of 12 | 11 of 12 | +441 | +96 |
| Opponent | Skaven | 4 | 0 | 274 | 3.8 | 1.1 | 73 | 40 | +33 | 7 of 15 | 10 of 15 | -65 | +40 |
| Opponent | Tomb Kings of Khemri | 2 | 150 | 392 | 4.0 | 1.0 | 98 | 17 | +81 | 3 of 8 | 4 of 8 | - | +81 |
| Opponent | Vampire Counts | 6 | 0 | 486 | 4.5 | 1.3 | 108 | 32 | +76 | 12 of 27 | 21 of 27 | +190 | +50 |
| Opponent | Warriors of Chaos | 7 | 24 | 735 | 3.1 | 1.0 | 234 | 41 | +193 | 10 of 22 | 17 of 22 | +380 | +184 |
| Opponent | Wood Elf Realms | 6 | 96 | 486 | 5.5 | 1.2 | 88 | 39 | +50 | 12 of 33 | 28 of 33 | +28 | +55 |
| **Opponent** | all armies | 36 | 84 | 555 | 4.0 | 1.1 | 139 | 31 | +108 | 64 of 144 | 111 of 144 | +189 | +97 |

### Effective charges: hc-mine-31c41bf-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 2 (net +42) | 0 | 2 (net +0) | 1 (net +177) | 0 | 0 | 2 | 40% (2 of 5) |
| Mine | Chaos Dwarfs | 10 | 0 | 0 | 3 (net -113) | 4 (net -20) | 0 | 1 (net +0) | 2 | 38% (3 of 8) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 0 | 1 (net +60) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 7 | 1 (net +499) | 0 | 2 (net +200) | 2 (net +85) | 0 | 2 (net +61) | 0 | 29% (2 of 7) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 0 | 5 (net +0) | 2 (net +48) | 1 (net +27) | 2 | 0% (0 of 9) |
| Mine | High Elf Realms | 11 | 2 (net +286) | 2 (net -28) | 1 (net +0) | 2 (net +33) | 1 (net +66) | 0 | 3 | 12% (1 of 8) |
| Mine | Kingdom of Bretonnia | 6 | 0 | 0 | 0 | 1 (net +572) | 0 | 4 (net +171) | 1 | 0% (0 of 5) |
| Mine | Lizardmen | 6 | 1 (net -72) | 0 | 0 | 2 (net +155) | 0 | 1 (net +0) | 2 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 6 | 1 (net +0) | 1 (net +0) | 1 (net +255) | 1 (net -185) | 0 | 1 (net +0) | 1 | 20% (1 of 5) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +33) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 2 (net -98) | 2 (net +180) | 2 (net +30) | 2 (net +72) | 1 | 25% (2 of 8) |
| Mine | Vampire Counts | 5 | 0 | 0 | 0 | 3 (net +74) | 1 (net +759) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 6 | 2 (net +25) | 0 | 1 (net +0) | 0 | 2 (net +84) | 1 (net +173) | 0 | 17% (1 of 6) |
| Opponent | High Elf Realms | 19 | 2 (net +0) | 1 (net -151) | 7 (net +301) | 4 (net +303) | 0 | 4 (net +21) | 1 | 39% (7 of 18) |
| Opponent | Lizardmen | 7 | 0 | 0 | 2 (net +445) | 1 (net +162) | 0 | 2 (net +249) | 2 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 12 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 (net +62) | 9 | 0% (0 of 3) |
| Opponent | Skaven | 15 | 4 (net -80) | 1 (net +80) | 5 (net -55) | 1 (net +434) | 0 | 3 (net +53) | 1 | 36% (5 of 14) |
| Opponent | Tomb Kings of Khemri | 8 | 3 (net -45) | 0 | 3 (net +191) | 1 (net +210) | 1 (net +0) | 0 | 0 | 38% (3 of 8) |
| Opponent | Vampire Counts | 27 | 5 (net +71) | 0 | 7 (net +38) | 4 (net -14) | 3 (net +145) | 7 (net +108) | 1 | 27% (7 of 26) |
| Opponent | Warriors of Chaos | 22 | 4 (net +230) | 0 | 3 (net +233) | 5 (net +195) | 2 (net +288) | 5 (net +376) | 3 | 16% (3 of 19) |
| Opponent | Wood Elf Realms | 33 | 5 (net +105) | 0 | 4 (net -59) | 9 (net +58) | 4 (net -68) | 8 (net +141) | 3 | 13% (4 of 30) |

### Charged fights, damage counted: hc-mine-31c41bf-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 170 | 234 | +97 | 237 | 154 | +83 | +48.7 |
| Mine | 50-54% | 3 | 343 | 312 | -19 | 189 | 199 | -10 | -2.9 |
| Mine | Effective (55-75%) | 12 | 262 | 284 | +10 | 78 | 63 | +15 | +5.8 |
| Mine | 76-89% | 25 | 303 | 200 | +67 | 96 | 30 | +65 | +21.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 266 | 179 | +72 | 102 | 9 | +92 | +34.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 436 | 84 | +144 | 151 | 0 | +151 | +34.6 |
| Mine | No odds | 14 | 242 | 208 | +82 | 125 | 32 | +93 | +38.5 |
| Mine | All fights | 90 | 278 | 206 | +70 | 124 | 49 | +75 | +27.1 |
| Opponent | Long shot (under 50%) | 23 | 219 | 314 | +58 | 123 | 77 | +47 | +21.3 |
| Opponent | 50-54% | 3 | 181 | 182 | -24 | 46 | 60 | -14 | -7.9 |
| Opponent | Effective (55-75%) | 31 | 252 | 260 | +130 | 179 | 68 | +111 | +43.9 |
| Opponent | 76-89% | 25 | 261 | 186 | +139 | 170 | 43 | +127 | +48.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 365 | 179 | +149 | 175 | 22 | +153 | +41.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 484 | 107 | +74 | 160 | 63 | +98 | +20.2 |
| Opponent | No odds | 21 | 302 | 170 | +65 | 141 | 85 | +56 | +18.7 |
| Opponent | All fights | 144 | 295 | 213 | +108 | 158 | 57 | +101 | +34.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-mine-31c41bf-p4 | move | 301 | 91 (30%) | 66 (22%) | 38 (13%) | 172 (57%) |
| hc-mine-31c41bf-p4 | objective | 340 | 47 (14%) | 37 (11%) | 50 (15%) | 243 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Doctrine scorecard: hc-opp-31c41bf-p2

### Scorecard: hc-opp-31c41bf-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 639 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 1 | 0 | 0 | 0 | 110 |
| L0307 | 1 | 1 | Mine | yes | 4 | 4 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 5 | 0 | 2 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 961 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 1 | 0 | 0 | 0 | 50 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1372 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 1097 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 3 | - | 1 | 3 | 1 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 864 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 9 | 2 | 1 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1303 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 6 | 3 | 1 | 0 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | 6 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 5 | 5 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 6 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 3 | 3 | 3 | 0 | 2 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 1 | 0 | 0 | 307 |
| L1629 | 3 | 1 | Opponent | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 4 | 1 | 0 | 0 | 0 | 0 | 147 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 262 |
| L1827 | 3 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 226 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 7 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 9 | - | 2 | 2 | 1 | 0 | 0 | 577 |
| L2131 | 1 | 1 | Opponent | no | 2 | 2 | 0 | 2 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | no | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 4 | 1 | 3 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 2.4 | 3.0 | 1.8 | 1.4 | 0.1 | 0.0 | 0.0 | 372.6 |
| **Average** | | | Opponent | 27% | 2.6 | 2.7 | 2.5 | 1.5 | 0.4 | 0.0 | 0.0 | 180.8 |

### KPIs: hc-opp-31c41bf-p2

Rules off - Mine only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (33 of 165) | 16% (28 of 175) | 18% (61 of 340) |
| Winner chose to follow up after the loser gave ground |  | 100% (60 of 60); on the table 100% | 98% (42 of 43); on the table 98% | 99% (102 of 103); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (9 of 9); on the table 100% | 89% (16 of 18); on the table 94% | 93% (25 of 27); on the table 96% |
| Winner chose to pursue after the loser fled |  | 80% (20 of 25); on the table 84% | 71% (22 of 31); on the table 77% | 75% (42 of 56); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 95% (89 of 94); on the table 96% | 87% (80 of 92); on the table 90% | 91% (169 of 186); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 35% (121 of 342) | 35% (54 of 156) | 35% (175 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (121 of 237) | 49% (54 of 111) | 50% (175 of 348) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (15 of 24) | 48% (27 of 56) | 52% (42 of 80) |
| Points that never fought | lower | 41% (29300 of 71583) | 41% (29594 of 71989) | 41% (58894 of 143572) |
|   infantry points that never fought | lower | 53% (8627 of 16324) | 63% (8857 of 14029) | 58% (17484 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (163 of 284) | 59% (175 of 297) | 58% (338 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 67% (12 of 18); 1.0 uses a game | 79% (30 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 33% (6 of 18); 0.3 uses a game | 50% (1 of 2); 0.0 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30888 of 60231) | 56% (35225 of 63281) | 54% (66113 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (27%) | 0.8 (26%) | 2.4 (27%) |
| MARCHED: its unit marched | 1.3 (21%) | 0.4 (14%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.5 (17%) | 2.1 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.1 (2%) |
| GONE: slain | 0.8 (13%) | 0.7 (24%) | 1.4 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (8%) | 0.0 (1%) | 0.5 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.2 | 1.1 | 4.9 | 0.4 | 2.0 |
| not cast | 4.2 | 3.6 | 3.9 | 9.0 | 1.9 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (40%) | 0.1 (3%) | 2.4 (27%) | 0.5 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.4 (11%) | 0.8 (21%) | 2.1 (23%) | 0.4 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.3 (9%) | 0.2 (6%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (2%) | 0.1 (3%) | 0.1 (2%) | 0.0 (1%) | 0.4 (2%) |
| GONE: slain | 0.9 (21%) | 0.8 (22%) | 0.7 (17%) | 1.4 (16%) | 0.3 (14%) | 2.9 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (3%) | 0.1 (4%) | 0.5 (6%) | 0.2 (9%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (57%) | 0.1 (2%) | 1.7 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 67% (10 of 15) | 61% (14 of 23) | 63% (24 of 38) |
| the unit moved after it | 90% (9 of 10) | 57% (8 of 14) | 71% (17 of 24) |
| it charged on its next turn | 0% (0 of 10) | 7% (1 of 14) | 4% (1 of 24) |
| the enemy charged it first | 0% (0 of 10) | 7% (1 of 14) | 4% (1 of 24) |
| it fought by the end of its next turn | 0% (0 of 10) | 7% (1 of 14) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (1 of 10) | 14% (2 of 14) | 12% (3 of 24) |
| none of these (no charge, no fight, no charge escaped) | 90% (9 of 10) | 71% (10 of 14) | 79% (19 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (566 of 855) | 56% (448 of 805) | 61% (1014 of 1660) |
|   cavalry | 58% (42 of 73) | 60% (102 of 171) | 59% (144 of 244) |
|   character | 48% (48 of 101) | 31% (34 of 110) | 39% (82 of 211) |
|   chariot | 62% (61 of 98) | 55% (26 of 47) | 60% (87 of 145) |
|   infantry | 59% (152 of 256) | 57% (174 of 303) | 58% (326 of 559) |
|   monster | 45% (23 of 51) | 50% (20 of 40) | 47% (43 of 91) |
|   war machine | 87% (240 of 276) | 69% (92 of 134) | 81% (332 of 410) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (26%) | 2.2 (22%) | 4.3 (24%) |
| CHARGED: it charged | 1.1 (14%) | 1.6 (17%) | 2.8 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.5 (5%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.6 (20%) | 1.8 (18%) | 3.4 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (6%) | 0.5 (5%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (20%) | 2.3 (23%) | 3.9 (22%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (4%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.1 (1%) | 0.4 (4%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.1 | 1.6 | 82% | 5.7 pts | 35 pts |
| character | 2.3 | 0.9 | 73% | 9.6 pts | 22 pts |
| chariot | 2.4 | 1.7 | 67% | 13.5 pts | 33 pts |
| infantry | 12.4 | 5.1 | 69% | 9.4 pts | 117 pts |
| monster | 1.3 | 0.3 | 79% | 5.5 pts | 7 pts |
| war machine | 9.2 | 7.6 | 58% | 27.9 pts | 257 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.2 | 4.5 |
| Charges that made contact a game | 3.1 | 3.4 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.77 declared, 0.69 contact (26 units) | 0.64 declared, 0.55 contact (11 units) | 0.73 declared, 0.65 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.38 declared, 0.38 contact (8 units) | 0.92 declared, 0.75 contact (12 units) | 0.70 declared, 0.60 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.36 contact (248 units) | 0.60 declared, 0.38 contact (281 units) | 0.53 declared, 0.37 contact (529 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (45 of 73) | 50% (9 of 18) | 67% (8 of 12) | 60% (62 of 103) |
| Character in a unit | 66% (21 of 32) | 62% (10 of 16) | 50% (2 of 4) | 63% (33 of 52) |
| Character on its own | 78% (31 of 40) | 63% (24 of 38) | 29% (18 of 62) | 52% (73 of 140) |
| Chariot | 76% (13 of 17) | 54% (7 of 13) | - | 67% (20 of 30) |
| Infantry | 57% (54 of 94) | 53% (18 of 34) | 33% (1 of 3) | 56% (73 of 131) |
| Monster | 38% (11 of 29) | 100% (9 of 9) | - | 53% (20 of 38) |
| Monstrous | 50% (7 of 14) | 57% (8 of 14) | - | 54% (15 of 28) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (11 of 11); on the table 100% | 33% (34 of 102) | 52% | 55% (12 of 22) | 67% (4 of 6); 4.2 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 93% (13 of 14); on the table 93% | 50% (18 of 36) | 60% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (15 of 15); on the table 100% | - | 69% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 91% (10 of 11); on the table 100% | 29% (14 of 48) | 49% | 63% (48 of 76) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 87% (13 of 15); on the table 87% | 34% (47 of 138) | 46% | 39% (21 of 54) | 86% (12 of 14); 6.5 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (11 of 11); on the table 100% | 11% (2 of 18) | 23% | 61% (20 of 33) | 100% (3 of 3); 1.5 uses a game | 29% (4 of 14); 1.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (5 of 5); on the table 100% | - | 46% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 36% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (7 of 7); on the table 100% | 0% (0 of 18) | 46% | 82% (23 of 28) | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 50% (6 of 12) | 0% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 73% (8 of 11); on the table 91% | 22% (4 of 18) | 24% | 64% (16 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 100% (9 of 9); on the table 100% | - | 44% | 48% (12 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 93% (28 of 30); on the table 93% | 47% (31 of 66) | 25% | 76% (41 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 83% (25 of 30); on the table 87% | 56% (10 of 18) | 30% | 41% (30 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 77% (10 of 13); on the table 77% | 38% (9 of 24) | 40% | 67% (52 of 78) | 43% (3 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hc-opp-31c41bf-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (34) | 51% (37) | 48% (71) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.78 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.14 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.50 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.06 | 2.86 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.78 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.22 | 5.33 | 10.56 |

### Quality by phase: hc-opp-31c41bf-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 61% (74 of 121) | 40% (71 of 177) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (146 of 390) | 49% (133 of 274) |
| Strategy | Close-in objectives charged next turn | 12% (19 of 161) | 14% (30 of 209) |
| Strategy | Support requests answered (helper made contact too) | 50% (7 of 14) | 42% (14 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 41% (7 of 17) | 60% (6 of 10) |
| Strategy | Joined characters whose unit fought | 30% (14 of 46) | 48% (19 of 40) |
| Strategy | Lone characters that fought | 68% (67 of 99) | 71% (59 of 83) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.4 | 1.5 |
| Movement | Points that never moved of their own | 372.6 | 180.8 |
| Movement | Fights charged into per game | 2.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 89, net -87 | 27 of 91, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 89, net +128 | 20 of 91, net +193 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 89, net +86 | 5 of 91, net +174 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 89, net +79 | 17 of 91, net +93 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (132 of 350) | 45% (176 of 387) |
| Shooting | Points destroyed by shooting units | 126.1 | 56.8 |
| Shooting | War machine shots | 6.7 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (131 of 240) | 43% (40 of 92) |
| Shooting | Points destroyed by war machines | 97.5 | 42.1 |
| Magic | Magic missiles cast | 2.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (23 of 71) | 37% (13 of 35) |
| Magic | Wounds caused by magic missiles | 2.6 | 1.7 |
| Magic | Wounds caused by other spells | 1.5 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 54.9 | 33.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.1 | 1.8 / 0.3 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 305.1 | 347.6 |
| Combat | Points run down | 76.7 | 107.0 |
| Combat | Net points per charged fight, damage counted | +68 | +96 |
| Combat | Net per 100 charger points, damage counted | +27.9 | +35.5 |
| Combat | First round won (charged fights) | 77% | 64% |
| Combat | Net points per charged fight | +66 | +91 |
| Combat | Net points per supported fight / lone fight | +232 / +49 | +193 / +70 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 97 | 50 of 103 |
| Game | Points lost | 811.1 | 709.4 |
| Game | VP from objectives | 536.1 | 630.8 |
| Game | Lone holders (player turns) | 2.4 | 2.6 |

- Mine won / drew / lost: 12 / 5 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -223 VP
- The side that went first won 20 of 31 games with a winner
- Points traded per game (both sides' losses): 1521
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-opp-31c41bf-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.3 | -166.6 | 174.6 | 106.8 | 5.2 | -192.6 | 220.5 | 95.1 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +5.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 27.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +2.7 | 0.0 | 24.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| BEST FACING | 0.3 | +13.5 | 0.0 | 19.3 | 0.2 | +6.2 | 0.0 | 15.5 |
| BEST FIRST | 1.2 | +54.8 | 25.8 | 39.3 | 1.1 | +64.6 | 30.4 | 54.8 |
| BEST OVERALL | 0.3 | +19.0 | 0.0 | 13.6 | 0.3 | +22.9 | 0.0 | 16.0 |
| BEST PREY | 0.9 | +48.8 | 32.0 | 33.8 | 0.7 | +23.3 | 18.9 | 3.9 |
| BEST PRIZE | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -2.1 | 4.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.3 | 0.0 | 26.1 | 0.2 | -1.5 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | 0.0 | +0.3 | 0.0 | 7.1 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 21.7 | 0.0 |
| BLOCKED WHEEL | 0.3 | +10.0 | 0.0 | 6.5 | 0.7 | +7.9 | 0.0 | 16.6 |
| BLOWS WHERE AIMED | 0.2 | -12.8 | 22.9 | 4.2 | 0.3 | -43.3 | 32.1 | 26.9 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 154.0 | 10.3 | 0.2 | +0.0 | 11.9 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +185.6 | 531.2 | 118.1 | 1.9 | +84.7 | 86.4 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 5.8 | 0.0 | 0.2 | -3.5 | 37.8 | 12.1 |
| CAST JOB | 0.7 | +12.5 | 25.3 | 27.1 | 0.4 | +12.9 | 37.9 | 26.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +24.4 | 17.7 | 0.0 | 0.4 | +10.8 | 12.2 | 4.4 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 9.9 | 0.4 | +0.0 | 0.0 | 18.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +43.4 | 0.0 | 10.8 | 1.5 | +76.0 | 0.0 | 33.4 |
| CHAFF PASSED | 0.2 | -0.5 | 15.9 | 4.5 | 0.4 | -0.8 | 0.0 | 17.7 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 5.3 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 186.1 | 37.5 | 2.1 | +0.0 | 220.8 | 109.8 |
| CHARGE NOW WEIGHED | 0.3 | -29.9 | 13.9 | 12.8 | 0.5 | -53.0 | 48.5 | 38.8 |
| CHARGER SLAIN LOST | 0.5 | -12.9 | 27.8 | 26.4 | 0.7 | -25.9 | 61.0 | 28.3 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 1.7 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.8 | 0.1 | +0.0 | 4.6 | 0.9 |
| COMBAT PIVOT | 0.2 | +0.0 | 9.8 | 19.6 | 0.5 | +0.0 | 45.3 | 26.2 |
| CONVEYANCE SEARCH | 0.3 | +59.4 | 13.9 | 23.8 | 0.5 | +47.8 | 17.2 | 34.1 |
| COVER ONCE | 8.9 | -643.4 | 0.0 | 268.6 | 6.7 | -500.0 | 0.0 | 135.2 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 30.5 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +7.9 | 9.9 | 2.4 | 0.6 | +18.0 | 52.6 | 19.8 |
| ELIXIR WORTH | 0.0 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +116.5 | 0.0 | 81.1 | 1.1 | +76.6 | 0.0 | 49.1 |
| FALLBACK BY WORTH | 4.3 | +30.7 | 0.0 | 54.8 | 5.7 | +44.8 | 0.0 | 99.1 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.7 | 0.0 | 3.1 | - | - | - | - |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 158.4 | 4.7 | +0.0 | 0.0 | 147.4 |
| FOCUS FIRE | 0.1 | +4.9 | 3.1 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +128.9 | 0.0 | 55.4 | 0.7 | +74.7 | 0.0 | 6.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.7 | 0.0 | 3.4 | 0.2 | +7.2 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.2 | 0.0 | 11.0 | 0.2 | -0.6 | 29.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.2 | 3.5 | 3.2 | 0.1 | -0.1 | 8.6 | 0.0 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 6.5 | 1.2 | 0.1 | +0.0 | 12.9 | 0.8 |
| HELPER UNSEEN | 0.2 | +0.0 | 9.8 | 13.1 | 0.2 | +0.0 | 22.6 | 9.8 |
| HILL BY ITS CHANCE | 0.4 | -53.4 | 0.0 | 5.1 | 0.6 | -67.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.3 | -112.2 | 308.1 | 112.6 | 5.7 | -126.7 | 387.5 | 169.4 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.6 | 0.0 | 1.4 | 0.6 | +6.9 | 24.3 | 5.8 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 31.2 | 3.8 |
| HUNT IN PAIRS | 0.4 | +18.2 | 0.0 | 0.0 | 0.6 | +45.3 | 0.0 | 51.8 |
| HUNT KEPT | 0.1 | +0.5 | 0.0 | 8.3 | 0.3 | +5.7 | 22.2 | 2.9 |
| HUNT RESULT | 0.1 | +3.4 | 5.4 | 1.4 | 0.5 | +48.5 | 44.0 | 8.5 |
| HUNT THE GUNS | 0.1 | +23.0 | 3.3 | 2.9 | 0.6 | +153.7 | 24.7 | 7.6 |
| IDLE COST | 15.8 | -249.2 | 0.0 | 199.4 | 19.7 | -310.3 | 0.0 | 252.0 |
| INVITES THE FIGHT | 1.2 | +10.3 | 49.2 | 28.1 | 0.9 | +8.0 | 93.3 | 1.8 |
| JOINT CHARGE PLAN | 0.1 | +1.4 | 0.0 | 0.0 | 0.3 | +18.9 | 33.1 | 22.5 |
| JOINT KNOWS CHALLENGE | 0.1 | -4.4 | 25.7 | 0.0 | 0.2 | -6.5 | 48.1 | 42.8 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.1 | 3.1 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 129.3 | 58.1 | 1.9 | +55.8 | 171.7 | 78.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.5 | +54.5 | 89.7 | 26.8 | 2.1 | +81.1 | 183.4 | 38.6 |
| KILLS COUNT NEXT TURN | 4.9 | +187.4 | 137.4 | 131.1 | 3.2 | +122.2 | 145.1 | 67.6 |
| LONE CHARACTER SAFE SPOT | 0.3 | +12.5 | 2.2 | 13.9 | 0.2 | +5.0 | 4.6 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 8.1 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -1.8 | 14.1 | 5.1 | 0.6 | +1.3 | 21.3 | 13.9 |
| LOST CHARGE | 2.7 | -48.1 | 90.4 | 110.6 | 2.2 | -38.9 | 101.1 | 61.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.2 | 0.0 | 1.1 | 0.1 | -6.1 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 0.2 | +5.3 | 0.0 | 1.7 | 1.1 | +145.8 | 54.9 | 41.0 |
| MANOEUVRE | 0.3 | +9.0 | 0.0 | 0.9 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +23.6 | 0.0 | 11.0 | 0.3 | +7.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +6.5 | 3.5 | 0.0 | 0.1 | +8.3 | 12.1 | 5.7 |
| MARCH OVER CASTS | 0.6 | +33.0 | 0.0 | 23.1 | 0.2 | +23.2 | 0.0 | 22.6 |
| MAX FOR POSITIONING | 6.6 | +93.6 | 0.0 | 167.5 | 5.9 | +64.3 | 0.0 | 147.3 |
| MEASURED NEXT CHARGE | - | - | - | - | 11.1 | -278.8 | 362.5 | 366.4 |
| MISSILES IN THE MOVE | 4.2 | +100.5 | 0.0 | 140.2 | 3.0 | +70.2 | 0.0 | 77.5 |
| MISSILES NEXT TURN | 4.8 | +65.5 | 0.0 | 169.9 | 3.6 | +42.7 | 0.0 | 116.6 |
| MODEL FACING | 0.3 | +77.0 | 0.0 | 0.0 | 0.3 | +111.1 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 10.4 | 0.0 | 0.1 | +0.0 | 19.9 | 0.0 |
| MOVE AND CAST | 0.4 | +7.6 | 0.0 | 6.9 | 0.2 | +7.5 | 0.0 | 10.5 |
| MOVE SPELL IN RANGE | 0.1 | +5.5 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -21.7 | 0.0 | 0.0 | 0.3 | -8.7 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.9 | +138.4 | 87.5 | 104.3 | 1.5 | +8.7 | 52.7 | 29.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +10.1 | 0.0 | 0.0 | 0.0 | +3.7 | 3.2 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -5.5 | 16.4 | 2.1 | 0.4 | -10.2 | 36.4 | 2.6 |
| NOT TURNED | 5.2 | +74.6 | 0.0 | 142.1 | 5.3 | +9.1 | 0.0 | 122.9 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 11.0 | 0.6 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 16.5 | -660.4 | 7.2 | 291.0 | 17.2 | -839.3 | 17.4 | 268.6 |
| ONE FIGHT FORMULA | 9.3 | -170.1 | 40.5 | 257.8 | 8.2 | -172.6 | 68.5 | 249.6 |
| ONE OBJECTIVE FORMULA | 1.9 | -101.7 | 0.0 | 28.1 | 2.5 | -127.5 | 0.0 | 32.2 |
| OPENS A LANE | 0.1 | +1.0 | 13.5 | 3.5 | 0.1 | +0.7 | 10.4 | 0.0 |
| OPENS UP | 0.1 | +5.0 | 0.0 | 0.0 | 0.1 | +1.2 | 11.1 | 0.0 |
| OVERRUNS AWAY | 0.3 | +2.6 | 33.1 | 11.1 | 0.3 | +2.5 | 25.8 | 16.4 |
| PATHS CROSS | 2.2 | +148.2 | 0.0 | 18.1 | 2.8 | +149.3 | 0.0 | 96.4 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 9.8 | 0.1 | -2.5 | 0.0 | 1.9 |
| PLAN RESULT | 37.4 | +1573.4 | 1415.7 | 1088.1 | 41.3 | +1292.2 | 1697.6 | 1029.5 |
| PURSUES BIG PREY | 0.1 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| PURSUES ON | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.1 | +4.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +5.2 | 0.0 | 25.1 | 1.6 | +47.5 | 0.0 | 41.5 |
| RANDOM MOVER NO PROMISE | 0.2 | -8.6 | 1.5 | 0.0 | 0.1 | -1.5 | 7.3 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -13.9 | 0.0 | 8.5 | 1.1 | -26.8 | 0.0 | 24.4 |
| REDIRECT COUNTER | 2.3 | +122.8 | 0.0 | 50.8 | 3.7 | +296.6 | 0.0 | 73.2 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.8 | 0.4 | +2.0 | 5.7 | 0.0 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 8.9 | 0.4 | +0.0 | 0.0 | 34.6 |
| RESERVE FALL BACK | 0.2 | +1.8 | 0.0 | 0.0 | 1.3 | +27.3 | 0.0 | 42.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +4.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +71.5 | 168.3 | 61.9 | 2.9 | +56.2 | 274.5 | 94.5 |
| RISK ONCE | 4.2 | +213.3 | 26.2 | 193.7 | 3.3 | +109.7 | 95.4 | 220.2 |
| RUN DOWN | - | - | - | - | 2.1 | -6.5 | 155.2 | 69.0 |
| SAFE SURE CHARGE | 0.0 | -0.7 | 1.1 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +47.7 | 0.0 | 34.1 | 0.8 | +46.4 | 0.0 | 16.0 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -5.4 | 0.0 | 1.2 | 0.5 | -31.8 | 0.0 | 6.5 |
| SEARCH SPOT | 2.3 | +93.2 | 0.0 | 16.5 | 2.6 | +101.4 | 0.0 | 53.9 |
| SECOND HUNTER | - | - | - | - | 0.2 | -0.9 | 10.0 | 6.6 |
| SELF MOVE SPELL | 0.3 | +1.4 | 0.0 | 21.9 | - | - | - | - |
| SET UP TOGETHER | 0.4 | +14.4 | 0.0 | 4.8 | 2.7 | +237.7 | 117.6 | 102.8 |
| SET-UP ANY TARGET | 0.1 | +13.2 | 13.9 | 13.9 | 0.1 | +28.5 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +32.1 | 29.8 | 16.9 | 0.9 | +42.0 | 30.3 | 40.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 162.9 | 18.7 | 0.3 | +0.0 | 33.8 | 0.0 |
| SHOTS IN THE MOVE | 13.9 | +570.8 | 0.0 | 290.2 | 11.6 | +367.9 | 0.0 | 141.6 |
| SPELL SETS UP CHARGE | 0.2 | +42.1 | 13.9 | 13.9 | 0.2 | +36.0 | 0.0 | 7.6 |
| SPELL WORTH | 0.7 | +17.6 | 118.4 | 115.1 | 1.4 | +24.7 | 93.8 | 93.8 |
| SPELLS IN THE FIGHT | 0.6 | +4.7 | 60.8 | 19.6 | 0.6 | -12.0 | 66.6 | 14.3 |
| STABLE ROLE | 11.8 | +0.0 | 336.7 | 160.4 | 11.8 | +0.0 | 363.7 | 153.1 |
| STAY WEIGHED | - | - | - | - | 0.1 | +5.8 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.6 | 3.3 | 4.6 | 0.2 | +9.8 | 18.1 | 4.6 |
| STOPS SHORT OF THE FLANK | 0.4 | +6.9 | 0.0 | 35.8 | 0.4 | +20.5 | 0.0 | 12.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 6.9 | -63.8 | 346.4 | 136.8 | 7.6 | -68.5 | 428.5 | 82.1 |
| SUPPORTS | 4.9 | +63.8 | 229.5 | 73.8 | 5.3 | +76.0 | 237.3 | 42.3 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.0 | 4.4 | 1.7 | 0.1 | -2.4 | 16.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.6 | 0.0 | 6.5 | 1.0 | +2.4 | 9.6 | 14.5 |
| THROUGH LINE OF FIRE | 0.3 | +5.8 | 0.0 | 0.0 | 0.4 | +24.6 | 0.0 | 1.8 |
| TURN WORTH | 0.3 | -25.5 | 35.7 | 0.0 | 0.2 | -10.6 | 18.1 | 5.2 |
| TWO OR MORE ARRIVE | 0.1 | +0.5 | 0.0 | 1.4 | 0.6 | +4.5 | 37.6 | 37.2 |
| WAIT AFTER COSTS | 6.4 | -294.6 | 201.9 | 169.7 | 3.7 | -175.1 | 164.8 | 60.7 |
| WALKS TO THE FIGHT | 1.6 | +12.7 | 65.5 | 10.3 | 1.6 | +9.0 | 18.7 | 29.1 |
| WAR ENGINE CHARGES | 0.1 | +6.2 | 2.9 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 6.6 | 25.1 | 0.3 | +0.0 | 22.6 | 14.3 |
| WEARS DOWN | 0.9 | +34.8 | 104.3 | 30.8 | 1.2 | +43.2 | 146.8 | 96.6 |
| WHO HITS BACK | 0.2 | +7.1 | 0.0 | 8.0 | 0.3 | +15.3 | 0.0 | 21.3 |
| WHOLE FIGHT | 0.1 | +0.9 | 4.9 | 0.0 | 0.2 | -11.8 | 23.6 | 16.1 |
| WHOLE FIGHT GAIN | 0.4 | +22.7 | 35.1 | 11.2 | 0.8 | +53.4 | 77.7 | 25.8 |
| WIDER SPREAD | 2.2 | -6.6 | 143.8 | 41.3 | 3.4 | -3.0 | 306.4 | 77.6 |

### Rule changes: hc-opp-31c41bf-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1215 | 1215 | 1215 | 33.75 | -53987 | -44.4 |
| PATHS CROSS | 178 | 178 | 178 | 4.94 | +10709 | +60.2 |
| SEARCH SPOT | 178 | 178 | 170 | 4.72 | +7007 | +41.2 |
| SUPPORTS | 369 | 369 | 155 | 4.31 | +1764 | +11.4 |
| KILLS COUNT NEXT TURN | 290 | 290 | 107 | 2.97 | +3315 | +31.0 |
| FACES THE THREAT | 103 | 103 | 103 | 2.86 | +6954 | +67.5 |
| SHOTS IN THE MOVE | 918 | 619 | 87 | 2.42 | +2425 | +27.9 |
| BEST FIRST | 82 | 82 | 82 | 2.28 | +4299 | +52.4 |
| COVER ONCE | 562 | 338 | 82 | 2.28 | +1166 | +14.2 |
| MOVE TO CHARGE | 158 | 158 | 82 | 2.28 | +1226 | +14.9 |
| FALLBACK BY WORTH | 362 | 362 | 74 | 2.06 | +2719 | +36.7 |
| ADVANCE WORTH | 380 | 380 | 73 | 2.03 | +2031 | +27.8 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 67 | 67 | 67 | 1.86 | +7331 | +109.4 |
| MISSILES IN THE MOVE | 261 | 171 | 64 | 1.78 | +1296 | +20.2 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +3388 | +55.5 |
| ONE FIGHT FORMULA | 633 | 377 | 59 | 1.64 | +287 | +4.9 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| MEASURED NEXT CHARGE | 400 | 298 | 56 | 1.56 | +540 | +9.6 |
| SET UP TOGETHER | 113 | 90 | 56 | 1.56 | +4013 | +71.7 |
| WAIT AFTER COSTS | 361 | 361 | 56 | 1.56 | +689 | +12.3 |
| IDLE COST | 1276 | 721 | 53 | 1.47 | +559 | +10.5 |
| RESERVE FALL BACK | 52 | 52 | 52 | 1.44 | +1045 | +20.1 |
| WALKS TO THE FIGHT | 116 | 116 | 49 | 1.36 | +242 | +4.9 |
| CHAFF IN THE MOVE | 82 | 79 | 48 | 1.33 | +1348 | +28.1 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 42 | 1.17 | +1897 | +45.2 |
| SHOT REPLANNED | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK ONCE | 270 | 184 | 41 | 1.14 | +1996 | +48.7 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| REDIRECT COUNTER | 215 | 92 | 40 | 1.11 | +3227 | +80.7 |
| CANNON PLANNED TARGET | 250 | 250 | 37 | 1.03 | -484 | -13.1 |
| BLOCKED WHEEL | 36 | 36 | 36 | 1.00 | +644 | +17.9 |
| RISK BY ARC | 181 | 175 | 34 | 0.94 | +1138 | +33.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| MARCH CHECK | 34 | 34 | 33 | 0.92 | +1412 | +42.8 |
| MAX FOR POSITIONING | 450 | 268 | 32 | 0.89 | +118 | +3.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 85 | 85 | 32 | 0.89 | +1005 | +31.4 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +3471 | +112.0 |
| INVITES THE FIGHT | 76 | 76 | 29 | 0.81 | +275 | +9.5 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +986 | +34.0 |
| KILLS COUNT | 129 | 126 | 28 | 0.78 | +1097 | +39.2 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1094 | +39.1 |
| COMBAT PIVOT | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| CHAFF PASSED | 23 | 23 | 23 | 0.64 | -44 | -1.9 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +543 | +23.6 |
| WHOLE FIGHT GAIN | 43 | 40 | 23 | 0.64 | +785 | +34.1 |
| BEST OVERALL | 22 | 22 | 22 | 0.61 | +1507 | +68.5 |
| MODEL FACING | 21 | 21 | 21 | 0.58 | +6773 | +322.5 |
| CASTING BLOCK | 27 | 27 | 20 | 0.56 | +701 | +35.1 |
| HONEST WORTH | 469 | 465 | 20 | 0.56 | +113 | +5.7 |
| MAKE SURE TOGETHER | 48 | 34 | 20 | 0.56 | +2240 | +112.0 |
| CHARGE NOW FIRST | 148 | 148 | 19 | 0.53 | -753 | -39.7 |
| BEST FACING | 18 | 18 | 18 | 0.50 | +707 | +39.3 |
| BEST PREY | 58 | 58 | 18 | 0.50 | +659 | +36.6 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| KEEPS ITS TARGET | 121 | 120 | 16 | 0.44 | +297 | +18.5 |
| REDIRECT WEIGHED | 16 | 16 | 16 | 0.44 | +1237 | +77.3 |
| WAR ENGINE JOBS | 35 | 35 | 16 | 0.44 | -646 | -40.4 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +452 | +28.3 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| HUNT IN PAIRS | 35 | 22 | 15 | 0.42 | +650 | +43.4 |
| WEARS DOWN | 78 | 75 | 15 | 0.42 | +597 | +39.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| REFUSING RETIRES | 31 | 31 | 13 | 0.36 | -3 | -0.2 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +430 | +35.9 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -43 | -3.9 |
| CAST JOB | 40 | 40 | 11 | 0.31 | +320 | +29.1 |
| SUPPORT NARROWED | 520 | 520 | 11 | 0.31 | -194 | -17.6 |
| MANOEUVRE | 12 | 12 | 9 | 0.25 | +348 | +38.6 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +135 | +15.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE REACH TOGETHER | 48 | 35 | 8 | 0.22 | +51 | +6.4 |
| MISSILES NEXT TURN | 301 | 185 | 7 | 0.19 | +14 | +2.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -124 | -17.7 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| EDGE GIVE GROUND | 25 | 24 | 6 | 0.17 | +320 | +53.3 |
| LOST CHARGE | 177 | 177 | 6 | 0.17 | +286 | +47.6 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -132 | -22.0 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -159 | -31.9 |
| DEFENSIVE ARMY | 13 | 13 | 5 | 0.14 | -188 | -37.6 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 5 | 0.14 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 159 | 75 | 5 | 0.14 | +115 | +23.1 |
| WIDER SPREAD | 200 | 191 | 5 | 0.14 | +28 | +5.6 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +161 | +40.2 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +25 | +8.3 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +189 | +63.0 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +121 | +40.4 |
| SAFE SURE CHARGE | 3 | 3 | 3 | 0.08 | -67 | -22.2 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +208 | +69.5 |
| WHOLE FIGHT | 14 | 14 | 3 | 0.08 | +107 | +35.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| JOINT CHARGE PLAN | 14 | 14 | 2 | 0.06 | +116 | +58.1 |
| LONG SHOT | 41 | 39 | 2 | 0.06 | +34 | +17.1 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 24 | 23 | 2 | 0.06 | +8 | +4.0 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -88 | -44.1 |
| RUN DOWN | 74 | 71 | 2 | 0.06 | +3 | +1.4 |
| SPELLS IN THE FIGHT | 45 | 43 | 2 | 0.06 | +70 | +34.9 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +53 | +26.7 |
| BACKUP TARGETS | 37 | 21 | 1 | 0.03 | +0 | +0.0 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +11 | +11.3 |
| BLOWS WHERE AIMED | 18 | 15 | 1 | 0.03 | +121 | +121.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +21 | +21.2 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -126 | -126.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -1 | -0.7 |
| CHARGER SLAIN LOST | 45 | 41 | 1 | 0.03 | +79 | +78.6 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -9 | -9.3 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +10 | +10.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +167 | +166.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| HUNT ADVANCE | 24 | 24 | 1 | 0.03 | +40 | +39.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +39 | +39.2 |
| MOVE SPELL IN RANGE | 5 | 4 | 1 | 0.03 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +41 | +41.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +73 | +73.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +1 | +1.3 |
| STOPS | 11 | 11 | 1 | 0.03 | +9 | +9.3 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 28 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 343 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 15 | 14 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 35 | 35 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 16 | trace | - | - | - | - |
| HUNT RESULT | 22 | trace | - | - | - | - |
| HUNT THE GUNS | 24 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 12 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 380 | 380 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 5 | 0 | 0.00 | - | - |
| OPENS UP | 7 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2834 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 60 | 60 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SECOND HUNTER | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 10 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 78 | not checked | - | - | - | - |
| STABLE ROLE | 850 | 848 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 28 | 26 | 0 | 0.00 | - | - |

### Off best figure: hc-opp-31c41bf-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.97 | 15.47 | 45.5 |
| FALLBACK | gate | 0.56 | 0.86 | 45.8 |
| TURN GATE | gate | 0.42 | 0.50 | 25.7 |
| CHARGE NOW FIRST | rule | 0.25 | 0.28 | 39.7 |
| WAR ENGINE JOBS | rule | 0.36 | 0.08 | 40.4 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.08 | 37.7 |
| CHAFF PASSED | rule | 0.11 | 0.19 | 4.0 |
| SUPPORT NARROWED | rule | 0.22 | 0.08 | 17.6 |
| AFTERMATH BAND | gate | 0.17 | 0.08 | 3.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.08 | 16.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 75.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.14 | 17.7 |
| FIGHT ORDER BAND | gate | 0.14 | 0.03 | 1.8 |
| PATHS CROSS | rule | 0.08 | 0.08 | 11.0 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.11 | 22.0 |
| BEST PRIZE | rule | 0.03 | 0.11 | 31.9 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.11 | 10.7 |
| DEFENSIVE ARMY | rule | 0.08 | 0.06 | 37.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.11 | 10.7 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 12.4 |
| SAFE SURE CHARGE | rule | 0.03 | 0.06 | 22.2 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 6.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 48.6 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.5 |
| PURSUES BIG PREY | rule | 0.06 | - | 44.1 |
| REFUSING RETIRES | rule | 0.06 | - | 0.8 |
| BLOCKED WHEEL | rule | - | 0.03 | 7.2 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 126.4 |
| CATCH ODDS | rule | - | 0.03 | 0.7 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 9.3 |
| FALLBACK BY WORTH | rule | - | 0.03 | 72.9 |
| MARCH ODDS | rule | 0.03 | - | 4.6 |
| NO REASON | gate | - | 0.03 | 5.0 |
| REDIRECT WEIGHED | rule | - | 0.03 | 1.1 |
| RULE SWITCHED OFF | gate | 0.03 | - | 22.8 |
| WHO HITS BACK | rule | 0.03 | - | 2.5 |

### Plans: hc-opp-31c41bf-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.5 | 19% | 225 | 257 | 114% |
| Mine | charge | 2.9 | 58% | 212 | 216 | 102% |
| Mine | close in | 4.5 | 22% | 187 | 145 | 77% |
| Mine | hold | 5.0 | 28% | 305 | 0 | 0% |
| Mine | join | 0.6 | 96% | 21 | 0 | 0% |
| Mine | shoot | 9.3 | 66% | 309 | 956 | 310% |
| Mine | support | 5.7 | 91% | 44 | 0 | 0% |
| Opponent | advance | 13.2 | 17% | 194 | 322 | 166% |
| Opponent | charge | 4.3 | 61% | 303 | 454 | 150% |
| Opponent | close in | 5.8 | 26% | 322 | 164 | 51% |
| Opponent | hold | 4.4 | 43% | 325 | 0 | 0% |
| Opponent | join | 0.9 | 100% | 41 | 0 | 0% |
| Opponent | shoot | 5.9 | 55% | 194 | 353 | 181% |
| Opponent | support | 6.7 | 91% | 66 | 0 | 0% |

### Packages: hunt the guns, hc-opp-31c41bf-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 67% | 33% | 0% | 2.0 | 210 | 41 | 33% | 38 |
| Opponent | 0.6 | 20 | 1 | 16% | 42% | 0% | 2.6 | 287 | 92 | 32% | 152 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 50% | 0% | 2.0 | 199 | 61 | 50% | 118 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 100% | 0% | 5.0 | 244 | 110 | 0% | 123 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 206 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 1 | 67% | 67% | 0% | 3.0 | 590 | 276 | 33% | 197 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 2.0 | 10 | 1 | 11% | 33% | 0% | 2.0 | 123 | 41 | 33% | 39 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 116 |
| Wood Elf Realms | 0.6 | 4 | 0 | 0% | 50% | 0% | 2.0 | 350 | 111 | 50% | 0 |

### Battle groups: hc-opp-31c41bf-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 33% | 70% | 15% | 25% | 9% | 0% | 13% | 78% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 26% | 68% | 12% | 0% | 13% | 3% | 10% | 70% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-opp-31c41bf-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.8 | 0 (2) | 0 (3) | - | - | 0 (5) |
| Mine | Chaff | 34 | 71 (34) | 34 | 37 | 59 | 47% | 2.8 | 49 (19) | 202 (7) | 5 (8) | 94 (23) | 18 (11) |
| Mine | Character | 123 | 48 (123) | 47 | 1 | 38 | 23% | 2.6 | 44 (38) | 59 (54) | 42 (14) | 71 (51) | 32 (55) |
| Mine | Clean-up | 21 | 38 (21) | 6 | 32 | 75 | 43% | 2.8 | 18 (5) | 34 (13) | 116 (3) | 75 (13) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 52 (48) | 30 | 22 | 49 | 21% | 2.8 | 57 (23) | 65 (16) | 0 (9) | 62 (29) | 38 (19) |
| Mine | Fragile | 5 | 36 (5) | 36 | 0 | 80 | 0% | 2.0 | - | 0 (3) | 89 (2) | 36 (5) | - |
| Mine | Hammer | 57 | 23 (57) | 13 | 10 | 41 | 28% | 2.3 | 5 (18) | 32 (29) | 33 (10) | 24 (38) | 22 (19) |
| Mine | Holder | 28 | 53 (28) | 8 | 45 | 41 | 36% | 3.1 | 20 (10) | 101 (10) | 27 (8) | 62 (19) | 35 (9) |
| Mine | Shooter | 41 | 95 (41) | 48 | 47 | 40 | 2% | 1.4 | 96 (5) | 107 (30) | 36 (6) | 114 (25) | 65 (16) |
| Mine | Support | 2 | 78 (2) | 78 | 0 | 66 | 0% | 4.0 | - | 78 (2) | - | - | 78 (2) |
| Mine | War machine | 59 | 76 (59) | 76 | 0 | 52 | 3% | 1.2 | 70 (10) | 72 (37) | 94 (12) | 0 (10) | 91 (49) |
| Mine | Wizard | 22 | 17 (22) | 17 | 0 | 34 | 14% | 2.3 | 0 (6) | 47 (8) | 0 (5) | 12 (7) | 23 (12) |
| Opponent | Blocker | 2 | 85 (2) | 85 | 0 | 100 | 0% | 5.0 | 137 (1) | 0 (1) | - | 85 (2) | - |
| Opponent | Chaff | 76 | 58 (76) | 36 | 22 | 53 | 38% | 2.7 | 75 (32) | 60 (19) | 33 (25) | 83 (54) | 2 (22) |
| Opponent | Character | 97 | 55 (97) | 55 | 0 | 39 | 23% | 2.6 | 64 (42) | 58 (41) | 12 (5) | 54 (61) | 65 (27) |
| Opponent | Clean-up | 19 | 13 (19) | 12 | 1 | 47 | 32% | 3.4 | 0 (9) | 34 (10) | - | 17 (14) | 0 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 29 (48) | 23 | 6 | 34 | 23% | 2.7 | 35 (22) | 16 (16) | 39 (10) | 28 (28) | 32 (20) |
| Opponent | Fragile | 5 | 177 (5) | 177 | 0 | 58 | 20% | 4.2 | - | 230 (4) | 0 (1) | 272 (3) | 0 (2) |
| Opponent | Hammer | 70 | 34 (70) | 28 | 5 | 41 | 23% | 3.0 | 25 (17) | 39 (42) | 18 (11) | 37 (43) | 29 (27) |
| Opponent | Holder | 35 | 99 (35) | 8 | 91 | 18 | 43% | 2.9 | 142 (5) | 103 (23) | 72 (6) | 121 (23) | 58 (11) |
| Opponent | Shooter | 33 | 84 (33) | 11 | 73 | 21 | 3% | 1.8 | 52 (8) | 111 (19) | 27 (6) | 119 (22) | 28 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 48 (24) | 48 | 0 | 13 | 8% | 1.5 | 36 (6) | 43 (14) | 78 (4) | 0 (3) | 56 (21) |
| Opponent | Wizard | 26 | 13 (26) | 13 | 0 | 59 | 8% | 1.8 | 0 (10) | 53 (6) | 11 (6) | 43 (6) | 2 (16) |

### Charged fights: hc-opp-31c41bf-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 192 | 85 | 1.5 | 1.0 | 57 | 5 | +52 | 1 of 6 | 4 of 6 | - | +52 |
| Mine | Chaos Dwarfs | 4 | 248 | 469 | 2.8 | 1.3 | 171 | 0 | +171 | 4 of 11 | 9 of 11 | +384 | +123 |
| Mine | Dwarfen Mountain Holds | 4 | 929 | 112 | 2.0 | 1.0 | 56 | 8 | +49 | 0 of 8 | 8 of 8 | - | +49 |
| Mine | Empire of Man | 5 | 458 | 156 | 1.8 | 1.1 | 87 | 63 | +24 | 2 of 9 | 8 of 9 | +210 | +0 |
| Mine | Grand Cathay | 4 | 289 | 507 | 2.5 | 1.2 | 203 | 67 | +136 | 4 of 10 | 7 of 10 | +990 | +41 |
| Mine | High Elf Realms | 4 | 132 | 627 | 3.2 | 1.1 | 193 | 55 | +138 | 6 of 13 | 11 of 13 | -18 | +151 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 170 | 3.0 | 1.0 | 57 | 36 | +21 | 0 of 3 | 3 of 3 | - | +21 |
| Mine | Lizardmen | 1 | 45 | 287 | 2.0 | 1.0 | 144 | 0 | +144 | 1 of 2 | 1 of 2 | - | +144 |
| Mine | Ogre Kingdoms | 1 | 186 | 45 | 6.0 | 1.0 | 8 | 6 | +2 | 2 of 6 | 4 of 5 | - | +2 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 289 | 5.0 | 1.2 | 58 | 0 | +58 | 0 of 5 | 4 of 5 | +45 | +61 |
| Mine | Skaven | 2 | 116 | 0 | 3.0 | 1.2 | 0 | 232 | -232 | 2 of 6 | 1 of 6 | -130 | -252 |
| Mine | Tomb Kings of Khemri | 1 | 110 | 947 | 6.0 | 1.2 | 158 | 20 | +138 | 1 of 6 | 6 of 6 | +140 | +137 |
| Mine | Vampire Counts | 3 | 0 | 233 | 3.7 | 1.3 | 64 | 27 | +36 | 2 of 11 | 7 of 10 | +80 | +32 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 36 | 278 | 289 | 2.7 | 1.1 | 107 | 41 | +66 | 25 of 97 | 73 of 95 | +232 | +49 |
| Opponent | Dwarfen Mountain Holds | 2 | 264 | 160 | 3.5 | 1.7 | 46 | 0 | +46 | 0 of 7 | 6 of 7 | +59 | +28 |
| Opponent | Empire of Man | 2 | 365 | 55 | 0.5 | 1.0 | 110 | 0 | +110 | 0 of 1 | 1 of 1 | - | +110 |
| Opponent | Grand Cathay | 2 | 613 | 1046 | 3.0 | 1.3 | 349 | 0 | +349 | 5 of 6 | 6 of 6 | +654 | +196 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| Opponent | Ogre Kingdoms | 3 | 0 | 333 | 3.7 | 1.2 | 91 | 47 | +44 | 5 of 11 | 2 of 11 | -134 | +84 |
| Opponent | Skaven | 1 | 425 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 173 | 479 | 2.5 | 1.2 | 192 | 145 | +46 | 6 of 10 | 4 of 10 | +506 | -69 |
| Opponent | Vampire Counts | 6 | 63 | 281 | 3.8 | 1.2 | 73 | 45 | +29 | 14 of 23 | 17 of 23 | +188 | -5 |
| Opponent | Warriors of Chaos | 8 | 0 | 350 | 2.2 | 1.1 | 155 | 0 | +155 | 5 of 18 | 14 of 18 | +264 | +149 |
| Opponent | Wood Elf Realms | 7 | 89 | 503 | 3.6 | 1.1 | 141 | 49 | +91 | 13 of 25 | 15 of 25 | +58 | +96 |
| **Opponent** | all armies | 36 | 133 | 378 | 2.9 | 1.2 | 132 | 41 | +91 | 50 of 103 | 66 of 103 | +193 | +70 |

### Effective charges: hc-opp-31c41bf-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +55) | 0 | 0 | 3 (net +77) | 0 | 1 (net +55) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 11 | 1 (net +516) | 0 | 1 (net +0) | 4 (net +277) | 1 (net +45) | 4 (net +52) | 0 | 9% (1 of 11) |
| Mine | Dwarfen Mountain Holds | 8 | 0 | 0 | 2 (net +155) | 4 (net -15) | 0 | 2 (net +70) | 0 | 25% (2 of 8) |
| Mine | Empire of Man | 9 | 0 | 0 | 3 (net -45) | 0 | 3 (net +1) | 3 (net +116) | 0 | 33% (3 of 9) |
| Mine | Grand Cathay | 10 | 1 (net -233) | 0 | 2 (net +495) | 1 (net +274) | 1 (net +111) | 5 (net +44) | 0 | 20% (2 of 10) |
| Mine | High Elf Realms | 13 | 1 (net -395) | 0 | 4 (net +206) | 3 (net +202) | 3 (net +178) | 0 | 2 | 36% (4 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +32) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 2 | 1 (net +233) | 0 | 0 | 1 (net +54) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 6 | 3 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +45) | 0 | 1 | 20% (1 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 2 (net +118) | 0 | 0 | 0 | 3 | 100% (2 of 2) |
| Mine | Skaven | 6 | 4 (net -348) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 17% (1 of 6) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +0) | 0 | 1 (net +125) | 4 (net +175) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 11 | 2 (net +0) | 0 | 1 (net +205) | 3 (net +42) | 2 (net +82) | 2 (net +79) | 1 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 7 | 2 (net +0) | 0 | 2 (net +84) | 2 (net +32) | 0 | 1 (net +85) | 0 | 29% (2 of 7) |
| Opponent | Empire of Man | 1 | 1 (net +110) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 6 | 1 (net +745) | 0 | 2 (net +626) | 2 (net +48) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 11 | 3 (net +110) | 1 (net +0) | 0 | 3 (net -33) | 0 | 0 | 4 | 0% (0 of 7) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 10 | 5 (net -41) | 0 | 2 (net +155) | 2 (net +98) | 0 | 0 | 1 | 22% (2 of 9) |
| Opponent | Vampire Counts | 23 | 4 (net -147) | 0 | 4 (net +228) | 7 (net -39) | 3 (net +201) | 3 (net +0) | 2 | 19% (4 of 21) |
| Opponent | Warriors of Chaos | 18 | 3 (net +129) | 0 | 4 (net +215) | 2 (net +105) | 2 (net +132) | 6 (net +150) | 1 | 24% (4 of 17) |
| Opponent | Wood Elf Realms | 25 | 7 (net +120) | 1 (net +666) | 6 (net +58) | 2 (net +360) | 0 | 5 (net +81) | 4 | 29% (6 of 21) |

### Charged fights, damage counted: hc-opp-31c41bf-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 142 | 205 | -87 | 85 | 187 | -102 | -71.9 |
| Mine | Effective (55-75%) | 19 | 251 | 179 | +128 | 169 | 38 | +131 | +52.1 |
| Mine | 76-89% | 20 | 257 | 155 | +117 | 140 | 7 | +133 | +51.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 215 | 136 | +79 | 117 | 28 | +90 | +41.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 392 | 87 | +86 | 131 | 70 | +61 | +15.6 |
| Mine | No odds | 8 | 217 | 154 | -5 | 43 | 51 | -8 | -3.8 |
| Mine | All fights | 97 | 242 | 154 | +66 | 123 | 56 | +68 | +27.9 |
| Opponent | Long shot (under 50%) | 27 | 243 | 273 | +60 | 174 | 116 | +59 | +24.2 |
| Opponent | 50-54% | 2 | 364 | 250 | +333 | 393 | 0 | +393 | +108.2 |
| Opponent | Effective (55-75%) | 20 | 278 | 234 | +193 | 227 | 30 | +196 | +70.7 |
| Opponent | 76-89% | 20 | 236 | 182 | +46 | 112 | 55 | +57 | +24.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 333 | 207 | +93 | 113 | 15 | +98 | +29.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 506 | 122 | +174 | 186 | 17 | +168 | +33.3 |
| Opponent | No odds | 12 | 177 | 243 | -8 | 107 | 113 | -6 | -3.6 |
| Opponent | All fights | 103 | 271 | 225 | +91 | 159 | 63 | +96 | +35.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-opp-31c41bf-p2 | move | 372 | 84 (23%) | 69 (19%) | 48 (13%) | 240 (65%) |
| hc-opp-31c41bf-p2 | objective | 370 | 49 (13%) | 40 (11%) | 47 (13%) | 274 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

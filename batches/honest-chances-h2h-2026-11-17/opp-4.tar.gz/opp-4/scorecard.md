# Doctrine scorecard: hc-opp-31c41bf-p4

### Scorecard: hc-opp-31c41bf-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 1 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 8 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 2 | 3 | 3 | 3 | 1 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 0 | 1 | 0 | 1 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 4 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 900 |
| L0315 | 3 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 7 | - | 1 | 4 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 769 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 1167 |
| L0624 | 6 | 1 | Opponent | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 513 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 2 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | yes | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 3 | 0 | 2 | 2 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 3 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 762 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 926 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 4 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 500 |
| L1126 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 4 | 2 | 5 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 2 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 440 |
| L1314 | 6 | 1 | Mine | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 15 | 2 | 3 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | no | - | 4 | 5 | 1 | 0 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 1 | 3 | 2 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 185 |
| L1621 | 1 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 4 | 2 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 0 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 3 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 1 | 3 | 0 | 0 | 0 | 110 |
| L2021 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 2 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 3 | 2 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | yes | 4 | 1 | 5 | 1 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 8 | - | 0 | 0 | 0 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 9 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 2.1 | 2.9 | 2.4 | 1.2 | 0.3 | 0.0 | 0.0 | 330.6 |
| **Average** | | | Opponent | 46% | 3.5 | 1.9 | 2.8 | 1.9 | 0.4 | 0.0 | 0.0 | 128.7 |

### KPIs: hc-opp-31c41bf-p4

Rules off - Mine only: MEASURED NEXT CHARGE, RUN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (42 of 172) | 1% (2 of 185) | 12% (44 of 357) |
| Winner chose to follow up after the loser gave ground |  | 98% (51 of 52); on the table 98% | 95% (52 of 55); on the table 95% | 96% (103 of 107); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (9 of 12); on the table 92% | 100% (6 of 6); on the table 100% | 83% (15 of 18); on the table 94% |
| Winner chose to pursue after the loser fled |  | 70% (21 of 30); on the table 70% | 88% (30 of 34); on the table 91% | 80% (51 of 64); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 86% (81 of 94); on the table 88% | 93% (88 of 95); on the table 94% | 89% (169 of 189); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 28% (75 of 265) | 35% (61 of 176) | 31% (136 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (75 of 181) | 51% (61 of 120) | 45% (136 of 301) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 66% (29 of 44) | 52% (33 of 64) | 57% (62 of 108) |
| Points that never fought | lower | 34% (23192 of 67942) | 37% (26623 of 71984) | 36% (49815 of 139926) |
|   infantry points that never fought | lower | 45% (6944 of 15347) | 59% (8100 of 13804) | 52% (15044 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (164 of 270) | 57% (160 of 280) | 59% (324 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.7 uses a game | 89% (8 of 9); 0.6 uses a game | 90% (28 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.2 uses a game | 35% (7 of 20); 0.3 uses a game | 33% (12 of 36); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31842 of 57750) | 49% (30836 of 63347) | 52% (62678 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (25%) | 0.8 (23%) | 2.1 (24%) |
| MARCHED: its unit marched | 1.2 (23%) | 0.4 (14%) | 1.7 (20%) |
| CHARGED: its unit charged | 0.4 (8%) | 0.2 (6%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 1.3 (24%) | 0.6 (20%) | 1.9 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| GONE: slain | 0.8 (15%) | 0.9 (28%) | 1.7 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.4 | 1.8 | 3.8 | 0.6 | 2.6 |
| not cast | 3.2 | 2.4 | 3.0 | 8.5 | 1.4 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (55%) | 0.2 (7%) | 2.1 (24%) | 0.1 (6%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (20%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (6%) | 0.7 (22%) | 1.9 (23%) | 0.3 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.1 (3%) | 0.2 (6%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (1%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.1 (33%) | 0.3 (12%) | 0.7 (22%) | 1.7 (20%) | 0.1 (8%) | 4.6 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.1 (5%) | 0.2 (7%) | 0.1 (1%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.6 (42%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (44%) | 0.1 (5%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.1 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 70% (30 of 43) | 73% (8 of 11) | 70% (38 of 54) |
| the unit moved after it | 73% (22 of 30) | 50% (4 of 8) | 68% (26 of 38) |
| it charged on its next turn | 10% (3 of 30) | 0% (0 of 8) | 8% (3 of 38) |
| the enemy charged it first | 20% (6 of 30) | 0% (0 of 8) | 16% (6 of 38) |
| it fought by the end of its next turn | 10% (3 of 30) | 38% (3 of 8) | 16% (6 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (3 of 30) | 25% (2 of 8) | 13% (5 of 38) |
| none of these (no charge, no fight, no charge escaped) | 67% (20 of 30) | 62% (5 of 8) | 66% (25 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (591 of 918) | 54% (284 of 526) | 61% (875 of 1444) |
|   cavalry | 56% (45 of 81) | 65% (71 of 109) | 61% (116 of 190) |
|   character | 53% (53 of 100) | 20% (25 of 127) | 34% (78 of 227) |
|   chariot | 53% (55 of 104) | 68% (15 of 22) | 56% (70 of 126) |
|   infantry | 64% (182 of 283) | 66% (152 of 229) | 65% (334 of 512) |
|   monster | 39% (19 of 49) | 27% (6 of 22) | 35% (25 of 71) |
|   war machine | 79% (237 of 301) | 88% (15 of 17) | 79% (252 of 318) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (21%) | 1.5 (22%) | 3.4 (22%) |
| CHARGED: it charged | 0.8 (9%) | 1.6 (24%) | 2.4 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.4 (7%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.0 (22%) | 1.0 (15%) | 3.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.6 (10%) | 1.4 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (20%) | 1.3 (19%) | 3.1 (19%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.1 | 84% | 4.2 pts | 22 pts |
| character | 2.4 | 0.5 | 86% | 4.8 pts | 12 pts |
| chariot | 2.0 | 1.0 | 65% | 14.1 pts | 28 pts |
| infantry | 13.3 | 4.9 | 74% | 8.7 pts | 116 pts |
| monster | 0.8 | 0.2 | 82% | 2.3 pts | 2 pts |
| war machine | 7.0 | 5.8 | 65% | 29.9 pts | 209 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.8 | 4.8 |
| Charges that made contact a game | 3.0 | 4.4 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.69 contact (16 units) | 0.39 declared, 0.33 contact (18 units) | 0.59 declared, 0.50 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.62 contact (8 units) | 1.36 declared, 1.14 contact (14 units) | 1.14 declared, 0.95 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.37 contact (247 units) | 0.63 declared, 0.47 contact (289 units) | 0.55 declared, 0.42 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (53 of 81) | 44% (7 of 16) | 67% (4 of 6) | 62% (64 of 103) |
| Character in a unit | 87% (26 of 30) | 81% (13 of 16) | 100% (1 of 1) | 85% (40 of 47) |
| Character on its own | 83% (29 of 35) | 54% (14 of 26) | 23% (18 of 77) | 44% (61 of 138) |
| Chariot | 80% (12 of 15) | 75% (9 of 12) | - | 78% (21 of 27) |
| Infantry | 55% (46 of 83) | 44% (11 of 25) | 50% (3 of 6) | 53% (60 of 114) |
| Monster | 68% (23 of 34) | 57% (8 of 14) | - | 65% (31 of 48) |
| Monstrous | 43% (6 of 14) | 57% (8 of 14) | - | 50% (14 of 28) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (7 of 8); on the table 88% | 20% (20 of 102) | 13% | 55% (12 of 22) | 83% (5 of 6); 2.8 uses a game | 50% (1 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 77% (10 of 13); on the table 77% | 58% (14 of 24) | 26% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 80% (4 of 5); on the table 80% | - | 80% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (14 of 18); on the table 83% | 44% (8 of 18) | 45% | 60% (37 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (8 of 8); on the table 100% | 31% (26 of 84) | 47% | 54% (20 of 37) | 100% (9 of 9); 7.2 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 86% (30 of 35); on the table 86% | 25% (9 of 36) | 31% | 51% (36 of 70) | 100% (7 of 7); 3.6 uses a game | 30% (9 of 30); 1.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (5 of 5); on the table 100% | - | 35% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 89% (8 of 9); on the table 89% | 67% (4 of 6) | 30% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (5 of 5); on the table 100% | 50% (3 of 6) | 42% | 86% (12 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 26% (11 of 42) | 2% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 75% (9 of 12); on the table 92% | 32% (13 of 40) | 35% | 64% (29 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 83% (5 of 6); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 92% | 50% (3 of 6) | 23% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (22 of 22); on the table 100% | 34% (20 of 59) | 47% | 67% (28 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (8 of 9); on the table 89% | 17% (2 of 12) | 31% | 62% (45 of 72) | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (18 of 18); on the table 100% | 50% (3 of 6) | 43% | 50% (28 of 56) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (hc-opp-31c41bf-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (51) | 40% (29) | 45% (80) |
| ...free all their last turn and able to turn (per game) | 0.97 | 0.50 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.17 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.42 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.61 | 1.17 | 2.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 0.61 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.83 | 6.00 | 11.83 |

### Quality by phase: hc-opp-31c41bf-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (74 of 128) | 45% (77 of 171) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (197 of 426) | 35% (60 of 173) |
| Strategy | Close-in objectives charged next turn | 13% (23 of 183) | 16% (26 of 165) |
| Strategy | Support requests answered (helper made contact too) | 62% (8 of 13) | 54% (14 of 26) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (8 of 12) | 100% (5 of 5) |
| Strategy | Joined characters whose unit fought | 54% (20 of 37) | 42% (13 of 31) |
| Strategy | Lone characters that fought | 79% (68 of 86) | 73% (62 of 85) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 330.6 | 128.7 |
| Movement | Fights charged into per game | 2.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 92, net +129 | 26 of 116, net +22 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 92, net +95 | 27 of 116, net +57 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 92, net +63 | 12 of 116, net +102 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 92, net +61 | 24 of 116, net +200 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (195 of 394) | 37% (117 of 316) |
| Shooting | Points destroyed by shooting units | 44.9 | 25.2 |
| Shooting | War machine shots | 6.6 | 0.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (131 of 237) | 20% (3 of 15) |
| Shooting | Points destroyed by war machines | 93.6 | 6.4 |
| Magic | Magic missiles cast | 1.3 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (17 of 47) | 18% (9 of 49) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.4 |
| Magic | Wounds caused by other spells | 2.1 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 68.1 | 27.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.9 / 0.2 | 1.9 / 0.4 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 251.8 | 439.4 |
| Combat | Points run down | 119.9 | 139.5 |
| Combat | Net points per charged fight, damage counted | +84 | +97 |
| Combat | Net per 100 charger points, damage counted | +30.5 | +31.5 |
| Combat | First round won (charged fights) | 84% | 73% |
| Combat | Net points per charged fight | +82 | +100 |
| Combat | Net points per supported fight / lone fight | +49 / +86 | +20 / +112 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 98 | 70 of 134 |
| Game | Points lost | 707.1 | 728.7 |
| Game | VP from objectives | 501.9 | 511.4 |
| Game | Lone holders (player turns) | 2.1 | 3.5 |

- Mine won / drew / lost: 14 / 9 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +4 VP
- The side that went first won 14 of 27 games with a winner
- Points traded per game (both sides' losses): 1436
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hc-opp-31c41bf-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 6.1 | -137.1 | 185.9 | 112.2 | 4.5 | -151.0 | 82.1 | 93.4 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 10.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.4 | +1.8 | 0.0 | 26.1 | 0.2 | +0.4 | 0.0 | 5.4 |
| BEST FACING | 0.4 | +2.0 | 0.0 | 12.0 | 0.2 | +4.5 | 0.0 | 10.4 |
| BEST FIRST | 1.2 | +52.3 | 32.0 | 53.1 | 0.7 | +38.4 | 1.8 | 29.9 |
| BEST OVERALL | 0.3 | +8.6 | 0.0 | 23.9 | 0.1 | +1.6 | 0.0 | 6.2 |
| BEST PREY | 0.6 | +29.0 | 8.8 | 5.2 | 0.7 | +48.6 | 20.6 | 14.3 |
| BEST PRIZE | 0.1 | -1.9 | 1.8 | 0.0 | 0.1 | -1.3 | 9.8 | 1.9 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 32.2 | 0.4 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.0 | 5.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +10.6 | 0.0 | 0.0 | 0.6 | +7.5 | 0.0 | 5.3 |
| BLOWS WHERE AIMED | 0.2 | -15.9 | 32.8 | 2.5 | 0.2 | -40.0 | 30.3 | 24.6 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.4 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 116.9 | 14.2 | 0.0 | +0.0 | 1.7 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +214.3 | 454.5 | 69.4 | 0.4 | +24.6 | 16.4 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.1 | -3.3 | 15.3 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 12.0 | 12.1 | 0.1 | -4.4 | 21.9 | 16.6 |
| CAST JOB | 1.1 | +29.6 | 44.0 | 0.0 | 0.4 | +7.6 | 22.6 | 7.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +25.8 | 27.1 | 0.0 | 0.1 | +1.1 | 13.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 38.9 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +60.5 | 0.0 | 28.6 | 2.3 | +127.7 | 0.0 | 43.1 |
| CHAFF PASSED | 0.1 | -0.5 | 0.0 | 0.0 | 0.1 | -0.3 | 3.8 | 0.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 229.0 | 75.5 | 2.4 | +0.0 | 237.2 | 83.4 |
| CHARGE NOW WEIGHED | 0.4 | -33.4 | 14.6 | 11.8 | 0.6 | -29.7 | 53.8 | 20.7 |
| CHARGER SLAIN LOST | 0.3 | -6.5 | 36.7 | 5.1 | 0.6 | -22.1 | 54.1 | 9.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 11.1 | 0.1 | -0.5 | 0.0 | 30.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.8 | 0.0 | 0.1 | +0.0 | 3.2 | 8.1 |
| COMBAT PIVOT | 0.6 | +0.0 | 8.5 | 87.1 | 0.5 | +0.0 | 49.6 | 41.9 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.8 | 0.0 | 0.1 | +0.0 | 1.8 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +69.1 | 15.3 | 2.6 | 0.2 | +28.5 | 0.0 | 7.6 |
| COVER ONCE | 7.6 | -408.0 | 0.0 | 148.1 | 6.4 | -465.9 | 0.0 | 131.9 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 38.9 | 5.7 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.5 | 0.0 | 2.6 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +3.6 | 8.3 | 0.0 | 0.2 | +2.5 | 17.6 | 13.7 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +121.3 | 0.0 | 63.1 | 1.2 | +55.4 | 0.0 | 28.5 |
| FALLBACK BY WORTH | 5.3 | +65.4 | 0.0 | 102.0 | 5.2 | +23.4 | 0.0 | 52.4 |
| FIGHT LIFT | 0.2 | +4.1 | 13.9 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.0 | 0.0 | 3.1 | 0.1 | +0.6 | 5.1 | 5.9 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 136.2 | 5.4 | +0.0 | 0.0 | 127.3 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +128.1 | 0.0 | 56.9 | 0.8 | +130.0 | 0.0 | 13.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +14.4 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 9.6 |
| GIVES UP | - | - | - | - | 0.1 | -1.7 | 29.8 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 10.4 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 10.4 | 0.0 | 0.0 | +0.0 | 3.9 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 55.6 | 8.0 | 0.4 | +0.0 | 41.5 | 0.0 |
| HILL BY ITS CHANCE | 0.7 | -83.4 | 0.0 | 26.1 | 0.4 | -25.4 | 0.0 | 7.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -143.4 | 527.9 | 198.0 | 5.3 | -147.8 | 420.6 | 132.8 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +6.3 | 3.5 | 1.7 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 4.6 | 3.1 |
| HUNT IN PAIRS | 0.3 | +5.6 | 0.0 | 16.1 | 0.2 | +9.5 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +2.9 | 3.5 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.2 | +16.2 | 12.6 | 3.1 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +50.2 | 4.6 | 1.7 |
| IDLE COST | 17.3 | -276.2 | 0.0 | 202.2 | 20.6 | -335.6 | 0.0 | 194.2 |
| INVITES THE FIGHT | 1.2 | +6.7 | 44.5 | 8.6 | 1.1 | +11.6 | 11.3 | 48.4 |
| JOINT CHARGE PLAN | 0.2 | +1.2 | 12.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.0 | 25.2 | 0.0 | 0.2 | -10.0 | 23.8 | 4.2 |
| KEEP FALLS | 0.1 | +2.8 | 0.0 | 6.6 | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 5.2 | 0.1 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +54.2 | 182.8 | 37.2 | 1.5 | +45.8 | 197.2 | 55.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +46.0 | 98.4 | 30.7 | 1.9 | +100.8 | 144.9 | 27.1 |
| KILLS COUNT NEXT TURN | 4.9 | +172.6 | 261.7 | 117.3 | 3.1 | +130.1 | 74.8 | 55.8 |
| LONE CHARACTER SAFE SPOT | 0.2 | +4.8 | 36.0 | 2.5 | 0.4 | +15.4 | 7.7 | 13.7 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 1.8 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +0.3 | 1.8 | 11.8 | 0.7 | -5.6 | 43.4 | 8.2 |
| LOST CHARGE | 2.6 | -32.6 | 133.0 | 75.8 | 2.1 | -45.8 | 71.6 | 45.3 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.1 | 0.0 | 7.1 | 0.2 | -25.0 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.8 | +80.0 | 7.0 | 5.7 | 0.6 | +53.3 | 39.7 | 10.3 |
| MANOEUVRE | 0.3 | +8.4 | 0.0 | 7.9 | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +8.1 | 0.0 | 21.6 | 0.3 | +6.4 | 0.0 | 20.3 |
| MARCH ODDS | 0.3 | +21.7 | 9.4 | 0.0 | 0.3 | +16.9 | 8.2 | 13.9 |
| MARCH OVER CASTS | 0.6 | +47.0 | 0.0 | 38.3 | 0.3 | +25.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.0 | +95.6 | 0.0 | 139.9 | 5.2 | +46.0 | 0.0 | 97.5 |
| MEASURED NEXT CHARGE | - | - | - | - | 9.9 | -249.0 | 153.4 | 222.2 |
| MISSILES IN THE MOVE | 4.1 | +119.0 | 0.0 | 79.9 | 2.2 | +35.9 | 0.0 | 84.7 |
| MISSILES NEXT TURN | 4.8 | +82.5 | 0.0 | 149.0 | 2.8 | +24.0 | 0.0 | 98.6 |
| MODEL FACING | 0.2 | +46.4 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 15.7 | 5.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +10.1 | 0.0 | 0.0 | 0.4 | +14.0 | 0.0 | 14.3 |
| MOVE SPELL IN RANGE | 0.2 | +5.8 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -33.5 | 0.0 | 50.4 | 0.0 | -0.2 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 27.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.5 | +200.4 | 219.8 | 63.1 | 1.1 | +4.7 | 24.9 | 35.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.2 | 5.2 | 0.0 |
| NOT NEEDED | 0.2 | -6.6 | 11.5 | 20.3 | 0.2 | -15.4 | 56.6 | 5.4 |
| NOT TURNED | 5.8 | +130.2 | 0.0 | 160.7 | 6.0 | +69.5 | 0.0 | 129.3 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 11.1 | 0.4 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.5 | -630.4 | 6.2 | 271.9 | 15.2 | -673.9 | 0.0 | 291.5 |
| ONE FIGHT FORMULA | 8.4 | -145.8 | 27.8 | 169.9 | 8.2 | -172.9 | 11.3 | 227.1 |
| ONE OBJECTIVE FORMULA | 2.6 | -114.3 | 0.0 | 56.7 | 2.1 | -139.3 | 0.0 | 59.2 |
| OPENS A LANE | 0.2 | +0.8 | 18.5 | 3.6 | 0.1 | +0.7 | 0.0 | 3.4 |
| OPENS UP | 0.2 | +20.5 | 22.5 | 0.0 | 0.1 | +3.0 | 8.5 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +19.3 | 57.6 | 23.6 | 0.4 | +8.3 | 54.9 | 27.6 |
| PATHS CROSS | 2.4 | +208.4 | 0.0 | 56.5 | 2.9 | +174.1 | 0.0 | 69.2 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +9.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.3 | 0.0 | 3.9 | 0.1 | -1.6 | 0.0 | 15.0 |
| PLAN RESULT | 39.3 | +1634.5 | 1738.3 | 983.6 | 38.5 | +993.8 | 1630.5 | 1057.7 |
| PURSUES BIG PREY | 0.1 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.3 | 0.0 | 2.2 | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +21.3 | 0.0 | 37.5 | 1.8 | +19.5 | 0.0 | 63.1 |
| RANDOM MOVER NO PROMISE | 0.2 | -5.8 | 11.4 | 0.0 | 0.1 | -5.6 | 0.0 | 8.1 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -10.4 | 0.0 | 18.6 | 2.1 | -65.5 | 0.0 | 31.6 |
| REDIRECT COUNTER | 2.3 | +120.6 | 0.0 | 51.1 | 4.1 | +254.3 | 0.0 | 76.4 |
| REDIRECT WEIGHED | 0.1 | -1.9 | 1.8 | 1.8 | 0.3 | +5.2 | 16.5 | 10.9 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +19.1 | 0.0 | 16.4 | 0.8 | +23.2 | 0.0 | 19.9 |
| RESTRAINS TO SHOOT | 0.1 | +6.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +97.0 | 209.5 | 95.3 | 2.3 | +33.8 | 256.2 | 87.3 |
| RISK ONCE | 1.4 | +21.4 | 5.1 | 102.2 | 4.5 | +171.3 | 38.7 | 179.1 |
| RUN DOWN | - | - | - | - | 2.2 | -18.3 | 170.7 | 56.1 |
| SAFER THAN THE JOB | 1.1 | +76.2 | 0.0 | 10.9 | 0.6 | +21.9 | 0.0 | 9.1 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.7 | 0.0 | 2.9 | 0.4 | -25.4 | 0.0 | 1.2 |
| SEARCH SPOT | 2.8 | +119.8 | 0.0 | 47.0 | 2.6 | +122.4 | 0.0 | 45.8 |
| SELF MOVE SPELL | 0.2 | +36.1 | 0.0 | 0.0 | 0.5 | +14.7 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.1 | +103.6 | 38.1 | 5.7 | 1.6 | +145.9 | 47.7 | 23.4 |
| SET-UP ANY TARGET | 0.4 | +42.2 | 0.0 | 0.0 | 0.0 | +2.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 1.1 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +45.1 | 49.8 | 8.6 | 1.4 | +36.0 | 61.2 | 27.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.4 | +0.0 | 73.8 | 13.0 | 0.2 | +0.0 | 20.9 | 1.8 |
| SHOTS IN THE MOVE | 15.4 | +774.7 | 0.0 | 224.6 | 7.3 | +178.3 | 0.0 | 129.9 |
| SPELL OFF EDGE | 0.0 | +1.5 | 4.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +63.5 | 5.1 | 0.0 | 0.1 | +29.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +30.1 | 125.4 | 120.4 | 2.2 | +42.0 | 89.8 | 92.5 |
| SPELLS IN THE FIGHT | 0.6 | -0.5 | 100.3 | 33.8 | 0.9 | +0.0 | 116.0 | 28.2 |
| STABLE ROLE | 10.9 | +0.0 | 418.3 | 188.0 | 9.7 | +0.0 | 406.7 | 177.9 |
| STANDS TO CAST | 0.1 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +10.9 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +1.3 | 4.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +27.9 | 0.0 | 23.9 | 0.4 | +15.7 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 6.9 | -65.0 | 309.1 | 119.8 | 7.8 | -72.7 | 385.8 | 115.9 |
| SUPPORTS | 5.2 | +71.0 | 169.1 | 55.7 | 6.0 | +72.7 | 221.1 | 72.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.1 | 12.9 | 0.0 | 0.1 | -2.6 | 6.4 | 1.9 |
| SURE REACH TOGETHER | 0.3 | -1.4 | 11.3 | 0.0 | 0.6 | +3.1 | 0.0 | 9.7 |
| THROUGH LINE OF FIRE | 0.2 | +14.9 | 0.0 | 16.1 | 0.2 | +14.1 | 0.0 | 3.0 |
| TURN WORTH | 0.3 | -25.2 | 31.6 | 0.0 | 0.1 | -12.3 | 5.4 | 9.6 |
| TWO OR MORE ARRIVE | 0.3 | +1.0 | 10.4 | 0.0 | 0.6 | +5.7 | 8.0 | 12.2 |
| WAIT AFTER COSTS | 7.0 | -302.8 | 334.9 | 87.2 | 3.2 | -154.1 | 60.8 | 93.2 |
| WALKS TO THE FIGHT | 1.9 | +12.3 | 34.3 | 24.6 | 1.0 | +6.0 | 36.5 | 9.8 |
| WAR ENGINE CHARGES | 0.2 | +5.7 | 6.6 | 4.2 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 41.4 | 22.6 | 0.1 | +0.0 | 2.2 | 4.0 |
| WEARS DOWN | 1.1 | +35.0 | 119.2 | 45.9 | 1.3 | +58.6 | 187.1 | 44.7 |
| WHO HITS BACK | 0.3 | +42.3 | 0.0 | 32.5 | 0.4 | +18.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +10.1 | 25.1 | 6.2 | 0.5 | +31.9 | 109.6 | 23.5 |
| WHOLE FIGHT GAIN | 0.2 | +28.1 | 43.4 | 0.0 | 0.6 | +45.8 | 59.8 | 5.0 |
| WIDER SPREAD | 2.4 | -6.1 | 233.3 | 65.4 | 3.2 | -6.6 | 367.9 | 107.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 15.4 | 0.0 |

### Rule changes: hc-opp-31c41bf-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1106 | 1106 | 1106 | 30.72 | -46953 | -42.5 |
| PATHS CROSS | 192 | 192 | 192 | 5.33 | +13770 | +71.7 |
| SEARCH SPOT | 192 | 192 | 186 | 5.17 | +8721 | +46.9 |
| SUPPORTS | 404 | 404 | 175 | 4.86 | +1917 | +11.0 |
| FACES THE THREAT | 100 | 100 | 100 | 2.78 | +6361 | +63.6 |
| MOVE TO CHARGE | 168 | 168 | 95 | 2.64 | +2426 | +25.5 |
| KILLS COUNT NEXT TURN | 290 | 290 | 93 | 2.58 | +3063 | +32.9 |
| SHOTS IN THE MOVE | 818 | 589 | 90 | 2.50 | +2506 | +27.8 |
| COVER ONCE | 504 | 293 | 82 | 2.28 | +1264 | +15.4 |
| FALLBACK BY WORTH | 377 | 377 | 73 | 2.03 | +3195 | +43.8 |
| CHAFF IN THE MOVE | 114 | 111 | 70 | 1.94 | +2412 | +34.5 |
| BEST FIRST | 68 | 68 | 68 | 1.89 | +3265 | +48.0 |
| ADVANCE WORTH | 379 | 379 | 64 | 1.78 | +1902 | +29.7 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +3531 | +56.0 |
| RANDOM MOVE BY FIGURES | 108 | 108 | 62 | 1.72 | +1467 | +23.7 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +9294 | +152.4 |
| MEASURED NEXT CHARGE | 355 | 255 | 57 | 1.58 | +319 | +5.6 |
| ONE FIGHT FORMULA | 598 | 359 | 57 | 1.58 | +236 | +4.1 |
| SET UP TOGETHER | 97 | 85 | 57 | 1.58 | +3806 | +66.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| IDLE COST | 1363 | 786 | 55 | 1.53 | +831 | +15.1 |
| WAIT AFTER COSTS | 366 | 366 | 55 | 1.53 | +880 | +16.0 |
| REDIRECT COUNTER | 231 | 127 | 51 | 1.42 | +3799 | +74.5 |
| MISSILES IN THE MOVE | 227 | 159 | 47 | 1.31 | +883 | +18.8 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1523 | +35.4 |
| WALKS TO THE FIGHT | 106 | 106 | 43 | 1.19 | +188 | +4.4 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| COMBAT PIVOT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +1797 | +46.1 |
| CHARGE NOW FIRST | 176 | 176 | 37 | 1.03 | -1502 | -40.6 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 118 | 116 | 34 | 0.94 | +1408 | +41.4 |
| RISK BY ARC | 172 | 167 | 34 | 0.94 | +854 | +25.1 |
| BLOCKED WHEEL | 33 | 33 | 33 | 0.92 | +650 | +19.7 |
| SHOOTS FROM THE BEST SPOT | 93 | 93 | 33 | 0.92 | +877 | +26.6 |
| INVITES THE FIGHT | 84 | 84 | 32 | 0.89 | +137 | +4.3 |
| CAST JOB | 55 | 55 | 30 | 0.83 | +561 | +18.7 |
| MAX FOR POSITIONING | 404 | 261 | 30 | 0.83 | +71 | +2.4 |
| MOVE AND CAST | 30 | 30 | 30 | 0.83 | +869 | +29.0 |
| RISK ONCE | 214 | 163 | 30 | 0.83 | +998 | +33.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1570 | +58.2 |
| CANNON PLANNED TARGET | 201 | 201 | 26 | 0.72 | -621 | -23.9 |
| WHO HITS BACK | 26 | 26 | 26 | 0.72 | +1609 | +61.9 |
| HONEST WORTH | 491 | 486 | 24 | 0.67 | +276 | +11.5 |
| MARCH CHECK | 27 | 26 | 24 | 0.67 | +678 | +28.2 |
| MARCH ODDS | 24 | 24 | 24 | 0.67 | +259 | +10.8 |
| BEST FACING | 22 | 22 | 22 | 0.61 | +234 | +10.7 |
| MAKE SURE TOGETHER | 49 | 42 | 22 | 0.61 | +1474 | +67.0 |
| BIG CHARACTER SAFETY | 21 | 21 | 21 | 0.58 | -13 | -0.6 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| SHOT REPLANNED | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WEARS DOWN | 86 | 82 | 20 | 0.56 | +914 | +45.7 |
| KEEPS ITS TARGET | 120 | 118 | 18 | 0.50 | +377 | +20.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +980 | +61.2 |
| REDIRECT WEIGHED | 16 | 16 | 16 | 0.44 | -126 | -7.9 |
| BEST PREY | 47 | 47 | 15 | 0.42 | +313 | +20.9 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +1044 | +69.6 |
| WAR ENGINE JOBS | 34 | 34 | 14 | 0.39 | -290 | -20.7 |
| WHOLE FIGHT GAIN | 30 | 28 | 13 | 0.36 | +433 | +33.3 |
| BEST OVERALL | 12 | 12 | 12 | 0.33 | +369 | +30.7 |
| LOST CHARGE | 169 | 168 | 12 | 0.33 | +372 | +31.0 |
| MANOEUVRE | 11 | 11 | 10 | 0.28 | +306 | +30.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 54 | 52 | 9 | 0.25 | +283 | +31.4 |
| WHOLE FIGHT | 28 | 28 | 9 | 0.25 | +466 | +51.8 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -32 | -4.0 |
| MISSILES NEXT TURN | 274 | 172 | 8 | 0.22 | +10 | +1.2 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +1669 | +208.7 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -138 | -17.3 |
| SUPPORT NARROWED | 530 | 530 | 8 | 0.22 | -114 | -14.3 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OPENS UP | 14 | 14 | 7 | 0.19 | +150 | +21.5 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -277 | -39.6 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -442 | -73.7 |
| ONE OBJECTIVE FORMULA | 169 | 90 | 6 | 0.17 | +264 | +43.9 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +584 | +97.3 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +227 | +37.9 |
| CASTING BLOCK | 14 | 14 | 5 | 0.14 | +425 | +84.9 |
| OVERRUNS AWAY | 31 | 29 | 5 | 0.14 | +97 | +19.5 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +232 | +46.4 |
| REFUSING RETIRES | 25 | 25 | 5 | 0.14 | -3 | -0.5 |
| WIDER SPREAD | 204 | 195 | 5 | 0.14 | +19 | +3.8 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +22 | +5.4 |
| HUNT IN PAIRS | 21 | 11 | 4 | 0.11 | +149 | +37.1 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +146 | +36.5 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +393 | +98.2 |
| SURE REACH TOGETHER | 32 | 22 | 4 | 0.11 | +9 | +2.2 |
| BACKUP TARGETS | 23 | 11 | 3 | 0.08 | +5 | +1.7 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| LONG SHOT | 40 | 38 | 3 | 0.08 | +16 | +5.3 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +28 | +9.4 |
| WOUNDED STAYS OUT | 4 | 4 | 3 | 0.08 | -405 | -135.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -158 | -79.2 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +48 | +24.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 2 | 0.06 | -158 | -78.8 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -106 | -52.9 |
| RUN DOWN | 81 | 80 | 2 | 0.06 | +7 | +3.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +29 | +28.9 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -118 | -118.5 |
| CHARGER SLAIN LOST | 33 | 32 | 1 | 0.03 | +174 | +174.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +74 | +73.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +15 | +15.0 |
| HILL BY ITS CHANCE | 42 | 42 | 1 | 0.03 | +64 | +64.4 |
| JOINT CHARGE PLAN | 10 | 10 | 1 | 0.03 | +149 | +148.8 |
| KEEPS ITS PREY | 6 | 6 | 1 | 0.03 | +6 | +5.5 |
| MOVE SPELL IN RANGE | 9 | 3 | 1 | 0.03 | +4 | +4.1 |
| NEEDED THERE | 2 | 1 | 1 | 0.03 | +0 | +0.0 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| WAR ENGINE CHARGES | 6 | 6 | 1 | 0.03 | +24 | +24.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 23 | 23 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 16 | 16 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 9 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 374 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 10 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 426 | 426 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 5 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2800 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 100 | 100 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 122 | not checked | - | - | - | - |
| STABLE ROLE | 742 | 740 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 32 | 29 | 0 | 0.00 | - | - |

### Off best figure: hc-opp-31c41bf-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.86 | 13.67 | 44.1 |
| FALLBACK | gate | 0.78 | 0.75 | 35.8 |
| CHARGE NOW FIRST | rule | 0.61 | 0.42 | 40.6 |
| TURN GATE | gate | 0.53 | 0.33 | 19.1 |
| WAR ENGINE JOBS | rule | 0.33 | 0.06 | 20.7 |
| AFTERMATH BAND | gate | 0.19 | 0.11 | 2.3 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 62.5 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 17.3 |
| SUPPORT NARROWED | rule | 0.11 | 0.11 | 14.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.11 | 39.6 |
| BEST PRIZE | rule | 0.06 | 0.11 | 73.7 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 6.5 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 31.9 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 22.7 |
| FIGHT ORDER BAND | gate | - | 0.11 | 1.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.11 | 38.6 |
| PATHS CROSS | rule | 0.03 | 0.08 | 24.4 |
| CHAFF PASSED | rule | 0.06 | 0.03 | 10.7 |
| FACES THE THREAT | rule | 0.06 | 0.03 | 7.6 |
| REDIRECT WEIGHED | rule | 0.03 | 0.06 | 132.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 5.4 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.06 | 135.0 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 79.2 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 3.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 78.8 |
| MARCH ODDS | rule | 0.06 | - | 3.6 |
| PURSUES BIG PREY | rule | 0.06 | - | 52.9 |
| REFUSING RETIRES | rule | 0.06 | - | 0.9 |
| RULE SWITCHED OFF | gate | 0.06 | - | 42.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 230.2 |
| BLOCKED WHEEL | rule | 0.03 | - | 1.0 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 118.5 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 1.4 |
| LONG SHOT | rule | 0.03 | - | 4.5 |
| MOVE AND CAST | rule | 0.03 | - | 2.2 |
| NO REASON | gate | - | 0.03 | 4.7 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 15.2 |
| WHO HITS BACK | rule | 0.03 | - | 0.9 |

### Plans: hc-opp-31c41bf-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 21% | 167 | 333 | 199% |
| Mine | charge | 2.8 | 65% | 187 | 260 | 139% |
| Mine | close in | 5.1 | 26% | 266 | 175 | 66% |
| Mine | hold | 4.8 | 30% | 303 | 0 | 0% |
| Mine | join | 0.5 | 94% | 14 | 0 | 0% |
| Mine | shoot | 9.7 | 61% | 431 | 866 | 201% |
| Mine | support | 6.0 | 92% | 54 | 0 | 0% |
| Opponent | advance | 12.8 | 12% | 210 | 253 | 121% |
| Opponent | charge | 3.9 | 58% | 302 | 403 | 133% |
| Opponent | close in | 4.5 | 21% | 197 | 101 | 51% |
| Opponent | hold | 4.3 | 29% | 312 | 0 | 0% |
| Opponent | join | 0.7 | 92% | 31 | 0 | 0% |
| Opponent | shoot | 3.9 | 60% | 87 | 246 | 282% |
| Opponent | support | 8.2 | 89% | 58 | 0 | 0% |

### Packages: hunt the guns, hc-opp-31c41bf-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Opponent | 0.2 | 6 | 0 | 17% | 33% | 0% | 3.0 | 301 | 97 | 17% | 100 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 101 | 0 | 0% | 16 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 215 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 20% | 40% | 0% | 3.0 | 341 | 116 | 20% | 6 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 121 |

### Battle groups: hc-opp-31c41bf-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 47% | 62% | 13% | 20% | 18% | 0% | 9% | 71% | 3% |
| Opponent | REDIRECT COUNTER | 4.1 | 22% | 91% | 22% | 14% | 8% | 0% | 20% | 72% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hc-opp-31c41bf-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 99 (4) | 99 | 0 | 38 | 0% | 2.8 | - | 0 (3) | 261 (1) | - | 99 (4) |
| Mine | Chaff | 34 | 23 (34) | 12 | 11 | 65 | 24% | 2.5 | 14 (14) | 9 (7) | 38 (13) | 27 (22) | 16 (12) |
| Mine | Character | 106 | 42 (106) | 42 | 0 | 38 | 14% | 2.3 | 54 (29) | 32 (56) | 87 (6) | 30 (44) | 52 (47) |
| Mine | Clean-up | 22 | 105 (22) | 69 | 35 | 23 | 41% | 3.5 | 0 (2) | 128 (16) | 84 (4) | 108 (10) | 103 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 50 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 46 (41) | 38 | 9 | 39 | 17% | 2.9 | 47 (27) | 56 (9) | 28 (5) | 53 (25) | 37 (16) |
| Mine | Fragile | 4 | 29 (4) | 29 | 0 | 73 | 25% | 2.0 | 0 (2) | 54 (2) | - | 108 (1) | 0 (3) |
| Mine | Hammer | 65 | 29 (65) | 19 | 11 | 53 | 17% | 2.5 | 22 (13) | 34 (45) | 8 (7) | 24 (40) | 36 (25) |
| Mine | Holder | 31 | 76 (31) | 16 | 59 | 30 | 23% | 3.2 | 44 (7) | 87 (20) | 89 (4) | 95 (19) | 49 (12) |
| Mine | Shooter | 34 | 65 (34) | 27 | 38 | 31 | 6% | 1.6 | 13 (8) | 101 (21) | 0 (5) | 73 (25) | 39 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 36 | 4% | 1.4 | 54 (16) | 65 (30) | 12 (10) | 30 (9) | 57 (47) |
| Mine | Wizard | 17 | 11 (17) | 11 | 0 | 39 | 0% | 2.0 | 0 (5) | 21 (7) | 0 (1) | 0 (6) | 21 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 54 (75) | 36 | 18 | 52 | 40% | 2.6 | 52 (31) | 41 (17) | 67 (27) | 60 (56) | 34 (19) |
| Opponent | Character | 97 | 54 (97) | 54 | 0 | 29 | 27% | 2.3 | 61 (45) | 48 (38) | 82 (6) | 55 (50) | 60 (39) |
| Opponent | Clean-up | 11 | 46 (11) | 13 | 33 | 32 | 27% | 2.6 | 0 (3) | 52 (6) | 56 (2) | 41 (6) | 49 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 45 (60) | 26 | 19 | 42 | 32% | 2.9 | 58 (26) | 27 (25) | 52 (9) | 41 (39) | 51 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 78 | 24% | 2.5 | 0 (2) | 0 (8) | 0 (4) | 0 (11) | 0 (3) |
| Opponent | Hammer | 65 | 50 (65) | 35 | 15 | 47 | 28% | 3.3 | 36 (20) | 58 (38) | 24 (7) | 66 (41) | 27 (24) |
| Opponent | Holder | 29 | 33 (29) | 3 | 30 | 33 | 48% | 3.9 | 0 (9) | 36 (14) | 141 (4) | 44 (17) | 20 (10) |
| Opponent | Shooter | 33 | 48 (33) | 22 | 26 | 34 | 0% | 1.2 | 44 (9) | 52 (21) | 28 (3) | 53 (18) | 43 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 33% | 3.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 35 (6) | 35 | 0 | 61 | 17% | 1.0 | 60 (3) | 0 (3) | - | 60 (3) | 0 (3) |
| Opponent | Wizard | 19 | 3 (19) | 3 | 0 | 59 | 5% | 2.0 | 3 (10) | 0 (1) | 0 (2) | 0 (7) | 6 (6) |

### Charged fights: hc-opp-31c41bf-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 102 | 116 | 1.5 | 1.0 | 77 | 0 | +77 | 0 of 6 | 5 of 5 | - | +77 |
| Mine | Chaos Dwarfs | 4 | 42 | 164 | 2.0 | 1.1 | 82 | 51 | +31 | 3 of 8 | 6 of 8 | +0 | +36 |
| Mine | Dwarfen Mountain Holds | 3 | 395 | 54 | 1.3 | 1.0 | 40 | 0 | +40 | 0 of 4 | 4 of 4 | - | +40 |
| Mine | Empire of Man | 5 | 543 | 329 | 1.6 | 1.5 | 206 | 77 | +128 | 6 of 8 | 7 of 8 | +170 | +114 |
| Mine | Grand Cathay | 4 | 332 | 158 | 2.8 | 1.3 | 58 | 19 | +39 | 2 of 11 | 9 of 11 | +0 | +48 |
| Mine | High Elf Realms | 4 | 190 | 216 | 3.5 | 1.1 | 62 | 8 | +54 | 2 of 14 | 13 of 14 | +0 | +63 |
| Mine | Kingdom of Bretonnia | 1 | 355 | 750 | 5.0 | 1.0 | 150 | 0 | +150 | 4 of 5 | 4 of 5 | - | +150 |
| Mine | Lizardmen | 1 | 0 | 1660 | 5.0 | 1.0 | 332 | 37 | +295 | 2 of 5 | 3 of 5 | - | +295 |
| Mine | Ogre Kingdoms | 2 | 63 | 118 | 4.0 | 1.1 | 29 | 44 | -14 | 4 of 8 | 3 of 8 | +0 | -16 |
| Mine | Skaven | 2 | 95 | 66 | 2.0 | 1.2 | 33 | 0 | +33 | 0 of 4 | 4 of 4 | +66 | +22 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 756 | 5.0 | 1.1 | 151 | 40 | +112 | 3 of 10 | 9 of 10 | +54 | +118 |
| Mine | Vampire Counts | 2 | 102 | 292 | 3.5 | 1.0 | 84 | 0 | +84 | 2 of 7 | 7 of 7 | - | +84 |
| Mine | Warriors of Chaos | 2 | 0 | 500 | 4.0 | 1.1 | 125 | 4 | +121 | 2 of 8 | 7 of 8 | +77 | +128 |
| **Mine** | all armies | 36 | 207 | 286 | 2.7 | 1.1 | 105 | 24 | +82 | 30 of 98 | 81 of 97 | +49 | +86 |
| Opponent | Empire of Man | 1 | 290 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 160 | 528 | 4.6 | 1.2 | 115 | 77 | +38 | 18 of 23 | 16 of 23 | -32 | +58 |
| Opponent | Lizardmen | 2 | 56 | 620 | 4.5 | 1.0 | 138 | 109 | +29 | 6 of 9 | 6 of 9 | - | +29 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 809 | 4.7 | 1.0 | 173 | 22 | +151 | 4 of 14 | 11 of 14 | - | +151 |
| Opponent | Skaven | 4 | 20 | 274 | 2.8 | 1.1 | 100 | 80 | +19 | 8 of 11 | 5 of 11 | -362 | +58 |
| Opponent | Tomb Kings of Khemri | 2 | 83 | 896 | 5.5 | 1.1 | 163 | 65 | +98 | 6 of 11 | 7 of 11 | -195 | +127 |
| Opponent | Vampire Counts | 6 | 0 | 358 | 3.3 | 1.1 | 108 | 2 | +105 | 10 of 20 | 16 of 20 | +35 | +118 |
| Opponent | Warriors of Chaos | 7 | 0 | 427 | 2.1 | 1.0 | 199 | 0 | +199 | 9 of 15 | 10 of 15 | - | +199 |
| Opponent | Wood Elf Realms | 6 | 116 | 651 | 5.2 | 1.3 | 126 | 6 | +119 | 9 of 31 | 27 of 31 | +122 | +118 |
| **Opponent** | all armies | 36 | 60 | 507 | 3.7 | 1.1 | 136 | 37 | +100 | 70 of 134 | 98 of 134 | +20 | +112 |

### Effective charges: hc-opp-31c41bf-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 2 (net +76) | 0 | 0 | 2 (net +49) | 0 | 2 (net +106) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 8 | 2 (net +10) | 0 | 0 | 2 (net -100) | 1 (net +0) | 3 (net +144) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +54) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 8 | 1 (net +227) | 0 | 3 (net +113) | 4 (net +115) | 0 | 0 | 0 | 38% (3 of 8) |
| Mine | Grand Cathay | 11 | 0 | 0 | 1 (net -205) | 6 (net +44) | 3 (net +28) | 1 (net +287) | 0 | 9% (1 of 11) |
| Mine | High Elf Realms | 14 | 2 (net +0) | 0 | 1 (net +250) | 5 (net +76) | 2 (net +60) | 3 (net +0) | 1 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +210) | 0 | 0 | 0 | 0 | 1 (net +0) | 3 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 2 (net +528) | 0 | 1 (net +255) | 0 | 1 (net +110) | 1 (net +55) | 0 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 8 | 2 (net -45) | 0 | 1 (net -40) | 2 (net -17) | 0 | 2 (net -92) | 1 | 14% (1 of 7) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +33) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 4 (net +104) | 2 (net +132) | 1 (net +54) | 2 (net +132) | 1 | 44% (4 of 9) |
| Mine | Vampire Counts | 7 | 0 | 0 | 2 (net +106) | 2 (net +148) | 2 (net +38) | 1 (net +0) | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 8 | 2 (net +181) | 0 | 0 | 0 | 4 (net +109) | 2 (net +86) | 0 | 0% (0 of 8) |
| Opponent | High Elf Realms | 23 | 4 (net +0) | 1 (net +110) | 5 (net -64) | 6 (net +113) | 1 (net +30) | 3 (net +152) | 3 | 25% (5 of 20) |
| Opponent | Lizardmen | 9 | 2 (net +68) | 0 | 3 (net -28) | 0 | 0 | 3 (net +117) | 1 | 38% (3 of 8) |
| Opponent | Orc & Goblin Tribes | 14 | 1 (net +297) | 0 | 1 (net +0) | 3 (net +190) | 0 | 0 | 9 | 20% (1 of 5) |
| Opponent | Skaven | 11 | 2 (net -240) | 1 (net -41) | 4 (net +0) | 2 (net +36) | 0 | 2 (net +330) | 0 | 36% (4 of 11) |
| Opponent | Tomb Kings of Khemri | 11 | 2 (net -155) | 0 | 1 (net +0) | 2 (net +100) | 1 (net +126) | 3 (net +163) | 2 | 11% (1 of 9) |
| Opponent | Vampire Counts | 20 | 6 (net +68) | 0 | 4 (net +60) | 3 (net +76) | 4 (net +76) | 2 (net +386) | 1 | 21% (4 of 19) |
| Opponent | Warriors of Chaos | 15 | 4 (net +84) | 1 (net +0) | 3 (net +148) | 1 (net +347) | 3 (net +183) | 3 (net +437) | 0 | 20% (3 of 15) |
| Opponent | Wood Elf Realms | 31 | 5 (net +39) | 0 | 6 (net +208) | 7 (net +162) | 3 (net +71) | 8 (net +95) | 2 | 21% (6 of 29) |

### Charged fights, damage counted: hc-opp-31c41bf-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 194 | 254 | +129 | 219 | 79 | +139 | +71.8 |
| Mine | Effective (55-75%) | 13 | 302 | 194 | +95 | 205 | 93 | +111 | +36.8 |
| Mine | 76-89% | 25 | 282 | 173 | +61 | 85 | 29 | +56 | +19.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 197 | 144 | +61 | 85 | 17 | +67 | +34.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 471 | 95 | +63 | 63 | 8 | +55 | +11.6 |
| Mine | No odds | 6 | 256 | 208 | +148 | 148 | 11 | +137 | +53.6 |
| Mine | All fights | 98 | 275 | 172 | +82 | 122 | 38 | +84 | +30.5 |
| Opponent | Long shot (under 50%) | 26 | 246 | 292 | +22 | 90 | 73 | +17 | +6.9 |
| Opponent | 50-54% | 3 | 246 | 168 | +23 | 53 | 47 | +6 | +2.4 |
| Opponent | Effective (55-75%) | 27 | 307 | 305 | +57 | 108 | 53 | +55 | +17.9 |
| Opponent | 76-89% | 24 | 317 | 180 | +134 | 212 | 54 | +157 | +49.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 355 | 218 | +200 | 244 | 52 | +192 | +54.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 425 | 85 | +102 | 111 | 38 | +73 | +17.2 |
| Opponent | No odds | 18 | 250 | 154 | +106 | 148 | 50 | +97 | +38.9 |
| Opponent | All fights | 134 | 307 | 222 | +100 | 152 | 55 | +97 | +31.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hc-opp-31c41bf-p4 | move | 317 | 70 (22%) | 57 (18%) | 40 (13%) | 207 (65%) |
| hc-opp-31c41bf-p4 | objective | 348 | 49 (14%) | 38 (11%) | 49 (14%) | 250 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

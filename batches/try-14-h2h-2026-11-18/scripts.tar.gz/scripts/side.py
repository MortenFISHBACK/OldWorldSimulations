import json,sys,collections,glob,os
T=["HIS ONE MOVE","HIS MOVE AS HE DECIDES","THE TABLE AGAIN","ARMY TABLE"]
for b in sorted(glob.glob(os.path.expanduser("~/w14/*/"))):
    c=collections.Counter(); n=0
    for f in glob.glob(b+"*/game-*.log.jsonl"):
        n+=1
        for line in open(f):
            if '"OpponentRule"' not in line: continue
            r=json.loads(line); s=r.get("summary") or ""
            if any(s.startswith(t+":") for t in T): c[r["side"]]+=1
    ro=open(glob.glob(b+"*/rules-off.txt")[0]).read().split("\n")[0][:60] if glob.glob(b+"*/rules-off.txt") else "?"
    print(os.path.basename(b[:-1]), n, dict(c), "| off:", open(glob.glob(b+"*/rules-off.txt")[0]).read().count("@mine"),"@mine", open(glob.glob(b+"*/rules-off.txt")[0]).read().count("@opponent"),"@opp")

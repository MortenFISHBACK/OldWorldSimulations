D=/mnt/project-files/try-14-h2h-2026-11-18
for p in mine-1 mine-2 mine-3 mine-4 opp-1 opp-2 opp-3 opp-4; do [ -f $D/$p/batch.tgz ] || continue; rm -rf ~/w14/$p; mkdir -p ~/w14/$p; tar xzf $D/$p/batch.tgz -C ~/w14/$p; done

import json,glob,re,collections
D='/root/t14'
agg=collections.defaultdict(lambda:[0,0,0,0,0])  # band of move figure -> n, move, castclaim, real, ncast
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  rows=[json.loads(l) for l in open(f)]
  new=collections.Counter(r['side'] for r in rows if r.get('kind')=='action' and r.get('summary','').startswith('FIVE ACTION'))
  if not new: continue
  ns=new.most_common(1)[0][0]
  acts=[r for r in rows if r.get('kind')=='action' and r['side']==ns]
  mv=collections.defaultdict(float); cc=collections.defaultdict(float); rr=collections.defaultdict(float); nc=collections.Counter()
  seen=set()
  for r in acts:
    s=r['summary']
    if r['type']=='OpponentRule' and s.startswith('MISSILES IN THE MOVE') and r['phase']=='Movement':
      k=(r['turn'],r['actor'])
      if k in seen: continue
      seen.add(k); mv[r['turn']]+=float(re.search(r'([+-][\d.]+) VP',s).group(1))
  allacts=[r for r in rows if r.get('kind')=='action']
  for i,r in enumerate(allacts):
    if r['side']!=ns or r['type']!='Computer': continue
    m=re.search(r' casts (.+?) at (.+?): its best target.*?\((\d+) pts.*?~([\d.]+) unsaved wounds of (\d+) left.*?-> ~(-?[\d.]+) VP',r['summary'])
    if not m or r['phase']!='Shooting': continue
    pts=float(m.group(3)); left=int(m.group(5)); t=m.group(2)
    cc[r['turn']]+=float(m.group(6)); nc[r['turn']]+=1
    for r2 in allacts[i+1:i+10]:
      if r2['type']=='Computer' and ' casts ' in r2['summary']: break
      if r2['phase']!=r['phase']: break
      w=re.search(r'(\d+) wounds? caused to (.+)$',r2['summary']) if r2['type']=='SpellEffect' else None
      if w and w.group(2).strip()[:10]==t[:10]: rr[r['turn']]+=min(pts,int(w.group(1))*pts/max(1,left))
  for t in mv:
    b='<50' if mv[t]<50 else '50-150' if mv[t]<150 else '150+'
    x=agg[b]; x[0]+=1; x[1]+=mv[t]; x[2]+=cc[t]; x[3]+=rr[t]; x[4]+=nc[t]
for b in ['<50','50-150','150+']:
  n,a,c,r,k=agg[b]; print(b,'army-turns',n,'missiles counted in the moves %.0f'%(a/n),'figures when cast %.0f'%(c/n),'happened %.0f'%(r/n),'missiles cast-tried %.1f'%(k/n))

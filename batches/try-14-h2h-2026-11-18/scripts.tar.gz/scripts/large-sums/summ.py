import pickle,statistics as st,collections
out=pickle.load(open('jrc3.pkl','rb'))
def mean(x): x=[v for v in x if v is not None]; return (sum(x)/len(x)) if x else float('nan')
print('CHARGES TAKEN (all worths) by worth band')
ch=[d for d in out if d['k']=='charge']
for lo,hi in [(-1e9,100),(100,200),(200,300),(300,400),(400,1e9)]:
  xs=[d for d in ch if lo<=d['worth']<hi]
  if not xs: continue
  print(f"{lo:>6}-{hi:<6} n={len(xs):4d} worth {mean([d['worth'] for d in xs]):6.0f} G {mean([d['G'] for d in xs]):6.0f} tpts {mean([d['tpts'] for d in xs]):5.0f} G>tpts {sum(1 for d in xs if d['tpts'] and d['G'] and d['G']>1.1*d['tpts'])/len(xs):4.0%} contact {mean([1 if d['contact_now'] else 0 for d in xs]):4.0%} target lost by end {mean([d['t_lost'] for d in xs]):4.0%} realised kill pts {mean([ (d['t_lost'] or 0)*(d['tpts'] or 0) for d in xs]):5.0f} rounds {mean([d['nr'] for d in xs]):3.1f} single-target {mean([1 if d['t_single'] else 0 for d in xs]):4.0%} single-charger {mean([1 if d['a_single'] else 0 for d in xs]):4.0%}")
print()
for c in sorted({d.get('cls') for d in out if d.get('cls')}):
  xs=[d for d in out if d.get('cls')==c]
  if c.startswith('C'):
    print(f"{c:40s} n={len(xs):3d} worth {mean([d['worth'] for d in xs]):5.0f} G {mean([d['G'] for d in xs]):5.0f} tpts {mean([d['tpts'] for d in xs]):5.0f} dest {mean([d['dest'] for d in xs]):4.2f} contact {mean([1 if d['contact_now'] else 0 for d in xs]):4.0%} t_lost {mean([d['t_lost'] for d in xs]):4.0%} kill pts real {mean([(d['t_lost'] or 0)*(d['tpts'] or 0) for d in xs]):5.0f} rounds {mean([d['nr'] for d in xs]):3.1f} 1-model target {mean([1 if d['t_single'] else 0 for d in xs]):4.0%} 1-model charger {mean([1 if d['a_single'] else 0 for d in xs]):4.0%}")
  elif c.startswith('P'):
    print(f"{c:40s} n={len(xs):3d} worth {mean([d['worth'] for d in xs]):5.0f} Braw {mean([d['Braw'] for d in xs]):5.0f} x {mean([d['Bp'] for d in xs]):4.0%} tpts {mean([d['Btpts'] for d in xs]):5.0f} charged next {mean([1 if d['charged_next'] else 0 for d in xs]):4.0%} t_lost {mean([d['t_lost'] for d in xs]):4.0%} kill pts real {mean([(d['t_lost'] or 0)*(d['Btpts'] or 0) for d in xs]):5.0f} 1-model target {mean([1 if d['t_single'] else 0 for d in xs]):4.0%} 1-model charger {mean([1 if d['a_single'] else 0 for d in xs]):4.0%}")
  else:
    print(f"{c:40s} n={len(xs):3d} worth {mean([d['worth'] for d in xs]):5.0f} obj {mean([d['A_obj'] for d in xs]):5.0f} q {mean([d['A_q'] for d in xs]):5.0f} feat {mean([d['A_feat'] for d in xs]):5.0f} shots {mean([d['A_sh']+d['A_mi']+d['shot'] for d in xs]):5.0f} B {mean([d['Braw']*d['Bp'] for d in xs]):5.0f} C {mean([d['C'] for d in xs]):5.0f} turn {mean([d['turn'] for d in xs]):3.1f}")

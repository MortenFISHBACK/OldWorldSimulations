import json,glob,os,pickle,collections,re
D='/root/t14'
out=pickle.load(open('jrc2.pkl','rb'))
need=collections.defaultdict(list)
for d in out:
  if d['worth']>300 or (d['k']=='charge') or d.get('Bk')=='charge': need[d['game']].append(d)
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  parts=f[len(D)+1:].split('/'); gid=parts[0]+'/'+parts[1]+'/'+os.path.basename(f).replace('.log.jsonl','')
  if gid not in need: continue
  rows=[json.loads(l) for l in open(f)]
  b=rows[0]; ids={u['n']:u['id'] for u in b['units']}; lk={u['id']:u['lk'] for u in b['units']}
  idx={}
  start={}; last={}
  for r in rows:
    if r['kind']=='frame':
      for u in r['units']:
        start.setdefault(u['id'],(len(u['m']),u.get('wt') or 0))
        last[u['id']]=(u['on'],len(u['m']),u.get('wt') or 0,u['fl'])
  charges=collections.defaultdict(set)  # (turn, actor) -> targets
  for r in rows:
    if r['kind']=='action' and r['type']=='Charge': charges[(r['turn'],r['actor'])].add(r['target'])
  def lost(uid):
    if uid not in last: return None
    on,m,wt,fl=last[uid]; m0,_=start[uid]; w=(lk.get(uid) or {}).get('w') or 1
    if not on: return 1.0
    if m0<=1: return min(1,wt/max(1,w))
    return max(0,(m0-m)/m0)
  for d in need[gid]:
    aid=ids.get(d['actor'])
    d['a_lost']=lost(aid)
    tid=d['tid'] if d['k']=='charge' else d.get('Bt')
    d['t_lost']=lost(tid) if tid else None
    tn=None
    for n,i in ids.items():
      if i==tid: tn=n
    d['contact_now']= tn in charges.get((d['turn'],d['actor']),set()) if d['k']=='charge' else None
    d['charged_next']= tn in charges.get((d['turn']+1,d['actor']),set()) if tid and d['k']!='charge' else None
    d['t_single']= (lk.get(tid) or {}).get('mc')==1 if tid else None
    d['a_single']= (lk.get(aid) or {}).get('mc')==1
pickle.dump(out,open('jrc3.pkl','wb'))

import json,glob,re,collections
D='/root/t14'
bands=collections.defaultdict(lambda:[0,0,0,0]); tot=[0,0,0]
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  rows=[json.loads(l) for l in open(f)]
  new=collections.Counter(r['side'] for r in rows if r.get('kind')=='action' and r.get('summary','').startswith('FIVE ACTION'))
  if not new: continue
  ns=new.most_common(1)[0][0]
  acts=[r for r in rows if r.get('kind')=='action']
  for i,r in enumerate(acts):
    if r['side']!=ns or r['type']!='Computer': continue
    m=re.search(r' casts (.+?) at (.+?): its best target.*?\((\d+) pts.*?~([\d.]+) unsaved wounds of (\d+) left.*?-> ~(-?[\d.]+) VP',r['summary'])
    if not m: continue
    pts=float(m.group(3)); left=int(m.group(5)); vp=float(m.group(6)); t=m.group(2)
    real=0; cast=False
    for r2 in acts[i+1:i+10]:
      if r2['type']=='Computer' and ' casts ' in r2['summary']: break
      if r2['phase']!=r['phase']: break
      if r2['type']=='SpellCast': cast='cast successfully' in r2['summary'] or 'rresistible' in r2['summary']
      w=re.search(r'(\d+) wounds? caused to (.+)$',r2['summary']) if r2['type']=='SpellEffect' else None
      if w and w.group(2).strip()[:10]==t[:10]: real+=min(pts,int(w.group(1))*pts/max(1,left))
    b=0 if vp<20 else 1 if vp<50 else 2
    x=bands[b]; x[0]+=1; x[1]+=vp; x[2]+=real; x[3]+=cast
    tot[0]+=1; tot[1]+=vp; tot[2]+=real
print('casts',tot[0],'claimed %.0f wounds-in-points %.0f ratio %.2f'%(tot[1],tot[2],tot[2]/tot[1]))
for b,(c,cv,rv,cs) in sorted(bands.items()): print(['<20','20-50','50+'][b],c,'claimed %.1f'%(cv/c),'happened %.1f'%(rv/c),'cast %.0f%%'%(100*cs/c))

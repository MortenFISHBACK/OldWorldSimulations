import json,glob,re,collections
D='/root/t14'
claim=0; real=0; n=0; ok=0; bands=collections.defaultdict(lambda:[0,0,0])
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  rows=[json.loads(l) for l in open(f)]
  new=collections.Counter(r['side'] for r in rows if r.get('kind')=='action' and r.get('summary','').startswith('FIVE ACTION'))
  if not new: continue
  ns=new.most_common(1)[0][0]
  pend=None
  for r in rows:
    if r.get('kind')!='action' or r['side']!=ns: continue
    s=r['summary']
    m=re.search(r' casts (.+?) at (.+?): its best target.*?\((\d+) pts.*?~([\d.]+) unsaved wounds of (\d+) left.*?-> ~(-?[\d.]+) VP',s)
    if r['type']=='Computer' and m:
      pend=dict(spell=m.group(1),t=m.group(2),pts=float(m.group(3)),left=int(m.group(5)),vp=float(m.group(6)),real=0.0); n+=1; claim+=pend['vp']
      b=0 if pend['vp']<20 else 1 if pend['vp']<50 else 2
      bands[b][0]+=1; bands[b][1]+=pend['vp']; cur=b
      continue
    if pend and r['type']=='SpellEffect':
      w=re.search(r'(\d+) wounds? caused to (.+)$',s)
      if w and w.group(2).strip().startswith(pend['t'][:12]):
        v=min(pend['pts'], int(w.group(1))*pend['pts']/max(1,pend['left']))
        real+=v; bands[cur][2]+=v
      if 'destroyed' in s.lower() or 'flee' in s.lower(): pass
print('casts',n,'claimed %.0f'%claim,'wounds in points %.0f'%real,'ratio %.2f'%(real/claim))
for b,(c,cv,rv) in sorted(bands.items()): print(['<20','20-50','50+'][b],c,'claimed %.1f'%(cv/c),'happened %.1f'%(rv/c))

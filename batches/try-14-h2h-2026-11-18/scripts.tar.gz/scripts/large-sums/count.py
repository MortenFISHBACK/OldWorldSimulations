import pickle,collections,re
recs,games=pickle.load(open('recs.pkl','rb'))
gb=collections.Counter(g.split('/')[0] for g in games)
print(gb)
def kind(r):
  l=r['label']
  if r['row']=='move': return 'move-spot'
  for k in ['charge','shoot','march by the five','move by the five','stand by the five','advance','hold','support','redirect','screen','cast','close in']:
    if l.startswith(k): return k
  return l.split()[0]
for th in (300,400):
  print('== >',th)
  for b in gb:
    rs=[r for r in recs if r['batch']==b]
    big=[r for r in rs if r['worth']>th]
    tk=[r for r in big if r['taken']]
    print(b,'options',len(rs),'big',len(big),'per game %.1f'%(len(big)/gb[b]),'taken',len(tk),'per game %.2f'%(len(tk)/gb[b]), 'games with any taken', len({r['game'] for r in tk}))
  big=[r for r in recs if r['worth']>th]
  c=collections.Counter((r['row'],kind(r)) for r in big); ct=collections.Counter((r['row'],kind(r)) for r in big if r['taken'])
  for k,v in c.most_common(): print('  ',k,v,'taken',ct[k])
# negative large too
neg=[r for r in recs if r['worth']<-300]
print('worth < -300:',len(neg),'taken',sum(r['taken'] for r in neg))

import json,glob,re,collections
D='/root/t14'
g=0; c=collections.Counter(); ck=collections.Counter(); allp=0
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  rows=[json.loads(l) for l in open(f)]
  new=collections.Counter(r['side'] for r in rows if r.get('kind')=='action' and r.get('summary','').startswith('FIVE ACTION'))
  if not new: continue
  ns=new.most_common(1)[0][0]; g+=1
  for r in rows:
    if r.get('kind')=='action' and r['side']!=ns and r['type']=='Computer' and r['summary'].startswith('Objective for'):
      m=re.search(r'worth ~(-?[\d.]+) VP',r['summary'])
      if not m: continue
      allp+=1; w=float(m.group(1))
      lab=r['summary'].split(': ',2)[1] if r['summary'].count(': ')>=2 else ''
      k=lab.split()[0] if lab else '?'
      if w>300: c[300]+=1; ck[k]+=1
      if w>400: c[400]+=1
print(g,allp,c,ck.most_common(8))

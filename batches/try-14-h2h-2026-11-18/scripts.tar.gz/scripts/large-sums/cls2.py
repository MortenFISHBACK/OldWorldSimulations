import pickle,collections
out=pickle.load(open('jrc.pkl','rb'))
def cls(d):
  if d['k']=='charge':
    G=d['G'] or 0; t=d['tpts']
    if d['flee'] is not None and d['flee']>=0.5: return 'C-flee reaction: caught/off table'
    if t and G>1.1*t: return 'C1 kills above target points'
    if t is None: return 'C? target pts unknown'
    return 'C2 kills within target points'
  parts={'B-promise':d['Braw']*d['Bp'] if d['Bk']=='charge' else 0,'B-other':d['Braw']*d['Bp'] if d['Bk']!='charge' else 0,
         'quarter':d['A_q'],'objectives':d['A_obj'],'feature':d['A_feat'],'shots':d['A_sh']+d['A_mi']+d['shot'],'C':d['C']}
  top=max(parts,key=parts.get)
  if top=='B-promise':
    t=d['Btpts']
    if t and d['Braw']>1.1*t: return 'P1 promise: fight above target points'
    if t is None: return 'P? promise target pts unknown'
    return 'P2 promise within target points'
  return 'O-'+top
c=collections.Counter(); c4=collections.Counter()
for d in out:
  if d['worth']>300: d['cls']=cls(d); c[(d['cls'])]+=1
  if d['worth']>400: c4[cls(d)]+=1
for k,v in sorted(c.items()): print(f'{k:45s} {v:4d} >400 {c4[k]}')
pickle.dump(out,open('jrc2.pkl','wb'))

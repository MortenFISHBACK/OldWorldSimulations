import json,sys,re,collections,glob,os,pickle
D='/root/t14'
OPT=re.compile(r'^(\d+)\. (.*?)( \[TAKEN\])?: worth ([+-]?\d+\.\d) = gain ([+-]?\d+\.\d) (.*?)- risk (-?\d+\.\d)(.*)$')
RULES=re.compile(r'\{([^{}]*)\}\s*$')
def rules(s):
  m=RULES.search(s); out={}
  if m:
    for p in m.group(1).split(', '):
      mm=re.match(r'(.*) ([+-]\d+\.\d)$',p.strip())
      if mm: out[mm.group(1)]=out.get(mm.group(1),0)+float(mm.group(2))
  return out
def comps(s):
  # gain parenthetical: (fight +26.6, kills-count +5.2, other-costs -42.2 [..]; after +190.2)
  out={}
  m=re.match(r'\((.*)',s)
  if not m: return out
  body=re.sub(r'\[[^\]]*\]','',s)
  for k,v in re.findall(r'([a-z][a-z\- ]+?) ([+-]\d+\.\d)',body.split(') - ')[0] if False else body):
    k=k.strip()
    if k not in out: out[k]=float(v)
  return out
recs=[]
games=[]
for f in sorted(glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True)):
  batch=f.split('/')[len(D.split('/'))]
  part=f.split('/')[len(D.split('/'))+1]
  rows=[json.loads(l) for l in open(f)]
  new=collections.Counter(r['side'] for r in rows if r.get('kind')=='action' and r.get('summary','').startswith('FIVE ACTION'))
  if not new: continue
  ns=new.most_common(1)[0][0]
  gid=batch+'/'+part+'/'+os.path.basename(f).replace('.log.jsonl','')
  games.append(gid)
  board=next(r for r in rows if r['kind']=='board')
  names={u['id']:u['n'] for u in board['units']}
  side_of={u['id']:u['s'] for u in board['units']}
  pts={}
  for r in rows:
    if r.get('type')=='JobSplit' and r['summary'].startswith('JOB SPLIT'):
      m=re.search(r'destroyed [\d.]+ x (\d+\.\d)',r['summary'])
      if m: pts.setdefault(r['actor'],float(m.group(1)))
  for i,r in enumerate(rows):
    if r.get('kind')!='action' or r['side']!=ns: continue
    s=r['summary']
    if r['type']=='JobSplit' and (s.startswith('JOB SPLIT') or s.startswith('MOVE SPLIT')):
      kind='job' if s.startswith('JOB SPLIT') else 'move'
      body=s.split(': ',1)[1] if kind=='job' else s[len('MOVE SPLIT: '):]
      parts=body.split(' | ')
      if kind=='job': parts=parts[1:]
      for p in parts:
        if kind=='job':
          m=OPT.match(p)
          if not m: continue
          label=m.group(2); taken=bool(m.group(3)); worth=float(m.group(4)); gain=float(m.group(5)); gtxt=m.group(6); risk=float(m.group(7)); rest=m.group(8)
        else:
          m=re.match(r'^(.*?)( \[TAKEN\])?: worth ([+-]?\d+\.\d) = (.*?)- risk (-?\d+\.\d)(.*)$',p)
          if not m: continue
          label=m.group(1); taken=bool(m.group(2)); worth=float(m.group(3)); gain=None; gtxt=m.group(4); risk=float(m.group(5)); rest=m.group(6)
        tid=re.search(r'#(\d+)',label)
        tid=int(tid.group(1)) if tid else None
        recs.append(dict(game=gid,batch=batch,side=ns,turn=r['turn'],phase=r['phase'],actor=r['actor'],row=kind,label=label,taken=taken,worth=worth,gain=gain,gtxt=gtxt,risk=risk,rules=rules(p),tid=tid,tname=names.get(tid),tpts=None,apts=pts.get(r['actor']),idx=i,raw=p))
  for rec in recs:
    if rec['game']==gid and rec['tid'] and rec['tpts'] is None:
      rec['tpts']=pts.get(names.get(rec['tid']))
pickle.dump((recs,games),open('recs.pkl','wb'))
print(len(games),len(recs))

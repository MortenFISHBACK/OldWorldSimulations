import json,re,glob,collections,pickle,os
D='/root/t14'
out=[]
for f in sorted(glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True)):
  rows=[json.loads(l) for l in open(f)]
  new=collections.Counter(r['side'] for r in rows if r.get('kind')=='action' and r.get('summary','').startswith('FIVE ACTION'))
  if not new: continue
  ns=new.most_common(1)[0][0]
  parts=f[len(D)+1:].split('/')
  gid=parts[0]+'/'+parts[1]+'/'+os.path.basename(f).replace('.log.jsonl','')
  for i,r in enumerate(rows):
    if r.get('kind')=='action' and r['side']==ns and r['type']=='JobRisk':
      out.append(dict(game=gid,turn=r['turn'],phase=r['phase'],actor=r['actor'],s=r['summary'],idx=i))
pickle.dump(out,open('jr.pkl','wb')); print(len(out))

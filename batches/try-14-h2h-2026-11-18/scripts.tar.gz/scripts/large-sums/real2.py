import json,glob,os,pickle,collections,re,math
D='/root/t14'
out=pickle.load(open('jrc4.pkl','rb'))
need=collections.defaultdict(list)
for d in out:
  if d['worth']>300 and d.get('cls','').startswith('O-'): need[d['game']].append(d)
def q(x,y): return (0 if x<36 else 1, 0 if y<24 else 1)
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  parts=f[len(D)+1:].split('/'); gid=parts[0]+'/'+parts[1]+'/'+os.path.basename(f).replace('.log.jsonl','')
  if gid not in need: continue
  rows=[json.loads(l) for l in open(f)]
  b=rows[0]; ids={u['n']:u['id'] for u in b['units']}
  spots=[(m['x'],m['y']) for m in (b.get('markers') or [])]
  for t in b['terrain']:
    if t['k'] in ('Impassable',) and t['l']=='Special feature' or 'feature' in t['l'].lower(): spots.append((t['f']['x'],t['f']['y']))
  # turn -> action id range: map each action row index to turn/side
  pos_at={}  # (uid) -> list of (turn, x,y,on,fl) per frame in order
  turn=0; hist=collections.defaultdict(list)
  for r in rows:
    if r['kind']=='action': turn=r['turn']; side=r['side']
    if r['kind']=='frame':
      for u in r['units']: hist[u['id']].append((turn,u['x'],u['y'],u['on'],u['fl']))
  for d in need[gid]:
    uid=ids.get(d['actor']); h=hist.get(uid,[])
    if not h: continue
    after=[p for p in h if p[0]==d['turn']]; endp=h[-1]
    p0=after[-1] if after else h[-1]
    d['q_kept']= endp[3]==1 and endp[4]==0 and q(endp[1],endp[2])==q(p0[1],p0[2])
    near=lambda p: any(math.hypot(p[1]-sx,p[2]-sy)<=6.5 for sx,sy in spots)
    d['obj_kept']= endp[3]==1 and endp[4]==0 and near(endp)
    d['obj_then']= near(p0)
    d['alive_end']= endp[3]==1 and endp[4]==0
pickle.dump(out,open('jrc5.pkl','wb'))
for c in ['O-quarter','O-objectives','O-B-other','O-shots','O-C']:
  xs=[d for d in out if d.get('cls')==c and 'q_kept' in d]
  if not xs: continue
  print(c,len(xs),'alive at end %.0f%%'%(100*sum(d['alive_end'] for d in xs)/len(xs)),'same quarter at end %.0f%%'%(100*sum(d['q_kept'] for d in xs)/len(xs)),'near an objective after its move %.0f%%'%(100*sum(d['obj_then'] for d in xs)/len(xs)),'near one at end %.0f%%'%(100*sum(d['obj_kept'] for d in xs)/len(xs)), 'turn %.1f'%(sum(d['turn'] for d in xs)/len(xs)))

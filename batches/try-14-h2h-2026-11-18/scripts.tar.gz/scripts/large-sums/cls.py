import pickle,re,collections,json
jr=pickle.load(open('jr.pkl','rb'))
recs,games=pickle.load(open('recs.pkl','rb'))
# points map per game: actor -> points (from destroyed x N)
pts=collections.defaultdict(dict)
for r in recs:
  if r['apts']: pts[r['game']][r['actor']]=r['apts']
# also names map
import glob,os
D='/root/t14'
names={}
ptsid={}
for f in glob.glob(D+'/*/*/**/*.log.jsonl',recursive=True):
  parts=f[len(D)+1:].split('/'); gid=parts[0]+'/'+parts[1]+'/'+os.path.basename(f).replace('.log.jsonl','')
  if gid not in set(games): continue
  with open(f) as fh: b=json.loads(fh.readline())
  names[gid]={u['id']:u['n'] for u in b['units']}
  # points of every unit from JobSplit rows both sides
  pid=ptsid.setdefault(gid,{})
  for l in open(f):
    for i_,p_ in re.findall(r'#(\d+) [^#|;"]{1,70}? \((\d+) pts',l): pid.setdefault(int(i_),float(p_))
    if '"JobSplit"' in l and 'destroyed' in l:
      d=json.loads(l); m=re.search(r'destroyed [\d.]+ x (\d+\.\d)',d['summary'])
      if m and d['actor']: pts[gid].setdefault(d['actor'],float(m.group(1)))
def num(p,s,default=None):
  m=re.search(p,s); return float(m.group(1)) if m else default
out=[]
for r in jr:
  s=r['s']; w=num(r'worth ([+-]\d+\.\d) VP',s)
  if w is None: continue
  m=re.match(r'JOB RISK: (.*?): gain',s); label=m.group(1) if m else ''
  tid=re.search(r'#(\d+)',label); tid=int(tid.group(1)) if tid else None
  d=dict(r,worth=w,label=label,tid=tid,tname=names[r['game']].get(tid) if tid else None)
  d['tpts']=(ptsid[r['game']].get(tid) or pts[r['game']].get(d['tname'])) if tid else None
  d['apts']=pts[r['game']].get(r['actor'])
  if label.startswith('charge'):
    d['k']='charge'
    d['G']=num(r'3 rounds kills (-?\d+\.\d)',s); d['L']=num(r'losses (-?\d+\.\d)',s); d['net']=num(r' net (-?\d+\.\d)',s)
    d['dest']=num(r'destroyed (\d\.\d+) we-are',s); d['own']=num(r'own figure (-?\d+\.\d)',s); d['added']=num(r'rounds added (-?\d+\.\d)',s)
    d['nr']=len(re.findall(r'\br\d+ \+',s)); d['flee']=num(r'flee-reaction (\d\.\d+)',s); d['fg']=num(r'flee-reaction \d\.\d+ (-?\d+\.\d)',s)
    d['B']=num(r'FIVE: charge, next turn ([+-]\d+\.\d)',s)
    # per-round kill/out
    d['rk']=[(float(a),float(b),float(c),float(e)) for a,b,c,e in re.findall(r'r\d+ \+(\d+\.\d)/-(\d+\.\d) \(out \+(\d+\.\d)/-(\d+\.\d)\)',s)]
    d['joint']='JOINT' in s or 'together' in s
  else:
    k=label.split(' by ')[0].split()[0] if label else '?'
    d['k']=k
    seg=s.split('|| else')[0]
    d['A_obj']=num(r'A objectives (-?\d+\.\d)',seg,0); d['A_sh']=num(r'shoots (-?\d+\.\d)',seg,0); d['A_mi']=num(r'missiles (-?\d+\.\d)',seg,0)
    d['A_feat']=num(r'feature (-?\d+\.\d)',seg,0); d['A_q']=num(r'quarter (-?\d+\.\d)',seg,0)
    mb=re.search(r'\| B (\w+) (-?\d+\.\d) x (\d+)%(?: on #(\d+))?',seg)
    d['Bk'],d['Braw'],d['Bp'],d['Bt']=(mb.group(1),float(mb.group(2)),float(mb.group(3))/100,int(mb.group(4)) if mb.group(4) else None) if mb else (None,0,0,None)
    d['Btname']=names[r['game']].get(d['Bt']) if d['Bt'] else None
    d['Btpts']=(ptsid[r['game']].get(d['Bt']) or pts[r['game']].get(d['Btname'])) if d['Bt'] else None
    d['C']=num(r'\| C support (-?\d+\.\d)',seg,0)+num(r'carries (-?\d+\.\d)',seg,0)+num(r'chaff (-?\d+\.\d)',seg,0)
    d['shot']=num(r'SPLIT: shoot (-?\d+\.\d)',s,0)
    d['D']=num(r'\| D (-?\d+\.\d)',seg,0)
  out.append(d)
pickle.dump(out,open('jrc.pkl','wb'))
big=[d for d in out if d['worth']>300]
print(len(out),len(big),collections.Counter(d['k'] for d in big))

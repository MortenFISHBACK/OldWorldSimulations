D=/mnt/project-files/try-14-h2h-2026-11-18; T=$1
while true; do n=0; for f in $D/*/count.txt; do c=$(awk '{print $4}' $f | cut -d/ -f1); n=$((n+c)); done; [ $n -ge $T ] && { echo "REACHED $n $(date -u +%H:%M)"; exit 0; }; sleep 60; done

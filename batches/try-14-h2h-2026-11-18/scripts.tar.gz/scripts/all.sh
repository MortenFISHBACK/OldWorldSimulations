#!/bin/bash
S=~/s14; W=~/w14r
bash $S/pull14.sh; bash $S/analyse14.sh ~/t14 $W >/dev/null
cd $S
timeout 600 python3 -I promise9.py ~/t14 > $W/promise9.out 2>&1
timeout 600 python3 -I rows.py ~/t14 > $W/rows.out 2>&1
timeout 600 python3 -I joint/build.py ~/t14 > /dev/null 2>&1; timeout 600 python3 -I joint/joint.py ~/t14 $S/joint/charges.pkl > $W/joint.out 2>&1
timeout 600 bash holds.sh > $W/holds.out 2>&1
timeout 300 python3 -I again.py ~/t14 > $W/again.out 2>&1
timeout 300 python3 -I m10.py ~/t14 > $W/m10.out 2>&1
find ~/t14 -name 'game-*.log.jsonl' | xargs grep -h '"OpponentRule"' | grep -c '"summary": "PROMISE BY ITS OWN SUM' > $W/takenoff.out
head -3 $W/report.out

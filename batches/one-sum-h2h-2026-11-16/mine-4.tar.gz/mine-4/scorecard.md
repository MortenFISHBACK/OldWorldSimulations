# Doctrine scorecard: os-h2h-mine-779e261-p4

### Scorecard: os-h2h-mine-779e261-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 2 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 5 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 6 | 2 | 10 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 8 | 1 | 0 | 0 | 0 | 513 |
| L0713 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 2 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 529 |
| L0729 | 3 | 1 | Opponent | no | 9 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 786 |
| L0926 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 1 | 2 | 1 | 0 | 3 | 0 | 0 | 49 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 2 | 6 | 0 | 0 | 0 | 556 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 501 |
| L1126 | 4 | 1 | Opponent | no | 6 | - | 0 | 4 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 3 | 0 | 0 | 440 |
| L1314 | 6 | 1 | Mine | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 7 | 2 | 2 | 2 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | no | - | 4 | 4 | 1 | 1 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 1 | 4 | 3 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 185 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 1 | 0 | 0 | 420 |
| L1719 | 3 | 1 | Mine | yes | 5 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 6 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 0 | 4 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 1 | 3 | 0 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | - | 0 | 6 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 5 | 0 | 0 | 0 | 577 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | yes | 5 | 2 | 4 | 2 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 4 | 2 | 2 | 0 | 2 | 0 | 0 | 185 |
| L2331 | 3 | 1 | Opponent | yes | 5 | - | 0 | 0 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 0 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 163 |
| **Average** | | | Mine | 29% | 2.1 | 2.5 | 2.8 | 1.2 | 0.4 | 0.0 | 0.0 | 309.2 |
| **Average** | | | Opponent | 39% | 3.0 | 2.1 | 2.2 | 2.1 | 0.6 | 0.0 | 0.0 | 117.8 |

### KPIs: os-h2h-mine-779e261-p4

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (39 of 172) | 1% (2 of 179) | 12% (41 of 351) |
| Winner chose to follow up after the loser gave ground |  | 99% (72 of 73); on the table 99% | 100% (46 of 46); on the table 100% | 99% (118 of 119); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 100% (8 of 8); on the table 100% | 100% (13 of 13); on the table 100% |
| Winner chose to pursue after the loser fled |  | 91% (21 of 23); on the table 96% | 82% (27 of 33); on the table 85% | 86% (48 of 56); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 97% (98 of 101); on the table 98% | 93% (81 of 87); on the table 94% | 95% (179 of 188); on the table 96% |
| Magic missiles tried each own turn | 50%+ | 28% (75 of 269) | 35% (60 of 170) | 31% (135 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (75 of 186) | 53% (60 of 114) | 45% (135 of 300) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (31 of 51) | 64% (45 of 70) | 63% (76 of 121) |
| Points that never fought | lower | 35% (23804 of 67942) | 40% (28528 of 71984) | 37% (52332 of 139926) |
|   infantry points that never fought | lower | 47% (7230 of 15347) | 65% (8965 of 13804) | 56% (16195 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (159 of 270) | 56% (158 of 280) | 58% (317 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.5 uses a game | 89% (8 of 9); 0.8 uses a game | 87% (27 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.4 uses a game | 40% (8 of 20); 0.3 uses a game | 44% (16 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 74% (14 of 19); 0.4 uses a game | 73% (11 of 15); 0.3 uses a game | 74% (25 of 34); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (30792 of 57750) | 49% (30826 of 63347) | 51% (61618 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (25%) | 0.8 (25%) | 2.1 (25%) |
| MARCHED: its unit marched | 1.3 (24%) | 0.3 (11%) | 1.6 (19%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.1 (5%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 1.3 (24%) | 0.5 (15%) | 1.8 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| GONE: slain | 0.7 (12%) | 1.0 (32%) | 1.6 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (4%) | 0.5 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.5 | 1.8 | 3.8 | 0.4 | 2.5 |
| not cast | 3.2 | 2.5 | 3.0 | 8.4 | 1.6 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (53%) | 0.2 (8%) | 2.1 (25%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (19%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (4%) | 0.6 (19%) | 1.8 (21%) | 0.3 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.1 (3%) | 0.2 (8%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.0 (32%) | 0.4 (17%) | 0.4 (15%) | 1.6 (19%) | 0.2 (12%) | 3.9 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.2 (7%) | 0.3 (9%) | 0.5 (6%) | 0.1 (5%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (1%) | 0.0 (0%) | 0.2 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (50%) | 0.1 (3%) | 1.1 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 60% (26 of 43) | 91% (10 of 11) | 67% (36 of 54) |
| the unit moved after it | 77% (20 of 26) | 60% (6 of 10) | 72% (26 of 36) |
| it charged on its next turn | 23% (6 of 26) | 0% (0 of 10) | 17% (6 of 36) |
| the enemy charged it first | 27% (7 of 26) | 30% (3 of 10) | 28% (10 of 36) |
| it fought by the end of its next turn | 19% (5 of 26) | 50% (5 of 10) | 28% (10 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (3 of 26) | 0% (0 of 10) | 8% (3 of 36) |
| none of these (no charge, no fight, no charge escaped) | 46% (12 of 26) | 50% (5 of 10) | 47% (17 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (607 of 910) | 55% (292 of 532) | 62% (899 of 1442) |
|   cavalry | 61% (51 of 83) | 73% (85 of 116) | 68% (136 of 199) |
|   character | 45% (45 of 101) | 15% (19 of 123) | 29% (64 of 224) |
|   chariot | 58% (67 of 115) | 44% (12 of 27) | 56% (79 of 142) |
|   infantry | 64% (175 of 274) | 69% (159 of 231) | 66% (334 of 505) |
|   monster | 47% (24 of 51) | 26% (5 of 19) | 41% (29 of 70) |
|   war machine | 86% (245 of 286) | 75% (12 of 16) | 85% (257 of 302) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (20%) | 1.5 (22%) | 3.2 (21%) |
| CHARGED: it charged | 1.1 (14%) | 1.6 (24%) | 2.8 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.4 (5%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.1 (24%) | 1.1 (17%) | 3.2 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.6 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (21%) | 1.4 (22%) | 3.2 (21%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.6 | 79% | 5.8 pts | 34 pts |
| character | 2.1 | 0.6 | 79% | 6.8 pts | 14 pts |
| chariot | 2.2 | 1.1 | 70% | 11.0 pts | 24 pts |
| infantry | 13.5 | 5.0 | 73% | 10.4 pts | 141 pts |
| monster | 0.9 | 0.2 | 84% | 4.0 pts | 4 pts |
| war machine | 7.1 | 6.6 | 58% | 32.9 pts | 235 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 5.6 | 5.0 |
| Charges that made contact a game | 3.4 | 3.8 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.76 contact (17 units) | 0.31 declared, 0.31 contact (16 units) | 0.55 declared, 0.55 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.57 contact (7 units) | 1.10 declared, 1.10 contact (10 units) | 0.88 declared, 0.88 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.42 contact (246 units) | 0.63 declared, 0.41 contact (293 units) | 0.61 declared, 0.42 contact (539 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (52 of 81) | 38% (6 of 16) | 67% (4 of 6) | 60% (62 of 103) |
| Character in a unit | 88% (29 of 33) | 72% (13 of 18) | 100% (1 of 1) | 83% (43 of 52) |
| Character on its own | 81% (26 of 32) | 42% (10 of 24) | 26% (20 of 77) | 42% (56 of 133) |
| Chariot | 67% (10 of 15) | 83% (10 of 12) | - | 74% (20 of 27) |
| Infantry | 52% (43 of 83) | 40% (10 of 25) | 50% (3 of 6) | 49% (56 of 114) |
| Monster | 50% (17 of 34) | 64% (9 of 14) | - | 54% (26 of 48) |
| Monstrous | 86% (12 of 14) | 71% (10 of 14) | - | 79% (22 of 28) |
| War Machines | 72% (31 of 43) | 50% (1 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 22% (22 of 102) | 12% | 59% (13 of 22) | 83% (5 of 6); 2.2 uses a game | 50% (1 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (12 of 12); on the table 100% | 50% (12 of 24) | 25% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 88% (7 of 8); on the table 88% | - | 64% | 59% (16 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (12 of 12); on the table 100% | 72% (13 of 18) | 51% | 69% (43 of 62) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (15 of 15); on the table 100% | 31% (26 of 84) | 45% | 46% (17 of 37) | 89% (8 of 9); 6.5 uses a game | 50% (1 of 2); 0.2 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 9 | 100% (29 of 29); on the table 100% | 31% (11 of 36) | 37% | 54% (38 of 70) | 100% (7 of 7); 3.2 uses a game | 40% (12 of 30); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 50% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 94% (15 of 16); on the table 94% | 67% (4 of 6) | 10% | 48% (10 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 48% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 92% (11 of 12); on the table 92% | 17% (7 of 42) | 28% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (6 of 6); on the table 100% | 32% (12 of 38) | 45% | 64% (29 of 45) | 100% (3 of 3); 1.7 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 92% | 17% (1 of 6) | 28% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 81% (13 of 16); on the table 88% | 32% (19 of 59) | 36% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 92% (24 of 26); on the table 96% | 25% (3 of 12) | 35% | 57% (41 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (9 of 9); on the table 100% | 83% (5 of 6) | 47% | 59% (33 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (45) | 48% (32) | 50% (77) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.56 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.17 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.44 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.67 | 1.33 | 3.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.56 | 1.47 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.67 | 6.81 | 11.47 |

### Quality by phase: os-h2h-mine-779e261-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 47% (70 of 148) | 43% (69 of 159) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (207 of 435) | 50% (86 of 173) |
| Strategy | Close-in objectives charged next turn | 13% (22 of 164) | 10% (22 of 219) |
| Strategy | Support requests answered (helper made contact too) | 50% (7 of 14) | 39% (11 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 56% (22 of 39) | 15% (5 of 33) |
| Strategy | Lone characters that fought | 79% (66 of 84) | 81% (67 of 83) |
| Movement | Charges halted short of contact | 0.2 | 0.4 |
| Movement | Idle units | 1.2 | 2.1 |
| Movement | Points that never moved of their own | 309.2 | 117.8 |
| Movement | Fights charged into per game | 3.1 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 94, net -27 | 15 of 96, net +118 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 94, net -33 | 24 of 96, net +162 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 94, net +101 | 7 of 96, net +141 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 94, net +56 | 21 of 96, net +109 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (189 of 387) | 41% (134 of 328) |
| Shooting | Points destroyed by shooting units | 147.9 | 80.5 |
| Shooting | War machine shots | 6.8 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (138 of 245) | 0% (0 of 12) |
| Shooting | Points destroyed by war machines | 53.8 | 8.2 |
| Magic | Magic missiles cast | 1.4 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (18 of 49) | 21% (10 of 48) |
| Magic | Wounds caused by magic missiles | 3.7 | 2.0 |
| Magic | Wounds caused by other spells | 2.0 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 116.9 | 16.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 1.0 / 0.2 | 1.5 / 0.5 / 0.6 / 0.0 |
| Combat | Points destroyed in combat | 222.8 | 520.2 |
| Combat | Points run down | 71.2 | 78.6 |
| Combat | Net points per charged fight, damage counted | +17 | +129 |
| Combat | Net per 100 charger points, damage counted | +6.6 | +36.6 |
| Combat | First round won (charged fights) | 72% | 74% |
| Combat | Net points per charged fight | +10 | +128 |
| Combat | Net points per supported fight / lone fight | +19 / +9 | +123 / +130 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 110 | 52 of 110 |
| Game | Points lost | 802.5 | 663.5 |
| Game | VP from objectives | 530.3 | 593.1 |
| Game | Lone holders (player turns) | 2.1 | 3.0 |

- Mine won / drew / lost: 12 / 6 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -228 VP
- The side that went first won 18 of 30 games with a winner
- Points traded per game (both sides' losses): 1466
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-mine-779e261-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.6 | -158.9 | 171.4 | 94.8 | - | - | - | - |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 31.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.4 | +1.7 | 0.0 | 0.0 | 0.9 | +8.3 | 0.0 | 5.4 |
| BEST FACING | 0.4 | +25.4 | 0.0 | 16.1 | 0.7 | +15.3 | 0.0 | 36.8 |
| BEST FIRST | 1.1 | +33.3 | 37.8 | 33.7 | 4.2 | +127.5 | 134.6 | 106.9 |
| BEST OVERALL | 0.2 | +9.4 | 0.0 | 12.6 | 0.6 | +36.9 | 0.0 | 7.1 |
| BEST PREY | 0.6 | +37.3 | 3.6 | 12.6 | 1.0 | +37.7 | 12.4 | 12.9 |
| BEST PRIZE | 0.1 | -4.1 | 6.4 | 11.9 | 0.1 | -0.7 | 15.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | +1.1 | 0.0 | 46.3 | 0.2 | +0.3 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.5 | 6.5 | 0.1 | +0.0 | 15.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +15.9 | 0.0 | 0.0 | 0.5 | +13.3 | 0.0 | 1.9 |
| BLOWS WHERE AIMED | 0.2 | -6.6 | 8.2 | 9.1 | 0.3 | -42.8 | 26.6 | 0.0 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 107.0 | 6.1 | - | - | - | - |
| CANNON PLANNED TARGET | 5.1 | +215.3 | 306.5 | 111.4 | 0.3 | +23.2 | 15.0 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 13.1 | 5.2 | 0.0 | +0.0 | 6.3 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 21.9 | 0.0 | 0.1 | +0.0 | 8.9 | 0.0 |
| CAST JOB | 0.9 | +29.6 | 56.2 | 27.9 | 0.4 | +4.4 | 22.4 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +50.1 | 13.8 | 17.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 64.9 | 0.3 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +49.6 | 0.0 | 19.7 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.9 | 28.6 | 0.0 | 0.1 | -0.3 | 22.6 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 272.3 | 175.7 | 2.6 | +0.0 | 296.3 | 48.7 |
| CHARGE NOW WEIGHED | 0.6 | -24.0 | 15.1 | 11.6 | 0.7 | -29.6 | 9.1 | 19.1 |
| CHARGER SLAIN LOST | 0.7 | -24.1 | 78.0 | 11.4 | 0.9 | -38.8 | 164.0 | 19.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.2 | +0.0 | 0.0 | 11.1 | 0.2 | -0.4 | 6.4 | 41.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.3 | 6.3 | 0.1 | +0.0 | 22.1 | 2.7 |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 26.6 | 0.4 | +0.0 | 49.7 | 46.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +110.5 | 22.8 | 23.8 | 0.2 | +52.0 | 11.1 | 11.1 |
| COUNTER-CHARGE COVER | - | - | - | - | 8.1 | +592.9 | 0.0 | 123.1 |
| COVER ONCE | 6.6 | -333.2 | 0.0 | 209.8 | - | - | - | - |
| DEFENSIVE ARMY | 0.3 | -0.0 | 3.3 | 7.6 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +3.8 | 0.0 | 6.1 | 0.1 | +5.3 | 19.2 | 4.4 |
| EDGE GIVE GROUND | 0.0 | +0.6 | 0.0 | 2.2 | 0.1 | +2.3 | 17.2 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +103.2 | 0.0 | 66.1 | 1.3 | +89.5 | 0.0 | 52.8 |
| FALLBACK BY WORTH | 4.0 | +18.8 | 0.0 | 85.8 | 7.2 | +61.8 | 0.0 | 80.7 |
| FIGHT LIFT | 0.1 | +1.2 | 13.1 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.2 | 0.0 | 3.5 |
| FLANK NOT WEIGHED | 4.1 | +0.0 | 0.0 | 146.9 | 6.7 | +0.0 | 0.0 | 107.9 |
| FOLLOW UP WEIGHED | 1.1 | +180.8 | 0.0 | 95.4 | 0.9 | +141.9 | 0.0 | 11.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +15.4 | 0.0 | 14.6 | 0.1 | +9.7 | 0.0 | 0.8 |
| GIVES UP | 0.1 | -1.2 | 12.2 | 0.0 | 0.1 | -1.0 | 10.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.2 | 3.4 | 1.2 |
| GROUND FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 15.9 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 16.5 | 58.1 | 0.4 | +0.0 | 51.1 | 8.9 |
| HILL BY ITS CHANCE | 0.7 | -65.2 | 0.0 | 6.0 | 0.5 | -38.1 | 0.0 | 6.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.1 | -138.3 | 485.6 | 229.2 | 8.4 | -199.3 | 518.8 | 113.1 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +0.9 | 3.9 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +13.4 | 0.0 | 0.0 | 0.5 | +33.6 | 0.0 | 3.1 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.6 | 3.9 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +39.3 | 3.5 | 3.1 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +69.2 | 39.2 | 1.2 |
| IDLE COST | 16.6 | -274.1 | 0.0 | 270.4 | - | - | - | - |
| INVITES THE FIGHT | 1.5 | +12.0 | 48.0 | 21.2 | 1.6 | +24.9 | 37.8 | 23.8 |
| JOINT CHARGE PLAN | 0.2 | +2.7 | 19.9 | 5.2 | 0.1 | +4.2 | 8.9 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.4 | 6.7 | 0.0 | 0.3 | -9.7 | 54.2 | 0.8 |
| KEEP FALLS | 0.2 | +2.0 | 0.0 | 6.1 | 0.0 | +1.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.7 | +50.0 | 145.2 | 54.2 | 2.1 | +61.7 | 235.1 | 27.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +86.7 | 157.2 | 111.9 | 1.5 | +108.1 | 146.5 | 34.0 |
| KILLS COUNT NEXT TURN | 4.9 | +169.4 | 202.5 | 159.4 | 6.6 | +230.7 | 236.6 | 116.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +11.8 | 0.0 | 2.5 | 0.4 | +11.5 | 24.7 | 46.4 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 9.1 | 16.1 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -4.2 | 35.7 | 22.2 | 0.3 | -0.9 | 23.2 | 7.5 |
| LOST CHARGE | 2.5 | -31.9 | 127.0 | 82.3 | 2.1 | -29.2 | 80.9 | 59.1 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | -2.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +52.6 | 81.5 | 13.9 | 0.9 | +76.4 | 31.6 | 17.8 |
| MANOEUVRE | 0.2 | +9.3 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 5.1 |
| MARCH AT ESCAPER | 0.1 | +1.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +15.7 | 0.0 | 15.0 | 0.4 | +17.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.4 | +22.8 | 16.8 | 18.5 | 0.2 | +14.7 | 7.1 | 13.1 |
| MARCH OVER CASTS | 0.4 | +22.6 | 0.0 | 16.6 | 0.3 | +28.9 | 0.0 | 20.4 |
| MAX FOR POSITIONING | 5.6 | +89.0 | 0.0 | 162.8 | 4.6 | +172.5 | 0.0 | 58.2 |
| MISSILES IN THE MOVE | 3.9 | +150.8 | 0.0 | 105.5 | 2.6 | +44.3 | 0.0 | 90.9 |
| MISSILES NEXT TURN | 4.8 | +95.5 | 0.0 | 155.3 | 3.0 | +28.3 | 0.0 | 107.6 |
| MODEL FACING | 0.2 | +35.0 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +9.8 | 0.0 | 0.0 | 0.2 | +16.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.5 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -39.8 | 25.5 | 9.9 | 0.1 | -3.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 27.8 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.4 | +169.6 | 209.1 | 107.5 | 4.0 | +313.1 | 167.1 | 39.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +8.9 | 3.5 | 0.0 | 0.1 | +6.3 | 17.2 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.9 | 0.0 | 11.6 | 0.0 | +0.2 | 0.0 | 1.8 |
| NOT NEEDED | 0.2 | -12.9 | 32.3 | 5.4 | 0.2 | -14.3 | 48.9 | 2.5 |
| NOT TURNED | 4.7 | +100.0 | 0.0 | 150.8 | 6.8 | +55.1 | 0.0 | 106.0 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 48.5 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.3 | -667.8 | 0.0 | 279.6 | 15.0 | -831.6 | 11.8 | 192.4 |
| ONE FIGHT FORMULA | 8.6 | -136.4 | 14.3 | 262.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.6 | -145.8 | 0.0 | 43.9 | - | - | - | - |
| OPENS A LANE | 0.1 | +1.0 | 8.8 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +11.7 | 20.2 | 0.0 | 0.2 | +26.6 | 14.2 | 0.0 |
| OVERRUNS AWAY | 0.8 | +16.1 | 49.5 | 32.2 | 0.3 | +6.4 | 35.6 | 7.4 |
| PATHS CROSS | 1.9 | +137.2 | 0.0 | 11.0 | 3.2 | +241.5 | 0.0 | 54.6 |
| PERIAPT WORTH | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +6.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.5 | 0.0 | 13.2 | 0.2 | -2.6 | 0.0 | 0.0 |
| PLAN RESULT | 38.9 | +1387.3 | 1688.7 | 1261.3 | 39.1 | +1355.5 | 1613.0 | 949.5 |
| PURSUES BIG PREY | 0.1 | -7.4 | 0.0 | 0.0 | 0.1 | -7.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.3 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.4 | +12.7 | 0.0 | 23.8 | 1.9 | +25.6 | 0.0 | 53.2 |
| RANDOM MOVER NO PROMISE | 0.2 | -9.1 | 0.0 | 5.8 | 0.5 | -26.3 | 13.3 | 16.4 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -4.7 | 0.0 | 17.9 | 0.8 | -20.9 | 0.0 | 10.8 |
| REDIRECT COUNTER | 2.3 | +94.4 | 0.0 | 42.6 | 3.9 | +264.6 | 0.0 | 53.4 |
| REDIRECT WEIGHED | 0.4 | +9.2 | 14.2 | 8.2 | 0.5 | +4.4 | 19.0 | 2.5 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 33.3 | 0.3 | +0.0 | 0.0 | 7.1 |
| RESERVE FALL BACK | 0.5 | +17.4 | 0.0 | 14.3 | 0.8 | +32.0 | 0.0 | 7.8 |
| RESTRAINS TO SHOOT | 0.1 | +5.8 | 0.0 | 5.1 | 0.0 | +4.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +148.1 | 267.2 | 130.7 | 2.4 | +11.0 | 345.1 | 51.0 |
| RISK ONCE | 1.7 | +24.4 | 14.8 | 108.6 | - | - | - | - |
| SAFE SURE CHARGE | 0.0 | -0.1 | 5.2 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +49.3 | 0.0 | 14.3 | 0.6 | +28.7 | 0.0 | 16.7 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.6 | 0.0 | 1.8 | 0.2 | -13.5 | 0.0 | 1.5 |
| SEARCH SPOT | 2.0 | +87.2 | 0.0 | 24.1 | 2.8 | +137.5 | 0.0 | 25.3 |
| SELF MOVE SPELL | 0.2 | +44.6 | 0.0 | 0.0 | 0.4 | +16.3 | 0.0 | 40.1 |
| SET UP TOGETHER | 0.8 | +73.5 | 81.5 | 32.2 | 1.4 | +105.3 | 36.8 | 32.5 |
| SET-UP ANY TARGET | 0.5 | +76.4 | 22.8 | 13.9 | 0.1 | +10.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +61.4 | 90.4 | 56.1 | 0.9 | +19.9 | 42.2 | 17.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.4 | +0.0 | 86.4 | 6.1 | 0.3 | +0.0 | 65.0 | 0.0 |
| SHOTS IN THE MOVE | 15.5 | +751.2 | 0.0 | 310.6 | 7.4 | +214.0 | 0.0 | 124.8 |
| SPELL OFF EDGE | 0.0 | +1.5 | 4.0 | 0.0 | 0.0 | +1.0 | 2.6 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +108.4 | 22.8 | 13.9 | 0.1 | +42.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +21.8 | 85.8 | 111.1 | 2.1 | +34.7 | 108.3 | 108.3 |
| SPELLS IN THE FIGHT | 0.7 | -8.0 | 133.5 | 50.5 | 0.9 | -15.3 | 192.9 | 39.4 |
| STABLE ROLE | 11.7 | +0.0 | 507.9 | 234.2 | 10.4 | +0.0 | 420.4 | 91.5 |
| STAY WEIGHED | 0.2 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.2 | +9.8 | 39.2 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +29.0 | 0.0 | 19.3 | 0.4 | +8.5 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 7.0 | -60.2 | 502.5 | 181.3 | 6.8 | -49.9 | 394.5 | 93.7 |
| SUPPORTS | 4.6 | +63.6 | 297.4 | 67.6 | 4.9 | +51.2 | 136.2 | 35.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.8 | 0.0 | 11.1 | 0.1 | -12.0 | 6.4 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -1.7 | 0.0 | 1.7 | 0.9 | +5.8 | 14.2 | 20.7 |
| THROUGH LINE OF FIRE | 0.2 | +18.0 | 0.0 | 0.0 | 0.2 | +17.2 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -24.5 | 32.5 | 7.0 | 0.2 | -18.9 | 22.0 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +0.8 | 71.7 | 19.1 | 0.5 | +3.1 | 6.4 | 19.1 |
| WAIT AFTER COSTS | 7.0 | -298.0 | 318.6 | 152.9 | 7.6 | -381.0 | 291.7 | 100.2 |
| WALKS TO THE FIGHT | 1.8 | +11.0 | 40.1 | 30.7 | 0.8 | +12.4 | 33.5 | 10.4 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 62.4 | 18.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.1 | +39.5 | 113.0 | 54.2 | 1.5 | +52.7 | 178.1 | 20.6 |
| WHO HITS BACK | 0.3 | +22.5 | 0.0 | 26.6 | 0.2 | +16.7 | 0.0 | 8.9 |
| WHOLE FIGHT | 0.2 | +6.0 | 21.2 | 21.4 | 0.6 | +48.2 | 181.2 | 11.0 |
| WHOLE FIGHT GAIN | 0.3 | +25.0 | 18.6 | 17.8 | 0.6 | +34.3 | 64.9 | 10.7 |
| WIDER SPREAD | 2.8 | -6.0 | 213.2 | 166.0 | 2.9 | -3.6 | 395.1 | 55.7 |

### Rule changes: os-h2h-mine-779e261-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1125 | 1125 | 1125 | 31.25 | -53982 | -48.0 |
| BEST FIRST | 191 | 191 | 191 | 5.31 | +5790 | +30.3 |
| PATHS CROSS | 183 | 183 | 183 | 5.08 | +13634 | +74.5 |
| SEARCH SPOT | 171 | 171 | 164 | 4.56 | +8167 | +49.8 |
| MOVE TO CHARGE | 264 | 264 | 142 | 3.94 | +6184 | +43.5 |
| KILLS COUNT NEXT TURN | 415 | 415 | 138 | 3.83 | +3665 | +26.6 |
| SUPPORTS | 344 | 344 | 120 | 3.33 | +1214 | +10.1 |
| FACES THE THREAT | 108 | 108 | 108 | 3.00 | +6937 | +64.2 |
| SHOTS IN THE MOVE | 823 | 563 | 85 | 2.36 | +2504 | +29.5 |
| RANDOM MOVE BY FIGURES | 121 | 121 | 76 | 2.11 | +1379 | +18.1 |
| WAIT AFTER COSTS | 527 | 527 | 74 | 2.06 | +1057 | +14.3 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +11619 | +163.7 |
| FALLBACK BY WORTH | 403 | 403 | 67 | 1.86 | +2901 | +43.3 |
| COUNTER-CHARGE COVER | 290 | 143 | 60 | 1.67 | +3144 | +52.4 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| SAFER THAN THE JOB | 53 | 53 | 53 | 1.47 | +2810 | +53.0 |
| REDIRECT COUNTER | 223 | 129 | 50 | 1.39 | +3595 | +71.9 |
| ARTILLERY RE-ROLL WEIGHED | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1779 | +37.8 |
| MISSILES IN THE MOVE | 233 | 151 | 46 | 1.28 | +1130 | +24.6 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +1723 | +38.3 |
| CHARGE NOW FIRST | 188 | 188 | 43 | 1.19 | -2675 | -62.2 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 41 | 1.14 | +1298 | +31.6 |
| SET UP TOGETHER | 79 | 69 | 40 | 1.11 | +2372 | +59.3 |
| BEST FACING | 39 | 39 | 39 | 1.08 | +1464 | +37.5 |
| RISK BY ARC | 193 | 187 | 38 | 1.06 | +1186 | +31.2 |
| WALKS TO THE FIGHT | 95 | 95 | 38 | 1.06 | +169 | +4.5 |
| MAX FOR POSITIONING | 367 | 209 | 37 | 1.03 | +356 | +9.6 |
| COVER ONCE | 239 | 127 | 36 | 1.00 | +435 | +12.1 |
| KILLS COUNT | 123 | 121 | 36 | 1.00 | +2640 | +73.3 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +1052 | +30.1 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| ADVANCE WORTH | 203 | 203 | 34 | 0.94 | +376 | +11.1 |
| ONE FIGHT FORMULA | 308 | 190 | 34 | 0.94 | +82 | +2.4 |
| REDIRECT WEIGHED | 32 | 32 | 32 | 0.89 | +1414 | +44.2 |
| BEST OVERALL | 31 | 31 | 31 | 0.86 | +1669 | +53.9 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1351 | +43.6 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| INVITES THE FIGHT | 112 | 112 | 29 | 0.81 | +287 | +9.9 |
| HONEST WORTH | 594 | 590 | 28 | 0.78 | +234 | +8.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MARCH CHECK | 30 | 30 | 27 | 0.75 | +1250 | +46.3 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| CAST JOB | 47 | 47 | 25 | 0.69 | +473 | +18.9 |
| CANNON PLANNED TARGET | 193 | 193 | 24 | 0.67 | -805 | -33.5 |
| IDLE COST | 597 | 338 | 22 | 0.61 | +283 | +12.9 |
| MAKE SURE TOGETHER | 52 | 42 | 22 | 0.61 | +1399 | +63.6 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +175 | +8.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BEST PREY | 58 | 58 | 20 | 0.56 | +724 | +36.2 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +943 | +47.2 |
| KEEPS ITS TARGET | 134 | 134 | 19 | 0.53 | +343 | +18.1 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +854 | +44.9 |
| BIG CHARACTER SAFETY | 18 | 18 | 18 | 0.50 | +50 | +2.8 |
| CHAFF IN THE MOVE | 27 | 26 | 18 | 0.50 | +580 | +32.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| WEARS DOWN | 94 | 90 | 18 | 0.50 | +436 | +24.2 |
| WHOLE FIGHT GAIN | 33 | 30 | 18 | 0.50 | +726 | +40.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +1267 | +79.2 |
| MISSILES NEXT TURN | 281 | 179 | 13 | 0.36 | +48 | +3.7 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -45 | -3.7 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +903 | +90.3 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -112 | -11.2 |
| WAR ENGINE JOBS | 32 | 32 | 10 | 0.28 | -596 | -59.6 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -452 | -50.2 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| HUNT IN PAIRS | 32 | 20 | 9 | 0.25 | +158 | +17.6 |
| OPENS UP | 15 | 15 | 9 | 0.25 | +549 | +61.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT | 29 | 29 | 9 | 0.25 | +871 | +96.8 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MANOEUVRE | 8 | 8 | 8 | 0.22 | +404 | +50.5 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +1260 | +157.6 |
| OVERRUNS AWAY | 38 | 38 | 8 | 0.22 | +111 | +13.9 |
| REFUSING RETIRES | 25 | 25 | 8 | 0.22 | -4 | -0.5 |
| RISK ONCE | 60 | 41 | 8 | 0.22 | +207 | +25.9 |
| WIDER SPREAD | 202 | 195 | 8 | 0.22 | +71 | +8.8 |
| CASTING BLOCK | 15 | 15 | 7 | 0.19 | +513 | +73.3 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +290 | +41.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SUPPORT NARROWED | 498 | 498 | 7 | 0.19 | -303 | -43.3 |
| BACKUP TARGETS | 46 | 24 | 6 | 0.17 | +10 | +1.6 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +375 | +62.6 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -495 | -82.5 |
| SURE REACH TOGETHER | 44 | 34 | 6 | 0.17 | +98 | +16.4 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +444 | +88.8 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -545 | -109.1 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 5 | 0.14 | +170 | +34.0 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 4 | 0.11 | -72 | -18.1 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +31 | +7.8 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +371 | +92.8 |
| CHARGER SLAIN LOST | 59 | 57 | 3 | 0.08 | +218 | +72.8 |
| LOST CHARGE | 166 | 166 | 3 | 0.08 | +49 | +16.4 |
| SPELLS IN THE FIGHT | 59 | 57 | 3 | 0.08 | +34 | +11.4 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -191 | -95.4 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +94 | +46.8 |
| HILL BY ITS CHANCE | 42 | 42 | 2 | 0.06 | +101 | +50.4 |
| JOINT CHARGE PLAN | 13 | 13 | 2 | 0.06 | +31 | +15.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 27 | 27 | 2 | 0.06 | +19 | +9.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -2.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 4 | 4 | 1 | 0.03 | +92 | +91.7 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +8 | +8.2 |
| ONE OBJECTIVE FORMULA | 94 | 44 | 1 | 0.03 | +2 | +1.8 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +125 | +125.0 |
| REDIRECT BY WHAT IT STOPS | 48 | 48 | 1 | 0.03 | +37 | +37.2 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -61 | -60.8 |
| STOPS | 8 | 8 | 1 | 0.03 | +5 | +5.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 21 | 21 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 12 | 12 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 6 | 6 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 390 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 13 | 11 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 23 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 24 | 24 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 413 | 413 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 2806 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 124 | not checked | - | - | - | - |
| STABLE ROLE | 797 | 795 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 22 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 31 | 28 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.19 | 12.78 | 49.4 |
| FALLBACK | gate | 0.42 | 0.94 | 36.2 |
| CHARGE NOW FIRST | rule | 0.47 | 0.67 | 65.2 |
| TURN GATE | gate | 0.31 | 0.69 | 45.5 |
| PATHS CROSS | rule | 0.11 | 0.25 | 19.5 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.19 | 11.2 |
| WAR ENGINE JOBS | rule | 0.28 | - | 59.6 |
| BEST PRIZE | rule | 0.14 | 0.11 | 50.2 |
| AFTERMATH BAND | gate | 0.14 | 0.08 | 2.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.14 | 17.4 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.08 | 5.5 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 133.6 |
| SUPPORT NARROWED | rule | 0.08 | 0.11 | 43.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.11 | 23.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 60.4 |
| FIGHT ORDER BAND | gate | 0.03 | 0.11 | 1.1 |
| MARCH ODDS | rule | 0.08 | 0.06 | 29.4 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 109.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.08 | 98.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 52.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 24.1 |
| REDIRECT WEIGHED | rule | - | 0.08 | 62.6 |
| REFUSING RETIRES | rule | 0.06 | 0.03 | 0.9 |
| RULE SWITCHED OFF | gate | - | 0.08 | 30.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 4.3 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 5.2 |
| CHAFF PASSED | rule | 0.03 | 0.03 | 22.4 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 95.4 |
| FACES THE THREAT | rule | 0.06 | - | 5.1 |
| FALLBACK BY WORTH | rule | 0.03 | 0.03 | 116.8 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 7.5 |
| CATCH ODDS | rule | - | 0.03 | 2.4 |
| SAFE SURE CHARGE | rule | 0.03 | - | 60.8 |
| WHO HITS BACK | rule | 0.03 | - | 3.8 |

### Plans: os-h2h-mine-779e261-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.0 | 16% | 149 | 206 | 139% |
| Mine | charge | 3.4 | 54% | 212 | 253 | 120% |
| Mine | close in | 4.5 | 24% | 206 | 116 | 56% |
| Mine | hold | 5.1 | 33% | 316 | 0 | 0% |
| Mine | join | 0.5 | 89% | 12 | 0 | 0% |
| Mine | shoot | 10.1 | 63% | 430 | 812 | 189% |
| Mine | support | 5.2 | 94% | 53 | 0 | 0% |
| Opponent | advance | 14.7 | 16% | 373 | 412 | 111% |
| Opponent | charge | 3.8 | 61% | 386 | 531 | 137% |
| Opponent | close in | 6.1 | 20% | 410 | 169 | 41% |
| Opponent | hold | 4.1 | 32% | 266 | 0 | 0% |
| Opponent | join | 0.5 | 89% | 24 | 0 | 0% |
| Opponent | shoot | 4.1 | 62% | 93 | 249 | 269% |
| Opponent | support | 5.7 | 92% | 36 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Opponent | 0.2 | 9 | 2 | 86% | 71% | 0% | 2.2 | 307 | 202 | 71% | 111 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.4 | 4 | 2 | 50% | 50% | 0% | 3.0 | 188 | 102 | 50% | 115 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 100% | 67% | 0% | 2.0 | 305 | 153 | 67% | 107 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 223 | 174 | 100% | 45 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 638 | 580 | 100% | 17 |

### Battle groups: os-h2h-mine-779e261-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 32% | 67% | 11% | 0% | 29% | 0% | 4% | 62% | 4% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 21% | 73% | 15% | 44% | 42% | 6% | 4% | 49% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 19% | 78% | 15% | 50% | 22% | 0% | 4% | 70% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.5 | - | - | - | - | - |
| Mine | Chaff | 34 | 18 (34) | 3 | 15 | 64 | 41% | 1.9 | 9 (14) | 0 (7) | 35 (13) | 5 (22) | 42 (12) |
| Mine | Character | 106 | 38 (106) | 38 | 0 | 49 | 14% | 2.3 | 33 (32) | 47 (55) | 0 (6) | 45 (45) | 35 (48) |
| Mine | Clean-up | 22 | 58 (22) | 29 | 30 | 47 | 23% | 3.5 | 56 (2) | 55 (16) | 71 (4) | 72 (10) | 51 (12) |
| Mine | Early | 1 | 60 (1) | 60 | 0 | 0 | 0% | 6.0 | - | 60 (1) | - | - | 60 (1) |
| Mine | Fast | 4 | 45 (4) | 45 | 0 | 73 | 0% | 3.2 | 0 (2) | 89 (2) | - | 0 (3) | 166 (1) |
| Mine | Fast Hammer | 41 | 49 (41) | 34 | 15 | 41 | 17% | 2.8 | 45 (27) | 57 (9) | 61 (5) | 59 (25) | 35 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 50% | 2.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 30 (65) | 19 | 11 | 45 | 18% | 2.4 | 29 (13) | 34 (45) | 0 (7) | 33 (40) | 26 (25) |
| Mine | Holder | 31 | 111 (31) | 25 | 85 | 27 | 29% | 2.9 | 73 (8) | 154 (19) | 7 (4) | 151 (18) | 66 (13) |
| Mine | Shooter | 34 | 74 (34) | 39 | 35 | 44 | 3% | 1.8 | 26 (8) | 110 (21) | 5 (5) | 88 (25) | 30 (9) |
| Mine | Support | 1 | 86 (1) | 86 | 0 | 0 | 0% | 6.0 | - | 86 (1) | - | 86 (1) | - |
| Mine | War machine | 56 | 58 (56) | 58 | 0 | 46 | 2% | 1.3 | 50 (16) | 76 (30) | 24 (10) | 13 (9) | 67 (47) |
| Mine | Wizard | 17 | 0 (17) | 0 | 0 | 54 | 6% | 2.0 | 0 (3) | 0 (8) | 0 (1) | 0 (5) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 75 | 43 (75) | 14 | 29 | 59 | 45% | 2.4 | 54 (31) | 73 (17) | 8 (27) | 37 (56) | 63 (19) |
| Opponent | Character | 97 | 56 (97) | 56 | 0 | 27 | 26% | 2.2 | 58 (45) | 48 (41) | 88 (7) | 50 (54) | 64 (39) |
| Opponent | Clean-up | 11 | 58 (11) | 25 | 33 | 49 | 36% | 2.3 | 0 (3) | 52 (6) | 117 (2) | 40 (6) | 68 (5) |
| Opponent | Fast | 1 | 383 (1) | 383 | 0 | 0 | 0% | 6.0 | - | 383 (1) | - | 383 (1) | - |
| Opponent | Fast Hammer | 60 | 48 (60) | 26 | 22 | 28 | 28% | 2.6 | 48 (26) | 41 (25) | 73 (9) | 40 (39) | 62 (21) |
| Opponent | Fragile | 17 | 43 (17) | 43 | 0 | 51 | 12% | 2.7 | 169 (5) | 0 (8) | 0 (4) | 37 (13) | 62 (4) |
| Opponent | Hammer | 65 | 66 (65) | 49 | 17 | 42 | 34% | 3.1 | 71 (20) | 66 (38) | 43 (7) | 93 (41) | 25 (24) |
| Opponent | Holder | 29 | 47 (29) | 15 | 33 | 23 | 66% | 3.5 | 28 (12) | 60 (12) | 54 (5) | 55 (18) | 35 (11) |
| Opponent | Shooter | 33 | 110 (33) | 55 | 54 | 36 | 0% | 1.6 | 134 (9) | 88 (21) | 203 (3) | 106 (18) | 114 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 33% | 4.5 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | War machine | 6 | 45 (6) | 45 | 0 | 61 | 17% | 1.0 | 61 (3) | 22 (3) | - | 61 (3) | 22 (3) |
| Opponent | Wizard | 19 | 18 (19) | 18 | 0 | 53 | 11% | 1.9 | 21 (10) | 49 (1) | 0 (2) | 19 (8) | 25 (5) |

### Charged fights: os-h2h-mine-779e261-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 97 | 274 | 3.2 | 1.2 | 84 | 36 | +48 | 5 of 13 | 10 of 13 | -66 | +69 |
| Mine | Chaos Dwarfs | 4 | 273 | 273 | 3.8 | 1.1 | 73 | 43 | +30 | 5 of 15 | 11 of 15 | +332 | +8 |
| Mine | Dwarfen Mountain Holds | 3 | 635 | 74 | 2.0 | 1.0 | 37 | 20 | +17 | 2 of 6 | 4 of 6 | - | +17 |
| Mine | Empire of Man | 5 | 363 | 25 | 2.2 | 1.1 | 11 | 136 | -125 | 5 of 11 | 6 of 11 | -189 | -118 |
| Mine | Grand Cathay | 4 | 635 | 176 | 3.0 | 1.2 | 59 | 53 | +5 | 4 of 12 | 10 of 12 | +65 | -14 |
| Mine | High Elf Realms | 4 | 602 | 231 | 3.2 | 1.1 | 71 | 38 | +33 | 2 of 13 | 10 of 13 | +0 | +36 |
| Mine | Kingdom of Bretonnia | 1 | 817 | 355 | 4.0 | 1.0 | 89 | 0 | +89 | 2 of 4 | 3 of 4 | - | +89 |
| Mine | Lizardmen | 1 | 55 | 391 | 8.0 | 1.0 | 49 | 113 | -64 | 5 of 8 | 5 of 8 | - | -64 |
| Mine | Ogre Kingdoms | 2 | 0 | 126 | 2.0 | 1.5 | 63 | 84 | -21 | 1 of 4 | 1 of 4 | +125 | -70 |
| Mine | Skaven | 2 | 165 | 33 | 1.5 | 1.0 | 22 | 0 | +22 | 1 of 3 | 3 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 521 | 4.0 | 1.2 | 130 | 101 | +30 | 2 of 8 | 8 of 8 | -159 | +92 |
| Mine | Vampire Counts | 2 | 0 | 578 | 4.0 | 1.2 | 145 | 41 | +104 | 3 of 8 | 6 of 8 | +116 | +100 |
| Mine | Warriors of Chaos | 2 | 58 | 0 | 2.5 | 1.0 | 0 | 19 | -19 | 1 of 5 | 2 of 5 | - | -19 |
| **Mine** | all armies | 36 | 319 | 206 | 3.1 | 1.1 | 68 | 57 | +10 | 38 of 110 | 79 of 110 | +19 | +9 |
| Opponent | Empire of Man | 1 | 460 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 267 | 514 | 3.0 | 1.2 | 171 | 0 | +171 | 10 of 15 | 10 of 15 | +301 | +139 |
| Opponent | Lizardmen | 2 | 137 | 704 | 4.0 | 1.2 | 176 | 50 | +126 | 4 of 8 | 7 of 8 | -116 | +207 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 836 | 4.7 | 1.0 | 179 | 94 | +85 | 5 of 14 | 12 of 14 | - | +85 |
| Opponent | Skaven | 4 | 138 | 16 | 0.8 | 1.0 | 22 | 0 | +22 | 1 of 3 | 1 of 3 | - | +22 |
| Opponent | Tomb Kings of Khemri | 2 | 122 | 852 | 4.5 | 1.2 | 189 | 29 | +160 | 5 of 9 | 6 of 9 | +286 | +124 |
| Opponent | Vampire Counts | 6 | 0 | 289 | 2.5 | 1.4 | 116 | 12 | +103 | 4 of 15 | 11 of 15 | +212 | +49 |
| Opponent | Warriors of Chaos | 7 | 0 | 501 | 3.0 | 1.2 | 167 | 8 | +159 | 10 of 21 | 15 of 21 | -11 | +199 |
| Opponent | Wood Elf Realms | 6 | 150 | 544 | 4.0 | 1.2 | 136 | 13 | +123 | 12 of 24 | 19 of 24 | +73 | +140 |
| **Opponent** | all armies | 36 | 105 | 466 | 3.1 | 1.2 | 152 | 24 | +128 | 52 of 110 | 81 of 110 | +123 | +130 |

### Effective charges: os-h2h-mine-779e261-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 13 | 3 (net -6) | 1 (net +0) | 1 (net +39) | 2 (net +88) | 0 | 2 (net +35) | 4 | 11% (1 of 9) |
| Mine | Chaos Dwarfs | 15 | 1 (net +0) | 0 | 3 (net -215) | 1 (net +0) | 2 (net +212) | 5 (net +72) | 3 | 25% (3 of 12) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 0 | 2 (net +30) | 0 | 4 (net +10) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 11 | 1 (net +0) | 1 (net -380) | 4 (net -16) | 3 (net -71) | 0 | 1 (net +0) | 1 | 40% (4 of 10) |
| Mine | Grand Cathay | 12 | 1 (net +0) | 1 (net +195) | 2 (net +105) | 6 (net -74) | 0 | 2 (net +54) | 0 | 17% (2 of 12) |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 2 (net +85) | 4 (net +60) | 1 (net +60) | 4 (net +78) | 1 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 1 (net +145) | 0 | 1 (net +210) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 8 | 3 (net -188) | 0 | 0 | 2 (net +118) | 0 | 0 | 3 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 4 | 2 (net +46) | 0 | 0 | 1 (net -301) | 1 (net +125) | 0 | 0 | 0% (0 of 4) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +33) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +116) | 0 | 1 (net +120) | 3 (net -34) | 1 (net +54) | 2 (net +25) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 8 | 0 | 1 (net +500) | 2 (net -164) | 3 (net +142) | 1 (net +45) | 1 (net +186) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 3 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 15 | 2 (net +115) | 0 | 6 (net +149) | 3 (net +416) | 1 (net +65) | 1 (net +0) | 2 | 46% (6 of 13) |
| Opponent | Lizardmen | 8 | 1 (net +124) | 0 | 2 (net +559) | 2 (net -200) | 1 (net +167) | 1 (net +0) | 1 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 14 | 1 (net +387) | 0 | 0 | 2 (net +248) | 1 (net +77) | 1 (net +0) | 9 | 0% (0 of 5) |
| Opponent | Skaven | 3 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 (net +65) | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 9 | 0 | 1 (net +0) | 5 (net +208) | 1 (net +236) | 0 | 2 (net +80) | 0 | 56% (5 of 9) |
| Opponent | Vampire Counts | 15 | 2 (net -45) | 1 (net +0) | 2 (net +14) | 4 (net +170) | 2 (net +52) | 4 (net +207) | 0 | 13% (2 of 15) |
| Opponent | Warriors of Chaos | 21 | 5 (net +184) | 0 | 2 (net -38) | 7 (net +127) | 2 (net +288) | 4 (net +182) | 1 | 10% (2 of 20) |
| Opponent | Wood Elf Realms | 24 | 4 (net +51) | 2 (net +142) | 5 (net +179) | 5 (net +151) | 0 | 7 (net +74) | 1 | 22% (5 of 23) |

### Charged fights, damage counted: os-h2h-mine-779e261-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 156 | 323 | -27 | 53 | 67 | -15 | -9.4 |
| Mine | 50-54% | 4 | 321 | 291 | +79 | 206 | 124 | +82 | +25.6 |
| Mine | Effective (55-75%) | 15 | 274 | 253 | -33 | 88 | 110 | -22 | -7.9 |
| Mine | 76-89% | 29 | 265 | 175 | +8 | 103 | 86 | +17 | +6.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 226 | 171 | +56 | 87 | 36 | +51 | +22.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 443 | 88 | +101 | 101 | 24 | +77 | +17.3 |
| Mine | No odds | 16 | 267 | 210 | -42 | 86 | 102 | -15 | -5.7 |
| Mine | All fights | 110 | 257 | 207 | +10 | 92 | 75 | +17 | +6.6 |
| Opponent | Long shot (under 50%) | 15 | 207 | 298 | +118 | 153 | 36 | +117 | +56.4 |
| Opponent | 50-54% | 5 | 394 | 345 | +57 | 165 | 43 | +122 | +30.9 |
| Opponent | Effective (55-75%) | 24 | 392 | 305 | +162 | 227 | 58 | +169 | +43.1 |
| Opponent | 76-89% | 24 | 376 | 180 | +163 | 193 | 30 | +163 | +43.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 340 | 200 | +109 | 143 | 33 | +109 | +32.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 597 | 99 | +141 | 161 | 48 | +112 | +18.8 |
| Opponent | No odds | 14 | 289 | 196 | +70 | 172 | 115 | +57 | +19.8 |
| Opponent | All fights | 110 | 353 | 232 | +128 | 179 | 50 | +129 | +36.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p4 | move | 393 | 84 (21%) | 62 (16%) | 52 (13%) | 257 (65%) |
| os-h2h-mine-779e261-p4 | objective | 383 | 44 (11%) | 36 (9%) | 61 (16%) | 278 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

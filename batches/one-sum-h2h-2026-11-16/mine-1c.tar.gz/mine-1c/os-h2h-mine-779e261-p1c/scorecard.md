# Doctrine scorecard: os-h2h-mine-779e261-p1c

### Scorecard: os-h2h-mine-779e261-p1c

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 1167 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 343 |
| L0717 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 513 |
| L0717 | 3 | 1 | Opponent | yes | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 12 | 1 | 1 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 315 |
| L0913 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 5 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 677 |
| **Average** | | | Mine | 11% | 1.7 | 2.4 | 2.0 | 0.7 | 0.3 | 0.0 | 0.0 | 548.8 |
| **Average** | | | Opponent | 11% | 2.6 | 2.4 | 2.2 | 1.6 | 0.6 | 0.0 | 0.0 | 259.4 |

### KPIs: os-h2h-mine-779e261-p1c

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 70% (32 of 46) | 0% (0 of 44) | 36% (32 of 90) |
| Winner chose to follow up after the loser gave ground |  | 100% (14 of 14); on the table 100% | 100% (8 of 8); on the table 100% | 100% (22 of 22); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 56% (5 of 9); on the table 67% | 80% (8 of 10); on the table 90% | 68% (13 of 19); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 83% (19 of 23); on the table 87% | 90% (18 of 20); on the table 95% | 86% (37 of 43); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 35% (29 of 84) | 31% (17 of 54) | 33% (46 of 138) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (29 of 55) | 50% (17 of 34) | 52% (46 of 89) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (6 of 9) | 67% (6 of 9) |
| Points that never fought | lower | 46% (8266 of 17994) | 43% (7687 of 17999) | 44% (15953 of 35993) |
|   infantry points that never fought | lower | 55% (2371 of 4278) | 54% (1847 of 3449) | 55% (4218 of 7727) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (49 of 92) | 49% (34 of 70) | 51% (83 of 162) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 1.2 uses a game | 100% (7 of 7); 3.0 uses a game | 100% (11 of 11); 2.1 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.3 uses a game | 25% (2 of 8); 0.4 uses a game | 45% (5 of 11); 0.9 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 20% (1 of 5); 0.1 uses a game | 50% (2 of 4); 0.2 uses a game | 33% (3 of 9); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (7848 of 15843) | 43% (7014 of 16132) | 46% (14862 of 31975) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (16%) | 1.1 (27%) | 2.1 (21%) |
| MARCHED: its unit marched | 1.1 (18%) | 0.4 (11%) | 1.6 (15%) |
| CHARGED: its unit charged | 0.8 (13%) | 0.1 (3%) | 0.9 (9%) |
| IN COMBAT: engaged in combat | 2.1 (35%) | 0.7 (16%) | 2.8 (27%) |
| FLEEING: fleeing | 0.0 (0%) | 0.4 (11%) | 0.4 (4%) |
| GONE: slain | 0.7 (11%) | 1.1 (27%) | 1.8 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.0 (0%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.8 | 2.0 | 0.3 | 5.1 | 0.8 | 1.8 |
| not cast | 2.6 | 2.9 | 1.0 | 10.2 | 1.9 | 20.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (54%) | 0.0 (0%) | 2.1 (21%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (15%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (9%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (4%) | 0.0 (0%) | 2.8 (27%) | 0.7 (35%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.4 (4%) | 0.2 (12%) | 1.0 (5%) |
| GONE: slain | 1.3 (52%) | 0.9 (31%) | 0.9 (89%) | 1.8 (17%) | 0.0 (0%) | 6.7 (32%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.7 (35%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.9 (35%) | 0.0 (0%) | 0.1 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.1 (58%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 50% (1 of 2) | 50% (1 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (1 of 2) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (241 of 355) | 59% (105 of 177) | 65% (346 of 532) |
|   cavalry | 45% (10 of 22) | 53% (16 of 30) | 50% (26 of 52) |
|   character | 100% (11 of 11) | 25% (7 of 28) | 46% (18 of 39) |
|   chariot | 71% (20 of 28) | 83% (5 of 6) | 74% (25 of 34) |
|   infantry | 56% (67 of 120) | 67% (55 of 82) | 60% (122 of 202) |
|   monster | 56% (10 of 18) | 18% (2 of 11) | 41% (12 of 29) |
|   war machine | 79% (123 of 156) | 100% (20 of 20) | 81% (143 of 176) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (24%) | 1.0 (12%) | 4.0 (19%) |
| CHARGED: it charged | 1.3 (11%) | 2.3 (29%) | 3.7 (18%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (7%) | 0.6 (7%) | 1.4 (7%) |
| NO TARGET IN RANGE | 2.4 (19%) | 2.2 (28%) | 4.7 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (6%) | 0.2 (3%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.8 (22%) | 1.6 (19%) | 4.3 (21%) |
| SHELTERED: the target was sheltered | 0.8 (6%) | 0.0 (0%) | 0.8 (4%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.8 | 0.9 | 79% | 4.1 pts | 15 pts |
| character | 2.3 | 1.0 | 62% | 12.7 pts | 30 pts |
| chariot | 2.8 | 1.7 | 60% | 11.3 pts | 31 pts |
| infantry | 20.9 | 5.4 | 79% | 8.8 pts | 184 pts |
| monster | 1.8 | 0.6 | 81% | 4.6 pts | 8 pts |
| war machine | 15.9 | 12.6 | 59% | 28.2 pts | 448 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 4.3 | 4.4 |
| Charges that made contact a game | 3.4 | 2.4 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.86 declared, 1.43 contact (7 units) | 0.25 declared, 0.25 contact (4 units) | 1.27 declared, 1.00 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.33 contact (3 units) | 1.00 declared, 0.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.36 contact (58 units) | 0.60 declared, 0.34 contact (58 units) | 0.53 declared, 0.35 contact (116 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (13 of 23) | 0% (0 of 3) | 67% (2 of 3) | 52% (15 of 29) |
| Character in a unit | 71% (5 of 7) | 100% (2 of 2) | 0% (0 of 1) | 70% (7 of 10) |
| Character on its own | 69% (9 of 13) | 36% (4 of 11) | 20% (3 of 15) | 41% (16 of 39) |
| Chariot | 25% (1 of 4) | 67% (2 of 3) | - | 43% (3 of 7) |
| Infantry | 48% (12 of 25) | 44% (4 of 9) | 0% (0 of 1) | 46% (16 of 35) |
| Monster | 57% (4 of 7) | 50% (1 of 2) | - | 56% (5 of 9) |
| Monstrous | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| War Machines | 60% (18 of 30) | - | - | 60% (18 of 30) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 2 | 75% (3 of 4); on the table 75% | - | 57% | 65% (13 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 91% (10 of 11); on the table 100% | 42% (15 of 36) | 48% | 59% (32 of 54) | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 3 | 78% (7 of 9); on the table 78% | 27% (18 of 66) | 38% | 30% (8 of 27) | 100% (7 of 7); 8.0 uses a game | 100% (1 of 1); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 2 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 62% | 53% (9 of 17) | 100% (1 of 1); 2.0 uses a game | 25% (2 of 8); 2.0 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 21% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 67% (4 of 6); on the table 83% | 50% (3 of 6) | 39% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 37% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 83% (5 of 6) | 49% | 62% (8 of 13) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 11% | 30% (3 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p1c, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (8) | 56% (9) | 55% (17) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.56 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.22 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.22 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.89 | 3.89 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.33 | 1.11 | 2.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.22 | 3.44 | 7.67 |

### Quality by phase: os-h2h-mine-779e261-p1c

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (18 of 35) | 46% (13 of 28) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (82 of 177) | 65% (36 of 55) |
| Strategy | Close-in objectives charged next turn | 18% (8 of 45) | 13% (9 of 68) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 50% (2 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (6 of 8) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 50% (6 of 12) | 50% (3 of 6) |
| Strategy | Lone characters that fought | 76% (19 of 25) | 78% (18 of 23) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.6 |
| Movement | Points that never moved of their own | 548.8 | 259.4 |
| Movement | Fights charged into per game | 2.9 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 25, net +82 | 3 of 16, net +478 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 25, net +33 | 5 of 16, net +187 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 25, net +34 | 0 of 16 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 of 25, net +70 | 3 of 16, net +172 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.7 | 10.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (73 of 123) | 48% (45 of 94) |
| Shooting | Points destroyed by shooting units | 135.9 | 101.0 |
| Shooting | War machine shots | 13.7 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (62 of 123) | 15% (3 of 20) |
| Shooting | Points destroyed by war machines | 309.4 | 26.7 |
| Magic | Magic missiles cast | 2.0 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (9 of 18) | 36% (4 of 11) |
| Magic | Wounds caused by magic missiles | 3.9 | 3.1 |
| Magic | Wounds caused by other spells | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 161.6 | 34.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.9 / 0.4 / 0.3 | 1.7 / 0.3 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 156.1 | 374.9 |
| Combat | Points run down | 51.3 | 159.9 |
| Combat | Net points per charged fight, damage counted | +67 | +193 |
| Combat | Net per 100 charger points, damage counted | +27.3 | +53.9 |
| Combat | First round won (charged fights) | 65% | 85% |
| Combat | Net points per charged fight | +58 | +218 |
| Combat | Net points per supported fight / lone fight | +130 / +41 | +332 / +205 |
| Combat | Charged fights on a top-3 enemy unit | 12 of 26 | 11 of 20 |
| Game | Points lost | 864.7 | 870.9 |
| Game | VP from objectives | 696.7 | 643.3 |
| Game | Lone holders (player turns) | 1.7 | 2.6 |

- Mine won / drew / lost: 4 / 1 / 4 of 9 ended games (of 9); mean margin (Mine - Opponent) +101 VP
- The side that went first won 4 of 8 games with a winner
- Points traded per game (both sides' losses): 1736
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-mine-779e261-p1c

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 7.1 | -249.6 | 620.0 | 131.1 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.9 | +0.0 | 0.0 | 42.2 | 0.3 | +0.0 | 0.0 | 18.3 |
| BACKUP TARGETS | 0.4 | +3.3 | 0.0 | 42.2 | 0.8 | +4.8 | 0.0 | 94.3 |
| BEST FACING | 0.3 | +22.5 | 0.0 | 0.0 | 0.6 | +57.1 | 0.0 | 45.2 |
| BEST FIRST | 2.0 | +74.3 | 89.7 | 0.0 | 3.8 | +178.3 | 146.8 | 140.8 |
| BEST OVERALL | 0.3 | +49.2 | 0.0 | 11.7 | 0.7 | +25.3 | 0.0 | 68.6 |
| BEST PREY | 0.6 | +32.8 | 0.0 | 42.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.2 | -17.0 | 29.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.0 | 0.0 | 0.0 | 0.6 | -3.3 | 0.0 | 49.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 11.6 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | - | - | - | - | 0.2 | +2.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | +1.9 | 66.9 | 0.0 | 0.1 | -26.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 2.3 | +0.0 | 297.7 | 32.2 | 0.6 | +0.0 | 25.0 | 18.3 |
| CANNON PLANNED TARGET | 10.1 | +565.3 | 1015.6 | 167.2 | 1.4 | +39.0 | 95.6 | 33.9 |
| CANNON SIGHT KEPT | 2.6 | +0.0 | 0.0 | 6.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +42.6 | 142.7 | 0.0 | 0.1 | +1.0 | 11.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.2 | +14.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.2 | +0.0 | 0.0 | 44.4 |
| CATCH FLIERS | 0.1 | +2.1 | 0.0 | 20.9 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.7 | -0.0 | 49.1 | 13.9 | - | - | - | - |
| CHARGE NOW FIRST | 2.4 | +0.0 | 352.3 | 96.9 | 2.0 | +0.0 | 254.2 | 0.0 |
| CHARGE NOW WEIGHED | 0.9 | -93.2 | 100.1 | 6.7 | 0.7 | -88.8 | 70.6 | 105.3 |
| CHARGER SLAIN LOST | 0.4 | -55.7 | 174.7 | 6.7 | 0.2 | -9.4 | 34.6 | 0.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -4.0 | 0.0 | 60.0 |
| CHEAP HELPER | 0.1 | +0.0 | 45.2 | 0.0 | 0.1 | +0.0 | 18.2 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 21.7 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +21.9 | 88.9 | 88.9 |
| COUNTER-CHARGE COVER | - | - | - | - | 8.4 | +819.1 | 0.0 | 331.3 |
| COVER ONCE | 7.1 | -709.4 | 0.0 | 203.3 | - | - | - | - |
| DEFENSIVE ARMY | 0.9 | +0.0 | 154.2 | 20.7 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +0.8 | 24.7 | 0.0 | 0.4 | +17.8 | 96.6 | 0.0 |
| FACES THE THREAT | 2.0 | +111.0 | 0.0 | 115.0 | 1.9 | +160.5 | 0.0 | 124.8 |
| FALLBACK BY WORTH | 4.4 | +62.3 | 0.0 | 63.6 | 3.8 | +31.6 | 0.0 | 33.0 |
| FLANK NOT WEIGHED | 4.1 | +0.0 | 0.0 | 66.0 | 5.1 | +0.0 | 0.0 | 296.9 |
| FOLLOW UP WEIGHED | 0.8 | +80.4 | 0.0 | 0.0 | 0.8 | +97.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.6 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -2.4 | 12.3 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 24.7 | 0.0 | 0.3 | +0.0 | 58.1 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.6 | -142.0 | 331.9 | 226.2 | 9.6 | -231.7 | 658.1 | 352.1 |
| HORN WORTH | - | - | - | - | 0.1 | +2.6 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +14.3 | 0.0 | 11.6 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +31.7 | 0.0 | 0.0 | 1.1 | +60.7 | 0.0 | 24.1 |
| HUNT KEPT | 0.1 | +1.5 | 42.1 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +43.2 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +45.5 | 42.1 | 0.0 | 0.2 | +74.5 | 0.0 | 11.6 |
| IDLE COST | 13.2 | -209.6 | 0.0 | 231.0 | - | - | - | - |
| INVITES THE FIGHT | 1.8 | +21.8 | 215.7 | 32.0 | 0.6 | +10.9 | 27.7 | 0.0 |
| JOINT CHARGE PLAN | 0.2 | +3.9 | 0.0 | 0.0 | 0.6 | +51.9 | 46.8 | 15.9 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.7 | +50.0 | 68.2 | 50.8 | 1.7 | +50.0 | 76.9 | 64.7 |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +63.8 | 143.4 | 36.1 | 0.8 | +20.8 | 73.4 | 0.0 |
| KILLS COUNT NEXT TURN | 5.0 | +217.2 | 122.4 | 161.1 | 6.8 | +311.2 | 343.7 | 398.6 |
| LONE CHARACTER SAFE SPOT | 0.8 | +8.7 | 102.1 | 10.0 | 0.3 | +52.5 | 0.0 | 60.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 11.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +31.3 | 0.0 | 0.0 | 0.2 | +31.9 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -2.4 | 66.9 | 33.8 | 0.1 | -2.1 | 8.6 | 0.0 |
| LOST CHARGE | 2.9 | -28.1 | 65.1 | 143.4 | 2.4 | -31.1 | 24.3 | 259.4 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +26.2 | 0.0 | 42.2 | 0.9 | +56.5 | 0.0 | 16.8 |
| MANOEUVRE | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +21.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +12.8 | 0.0 | 18.0 | 0.2 | +26.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.4 | +29.4 | 32.4 | 0.0 | 0.6 | +20.8 | 23.3 | 44.4 |
| MARCH OVER CASTS | 0.6 | +41.6 | 0.0 | 41.0 | 0.1 | +23.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.4 | +120.1 | 0.0 | 186.9 | 4.7 | +221.9 | 0.0 | 313.9 |
| MISSILES IN THE MOVE | 4.4 | +166.6 | 0.0 | 101.2 | 5.0 | +63.2 | 0.0 | 194.1 |
| MISSILES NEXT TURN | 4.8 | +109.2 | 0.0 | 143.4 | 5.1 | +57.3 | 0.0 | 194.1 |
| MODEL FACING | 0.7 | +217.0 | 0.0 | 20.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +44.6 | 0.0 | 41.0 | 0.6 | +5.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 44.4 |
| MOVE TO CHARGE | 3.6 | +307.1 | 19.4 | 105.4 | 6.9 | +510.4 | 280.3 | 365.7 |
| NOT NEEDED | 0.1 | -11.1 | 24.7 | 0.0 | 0.2 | -4.7 | 13.9 | 0.0 |
| NOT TURNED | 4.2 | +37.1 | 0.0 | 49.2 | 3.4 | +68.5 | 0.0 | 57.8 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 93.9 | - | - | - | - |
| OFF BEST | 19.0 | -746.3 | 0.0 | 293.2 | 15.8 | -920.0 | 0.0 | 347.3 |
| ONE FIGHT FORMULA | 8.9 | -143.8 | 131.9 | 296.1 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.1 | -36.9 | 0.0 | 38.8 | - | - | - | - |
| OPENS UP | 0.3 | +12.6 | 23.3 | 0.0 | 0.3 | +24.0 | 24.3 | 31.7 |
| OVERRUN THREAT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.8 | +19.8 | 45.6 | 67.4 | 0.1 | +1.1 | 32.0 | 0.0 |
| PATHS CROSS | 1.3 | +34.3 | 0.0 | 42.2 | 1.6 | +118.2 | 0.0 | 60.3 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.7 | 0.0 | 44.4 |
| PLAN RESULT | 41.1 | +3099.1 | 2101.0 | 1123.8 | 33.9 | +1215.7 | 1442.4 | 1177.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.0 | +24.6 | 0.0 | 55.6 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.0 | 0.0 | 0.0 | 0.4 | +15.8 | 0.0 | 2.1 |
| REDIRECT COUNTER | 0.1 | +4.5 | 0.0 | 0.0 | 2.2 | +145.4 | 0.0 | 32.7 |
| REDIRECT WEIGHED | 0.3 | +2.0 | 10.2 | 0.0 | 0.6 | -10.1 | 44.4 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.2 | +12.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.8 | +110.7 | 381.8 | 74.1 | 1.7 | +18.7 | 174.3 | 31.7 |
| RISK ONCE | 4.1 | +170.4 | 0.0 | 221.9 | - | - | - | - |
| SAFER THAN THE JOB | 1.3 | +86.7 | 0.0 | 32.7 | 1.1 | +74.0 | 0.0 | 159.8 |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 0.0 | 0.2 | +1.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -18.5 | 0.0 | 2.1 |
| SEARCH SPOT | 1.6 | +100.9 | 0.0 | 27.7 | 2.1 | +55.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +173.2 | 0.0 | 42.2 | 3.3 | +339.0 | 180.1 | 102.2 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.2 | +148.1 | 357.6 | 41.0 | 1.0 | +9.3 | 13.3 | 34.1 |
| SHORT GUN FORWARD | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 1.9 | +0.0 | 438.4 | 40.8 | 0.3 | +0.0 | 69.4 | 0.0 |
| SHOTS IN THE MOVE | 27.2 | +1563.5 | 0.0 | 332.1 | 10.3 | +363.0 | 0.0 | 194.9 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +81.2 | 88.9 | 88.9 |
| SPELL WORTH | 0.1 | +2.2 | 9.4 | 9.4 | 2.7 | +75.3 | 148.9 | 174.9 |
| SPELLS IN THE FIGHT | 1.0 | -22.3 | 235.6 | 25.2 | 1.1 | +23.7 | 139.7 | 0.0 |
| STABLE ROLE | 14.4 | +0.0 | 1061.1 | 210.2 | 11.7 | +0.0 | 315.3 | 273.0 |
| STOPS | 0.2 | +3.7 | 84.2 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.3 | +9.5 | 0.0 | 54.4 | 0.4 | +7.5 | 0.0 | 44.4 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 3.8 | -30.0 | 278.8 | 105.6 | 4.2 | -47.8 | 206.9 | 27.4 |
| SUPPORTS | 2.2 | +30.0 | 101.2 | 50.9 | 3.0 | +48.8 | 90.4 | 27.4 |
| SURE REACH TOGETHER | 0.4 | -19.6 | 0.0 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.9 | +46.2 | 0.0 | 46.8 | 0.2 | +23.8 | 0.0 | 49.1 |
| TURN WORTH | 0.4 | -27.0 | 4.6 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.4 | +5.2 | 0.0 | 0.0 | 0.9 | +6.1 | 0.0 | 15.9 |
| WAIT AFTER COSTS | 7.6 | -492.6 | 350.7 | 190.9 | 8.7 | -491.2 | 424.7 | 365.7 |
| WALKS TO THE FIGHT | 1.8 | +14.2 | 44.3 | 8.6 | 0.6 | +18.6 | 49.3 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 49.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.2 | +54.8 | 121.7 | 33.8 | 1.0 | +26.8 | 124.9 | 0.0 |
| WHOLE FIGHT | 0.2 | +53.4 | 84.2 | 0.0 | 0.2 | -58.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +20.0 | 90.4 | 6.7 | 0.3 | +24.7 | 57.4 | 0.0 |
| WIDER SPREAD | 2.6 | -1.7 | 345.7 | 69.9 | 2.1 | -10.6 | 222.2 | 31.7 |

### Rule changes: os-h2h-mine-779e261-p1c

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 313 | 313 | 313 | 34.78 | -14996 | -47.9 |
| BEST FIRST | 52 | 52 | 52 | 5.78 | +2274 | +43.7 |
| MOVE TO CHARGE | 94 | 94 | 47 | 5.22 | +2887 | +61.4 |
| KILLS COUNT NEXT TURN | 106 | 106 | 38 | 4.22 | +1556 | +40.9 |
| FACES THE THREAT | 35 | 35 | 35 | 3.89 | +2444 | +69.8 |
| SEARCH SPOT | 33 | 33 | 33 | 3.67 | +1408 | +42.7 |
| CANNON SIGHT KEPT | 32 | 32 | 32 | 3.56 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 29 | 29 | 29 | 3.22 | +0 | +0.0 |
| FALLBACK BY WORTH | 74 | 74 | 26 | 2.89 | +844 | +32.5 |
| PATHS CROSS | 26 | 26 | 26 | 2.89 | +1373 | +52.8 |
| SET UP TOGETHER | 42 | 39 | 25 | 2.78 | +1864 | +74.6 |
| SHOTS IN THE MOVE | 338 | 230 | 23 | 2.56 | +647 | +28.1 |
| SAFER THAN THE JOB | 22 | 22 | 22 | 2.44 | +1446 | +65.7 |
| COUNTER-CHARGE COVER | 76 | 42 | 20 | 2.22 | +1228 | +61.4 |
| SHOT REPLANNED | 20 | 20 | 20 | 2.22 | +0 | +0.0 |
| WAIT AFTER COSTS | 146 | 146 | 20 | 2.22 | +464 | +23.2 |
| MISSILES IN THE MOVE | 85 | 53 | 17 | 1.89 | +536 | +31.5 |
| SUPPORTS | 47 | 47 | 15 | 1.67 | +184 | +12.3 |
| CHARGE NOW WEIGHED | 14 | 14 | 14 | 1.56 | +1900 | +135.7 |
| FOLLOW UP WEIGHED | 14 | 14 | 14 | 1.56 | +1599 | +114.2 |
| RISK BY ARC | 40 | 40 | 12 | 1.33 | +409 | +34.1 |
| WALKS TO THE FIGHT | 21 | 21 | 11 | 1.22 | +115 | +10.4 |
| CHARGE NOW FIRST | 40 | 40 | 10 | 1.11 | -826 | -82.6 |
| SHOOTS FROM THE BEST SPOT | 29 | 29 | 10 | 1.11 | +484 | +48.4 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 1.11 | +630 | +63.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 1.00 | +0 | +0.0 |
| BEST OVERALL | 9 | 9 | 9 | 1.00 | +670 | +74.5 |
| CANNON PLANNED TARGET | 104 | 104 | 9 | 1.00 | -148 | -16.5 |
| KILLS COUNT | 20 | 20 | 9 | 1.00 | +231 | +25.7 |
| MARCH ODDS | 9 | 9 | 9 | 1.00 | +52 | +5.7 |
| ADVANCE WORTH | 64 | 64 | 8 | 0.89 | +132 | +16.5 |
| BEST FACING | 8 | 8 | 8 | 0.89 | +717 | +89.6 |
| KEEPS ITS TARGET | 30 | 30 | 8 | 0.89 | +175 | +21.9 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 0.89 | +569 | +71.1 |
| MOVE AND CAST | 8 | 8 | 8 | 0.89 | +453 | +56.7 |
| REDIRECT WEIGHED | 8 | 8 | 8 | 0.89 | +52 | +6.6 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.89 | +21 | +2.6 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.78 | -38 | -5.4 |
| HONEST WORTH | 154 | 154 | 7 | 0.78 | +118 | +16.8 |
| INVITES THE FIGHT | 21 | 21 | 7 | 0.78 | +81 | +11.6 |
| RISK ONCE | 37 | 25 | 7 | 0.78 | +311 | +44.4 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.78 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 7 | 7 | 7 | 0.78 | +153 | +21.8 |
| CHAFF PASSED | 6 | 6 | 6 | 0.67 | -0 | -0.0 |
| COVER ONCE | 64 | 28 | 6 | 0.67 | +46 | +7.6 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 6 | 6 | 6 | 0.67 | +518 | +86.3 |
| MAX FOR POSITIONING | 82 | 45 | 6 | 0.67 | +8 | +1.4 |
| MODEL FACING | 6 | 6 | 6 | 0.67 | +1953 | +325.4 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 6 | 0.67 | +222 | +37.0 |
| SCOUT WAITS | 6 | 6 | 6 | 0.67 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 5 | 0.56 | +55 | +11.0 |
| SPELLS IN THE FIGHT | 19 | 19 | 5 | 0.56 | +74 | +14.8 |
| LOST CHARGE | 48 | 48 | 4 | 0.44 | +385 | +96.1 |
| ONE FIGHT FORMULA | 80 | 51 | 4 | 0.44 | +35 | +8.7 |
| REDIRECT COUNTER | 21 | 8 | 4 | 0.44 | +363 | +90.8 |
| WAR ENGINE JOBS | 7 | 7 | 4 | 0.44 | -77 | -19.2 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.33 | +37 | +12.3 |
| HUNT IN PAIRS | 14 | 9 | 3 | 0.33 | +97 | +32.3 |
| MAKE SURE TOGETHER | 13 | 10 | 3 | 0.33 | +228 | +76.1 |
| MANOEUVRE | 4 | 4 | 3 | 0.33 | +194 | +64.8 |
| MISSILES NEXT TURN | 89 | 59 | 3 | 0.33 | +8 | +2.8 |
| OPENS UP | 6 | 6 | 3 | 0.33 | +61 | +20.3 |
| BEST PREY | 5 | 5 | 2 | 0.22 | +64 | +31.9 |
| BEST PRIZE | 2 | 2 | 2 | 0.22 | -207 | -103.5 |
| BLOCKED WHEEL | 2 | 2 | 2 | 0.22 | +21 | +10.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.22 | +55 | +27.3 |
| IDLE COST | 119 | 58 | 2 | 0.22 | +8 | +4.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| OVERRUNS AWAY | 8 | 8 | 2 | 0.22 | +32 | +15.8 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.22 | -1 | -0.7 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.22 | +108 | +54.2 |
| WEARS DOWN | 20 | 20 | 2 | 0.22 | +235 | +117.7 |
| WHOLE FIGHT | 4 | 4 | 2 | 0.22 | +416 | +207.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.11 | +23 | +23.3 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.11 | +29 | +29.2 |
| JOINT CHARGE PLAN | 7 | 7 | 1 | 0.11 | +120 | +120.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.11 | +2 | +2.2 |
| LONE WIZARD HOLDS BACK | 1 | 1 | 1 | 0.11 | -2 | -1.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.11 | -6 | -6.4 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.11 | +90 | +90.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| SUPPORT NARROWED | 72 | 72 | 1 | 0.11 | -54 | -53.5 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 11 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 6 | 6 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 8 | 8 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 83 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 10 | not checked | - | - | - | - |
| LONG SHOT | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NOT NEEDED | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 69 | 69 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 19 | 12 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 675 | trace | - | - | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 25 | not checked | - | - | - | - |
| STABLE ROLE | 235 | 235 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 7 | 6 | 0 | 0.00 | - | - |
| TURN WORTH | 4 | 4 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 12 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 5 | 5 | 0 | 0.00 | - | - |
| WIDER SPREAD | 42 | 42 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p1c

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 17.11 | 14.56 | 48.5 |
| FALLBACK | gate | 0.56 | 0.78 | 40.0 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 91.7 |
| TURN GATE | gate | 0.56 | 0.11 | 39.1 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.33 | 10.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | 0.11 | 30.8 |
| PATHS CROSS | rule | 0.33 | 0.11 | 67.0 |
| WAR ENGINE JOBS | rule | 0.44 | - | 19.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 94.1 |
| AFTERMATH BAND | gate | - | 0.22 | 3.5 |
| BEST PRIZE | rule | - | 0.22 | 103.5 |
| CANNON PLANNED TARGET | rule | - | 0.22 | 74.1 |
| CHARGE NOW WEIGHED | rule | - | 0.22 | 8.4 |
| MARCH ODDS | rule | 0.11 | 0.11 | 13.4 |
| MOVE AND CAST | rule | - | 0.22 | 11.0 |
| REDIRECT WEIGHED | rule | - | 0.22 | 103.5 |
| SAFER THAN THE JOB | rule | - | 0.22 | 11.8 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.11 | 9.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.11 | 4.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 1.6 |
| NO REASON | gate | 0.11 | - | 50.4 |
| PIVOT GUARDS FLANK | rule | - | 0.11 | 6.4 |
| REFUSING RETIRES | rule | 0.11 | - | 0.8 |
| SUPPORT NARROWED | rule | 0.11 | - | 53.5 |

### Plans: os-h2h-mine-779e261-p1c

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 7.8 | 26% | 158 | 414 | 261% |
| Mine | charge | 3.0 | 48% | 287 | 299 | 104% |
| Mine | close in | 5.0 | 27% | 353 | 176 | 50% |
| Mine | hold | 6.4 | 33% | 384 | 0 | 0% |
| Mine | join | 0.7 | 83% | 6 | 0 | 0% |
| Mine | shoot | 15.8 | 77% | 878 | 2211 | 252% |
| Mine | support | 2.4 | 82% | 15 | 0 | 0% |
| Opponent | advance | 9.9 | 20% | 429 | 363 | 85% |
| Opponent | charge | 2.1 | 53% | 232 | 172 | 74% |
| Opponent | close in | 7.6 | 24% | 594 | 318 | 54% |
| Opponent | hold | 5.9 | 53% | 404 | 0 | 0% |
| Opponent | shoot | 5.0 | 56% | 182 | 363 | 199% |
| Opponent | support | 3.4 | 90% | 38 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p1c

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 410 | 389 | 100% | 27 |
| Opponent | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 335 | 0 | 0% | 334 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 0.5 | 1 | 0 | 100% | 100% | 0% | 3.0 | 410 | 389 | 100% | 120 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 854 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 316 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 210 |
| Tomb Kings of Khemri | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 342 | 0 | 0% | 265 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 142 |
| Wood Elf Realms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 0 |

### Battle groups: os-h2h-mine-779e261-p1c

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.1 | 0% | - | - | - | - | - | - | - | - |
| Opponent | COUNTER-CHARGE COVER | 8.4 | 18% | 64% | 14% | 50% | 50% | 25% | 8% | 17% | 0% |
| Opponent | REDIRECT COUNTER | 2.2 | 55% | 73% | 0% | - | 0% | 0% | 9% | 82% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p1c

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 32 | 45 (32) | 45 | 0 | 53 | 25% | 2.5 | 34 (13) | 55 (12) | 167 (1) | 63 (21) | 11 (5) |
| Mine | Clean-up | 6 | 49 (6) | 33 | 16 | 0 | 17% | 3.0 | 0 (1) | 64 (5) | - | 64 (5) | 0 (1) |
| Mine | Fast | 3 | 168 (3) | 168 | 0 | 73 | 0% | 1.3 | - | 0 (2) | 632 (1) | 168 (3) | - |
| Mine | Fast Hammer | 13 | 34 (13) | 15 | 19 | 78 | 23% | 2.5 | 59 (6) | 15 (2) | 15 (5) | 41 (10) | 6 (3) |
| Mine | Hammer | 11 | 24 (11) | 17 | 7 | 43 | 9% | 2.8 | 0 (2) | 35 (6) | 21 (3) | 25 (8) | 23 (3) |
| Mine | Holder | 1 | 193 (1) | 0 | 193 | 0 | 100% | - | - | 193 (1) | - | 193 (1) | - |
| Mine | Shooter | 20 | 127 (20) | 33 | 94 | 31 | 0% | 2.0 | - | 127 (13) | 127 (7) | 141 (13) | 97 (7) |
| Mine | War machine | 32 | 77 (32) | 77 | 0 | 37 | 9% | 1.3 | 83 (6) | 85 (23) | 0 (3) | 46 (8) | 89 (24) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 45 | 0% | 1.6 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 9 | 62 (9) | 29 | 32 | 73 | 33% | 2.7 | 228 (2) | 39 (3) | 25 (4) | 71 (7) | 0 (2) |
| Opponent | Character | 27 | 66 (27) | 66 | 0 | 43 | 26% | 2.8 | 144 (4) | 50 (19) | - | 59 (15) | 99 (8) |
| Opponent | Clean-up | 3 | 16 (3) | 0 | 16 | 19 | 100% | - | - | 16 (3) | - | 0 (2) | 26 (1) |
| Opponent | Fast Hammer | 19 | 35 (19) | 5 | 30 | 67 | 47% | 2.3 | 29 (5) | 38 (7) | 36 (7) | 35 (17) | 32 (2) |
| Opponent | Fragile | 6 | 0 (6) | 0 | 0 | 40 | 17% | 1.6 | 0 (3) | 0 (1) | 0 (2) | 0 (6) | - |
| Opponent | Hammer | 8 | 66 (8) | 46 | 20 | 61 | 12% | 2.9 | 0 (1) | 77 (6) | 45 (1) | 120 (3) | 31 (5) |
| Opponent | Holder | 11 | 75 (11) | 0 | 75 | 21 | 36% | 3.0 | 0 (4) | 187 (5) | 0 (2) | 89 (7) | 42 (4) |
| Opponent | Shooter | 10 | 113 (10) | 62 | 51 | 29 | 0% | 1.4 | 329 (2) | 85 (6) | 55 (2) | 74 (6) | 214 (4) |
| Opponent | War machine | 4 | 51 (4) | 51 | 0 | 50 | 0% | 1.0 | - | 73 (1) | 39 (3) | 0 (1) | 60 (3) |
| Opponent | Wizard | 2 | 53 (2) | 53 | 0 | 0 | 0% | 1.0 | - | 53 (2) | - | 7 (1) | 138 (1) |

### Charged fights: os-h2h-mine-779e261-p1c

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 356 | 469 | 3.0 | 1.2 | 156 | 10 | +146 | 2 of 6 | 5 of 6 | +347 | +106 |
| Mine | Empire of Man | 5 | 458 | 103 | 2.6 | 1.1 | 39 | 38 | +2 | 4 of 13 | 8 of 13 | +83 | -5 |
| Mine | Grand Cathay | 2 | 1232 | 304 | 3.5 | 1.4 | 87 | 0 | +87 | 6 of 7 | 4 of 7 | +74 | +97 |
| **Mine** | all armies | 9 | 607 | 229 | 2.9 | 1.2 | 79 | 21 | +58 | 12 of 26 | 17 of 26 | +130 | +41 |
| Opponent | Grand Cathay | 1 | 240 | 220 | 3.0 | 1.0 | 73 | 0 | +73 | 0 of 3 | 3 of 3 | - | +73 |
| Opponent | High Elf Realms | 2 | 114 | 559 | 2.0 | 1.0 | 280 | 0 | +280 | 2 of 4 | 3 of 4 | - | +280 |
| Opponent | Lizardmen | 1 | 569 | 710 | 3.0 | 1.7 | 237 | 0 | +237 | 2 of 3 | 3 of 3 | +332 | +45 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 140 | -140 | 1 of 1 | 1 of 1 | - | -140 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 1460 | 5.0 | 1.0 | 292 | 0 | +292 | 3 of 5 | 4 of 5 | - | +292 |
| Opponent | Warriors of Chaos | 2 | 0 | 348 | 1.5 | 1.0 | 232 | 0 | +232 | 2 of 3 | 2 of 3 | - | +232 |
| Opponent | Wood Elf Realms | 1 | 380 | 288 | 1.0 | 1.0 | 288 | 0 | +288 | 1 of 1 | 1 of 1 | - | +288 |
| **Opponent** | all armies | 9 | 163 | 499 | 2.2 | 1.1 | 225 | 7 | +218 | 11 of 20 | 17 of 20 | +332 | +205 |

### Effective charges: os-h2h-mine-779e261-p1c

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +347) | 0 | 0 | 1 (net +111) | 0 | 4 (net +105) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 13 | 2 (net -114) | 0 | 2 (net +50) | 3 (net +78) | 3 (net +34) | 3 (net -63) | 0 | 15% (2 of 13) |
| Mine | Grand Cathay | 7 | 1 (net +210) | 0 | 1 (net +0) | 2 (net +0) | 0 | 2 (net +200) | 1 | 17% (1 of 6) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +115) | 1 (net +105) | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | High Elf Realms | 4 | 1 (net +654) | 0 | 2 (net +48) | 0 | 0 | 1 (net +369) | 0 | 50% (2 of 4) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +476) | 1 (net +189) | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -140) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net +270) | 0 | 1 (net +249) | 2 (net +128) | 0 | 0 | 1 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 3 | 1 (net +509) | 0 | 0 | 1 (net +186) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +288) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: os-h2h-mine-779e261-p1c

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 211 | 278 | +82 | 266 | 138 | +128 | +60.5 |
| Mine | Effective (55-75%) | 3 | 224 | 161 | +33 | 59 | 26 | +33 | +14.9 |
| Mine | 76-89% | 6 | 294 | 202 | +58 | 74 | 16 | +58 | +19.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 205 | 167 | +70 | 134 | 38 | +96 | +47.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 303 | 69 | +34 | 34 | 87 | -53 | -17.6 |
| Mine | No odds | 1 | 334 | 92 | +0 | 74 | 0 | +74 | +22.0 |
| Mine | All fights | 26 | 245 | 177 | +58 | 118 | 51 | +67 | +27.3 |
| Opponent | Long shot (under 50%) | 3 | 469 | 313 | +478 | 478 | 35 | +442 | +94.2 |
| Opponent | Effective (55-75%) | 5 | 297 | 217 | +187 | 221 | 57 | +164 | +55.2 |
| Opponent | 76-89% | 5 | 415 | 147 | +147 | 147 | 11 | +136 | +32.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 268 | 271 | +172 | 219 | 83 | +136 | +50.7 |
| Opponent | No odds | 4 | 349 | 116 | +183 | 183 | 24 | +158 | +45.3 |
| Opponent | All fights | 20 | 359 | 202 | +218 | 233 | 40 | +193 | +53.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p1c | move | 104 | 23 (22%) | 13 (12%) | 13 (12%) | 68 (65%) |
| os-h2h-mine-779e261-p1c | objective | 113 | 17 (15%) | 11 (10%) | 15 (13%) | 81 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Doom | Mine | L1114 |
| Ring of Doom | Opponent | L0612, L0733 |
| Ring of Jet | Mine | L1021, L1114 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

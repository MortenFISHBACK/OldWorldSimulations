# Doctrine scorecard: os-h2h-opp-779e261-p4

### Scorecard: os-h2h-opp-779e261-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 11 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 9 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 5 | 1 | 6 | 2 | 0 | 0 | 0 | 70 |
| L0214 | 4 | 1 | Mine | yes | 4 | 2 | 4 | 4 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 4 | 3 | 0 | 0 | 0 | 200 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 7 | - | 0 | 1 | 0 | 0 | 0 | 985 |
| L0315 | 3 | 1 | Opponent | yes | 11 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 1 | 0 | 0 | 218 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0520 | 4 | 1 | Opponent | no | 7 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 4 | 0 | 0 | 0 | 0 | 475 |
| L0624 | 6 | 1 | Mine | no | 0 | 5 | 4 | 0 | 0 | 0 | 0 | 801 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 2 | 0 | 0 | 564 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 6 | 1 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 597 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 6 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 6 | 3 | 5 | 0 | 0 | 0 | 674 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 210 |
| L1314 | 6 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 0 | 2 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 311 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 5 | 3 | 8 | 3 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 49 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 2 | 1 | 1 | 0 | 0 | 185 |
| L1819 | 1 | 1 | Opponent | yes | 2 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 4 | 2 | 3 | 0 | 0 | 0 | 625 |
| L2021 | 5 | 1 | Mine | yes | - | 6 | 3 | 3 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 5 | 1 | 6 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 0 | 0 | 0 | 940 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 2 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 6 | 3 | 4 | 0 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 5 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 5 | 2 | 6 | 1 | 0 | 0 | 0 | 56 |
| L2930 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 36% | 2.0 | 2.9 | 2.6 | 1.0 | 0.4 | 0.0 | 0.0 | 311.3 |
| **Average** | | | Opponent | 36% | 4.3 | 2.4 | 3.1 | 2.0 | 0.4 | 0.0 | 0.0 | 132.2 |

### KPIs: os-h2h-opp-779e261-p4

Rules off - Mine only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (41 of 167) | 1% (1 of 183) | 12% (42 of 350) |
| Winner chose to follow up after the loser gave ground |  | 97% (62 of 64); on the table 97% | 96% (52 of 54); on the table 98% | 97% (114 of 118); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 83% (15 of 18); on the table 100% | 86% (24 of 28); on the table 96% |
| Winner chose to pursue after the loser fled |  | 73% (11 of 15); on the table 87% | 86% (32 of 37); on the table 92% | 83% (43 of 52); on the table 90% |
| Winner chose to follow up or pursue (all three) |  | 92% (82 of 89); on the table 94% | 91% (99 of 109); on the table 96% | 91% (181 of 198); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 25% (66 of 268) | 32% (55 of 171) | 28% (121 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (66 of 187) | 47% (55 of 118) | 40% (121 of 305) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (24 of 41) | 54% (30 of 56) | 56% (54 of 97) |
| Points that never fought | lower | 35% (23574 of 67942) | 34% (24787 of 71984) | 35% (48361 of 139926) |
|   infantry points that never fought | lower | 39% (6059 of 15347) | 55% (7653 of 13804) | 47% (13712 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (162 of 270) | 50% (141 of 280) | 55% (303 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.5 uses a game | 78% (7 of 9); 0.6 uses a game | 84% (26 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.5 uses a game | 40% (8 of 20); 0.3 uses a game | 42% (15 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 87% (13 of 15); 0.4 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (31258 of 57750) | 44% (27726 of 63347) | 49% (58984 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (28%) | 0.9 (28%) | 2.5 (28%) |
| MARCHED: its unit marched | 1.4 (25%) | 0.3 (10%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.2 (7%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 1.3 (23%) | 0.8 (23%) | 2.0 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 0.7 (12%) | 0.5 (16%) | 1.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.4 | 2.0 | 3.4 | 0.4 | 2.2 |
| not cast | 2.6 | 2.6 | 2.8 | 8.8 | 1.6 | 20.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (40%) | 0.3 (10%) | 2.5 (28%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.4 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (3%) | 0.6 (20%) | 2.0 (23%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (4%) | 0.3 (10%) | 0.3 (3%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.1 (3%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 0.4 (15%) | 0.5 (20%) | 0.3 (12%) | 1.2 (14%) | 0.1 (7%) | 3.0 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.3 (11%) | 0.1 (3%) | 0.3 (4%) | 0.1 (3%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (13%) | 0.0 (1%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (55%) | 0.1 (5%) | 1.1 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.4 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.5 a game | 1.1 a game |
| stood (cast and not dispelled) | 67% (37 of 55) | 55% (6 of 11) | 65% (43 of 66) |
| the unit moved after it | 70% (26 of 37) | 83% (5 of 6) | 72% (31 of 43) |
| it charged on its next turn | 5% (2 of 37) | 0% (0 of 6) | 5% (2 of 43) |
| the enemy charged it first | 27% (10 of 37) | 0% (0 of 6) | 23% (10 of 43) |
| it fought by the end of its next turn | 19% (7 of 37) | 0% (0 of 6) | 16% (7 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 16% (6 of 37) | 0% (0 of 6) | 14% (6 of 43) |
| none of these (no charge, no fight, no charge escaped) | 54% (20 of 37) | 100% (6 of 6) | 60% (26 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (579 of 889) | 58% (311 of 536) | 62% (890 of 1425) |
|   cavalry | 65% (55 of 84) | 72% (81 of 112) | 69% (136 of 196) |
|   character | 37% (38 of 103) | 20% (24 of 123) | 27% (62 of 226) |
|   chariot | 51% (52 of 102) | 65% (11 of 17) | 53% (63 of 119) |
|   infantry | 65% (172 of 266) | 70% (157 of 225) | 67% (329 of 491) |
|   monster | 45% (21 of 47) | 30% (8 of 27) | 39% (29 of 74) |
|   war machine | 84% (241 of 287) | 94% (30 of 32) | 85% (271 of 319) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 1.4 (22%) | 3.6 (24%) |
| CHARGED: it charged | 1.4 (16%) | 1.4 (23%) | 2.8 (19%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.4 (6%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.7 (20%) | 1.2 (20%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.7 (11%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 1.0 (16%) | 2.3 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.4 | 84% | 5.2 pts | 33 pts |
| character | 2.0 | 0.6 | 83% | 7.0 pts | 14 pts |
| chariot | 1.8 | 0.9 | 67% | 12.8 pts | 22 pts |
| infantry | 13.0 | 4.9 | 74% | 9.6 pts | 125 pts |
| monster | 0.9 | 0.2 | 85% | 3.1 pts | 3 pts |
| war machine | 7.5 | 6.4 | 64% | 27.5 pts | 207 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.8 | 5.5 |
| Charges that made contact a game | 2.9 | 4.9 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.71 contact (17 units) | 0.76 declared, 0.65 contact (17 units) | 0.88 declared, 0.68 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (8 units) | 1.50 declared, 1.14 contact (14 units) | 1.14 declared, 0.91 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.36 contact (248 units) | 0.72 declared, 0.51 contact (295 units) | 0.63 declared, 0.44 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (38 of 81) | 31% (5 of 16) | 50% (3 of 6) | 45% (46 of 103) |
| Character in a unit | 79% (22 of 28) | 67% (10 of 15) | 0% (0 of 1) | 73% (32 of 44) |
| Character on its own | 78% (29 of 37) | 56% (15 of 27) | 29% (22 of 77) | 47% (66 of 141) |
| Chariot | 73% (11 of 15) | 33% (4 of 12) | - | 56% (15 of 27) |
| Infantry | 60% (50 of 83) | 40% (10 of 25) | 17% (1 of 6) | 54% (61 of 114) |
| Monster | 68% (23 of 34) | 57% (8 of 14) | - | 65% (31 of 48) |
| Monstrous | 57% (8 of 14) | 71% (10 of 14) | - | 64% (18 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 82% (9 of 11); on the table 91% | 17% (17 of 102) | 27% | 64% (14 of 22) | 83% (5 of 6); 2.5 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 90% (9 of 10); on the table 90% | 62% (15 of 24) | 37% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 87% (13 of 15); on the table 87% | - | 48% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 90% (9 of 10); on the table 90% | 56% (10 of 18) | 44% | 63% (39 of 62) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (7 of 7); on the table 100% | 21% (18 of 84) | 41% | 38% (14 of 37) | 100% (9 of 9); 7.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 88% (22 of 25); on the table 96% | 17% (6 of 36) | 32% | 49% (34 of 70) | 86% (6 of 7); 2.8 uses a game | 43% (13 of 30); 2.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 24% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (8 of 8); on the table 100% | 50% (3 of 6) | 31% | 71% (15 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (6 of 6); on the table 100% | 50% (3 of 6) | 50% | 86% (12 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (12 of 12); on the table 100% | 24% (10 of 42) | 30% | 29% (7 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 88% (22 of 25); on the table 100% | 32% (13 of 40) | 45% | 71% (32 of 45) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 100% (13 of 13); on the table 100% | 0% (0 of 6) | 22% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 84% (16 of 19); on the table 89% | 30% (17 of 57) | 24% | 43% (18 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (17 of 19); on the table 95% | 33% (4 of 12) | 24% | 51% (37 of 72) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (15 of 15); on the table 100% | 83% (5 of 6) | 49% | 59% (33 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-opp-779e261-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (48) | 50% (34) | 48% (82) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.50 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.28 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.36 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.42 | 1.31 | 2.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.17 | 0.42 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 5.44 | 11.03 |

### Quality by phase: os-h2h-opp-779e261-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 44% (67 of 151) | 45% (83 of 183) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (170 of 405) | 38% (72 of 190) |
| Strategy | Close-in objectives charged next turn | 16% (24 of 147) | 15% (36 of 239) |
| Strategy | Support requests answered (helper made contact too) | 59% (10 of 17) | 47% (14 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (4 of 9) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 46% (17 of 37) | 62% (18 of 29) |
| Strategy | Lone characters that fought | 76% (65 of 86) | 76% (66 of 87) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 311.3 | 132.2 |
| Movement | Fights charged into per game | 2.9 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 96, net +23 | 20 of 121, net -19 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 96, net +51 | 26 of 121, net +129 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 96, net +73 | 16 of 121, net +151 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 96, net +56 | 28 of 121, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (180 of 364) | 46% (151 of 327) |
| Shooting | Points destroyed by shooting units | 63.2 | 47.8 |
| Shooting | War machine shots | 6.7 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (127 of 241) | 23% (7 of 30) |
| Shooting | Points destroyed by war machines | 54.2 | 12.6 |
| Magic | Magic missiles cast | 1.2 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 19% (8 of 42) | 17% (7 of 42) |
| Magic | Wounds caused by magic missiles | 3.4 | 1.6 |
| Magic | Wounds caused by other spells | 1.4 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 113.6 | 29.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.3 / 0.6 / 0.1 | 2.1 / 0.4 / 0.9 / 0.1 |
| Combat | Points destroyed in combat | 247.4 | 446.5 |
| Combat | Points run down | 134.0 | 97.6 |
| Combat | Net points per charged fight, damage counted | +59 | +95 |
| Combat | Net per 100 charger points, damage counted | +22.0 | +31.2 |
| Combat | First round won (charged fights) | 76% | 74% |
| Combat | Net points per charged fight | +59 | +96 |
| Combat | Net points per supported fight / lone fight | +85 / +56 | +172 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 105 | 67 of 140 |
| Game | Points lost | 772.3 | 684.5 |
| Game | VP from objectives | 475.8 | 606.7 |
| Game | Lone holders (player turns) | 2.0 | 4.3 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -263 VP
- The side that went first won 17 of 29 games with a winner
- Points traded per game (both sides' losses): 1457
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-opp-779e261-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.8 | -214.0 | 143.6 | 68.4 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 34.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +5.1 | 0.0 | 17.8 | 0.5 | +3.8 | 0.0 | 5.8 |
| BEST FACING | 0.6 | +30.1 | 0.0 | 31.3 | 0.3 | +9.9 | 0.0 | 27.3 |
| BEST FIRST | 3.6 | +142.1 | 105.9 | 76.6 | 0.9 | +51.6 | 28.9 | 13.2 |
| BEST OVERALL | 0.5 | +30.3 | 0.0 | 13.5 | 0.1 | +1.7 | 0.0 | 1.9 |
| BEST PREY | 0.7 | +38.3 | 17.3 | 15.2 | 0.6 | +32.1 | 4.2 | 27.2 |
| BEST PRIZE | 0.1 | -0.8 | 5.8 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | -0.7 | 0.0 | 0.0 | 0.2 | -0.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 18.6 | 0.0 | 0.1 | +0.0 | 6.1 | 3.9 |
| BLOCKED WHEEL | 0.4 | +8.8 | 0.0 | 7.1 | 0.4 | +8.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -13.4 | 35.2 | 4.9 | 0.4 | -55.1 | 48.7 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 81.3 | 5.4 | 0.2 | +0.0 | 32.3 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +239.3 | 306.4 | 98.5 | 0.7 | +26.4 | 75.7 | 0.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.9 | 4.9 | 12.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -0.6 | 8.3 | 12.1 | 0.2 | -4.0 | 5.2 | 0.0 |
| CAST JOB | 0.9 | +29.8 | 32.3 | 27.5 | 0.2 | +2.0 | 0.0 | 6.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +16.7 | 8.1 | 0.0 | 0.1 | +4.9 | 23.2 | 0.0 |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 33.6 | 0.2 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.9 | +103.5 | 0.0 | 34.9 |
| CHAFF PASSED | 0.1 | +0.0 | 28.6 | 0.0 | 0.2 | -0.1 | 0.0 | 19.6 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 196.8 | 128.1 | 2.6 | +0.0 | 284.9 | 78.1 |
| CHARGE NOW WEIGHED | 0.3 | -19.0 | 14.3 | 11.3 | 0.6 | -44.1 | 8.8 | 17.8 |
| CHARGER SLAIN LOST | 0.5 | -16.1 | 82.8 | 38.7 | 0.5 | -16.7 | 51.6 | 18.8 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.9 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 20.9 | 3.2 | 0.0 | +0.0 | 0.0 | 1.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 1.2 | 60.0 | 0.7 | +0.0 | 45.3 | 23.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 5.1 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.1 | +125.6 | 8.1 | 13.9 | 0.2 | +15.5 | 11.1 | 11.1 |
| COUNTER-CHARGE COVER | 9.1 | +779.9 | 0.0 | 209.4 | - | - | - | - |
| COVER ONCE | - | - | - | - | 6.5 | -514.8 | 0.0 | 134.9 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 1.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.0 | +1.0 | 3.0 | 0.0 | 0.1 | +9.4 | 4.9 | 17.9 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +89.4 | 0.0 | 49.6 | 1.3 | +86.2 | 0.0 | 53.8 |
| FALLBACK BY WORTH | 4.7 | +41.1 | 0.0 | 99.7 | 5.9 | +56.4 | 0.0 | 47.0 |
| FIGHT LIFT | 0.2 | +1.6 | 3.2 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 133.3 | 4.8 | +0.0 | 0.0 | 103.8 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.7 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +124.3 | 0.0 | 37.1 | 0.9 | +124.0 | 0.0 | 4.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.1 | 0.0 | 0.0 | 0.1 | +7.4 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.3 | 0.0 | 12.3 | 0.1 | -1.5 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.3 | 6.8 | 0.0 | 0.0 | -0.5 | 0.0 | 1.2 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.8 | 1.7 | 0.0 | +0.0 | 6.2 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 29.5 | 18.4 | 0.6 | +0.0 | 58.8 | 7.2 |
| HILL BY ITS CHANCE | 0.6 | -63.9 | 0.0 | 5.3 | 0.7 | -72.8 | 0.0 | 12.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -159.5 | 396.2 | 198.2 | 9.2 | -210.3 | 556.6 | 165.9 |
| HUNT ADVANCE | 0.0 | +0.2 | 5.4 | 0.0 | 0.1 | +2.4 | 0.0 | 4.7 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.1 |
| HUNT IN PAIRS | 0.3 | +5.0 | 0.0 | 0.0 | 0.4 | +26.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +5.9 | 5.4 | 1.9 | 0.1 | +0.0 | 0.0 | 7.4 |
| HUNT THE GUNS | 0.0 | +6.0 | 5.4 | 0.0 | 0.1 | +34.2 | 0.0 | 6.0 |
| IDLE COST | - | - | - | - | 19.6 | -320.9 | 0.0 | 171.2 |
| INVITES THE FIGHT | 2.1 | +36.1 | 99.8 | 43.3 | 1.1 | +8.9 | 58.2 | 1.7 |
| JOINT CHARGE PLAN | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -6.9 | 18.5 | 0.0 |
| KEEP FALLS | 0.1 | +2.0 | 0.0 | 6.1 | 0.1 | +0.6 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +52.5 | 118.3 | 49.9 | 2.3 | +70.0 | 223.7 | 48.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +60.2 | 105.9 | 56.0 | 2.1 | +119.1 | 187.2 | 49.1 |
| KILLS COUNT NEXT TURN | 4.8 | +148.0 | 179.7 | 131.6 | 6.7 | +214.6 | 211.9 | 126.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +9.7 | 5.7 | 3.8 | 0.4 | +26.1 | 7.8 | 14.6 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 37.5 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +0.7 | 22.5 | 16.7 | 0.5 | +1.8 | 26.5 | 1.7 |
| LOST CHARGE | 2.6 | -43.5 | 114.3 | 56.9 | 1.9 | -29.5 | 43.7 | 58.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -15.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +61.0 | 4.7 | 22.1 | 1.0 | +54.5 | 0.0 | 23.2 |
| MANOEUVRE | 0.4 | +17.8 | 0.0 | 15.6 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +27.0 | 0.0 | 0.0 | 0.2 | +10.2 | 0.0 | 14.1 |
| MARCH ODDS | 0.3 | +17.7 | 28.7 | 10.2 | 0.4 | +20.3 | 11.6 | 0.0 |
| MARCH OVER CASTS | 0.6 | +27.7 | 0.0 | 18.8 | 0.2 | +16.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +166.9 | 0.0 | 84.6 | 6.0 | +93.0 | 0.0 | 111.4 |
| MISSILES IN THE MOVE | 3.7 | +126.9 | 0.0 | 51.3 | 2.0 | +27.9 | 0.0 | 77.6 |
| MISSILES NEXT TURN | 4.6 | +86.5 | 0.0 | 85.1 | 2.9 | +22.4 | 0.0 | 71.1 |
| MODEL FACING | 0.3 | +40.0 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 5.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +15.5 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 6.4 |
| MOVE SPELL IN RANGE | 0.3 | +5.9 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.8 | -42.5 | 72.4 | 63.2 | 0.1 | -10.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 1.5 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.5 | +124.9 | 76.8 | 64.2 | 4.4 | +284.6 | 144.2 | 83.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +9.8 | 11.9 | 0.0 | 0.1 | +10.2 | 10.3 | 0.0 |
| NOT NEEDED | 0.2 | -7.6 | 9.7 | 12.1 | 0.2 | -8.0 | 23.0 | 1.2 |
| NOT TURNED | 5.6 | +63.7 | 0.0 | 114.4 | 5.4 | +96.8 | 0.0 | 82.6 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 13.2 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.7 | -703.1 | 7.4 | 243.5 | 15.0 | -719.4 | 13.4 | 242.6 |
| ONE FIGHT FORMULA | - | - | - | - | 8.8 | -174.5 | 32.1 | 152.4 |
| ONE OBJECTIVE FORMULA | - | - | - | - | 2.1 | -113.8 | 0.0 | 52.7 |
| OPENS A LANE | 0.1 | +0.4 | 4.2 | 0.0 | 0.1 | +0.8 | 12.9 | 2.0 |
| OPENS UP | 0.4 | +24.3 | 25.6 | 0.0 | 0.2 | +41.1 | 16.9 | 13.9 |
| OVERRUN THREAT | 0.0 | +4.6 | 0.0 | 3.3 | 0.0 | +0.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +13.7 | 65.7 | 30.4 | 0.6 | +16.0 | 64.1 | 11.1 |
| PATHS CROSS | 2.2 | +124.3 | 0.0 | 47.3 | 2.8 | +186.9 | 0.0 | 15.7 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +7.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.8 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 16.6 |
| PLAN RESULT | 38.6 | +1349.7 | 1509.9 | 1143.3 | 38.9 | +1286.2 | 1566.2 | 985.0 |
| PURSUES BIG PREY | 0.1 | -8.8 | 0.0 | 0.0 | 0.0 | -7.1 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.9 | 0.0 | 2.2 | 0.1 | +13.0 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +18.4 | 0.0 | 40.8 | 1.6 | +14.9 | 0.0 | 81.7 |
| RANDOM MOVER NO PROMISE | 0.4 | -18.1 | 17.9 | 4.0 | 0.2 | -13.2 | 9.5 | 8.8 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -2.2 | 0.0 | 7.0 | 1.7 | -47.9 | 0.0 | 32.7 |
| REDIRECT COUNTER | 2.7 | +193.3 | 0.0 | 40.3 | 3.8 | +254.4 | 0.0 | 71.2 |
| REDIRECT WEIGHED | 0.3 | +2.9 | 5.8 | 13.9 | 0.3 | +10.9 | 20.4 | 9.7 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 12.7 | 0.4 | +0.0 | 0.0 | 13.9 |
| RESERVE FALL BACK | 0.5 | +24.3 | 0.0 | 0.0 | 0.5 | +27.0 | 0.0 | 9.1 |
| RESTRAINS TO SHOOT | 0.1 | +3.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.8 | +108.4 | 248.9 | 136.8 | 2.5 | +52.0 | 286.1 | 88.8 |
| RISK ONCE | - | - | - | - | 4.4 | +218.1 | 44.3 | 272.7 |
| SAFE SURE CHARGE | - | - | - | - | 0.1 | -2.7 | 2.0 | 0.0 |
| SAFER THAN THE JOB | 1.2 | +106.3 | 0.0 | 43.7 | 0.4 | +13.8 | 0.0 | 19.2 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.2 | 0.0 | 0.9 | 0.4 | -28.4 | 0.0 | 3.8 |
| SEARCH SPOT | 2.6 | +129.8 | 0.0 | 32.1 | 3.1 | +151.0 | 0.0 | 38.9 |
| SELF MOVE SPELL | 0.2 | +57.9 | 0.0 | 0.0 | 0.4 | +21.0 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.0 | +70.7 | 18.6 | 24.5 | 1.5 | +102.9 | 6.1 | 33.4 |
| SET-UP ANY TARGET | 0.7 | +88.1 | 2.5 | 13.9 | 0.1 | +7.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +28.7 | 40.4 | 1.8 | 1.2 | +24.7 | 45.2 | 29.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 97.2 | 9.6 | 0.5 | +0.0 | 82.9 | 0.0 |
| SHOTS IN THE MOVE | 14.8 | +660.0 | 0.0 | 282.6 | 7.7 | +208.5 | 0.0 | 149.9 |
| SPELL CATCH ODDS | 0.0 | -0.8 | 0.0 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +88.1 | 2.5 | 13.9 | 0.1 | +7.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +21.1 | 157.6 | 169.5 | 2.4 | +54.3 | 58.6 | 61.2 |
| SPELLS IN THE FIGHT | 0.8 | +0.1 | 81.8 | 36.9 | 0.7 | -13.2 | 64.1 | 1.7 |
| STABLE ROLE | 11.1 | +0.0 | 439.5 | 239.8 | 10.0 | +0.0 | 328.8 | 161.9 |
| STAY WEIGHED | 0.2 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +0.9 | 0.0 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +20.0 | 0.0 | 0.0 | 0.2 | +1.4 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.4 | -66.3 | 387.9 | 122.1 | 7.6 | -67.7 | 337.9 | 80.6 |
| SUPPORTS | 4.4 | +71.1 | 247.8 | 91.1 | 5.5 | +69.9 | 147.1 | 46.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 11.4 | 0.0 | 0.0 | -0.1 | 1.8 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -0.5 | 0.0 | 0.0 | 0.5 | +6.7 | 0.0 | 11.4 |
| THROUGH LINE OF FIRE | 0.2 | -5.1 | 0.0 | 0.0 | 0.2 | +6.4 | 0.0 | 4.9 |
| TURN WORTH | 0.3 | -18.8 | 29.1 | 1.5 | 0.2 | -18.9 | 17.0 | 13.9 |
| TWO OR MORE ARRIVE | 0.4 | +2.3 | 18.6 | 9.0 | 0.5 | +2.3 | 0.0 | 16.7 |
| WAIT AFTER COSTS | 6.5 | -279.8 | 241.5 | 128.1 | 7.7 | -376.0 | 292.2 | 96.3 |
| WALKS TO THE FIGHT | 1.3 | +14.6 | 31.2 | 18.9 | 0.7 | +5.5 | 16.8 | 11.2 |
| WAR ENGINE CHARGES | 0.1 | +4.3 | 7.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 49.9 | 12.6 | 0.1 | +0.0 | 2.2 | 8.1 |
| WEARS DOWN | 1.5 | +55.7 | 132.0 | 90.4 | 1.2 | +43.8 | 142.6 | 38.9 |
| WHO HITS BACK | 0.2 | +10.3 | 0.0 | 8.4 | 0.3 | +26.9 | 0.0 | 7.4 |
| WHOLE FIGHT | 0.4 | +31.1 | 56.1 | 1.5 | 0.5 | +27.1 | 83.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +31.3 | 38.3 | 7.7 | 0.6 | +53.0 | 64.8 | 7.8 |
| WIDER SPREAD | 2.8 | -8.9 | 218.4 | 100.5 | 3.2 | -9.0 | 311.8 | 54.1 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 0.8 | 0.0 | - | - | - | - |

### Rule changes: os-h2h-opp-779e261-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1068 | 1068 | 1068 | 29.67 | -51208 | -47.9 |
| SEARCH SPOT | 208 | 208 | 200 | 5.56 | +10148 | +50.7 |
| PATHS CROSS | 180 | 180 | 180 | 5.00 | +11205 | +62.3 |
| BEST FIRST | 161 | 161 | 161 | 4.47 | +6972 | +43.3 |
| SUPPORTS | 356 | 356 | 148 | 4.11 | +1859 | +12.6 |
| MOVE TO CHARGE | 250 | 250 | 136 | 3.78 | +5179 | +38.1 |
| KILLS COUNT NEXT TURN | 416 | 416 | 132 | 3.67 | +2830 | +21.4 |
| FACES THE THREAT | 98 | 98 | 98 | 2.72 | +6322 | +64.5 |
| COUNTER-CHARGE COVER | 329 | 183 | 87 | 2.42 | +6334 | +72.8 |
| WAIT AFTER COSTS | 512 | 512 | 83 | 2.31 | +1321 | +15.9 |
| FALLBACK BY WORTH | 381 | 381 | 72 | 2.00 | +3511 | +48.8 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +8941 | +129.6 |
| REDIRECT COUNTER | 235 | 130 | 66 | 1.83 | +5831 | +88.4 |
| SHOTS IN THE MOVE | 812 | 564 | 66 | 1.83 | +1713 | +26.0 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +4321 | +75.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 97 | 97 | 54 | 1.50 | +1199 | +22.2 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| MAX FOR POSITIONING | 391 | 236 | 47 | 1.31 | +452 | +9.6 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHAFF IN THE MOVE | 69 | 65 | 41 | 1.14 | +1336 | +32.6 |
| SHOT REPLANNED | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RISK BY ARC | 190 | 182 | 39 | 1.08 | +1070 | +27.4 |
| COVER ONCE | 233 | 140 | 38 | 1.06 | +883 | +23.2 |
| RESERVE FALL BACK | 38 | 38 | 38 | 1.06 | +1848 | +48.6 |
| SET UP TOGETHER | 90 | 75 | 36 | 1.00 | +1742 | +48.4 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2116 | +60.5 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| WALKS TO THE FIGHT | 72 | 72 | 34 | 0.94 | +201 | +5.9 |
| BEST FACING | 33 | 33 | 33 | 0.92 | +1442 | +43.7 |
| CHARGE NOW FIRST | 182 | 182 | 33 | 0.92 | -1084 | -32.8 |
| HONEST WORTH | 607 | 600 | 33 | 0.92 | +388 | +11.8 |
| RISK ONCE | 160 | 132 | 33 | 0.92 | +2338 | +70.8 |
| KILLS COUNT | 129 | 123 | 32 | 0.89 | +1415 | +44.2 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +620 | +20.7 |
| MISSILES IN THE MOVE | 206 | 129 | 29 | 0.81 | +732 | +25.2 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 29 | 0.81 | +447 | +15.4 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| CANNON PLANNED TARGET | 208 | 208 | 26 | 0.72 | -335 | -12.9 |
| INVITES THE FIGHT | 115 | 115 | 25 | 0.69 | +250 | +10.0 |
| KEEPS ITS TARGET | 147 | 146 | 25 | 0.69 | +454 | +18.2 |
| MARCH ODDS | 25 | 25 | 25 | 0.69 | +301 | +12.1 |
| CAST JOB | 42 | 42 | 23 | 0.64 | +302 | +13.1 |
| STOPS SHORT OF THE FLANK | 23 | 23 | 23 | 0.64 | +771 | +33.5 |
| MARCH CHECK | 25 | 24 | 22 | 0.61 | +947 | +43.1 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +987 | +44.9 |
| BEST OVERALL | 21 | 21 | 21 | 0.58 | +1154 | +54.9 |
| IDLE COST | 707 | 421 | 21 | 0.58 | +254 | +12.1 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1550 | +73.8 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| ADVANCE WORTH | 172 | 172 | 19 | 0.53 | +408 | +21.5 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +878 | +46.2 |
| ONE FIGHT FORMULA | 317 | 180 | 18 | 0.50 | +31 | +1.7 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MAKE SURE TOGETHER | 63 | 41 | 17 | 0.47 | +973 | +57.2 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +49 | +2.9 |
| WAR ENGINE JOBS | 29 | 29 | 17 | 0.47 | -574 | -33.8 |
| WHOLE FIGHT GAIN | 34 | 32 | 17 | 0.47 | +813 | +47.8 |
| OPENS UP | 23 | 23 | 16 | 0.44 | +760 | +47.5 |
| BEST PREY | 46 | 46 | 14 | 0.39 | +510 | +36.5 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -52 | -3.7 |
| MANOEUVRE | 15 | 15 | 14 | 0.39 | +648 | +46.3 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +595 | +49.6 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| WEARS DOWN | 99 | 97 | 12 | 0.33 | +497 | +41.4 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -5 | -0.5 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +1438 | +130.8 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WHOLE FIGHT | 33 | 33 | 8 | 0.22 | +383 | +47.9 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +209 | +29.9 |
| MISSILES NEXT TURN | 269 | 155 | 7 | 0.19 | +51 | +7.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OVERRUNS AWAY | 43 | 42 | 7 | 0.19 | +279 | +39.8 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +289 | +41.3 |
| SUPPORT NARROWED | 504 | 504 | 7 | 0.19 | -92 | -13.1 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -103 | -17.1 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +716 | +119.4 |
| SURE REACH TOGETHER | 35 | 29 | 6 | 0.17 | +31 | +5.2 |
| BACKUP TARGETS | 51 | 23 | 5 | 0.14 | +22 | +4.4 |
| CASTING BLOCK | 11 | 11 | 5 | 0.14 | +396 | +79.2 |
| LOST CHARGE | 164 | 164 | 5 | 0.14 | +268 | +53.6 |
| NEEDED THERE | 6 | 6 | 5 | 0.14 | +0 | +0.0 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +395 | +79.0 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +125 | +25.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -50 | -10.0 |
| HUNT IN PAIRS | 23 | 10 | 4 | 0.11 | +120 | +29.9 |
| SAFE SURE CHARGE | 4 | 4 | 4 | 0.11 | -97 | -24.1 |
| LONG SHOT | 34 | 34 | 3 | 0.08 | +20 | +6.6 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -572 | -190.6 |
| REFUSING RETIRES | 25 | 25 | 3 | 0.08 | -0 | -0.2 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.08 | -56 | -18.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -28 | -13.9 |
| BLOWS WHERE AIMED | 28 | 25 | 2 | 0.06 | +104 | +51.8 |
| CARRIES OUT SET-UP | 13 | 13 | 2 | 0.06 | -168 | -83.9 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +51 | +25.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 75 | 39 | 2 | 0.06 | +185 | +92.6 |
| WIDER SPREAD | 218 | 208 | 2 | 0.06 | +11 | +5.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +29 | +28.9 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -32 | -31.5 |
| CHARGER SLAIN LOST | 36 | 36 | 1 | 0.03 | +11 | +11.0 |
| DEFENSIVE ARMY | 5 | 5 | 1 | 0.03 | -3 | -2.8 |
| EDGE GIVE GROUND | 6 | 6 | 1 | 0.03 | +92 | +92.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +11.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +24 | +24.0 |
| HILL BY ITS CHANCE | 46 | 46 | 1 | 0.03 | +40 | +39.7 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +22 | +21.7 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 1 | 0.03 | -129 | -128.6 |
| MOVE SPELL IN RANGE | 14 | 5 | 1 | 0.03 | +2 | +2.1 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +20 | +20.2 |
| REDIRECT BY WHAT IT STOPS | 75 | 75 | 1 | 0.03 | +40 | +40.1 |
| SPELLS IN THE FIGHT | 54 | 52 | 1 | 0.03 | +8 | +8.1 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 50 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 369 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 32 | 29 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 7 | 7 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 10 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 26 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 33 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 397 | 397 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 6 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 2 | not checked | - | - | - | - |
| PLAN RESULT | 2791 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 22 | 22 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 28 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 139 | not checked | - | - | - | - |
| STABLE ROLE | 760 | 758 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 32 | 28 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-opp-779e261-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.97 | 13.56 | 49.2 |
| FALLBACK | gate | 0.56 | 0.58 | 48.4 |
| TURN GATE | gate | 0.69 | 0.28 | 30.2 |
| CHARGE NOW FIRST | rule | 0.53 | 0.39 | 32.8 |
| WAR ENGINE JOBS | rule | 0.36 | 0.11 | 33.8 |
| PATHS CROSS | rule | 0.14 | 0.19 | 23.2 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.11 | 6.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.11 | 59.6 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 59.0 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.03 | 59.3 |
| FIGHT ORDER BAND | gate | 0.06 | 0.14 | 1.5 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.08 | 6.3 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 13.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 17.1 |
| AFTERMATH BAND | gate | - | 0.14 | 2.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.03 | 10.0 |
| RULE SWITCHED OFF | gate | 0.11 | - | 14.7 |
| SAFE SURE CHARGE | rule | - | 0.11 | 24.1 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 59.3 |
| MARCH ODDS | rule | 0.03 | 0.06 | 45.0 |
| PURSUES BIG PREY | rule | 0.06 | 0.03 | 190.6 |
| WOUNDED STAYS OUT | rule | 0.08 | - | 18.6 |
| BEST PRIZE | rule | 0.06 | - | 13.9 |
| BLOCKED WHEEL | rule | 0.06 | - | 7.4 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 83.9 |
| CHAFF PASSED | rule | - | 0.06 | 2.5 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 14.9 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 6.6 |
| NO REASON | gate | - | 0.06 | 2.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 8.3 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 31.5 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 128.6 |
| REDIRECT WEIGHED | rule | 0.03 | - | 22.1 |
| SAFER THAN THE JOB | rule | 0.03 | - | 11.3 |

### Plans: os-h2h-opp-779e261-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 20% | 380 | 325 | 86% |
| Mine | charge | 3.3 | 55% | 271 | 269 | 99% |
| Mine | close in | 4.1 | 27% | 220 | 114 | 52% |
| Mine | hold | 4.7 | 31% | 306 | 0 | 0% |
| Mine | join | 0.5 | 94% | 9 | 0 | 0% |
| Mine | shoot | 9.7 | 56% | 363 | 641 | 177% |
| Mine | support | 4.8 | 88% | 49 | 0 | 0% |
| Opponent | advance | 11.0 | 16% | 136 | 337 | 248% |
| Opponent | charge | 4.3 | 57% | 386 | 474 | 123% |
| Opponent | close in | 6.6 | 26% | 344 | 196 | 57% |
| Opponent | hold | 4.5 | 35% | 326 | 0 | 0% |
| Opponent | join | 0.8 | 93% | 31 | 0 | 0% |
| Opponent | shoot | 4.3 | 69% | 80 | 287 | 359% |
| Opponent | support | 7.4 | 89% | 49 | 0 | 0% |

### Packages: hunt the guns, os-h2h-opp-779e261-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 216 | 211 | 100% | 25 |
| Opponent | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 308 | 0 | 0% | 65 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 109 | 0 | 0% | 33 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 216 | 211 | 100% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 62 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 26 |

### Battle groups: os-h2h-opp-779e261-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.1 | 21% | 43% | 6% | 50% | 29% | 18% | 9% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.7 | 33% | 66% | 9% | 33% | 21% | 0% | 7% | 69% | 3% |
| Opponent | REDIRECT COUNTER | 3.8 | 25% | 65% | 18% | 0% | 25% | 4% | 4% | 64% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-opp-779e261-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 138 (4) | 138 | 0 | 41 | 0% | 4.2 | - | 138 (4) | - | 222 (1) | 115 (3) |
| Mine | Chaff | 34 | 22 (34) | 18 | 4 | 64 | 32% | 2.4 | 21 (14) | 26 (7) | 21 (13) | 31 (22) | 5 (12) |
| Mine | Character | 106 | 34 (106) | 34 | 0 | 47 | 19% | 2.4 | 22 (29) | 46 (54) | 16 (5) | 35 (41) | 38 (47) |
| Mine | Clean-up | 22 | 59 (22) | 38 | 21 | 35 | 14% | 3.6 | 48 (2) | 61 (16) | 60 (4) | 35 (10) | 72 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 25% | 3.3 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 52 (41) | 29 | 23 | 43 | 12% | 2.8 | 54 (27) | 50 (9) | 47 (5) | 61 (25) | 38 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.3 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 37 (65) | 28 | 9 | 45 | 14% | 2.5 | 50 (13) | 36 (45) | 22 (7) | 44 (40) | 29 (25) |
| Mine | Holder | 31 | 97 (31) | 20 | 77 | 28 | 35% | 3.1 | 127 (8) | 108 (16) | 21 (7) | 129 (21) | 45 (10) |
| Mine | Shooter | 34 | 69 (34) | 37 | 32 | 38 | 0% | 1.6 | 4 (8) | 111 (21) | 0 (5) | 76 (25) | 47 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 34 (56) | 34 | 0 | 42 | 2% | 1.3 | 42 (16) | 40 (30) | 0 (10) | 29 (9) | 35 (47) |
| Mine | Wizard | 17 | 9 (17) | 9 | 0 | 40 | 12% | 1.9 | 0 (5) | 22 (8) | 0 (1) | 8 (7) | 16 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 75 | 30 (75) | 10 | 20 | 56 | 45% | 2.6 | 35 (31) | 41 (17) | 15 (27) | 31 (56) | 25 (19) |
| Opponent | Character | 97 | 55 (97) | 55 | 0 | 30 | 16% | 2.6 | 53 (46) | 65 (37) | 26 (6) | 55 (51) | 57 (38) |
| Opponent | Clean-up | 11 | 75 (11) | 10 | 64 | 25 | 27% | 2.4 | 0 (3) | 82 (6) | 101 (2) | 33 (6) | 98 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 56 (60) | 39 | 17 | 34 | 25% | 2.9 | 49 (26) | 49 (25) | 111 (9) | 49 (39) | 68 (21) |
| Opponent | Fragile | 17 | 6 (17) | 6 | 0 | 57 | 18% | 1.9 | 25 (5) | 0 (8) | 0 (4) | 0 (13) | 28 (4) |
| Opponent | Hammer | 65 | 42 (65) | 22 | 19 | 38 | 34% | 3.0 | 35 (20) | 44 (38) | 36 (7) | 30 (41) | 58 (24) |
| Opponent | Holder | 29 | 56 (29) | 21 | 35 | 19 | 52% | 3.9 | 7 (11) | 55 (11) | 147 (7) | 66 (20) | 36 (9) |
| Opponent | Shooter | 33 | 67 (33) | 27 | 40 | 47 | 3% | 1.4 | 51 (9) | 73 (21) | 74 (3) | 71 (18) | 63 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 64 | 83% | 6.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | War machine | 6 | 137 (6) | 137 | 0 | 21 | 0% | 1.0 | 106 (3) | 180 (3) | - | 106 (3) | 180 (3) |
| Opponent | Wizard | 19 | 15 (19) | 15 | 0 | 60 | 16% | 1.8 | 2 (10) | 0 (1) | 14 (3) | 7 (9) | 0 (5) |

### Charged fights: os-h2h-opp-779e261-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 104 | 92 | 2.0 | 1.1 | 46 | 32 | +14 | 3 of 8 | 7 of 8 | +70 | +6 |
| Mine | Chaos Dwarfs | 4 | 160 | 368 | 2.2 | 1.1 | 164 | 13 | +150 | 4 of 9 | 7 of 9 | +160 | +149 |
| Mine | Dwarfen Mountain Holds | 3 | 513 | 96 | 2.7 | 1.1 | 36 | 0 | +36 | 3 of 8 | 7 of 8 | +0 | +41 |
| Mine | Empire of Man | 5 | 248 | 277 | 1.4 | 1.0 | 198 | 38 | +160 | 3 of 7 | 5 of 7 | - | +160 |
| Mine | Grand Cathay | 4 | 300 | 262 | 3.8 | 1.1 | 70 | 25 | +45 | 5 of 15 | 13 of 15 | +144 | +30 |
| Mine | High Elf Realms | 4 | 481 | 312 | 4.0 | 1.1 | 78 | 4 | +74 | 3 of 16 | 14 of 16 | +65 | +76 |
| Mine | Kingdom of Bretonnia | 1 | 410 | 0 | 6.0 | 1.0 | 0 | 0 | +0 | 5 of 6 | 2 of 6 | - | +0 |
| Mine | Lizardmen | 1 | 55 | 235 | 4.0 | 1.0 | 59 | 226 | -168 | 4 of 4 | 2 of 4 | - | -168 |
| Mine | Ogre Kingdoms | 2 | 57 | 0 | 2.0 | 1.2 | 0 | 8 | -8 | 1 of 4 | 3 of 4 | +0 | -11 |
| Mine | Skaven | 2 | 292 | 176 | 3.0 | 1.0 | 59 | 0 | +59 | 1 of 6 | 5 of 6 | - | +59 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 534 | 2.5 | 1.4 | 214 | 108 | +106 | 2 of 5 | 4 of 5 | +101 | +109 |
| Mine | Vampire Counts | 2 | 38 | 442 | 3.5 | 1.0 | 126 | 6 | +121 | 3 of 7 | 4 of 7 | - | +121 |
| Mine | Warriors of Chaos | 2 | 0 | 254 | 5.0 | 1.0 | 51 | 9 | +41 | 4 of 10 | 7 of 10 | - | +41 |
| **Mine** | all armies | 36 | 231 | 246 | 2.9 | 1.1 | 84 | 26 | +59 | 41 of 105 | 80 of 105 | +85 | +56 |
| Opponent | Empire of Man | 1 | 675 | 613 | 2.0 | 1.0 | 306 | 0 | +306 | 2 of 2 | 2 of 2 | - | +306 |
| Opponent | High Elf Realms | 5 | 280 | 373 | 3.4 | 1.2 | 110 | 85 | +25 | 12 of 17 | 11 of 17 | -281 | +90 |
| Opponent | Lizardmen | 2 | 0 | 781 | 3.5 | 1.1 | 223 | 0 | +223 | 3 of 7 | 5 of 7 | +0 | +260 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 723 | 4.3 | 1.1 | 167 | 62 | +105 | 3 of 13 | 10 of 13 | +185 | +99 |
| Opponent | Skaven | 4 | 138 | 272 | 3.8 | 1.0 | 73 | 57 | +16 | 10 of 15 | 10 of 15 | - | +16 |
| Opponent | Tomb Kings of Khemri | 2 | 90 | 390 | 4.0 | 1.4 | 98 | 8 | +90 | 3 of 8 | 7 of 8 | +151 | +70 |
| Opponent | Vampire Counts | 6 | 10 | 428 | 4.7 | 1.4 | 92 | 12 | +80 | 16 of 28 | 21 of 28 | +238 | +16 |
| Opponent | Warriors of Chaos | 7 | 0 | 649 | 3.9 | 1.2 | 168 | 32 | +136 | 12 of 27 | 18 of 27 | +312 | +96 |
| Opponent | Wood Elf Realms | 6 | 60 | 453 | 3.8 | 1.2 | 118 | 7 | +111 | 6 of 23 | 19 of 23 | +236 | +76 |
| **Opponent** | all armies | 36 | 90 | 497 | 3.9 | 1.2 | 128 | 32 | +96 | 67 of 140 | 103 of 140 | +172 | +79 |

### Effective charges: os-h2h-opp-779e261-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net -85) | 0 | 1 (net +0) | 2 (net +88) | 0 | 3 (net +8) | 1 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 9 | 2 (net +190) | 0 | 0 | 2 (net +360) | 2 (net +126) | 1 (net +0) | 2 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 8 | 0 | 0 | 4 (net +57) | 3 (net +20) | 0 | 1 (net +0) | 0 | 50% (4 of 8) |
| Mine | Empire of Man | 7 | 0 | 0 | 3 (net +203) | 2 (net +55) | 0 | 1 (net +400) | 1 | 50% (3 of 6) |
| Mine | Grand Cathay | 15 | 0 | 0 | 3 (net -27) | 4 (net +98) | 2 (net +30) | 4 (net +77) | 2 | 23% (3 of 13) |
| Mine | High Elf Realms | 16 | 2 (net +216) | 0 | 2 (net -30) | 3 (net +53) | 4 (net +32) | 5 (net +106) | 0 | 12% (2 of 16) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 3 (net +0) | 0 | 0% (0 of 6) |
| Mine | Lizardmen | 4 | 2 (net -382) | 0 | 0 | 0 | 0 | 2 (net +47) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |
| Mine | Skaven | 6 | 0 | 0 | 1 (net +145) | 1 (net +142) | 0 | 4 (net +16) | 0 | 17% (1 of 6) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +251) | 0 | 0 | 1 (net +75) | 2 (net +101) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 7 | 1 (net -40) | 1 (net +0) | 0 | 3 (net +263) | 0 | 2 (net +48) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 10 | 2 (net +54) | 1 (net +0) | 2 (net +14) | 1 (net -30) | 1 (net +160) | 1 (net +98) | 2 | 25% (2 of 8) |
| Opponent | Empire of Man | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +613) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 17 | 2 (net -350) | 0 | 4 (net +46) | 5 (net +126) | 2 (net +32) | 3 (net +81) | 1 | 25% (4 of 16) |
| Opponent | Lizardmen | 7 | 0 | 0 | 1 (net +590) | 2 (net +372) | 0 | 2 (net +81) | 2 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 13 | 0 | 1 (net +482) | 0 | 2 (net +92) | 0 | 1 (net +185) | 9 | 0% (0 of 4) |
| Opponent | Skaven | 15 | 6 (net -52) | 1 (net -41) | 1 (net +0) | 2 (net +217) | 0 | 5 (net +31) | 0 | 7% (1 of 15) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 1 (net +0) | 2 (net +16) | 1 (net +65) | 1 (net +302) | 1 (net +112) | 2 | 33% (2 of 6) |
| Opponent | Vampire Counts | 28 | 5 (net +70) | 0 | 6 (net +117) | 7 (net +1) | 7 (net +94) | 3 (net +170) | 0 | 21% (6 of 28) |
| Opponent | Warriors of Chaos | 27 | 3 (net +112) | 1 (net +0) | 3 (net +67) | 3 (net +239) | 5 (net +241) | 7 (net +232) | 5 | 14% (3 of 22) |
| Opponent | Wood Elf Realms | 23 | 3 (net -18) | 0 | 9 (net +183) | 5 (net +31) | 1 (net +189) | 5 (net +122) | 0 | 39% (9 of 23) |

### Charged fights, damage counted: os-h2h-opp-779e261-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 181 | 262 | +23 | 124 | 84 | +40 | +22.1 |
| Mine | 50-54% | 2 | 216 | 297 | +0 | 0 | 81 | -81 | -37.3 |
| Mine | Effective (55-75%) | 17 | 243 | 255 | +51 | 114 | 52 | +62 | +25.6 |
| Mine | 76-89% | 25 | 260 | 211 | +104 | 132 | 49 | +83 | +31.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 220 | 155 | +56 | 84 | 17 | +67 | +30.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 545 | 100 | +73 | 122 | 55 | +67 | +12.3 |
| Mine | No odds | 9 | 258 | 168 | +2 | 24 | 23 | +2 | +0.6 |
| Mine | All fights | 105 | 266 | 195 | +59 | 102 | 44 | +59 | +22.0 |
| Opponent | Long shot (under 50%) | 20 | 202 | 256 | -19 | 71 | 105 | -34 | -16.9 |
| Opponent | 50-54% | 4 | 264 | 171 | +110 | 153 | 10 | +143 | +54.2 |
| Opponent | Effective (55-75%) | 26 | 322 | 263 | +129 | 171 | 45 | +126 | +39.1 |
| Opponent | 76-89% | 27 | 276 | 228 | +109 | 132 | 41 | +91 | +33.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 331 | 196 | +150 | 208 | 46 | +162 | +48.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 489 | 104 | +151 | 174 | 3 | +171 | +35.0 |
| Opponent | No odds | 19 | 240 | 192 | +20 | 95 | 74 | +21 | +8.7 |
| Opponent | All fights | 140 | 304 | 212 | +96 | 146 | 51 | +95 | +31.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-opp-779e261-p4 | move | 397 | 99 (25%) | 76 (19%) | 62 (16%) | 236 (59%) |
| os-h2h-opp-779e261-p4 | objective | 386 | 60 (16%) | 48 (12%) | 54 (14%) | 272 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

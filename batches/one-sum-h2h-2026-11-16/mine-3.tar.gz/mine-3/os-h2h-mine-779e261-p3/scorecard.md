# Doctrine scorecard: os-h2h-mine-779e261-p3

### Scorecard: os-h2h-mine-779e261-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 2 | 3 | 2 | 5 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 770 |
| L0327 | 3 | 1 | Opponent | no | 4 | 3 | 1 | 4 | 2 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 659 |
| L0429 | 3 | 1 | Mine | yes | 10 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 8 | 4 | 0 | 1 | 0 | 0 | 0 | 560 |
| L0516 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 144 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 717 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 1 | 6 | 2 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 885 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 549 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 20 | 3 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 4 | 0 | 0 | 0 | 190 |
| L1422 | 6 | 1 | Mine | no | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 2 | 1 | 4 | 0 | 0 | 0 | 140 |
| L1633 | 1 | 1 | Mine | no | 9 | 2 | 3 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 380 |
| L1731 | 3 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 2 | 3 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 2 | 0 | 2 | 0 | 0 | 255 |
| L1932 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 3 | 0 | 5 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 3 | 1 | 8 | 0 | 0 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 4 | 3 | 4 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 28% | 4.0 | 2.6 | 2.7 | 1.0 | 0.3 | 0.0 | 0.0 | 302.4 |
| **Average** | | | Opponent | 22% | 2.8 | 2.4 | 2.7 | 1.9 | 0.4 | 0.0 | 0.0 | 163.2 |

### KPIs: os-h2h-mine-779e261-p3

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 170) | 7% (12 of 174) | 17% (57 of 344) |
| Winner chose to follow up after the loser gave ground |  | 98% (44 of 45); on the table 98% | 97% (67 of 69); on the table 99% | 97% (111 of 114); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 88% (7 of 8); on the table 88% | 93% (14 of 15); on the table 93% |
| Winner chose to pursue after the loser fled |  | 78% (21 of 27); on the table 81% | 77% (24 of 31); on the table 87% | 78% (45 of 58); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 91% (72 of 79); on the table 92% | 91% (98 of 108); on the table 94% | 91% (170 of 187); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 34% (117 of 342) | 40% (76 of 192) | 36% (193 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (117 of 242) | 52% (76 of 147) | 50% (193 of 389) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (10 of 19) | 49% (31 of 63) | 50% (41 of 82) |
| Points that never fought | lower | 42% (28652 of 68801) | 45% (32330 of 71990) | 43% (60982 of 140791) |
|   infantry points that never fought | lower | 53% (7562 of 14174) | 65% (9208 of 14220) | 59% (16770 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (150 of 272) | 60% (172 of 285) | 58% (322 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.6 uses a game | 96% (23 of 24); 2.2 uses a game | 92% (45 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 0.3 uses a game | 33% (2 of 6); 0.1 uses a game | 25% (5 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 53% (18 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29986 of 59391) | 55% (35294 of 64043) | 53% (65280 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (27%) | 0.8 (23%) | 2.4 (26%) |
| MARCHED: its unit marched | 1.2 (19%) | 0.8 (26%) | 2.0 (21%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (6%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.6 (20%) | 2.0 (21%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.8 (13%) | 0.6 (18%) | 1.4 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.0 (0%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.1 | 2.0 | 5.4 | 1.0 | 1.2 |
| not cast | 4.2 | 1.5 | 4.2 | 9.5 | 2.3 | 19.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (49%) | 0.4 (9%) | 2.4 (26%) | 0.4 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (21%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (8%) | 0.8 (18%) | 2.0 (21%) | 0.3 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (0%) | 0.2 (6%) | 0.2 (3%) | 0.2 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (2%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.2 (28%) | 0.2 (15%) | 0.9 (21%) | 1.4 (15%) | 0.4 (15%) | 2.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (6%) | 0.3 (7%) | 0.4 (4%) | 0.1 (4%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.2 (4%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (8%) | 0.0 (0%) | 0.2 (2%) | 0.5 (23%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (55%) | 0.2 (13%) | 1.4 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 69% (24 of 35) | 57% (13 of 23) | 64% (37 of 58) |
| the unit moved after it | 58% (14 of 24) | 85% (11 of 13) | 68% (25 of 37) |
| it charged on its next turn | 4% (1 of 24) | 15% (2 of 13) | 8% (3 of 37) |
| the enemy charged it first | 8% (2 of 24) | 15% (2 of 13) | 11% (4 of 37) |
| it fought by the end of its next turn | 4% (1 of 24) | 8% (1 of 13) | 5% (2 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 33% (8 of 24) | 8% (1 of 13) | 24% (9 of 37) |
| none of these (no charge, no fight, no charge escaped) | 50% (12 of 24) | 62% (8 of 13) | 54% (20 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (536 of 804) | 57% (354 of 617) | 63% (890 of 1421) |
|   cavalry | 72% (46 of 64) | 63% (74 of 118) | 66% (120 of 182) |
|   character | 66% (71 of 107) | 25% (30 of 122) | 44% (101 of 229) |
|   chariot | 48% (46 of 96) | 68% (17 of 25) | 52% (63 of 121) |
|   infantry | 55% (121 of 219) | 60% (159 of 263) | 58% (280 of 482) |
|   monster | 46% (19 of 41) | 100% (4 of 4) | 51% (23 of 45) |
|   war machine | 84% (233 of 277) | 82% (70 of 85) | 84% (303 of 362) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (30%) | 1.6 (22%) | 3.9 (26%) |
| CHARGED: it charged | 1.0 (13%) | 1.6 (21%) | 2.5 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.6 (8%) | 1.1 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.2 (16%) | 0.8 (11%) | 2.0 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.4 (6%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (18%) | 1.7 (23%) | 3.1 (21%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (2%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.4 (6%) | 0.3 (4%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.4 | 78% | 6.6 pts | 35 pts |
| character | 3.3 | 1.3 | 73% | 9.1 pts | 30 pts |
| chariot | 1.8 | 0.6 | 71% | 11.4 pts | 20 pts |
| infantry | 12.1 | 3.7 | 77% | 8.0 pts | 96 pts |
| monster | 0.8 | 0.2 | 82% | 8.0 pts | 6 pts |
| war machine | 8.8 | 7.2 | 63% | 22.3 pts | 196 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.2 | 4.6 |
| Charges that made contact a game | 3.0 | 3.3 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.85 declared, 0.67 contact (27 units) | 0.74 declared, 0.47 contact (19 units) | 0.80 declared, 0.59 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.25 contact (4 units) | 0.75 declared, 0.62 contact (8 units) | 0.92 declared, 0.83 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.39 contact (218 units) | 0.63 declared, 0.39 contact (264 units) | 0.59 declared, 0.39 contact (482 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (37 of 77) | 53% (8 of 15) | 40% (4 of 10) | 48% (49 of 102) |
| Character in a unit | 86% (31 of 36) | 72% (13 of 18) | 43% (3 of 7) | 77% (47 of 61) |
| Character on its own | 80% (33 of 41) | 50% (19 of 38) | 37% (25 of 68) | 52% (77 of 147) |
| Chariot | 82% (9 of 11) | 58% (7 of 12) | - | 70% (16 of 23) |
| Infantry | 67% (47 of 70) | 48% (20 of 42) | 40% (2 of 5) | 59% (69 of 117) |
| Monster | 41% (14 of 34) | 71% (5 of 7) | - | 46% (19 of 41) |
| Monstrous | 70% (7 of 10) | 45% (5 of 11) | - | 57% (12 of 21) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (8 of 8); on the table 100% | 32% (31 of 96) | 41% | 59% (13 of 22) | 100% (6 of 6); 3.8 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (12 of 12); on the table 100% | 61% (22 of 36) | 54% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 80% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (3 of 4); on the table 100% | 53% (16 of 30) | 48% | 64% (38 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 96% (23 of 24); on the table 100% | 39% (74 of 192) | 60% | 55% (41 of 74) | 94% (17 of 18); 6.1 uses a game | 50% (2 of 4); 1.2 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 83% (15 of 18); on the table 83% | 24% (10 of 42) | 38% | 56% (30 of 54) | 89% (8 of 9); 3.9 uses a game | 17% (2 of 12); 0.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 75% (3 of 4); on the table 75% | - | 52% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 24% | 14% (1 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 19% | 57% (4 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 71% (5 of 7); on the table 71% | 8% (1 of 12) | 1% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 100% (7 of 7); on the table 100% | 33% (4 of 12) | 70% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (7 of 7); on the table 100% | 0% (0 of 6) | 36% | 38% (10 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (30 of 32); on the table 94% | 33% (18 of 54) | 26% | 59% (27 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 91% (41 of 45); on the table 93% | 33% (10 of 30) | 37% | 58% (56 of 96) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 79% (11 of 14); on the table 93% | 42% (5 of 12) | 47% | 61% (38 of 62) | 91% (10 of 11); 5.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (34) | 34% (25) | 40% (59) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.39 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.17 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.25 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.11 | 1.42 | 3.53 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.75 | 0.78 | 1.53 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 6.44 | 12.03 |

### Quality by phase: os-h2h-mine-779e261-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (70 of 135) | 43% (63 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (187 of 412) | 47% (97 of 208) |
| Strategy | Close-in objectives charged next turn | 13% (26 of 194) | 19% (47 of 244) |
| Strategy | Support requests answered (helper made contact too) | 38% (5 of 13) | 28% (8 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (4 of 10) | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 40% (17 of 43) | 36% (16 of 44) |
| Strategy | Lone characters that fought | 70% (64 of 92) | 71% (64 of 90) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 302.4 | 163.2 |
| Movement | Fights charged into per game | 2.9 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 92, net +6 | 15 of 84, net +22 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 92, net +46 | 12 of 84, net +243 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 92, net +85 | 3 of 84, net +93 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 92, net +94 | 29 of 84, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (132 of 333) | 51% (174 of 338) |
| Shooting | Points destroyed by shooting units | 72.3 | 32.1 |
| Shooting | War machine shots | 6.5 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (109 of 233) | 42% (35 of 83) |
| Shooting | Points destroyed by war machines | 71.7 | 15.7 |
| Magic | Magic missiles cast | 2.3 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (37 of 84) | 32% (17 of 53) |
| Magic | Wounds caused by magic missiles | 4.6 | 2.4 |
| Magic | Wounds caused by other spells | 1.1 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 88.9 | 27.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.3 / 0.5 / 0.1 | 2.1 / 0.2 / 0.2 / 0.5 |
| Combat | Points destroyed in combat | 316.1 | 310.1 |
| Combat | Points run down | 55.6 | 139.9 |
| Combat | Net points per charged fight, damage counted | +64 | +87 |
| Combat | Net per 100 charger points, damage counted | +23.1 | +33.2 |
| Combat | First round won (charged fights) | 72% | 74% |
| Combat | Net points per charged fight | +66 | +81 |
| Combat | Net points per supported fight / lone fight | +30 / +70 | -18 / +92 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 103 | 49 of 101 |
| Game | Points lost | 674.6 | 693.5 |
| Game | VP from objectives | 571.1 | 547.8 |
| Game | Lone holders (player turns) | 4.0 | 2.8 |

- Mine won / drew / lost: 15 / 10 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +38 VP
- The side that went first won 13 of 26 games with a winner
- Points traded per game (both sides' losses): 1368
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-mine-779e261-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.4 | -164.3 | 198.7 | 105.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 20.7 | 0.2 | +0.0 | 0.0 | 8.1 |
| BACKUP TARGETS | 0.5 | +4.0 | 0.0 | 0.0 | 0.9 | +6.2 | 0.0 | 16.3 |
| BEST FACING | 0.7 | +12.4 | 0.0 | 37.3 | 0.5 | +12.4 | 0.0 | 13.3 |
| BEST FIRST | 1.6 | +71.6 | 40.9 | 56.3 | 3.9 | +145.7 | 141.2 | 56.2 |
| BEST OVERALL | 0.4 | +15.2 | 0.0 | 15.4 | 0.5 | +28.4 | 0.0 | 36.1 |
| BEST PREY | 0.5 | +52.6 | 8.1 | 22.1 | 0.9 | +29.5 | 19.1 | 21.3 |
| BEST PRIZE | 0.1 | +3.2 | 4.5 | 0.0 | 0.1 | +1.7 | 3.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 10.6 | 0.2 | -1.4 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +4.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 6.5 | 3.2 | 0.1 | +0.0 | 9.7 | 0.0 |
| BLOCKED WHEEL | 0.2 | +4.8 | 0.0 | 7.8 | 0.5 | +7.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.4 | -22.7 | 26.4 | 27.8 | 0.3 | -34.1 | 68.3 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 33.8 | 3.3 | 0.3 | +0.0 | 25.9 | 3.5 |
| CANNON PLANNED TARGET | 5.7 | +179.3 | 381.4 | 78.2 | 1.3 | +78.1 | 55.3 | 36.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 1.2 | 0.0 | 0.0 | -1.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 13.6 | 13.7 | 0.2 | -2.7 | 40.9 | 6.4 |
| CAST JOB | 1.1 | +45.7 | 80.7 | 12.9 | 0.7 | +22.8 | 60.8 | 31.6 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +22.1 | 27.3 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 56.8 | 0.4 | +0.0 | 0.0 | 22.9 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.8 | +50.5 | 0.0 | 25.4 | - | - | - | - |
| CHAFF PASSED | 0.3 | -0.2 | 0.0 | 1.8 | 0.2 | -0.8 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 297.4 | 71.0 | 1.9 | +0.0 | 240.9 | 60.3 |
| CHARGE NOW WEIGHED | 0.7 | -79.8 | 6.2 | 41.9 | 0.9 | -65.6 | 45.5 | 21.3 |
| CHARGER SLAIN LOST | 0.4 | -22.7 | 26.0 | 27.8 | 0.6 | -15.2 | 58.6 | 6.4 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 11.1 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 8.5 | 1.2 |
| COMBAT PIVOT | 0.5 | +0.0 | 9.0 | 31.1 | 0.5 | +0.0 | 28.4 | 71.9 |
| CONVEYANCE SEARCH | 0.7 | +98.7 | 30.4 | 56.8 | 0.5 | +33.6 | 34.1 | 32.8 |
| COUNTER-CHARGE COVER | - | - | - | - | 7.4 | +634.0 | 0.0 | 200.8 |
| COVER ONCE | 8.8 | -561.3 | 0.0 | 208.3 | - | - | - | - |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +8.9 | 22.3 | 0.0 | 0.0 | +0.7 | 13.9 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +2.0 | 13.0 | 6.8 | 0.1 | +1.8 | 11.1 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +149.0 | 0.0 | 85.8 | 1.4 | +118.5 | 0.0 | 57.1 |
| FALLBACK BY WORTH | 4.7 | +39.8 | 0.0 | 46.3 | 5.9 | +50.0 | 0.0 | 58.8 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +7.9 | 2.9 | 8.2 | 0.1 | +0.5 | 0.0 | 2.2 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 215.3 | 6.1 | +0.0 | 0.0 | 113.9 |
| FOCUS FIRE | - | - | - | - | 0.1 | +2.4 | 7.1 | 6.5 |
| FOLLOW UP WEIGHED | 0.8 | +165.7 | 0.0 | 25.6 | 1.0 | +128.1 | 0.0 | 25.4 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.7 | 0.0 | 0.9 | 0.1 | +2.0 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.1 | 25.4 | 0.0 | 0.0 | -0.6 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 0.0 | 1.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 33.1 | 5.2 |
| HELPER UNSEEN | 0.3 | +0.0 | 24.6 | 10.8 | 0.5 | +0.0 | 48.8 | 36.1 |
| HILL BY ITS CHANCE | 0.3 | -35.3 | 0.0 | 0.0 | 0.6 | -60.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.2 | -141.2 | 459.6 | 186.4 | 8.3 | -195.3 | 557.3 | 173.3 |
| HORN WORTH | - | - | - | - | 0.1 | +1.4 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.2 | +12.9 | 4.6 | 0.0 | 0.1 | +3.8 | 0.0 | 7.8 |
| HUNT DROPPED | 0.1 | +0.0 | 4.6 | 2.4 | 0.1 | +0.0 | 0.0 | 7.8 |
| HUNT IN PAIRS | 0.3 | +12.8 | 0.0 | 5.4 | 0.8 | +41.3 | 0.0 | 36.3 |
| HUNT KEPT | 0.1 | +6.0 | 0.0 | 1.5 | 0.0 | +1.1 | 0.0 | 2.9 |
| HUNT RESULT | 0.2 | +5.8 | 4.6 | 3.9 | 0.2 | +20.2 | 0.0 | 11.4 |
| HUNT THE GUNS | 0.2 | +62.8 | 4.6 | 0.0 | 0.2 | +51.8 | 8.2 | 6.6 |
| IDLE COST | 15.0 | -256.8 | 0.0 | 254.4 | - | - | - | - |
| INVITES THE FIGHT | 1.2 | +9.1 | 48.1 | 6.5 | 1.3 | +21.0 | 44.0 | 24.5 |
| JOINT CHARGE PLAN | 0.1 | +1.9 | 0.0 | 0.0 | 0.3 | +9.3 | 25.7 | 7.7 |
| JOINT KNOWS CHALLENGE | 0.0 | -1.8 | 7.0 | 5.1 | 0.1 | -2.1 | 11.2 | 9.7 |
| KEEP FALLS | 0.2 | +4.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 1.8 | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +48.3 | 117.0 | 43.2 | 2.1 | +63.3 | 209.5 | 17.4 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +78.1 | 148.5 | 43.6 | 1.4 | +75.9 | 141.6 | 21.4 |
| KILLS COUNT NEXT TURN | 5.2 | +175.1 | 173.8 | 171.5 | 7.5 | +239.5 | 324.4 | 122.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +20.1 | 20.6 | 22.2 | 0.2 | +2.6 | 16.3 | 1.4 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +6.2 | 38.0 | 0.0 | 0.4 | -3.1 | 36.6 | 9.6 |
| LOST CHARGE | 2.8 | -35.8 | 125.3 | 87.4 | 2.6 | -38.1 | 79.6 | 38.8 |
| LURE BY WHAT IT DRAWS | 0.1 | -17.5 | 0.0 | 11.8 | 0.1 | -5.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +150.6 | 43.5 | 39.9 | 1.1 | +71.9 | 82.1 | 22.8 |
| MANOEUVRE | 0.3 | +8.9 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +23.2 | 0.0 | 20.3 | 0.6 | +37.0 | 0.0 | 16.6 |
| MARCH ODDS | 0.4 | +23.8 | 20.6 | 0.0 | 0.2 | +8.9 | 15.3 | 0.0 |
| MARCH OVER CASTS | 0.4 | +42.4 | 0.0 | 25.9 | 0.5 | +28.2 | 0.0 | 14.1 |
| MAX FOR POSITIONING | 6.7 | +98.7 | 0.0 | 146.3 | 4.6 | +206.8 | 0.0 | 121.2 |
| MISSILES IN THE MOVE | 4.2 | +164.5 | 0.0 | 76.7 | 4.2 | +84.5 | 0.0 | 86.8 |
| MISSILES NEXT TURN | 5.1 | +96.8 | 0.0 | 116.6 | 5.1 | +60.8 | 0.0 | 100.9 |
| MODEL FACING | 0.1 | +45.1 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +17.8 | 0.0 | 0.0 | 0.5 | +16.5 | 0.0 | 31.5 |
| MOVE SPELL IN RANGE | 0.1 | +3.9 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -23.7 | 8.0 | 46.1 | 0.1 | -2.7 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 13.9 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.7 | +347.7 | 115.0 | 126.0 | 4.9 | +380.9 | 242.8 | 109.1 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +3.8 | 0.0 | 5.7 | 0.1 | +9.0 | 3.6 | 0.0 |
| NOT NEEDED | 0.1 | -2.4 | 14.1 | 4.5 | 0.3 | -11.5 | 53.3 | 3.2 |
| NOT TURNED | 5.6 | +105.2 | 0.0 | 160.1 | 6.4 | +37.3 | 0.0 | 91.5 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 32.4 | 1.0 | -1.1 | 0.0 | 11.0 |
| OFF BEST | 15.8 | -682.1 | 25.8 | 308.9 | 14.3 | -818.3 | 20.3 | 224.9 |
| ONE FIGHT FORMULA | 9.1 | -157.8 | 43.6 | 201.6 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.8 | -100.0 | 0.0 | 31.1 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.3 | 14.6 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +18.8 | 9.9 | 0.0 | 0.1 | +5.9 | 9.6 | 0.0 |
| OVERRUNS AWAY | 0.5 | +12.4 | 62.6 | 5.8 | 0.3 | +3.7 | 38.2 | 10.7 |
| PATHS CROSS | 1.9 | +127.3 | 0.0 | 6.6 | 2.6 | +145.8 | 0.0 | 34.6 |
| PERIAPT WORTH | 0.0 | +2.9 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | -2.4 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +1369.9 | 1600.7 | 909.7 | 37.7 | +1220.0 | 1575.5 | 974.6 |
| PURSUES BIG PREY | 0.1 | -4.5 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +5.6 | 0.0 | 9.4 | 1.8 | +28.5 | 0.0 | 56.4 |
| RANDOM MOVER NO PROMISE | 0.1 | -11.2 | 0.0 | 4.7 | 0.5 | -36.2 | 8.4 | 11.7 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -10.6 | 0.0 | 12.8 | 0.6 | -20.7 | 0.0 | 12.4 |
| REDIRECT COUNTER | 1.7 | +105.0 | 0.0 | 42.2 | 4.1 | +380.5 | 0.0 | 58.4 |
| REDIRECT WEIGHED | 0.3 | +6.8 | 4.5 | 1.7 | 0.5 | +4.9 | 8.2 | 5.2 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 18.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +14.0 | 0.0 | 1.8 | 1.0 | +46.3 | 0.0 | 16.0 |
| RESTRAINS TO SHOOT | 0.1 | +7.9 | 0.0 | 6.6 | 0.0 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +87.7 | 200.7 | 92.9 | 2.3 | +52.0 | 269.5 | 51.6 |
| RISK ONCE | 4.4 | +105.6 | 26.4 | 127.9 | - | - | - | - |
| SAFE SURE CHARGE | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.8 | +45.5 | 0.0 | 27.5 | 0.8 | +58.4 | 0.0 | 41.7 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | +1.0 | 0.0 | 0.9 | 0.4 | -23.3 | 0.0 | 2.8 |
| SEARCH SPOT | 2.1 | +80.9 | 0.0 | 26.7 | 3.0 | +130.6 | 0.0 | 55.9 |
| SECOND HUNTER | 0.1 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +80.2 | 0.0 | 29.1 | 0.1 | +43.5 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.7 | +188.9 | 43.5 | 46.8 | 2.4 | +189.7 | 125.6 | 28.9 |
| SET-UP ANY TARGET | 0.3 | +72.4 | 8.2 | 31.7 | 0.2 | +20.6 | 11.1 | 16.4 |
| SET-UP MISSED | 0.0 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +33.0 | 63.2 | 5.1 | 1.0 | +20.5 | 30.6 | 17.9 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.4 | +0.0 | 42.9 | 0.0 | 0.2 | +0.0 | 35.1 | 3.5 |
| SHOTS IN THE MOVE | 14.4 | +563.4 | 0.0 | 205.7 | 9.2 | +293.9 | 0.0 | 158.4 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +120.2 | 22.1 | 45.6 | 0.2 | +28.4 | 11.1 | 16.4 |
| SPELL WORTH | 1.5 | +16.9 | 42.6 | 62.2 | 2.2 | +38.2 | 112.5 | 105.2 |
| SPELLS IN THE FIGHT | 0.5 | +0.9 | 55.6 | 15.1 | 0.6 | -3.9 | 79.8 | 0.0 |
| STABLE ROLE | 11.3 | +0.0 | 346.4 | 167.3 | 8.1 | +0.0 | 345.6 | 136.2 |
| STANDS TO CAST | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 2.7 |
| STOPS | 0.1 | +2.0 | 0.0 | 1.5 | 0.1 | +3.2 | 8.2 | 1.7 |
| STOPS SHORT OF THE FLANK | 0.4 | +14.5 | 0.0 | 0.0 | 0.3 | +18.6 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 5.9 | -51.7 | 365.3 | 113.9 | 5.9 | -42.1 | 341.6 | 128.3 |
| SUPPORTS | 3.9 | +57.2 | 231.3 | 42.9 | 4.1 | +44.8 | 147.6 | 58.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.7 | 11.5 | 0.0 | 0.1 | -2.0 | 4.7 | 1.9 |
| SURE REACH TOGETHER | 0.8 | +6.4 | 0.0 | 26.6 | 1.0 | -5.2 | 25.4 | 15.2 |
| THROUGH LINE OF FIRE | 0.6 | +29.2 | 0.0 | 7.8 | 0.2 | +11.7 | 0.0 | 6.2 |
| TURN WORTH | 0.3 | -18.3 | 21.9 | 6.8 | 0.2 | -16.5 | 24.0 | 5.7 |
| TWO OR MORE ARRIVE | 0.4 | +2.9 | 7.3 | 15.4 | 0.6 | +2.9 | 22.2 | 0.0 |
| WAIT AFTER COSTS | 7.0 | -325.6 | 258.5 | 174.5 | 7.8 | -373.0 | 361.5 | 150.1 |
| WALKS TO THE FIGHT | 1.6 | +14.5 | 70.9 | 20.2 | 0.7 | +9.8 | 40.2 | 3.3 |
| WAR ENGINE CHARGES | 0.2 | +18.3 | 15.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 72.4 | 15.8 | 0.2 | +0.0 | 2.4 | 5.8 |
| WEARS DOWN | 1.0 | +58.8 | 101.1 | 22.8 | 1.1 | +48.6 | 142.9 | 53.1 |
| WHO HITS BACK | 0.1 | +8.7 | 0.0 | 0.0 | 0.1 | +5.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +11.5 | 29.0 | 8.9 | 0.4 | +25.3 | 47.3 | 1.7 |
| WHOLE FIGHT GAIN | 0.1 | +6.8 | 19.0 | 0.0 | 0.7 | +52.8 | 84.4 | 7.9 |
| WIDER SPREAD | 2.4 | -6.8 | 238.9 | 68.8 | 2.5 | -6.1 | 288.0 | 25.2 |

### Rule changes: os-h2h-mine-779e261-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1083 | 1083 | 1083 | 30.08 | -54014 | -49.9 |
| BEST FIRST | 198 | 198 | 198 | 5.50 | +7820 | +39.5 |
| SEARCH SPOT | 181 | 181 | 176 | 4.89 | +7613 | +43.3 |
| MOVE TO CHARGE | 310 | 310 | 173 | 4.81 | +10519 | +60.8 |
| PATHS CROSS | 159 | 159 | 159 | 4.42 | +9830 | +61.8 |
| KILLS COUNT NEXT TURN | 458 | 458 | 138 | 3.83 | +3526 | +25.6 |
| FACES THE THREAT | 127 | 127 | 127 | 3.53 | +9629 | +75.8 |
| SUPPORTS | 287 | 287 | 117 | 3.25 | +1204 | +10.3 |
| SHOTS IN THE MOVE | 848 | 596 | 78 | 2.17 | +1941 | +24.9 |
| FALLBACK BY WORTH | 381 | 381 | 74 | 2.06 | +3235 | +43.7 |
| COUNTER-CHARGE COVER | 268 | 146 | 72 | 2.00 | +4715 | +65.5 |
| MISSILES IN THE MOVE | 305 | 200 | 69 | 1.92 | +1772 | +25.7 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| WAIT AFTER COSTS | 533 | 533 | 67 | 1.86 | +1241 | +18.5 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +10574 | +162.7 |
| SET UP TOGETHER | 147 | 125 | 64 | 1.78 | +4628 | +72.3 |
| CHARGE NOW WEIGHED | 59 | 59 | 59 | 1.64 | +5508 | +93.3 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| SAFER THAN THE JOB | 55 | 55 | 55 | 1.53 | +3740 | +68.0 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +2170 | +42.6 |
| MAX FOR POSITIONING | 407 | 242 | 49 | 1.36 | +383 | +7.8 |
| REDIRECT COUNTER | 208 | 105 | 44 | 1.22 | +3697 | +84.0 |
| CANNON PLANNED TARGET | 254 | 254 | 43 | 1.19 | -793 | -18.4 |
| COVER ONCE | 316 | 181 | 43 | 1.19 | +671 | +15.6 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +892 | +21.2 |
| RANDOM MOVE BY FIGURES | 82 | 82 | 41 | 1.14 | +1228 | +30.0 |
| RISK BY ARC | 169 | 165 | 41 | 1.14 | +1072 | +26.1 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MARCH CHECK | 41 | 40 | 38 | 1.06 | +1949 | +51.3 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| COMBAT PIVOT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 79 | 79 | 35 | 0.97 | +599 | +17.1 |
| CAST JOB | 64 | 64 | 34 | 0.94 | +906 | +26.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| ADVANCE WORTH | 195 | 195 | 32 | 0.89 | +634 | +19.8 |
| BEST OVERALL | 32 | 32 | 32 | 0.89 | +1570 | +49.1 |
| CHARGE NOW FIRST | 161 | 161 | 32 | 0.89 | -1421 | -44.4 |
| KILLS COUNT | 110 | 108 | 32 | 0.89 | +1580 | +49.4 |
| MOVE AND CAST | 31 | 31 | 31 | 0.86 | +1236 | +39.9 |
| WALKS TO THE FIGHT | 82 | 82 | 30 | 0.83 | +298 | +9.9 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +1474 | +50.8 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +437 | +15.6 |
| MAKE SURE TOGETHER | 77 | 58 | 27 | 0.75 | +2279 | +84.4 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +968 | +35.9 |
| ONE FIGHT FORMULA | 329 | 207 | 26 | 0.72 | +119 | +4.6 |
| HONEST WORTH | 594 | 590 | 25 | 0.69 | +211 | +8.4 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1192 | +47.7 |
| KEEPS ITS TARGET | 134 | 130 | 24 | 0.67 | +454 | +18.9 |
| INVITES THE FIGHT | 91 | 91 | 23 | 0.64 | +163 | +7.1 |
| MARCH ODDS | 22 | 22 | 21 | 0.58 | +247 | +11.8 |
| IDLE COST | 540 | 300 | 20 | 0.56 | +234 | +11.7 |
| SHOT REPLANNED | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| CHAFF IN THE MOVE | 29 | 29 | 19 | 0.53 | +671 | +35.3 |
| RISK ONCE | 160 | 114 | 19 | 0.53 | +703 | +37.0 |
| BIG CHARACTER SAFETY | 18 | 18 | 18 | 0.50 | -54 | -3.0 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -38 | -2.1 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WHOLE FIGHT GAIN | 28 | 28 | 18 | 0.50 | +548 | +30.5 |
| BEST PREY | 53 | 53 | 15 | 0.42 | +607 | +40.5 |
| MANOEUVRE | 17 | 17 | 14 | 0.39 | +430 | +30.7 |
| MISSILES NEXT TURN | 367 | 230 | 14 | 0.39 | +11 | +0.8 |
| WAR ENGINE JOBS | 31 | 31 | 14 | 0.39 | -682 | -48.7 |
| WEARS DOWN | 76 | 73 | 14 | 0.39 | +487 | +34.8 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| CASTING BLOCK | 16 | 16 | 12 | 0.33 | +332 | +27.7 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +241 | +20.0 |
| LOST CHARGE | 194 | 194 | 10 | 0.28 | +260 | +26.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| HUNT IN PAIRS | 42 | 17 | 9 | 0.25 | +161 | +17.9 |
| OPENS UP | 9 | 9 | 9 | 0.25 | +475 | +52.7 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -134 | -14.8 |
| KEEP FALLS | 8 | 8 | 8 | 0.22 | +300 | +37.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -111 | -13.9 |
| SUPPORT NARROWED | 423 | 423 | 8 | 0.22 | -132 | -16.5 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 7 | 0.19 | -236 | -33.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| SPELLS IN THE FIGHT | 38 | 37 | 7 | 0.19 | +124 | +17.7 |
| SURE REACH TOGETHER | 63 | 48 | 7 | 0.19 | +146 | +20.8 |
| WHO HITS BACK | 7 | 7 | 7 | 0.19 | +259 | +37.0 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +302 | +50.3 |
| WHOLE FIGHT | 19 | 18 | 6 | 0.17 | +207 | +34.5 |
| DEFENSIVE FLOOR | 6 | 6 | 5 | 0.14 | +161 | +32.1 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +302 | +60.4 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +1623 | +324.6 |
| REFUSING RETIRES | 18 | 18 | 5 | 0.14 | -1 | -0.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| WIDER SPREAD | 177 | 170 | 5 | 0.14 | +25 | +4.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -16 | -4.0 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +88 | +22.0 |
| OVERRUNS AWAY | 29 | 28 | 4 | 0.11 | +121 | +30.3 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +86 | +21.5 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +62 | +20.5 |
| CARRIES OUT SET-UP | 9 | 9 | 3 | 0.08 | -98 | -32.7 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -57 | -18.9 |
| EDGE GIVE GROUND | 11 | 11 | 3 | 0.08 | +27 | +8.9 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +52 | +17.3 |
| HUNT ADVANCE | 13 | 13 | 3 | 0.08 | +150 | +50.2 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -162 | -54.0 |
| SAFE SURE CHARGE | 3 | 3 | 3 | 0.08 | -123 | -41.0 |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 3 | 0.08 | +148 | +49.5 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +6 | +1.9 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +98 | +32.6 |
| JOINT CHARGE PLAN | 16 | 16 | 2 | 0.06 | +44 | +22.1 |
| LONG SHOT | 29 | 28 | 2 | 0.06 | +88 | +44.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +206 | +102.8 |
| STOPS | 5 | 5 | 2 | 0.06 | +72 | +35.9 |
| BACKUP TARGETS | 49 | 23 | 1 | 0.03 | +3 | +2.9 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +146 | +145.8 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -58 | -58.3 |
| CHARGER SLAIN LOST | 34 | 33 | 1 | 0.03 | +8 | +8.1 |
| HILL BY ITS CHANCE | 33 | 33 | 1 | 0.03 | +11 | +11.2 |
| KEEPS ITS PREY | 4 | 4 | 1 | 0.03 | +8 | +8.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 99 | 44 | 1 | 0.03 | +95 | +95.3 |
| OPENS A LANE | 6 | 4 | 1 | 0.03 | +7 | +6.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +146 | +145.5 |
| REDIRECT BY WHAT IT STOPS | 41 | 41 | 1 | 0.03 | +17 | +17.2 |
| TWO OR MORE ARRIVE | 36 | 31 | 1 | 0.03 | +14 | +14.1 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 26 | 23 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 30 | 30 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 424 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 433 | 433 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 56 | not checked | - | - | - | - |
| PLAN RESULT | 2712 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 132 | not checked | - | - | - | - |
| STABLE ROLE | 699 | 695 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.33 | 12.53 | 51.1 |
| FALLBACK | gate | 0.69 | 0.61 | 44.0 |
| TURN GATE | gate | 0.36 | 0.78 | 32.0 |
| CHARGE NOW FIRST | rule | 0.53 | 0.33 | 45.8 |
| CANNON PLANNED TARGET | rule | 0.33 | 0.17 | 52.0 |
| WAR ENGINE JOBS | rule | 0.33 | 0.03 | 52.5 |
| CHAFF PASSED | rule | 0.11 | 0.14 | 4.2 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 60.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.14 | 14.8 |
| PATHS CROSS | rule | 0.06 | 0.17 | 27.5 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 13.9 |
| SUPPORT NARROWED | rule | 0.06 | 0.17 | 16.5 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.11 | 11.6 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.14 | 32.8 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 2.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 2.1 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 41.4 |
| BEST PRIZE | rule | 0.03 | 0.06 | 5.3 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 32.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 153.9 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 78.6 |
| PURSUES BIG PREY | rule | 0.08 | - | 54.0 |
| SAFE SURE CHARGE | rule | 0.03 | 0.06 | 41.0 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 13.7 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 10.7 |
| CATCH ODDS | rule | 0.06 | - | 28.1 |
| FACES THE THREAT | rule | 0.06 | - | 1.8 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.2 |
| MARCH ODDS | rule | 0.03 | 0.03 | 5.9 |
| NO REASON | gate | 0.06 | - | 106.0 |
| RULE SWITCHED OFF | gate | - | 0.06 | 2.3 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 18.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 6.2 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 58.3 |
| FALLBACK BY WORTH | rule | - | 0.03 | 2.4 |
| MOVE AND CAST | rule | - | 0.03 | 58.5 |

### Plans: os-h2h-mine-779e261-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.0 | 17% | 141 | 285 | 203% |
| Mine | charge | 3.1 | 55% | 209 | 313 | 150% |
| Mine | close in | 5.3 | 19% | 332 | 146 | 44% |
| Mine | hold | 4.9 | 43% | 319 | 0 | 0% |
| Mine | join | 0.4 | 81% | 15 | 0 | 0% |
| Mine | shoot | 9.2 | 59% | 195 | 626 | 321% |
| Mine | support | 4.7 | 90% | 45 | 0 | 0% |
| Opponent | advance | 12.7 | 14% | 353 | 336 | 95% |
| Opponent | charge | 3.6 | 60% | 293 | 415 | 142% |
| Opponent | close in | 6.8 | 20% | 385 | 156 | 41% |
| Opponent | hold | 4.1 | 29% | 274 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 21 | 0 | 0% |
| Opponent | shoot | 5.1 | 52% | 125 | 314 | 251% |
| Opponent | support | 4.8 | 86% | 35 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 0% | 17% | 0% | 2.0 | 377 | 35 | 17% | 16 |
| Opponent | 0.2 | 6 | 0 | 33% | 33% | 0% | 2.0 | 311 | 121 | 33% | 71 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 0 | 0% | 17% | 0% | 2.0 | 377 | 35 | 17% | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 506 | 431 | 100% | 145 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 272 | 98 | 33% | 56 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 271 | 0 | 0% | 66 |

### Battle groups: os-h2h-mine-779e261-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 28% | 71% | 12% | 0% | 20% | 0% | 0% | 60% | 20% |
| Opponent | COUNTER-CHARGE COVER | 7.4 | 18% | 76% | 12% | 33% | 35% | 5% | 9% | 51% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 20% | 79% | 24% | 0% | 23% | 0% | 0% | 73% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 72 (34) | 15 | 57 | 53 | 38% | 2.3 | 72 (21) | 0 (4) | 96 (9) | 107 (24) | 0 (10) |
| Mine | Character | 118 | 40 (118) | 40 | 0 | 34 | 19% | 2.3 | 54 (36) | 36 (59) | 46 (8) | 42 (58) | 47 (45) |
| Mine | Clean-up | 18 | 66 (18) | 34 | 31 | 41 | 28% | 2.9 | 42 (3) | 58 (13) | 220 (2) | 54 (12) | 83 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 43 (44) | 21 | 22 | 49 | 30% | 2.7 | 44 (22) | 35 (14) | 56 (8) | 39 (30) | 51 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 67% | 3.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 34 (52) | 22 | 12 | 29 | 21% | 2.7 | 15 (14) | 39 (35) | 49 (3) | 35 (36) | 30 (16) |
| Mine | Holder | 25 | 60 (25) | 20 | 41 | 26 | 40% | 3.2 | 0 (7) | 68 (14) | 129 (4) | 82 (12) | 39 (13) |
| Mine | Shooter | 37 | 74 (37) | 26 | 48 | 39 | 3% | 1.8 | 19 (6) | 90 (28) | 26 (3) | 95 (23) | 38 (14) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.5 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 39 (52) | 39 | 0 | 29 | 0% | 1.1 | 73 (13) | 29 (36) | 0 (3) | 89 (13) | 21 (39) |
| Mine | Wizard | 17 | 41 (17) | 41 | 0 | 46 | 6% | 2.1 | 0 (4) | 86 (8) | 53 (1) | 92 (7) | 7 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 60 (68) | 23 | 37 | 59 | 47% | 2.9 | 23 (29) | 115 (11) | 62 (28) | 69 (48) | 39 (20) |
| Opponent | Character | 102 | 42 (102) | 42 | 1 | 31 | 18% | 2.3 | 33 (40) | 55 (52) | 13 (5) | 47 (57) | 41 (40) |
| Opponent | Clean-up | 11 | 46 (11) | 15 | 32 | 29 | 45% | 3.0 | 28 (4) | 55 (6) | 56 (1) | 28 (6) | 63 (5) |
| Opponent | Fast | 1 | 217 (1) | 217 | 0 | 100 | 0% | 2.0 | - | 217 (1) | - | 217 (1) | - |
| Opponent | Fast Hammer | 60 | 49 (60) | 36 | 13 | 38 | 23% | 3.0 | 34 (30) | 35 (20) | 129 (10) | 42 (28) | 55 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.3 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 45 (50) | 34 | 11 | 42 | 34% | 2.8 | 9 (17) | 61 (30) | 6 (3) | 45 (30) | 46 (20) |
| Opponent | Holder | 40 | 71 (40) | 3 | 68 | 37 | 40% | 2.5 | 30 (9) | 78 (23) | 107 (8) | 99 (26) | 27 (14) |
| Opponent | Shooter | 27 | 45 (27) | 29 | 16 | 38 | 7% | 1.3 | 6 (6) | 44 (19) | 259 (2) | 42 (16) | 49 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 33 | 75% | 5.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 28 (17) | 28 | 0 | 56 | 0% | 1.4 | 75 (3) | 23 (10) | 12 (4) | 0 (3) | 32 (14) |
| Opponent | Wizard | 32 | 13 (32) | 13 | 0 | 27 | 22% | 2.1 | 9 (12) | 12 (11) | 0 (2) | 13 (14) | 0 (11) |

### Charged fights: os-h2h-mine-779e261-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 137 | 202 | 1.5 | 1.0 | 135 | 0 | +135 | 1 of 6 | 5 of 6 | - | +135 |
| Mine | Chaos Dwarfs | 4 | 298 | 579 | 4.0 | 1.1 | 145 | 19 | +125 | 8 of 16 | 13 of 16 | +0 | +134 |
| Mine | Dwarfen Mountain Holds | 3 | 383 | 13 | 1.3 | 1.2 | 10 | 0 | +10 | 0 of 4 | 2 of 4 | +0 | +13 |
| Mine | Empire of Man | 5 | 404 | 96 | 1.4 | 1.0 | 69 | 0 | +69 | 0 of 7 | 6 of 7 | - | +69 |
| Mine | Grand Cathay | 5 | 448 | 233 | 3.6 | 1.1 | 65 | 23 | +42 | 4 of 18 | 14 of 18 | +0 | +45 |
| Mine | High Elf Realms | 4 | 167 | 444 | 2.8 | 1.1 | 161 | 10 | +151 | 6 of 11 | 11 of 11 | +120 | +154 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 570 | 3.0 | 1.3 | 190 | 0 | +190 | 1 of 3 | 2 of 3 | +144 | +213 |
| Mine | Lizardmen | 1 | 116 | 286 | 2.0 | 1.5 | 143 | 92 | +51 | 0 of 2 | 2 of 2 | -14 | +116 |
| Mine | Ogre Kingdoms | 1 | 116 | 251 | 4.0 | 1.0 | 63 | 55 | +8 | 3 of 4 | 2 of 4 | - | +8 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 36 | 320 | 6.5 | 1.2 | 49 | 22 | +28 | 5 of 13 | 7 of 13 | +83 | +11 |
| Mine | Vampire Counts | 2 | 122 | 286 | 4.0 | 1.1 | 72 | 91 | -19 | 3 of 8 | 4 of 8 | -203 | +7 |
| Mine | Warriors of Chaos | 2 | 0 | 240 | 3.5 | 1.0 | 68 | 50 | +18 | 2 of 7 | 3 of 7 | - | +18 |
| **Mine** | all armies | 36 | 233 | 261 | 2.9 | 1.1 | 91 | 25 | +66 | 33 of 103 | 74 of 103 | +30 | +70 |
| Opponent | Empire of Man | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 179 | 407 | 3.0 | 1.0 | 136 | 0 | +136 | 2 of 9 | 8 of 9 | - | +136 |
| Opponent | High Elf Realms | 3 | 127 | 43 | 1.7 | 1.0 | 26 | 0 | +26 | 2 of 5 | 3 of 5 | - | +26 |
| Opponent | Kingdom of Bretonnia | 2 | 125 | 108 | 1.5 | 1.0 | 72 | 124 | -51 | 2 of 3 | 1 of 3 | - | -51 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 594 | 5.0 | 1.0 | 119 | 33 | +86 | 2 of 5 | 3 of 5 | - | +86 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 42 | 307 | 2.8 | 1.0 | 112 | 18 | +94 | 7 of 11 | 10 of 11 | - | +94 |
| Opponent | Vampire Counts | 6 | 0 | 521 | 3.5 | 1.2 | 149 | 53 | +96 | 13 of 21 | 15 of 21 | +19 | +120 |
| Opponent | Warriors of Chaos | 9 | 9 | 527 | 3.2 | 1.1 | 164 | 50 | +114 | 18 of 29 | 22 of 29 | -77 | +136 |
| Opponent | Wood Elf Realms | 6 | 150 | 190 | 2.8 | 1.1 | 67 | 54 | +12 | 3 of 17 | 12 of 17 | -22 | +17 |
| **Opponent** | all armies | 36 | 75 | 344 | 2.8 | 1.1 | 123 | 42 | +81 | 49 of 101 | 75 of 101 | -18 | +92 |

### Effective charges: os-h2h-mine-779e261-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 2 (net +82) | 0 | 0 | 3 (net +15) | 0 | 0 | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 16 | 2 (net +0) | 0 | 2 (net +0) | 5 (net +139) | 1 (net +85) | 3 (net +202) | 3 | 15% (2 of 13) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 2 (net +19) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +100) | 1 (net +72) | 2 (net +104) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 18 | 1 (net +0) | 2 (net +71) | 4 (net +0) | 4 (net +72) | 1 (net +80) | 6 (net +41) | 0 | 22% (4 of 18) |
| Mine | High Elf Realms | 11 | 0 | 1 (net +365) | 1 (net +599) | 4 (net +0) | 1 (net +55) | 4 (net +160) | 0 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +190) | 0 | 1 (net +144) | 0 | 0 | 1 (net +236) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 1 (net -14) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 4 | 1 (net +66) | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Skaven | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +0) | 1 (net +0) | 5 (net +25) | 3 (net +23) | 2 (net +110) | 1 (net -56) | 0 | 38% (5 of 13) |
| Mine | Vampire Counts | 8 | 3 (net -111) | 0 | 0 | 3 (net +27) | 0 | 2 (net +49) | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 7 | 1 (net +0) | 0 | 2 (net -44) | 0 | 0 | 1 (net +170) | 3 | 50% (2 of 4) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 9 | 0 | 1 (net +355) | 1 (net +0) | 4 (net +197) | 0 | 1 (net +77) | 2 | 14% (1 of 7) |
| Opponent | High Elf Realms | 5 | 1 (net +130) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net -107) | 1 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +199) | 0 | 2 (net +198) | 2 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net +240) | 0 | 2 (net +108) | 2 (net +62) | 0 | 6 (net +75) | 0 | 18% (2 of 11) |
| Opponent | Vampire Counts | 21 | 7 (net -48) | 0 | 2 (net +614) | 5 (net +110) | 1 (net +110) | 6 (net +76) | 0 | 10% (2 of 21) |
| Opponent | Warriors of Chaos | 29 | 4 (net +102) | 1 (net +255) | 5 (net +271) | 7 (net +75) | 1 (net +110) | 8 (net +54) | 3 | 19% (5 of 26) |
| Opponent | Wood Elf Realms | 17 | 1 (net -109) | 0 | 1 (net +116) | 3 (net +38) | 1 (net +60) | 2 (net -52) | 9 | 12% (1 of 8) |

### Charged fights, damage counted: os-h2h-mine-779e261-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 180 | 251 | +6 | 79 | 80 | -1 | -0.5 |
| Mine | 50-54% | 5 | 233 | 202 | +101 | 188 | 120 | +69 | +29.4 |
| Mine | Effective (55-75%) | 17 | 286 | 247 | +46 | 119 | 59 | +60 | +21.0 |
| Mine | 76-89% | 27 | 285 | 168 | +52 | 100 | 50 | +50 | +17.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 289 | 161 | +94 | 127 | 29 | +97 | +33.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 394 | 69 | +85 | 100 | 46 | +54 | +13.7 |
| Mine | No odds | 11 | 284 | 157 | +122 | 161 | 44 | +117 | +41.4 |
| Mine | All fights | 103 | 275 | 186 | +66 | 117 | 54 | +64 | +23.1 |
| Opponent | Long shot (under 50%) | 15 | 225 | 287 | +22 | 117 | 97 | +20 | +8.9 |
| Opponent | 50-54% | 2 | 252 | 288 | +305 | 305 | 0 | +305 | +121.0 |
| Opponent | Effective (55-75%) | 12 | 390 | 246 | +243 | 272 | 27 | +245 | +62.7 |
| Opponent | 76-89% | 23 | 259 | 217 | +100 | 143 | 31 | +112 | +43.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 299 | 185 | +55 | 128 | 61 | +67 | +22.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 278 | 77 | +93 | 93 | 0 | +93 | +33.5 |
| Opponent | No odds | 17 | 140 | 181 | +8 | 87 | 80 | +7 | +5.1 |
| Opponent | All fights | 101 | 261 | 213 | +81 | 143 | 56 | +87 | +33.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p3 | move | 404 | 76 (19%) | 51 (13%) | 57 (14%) | 271 (67%) |
| os-h2h-mine-779e261-p3 | objective | 438 | 72 (16%) | 47 (11%) | 48 (11%) | 318 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

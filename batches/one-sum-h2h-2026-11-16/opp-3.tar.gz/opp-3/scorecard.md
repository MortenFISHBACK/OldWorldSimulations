# Doctrine scorecard: os-h2h-opp-779e261-p3

### Scorecard: os-h2h-opp-779e261-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 15 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 1 | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 4 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 686 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | 5 | 0 | 0 | 0 | 0 | 0 | 1120 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 3 | 3 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 1 | 5 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 830 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 881 |
| L0831 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 3 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 745 |
| L0922 | 4 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 1 | 4 | 2 | 0 | 1 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 12 | 2 | 4 | 2 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 414 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 10 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 6 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 5 | 1 | 0 | 1 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 110 |
| L1633 | 1 | 1 | Mine | yes | 5 | 4 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 368 |
| L1731 | 3 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 135 |
| L1731 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 5 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 4 | 4 | 1 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | 5 | 1 | 6 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 60 |
| L2433 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 334 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 460 |
| L3133 | 1 | 1 | Opponent | no | 3 | 3 | 4 | 1 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 28% | 2.2 | 2.8 | 2.3 | 0.9 | 0.3 | 0.0 | 0.0 | 289.4 |
| **Average** | | | Opponent | 25% | 3.9 | 2.2 | 2.8 | 1.9 | 0.4 | 0.0 | 0.0 | 170.3 |

### KPIs: os-h2h-opp-779e261-p3

Rules off - Mine only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (43 of 167) | 13% (22 of 174) | 19% (65 of 341) |
| Winner chose to follow up after the loser gave ground |  | 98% (50 of 51); on the table 98% | 100% (30 of 30); on the table 100% | 99% (80 of 81); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 93% (14 of 15); on the table 93% | 88% (23 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 80% (20 of 25); on the table 80% | 70% (19 of 27); on the table 78% | 75% (39 of 52); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 91% (79 of 87); on the table 91% | 88% (63 of 72); on the table 90% | 89% (142 of 159); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 24% (83 of 342) | 45% (87 of 192) | 32% (170 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (83 of 218) | 55% (87 of 158) | 45% (170 of 376) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 70% (14 of 20) | 52% (27 of 52) | 57% (41 of 72) |
| Points that never fought | lower | 36% (24663 of 68801) | 44% (32010 of 71990) | 40% (56673 of 140791) |
|   infantry points that never fought | lower | 45% (6375 of 14174) | 62% (8819 of 14220) | 54% (15194 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (157 of 272) | 59% (167 of 285) | 58% (324 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.8 uses a game | 88% (21 of 24); 2.1 uses a game | 92% (45 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 53% (18 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32461 of 59391) | 51% (32694 of 64043) | 53% (65155 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (22%) | 1.0 (33%) | 2.5 (25%) |
| MARCHED: its unit marched | 1.8 (25%) | 0.6 (22%) | 2.5 (24%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (7%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.4 (20%) | 0.4 (14%) | 1.8 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.2 (17%) | 0.5 (18%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (10%) | 0.0 (0%) | 0.8 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.2 | 1.5 | 4.7 | 0.8 | 1.2 |
| not cast | 4.0 | 1.4 | 4.6 | 10.1 | 2.5 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.7 (46%) | 0.2 (5%) | 2.5 (25%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (24%) | 0.5 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (4%) | 0.6 (14%) | 1.8 (18%) | 0.3 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.0 (0%) | 0.3 (7%) | 0.2 (2%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.2 (30%) | 0.2 (17%) | 1.5 (33%) | 1.7 (17%) | 0.6 (25%) | 3.4 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (12%) | 0.1 (2%) | 0.8 (7%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (6%) | 0.1 (8%) | 0.0 (0%) | 0.1 (1%) | 0.7 (27%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (48%) | 0.2 (12%) | 1.8 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 56% (18 of 32) | 50% (7 of 14) | 54% (25 of 46) |
| the unit moved after it | 83% (15 of 18) | 71% (5 of 7) | 80% (20 of 25) |
| it charged on its next turn | 0% (0 of 18) | 14% (1 of 7) | 4% (1 of 25) |
| the enemy charged it first | 22% (4 of 18) | 29% (2 of 7) | 24% (6 of 25) |
| it fought by the end of its next turn | 17% (3 of 18) | 14% (1 of 7) | 16% (4 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (4 of 18) | 14% (1 of 7) | 20% (5 of 25) |
| none of these (no charge, no fight, no charge escaped) | 56% (10 of 18) | 43% (3 of 7) | 52% (13 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (491 of 754) | 56% (354 of 627) | 61% (845 of 1381) |
|   cavalry | 62% (33 of 53) | 54% (60 of 111) | 57% (93 of 164) |
|   character | 57% (57 of 100) | 22% (26 of 118) | 38% (83 of 218) |
|   chariot | 52% (47 of 90) | 62% (18 of 29) | 55% (65 of 119) |
|   infantry | 50% (100 of 202) | 64% (174 of 271) | 58% (274 of 473) |
|   monster | 41% (16 of 39) | 83% (5 of 6) | 47% (21 of 45) |
|   war machine | 88% (238 of 270) | 77% (71 of 92) | 85% (309 of 362) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (32%) | 1.7 (22%) | 4.0 (27%) |
| CHARGED: it charged | 1.0 (13%) | 1.5 (20%) | 2.5 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.4 (6%) | 1.1 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.0 (13%) | 1.2 (16%) | 2.2 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (6%) | 0.8 (11%) | 1.2 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 1.6 (21%) | 2.8 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (5%) | 0.2 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.9 | 81% | 6.0 pts | 24 pts |
| character | 2.7 | 1.0 | 78% | 5.6 pts | 15 pts |
| chariot | 1.8 | 1.2 | 60% | 20.2 pts | 37 pts |
| infantry | 11.8 | 4.3 | 75% | 9.3 pts | 110 pts |
| monster | 0.7 | 0.2 | 79% | 7.2 pts | 5 pts |
| war machine | 9.0 | 9.5 | 54% | 28.3 pts | 255 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 4.9 | 4.3 |
| Charges that made contact a game | 2.9 | 3.3 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.58 contact (26 units) | 0.50 declared, 0.38 contact (16 units) | 0.64 declared, 0.50 contact (42 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 1.00 declared, 0.80 contact (10 units) | 0.79 declared, 0.64 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.39 contact (224 units) | 0.60 declared, 0.39 contact (267 units) | 0.56 declared, 0.39 contact (491 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (44 of 77) | 53% (8 of 15) | 30% (3 of 10) | 54% (55 of 102) |
| Character in a unit | 79% (30 of 38) | 76% (13 of 17) | 50% (3 of 6) | 75% (46 of 61) |
| Character on its own | 77% (30 of 39) | 44% (17 of 39) | 29% (20 of 69) | 46% (67 of 147) |
| Chariot | 73% (8 of 11) | 83% (10 of 12) | - | 78% (18 of 23) |
| Infantry | 61% (43 of 70) | 60% (25 of 42) | 40% (2 of 5) | 60% (70 of 117) |
| Monster | 65% (22 of 34) | 43% (3 of 7) | - | 61% (25 of 41) |
| Monstrous | 80% (8 of 10) | 64% (7 of 11) | - | 71% (15 of 21) |
| War Machines | 60% (26 of 43) | 100% (2 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 20% (19 of 96) | 39% | 73% (16 of 22) | 100% (6 of 6); 4.0 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 39% (14 of 36) | 52% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (4 of 6); on the table 67% | - | 51% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 43% (13 of 30) | 62% | 68% (40 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 94% (16 of 17); on the table 94% | 39% (74 of 192) | 53% | 53% (39 of 74) | 89% (16 of 18); 5.8 uses a game | 0% (0 of 4); 0.0 uses a game | 62% (5 of 8); 0.6 uses a game |
| High Elf Realms | 7 | 83% (10 of 12); on the table 83% | 21% (9 of 42) | 27% | 56% (30 of 54) | 89% (8 of 9); 4.0 uses a game | 42% (5 of 12); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (8 of 8); on the table 100% | - | 43% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 62% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (8 of 8); on the table 100% | 0% (0 of 6) | 15% | 43% (3 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 7% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 83% (5 of 6); on the table 100% | 0% (0 of 12) | 69% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 95% (18 of 19); on the table 95% | 0% (0 of 6) | 24% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 80% (16 of 20); on the table 80% | 44% (24 of 54) | 34% | 41% (19 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 79% (19 of 24); on the table 83% | 43% (13 of 30) | 35% | 62% (60 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (8 of 8); on the table 100% | 8% (1 of 12) | 40% | 68% (42 of 62) | 91% (10 of 11); 5.2 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-opp-779e261-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (33) | 51% (34) | 49% (67) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.58 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.19 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.39 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.47 | 0.97 | 3.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.78 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.97 | 5.31 | 11.28 |

### Quality by phase: os-h2h-opp-779e261-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 53% (62 of 116) | 45% (69 of 153) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (167 of 358) | 47% (118 of 250) |
| Strategy | Close-in objectives charged next turn | 19% (25 of 134) | 14% (34 of 246) |
| Strategy | Support requests answered (helper made contact too) | 45% (5 of 11) | 33% (7 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (3 of 8) | 44% (4 of 9) |
| Strategy | Joined characters whose unit fought | 44% (19 of 43) | 33% (15 of 46) |
| Strategy | Lone characters that fought | 76% (70 of 92) | 70% (62 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 0.9 | 1.9 |
| Movement | Points that never moved of their own | 289.4 | 170.3 |
| Movement | Fights charged into per game | 2.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 86, net +54 | 18 of 87, net +107 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 86, net +2 | 14 of 87, net +266 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 86, net +80 | 8 of 87, net +53 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 86, net +143 | 27 of 87, net +139 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.5 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (100 of 271) | 44% (147 of 336) |
| Shooting | Points destroyed by shooting units | 45.3 | 31.2 |
| Shooting | War machine shots | 6.6 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (129 of 238) | 45% (39 of 87) |
| Shooting | Points destroyed by war machines | 75.4 | 14.3 |
| Magic | Magic missiles cast | 1.6 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (21 of 59) | 27% (16 of 59) |
| Magic | Wounds caused by magic missiles | 3.1 | 3.8 |
| Magic | Wounds caused by other spells | 1.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 49.1 | 57.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.2 / 0.5 / 0.1 | 2.2 / 0.3 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 335.8 | 405.2 |
| Combat | Points run down | 65.2 | 146.9 |
| Combat | Net points per charged fight, damage counted | +88 | +150 |
| Combat | Net per 100 charger points, damage counted | +32.9 | +52.6 |
| Combat | First round won (charged fights) | 74% | 77% |
| Combat | Net points per charged fight | +84 | +144 |
| Combat | Net points per supported fight / lone fight | +87 / +84 | +144 / +144 |
| Combat | Charged fights on a top-3 enemy unit | 37 of 97 | 47 of 104 |
| Game | Points lost | 798.7 | 632.2 |
| Game | VP from objectives | 498.1 | 568.9 |
| Game | Lone holders (player turns) | 2.2 | 3.9 |

- Mine won / drew / lost: 11 / 6 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -261 VP
- The side that went first won 17 of 30 games with a winner
- Points traded per game (both sides' losses): 1431
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-opp-779e261-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 3.6 | -159.6 | 195.9 | 68.6 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 30.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.2 | +9.5 | 0.0 | 53.2 | 0.7 | +5.8 | 0.0 | 5.4 |
| BEST FACING | 1.1 | +51.1 | 0.0 | 47.8 | 0.2 | +3.8 | 0.0 | 0.0 |
| BEST FIRST | 4.0 | +175.6 | 114.8 | 98.6 | 0.9 | +61.4 | 30.3 | 21.6 |
| BEST OVERALL | 0.8 | +39.1 | 0.0 | 21.3 | 0.2 | +6.8 | 0.0 | 4.5 |
| BEST PREY | 0.7 | +26.6 | 23.9 | 33.6 | 0.6 | +22.6 | 8.5 | 10.3 |
| BEST PRIZE | 0.1 | -3.3 | 6.7 | 16.6 | 0.1 | -4.7 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -2.6 | 0.0 | 10.6 | 0.2 | -0.2 | 0.0 | 11.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.7 |
| BLOCKED WHEEL | 0.3 | +14.4 | 0.0 | 8.0 | 0.3 | +12.6 | 0.0 | 1.2 |
| BLOWS WHERE AIMED | 0.2 | -18.7 | 25.5 | 8.6 | 0.3 | -62.5 | 65.2 | 3.2 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 42.0 | 4.6 | 0.1 | +0.0 | 14.2 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +109.7 | 253.9 | 97.9 | 1.6 | +72.6 | 111.5 | 7.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 11.3 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -4.3 | 20.1 | 12.1 | 0.2 | -1.3 | 27.8 | 0.0 |
| CAST JOB | 0.9 | +27.6 | 56.5 | 17.9 | 1.1 | +39.2 | 58.3 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +27.3 | 0.0 | 13.7 | 0.0 | +0.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 34.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.8 | +88.5 | 0.0 | 37.9 |
| CHAFF PASSED | 0.1 | -0.0 | 5.2 | 0.0 | 0.2 | -0.3 | 14.1 | 5.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 195.8 | 66.1 | 2.6 | +0.0 | 295.9 | 34.8 |
| CHARGE NOW WEIGHED | 0.8 | -81.9 | 27.8 | 17.9 | 0.5 | -44.6 | 24.2 | 16.7 |
| CHARGER SLAIN LOST | 0.4 | -8.7 | 40.5 | 26.6 | 0.8 | -19.7 | 55.9 | 26.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.9 | 0.0 | 11.0 | 0.1 | -3.0 | 0.0 | 22.1 |
| CHEAP HELPER | 0.0 | +0.0 | 3.2 | 0.0 | 0.1 | +0.0 | 9.9 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.9 | 48.4 | 0.6 | +0.0 | 59.0 | 60.2 |
| CONVEYANCE SEARCH | 0.7 | +79.5 | 42.2 | 42.2 | 0.2 | +24.2 | 8.3 | 19.4 |
| COUNTER-CHARGE COVER | 10.2 | +869.5 | 0.0 | 241.2 | - | - | - | - |
| COVER ONCE | - | - | - | - | 6.4 | -526.9 | 0.0 | 111.5 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +5.8 | 8.6 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +8.0 | 25.6 | 5.2 | 0.2 | +2.0 | 23.1 | 2.5 |
| ELIXIR WORTH | 0.1 | +0.8 | 0.0 | 8.2 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.5 | +194.5 | 0.0 | 107.4 | 1.0 | +47.8 | 0.0 | 12.4 |
| FALLBACK BY WORTH | 4.3 | +62.2 | 0.0 | 72.7 | 5.3 | +63.2 | 0.0 | 67.8 |
| FIGHT LIFT | 0.1 | +0.5 | 3.2 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 6.4 | +0.0 | 0.0 | 236.4 | 4.9 | +0.0 | 0.0 | 104.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +2.7 | 4.7 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +125.0 | 0.0 | 32.8 | 0.8 | +117.4 | 0.0 | 7.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.1 | 0.0 | 3.2 | 0.1 | +4.7 | 0.0 | 5.4 |
| GIVES UP | 0.1 | -2.2 | 11.9 | 1.7 | 0.1 | -0.2 | 15.1 | 2.7 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 12.3 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 2.7 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.2 | +0.0 | 19.3 | 14.5 | 0.4 | +0.0 | 43.7 | 6.1 |
| HILL BY ITS CHANCE | 0.2 | -13.2 | 0.0 | 0.0 | 0.5 | -45.1 | 0.0 | 9.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.2 | -132.2 | 354.4 | 197.6 | 9.0 | -208.3 | 611.3 | 152.2 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +4.2 | 0.0 | 3.1 | 0.1 | +4.0 | 8.1 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.4 | +11.1 | 0.0 | 10.5 | 0.5 | +30.8 | 0.0 | 20.4 |
| HUNT KEPT | 0.2 | +4.3 | 0.0 | 0.0 | 0.1 | +1.1 | 3.5 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.4 | 0.1 | +6.2 | 8.1 | 2.7 |
| HUNT THE GUNS | 0.1 | +28.2 | 0.0 | 3.1 | 0.2 | +48.5 | 8.1 | 3.2 |
| IDLE COST | - | - | - | - | 19.2 | -343.5 | 0.0 | 221.5 |
| INVITES THE FIGHT | 2.0 | +45.5 | 55.0 | 47.8 | 0.6 | +4.9 | 42.9 | 24.6 |
| JOINT CHARGE PLAN | 0.1 | +0.8 | 0.0 | 12.1 | 0.2 | +28.4 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.5 | 14.8 | 0.0 |
| KEEP FALLS | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 5.8 |
| KEEPS ITS TARGET | 1.6 | +49.2 | 144.5 | 28.3 | 2.4 | +73.3 | 264.5 | 10.4 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +75.2 | 146.8 | 19.0 | 1.6 | +84.4 | 133.2 | 3.2 |
| KILLS COUNT NEXT TURN | 4.7 | +171.8 | 211.0 | 137.0 | 7.1 | +239.1 | 219.9 | 153.5 |
| LONE CHARACTER SAFE SPOT | 0.4 | +16.2 | 7.5 | 3.2 | 0.2 | +25.1 | 4.6 | 19.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 6.3 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.1 | 22.8 | 0.0 | 0.2 | -2.5 | 17.4 | 1.2 |
| LOST CHARGE | 3.1 | -51.4 | 120.4 | 82.6 | 2.5 | -40.8 | 84.7 | 55.7 |
| LURE BY WHAT IT DRAWS | 0.0 | -2.9 | 0.0 | 0.0 | 0.1 | -12.2 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.9 | +132.3 | 10.7 | 49.8 | 1.2 | +106.7 | 26.4 | 27.1 |
| MANOEUVRE | 0.3 | +13.4 | 0.0 | 1.8 | 0.2 | +17.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.5 | 0.0 | 7.2 | 0.0 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +36.8 | 0.0 | 43.0 | 0.5 | +19.6 | 0.0 | 7.2 |
| MARCH ODDS | 0.2 | +10.5 | 4.7 | 13.9 | 0.2 | +13.0 | 11.8 | 0.0 |
| MARCH OVER CASTS | 0.7 | +34.5 | 0.0 | 23.9 | 0.4 | +38.1 | 0.0 | 14.1 |
| MAX FOR POSITIONING | 4.9 | +205.5 | 0.0 | 173.2 | 7.6 | +135.8 | 0.0 | 159.2 |
| MISSILES IN THE MOVE | 4.0 | +134.3 | 0.0 | 158.1 | 4.3 | +82.7 | 0.0 | 58.9 |
| MISSILES NEXT TURN | 5.3 | +83.6 | 0.0 | 190.3 | 5.1 | +57.8 | 0.0 | 76.0 |
| MODEL FACING | 0.1 | +57.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 12.6 | 0.0 | 0.2 | +0.0 | 17.9 | 0.0 |
| MOVE AND CAST | 0.4 | +25.5 | 0.0 | 0.0 | 0.6 | +32.7 | 0.0 | 5.3 |
| MOVE SPELL IN RANGE | 0.2 | +5.3 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -16.1 | 0.0 | 46.1 | 0.2 | -3.8 | 19.5 | 20.6 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 34.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.8 | +319.1 | 102.4 | 98.1 | 4.9 | +418.3 | 223.4 | 107.3 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 2.7 | 0.0 | 0.1 | +1.9 | 3.4 | 0.0 |
| NO RALLY LEFT | 0.1 | +3.2 | 0.0 | 2.3 | - | - | - | - |
| NOT NEEDED | 0.1 | -3.1 | 4.7 | 3.2 | 0.2 | -7.2 | 40.4 | 0.0 |
| NOT TURNED | 6.0 | +76.7 | 0.0 | 133.0 | 5.3 | +52.7 | 0.0 | 123.8 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 21.1 | 0.7 | -8.2 | 0.0 | 11.0 |
| OFF BEST | 15.8 | -774.0 | 0.0 | 323.6 | 16.4 | -836.7 | 11.3 | 263.9 |
| ONE FIGHT FORMULA | - | - | - | - | 8.8 | -196.8 | 29.6 | 198.1 |
| ONE OBJECTIVE FORMULA | - | - | - | - | 1.7 | -82.7 | 0.0 | 15.4 |
| OPENS A LANE | - | - | - | - | 0.4 | +1.4 | 33.0 | 0.0 |
| OPENS UP | 0.2 | +14.8 | 10.8 | 0.0 | 0.1 | +3.8 | 4.7 | 0.0 |
| OVERRUNS AWAY | 0.4 | +11.3 | 34.6 | 21.3 | 0.7 | +13.9 | 68.1 | 20.6 |
| PATHS CROSS | 1.8 | +133.2 | 0.0 | 61.0 | 2.2 | +191.2 | 0.0 | 51.8 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.4 | 0.0 | 0.0 | 0.0 | -0.6 | 0.0 | 7.0 |
| PLAN RESULT | 35.7 | +1139.0 | 1012.6 | 993.1 | 37.4 | +1424.0 | 1486.2 | 878.7 |
| PURSUES BIG PREY | 0.1 | -7.7 | 0.0 | 0.0 | 0.1 | -2.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +11.5 | 0.0 | 9.2 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +6.0 | 0.0 | 14.2 | 1.4 | +26.4 | 0.0 | 65.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.4 | 0.0 | 9.4 | 0.2 | -13.4 | 3.1 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -12.9 | 0.0 | 3.6 | 1.4 | -47.4 | 0.0 | 31.1 |
| REDIRECT COUNTER | 1.6 | +133.5 | 0.0 | 41.0 | 3.8 | +310.4 | 0.0 | 60.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +2.5 | 9.6 | 3.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 19.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +5.5 | 0.0 | 2.2 | 0.8 | +41.3 | 0.0 | 17.0 |
| RESTRAINS TO SHOOT | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +73.6 | 208.5 | 63.3 | 2.4 | +43.5 | 282.2 | 42.2 |
| RISK ONCE | - | - | - | - | 4.0 | +259.9 | 68.9 | 197.6 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.5 | 5.4 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +55.7 | 0.0 | 32.3 | 0.8 | +26.5 | 0.0 | 4.5 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -2.4 | 0.0 | 0.0 | 0.5 | -32.8 | 0.0 | 1.1 |
| SEARCH SPOT | 2.6 | +149.9 | 0.0 | 79.6 | 2.3 | +122.2 | 0.0 | 42.1 |
| SELF MOVE SPELL | 0.3 | +41.3 | 0.0 | 29.1 | 0.1 | +21.9 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.2 | +164.5 | 29.6 | 66.3 | 2.1 | +174.6 | 67.5 | 43.1 |
| SET-UP ANY TARGET | 0.4 | +56.8 | 42.2 | 42.2 | 0.1 | +16.6 | 0.0 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +10.9 | 16.6 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +34.7 | 25.7 | 2.2 | 1.1 | +38.9 | 24.2 | 12.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 51.2 | 5.8 | 0.2 | +0.0 | 30.8 | 2.0 |
| SHOTS IN THE MOVE | 13.4 | +470.9 | 0.0 | 242.3 | 9.6 | +283.7 | 0.0 | 109.2 |
| SPELL CATCH ODDS | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.5 | +97.7 | 42.2 | 42.2 | 0.1 | +16.6 | 0.0 | 7.6 |
| SPELL WORTH | 1.4 | +22.8 | 89.4 | 105.8 | 2.4 | +33.8 | 44.1 | 48.1 |
| SPELLS IN THE FIGHT | 0.4 | -4.8 | 74.8 | 16.3 | 0.7 | -12.9 | 134.6 | 18.0 |
| STABLE ROLE | 10.1 | +0.0 | 333.5 | 194.7 | 8.7 | +0.0 | 384.0 | 165.2 |
| STANDS TO CAST | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +3.2 | 0.0 | 0.0 | 0.1 | +5.4 | 0.0 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.6 | +31.2 | 0.0 | 17.6 | 0.6 | +25.1 | 0.0 | 18.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 6.0 | -62.7 | 280.7 | 141.4 | 6.7 | -70.6 | 425.2 | 81.9 |
| SUPPORTS | 4.2 | +67.1 | 103.9 | 80.9 | 4.7 | +75.4 | 197.3 | 49.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.5 | 22.1 | 0.0 | 0.2 | -3.9 | 13.4 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +3.0 | 7.9 | 21.5 | 0.7 | +6.9 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.3 | +7.5 | 0.0 | 0.0 | 0.2 | +9.0 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -9.1 | 18.5 | 5.2 | 0.3 | -24.0 | 29.3 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +2.2 | 7.9 | 16.2 | 0.6 | +3.1 | 36.3 | 7.8 |
| WAIT AFTER COSTS | 6.6 | -371.9 | 201.9 | 180.6 | 7.2 | -370.2 | 357.6 | 145.1 |
| WALKS TO THE FIGHT | 1.4 | +27.7 | 23.9 | 24.1 | 0.7 | +4.1 | 43.7 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +9.5 | 3.4 | 0.0 | 0.0 | +5.1 | 10.2 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 50.6 | 31.7 | 0.1 | +0.0 | 8.6 | 3.8 |
| WEARS DOWN | 1.1 | +54.9 | 75.5 | 58.5 | 1.2 | +44.1 | 167.4 | 29.1 |
| WHO HITS BACK | 0.4 | +53.2 | 0.0 | 29.5 | 0.2 | +14.7 | 0.0 | 11.1 |
| WHOLE FIGHT | 0.2 | +3.1 | 20.7 | 15.8 | 0.3 | +39.9 | 92.8 | 0.8 |
| WHOLE FIGHT GAIN | 0.3 | +14.7 | 23.3 | 1.7 | 0.5 | +36.5 | 66.1 | 3.2 |
| WIDER SPREAD | 2.2 | -8.7 | 226.3 | 47.2 | 2.9 | -9.8 | 345.8 | 20.0 |

### Rule changes: os-h2h-opp-779e261-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1158 | 1158 | 1158 | 32.17 | -57986 | -50.1 |
| BEST FIRST | 177 | 177 | 177 | 4.92 | +8532 | +48.2 |
| SEARCH SPOT | 176 | 176 | 172 | 4.78 | +9795 | +56.9 |
| MOVE TO CHARGE | 276 | 276 | 146 | 4.06 | +10643 | +72.9 |
| PATHS CROSS | 146 | 146 | 146 | 4.06 | +11677 | +80.0 |
| SUPPORTS | 321 | 321 | 133 | 3.69 | +1687 | +12.7 |
| FACES THE THREAT | 124 | 124 | 124 | 3.44 | +8724 | +70.4 |
| KILLS COUNT NEXT TURN | 426 | 426 | 117 | 3.25 | +3074 | +26.3 |
| COUNTER-CHARGE COVER | 367 | 181 | 94 | 2.61 | +5511 | +58.6 |
| WAIT AFTER COSTS | 496 | 496 | 77 | 2.14 | +1382 | +17.9 |
| FALLBACK BY WORTH | 346 | 346 | 72 | 2.00 | +4515 | +62.7 |
| ARTILLERY RE-ROLL WEIGHED | 71 | 71 | 71 | 1.97 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +8727 | +136.4 |
| SHOTS IN THE MOVE | 827 | 554 | 62 | 1.72 | +1215 | +19.6 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +2960 | +48.5 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CANNON PLANNED TARGET | 262 | 262 | 52 | 1.44 | -933 | -17.9 |
| BEST FACING | 48 | 48 | 48 | 1.33 | +1978 | +41.2 |
| REDIRECT COUNTER | 196 | 106 | 48 | 1.33 | +3599 | +75.0 |
| SET UP TOGETHER | 120 | 103 | 48 | 1.33 | +3648 | +76.0 |
| MAX FOR POSITIONING | 452 | 254 | 46 | 1.28 | +307 | +6.7 |
| MISSILES IN THE MOVE | 300 | 168 | 46 | 1.28 | +856 | +18.6 |
| CHARGE NOW WEIGHED | 44 | 44 | 44 | 1.22 | +4139 | +94.1 |
| WALKS TO THE FIGHT | 77 | 77 | 44 | 1.22 | +567 | +12.9 |
| STOPS SHORT OF THE FLANK | 43 | 43 | 43 | 1.19 | +2028 | +47.2 |
| COVER ONCE | 230 | 130 | 42 | 1.17 | +596 | +14.2 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 41 | 1.14 | +1166 | +28.4 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RESERVE FALL BACK | 38 | 38 | 38 | 1.06 | +1685 | +44.3 |
| CHAFF IN THE MOVE | 65 | 62 | 37 | 1.03 | +1084 | +29.3 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| MOVE AND CAST | 37 | 37 | 37 | 1.03 | +2097 | +56.7 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 37 | 1.03 | +1191 | +32.2 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| BEST OVERALL | 35 | 35 | 35 | 0.97 | +1653 | +47.2 |
| CAST JOB | 69 | 69 | 35 | 0.97 | +848 | +24.2 |
| RISK ONCE | 145 | 110 | 34 | 0.94 | +1344 | +39.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| CHARGE NOW FIRST | 162 | 162 | 32 | 0.89 | -2023 | -63.2 |
| MARCH CHECK | 39 | 37 | 32 | 0.89 | +2266 | +70.8 |
| HONEST WORTH | 582 | 577 | 31 | 0.86 | +325 | +10.5 |
| ONE FIGHT FORMULA | 316 | 179 | 30 | 0.83 | +95 | +3.2 |
| INVITES THE FIGHT | 94 | 94 | 29 | 0.81 | +356 | +12.3 |
| ADVANCE WORTH | 129 | 129 | 28 | 0.78 | +625 | +22.3 |
| RISK BY ARC | 171 | 167 | 26 | 0.72 | +648 | +24.9 |
| SHOT REPLANNED | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| KILLS COUNT | 111 | 110 | 24 | 0.67 | +1270 | +52.9 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +446 | +20.3 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +971 | +46.2 |
| IDLE COST | 690 | 386 | 20 | 0.56 | +169 | +8.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1779 | +89.0 |
| MAKE SURE TOGETHER | 74 | 48 | 19 | 0.53 | +2006 | +105.6 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.53 | +595 | +31.3 |
| BIG CHARACTER SAFETY | 18 | 18 | 18 | 0.50 | -101 | -5.6 |
| MANOEUVRE | 19 | 19 | 18 | 0.50 | +1120 | +62.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| KEEPS ITS TARGET | 147 | 144 | 17 | 0.47 | +318 | +18.7 |
| BEST PREY | 47 | 47 | 14 | 0.39 | +368 | +26.3 |
| WAR ENGINE JOBS | 32 | 32 | 14 | 0.39 | -557 | -39.8 |
| MARCH ODDS | 14 | 14 | 13 | 0.36 | +139 | +10.7 |
| WHOLE FIGHT GAIN | 29 | 25 | 13 | 0.36 | +568 | +43.7 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -10 | -0.9 |
| LOST CHARGE | 202 | 201 | 12 | 0.33 | +256 | +21.3 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -266 | -24.2 |
| CASTING BLOCK | 11 | 11 | 10 | 0.28 | +339 | +33.9 |
| WEARS DOWN | 82 | 81 | 10 | 0.28 | +413 | +41.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +603 | +67.0 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -382 | -47.8 |
| MISSILES NEXT TURN | 376 | 200 | 8 | 0.22 | +16 | +2.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +270 | +38.5 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 7 | 0.19 | -317 | -45.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OPENS UP | 10 | 10 | 7 | 0.19 | +203 | +29.0 |
| REFUSING RETIRES | 17 | 17 | 7 | 0.19 | -3 | -0.4 |
| SUPPORT NARROWED | 458 | 458 | 7 | 0.19 | -104 | -14.8 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -70 | -11.8 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +273 | +45.5 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +2077 | +415.4 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -361 | -72.3 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +111 | +22.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE REACH TOGETHER | 40 | 26 | 5 | 0.14 | +4 | +0.9 |
| BACKUP TARGETS | 69 | 36 | 4 | 0.11 | +6 | +1.5 |
| HUNT IN PAIRS | 31 | 13 | 4 | 0.11 | +198 | +49.5 |
| WIDER SPREAD | 186 | 180 | 4 | 0.11 | +25 | +6.3 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CARRIES OUT SET-UP | 13 | 13 | 3 | 0.08 | -204 | -68.2 |
| DEFENSIVE FLOOR | 3 | 3 | 3 | 0.08 | +101 | +33.6 |
| OVERRUNS AWAY | 40 | 39 | 3 | 0.08 | +19 | +6.3 |
| SPELLS IN THE FIGHT | 40 | 40 | 3 | 0.08 | +35 | +11.8 |
| WAR ENGINE CHARGES | 5 | 5 | 3 | 0.08 | +286 | +95.2 |
| WHOLE FIGHT | 18 | 17 | 3 | 0.08 | +73 | +24.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -4 | -2.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +30 | +15.1 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +97 | +48.4 |
| HUNT ADVANCE | 8 | 8 | 2 | 0.06 | +109 | +54.6 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +12 | +5.9 |
| ONE OBJECTIVE FORMULA | 62 | 36 | 2 | 0.06 | +56 | +27.9 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +313 | +156.4 |
| SCREEN BY WHAT IT SAVES | 23 | 23 | 2 | 0.06 | +45 | +22.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -13 | -6.5 |
| STOPS | 7 | 7 | 2 | 0.06 | +141 | +70.3 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CHARGER SLAIN LOST | 44 | 43 | 1 | 0.03 | +31 | +31.3 |
| EDGE GIVE GROUND | 15 | 14 | 1 | 0.03 | +10 | +10.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +256 | +256.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 18 | 18 | 1 | 0.03 | +1 | +0.9 |
| MOVE SPELL IN RANGE | 8 | 5 | 1 | 0.03 | +12 | +12.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -104 | -104.3 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 19 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 26 | trace | - | - | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 407 | not checked | - | - | - | - |
| GIVES UP | 7 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 24 | 24 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 406 | 406 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 16 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2633 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 69 | 69 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 18 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| STABLE ROLE | 677 | 673 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 17 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 33 | 27 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-opp-779e261-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.11 | 14.75 | 50.8 |
| FALLBACK | gate | 0.72 | 0.89 | 59.9 |
| CHARGE NOW FIRST | rule | 0.36 | 0.53 | 63.2 |
| TURN GATE | gate | 0.53 | 0.36 | 31.5 |
| CANNON PLANNED TARGET | rule | 0.53 | 0.06 | 47.4 |
| WAR ENGINE JOBS | rule | 0.31 | 0.06 | 42.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.17 | 24.2 |
| BEST PRIZE | rule | 0.11 | 0.11 | 47.8 |
| AFTERMATH BAND | gate | 0.17 | 0.03 | 2.2 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.06 | 17.4 |
| SUPPORT NARROWED | rule | 0.03 | 0.17 | 14.8 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 1.7 |
| LONE WIZARD HOLDS BACK | rule | 0.08 | 0.08 | 52.8 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.03 | 11.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.06 | 59.9 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 72.3 |
| CHAFF PASSED | rule | - | 0.11 | 2.5 |
| PATHS CROSS | rule | 0.08 | 0.03 | 7.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 11.5 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 68.2 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 20.9 |
| FACES THE THREAT | rule | 0.08 | - | 16.5 |
| NO REASON | gate | - | 0.08 | 8.2 |
| REDIRECT WEIGHED | rule | - | 0.08 | 33.7 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 20.9 |
| SUPPORT REQUEST | gate | - | 0.08 | 80.0 |
| CATCH ODDS | rule | 0.06 | - | 2.0 |
| MOVE AND CAST | rule | 0.03 | 0.03 | 19.8 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.8 |
| RULE SWITCHED OFF | gate | 0.06 | - | 23.3 |
| STANDS TO CAST | rule | 0.06 | - | 6.5 |
| MARCH ODDS | rule | 0.03 | - | 5.3 |
| SAFE SURE CHARGE | rule | - | 0.03 | 104.3 |
| SAFER THAN THE JOB | rule | - | 0.03 | 9.7 |

### Plans: os-h2h-opp-779e261-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 15% | 405 | 256 | 63% |
| Mine | charge | 2.7 | 66% | 236 | 253 | 107% |
| Mine | close in | 3.7 | 30% | 319 | 134 | 42% |
| Mine | hold | 4.3 | 33% | 229 | 0 | 0% |
| Mine | join | 0.5 | 100% | 12 | 0 | 0% |
| Mine | shoot | 8.3 | 60% | 168 | 497 | 295% |
| Mine | support | 4.7 | 90% | 46 | 0 | 0% |
| Opponent | advance | 10.2 | 19% | 135 | 296 | 219% |
| Opponent | charge | 3.7 | 67% | 382 | 436 | 114% |
| Opponent | close in | 6.8 | 26% | 425 | 237 | 56% |
| Opponent | hold | 4.3 | 36% | 317 | 0 | 0% |
| Opponent | join | 0.7 | 100% | 33 | 0 | 0% |
| Opponent | shoot | 5.5 | 62% | 187 | 455 | 244% |
| Opponent | support | 6.3 | 87% | 62 | 0 | 0% |

### Packages: hunt the guns, os-h2h-opp-779e261-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 1 | 0% | 0% | 0% | - | 370 | 0 | 0% | 22 |
| Opponent | 0.2 | 6 | 1 | 0% | 20% | 0% | 2.0 | 308 | 44 | 20% | 93 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 1 | 0% | 0% | 0% | - | 448 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 292 | 0 | 0% | 78 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 91 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| Tomb Kings of Khemri | 0.5 | 3 | 1 | 0% | 0% | 0% | - | 342 | 0 | 0% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 16 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 50% | 0% | 2.0 | 280 | 111 | 50% | 109 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 114 |

### Battle groups: os-h2h-opp-779e261-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.2 | 22% | 46% | 8% | 50% | 32% | 10% | 7% | 52% | 0% |
| Mine | REDIRECT COUNTER | 1.6 | 27% | 62% | 19% | 0% | 38% | 8% | 8% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 27% | 78% | 24% | 22% | 7% | 0% | 14% | 71% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-opp-779e261-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 74 (34) | 26 | 48 | 50 | 35% | 2.5 | 93 (21) | 0 (4) | 51 (9) | 103 (24) | 14 (10) |
| Mine | Character | 118 | 37 (118) | 36 | 1 | 39 | 21% | 2.4 | 56 (41) | 31 (53) | 0 (5) | 43 (54) | 36 (45) |
| Mine | Clean-up | 18 | 79 (18) | 31 | 48 | 32 | 39% | 2.6 | 101 (3) | 77 (13) | 52 (2) | 111 (12) | 30 (6) |
| Mine | Fast | 1 | 23 (1) | 23 | 0 | 100 | 0% | 2.0 | - | 23 (1) | - | 23 (1) | - |
| Mine | Fast Hammer | 44 | 34 (44) | 18 | 16 | 61 | 18% | 2.9 | 47 (22) | 24 (14) | 18 (8) | 45 (30) | 16 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 5.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 35 (52) | 25 | 10 | 37 | 15% | 2.6 | 18 (14) | 45 (35) | 7 (3) | 44 (36) | 18 (16) |
| Mine | Holder | 25 | 52 (25) | 23 | 28 | 44 | 44% | 2.8 | 61 (7) | 57 (12) | 26 (6) | 84 (14) | 10 (11) |
| Mine | Shooter | 37 | 49 (37) | 18 | 31 | 61 | 0% | 2.0 | 8 (6) | 59 (29) | 0 (2) | 59 (22) | 34 (15) |
| Mine | Support | 4 | 109 (4) | 109 | 0 | 0 | 0% | 2.5 | - | 109 (4) | - | 115 (3) | 101 (1) |
| Mine | War machine | 52 | 52 (52) | 52 | 0 | 35 | 2% | 1.0 | 59 (13) | 53 (36) | 0 (3) | 55 (13) | 50 (39) |
| Mine | Wizard | 17 | 23 (17) | 23 | 0 | 49 | 6% | 2.1 | 69 (4) | 23 (7) | 0 (1) | 23 (6) | 51 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 64 (68) | 24 | 41 | 54 | 49% | 2.7 | 44 (29) | 27 (11) | 100 (28) | 89 (48) | 7 (20) |
| Opponent | Character | 102 | 62 (102) | 62 | 0 | 28 | 22% | 2.1 | 63 (38) | 71 (52) | 11 (4) | 59 (54) | 74 (40) |
| Opponent | Clean-up | 11 | 57 (11) | 19 | 38 | 14 | 55% | 3.4 | 28 (4) | 47 (6) | 256 (1) | 66 (6) | 49 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 48 (60) | 38 | 10 | 40 | 25% | 2.8 | 53 (30) | 41 (20) | 48 (10) | 52 (28) | 45 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.5 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 39 (50) | 29 | 11 | 41 | 36% | 2.5 | 30 (17) | 46 (30) | 0 (3) | 44 (30) | 33 (20) |
| Opponent | Holder | 40 | 90 (40) | 6 | 84 | 28 | 35% | 2.6 | 31 (9) | 109 (23) | 113 (8) | 118 (29) | 21 (11) |
| Opponent | Shooter | 27 | 29 (27) | 12 | 16 | 39 | 0% | 1.3 | 48 (6) | 22 (19) | 29 (2) | 33 (16) | 23 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 39 (17) | 39 | 0 | 22 | 6% | 1.5 | 0 (3) | 47 (10) | 44 (4) | 28 (3) | 41 (14) |
| Opponent | Wizard | 32 | 17 (32) | 17 | 0 | 24 | 22% | 2.2 | 26 (14) | 12 (13) | 0 (2) | 23 (17) | 6 (12) |

### Charged fights: os-h2h-opp-779e261-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 10 | 55 | 1.0 | 1.5 | 55 | 0 | +55 | 0 of 4 | 3 of 4 | +42 | +68 |
| Mine | Chaos Dwarfs | 4 | 78 | 785 | 3.8 | 1.0 | 209 | 0 | +209 | 9 of 15 | 14 of 15 | - | +209 |
| Mine | Dwarfen Mountain Holds | 3 | 349 | 70 | 1.0 | 1.0 | 70 | 210 | -140 | 0 of 3 | 2 of 3 | - | -140 |
| Mine | Empire of Man | 5 | 288 | 74 | 1.4 | 1.0 | 53 | 38 | +15 | 1 of 7 | 5 of 7 | - | +15 |
| Mine | Grand Cathay | 5 | 304 | 299 | 3.6 | 1.1 | 83 | 69 | +14 | 7 of 18 | 13 of 18 | +0 | +15 |
| Mine | High Elf Realms | 4 | 159 | 487 | 3.5 | 1.1 | 139 | 35 | +104 | 7 of 14 | 11 of 14 | +0 | +112 |
| Mine | Kingdom of Bretonnia | 1 | 342 | 794 | 3.0 | 1.0 | 265 | 0 | +265 | 1 of 3 | 3 of 3 | - | +265 |
| Mine | Lizardmen | 1 | 201 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Ogre Kingdoms | 1 | 116 | 1252 | 6.0 | 1.0 | 209 | 0 | +209 | 3 of 6 | 4 of 6 | - | +209 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 644 | 3.0 | 1.0 | 215 | 18 | +196 | 1 of 3 | 2 of 3 | - | +196 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 33 | 660 | 4.5 | 1.2 | 147 | 60 | +87 | 4 of 9 | 5 of 9 | +125 | +76 |
| Mine | Vampire Counts | 2 | 196 | 137 | 2.5 | 1.4 | 55 | 159 | -104 | 2 of 5 | 3 of 5 | +274 | -199 |
| Mine | Warriors of Chaos | 2 | 0 | 472 | 4.0 | 1.0 | 118 | 50 | +68 | 2 of 8 | 5 of 8 | - | +68 |
| **Mine** | all armies | 36 | 170 | 350 | 2.7 | 1.1 | 130 | 46 | +84 | 37 of 97 | 72 of 97 | +87 | +84 |
| Opponent | Empire of Man | 1 | 679 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 554 | 273 | 1.3 | 1.0 | 205 | 0 | +205 | 2 of 4 | 2 of 4 | - | +205 |
| Opponent | High Elf Realms | 3 | 100 | 66 | 1.3 | 1.2 | 49 | 87 | -38 | 2 of 4 | 3 of 4 | +0 | -50 |
| Opponent | Kingdom of Bretonnia | 2 | 95 | 295 | 2.5 | 1.4 | 118 | 55 | +63 | 2 of 5 | 5 of 5 | -70 | +151 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 571 | 4.0 | 1.2 | 143 | 26 | +117 | 2 of 4 | 3 of 4 | +0 | +156 |
| Opponent | Skaven | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 68 | 1074 | 6.0 | 1.1 | 179 | 8 | +171 | 12 of 24 | 19 of 24 | +317 | +158 |
| Opponent | Vampire Counts | 6 | 9 | 699 | 4.0 | 1.0 | 175 | 4 | +171 | 11 of 24 | 20 of 24 | +0 | +178 |
| Opponent | Warriors of Chaos | 9 | 24 | 625 | 2.7 | 1.2 | 234 | 23 | +211 | 12 of 24 | 17 of 24 | +271 | +199 |
| Opponent | Wood Elf Realms | 6 | 56 | 108 | 2.0 | 1.1 | 54 | 36 | +18 | 2 of 12 | 9 of 12 | +144 | +7 |
| **Opponent** | all armies | 36 | 103 | 471 | 2.9 | 1.1 | 163 | 19 | +144 | 47 of 104 | 80 of 104 | +144 | +144 |

### Effective charges: os-h2h-opp-779e261-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 2 (net +68) | 2 (net +42) | 0 | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 15 | 2 (net +432) | 1 (net +0) | 2 (net +366) | 6 (net +150) | 0 | 4 (net +160) | 0 | 13% (2 of 15) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net -566) | 1 (net -65) | 0 | 0 | 0 | 1 (net +210) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 1 (net -265) | 1 (net +45) | 0 | 4 (net +81) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 18 | 3 (net -108) | 3 (net -118) | 2 (net +107) | 4 (net +20) | 1 (net +0) | 2 (net +154) | 3 | 13% (2 of 15) |
| Mine | High Elf Realms | 14 | 1 (net -175) | 1 (net +125) | 1 (net +159) | 2 (net +200) | 2 (net +61) | 4 (net +158) | 3 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +190) | 0 | 0 | 1 (net +368) | 0 | 1 (net +236) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 6 | 1 (net +743) | 0 | 2 (net +98) | 0 | 0 | 1 (net +144) | 2 | 50% (2 of 4) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +137) | 2 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 4 (net -68) | 4 (net +246) | 0 | 1 (net +66) | 0 | 44% (4 of 9) |
| Mine | Vampire Counts | 5 | 0 | 1 (net -60) | 1 (net -736) | 1 (net +0) | 1 (net +274) | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 8 | 2 (net -44) | 0 | 2 (net +0) | 1 (net +30) | 0 | 3 (net +200) | 0 | 25% (2 of 8) |
| Opponent | Grand Cathay | 4 | 1 (net +189) | 0 | 0 | 3 (net +210) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 4 | 1 (net -347) | 0 | 0 | 1 (net +0) | 0 | 2 (net +98) | 0 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 2 (net +36) | 0 | 2 (net +120) | 1 | 0% (0 of 4) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +198) | 2 | 0% (0 of 2) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 24 | 5 (net +199) | 0 | 3 (net +105) | 6 (net +190) | 3 (net +41) | 6 (net +234) | 1 | 13% (3 of 23) |
| Opponent | Vampire Counts | 24 | 6 (net +224) | 0 | 3 (net +210) | 4 (net +232) | 4 (net +59) | 5 (net +120) | 2 | 14% (3 of 22) |
| Opponent | Warriors of Chaos | 24 | 3 (net -49) | 0 | 6 (net +464) | 4 (net +492) | 1 (net +65) | 7 (net +93) | 3 | 29% (6 of 21) |
| Opponent | Wood Elf Realms | 12 | 1 (net -104) | 0 | 1 (net +0) | 0 | 0 | 2 (net +130) | 8 | 25% (1 of 4) |

### Charged fights, damage counted: os-h2h-opp-779e261-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 193 | 291 | +54 | 203 | 132 | +71 | +36.6 |
| Mine | 50-54% | 7 | 262 | 294 | -51 | 84 | 109 | -25 | -9.5 |
| Mine | Effective (55-75%) | 15 | 242 | 239 | +2 | 138 | 117 | +21 | +8.5 |
| Mine | 76-89% | 23 | 298 | 214 | +128 | 155 | 29 | +126 | +42.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 250 | 166 | +143 | 167 | 23 | +144 | +57.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 496 | 105 | +80 | 96 | 47 | +49 | +9.8 |
| Mine | No odds | 11 | 233 | 124 | +105 | 115 | 20 | +95 | +40.7 |
| Mine | All fights | 97 | 267 | 205 | +84 | 148 | 60 | +88 | +32.9 |
| Opponent | Long shot (under 50%) | 18 | 219 | 278 | +107 | 176 | 61 | +115 | +52.5 |
| Opponent | Effective (55-75%) | 14 | 346 | 272 | +266 | 322 | 22 | +300 | +86.8 |
| Opponent | 76-89% | 20 | 319 | 216 | +237 | 244 | 13 | +231 | +72.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 296 | 206 | +139 | 159 | 41 | +118 | +39.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 487 | 86 | +53 | 62 | 0 | +62 | +12.7 |
| Opponent | No odds | 17 | 149 | 179 | +22 | 108 | 51 | +57 | +38.5 |
| Opponent | All fights | 104 | 285 | 216 | +144 | 184 | 35 | +150 | +52.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-opp-779e261-p3 | move | 432 | 83 (19%) | 59 (14%) | 52 (12%) | 297 (69%) |
| os-h2h-opp-779e261-p3 | objective | 380 | 58 (15%) | 45 (12%) | 51 (13%) | 271 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: os-h2h-mine-779e261-p1b

### Scorecard: os-h2h-mine-779e261-p1b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | 4 | 1 | 1 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | yes | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 4 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 3 | 3 | 0 | 0 | 0 | 125 |
| L1723 | 1 | 1 | Mine | no | 3 | 1 | 0 | 0 | 2 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 6 | 3 | 1 | 1 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 5 | 1 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 226 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 3 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 6 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 657 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 60 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 274 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 41% | 2.3 | 2.4 | 2.5 | 1.1 | 0.3 | 0.0 | 0.0 | 200.1 |
| **Average** | | | Opponent | 12% | 2.6 | 2.1 | 3.0 | 1.8 | 0.5 | 0.0 | 0.0 | 106.0 |

### KPIs: os-h2h-mine-779e261-p1b

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 17 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (6 of 86) | 0% (0 of 82) | 4% (6 of 168) |
| Winner chose to follow up after the loser gave ground |  | 100% (31 of 31); on the table 100% | 100% (17 of 17); on the table 100% | 100% (48 of 48); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 100% | 88% (7 of 8); on the table 100% |
| Winner chose to pursue after the loser fled |  | 75% (3 of 4); on the table 75% | 65% (11 of 17); on the table 71% | 67% (14 of 21); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 97% (37 of 38); on the table 97% | 82% (32 of 39); on the table 87% | 90% (69 of 77); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 40% (41 of 102) | 31% (30 of 96) | 36% (71 of 198) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (41 of 78) | 45% (30 of 66) | 49% (71 of 144) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (15 of 24) | 48% (13 of 27) | 55% (28 of 51) |
| Points that never fought | lower | 36% (12088 of 33995) | 40% (13623 of 33994) | 38% (25711 of 67989) |
|   infantry points that never fought | lower | 57% (3759 of 6556) | 70% (3921 of 5635) | 63% (7680 of 12191) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (64 of 122) | 67% (94 of 140) | 60% (158 of 262) |
| Bound items with a magic missile used (at least once a game) |  | 91% (10 of 11); 2.3 uses a game | 67% (4 of 6); 0.8 uses a game | 82% (14 of 17); 1.6 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 0.3 uses a game | 0.0 uses a game | 30% (3 of 10); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (2 of 6); 0.1 uses a game | 33% (1 of 3); 0.1 uses a game | 33% (3 of 9); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (13938 of 29335) | 61% (18082 of 29664) | 54% (32020 of 58999) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (41%) | 1.6 (42%) | 3.1 (42%) |
| MARCHED: its unit marched | 0.6 (18%) | 0.5 (12%) | 1.1 (15%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.5 (15%) | 0.5 (14%) | 1.1 (14%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |
| GONE: slain | 0.6 (18%) | 0.8 (21%) | 1.5 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.4 (11%) | 0.5 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.1 | 1.5 | 4.2 | 0.6 | 1.1 |
| not cast | 4.9 | 2.6 | 2.4 | 7.5 | 1.8 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (62%) | 0.1 (2%) | 3.1 (42%) | 0.5 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (15%) | 0.1 (3%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.0 (0%) | 0.3 (12%) | 1.1 (14%) | 0.1 (3%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.2 (25%) | 0.2 (9%) | 0.4 (15%) | 1.5 (20%) | 0.4 (23%) | 2.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (7%) | 0.3 (12%) | 0.5 (7%) | 0.0 (0%) | 1.2 (5%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.4 (13%) | 0.0 (0%) | 0.0 (0%) | 0.8 (42%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.1 (63%) | 0.0 (0%) | 1.4 (58%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.6 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 62% (8 of 13) | 60% (3 of 5) | 61% (11 of 18) |
| the unit moved after it | 75% (6 of 8) | 67% (2 of 3) | 73% (8 of 11) |
| it charged on its next turn | 0% (0 of 8) | 33% (1 of 3) | 9% (1 of 11) |
| the enemy charged it first | 12% (1 of 8) | 0% (0 of 3) | 9% (1 of 11) |
| it fought by the end of its next turn | 12% (1 of 8) | 0% (0 of 3) | 9% (1 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 8) | 33% (1 of 3) | 9% (1 of 11) |
| none of these (no charge, no fight, no charge escaped) | 75% (6 of 8) | 33% (1 of 3) | 64% (7 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (214 of 353) | 52% (101 of 195) | 57% (315 of 548) |
|   cavalry | 73% (27 of 37) | 70% (43 of 61) | 71% (70 of 98) |
|   character | 32% (21 of 65) | 6% (3 of 47) | 21% (24 of 112) |
|   chariot | 47% (17 of 36) | - | 47% (17 of 36) |
|   infantry | 64% (91 of 142) | 63% (55 of 87) | 64% (146 of 229) |
|   monster | 78% (14 of 18) | - | 78% (14 of 18) |
|   war machine | 80% (44 of 55) | - | 80% (44 of 55) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (22%) | 0.8 (15%) | 2.6 (19%) |
| CHARGED: it charged | 1.1 (14%) | 1.6 (29%) | 2.7 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.1 (1%) | 0.9 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.9 (24%) | 1.2 (21%) | 3.1 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.6 (11%) | 1.1 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 0.7 (13%) | 2.2 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.4 (6%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 0.8 | 88% | 3.1 pts | 19 pts |
| character | 2.0 | 0.7 | 76% | 10.1 pts | 20 pts |
| chariot | 1.1 | 0.5 | 72% | 13.5 pts | 14 pts |
| infantry | 12.1 | 4.9 | 73% | 10.7 pts | 130 pts |
| monster | 0.9 | 0.2 | 80% | 7.0 pts | 6 pts |
| war machine | 2.6 | 1.9 | 61% | 23.0 pts | 60 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 5.4 | 5.0 |
| Charges that made contact a game | 3.1 | 3.6 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.45 declared, 0.36 contact (11 units) | 0.38 declared, 0.25 contact (8 units) | 0.42 declared, 0.32 contact (19 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.50 contact (6 units) | 1.40 declared, 0.60 contact (5 units) | 1.09 declared, 0.55 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.36 contact (127 units) | 0.61 declared, 0.42 contact (134 units) | 0.58 declared, 0.39 contact (261 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 41% (15 of 37) | 73% (11 of 15) | 20% (1 of 5) | 47% (27 of 57) |
| Character in a unit | 100% (15 of 15) | 100% (5 of 5) | 100% (3 of 3) | 100% (23 of 23) |
| Character on its own | 91% (20 of 22) | 65% (11 of 17) | 32% (13 of 40) | 56% (44 of 79) |
| Chariot | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Infantry | 65% (30 of 46) | 50% (4 of 8) | - | 63% (34 of 54) |
| Monster | 55% (12 of 22) | 60% (3 of 5) | - | 56% (15 of 27) |
| Monstrous | 83% (5 of 6) | 50% (3 of 6) | - | 67% (8 of 12) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 2 | 100% (5 of 5); on the table 100% | 55% (23 of 42) | 56% | 53% (9 of 17) | 100% (5 of 5); 11.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 4 | 100% (7 of 7); on the table 100% | 61% (11 of 18) | 42% | 41% (13 of 32) | 100% (4 of 4); 3.8 uses a game | 30% (3 of 10); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 25% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 20% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 37% | 43% (3 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (9 of 9); on the table 100% | 8% (2 of 24) | 9% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 17% (3 of 18) | 35% | 62% (10 of 16) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Tomb Kings of Khemri | 5 | 73% (8 of 11); on the table 73% | 0% (0 of 6) | 30% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 81% (13 of 16); on the table 94% | 40% (19 of 48) | 40% | 67% (29 of 43) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 85% (11 of 13); on the table 85% | 42% (10 of 24) | 47% | 75% (46 of 61) | 100% (4 of 4); 2.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 3 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 40% | 59% (19 of 32) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p1b, 17 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (12) | 55% (21) | 49% (33) |
| ...free all their last turn and able to turn (per game) | 0.41 | 0.82 | 1.24 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.06 | 0.24 | 0.29 |
| ...with the charger already in that arc before they moved (per game) | 0.18 | 0.53 | 0.71 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.12 | 1.24 | 3.35 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.82 | 0.94 | 1.76 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.76 | 5.88 | 12.65 |

### Quality by phase: os-h2h-mine-779e261-p1b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.2 | 4.2 |
| Strategy | Charge objectives carried out (made contact) | 55% (35 of 64) | 36% (29 of 80) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (76 of 157) | 37% (19 of 51) |
| Strategy | Close-in objectives charged next turn | 17% (15 of 86) | 16% (17 of 105) |
| Strategy | Support requests answered (helper made contact too) | 56% (5 of 9) | 56% (9 of 16) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 27% (3 of 11) | 29% (7 of 24) |
| Strategy | Lone characters that fought | 74% (35 of 47) | 71% (32 of 45) |
| Movement | Charges halted short of contact | 0.4 | 0.1 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 200.1 | 106.0 |
| Movement | Fights charged into per game | 2.6 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 38, net +31 | 6 of 45, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 38, net +349 | 13 of 45, net +1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 38, net +43 | 4 of 45, net +62 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 of 38, net +166 | 11 of 45, net +175 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.5 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (64 of 195) | 43% (51 of 119) |
| Shooting | Points destroyed by shooting units | 53.1 | 23.9 |
| Shooting | War machine shots | 2.6 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (21 of 44) | - |
| Shooting | Points destroyed by war machines | 14.4 | 0.0 |
| Magic | Magic missiles cast | 1.9 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (11 of 33) | 18% (3 of 17) |
| Magic | Wounds caused by magic missiles | 3.0 | 0.5 |
| Magic | Wounds caused by other spells | 1.2 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 74.5 | 17.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.1 / 0.3 / 0.5 / 0.3 | 1.2 / 0.5 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 452.1 | 388.3 |
| Combat | Points run down | 31.5 | 52.5 |
| Combat | Net points per charged fight, damage counted | +98 | +108 |
| Combat | Net per 100 charger points, damage counted | +30.1 | +39.0 |
| Combat | First round won (charged fights) | 73% | 76% |
| Combat | Net points per charged fight | +116 | +105 |
| Combat | Net points per supported fight / lone fight | +150 / +110 | +73 / +111 |
| Combat | Charged fights on a top-3 enemy unit | 17 of 45 | 16 of 51 |
| Game | Points lost | 622.2 | 697.2 |
| Game | VP from objectives | 635.3 | 598.2 |
| Game | Lone holders (player turns) | 2.3 | 2.6 |

- Mine won / drew / lost: 9 / 1 / 7 of 17 ended games (of 17); mean margin (Mine - Opponent) +93 VP
- The side that went first won 6 of 16 games with a winner
- Points traded per game (both sides' losses): 1319
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-mine-779e261-p1b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 6.2 | -141.0 | 230.6 | 246.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.8 | +5.3 | 0.0 | 0.0 | 1.3 | +13.2 | 0.0 | 8.5 |
| BEST FACING | 0.5 | +8.3 | 0.0 | 0.0 | 0.5 | +22.0 | 0.0 | 64.2 |
| BEST FIRST | 1.4 | +94.7 | 76.5 | 30.2 | 4.4 | +185.8 | 138.3 | 43.9 |
| BEST OVERALL | 0.3 | +6.8 | 0.0 | 4.1 | 0.4 | +14.9 | 0.0 | 20.3 |
| BEST PREY | 1.1 | +63.1 | 41.2 | 12.1 | 1.2 | +116.3 | 16.6 | 9.3 |
| BEST PRIZE | 0.1 | -4.2 | 0.0 | 8.4 | 0.1 | -0.5 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -0.9 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 12.8 | 10.9 |
| BLOCKED WHEEL | 0.5 | +20.8 | 0.0 | 10.9 | 0.4 | +12.4 | 0.0 | 7.4 |
| BLOWS WHERE AIMED | 0.3 | -40.8 | 34.6 | 0.0 | 0.4 | +2.2 | 46.5 | 11.5 |
| BOMBING RUN | 0.1 | +1.4 | 0.0 | 8.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 63.5 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.1 | +91.0 | 165.9 | 4.1 | - | - | - | - |
| CANNON SIGHT KEPT | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 13.5 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -0.6 | 30.0 | 0.0 | 0.3 | +0.0 | 35.7 | 0.0 |
| CAST JOB | 1.1 | +37.2 | 82.5 | 54.0 | 0.5 | +7.1 | 0.0 | 6.8 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +3.8 | 11.5 | 40.6 | 0.1 | +0.4 | 0.0 | 9.3 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 43.0 | 0.2 | +0.0 | 0.0 | 43.8 |
| CASTS FROM BEHIND | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.1 | +66.9 | 0.0 | 30.3 | - | - | - | - |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.2 | 13.8 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 323.3 | 40.3 | 2.4 | +0.0 | 273.5 | 51.6 |
| CHARGE NOW WEIGHED | 0.9 | -92.8 | 10.0 | 0.0 | 0.2 | -16.3 | 0.0 | 27.6 |
| CHARGER SLAIN LOST | 0.3 | -3.6 | 38.9 | 0.0 | 1.1 | -21.1 | 127.6 | 44.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -7.2 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 9.2 | 3.3 |
| COMBAT PIVOT | 0.5 | +0.0 | 20.0 | 34.7 | 1.0 | +0.0 | 81.2 | 72.1 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.3 | +24.4 | 4.5 | 23.8 | 0.2 | +21.4 | 27.6 | 43.8 |
| COUNTER-CHARGE COVER | - | - | - | - | 6.8 | +904.2 | 0.0 | 151.9 |
| COVER ONCE | 10.2 | -724.7 | 0.0 | 280.9 | - | - | - | - |
| DEFENSIVE ARMY | 0.2 | +0.0 | 20.5 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +5.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.1 | 6.7 | 0.0 | 0.1 | +1.0 | 8.5 | 0.0 |
| ELIXIR WORTH | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| FACES THE THREAT | 2.1 | +127.0 | 0.0 | 66.8 | 1.2 | +93.3 | 0.0 | 64.2 |
| FALLBACK BY WORTH | 5.0 | +56.9 | 0.0 | 62.1 | 6.2 | +91.2 | 0.0 | 46.0 |
| FIRE AND FLEE | 0.1 | +1.2 | 0.0 | 5.0 | 0.1 | +2.8 | 0.0 | 6.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 239.8 | 5.5 | +0.0 | 0.0 | 179.6 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.6 | 3.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +184.6 | 0.0 | 0.0 | 0.6 | +92.6 | 0.0 | 26.2 |
| FRIENDS SHOTS CHECKED | 0.1 | +9.5 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.2 | 22.4 | 0.0 | 0.2 | -2.8 | 63.5 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -6.3 | 4.7 | 3.5 |
| GROUND FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 6.8 | 0.0 | 0.2 | +0.0 | 61.9 | 0.0 |
| HELPER UNSEEN | 0.5 | +0.0 | 30.9 | 0.0 | 0.5 | +0.0 | 40.5 | 5.3 |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.2 | -134.6 | 422.3 | 128.8 | 8.5 | -172.2 | 621.2 | 132.5 |
| HUNT ADVANCE | - | - | - | - | 0.4 | +22.9 | 18.4 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 0.0 | 13.6 |
| HUNT IN PAIRS | 0.4 | +10.3 | 0.0 | 11.5 | 0.5 | +15.7 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.1 | 9.2 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +9.2 | 0.0 | 16.3 |
| HUNT THE GUNS | - | - | - | - | 0.4 | +146.7 | 9.2 | 2.6 |
| IDLE COST | 17.5 | -305.9 | 0.0 | 269.1 | - | - | - | - |
| INVITES THE FIGHT | 1.6 | +13.5 | 62.8 | 107.9 | 1.6 | +30.4 | 18.6 | 7.4 |
| JOINT CHARGE PLAN | 0.1 | +2.6 | 10.0 | 0.0 | 0.2 | +7.0 | 0.0 | 10.5 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.9 | 0.0 | 0.0 | 0.2 | -2.4 | 0.0 | 26.2 |
| KEEP FALLS | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.5 | +45.9 | 132.5 | 0.0 | 2.2 | +67.1 | 178.3 | 51.3 |
| KILLS COUNT | 1.8 | +72.7 | 148.1 | 40.6 | 2.5 | +131.1 | 266.2 | 58.7 |
| KILLS COUNT NEXT TURN | 5.1 | +247.2 | 269.1 | 52.5 | 6.5 | +173.7 | 333.3 | 113.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +27.8 | 20.6 | 31.8 | 0.6 | +13.3 | 8.8 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.4 | +0.0 | 7.1 | 9.2 | 0.5 | +0.0 | 0.0 | 45.3 |
| LONE WIZARD KEPT IN | 0.4 | +19.2 | 0.0 | 0.0 | 0.2 | +8.2 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +3.5 | 5.8 | 18.5 | 0.3 | +0.7 | 16.1 | 6.8 |
| LOST CHARGE | 3.2 | -41.9 | 141.9 | 98.5 | 2.2 | -50.1 | 3.9 | 113.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.1 | 0.0 | 3.2 | 0.2 | -6.9 | 0.0 | 6.3 |
| MAKE SURE TOGETHER | 0.9 | +95.6 | 30.0 | 0.0 | 1.1 | +71.4 | 40.6 | 91.2 |
| MANOEUVRE | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 5.8 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 0.0 | 0.2 | +2.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +10.9 | 0.0 | 36.8 | 0.6 | +19.1 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +4.7 | 10.0 | 0.0 | 0.2 | +13.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +74.8 | 0.0 | 95.6 | 0.2 | -4.4 | 0.0 | 27.6 |
| MAX FOR POSITIONING | 7.6 | +103.3 | 0.0 | 238.6 | 5.3 | +209.1 | 0.0 | 113.4 |
| MISSILES IN THE MOVE | 4.5 | +106.2 | 0.0 | 146.4 | 3.4 | +42.6 | 0.0 | 65.5 |
| MISSILES NEXT TURN | 5.4 | +88.2 | 0.0 | 236.4 | 3.9 | +35.7 | 0.0 | 93.1 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +16.1 | 0.0 | 9.2 | 0.4 | +11.6 | 0.0 | 6.8 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 27.6 |
| MOVE TO CHARGE | 3.2 | +321.3 | 158.9 | 22.5 | 4.0 | +236.7 | 259.0 | 84.8 |
| MOVES UNITS SPELL | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +7.4 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.7 | -24.2 | 72.9 | 7.2 | 0.5 | -25.4 | 117.5 | 0.0 |
| NOT TURNED | 6.8 | +45.8 | 0.0 | 259.9 | 5.9 | +66.0 | 0.0 | 149.5 |
| NOT WORTH A CAST | 1.0 | -0.6 | 0.0 | 0.0 | 0.6 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 14.1 | -591.0 | 0.0 | 225.0 | 15.8 | -837.6 | 2.0 | 225.4 |
| ONE FIGHT FORMULA | 9.5 | -223.7 | 31.7 | 305.7 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.5 | -62.1 | 0.0 | 42.2 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.2 | 13.6 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +9.6 | 19.9 | 0.0 | 0.1 | +9.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +12.2 | 25.0 | 0.0 | 0.6 | +18.4 | 45.7 | 23.1 |
| PATHS CROSS | 2.5 | +168.2 | 0.0 | 43.7 | 2.6 | +164.1 | 0.0 | 72.9 |
| PIVOT GUARDS FLANK | 0.4 | -3.7 | 0.0 | 14.4 | 0.2 | -1.4 | 0.0 | 11.5 |
| PLAN RESULT | 38.8 | +1306.0 | 1391.8 | 872.4 | 39.1 | +1194.2 | 1168.9 | 943.0 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -7.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.0 | 0.0 | 0.0 | 0.1 | +7.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.4 | +25.7 | 0.0 | 29.4 | 1.6 | +24.5 | 0.0 | 30.0 |
| RANDOM MOVER NO PROMISE | 0.2 | -8.7 | 0.0 | 0.0 | 0.4 | -14.8 | 7.2 | 20.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -18.5 | 0.0 | 20.2 | 0.4 | +5.1 | 0.0 | 6.0 |
| REDIRECT COUNTER | 1.9 | +143.2 | 0.0 | 47.6 | 4.4 | +430.5 | 0.0 | 104.7 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +5.9 | 5.4 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 22.6 |
| RESERVE FALL BACK | 0.8 | +19.2 | 0.0 | 30.1 | 1.2 | +46.0 | 0.0 | 26.2 |
| RISK BY ARC | 2.6 | +171.2 | 302.4 | 28.8 | 3.1 | +71.1 | 334.1 | 98.2 |
| RISK ONCE | 1.5 | +17.4 | 6.7 | 45.8 | - | - | - | - |
| SAFER THAN THE JOB | 0.8 | +50.4 | 0.0 | 3.8 | 0.9 | +71.5 | 0.0 | 3.5 |
| SCOUT SPOT | 0.4 | +1.0 | 0.0 | 0.0 | 0.2 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -14.4 | 0.0 | 8.9 | 0.4 | +3.9 | 0.0 | 3.5 |
| SEARCH SPOT | 1.9 | +73.3 | 0.0 | 64.5 | 3.4 | +171.3 | 0.0 | 99.6 |
| SELF MOVE SPELL | 0.5 | +59.7 | 0.0 | 38.4 | 0.4 | -0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +118.3 | 30.0 | 0.0 | 1.4 | +73.0 | 40.6 | 91.2 |
| SET-UP ANY TARGET | 0.1 | +2.4 | 4.5 | 23.8 | 0.1 | +24.7 | 27.6 | 43.8 |
| SHOOTER COUNTED ONCE | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.2 | +0.6 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +51.2 | 85.7 | 8.8 | 0.6 | +23.7 | 0.0 | 6.5 |
| SHOT REPLANNED | 0.6 | +0.0 | 58.5 | 9.5 | 0.5 | +0.0 | 29.9 | 3.9 |
| SHOTS IN THE MOVE | 12.0 | +310.8 | 0.0 | 142.8 | 6.2 | +132.3 | 0.0 | 59.9 |
| SPELL SETS UP CHARGE | 0.1 | +2.4 | 4.5 | 23.8 | 0.1 | +24.7 | 27.6 | 43.8 |
| SPELL WORTH | 1.8 | +33.1 | 147.6 | 142.9 | 0.5 | +10.5 | 55.3 | 55.3 |
| SPELLS IN THE FIGHT | 0.6 | +10.9 | 85.2 | 8.4 | 0.8 | -29.1 | 122.4 | 37.8 |
| STABLE ROLE | 9.9 | +0.0 | 347.9 | 178.5 | 10.4 | +0.0 | 353.3 | 240.2 |
| STANDS TO CAST | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +3.7 | 0.0 | 2.6 |
| STOPS SHORT OF THE FLANK | 0.6 | +13.8 | 0.0 | 4.1 | 0.4 | +28.5 | 0.0 | 7.1 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 7.1 | -74.3 | 366.9 | 138.8 | 7.8 | -72.1 | 416.9 | 158.2 |
| SUPPORTS | 5.0 | +76.9 | 143.7 | 109.9 | 5.0 | +72.1 | 160.3 | 108.0 |
| SURE REACH TOGETHER | 0.5 | -0.4 | 0.0 | 0.0 | 0.6 | +18.3 | 7.9 | 38.2 |
| THROUGH LINE OF FIRE | 0.4 | +12.8 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -42.2 | 31.5 | 0.0 | 0.2 | -14.1 | 7.8 | 0.0 |
| TWO OR MORE ARRIVE | 0.5 | +2.7 | 20.0 | 0.0 | 0.4 | +1.1 | 17.5 | 6.8 |
| WAIT AFTER COSTS | 6.4 | -337.0 | 281.5 | 177.9 | 7.4 | -390.6 | 365.8 | 106.9 |
| WALKS TO THE FIGHT | 1.2 | +5.8 | 23.6 | 46.9 | 0.9 | +23.4 | 7.4 | 14.7 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 18.2 | 28.5 | 0.1 | +0.0 | 0.0 | 4.4 |
| WEARS DOWN | 0.8 | +68.3 | 150.4 | 1.8 | 0.9 | +18.3 | 160.2 | 26.2 |
| WHO HITS BACK | 0.4 | +14.6 | 0.0 | 39.2 | 0.1 | +1.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +21.1 | 53.1 | 0.0 | 0.4 | +10.1 | 49.9 | 2.9 |
| WHOLE FIGHT GAIN | 0.5 | +42.1 | 60.5 | 0.0 | 1.2 | +114.3 | 167.8 | 34.3 |
| WIDER SPREAD | 2.3 | -3.2 | 238.5 | 53.6 | 3.4 | +1.7 | 400.4 | 72.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 10.3 | 0.0 |

### Rule changes: os-h2h-mine-779e261-p1b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 507 | 507 | 507 | 29.82 | -24288 | -47.9 |
| BEST FIRST | 98 | 98 | 98 | 5.76 | +4770 | +48.7 |
| PATHS CROSS | 87 | 87 | 87 | 5.12 | +5650 | +64.9 |
| SEARCH SPOT | 90 | 90 | 87 | 5.12 | +4159 | +47.8 |
| MOVE TO CHARGE | 123 | 123 | 72 | 4.24 | +4201 | +58.4 |
| SUPPORTS | 170 | 170 | 70 | 4.12 | +841 | +12.0 |
| KILLS COUNT NEXT TURN | 198 | 198 | 65 | 3.82 | +1483 | +22.8 |
| FACES THE THREAT | 57 | 57 | 57 | 3.35 | +3744 | +65.7 |
| FALLBACK BY WORTH | 190 | 190 | 49 | 2.88 | +2517 | +51.4 |
| COUNTER-CHARGE COVER | 116 | 60 | 39 | 2.29 | +3181 | +81.6 |
| WAIT AFTER COSTS | 234 | 234 | 38 | 2.24 | +505 | +13.3 |
| RESERVE FALL BACK | 35 | 35 | 35 | 2.06 | +1108 | +31.7 |
| FOLLOW UP WEIGHED | 30 | 30 | 30 | 1.76 | +4712 | +157.1 |
| SAFER THAN THE JOB | 30 | 30 | 30 | 1.76 | +2072 | +69.1 |
| SHOTS IN THE MOVE | 309 | 210 | 29 | 1.71 | +422 | +14.6 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 1.65 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 51 | 51 | 28 | 1.65 | +853 | +30.5 |
| COMBAT PIVOT | 26 | 26 | 26 | 1.53 | +0 | +0.0 |
| COVER ONCE | 174 | 100 | 26 | 1.53 | +634 | +24.4 |
| RISK BY ARC | 96 | 93 | 25 | 1.47 | +1133 | +45.3 |
| MAX FOR POSITIONING | 219 | 118 | 23 | 1.35 | +200 | +8.7 |
| MARCH CHECK | 25 | 23 | 22 | 1.29 | +528 | +24.0 |
| INVITES THE FIGHT | 55 | 55 | 21 | 1.24 | +248 | +11.8 |
| SHOT REPLANNED | 20 | 20 | 20 | 1.18 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 30 | 28 | 20 | 1.18 | +1143 | +57.1 |
| ADVANCE LANE KEPT | 19 | 19 | 19 | 1.12 | +0 | +0.0 |
| ADVANCE WORTH | 105 | 105 | 19 | 1.12 | +156 | +8.2 |
| CHARGE NOW WEIGHED | 19 | 19 | 19 | 1.12 | +1853 | +97.5 |
| KILLS COUNT | 72 | 71 | 19 | 1.12 | +767 | +40.4 |
| MISSILES IN THE MOVE | 133 | 76 | 19 | 1.12 | +410 | +21.6 |
| BEST PREY | 38 | 38 | 18 | 1.06 | +647 | +35.9 |
| IDLE COST | 298 | 187 | 18 | 1.06 | +208 | +11.6 |
| BEST FACING | 17 | 17 | 17 | 1.00 | +516 | +30.3 |
| CHAFF IN THE MOVE | 19 | 19 | 17 | 1.00 | +625 | +36.8 |
| ONE FIGHT FORMULA | 161 | 99 | 17 | 1.00 | +101 | +6.0 |
| REDIRECT COUNTER | 106 | 55 | 17 | 1.00 | +1663 | +97.8 |
| STOPS SHORT OF THE FLANK | 17 | 17 | 17 | 1.00 | +720 | +42.3 |
| WALKS TO THE FIGHT | 35 | 35 | 17 | 1.00 | +226 | +13.3 |
| CHARGE NOW FIRST | 86 | 86 | 15 | 0.88 | -1312 | -87.5 |
| SHOOTS FROM THE BEST SPOT | 38 | 38 | 15 | 0.88 | +399 | +26.6 |
| BLOCKED WHEEL | 14 | 14 | 14 | 0.82 | +564 | +40.3 |
| CAST JOB | 27 | 27 | 14 | 0.82 | +280 | +20.0 |
| MOVE AND CAST | 14 | 14 | 14 | 0.82 | +471 | +33.6 |
| CASTS FROM BEHIND | 13 | 13 | 13 | 0.76 | +0 | +0.0 |
| HONEST WORTH | 266 | 266 | 13 | 0.76 | +128 | +9.8 |
| SET UP TOGETHER | 41 | 33 | 13 | 0.76 | +819 | +63.0 |
| MAKE SURE TOGETHER | 35 | 23 | 12 | 0.71 | +507 | +42.3 |
| BEST OVERALL | 11 | 11 | 11 | 0.65 | +369 | +33.5 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.65 | -87 | -7.9 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.65 | +803 | +73.0 |
| SCOUT WAITS | 11 | 11 | 11 | 0.65 | +0 | +0.0 |
| KEEPS ITS TARGET | 64 | 64 | 10 | 0.59 | +176 | +17.6 |
| LONE WIZARD KEPT IN | 9 | 9 | 9 | 0.53 | +466 | +51.8 |
| LOST CHARGE | 92 | 92 | 8 | 0.47 | +213 | +26.7 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.47 | +23 | +2.9 |
| THROUGH LINE OF FIRE | 8 | 8 | 8 | 0.47 | +217 | +27.1 |
| WAR ENGINE JOBS | 12 | 12 | 8 | 0.47 | -419 | -52.4 |
| WHO HITS BACK | 8 | 8 | 8 | 0.47 | +120 | +15.0 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.41 | +0 | +0.0 |
| REFUSING RETIRES | 15 | 15 | 7 | 0.41 | -2 | -0.3 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.35 | -15 | -2.6 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 0.35 | +0 | +0.0 |
| BACKUP TARGETS | 35 | 20 | 5 | 0.29 | +32 | +6.5 |
| CANNON PLANNED TARGET | 36 | 36 | 5 | 0.29 | +0 | +0.0 |
| MARCH ODDS | 5 | 5 | 5 | 0.29 | +76 | +15.3 |
| OVERRUNS AWAY | 17 | 17 | 5 | 0.29 | +127 | +25.4 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.24 | +0 | +0.0 |
| MANOEUVRE | 4 | 4 | 4 | 0.24 | +96 | +24.1 |
| WEARS DOWN | 29 | 29 | 4 | 0.24 | +222 | +55.4 |
| CHAFF PASSED | 3 | 3 | 3 | 0.18 | -3 | -0.9 |
| LONG SHOT | 12 | 12 | 3 | 0.18 | -36 | -11.9 |
| MISSILES NEXT TURN | 159 | 91 | 3 | 0.18 | +13 | +4.2 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.18 | +16 | +5.3 |
| STUCK PIVOT | 3 | 3 | 3 | 0.18 | +0 | +0.0 |
| WHOLE FIGHT | 13 | 12 | 3 | 0.18 | +91 | +30.3 |
| ARTILLERY RE-ROLL WEIGHED | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.12 | -79 | -39.6 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.12 | +30 | +15.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.12 | +68 | +34.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.12 | +181 | +90.7 |
| HUNT ADVANCE | 6 | 6 | 2 | 0.12 | +111 | +55.7 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 2 | 0.12 | -113 | -56.6 |
| NEEDED THERE | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 43 | 20 | 2 | 0.12 | +13 | +6.3 |
| OPENS UP | 6 | 6 | 2 | 0.12 | +37 | +18.7 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.12 | -128 | -64.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.12 | +203 | +101.5 |
| REDIRECT BY WHAT IT STOPS | 19 | 19 | 2 | 0.12 | +46 | +23.0 |
| RISK ONCE | 25 | 19 | 2 | 0.12 | +24 | +12.1 |
| SUPPORT NARROWED | 254 | 254 | 2 | 0.12 | -50 | -25.0 |
| WIDER SPREAD | 96 | 93 | 2 | 0.12 | +38 | +19.1 |
| BLOWS WHERE AIMED | 11 | 11 | 1 | 0.06 | +62 | +62.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.06 | +24 | +23.6 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.06 | -11 | -10.6 |
| CASTING BLOCK | 6 | 6 | 1 | 0.06 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.06 | +62 | +62.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.06 | +28 | +27.7 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.06 | +51 | +50.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.06 | +66 | +66.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.06 | +49 | +49.0 |
| SPELLS IN THE FIGHT | 24 | 23 | 1 | 0.06 | +97 | +97.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.06 | +17 | +16.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.06 | +0 | +0.2 |
| STOPS | 1 | 1 | 1 | 0.06 | +26 | +26.1 |
| SURE REACH TOGETHER | 19 | 12 | 1 | 0.06 | +2 | +2.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.06 | -69 | -69.2 |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 13 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 24 | 23 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 196 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 16 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT IN PAIRS | 15 | 6 | 0 | 0.00 | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 20 | 0 | 0.00 | - | - |
| NOT TURNED | 215 | 215 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 27 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 1325 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 40 | not checked | - | - | - | - |
| STABLE ROLE | 345 | 344 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 15 | 12 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p1b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.65 | 13.65 | 48.0 |
| FALLBACK | gate | 0.65 | 0.88 | 39.2 |
| TURN GATE | gate | 0.47 | 0.65 | 37.1 |
| CHARGE NOW FIRST | rule | 0.41 | 0.47 | 87.5 |
| PIVOT GUARDS FLANK | rule | 0.41 | 0.24 | 7.9 |
| WAR ENGINE JOBS | rule | 0.41 | 0.06 | 52.4 |
| AFTERMATH BAND | gate | 0.12 | 0.12 | 2.5 |
| BIG CHARACTER SAFETY | rule | 0.18 | 0.06 | 4.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.18 | 168.1 |
| CHARGE NOW WEIGHED | rule | 0.18 | - | 17.0 |
| SUPPORT REQUEST | gate | - | 0.18 | 122.5 |
| BEST PRIZE | rule | 0.06 | 0.06 | 39.6 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 2.5 |
| PURSUES BIG PREY | rule | - | 0.12 | 64.0 |
| STOPS SHORT OF THE FLANK | rule | 0.12 | - | 1.6 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 25.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 20.6 |
| BLOCKED WHEEL | rule | - | 0.06 | 1.0 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 10.6 |
| CHAFF PASSED | rule | - | 0.06 | 2.7 |
| FACES THE THREAT | rule | 0.06 | - | 15.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 113.2 |
| LONG SHOT | rule | - | 0.06 | 57.4 |
| NO REASON | gate | 0.06 | - | 19.5 |
| REFUSING RETIRES | rule | - | 0.06 | 0.6 |
| SAFER THAN THE JOB | rule | - | 0.06 | 0.8 |
| WHO HITS BACK | rule | 0.06 | - | 3.9 |
| WOUNDED STAYS OUT | rule | - | 0.06 | 69.2 |

### Plans: os-h2h-mine-779e261-p1b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.6 | 18% | 224 | 285 | 127% |
| Mine | charge | 3.2 | 69% | 252 | 337 | 134% |
| Mine | close in | 5.1 | 31% | 287 | 199 | 69% |
| Mine | hold | 5.5 | 32% | 301 | 0 | 0% |
| Mine | join | 0.6 | 91% | 35 | 0 | 0% |
| Mine | shoot | 7.7 | 58% | 188 | 485 | 258% |
| Mine | support | 6.1 | 84% | 54 | 0 | 0% |
| Opponent | advance | 13.6 | 18% | 517 | 335 | 65% |
| Opponent | charge | 4.8 | 68% | 348 | 599 | 172% |
| Opponent | close in | 6.1 | 35% | 301 | 192 | 64% |
| Opponent | hold | 4.4 | 35% | 222 | 0 | 0% |
| Opponent | join | 2.2 | 95% | 117 | 0 | 0% |
| Opponent | shoot | 2.4 | 29% | 48 | 68 | 141% |
| Opponent | support | 5.6 | 91% | 80 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p1b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.4 | 6 | 1 | 0% | 20% | 0% | 3.0 | 456 | 31 | 20% | 22 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 3.0 | 165 | 156 | 100% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 319 | 0 | 0% | 11 |
| Warriors of Chaos | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 598 | 0 | 0% | 28 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 42 |

### Battle groups: os-h2h-mine-779e261-p1b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 41% | 85% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 16% | 63% | 11% | 0% | 41% | 0% | 0% | 59% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 23% | 82% | 6% | 100% | 12% | 0% | 6% | 75% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p1b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 56 | 33% | 5.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Chaff | 27 | 30 (27) | 9 | 20 | 57 | 33% | 2.1 | 20 (13) | 11 (5) | 50 (9) | 45 (16) | 8 (11) |
| Mine | Character | 45 | 56 (45) | 56 | 0 | 28 | 16% | 2.2 | 73 (20) | 46 (19) | 0 (1) | 75 (25) | 38 (15) |
| Mine | Clean-up | 17 | 69 (17) | 26 | 43 | 23 | 35% | 3.4 | 45 (8) | 125 (6) | 12 (3) | 133 (8) | 11 (9) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 18 | 36 (18) | 16 | 20 | 34 | 28% | 2.5 | 35 (9) | 31 (6) | 50 (3) | 35 (10) | 38 (8) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 0% | 1.8 | - | 17 (4) | 0 (1) | 0 (1) | 17 (4) |
| Mine | Hammer | 21 | 29 (21) | 23 | 6 | 59 | 14% | 2.3 | 23 (7) | 35 (13) | 0 (1) | 37 (9) | 25 (12) |
| Mine | Holder | 12 | 39 (12) | 0 | 39 | 24 | 25% | 3.0 | 54 (5) | 27 (7) | - | 72 (4) | 24 (8) |
| Mine | Shooter | 17 | 62 (17) | 37 | 25 | 29 | 0% | 1.7 | 91 (4) | 49 (13) | - | 159 (6) | 16 (11) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 20% | 2.5 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 10 | 33 (10) | 33 | 0 | 6 | 0% | 1.2 | 97 (3) | 11 (6) | 0 (1) | 97 (3) | 9 (7) |
| Mine | Wizard | 13 | 12 (13) | 12 | 0 | 37 | 23% | 2.1 | 11 (6) | 16 (6) | 0 (1) | 15 (3) | 10 (10) |
| Opponent | Chaff | 36 | 59 (36) | 13 | 46 | 53 | 33% | 3.0 | 93 (16) | 42 (9) | 28 (11) | 75 (24) | 23 (12) |
| Opponent | Character | 55 | 47 (55) | 47 | 0 | 33 | 42% | 2.2 | 59 (29) | 38 (18) | 0 (4) | 33 (33) | 79 (18) |
| Opponent | Clean-up | 10 | 50 (10) | 50 | 0 | 45 | 50% | 3.4 | 86 (4) | 35 (4) | 0 (2) | 89 (5) | 21 (5) |
| Opponent | Fast Hammer | 29 | 34 (29) | 19 | 15 | 39 | 28% | 2.2 | 31 (15) | 36 (9) | 48 (5) | 42 (18) | 22 (11) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 26 | 34 (26) | 25 | 9 | 41 | 27% | 3.0 | 32 (10) | 36 (13) | 27 (3) | 33 (14) | 35 (12) |
| Opponent | Holder | 22 | 32 (22) | 9 | 23 | 23 | 64% | 3.2 | 9 (5) | 50 (10) | 28 (5) | 63 (6) | 23 (14) |
| Opponent | Shooter | 12 | 44 (12) | 6 | 38 | 44 | 0% | 1.2 | 42 (3) | 51 (7) | 24 (2) | 42 (6) | 46 (6) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | Wizard | 14 | 15 (14) | 15 | 0 | 36 | 14% | 2.0 | 17 (8) | 0 (2) | 0 (2) | 37 (3) | 0 (9) |

### Charged fights: os-h2h-mine-779e261-p1b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 606 | 196 | 1.0 | 1.0 | 196 | 0 | +196 | 2 of 2 | 1 of 2 | - | +196 |
| Mine | High Elf Realms | 4 | 209 | 465 | 2.8 | 1.3 | 169 | 45 | +124 | 5 of 11 | 7 of 11 | +85 | +133 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 1113 | 4.0 | 1.2 | 278 | 0 | +278 | 2 of 4 | 4 of 4 | +254 | +286 |
| Mine | Lizardmen | 1 | 66 | 0 | 1.0 | 1.0 | 0 | 141 | -141 | 1 of 1 | 0 of 1 | - | -141 |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 2.0 | 1.0 | 0 | 45 | -45 | 1 of 2 | 0 of 2 | - | -45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 60 | 4.0 | 1.0 | 15 | 98 | -83 | 2 of 4 | 4 of 4 | - | -83 |
| Mine | Skaven | 2 | 22 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 55 | 1050 | 5.0 | 1.1 | 210 | 20 | +190 | 2 of 10 | 8 of 10 | +125 | +198 |
| Mine | Vampire Counts | 2 | 0 | 252 | 4.0 | 1.4 | 63 | 0 | +63 | 1 of 8 | 7 of 8 | +168 | +0 |
| Mine | Warriors of Chaos | 1 | 0 | 500 | 3.0 | 1.0 | 167 | 0 | +167 | 1 of 3 | 2 of 3 | - | +167 |
| **Mine** | all armies | 17 | 142 | 384 | 2.6 | 1.2 | 145 | 29 | +116 | 17 of 45 | 33 of 45 | +150 | +110 |
| Opponent | Orc & Goblin Tribes | 1 | 70 | 162 | 3.0 | 1.0 | 54 | 37 | +17 | 1 of 3 | 1 of 3 | - | +17 |
| Opponent | Tomb Kings of Khemri | 3 | 117 | 1092 | 6.0 | 1.0 | 182 | 43 | +139 | 6 of 18 | 14 of 18 | - | +139 |
| Opponent | Vampire Counts | 5 | 11 | 382 | 3.4 | 1.2 | 112 | 39 | +73 | 4 of 17 | 15 of 17 | +60 | +77 |
| Opponent | Warriors of Chaos | 5 | 47 | 0 | 0.4 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Wood Elf Realms | 3 | 0 | 588 | 3.7 | 1.5 | 160 | 17 | +143 | 4 of 11 | 9 of 11 | +85 | +176 |
| **Opponent** | all armies | 17 | 42 | 418 | 3.0 | 1.2 | 139 | 34 | +105 | 16 of 51 | 39 of 51 | +73 | +111 |

### Effective charges: os-h2h-mine-779e261-p1b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 1 (net +0) | 0 | 1 (net +393) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | High Elf Realms | 11 | 1 (net +156) | 1 (net +663) | 3 (net +142) | 2 (net +122) | 0 | 3 (net +47) | 1 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +211) | 1 (net +68) | 2 (net +417) | 0 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 2 (net +30) | 0 | 2 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +0) | 0 | 1 (net +925) | 1 (net +286) | 2 (net +0) | 4 (net +142) | 1 | 11% (1 of 9) |
| Mine | Vampire Counts | 8 | 1 (net +0) | 0 | 0 | 3 (net +0) | 2 (net +109) | 2 (net +142) | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 3 | 1 (net +0) | 0 | 0 | 1 (net +500) | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 18 | 1 (net +405) | 1 (net +0) | 8 (net +44) | 3 (net +406) | 0 | 3 (net +58) | 2 | 50% (8 of 16) |
| Opponent | Vampire Counts | 17 | 2 (net -8) | 0 | 4 (net -59) | 4 (net +39) | 1 (net +0) | 5 (net +250) | 1 | 25% (4 of 16) |
| Opponent | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 11 | 1 (net -83) | 0 | 1 (net -109) | 3 (net +340) | 3 (net +83) | 3 (net +165) | 0 | 9% (1 of 11) |

### Charged fights, damage counted: os-h2h-mine-779e261-p1b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 216 | 205 | +31 | 36 | 67 | -31 | -14.4 |
| Mine | 50-54% | 1 | 497 | 380 | +663 | 663 | 0 | +663 | +133.4 |
| Mine | Effective (55-75%) | 5 | 360 | 202 | +349 | 453 | 126 | +327 | +91.0 |
| Mine | 76-89% | 8 | 313 | 204 | +155 | 167 | 50 | +117 | +37.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 399 | 240 | +166 | 192 | 55 | +137 | +34.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 427 | 95 | +43 | 71 | 0 | +71 | +16.7 |
| Mine | No odds | 7 | 144 | 197 | -109 | 22 | 127 | -105 | -73.2 |
| Mine | All fights | 45 | 327 | 196 | +116 | 162 | 64 | +98 | +30.1 |
| Opponent | Long shot (under 50%) | 6 | 104 | 252 | +51 | 134 | 59 | +74 | +71.6 |
| Opponent | 50-54% | 1 | 440 | 405 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 13 | 225 | 193 | +1 | 105 | 94 | +11 | +5.1 |
| Opponent | 76-89% | 10 | 272 | 153 | +239 | 279 | 59 | +220 | +80.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 365 | 208 | +175 | 199 | 15 | +184 | +50.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 450 | 72 | +62 | 68 | 42 | +26 | +5.8 |
| Opponent | No odds | 6 | 266 | 169 | +82 | 116 | 18 | +97 | +36.6 |
| Opponent | All fights | 51 | 277 | 187 | +105 | 159 | 51 | +108 | +39.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p1b | move | 211 | 43 (20%) | 27 (13%) | 20 (9%) | 148 (70%) |
| os-h2h-mine-779e261-p1b | objective | 191 | 32 (17%) | 25 (13%) | 25 (13%) | 134 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1131, L1923 |
| Elixir of Power | Opponent | L1319 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Ring of Doom | Mine | L1131, L1224, L1527 |
| Ring of Doom | Opponent | L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1131, L1224 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

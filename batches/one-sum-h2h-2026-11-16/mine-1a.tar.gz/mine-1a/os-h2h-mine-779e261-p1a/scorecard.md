# Doctrine scorecard: os-h2h-mine-779e261-p1a

### Scorecard: os-h2h-mine-779e261-p1a

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 12 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 2 | 1 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 322 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 8 | 3 | 2 | 0 | 1 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 0 | - | 0 | 2 | 0 | 0 | 0 | 1331 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | 5 | 1 | 3 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 1258 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 12% | 3.4 | 2.3 | 1.9 | 1.2 | 0.4 | 0.0 | 0.0 | 320.8 |
| **Average** | | | Opponent | 25% | 0.9 | 3.0 | 1.9 | 2.3 | 0.1 | 0.0 | 0.0 | 304.1 |

### KPIs: os-h2h-mine-779e261-p1a

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 10 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 18% (7 of 40) | 14% (7 of 50) | 16% (14 of 90) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 95% (18 of 19); on the table 95% | 96% (25 of 26); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 60% (3 of 5); on the table 60% | 75% (6 of 8); on the table 75% |
| Winner chose to pursue after the loser fled |  | 70% (7 of 10); on the table 80% | 86% (6 of 7); on the table 86% | 76% (13 of 17); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 85% (17 of 20); on the table 90% | 87% (27 of 31); on the table 87% | 86% (44 of 51); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 44% (63 of 144) | 17% (10 of 60) | 36% (73 of 204) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (63 of 133) | 22% (10 of 46) | 41% (73 of 179) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (5 of 7) | 44% (8 of 18) | 52% (13 of 25) |
| Points that never fought | lower | 47% (9158 of 19495) | 45% (8983 of 19896) | 46% (18141 of 39391) |
|   infantry points that never fought | lower | 49% (2934 of 6029) | 59% (2525 of 4264) | 53% (5459 of 10293) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (36 of 65) | 60% (51 of 85) | 58% (87 of 150) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 3.4 uses a game | 57% (4 of 7); 1.1 uses a game | 79% (11 of 14); 2.2 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 100% (3 of 3); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.6 uses a game | 80% (4 of 5); 0.4 uses a game | 77% (10 of 13); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (7237 of 14488) | 56% (9446 of 16903) | 53% (16683 of 31391) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.6 (69%) | 1.1 (22%) | 6.7 (51%) |
| MARCHED: its unit marched | 0.9 (11%) | 0.5 (10%) | 1.4 (11%) |
| CHARGED: its unit charged | 0.5 (6%) | 0.0 (0%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 0.6 (7%) | 0.4 (8%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.2 (24%) | 1.2 (9%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| GONE: slain | 0.5 (6%) | 0.3 (6%) | 0.8 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.5 (10%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.4 (8%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 0.6 | 2.4 | 7.3 | 0.3 | 1.5 |
| not cast | 3.5 | 4.2 | 6.6 | 13.1 | 1.5 | 24.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (3%) | 0.9 (21%) | 0.4 (6%) | 6.7 (51%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (11%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.2 (13%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.4 (6%) | 1.0 (8%) | 0.4 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.6 (14%) | 1.3 (20%) | 1.2 (9%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.5 (14%) | 0.0 (0%) | 0.3 (5%) | 0.8 (6%) | 0.3 (20%) | 1.1 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (17%) | 1.1 (26%) | 1.1 (17%) | 0.5 (4%) | 0.0 (0%) | 2.3 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.3 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.2 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (60%) | 1.5 (36%) | 3.0 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.1 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.4 a game | 0.2 a game | 1.8 a game |
| stood (cast and not dispelled) | 71% (24 of 34) | 100% (2 of 2) | 72% (26 of 36) |
| the unit moved after it | 62% (15 of 24) | 50% (1 of 2) | 62% (16 of 26) |
| it charged on its next turn | 0% (0 of 24) | 0% (0 of 2) | 0% (0 of 26) |
| the enemy charged it first | 12% (3 of 24) | 50% (1 of 2) | 15% (4 of 26) |
| it fought by the end of its next turn | 8% (2 of 24) | 0% (0 of 2) | 8% (2 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 33% (8 of 24) | 0% (0 of 2) | 31% (8 of 26) |
| none of these (no charge, no fight, no charge escaped) | 54% (13 of 24) | 50% (1 of 2) | 54% (14 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (148 of 207) | 65% (168 of 257) | 68% (316 of 464) |
|   cavalry | 75% (9 of 12) | 72% (29 of 40) | 73% (38 of 52) |
|   character | 80% (35 of 44) | 79% (33 of 42) | 79% (68 of 86) |
|   chariot | 34% (11 of 32) | 72% (28 of 39) | 55% (39 of 71) |
|   infantry | 67% (34 of 51) | 40% (29 of 73) | 51% (63 of 124) |
|   monster | - | 60% (12 of 20) | 60% (12 of 20) |
|   war machine | 87% (59 of 68) | 86% (37 of 43) | 86% (96 of 111) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (39%) | 3.7 (42%) | 6.0 (41%) |
| CHARGED: it charged | 0.5 (8%) | 0.9 (10%) | 1.4 (9%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (8%) | 0.6 (7%) | 1.1 (7%) |
| NO TARGET IN RANGE | 1.2 (20%) | 1.4 (16%) | 2.6 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.9 (15%) | 0.9 (10%) | 1.8 (12%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.7 (8%) | 0.9 (6%) |
| OTHER BAR | 0.2 (3%) | 0.3 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.7 | 77% | 5.1 pts | 27 pts |
| character | 7.7 | 2.6 | 73% | 10.1 pts | 78 pts |
| chariot | 3.9 | 3.9 | 59% | 14.2 pts | 56 pts |
| infantry | 9.2 | 4.7 | 64% | 15.4 pts | 142 pts |
| monster | 1.2 | 0.6 | 67% | 6.1 pts | 7 pts |
| war machine | 9.6 | 6.7 | 69% | 20.9 pts | 200 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.0 | 4.2 |
| Charges that made contact a game | 2.2 | 3.5 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.50 contact (4 units) | 0.50 declared, 0.50 contact (2 units) | 0.83 declared, 0.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.32 contact (62 units) | 0.55 declared, 0.37 contact (86 units) | 0.51 declared, 0.35 contact (148 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (5 of 10) | 0% (0 of 3) | - | 38% (5 of 13) |
| Character in a unit | 88% (14 of 16) | 81% (13 of 16) | - | 84% (27 of 32) |
| Character on its own | 86% (12 of 14) | 67% (6 of 9) | 14% (1 of 7) | 63% (19 of 30) |
| Chariot | 33% (2 of 6) | 29% (2 of 7) | - | 31% (4 of 13) |
| Infantry | 44% (8 of 18) | 37% (7 of 19) | 100% (1 of 1) | 42% (16 of 38) |
| Monster | 67% (2 of 3) | 67% (2 of 3) | - | 67% (4 of 6) |
| Monstrous | 50% (2 of 4) | 50% (3 of 6) | - | 50% (5 of 10) |
| War Machines | 86% (6 of 7) | 100% (1 of 1) | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 80% (12 of 15); on the table 80% | 46% (63 of 138) | 42% | 70% (23 of 33) | 100% (9 of 9); 6.7 uses a game | 100% (3 of 3); 2.0 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 86% (6 of 7); on the table 100% | 17% (4 of 24) | 45% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 80% (4 of 5); on the table 80% | - | 48% | 76% (16 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 87% | 80% (8 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 73% | 64% (9 of 14) | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 91% (10 of 11); on the table 91% | 8% (1 of 12) | 3% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | - | 17% (1 of 6) | 29% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 31% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (4 of 4); on the table 100% | 17% (2 of 12) | 46% | 50% (12 of 24) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p1a, 10 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (10) | 27% (3) | 39% (13) |
| ...free all their last turn and able to turn (per game) | 0.40 | 0.30 | 0.70 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.30 | 0.00 | 0.30 |
| ...with the charger already in that arc before they moved (per game) | 0.20 | 0.20 | 0.40 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.00 | 1.80 | 2.80 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.80 | 1.10 | 1.90 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.10 | 5.70 | 9.80 |

### Quality by phase: os-h2h-mine-779e261-p1a

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 46% (13 of 28) | 61% (22 of 36) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (61 of 121) | 64% (55 of 86) |
| Strategy | Close-in objectives charged next turn | 15% (5 of 34) | 24% (11 of 46) |
| Strategy | Support requests answered (helper made contact too) | 33% (1 of 3) | 57% (4 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 45% (15 of 33) | 64% (9 of 14) |
| Strategy | Lone characters that fought | 72% (13 of 18) | 67% (16 of 24) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.2 | 2.3 |
| Movement | Points that never moved of their own | 320.8 | 304.1 |
| Movement | Fights charged into per game | 2.0 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 17, net +78 | 3 of 23, net -13 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 17, net +0 | 8 of 23, net -0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 17 | 1 of 23, net +808 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 17, net +202 | 6 of 23, net +212 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 13.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (41 of 89) | 33% (46 of 138) |
| Shooting | Points destroyed by shooting units | 58.3 | 88.2 |
| Shooting | War machine shots | 5.9 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (33 of 59) | 43% (16 of 37) |
| Shooting | Points destroyed by war machines | 17.0 | 55.2 |
| Magic | Magic missiles cast | 3.6 | 0.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (10 of 36) | 60% (3 of 5) |
| Magic | Wounds caused by magic missiles | 10.6 | 1.2 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 82.9 | 6.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.2 / 0.7 / 0.2 | 1.2 / 0.4 / 0.1 / 0.1 |
| Combat | Points destroyed in combat | 289.5 | 173.5 |
| Combat | Points run down | 83.7 | 94.5 |
| Combat | Net points per charged fight, damage counted | +120 | +72 |
| Combat | Net per 100 charger points, damage counted | +55.6 | +27.5 |
| Combat | First round won (charged fights) | 65% | 66% |
| Combat | Net points per charged fight | +112 | +70 |
| Combat | Net points per supported fight / lone fight | +349 / +86 | +179 / +47 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 20 | 10 of 29 |
| Game | Points lost | 512.9 | 757.5 |
| Game | VP from objectives | 677.0 | 595.0 |
| Game | Lone holders (player turns) | 3.4 | 0.9 |

- Mine won / drew / lost: 5 / 3 / 2 of 10 ended games (of 10); mean margin (Mine - Opponent) +369 VP
- The side that went first won 4 of 7 games with a winner
- Points traded per game (both sides' losses): 1270
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-mine-779e261-p1a

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 4.4 | -79.8 | 187.9 | 23.9 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 14.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| BEST FACING | 0.3 | +1.1 | 0.0 | 0.0 | 1.1 | +38.6 | 0.0 | 126.9 |
| BEST FIRST | 0.4 | +62.4 | 0.0 | 23.9 | 4.3 | +163.7 | 184.0 | 5.2 |
| BEST OVERALL | 0.2 | +23.4 | 0.0 | 0.0 | 0.6 | +42.3 | 0.0 | 126.9 |
| BEST PREY | 0.5 | +23.9 | 22.2 | 17.0 | 1.6 | +71.8 | 50.5 | 27.4 |
| BEST PRIZE | 0.2 | -7.6 | 9.5 | 0.0 | 0.2 | -7.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +10.1 | 0.0 | 0.0 | 0.5 | +16.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -43.5 | 44.4 | 0.0 | 0.3 | -69.6 | 0.0 | 22.2 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 58.0 | 9.5 | 0.4 | +0.0 | 13.0 | 13.0 |
| CANNON PLANNED TARGET | 5.7 | +115.3 | 171.5 | 61.5 | 3.3 | +50.1 | 278.5 | 41.0 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 5.2 | 12.5 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 5.2 | - | - | - | - |
| CAST JOB | 0.9 | +22.4 | 0.0 | 0.0 | 0.3 | +8.3 | 35.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.4 | +209.2 | 191.0 | 0.0 | 0.6 | +8.5 | 30.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +8.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +107.6 | 0.0 | 34.5 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 13.5 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 258.2 | 78.2 | 1.7 | +0.0 | 66.2 | 78.9 |
| CHARGE NOW WEIGHED | 0.2 | -0.3 | 0.0 | 31.0 | 0.3 | -26.0 | 17.0 | 3.4 |
| CHARGER SLAIN LOST | 0.7 | -10.1 | 27.7 | 22.2 | 0.4 | -29.1 | 23.9 | 80.9 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 8.5 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 21.0 | 17.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.9 | +248.8 | 0.0 | 0.0 | 0.2 | +141.7 | 0.0 | 27.4 |
| COUNTER-CHARGE COVER | - | - | - | - | 8.6 | +459.5 | 0.0 | 223.2 |
| COVER ONCE | 4.4 | -284.7 | 0.0 | 46.6 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +0.2 | 5.2 | 12.5 |
| EDGE GIVE GROUND | 0.2 | +5.8 | 22.2 | 5.2 | 0.2 | +20.1 | 6.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +5.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.0 | +51.6 | 0.0 | 6.5 | 1.8 | +96.2 | 0.0 | 136.1 |
| FALLBACK BY WORTH | 3.2 | +55.0 | 0.0 | 34.0 | 6.1 | +24.7 | 0.0 | 13.7 |
| FLANK NOT WEIGHED | 4.1 | +0.0 | 0.0 | 91.7 | 6.2 | +0.0 | 0.0 | 261.6 |
| FOLLOW UP WEIGHED | 0.4 | +29.8 | 0.0 | 0.0 | 0.6 | +64.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +16.4 | 0.0 | 0.0 | 0.2 | +6.0 | 0.0 | 14.2 |
| GROUND FLIERS | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 9.2 | 0.0 | 0.2 | +0.0 | 26.9 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.3 | -45.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.2 | -113.2 | 344.2 | 90.0 | 7.6 | -95.6 | 195.4 | 167.2 |
| HUNT ADVANCE | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +23.7 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +45.0 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 12.7 | -205.7 | 0.0 | 69.4 | - | - | - | - |
| INVITES THE FIGHT | 0.8 | +5.4 | 61.6 | 0.0 | 2.1 | +19.5 | 38.7 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +0.1 | 0.0 | 3.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -4.1 | 0.0 | 59.9 |
| KEEPS ITS PREY | - | - | - | - | 0.3 | +1.5 | 6.5 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +33.0 | 63.5 | 20.2 | 1.6 | +48.0 | 42.9 | 39.9 |
| KILLS COUNT | 0.9 | +58.0 | 101.7 | 15.6 | 1.4 | +92.2 | 86.7 | 22.2 |
| KILLS COUNT NEXT TURN | 3.3 | +124.7 | 67.7 | 64.4 | 5.5 | +236.4 | 94.4 | 128.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.1 | 0.0 | 0.0 | 0.7 | +12.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.0 | 0.0 | 0.0 | 0.4 | +45.3 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +6.5 | 6.0 | 17.6 | 0.9 | -4.6 | 39.2 | 27.7 |
| LOST CHARGE | 1.9 | -35.5 | 47.3 | 43.9 | 4.6 | -54.3 | 43.7 | 122.8 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 6.5 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +21.9 | 0.0 | 16.4 | 1.1 | +13.3 | 0.0 | 28.6 |
| MANOEUVRE | - | - | - | - | 0.4 | +1.6 | 0.0 | 4.0 |
| MARCH CHECK | 0.9 | +84.4 | 0.0 | 0.0 | 0.3 | +38.7 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.5 | +54.8 | 0.0 | 54.0 |
| MARCH OVER CASTS | 0.2 | +8.7 | 0.0 | 0.0 | 0.1 | +9.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.4 | +78.1 | 0.0 | 58.6 | 4.9 | +95.0 | 0.0 | 134.7 |
| MISSILES IN THE MOVE | 5.3 | +383.5 | 0.0 | 0.0 | 3.0 | +36.5 | 0.0 | 92.0 |
| MISSILES NEXT TURN | 5.2 | +245.8 | 0.0 | 0.0 | 3.0 | +30.7 | 0.0 | 69.8 |
| MOVE AND CAST | 0.2 | +14.4 | 0.0 | 0.0 | 0.3 | +3.4 | 0.0 | 15.8 |
| MOVE SPELL IN RANGE | 0.3 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -248.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.4 | +89.4 | 44.2 | 16.4 | 3.6 | +355.9 | 63.9 | 86.7 |
| MOVES UNITS SPELL | 0.2 | +11.0 | 0.0 | 0.0 | 0.2 | +5.9 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +32.9 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -24.1 | 63.2 | 0.0 | 0.1 | -4.7 | 23.9 | 0.0 |
| NOT TURNED | 4.1 | +69.2 | 0.0 | 107.9 | 5.7 | +125.3 | 0.0 | 132.0 |
| NOT WORTH A CAST | 1.5 | -2.4 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -779.0 | 0.0 | 164.6 | 14.8 | -697.5 | 0.0 | 221.6 |
| ONE FIGHT FORMULA | 6.5 | -92.9 | 35.1 | 82.1 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.2 | -100.5 | 0.0 | 22.1 | - | - | - | - |
| OPENS A LANE | - | - | - | - | 0.1 | +0.2 | 6.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +11.0 | 23.5 | 8.5 | 0.4 | +10.3 | 5.2 | 94.6 |
| PATHS CROSS | 2.1 | +162.7 | 0.0 | 8.5 | 2.9 | +195.9 | 0.0 | 41.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +9.9 | 0.0 | 54.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 34.3 | +1005.7 | 1261.7 | 673.5 | 40.8 | +1065.0 | 1287.3 | 949.6 |
| PURSUES BIG PREY | 0.2 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.3 | +26.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +43.8 | 0.0 | 34.0 | 1.8 | +6.1 | 0.0 | 35.5 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.6 | -30.1 | 6.5 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.6 | -68.4 | 0.0 | 22.5 | 0.3 | -16.6 | 0.0 | 5.5 |
| REDIRECT COUNTER | 3.6 | +272.6 | 0.0 | 55.5 | 4.4 | +168.4 | 0.0 | 35.7 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 22.2 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 59.9 |
| RESERVE FALL BACK | 0.7 | +20.7 | 0.0 | 0.0 | 0.7 | +18.3 | 0.0 | 15.8 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.2 | +11.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +12.7 | 83.5 | 87.3 | 2.2 | -48.9 | 113.6 | 123.5 |
| RISK ONCE | 2.4 | +19.1 | 0.0 | 35.9 | - | - | - | - |
| SAFER THAN THE JOB | 0.8 | +44.1 | 0.0 | 23.9 | 1.1 | +66.2 | 0.0 | 12.5 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.4 | +0.7 | 0.0 | 3.4 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 3.4 |
| SCREEN BY WHAT IT SAVES | 0.2 | -32.6 | 0.0 | 5.5 | 0.1 | -4.6 | 0.0 | 0.0 |
| SEARCH SPOT | 1.7 | +56.7 | 0.0 | 13.0 | 3.3 | +185.5 | 0.0 | 14.0 |
| SELF MOVE SPELL | - | - | - | - | 0.2 | -0.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +43.0 | 0.0 | 21.6 | 1.9 | +176.9 | 0.0 | 100.4 |
| SET-UP ANY TARGET | 1.0 | +125.5 | 0.0 | 0.0 | 0.1 | +5.2 | 0.0 | 27.4 |
| SHOOTER COUNTED ONCE | 0.2 | -0.1 | 0.0 | 5.5 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.4 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +91.1 | 44.2 | 6.5 | 0.7 | +13.2 | 0.0 | 13.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 56.9 | 9.5 | 0.4 | +0.0 | 23.7 | 11.4 |
| SHOTS IN THE MOVE | 11.6 | +307.5 | 0.0 | 112.4 | 13.5 | +516.7 | 0.0 | 149.2 |
| SPELL SETS UP CHARGE | 1.1 | +173.2 | 0.0 | 0.0 | 0.2 | +94.1 | 0.0 | 27.4 |
| SPELL WORTH | 0.9 | +4.0 | 76.7 | 58.0 | 2.1 | +67.3 | 108.0 | 108.0 |
| SPELLS IN THE FIGHT | 0.1 | +2.8 | 22.2 | 0.0 | 0.4 | -25.0 | 0.0 | 43.2 |
| STABLE ROLE | 10.0 | +0.0 | 281.5 | 81.7 | 13.1 | +0.0 | 246.9 | 150.1 |
| STAY WEIGHED | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.1 | +4.2 | 0.0 | 0.0 | 0.1 | +2.7 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 17.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 3.9 | -41.2 | 194.6 | 36.2 | 8.7 | -57.0 | 274.3 | 123.1 |
| SUPPORTS | 2.8 | +41.2 | 104.5 | 31.0 | 7.1 | +57.0 | 194.7 | 105.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -6.4 | 0.0 | 0.0 | 0.2 | -1.9 | 6.5 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.4 | 0.0 | 0.0 | 1.0 | -5.9 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.4 | +25.8 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -9.3 | 25.5 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.6 | +0.8 | 0.0 | 10.4 | 0.2 | +0.2 | 0.0 | 23.4 |
| WAIT AFTER COSTS | 6.1 | -227.6 | 215.4 | 16.4 | 7.8 | -410.9 | 121.6 | 105.2 |
| WALKS TO THE FIGHT | 2.4 | +29.3 | 89.1 | 0.0 | 1.2 | +23.8 | 6.5 | 12.5 |
| WAR ENGINE CHARGES | - | - | - | - | 0.1 | +1.8 | 5.5 | 0.0 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 43.5 | 19.5 | 1.3 | +0.0 | 12.0 | 0.0 |
| WEARS DOWN | 0.9 | +38.1 | 85.1 | 27.4 | 1.3 | +100.8 | 30.4 | 112.6 |
| WHO HITS BACK | 0.3 | +10.1 | 0.0 | 9.1 | 0.1 | +6.5 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +6.3 | 14.3 | 23.7 |
| WHOLE FIGHT GAIN | 0.2 | +34.4 | 9.2 | 0.0 | 0.2 | +51.8 | 30.4 | 0.0 |
| WIDER SPREAD | 1.9 | -7.9 | 158.3 | 28.7 | 2.6 | -11.2 | 75.5 | 87.4 |

### Rule changes: os-h2h-mine-779e261-p1a

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 304 | 304 | 304 | 30.40 | -14765 | -48.6 |
| PATHS CROSS | 50 | 50 | 50 | 5.00 | +3586 | +71.7 |
| SEARCH SPOT | 50 | 50 | 50 | 5.00 | +2422 | +48.4 |
| BEST FIRST | 47 | 47 | 47 | 4.70 | +2260 | +48.1 |
| SUPPORTS | 99 | 99 | 38 | 3.80 | +363 | +9.6 |
| FACES THE THREAT | 28 | 28 | 28 | 2.80 | +1478 | +52.8 |
| ARTILLERY RE-ROLL WEIGHED | 27 | 27 | 27 | 2.70 | +0 | +0.0 |
| WAIT AFTER COSTS | 139 | 139 | 27 | 2.70 | +254 | +9.4 |
| CANNON PLANNED TARGET | 90 | 90 | 25 | 2.50 | -873 | -34.9 |
| KILLS COUNT NEXT TURN | 88 | 88 | 24 | 2.40 | +918 | +38.3 |
| MOVE TO CHARGE | 60 | 60 | 23 | 2.30 | +1843 | +80.1 |
| COUNTER-CHARGE COVER | 86 | 52 | 22 | 2.20 | +752 | +34.2 |
| REDIRECT COUNTER | 80 | 50 | 22 | 2.20 | +1773 | +80.6 |
| SHOTS IN THE MOVE | 251 | 185 | 22 | 2.20 | +760 | +34.5 |
| FALLBACK BY WORTH | 93 | 93 | 20 | 2.00 | +797 | +39.8 |
| WALKS TO THE FIGHT | 36 | 36 | 20 | 2.00 | +185 | +9.3 |
| SAFER THAN THE JOB | 19 | 19 | 19 | 1.90 | +1103 | +58.1 |
| ADVANCE LANE KEPT | 18 | 18 | 18 | 1.80 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 1.70 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 17 | 17 | 17 | 1.70 | +1613 | +94.9 |
| ADVANCE WORTH | 44 | 44 | 14 | 1.40 | +178 | +12.7 |
| BEST FACING | 14 | 14 | 14 | 1.40 | +397 | +28.4 |
| RESERVE FALL BACK | 14 | 14 | 14 | 1.40 | +390 | +27.9 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 1.30 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 13 | 1.30 | +499 | +38.4 |
| CHAFF IN THE MOVE | 17 | 17 | 12 | 1.20 | +518 | +43.1 |
| COVER ONCE | 44 | 27 | 12 | 1.20 | +481 | +40.1 |
| MARCH CHECK | 12 | 12 | 12 | 1.20 | +1451 | +120.9 |
| MISSILES IN THE MOVE | 83 | 48 | 12 | 1.20 | +601 | +50.1 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 12 | 1.20 | +363 | +30.3 |
| CASTING BLOCK | 20 | 20 | 11 | 1.10 | +946 | +86.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 1.00 | +942 | +94.2 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 1.00 | +0 | +0.0 |
| SET UP TOGETHER | 32 | 25 | 10 | 1.00 | +1227 | +122.7 |
| WAR ENGINE JOBS | 22 | 22 | 10 | 1.00 | -735 | -73.5 |
| SCOUT WAITS | 9 | 9 | 9 | 0.90 | +0 | +0.0 |
| SHOT REPLANNED | 9 | 9 | 9 | 0.90 | +0 | +0.0 |
| BEST OVERALL | 8 | 8 | 8 | 0.80 | +656 | +82.0 |
| BLOCKED WHEEL | 8 | 8 | 8 | 0.80 | +267 | +33.4 |
| MAX FOR POSITIONING | 103 | 56 | 8 | 0.80 | +21 | +2.6 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.80 | +14 | +1.8 |
| BEST PREY | 21 | 21 | 7 | 0.70 | +184 | +26.3 |
| COMBAT PIVOT | 7 | 7 | 7 | 0.70 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 7 | 7 | 7 | 0.70 | +342 | +48.9 |
| CHARGE NOW FIRST | 34 | 34 | 6 | 0.60 | -314 | -52.3 |
| ONE FIGHT FORMULA | 65 | 33 | 6 | 0.60 | +17 | +2.9 |
| CHARGE NOW WEIGHED | 5 | 5 | 5 | 0.50 | +149 | +29.8 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.50 | +224 | +44.8 |
| MARCH ODDS | 5 | 5 | 5 | 0.50 | +133 | +26.7 |
| MOVE AND CAST | 5 | 5 | 5 | 0.50 | +178 | +35.6 |
| RISK ONCE | 24 | 20 | 5 | 0.50 | +30 | +6.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.40 | -151 | -37.8 |
| LOST CHARGE | 65 | 65 | 4 | 0.40 | +281 | +70.4 |
| MANOEUVRE | 4 | 4 | 4 | 0.40 | +16 | +4.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.40 | +170 | +42.4 |
| SURE REACH TOGETHER | 13 | 9 | 4 | 0.40 | +7 | +1.9 |
| WHO HITS BACK | 4 | 4 | 4 | 0.40 | +123 | +30.7 |
| WHOLE FIGHT GAIN | 4 | 4 | 4 | 0.40 | +368 | +92.0 |
| CAST JOB | 12 | 12 | 3 | 0.30 | +135 | +45.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| INVITES THE FIGHT | 29 | 29 | 3 | 0.30 | +18 | +5.8 |
| KILLS COUNT | 23 | 23 | 3 | 0.30 | +387 | +128.9 |
| MISSILES NEXT TURN | 82 | 48 | 3 | 0.30 | +55 | +18.5 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.30 | +6 | +2.0 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 0.30 | +13 | +4.4 |
| RISK BY ARC | 38 | 37 | 3 | 0.30 | +79 | +26.3 |
| STUCK PIVOT | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.30 | -83 | -27.7 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.20 | -196 | -97.8 |
| KEEPS ITS TARGET | 27 | 27 | 2 | 0.20 | +25 | +12.6 |
| MAKE SURE TOGETHER | 17 | 10 | 2 | 0.20 | +18 | +9.0 |
| ONE OBJECTIVE FORMULA | 22 | 9 | 2 | 0.20 | +177 | +88.4 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.20 | -82 | -41.1 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.20 | +117 | +58.7 |
| STOPS SHORT OF THE FLANK | 2 | 2 | 2 | 0.20 | +68 | +34.2 |
| WEARS DOWN | 22 | 21 | 2 | 0.20 | +178 | +89.0 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.10 | -64 | -63.9 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.10 | +160 | +160.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.10 | +59 | +59.3 |
| HONEST WORTH | 138 | 138 | 1 | 0.10 | +8 | +8.2 |
| IDLE COST | 127 | 66 | 1 | 0.10 | +4 | +4.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.10 | +268 | +267.6 |
| OVERRUNS AWAY | 8 | 8 | 1 | 0.10 | +8 | +8.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.10 | +99 | +99.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.10 | -9 | -9.3 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.10 | -0 | -0.3 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| STAY WEIGHED | 1 | 1 | 1 | 0.10 | +30 | +29.7 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 23 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 11 | 11 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 103 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 1 | 1 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 10 | not checked | - | - | - | - |
| LONG SHOT | 15 | 15 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 4 | 4 | 0 | 0.00 | - | - |
| NOT TURNED | 98 | 98 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 22 | not checked | - | - | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 751 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 19 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 2 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 30 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| STABLE ROLE | 231 | 231 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 126 | 126 | 0 | 0.00 | - | - |
| TURN WORTH | 2 | 2 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 45 | 44 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p1a

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.80 | 13.30 | 47.3 |
| FALLBACK | gate | 0.30 | 0.70 | 49.9 |
| WAR ENGINE JOBS | rule | 0.60 | 0.40 | 73.5 |
| CHARGE NOW FIRST | rule | 0.20 | 0.40 | 52.3 |
| TURN GATE | gate | 0.40 | 0.20 | 94.4 |
| CANNON PLANNED TARGET | rule | - | 0.50 | 176.7 |
| BEST PRIZE | rule | 0.20 | 0.20 | 37.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.10 | 0.20 | 27.7 |
| CHARGE NOW WEIGHED | rule | 0.10 | 0.10 | 18.9 |
| CHARIOT NO STATIC JOB | rule | 0.10 | 0.10 | 97.8 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.20 | 54.2 |
| PATHS CROSS | rule | 0.10 | 0.10 | 29.5 |
| PURSUES BIG PREY | rule | 0.20 | - | 41.1 |
| SUPPORT REQUEST | gate | - | 0.20 | 125.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.10 | 13.2 |
| BLOCKED WHEEL | rule | - | 0.10 | 48.1 |
| CATCH ODDS | rule | - | 0.10 | 63.9 |
| NO REASON | gate | 0.10 | - | 3.4 |
| PIVOT GUARDS FLANK | rule | - | 0.10 | 9.3 |
| RULE SWITCHED OFF | gate | - | 0.10 | 22.9 |

### Plans: os-h2h-mine-779e261-p1a

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 8.1 | 17% | 251 | 196 | 78% |
| Mine | charge | 2.3 | 52% | 221 | 153 | 69% |
| Mine | close in | 3.4 | 24% | 112 | 62 | 55% |
| Mine | hold | 5.8 | 47% | 428 | 0 | 0% |
| Mine | join | 0.8 | 100% | 23 | 0 | 0% |
| Mine | shoot | 9.6 | 54% | 386 | 596 | 154% |
| Mine | support | 4.3 | 86% | 27 | 0 | 0% |
| Opponent | advance | 14.4 | 15% | 294 | 351 | 120% |
| Opponent | charge | 3.1 | 48% | 229 | 225 | 98% |
| Opponent | close in | 4.5 | 13% | 331 | 47 | 14% |
| Opponent | hold | 3.6 | 31% | 278 | 0 | 0% |
| Opponent | join | 0.5 | 80% | 22 | 0 | 0% |
| Opponent | shoot | 7.4 | 65% | 136 | 443 | 325% |
| Opponent | support | 7.3 | 88% | 25 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p1a

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 50 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 63 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 170 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: os-h2h-mine-779e261-p1a

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.6 | 39% | 50% | 0% | - | 36% | 0% | 7% | 57% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.6 | 16% | 57% | 7% | 100% | 31% | 15% | 0% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 23% | 80% | 10% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p1a

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 6 (9) | 0 | 6 | 69 | 78% | 1.5 | 0 (3) | 10 (4) | 0 (2) | 0 (7) | 17 (2) |
| Mine | Character | 46 | 38 (46) | 38 | 0 | 27 | 17% | 2.2 | 35 (4) | 43 (31) | 27 (8) | 25 (17) | 46 (26) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast Hammer | 10 | 63 (10) | 63 | 0 | 66 | 20% | 3.2 | 18 (3) | 16 (4) | 152 (3) | 69 (8) | 33 (2) |
| Mine | Hammer | 26 | 55 (26) | 36 | 19 | 25 | 15% | 2.6 | 306 (1) | 44 (19) | 30 (6) | 70 (17) | 35 (9) |
| Mine | Holder | 12 | 116 (12) | 4 | 112 | 14 | 58% | 4.6 | 188 (3) | 100 (4) | 85 (5) | 114 (7) | 120 (5) |
| Mine | Shooter | 7 | 127 (7) | 25 | 102 | 52 | 0% | 1.9 | 82 (1) | 139 (6) | - | 171 (5) | 0 (2) |
| Mine | War machine | 14 | 11 (14) | 11 | 0 | 28 | 0% | 1.1 | 0 (4) | 18 (8) | 0 (2) | - | 11 (14) |
| Mine | Wizard | 5 | 19 (5) | 19 | 0 | 0 | 20% | 5.0 | - | 11 (4) | 55 (1) | - | 19 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 21 | 25 (21) | 15 | 11 | 54 | 48% | 2.9 | 36 (10) | 0 (4) | 22 (7) | 29 (17) | 12 (4) |
| Opponent | Character | 32 | 30 (32) | 30 | 0 | 52 | 19% | 2.5 | 83 (9) | 8 (17) | - | 19 (17) | 64 (9) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 37 | 33% | 3.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 10 | 47 (10) | 27 | 21 | 33 | 40% | 1.8 | 65 (5) | 0 (3) | 0 (2) | 17 (7) | 96 (3) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 67% | 2.0 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Opponent | Hammer | 31 | 39 (31) | 33 | 6 | 34 | 19% | 2.6 | 12 (5) | 46 (23) | 20 (3) | 27 (23) | 77 (8) |
| Opponent | Holder | 7 | 93 (7) | 0 | 93 | 36 | 71% | 3.0 | 0 (2) | 159 (2) | 68 (2) | 22 (5) | 298 (1) |
| Opponent | Shooter | 8 | 93 (8) | 11 | 82 | 20 | 0% | 1.2 | 0 (2) | 127 (5) | 79 (1) | 87 (4) | 100 (4) |
| Opponent | War machine | 9 | 51 (9) | 51 | 0 | 59 | 0% | 1.2 | 0 (5) | 114 (4) | - | 73 (2) | 42 (7) |
| Opponent | Wizard | 6 | 12 (6) | 12 | 0 | 16 | 0% | 2.8 | 19 (3) | 0 (2) | - | 14 (5) | - |

### Charged fights: os-h2h-mine-779e261-p1a

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 173 | 74 | 1.8 | 1.1 | 41 | 21 | +20 | 0 of 9 | 6 of 9 | -52 | +29 |
| Mine | Chaos Dwarfs | 3 | 78 | 668 | 3.0 | 1.1 | 223 | 0 | +223 | 6 of 9 | 5 of 9 | +750 | +157 |
| Mine | Dwarfen Mountain Holds | 2 | 242 | 30 | 1.0 | 1.0 | 30 | 0 | +30 | 0 of 2 | 2 of 2 | - | +30 |
| **Mine** | all armies | 10 | 158 | 243 | 2.0 | 1.1 | 122 | 9 | +112 | 6 of 20 | 13 of 20 | +349 | +86 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 2.0 | 1.5 | 65 | 0 | +65 | 1 of 2 | 2 of 2 | +130 | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 955 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 255 | 0 | 2.0 | 1.0 | 0 | 132 | -132 | 1 of 2 | 1 of 2 | - | -132 |
| Opponent | Ogre Kingdoms | 2 | 52 | 132 | 4.0 | 1.0 | 33 | 4 | +29 | 0 of 8 | 5 of 8 | - | +29 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 760 | 5.0 | 1.6 | 152 | 104 | +48 | 3 of 5 | 4 of 5 | +110 | +7 |
| Opponent | Skaven | 1 | 65 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 65 | 1537 | 3.0 | 1.3 | 512 | 0 | +512 | 2 of 3 | 3 of 3 | +808 | +364 |
| Opponent | Wood Elf Realms | 2 | 28 | 434 | 4.0 | 1.1 | 109 | 90 | +18 | 3 of 8 | 4 of 8 | -264 | +58 |
| **Opponent** | all armies | 10 | 150 | 356 | 2.9 | 1.2 | 123 | 53 | +70 | 10 of 29 | 19 of 29 | +179 | +47 |

### Effective charges: os-h2h-mine-779e261-p1a

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net -68) | 0 | 1 (net +0) | 4 (net +44) | 0 | 0 | 2 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 9 | 2 (net +263) | 1 (net +210) | 0 | 0 | 0 | 5 (net +230) | 1 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +65) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 2 (net +48) | 3 (net +57) | 0 | 1 (net +0) | 2 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 1 (net +219) | 0 | 0 | 1 (net +245) | 2 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 0 | 0 | 1 (net +808) | 1 (net +729) | 1 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 8 | 2 (net -20) | 0 | 4 (net -12) | 1 (net +65) | 0 | 1 (net +170) | 0 | 50% (4 of 8) |

### Charged fights, damage counted: os-h2h-mine-779e261-p1a

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 201 | 190 | +78 | 116 | 27 | +88 | +43.8 |
| Mine | 50-54% | 1 | 339 | 222 | +210 | 321 | 0 | +321 | +94.7 |
| Mine | Effective (55-75%) | 1 | 85 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 4 | 82 | 102 | +44 | 74 | 13 | +61 | +74.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 274 | 166 | +202 | 203 | 15 | +188 | +68.5 |
| Mine | No odds | 3 | 308 | 127 | +86 | 91 | 0 | +91 | +29.6 |
| Mine | All fights | 20 | 216 | 154 | +112 | 134 | 14 | +120 | +55.6 |
| Opponent | Long shot (under 50%) | 3 | 401 | 301 | -13 | 95 | 42 | +53 | +13.3 |
| Opponent | Effective (55-75%) | 8 | 301 | 170 | -0 | 148 | 151 | -2 | -0.8 |
| Opponent | 76-89% | 5 | 153 | 92 | +47 | 57 | 24 | +34 | +22.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 225 | 162 | +212 | 262 | 48 | +214 | +94.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 813 | 239 | +808 | 808 | 49 | +759 | +93.4 |
| Opponent | No odds | 6 | 179 | 115 | -43 | 26 | 69 | -43 | -24.0 |
| Opponent | All fights | 29 | 263 | 160 | +70 | 148 | 76 | +72 | +27.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p1a | move | 86 | 27 (31%) | 18 (21%) | 6 (7%) | 53 (62%) |
| os-h2h-mine-779e261-p1a | objective | 80 | 16 (20%) | 11 (14%) | 9 (11%) | 55 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524 |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Invocation of Nehek | Opponent | L0524 |
| Periapt of Soul Exchange | Opponent | L0421 |
| Ring of Doom | Mine | L0218, L0235 |
| Ring of Doom | Opponent | L0102 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

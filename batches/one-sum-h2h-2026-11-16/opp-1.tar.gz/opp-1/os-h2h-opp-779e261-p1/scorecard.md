# Doctrine scorecard: os-h2h-opp-779e261-p1

### Scorecard: os-h2h-opp-779e261-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 11 | 4 | 0 | 1 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 5 | 3 | 2 | 5 | 0 | 0 | 0 | 302 |
| L0135 | 3 | 1 | Mine | no | 2 | 4 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 110 |
| L0319 | 1 | 1 | Mine | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 954 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 633 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 7 | 2 | 3 | 1 | 1 | 0 | 0 | 497 |
| L0717 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 7 | 1 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 8 | 4 | 4 | 3 | 0 | 0 | 0 | 236 |
| L0823 | 1 | 1 | Mine | no | 4 | 2 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 315 |
| L0913 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 641 |
| L0913 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 3 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 3 | - | 2 | 1 | 1 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 60 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 72 |
| L1723 | 1 | 1 | Opponent | yes | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 6 | 3 | 1 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 6 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 0 | - | 2 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 3 | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 290 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 2 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | - | 2 | 4 | 0 | 0 | 0 | 480 |
| L2531 | 5 | 1 | Opponent | no | - | 3 | 0 | 4 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 2 | 1 | 5 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 15% | 2.6 | 2.7 | 2.4 | 1.0 | 0.3 | 0.0 | 0.0 | 267.1 |
| **Average** | | | Opponent | 18% | 2.2 | 2.3 | 3.1 | 2.0 | 0.5 | 0.0 | 0.0 | 164.1 |

### KPIs: os-h2h-opp-779e261-p1

Rules off - Mine only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (49 of 175) | 3% (5 of 177) | 15% (54 of 352) |
| Winner chose to follow up after the loser gave ground |  | 100% (61 of 61); on the table 100% | 100% (52 of 52); on the table 100% | 100% (113 of 113); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (9 of 9); on the table 100% | 82% (9 of 11); on the table 91% | 90% (18 of 20); on the table 95% |
| Winner chose to pursue after the loser fled |  | 70% (16 of 23); on the table 74% | 77% (20 of 26); on the table 85% | 73% (36 of 49); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 92% (86 of 93); on the table 94% | 91% (81 of 89); on the table 94% | 92% (167 of 182); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 39% (130 of 330) | 33% (69 of 210) | 37% (199 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (130 of 253) | 45% (63 of 141) | 49% (193 of 394) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (20 of 32) | 59% (32 of 54) | 60% (52 of 86) |
| Points that never fought | lower | 38% (27409 of 71484) | 43% (30722 of 71889) | 41% (58131 of 143373) |
|   infantry points that never fought | lower | 46% (7798 of 16863) | 57% (7636 of 13348) | 51% (15434 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (146 of 279) | 61% (180 of 295) | 57% (326 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.9 uses a game | 80% (16 of 20); 1.6 uses a game | 81% (34 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 54% (13 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 50% (6 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (28231 of 59666) | 57% (35994 of 62699) | 52% (64225 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (39%) | 1.2 (30%) | 3.4 (35%) |
| MARCHED: its unit marched | 0.8 (14%) | 0.4 (11%) | 1.2 (13%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.1 (1%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 1.4 (26%) | 0.6 (15%) | 2.0 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.5 (12%) | 0.5 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.5 (9%) | 1.0 (26%) | 1.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.2 | 1.4 | 5.5 | 0.7 | 1.4 |
| not cast | 3.6 | 3.0 | 3.3 | 9.5 | 1.7 | 22.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.9 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (42%) | 0.4 (11%) | 3.4 (35%) | 0.6 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (13%) | 0.1 (8%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.3 (9%) | 0.4 (12%) | 2.0 (21%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (11%) | 0.5 (15%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.8 (21%) | 0.4 (15%) | 0.8 (24%) | 1.5 (16%) | 0.2 (13%) | 3.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.1 (1%) | 0.3 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (60%) | 0.4 (12%) | 1.2 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.9 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 69% (24 of 35) | 73% (8 of 11) | 70% (32 of 46) |
| the unit moved after it | 67% (16 of 24) | 75% (6 of 8) | 69% (22 of 32) |
| it charged on its next turn | 8% (2 of 24) | 0% (0 of 8) | 6% (2 of 32) |
| the enemy charged it first | 4% (1 of 24) | 25% (2 of 8) | 9% (3 of 32) |
| it fought by the end of its next turn | 8% (2 of 24) | 12% (1 of 8) | 9% (3 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (5 of 24) | 0% (0 of 8) | 16% (5 of 32) |
| none of these (no charge, no fight, no charge escaped) | 62% (15 of 24) | 75% (6 of 8) | 66% (21 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (573 of 894) | 63% (380 of 601) | 64% (953 of 1495) |
|   cavalry | 56% (39 of 70) | 70% (93 of 133) | 65% (132 of 203) |
|   character | 50% (56 of 111) | 36% (40 of 112) | 43% (96 of 223) |
|   chariot | 50% (47 of 94) | 73% (30 of 41) | 57% (77 of 135) |
|   infantry | 60% (181 of 304) | 66% (154 of 235) | 62% (335 of 539) |
|   monster | 69% (25 of 36) | 48% (10 of 21) | 61% (35 of 57) |
|   war machine | 81% (225 of 279) | 90% (53 of 59) | 82% (278 of 338) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (30%) | 1.4 (22%) | 4.0 (27%) |
| CHARGED: it charged | 1.1 (12%) | 1.2 (19%) | 2.2 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.5 (8%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.3 (21%) | 2.9 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.3 (5%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 1.1 (19%) | 2.8 (19%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.2 (3%) | 0.5 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.5 | 1.2 | 80% | 4.3 pts | 24 pts |
| character | 3.1 | 1.1 | 76% | 6.9 pts | 22 pts |
| chariot | 2.1 | 1.4 | 62% | 14.3 pts | 31 pts |
| infantry | 13.7 | 4.6 | 76% | 8.0 pts | 109 pts |
| monster | 1.1 | 0.3 | 80% | 7.2 pts | 8 pts |
| war machine | 7.7 | 5.8 | 63% | 24.1 pts | 186 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 4.9 | 4.4 |
| Charges that made contact a game | 2.7 | 3.3 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.91 declared, 0.68 contact (22 units) | 0.00 declared, 0.00 contact (14 units) | 0.56 declared, 0.42 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 1.33 declared, 0.78 contact (9 units) | 1.07 declared, 0.71 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.32 contact (242 units) | 0.59 declared, 0.40 contact (281 units) | 0.54 declared, 0.36 contact (523 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (42 of 70) | 48% (10 of 21) | 62% (5 of 8) | 58% (57 of 99) |
| Character in a unit | 74% (31 of 42) | 76% (19 of 25) | 67% (2 of 3) | 74% (52 of 70) |
| Character on its own | 84% (38 of 45) | 51% (18 of 35) | 33% (21 of 63) | 54% (77 of 143) |
| Chariot | 50% (8 of 16) | 60% (6 of 10) | - | 54% (14 of 26) |
| Infantry | 51% (45 of 89) | 36% (13 of 36) | 50% (1 of 2) | 46% (59 of 127) |
| Monster | 66% (21 of 32) | 70% (7 of 10) | - | 67% (28 of 42) |
| Monstrous | 55% (6 of 11) | 36% (5 of 14) | - | 44% (11 of 25) |
| War Machines | 68% (28 of 41) | 0% (0 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 75% (9 of 12); on the table 75% | 46% (63 of 138) | 22% | 48% (16 of 33) | 89% (8 of 9); 4.3 uses a game | 100% (3 of 3); 1.0 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (6 of 6); on the table 100% | 25% (6 of 24) | 60% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 88% (7 of 8); on the table 88% | - | 64% | 61% (25 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (15 of 15); on the table 100% | 39% (14 of 36) | 59% | 55% (35 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 95% (20 of 21); on the table 100% | 35% (38 of 108) | 45% | 41% (18 of 44) | 92% (11 of 12); 8.8 uses a game | 100% (1 of 1); 0.8 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 93% (13 of 14); on the table 93% | 27% (8 of 30) | 32% | 53% (26 of 49) | 100% (5 of 5); 3.3 uses a game | 39% (7 of 18); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 33% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (3 of 3); on the table 100% | - | 35% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 90% (9 of 10); on the table 100% | 17% (2 of 12) | 61% | 76% (16 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (11 of 11); on the table 100% | 17% (6 of 36) | 7% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 92% (11 of 12); on the table 92% | 53% (16 of 30) | 40% | 59% (20 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 83% (15 of 18); on the table 89% | 8% (1 of 12) | 29% | 30% (9 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (24 of 26); on the table 96% | 39% (21 of 54) | 42% | 60% (30 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 89% (8 of 9); on the table 89% | 47% (14 of 30) | 35% | 70% (52 of 74) | 100% (4 of 4); 2.4 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 94% (15 of 16); on the table 94% | 33% (10 of 30) | 43% | 62% (41 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-opp-779e261-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (30) | 50% (26) | 47% (56) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.50 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.33 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.19 | 3.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.78 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.97 | 5.17 | 11.14 |

### Quality by phase: os-h2h-opp-779e261-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 52% (61 of 117) | 44% (66 of 151) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (194 of 410) | 55% (129 of 233) |
| Strategy | Close-in objectives charged next turn | 15% (23 of 151) | 12% (29 of 249) |
| Strategy | Support requests answered (helper made contact too) | 40% (6 of 15) | 35% (7 of 20) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (5 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (5 of 9) | 46% (6 of 13) |
| Strategy | Joined characters whose unit fought | 53% (32 of 60) | 45% (19 of 42) |
| Strategy | Lone characters that fought | 74% (64 of 86) | 71% (67 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 267.1 | 164.1 |
| Movement | Fights charged into per game | 2.4 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 71, net +122 | 14 of 96, net +81 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 71, net +29 | 23 of 96, net +116 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 71, net +86 | 4 of 96, net +275 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 71, net +66 | 28 of 96, net +76 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (169 of 381) | 38% (139 of 368) |
| Shooting | Points destroyed by shooting units | 105.2 | 53.3 |
| Shooting | War machine shots | 6.2 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (99 of 225) | 26% (14 of 53) |
| Shooting | Points destroyed by war machines | 84.6 | 24.0 |
| Magic | Magic missiles cast | 2.3 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (28 of 83) | 27% (12 of 45) |
| Magic | Wounds caused by magic missiles | 5.6 | 1.9 |
| Magic | Wounds caused by other spells | 1.2 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 103.8 | 21.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.3 / 0.5 / 0.2 | 1.6 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 313.3 | 351.3 |
| Combat | Points run down | 17.0 | 79.3 |
| Combat | Net points per charged fight, damage counted | +77 | +82 |
| Combat | Net per 100 charger points, damage counted | +27.0 | +34.4 |
| Combat | First round won (charged fights) | 72% | 70% |
| Combat | Net points per charged fight | +74 | +83 |
| Combat | Net points per supported fight / lone fight | +199 / +55 | +56 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 85 | 45 of 113 |
| Game | Points lost | 648.4 | 729.4 |
| Game | VP from objectives | 615.8 | 628.9 |
| Game | Lone holders (player turns) | 2.6 | 2.2 |

- Mine won / drew / lost: 16 / 5 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +60 VP
- The side that went first won 11 of 31 games with a winner
- Points traded per game (both sides' losses): 1378
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-opp-779e261-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.6 | -140.1 | 113.1 | 79.2 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 10.8 | 0.3 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.7 | +6.4 | 0.0 | 0.0 | 0.6 | +3.6 | 0.0 | 3.9 |
| BEST FACING | 0.8 | +19.8 | 0.0 | 16.6 | 0.3 | +12.5 | 0.0 | 0.0 |
| BEST FIRST | 4.6 | +179.5 | 177.8 | 78.2 | 0.8 | +42.4 | 9.5 | 23.4 |
| BEST OVERALL | 0.5 | +53.6 | 0.0 | 14.4 | 0.2 | +11.0 | 0.0 | 0.0 |
| BEST PREY | 0.9 | +49.2 | 38.7 | 18.3 | 0.6 | +35.6 | 27.4 | 8.8 |
| BEST PRIZE | 0.1 | -1.0 | 2.6 | 0.0 | 0.1 | -2.6 | 1.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -0.9 | 0.0 | 10.2 | 0.1 | -0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +2.6 | 0.0 | 10.1 | 0.2 | +0.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.4 | -62.4 | 44.4 | 12.3 | 0.1 | -11.9 | 18.8 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 12.6 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 106.1 | 15.3 | 0.1 | +0.0 | 3.5 | 2.6 |
| CANNON PLANNED TARGET | 4.9 | +126.0 | 365.3 | 65.8 | 1.2 | +40.0 | 85.0 | 21.2 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 12.0 | 3.5 |
| CAST JOB | 0.7 | +30.8 | 85.4 | 19.5 | 0.7 | +10.5 | 28.9 | 23.6 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +77.7 | 33.6 | 19.3 | 0.2 | +3.9 | 19.9 | 4.4 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 33.6 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +4.5 | 0.0 | 15.0 | 0.1 | +0.6 | 0.0 | 3.2 |
| CHAFF IN THE MOVE | - | - | - | - | 1.4 | +79.7 | 0.0 | 36.3 |
| CHAFF PASSED | 0.2 | -0.3 | 5.2 | 4.9 | 0.2 | -0.3 | 0.0 | 10.8 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 199.4 | 60.0 | 2.5 | +0.0 | 202.4 | 57.9 |
| CHARGE NOW WEIGHED | 0.5 | -45.9 | 7.1 | 28.2 | 0.4 | -33.1 | 20.1 | 6.6 |
| CHARGER SLAIN LOST | 0.6 | -17.3 | 42.8 | 24.3 | 0.4 | -5.2 | 37.9 | 15.4 |
| CHARIOT WIZARD CAREFUL | 0.1 | -6.5 | 0.0 | 11.1 | 0.1 | -0.9 | 16.1 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 2.1 | 3.5 |
| COMBAT PIVOT | 0.4 | +0.0 | 20.4 | 37.9 | 0.4 | +0.0 | 13.5 | 37.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 2.1 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +65.5 | 19.4 | 33.6 | 0.2 | +65.5 | 5.9 | 21.1 |
| COUNTER-CHARGE COVER | 10.5 | +946.9 | 0.0 | 175.8 | - | - | - | - |
| COVER ONCE | - | - | - | - | 5.8 | -428.8 | 0.0 | 151.0 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 12.3 | 5.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +5.0 | 11.9 | 9.6 |
| EDGE GIVE GROUND | 0.1 | +3.1 | 11.6 | 5.1 | 0.1 | +5.8 | 18.2 | 10.8 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +115.6 | 0.0 | 51.5 | 1.2 | +57.2 | 0.0 | 19.8 |
| FALLBACK BY WORTH | 4.7 | +40.2 | 0.0 | 58.1 | 4.9 | +46.6 | 0.0 | 72.3 |
| FIGHT LIFT | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.9 | 0.0 | 2.9 | - | - | - | - |
| FLANK NOT WEIGHED | 6.4 | +0.0 | 0.0 | 161.9 | 4.8 | +0.0 | 0.0 | 134.0 |
| FOCUS FIRE | 0.1 | +3.9 | 0.0 | 0.0 | 0.0 | +1.0 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +141.6 | 0.0 | 39.9 | 0.9 | +128.6 | 0.0 | 19.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.9 | 0.0 | 0.0 | 0.2 | +6.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.7 | 1.9 | 7.9 |
| GIVES UP ITS SCREEN | 0.1 | -0.9 | 10.2 | 2.9 | 0.0 | -0.1 | 0.0 | 3.1 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 14.1 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 18.9 | 0.0 | 0.4 | +0.0 | 17.9 | 9.3 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -17.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -133.3 | 442.6 | 135.3 | 10.0 | -182.6 | 419.8 | 204.4 |
| HORN WORTH | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.8 | 3.5 | 0.0 | 0.2 | +10.3 | 0.0 | 12.6 |
| HUNT DROPPED | 0.0 | +0.0 | 3.5 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +19.5 | 0.0 | 0.0 | 0.4 | +14.7 | 0.0 | 5.4 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.1 | 0.0 | 4.5 |
| HUNT RESULT | 0.0 | +0.0 | 3.5 | 0.0 | 0.2 | +0.1 | 0.0 | 3.2 |
| HUNT THE GUNS | 0.0 | +10.7 | 3.5 | 0.0 | 0.2 | +79.9 | 0.0 | 10.6 |
| IDLE COST | - | - | - | - | 18.6 | -280.2 | 0.0 | 265.4 |
| INVITES THE FIGHT | 2.1 | +38.7 | 65.6 | 36.3 | 1.1 | +6.8 | 35.2 | 21.9 |
| JOINT CHARGE PLAN | 0.3 | +20.3 | 0.0 | 12.4 | 0.3 | +21.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.2 | 19.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.6 | +49.2 | 127.9 | 49.1 | 2.1 | +62.5 | 123.2 | 53.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +51.0 | 93.9 | 32.7 | 2.1 | +99.2 | 140.9 | 38.1 |
| KILLS COUNT NEXT TURN | 4.9 | +147.2 | 175.1 | 121.0 | 7.0 | +292.0 | 157.5 | 180.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +12.3 | 8.4 | 0.0 | 0.5 | +16.2 | 3.5 | 23.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.3 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.5 | 24.4 | 6.4 | 0.5 | +2.8 | 10.6 | 1.5 |
| LOST CHARGE | 2.9 | -33.2 | 113.7 | 94.0 | 2.5 | -29.1 | 64.5 | 73.5 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.2 | -22.1 | 0.0 | 14.4 |
| MAKE SURE TOGETHER | 0.6 | +42.6 | 6.8 | 5.4 | 0.9 | +47.4 | 0.0 | 32.8 |
| MANOEUVRE | 0.1 | +2.4 | 0.0 | 0.0 | 0.2 | +5.9 | 0.0 | 3.9 |
| MARCH AT ESCAPER | 0.1 | +4.6 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +14.7 | 0.0 | 2.2 | 0.5 | +23.7 | 0.0 | 10.1 |
| MARCH ODDS | 0.1 | +10.6 | 4.6 | 0.0 | 0.2 | +24.0 | 5.1 | 0.0 |
| MARCH OVER CASTS | 0.4 | +25.4 | 0.0 | 10.6 | 0.2 | +12.3 | 0.0 | 7.0 |
| MAX FOR POSITIONING | 5.1 | +180.4 | 0.0 | 92.9 | 6.6 | +85.9 | 0.0 | 136.8 |
| MISSILES IN THE MOVE | 4.6 | +217.8 | 0.0 | 95.3 | 3.7 | +69.9 | 0.0 | 85.4 |
| MISSILES NEXT TURN | 5.1 | +127.5 | 0.0 | 105.8 | 4.2 | +44.8 | 0.0 | 96.5 |
| MODEL FACING | 0.3 | +79.5 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 7.0 | 0.0 | 0.1 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | 0.4 | +26.2 | 0.0 | 2.2 | 0.4 | +15.0 | 0.0 | 10.0 |
| MOVE SPELL IN RANGE | 0.1 | +6.6 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -93.5 | 0.0 | 19.7 | 0.1 | -1.9 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 19.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +320.5 | 112.2 | 56.5 | 5.3 | +352.8 | 122.4 | 167.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +4.1 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -9.2 | 41.1 | 1.2 | 0.2 | -6.9 | 33.6 | 0.0 |
| NOT TURNED | 6.0 | +133.3 | 0.0 | 153.2 | 5.2 | +84.5 | 0.0 | 129.2 |
| NOT WORTH A CAST | 1.1 | -1.0 | 0.0 | 31.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.3 | -881.7 | 0.0 | 236.0 | 16.2 | -766.3 | 0.9 | 253.4 |
| ONE FIGHT FORMULA | - | - | - | - | 8.9 | -164.6 | 26.2 | 224.8 |
| ONE OBJECTIVE FORMULA | - | - | - | - | 2.0 | -68.5 | 0.0 | 29.1 |
| OPENS A LANE | 0.1 | +0.9 | 16.5 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +10.0 | 12.2 | 0.0 | 0.3 | +20.5 | 18.4 | 7.9 |
| OVERRUNS AWAY | 0.4 | +10.2 | 49.2 | 20.5 | 0.5 | +6.4 | 32.8 | 9.2 |
| PATHS CROSS | 2.2 | +130.1 | 0.0 | 6.5 | 2.7 | +210.6 | 0.0 | 49.5 |
| PERIAPT WORTH | 0.0 | +3.5 | 0.0 | 15.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.1 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 1.4 |
| PLAN RESULT | 37.9 | +1512.3 | 1321.4 | 911.4 | 38.1 | +1002.0 | 1232.9 | 938.7 |
| PURSUES BIG PREY | 0.0 | -2.3 | 0.0 | 0.0 | 0.1 | -2.6 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +2.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +9.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +9.2 | 0.0 | 23.3 | 1.5 | +29.8 | 0.0 | 45.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -10.2 | 0.0 | 4.7 | 0.2 | -7.9 | 7.2 | 14.2 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.1 | 0.0 | 3.4 | 0.9 | -21.7 | 0.0 | 15.9 |
| REDIRECT COUNTER | 1.6 | +92.9 | 0.0 | 37.8 | 3.3 | +272.3 | 0.0 | 41.8 |
| REDIRECT WEIGHED | 0.2 | +0.6 | 5.2 | 3.8 | 0.5 | +3.6 | 2.0 | 8.6 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 6.2 |
| RESERVE FALL BACK | 0.6 | +14.1 | 0.0 | 10.2 | 0.5 | +21.5 | 0.0 | 7.6 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +8.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +65.0 | 186.7 | 69.1 | 2.4 | +85.0 | 176.4 | 71.9 |
| RISK ONCE | - | - | - | - | 5.0 | +278.3 | 13.3 | 263.3 |
| SAFER THAN THE JOB | 0.9 | +65.2 | 0.0 | 10.2 | 0.8 | +35.0 | 0.0 | 1.8 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.6 | 0.0 | 0.9 | 0.3 | -18.2 | 0.0 | 4.0 |
| SEARCH SPOT | 2.1 | +119.1 | 0.0 | 30.3 | 2.7 | +96.3 | 0.0 | 22.9 |
| SELF MOVE SPELL | 0.3 | +26.9 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.4 | +168.2 | 6.8 | 21.3 | 2.0 | +147.0 | 0.0 | 99.8 |
| SET-UP ANY TARGET | 0.3 | +19.5 | 8.2 | 11.2 | 0.1 | +9.7 | 5.9 | 5.9 |
| SET-UP MISSED | 0.1 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 2.5 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +47.3 | 87.1 | 15.4 | 1.1 | +34.3 | 21.4 | 2.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 165.0 | 20.3 | 0.2 | +0.0 | 28.5 | 6.6 |
| SHOTS IN THE MOVE | 15.2 | +583.6 | 0.0 | 248.4 | 9.6 | +271.0 | 0.0 | 142.1 |
| SPELL CATCH ODDS | 0.1 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +49.0 | 19.4 | 22.4 | 0.1 | +53.5 | 5.9 | 5.9 |
| SPELL WORTH | 1.1 | +23.3 | 92.2 | 91.9 | 1.6 | +28.4 | 99.2 | 102.7 |
| SPELLS IN THE FIGHT | 0.5 | -3.9 | 71.5 | 9.4 | 0.4 | -4.0 | 24.0 | 21.8 |
| STABLE ROLE | 11.5 | +0.0 | 387.0 | 189.1 | 11.4 | +0.0 | 254.2 | 163.6 |
| STANDS TO CAST | 0.1 | +18.5 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +0.2 | 0.0 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +9.5 | 0.0 | 24.2 | 0.2 | +6.1 | 0.0 | 3.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.7 | -42.7 | 229.5 | 106.1 | 8.2 | -67.2 | 416.1 | 130.5 |
| SUPPORTS | 3.1 | +46.5 | 113.4 | 70.7 | 5.4 | +69.9 | 235.0 | 54.2 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.3 | 4.4 | 0.0 |
| SURE REACH TOGETHER | 0.7 | -2.7 | 6.6 | 8.2 | 0.8 | -7.5 | 0.0 | 18.9 |
| THROUGH LINE OF FIRE | 0.5 | +8.2 | 0.0 | 0.0 | 0.2 | +9.7 | 0.0 | 8.4 |
| TURN WORTH | 0.2 | -16.1 | 16.9 | 2.4 | 0.3 | -16.2 | 17.1 | 3.2 |
| TWO OR MORE ARRIVE | 0.2 | +2.0 | 0.0 | 3.1 | 0.4 | +3.5 | 0.0 | 8.6 |
| WAIT AFTER COSTS | 7.2 | -378.5 | 254.9 | 118.7 | 8.5 | -421.8 | 209.0 | 217.2 |
| WALKS TO THE FIGHT | 1.7 | +35.5 | 58.9 | 1.4 | 1.0 | +5.5 | 31.5 | 15.0 |
| WAR ENGINE CHARGES | 0.1 | +7.4 | 4.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 27.8 | 5.1 | 0.5 | +0.0 | 6.9 | 15.3 |
| WEARS DOWN | 1.1 | +60.3 | 131.5 | 29.0 | 1.2 | +32.8 | 110.9 | 35.1 |
| WHO HITS BACK | 0.2 | +5.7 | 0.0 | 9.3 | 0.2 | +17.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.0 | +0.0 | 1.7 | 0.0 | 0.4 | +15.0 | 70.9 | 4.6 |
| WHOLE FIGHT GAIN | 0.4 | +27.7 | 29.9 | 4.5 | 0.6 | +22.0 | 41.6 | 7.7 |
| WIDER SPREAD | 2.1 | -9.0 | 182.6 | 55.6 | 2.9 | -6.0 | 216.3 | 86.7 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 4.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |

### Rule changes: os-h2h-opp-779e261-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1170 | 1170 | 1170 | 32.50 | -59327 | -50.7 |
| BEST FIRST | 195 | 195 | 195 | 5.42 | +7990 | +41.0 |
| PATHS CROSS | 176 | 176 | 176 | 4.89 | +12265 | +69.7 |
| SEARCH SPOT | 175 | 175 | 171 | 4.75 | +7776 | +45.5 |
| MOVE TO CHARGE | 301 | 301 | 146 | 4.06 | +9178 | +62.9 |
| KILLS COUNT NEXT TURN | 428 | 428 | 132 | 3.67 | +3715 | +28.1 |
| SUPPORTS | 307 | 307 | 132 | 3.67 | +1634 | +12.4 |
| FACES THE THREAT | 108 | 108 | 108 | 3.00 | +6222 | +57.6 |
| WAIT AFTER COSTS | 565 | 565 | 88 | 2.44 | +1670 | +19.0 |
| COUNTER-CHARGE COVER | 378 | 200 | 86 | 2.39 | +5423 | +63.1 |
| SHOTS IN THE MOVE | 894 | 587 | 82 | 2.28 | +2658 | +32.4 |
| FALLBACK BY WORTH | 346 | 346 | 77 | 2.14 | +3123 | +40.6 |
| FOLLOW UP WEIGHED | 68 | 68 | 68 | 1.89 | +9728 | +143.1 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +3607 | +59.1 |
| MISSILES IN THE MOVE | 299 | 197 | 55 | 1.53 | +1435 | +26.1 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| RISK ONCE | 181 | 141 | 54 | 1.50 | +2283 | +42.3 |
| SET UP TOGETHER | 124 | 109 | 53 | 1.47 | +3935 | +74.2 |
| RANDOM MOVE BY FIGURES | 86 | 86 | 52 | 1.44 | +1404 | +27.0 |
| CANNON PLANNED TARGET | 222 | 222 | 51 | 1.42 | -31 | -0.6 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| REDIRECT COUNTER | 176 | 89 | 49 | 1.36 | +4337 | +88.5 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| WALKS TO THE FIGHT | 95 | 95 | 46 | 1.28 | +630 | +13.7 |
| MAX FOR POSITIONING | 424 | 249 | 45 | 1.25 | +435 | +9.7 |
| COVER ONCE | 207 | 114 | 44 | 1.22 | +751 | +17.1 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 166 | 164 | 42 | 1.17 | +1452 | +34.6 |
| SHOT REPLANNED | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| BEST FACING | 39 | 39 | 39 | 1.08 | +1161 | +29.8 |
| RESERVE FALL BACK | 39 | 39 | 39 | 1.08 | +1280 | +32.8 |
| MARCH CHECK | 40 | 39 | 38 | 1.06 | +2276 | +59.9 |
| SHOOTS FROM THE BEST SPOT | 91 | 91 | 38 | 1.06 | +1343 | +35.3 |
| CHARGE NOW FIRST | 172 | 172 | 37 | 1.03 | -2218 | -59.9 |
| INVITES THE FIGHT | 113 | 113 | 35 | 0.97 | +337 | +9.6 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| ONE FIGHT FORMULA | 322 | 185 | 34 | 0.94 | +126 | +3.7 |
| CHAFF IN THE MOVE | 52 | 50 | 32 | 0.89 | +1240 | +38.7 |
| CHARGE NOW WEIGHED | 32 | 32 | 32 | 0.89 | +2033 | +63.5 |
| MOVE AND CAST | 32 | 32 | 32 | 0.89 | +1482 | +46.3 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| HONEST WORTH | 628 | 628 | 29 | 0.81 | +206 | +7.1 |
| ADVANCE WORTH | 166 | 166 | 28 | 0.78 | +912 | +32.6 |
| BEST OVERALL | 28 | 28 | 28 | 0.78 | +2325 | +83.0 |
| KILLS COUNT | 122 | 120 | 28 | 0.78 | +840 | +30.0 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +102 | +3.8 |
| CAST JOB | 52 | 52 | 26 | 0.72 | +847 | +32.6 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| REDIRECT WEIGHED | 26 | 26 | 26 | 0.72 | +582 | +22.4 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 26 | 26 | 26 | 0.72 | +564 | +21.7 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +642 | +24.7 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| IDLE COST | 668 | 377 | 23 | 0.64 | +214 | +9.3 |
| CASTING BLOCK | 28 | 28 | 20 | 0.56 | +1174 | +58.7 |
| KEEPS ITS TARGET | 134 | 134 | 20 | 0.56 | +293 | +14.6 |
| MAKE SURE TOGETHER | 53 | 39 | 20 | 0.56 | +1315 | +65.7 |
| BEST PREY | 55 | 55 | 19 | 0.53 | +785 | +41.3 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -62 | -3.9 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -22 | -1.5 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +746 | +53.3 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +670 | +47.8 |
| MARCH ODDS | 12 | 12 | 12 | 0.33 | +104 | +8.6 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 36 | 36 | 12 | 0.33 | -495 | -41.3 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +2861 | +260.1 |
| WEARS DOWN | 82 | 82 | 11 | 0.31 | +231 | +21.0 |
| MANOEUVRE | 11 | 11 | 10 | 0.28 | +300 | +30.0 |
| OPENS UP | 18 | 18 | 10 | 0.28 | +365 | +36.5 |
| WHOLE FIGHT GAIN | 33 | 32 | 10 | 0.28 | +381 | +38.1 |
| REFUSING RETIRES | 20 | 20 | 9 | 0.25 | -3 | -0.4 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 194 | 194 | 7 | 0.19 | +93 | +13.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -86 | -12.3 |
| STANDS TO CAST | 6 | 6 | 6 | 0.17 | -205 | -34.1 |
| SURE REACH TOGETHER | 56 | 48 | 6 | 0.17 | +74 | +12.4 |
| WHOLE FIGHT | 16 | 16 | 6 | 0.17 | +397 | +66.2 |
| CATCH ODDS | 5 | 5 | 5 | 0.14 | -65 | -13.1 |
| HUNT IN PAIRS | 32 | 21 | 5 | 0.14 | +183 | +36.5 |
| SUPPORT NARROWED | 466 | 466 | 5 | 0.14 | -68 | -13.6 |
| BACKUP TARGETS | 46 | 21 | 4 | 0.11 | +19 | +4.8 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -141 | -35.2 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| HUNT ADVANCE | 9 | 9 | 4 | 0.11 | +166 | +41.4 |
| JOINT CHARGE PLAN | 20 | 20 | 4 | 0.11 | +350 | +87.4 |
| MISSILES NEXT TURN | 333 | 206 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 33 | 32 | 4 | 0.11 | +32 | +7.9 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +286 | +71.6 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -82 | -20.6 |
| WIDER SPREAD | 179 | 177 | 4 | 0.11 | +43 | +10.9 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +175 | +58.4 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -177 | -58.9 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +33 | +10.9 |
| SPELLS IN THE FIGHT | 33 | 32 | 3 | 0.08 | +20 | +6.8 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +36 | +17.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +26 | +13.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +89 | +44.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +227 | +113.5 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +19 | +18.7 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -154 | -154.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +33 | +32.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +1 | +1.0 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 1 | 0.03 | -1 | -0.8 |
| ONE OBJECTIVE FORMULA | 73 | 37 | 1 | 0.03 | +34 | +34.2 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +82 | +81.5 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +114 | +113.5 |
| REDIRECT BY WHAT IT STOPS | 40 | 40 | 1 | 0.03 | +40 | +40.1 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +16 | +16.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +196 | +196.4 |
| WOUNDED STAYS OUT | 3 | 3 | 1 | 0.03 | -35 | -34.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 20 | 20 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 40 | 40 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 37 | 37 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 9 | 9 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 402 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 6 | 6 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 17 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 34 | not checked | - | - | - | - |
| LONG SHOT | 36 | 35 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 401 | 401 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 52 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2739 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 97 | not checked | - | - | - | - |
| STABLE ROLE | 823 | 822 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 20 | 20 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 24 | 24 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-opp-779e261-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.86 | 14.64 | 52.9 |
| FALLBACK | gate | 0.69 | 0.78 | 37.0 |
| CHARGE NOW FIRST | rule | 0.50 | 0.47 | 63.4 |
| TURN GATE | gate | 0.56 | 0.28 | 25.4 |
| WAR ENGINE JOBS | rule | 0.11 | 0.22 | 41.3 |
| BIG CHARACTER SAFETY | rule | 0.19 | 0.06 | 9.9 |
| FIGHT ORDER BAND | gate | 0.14 | 0.08 | 1.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.19 | 16.5 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 38.2 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.06 | 30.0 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 12.3 |
| AFTERMATH BAND | gate | 0.03 | 0.14 | 1.8 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 3.5 |
| PATHS CROSS | rule | 0.11 | 0.06 | 45.5 |
| BLOCKED WHEEL | rule | 0.08 | 0.06 | 19.5 |
| CATCH ODDS | rule | 0.08 | 0.06 | 13.1 |
| SUPPORT NARROWED | rule | 0.06 | 0.08 | 13.6 |
| BEST PRIZE | rule | 0.06 | 0.06 | 35.2 |
| STANDS TO CAST | rule | 0.11 | - | 64.0 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | - | 7.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 58.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 17.3 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.08 | 27.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 85.2 |
| FACES THE THREAT | rule | 0.06 | - | 4.2 |
| MARCH ODDS | rule | - | 0.06 | 5.3 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 25.1 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 154.0 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 1.3 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 0.8 |
| REDIRECT WEIGHED | rule | - | 0.03 | 9.4 |
| REFUSING RETIRES | rule | 0.03 | - | 1.5 |
| SUPPORT REQUEST | gate | - | 0.03 | 59.9 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 34.9 |

### Plans: os-h2h-opp-779e261-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.0 | 16% | 442 | 324 | 73% |
| Mine | charge | 2.7 | 61% | 264 | 242 | 92% |
| Mine | close in | 4.2 | 28% | 328 | 163 | 50% |
| Mine | hold | 5.0 | 36% | 293 | 0 | 0% |
| Mine | join | 0.6 | 100% | 20 | 0 | 0% |
| Mine | shoot | 9.9 | 61% | 373 | 783 | 210% |
| Mine | support | 3.4 | 85% | 26 | 0 | 0% |
| Opponent | advance | 10.1 | 17% | 152 | 275 | 181% |
| Opponent | charge | 3.9 | 63% | 320 | 344 | 108% |
| Opponent | close in | 6.8 | 23% | 441 | 152 | 34% |
| Opponent | hold | 4.5 | 43% | 296 | 0 | 0% |
| Opponent | join | 1.1 | 98% | 55 | 0 | 0% |
| Opponent | shoot | 5.1 | 53% | 120 | 235 | 196% |
| Opponent | support | 6.6 | 89% | 60 | 0 | 0% |

### Packages: hunt the guns, os-h2h-opp-779e261-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 25 |
| Opponent | 0.2 | 8 | 1 | 14% | 0% | 14% | - | 377 | 0 | 0% | 97 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 92 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 153 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 133 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 246 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.7 | 4 | 1 | 0% | 0% | 33% | - | 223 | 1 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 464 | 0 | 0% | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 588 | 0 | 0% | 77 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 42 |

### Battle groups: os-h2h-opp-779e261-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.5 | 25% | 49% | 11% | 45% | 44% | 7% | 7% | 42% | 0% |
| Mine | REDIRECT COUNTER | 1.6 | 37% | 57% | 0% | - | 48% | 5% | 5% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 22% | 81% | 23% | 50% | 35% | 0% | 5% | 55% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-opp-779e261-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 37 (3) | 37 | 0 | 37 | 67% | 6.0 | 0 (1) | - | 67 (2) | 0 (1) | 46 (2) |
| Mine | Chaff | 37 | 10 (37) | 8 | 1 | 66 | 38% | 2.0 | 24 (16) | 0 (9) | 0 (12) | 16 (24) | 0 (13) |
| Mine | Character | 123 | 48 (123) | 48 | 0 | 28 | 22% | 2.3 | 51 (38) | 52 (62) | 51 (11) | 67 (62) | 35 (49) |
| Mine | Clean-up | 24 | 61 (24) | 25 | 36 | 19 | 33% | 3.3 | 50 (9) | 65 (11) | 100 (4) | 69 (14) | 52 (10) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 47 | 25% | 1.3 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 41 | 30 (41) | 20 | 10 | 49 | 27% | 3.0 | 47 (18) | 13 (12) | 17 (11) | 45 (28) | 4 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 43 (58) | 25 | 17 | 47 | 10% | 2.8 | 37 (10) | 46 (38) | 35 (10) | 55 (34) | 29 (24) |
| Mine | Holder | 25 | 83 (25) | 9 | 74 | 27 | 56% | 2.9 | 93 (7) | 95 (11) | 61 (5) | 89 (9) | 88 (14) |
| Mine | Shooter | 44 | 101 (44) | 36 | 65 | 28 | 2% | 1.8 | 37 (5) | 137 (31) | 27 (8) | 153 (24) | 42 (20) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 80% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 38 | 4% | 1.4 | 74 (13) | 49 (37) | 36 (6) | 27 (11) | 60 (45) |
| Mine | Wizard | 23 | 30 (23) | 30 | 0 | 18 | 13% | 2.5 | 16 (7) | 56 (11) | 0 (2) | 65 (5) | 15 (15) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 66 | 67 (66) | 25 | 42 | 41 | 44% | 2.8 | 94 (28) | 74 (16) | 26 (22) | 75 (48) | 43 (18) |
| Opponent | Character | 114 | 41 (114) | 41 | 0 | 31 | 23% | 2.4 | 66 (42) | 29 (55) | 0 (6) | 44 (70) | 45 (33) |
| Opponent | Clean-up | 16 | 37 (16) | 37 | 0 | 15 | 62% | 2.7 | 43 (5) | 32 (8) | 37 (3) | 19 (8) | 51 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 37 (58) | 19 | 18 | 58 | 28% | 2.6 | 46 (25) | 33 (19) | 21 (14) | 35 (42) | 43 (16) |
| Opponent | Fragile | 10 | 174 (10) | 174 | 0 | 78 | 30% | 2.1 | - | 312 (3) | 0 (3) | 161 (6) | - |
| Opponent | Hammer | 65 | 43 (65) | 33 | 10 | 40 | 25% | 2.7 | 48 (16) | 42 (42) | 30 (7) | 57 (40) | 16 (25) |
| Opponent | Holder | 40 | 55 (40) | 2 | 53 | 25 | 48% | 3.2 | 34 (9) | 78 (22) | 11 (8) | 82 (22) | 22 (17) |
| Opponent | Shooter | 30 | 70 (30) | 17 | 53 | 46 | 13% | 1.2 | 69 (7) | 68 (18) | 80 (5) | 66 (16) | 75 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 61 (13) | 61 | 0 | 58 | 0% | 1.2 | 0 (5) | 98 (5) | 98 (3) | 67 (3) | 60 (10) |
| Opponent | Wizard | 22 | 15 (22) | 15 | 0 | 46 | 9% | 1.6 | 19 (13) | 31 (3) | 0 (3) | 23 (12) | 0 (7) |

### Charged fights: os-h2h-opp-779e261-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 292 | 77 | 1.4 | 1.0 | 55 | 31 | +24 | 1 of 7 | 6 of 7 | - | +24 |
| Mine | Chaos Dwarfs | 3 | 155 | 420 | 2.0 | 1.0 | 210 | 52 | +158 | 3 of 6 | 5 of 6 | - | +158 |
| Mine | Dwarfen Mountain Holds | 4 | 703 | 25 | 1.5 | 1.2 | 17 | 10 | +7 | 1 of 6 | 4 of 6 | +0 | +8 |
| Mine | Empire of Man | 5 | 567 | 99 | 2.0 | 1.0 | 49 | 38 | +11 | 2 of 10 | 7 of 10 | - | +11 |
| Mine | Grand Cathay | 4 | 623 | 424 | 3.2 | 1.2 | 131 | 41 | +90 | 7 of 13 | 9 of 13 | +273 | +35 |
| Mine | High Elf Realms | 4 | 77 | 332 | 2.5 | 1.2 | 133 | 21 | +112 | 4 of 10 | 7 of 10 | +30 | +132 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 286 | 2.0 | 1.0 | 143 | 0 | +143 | 1 of 2 | 1 of 2 | - | +143 |
| Mine | Lizardmen | 1 | 0 | 210 | 4.0 | 1.0 | 52 | 56 | -4 | 1 of 4 | 2 of 4 | - | -4 |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 1 of 3 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 327 | 5.0 | 1.2 | 65 | 22 | +43 | 2 of 5 | 3 of 5 | +195 | +6 |
| Mine | Skaven | 2 | 0 | 198 | 1.5 | 1.0 | 132 | 0 | +132 | 1 of 3 | 3 of 3 | - | +132 |
| Mine | Tomb Kings of Khemri | 2 | 63 | 881 | 5.0 | 1.3 | 176 | 50 | +126 | 3 of 10 | 8 of 10 | +371 | +21 |
| Mine | Vampire Counts | 2 | 0 | 312 | 2.5 | 1.2 | 125 | 0 | +125 | 1 of 5 | 5 of 5 | +0 | +156 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 30 | -30 | 0 of 1 | 0 of 1 | - | -30 |
| **Mine** | all armies | 36 | 294 | 246 | 2.4 | 1.1 | 104 | 30 | +74 | 28 of 85 | 61 of 85 | +199 | +55 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 77 | -77 | 2 of 3 | 0 of 3 | - | -77 |
| Opponent | Dwarfen Mountain Holds | 1 | 375 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 445 | 474 | 1.0 | 1.0 | 474 | 0 | +474 | 1 of 1 | 1 of 1 | - | +474 |
| Opponent | Grand Cathay | 1 | 235 | 470 | 4.0 | 1.0 | 118 | 0 | +118 | 1 of 4 | 3 of 4 | - | +118 |
| Opponent | High Elf Realms | 2 | 166 | 293 | 2.0 | 1.0 | 146 | 0 | +146 | 1 of 4 | 2 of 4 | - | +146 |
| Opponent | Lizardmen | 1 | 326 | 189 | 1.0 | 2.0 | 189 | 0 | +189 | 1 of 1 | 1 of 1 | +189 | - |
| Opponent | Ogre Kingdoms | 2 | 32 | 70 | 3.0 | 1.0 | 23 | 0 | +23 | 1 of 6 | 3 of 6 | - | +23 |
| Opponent | Orc & Goblin Tribes | 2 | 148 | 838 | 5.5 | 1.1 | 152 | 10 | +142 | 4 of 11 | 8 of 11 | +0 | +156 |
| Opponent | Skaven | 2 | 290 | 0 | 0.5 | 1.0 | 0 | 112 | -112 | 1 of 1 | 0 of 1 | - | -112 |
| Opponent | Tomb Kings of Khemri | 4 | 18 | 1088 | 5.2 | 1.1 | 207 | 34 | +173 | 9 of 21 | 17 of 21 | +62 | +185 |
| Opponent | Vampire Counts | 6 | 0 | 425 | 3.8 | 1.1 | 111 | 44 | +66 | 11 of 23 | 16 of 23 | +10 | +72 |
| Opponent | Warriors of Chaos | 7 | 28 | 305 | 2.4 | 1.0 | 126 | 34 | +92 | 8 of 17 | 11 of 17 | - | +92 |
| Opponent | Wood Elf Realms | 6 | 106 | 127 | 3.5 | 1.0 | 36 | 59 | -22 | 5 of 21 | 17 of 21 | - | -22 |
| **Opponent** | all armies | 36 | 99 | 370 | 3.1 | 1.1 | 118 | 35 | +83 | 45 of 113 | 79 of 113 | +56 | +84 |

### Effective charges: os-h2h-opp-779e261-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net -52) | 0 | 0 | 0 | 0 | 2 (net +16) | 4 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 6 | 1 (net +388) | 0 | 0 | 2 (net +342) | 1 (net +145) | 2 (net -134) | 0 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +0) | 0 | 0 | 2 (net -10) | 0 | 2 (net +30) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 10 | 3 (net -127) | 0 | 0 | 3 (net +114) | 1 (net +0) | 2 (net +0) | 1 | 0% (0 of 9) |
| Mine | Grand Cathay | 13 | 2 (net +0) | 0 | 3 (net -71) | 4 (net +220) | 0 | 3 (net +136) | 1 | 25% (3 of 12) |
| Mine | High Elf Realms | 10 | 2 (net +358) | 1 (net +251) | 2 (net +20) | 3 (net -20) | 2 (net +85) | 0 | 0 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +211) | 0 | 0 | 0 | 0 | 1 (net +75) | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 1 (net +90) | 0 | 0 | 0 | 1 (net +60) | 0 | 2 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +195) | 0 | 0 | 0 | 4 | 100% (1 of 1) |
| Mine | Skaven | 3 | 0 | 0 | 1 (net +211) | 0 | 0 | 2 (net +93) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +888) | 0 | 1 (net +0) | 2 (net -200) | 2 (net +113) | 4 (net +136) | 0 | 10% (1 of 10) |
| Mine | Vampire Counts | 5 | 0 | 1 (net +0) | 0 | 3 (net +113) | 0 | 1 (net +285) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 1 | 1 (net -30) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 2 (net -68) | 1 (net -95) | 0 | 0 | 0 | 67% (2 of 3) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +474) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +290) | 0 | 0 | 2 (net +90) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | High Elf Realms | 4 | 2 (net +108) | 0 | 0 | 1 (net +369) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Lizardmen | 1 | 0 | 0 | 0 | 0 | 1 (net +189) | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 6 | 0 | 0 | 1 (net +0) | 1 (net +55) | 0 | 2 (net +42) | 2 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 11 | 2 (net -55) | 0 | 1 (net +442) | 3 (net +202) | 0 | 1 (net +0) | 4 | 14% (1 of 7) |
| Opponent | Skaven | 1 | 1 (net -112) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 21 | 1 (net +175) | 1 (net +0) | 5 (net +151) | 5 (net +167) | 1 (net +175) | 7 (net +216) | 1 | 25% (5 of 20) |
| Opponent | Vampire Counts | 23 | 4 (net +84) | 0 | 6 (net +96) | 3 (net +33) | 1 (net +652) | 7 (net +19) | 2 | 29% (6 of 21) |
| Opponent | Warriors of Chaos | 17 | 2 (net +168) | 0 | 2 (net +447) | 3 (net +134) | 0 | 7 (net +47) | 3 | 14% (2 of 14) |
| Opponent | Wood Elf Realms | 21 | 1 (net +0) | 0 | 5 (net -67) | 7 (net +43) | 1 (net +85) | 3 (net +27) | 4 | 29% (5 of 17) |

### Charged fights, damage counted: os-h2h-opp-779e261-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 309 | 233 | +122 | 187 | 64 | +123 | +39.9 |
| Mine | 50-54% | 2 | 445 | 186 | +126 | 126 | 0 | +126 | +28.2 |
| Mine | Effective (55-75%) | 8 | 232 | 158 | +29 | 134 | 85 | +49 | +21.2 |
| Mine | 76-89% | 19 | 275 | 186 | +93 | 142 | 41 | +101 | +36.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 205 | 145 | +66 | 115 | 26 | +88 | +43.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 495 | 93 | +86 | 90 | 31 | +59 | +12.0 |
| Mine | No odds | 14 | 291 | 119 | +21 | 47 | 50 | -3 | -1.1 |
| Mine | All fights | 85 | 285 | 163 | +74 | 123 | 46 | +77 | +27.0 |
| Opponent | Long shot (under 50%) | 14 | 212 | 262 | +81 | 127 | 64 | +63 | +29.8 |
| Opponent | 50-54% | 1 | 440 | 399 | +0 | 57 | 147 | -90 | -20.4 |
| Opponent | Effective (55-75%) | 23 | 212 | 231 | +116 | 182 | 76 | +106 | +49.8 |
| Opponent | 76-89% | 26 | 232 | 138 | +106 | 144 | 51 | +93 | +40.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 228 | 153 | +76 | 114 | 32 | +82 | +36.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 547 | 140 | +275 | 275 | 24 | +252 | +46.0 |
| Opponent | No odds | 17 | 237 | 223 | -27 | 119 | 102 | +18 | +7.4 |
| Opponent | All fights | 113 | 238 | 191 | +83 | 142 | 60 | +82 | +34.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-opp-779e261-p1 | move | 425 | 96 (23%) | 69 (16%) | 48 (11%) | 281 (66%) |
| os-h2h-opp-779e261-p1 | objective | 400 | 52 (13%) | 39 (10%) | 47 (12%) | 301 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

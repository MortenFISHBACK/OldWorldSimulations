# Doctrine scorecard: os-h2h-mine-779e261-p2

### Scorecard: os-h2h-mine-779e261-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 1 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 12 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 3 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 124 |
| L0409 | 1 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 624 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 3 | 2 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 665 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 593 |
| L0528 | 6 | 1 | Opponent | no | 8 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 2 | 4 | 3 | 1 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0810 | 6 | 1 | Mine | no | 3 | 4 | 1 | 2 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 12 | 2 | 7 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 988 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 1 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 1.9 | 2.9 | 1.9 | 1.5 | 0.1 | 0.0 | 0.0 | 458.1 |
| **Average** | | | Opponent | 29% | 3.6 | 2.4 | 2.4 | 1.8 | 0.4 | 0.0 | 0.0 | 236.1 |

### KPIs: os-h2h-mine-779e261-p2

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 18 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 51% (42 of 83) | 16% (14 of 85) | 33% (56 of 168) |
| Winner chose to follow up after the loser gave ground |  | 100% (37 of 37); on the table 100% | 97% (31 of 32); on the table 97% | 99% (68 of 69); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 77% (10 of 13); on the table 77% | 64% (9 of 14); on the table 71% | 70% (19 of 27); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 92% (47 of 51); on the table 94% | 88% (43 of 49); on the table 90% | 90% (90 of 100); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 40% (77 of 192) | 33% (32 of 96) | 38% (109 of 288) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (77 of 139) | 45% (32 of 71) | 52% (109 of 210) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (9 of 12) | 62% (15 of 24) | 67% (24 of 36) |
| Points that never fought | lower | 44% (15704 of 35590) | 49% (17805 of 35992) | 47% (33509 of 71582) |
|   infantry points that never fought | lower | 46% (4549 of 9891) | 73% (5287 of 7216) | 57% (9836 of 17107) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (94 of 152) | 56% (77 of 138) | 59% (171 of 290) |
| Bound items with a magic missile used (at least once a game) |  | 100% (8 of 8); 1.4 uses a game | 100% (7 of 7); 1.4 uses a game | 100% (15 of 15); 1.4 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.3 uses a game | 50% (1 of 2); 0.1 uses a game | 67% (4 of 6); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (8 of 12); 0.4 uses a game | 17% (1 of 6); 0.1 uses a game | 50% (9 of 18); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (16691 of 28797) | 50% (15182 of 30254) | 54% (31873 of 59051) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (38%) | 0.6 (17%) | 3.1 (31%) |
| MARCHED: its unit marched | 0.9 (15%) | 0.9 (25%) | 1.8 (18%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.3 (9%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.8 (28%) | 0.9 (27%) | 2.7 (27%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.3 (4%) | 0.1 (3%) | 0.4 (4%) |
| GONE: slain | 0.7 (10%) | 0.3 (9%) | 1.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.1 | 1.4 | 6.1 | 0.3 | 2.0 |
| not cast | 2.1 | 2.3 | 2.9 | 9.9 | 2.0 | 15.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.8 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (39%) | 0.4 (15%) | 3.1 (31%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (18%) | 0.5 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (11%) | 0.2 (10%) | 1.0 (34%) | 2.7 (27%) | 0.4 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (16%) | 0.3 (15%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (2%) | 0.4 (4%) | 0.1 (3%) | 0.2 (1%) |
| GONE: slain | 0.0 (0%) | 0.2 (7%) | 0.0 (0%) | 1.0 (10%) | 0.7 (33%) | 1.8 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (5%) | 0.3 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (66%) | 0.2 (10%) | 1.4 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.4 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 56% (10 of 18) | 64% (7 of 11) | 59% (17 of 29) |
| the unit moved after it | 60% (6 of 10) | 100% (7 of 7) | 76% (13 of 17) |
| it charged on its next turn | 0% (0 of 10) | 14% (1 of 7) | 6% (1 of 17) |
| the enemy charged it first | 0% (0 of 10) | 14% (1 of 7) | 6% (1 of 17) |
| it fought by the end of its next turn | 0% (0 of 10) | 14% (1 of 7) | 6% (1 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (1 of 10) | 0% (0 of 7) | 6% (1 of 17) |
| none of these (no charge, no fight, no charge escaped) | 90% (9 of 10) | 86% (6 of 7) | 88% (15 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (386 of 530) | 55% (266 of 485) | 64% (652 of 1015) |
|   cavalry | 60% (26 of 43) | 61% (46 of 76) | 61% (72 of 119) |
|   character | 85% (58 of 68) | 29% (14 of 49) | 62% (72 of 117) |
|   chariot | 51% (35 of 68) | 48% (13 of 27) | 51% (48 of 95) |
|   infantry | 58% (79 of 137) | 53% (104 of 197) | 55% (183 of 334) |
|   monster | 50% (8 of 16) | 50% (8 of 16) | 50% (16 of 32) |
|   war machine | 91% (180 of 198) | 68% (81 of 120) | 82% (261 of 318) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.1 (39%) | 2.3 (19%) | 5.4 (27%) |
| CHARGED: it charged | 0.8 (10%) | 1.9 (16%) | 2.7 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.4 (4%) | 1.1 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.7 (9%) | 2.7 (22%) | 3.4 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (6%) | 1.0 (8%) | 1.4 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.9 (16%) | 3.5 (17%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (4%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (0%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 1.2 (10%) | 1.4 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 2.1 | 75% | 5.5 pts | 32 pts |
| character | 4.1 | 0.8 | 81% | 6.4 pts | 26 pts |
| chariot | 2.7 | 1.7 | 59% | 14.8 pts | 40 pts |
| infantry | 14.1 | 6.6 | 67% | 8.9 pts | 126 pts |
| monster | 1.1 | 0.2 | 85% | 5.9 pts | 7 pts |
| war machine | 14.5 | 9.3 | 65% | 20.4 pts | 296 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 5.6 | 4.3 |
| Charges that made contact a game | 2.2 | 3.8 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.80 declared, 0.70 contact (10 units) | 1.00 declared, 0.56 contact (9 units) | 0.89 declared, 0.63 contact (19 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.80 declared, 0.80 contact (5 units) | 0.80 declared, 0.80 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.28 contact (120 units) | 0.63 declared, 0.42 contact (139 units) | 0.51 declared, 0.36 contact (259 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 38% (9 of 24) | 50% (3 of 6) | 67% (2 of 3) | 42% (14 of 33) |
| Character in a unit | 88% (21 of 24) | 90% (9 of 10) | 100% (1 of 1) | 89% (31 of 35) |
| Character on its own | 78% (14 of 18) | 44% (7 of 16) | 26% (6 of 23) | 47% (27 of 57) |
| Chariot | 67% (4 of 6) | 69% (9 of 13) | - | 68% (13 of 19) |
| Infantry | 45% (19 of 42) | 50% (11 of 22) | 33% (1 of 3) | 46% (31 of 67) |
| Monster | 60% (9 of 15) | 100% (2 of 2) | - | 65% (11 of 17) |
| Monstrous | 33% (1 of 3) | 50% (3 of 6) | - | 44% (4 of 9) |
| War Machines | 75% (38 of 51) | 100% (2 of 2) | - | 75% (40 of 53) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 40% (41 of 102) | 58% | 64% (14 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 93% (14 of 15); on the table 100% | 44% (16 of 36) | 48% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 77% (10 of 13); on the table 77% | - | 48% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 93% (14 of 15); on the table 93% | 42% (20 of 48) | 39% | 62% (47 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 3 | 79% (11 of 14); on the table 86% | 30% (20 of 66) | 48% | 38% (11 of 29) | 100% (7 of 7); 8.7 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 68% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (7 of 7); on the table 100% | 0% (0 of 6) | 64% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 43% | 56% (5 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (2 of 2); on the table 100% | - | 55% | 40% (6 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 92% (11 of 12); on the table 92% | 33% (6 of 18) | 21% | 65% (11 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 50% (1 of 2); on the table 50% | 83% (5 of 6) | 60% | 67% (10 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (5 of 5); on the table 100% | - | 38% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p2, 18 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 31% (11) | 59% (17) | 44% (28) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.61 | 0.94 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.06 | 0.11 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.22 | 0.44 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.56 | 1.06 | 2.61 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 0.89 | 1.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.11 | 4.83 | 9.94 |

### Quality by phase: os-h2h-mine-779e261-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 46% (24 of 52) | 48% (46 of 96) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (93 of 254) | 55% (78 of 143) |
| Strategy | Close-in objectives charged next turn | 18% (9 of 49) | 12% (14 of 120) |
| Strategy | Support requests answered (helper made contact too) | 86% (6 of 7) | 47% (8 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 71% (5 of 7) | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 54% (25 of 46) | 23% (5 of 22) |
| Strategy | Lone characters that fought | 64% (23 of 36) | 67% (28 of 42) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 1.5 | 1.8 |
| Movement | Points that never moved of their own | 458.1 | 236.1 |
| Movement | Fights charged into per game | 2.1 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 36, net +258 | 9 of 49, net -14 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 36, net -44 | 12 of 49, net +25 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 36, net +71 | 4 of 49, net +86 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 of 36, net +112 | 10 of 49, net +93 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.8 | 11.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (112 of 213) | 38% (79 of 209) |
| Shooting | Points destroyed by shooting units | 134.3 | 34.0 |
| Shooting | War machine shots | 10.0 | 4.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (106 of 180) | 47% (38 of 81) |
| Shooting | Points destroyed by war machines | 126.9 | 59.1 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 51% (18 of 35) | 42% (8 of 19) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.8 |
| Magic | Wounds caused by other spells | 0.4 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 47.5 | 82.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.4 / 0.7 / 0.1 | 3.0 / 0.2 / 0.6 / 0.0 |
| Combat | Points destroyed in combat | 258.8 | 253.8 |
| Combat | Points run down | 21.2 | 122.2 |
| Combat | Net points per charged fight, damage counted | +69 | +62 |
| Combat | Net per 100 charger points, damage counted | +25.7 | +21.5 |
| Combat | First round won (charged fights) | 82% | 77% |
| Combat | Net points per charged fight | +63 | +67 |
| Combat | Net points per supported fight / lone fight | +128 / +59 | +75 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 13 of 38 | 25 of 56 |
| Game | Points lost | 674.8 | 598.5 |
| Game | VP from objectives | 474.4 | 792.8 |
| Game | Lone holders (player turns) | 1.9 | 3.6 |

- Mine won / drew / lost: 6 / 1 / 11 of 18 ended games (of 18); mean margin (Mine - Opponent) -350 VP
- The side that went first won 10 of 17 games with a winner
- Points traded per game (both sides' losses): 1273
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-mine-779e261-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 4.6 | -151.4 | 161.0 | 67.2 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 85.8 | 0.4 | +0.0 | 0.0 | 9.2 |
| BACKUP TARGETS | 0.9 | +4.5 | 0.0 | 2.9 | 0.6 | +7.0 | 0.0 | 0.0 |
| BEST FACING | 0.6 | +19.5 | 0.0 | 28.8 | 0.3 | +6.9 | 0.0 | 0.0 |
| BEST FIRST | 1.8 | +94.5 | 40.2 | 28.4 | 4.0 | +108.1 | 123.3 | 52.9 |
| BEST OVERALL | 0.6 | +38.4 | 0.0 | 37.8 | 0.6 | +30.4 | 0.0 | 13.6 |
| BEST PREY | 0.7 | +51.3 | 15.1 | 0.0 | 0.7 | +24.2 | 60.4 | 7.6 |
| BEST PRIZE | 0.1 | -31.1 | 6.9 | 0.0 | 0.1 | -6.8 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -1.3 | 0.0 | 27.8 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | -2.2 | 0.0 | 0.0 | 0.5 | +3.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | +0.6 | 0.0 | 0.0 | 0.4 | -95.0 | 59.1 | 44.1 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 161.0 | 26.4 | 0.2 | +0.0 | 6.9 | 9.2 |
| CANNON PLANNED TARGET | 7.4 | +238.2 | 696.0 | 213.9 | 3.6 | +186.9 | 101.2 | 45.3 |
| CANNON SIGHT KEPT | 1.9 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -9.0 | 7.6 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | +0.0 | 32.1 | 33.3 |
| CAST JOB | 0.9 | +19.1 | 50.2 | 4.7 | 0.4 | +13.5 | 17.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +34.7 | 10.8 | 0.0 | 0.1 | +2.4 | 12.6 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +2.5 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.6 | +35.3 | 0.0 | 13.9 | - | - | - | - |
| CHAFF PASSED | 0.4 | -0.7 | 0.0 | 5.8 | 0.5 | -0.2 | 6.7 | 7.1 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 172.1 | 94.7 | 2.9 | +0.0 | 273.3 | 62.6 |
| CHARGE NOW WEIGHED | 0.6 | -26.0 | 13.2 | 7.6 | 0.9 | -125.6 | 64.1 | 91.0 |
| CHARGER SLAIN LOST | 0.3 | -5.3 | 11.8 | 0.0 | 0.6 | -3.2 | 38.4 | 22.1 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 7.6 | 0.0 | 0.1 | +0.0 | 3.1 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 49.9 | 50.5 | 0.4 | +0.0 | 32.8 | 15.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 33.3 |
| CONVEYANCE SEARCH | 0.8 | +81.9 | 0.0 | 0.0 | 0.3 | +16.6 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | - | - | - | - | 5.9 | +425.5 | 0.0 | 133.7 |
| COVER ONCE | 9.2 | -726.3 | 0.0 | 134.1 | - | - | - | - |
| DEFENSIVE ARMY | 0.7 | +0.0 | 133.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +2.1 | 4.7 | 3.1 |
| EDGE GIVE GROUND | 0.1 | +0.0 | 0.0 | 0.0 | 0.7 | +16.6 | 79.2 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +113.7 | 0.0 | 37.0 | 1.1 | +82.7 | 0.0 | 35.4 |
| FALLBACK BY WORTH | 4.1 | +31.7 | 0.0 | 34.7 | 6.4 | +35.7 | 0.0 | 82.2 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +3.4 | 0.0 | 11.9 | - | - | - | - |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 110.6 | 4.4 | +0.0 | 0.0 | 120.8 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.8 | 3.1 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +229.4 | 0.0 | 39.7 | 0.8 | +103.5 | 0.0 | 42.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +18.7 | 0.0 | 0.0 | 0.2 | +13.8 | 0.0 | 5.8 |
| GIVES UP | - | - | - | - | 0.3 | -3.1 | 34.1 | 0.0 |
| GROUND FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 35.6 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 56.8 | 2.8 |
| HILL BY ITS CHANCE | 0.2 | -18.5 | 0.0 | 0.0 | 0.9 | -122.3 | 0.0 | 7.6 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.5 | -84.2 | 185.3 | 103.3 | 10.2 | -246.9 | 529.4 | 240.1 |
| HUNT ADVANCE | 0.1 | +0.6 | 0.0 | 2.9 | 0.5 | +7.2 | 16.4 | 7.6 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.9 | 0.3 | +0.0 | 16.4 | 7.6 |
| HUNT IN PAIRS | 0.1 | +2.7 | 0.0 | 0.0 | 0.7 | +48.6 | 0.0 | 34.8 |
| HUNT KEPT | - | - | - | - | 0.2 | +1.2 | 9.4 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 2.9 | 0.4 | +23.8 | 21.1 | 7.6 |
| HUNT THE GUNS | 0.1 | +13.5 | 0.0 | 2.9 | 0.6 | +122.2 | 30.3 | 11.2 |
| IDLE COST | 13.7 | -196.9 | 0.0 | 86.3 | - | - | - | - |
| INVITES THE FIGHT | 1.4 | +10.5 | 63.7 | 11.6 | 0.7 | +6.9 | 28.5 | 0.0 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +12.4 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.4 | 16.1 | 0.0 |
| KEEP FALLS | 0.2 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 11.7 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 97.3 | 62.7 | 2.4 | +73.3 | 192.1 | 100.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.1 | +72.9 | 76.7 | 47.2 | 2.4 | +90.7 | 209.8 | 79.4 |
| KILLS COUNT NEXT TURN | 3.7 | +173.1 | 81.7 | 26.0 | 7.4 | +256.9 | 297.5 | 227.3 |
| LONE CHARACTER SAFE SPOT | 0.2 | +3.7 | 0.0 | 0.0 | 0.3 | +24.7 | 25.3 | 9.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 3.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.9 | +59.2 | 0.0 | 0.0 | 0.5 | +42.0 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -7.7 | 20.6 | 17.3 | 0.9 | -0.6 | 56.5 | 5.3 |
| LOST CHARGE | 2.8 | -59.1 | 83.3 | 65.8 | 1.6 | -21.5 | 28.0 | 23.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.2 | +4.9 | 0.0 | 6.2 | 0.4 | +19.6 | 0.0 | 30.5 |
| MANOEUVRE | 0.3 | +19.2 | 0.0 | 4.5 | 0.1 | +12.2 | 0.0 | 3.6 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +12.5 | 0.0 | 0.0 | 0.6 | +26.4 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +11.7 | 5.0 | 0.0 | 0.5 | +43.0 | 51.3 | 0.0 |
| MARCH OVER CASTS | 0.2 | +9.9 | 0.0 | 0.0 | 0.2 | +12.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.2 | +76.5 | 0.0 | 49.4 | 4.4 | +173.4 | 0.0 | 127.3 |
| MISSILES IN THE MOVE | 4.3 | +120.4 | 0.0 | 30.1 | 3.2 | +56.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +82.0 | 0.0 | 30.1 | 3.7 | +39.4 | 0.0 | 21.1 |
| MODEL FACING | 0.7 | +195.8 | 0.0 | 6.7 | 0.6 | +182.5 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +7.5 | 0.0 | 4.7 | 0.1 | +0.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -31.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.1 | +89.0 | 20.8 | 15.3 | 5.6 | +324.9 | 151.9 | 160.2 |
| MOVES UNITS SPELL | 0.1 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -11.4 | 22.7 | 5.3 | 0.3 | -13.9 | 35.5 | 0.0 |
| NOT TURNED | 5.1 | +132.0 | 0.0 | 79.3 | 4.8 | +52.6 | 0.0 | 79.1 |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.3 | -534.1 | 0.0 | 265.9 | 16.9 | -869.2 | 3.1 | 176.1 |
| ONE FIGHT FORMULA | 8.8 | -106.8 | 63.7 | 139.7 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | -88.9 | 0.0 | 29.8 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.1 | 3.6 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +14.2 | 12.4 | 0.0 | 0.3 | +28.5 | 29.2 | 0.0 |
| OVERRUNS AWAY | 0.2 | +22.9 | 15.9 | 0.0 | 0.7 | +25.3 | 42.6 | 17.8 |
| PATHS CROSS | 1.2 | +90.7 | 0.0 | 0.0 | 2.9 | +229.1 | 0.0 | 117.9 |
| PIVOT GUARDS FLANK | 0.1 | -0.2 | 0.0 | 0.0 | 0.1 | -2.5 | 0.0 | 0.0 |
| PLAN RESULT | 36.4 | +1712.8 | 1453.6 | 807.3 | 41.9 | +1229.2 | 1242.1 | 797.2 |
| PURSUES BIG PREY | 0.1 | -10.8 | 0.0 | 0.0 | 0.1 | -9.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +17.5 | 0.0 | 0.0 | 1.3 | +30.3 | 0.0 | 55.6 |
| RANDOM MOVER NO PROMISE | 0.2 | -5.4 | 8.0 | 0.0 | 0.2 | -10.7 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -6.1 | 0.0 | 13.9 | 0.1 | -0.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.6 | +185.3 | 0.0 | 28.1 | 3.3 | +164.1 | 0.0 | 44.6 |
| REDIRECT WEIGHED | 0.1 | -22.0 | 6.9 | 0.0 | 0.7 | +4.1 | 15.6 | 9.3 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 18.4 |
| RESERVE FALL BACK | 0.2 | +4.4 | 0.0 | 6.2 | 1.4 | +34.2 | 0.0 | 11.3 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.2 | +6.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +43.9 | 87.3 | 68.1 | 3.4 | +34.4 | 292.7 | 86.9 |
| RISK ONCE | 5.7 | +141.6 | 23.1 | 168.4 | - | - | - | - |
| SAFER THAN THE JOB | 0.7 | +39.4 | 0.0 | 37.8 | 0.9 | +49.7 | 0.0 | 51.6 |
| SCOUT SPOT | 0.3 | +1.6 | 0.0 | 0.0 | 0.7 | +3.3 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -5.5 | 0.0 | 0.0 | 0.6 | -28.1 | 0.0 | 0.0 |
| SEARCH SPOT | 2.2 | +94.6 | 0.0 | 15.7 | 1.9 | +64.2 | 0.0 | 38.6 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.0 | 4.7 | 3.7 |
| SET UP TOGETHER | 0.3 | +6.4 | 0.0 | 6.2 | 2.9 | +235.1 | 11.6 | 117.9 |
| SET-UP ANY TARGET | 0.2 | +23.8 | 0.0 | 0.0 | 0.1 | +11.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.6 | +1.1 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +27.2 | 48.8 | 4.7 | 0.5 | +6.8 | 15.7 | 3.6 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 277.1 | 26.4 | 0.1 | +0.0 | 6.5 | 0.0 |
| SHOTS IN THE MOVE | 16.6 | +852.0 | 0.0 | 356.7 | 13.9 | +497.5 | 0.0 | 210.6 |
| SPELL SETS UP CHARGE | 0.4 | +94.6 | 0.0 | 0.0 | 0.1 | +11.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +24.6 | 10.8 | 0.0 | 2.2 | +41.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.5 | 28.6 | 15.6 | 0.4 | -0.9 | 15.8 | 10.8 |
| STABLE ROLE | 12.3 | +0.0 | 445.7 | 68.2 | 11.9 | +0.0 | 399.1 | 129.7 |
| STANDS TO CAST | 0.1 | +1.0 | 4.7 | 9.0 | 0.1 | +3.2 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.2 | +3.6 | 18.6 | 3.7 |
| STOPS SHORT OF THE FLANK | 0.2 | +8.5 | 0.0 | 0.0 | 0.3 | +14.5 | 0.0 | 33.9 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 27.8 |
| SUPPORT NARROWED | 6.3 | -65.9 | 257.9 | 107.8 | 6.2 | -37.9 | 247.6 | 33.3 |
| SUPPORTS | 4.2 | +74.8 | 88.2 | 33.9 | 3.7 | +39.9 | 53.7 | 14.0 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.2 | -4.7 | 3.3 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.8 | 0.0 | 3.3 | 1.0 | -2.9 | 0.0 | 19.6 |
| THROUGH LINE OF FIRE | 0.5 | +14.2 | 0.0 | 0.0 | 0.2 | +6.6 | 0.0 | 23.9 |
| TURN WORTH | 0.3 | -22.1 | 37.7 | 13.4 | 0.2 | -7.5 | 11.4 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 3.3 | 0.3 | +1.1 | 0.0 | 6.1 |
| WAIT AFTER COSTS | 4.9 | -179.6 | 94.7 | 44.7 | 7.8 | -381.3 | 252.4 | 163.5 |
| WALKS TO THE FIGHT | 1.5 | +10.7 | 12.7 | 14.7 | 0.5 | +8.2 | 11.2 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +9.3 | 0.0 | 17.2 | 0.1 | +12.2 | 11.2 | 0.0 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 41.6 | 3.6 | 0.5 | +0.0 | 21.4 | 10.3 |
| WEARS DOWN | 1.1 | +30.5 | 25.0 | 38.6 | 1.3 | +30.0 | 105.2 | 34.8 |
| WHO HITS BACK | 0.2 | +17.5 | 0.0 | 0.0 | 0.3 | +14.0 | 0.0 | 6.2 |
| WHOLE FIGHT | 0.2 | +5.6 | 35.1 | 0.0 | 0.4 | +21.0 | 40.2 | 2.8 |
| WHOLE FIGHT GAIN | 0.3 | +45.6 | 25.7 | 9.9 | 0.8 | +67.8 | 63.8 | 24.5 |
| WIDER SPREAD | 2.0 | -8.6 | 107.9 | 49.2 | 3.6 | -8.4 | 289.8 | 75.2 |

### Rule changes: os-h2h-mine-779e261-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 599 | 599 | 599 | 33.28 | -25257 | -42.2 |
| BEST FIRST | 104 | 104 | 104 | 5.78 | +3647 | +35.1 |
| KILLS COUNT NEXT TURN | 199 | 199 | 76 | 4.22 | +2611 | +34.4 |
| PATHS CROSS | 74 | 74 | 74 | 4.11 | +5757 | +77.8 |
| SEARCH SPOT | 73 | 73 | 72 | 4.00 | +2858 | +39.7 |
| SUPPORTS | 143 | 143 | 69 | 3.83 | +864 | +12.5 |
| MOVE TO CHARGE | 138 | 138 | 66 | 3.67 | +2419 | +36.7 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 3.11 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 2.83 | +0 | +0.0 |
| FACES THE THREAT | 47 | 47 | 47 | 2.61 | +3535 | +75.2 |
| SHOTS IN THE MOVE | 550 | 376 | 41 | 2.28 | +1224 | +29.9 |
| WAIT AFTER COSTS | 228 | 228 | 40 | 2.22 | +686 | +17.1 |
| FOLLOW UP WEIGHED | 38 | 38 | 38 | 2.11 | +5992 | +157.7 |
| FALLBACK BY WORTH | 190 | 190 | 36 | 2.00 | +1212 | +33.7 |
| SET UP TOGETHER | 59 | 52 | 32 | 1.78 | +2268 | +70.9 |
| MISSILES IN THE MOVE | 135 | 75 | 31 | 1.72 | +534 | +17.2 |
| CANNON PLANNED TARGET | 199 | 199 | 30 | 1.67 | -201 | -6.7 |
| COUNTER-CHARGE COVER | 107 | 51 | 30 | 1.67 | +1366 | +45.5 |
| RESERVE FALL BACK | 30 | 30 | 30 | 1.67 | +695 | +23.2 |
| SAFER THAN THE JOB | 28 | 28 | 28 | 1.56 | +1605 | +57.3 |
| CHARGE NOW WEIGHED | 27 | 27 | 27 | 1.50 | +2117 | +78.4 |
| LONE WIZARD KEPT IN | 25 | 25 | 25 | 1.39 | +1822 | +72.9 |
| RANDOM MOVE BY FIGURES | 36 | 36 | 24 | 1.33 | +860 | +35.8 |
| RISK BY ARC | 92 | 89 | 24 | 1.33 | +646 | +26.9 |
| MODEL FACING | 23 | 23 | 23 | 1.28 | +6808 | +296.0 |
| BEST OVERALL | 22 | 22 | 22 | 1.22 | +1238 | +56.3 |
| REDIRECT COUNTER | 87 | 50 | 22 | 1.22 | +1445 | +65.7 |
| COVER ONCE | 166 | 85 | 21 | 1.17 | +350 | +16.7 |
| WALKS TO THE FIGHT | 36 | 36 | 20 | 1.11 | +110 | +5.5 |
| COMBAT PIVOT | 19 | 19 | 19 | 1.06 | +0 | +0.0 |
| MAX FOR POSITIONING | 192 | 113 | 19 | 1.06 | +80 | +4.2 |
| SCOUT WAITS | 19 | 19 | 19 | 1.06 | +0 | +0.0 |
| SHOT REPLANNED | 19 | 19 | 19 | 1.06 | +0 | +0.0 |
| ADVANCE LANE KEPT | 17 | 17 | 17 | 0.94 | +0 | +0.0 |
| BEST FACING | 17 | 17 | 17 | 0.94 | +477 | +28.0 |
| MARCH CHECK | 18 | 17 | 17 | 0.94 | +1012 | +59.5 |
| CHAFF PASSED | 16 | 16 | 16 | 0.89 | -15 | -0.9 |
| CHARGE NOW FIRST | 91 | 91 | 16 | 0.89 | -322 | -20.1 |
| INVITES THE FIGHT | 39 | 39 | 16 | 0.89 | +63 | +3.9 |
| KILLS COUNT | 63 | 63 | 16 | 0.89 | +457 | +28.5 |
| ADVANCE WORTH | 82 | 82 | 15 | 0.83 | +412 | +27.4 |
| HOLDS AMBUSHERS | 15 | 15 | 15 | 0.83 | +0 | +0.0 |
| HONEST WORTH | 283 | 281 | 15 | 0.83 | +67 | +4.5 |
| RISK ONCE | 103 | 69 | 15 | 0.83 | +329 | +21.9 |
| SHOOTERS IN TWO RANKS | 15 | 15 | 15 | 0.83 | +30 | +2.0 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.78 | -156 | -11.2 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.78 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 21 | 20 | 14 | 0.78 | +492 | +35.2 |
| KEEPS ITS TARGET | 70 | 69 | 13 | 0.72 | +196 | +15.1 |
| BLOCKED WHEEL | 12 | 12 | 12 | 0.67 | +24 | +2.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.67 | +0 | +0.0 |
| MARCH ODDS | 12 | 12 | 12 | 0.67 | +307 | +25.6 |
| ONE FIGHT FORMULA | 159 | 99 | 12 | 0.67 | +38 | +3.2 |
| THROUGH LINE OF FIRE | 12 | 12 | 12 | 0.67 | +374 | +31.2 |
| CAST JOB | 24 | 24 | 10 | 0.56 | +178 | +17.8 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 10 | 0.56 | +292 | +29.2 |
| STOPS SHORT OF THE FLANK | 10 | 10 | 10 | 0.56 | +414 | +41.4 |
| WAR ENGINE JOBS | 25 | 25 | 10 | 0.56 | -574 | -57.4 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.50 | +584 | +64.9 |
| BEST PREY | 25 | 25 | 8 | 0.44 | +412 | +51.5 |
| STUCK PIVOT | 8 | 8 | 8 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 8 | 8 | 8 | 0.44 | +510 | +63.8 |
| CHAFF IN THE MOVE | 11 | 10 | 7 | 0.39 | +298 | +42.6 |
| MANOEUVRE | 8 | 8 | 7 | 0.39 | +564 | +80.6 |
| MOVE AND CAST | 7 | 7 | 7 | 0.39 | +148 | +21.1 |
| OPENS UP | 9 | 9 | 7 | 0.39 | +321 | +45.8 |
| HUNT IN PAIRS | 14 | 9 | 6 | 0.33 | +490 | +81.6 |
| IDLE COST | 246 | 132 | 6 | 0.33 | +134 | +22.4 |
| OVERRUNS AWAY | 16 | 15 | 6 | 0.33 | +163 | +27.1 |
| WEARS DOWN | 43 | 42 | 6 | 0.33 | +137 | +22.9 |
| CASTING BLOCK | 12 | 12 | 5 | 0.28 | +143 | +28.7 |
| LOST CHARGE | 80 | 80 | 5 | 0.28 | +35 | +7.0 |
| SUPPORT NARROWED | 226 | 226 | 5 | 0.28 | -34 | -6.8 |
| BEST PRIZE | 4 | 4 | 4 | 0.22 | -761 | -190.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.22 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.22 | +0 | +0.0 |
| MAKE SURE TOGETHER | 12 | 8 | 4 | 0.22 | +87 | +21.8 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.22 | +112 | +27.9 |
| BIG CHARACTER SAFETY | 3 | 3 | 3 | 0.17 | -23 | -7.6 |
| KEEP FALLS | 3 | 3 | 3 | 0.17 | +212 | +70.8 |
| MISSILES NEXT TURN | 151 | 77 | 3 | 0.17 | +9 | +3.1 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.17 | -48 | -16.1 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.17 | -361 | -120.2 |
| REFUSING RETIRES | 11 | 11 | 3 | 0.17 | -2 | -0.7 |
| STANDS TO CAST | 3 | 3 | 3 | 0.17 | +11 | +3.6 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.17 | -85 | -28.3 |
| SURE REACH TOGETHER | 26 | 19 | 3 | 0.17 | +1 | +0.2 |
| WIDER SPREAD | 101 | 98 | 3 | 0.17 | +12 | +4.1 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.11 | -46 | -22.9 |
| DEFENSIVE ARMY | 14 | 14 | 2 | 0.11 | -83 | -41.4 |
| EDGE GIVE GROUND | 13 | 12 | 2 | 0.11 | +75 | +37.6 |
| HUNT ADVANCE | 10 | 10 | 2 | 0.11 | +16 | +7.8 |
| LONG SHOT | 29 | 28 | 2 | 0.11 | +51 | +25.3 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.11 | +110 | +55.1 |
| STAY WEIGHED | 2 | 2 | 2 | 0.11 | +23 | +11.5 |
| WHOLE FIGHT | 11 | 10 | 2 | 0.11 | +157 | +78.7 |
| BACKUP TARGETS | 28 | 13 | 1 | 0.06 | +0 | +0.2 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.06 | -162 | -161.9 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.06 | -41 | -41.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.06 | +13 | +13.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.06 | +62 | +61.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.06 | +14 | +13.7 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 1 | 0.06 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 4 | 2 | 1 | 0.06 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.06 | +12 | +11.7 |
| ONE OBJECTIVE FORMULA | 41 | 25 | 1 | 0.06 | +3 | +3.4 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.06 | +82 | +81.5 |
| STOPS | 4 | 4 | 1 | 0.06 | +6 | +5.5 |
| TWO OR MORE ARRIVE | 8 | 8 | 1 | 0.06 | +10 | +10.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 18 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 16 | 15 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 179 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 6 | 6 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 20 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 9 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 179 | 179 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 1411 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 51 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 13 | 13 | 0 | 0.00 | - | - |
| STABLE ROLE | 436 | 435 | 0 | 0.00 | - | - |
| TURN WORTH | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.83 | 14.72 | 42.6 |
| FALLBACK | gate | 0.67 | 1.22 | 39.0 |
| TURN GATE | gate | 0.44 | 0.72 | 38.4 |
| CHARGE NOW FIRST | rule | 0.22 | 0.61 | 21.4 |
| WAR ENGINE JOBS | rule | 0.44 | 0.11 | 57.3 |
| CHARGE NOW WEIGHED | rule | 0.17 | 0.28 | 14.4 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.06 | 54.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.22 | - | 67.5 |
| BEST PRIZE | rule | 0.11 | 0.11 | 190.3 |
| CHAFF PASSED | rule | 0.11 | 0.11 | 3.6 |
| SUPPORT NARROWED | rule | 0.11 | 0.11 | 8.4 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.5 |
| BLOCKED WHEEL | rule | 0.11 | 0.06 | 39.2 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.11 | 16.1 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 120.2 |
| REFUSING RETIRES | rule | 0.17 | - | 0.7 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.17 | 28.3 |
| CATCH ODDS | rule | 0.06 | 0.06 | 22.9 |
| DEFENSIVE ARMY | rule | - | 0.11 | 41.4 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.11 | 52.1 |
| PATHS CROSS | rule | 0.11 | - | 25.3 |
| REDIRECT WEIGHED | rule | 0.06 | 0.06 | 232.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.06 | 32.0 |
| THROUGH LINE OF FIRE | rule | 0.11 | - | 2.3 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 24.6 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 161.9 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 41.4 |
| FACES THE THREAT | rule | - | 0.06 | 24.6 |
| FALLBACK BY WORTH | rule | - | 0.06 | 15.1 |
| FIGHT ORDER BAND | gate | 0.06 | - | 3.1 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 2.0 |
| MARCH ODDS | rule | - | 0.06 | 16.5 |

### Plans: os-h2h-mine-779e261-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.1 | 13% | 181 | 239 | 132% |
| Mine | charge | 2.4 | 60% | 180 | 189 | 105% |
| Mine | close in | 2.7 | 24% | 147 | 40 | 27% |
| Mine | hold | 5.2 | 28% | 375 | 0 | 0% |
| Mine | join | 0.6 | 100% | 18 | 0 | 0% |
| Mine | shoot | 11.9 | 62% | 426 | 1244 | 292% |
| Mine | support | 4.6 | 92% | 44 | 0 | 0% |
| Opponent | advance | 12.9 | 22% | 242 | 371 | 154% |
| Opponent | charge | 4.8 | 56% | 326 | 397 | 122% |
| Opponent | close in | 6.6 | 24% | 443 | 189 | 43% |
| Opponent | hold | 6.3 | 46% | 443 | 0 | 0% |
| Opponent | join | 0.7 | 92% | 36 | 0 | 0% |
| Opponent | shoot | 6.4 | 66% | 242 | 272 | 112% |
| Opponent | support | 4.3 | 95% | 36 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 244 | 0 | 0% | 59 |
| Opponent | 0.6 | 10 | 2 | 12% | 12% | 0% | 2.0 | 242 | 54 | 12% | 170 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 244 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 196 | 0 | 0% | 99 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 277 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 505 | 429 | 100% | 419 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 200 |
| Tomb Kings of Khemri | 1.7 | 5 | 1 | 0% | 0% | 0% | - | 123 | 0 | 0% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 660 |
| Wood Elf Realms | 3.0 | 3 | 1 | 0% | 0% | 0% | - | 369 | 0 | 0% | 500 |

### Battle groups: os-h2h-mine-779e261-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 32% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 5.9 | 17% | 44% | 22% | 25% | 29% | 0% | 29% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 17% | 70% | 0% | - | 30% | 10% | 0% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 41 (9) | 41 | 0 | 52 | 67% | 2.0 | 61 (4) | 0 (3) | 77 (2) | 62 (5) | 0 (4) |
| Mine | Character | 70 | 35 (70) | 35 | 0 | 29 | 20% | 2.7 | 12 (10) | 44 (34) | 19 (15) | 61 (27) | 7 (32) |
| Mine | Clean-up | 13 | 91 (13) | 6 | 85 | 30 | 69% | 2.5 | 0 (2) | 90 (9) | 200 (2) | 135 (9) | 0 (4) |
| Mine | Fast Hammer | 17 | 44 (17) | 39 | 6 | 48 | 29% | 3.1 | 64 (5) | 31 (7) | 35 (5) | 51 (12) | 27 (5) |
| Mine | Hammer | 40 | 38 (40) | 24 | 14 | 29 | 25% | 2.8 | 10 (10) | 60 (21) | 26 (9) | 46 (27) | 25 (13) |
| Mine | Holder | 10 | 29 (10) | 0 | 29 | 38 | 60% | 2.5 | 8 (4) | 138 (2) | 19 (3) | 44 (7) | 0 (2) |
| Mine | Shooter | 25 | 42 (25) | 12 | 30 | 29 | 4% | 1.5 | 42 (2) | 41 (18) | 44 (5) | 63 (15) | 12 (10) |
| Mine | War machine | 49 | 52 (49) | 52 | 0 | 66 | 2% | 1.2 | 68 (8) | 33 (31) | 113 (10) | 26 (9) | 58 (40) |
| Mine | Wizard | 12 | 12 (12) | 12 | 0 | 15 | 8% | 4.0 | 0 (2) | 27 (6) | 0 (4) | 37 (2) | 7 (10) |
| Opponent | Chaff | 39 | 53 (39) | 9 | 44 | 38 | 44% | 2.3 | 54 (14) | 15 (13) | 108 (12) | 63 (30) | 23 (9) |
| Opponent | Character | 50 | 50 (50) | 50 | 0 | 32 | 24% | 2.3 | 86 (15) | 38 (24) | 17 (7) | 44 (32) | 64 (14) |
| Opponent | Clean-up | 15 | 11 (15) | 7 | 5 | 64 | 27% | 2.9 | 11 (6) | 11 (9) | - | 14 (12) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 17 | 30 (17) | 21 | 9 | 42 | 41% | 2.7 | 24 (6) | 30 (6) | 36 (5) | 34 (10) | 22 (7) |
| Opponent | Fragile | 5 | 44 (5) | 44 | 0 | 46 | 20% | 3.0 | - | 57 (4) | 0 (1) | 54 (4) | 0 (1) |
| Opponent | Hammer | 26 | 29 (26) | 21 | 9 | 29 | 38% | 2.4 | 51 (4) | 26 (16) | 29 (6) | 38 (19) | 7 (7) |
| Opponent | Holder | 20 | 140 (20) | 13 | 127 | 14 | 25% | 2.9 | 189 (4) | 135 (10) | 126 (6) | 160 (14) | 90 (6) |
| Opponent | Shooter | 16 | 141 (16) | 17 | 124 | 12 | 6% | 1.9 | 29 (3) | 174 (11) | 95 (2) | 176 (13) | 32 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | War machine | 24 | 37 (24) | 37 | 0 | 34 | 8% | 1.4 | 0 (6) | 30 (14) | 102 (4) | 38 (3) | 37 (21) |
| Opponent | Wizard | 14 | 33 (14) | 33 | 0 | 15 | 0% | 1.4 | 0 (5) | 87 (6) | 0 (3) | 72 (4) | 0 (10) |

### Charged fights: os-h2h-mine-779e261-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 109 | 103 | 1.8 | 1.1 | 59 | 15 | +44 | 2 of 7 | 7 of 7 | +120 | +31 |
| Mine | Chaos Dwarfs | 4 | 268 | 471 | 3.2 | 1.0 | 145 | 0 | +145 | 8 of 13 | 11 of 13 | - | +145 |
| Mine | Dwarfen Mountain Holds | 4 | 616 | 62 | 2.2 | 1.1 | 28 | 0 | +28 | 0 of 9 | 6 of 9 | +137 | +14 |
| Mine | Empire of Man | 5 | 308 | 18 | 1.2 | 1.0 | 15 | 44 | -29 | 3 of 6 | 5 of 6 | - | -29 |
| Mine | Grand Cathay | 1 | 45 | 110 | 3.0 | 1.0 | 37 | 0 | +37 | 0 of 3 | 2 of 3 | - | +37 |
| **Mine** | all armies | 18 | 309 | 152 | 2.1 | 1.1 | 72 | 10 | +63 | 13 of 38 | 31 of 38 | +128 | +59 |
| Opponent | Dwarfen Mountain Holds | 2 | 94 | 28 | 2.5 | 1.2 | 11 | 21 | -10 | 0 of 5 | 4 of 5 | +0 | -12 |
| Opponent | Empire of Man | 2 | 70 | 48 | 1.0 | 1.5 | 48 | 0 | +48 | 0 of 2 | 2 of 2 | +95 | +0 |
| Opponent | Grand Cathay | 2 | 701 | 553 | 3.0 | 1.5 | 184 | 0 | +184 | 5 of 6 | 5 of 6 | +152 | +200 |
| Opponent | Kingdom of Bretonnia | 1 | 235 | 440 | 3.0 | 1.0 | 147 | 0 | +147 | 0 of 3 | 3 of 3 | - | +147 |
| Opponent | Ogre Kingdoms | 1 | 0 | 522 | 10.0 | 1.2 | 52 | 20 | +32 | 2 of 10 | 9 of 10 | -45 | +52 |
| Opponent | Skaven | 1 | 470 | 0 | 2.0 | 1.0 | 0 | 56 | -56 | 2 of 2 | 1 of 2 | - | -56 |
| Opponent | Tomb Kings of Khemri | 3 | 95 | 518 | 3.0 | 1.2 | 173 | 70 | +103 | 6 of 9 | 5 of 9 | +108 | +102 |
| Opponent | Vampire Counts | 3 | 145 | 279 | 3.7 | 1.1 | 76 | 107 | -31 | 6 of 11 | 9 of 11 | +0 | -34 |
| Opponent | Warriors of Chaos | 2 | 0 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 2 of 4 | 2 of 4 | - | +56 |
| Opponent | Wood Elf Realms | 1 | 0 | 1126 | 4.0 | 1.5 | 282 | 0 | +282 | 2 of 4 | 3 of 4 | +227 | +300 |
| **Opponent** | all armies | 18 | 175 | 331 | 3.1 | 1.2 | 106 | 40 | +67 | 25 of 56 | 43 of 56 | +75 | +65 |

### Effective charges: os-h2h-mine-779e261-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 0 | 2 (net +34) | 0 | 3 (net +62) | 2 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 13 | 1 (net +516) | 1 (net +0) | 1 (net +0) | 3 (net +0) | 2 (net +60) | 5 (net +249) | 0 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 9 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +0) | 0 | 5 (net +50) | 0 | 22% (2 of 9) |
| Mine | Empire of Man | 6 | 0 | 0 | 3 (net -88) | 1 (net +0) | 1 (net +92) | 1 (net +0) | 0 | 50% (3 of 6) |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 2 (net +55) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 5 | 0 | 0 | 2 (net -52) | 1 (net +55) | 1 (net +0) | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 1 (net +95) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 6 | 1 (net +0) | 0 | 2 (net +0) | 2 (net +401) | 0 | 1 (net +304) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 2 (net +160) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 10 | 1 (net +125) | 0 | 3 (net -43) | 2 (net +22) | 0 | 3 (net +106) | 1 | 33% (3 of 9) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net +46) | 0 | 0 | 2 (net +220) | 1 (net +85) | 1 (net +310) | 3 | 0% (0 of 6) |
| Opponent | Vampire Counts | 11 | 2 (net -485) | 0 | 4 (net +108) | 2 (net +16) | 1 (net +165) | 2 (net +0) | 0 | 36% (4 of 11) |
| Opponent | Warriors of Chaos | 4 | 2 (net +59) | 0 | 1 (net +105) | 1 (net +0) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 4 | 1 (net +509) | 1 (net +227) | 0 | 1 (net +265) | 0 | 0 | 1 | 0% (0 of 3) |

### Charged fights, damage counted: os-h2h-mine-779e261-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 194 | 178 | +258 | 286 | 0 | +286 | +147.0 |
| Mine | 50-54% | 1 | 310 | 431 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 6 | 193 | 268 | -44 | 23 | 62 | -39 | -20.4 |
| Mine | 76-89% | 9 | 227 | 243 | +20 | 42 | 13 | +29 | +13.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 280 | 186 | +112 | 140 | 22 | +118 | +42.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 400 | 71 | +71 | 71 | 7 | +64 | +15.9 |
| Mine | No odds | 2 | 460 | 52 | +28 | 28 | 0 | +28 | +6.0 |
| Mine | All fights | 38 | 269 | 202 | +63 | 91 | 22 | +69 | +25.7 |
| Opponent | Long shot (under 50%) | 9 | 276 | 301 | -14 | 165 | 218 | -52 | -18.9 |
| Opponent | 50-54% | 1 | 636 | 227 | +227 | 227 | 203 | +24 | +3.8 |
| Opponent | Effective (55-75%) | 12 | 293 | 187 | +25 | 72 | 46 | +26 | +8.8 |
| Opponent | 76-89% | 13 | 256 | 140 | +151 | 185 | 26 | +159 | +62.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 10 | 297 | 180 | +93 | 122 | 5 | +117 | +39.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 388 | 94 | +86 | 90 | 6 | +84 | +21.8 |
| Opponent | No odds | 7 | 229 | 163 | +14 | 63 | 58 | +5 | +2.1 |
| Opponent | All fights | 56 | 287 | 184 | +67 | 125 | 63 | +62 | +21.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p2 | move | 194 | 44 (23%) | 32 (16%) | 25 (13%) | 125 (64%) |
| os-h2h-mine-779e261-p2 | objective | 169 | 23 (14%) | 20 (12%) | 24 (14%) | 122 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026 |
| Clockwork Compass | Opponent | L0512 |
| Fistful of Laurels | Opponent | L0918 |
| Invocation of Nehek | Opponent | L0425, L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Mine | L1026 |
| Ring of Jet | Opponent | L0512, L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

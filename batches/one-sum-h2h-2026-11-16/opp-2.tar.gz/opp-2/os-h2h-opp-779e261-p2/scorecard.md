# Doctrine scorecard: os-h2h-opp-779e261-p2

### Scorecard: os-h2h-opp-779e261-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 5 | 0 | 3 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 3 | - | 1 | 2 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 1 | 2 | 2 | 3 | 1 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 4 | 2 | 0 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 770 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 6 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 0 | 6 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 800 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 6 | 4 | 1 | 0 | 2 | 0 | 0 | 307 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 1176 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 5 | 0 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 762 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 769 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 6 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0918 | 6 | 1 | Opponent | no | 14 | 2 | 0 | 3 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 1 | 3 | 0 | 0 | 0 | 0 | 0 | 768 |
| L0934 | 4 | 1 | Opponent | yes | 0 | 2 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 8 | 5 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | no | 4 | 6 | 1 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 4 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 2 | 0 | 0 | 462 |
| L1323 | 3 | 1 | Mine | yes | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 3 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 1 | 0 | 0 | 49 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 1 | - | 3 | 0 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 3 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 133 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 1 | 2 | 1 | 0 | 0 | 860 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 1 | - | 1 | 4 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 1 | 1 | 0 | 0 | 562 |
| L2235 | 3 | 1 | Mine | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | 5 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 6 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 1.7 | 3.0 | 2.2 | 1.3 | 0.2 | 0.0 | 0.0 | 335.1 |
| **Average** | | | Opponent | 37% | 3.5 | 2.5 | 2.5 | 1.7 | 0.5 | 0.0 | 0.0 | 175.6 |

### KPIs: os-h2h-opp-779e261-p2

Rules off - Mine only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (39 of 174) | 15% (27 of 182) | 19% (66 of 356) |
| Winner chose to follow up after the loser gave ground |  | 96% (70 of 73); on the table 96% | 97% (67 of 69); on the table 97% | 96% (137 of 142); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 69% (9 of 13); on the table 77% | 92% (12 of 13); on the table 92% | 81% (21 of 26); on the table 85% |
| Winner chose to pursue after the loser fled |  | 81% (25 of 31); on the table 84% | 91% (30 of 33); on the table 91% | 86% (55 of 64); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 89% (104 of 117); on the table 91% | 95% (109 of 115); on the table 95% | 92% (213 of 232); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 35% (118 of 342) | 38% (60 of 156) | 36% (178 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (118 of 245) | 51% (60 of 118) | 49% (178 of 363) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (20 of 30) | 49% (22 of 45) | 56% (42 of 75) |
| Points that never fought | lower | 34% (24299 of 71583) | 39% (28296 of 71989) | 37% (52595 of 143572) |
|   infantry points that never fought | lower | 45% (7277 of 16324) | 59% (8286 of 14029) | 51% (15563 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (166 of 284) | 57% (170 of 297) | 58% (336 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.4 uses a game | 78% (14 of 18); 1.2 uses a game | 87% (33 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 0.7 uses a game | 50% (1 of 2); 0.0 uses a game | 60% (12 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32299 of 60231) | 53% (33440 of 63281) | 53% (65739 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (34%) | 0.7 (26%) | 2.8 (32%) |
| MARCHED: its unit marched | 0.9 (15%) | 0.4 (16%) | 1.3 (15%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.5 (19%) | 2.1 (24%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.7 (12%) | 0.2 (9%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.3 (11%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.7 | 1.4 | 4.9 | 0.4 | 1.9 |
| not cast | 3.6 | 3.2 | 3.6 | 8.9 | 1.9 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.6 (50%) | 0.2 (5%) | 2.8 (32%) | 0.6 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (15%) | 0.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.4 (12%) | 0.7 (19%) | 2.1 (24%) | 0.4 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.4 (11%) | 0.4 (10%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.4 (11%) | 0.2 (8%) | 0.5 (13%) | 1.0 (11%) | 0.3 (16%) | 2.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.3 (9%) | 0.1 (4%) | 0.6 (6%) | 0.0 (0%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (60%) | 0.2 (5%) | 1.7 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.8 a game | 0.7 a game |
| stood (cast and not dispelled) | 73% (16 of 22) | 67% (18 of 27) | 69% (34 of 49) |
| the unit moved after it | 75% (12 of 16) | 67% (12 of 18) | 71% (24 of 34) |
| it charged on its next turn | 0% (0 of 16) | 6% (1 of 18) | 3% (1 of 34) |
| the enemy charged it first | 19% (3 of 16) | 17% (3 of 18) | 18% (6 of 34) |
| it fought by the end of its next turn | 12% (2 of 16) | 6% (1 of 18) | 9% (3 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (3 of 16) | 6% (1 of 18) | 12% (4 of 34) |
| none of these (no charge, no fight, no charge escaped) | 62% (10 of 16) | 72% (13 of 18) | 68% (23 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (591 of 874) | 59% (470 of 798) | 63% (1061 of 1672) |
|   cavalry | 69% (53 of 77) | 59% (101 of 170) | 62% (154 of 247) |
|   character | 60% (65 of 109) | 33% (33 of 101) | 47% (98 of 210) |
|   chariot | 52% (56 of 107) | 67% (26 of 39) | 56% (82 of 146) |
|   infantry | 61% (166 of 270) | 62% (199 of 322) | 62% (365 of 592) |
|   monster | 61% (31 of 51) | 61% (22 of 36) | 61% (53 of 87) |
|   war machine | 85% (220 of 260) | 68% (89 of 130) | 79% (309 of 390) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (27%) | 2.3 (25%) | 4.4 (26%) |
| CHARGED: it charged | 1.3 (16%) | 1.8 (19%) | 3.0 (18%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (13%) | 0.5 (5%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.3 (17%) | 1.6 (18%) | 2.9 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (4%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 1.6 (18%) | 2.8 (17%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.3 (4%) | 0.5 (3%) |
| OTHER BAR | 0.3 (4%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.9 | 77% | 6.4 pts | 42 pts |
| character | 2.9 | 0.9 | 76% | 8.2 pts | 23 pts |
| chariot | 2.3 | 0.9 | 77% | 7.4 pts | 17 pts |
| infantry | 13.9 | 5.5 | 75% | 8.3 pts | 115 pts |
| monster | 1.8 | 0.6 | 74% | 7.4 pts | 14 pts |
| war machine | 8.6 | 6.8 | 62% | 23.5 pts | 202 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.3 | 4.8 |
| Charges that made contact a game | 3.3 | 3.8 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.67 contact (24 units) | 0.67 declared, 0.50 contact (12 units) | 0.69 declared, 0.61 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.50 contact (4 units) | 1.40 declared, 1.10 contact (10 units) | 1.43 declared, 1.21 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.40 contact (245 units) | 0.58 declared, 0.41 contact (292 units) | 0.56 declared, 0.41 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (40 of 73) | 61% (11 of 18) | 50% (6 of 12) | 55% (57 of 103) |
| Character in a unit | 72% (26 of 36) | 60% (9 of 15) | 0% (0 of 1) | 67% (35 of 52) |
| Character on its own | 75% (27 of 36) | 49% (19 of 39) | 35% (23 of 65) | 49% (69 of 140) |
| Chariot | 82% (14 of 17) | 62% (8 of 13) | - | 73% (22 of 30) |
| Infantry | 59% (55 of 94) | 53% (18 of 34) | 0% (0 of 3) | 56% (73 of 131) |
| Monster | 52% (15 of 29) | 56% (5 of 9) | - | 53% (20 of 38) |
| Monstrous | 57% (8 of 14) | 50% (7 of 14) | - | 54% (15 of 28) |
| War Machines | 75% (43 of 57) | 100% (2 of 2) | - | 76% (45 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (17 of 18); on the table 100% | 30% (31 of 102) | 34% | 50% (11 of 22) | 100% (6 of 6); 3.0 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 83% | 56% (20 of 36) | 44% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 88% (15 of 17); on the table 88% | - | 51% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 88% (14 of 16); on the table 88% | 23% (11 of 48) | 41% | 62% (47 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 100% (19 of 19); on the table 100% | 36% (49 of 138) | 41% | 46% (25 of 54) | 86% (12 of 14); 5.3 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 87% (13 of 15); on the table 87% | 11% (2 of 18) | 19% | 48% (16 of 33) | 100% (3 of 3); 3.0 uses a game | 57% (8 of 14); 5.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 83% (5 of 6); on the table 83% | - | 37% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | - | 26% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (10 of 10); on the table 100% | 0% (0 of 18) | 36% | 82% (23 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 8% (1 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 83% (5 of 6); on the table 83% | 39% (7 of 18) | 46% | 56% (14 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 71% (5 of 7); on the table 71% | - | 36% | 40% (10 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 98% (40 of 41); on the table 98% | 52% (34 of 66) | 37% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 86% (25 of 29); on the table 90% | 44% (8 of 18) | 24% | 53% (39 of 73) | 100% (2 of 2); 1.1 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 96% (26 of 27); on the table 96% | 62% (15 of 24) | 41% | 60% (47 of 78) | 57% (4 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-opp-779e261-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (48) | 47% (35) | 54% (83) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.75 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.14 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.58 | 1.11 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.19 | 1.78 | 3.97 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.31 | 0.69 | 2.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.50 | 5.28 | 11.78 |

### Quality by phase: os-h2h-opp-779e261-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (71 of 123) | 46% (90 of 196) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (137 of 370) | 45% (127 of 283) |
| Strategy | Close-in objectives charged next turn | 15% (22 of 143) | 15% (36 of 237) |
| Strategy | Support requests answered (helper made contact too) | 50% (8 of 16) | 47% (14 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (8 of 8) | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 19% (3 of 16) | 69% (9 of 13) |
| Strategy | Joined characters whose unit fought | 52% (28 of 54) | 32% (11 of 34) |
| Strategy | Lone characters that fought | 76% (69 of 91) | 70% (62 of 89) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 335.1 | 175.6 |
| Movement | Fights charged into per game | 2.9 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 93, net +105 | 28 of 108, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 22 of 93, net +25 | 19 of 108, net +133 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 93, net +104 | 3 of 108, net +92 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 93, net +65 | 32 of 108, net +117 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 11.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (157 of 399) | 47% (196 of 420) |
| Shooting | Points destroyed by shooting units | 89.4 | 30.3 |
| Shooting | War machine shots | 6.1 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (134 of 220) | 57% (51 of 89) |
| Shooting | Points destroyed by war machines | 45.3 | 43.8 |
| Magic | Magic missiles cast | 2.2 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (22 of 80) | 57% (24 of 42) |
| Magic | Wounds caused by magic missiles | 3.4 | 1.5 |
| Magic | Wounds caused by other spells | 1.7 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 61.0 | 33.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.6 / 0.7 / 0.1 | 2.1 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 316.4 | 431.8 |
| Combat | Points run down | 46.9 | 46.1 |
| Combat | Net points per charged fight, damage counted | +73 | +102 |
| Combat | Net per 100 charger points, damage counted | +27.7 | +40.6 |
| Combat | First round won (charged fights) | 79% | 72% |
| Combat | Net points per charged fight | +66 | +98 |
| Combat | Net points per supported fight / lone fight | +114 / +58 | +122 / +94 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 106 | 42 of 120 |
| Game | Points lost | 718.3 | 689.2 |
| Game | VP from objectives | 478.1 | 658.6 |
| Game | Lone holders (player turns) | 1.7 | 3.5 |

- Mine won / drew / lost: 13 / 6 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -204 VP
- The side that went first won 16 of 30 games with a winner
- Points traded per game (both sides' losses): 1408
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: os-h2h-opp-779e261-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.2 | -164.8 | 158.7 | 66.8 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 24.9 | 0.3 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.3 | +9.0 | 0.0 | 38.8 | 0.9 | +5.2 | 0.0 | 16.5 |
| BEST FACING | 0.9 | +49.7 | 0.0 | 42.4 | 0.5 | +18.6 | 0.0 | 8.8 |
| BEST FIRST | 5.3 | +217.8 | 180.8 | 74.5 | 1.2 | +74.1 | 36.6 | 15.6 |
| BEST OVERALL | 0.8 | +55.7 | 0.0 | 21.5 | 0.6 | +27.6 | 0.0 | 34.9 |
| BEST PREY | 0.8 | +45.4 | 30.3 | 17.4 | 0.8 | +27.8 | 20.9 | 13.8 |
| BEST PRIZE | 0.0 | +0.8 | 3.5 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | +0.3 | 0.0 | 12.3 | 0.1 | +0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 6.2 | 7.4 | 0.1 | +0.0 | 5.1 | 0.0 |
| BLOCKED WHEEL | 0.2 | +5.8 | 0.0 | 7.8 | 0.5 | +0.8 | 0.0 | 21.9 |
| BLOWS WHERE AIMED | 0.3 | -17.7 | 45.2 | 0.0 | 0.3 | -33.7 | 28.1 | 38.5 |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 101.1 | 2.9 | 0.4 | +0.0 | 27.3 | 0.0 |
| CANNON PLANNED TARGET | 4.7 | +135.5 | 400.5 | 92.6 | 1.9 | +102.5 | 170.2 | 19.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.8 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 7.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 6.2 | 0.0 | 0.2 | -5.2 | 26.4 | 0.0 |
| CAST JOB | 0.9 | +18.6 | 64.5 | 0.0 | 0.4 | +13.3 | 21.7 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +37.3 | 37.8 | 7.6 | 0.2 | +9.2 | 14.9 | 4.4 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 11.1 | 0.4 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +3.7 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.9 | +94.5 | 0.0 | 36.6 |
| CHAFF PASSED | 0.2 | -0.1 | 4.7 | 12.9 | 0.3 | -0.1 | 7.1 | 2.0 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 161.2 | 63.9 | 2.7 | +0.0 | 271.1 | 118.6 |
| CHARGE NOW WEIGHED | 0.6 | -25.1 | 12.7 | 18.2 | 0.4 | -38.0 | 18.4 | 9.8 |
| CHARGER SLAIN LOST | 0.6 | -9.2 | 57.8 | 36.7 | 0.4 | -20.5 | 24.6 | 10.8 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 4.7 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 23.7 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 5.4 | 46.4 | 0.6 | +0.0 | 25.7 | 44.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.2 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +39.3 | 7.6 | 0.0 | 0.7 | +60.1 | 4.4 | 22.8 |
| COUNTER-CHARGE COVER | 12.0 | +1057.9 | 0.0 | 159.3 | - | - | - | - |
| COVER ONCE | - | - | - | - | 6.8 | -539.3 | 0.0 | 84.8 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 35.4 | 0.0 | 0.1 | +0.0 | 2.7 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +13.3 | 25.2 | 9.5 | 0.3 | +5.2 | 34.8 | 2.0 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +153.8 | 0.0 | 70.5 | 1.8 | +112.9 | 0.0 | 23.5 |
| FALLBACK BY WORTH | 4.9 | +70.1 | 0.0 | 48.7 | 5.7 | +55.3 | 0.0 | 93.9 |
| FIGHT LIFT | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 1.7 |
| FLANK NOT WEIGHED | 7.1 | +0.0 | 0.0 | 158.2 | 5.1 | +0.0 | 0.0 | 123.4 |
| FOCUS FIRE | 0.1 | +5.3 | 0.0 | 0.0 | 0.1 | +0.8 | 2.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +96.0 | 0.0 | 22.7 | 1.2 | +174.5 | 0.0 | 24.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.5 | 0.0 | 5.8 | 0.2 | +4.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.8 | 1.5 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 5.4 | 0.0 | 0.0 | -0.0 | 3.4 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 21.5 | 2.8 | 0.3 | +0.0 | 12.8 | 0.0 |
| HILL BY ITS CHANCE | 0.3 | -42.1 | 0.0 | 0.0 | 0.6 | -52.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.7 | -108.6 | 267.1 | 144.4 | 10.8 | -226.6 | 589.8 | 335.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.4 | +3.0 | 0.0 | 3.9 |
| HUNT DROPPED | 0.0 | +0.0 | 5.4 | 0.0 | 0.2 | +0.0 | 13.5 | 3.8 |
| HUNT IN PAIRS | 0.3 | +21.9 | 0.0 | 6.0 | 0.5 | +35.8 | 0.0 | 17.4 |
| HUNT KEPT | - | - | - | - | 0.2 | +4.3 | 9.2 | 1.9 |
| HUNT RESULT | 0.1 | +12.4 | 5.4 | 0.0 | 0.4 | +49.5 | 16.9 | 4.7 |
| HUNT THE GUNS | 0.1 | +27.1 | 12.4 | 0.0 | 0.4 | +131.7 | 17.2 | 3.8 |
| IDLE COST | - | - | - | - | 19.4 | -301.6 | 0.0 | 259.5 |
| INVITES THE FIGHT | 1.4 | +28.5 | 32.0 | 7.4 | 0.7 | +7.1 | 23.2 | 13.9 |
| JOINT CHARGE PLAN | 0.1 | +2.5 | 0.0 | 0.0 | 0.2 | +5.5 | 11.0 | 4.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -8.6 | 7.0 | 6.0 | 0.1 | -1.8 | 16.1 | 6.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 10.6 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +46.7 | 118.4 | 79.6 | 2.2 | +67.5 | 136.8 | 74.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.4 | +67.2 | 64.9 | 71.8 | 2.6 | +111.8 | 233.7 | 97.6 |
| KILLS COUNT NEXT TURN | 5.1 | +161.5 | 189.2 | 103.9 | 6.9 | +283.4 | 224.3 | 220.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +14.2 | 0.0 | 0.0 | 0.3 | +11.0 | 4.6 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 10.8 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -2.6 | 12.5 | 0.0 | 0.8 | +7.6 | 34.7 | 0.0 |
| LOST CHARGE | 2.8 | -53.3 | 104.2 | 74.6 | 2.4 | -41.8 | 115.4 | 86.2 |
| LURE BY WHAT IT DRAWS | 0.0 | -11.4 | 0.0 | 4.2 | 0.1 | -8.0 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 0.4 | +37.5 | 0.0 | 1.2 | 0.5 | +14.3 | 17.5 | 15.5 |
| MANOEUVRE | 0.4 | +9.3 | 0.0 | 0.0 | 0.2 | +6.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +2.8 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +37.6 | 0.0 | 9.8 | 0.4 | +12.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +21.0 | 21.3 | 0.0 | 0.1 | +14.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +67.9 | 0.0 | 13.4 | 0.2 | +42.9 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 5.8 | +212.7 | 0.0 | 105.3 | 6.9 | +91.8 | 0.0 | 145.4 |
| MISSILES IN THE MOVE | 4.2 | +107.7 | 0.0 | 70.8 | 3.2 | +62.5 | 0.0 | 69.6 |
| MISSILES NEXT TURN | 4.9 | +66.1 | 0.0 | 82.6 | 3.8 | +43.1 | 0.0 | 97.7 |
| MODEL FACING | 0.2 | +78.1 | 0.0 | 1.7 | 0.2 | +88.2 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 33.9 | 0.0 | 0.3 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +13.0 | 0.0 | 0.0 | 0.3 | +18.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +6.6 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.1 | -0.0 | 1.4 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.6 | 10.8 | 0.0 | 0.2 | -3.5 | 0.0 | 21.7 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 26.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +165.3 | 122.1 | 66.1 | 5.4 | +286.9 | 196.6 | 163.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +24.4 | 1.9 | 12.3 | - | - | - | - |
| NOT NEEDED | 0.1 | -1.7 | 6.4 | 1.8 | 0.3 | -10.9 | 26.8 | 1.8 |
| NOT TURNED | 6.5 | +127.9 | 0.0 | 115.3 | 5.3 | +110.3 | 0.0 | 149.3 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 7.6 |
| OFF BEST | 15.4 | -770.8 | 0.0 | 311.4 | 18.0 | -865.1 | 25.2 | 232.7 |
| ONE FIGHT FORMULA | - | - | - | - | 8.8 | -178.5 | 13.8 | 234.1 |
| ONE OBJECTIVE FORMULA | - | - | - | - | 2.6 | -144.3 | 0.0 | 44.5 |
| OPENS A LANE | 0.1 | +0.2 | 5.0 | 6.5 | 0.1 | +0.1 | 6.8 | 5.4 |
| OPENS UP | 0.1 | +13.4 | 7.8 | 0.0 | 0.1 | +12.0 | 10.6 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.0 | 41.6 | 37.0 | 0.4 | +7.6 | 16.8 | 19.8 |
| PATHS CROSS | 2.0 | +146.2 | 0.0 | 13.6 | 3.0 | +176.6 | 0.0 | 96.7 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 15.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 2.7 | 0.1 | -3.3 | 0.0 | 5.6 |
| PLAN RESULT | 37.3 | +1508.2 | 1362.8 | 893.4 | 41.3 | +1053.3 | 1404.5 | 888.1 |
| PURSUES BIG PREY | 0.0 | -4.6 | 0.0 | 16.1 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +22.0 | 0.0 | 17.5 | 1.2 | +13.0 | 0.0 | 49.2 |
| RANDOM MOVER NO PROMISE | 0.3 | -12.9 | 20.0 | 4.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.3 | -7.5 | 0.0 | 3.2 | 1.1 | -25.8 | 0.0 | 23.7 |
| REDIRECT COUNTER | 2.3 | +160.2 | 0.0 | 64.8 | 4.0 | +297.3 | 0.0 | 64.1 |
| REDIRECT WEIGHED | 0.2 | +5.6 | 11.3 | 2.3 | 0.3 | +11.1 | 14.6 | 20.5 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 8.2 |
| RESERVE FALL BACK | 0.3 | +7.0 | 0.0 | 4.2 | 1.2 | +32.1 | 0.0 | 15.8 |
| RESTRAINS TO SHOOT | 0.2 | +13.6 | 0.0 | 3.4 | 0.1 | +0.9 | 0.0 | 6.3 |
| RISK BY ARC | 2.3 | +90.6 | 208.2 | 100.1 | 3.2 | +93.3 | 278.1 | 118.4 |
| RISK ONCE | - | - | - | - | 3.1 | +174.9 | 40.0 | 187.2 |
| SAFER THAN THE JOB | 1.3 | +73.7 | 0.0 | 13.7 | 0.7 | +43.5 | 0.0 | 48.8 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 1.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -5.6 | 0.0 | 1.2 | 0.8 | -55.2 | 0.0 | 7.6 |
| SEARCH SPOT | 2.5 | +113.3 | 0.0 | 35.1 | 2.6 | +137.7 | 0.0 | 34.4 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.7 | 9.2 | 3.8 |
| SELF MOVE SPELL | 0.2 | +7.5 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +48.9 | 42.2 | 7.3 | 1.9 | +130.4 | 86.1 | 79.9 |
| SET-UP ANY TARGET | 0.1 | +2.6 | 0.0 | 0.0 | 0.1 | +11.8 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +7.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 1.1 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +40.1 | 71.1 | 7.2 | 1.1 | +36.2 | 73.3 | 18.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 103.8 | 7.4 | 0.4 | +0.0 | 82.7 | 0.0 |
| SHOTS IN THE MOVE | 14.6 | +566.2 | 0.0 | 275.5 | 12.0 | +410.8 | 0.0 | 149.9 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.1 | +24.3 | 0.0 | 0.0 | 0.1 | +19.2 | 0.0 | 0.0 |
| SPELL WORTH | 0.9 | +20.4 | 60.4 | 55.0 | 1.7 | +29.5 | 97.1 | 93.7 |
| SPELLS IN THE FIGHT | 0.6 | +13.1 | 65.6 | 45.8 | 0.7 | -11.4 | 73.3 | 16.0 |
| STABLE ROLE | 11.2 | +0.0 | 342.8 | 192.4 | 11.2 | +0.0 | 410.0 | 131.9 |
| STANDS TO CAST | 0.1 | +0.9 | 2.4 | 0.0 | 0.0 | +2.5 | 0.0 | 0.0 |
| STOPS | 0.1 | +3.6 | 12.4 | 0.0 | 0.2 | +15.1 | 26.4 | 1.8 |
| STOPS SHORT OF THE FLANK | 0.6 | +40.5 | 0.0 | 12.3 | 0.3 | +24.7 | 0.0 | 13.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 5.7 | -49.2 | 249.1 | 104.4 | 8.0 | -70.9 | 485.6 | 58.3 |
| SUPPORTS | 4.2 | +61.4 | 134.2 | 45.1 | 5.2 | +75.6 | 259.3 | 31.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.1 | 4.6 | 0.0 | 0.1 | -1.7 | 9.6 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -0.1 | 0.0 | 23.4 | 0.9 | -2.8 | 15.7 | 35.5 |
| THROUGH LINE OF FIRE | 0.2 | +14.2 | 0.0 | 0.0 | 0.4 | +25.9 | 0.0 | 13.9 |
| TURN WORTH | 0.2 | -14.4 | 5.1 | 12.5 | 0.2 | -16.5 | 27.4 | 9.4 |
| TWO OR MORE ARRIVE | 0.2 | +2.0 | 8.2 | 0.0 | 0.4 | +1.8 | 16.1 | 25.1 |
| WAIT AFTER COSTS | 5.4 | -273.0 | 190.2 | 90.7 | 8.7 | -413.1 | 308.1 | 212.4 |
| WALKS TO THE FIGHT | 1.2 | +30.2 | 19.5 | 15.7 | 1.4 | +8.4 | 43.4 | 16.2 |
| WAR ENGINE CHARGES | 0.1 | +7.6 | 12.9 | 0.0 | 0.1 | +2.4 | 1.1 | 2.1 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 28.9 | 14.4 | 0.4 | +0.0 | 20.6 | 19.4 |
| WEARS DOWN | 1.2 | +50.3 | 142.3 | 42.5 | 1.6 | +42.6 | 120.4 | 65.4 |
| WHO HITS BACK | 0.3 | +9.6 | 0.0 | 24.5 | 0.2 | +19.1 | 0.0 | 2.4 |
| WHOLE FIGHT | 0.1 | +5.5 | 12.4 | 6.4 | 0.2 | +3.1 | 21.5 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +28.7 | 30.1 | 8.4 | 0.6 | +40.9 | 16.4 | 3.9 |
| WIDER SPREAD | 2.4 | -4.2 | 175.8 | 112.5 | 3.9 | -7.4 | 329.9 | 55.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 7.6 | 0.0 |

### Rule changes: os-h2h-opp-779e261-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1204 | 1204 | 1204 | 33.44 | -58891 | -48.9 |
| BEST FIRST | 234 | 234 | 234 | 6.50 | +10508 | +44.9 |
| PATHS CROSS | 182 | 182 | 182 | 5.06 | +11620 | +63.8 |
| SEARCH SPOT | 182 | 182 | 176 | 4.89 | +9045 | +51.4 |
| SUPPORTS | 337 | 337 | 155 | 4.31 | +1974 | +12.7 |
| MOVE TO CHARGE | 289 | 289 | 154 | 4.28 | +5629 | +36.6 |
| FACES THE THREAT | 143 | 143 | 143 | 3.97 | +9600 | +67.1 |
| KILLS COUNT NEXT TURN | 432 | 432 | 133 | 3.69 | +3955 | +29.7 |
| COUNTER-CHARGE COVER | 433 | 245 | 101 | 2.81 | +6949 | +68.8 |
| SHOTS IN THE MOVE | 957 | 630 | 88 | 2.44 | +2486 | +28.2 |
| FALLBACK BY WORTH | 381 | 381 | 79 | 2.19 | +4512 | +57.1 |
| FOLLOW UP WEIGHED | 79 | 79 | 79 | 2.19 | +9740 | +123.3 |
| WAIT AFTER COSTS | 508 | 508 | 74 | 2.06 | +1482 | +20.0 |
| SAFER THAN THE JOB | 72 | 72 | 72 | 2.00 | +4217 | +58.6 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| RESERVE FALL BACK | 52 | 52 | 52 | 1.44 | +1410 | +27.1 |
| BEST FACING | 50 | 50 | 50 | 1.39 | +2458 | +49.2 |
| BEST OVERALL | 50 | 50 | 50 | 1.39 | +2998 | +60.0 |
| MAX FOR POSITIONING | 455 | 272 | 45 | 1.25 | +533 | +11.8 |
| WALKS TO THE FIGHT | 97 | 97 | 45 | 1.25 | +538 | +12.0 |
| CHAFF IN THE MOVE | 67 | 65 | 43 | 1.19 | +1055 | +24.5 |
| KILLS COUNT | 144 | 143 | 43 | 1.19 | +1576 | +36.7 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 42 | 1.17 | +1259 | +30.0 |
| RISK BY ARC | 200 | 192 | 42 | 1.17 | +1010 | +24.1 |
| SET UP TOGETHER | 94 | 82 | 42 | 1.17 | +2630 | +62.6 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MARCH CHECK | 41 | 41 | 38 | 1.06 | +1964 | +51.7 |
| MISSILES IN THE MOVE | 267 | 163 | 38 | 1.06 | +687 | +18.1 |
| SHOOTS FROM THE BEST SPOT | 82 | 82 | 38 | 1.06 | +1110 | +29.2 |
| SHOT REPLANNED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +3683 | +102.3 |
| CHARGE NOW FIRST | 161 | 161 | 35 | 0.97 | -2302 | -65.8 |
| CANNON PLANNED TARGET | 235 | 235 | 34 | 0.94 | -73 | -2.2 |
| REDIRECT COUNTER | 227 | 114 | 34 | 0.94 | +4253 | +125.1 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +2347 | +69.0 |
| COVER ONCE | 246 | 155 | 33 | 0.92 | +659 | +20.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| HONEST WORTH | 629 | 624 | 30 | 0.83 | +214 | +7.1 |
| KEEPS ITS TARGET | 137 | 136 | 28 | 0.78 | +461 | +16.5 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +238 | +8.8 |
| ADVANCE WORTH | 187 | 187 | 26 | 0.72 | +497 | +19.1 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| IDLE COST | 699 | 407 | 23 | 0.64 | +304 | +13.2 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1443 | +62.7 |
| BEST PREY | 58 | 58 | 22 | 0.61 | +813 | +37.0 |
| CASTING BLOCK | 29 | 29 | 21 | 0.58 | +697 | +33.2 |
| INVITES THE FIGHT | 77 | 77 | 19 | 0.53 | +238 | +12.5 |
| MANOEUVRE | 22 | 22 | 19 | 0.53 | +582 | +30.6 |
| ONE FIGHT FORMULA | 317 | 186 | 19 | 0.53 | +30 | +1.6 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +844 | +44.4 |
| RISK ONCE | 112 | 88 | 19 | 0.53 | +514 | +27.0 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +871 | +45.8 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +1116 | +62.0 |
| WEARS DOWN | 98 | 92 | 18 | 0.50 | +466 | +25.9 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -5 | -0.3 |
| WHOLE FIGHT GAIN | 38 | 34 | 17 | 0.47 | +705 | +41.5 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MARCH ODDS | 17 | 17 | 16 | 0.44 | +320 | +20.0 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +5984 | +374.0 |
| WAR ENGINE JOBS | 33 | 33 | 16 | 0.44 | -822 | -51.4 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +479 | +36.9 |
| MAKE SURE TOGETHER | 30 | 22 | 12 | 0.33 | +592 | +49.3 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | +15 | +1.4 |
| CAST JOB | 48 | 48 | 11 | 0.31 | +258 | +23.5 |
| HUNT IN PAIRS | 30 | 25 | 11 | 0.31 | +572 | +52.0 |
| REFUSING RETIRES | 21 | 21 | 11 | 0.31 | -3 | -0.3 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +524 | +52.4 |
| SUPPORT NARROWED | 493 | 493 | 9 | 0.25 | -80 | -8.8 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MISSILES NEXT TURN | 312 | 182 | 7 | 0.19 | +25 | +3.6 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -102 | -14.5 |
| WIDER SPREAD | 225 | 215 | 7 | 0.19 | +28 | +4.0 |
| LOST CHARGE | 187 | 186 | 6 | 0.17 | +119 | +19.8 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -182 | -30.4 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +85 | +17.0 |
| OPENS UP | 9 | 9 | 5 | 0.14 | +291 | +58.2 |
| SPELLS IN THE FIGHT | 47 | 46 | 5 | 0.14 | +79 | +15.8 |
| BACKUP TARGETS | 78 | 42 | 4 | 0.11 | +52 | +12.9 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +217 | +54.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 20 | 20 | 4 | 0.11 | -221 | -55.2 |
| LONG SHOT | 44 | 43 | 4 | 0.11 | +110 | +27.5 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| STOPS | 10 | 10 | 4 | 0.11 | +42 | +10.6 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -95 | -31.8 |
| DEFENSIVE ARMY | 13 | 13 | 3 | 0.08 | -132 | -44.1 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -70 | -23.3 |
| WAR ENGINE CHARGES | 6 | 6 | 3 | 0.08 | +110 | +36.7 |
| CARRIES OUT SET-UP | 12 | 12 | 2 | 0.06 | -187 | -93.6 |
| CHARGER SLAIN LOST | 39 | 35 | 2 | 0.06 | +72 | +36.1 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 25 | 25 | 2 | 0.06 | +22 | +11.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +106 | +53.1 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +96 | +47.8 |
| TWO OR MORE ARRIVE | 21 | 20 | 2 | 0.06 | +14 | +6.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -108 | -107.8 |
| BLOWS WHERE AIMED | 22 | 21 | 1 | 0.03 | +83 | +82.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +14.2 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -57 | -56.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +22 | +22.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| HUNT ADVANCE | 15 | 15 | 1 | 0.03 | +9 | +9.3 |
| JOINT CHARGE PLAN | 10 | 10 | 1 | 0.03 | +62 | +61.6 |
| MOVE SPELL IN RANGE | 5 | 4 | 1 | 0.03 | +1 | +1.1 |
| ONE OBJECTIVE FORMULA | 95 | 48 | 1 | 0.03 | +33 | +32.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -164 | -164.3 |
| SURE REACH TOGETHER | 50 | 31 | 1 | 0.03 | +15 | +15.3 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -7 | -6.7 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 42 | 42 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 21 | 20 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 439 | not checked | - | - | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 32 | 32 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 21 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 424 | 424 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2832 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 50 | 50 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 35 | 35 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 807 | 805 | 0 | 0.00 | - | - |
| TURN WORTH | 15 | 15 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-opp-779e261-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.44 | 16.17 | 49.4 |
| FALLBACK | gate | 0.75 | 0.83 | 59.2 |
| TURN GATE | gate | 0.86 | 0.33 | 33.0 |
| CHARGE NOW FIRST | rule | 0.44 | 0.53 | 65.8 |
| WAR ENGINE JOBS | rule | 0.22 | 0.22 | 51.4 |
| SUPPORT REQUEST | gate | 0.11 | 0.19 | 88.7 |
| AFTERMATH BAND | gate | 0.08 | 0.19 | 1.8 |
| SUPPORT NARROWED | rule | 0.11 | 0.14 | 8.8 |
| PATHS CROSS | rule | 0.17 | 0.06 | 52.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.14 | 41.7 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.08 | 19.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.11 | 14.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 29.0 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.11 | 30.4 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 1.0 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.08 | 21.1 |
| CATCH ODDS | rule | - | 0.08 | 31.8 |
| DEFENSIVE ARMY | rule | 0.03 | 0.06 | 44.1 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.03 | 8.3 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 112.7 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 93.6 |
| FIGHT ORDER BAND | gate | 0.06 | - | 2.3 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 1.3 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 110.5 |
| NO REASON | gate | - | 0.06 | 3.6 |
| THROUGH LINE OF FIRE | rule | - | 0.06 | 1.5 |
| BEST PRIZE | rule | 0.03 | - | 107.8 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 56.9 |
| FACES THE THREAT | rule | 0.03 | - | 7.5 |
| PURSUES BIG PREY | rule | 0.03 | - | 164.3 |
| REDIRECT WEIGHED | rule | 0.03 | - | 107.8 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| STANDS TO CAST | rule | - | 0.03 | 71.8 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 9.2 |
| WHO HITS BACK | rule | - | 0.03 | 1.6 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 6.7 |

### Plans: os-h2h-opp-779e261-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 18% | 478 | 360 | 75% |
| Mine | charge | 2.6 | 57% | 235 | 226 | 96% |
| Mine | close in | 3.9 | 24% | 185 | 124 | 67% |
| Mine | hold | 4.4 | 28% | 282 | 0 | 0% |
| Mine | join | 0.7 | 92% | 24 | 0 | 0% |
| Mine | shoot | 8.8 | 67% | 278 | 799 | 288% |
| Mine | support | 4.6 | 93% | 40 | 0 | 0% |
| Opponent | advance | 11.7 | 12% | 192 | 216 | 112% |
| Opponent | charge | 4.8 | 57% | 409 | 346 | 85% |
| Opponent | close in | 6.5 | 23% | 398 | 125 | 31% |
| Opponent | hold | 4.3 | 39% | 298 | 0 | 0% |
| Opponent | join | 1.1 | 100% | 51 | 0 | 0% |
| Opponent | shoot | 6.0 | 60% | 210 | 368 | 175% |
| Opponent | support | 6.9 | 91% | 66 | 0 | 0% |

### Packages: hunt the guns, os-h2h-opp-779e261-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 67% | 67% | 0% | 2.0 | 258 | 149 | 67% | 44 |
| Opponent | 0.4 | 14 | 0 | 29% | 29% | 0% | 2.5 | 339 | 127 | 29% | 54 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Chaos Dwarfs | 0.5 | 2 | 1 | 100% | 100% | 0% | 2.0 | 278 | 202 | 100% | 222 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 304 | 0 | 0% | 18 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| High Elf Realms | 0.5 | 2 | 0 | 50% | 50% | 0% | 2.0 | 248 | 123 | 50% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 100% | 100% | 0% | 2.5 | 562 | 446 | 100% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 85 |
| Tomb Kings of Khemri | 1.2 | 6 | 0 | 0% | 0% | 0% | - | 128 | 0 | 0% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 489 | 0 | 0% | 27 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 446 | 0 | 0% | 0 |

### Battle groups: os-h2h-opp-779e261-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 12.0 | 18% | 51% | 15% | 17% | 48% | 10% | 19% | 22% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 30% | 60% | 12% | 0% | 18% | 0% | 14% | 68% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 23% | 70% | 18% | 17% | 30% | 0% | 15% | 56% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-opp-779e261-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 32 | 20% | 2.5 | 0 (1) | 0 (4) | - | 0 (1) | 0 (4) |
| Mine | Chaff | 34 | 72 (34) | 30 | 43 | 58 | 35% | 2.7 | 58 (19) | 189 (7) | 5 (8) | 103 (23) | 5 (11) |
| Mine | Character | 123 | 51 (123) | 50 | 1 | 36 | 20% | 2.5 | 50 (41) | 58 (52) | 38 (13) | 62 (55) | 43 (51) |
| Mine | Clean-up | 21 | 47 (21) | 11 | 36 | 27 | 52% | 3.0 | 14 (5) | 37 (13) | 182 (3) | 91 (13) | 1 (8) |
| Mine | Fast | 1 | 480 (1) | 480 | 0 | 0 | 0% | 4.0 | - | 480 (1) | - | 480 (1) | - |
| Mine | Fast Hammer | 48 | 41 (48) | 27 | 14 | 40 | 17% | 3.0 | 26 (23) | 64 (16) | 58 (9) | 61 (29) | 12 (19) |
| Mine | Fragile | 5 | 185 (5) | 185 | 0 | 0 | 0% | 1.6 | - | 75 (3) | 351 (2) | 185 (5) | - |
| Mine | Hammer | 57 | 40 (57) | 32 | 8 | 36 | 14% | 2.7 | 26 (18) | 59 (29) | 12 (10) | 48 (38) | 27 (19) |
| Mine | Holder | 28 | 29 (28) | 6 | 24 | 33 | 50% | 2.7 | 46 (9) | 32 (11) | 0 (8) | 29 (20) | 29 (8) |
| Mine | Shooter | 41 | 60 (41) | 18 | 42 | 47 | 5% | 1.6 | 118 (5) | 59 (30) | 29 (6) | 80 (25) | 29 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 27 (59) | 27 | 0 | 55 | 2% | 1.2 | 3 (10) | 38 (37) | 8 (12) | 17 (10) | 29 (49) |
| Mine | Wizard | 22 | 30 (22) | 30 | 0 | 36 | 5% | 2.1 | 0 (6) | 64 (8) | 44 (3) | 36 (6) | 32 (11) |
| Opponent | Blocker | 2 | 99 (2) | 99 | 0 | 38 | 0% | 4.5 | 159 (1) | 0 (1) | - | 159 (1) | 0 (1) |
| Opponent | Chaff | 76 | 63 (76) | 24 | 39 | 38 | 41% | 2.4 | 92 (32) | 29 (19) | 57 (25) | 73 (54) | 39 (22) |
| Opponent | Character | 97 | 47 (97) | 47 | 0 | 38 | 25% | 2.4 | 52 (38) | 52 (41) | 12 (6) | 46 (59) | 56 (26) |
| Opponent | Clean-up | 19 | 25 (19) | 20 | 5 | 35 | 37% | 2.8 | 15 (9) | 42 (10) | - | 34 (14) | 0 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 48 | 35 (48) | 24 | 11 | 44 | 21% | 2.6 | 47 (22) | 19 (16) | 37 (10) | 37 (28) | 31 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 39 | 60% | 2.0 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Opponent | Hammer | 70 | 33 (70) | 27 | 6 | 44 | 24% | 2.9 | 42 (17) | 30 (42) | 31 (11) | 34 (43) | 31 (27) |
| Opponent | Holder | 35 | 103 (35) | 18 | 85 | 32 | 20% | 3.1 | 61 (8) | 121 (23) | 68 (4) | 118 (23) | 72 (12) |
| Opponent | Shooter | 33 | 85 (33) | 25 | 60 | 12 | 0% | 1.8 | 28 (8) | 94 (19) | 123 (6) | 112 (22) | 43 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | War machine | 24 | 55 (24) | 55 | 0 | 23 | 12% | 1.4 | 17 (6) | 74 (14) | 42 (4) | 0 (3) | 64 (21) |
| Opponent | Wizard | 26 | 11 (26) | 11 | 0 | 28 | 12% | 1.7 | 0 (10) | 24 (7) | 12 (5) | 29 (6) | 5 (16) |

### Charged fights: os-h2h-opp-779e261-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 140 | 97 | 1.8 | 1.0 | 56 | 22 | +33 | 4 of 7 | 4 of 7 | - | +33 |
| Mine | Chaos Dwarfs | 4 | 87 | 533 | 3.2 | 1.2 | 164 | 13 | +151 | 6 of 13 | 12 of 13 | +248 | +133 |
| Mine | Dwarfen Mountain Holds | 4 | 457 | 84 | 2.5 | 1.1 | 34 | 0 | +34 | 3 of 10 | 6 of 10 | +0 | +38 |
| Mine | Empire of Man | 5 | 324 | 70 | 2.2 | 1.2 | 32 | 26 | +6 | 3 of 11 | 9 of 11 | +128 | -21 |
| Mine | Grand Cathay | 4 | 328 | 568 | 3.0 | 1.2 | 189 | 18 | +171 | 6 of 12 | 11 of 12 | +386 | +128 |
| Mine | High Elf Realms | 4 | 62 | 587 | 4.2 | 1.2 | 138 | 17 | +121 | 5 of 17 | 15 of 17 | +65 | +133 |
| Mine | Kingdom of Bretonnia | 1 | 170 | 699 | 5.0 | 1.0 | 140 | 94 | +46 | 2 of 5 | 4 of 5 | - | +46 |
| Mine | Lizardmen | 1 | 45 | 114 | 4.0 | 1.2 | 28 | 125 | -96 | 1 of 4 | 3 of 4 | +60 | -148 |
| Mine | Ogre Kingdoms | 1 | 125 | 0 | 3.0 | 1.3 | 0 | 108 | -108 | 1 of 3 | 2 of 3 | +0 | -162 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 762 | 4.0 | 1.2 | 190 | 14 | +177 | 1 of 4 | 4 of 4 | +45 | +221 |
| Mine | Skaven | 2 | 398 | 0 | 1.5 | 1.0 | 0 | 123 | -123 | 1 of 3 | 1 of 3 | - | -123 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 349 | 5.0 | 1.0 | 70 | 0 | +70 | 1 of 5 | 5 of 5 | - | +70 |
| Mine | Vampire Counts | 3 | 0 | 42 | 2.7 | 1.1 | 16 | 29 | -13 | 1 of 8 | 5 of 8 | -229 | +18 |
| Mine | Warriors of Chaos | 1 | 0 | 342 | 4.0 | 1.0 | 86 | 43 | +42 | 1 of 4 | 3 of 4 | - | +42 |
| **Mine** | all armies | 36 | 196 | 284 | 2.9 | 1.1 | 96 | 31 | +66 | 36 of 106 | 84 of 106 | +114 | +58 |
| Opponent | Dwarfen Mountain Holds | 2 | 273 | 190 | 3.5 | 1.4 | 54 | 0 | +54 | 1 of 7 | 3 of 7 | +50 | +58 |
| Opponent | Empire of Man | 2 | 445 | 0 | 1.0 | 1.5 | 0 | 190 | -190 | 1 of 2 | 2 of 2 | +0 | -380 |
| Opponent | Grand Cathay | 2 | 518 | 586 | 3.0 | 1.3 | 195 | 0 | +195 | 4 of 6 | 5 of 6 | +474 | +139 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 120 | 1.0 | 1.0 | 120 | 0 | +120 | 0 of 1 | 1 of 1 | - | +120 |
| Opponent | Ogre Kingdoms | 3 | 0 | 415 | 3.7 | 1.1 | 113 | 9 | +104 | 2 of 11 | 9 of 11 | +147 | +100 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 114 | 547 | 4.0 | 1.1 | 137 | 86 | +51 | 7 of 16 | 11 of 16 | +95 | +48 |
| Opponent | Vampire Counts | 6 | 15 | 637 | 3.8 | 1.2 | 166 | 41 | +125 | 9 of 23 | 17 of 23 | +177 | +114 |
| Opponent | Warriors of Chaos | 8 | 0 | 343 | 2.1 | 1.2 | 161 | 15 | +147 | 8 of 17 | 10 of 17 | +27 | +183 |
| Opponent | Wood Elf Realms | 7 | 93 | 556 | 5.3 | 1.0 | 105 | 21 | +84 | 10 of 37 | 28 of 37 | +265 | +79 |
| **Opponent** | all armies | 36 | 108 | 432 | 3.3 | 1.1 | 130 | 32 | +98 | 42 of 120 | 86 of 120 | +122 | +94 |

### Effective charges: os-h2h-opp-779e261-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +122) | 0 | 2 (net -52) | 0 | 0 | 1 (net +20) | 3 | 50% (2 of 4) |
| Mine | Chaos Dwarfs | 13 | 4 (net +150) | 0 | 2 (net +424) | 1 (net +70) | 3 (net +42) | 3 (net +104) | 0 | 15% (2 of 13) |
| Mine | Dwarfen Mountain Holds | 10 | 2 (net +0) | 0 | 3 (net +0) | 2 (net +0) | 0 | 2 (net +56) | 1 | 33% (3 of 9) |
| Mine | Empire of Man | 11 | 3 (net +0) | 0 | 2 (net -140) | 1 (net +0) | 0 | 3 (net +0) | 2 | 22% (2 of 9) |
| Mine | Grand Cathay | 12 | 2 (net +495) | 0 | 3 (net +6) | 2 (net +122) | 1 (net +40) | 4 (net +190) | 0 | 25% (3 of 12) |
| Mine | High Elf Realms | 17 | 0 | 2 (net +72) | 3 (net +75) | 6 (net +131) | 2 (net +98) | 3 (net +177) | 1 | 19% (3 of 16) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 3 (net -89) | 2 (net +247) | 0 | 0 | 0 | 60% (3 of 5) |
| Mine | Lizardmen | 4 | 1 (net -499) | 0 | 2 (net +30) | 1 (net +54) | 0 | 0 | 0 | 50% (2 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +663) | 0 | 1 (net +45) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Skaven | 3 | 1 (net -192) | 0 | 0 | 0 | 0 | 2 (net -89) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +114) | 2 (net +118) | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 8 | 1 (net +0) | 1 (net +0) | 0 | 2 (net -114) | 0 | 2 (net +0) | 2 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 1 (net +0) | 0 | 1 (net +342) | 1 (net +0) | 1 | 33% (1 of 3) |
| Opponent | Dwarfen Mountain Holds | 7 | 2 (net +32) | 0 | 0 | 3 (net +50) | 0 | 2 (net +83) | 0 | 0% (0 of 7) |
| Opponent | Empire of Man | 2 | 1 (net -380) | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 6 | 1 (net +0) | 0 | 2 (net +372) | 2 (net +112) | 0 | 1 (net +202) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 1 (net +120) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Ogre Kingdoms | 11 | 4 (net +97) | 0 | 2 (net +304) | 1 (net +0) | 0 | 3 (net +49) | 1 | 20% (2 of 10) |
| Opponent | Tomb Kings of Khemri | 16 | 4 (net -260) | 0 | 1 (net +0) | 6 (net +190) | 0 | 4 (net +179) | 1 | 7% (1 of 15) |
| Opponent | Vampire Counts | 23 | 5 (net +148) | 2 (net +150) | 3 (net +145) | 3 (net +105) | 2 (net +138) | 3 (net +155) | 5 | 17% (3 of 18) |
| Opponent | Warriors of Chaos | 17 | 6 (net +107) | 1 (net +0) | 2 (net +0) | 0 | 0 | 7 (net +231) | 1 | 12% (2 of 16) |
| Opponent | Wood Elf Realms | 37 | 5 (net +253) | 0 | 8 (net +78) | 8 (net +65) | 0 | 12 (net +35) | 4 | 24% (8 of 33) |

### Charged fights, damage counted: os-h2h-opp-779e261-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 209 | 255 | +105 | 188 | 67 | +121 | +57.9 |
| Mine | 50-54% | 3 | 103 | 153 | +48 | 67 | 28 | +39 | +37.4 |
| Mine | Effective (55-75%) | 22 | 268 | 209 | +25 | 99 | 81 | +18 | +6.7 |
| Mine | 76-89% | 19 | 275 | 158 | +81 | 115 | 36 | +79 | +28.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 267 | 189 | +65 | 127 | 24 | +103 | +38.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 395 | 90 | +104 | 110 | 31 | +79 | +20.0 |
| Mine | No odds | 13 | 242 | 216 | +44 | 104 | 58 | +46 | +18.8 |
| Mine | All fights | 106 | 263 | 191 | +66 | 122 | 49 | +73 | +27.7 |
| Opponent | Long shot (under 50%) | 28 | 223 | 253 | +60 | 189 | 109 | +80 | +35.7 |
| Opponent | 50-54% | 3 | 260 | 339 | +100 | 166 | 20 | +146 | +56.2 |
| Opponent | Effective (55-75%) | 19 | 309 | 242 | +133 | 182 | 55 | +127 | +41.1 |
| Opponent | 76-89% | 23 | 202 | 132 | +102 | 109 | 5 | +104 | +51.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 247 | 168 | +117 | 153 | 38 | +116 | +46.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 404 | 122 | +92 | 112 | 10 | +101 | +25.0 |
| Opponent | No odds | 12 | 294 | 132 | +71 | 90 | 28 | +62 | +21.1 |
| Opponent | All fights | 120 | 251 | 192 | +98 | 151 | 49 | +102 | +40.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-opp-779e261-p2 | move | 422 | 85 (20%) | 61 (14%) | 57 (14%) | 280 (66%) |
| os-h2h-opp-779e261-p2 | objective | 380 | 58 (15%) | 47 (12%) | 44 (12%) | 278 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

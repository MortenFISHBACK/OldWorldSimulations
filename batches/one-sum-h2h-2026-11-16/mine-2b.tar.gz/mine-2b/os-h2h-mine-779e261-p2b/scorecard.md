# Doctrine scorecard: os-h2h-mine-779e261-p2b

### Scorecard: os-h2h-mine-779e261-p2b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 1 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | yes | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 5 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 5 | 0 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 9 | 4 | 1 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 6 | - | 0 | 2 | 1 | 0 | 0 | 479 |
| L1323 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 60 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 177 |
| L1435 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 2 | 6 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 485 |
| L2029 | 1 | 1 | Opponent | no | 4 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 8 | - | 1 | 3 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 2 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 125 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 9 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 2.5 | 3.0 | 1.7 | 1.1 | 0.3 | 0.0 | 0.0 | 171.0 |
| **Average** | | | Opponent | 38% | 1.8 | 2.7 | 3.7 | 1.6 | 0.3 | 0.0 | 0.0 | 89.6 |

### KPIs: os-h2h-mine-779e261-p2b

Rules off - Opponent only: ADVANCE WORTH, IDLE COST, RISK ONCE, ONE FIGHT FORMULA, COVER ONCE, CHAFF IN THE MOVE, ONE OBJECTIVE FORMULA.

Morten 2026-11-10; 18 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 11% (10 of 90) | 9% (8 of 88) | 10% (18 of 178) |
| Winner chose to follow up after the loser gave ground |  | 96% (27 of 28); on the table 96% | 100% (32 of 32); on the table 100% | 98% (59 of 60); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 86% (6 of 7); on the table 86% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fled |  | 79% (11 of 14); on the table 79% | 90% (18 of 20); on the table 90% | 85% (29 of 34); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 91% (43 of 47); on the table 91% | 95% (56 of 59); on the table 95% | 93% (99 of 106); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 27% (40 of 150) | 35% (21 of 60) | 29% (61 of 210) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (40 of 106) | 50% (21 of 42) | 41% (61 of 148) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (9 of 17) | 60% (18 of 30) | 57% (27 of 47) |
| Points that never fought | lower | 30% (10678 of 35993) | 40% (14447 of 35997) | 35% (25125 of 71990) |
|   infantry points that never fought | lower | 38% (2426 of 6433) | 68% (4605 of 6813) | 53% (7031 of 13246) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (78 of 132) | 61% (97 of 159) | 60% (175 of 291) |
| Bound items with a magic missile used (at least once a game) |  | 100% (12 of 12); 2.1 uses a game | 73% (8 of 11); 1.5 uses a game | 87% (20 of 23); 1.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.7 uses a game | 0.0 uses a game | 43% (6 of 14); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.2 uses a game | 0% (0 of 1); 0.0 uses a game | 44% (4 of 9); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (17619 of 31434) | 57% (18852 of 33027) | 57% (36471 of 64461) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (16%) | 1.0 (46%) | 2.0 (24%) |
| MARCHED: its unit marched | 1.9 (31%) | 0.1 (3%) | 1.9 (23%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (23%) | 0.1 (5%) | 1.5 (18%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.1 (17%) | 0.7 (31%) | 1.7 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (10%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.3 (5%) | 0.1 (5%) | 0.4 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 2.1 | 1.4 | 3.4 | 0.4 | 2.6 |
| not cast | 4.8 | 4.3 | 4.3 | 8.3 | 1.9 | 23.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (41%) | 0.1 (3%) | 2.0 (24%) | 0.6 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (23%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.3 (8%) | 0.5 (12%) | 1.5 (18%) | 0.1 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.1 (3%) | 0.5 (12%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 1.4 (29%) | 1.5 (35%) | 1.5 (35%) | 1.7 (21%) | 0.3 (14%) | 4.9 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.2 (5%) | 0.2 (5%) | 0.2 (3%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.6 (31%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.6 (55%) | 0.1 (1%) | 1.3 (30%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.1 a game | 0.7 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | 58% (11 of 19) | 59% (13 of 22) |
| the unit moved after it | 100% (2 of 2) | 36% (4 of 11) | 46% (6 of 13) |
| it charged on its next turn | 0% (0 of 2) | 9% (1 of 11) | 8% (1 of 13) |
| the enemy charged it first | 50% (1 of 2) | 9% (1 of 11) | 15% (2 of 13) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 11) | 0% (0 of 13) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 9% (1 of 11) | 8% (1 of 13) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 73% (8 of 11) | 69% (9 of 13) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (186 of 313) | 54% (168 of 310) | 57% (354 of 623) |
|   cavalry | 79% (30 of 38) | 49% (52 of 107) | 57% (82 of 145) |
|   character | 25% (12 of 48) | 32% (17 of 53) | 29% (29 of 101) |
|   chariot | 62% (21 of 34) | 87% (13 of 15) | 69% (34 of 49) |
|   infantry | 58% (69 of 120) | 63% (76 of 121) | 60% (145 of 241) |
|   monster | 39% (9 of 23) | 71% (10 of 14) | 51% (19 of 37) |
|   war machine | 90% (45 of 50) | - | 90% (45 of 50) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (20%) | 2.6 (32%) | 3.9 (26%) |
| CHARGED: it charged | 0.8 (12%) | 1.6 (20%) | 2.4 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (15%) | 0.4 (6%) | 1.5 (10%) |
| NO TARGET IN RANGE | 1.8 (25%) | 1.4 (18%) | 3.2 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (9%) | 0.2 (2%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (17%) | 1.6 (20%) | 2.8 (19%) |
| OTHER BAR | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.9 | 1.1 | 89% | 4.5 pts | 31 pts |
| character | 1.9 | 0.4 | 86% | 6.6 pts | 13 pts |
| chariot | 1.9 | 0.9 | 74% | 12.9 pts | 25 pts |
| infantry | 11.3 | 4.0 | 75% | 9.5 pts | 107 pts |
| monster | 1.1 | 0.2 | 84% | 8.7 pts | 9 pts |
| war machine | 2.5 | 1.6 | 64% | 18.4 pts | 46 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.4 | 5.4 |
| Charges that made contact a game | 3.3 | 3.8 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.53 contact (15 units) | 1.33 declared, 1.00 contact (3 units) | 0.78 declared, 0.61 contact (18 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.57 contact (7 units) | 1.25 declared, 0.75 contact (8 units) | 0.93 declared, 0.67 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.37 contact (128 units) | 0.66 declared, 0.39 contact (153 units) | 0.59 declared, 0.38 contact (281 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (30 of 49) | 67% (8 of 12) | 33% (3 of 9) | 59% (41 of 70) |
| Character in a unit | 100% (12 of 12) | 86% (6 of 7) | 33% (1 of 3) | 86% (19 of 22) |
| Character on its own | 67% (12 of 18) | 76% (16 of 21) | 38% (15 of 39) | 55% (43 of 78) |
| Chariot | 64% (7 of 11) | - | - | 64% (7 of 11) |
| Infantry | 58% (30 of 52) | 67% (8 of 12) | - | 59% (38 of 64) |
| Monster | 57% (8 of 14) | 71% (5 of 7) | - | 62% (13 of 21) |
| Monstrous | 36% (4 of 11) | 75% (6 of 8) | - | 53% (10 of 19) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 100% (4 of 4); on the table 100% | 29% (21 of 72) | 51% | 56% (14 of 25) | 100% (7 of 7); 8.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 4 | 75% (9 of 12); on the table 75% | 6% (1 of 18) | 31% | 52% (17 of 33) | 100% (3 of 3); 1.5 uses a game | 43% (6 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (6 of 6); on the table 100% | - | 33% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 31% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 39% | 81% (17 of 21) | 100% (3 of 3); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 100% (8 of 8); on the table 100% | 42% (5 of 12) | 21% | 56% (9 of 16) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (1 of 1); on the table 100% | - | 36% | 10% (1 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 96% (23 of 24); on the table 96% | 42% (20 of 48) | 33% | 65% (24 of 37) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 94% (32 of 34); on the table 94% | 42% (5 of 12) | 30% | 57% (33 of 58) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 6 | 93% (13 of 14); on the table 93% | 38% (9 of 24) | 46% | 69% (48 of 70) | 57% (4 of 7); 2.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (os-h2h-mine-779e261-p2b, 18 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (22) | 48% (16) | 49% (38) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.50 | 1.39 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.17 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.72 | 0.22 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.44 | 1.83 | 4.28 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 0.56 | 1.83 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.33 | 6.33 | 13.67 |

### Quality by phase: os-h2h-mine-779e261-p2b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.9 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 61% (41 of 67) | 44% (44 of 99) |
| Strategy | Shoot objectives carried out (shot that target) | 51% (60 of 118) | 44% (40 of 91) |
| Strategy | Close-in objectives charged next turn | 15% (14 of 96) | 19% (19 of 102) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | 46% (6 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 21% (3 of 14) | 43% (6 of 14) |
| Strategy | Joined characters whose unit fought | 58% (7 of 12) | 32% (6 of 19) |
| Strategy | Lone characters that fought | 78% (40 of 51) | 72% (29 of 40) |
| Movement | Charges halted short of contact | 0.1 | 0.5 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 171.0 | 89.6 |
| Movement | Fights charged into per game | 2.6 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 42, net -183 | 10 of 57, net +53 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 42, net +36 | 15 of 57, net +221 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 42, net +147 | 1 of 57, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 42, net +114 | 17 of 57, net +144 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (48 of 161) | 58% (106 of 184) |
| Shooting | Points destroyed by shooting units | 67.1 | 67.6 |
| Shooting | War machine shots | 2.5 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (28 of 45) | - |
| Shooting | Points destroyed by war machines | 12.2 | 6.8 |
| Magic | Magic missiles cast | 1.9 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (10 of 34) | 38% (5 of 13) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.5 |
| Magic | Wounds caused by other spells | 2.3 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 33.2 | 14.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.9 / 1.3 / 0.2 | 1.2 / 0.8 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 267.6 | 469.9 |
| Combat | Points run down | 100.7 | 180.3 |
| Combat | Net points per charged fight, damage counted | +86 | +125 |
| Combat | Net per 100 charger points, damage counted | +27.0 | +56.7 |
| Combat | First round won (charged fights) | 80% | 63% |
| Combat | Net points per charged fight | +73 | +129 |
| Combat | Net points per supported fight / lone fight | +206 / +32 | +424 / +98 |
| Combat | Charged fights on a top-3 enemy unit | 17 of 47 | 25 of 63 |
| Game | Points lost | 848.3 | 659.2 |
| Game | VP from objectives | 586.1 | 611.1 |
| Game | Lone holders (player turns) | 2.5 | 1.8 |

- Mine won / drew / lost: 6 / 2 / 10 of 18 ended games (of 18); mean margin (Mine - Opponent) -248 VP
- The side that went first won 9 of 16 games with a winner
- Points traded per game (both sides' losses): 1507
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: os-h2h-mine-779e261-p2b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.9 | -107.9 | 117.6 | 113.3 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +1.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.4 | +0.0 | 0.0 | 18.3 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +3.2 | 0.0 | 0.0 | 1.1 | +8.3 | 0.0 | 53.9 |
| BEST FACING | 0.4 | +26.2 | 0.0 | 26.3 | 0.7 | +30.1 | 0.0 | 16.5 |
| BEST FIRST | 1.6 | +95.5 | 0.0 | 51.7 | 5.2 | +218.0 | 169.9 | 63.1 |
| BEST OVERALL | 0.5 | +10.3 | 0.0 | 10.3 | 0.6 | +76.5 | 0.0 | 21.7 |
| BEST PREY | 0.7 | +44.1 | 8.8 | 0.0 | 0.6 | +31.5 | 23.3 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | +6.5 | 9.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.7 | -0.4 | 0.0 | 22.2 | 0.2 | -2.1 | 0.0 | 33.3 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +5.6 | 0.0 | 0.0 | 0.6 | +14.0 | 0.0 | 33.3 |
| BLOWS WHERE AIMED | 0.3 | +11.8 | 33.0 | 0.0 | 0.1 | -18.1 | 0.0 | 33.3 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 13.7 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 31.6 | 5.6 | - | - | - | - |
| CANNON PLANNED TARGET | 1.8 | +25.9 | 81.0 | 18.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 15.4 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -9.0 | 28.3 | 6.9 |
| CAST JOB | 0.5 | +4.4 | 16.8 | 30.0 | 0.2 | +8.3 | 21.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +21.5 | 19.1 | 0.0 | 0.5 | +32.2 | 42.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 66.1 | 0.7 | +0.0 | 0.0 | 41.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.9 | +125.2 | 0.0 | 29.8 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 9.0 | 0.1 | -0.2 | 0.0 | 6.3 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 258.6 | 105.8 | 2.2 | +0.0 | 258.5 | 47.2 |
| CHARGE NOW WEIGHED | 0.4 | -24.9 | 0.0 | 10.3 | 0.4 | -18.8 | 3.1 | 7.0 |
| CHARGER SLAIN LOST | 0.8 | -22.0 | 96.2 | 53.5 | 0.9 | -52.9 | 77.2 | 36.6 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 9.2 | 4.4 |
| COMBAT PIVOT | 0.3 | +0.0 | 3.3 | 27.7 | 0.6 | +0.0 | 27.2 | 20.3 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 15.8 | 0.0 |
| CONVEYANCE SEARCH | 0.1 | +5.8 | 22.2 | 27.5 | 0.8 | +115.2 | 28.1 | 66.8 |
| COUNTER-CHARGE COVER | - | - | - | - | 9.6 | +932.3 | 0.0 | 284.2 |
| COVER ONCE | 9.9 | -680.3 | 0.0 | 302.5 | - | - | - | - |
| DEFENSIVE ARMY | 0.2 | +0.0 | 8.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +8.3 | 6.9 | 14.1 | 0.3 | +3.4 | 26.0 | 1.9 |
| FACES THE THREAT | 2.4 | +120.2 | 0.0 | 100.8 | 1.8 | +176.4 | 0.0 | 56.0 |
| FALLBACK BY WORTH | 4.1 | +28.1 | 0.0 | 63.2 | 5.3 | +52.5 | 0.0 | 80.9 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.1 | 0.0 | 7.0 |
| FLANK NOT WEIGHED | 6.6 | +0.0 | 0.0 | 185.8 | 6.6 | +0.0 | 0.0 | 267.2 |
| FOLLOW UP WEIGHED | 1.4 | +164.1 | 0.0 | 46.2 | 1.3 | +196.9 | 0.0 | 26.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +5.3 | 0.0 | 27.8 | 0.1 | +3.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 6.1 | 0.0 | 0.1 | -1.8 | 14.2 | 6.4 |
| GIVES UP ITS SCREEN | 0.1 | -0.4 | 10.8 | 0.0 | 0.1 | -0.1 | 6.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 10.8 | 53.9 | 0.4 | +0.0 | 84.2 | 17.8 |
| HILL BY ITS CHANCE | 0.6 | -35.1 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.6 | -130.2 | 420.8 | 201.5 | 10.4 | -191.1 | 715.1 | 241.7 |
| HORN WORTH | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.4 | 10.8 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.8 | +8.5 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| HUNT KEPT | 0.1 | +1.0 | 10.8 | 0.0 | 0.2 | +7.5 | 40.3 | 8.3 |
| HUNT RESULT | 0.1 | +12.3 | 0.0 | 0.0 | 0.3 | +110.8 | 18.3 | 3.8 |
| HUNT THE GUNS | 0.1 | +13.0 | 10.8 | 0.0 | 0.3 | +138.1 | 49.7 | 6.4 |
| IDLE COST | 16.4 | -287.3 | 0.0 | 225.8 | - | - | - | - |
| INVITES THE FIGHT | 1.2 | +6.6 | 17.5 | 48.1 | 2.1 | +40.5 | 78.3 | 61.6 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +4.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.2 | -2.0 | 52.3 | 0.0 | 0.2 | -5.2 | 36.0 | 1.7 |
| KEEPS ITS TARGET | 2.2 | +66.7 | 180.6 | 66.3 | 1.8 | +53.3 | 188.1 | 55.7 |
| KILLS COUNT | 1.8 | +102.4 | 146.3 | 97.4 | 2.3 | +80.2 | 158.6 | 25.7 |
| KILLS COUNT NEXT TURN | 5.2 | +193.5 | 224.9 | 125.3 | 6.9 | +285.3 | 402.7 | 183.4 |
| LONE CHARACTER SAFE SPOT | 0.6 | +69.7 | 0.0 | 22.2 | 0.3 | +0.6 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 3.3 | 21.4 |
| LONE WIZARD KEPT IN | 0.4 | +19.7 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +0.5 | 6.9 | 10.7 | 0.8 | +12.9 | 27.1 | 2.2 |
| LOST CHARGE | 2.7 | -44.9 | 99.1 | 130.4 | 3.2 | -61.0 | 89.3 | 117.0 |
| LURE BY WHAT IT DRAWS | 0.4 | -39.2 | 0.0 | 6.1 | 0.3 | -20.1 | 0.0 | 4.1 |
| MAKE SURE TOGETHER | 0.3 | +12.5 | 0.0 | 21.9 | 0.8 | +47.4 | 7.0 | 18.8 |
| MANOEUVRE | 0.3 | +5.7 | 0.0 | 13.0 | 0.2 | +3.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +8.7 | 0.0 | 0.0 | 0.2 | +14.8 | 0.0 | 0.0 |
| MARCH ODDS | 0.5 | +45.7 | 14.6 | 0.0 | 0.1 | +8.4 | 0.0 | 16.5 |
| MARCH OVER CASTS | 1.2 | +126.3 | 0.0 | 66.4 | 0.1 | +14.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.9 | +93.9 | 0.0 | 257.3 | 4.8 | +194.0 | 0.0 | 151.4 |
| MISSILES IN THE MOVE | 3.3 | +62.5 | 0.0 | 96.9 | 3.0 | +94.0 | 0.0 | 73.0 |
| MISSILES NEXT TURN | 4.7 | +50.1 | 0.0 | 189.4 | 3.2 | +47.4 | 0.0 | 73.0 |
| MOVE AND CAST | 0.1 | +3.2 | 0.0 | 0.0 | 0.4 | +24.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.4 | -14.4 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 22.2 | - | - | - | - |
| MOVE TO CHARGE | 3.3 | +249.3 | 110.1 | 77.8 | 3.5 | +277.9 | 182.4 | 113.7 |
| MOVES UNITS SPELL | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +17.6 | 6.9 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.6 | -24.2 | 55.6 | 0.0 | 0.3 | -29.9 | 51.4 | 0.0 |
| NOT TURNED | 7.3 | +203.3 | 0.0 | 169.7 | 6.3 | +48.7 | 0.0 | 164.9 |
| NOT WORTH A CAST | 0.6 | -0.2 | 0.0 | 0.0 | 1.3 | -0.8 | 0.0 | 15.2 |
| OFF BEST | 15.2 | -673.4 | 23.4 | 317.4 | 14.8 | -858.1 | 0.0 | 304.8 |
| ONE FIGHT FORMULA | 9.4 | -198.2 | 11.2 | 303.7 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.6 | -131.2 | 0.0 | 56.0 | - | - | - | - |
| OPENS A LANE | 0.1 | +1.4 | 26.0 | 8.3 | 0.1 | +0.1 | 5.4 | 0.0 |
| OPENS UP | 0.3 | +19.6 | 18.8 | 0.0 | 0.1 | +2.4 | 6.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +10.9 | 86.4 | 23.3 | 0.6 | +16.7 | 78.1 | 21.7 |
| PATHS CROSS | 2.8 | +173.0 | 0.0 | 60.6 | 3.0 | +118.4 | 0.0 | 79.8 |
| PERIAPT WORTH | 0.1 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -2.5 | 0.0 | 0.0 | 0.2 | -3.5 | 0.0 | 0.0 |
| PLAN RESULT | 37.1 | +1060.5 | 1011.8 | 1190.2 | 41.1 | +1613.3 | 1720.9 | 869.1 |
| PURSUES BIG PREY | 0.2 | -5.4 | 0.0 | 0.0 | 0.2 | -12.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.0 | 0.0 | 6.8 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +20.6 | 0.0 | 43.1 | 1.7 | +34.6 | 0.0 | 37.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.9 | 0.0 | 0.0 | 0.4 | -20.9 | 26.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.9 | -14.6 | 0.0 | 18.7 | 0.4 | -5.7 | 0.0 | 3.3 |
| REDIRECT COUNTER | 3.5 | +183.7 | 0.0 | 64.6 | 3.9 | +353.3 | 0.0 | 49.1 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +6.5 | 9.8 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 8.8 |
| RESERVE FALL BACK | 0.2 | +12.0 | 0.0 | 4.4 | 0.6 | +36.1 | 0.0 | 15.1 |
| RESTRAINS TO SHOOT | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +90.3 | 278.8 | 149.2 | 3.8 | +96.6 | 339.7 | 76.0 |
| RISK ONCE | 3.6 | +96.6 | 72.8 | 144.8 | - | - | - | - |
| SAFER THAN THE JOB | 1.3 | +52.9 | 0.0 | 13.4 | 0.6 | +37.8 | 0.0 | 17.3 |
| SCOUT SPOT | 0.2 | +0.2 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.5 | -16.0 | 0.0 | 5.0 | 0.1 | -4.0 | 0.0 | 0.0 |
| SEARCH SPOT | 2.8 | +116.4 | 0.0 | 46.2 | 3.6 | +121.7 | 0.0 | 69.2 |
| SECOND HUNTER | - | - | - | - | 0.1 | -1.3 | 9.2 | 1.9 |
| SELF MOVE SPELL | 0.2 | +42.6 | 0.0 | 43.9 | - | - | - | - |
| SET UP TOGETHER | 0.3 | +13.6 | 0.0 | 21.9 | 1.2 | +69.2 | 10.9 | 18.8 |
| SET-UP ANY TARGET | 0.1 | +8.0 | 22.2 | 22.2 | 0.2 | +46.4 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +11.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.2 | +0.6 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +33.4 | 30.1 | 13.2 | 1.1 | +53.0 | 90.4 | 13.9 |
| SHOT REPLANNED | 0.4 | +0.0 | 117.8 | 29.1 | 0.2 | +0.0 | 92.5 | 0.0 |
| SHOTS IN THE MOVE | 9.3 | +288.5 | 0.0 | 156.8 | 8.9 | +334.1 | 0.0 | 211.2 |
| SPELL SETS UP CHARGE | 0.1 | +8.0 | 22.2 | 22.2 | 0.4 | +84.8 | 6.9 | 15.2 |
| SPELL WORTH | 1.4 | +41.8 | 188.1 | 172.8 | 1.6 | +26.0 | 75.4 | 75.4 |
| SPELLS IN THE FIGHT | 0.8 | +4.3 | 113.0 | 35.7 | 1.1 | -22.1 | 106.9 | 44.4 |
| STABLE ROLE | 8.1 | +0.0 | 264.5 | 218.2 | 12.1 | +0.0 | 560.8 | 180.2 |
| STAY WEIGHED | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| STOPS | 0.1 | +1.0 | 10.8 | 0.0 | 0.4 | +20.4 | 68.1 | 8.3 |
| STOPS SHORT OF THE FLANK | 0.7 | +17.0 | 0.0 | 22.2 | 0.5 | +35.3 | 0.0 | 71.7 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 11.7 | 0.3 | +0.0 | 0.0 | 9.4 |
| SUPPORT NARROWED | 8.6 | -89.1 | 632.2 | 178.7 | 9.7 | -76.4 | 533.0 | 93.9 |
| SUPPORTS | 6.3 | +89.1 | 423.7 | 85.6 | 6.8 | +91.1 | 216.3 | 26.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -5.2 | 11.7 | 0.0 |
| SURE REACH TOGETHER | 0.1 | -2.8 | 0.0 | 0.0 | 0.8 | +8.0 | 10.9 | 3.7 |
| THROUGH LINE OF FIRE | 0.2 | +9.5 | 0.0 | 0.0 | 0.1 | +7.9 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -43.5 | 61.1 | 15.4 | 0.2 | -6.0 | 5.4 | 5.8 |
| TWO OR MORE ARRIVE | 0.2 | +0.7 | 0.0 | 21.9 | - | - | - | - |
| WAIT AFTER COSTS | 6.9 | -371.8 | 203.7 | 152.0 | 8.4 | -385.5 | 435.2 | 252.9 |
| WALKS TO THE FIGHT | 1.6 | +15.3 | 35.1 | 0.0 | 2.2 | +40.8 | 113.6 | 37.3 |
| WAR ENGINE CHARGES | - | - | - | - | 0.1 | +3.7 | 0.0 | 10.3 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 67.6 | 16.4 | 0.4 | +0.0 | 0.0 | 10.3 |
| WEARS DOWN | 1.1 | +74.6 | 119.4 | 61.8 | 1.6 | +98.8 | 244.9 | 74.4 |
| WHO HITS BACK | 0.2 | +21.4 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +24.8 | 26.2 | 0.0 | 0.5 | -9.4 | 55.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +23.0 | 58.3 | 8.3 | 0.6 | +43.6 | 54.2 | 5.2 |
| WIDER SPREAD | 2.7 | -4.7 | 287.8 | 153.9 | 3.7 | -7.7 | 301.6 | 101.8 |

### Rule changes: os-h2h-mine-779e261-p2b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 541 | 541 | 541 | 30.06 | -27566 | -51.0 |
| BEST FIRST | 123 | 123 | 123 | 6.83 | +5643 | +45.9 |
| SEARCH SPOT | 115 | 115 | 111 | 6.17 | +4364 | +39.3 |
| PATHS CROSS | 104 | 104 | 104 | 5.78 | +5245 | +50.4 |
| SUPPORTS | 235 | 235 | 90 | 5.00 | +1082 | +12.0 |
| FACES THE THREAT | 77 | 77 | 77 | 4.28 | +5340 | +69.4 |
| KILLS COUNT NEXT TURN | 217 | 217 | 76 | 4.22 | +2349 | +30.9 |
| MOVE TO CHARGE | 122 | 122 | 75 | 4.17 | +2798 | +37.3 |
| COUNTER-CHARGE COVER | 172 | 112 | 54 | 3.00 | +3182 | +58.9 |
| FOLLOW UP WEIGHED | 49 | 49 | 49 | 2.72 | +6499 | +132.6 |
| SHOTS IN THE MOVE | 328 | 206 | 39 | 2.17 | +1536 | +39.4 |
| FALLBACK BY WORTH | 169 | 169 | 35 | 1.94 | +1450 | +41.4 |
| WALKS TO THE FIGHT | 68 | 68 | 34 | 1.89 | +442 | +13.0 |
| SAFER THAN THE JOB | 33 | 33 | 33 | 1.83 | +1632 | +49.5 |
| WAIT AFTER COSTS | 275 | 275 | 33 | 1.83 | +614 | +18.6 |
| REDIRECT COUNTER | 134 | 71 | 29 | 1.61 | +2559 | +88.2 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 27 | 1.50 | +993 | +36.8 |
| CHAFF IN THE MOVE | 35 | 34 | 26 | 1.44 | +888 | +34.1 |
| RISK BY ARC | 116 | 114 | 26 | 1.44 | +1012 | +38.9 |
| ADVANCE LANE KEPT | 25 | 25 | 25 | 1.39 | +0 | +0.0 |
| COVER ONCE | 179 | 103 | 25 | 1.39 | +399 | +15.9 |
| HOLDS AMBUSHERS | 25 | 25 | 25 | 1.39 | +0 | +0.0 |
| MAX FOR POSITIONING | 211 | 131 | 25 | 1.39 | +271 | +10.8 |
| BLOCKED WHEEL | 21 | 21 | 21 | 1.17 | +352 | +16.7 |
| HONEST WORTH | 342 | 341 | 21 | 1.17 | +144 | +6.9 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 1.17 | +941 | +44.8 |
| ADVANCE WORTH | 106 | 106 | 20 | 1.11 | +320 | +16.0 |
| BEST FACING | 20 | 20 | 20 | 1.11 | +1014 | +50.7 |
| BEST OVERALL | 20 | 20 | 20 | 1.11 | +1563 | +78.1 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.94 | -45 | -2.7 |
| COMBAT PIVOT | 17 | 17 | 17 | 0.94 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 43 | 43 | 17 | 0.94 | +603 | +35.5 |
| CASTING BLOCK | 18 | 18 | 16 | 0.89 | +649 | +40.6 |
| INVITES THE FIGHT | 60 | 60 | 16 | 0.89 | +269 | +16.8 |
| KILLS COUNT | 75 | 74 | 16 | 0.89 | +769 | +48.1 |
| CHARGE NOW WEIGHED | 15 | 15 | 15 | 0.83 | +836 | +55.7 |
| MISSILES IN THE MOVE | 114 | 63 | 15 | 0.83 | +398 | +26.5 |
| RESERVE FALL BACK | 15 | 15 | 15 | 0.83 | +866 | +57.7 |
| RISK ONCE | 64 | 45 | 15 | 0.83 | +486 | +32.4 |
| CANNON SIGHT KEPT | 14 | 14 | 14 | 0.78 | +0 | +0.0 |
| KEEPS ITS TARGET | 72 | 72 | 14 | 0.78 | +230 | +16.4 |
| SET UP TOGETHER | 28 | 27 | 14 | 0.78 | +427 | +30.5 |
| IDLE COST | 295 | 171 | 13 | 0.72 | +150 | +11.5 |
| SCOUT WAITS | 13 | 13 | 13 | 0.72 | +0 | +0.0 |
| CHARGE NOW FIRST | 78 | 78 | 12 | 0.67 | -486 | -40.5 |
| WEARS DOWN | 48 | 47 | 12 | 0.67 | +673 | +56.1 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.61 | +0 | +0.0 |
| MARCH ODDS | 11 | 11 | 11 | 0.61 | +164 | +14.9 |
| SHOT REPLANNED | 11 | 11 | 11 | 0.61 | +0 | +0.0 |
| BEST PREY | 23 | 23 | 10 | 0.56 | +469 | +46.9 |
| SHOOTERS IN TWO RANKS | 10 | 10 | 10 | 0.56 | +20 | +2.0 |
| CAST JOB | 12 | 12 | 9 | 0.50 | +157 | +17.5 |
| MARCH CHECK | 9 | 9 | 9 | 0.50 | +328 | +36.4 |
| ONE FIGHT FORMULA | 170 | 95 | 9 | 0.50 | +14 | +1.5 |
| REFUSING RETIRES | 20 | 20 | 9 | 0.50 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 0.44 | +444 | +55.5 |
| MAKE SURE TOGETHER | 19 | 14 | 8 | 0.44 | +267 | +33.3 |
| MOVE AND CAST | 8 | 8 | 8 | 0.44 | +498 | +62.2 |
| REDIRECT WEIGHED | 8 | 8 | 8 | 0.44 | -24 | -3.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.44 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 0.39 | +0 | +0.0 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.39 | -324 | -46.2 |
| WAR ENGINE JOBS | 20 | 20 | 7 | 0.39 | -221 | -31.6 |
| MANOEUVRE | 10 | 10 | 6 | 0.33 | +168 | +28.1 |
| SUPPORT NARROWED | 330 | 330 | 6 | 0.33 | -24 | -3.9 |
| WHOLE FIGHT GAIN | 16 | 13 | 6 | 0.33 | +383 | +63.8 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.28 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.28 | +164 | +32.8 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.28 | -108 | -21.5 |
| SURE REACH TOGETHER | 15 | 11 | 5 | 0.28 | +46 | +9.1 |
| THROUGH LINE OF FIRE | 5 | 5 | 5 | 0.28 | +315 | +63.0 |
| WHO HITS BACK | 5 | 5 | 5 | 0.28 | +287 | +57.4 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 0.22 | +0 | +0.0 |
| WHOLE FIGHT | 11 | 11 | 4 | 0.22 | +340 | +85.0 |
| WIDER SPREAD | 115 | 112 | 4 | 0.22 | +27 | +6.8 |
| CANNON PLANNED TARGET | 33 | 33 | 3 | 0.17 | -2 | -0.5 |
| CHAFF PASSED | 3 | 3 | 3 | 0.17 | -8 | -2.7 |
| HUNT IN PAIRS | 17 | 14 | 3 | 0.17 | +1 | +0.3 |
| LONG SHOT | 22 | 22 | 3 | 0.17 | +49 | +16.2 |
| LOST CHARGE | 105 | 104 | 3 | 0.17 | +59 | +19.6 |
| OPENS UP | 6 | 6 | 3 | 0.17 | +64 | +21.2 |
| OVERRUNS AWAY | 20 | 20 | 3 | 0.17 | +36 | +11.9 |
| STAY WEIGHED | 3 | 3 | 3 | 0.17 | +7 | +2.2 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.17 | -113 | -37.7 |
| BLOWS WHERE AIMED | 8 | 7 | 2 | 0.11 | +201 | +100.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.11 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 141 | 79 | 2 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.11 | +12 | +5.8 |
| ONE OBJECTIVE FORMULA | 46 | 24 | 2 | 0.11 | +10 | +4.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.11 | +162 | +81.2 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.11 | +133 | +66.7 |
| SPELLS IN THE FIGHT | 33 | 33 | 2 | 0.11 | +5 | +2.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.06 | -24 | -24.3 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.06 | -162 | -161.6 |
| EDGE GIVE GROUND | 10 | 10 | 1 | 0.06 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.06 | +2 | +1.9 |
| HORN WORTH | 1 | 1 | 1 | 0.06 | +3 | +3.0 |
| JOINT CHARGE PLAN | 1 | 1 | 1 | 0.06 | +62 | +61.6 |
| NEEDED THERE | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 24 | 24 | 1 | 0.06 | +30 | +29.9 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.06 | +25 | +25.3 |
| STOPS | 8 | 8 | 1 | 0.06 | +42 | +41.5 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.06 | +59 | +58.8 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 32 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 30 | 27 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 237 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 11 | 11 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 10 | 10 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 9 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 23 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 246 | 246 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 1407 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 54 | not checked | - | - | - | - |
| STABLE ROLE | 362 | 362 | 0 | 0.00 | - | - |
| TURN WORTH | 15 | 15 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: os-h2h-mine-779e261-p2b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.33 | 13.00 | 53.3 |
| TURN GATE | gate | 0.56 | 0.72 | 37.0 |
| FALLBACK | gate | 0.50 | 0.50 | 50.1 |
| CHARGE NOW FIRST | rule | 0.28 | 0.39 | 40.5 |
| AFTERMATH BAND | gate | 0.33 | 0.28 | 2.7 |
| BIG CHARACTER SAFETY | rule | 0.28 | 0.17 | 12.0 |
| PATHS CROSS | rule | 0.11 | 0.28 | 35.8 |
| PURSUES BIG PREY | rule | 0.17 | 0.22 | 46.2 |
| WAR ENGINE JOBS | rule | 0.28 | 0.11 | 31.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.11 | 36.0 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.17 | 21.5 |
| BLOCKED WHEEL | rule | 0.11 | 0.11 | 26.4 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.11 | 6.8 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.06 | 35.5 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 0.8 |
| SUPPORT NARROWED | rule | 0.11 | 0.06 | 7.6 |
| SUPPORT REQUEST | gate | 0.11 | 0.06 | 33.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.11 | 37.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 21.9 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 3.8 |
| FACES THE THREAT | rule | 0.11 | - | 14.8 |
| NO REASON | gate | 0.11 | - | 103.6 |
| SAFER THAN THE JOB | rule | 0.06 | 0.06 | 19.8 |
| BEST PRIZE | rule | - | 0.06 | 24.3 |
| CANNON PLANNED TARGET | rule | 0.06 | - | 1.5 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 161.6 |
| FOLLOW UP WEIGHED | rule | 0.06 | - | 2.6 |
| REDIRECT WEIGHED | rule | - | 0.06 | 24.3 |
| REFUSING RETIRES | rule | 0.06 | - | 0.7 |
| WHO HITS BACK | rule | - | 0.06 | 4.4 |

### Plans: os-h2h-mine-779e261-p2b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.7 | 13% | 241 | 212 | 88% |
| Mine | charge | 3.2 | 71% | 302 | 325 | 108% |
| Mine | close in | 5.3 | 26% | 248 | 124 | 50% |
| Mine | hold | 4.8 | 30% | 254 | 0 | 0% |
| Mine | join | 0.7 | 100% | 26 | 0 | 0% |
| Mine | shoot | 5.3 | 63% | 139 | 400 | 288% |
| Mine | support | 8.0 | 91% | 66 | 0 | 0% |
| Opponent | advance | 15.2 | 19% | 533 | 591 | 111% |
| Opponent | charge | 4.8 | 53% | 423 | 478 | 113% |
| Opponent | close in | 5.6 | 26% | 306 | 145 | 47% |
| Opponent | hold | 2.8 | 26% | 139 | 0 | 0% |
| Opponent | join | 1.2 | 95% | 64 | 0 | 0% |
| Opponent | shoot | 4.2 | 50% | 144 | 399 | 278% |
| Opponent | support | 7.3 | 95% | 97 | 0 | 0% |

### Packages: hunt the guns, os-h2h-mine-779e261-p2b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Opponent | 0.3 | 6 | 0 | 83% | 83% | 0% | 2.6 | 414 | 332 | 83% | 23 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.7 | 2 | 0 | 100% | 100% | 0% | 3.0 | 633 | 477 | 100% | 73 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.0 | 2 | 0 | 50% | 50% | 0% | 2.0 | 265 | 219 | 50% | 98 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.3 | 2 | 0 | 100% | 100% | 0% | 2.5 | 344 | 301 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: os-h2h-mine-779e261-p2b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.5 | 35% | 64% | 18% | 25% | 22% | 0% | 11% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 9.6 | 17% | 47% | 20% | 33% | 25% | 25% | 17% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 17% | 83% | 0% | - | 42% | 0% | 17% | 25% | 17% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: os-h2h-mine-779e261-p2b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.2 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 25 | 71 (25) | 22 | 49 | 49 | 28% | 3.0 | 64 (15) | 199 (4) | 7 (6) | 99 (18) | 6 (7) |
| Mine | Character | 53 | 37 (53) | 37 | 0 | 37 | 9% | 2.8 | 41 (29) | 38 (17) | - | 46 (24) | 34 (22) |
| Mine | Clean-up | 8 | 19 (8) | 8 | 10 | 73 | 38% | 2.8 | 22 (3) | 20 (4) | 0 (1) | 46 (4) | 0 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 31 | 70 (31) | 35 | 35 | 38 | 23% | 3.0 | 74 (18) | 84 (9) | 6 (4) | 70 (17) | 70 (14) |
| Mine | Fragile | 5 | 106 (5) | 106 | 0 | 40 | 0% | 2.4 | - | 0 (3) | 265 (2) | 106 (5) | - |
| Mine | Hammer | 17 | 21 (17) | 19 | 2 | 69 | 12% | 2.5 | 25 (8) | 12 (8) | 80 (1) | 26 (11) | 11 (6) |
| Mine | Holder | 18 | 41 (18) | 7 | 34 | 52 | 28% | 3.4 | 20 (7) | 63 (7) | 27 (4) | 55 (12) | 16 (6) |
| Mine | Shooter | 16 | 146 (16) | 93 | 53 | 59 | 6% | 1.3 | 287 (3) | 120 (12) | 0 (1) | 212 (10) | 23 (6) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 66 | 50% | 3.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 10 | 31 (10) | 31 | 0 | 32 | 0% | 1.3 | 0 (2) | 23 (6) | 66 (2) | 0 (1) | 34 (9) |
| Mine | Wizard | 10 | 0 (10) | 0 | 0 | 76 | 10% | 2.1 | 0 (4) | - | 0 (1) | 0 (2) | 0 (3) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Chaff | 37 | 47 (37) | 22 | 24 | 42 | 35% | 2.5 | 34 (18) | 91 (6) | 36 (13) | 73 (24) | 0 (13) |
| Opponent | Character | 47 | 67 (47) | 67 | 0 | 28 | 26% | 2.4 | 97 (26) | 13 (16) | 0 (1) | 86 (30) | 53 (13) |
| Opponent | Clean-up | 4 | 8 (4) | 0 | 8 | 0 | 50% | 3.0 | 10 (3) | 0 (1) | - | 17 (2) | 0 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Fast Hammer | 31 | 44 (31) | 33 | 11 | 34 | 23% | 2.3 | 39 (16) | 34 (10) | 87 (5) | 41 (18) | 48 (13) |
| Opponent | Hammer | 44 | 32 (44) | 27 | 5 | 44 | 32% | 3.0 | 28 (13) | 28 (26) | 72 (5) | 37 (24) | 26 (20) |
| Opponent | Holder | 15 | 97 (15) | 42 | 55 | 25 | 40% | 4.3 | 102 (3) | 88 (10) | 151 (2) | 160 (7) | 39 (8) |
| Opponent | Shooter | 17 | 37 (17) | 26 | 12 | 43 | 6% | 1.6 | 123 (5) | 3 (8) | 12 (4) | 73 (9) | 5 (8) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | Wizard | 12 | 0 (12) | 0 | 0 | 49 | 8% | 2.2 | 0 (5) | 0 (2) | 0 (4) | 0 (4) | 0 (7) |

### Charged fights: os-h2h-mine-779e261-p2b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 200 | 598 | 1.3 | 1.5 | 448 | 0 | +448 | 3 of 4 | 4 of 4 | +684 | +213 |
| Mine | High Elf Realms | 4 | 162 | 345 | 2.8 | 1.1 | 125 | 13 | +112 | 6 of 11 | 10 of 11 | +0 | +124 |
| Mine | Kingdom of Bretonnia | 1 | 30 | 410 | 3.0 | 1.0 | 137 | 249 | -113 | 1 of 3 | 2 of 3 | - | -113 |
| Mine | Lizardmen | 1 | 0 | 186 | 2.0 | 1.0 | 93 | 250 | -156 | 1 of 2 | 1 of 2 | - | -156 |
| Mine | Ogre Kingdoms | 1 | 45 | 0 | 3.0 | 1.7 | 0 | 112 | -112 | 0 of 3 | 1 of 2 | -17 | -301 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 481 | 5.0 | 1.2 | 96 | 11 | +85 | 1 of 5 | 4 of 5 | +45 | +95 |
| Mine | Skaven | 2 | 288 | 100 | 2.5 | 1.0 | 40 | 93 | -53 | 1 of 5 | 4 of 5 | - | -53 |
| Mine | Tomb Kings of Khemri | 1 | 125 | 542 | 2.0 | 2.0 | 271 | 0 | +271 | 1 of 2 | 2 of 2 | +271 | - |
| Mine | Vampire Counts | 3 | 0 | 290 | 3.0 | 1.4 | 97 | 48 | +48 | 2 of 9 | 7 of 9 | +117 | +14 |
| Mine | Warriors of Chaos | 1 | 0 | 236 | 3.0 | 1.0 | 79 | 0 | +79 | 1 of 3 | 2 of 3 | - | +79 |
| **Mine** | all armies | 18 | 112 | 339 | 2.6 | 1.3 | 130 | 57 | +73 | 17 of 47 | 37 of 46 | +206 | +32 |
| Opponent | Ogre Kingdoms | 2 | 312 | 171 | 3.5 | 1.0 | 49 | 11 | +38 | 3 of 7 | 1 of 7 | - | +38 |
| Opponent | Tomb Kings of Khemri | 1 | 551 | 837 | 4.0 | 1.0 | 209 | 0 | +209 | 1 of 4 | 3 of 4 | - | +209 |
| Opponent | Vampire Counts | 3 | 0 | 671 | 3.3 | 1.3 | 201 | 4 | +197 | 4 of 10 | 6 of 10 | +413 | +104 |
| Opponent | Warriors of Chaos | 6 | 0 | 710 | 3.7 | 1.1 | 194 | 27 | +166 | 11 of 22 | 16 of 22 | +435 | +124 |
| Opponent | Wood Elf Realms | 6 | 70 | 358 | 3.3 | 1.0 | 107 | 36 | +71 | 6 of 20 | 14 of 20 | - | +71 |
| **Opponent** | all armies | 18 | 88 | 533 | 3.5 | 1.1 | 152 | 23 | +129 | 25 of 63 | 40 of 63 | +424 | +98 |

### Effective charges: os-h2h-mine-779e261-p2b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 4 | 0 | 0 | 0 | 2 (net +618) | 1 (net +432) | 1 (net +125) | 0 | 0% (0 of 4) |
| Mine | High Elf Realms | 11 | 1 (net +0) | 1 (net +0) | 4 (net +201) | 1 (net +0) | 3 (net +144) | 0 | 1 | 40% (4 of 10) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 2 (net -133) | 0 | 0 | 1 (net -72) | 0 | 67% (2 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net -499) | 1 (net +186) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 2 (net -17) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 3 | 50% (1 of 2) |
| Mine | Skaven | 5 | 1 (net -402) | 0 | 0 | 0 | 0 | 4 (net +34) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 1 (net +110) | 1 (net +432) | 0 | 0% (0 of 2) |
| Mine | Vampire Counts | 9 | 2 (net -165) | 0 | 0 | 1 (net +0) | 2 (net +102) | 4 (net +140) | 0 | 0% (0 of 9) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +236) | 1 (net +0) | 1 (net +0) | 0 | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 7 | 3 (net +44) | 0 | 2 (net -20) | 0 | 0 | 1 (net +177) | 1 | 33% (2 of 6) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net +347) | 0 | 0 | 0 | 0 | 1 (net +151) | 2 | 0% (0 of 2) |
| Opponent | Vampire Counts | 10 | 1 (net -45) | 1 (net +0) | 4 (net +380) | 2 (net +118) | 1 (net +0) | 1 (net +255) | 0 | 40% (4 of 10) |
| Opponent | Warriors of Chaos | 22 | 3 (net +162) | 0 | 4 (net +267) | 6 (net +134) | 0 | 7 (net +202) | 2 | 20% (4 of 20) |
| Opponent | Wood Elf Realms | 20 | 2 (net -192) | 2 (net +134) | 5 (net +152) | 3 (net +89) | 0 | 7 (net +64) | 1 | 26% (5 of 19) |

### Charged fights, damage counted: os-h2h-mine-779e261-p2b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 154 | 332 | -183 | 28 | 183 | -154 | -100.5 |
| Mine | 50-54% | 1 | 199 | 201 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 9 | 289 | 269 | +36 | 185 | 124 | +62 | +21.4 |
| Mine | 76-89% | 8 | 343 | 158 | +174 | 234 | 33 | +202 | +58.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 226 | 138 | +114 | 159 | 40 | +119 | +52.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 586 | 148 | +147 | 177 | 32 | +145 | +24.7 |
| Mine | No odds | 5 | 269 | 122 | -22 | 49 | 71 | -22 | -8.2 |
| Mine | All fights | 47 | 317 | 184 | +73 | 154 | 68 | +86 | +27.0 |
| Opponent | Long shot (under 50%) | 10 | 118 | 245 | +53 | 140 | 99 | +40 | +34.4 |
| Opponent | 50-54% | 3 | 270 | 216 | +89 | 89 | 6 | +83 | +30.9 |
| Opponent | Effective (55-75%) | 15 | 235 | 220 | +221 | 235 | 24 | +210 | +89.5 |
| Opponent | 76-89% | 11 | 254 | 205 | +119 | 175 | 51 | +124 | +49.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 228 | 173 | +144 | 168 | 27 | +141 | +61.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 521 | 60 | +0 | 30 | 0 | +30 | +5.8 |
| Opponent | No odds | 6 | 200 | 283 | +48 | 76 | 29 | +47 | +23.6 |
| Opponent | All fights | 63 | 221 | 212 | +129 | 166 | 41 | +125 | +56.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| os-h2h-mine-779e261-p2b | move | 237 | 56 (24%) | 40 (17%) | 22 (9%) | 159 (67%) |
| os-h2h-mine-779e261-p2b | objective | 198 | 33 (17%) | 24 (12%) | 22 (11%) | 143 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429, L2535, L2735 |
| Charmed Shield | Opponent | L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Ring of Doom | Mine | L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L1531, L2131, L3033 |
| Ring of Jet | Mine | L1118, L1135, L1228 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

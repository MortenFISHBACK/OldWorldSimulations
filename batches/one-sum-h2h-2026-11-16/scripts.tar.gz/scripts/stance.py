import csv,glob,statistics as st,math,collections
D='/mnt/project-files/one-sum-h2h-2026-11-16'; S='/mnt/project-files/defensive-stance-2026-11-14/scripts'
gun={('Mine',p) for p in open(S+'/def-mine.txt').read().strip().split(',')}|{('Opponent',p) for p in open(S+'/def-opp.txt').read().strip().split(',')}
G={}
for arm in ('mine','opp'):
  for f in glob.glob(f'{D}/{arm}-*/games.csv')+glob.glob(f'{D}/{arm}-*/*/games.csv'):
    if '/parts/' in f: continue
    for r in csv.DictReader(open(f)):
      m,o=map(int,r['vp_mine_opponent'].split('-')); G[(arm,r['pair'])]={'Mine':m-o,'Opponent':o-m}
def b(x): return 1.96*st.stdev(x)/math.sqrt(len(x))
for lbl,sel in (('Gunline armies',lambda k:k in gun),('Other armies',lambda k:k not in gun)):
  d=[];on=[];off=[]
  for side in ('Mine','Opponent'):
    for p in sorted({p for _,p in G}):
      if not sel((side,p)): continue
      fixarm='mine' if side=='Mine' else 'opp'; offarm='opp' if side=='Mine' else 'mine'
      if (fixarm,p) in G and (offarm,p) in G:
        a=G[(fixarm,p)][side]; c=G[(offarm,p)][side]; on.append(a); off.append(c); d.append(a-c)
  print(f"| {lbl} | {len(d)} | {st.mean(on):+.0f} | {st.mean(off):+.0f} | {st.mean(d):+.0f} ±{b(d):.0f} | {sum(x>0 for x in d)} / {sum(x<0 for x in d)} |")

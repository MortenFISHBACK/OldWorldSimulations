import json,glob,os,re,collections
D='/mnt/project-files/one-sum-h2h-2026-11-16'
TAGS=['ADVANCE WORTH','IDLE COST','RISK ONCE','ONE FIGHT FORMULA','COVER ONCE','CHAFF IN THE MOVE','ONE OBJECTIVE FORMULA']
R=re.compile(r"^([A-Z ]+): ([+-]?[\d.]+) VP: .*?\| (SAME|CHANGED)")
JR=re.compile(r"^JOB RISK: ([a-z ]+?) #.*gain ([+-]?[\d.]+) VP, risk ([+-]?[\d.]+) VP")
C=collections.Counter(); leak=collections.Counter(); games=collections.Counter(); seen=set()
risk=collections.defaultdict(float); jobs=collections.Counter()
for f in sorted(glob.glob(D+'/*/*/game-*.log.jsonl')+glob.glob(D+'/*/game-*.log.jsonl')):
  arm=os.path.relpath(f,D).split('/')[0].split('-')[0]; key=(arm,os.path.basename(f))
  if key in seen: continue
  seen.add(key); fx='Mine' if arm=='mine' else 'Opponent'; games[arm]+=1
  for l in open(f):
    if '"summary"' not in l: continue
    if not any(t in l for t in TAGS+['JOB RISK']): continue
    try: d=json.loads(l)
    except ValueError: continue
    s=d.get('summary') or ''; side=d.get('side'); b='on' if side==fx else 'off'
    m=JR.match(s)
    if m: risk[(b,m.group(1))]+=float(m.group(3)); jobs[(b,m.group(1))]+=1; continue
    t=next((t for t in TAGS if s.startswith(t+':')),None)
    if not t: continue
    if b=='off': leak[t]+=1; continue
    m=R.match(s); C[(t,m.group(3) if m else 'other')]+=1
n=sum(games.values())
print('games',dict(games),'total',n,'| leak rows on switched-off side:',dict(leak) or 'none')
print('| Rule | Rows a game | Changed the pick a game | Rows total |\n| --- | --- | --- | --- |')
for t in TAGS:
  tot=sum(v for (k,_),v in C.items() if k==t); ch=C[(t,'CHANGED')]
  print(f"| {t} | {tot/n:.1f} | {ch/n:.2f} | {tot} |")
print('\nJOB RISK rows: side, job, rows, risk claimed a game (VP)')
for b in ('on','off'):
  tr=sum(v for (bb,_),v in risk.items() if bb==b)
  print(b,'total risk claimed a game %.0f'%(tr/n), {k:(jobs[(bb,k)], round(v/n,1)) for (bb,k),v in risk.items() if bb==b})

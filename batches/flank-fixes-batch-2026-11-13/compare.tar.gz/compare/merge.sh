#!/bin/bash
# Merge the four parts of each arm into one batch folder compare-batches.py can read.
D=/mnt/project-files/flank-fixes-batch-2026-11-13; OUT=${OUT:-$HOME/ff-merged}
for arm in on off; do
  sha=$([ $arm = on ] && echo 4391d94 || echo 101d908)
  M=$OUT/ff-$arm-$sha-all; rm -rf $M; mkdir -p $M
  first=1
  for n in 1 2 3 4; do
    P=$D/$arm-$n/ff-$arm-$sha-p$n
    [ -d $P ] || { echo "missing $P"; continue; }
    for f in games.csv plays.csv; do [ -f $P/$f ] || continue
      if [ $first = 1 ]; then cat $P/$f >> $M/$f; else tail -n +2 $P/$f >> $M/$f; fi; done
    first=0
    ln -s $P/game-* $M/
    for f in commit.txt look-for.md rules-off.txt; do [ -f $P/$f ] && cp $P/$f $M/; done
  done
  python3 $D/compare/merge-records.py $M/records.db $D/$arm-*/ff-$arm-$sha-p*/records.db
  echo "$arm: $(($(wc -l < $M/games.csv)-1)) games"
done

# Doctrine scorecard: ff-on-101d908-p1

### Scorecard: ff-on-101d908-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 10 | 3 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 2 | 3 | 1 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 4 | 1 | 4 | 4 | 0 | 0 | 0 | 302 |
| L0135 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0135 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0218 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0218 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0235 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0235 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0319 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0319 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0405 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0405 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 10 | 4 | 0 | 0 | 0 | 112 |
| L0421 | 1 | 1 | Opponent | no | 3 | - | 0 | 6 | 1 | 0 | 0 | 565 |
| L0508 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0508 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0524 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0524 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0612 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0612 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0628 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0628 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0717 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0717 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0733 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0733 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0823 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 6 | 3 | 1 | 2 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0930 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1021 | 1 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 3 | - | 1 | 3 | 0 | 0 | 0 | 467 |
| L1114 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1114 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1131 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1131 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1224 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1224 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1319 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1319 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1335 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 140 |
| L1431 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1431 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1527 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1527 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1823 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1823 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1923 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1923 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2025 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2025 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2231 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2231 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 3.9 | 2.3 | 2.6 | 1.3 | 0.0 | 0.0 | 0.0 | 279.4 |
| **Average** | | | Opponent | 0% | 2.9 | 2.2 | 1.4 | 3.3 | 0.3 | 0.0 | 0.0 | 263.4 |

### KPIs: ff-on-101d908-p1

Morten 2026-11-10; 31 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 83% (5 of 6); on the table 100% | 80% (8 of 10); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (4 of 4); on the table 100% | 50% (1 of 2); on the table 100% | 83% (5 of 6); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 90% (9 of 10); on the table 90% | 78% (7 of 9); on the table 100% | 84% (16 of 19); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 29% (51 of 176) | 31% (27 of 87) | 30% (78 of 263) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (51 of 138) | 46% (26 of 57) | 39% (77 of 195) |
| Points that never fought | lower | 53% (7248 of 13797) | 61% (8444 of 13897) | 57% (15692 of 27694) |
|   infantry points that never fought | lower | 71% (2935 of 4107) | 78% (2873 of 3701) | 74% (5808 of 7808) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (23 of 58) | 70% (39 of 56) | 54% (62 of 114) |
| Bound items with a magic missile used (at least once a game) |  | 76% (16 of 21); 1.2 uses a game | 67% (12 of 18); 1.1 uses a game | 72% (28 of 39); 1.1 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 46% (11 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 44% (8 of 18); 0.3 uses a game | 40% (4 of 10); 0.1 uses a game | 43% (12 of 28); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 34% (4108 of 12134) | 68% (7823 of 11461) | 51% (11931 of 23595) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (40%) | 0.5 (29%) | 2.1 (37%) |
| MARCHED: its unit marched | 1.0 (25%) | 0.4 (20%) | 1.4 (24%) |
| CHARGED: its unit charged | 0.3 (8%) | 0.1 (3%) | 0.4 (6%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | 0.3 (15%) | 1.3 (22%) |
| GONE: slain | 0.0 (0%) | 0.5 (27%) | 0.5 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.9 | 0.7 | 0.8 | 2.5 | 0.2 | 0.7 |
| not cast | 1.9 | 1.8 | 1.7 | 5.7 | 0.9 | 11.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (49%) | 0.2 (13%) | 2.1 (37%) | 0.1 (7%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (24%) | 0.3 (36%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (6%) | 0.1 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (13%) | 0.2 (11%) | 1.3 (22%) | 0.3 (32%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (10%) | 0.2 (11%) | 0.2 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (31%) | 0.1 (7%) | 0.1 (7%) | 0.5 (9%) | 0.0 (0%) | 1.5 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (52%) | 0.3 (18%) | 1.0 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.2 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.3 a game | 0.5 a game |
| stood (cast and not dispelled) | 59% (13 of 22) | 75% (6 of 8) | 63% (19 of 30) |
| the unit moved after it | 54% (7 of 13) | 83% (5 of 6) | 63% (12 of 19) |
| it charged on its next turn | 0% (0 of 13) | 0% (0 of 6) | 0% (0 of 19) |
| the enemy charged it first | 8% (1 of 13) | 0% (0 of 6) | 5% (1 of 19) |
| it fought by the end of its next turn | 8% (1 of 13) | 0% (0 of 6) | 5% (1 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 31% (4 of 13) | 0% (0 of 6) | 21% (4 of 19) |
| none of these (no charge, no fight, no charge escaped) | 54% (7 of 13) | 100% (6 of 6) | 68% (13 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (99 of 168) | 54% (80 of 147) | 57% (179 of 315) |
|   cavalry | 42% (5 of 12) | 46% (12 of 26) | 45% (17 of 38) |
|   character | 60% (9 of 15) | 19% (4 of 21) | 36% (13 of 36) |
|   chariot | 22% (6 of 27) | 78% (14 of 18) | 44% (20 of 45) |
|   infantry | 62% (32 of 52) | 56% (39 of 70) | 58% (71 of 122) |
|   monster | 40% (2 of 5) | 50% (1 of 2) | 43% (3 of 7) |
|   war machine | 79% (45 of 57) | 100% (10 of 10) | 82% (55 of 67) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.8 (36%) | 0.8 (36%) | 1.6 (36%) |
| CHARGED: it charged | 0.3 (12%) | 0.5 (21%) | 0.7 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.1 (4%) | 0.1 (6%) | 0.2 (5%) |
| MOVED: a war machine that moved | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) |
| NO TARGET IN RANGE | 0.2 (10%) | 0.5 (21%) | 0.7 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (3%) | 0.2 (10%) | 0.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.5 (22%) | 0.1 (4%) | 0.6 (13%) |
| SHELTERED: the target was sheltered | 0.2 (9%) | 0.0 (0%) | 0.2 (4%) |
| OTHER BAR | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.8 | 0.0 | 96% | 0.8 pts | 1 pts |
| character | 0.5 | 0.2 | 67% | 6.3 pts | 3 pts |
| chariot | 0.6 | 0.4 | 70% | 15.9 pts | 10 pts |
| infantry | 3.3 | 1.6 | 65% | 9.7 pts | 32 pts |
| monster | 0.2 | 0.1 | 60% | 22.8 pts | 4 pts |
| war machine | 1.8 | 1.3 | 69% | 25.1 pts | 45 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.1 | 2.0 |
| Charges that made contact a game | 1.4 | 1.4 | 1.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.12 declared, 0.81 contact (16 units) | 0.31 declared, 0.31 contact (13 units) | 0.76 declared, 0.59 contact (29 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.50 declared, 0.00 contact (2 units) | 0.40 declared, 0.20 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.16 declared, 0.11 contact (262 units) | 0.22 declared, 0.14 contact (269 units) | 0.19 declared, 0.12 contact (531 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 18% (2 of 11) | 0% (0 of 1) | - | 17% (2 of 12) |
| Character in a unit | 40% (2 of 5) | 57% (4 of 7) | - | 50% (6 of 12) |
| Character on its own | 88% (7 of 8) | 33% (3 of 9) | 56% (5 of 9) | 58% (15 of 26) |
| Chariot | 100% (7 of 7) | 50% (2 of 4) | - | 82% (9 of 11) |
| Infantry | 77% (17 of 22) | 40% (4 of 10) | 0% (0 of 1) | 64% (21 of 33) |
| Monster | 0% (0 of 3) | 67% (2 of 3) | - | 33% (2 of 6) |
| Monstrous | 50% (1 of 2) | 33% (1 of 3) | - | 40% (2 of 5) |
| War Machines | 56% (5 of 9) | - | - | 56% (5 of 9) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (1 of 1); on the table 100% | 51% (40 of 78) | 74% | 31% (5 of 16) | 100% (4 of 4); 6.7 uses a game | 100% (2 of 2); 2.7 uses a game | 75% (3 of 4); 1.0 uses a game |
| Chaos Dwarfs | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 44% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 75% (9 of 12) | 56% | 55% (12 of 22) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Grand Cathay | 1 | 80% (4 of 5); on the table 80% | 4% (1 of 24) | 40% | 30% (3 of 10) | 100% (2 of 2); 6.0 uses a game | 100% (1 of 1); 2.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 2 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 61% | 44% (7 of 16) | 100% (2 of 2); 3.0 uses a game | 50% (2 of 4); 3.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | - | 86% | 86% (6 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 8% (1 of 12) | 44% | 94% (17 of 18) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 50% (2 of 4); on the table 100% | 17% (1 of 6) | 34% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 48% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ff-on-101d908-p1, 31 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (3) | 36% (8) | 30% (11) |
| ...free all their last turn and able to turn (per game) | 0.10 | 0.19 | 0.29 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.03 | 0.03 |
| ...with the charger already in that arc before they moved (per game) | 0.06 | 0.06 | 0.13 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.35 | 0.26 | 0.61 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.26 | 0.48 | 0.74 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 2.16 | 2.94 | 5.10 |

### Quality by phase: ff-on-101d908-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.9 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 35% (18 of 52) | 49% (26 of 53) |
| Strategy | Shoot objectives carried out (shot that target) | 51% (94 of 183) | 71% (45 of 63) |
| Strategy | Close-in objectives charged next turn | 15% (11 of 74) | 9% (8 of 89) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | 50% (4 of 8) |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (2 of 5) | - |
| Strategy | Joined characters whose unit fought | 27% (4 of 15) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 69% (11 of 16) | 60% (9 of 15) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.3 |
| Movement | Points that never moved of their own | 279.4 | 263.4 |
| Movement | Fights charged into per game | 2.4 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 14 | 1 of 12, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 14, net +133 | 3 of 12, net +113 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 14, net +88 | 0 of 12 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 14, net +62 | 7 of 12, net +138 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.1 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (27 of 64) | 69% (54 of 78) |
| Shooting | Points destroyed by shooting units | 29.3 | 0.0 |
| Shooting | War machine shots | 1.5 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (18 of 45) | 50% (5 of 10) |
| Shooting | Points destroyed by war machines | 15.5 | 0.0 |
| Magic | Magic missiles cast | 1.1 | 0.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (5 of 35) | 38% (5 of 13) |
| Magic | Wounds caused by magic missiles | 3.5 | 1.0 |
| Magic | Wounds caused by other spells | 1.1 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 44.2 | 2.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.2 / 0.2 / 0.1 | 0.8 / 0.1 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 74.9 | 62.2 |
| Combat | Points run down | 23.1 | 17.1 |
| Combat | Net points per charged fight, damage counted | +147 | +107 |
| Combat | Net per 100 charger points, damage counted | +39.8 | +50.2 |
| Combat | First round won (charged fights) | 94% | 67% |
| Combat | Net points per charged fight | +149 | +106 |
| Combat | Net points per supported fight / lone fight | +77 / +165 | +178 / +88 |
| Combat | Charged fights on a top-3 enemy unit | 9 of 17 | 2 of 15 |
| Game | Points lost | 470.3 | 999.1 |
| Game | VP from objectives | 961.4 | 698.6 |
| Game | Lone holders (player turns) | 3.9 | 2.9 |

- Mine won / drew / lost: 5 / 1 / 1 of 7 ended games (of 31); mean margin (Mine - Opponent) +819 VP
- The side that went first won 3 of 6 games with a winner
- Points traded per game (both sides' losses): 1469
- Games not ended: 24 (L0135-1, L0218-1, L0235-1, L0319-1, L0405-1, L0508-1, L0524-1, L0612-1, L0628-1, L0717-1, L0733-1, L0930-1, L1114-1, L1131-1, L1224-1, L1319-1, L1431-1, L1527-1, L1625-1, L1723-1, L1823-1, L1923-1, L2025-1, L2231-1); findings 24, warnings 0

### Opponent rules: ff-on-101d908-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.9 | +0.0 | 0.0 | 8.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +5.9 | 0.0 | 0.0 | 0.5 | +5.0 | 0.0 | 0.0 |
| BEST OVERALL | 0.1 | +9.8 | 0.0 | 0.0 | 0.2 | +5.9 | 0.0 | 0.0 |
| BEST PREY | 2.1 | +136.8 | 38.6 | 64.9 | 2.5 | +177.7 | 43.6 | 53.0 |
| BEST PRIZE | 0.0 | +2.7 | 3.6 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +10.6 | 0.0 | 0.0 | 0.1 | +16.7 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 8.1 | 0.0 | 0.0 | +0.0 | 7.3 | 2.3 |
| CANNON PLANNED TARGET | 3.5 | +98.3 | 95.2 | 31.1 | 0.6 | +16.6 | 14.6 | 9.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.3 | +7.5 | 17.6 | 0.0 | 0.2 | +2.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +86.6 | 40.7 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 25.8 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.2 | -17.9 | 0.0 | 5.2 | 0.5 | -26.9 | 0.0 | 13.1 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 8.5 | 0.2 | +0.0 | 0.0 | 15.1 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.4 | +27.3 | 0.0 | 0.0 | 0.1 | +38.4 | 12.9 | 12.9 |
| COUNTER-CHARGE COVER | 4.3 | +316.5 | 0.0 | 15.3 | 4.0 | +365.3 | 0.0 | 50.5 |
| EDGE GIVE GROUND | - | - | - | - | 0.0 | +0.1 | 4.2 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.4 | +45.4 | 0.0 | 0.0 | 0.3 | +10.5 | 0.0 | 8.1 |
| FALLBACK BY WORTH | 2.7 | +31.1 | 0.0 | 29.3 | 4.2 | +62.7 | 0.0 | 42.0 |
| FIGHT LIFT | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 2.2 | +0.0 | 0.0 | 18.6 | 2.9 | +0.0 | 0.0 | 53.5 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +39.4 | 0.0 | 0.0 | 0.3 | +65.3 | 0.0 | 10.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.5 | 0.0 | 0.0 | 0.1 | +17.7 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -20.9 | 55.0 | 0.0 | 0.7 | -21.1 | 33.1 | 9.6 |
| GIVES UP ITS SCREEN | 0.3 | -2.5 | 0.0 | 0.0 | 0.5 | -5.3 | 26.2 | 3.7 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 8.5 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +8.0 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +17.4 | 0.0 | 0.0 | 0.3 | +7.4 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +6.8 | 0.0 | 0.0 | 0.1 | +45.4 | 0.0 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 6.0 |
| KEEPS ITS TARGET | 0.9 | +27.1 | 16.5 | 5.2 | 0.9 | +26.1 | 17.7 | 22.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.6 | +21.9 | 25.7 | 0.0 | 0.8 | +47.6 | 13.5 | 3.7 |
| KILLS COUNT NEXT TURN | 4.0 | +164.5 | 130.6 | 56.0 | 5.8 | +290.8 | 77.3 | 105.7 |
| LONE CHARACTER SAFE SPOT | 0.1 | +3.7 | 0.0 | 0.0 | 0.3 | +14.5 | 0.0 | 17.4 |
| LONE WIZARD HOLDS BACK | 0.4 | +0.0 | 17.4 | 0.0 | 0.6 | +0.0 | 0.0 | 30.3 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | 0.3 | +28.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +6.4 | 0.0 | 0.0 | 0.4 | +25.0 | 0.0 | 1.7 |
| MANOEUVRE | 0.1 | +3.5 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +19.8 | 0.0 | 0.0 | 0.4 | +12.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.6 | +56.4 | 6.8 | 5.2 | 0.3 | +24.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +57.4 | 0.0 | 5.2 | 0.1 | +4.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.4 | +112.5 | 0.0 | 0.0 | 3.1 | +103.3 | 0.0 | 29.5 |
| MISSILES IN THE MOVE | 2.3 | +115.3 | 0.0 | 15.7 | 1.7 | +24.8 | 0.0 | 24.6 |
| MISSILES NEXT TURN | 3.2 | +83.9 | 0.0 | 20.9 | 2.2 | +17.7 | 0.0 | 50.4 |
| MODEL FACING | 0.1 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +9.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -72.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 25.8 |
| MOVES UNITS SPELL | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +0.0 | 4.4 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.5 | 0.0 | 2.3 | - | - | - | - |
| NOT NEEDED | 0.2 | -5.2 | 6.5 | 0.0 | 0.1 | -5.4 | 0.0 | 3.7 |
| NOT TURNED | 2.2 | +31.8 | 0.0 | 12.0 | 2.9 | +38.7 | 0.0 | 27.6 |
| NOT WORTH A CAST | 0.6 | -0.7 | 0.0 | 2.7 | 0.0 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 9.0 | -438.9 | 7.2 | 67.8 | 9.1 | -529.3 | 0.0 | 43.9 |
| OPENS A LANE | 0.2 | +0.9 | 0.0 | 2.1 | 0.0 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +22.2 | 4.2 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +25.5 | 20.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| PATHS CROSS | 1.1 | +57.7 | 0.0 | 23.2 | 1.6 | +99.7 | 0.0 | 15.0 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +4.1 | 0.0 | 17.4 |
| PIVOT GUARDS FLANK | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| PLAN LEADS | 0.9 | +72.5 | 41.2 | 0.0 | 1.0 | +95.5 | 0.0 | 0.0 |
| PLAN RESULT | 16.5 | +694.9 | 298.5 | 121.4 | 16.1 | +349.5 | 187.2 | 280.2 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +41.8 | 0.0 | 1.8 | 2.9 | +220.3 | 0.0 | 8.3 |
| REDIRECT WEIGHED | 0.1 | +3.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +0.8 | 0.0 | 0.0 | 0.1 | +3.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.2 | +27.9 | 44.3 | 0.0 | 1.0 | +6.8 | 12.5 | 13.3 |
| SAFER THAN THE JOB | 0.3 | +20.7 | 0.0 | 0.0 | 0.5 | +15.8 | 0.0 | 7.2 |
| SCOUT SPOT | 0.4 | +0.2 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 2.2 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 2.2 |
| SEARCH SPOT | 0.8 | +33.7 | 0.0 | 8.1 | 1.4 | +70.1 | 0.0 | 18.4 |
| SELF MOVE SPELL | 0.2 | +4.4 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +24.5 | 0.0 | 0.0 | 0.6 | +36.5 | 0.0 | 11.3 |
| SET-UP ANY TARGET | 0.2 | +22.2 | 0.0 | 0.0 | 0.1 | +12.1 | 12.9 | 12.9 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 6.3 | 0.0 | 0.0 | +0.0 | 7.3 | 2.3 |
| SHOTS IN THE MOVE | 7.9 | +327.4 | 0.0 | 71.6 | 4.1 | +83.5 | 0.0 | 27.3 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 0.0 | 0.0 | 0.0 | -4.4 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +31.5 | 0.0 | 0.0 | 0.1 | +48.4 | 12.9 | 12.9 |
| SPELL WORTH | 0.5 | +12.2 | 5.5 | 2.7 | 0.8 | +17.7 | 95.7 | 95.7 |
| STOPS SHORT OF THE FLANK | 0.3 | +13.1 | 0.0 | 11.2 | 0.2 | +2.9 | 0.0 | 2.1 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -7.5 | 12.3 | 11.2 | 0.1 | -4.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.2 | -5.3 | 0.0 | 0.0 | 0.4 | +2.4 | 0.0 | 27.2 |
| THROUGH LINE OF FIRE | 0.4 | +11.1 | 0.0 | 30.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -11.5 | 16.0 | 0.0 | 0.1 | -8.8 | 6.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +2.7 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| WEARS DOWN | 0.5 | +22.8 | 31.1 | 0.0 | 0.5 | +10.7 | 31.5 | 9.6 |
| WHO HITS BACK | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +5.9 | 16.7 | 0.0 | 0.0 | +4.1 | 8.5 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +20.7 | 3.0 | 0.0 | 0.2 | +24.6 | 12.5 | 2.7 |

### Rule changes: ff-on-101d908-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 559 | 559 | 559 | 18.03 | -30017 | -53.7 |
| KILLS COUNT NEXT TURN | 303 | 303 | 104 | 3.35 | +4513 | +43.4 |
| PATHS CROSS | 85 | 85 | 85 | 2.74 | +4879 | +57.4 |
| BEST PREY | 142 | 141 | 69 | 2.23 | +3031 | +43.9 |
| SEARCH SPOT | 67 | 67 | 63 | 2.03 | +3259 | +51.7 |
| FALLBACK BY WORTH | 215 | 215 | 59 | 1.90 | +2906 | +49.3 |
| COUNTER-CHARGE COVER | 257 | 121 | 54 | 1.74 | +4391 | +81.3 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.52 | +0 | +0.0 |
| ADVANCE LANE KEPT | 40 | 40 | 40 | 1.29 | +0 | +0.0 |
| CANNON PLANNED TARGET | 127 | 127 | 34 | 1.10 | -50 | -1.5 |
| HOLDS AMBUSHERS | 34 | 34 | 34 | 1.10 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 1.03 | +2518 | +78.7 |
| ARTILLERY RE-ROLL WEIGHED | 31 | 31 | 31 | 1.00 | +0 | +0.0 |
| MARCH ODDS | 28 | 28 | 26 | 0.84 | +721 | +27.7 |
| PLAN LEADS | 59 | 59 | 25 | 0.81 | +1566 | +62.6 |
| MARCH CHECK | 25 | 24 | 24 | 0.77 | +1039 | +43.3 |
| SCOUT WAITS | 24 | 24 | 24 | 0.77 | +0 | +0.0 |
| MAX FOR POSITIONING | 168 | 81 | 23 | 0.74 | +150 | +6.5 |
| SAFER THAN THE JOB | 23 | 23 | 23 | 0.74 | +1131 | +49.2 |
| CHARGE NOW WEIGHED | 21 | 21 | 21 | 0.68 | +768 | +36.6 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.68 | +47 | +2.2 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.61 | +0 | +0.0 |
| FACES THE THREAT | 19 | 19 | 19 | 0.61 | +1733 | +91.2 |
| FOLLOW UP WEIGHED | 18 | 18 | 18 | 0.58 | +3246 | +180.4 |
| CASTING BLOCK | 19 | 19 | 17 | 0.55 | +1410 | +82.9 |
| REDIRECT COUNTER | 128 | 54 | 17 | 0.55 | +894 | +52.6 |
| SHOTS IN THE MOVE | 373 | 227 | 17 | 0.55 | +647 | +38.0 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.55 | +343 | +20.2 |
| SET UP TOGETHER | 32 | 29 | 16 | 0.52 | +730 | +45.6 |
| KILLS COUNT | 44 | 44 | 13 | 0.42 | +652 | +50.2 |
| RISK BY ARC | 68 | 65 | 13 | 0.42 | +456 | +35.1 |
| STOPS SHORT OF THE FLANK | 13 | 13 | 13 | 0.42 | +495 | +38.1 |
| MISSILES IN THE MOVE | 124 | 72 | 12 | 0.39 | +360 | +30.0 |
| CAST JOB | 14 | 14 | 11 | 0.35 | +144 | +13.1 |
| CHARIOT NO STATIC JOB | 16 | 16 | 11 | 0.35 | -1475 | -134.1 |
| KEEPS ITS TARGET | 55 | 54 | 11 | 0.35 | +193 | +17.6 |
| COMBAT PIVOT | 10 | 10 | 10 | 0.32 | +0 | +0.0 |
| MAKE SURE TOGETHER | 17 | 11 | 10 | 0.32 | +363 | +36.3 |
| BEST OVERALL | 9 | 9 | 9 | 0.29 | +487 | +54.1 |
| BLOCKED WHEEL | 9 | 9 | 9 | 0.29 | +846 | +94.0 |
| CHAFF PASSED | 9 | 9 | 9 | 0.29 | -11 | -1.2 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.29 | +846 | +94.0 |
| LONE WIZARD HOLDS BACK | 30 | 30 | 9 | 0.29 | -335 | -37.3 |
| SHOT REPLANNED | 9 | 9 | 9 | 0.29 | +0 | +0.0 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.26 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.26 | +0 | +0.0 |
| MISSILES NEXT TURN | 166 | 99 | 7 | 0.23 | +38 | +5.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.23 | +186 | +26.5 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.23 | +542 | +77.4 |
| WHOLE FIGHT GAIN | 10 | 9 | 7 | 0.23 | +891 | +127.3 |
| MOVE AND CAST | 6 | 6 | 6 | 0.19 | +304 | +50.7 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.19 | -365 | -60.9 |
| MANOEUVRE | 5 | 5 | 5 | 0.16 | +263 | +52.6 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.16 | +124 | +24.7 |
| WEARS DOWN | 30 | 27 | 5 | 0.16 | +111 | +22.3 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.13 | +0 | +0.0 |
| OPENS UP | 5 | 5 | 4 | 0.13 | +304 | +76.0 |
| STUCK PIVOT | 4 | 4 | 4 | 0.13 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 0.13 | +27 | +6.8 |
| WHOLE FIGHT | 5 | 5 | 4 | 0.13 | +155 | +38.8 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.10 | -33 | -10.9 |
| BIG CHARACTER SAFETY | 2 | 2 | 2 | 0.06 | -25 | -12.3 |
| HUNT ADVANCE | 4 | 4 | 2 | 0.06 | +57 | +28.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MODEL FACING | 2 | 2 | 2 | 0.06 | +167 | +83.7 |
| OVERRUNS AWAY | 13 | 12 | 2 | 0.06 | +212 | +106.2 |
| BACKUP TARGETS | 38 | 13 | 1 | 0.03 | +1 | +1.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -65 | -64.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -37 | -37.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +11 | +10.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +17 | +16.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +17 | +16.7 |
| HUNT IN PAIRS | 21 | 10 | 1 | 0.03 | +19 | +19.2 |
| JOINT CHARGE PLAN | 2 | 2 | 1 | 0.03 | +57 | +57.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +5 | +5.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +126 | +125.8 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| SURE REACH TOGETHER | 17 | 12 | 1 | 0.03 | +0 | +0.4 |
| TWO OR MORE ARRIVE | 9 | 9 | 1 | 0.03 | +20 | +19.6 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 11 | 11 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 159 | not checked | - | - | - | - |
| GIVES UP | 46 | 44 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 24 | 24 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NEEDED THERE | 1 | 1 | 0 | 0.00 | - | - |
| NOT NEEDED | 9 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 158 | 158 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 20 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 1010 | trace | - | - | - | - |
| SCOUT SPOT | 21 | 21 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 39 | not checked | - | - | - | - |
| TURN WORTH | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: ff-on-101d908-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 8.03 | 8.03 | 55.3 |
| FALLBACK | gate | 0.65 | 0.61 | 43.3 |
| CHARIOT NO STATIC JOB | rule | 0.23 | 0.13 | 134.1 |
| LONE WIZARD HOLDS BACK | rule | 0.10 | 0.19 | 37.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.19 | 32.4 |
| TURN GATE | gate | 0.10 | 0.13 | 16.7 |
| AFTERMATH BAND | gate | 0.06 | 0.13 | 2.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.13 | 101.6 |
| PATHS CROSS | rule | 0.10 | 0.10 | 34.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.13 | 0.06 | 60.9 |
| CANNON PLANNED TARGET | rule | 0.13 | - | 13.1 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.06 | 10.9 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.03 | 12.3 |
| CHAFF PASSED | rule | - | 0.06 | 5.0 |
| MARCH ODDS | rule | - | 0.06 | 24.4 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 12.3 |
| SUPPORT REQUEST | gate | 0.03 | 0.03 | 10.1 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 44.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 8.6 |
| BEST PRIZE | rule | 0.03 | - | 64.6 |
| BLOCKED WHEEL | rule | 0.03 | - | 8.6 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 37.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.6 |
| MOVE AND CAST | rule | 0.03 | - | 5.7 |
| WHO HITS BACK | rule | - | 0.03 | 2.7 |

### Plans: ff-on-101d908-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 5.0 | 21% | 227 | 173 | 76% |
| Mine | charge | 0.9 | 62% | 103 | 70 | 68% |
| Mine | close in | 1.7 | 33% | 140 | 96 | 69% |
| Mine | hold | 2.6 | 46% | 175 | 0 | 0% |
| Mine | join | 0.3 | 100% | 7 | 0 | 0% |
| Mine | shoot | 4.2 | 61% | 168 | 356 | 212% |
| Mine | support | 1.7 | 92% | 97 | 0 | 0% |
| Opponent | advance | 6.2 | 12% | 384 | 121 | 31% |
| Opponent | charge | 1.1 | 69% | 115 | 103 | 89% |
| Opponent | close in | 2.2 | 21% | 166 | 48 | 29% |
| Opponent | hold | 2.0 | 63% | 128 | 0 | 0% |
| Opponent | join | 0.5 | 81% | 22 | 0 | 0% |
| Opponent | shoot | 1.5 | 71% | 27 | 78 | 288% |
| Opponent | support | 2.7 | 87% | 125 | 0 | 0% |

### Packages: hunt the guns, ff-on-101d908-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.1 | 3 | 1 | 0% | 0% | 0% | - | 507 | 0 | 0% | 79 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 265 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ff-on-101d908-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 4.3 | 20% | 58% | 8% | 100% | 21% | 8% | 17% | 54% | 0% |
| Mine | REDIRECT COUNTER | 1.3 | 26% | 30% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | COUNTER-CHARGE COVER | 4.0 | 13% | 81% | 12% | 100% | 36% | 14% | 14% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 2.9 | 18% | 81% | 12% | 50% | 7% | 0% | 7% | 79% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-on-101d908-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 67% | 2.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Character | 27 | 61 (27) | 61 | 0 | 18 | 19% | 2.3 | 67 (5) | 87 (11) | 23 (9) | 87 (17) | 19 (8) |
| Mine | Clean-up | 2 | 29 (2) | 0 | 29 | 0 | 50% | 3.0 | - | 48 (1) | 0 (1) | 29 (2) | - |
| Mine | Fast Hammer | 6 | 51 (6) | 32 | 19 | 43 | 0% | 1.8 | 71 (3) | 49 (2) | 0 (1) | 47 (5) | 75 (1) |
| Mine | Hammer | 12 | 47 (12) | 35 | 12 | 26 | 58% | 1.6 | 326 (1) | 23 (6) | 29 (5) | 52 (9) | 32 (3) |
| Mine | Holder | 6 | 92 (6) | 0 | 92 | 0 | 83% | 6.0 | 70 (3) | 116 (3) | - | 127 (4) | 49 (2) |
| Mine | Shooter | 11 | 152 (11) | 28 | 124 | 52 | 0% | 1.9 | 0 (1) | 176 (9) | 202 (1) | 176 (10) | 0 (1) |
| Mine | War machine | 11 | 40 (11) | 40 | 0 | 43 | 0% | 1.5 | 65 (4) | 34 (6) | 0 (1) | 54 (5) | 28 (6) |
| Mine | Wizard | 4 | 141 (4) | 141 | 0 | 28 | 25% | 1.7 | - | 333 (2) | 25 (1) | 333 (2) | 25 (1) |
| Opponent | Chaff | 19 | 80 (19) | 37 | 44 | 42 | 58% | 2.6 | 0 (6) | 160 (8) | 77 (5) | 60 (15) | 146 (4) |
| Opponent | Character | 20 | 30 (20) | 30 | 0 | 59 | 15% | 2.0 | 91 (4) | 10 (10) | 0 (1) | 41 (10) | 27 (5) |
| Opponent | Clean-up | 3 | 4 (3) | 0 | 4 | 66 | 67% | 2.0 | - | 4 (3) | - | 4 (3) | - |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 9 | 104 (9) | 48 | 56 | 33 | 67% | 3.3 | 34 (4) | 238 (1) | 117 (4) | 109 (8) | 0 (1) |
| Opponent | Fragile | 6 | 0 (6) | 0 | 0 | 100 | 33% | 2.8 | 0 (1) | 0 (2) | 0 (3) | 0 (6) | - |
| Opponent | Hammer | 17 | 29 (17) | 12 | 17 | 53 | 29% | 2.1 | 22 (6) | 32 (11) | - | 28 (12) | 32 (5) |
| Opponent | Holder | 8 | 69 (8) | 0 | 69 | 66 | 50% | 4.0 | - | 91 (6) | 0 (1) | 201 (3) | 0 (4) |
| Opponent | Shooter | 7 | 36 (7) | 33 | 3 | 35 | 0% | 1.1 | 0 (1) | 54 (5) | 0 (1) | 0 (3) | 72 (4) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: ff-on-101d908-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 318 | 85 | 0.5 | 1.0 | 170 | 0 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| Mine | Chaos Dwarfs | 1 | 145 | 1099 | 5.0 | 1.0 | 220 | 0 | +220 | 3 of 5 | 5 of 5 | - | +220 |
| Mine | Empire of Man | 2 | 624 | 148 | 0.5 | 1.0 | 297 | 217 | +80 | 1 of 1 | 1 of 1 | - | +80 |
| Mine | Grand Cathay | 1 | 615 | 994 | 7.0 | 1.4 | 142 | 0 | +142 | 4 of 7 | 7 of 7 | +77 | +190 |
| Mine | High Elf Realms | 1 | 114 | 540 | 3.0 | 1.0 | 180 | 116 | +64 | 1 of 3 | 2 of 3 | - | +64 |
| **Mine** | all armies | 7 | 394 | 443 | 2.4 | 1.2 | 182 | 33 | +149 | 9 of 17 | 16 of 17 | +77 | +165 |
| Opponent | Beastmen Brayherds | 1 | 65 | 0 | 2.0 | 1.5 | 0 | 42 | -42 | 0 of 2 | 0 of 2 | +0 | -85 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1268 | 6.0 | 1.3 | 211 | 0 | +211 | 2 of 6 | 6 of 6 | +267 | +184 |
| Opponent | Wood Elf Realms | 1 | 0 | 409 | 4.0 | 1.0 | 102 | 0 | +102 | 0 of 4 | 4 of 4 | - | +102 |
| **Opponent** | all armies | 7 | 9 | 240 | 2.1 | 1.2 | 112 | 6 | +106 | 2 of 15 | 10 of 15 | +178 | +88 |

### Effective charges: ff-on-101d908-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 1 (net +170) | 0 | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 0 | 1 (net +210) | 1 (net +92) | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +80) | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 7 | 0 | 0 | 1 (net +140) | 1 (net +0) | 2 (net +46) | 2 (net +111) | 1 | 17% (1 of 6) |
| Mine | High Elf Realms | 3 | 0 | 0 | 1 (net +126) | 0 | 0 | 2 (net +34) | 0 | 33% (1 of 3) |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 1 (net -85) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +354) | 0 | 0 | 4 (net +197) | 1 | 20% (1 of 5) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +70) | 1 (net +0) | 0 | 1 (net +177) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: ff-on-101d908-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 440 | 174 | +133 | 133 | 0 | +133 | +30.2 |
| Mine | 76-89% | 2 | 407 | 210 | +105 | 122 | 24 | +99 | +24.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 211 | 170 | +62 | 162 | 94 | +68 | +32.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 565 | 112 | +88 | 88 | 18 | +71 | +12.5 |
| Mine | No odds | 3 | 349 | 331 | +446 | 446 | 0 | +446 | +127.7 |
| Mine | All fights | 17 | 369 | 190 | +149 | 187 | 40 | +147 | +39.8 |
| Opponent | Long shot (under 50%) | 1 | 247 | 189 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 3 | 149 | 112 | +113 | 145 | 28 | +117 | +78.1 |
| Opponent | 76-89% | 1 | 114 | 151 | +0 | 60 | 38 | +22 | +19.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 249 | 145 | +138 | 145 | 7 | +138 | +55.3 |
| Opponent | No odds | 3 | 218 | 117 | +96 | 103 | 12 | +91 | +41.7 |
| Opponent | All fights | 15 | 214 | 136 | +106 | 121 | 14 | +107 | +50.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-on-101d908-p1 | move | 228 | 41 (18%) | 28 (12%) | 23 (10%) | 164 (72%) |
| ff-on-101d908-p1 | objective | 163 | 19 (12%) | 12 (7%) | 18 (11%) | 126 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

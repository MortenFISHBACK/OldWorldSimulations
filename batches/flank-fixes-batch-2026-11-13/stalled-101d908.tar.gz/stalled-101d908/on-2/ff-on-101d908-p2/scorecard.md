# Doctrine scorecard: ff-on-101d908-p2

### Scorecard: ff-on-101d908-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0106 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0122 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0122 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0206 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0206 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 2 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0307 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 1 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0409 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0425 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0425 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 475 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 852 |
| L0528 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0616 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0721 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0810 | 6 | 1 | Mine | no | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 7 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0827 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0918 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0918 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0934 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0934 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 7 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1118 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1135 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 3 | 4 | 1 | 0 | 0 | 158 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1323 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1418 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1418 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1435 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1435 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1531 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1531 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1629 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1629 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1727 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1727 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1827 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1827 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1927 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1927 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2029 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2029 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2131 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2131 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2235 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2235 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2429 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2429 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2535 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2535 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2735 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 75 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 14 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 634 |
| **Average** | | | Mine | 11% | 3.3 | 3.3 | 1.6 | 1.1 | 0.2 | 0.0 | 0.0 | 432.0 |
| **Average** | | | Opponent | 33% | 2.1 | 2.5 | 2.8 | 1.8 | 0.6 | 0.0 | 0.0 | 144.7 |

### KPIs: ff-on-101d908-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 100% (15 of 15); on the table 100% | 100% (6 of 6); on the table 100% | 100% (21 of 21); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 0% (0 of 1); on the table 0% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 83% (10 of 12); on the table 83% | 80% (4 of 5); on the table 80% | 82% (14 of 17); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 93% (28 of 30); on the table 93% | 83% (10 of 12); on the table 83% | 90% (38 of 42); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 29% (61 of 213) | 21% (21 of 98) | 26% (82 of 311) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (60 of 149) | 33% (21 of 64) | 38% (81 of 213) |
| Points that never fought | lower | 32% (6929 of 21896) | 34% (7476 of 21998) | 33% (14405 of 43894) |
|   infantry points that never fought | lower | 38% (1668 of 4382) | 61% (2188 of 3607) | 48% (3856 of 7989) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (51 of 87) | 60% (54 of 90) | 59% (105 of 177) |
| Bound items with a magic missile used (at least once a game) |  | 75% (15 of 20); 1.1 uses a game | 72% (13 of 18); 1.0 uses a game | 74% (28 of 38); 1.0 uses a game |
| Bound items with another spell used |  | 33% (6 of 18); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 30% (6 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 14% (1 of 7); 0.0 uses a game | 37% (10 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (9492 of 17630) | 49% (9995 of 20398) | 51% (19487 of 38028) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (32%) | 0.5 (23%) | 1.8 (29%) |
| MARCHED: its unit marched | 0.8 (20%) | 0.5 (26%) | 1.4 (22%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.1 (3%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.3 (32%) | 0.4 (20%) | 1.7 (28%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.2 (4%) | 0.4 (22%) | 0.6 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.1 (3%) | 0.2 (4%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.4 | 1.0 | 0.7 | 2.3 | 0.2 | 1.1 |
| not cast | 1.9 | 2.1 | 2.4 | 6.2 | 1.6 | 11.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.9 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (48%) | 0.1 (3%) | 1.8 (29%) | 0.3 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (22%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.1 (5%) | 0.7 (27%) | 1.7 (28%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (10%) | 0.2 (8%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (6%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.3 (15%) | 0.2 (12%) | 0.4 (15%) | 0.6 (10%) | 0.4 (26%) | 1.6 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.1 (7%) | 0.1 (6%) | 0.1 (2%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (5%) | 0.1 (3%) | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.1 (58%) | 0.1 (4%) | 0.9 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.2 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.4 a game | 0.4 a game | 0.4 a game |
| stood (cast and not dispelled) | 69% (9 of 13) | 44% (7 of 16) | 55% (16 of 29) |
| the unit moved after it | 67% (6 of 9) | 57% (4 of 7) | 62% (10 of 16) |
| it charged on its next turn | 11% (1 of 9) | 14% (1 of 7) | 12% (2 of 16) |
| the enemy charged it first | 22% (2 of 9) | 0% (0 of 7) | 12% (2 of 16) |
| it fought by the end of its next turn | 11% (1 of 9) | 0% (0 of 7) | 6% (1 of 16) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 9) | 14% (1 of 7) | 6% (1 of 16) |
| none of these (no charge, no fight, no charge escaped) | 67% (6 of 9) | 71% (5 of 7) | 69% (11 of 16) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (229 of 284) | 48% (97 of 204) | 67% (326 of 488) |
|   cavalry | 71% (12 of 17) | 50% (32 of 64) | 54% (44 of 81) |
|   character | 86% (36 of 42) | 6% (2 of 31) | 52% (38 of 73) |
|   chariot | 41% (9 of 22) | 50% (4 of 8) | 43% (13 of 30) |
|   infantry | 72% (29 of 40) | 68% (52 of 77) | 69% (81 of 117) |
|   monster | 50% (3 of 6) | - | 50% (3 of 6) |
|   war machine | 89% (140 of 157) | 29% (7 of 24) | 81% (147 of 181) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (22%) | 0.8 (27%) | 1.1 (25%) |
| CHARGED: it charged | 0.3 (20%) | 0.6 (20%) | 0.9 (20%) |
| IN COMBAT: it fought this turn or the last | 0.2 (15%) | 0.1 (4%) | 0.3 (7%) |
| NO TARGET IN RANGE | 0.1 (4%) | 0.5 (17%) | 0.6 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (2%) | 0.2 (7%) | 0.2 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.4 (25%) | 0.6 (21%) | 1.0 (23%) |
| SHELTERED: the target was sheltered | 0.1 (4%) | 0.1 (4%) | 0.2 (4%) |
| STUPIDITY | 0.0 (2%) | 0.0 (0%) | 0.0 (1%) |
| OTHER BAR | 0.1 (7%) | 0.0 (1%) | 0.1 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.8 | 0.3 | 85% | 5.6 pts | 10 pts |
| character | 1.1 | 0.4 | 63% | 15.2 pts | 16 pts |
| chariot | 0.4 | 0.6 | 62% | 15.0 pts | 5 pts |
| infantry | 3.2 | 1.2 | 75% | 8.6 pts | 28 pts |
| monster | 0.1 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 4.1 | 3.2 | 65% | 28.7 pts | 117 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.8 | 2.7 | 2.2 |
| Charges that made contact a game | 1.4 | 2.0 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.79 declared, 0.68 contact (19 units) | 0.60 declared, 0.50 contact (10 units) | 0.72 declared, 0.62 contact (29 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.40 contact (5 units) | 0.88 declared, 0.62 contact (8 units) | 0.77 declared, 0.54 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.16 declared, 0.13 contact (280 units) | 0.26 declared, 0.18 contact (332 units) | 0.21 declared, 0.16 contact (612 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 68% (17 of 25) | 100% (1 of 1) | 50% (3 of 6) | 66% (21 of 32) |
| Character in a unit | 91% (10 of 11) | 50% (3 of 6) | 100% (1 of 1) | 78% (14 of 18) |
| Character on its own | 83% (10 of 12) | 56% (10 of 18) | 11% (2 of 19) | 45% (22 of 49) |
| Chariot | 0% (0 of 3) | 67% (2 of 3) | - | 33% (2 of 6) |
| Infantry | 67% (14 of 21) | 70% (7 of 10) | 0% (0 of 2) | 64% (21 of 33) |
| Monster | 67% (6 of 9) | 0% (0 of 1) | - | 60% (6 of 10) |
| Monstrous | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| War Machines | 62% (13 of 21) | 100% (1 of 1) | - | 64% (14 of 22) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 16% | 33% (2 of 6) | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 1 | - | 83% (10 of 12) | 26% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 86% (6 of 7); on the table 86% | - | 29% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 62% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Grand Cathay | 5 | 87% (13 of 15); on the table 87% | 28% (30 of 108) | 40% | 50% (23 of 46) | 92% (11 of 12); 9.2 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (5 of 5); on the table 100% | - | 33% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 67% (2 of 3); on the table 67% | 25% (3 of 12) | 4% | 64% (7 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 100% (6 of 6); on the table 100% | 50% (6 of 12) | 35% | 39% (11 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 3 | 100% (3 of 3); on the table 100% | 39% (7 of 18) | 38% | 82% (28 of 34) | 50% (2 of 4); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ff-on-101d908-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (23) | 38% (9) | 48% (32) |
| ...free all their last turn and able to turn (per game) | 0.44 | 0.17 | 0.61 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.06 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.11 | 0.42 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.42 | 0.53 | 0.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.44 | 0.50 | 0.94 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 3.19 | 3.00 | 6.19 |

### Quality by phase: ff-on-101d908-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 65% (33 of 51) | 48% (38 of 80) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (105 of 224) | 48% (34 of 71) |
| Strategy | Close-in objectives charged next turn | 17% (14 of 82) | 14% (17 of 123) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | 56% (5 of 9) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 81% (13 of 16) | 50% (4 of 8) |
| Strategy | Lone characters that fought | 81% (29 of 36) | 96% (26 of 27) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 432.0 | 144.7 |
| Movement | Fights charged into per game | 2.1 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 22 | 5 of 35, net +166 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 22, net +156 | 7 of 35, net +167 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 22, net +281 | 4 of 35, net +290 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 22, net +107 | 10 of 35, net +182 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.5 | 2.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (63 of 91) | 42% (43 of 103) |
| Shooting | Points destroyed by shooting units | 58.0 | 5.0 |
| Shooting | War machine shots | 3.9 | 0.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (88 of 140) | 29% (2 of 7) |
| Shooting | Points destroyed by war machines | 52.1 | 9.7 |
| Magic | Magic missiles cast | 1.3 | 0.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (12 of 46) | 47% (7 of 15) |
| Magic | Wounds caused by magic missiles | 2.1 | 0.6 |
| Magic | Wounds caused by other spells | 0.8 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 22.8 | 1.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.4 / 0.4 / 0.5 / 0.1 | 1.3 / 0.2 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 85.5 | 140.9 |
| Combat | Points run down | 54.3 | 55.3 |
| Combat | Net points per charged fight, damage counted | +103 | +133 |
| Combat | Net per 100 charger points, damage counted | +33.6 | +37.9 |
| Combat | First round won (charged fights) | 74% | 55% |
| Combat | Net points per charged fight | +115 | +168 |
| Combat | Net points per supported fight / lone fight | +366 / +46 | +161 / +169 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 23 | 21 of 38 |
| Game | Points lost | 783.9 | 888.0 |
| Game | VP from objectives | 458.2 | 515.5 |
| Game | Lone holders (player turns) | 3.3 | 2.1 |

- Mine won / drew / lost: 5 / 0 / 6 of 11 ended games (of 36); mean margin (Mine - Opponent) +36 VP
- The side that went first won 5 of 11 games with a winner
- Points traded per game (both sides' losses): 1672
- Games not ended: 25 (L0106-1, L0122-1, L0206-1, L0307-1, L0409-1, L0425-1, L0616-1, L0721-1, L0827-1, L0918-1, L0934-1, L1118-1, L1323-1, L1418-1, L1435-1, L1531-1, L1629-1, L1727-1, L1827-1, L1927-1, L2029-1, L2131-1, L2235-1, L2429-1, L2535-1); findings 25, warnings 0

### Opponent rules: ff-on-101d908-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 15.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +4.3 | 0.0 | 0.0 | 0.7 | +9.2 | 0.0 | 0.0 |
| BEST OVERALL | 0.3 | +11.4 | 0.0 | 16.8 | 0.2 | +14.1 | 0.0 | 0.0 |
| BEST PREY | 2.0 | +108.1 | 13.8 | 20.9 | 2.8 | +242.5 | 20.2 | 26.4 |
| BEST PRIZE | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | +3.7 | 4.7 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 12.1 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.1 | +2.5 | 0.0 | 0.0 | 0.2 | +2.0 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 120.6 | 5.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.9 | +154.3 | 367.2 | 32.8 | 0.6 | +16.2 | 18.1 | 0.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.4 | 7.4 | - | - | - | - |
| CARRIES OUT SET-UP | 0.0 | -1.9 | 0.0 | 0.0 | 0.1 | +0.0 | 5.9 | 0.0 |
| CAST JOB | 0.6 | +10.2 | 22.3 | 1.7 | 0.3 | +6.5 | 7.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +11.1 | 3.2 | 0.0 | 0.1 | +3.4 | 5.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 19.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.8 | 5.4 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +2.8 | 8.9 | 0.0 |
| CHARGE NOW WEIGHED | 0.2 | -20.7 | 20.6 | 5.9 | 0.3 | -57.3 | 3.3 | 25.8 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 12.6 | 10.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.1 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 7.4 | 0.2 | +0.0 | 15.9 | 30.8 |
| CONVEYANCE SEARCH | 0.3 | +52.7 | 0.0 | 0.0 | 0.4 | +39.4 | 0.0 | 7.6 |
| COUNTER-CHARGE COVER | 5.9 | +435.4 | 0.0 | 46.2 | 3.8 | +296.7 | 0.0 | 59.6 |
| EDGE GIVE GROUND | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +2.0 | 5.6 | 12.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.4 | +28.9 | 0.0 | 17.5 | 0.5 | +52.4 | 0.0 | 13.6 |
| FALLBACK BY WORTH | 3.5 | +58.8 | 0.0 | 25.9 | 4.5 | +34.5 | 0.0 | 29.5 |
| FIGHT LIFT | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 3.2 | +0.0 | 0.0 | 34.2 | 2.8 | +0.0 | 0.0 | 69.5 |
| FOCUS FIRE | 0.0 | +2.0 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +149.6 | 0.0 | 38.4 | 0.5 | +75.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +15.4 | 0.0 | 6.5 | 0.1 | +4.4 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -14.4 | 27.2 | 0.0 | 0.8 | -27.0 | 59.2 | 48.4 |
| GIVES UP ITS SCREEN | 0.2 | -5.3 | 0.0 | 0.0 | 0.5 | -12.7 | 16.2 | 1.1 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 12.1 | 5.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +18.7 | 0.0 | 0.0 | 0.3 | +12.2 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 5.7 | 1.1 |
| HUNT THE GUNS | 0.1 | +19.9 | 0.0 | 0.0 | 0.1 | +43.2 | 0.0 | 1.1 |
| JOINT CHARGE PLAN | 0.1 | +4.7 | 0.0 | 0.0 | 0.1 | +5.2 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.5 | 0.0 | 1.4 | 0.1 | +0.6 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.0 | +29.2 | 52.4 | 25.6 | 1.2 | +36.7 | 104.8 | 48.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 0.8 | +59.3 | 48.6 | 6.1 | 0.9 | +38.9 | 46.9 | 32.2 |
| KILLS COUNT NEXT TURN | 3.9 | +145.2 | 62.1 | 68.8 | 6.6 | +385.6 | 142.7 | 112.9 |
| LONE CHARACTER SAFE SPOT | 0.1 | +7.2 | 9.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.7 | +0.0 | 17.6 | 0.0 | 0.6 | +0.0 | 27.7 | 33.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +43.5 | 0.0 | 0.0 | 0.8 | +47.7 | 19.9 | 30.6 |
| MANOEUVRE | 0.1 | +2.3 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +5.3 | 0.0 | 0.0 | 0.4 | +36.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.5 | +37.8 | 12.2 | 17.8 | 0.4 | +32.5 | 19.5 | 34.8 |
| MARCH OVER CASTS | 0.3 | +17.0 | 0.0 | 0.0 | 0.2 | +29.4 | 0.0 | 25.6 |
| MAX FOR POSITIONING | 2.7 | +91.2 | 0.0 | 22.2 | 2.7 | +111.6 | 0.0 | 65.1 |
| MISSILES IN THE MOVE | 2.4 | +50.3 | 0.0 | 15.4 | 1.9 | +31.4 | 0.0 | 55.5 |
| MISSILES NEXT TURN | 3.1 | +41.5 | 0.0 | 10.8 | 2.3 | +24.8 | 0.0 | 81.1 |
| MODEL FACING | 0.2 | +60.6 | 0.0 | 1.7 | 0.2 | +45.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.1 | +6.3 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -25.8 | 9.4 | 17.5 | 0.1 | -6.3 | 3.5 | 6.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 12.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -14.6 | 10.7 | 0.0 | 0.1 | -11.9 | 18.0 | 3.8 |
| NOT TURNED | 3.2 | +104.5 | 0.0 | 35.7 | 3.0 | +35.4 | 0.0 | 53.0 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 9.6 | -535.6 | 0.0 | 70.4 | 9.9 | -573.4 | 0.0 | 174.8 |
| OPENS A LANE | 0.2 | +0.3 | 2.8 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +3.8 | 9.3 | 0.0 | 0.1 | +6.1 | 0.0 | 15.9 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +7.2 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.2 | +3.2 | 19.8 | 0.0 | 0.2 | +5.9 | 3.1 | 5.4 |
| PATHS CROSS | 1.4 | +107.7 | 0.0 | 7.4 | 2.0 | +128.3 | 0.0 | 31.9 |
| PIVOT GUARDS FLANK | 0.1 | -1.9 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| PLAN LEADS | 1.1 | +126.9 | 16.0 | 14.2 | 0.8 | +51.2 | 4.2 | 3.9 |
| PLAN RESULT | 18.1 | +935.8 | 520.8 | 284.7 | 19.6 | +419.7 | 343.0 | 412.2 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -1.1 | 0.0 | 16.6 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +3.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.1 | +129.0 | 0.0 | 15.3 | 2.6 | +198.4 | 0.0 | 27.9 |
| REDIRECT WEIGHED | 0.1 | +0.8 | 0.8 | 0.0 | 0.2 | +9.6 | 11.1 | 5.4 |
| RESTRAINS TO SHOOT | 0.0 | +4.6 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| RISK BY ARC | 0.9 | +42.7 | 77.4 | 6.1 | 1.3 | +17.8 | 44.7 | 42.0 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -9.9 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.4 | +23.6 | 0.0 | 16.8 | 0.5 | +38.8 | 0.0 | 24.1 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.1 | +67.3 | 0.0 | 15.2 | 1.1 | +68.6 | 0.0 | 6.2 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +51.7 | 0.0 | 0.0 | 1.1 | +68.6 | 19.9 | 33.6 |
| SET-UP ANY TARGET | 0.1 | +22.4 | 0.0 | 0.0 | 0.1 | +13.4 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +5.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 166.8 | 2.6 | 0.4 | +0.0 | 2.1 | 0.0 |
| SHOTS IN THE MOVE | 8.1 | +404.9 | 0.0 | 82.6 | 5.6 | +102.3 | 0.0 | 50.2 |
| SPELL SETS UP CHARGE | 0.2 | +39.8 | 0.0 | 0.0 | 0.2 | +38.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +6.8 | 1.7 | 1.7 | 1.2 | +20.8 | 49.9 | 59.6 |
| STOPS | - | - | - | - | 0.1 | +4.0 | 0.0 | 1.1 |
| STOPS SHORT OF THE FLANK | 0.2 | +13.7 | 0.0 | 0.0 | 0.1 | +8.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.4 | 3.5 | 2.4 | 0.1 | -8.4 | 14.4 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +5.5 | 0.0 | 0.0 | 0.5 | -6.5 | 0.0 | 3.0 |
| THROUGH LINE OF FIRE | 0.2 | +21.6 | 0.0 | 0.0 | 0.1 | +4.5 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -10.0 | 15.1 | 0.0 | 0.2 | -11.7 | 6.4 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +5.2 | 0.0 | 0.0 | 0.2 | +0.7 | 6.5 | 3.8 |
| WEARS DOWN | 0.4 | +26.2 | 37.6 | 7.4 | 0.7 | +27.8 | 32.0 | 9.4 |
| WHO HITS BACK | 0.1 | +12.2 | 0.0 | 3.8 | 0.1 | +2.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +3.7 | 5.7 | 0.0 | 0.2 | +12.5 | 39.5 | 1.1 |
| WHOLE FIGHT GAIN | 0.1 | +11.7 | 22.6 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |

### Rule changes: ff-on-101d908-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 703 | 703 | 703 | 19.53 | -39923 | -56.8 |
| KILLS COUNT NEXT TURN | 376 | 374 | 135 | 3.75 | +4790 | +35.5 |
| PATHS CROSS | 123 | 123 | 123 | 3.42 | +8498 | +69.1 |
| BEST PREY | 171 | 170 | 75 | 2.08 | +3750 | +50.0 |
| SEARCH SPOT | 76 | 76 | 75 | 2.08 | +4895 | +65.3 |
| FALLBACK BY WORTH | 287 | 287 | 71 | 1.97 | +3357 | +47.3 |
| COUNTER-CHARGE COVER | 349 | 171 | 68 | 1.89 | +3102 | +45.6 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 41 | 41 | 41 | 1.14 | +8110 | +197.8 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| FACES THE THREAT | 34 | 34 | 34 | 0.94 | +2927 | +86.1 |
| SAFER THAN THE JOB | 34 | 34 | 34 | 0.94 | +2248 | +66.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH ODDS | 31 | 31 | 29 | 0.81 | +533 | +18.4 |
| MAX FOR POSITIONING | 193 | 94 | 27 | 0.75 | +226 | +8.4 |
| PLAN LEADS | 71 | 71 | 27 | 0.75 | +1096 | +40.6 |
| CANNON PLANNED TARGET | 162 | 162 | 26 | 0.72 | -590 | -22.7 |
| MARCH CHECK | 27 | 27 | 26 | 0.72 | +1347 | +51.8 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| KILLS COUNT | 58 | 57 | 24 | 0.67 | +1297 | +54.0 |
| SET UP TOGETHER | 63 | 55 | 23 | 0.64 | +947 | +41.2 |
| REDIRECT COUNTER | 168 | 62 | 21 | 0.58 | +1768 | +84.2 |
| SHOTS IN THE MOVE | 495 | 311 | 21 | 0.58 | +738 | +35.1 |
| BEST OVERALL | 20 | 20 | 20 | 0.56 | +919 | +45.9 |
| CHARGE NOW WEIGHED | 19 | 19 | 19 | 0.53 | +2403 | +126.5 |
| KEEPS ITS TARGET | 79 | 79 | 18 | 0.50 | +291 | +16.2 |
| MISSILES IN THE MOVE | 153 | 82 | 18 | 0.50 | +431 | +23.9 |
| RISK BY ARC | 81 | 79 | 18 | 0.50 | +467 | +25.9 |
| LONE WIZARD HOLDS BACK | 46 | 46 | 17 | 0.47 | -1419 | -83.5 |
| CAST JOB | 35 | 35 | 16 | 0.44 | +157 | +9.8 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -38 | -2.5 |
| MODEL FACING | 15 | 15 | 15 | 0.42 | +3801 | +253.4 |
| COMBAT PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BLOCKED WHEEL | 13 | 13 | 13 | 0.36 | +162 | +12.5 |
| CHARIOT NO STATIC JOB | 26 | 26 | 13 | 0.36 | -1063 | -81.8 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 12 | 12 | 12 | 0.33 | +813 | +67.8 |
| THROUGH LINE OF FIRE | 12 | 12 | 12 | 0.33 | +941 | +78.5 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +712 | +64.7 |
| MAKE SURE TOGETHER | 46 | 32 | 10 | 0.28 | +385 | +38.5 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.25 | +216 | +24.0 |
| MOVE AND CAST | 8 | 8 | 8 | 0.22 | +410 | +51.2 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -461 | -57.6 |
| CASTING BLOCK | 11 | 11 | 7 | 0.19 | +241 | +34.5 |
| WEARS DOWN | 41 | 39 | 7 | 0.19 | +281 | +40.1 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | +34 | +5.7 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -83 | -13.9 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| WHO HITS BACK | 6 | 6 | 6 | 0.17 | +275 | +45.9 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +260 | +52.0 |
| SURE REACH TOGETHER | 34 | 23 | 5 | 0.14 | +99 | +19.8 |
| WHOLE FIGHT | 10 | 10 | 5 | 0.14 | +90 | +18.1 |
| HUNT IN PAIRS | 18 | 13 | 4 | 0.11 | +227 | +56.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| MANOEUVRE | 3 | 3 | 3 | 0.08 | +95 | +31.7 |
| MISSILES NEXT TURN | 193 | 100 | 3 | 0.08 | +25 | +8.2 |
| OVERRUNS AWAY | 18 | 18 | 3 | 0.08 | +43 | +14.2 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +239 | +79.7 |
| WHOLE FIGHT GAIN | 7 | 4 | 3 | 0.08 | +189 | +63.1 |
| BACKUP TARGETS | 49 | 20 | 2 | 0.06 | +81 | +40.4 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -24 | -12.2 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +101 | +50.5 |
| OPENS UP | 6 | 6 | 2 | 0.06 | +33 | +16.3 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -41 | -20.4 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +33 | +32.7 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -70 | -69.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +14 | +14.5 |
| GIVES UP | 44 | 44 | 1 | 0.03 | +8 | +8.0 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.03 | +3 | +2.9 |
| KEEPS ITS PREY | 7 | 7 | 1 | 0.03 | +10 | +10.1 |
| MOVE SPELL IN RANGE | 1 | 1 | 1 | 0.03 | +0 | +0.3 |
| OPENS A LANE | 8 | 2 | 1 | 0.03 | +20 | +19.6 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +23 | +23.1 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -449 | -448.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 216 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 24 | 20 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 11 | 10 | 0 | 0.00 | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 9 | not checked | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 223 | 223 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 20 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 1357 | trace | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 57 | not checked | - | - | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TURN WORTH | 11 | 11 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: ff-on-101d908-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 8.75 | 8.92 | 58.1 |
| FALLBACK | gate | 0.47 | 0.53 | 51.5 |
| TURN GATE | gate | 0.22 | 0.28 | 30.5 |
| CHARIOT NO STATIC JOB | rule | 0.19 | 0.17 | 81.8 |
| LONE WIZARD HOLDS BACK | rule | 0.14 | 0.19 | 118.2 |
| PATHS CROSS | rule | 0.08 | 0.17 | 45.1 |
| CHAFF PASSED | rule | 0.11 | 0.11 | 4.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.14 | 57.6 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.03 | 84.4 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.03 | 13.9 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.03 | 75.5 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 2.5 |
| AFTERMATH BAND | gate | 0.03 | 0.03 | 2.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 47.9 |
| BEST PRIZE | rule | 0.03 | 0.03 | 12.2 |
| BLOCKED WHEEL | rule | 0.06 | - | 17.5 |
| FALLBACK BY WORTH | rule | 0.06 | - | 13.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 69.0 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.9 |
| PURSUES BIG PREY | rule | - | 0.06 | 20.4 |
| STAYS FIRST | gate | 0.03 | 0.03 | 19.1 |
| SUPPORT REQUEST | gate | 0.03 | 0.03 | 147.4 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 69.8 |
| REDIRECT WEIGHED | rule | - | 0.03 | 12.4 |
| SAFE SURE CHARGE | rule | - | 0.03 | 448.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 0.6 |
| WHO HITS BACK | rule | - | 0.03 | 2.3 |

### Plans: ff-on-101d908-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 5.8 | 17% | 254 | 172 | 68% |
| Mine | charge | 0.8 | 73% | 132 | 132 | 100% |
| Mine | close in | 1.8 | 32% | 130 | 87 | 67% |
| Mine | hold | 2.0 | 31% | 150 | 0 | 0% |
| Mine | join | 0.4 | 100% | 9 | 0 | 0% |
| Mine | shoot | 5.0 | 64% | 209 | 545 | 261% |
| Mine | support | 2.2 | 86% | 146 | 0 | 0% |
| Opponent | advance | 7.2 | 15% | 392 | 144 | 37% |
| Opponent | charge | 1.6 | 46% | 250 | 127 | 51% |
| Opponent | close in | 2.9 | 26% | 261 | 79 | 31% |
| Opponent | hold | 2.4 | 38% | 244 | 0 | 0% |
| Opponent | join | 0.4 | 100% | 12 | 0 | 0% |
| Opponent | shoot | 1.5 | 68% | 22 | 72 | 325% |
| Opponent | support | 3.6 | 93% | 193 | 0 | 0% |

### Packages: hunt the guns, ff-on-101d908-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 358 | 0 | 0% | 23 |
| Opponent | 0.1 | 3 | 2 | 0% | 0% | 0% | - | 222 | 0 | 0% | 236 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 255 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 133 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Vampire Counts | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 222 | 0 | 0% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 419 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |

### Battle groups: ff-on-101d908-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 5.9 | 14% | 61% | 13% | 50% | 26% | 0% | 7% | 67% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 26% | 70% | 10% | 0% | 11% | 0% | 0% | 83% | 6% |
| Opponent | COUNTER-CHARGE COVER | 3.8 | 12% | 75% | 25% | 25% | 25% | 0% | 8% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.6 | 18% | 82% | 6% | 0% | 19% | 0% | 25% | 56% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-on-101d908-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 11 | 0 (11) | 0 | 0 | 71 | 18% | 3.2 | 0 (4) | 0 (3) | 0 (4) | 0 (8) | 0 (3) |
| Mine | Character | 46 | 68 (46) | 68 | 0 | 39 | 11% | 2.3 | 53 (9) | 89 (24) | 0 (1) | 77 (22) | 77 (12) |
| Mine | Clean-up | 2 | 33 (2) | 0 | 33 | 0 | 100% | - | - | 0 (1) | 92 (1) | 0 (1) | 92 (1) |
| Mine | Fast Hammer | 16 | 65 (16) | 32 | 33 | 60 | 25% | 3.2 | 68 (10) | 70 (4) | 0 (2) | 100 (9) | 32 (7) |
| Mine | Hammer | 15 | 37 (15) | 16 | 22 | 60 | 20% | 2.0 | 27 (4) | 52 (8) | 0 (3) | 32 (9) | 42 (6) |
| Mine | Holder | 8 | 34 (8) | 0 | 34 | 0 | 50% | 2.2 | 0 (2) | 51 (5) | 0 (1) | 67 (4) | 0 (4) |
| Mine | Shooter | 9 | 26 (9) | 12 | 14 | 66 | 0% | 1.6 | - | 32 (6) | 8 (3) | 36 (6) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 30 | 71 (30) | 71 | 0 | 27 | 3% | 1.2 | 147 (7) | 65 (16) | 13 (7) | 10 (5) | 86 (25) |
| Mine | Wizard | 6 | 54 (6) | 54 | 0 | 58 | 17% | 1.4 | 0 (3) | 189 (2) | - | 140 (3) | 0 (2) |
| Opponent | Chaff | 28 | 50 (28) | 12 | 38 | 56 | 25% | 2.6 | 32 (11) | 8 (5) | 89 (12) | 36 (23) | 107 (5) |
| Opponent | Character | 26 | 74 (26) | 74 | 0 | 37 | 12% | 2.5 | 90 (9) | 78 (10) | 69 (2) | 74 (14) | 99 (7) |
| Opponent | Clean-up | 3 | 131 (3) | 0 | 131 | 64 | 67% | 1.0 | 0 (1) | 365 (1) | 0 (1) | 0 (2) | 365 (1) |
| Opponent | Fast Hammer | 14 | 36 (14) | 17 | 19 | 71 | 36% | 2.6 | 9 (5) | 45 (6) | 67 (3) | 42 (9) | 18 (5) |
| Opponent | Hammer | 13 | 37 (13) | 37 | 0 | 51 | 38% | 3.2 | 0 (3) | 35 (8) | 124 (2) | 31 (6) | 44 (7) |
| Opponent | Holder | 11 | 100 (11) | 13 | 87 | 13 | 18% | 2.9 | 0 (2) | 126 (9) | - | 80 (6) | 131 (5) |
| Opponent | Shooter | 10 | 17 (10) | 13 | 4 | 44 | 10% | 1.8 | 22 (4) | 17 (5) | 0 (1) | 42 (5) | 0 (5) |
| Opponent | War machine | 4 | 39 (4) | 39 | 0 | 0 | 25% | 1.3 | - | 38 (2) | 39 (2) | - | 39 (4) |
| Opponent | Wizard | 9 | 5 (9) | 5 | 0 | 76 | 0% | 1.4 | 0 (3) | 6 (4) | - | 6 (5) | 0 (2) |

### Charged fights: ff-on-101d908-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 317 | 2.0 | 1.0 | 158 | 42 | +116 | 1 of 2 | 2 of 2 | - | +116 |
| Mine | Chaos Dwarfs | 1 | 461 | 195 | 1.0 | 1.0 | 195 | 0 | +195 | 1 of 1 | 1 of 1 | - | +195 |
| Mine | Dwarfen Mountain Holds | 3 | 1040 | 78 | 1.7 | 1.2 | 47 | 60 | -13 | 1 of 5 | 1 of 5 | +0 | -16 |
| Mine | Empire of Man | 1 | 569 | 0 | 1.0 | 1.0 | 0 | 301 | -301 | 1 of 1 | 0 of 1 | - | -301 |
| Mine | Grand Cathay | 3 | 198 | 697 | 3.3 | 1.4 | 209 | 34 | +175 | 2 of 10 | 9 of 10 | +408 | +75 |
| Mine | Vampire Counts | 1 | 0 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 1 of 2 | 2 of 2 | - | +62 |
| Mine | Warriors of Chaos | 1 | 38 | 717 | 2.0 | 1.5 | 358 | 0 | +358 | 0 of 2 | 2 of 2 | +608 | +109 |
| **Mine** | all armies | 11 | 435 | 335 | 2.1 | 1.3 | 160 | 45 | +115 | 7 of 23 | 17 of 23 | +366 | +46 |
| Opponent | Grand Cathay | 2 | 175 | 292 | 3.5 | 1.3 | 83 | 0 | +83 | 3 of 7 | 5 of 7 | +107 | +74 |
| Opponent | Tomb Kings of Khemri | 2 | 52 | 1497 | 4.5 | 1.1 | 333 | 57 | +276 | 5 of 9 | 5 of 9 | +594 | +236 |
| Opponent | Vampire Counts | 1 | 0 | 727 | 4.0 | 1.2 | 182 | 38 | +144 | 2 of 4 | 1 of 4 | -150 | +242 |
| Opponent | Warriors of Chaos | 3 | 0 | 455 | 2.3 | 1.3 | 195 | 0 | +195 | 6 of 7 | 4 of 7 | +153 | +212 |
| Opponent | Wood Elf Realms | 3 | 42 | 533 | 3.7 | 1.0 | 145 | 21 | +125 | 5 of 11 | 6 of 11 | - | +125 |
| **Opponent** | all armies | 11 | 53 | 661 | 3.5 | 1.2 | 191 | 23 | +168 | 21 of 38 | 21 of 38 | +161 | +169 |

### Effective charges: ff-on-101d908-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +116) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +195) | 0 | 0% (0 of 1) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 1 (net -233) | 1 (net -65) | 0 | 0 | 2 (net +102) | 1 | 25% (1 of 4) |
| Mine | Empire of Man | 1 | 0 | 0 | 1 (net -301) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Grand Cathay | 10 | 0 | 0 | 1 (net +990) | 2 (net +55) | 0 | 7 (net +93) | 0 | 10% (1 of 10) |
| Mine | Vampire Counts | 2 | 0 | 0 | 1 (net +0) | 0 | 1 (net +125) | 0 | 0 | 50% (1 of 2) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 2 (net +358) | 0 | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 7 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +32) | 1 (net +214) | 2 (net +152) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +219) | 1 (net +0) | 1 (net +491) | 1 (net +85) | 1 (net +594) | 3 (net +308) | 1 | 12% (1 of 8) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 2 (net +280) | 1 (net -150) | 0 | 1 (net +167) | 0 | 50% (2 of 4) |
| Opponent | Warriors of Chaos | 7 | 1 (net +73) | 0 | 1 (net +120) | 2 (net +282) | 1 (net +233) | 2 (net +188) | 0 | 14% (1 of 7) |
| Opponent | Wood Elf Realms | 11 | 2 (net +269) | 0 | 2 (net +0) | 2 (net +311) | 1 (net +120) | 2 (net +22) | 2 | 22% (2 of 9) |

### Charged fights, damage counted: ff-on-101d908-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 50 | 489 | -233 | 0 | 233 | -233 | -466.0 |
| Mine | Effective (55-75%) | 4 | 328 | 249 | +156 | 320 | 146 | +174 | +53.0 |
| Mine | 76-89% | 2 | 404 | 110 | +55 | 55 | 0 | +55 | +13.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 221 | 165 | +107 | 146 | 49 | +97 | +44.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 715 | 153 | +281 | 281 | 79 | +201 | +28.1 |
| Mine | No odds | 1 | 105 | 30 | +30 | 30 | 0 | +30 | +28.6 |
| Mine | All fights | 23 | 307 | 182 | +115 | 174 | 71 | +103 | +33.6 |
| Opponent | Long shot (under 50%) | 5 | 337 | 308 | +166 | 208 | 88 | +120 | +35.6 |
| Opponent | 50-54% | 1 | 411 | 272 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 7 | 370 | 266 | +167 | 295 | 90 | +204 | +55.3 |
| Opponent | 76-89% | 8 | 273 | 136 | +148 | 167 | 100 | +67 | +24.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 10 | 303 | 173 | +182 | 193 | 60 | +133 | +43.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 606 | 159 | +290 | 290 | 54 | +236 | +38.9 |
| Opponent | No odds | 3 | 345 | 266 | +72 | 107 | 35 | +72 | +20.9 |
| Opponent | All fights | 38 | 352 | 209 | +168 | 207 | 73 | +133 | +37.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-on-101d908-p2 | move | 271 | 57 (21%) | 47 (17%) | 20 (7%) | 194 (72%) |
| ff-on-101d908-p2 | objective | 205 | 31 (15%) | 28 (14%) | 24 (12%) | 150 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

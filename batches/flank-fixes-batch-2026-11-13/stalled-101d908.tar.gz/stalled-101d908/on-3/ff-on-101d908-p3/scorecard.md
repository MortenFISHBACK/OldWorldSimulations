# Doctrine scorecard: ff-on-101d908-p3

### Scorecard: ff-on-101d908-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0110 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0126 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0126 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0210 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0210 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0226 | 4 | 1 | Mine | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0311 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0327 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0327 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0413 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0413 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0429 | 3 | 1 | Mine | yes | 19 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 255 |
| L0516 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0516 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 1011 |
| L0620 | 2 | 1 | Opponent | - | - | 6 | 2 | 4 | 1 | 0 | 0 | 95 |
| L0709 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0709 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0725 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0725 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0831 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0922 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0922 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1013 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1013 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1030 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1030 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1122 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1122 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1232 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1327 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1327 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1422 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1422 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1535 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1633 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 4 | 0 | 0 | 0 | 405 |
| L1731 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1731 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1831 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1831 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 642 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2033 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2223 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2223 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2327 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2327 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 25% | 4.7 | 1.9 | 2.2 | 0.8 | 0.2 | 0.0 | 0.0 | 398.6 |
| **Average** | | | Opponent | 12% | 1.8 | 2.9 | 2.4 | 2.6 | 0.2 | 0.0 | 0.0 | 125.0 |

### KPIs: ff-on-101d908-p3

Morten 2026-11-10; 32 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 100% (13 of 13); on the table 100% | 89% (8 of 9); on the table 89% | 95% (21 of 22); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 100% (3 of 3); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fled |  | 86% (6 of 7); on the table 86% | 67% (8 of 12); on the table 67% | 74% (14 of 19); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 96% (24 of 25); on the table 96% | 79% (19 of 24); on the table 79% | 88% (43 of 49); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 20% (32 of 161) | 30% (29 of 96) | 24% (61 of 257) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 28% (32 of 115) | 39% (29 of 74) | 32% (61 of 189) |
| Points that never fought | lower | 33% (5869 of 17898) | 33% (5901 of 17997) | 33% (11770 of 35895) |
|   infantry points that never fought | lower | 32% (1241 of 3885) | 63% (2595 of 4116) | 48% (3836 of 8001) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (34 of 71) | 51% (35 of 68) | 50% (69 of 139) |
| Bound items with a magic missile used (at least once a game) |  | 79% (19 of 24); 1.4 uses a game | 80% (16 of 20); 1.2 uses a game | 80% (35 of 44); 1.3 uses a game |
| Bound items with another spell used |  | 7% (1 of 14); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game | 5% (1 of 20); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 36% (4 of 11); 0.1 uses a game | 45% (14 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (6530 of 15013) | 41% (6820 of 16465) | 42% (13350 of 31478) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (25%) | 0.7 (36%) | 1.7 (28%) |
| MARCHED: its unit marched | 1.2 (31%) | 0.6 (28%) | 1.8 (30%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.7 (17%) | 0.4 (22%) | 1.1 (19%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (3%) | 0.1 (2%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.2 (3%) |
| GONE: slain | 0.2 (6%) | 0.2 (8%) | 0.4 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.0 (0%) | 0.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 0.4 | 1.3 | 1.9 | 0.4 | 1.2 |
| not cast | 2.0 | 0.7 | 2.5 | 6.0 | 1.7 | 9.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.4 (64%) | 0.1 (4%) | 1.7 (28%) | 0.1 (4%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (30%) | 0.5 (28%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (9%) | 0.0 (5%) | 0.2 (10%) | 1.1 (19%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (8%) | 0.0 (0%) | 0.2 (10%) | 0.1 (2%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.2 (3%) | 0.1 (8%) | 0.7 (7%) |
| GONE: slain | 0.3 (17%) | 0.0 (0%) | 0.3 (11%) | 0.4 (7%) | 0.3 (21%) | 1.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (11%) | 0.2 (27%) | 0.2 (10%) | 0.3 (5%) | 0.0 (0%) | 0.6 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.2 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (52%) | 0.0 (5%) | 1.2 (48%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.9 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 60% (9 of 15) | 60% (6 of 10) | 60% (15 of 25) |
| the unit moved after it | 100% (9 of 9) | 83% (5 of 6) | 93% (14 of 15) |
| it charged on its next turn | 0% (0 of 9) | 0% (0 of 6) | 0% (0 of 15) |
| the enemy charged it first | 0% (0 of 9) | 0% (0 of 6) | 0% (0 of 15) |
| it fought by the end of its next turn | 0% (0 of 9) | 0% (0 of 6) | 0% (0 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 33% (3 of 9) | 0% (0 of 6) | 20% (3 of 15) |
| none of these (no charge, no fight, no charge escaped) | 67% (6 of 9) | 100% (6 of 6) | 80% (12 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (156 of 239) | 39% (43 of 109) | 57% (199 of 348) |
|   cavalry | 66% (19 of 29) | 20% (5 of 25) | 44% (24 of 54) |
|   character | 46% (18 of 39) | 32% (8 of 25) | 41% (26 of 64) |
|   chariot | 30% (7 of 23) | 0% (0 of 1) | 29% (7 of 24) |
|   infantry | 73% (30 of 41) | 49% (27 of 55) | 59% (57 of 96) |
|   monster | 25% (1 of 4) | - | 25% (1 of 4) |
|   war machine | 79% (81 of 103) | 100% (3 of 3) | 79% (84 of 106) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.8 (30%) | 0.7 (32%) | 1.4 (31%) |
| CHARGED: it charged | 0.3 (12%) | 0.3 (17%) | 0.7 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (1%) | 0.1 (3%) | 0.1 (2%) |
| IN COMBAT: it fought this turn or the last | 0.2 (7%) | 0.1 (6%) | 0.3 (7%) |
| MOVED: a war machine that moved | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) |
| NO TARGET IN RANGE | 0.3 (12%) | 0.4 (18%) | 0.7 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (1%) | 0.1 (5%) | 0.1 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (27%) | 0.3 (14%) | 1.0 (21%) |
| SHELTERED: the target was sheltered | 0.1 (5%) | 0.1 (5%) | 0.2 (5%) |
| STUPIDITY | 0.0 (0%) | 0.0 (2%) | 0.0 (1%) |
| OTHER BAR | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.1 | 0.3 | 76% | 10.3 pts | 11 pts |
| character | 0.9 | 0.3 | 77% | 8.2 pts | 8 pts |
| chariot | 0.2 | 0.1 | 57% | 7.7 pts | 2 pts |
| infantry | 3.1 | 0.9 | 76% | 8.4 pts | 26 pts |
| monster | 0.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 2.6 | 2.4 | 55% | 28.9 pts | 76 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 2.4 | 2.3 |
| Charges that made contact a game | 1.8 | 1.9 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.37 declared, 0.26 contact (19 units) | 0.56 declared, 0.44 contact (18 units) | 0.46 declared, 0.35 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 0.33 declared, 0.33 contact (9 units) | 0.31 declared, 0.31 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.21 contact (243 units) | 0.25 declared, 0.19 contact (259 units) | 0.25 declared, 0.20 contact (502 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (8 of 13) | 80% (4 of 5) | 50% (1 of 2) | 65% (13 of 20) |
| Character in a unit | 75% (9 of 12) | 33% (1 of 3) | 100% (1 of 1) | 69% (11 of 16) |
| Character on its own | 88% (7 of 8) | 58% (7 of 12) | 11% (2 of 18) | 42% (16 of 38) |
| Chariot | 100% (2 of 2) | 67% (2 of 3) | - | 80% (4 of 5) |
| Infantry | 35% (6 of 17) | 27% (4 of 15) | 50% (1 of 2) | 32% (11 of 34) |
| Monster | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monstrous | 67% (2 of 3) | 60% (3 of 5) | - | 62% (5 of 8) |
| War Machines | 40% (4 of 10) | - | - | 40% (4 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 10% | 33% (2 of 6) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game |
| Chaos Dwarfs | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 13% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (2 of 2); on the table 100% | - | 71% | 59% (10 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 51% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Grand Cathay | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 18) | 34% | 33% (3 of 9) | 100% (3 of 3); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| High Elf Realms | 2 | 91% (10 of 11); on the table 91% | 17% (2 of 12) | 33% | 43% (6 of 14) | 75% (3 of 4); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 64% (7 of 11); on the table 64% | - | 27% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 17% (2 of 12) | 2% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 50% (3 of 6) | 56% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 21% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (8 of 8); on the table 100% | - | 13% | 33% (5 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | - | 0% (0 of 6) | 57% | 75% (15 of 20) | 75% (3 of 4); 5.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ff-on-101d908-p3, 32 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (16) | 41% (13) | 43% (29) |
| ...free all their last turn and able to turn (per game) | 0.28 | 0.22 | 0.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.12 | 0.06 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.19 | 0.12 | 0.31 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.97 | 0.59 | 1.56 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.56 | 0.50 | 1.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 3.50 | 2.59 | 6.09 |

### Quality by phase: ff-on-101d908-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.9 |
| Strategy | Charge objectives carried out (made contact) | 58% (31 of 53) | 43% (26 of 60) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (95 of 209) | 53% (27 of 51) |
| Strategy | Close-in objectives charged next turn | 10% (9 of 93) | 10% (11 of 108) |
| Strategy | Support requests answered (helper made contact too) | 50% (3 of 6) | 33% (4 of 12) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 50% (6 of 12) | 62% (5 of 8) |
| Strategy | Lone characters that fought | 88% (23 of 26) | 90% (18 of 20) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 0.8 | 2.6 |
| Movement | Points that never moved of their own | 398.6 | 125.0 |
| Movement | Fights charged into per game | 3.3 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 25, net -146 | 3 of 21, net +28 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 25, net +128 | 3 of 21, net +71 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 25, net +45 | 0 of 21 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 of 25, net +113 | 4 of 21, net +340 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.4 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (36 of 78) | 30% (14 of 47) |
| Shooting | Points destroyed by shooting units | 34.6 | 6.6 |
| Shooting | War machine shots | 2.5 | 0.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (30 of 81) | 33% (1 of 3) |
| Shooting | Points destroyed by war machines | 42.9 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 22) | 5% (1 of 21) |
| Magic | Wounds caused by magic missiles | 2.5 | 1.3 |
| Magic | Wounds caused by other spells | 0.8 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 16.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.1 / 0.4 / 0.1 | 1.0 / 0.2 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 127.2 | 115.4 |
| Combat | Points run down | 31.8 | 57.9 |
| Combat | Net points per charged fight, damage counted | +47 | +69 |
| Combat | Net per 100 charger points, damage counted | +17.0 | +20.3 |
| Combat | First round won (charged fights) | 67% | 47% |
| Combat | Net points per charged fight | +40 | +69 |
| Combat | Net points per supported fight / lone fight | +131 / +21 | +15 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 30 | 17 of 30 |
| Game | Points lost | 842.3 | 844.9 |
| Game | VP from objectives | 655.6 | 582.2 |
| Game | Lone holders (player turns) | 4.7 | 1.8 |

- Mine won / drew / lost: 5 / 1 / 3 of 9 ended games (of 32); mean margin (Mine - Opponent) +99 VP
- The side that went first won 5 of 8 games with a winner
- Points traded per game (both sides' losses): 1687
- Games not ended: 23 (L0110-1, L0126-1, L0210-1, L0311-1, L0327-1, L0413-1, L0516-1, L0709-1, L0725-1, L0831-1, L0922-1, L1013-1, L1030-1, L1122-1, L1232-1, L1327-1, L1422-1, L1535-1, L1731-1, L1831-1, L2033-1, L2223-1, L2327-1); findings 23, warnings 0

### Opponent rules: ff-on-101d908-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 4.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.5 | +3.5 | 0.0 | 0.0 | 0.4 | +5.3 | 0.0 | 26.0 |
| BEST OVERALL | 0.2 | +11.0 | 0.0 | 0.0 | 0.2 | +20.5 | 0.0 | 0.0 |
| BEST PREY | 2.4 | +240.6 | 41.9 | 29.9 | 2.6 | +163.9 | 62.9 | 13.9 |
| BIG CHARACTER SAFETY | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -0.4 | 0.0 | 14.7 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 6.7 | 0.0 | 0.0 | +0.0 | 9.7 | 0.0 |
| BLOCKED WHEEL | 0.2 | +4.4 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 7.3 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 35.6 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.5 | +88.0 | 175.8 | 28.9 | 0.4 | +23.1 | 0.0 | 3.1 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 8.6 | 0.0 | 0.1 | +0.0 | 13.6 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | -5.4 | 2.5 | 0.0 | 0.1 | +0.0 | 0.0 | 7.4 |
| CAST JOB | 0.5 | +12.3 | 25.8 | 0.0 | 0.2 | +5.9 | 0.0 | 7.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +26.5 | 3.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 7.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +1.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.4 | -24.3 | 1.4 | 0.0 | 0.4 | -36.0 | 11.8 | 2.0 |
| CHARIOT NO STATIC JOB | 0.7 | +0.0 | 0.0 | 2.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 2.7 | 6.9 |
| COMBAT PIVOT | 0.3 | +0.0 | 8.6 | 11.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +52.1 | 0.0 | 0.0 | 0.3 | +27.8 | 7.3 | 7.3 |
| COUNTER-CHARGE COVER | 5.3 | +414.4 | 0.0 | 37.3 | 3.8 | +380.2 | 0.0 | 34.7 |
| EDGE GIVE GROUND | 0.2 | +7.3 | 10.5 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.0 | +52.8 | 0.0 | 25.4 | 0.6 | +50.7 | 0.0 | 0.0 |
| FALLBACK BY WORTH | 3.8 | +52.7 | 0.0 | 29.2 | 3.6 | +91.5 | 0.0 | 21.8 |
| FIGHT LIFT | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 3.5 | +0.0 | 0.0 | 24.8 | 2.7 | +0.0 | 0.0 | 38.0 |
| FOCUS FIRE | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.3 | +48.3 | 0.0 | 20.5 | 0.6 | +95.1 | 0.0 | 8.6 |
| FRIENDS SHOTS CHECKED | 0.1 | +3.8 | 0.0 | 13.6 | 0.1 | +1.0 | 0.0 | 12.3 |
| GIVES UP | 0.5 | -10.2 | 27.1 | 31.0 | 0.7 | -21.3 | 66.4 | 30.6 |
| GIVES UP ITS SCREEN | 0.4 | -5.5 | 17.7 | 9.8 | 0.5 | -16.1 | 15.3 | 2.5 |
| GROUND FLIERS | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.0 | +0.0 | 7.3 | 1.9 | 0.2 | +0.0 | 2.7 | 8.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +10.4 | 0.0 | 0.0 | 0.0 | +5.0 | 0.0 | 3.6 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.1 | +1.9 | 0.0 | 0.0 | 0.4 | +49.1 | 0.0 | 0.0 |
| HUNT KEPT | 0.1 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 4.1 | 0.0 |
| HUNT THE GUNS | 0.1 | +49.2 | 0.0 | 0.0 | 0.0 | +18.2 | 0.0 | 3.6 |
| JOINT CHARGE PLAN | 0.1 | +0.8 | 0.0 | 0.0 | 0.2 | +3.5 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 0.9 | +26.2 | 16.8 | 31.7 | 0.8 | +24.4 | 57.3 | 25.1 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.6 | +39.9 | 22.4 | 11.1 | 0.9 | +46.7 | 57.2 | 33.9 |
| KILLS COUNT NEXT TURN | 5.2 | +182.0 | 79.3 | 42.3 | 6.3 | +256.5 | 115.7 | 38.1 |
| LONE CHARACTER SAFE SPOT | 0.3 | +21.1 | 0.0 | 0.0 | 0.3 | +5.9 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 43.8 | 25.4 | 1.2 | +0.0 | 3.6 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +42.0 | 0.0 | 0.0 | 0.4 | +24.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +50.1 | 40.1 | 25.4 | 0.7 | +38.6 | 0.0 | 0.0 |
| MANOEUVRE | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +25.8 | 0.0 | 2.5 | 0.8 | +49.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +16.8 | 3.4 | 0.0 | 0.6 | +35.0 | 3.6 | 3.2 |
| MARCH OVER CASTS | 0.4 | +22.0 | 0.0 | 0.0 | 0.2 | +15.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.8 | +108.0 | 0.0 | 4.5 | 3.0 | +143.9 | 0.0 | 26.0 |
| MISSILES IN THE MOVE | 2.6 | +62.4 | 0.0 | 27.1 | 2.4 | +32.4 | 0.0 | 41.8 |
| MISSILES NEXT TURN | 3.8 | +53.3 | 0.0 | 27.1 | 3.3 | +31.1 | 0.0 | 29.4 |
| MODEL FACING | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.3 | +24.4 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 7.3 |
| MOVE SPELL IN RANGE | 0.1 | +2.5 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 7.3 |
| MOVE SPELL OUT OF RANGE | 0.1 | -2.6 | 0.0 | 0.0 | 0.1 | -1.0 | 3.2 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +4.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.0 | -1.7 | 8.7 | 0.0 | 0.1 | -9.6 | 11.8 | 0.0 |
| NOT TURNED | 3.5 | +47.8 | 0.0 | 25.9 | 2.6 | +38.5 | 0.0 | 53.7 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 10.0 | -550.4 | 14.5 | 53.9 | 7.8 | -410.0 | 0.0 | 67.8 |
| OPENS A LANE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +8.6 | 5.6 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +9.6 | 8.4 | 17.8 | 0.3 | +7.2 | 39.2 | 38.1 |
| PATHS CROSS | 1.6 | +74.6 | 0.0 | 9.7 | 1.7 | +130.3 | 0.0 | 22.5 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.2 | 0.0 | 0.0 | 0.1 | -1.5 | 0.0 | 4.3 |
| PLAN LEADS | 1.1 | +91.5 | 11.8 | 13.2 | 0.7 | +53.4 | 0.0 | 0.0 |
| PLAN RESULT | 18.9 | +696.5 | 414.4 | 344.4 | 16.6 | +562.0 | 344.2 | 300.0 |
| PURSUES BIG PREY | 0.0 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 1.7 |
| REDIRECT COUNTER | 1.9 | +102.9 | 0.0 | 15.6 | 1.6 | +132.3 | 0.0 | 18.4 |
| REDIRECT WEIGHED | 0.2 | +7.8 | 3.2 | 7.3 | 0.2 | +0.0 | 0.0 | 16.0 |
| RESTRAINS TO SHOOT | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.1 | +52.1 | 73.7 | 31.9 | 1.4 | +10.7 | 100.3 | 63.7 |
| SAFER THAN THE JOB | 0.6 | +36.6 | 0.0 | 0.0 | 0.5 | +23.6 | 0.0 | 14.7 |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.8 | +44.7 | 0.0 | 0.0 | 0.9 | +74.9 | 0.0 | 19.8 |
| SECOND HUNTER | 0.1 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +59.4 | 0.0 | 10.2 | 0.3 | +73.9 | 0.0 | 24.7 |
| SET UP TOGETHER | 0.9 | +67.4 | 40.1 | 25.4 | 0.9 | +73.3 | 7.8 | 2.0 |
| SET-UP ANY TARGET | 0.2 | +57.5 | 0.0 | 0.0 | 0.2 | +21.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +6.7 | 0.0 | 0.0 | 0.0 | +4.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.4 | +0.0 | 36.0 | 3.6 | 0.1 | +0.0 | 4.1 | 0.0 |
| SHOTS IN THE MOVE | 8.2 | +343.6 | 0.0 | 43.5 | 3.5 | +108.7 | 0.0 | 22.2 |
| SPELL SETS UP CHARGE | 0.2 | +57.5 | 0.0 | 0.0 | 0.2 | +21.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +12.3 | 29.8 | 29.8 | 1.4 | +26.4 | 6.7 | 0.0 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.2 | +5.1 | 0.0 | 7.8 | 0.2 | +4.2 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.9 | 7.3 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.2 | -3.0 | 0.0 | 0.0 | 0.4 | +3.1 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.4 | +13.9 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 6.7 |
| TURN WORTH | 0.2 | -15.9 | 8.9 | 0.0 | 0.1 | -1.5 | 2.7 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.5 | 6.7 | 0.0 | 0.3 | +6.0 | 7.8 | 2.0 |
| WEARS DOWN | 0.4 | +20.4 | 21.5 | 43.0 | 0.5 | +19.2 | 67.7 | 28.5 |
| WHO HITS BACK | 0.1 | +16.9 | 0.0 | 0.0 | 0.2 | +12.9 | 0.0 | 14.5 |
| WHOLE FIGHT | 0.1 | -0.7 | 15.0 | 0.0 | 0.2 | +22.4 | 47.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +11.0 | 20.3 | 3.6 | 0.3 | +16.0 | 10.9 | 2.5 |

### Rule changes: ff-on-101d908-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 569 | 569 | 569 | 17.78 | -30733 | -54.0 |
| PATHS CROSS | 104 | 104 | 104 | 3.25 | +6558 | +63.1 |
| KILLS COUNT NEXT TURN | 369 | 368 | 96 | 3.00 | +2787 | +29.0 |
| BEST PREY | 161 | 161 | 72 | 2.25 | +4133 | +57.4 |
| COUNTER-CHARGE COVER | 294 | 143 | 62 | 1.94 | +4352 | +70.2 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.75 | +0 | +0.0 |
| SEARCH SPOT | 56 | 56 | 56 | 1.75 | +3829 | +68.4 |
| FALLBACK BY WORTH | 237 | 237 | 55 | 1.72 | +4613 | +83.9 |
| FACES THE THREAT | 50 | 50 | 50 | 1.56 | +3313 | +66.3 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 1.34 | +0 | +0.0 |
| MARCH CHECK | 51 | 47 | 41 | 1.28 | +2406 | +58.7 |
| MAX FOR POSITIONING | 186 | 94 | 35 | 1.09 | +408 | +11.6 |
| HOLDS AMBUSHERS | 34 | 34 | 34 | 1.06 | +0 | +0.0 |
| SAFER THAN THE JOB | 34 | 34 | 34 | 1.06 | +1928 | +56.7 |
| SHOTS IN THE MOVE | 374 | 250 | 33 | 1.03 | +771 | +23.4 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 1.00 | +2140 | +66.9 |
| FOLLOW UP WEIGHED | 28 | 28 | 28 | 0.88 | +4591 | +164.0 |
| MARCH ODDS | 30 | 30 | 28 | 0.88 | +281 | +10.0 |
| PLAN LEADS | 56 | 56 | 28 | 0.88 | +1837 | +65.6 |
| ADVANCE LANE KEPT | 26 | 26 | 26 | 0.81 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 26 | 26 | 26 | 0.81 | +2404 | +92.5 |
| LONE WIZARD HOLDS BACK | 61 | 61 | 25 | 0.78 | -2209 | -88.3 |
| SCOUT WAITS | 25 | 25 | 25 | 0.78 | +0 | +0.0 |
| RISK BY ARC | 80 | 76 | 24 | 0.75 | +780 | +32.5 |
| CANNON PLANNED TARGET | 126 | 126 | 20 | 0.62 | -287 | -14.3 |
| CHARIOT NO STATIC JOB | 26 | 26 | 20 | 0.62 | -1652 | -82.6 |
| COMBAT PIVOT | 19 | 19 | 19 | 0.59 | +0 | +0.0 |
| KILLS COUNT | 48 | 48 | 18 | 0.56 | +772 | +42.9 |
| SET UP TOGETHER | 58 | 47 | 18 | 0.56 | +1629 | +90.5 |
| MISSILES IN THE MOVE | 160 | 82 | 17 | 0.53 | +294 | +17.3 |
| REDIRECT COUNTER | 111 | 43 | 17 | 0.53 | +1125 | +66.2 |
| SHOT REPLANNED | 17 | 17 | 17 | 0.53 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.50 | +27 | +1.7 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.47 | +459 | +30.6 |
| CAST JOB | 25 | 24 | 14 | 0.44 | +216 | +15.4 |
| BEST OVERALL | 13 | 13 | 13 | 0.41 | +1009 | +77.6 |
| MOVE AND CAST | 13 | 13 | 13 | 0.41 | +830 | +63.8 |
| STOPS SHORT OF THE FLANK | 13 | 13 | 13 | 0.41 | +296 | +22.8 |
| REDIRECT WEIGHED | 12 | 12 | 12 | 0.38 | +799 | +66.6 |
| CASTING BLOCK | 16 | 16 | 11 | 0.34 | +220 | +20.0 |
| MAKE SURE TOGETHER | 45 | 31 | 11 | 0.34 | +706 | +64.2 |
| KEEPS ITS TARGET | 54 | 54 | 10 | 0.31 | +201 | +20.1 |
| WEARS DOWN | 31 | 28 | 10 | 0.31 | +106 | +10.6 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.28 | +0 | +0.0 |
| WHO HITS BACK | 9 | 9 | 9 | 0.28 | +644 | +71.6 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.25 | -21 | -2.6 |
| BLOCKED WHEEL | 8 | 8 | 8 | 0.25 | +190 | +23.8 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.25 | +0 | +0.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.25 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.22 | +141 | +20.1 |
| WHOLE FIGHT GAIN | 13 | 13 | 6 | 0.19 | +85 | +14.1 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.16 | +154 | +30.7 |
| MANOEUVRE | 5 | 5 | 5 | 0.16 | +76 | +15.3 |
| OVERRUNS AWAY | 24 | 23 | 5 | 0.16 | +88 | +17.5 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.16 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 0.12 | -19 | -4.7 |
| HUNT ADVANCE | 7 | 7 | 4 | 0.12 | +218 | +54.6 |
| HUNT IN PAIRS | 17 | 9 | 4 | 0.12 | +729 | +182.2 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.12 | -85 | -21.4 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.12 | -121 | -30.4 |
| WHOLE FIGHT | 11 | 11 | 4 | 0.12 | +410 | +102.4 |
| KEEP FALLS | 3 | 3 | 3 | 0.09 | +92 | +30.7 |
| OPENS UP | 4 | 3 | 3 | 0.09 | +48 | +16.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| KEEPS ITS PREY | 5 | 5 | 2 | 0.06 | +5 | +2.3 |
| MISSILES NEXT TURN | 230 | 118 | 2 | 0.06 | +24 | +11.8 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +4 | +2.0 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +29 | +14.7 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +19 | +9.3 |
| SURE REACH TOGETHER | 21 | 18 | 2 | 0.06 | +10 | +4.9 |
| BACKUP TARGETS | 30 | 17 | 1 | 0.03 | +2 | +1.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -172 | -172.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -27 | -27.1 |
| EDGE GIVE GROUND | 6 | 6 | 1 | 0.03 | +4 | +4.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +8 | +7.9 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +6 | +6.5 |
| GIVES UP | 36 | 35 | 1 | 0.03 | +21 | +21.4 |
| GIVES UP ITS SCREEN | 29 | 29 | 1 | 0.03 | +13 | +13.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +41 | +41.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MODEL FACING | 1 | 1 | 1 | 0.03 | +105 | +105.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +106 | +105.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -195 | -195.1 |
| TWO OR MORE ARRIVE | 18 | 18 | 1 | 0.03 | +4 | +4.4 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 21 | 21 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 21 | trace | - | - | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 196 | not checked | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 20 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 4 | 4 | 0 | 0.00 | - | - |
| NOT TURNED | 195 | 195 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 15 | not checked | - | - | - | - |
| OPENS A LANE | 4 | not checked | - | - | - | - |
| PLAN RESULT | 1135 | trace | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 59 | not checked | - | - | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 8 | 7 | 0 | 0.00 | - | - |

### Off best figure: ff-on-101d908-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 9.03 | 6.78 | 54.3 |
| FALLBACK | gate | 0.44 | 0.56 | 56.7 |
| CHARIOT NO STATIC JOB | rule | 0.50 | 0.12 | 82.6 |
| LONE WIZARD HOLDS BACK | rule | 0.25 | 0.38 | 110.4 |
| TURN GATE | gate | 0.25 | 0.12 | 24.7 |
| PATHS CROSS | rule | 0.19 | 0.12 | 35.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.09 | 0.16 | 85.4 |
| SUPPORT REQUEST | gate | 0.03 | 0.12 | 79.2 |
| CANNON PLANNED TARGET | rule | 0.12 | - | 74.6 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 4.7 |
| MARCH ODDS | rule | 0.03 | 0.09 | 28.4 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 21.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 30.3 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.06 | 11.8 |
| AFTERMATH BAND | gate | 0.06 | - | 2.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 26.1 |
| STAYS FIRST | gate | 0.03 | 0.03 | 4.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 12.8 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 30.6 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 172.1 |
| CATCH ODDS | rule | - | 0.03 | 27.1 |
| CHARGE NOW WEIGHED | rule | 0.03 | - | 5.8 |
| PURSUES BIG PREY | rule | 0.03 | - | 195.1 |
| SAFER THAN THE JOB | rule | - | 0.03 | 9.8 |

### Plans: ff-on-101d908-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 6.2 | 18% | 249 | 171 | 69% |
| Mine | charge | 1.3 | 53% | 117 | 108 | 92% |
| Mine | close in | 2.3 | 29% | 169 | 96 | 57% |
| Mine | hold | 1.8 | 49% | 128 | 0 | 0% |
| Mine | join | 0.4 | 93% | 14 | 0 | 0% |
| Mine | shoot | 4.8 | 69% | 142 | 322 | 227% |
| Mine | support | 1.9 | 82% | 96 | 0 | 0% |
| Opponent | advance | 6.6 | 16% | 318 | 245 | 77% |
| Opponent | charge | 1.5 | 65% | 191 | 196 | 102% |
| Opponent | close in | 2.5 | 24% | 202 | 61 | 30% |
| Opponent | hold | 1.6 | 34% | 153 | 0 | 0% |
| Opponent | join | 0.4 | 93% | 17 | 0 | 0% |
| Opponent | shoot | 1.1 | 60% | 36 | 61 | 168% |
| Opponent | support | 2.9 | 84% | 122 | 0 | 0% |

### Packages: hunt the guns, ff-on-101d908-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 0% | 0% | 0% | - | 375 | 0 | 0% | 0 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 219 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 584 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 188 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 180 |

### Battle groups: ff-on-101d908-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 5.3 | 20% | 43% | 9% | 67% | 38% | 3% | 12% | 47% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 17% | 70% | 10% | 100% | 22% | 0% | 0% | 67% | 11% |
| Opponent | COUNTER-CHARGE COVER | 3.8 | 17% | 52% | 33% | 57% | 64% | 0% | 0% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 1.6 | 31% | 69% | 12% | 0% | 43% | 0% | 21% | 29% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-on-101d908-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 10 | 50 (10) | 24 | 26 | 78 | 40% | 2.3 | 62 (5) | 0 (1) | 51 (4) | 46 (8) | 65 (2) |
| Mine | Character | 32 | 53 (32) | 53 | 0 | 48 | 12% | 2.6 | 32 (13) | 69 (17) | - | 59 (17) | 52 (13) |
| Mine | Clean-up | 2 | 110 (2) | 0 | 110 | 0 | 50% | 1.0 | 161 (1) | 84 (1) | - | 110 (2) | - |
| Mine | Fast Hammer | 10 | 9 (10) | 6 | 4 | 51 | 10% | 3.3 | 12 (4) | 0 (2) | 13 (4) | 9 (6) | 9 (4) |
| Mine | Hammer | 15 | 54 (15) | 42 | 12 | 58 | 0% | 3.7 | 10 (5) | 76 (9) | 0 (1) | 20 (10) | 110 (5) |
| Mine | Holder | 5 | 219 (5) | 92 | 127 | 0 | 40% | 5.0 | 218 (1) | 282 (2) | 118 (2) | 380 (2) | 70 (3) |
| Mine | Shooter | 11 | 48 (11) | 23 | 26 | 31 | 0% | 2.0 | 48 (3) | 55 (7) | 0 (1) | 57 (8) | 26 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 19 | 92 (19) | 92 | 0 | 35 | 0% | 1.4 | 237 (5) | 39 (14) | - | 132 (7) | 69 (12) |
| Mine | Wizard | 6 | 4 (6) | 4 | 0 | 77 | 0% | 1.8 | 0 (1) | 10 (3) | - | - | 5 (4) |
| Opponent | Chaff | 21 | 8 (21) | 8 | 0 | 62 | 48% | 3.1 | 16 (10) | 0 (2) | 0 (9) | 8 (19) | 0 (2) |
| Opponent | Character | 22 | 75 (22) | 75 | 0 | 58 | 5% | 2.2 | 91 (7) | 78 (10) | 64 (1) | 68 (10) | 100 (8) |
| Opponent | Clean-up | 1 | 89 (1) | 0 | 89 | 0 | 0% | 3.0 | - | 89 (1) | - | - | 89 (1) |
| Opponent | Fast Hammer | 12 | 32 (12) | 31 | 1 | 50 | 33% | 2.9 | 45 (6) | 9 (3) | 12 (3) | 46 (7) | 7 (5) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 15 | 42 (15) | 35 | 8 | 28 | 40% | 3.4 | 0 (3) | 56 (9) | 23 (3) | 8 (7) | 77 (8) |
| Opponent | Holder | 7 | 90 (7) | 0 | 90 | 23 | 71% | 2.5 | 0 (1) | 100 (5) | 65 (1) | 91 (5) | 88 (2) |
| Opponent | Shooter | 6 | 23 (6) | 18 | 5 | 20 | 0% | 1.8 | 32 (2) | 18 (4) | - | 25 (4) | 18 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 100 | 50% | 1.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Wizard | 6 | 17 (6) | 17 | 0 | 36 | 0% | 1.5 | 14 (3) | 0 (1) | 48 (1) | 34 (3) | 0 (2) |

### Charged fights: ff-on-101d908-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 45 | 1.0 | 2.0 | 45 | 0 | +45 | 0 of 1 | 1 of 1 | +45 | - |
| Mine | Chaos Dwarfs | 1 | 0 | 960 | 7.0 | 1.1 | 137 | 44 | +93 | 3 of 7 | 5 of 7 | +465 | +31 |
| Mine | Dwarfen Mountain Holds | 2 | 431 | 32 | 3.0 | 1.0 | 11 | 41 | -30 | 2 of 6 | 5 of 6 | - | -30 |
| Mine | Empire of Man | 1 | 1167 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 377 | 294 | 5.0 | 1.2 | 59 | 0 | +59 | 2 of 5 | 3 of 5 | +0 | +74 |
| Mine | High Elf Realms | 1 | 55 | 926 | 3.0 | 1.7 | 309 | 219 | +90 | 2 of 3 | 2 of 3 | +0 | +134 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 104 | 3.0 | 1.0 | 35 | 92 | -57 | 0 of 3 | 1 of 3 | - | -57 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 337 | 5.0 | 1.2 | 67 | 11 | +56 | 1 of 5 | 3 of 5 | +145 | +34 |
| **Mine** | all armies | 9 | 276 | 303 | 3.3 | 1.2 | 91 | 51 | +40 | 10 of 30 | 20 of 30 | +131 | +21 |
| Opponent | High Elf Realms | 1 | 300 | 995 | 2.0 | 1.0 | 498 | 0 | +498 | 2 of 2 | 2 of 2 | - | +498 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 813 | 4.0 | 1.2 | 203 | 186 | +17 | 2 of 4 | 2 of 4 | +813 | -249 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 302 | 4.0 | 1.2 | 76 | 14 | +62 | 2 of 4 | 1 of 4 | -55 | +101 |
| Opponent | Skaven | 1 | 275 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 81 | 307 | 6.0 | 1.5 | 51 | 163 | -112 | 2 of 6 | 3 of 6 | -228 | +4 |
| Opponent | Warriors of Chaos | 2 | 0 | 1082 | 5.0 | 1.0 | 216 | 0 | +216 | 7 of 10 | 5 of 10 | - | +216 |
| Opponent | Wood Elf Realms | 2 | 40 | 0 | 1.5 | 1.0 | 0 | 247 | -247 | 2 of 3 | 1 of 3 | - | -247 |
| **Opponent** | all armies | 9 | 82 | 509 | 3.3 | 1.2 | 153 | 84 | +69 | 17 of 30 | 14 of 30 | +15 | +79 |

### Effective charges: ff-on-101d908-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 7 | 2 (net -155) | 0 | 2 (net +335) | 2 (net +42) | 0 | 1 (net +205) | 0 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 2 (net -123) | 2 (net +32) | 0 | 1 (net +0) | 1 | 40% (2 of 5) |
| Mine | Grand Cathay | 5 | 1 (net +0) | 0 | 1 (net +214) | 0 | 0 | 3 (net +27) | 0 | 20% (1 of 5) |
| Mine | High Elf Realms | 3 | 0 | 0 | 0 | 1 (net -318) | 0 | 2 (net +294) | 0 | 0% (0 of 3) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net -275) | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 2 (net +72) | 3 | 0% (0 of 2) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 2 (net +498) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +406) | 1 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 6 | 1 (net +85) | 1 (net -939) | 0 | 2 (net +85) | 0 | 0 | 2 | 0% (0 of 4) |
| Opponent | Warriors of Chaos | 10 | 1 (net +0) | 0 | 2 (net +360) | 4 (net +225) | 0 | 2 (net +272) | 1 | 22% (2 of 9) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 1 (net -505) | 0 | 0 | 0 | 2 | 100% (1 of 1) |

### Charged fights, damage counted: ff-on-101d908-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 285 | 370 | -146 | 7 | 179 | -171 | -60.1 |
| Mine | Effective (55-75%) | 5 | 258 | 333 | +128 | 199 | 60 | +139 | +53.8 |
| Mine | 76-89% | 6 | 235 | 170 | -28 | 100 | 147 | -47 | -20.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 353 | 182 | +113 | 168 | 17 | +150 | +42.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 137 | 45 | +45 | 45 | 0 | +45 | +32.8 |
| Mine | No odds | 5 | 215 | 183 | +48 | 55 | 0 | +55 | +25.4 |
| Mine | All fights | 30 | 274 | 225 | +40 | 115 | 68 | +47 | +17.0 |
| Opponent | Long shot (under 50%) | 3 | 235 | 276 | +28 | 60 | 33 | +27 | +11.5 |
| Opponent | 50-54% | 1 | 610 | 272 | -939 | 0 | 939 | -939 | -153.9 |
| Opponent | Effective (55-75%) | 3 | 328 | 406 | +71 | 306 | 205 | +101 | +30.9 |
| Opponent | 76-89% | 10 | 346 | 211 | +207 | 214 | 23 | +191 | +55.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 490 | 320 | +340 | 368 | 4 | +364 | +74.3 |
| Opponent | No odds | 9 | 273 | 215 | -80 | 41 | 125 | -84 | -30.7 |
| Opponent | All fights | 30 | 339 | 255 | +69 | 169 | 101 | +69 | +20.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-on-101d908-p3 | move | 264 | 43 (16%) | 33 (12%) | 23 (9%) | 198 (75%) |
| ff-on-101d908-p3 | objective | 201 | 20 (10%) | 16 (8%) | 19 (9%) | 162 (81%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

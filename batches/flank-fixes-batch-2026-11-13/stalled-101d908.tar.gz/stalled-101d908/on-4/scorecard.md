# Doctrine scorecard: ff-on-101d908-p4

### Scorecard: ff-on-101d908-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 11 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0130 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0214 | 4 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 9 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0230 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0315 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0315 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0332 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0332 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0417 | 3 | 1 | Mine | yes | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0434 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0520 | 4 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0520 | 4 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 2 | 4 | 5 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0713 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0729 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0729 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0819 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0819 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0926 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1017 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1017 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1034 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1034 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 11 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1220 | 2 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1314 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1314 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1523 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1621 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1621 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1719 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1719 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1819 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1819 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1835 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1835 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2123 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 1 | 0 | 0 | 60 |
| **Average** | | | Mine | 60% | 3.6 | 3.1 | 2.7 | 0.8 | 0.2 | 0.0 | 0.0 | 268.6 |
| **Average** | | | Opponent | 40% | 3.4 | 2.3 | 2.8 | 1.8 | 0.3 | 0.0 | 0.0 | 100.3 |

### KPIs: ff-on-101d908-p4

Morten 2026-11-10; 31 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 96% (25 of 26); on the table 100% | 100% (33 of 33); on the table 100% | 98% (58 of 59); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 67% (4 of 6); on the table 83% | 60% (6 of 10); on the table 70% | 62% (10 of 16); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 91% (30 of 33); on the table 97% | 91% (41 of 45); on the table 93% | 91% (71 of 78); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 24% (33 of 136) | 33% (32 of 98) | 28% (65 of 234) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (33 of 97) | 42% (30 of 71) | 38% (63 of 168) |
| Points that never fought | lower | 33% (6848 of 20747) | 38% (8429 of 21997) | 36% (15277 of 42744) |
|   infantry points that never fought | lower | 39% (2169 of 5580) | 75% (3073 of 4088) | 54% (5242 of 9668) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (49 of 83) | 52% (48 of 92) | 55% (97 of 175) |
| Bound items with a magic missile used (at least once a game) |  | 64% (14 of 22); 1.0 uses a game | 75% (6 of 8); 0.5 uses a game | 67% (20 of 30); 0.7 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.5 uses a game | 35% (7 of 20); 0.4 uses a game | 39% (14 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.3 uses a game | 33% (4 of 12); 0.1 uses a game | 42% (13 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (8780 of 17141) | 43% (8530 of 19755) | 47% (17310 of 36896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (22%) | 0.6 (33%) | 1.4 (27%) |
| MARCHED: its unit marched | 1.1 (35%) | 0.5 (27%) | 1.6 (32%) |
| CHARGED: its unit charged | 0.2 (7%) | 0.1 (3%) | 0.3 (6%) |
| IN COMBAT: engaged in combat | 0.6 (20%) | 0.4 (20%) | 1.0 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.2 (3%) |
| GONE: slain | 0.0 (1%) | 0.2 (12%) | 0.3 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.0 (0%) | 0.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.1 | 1.0 | 1.0 | 2.1 | 0.1 | 1.1 |
| not cast | 1.3 | 1.9 | 1.7 | 5.1 | 1.1 | 12.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (61%) | 0.2 (10%) | 1.4 (27%) | 0.3 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (32%) | 0.4 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (2%) | 0.2 (8%) | 0.5 (27%) | 1.0 (20%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (8%) | 0.1 (5%) | 0.1 (8%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.1 (3%) | 0.0 (2%) | 0.2 (3%) | 0.1 (9%) | 0.6 (5%) |
| GONE: slain | 0.4 (30%) | 0.1 (5%) | 0.0 (2%) | 0.3 (5%) | 0.1 (6%) | 0.7 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (8%) | 0.1 (4%) | 0.3 (5%) | 0.1 (6%) | 0.4 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.1 (6%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (55%) | 0.1 (7%) | 0.8 (48%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.5 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.3 a game | 0.6 a game |
| stood (cast and not dispelled) | 60% (15 of 25) | 67% (4 of 6) | 61% (19 of 31) |
| the unit moved after it | 80% (12 of 15) | 50% (2 of 4) | 74% (14 of 19) |
| it charged on its next turn | 13% (2 of 15) | 0% (0 of 4) | 11% (2 of 19) |
| the enemy charged it first | 33% (5 of 15) | 0% (0 of 4) | 26% (5 of 19) |
| it fought by the end of its next turn | 27% (4 of 15) | 0% (0 of 4) | 21% (4 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 4) | 0% (0 of 19) |
| none of these (no charge, no fight, no charge escaped) | 47% (7 of 15) | 100% (4 of 4) | 58% (11 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (179 of 296) | 58% (92 of 160) | 59% (271 of 456) |
|   cavalry | 52% (17 of 33) | 68% (26 of 38) | 61% (43 of 71) |
|   character | 15% (4 of 27) | 6% (1 of 18) | 11% (5 of 45) |
|   chariot | 35% (8 of 23) | 80% (12 of 15) | 53% (20 of 38) |
|   infantry | 63% (67 of 107) | 70% (38 of 54) | 65% (105 of 161) |
|   monster | 100% (4 of 4) | 14% (2 of 14) | 33% (6 of 18) |
|   war machine | 77% (79 of 102) | 62% (13 of 21) | 75% (92 of 123) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (26%) | 0.5 (24%) | 1.5 (25%) |
| CHARGED: it charged | 0.6 (15%) | 0.4 (16%) | 0.9 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (11%) | 0.1 (4%) | 0.5 (9%) |
| NO TARGET IN RANGE | 0.7 (20%) | 0.5 (21%) | 1.2 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (5%) | 0.1 (6%) | 0.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.6 (15%) | 0.6 (26%) | 1.2 (19%) |
| SHELTERED: the target was sheltered | 0.2 (4%) | 0.0 (0%) | 0.2 (3%) |
| STUPIDITY | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) |
| OTHER BAR | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.5 | 0.9 | 71% | 7.7 pts | 19 pts |
| character | 0.3 | 0.1 | 75% | 8.4 pts | 2 pts |
| chariot | 0.6 | 0.4 | 70% | 6.2 pts | 4 pts |
| infantry | 5.4 | 2.4 | 70% | 9.3 pts | 51 pts |
| monster | 0.2 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.0 | 2.5 | 60% | 21.8 pts | 65 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.9 | 2.7 | 2.3 |
| Charges that made contact a game | 1.4 | 2.1 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (12 units) | 0.73 declared, 0.60 contact (15 units) | 0.63 declared, 0.56 contact (27 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 0.71 declared, 0.57 contact (7 units) | 0.64 declared, 0.55 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.14 contact (258 units) | 0.25 declared, 0.19 contact (270 units) | 0.23 declared, 0.16 contact (528 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (16 of 33) | 50% (2 of 4) | 67% (2 of 3) | 50% (20 of 40) |
| Character in a unit | 82% (9 of 11) | 0% (0 of 3) | 100% (1 of 1) | 67% (10 of 15) |
| Character on its own | 92% (11 of 12) | 14% (1 of 7) | 15% (3 of 20) | 38% (15 of 39) |
| Chariot | 33% (1 of 3) | 50% (2 of 4) | - | 43% (3 of 7) |
| Infantry | 67% (18 of 27) | 44% (4 of 9) | 33% (1 of 3) | 59% (23 of 39) |
| Monster | 73% (8 of 11) | 67% (2 of 3) | - | 71% (10 of 14) |
| Monstrous | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| War Machines | 78% (14 of 18) | - | - | 78% (14 of 18) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 75% (3 of 4); on the table 75% | 31% (17 of 54) | 10% | 27% (3 of 11) | 100% (3 of 3); 3.0 uses a game | 100% (1 of 1); 1.5 uses a game | 67% (2 of 3); 1.0 uses a game |
| Chaos Dwarfs | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 35% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (6 of 6); on the table 100% | - | 64% | 90% (18 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (3 of 3); on the table 100% | - | 58% | 55% (11 of 20) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Grand Cathay | 1 | 100% (6 of 6); on the table 100% | 17% (3 of 18) | 42% | 38% (3 of 8) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 4 | 100% (10 of 10); on the table 100% | 22% (4 of 18) | 26% | 49% (17 of 35) | 100% (1 of 1); 1.2 uses a game | 60% (12 of 20); 6.0 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (7 of 7); on the table 100% | 83% (5 of 6) | 30% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 2 | 60% (3 of 5); on the table 100% | 35% (6 of 17) | 59% | 77% (10 of 13) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (6 of 6); on the table 100% | - | 9% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 95% (20 of 21); on the table 95% | 30% (9 of 30) | 23% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | 50% (3 of 6) | 70% | 83% (10 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 75% | - | 31% | 42% (5 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ff-on-101d908-p4, 31 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (16) | 35% (9) | 40% (25) |
| ...free all their last turn and able to turn (per game) | 0.35 | 0.13 | 0.48 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.03 | 0.06 | 0.10 |
| ...with the charger already in that arc before they moved (per game) | 0.29 | 0.06 | 0.35 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.74 | 0.19 | 0.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.58 | 0.48 | 1.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 2.45 | 2.90 | 5.35 |

### Quality by phase: ff-on-101d908-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.9 | 3.5 |
| Strategy | Charge objectives carried out (made contact) | 45% (22 of 49) | 49% (35 of 72) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (67 of 186) | 38% (29 of 77) |
| Strategy | Close-in objectives charged next turn | 9% (7 of 79) | 9% (9 of 95) |
| Strategy | Support requests answered (helper made contact too) | 75% (3 of 4) | 31% (4 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 43% (3 of 7) | 88% (7 of 8) |
| Strategy | Joined characters whose unit fought | 85% (11 of 13) | 18% (2 of 11) |
| Strategy | Lone characters that fought | 69% (18 of 26) | 79% (23 of 29) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.8 | 1.8 |
| Movement | Points that never moved of their own | 268.6 | 100.3 |
| Movement | Fights charged into per game | 2.5 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 23, net +0 | 7 of 42, net -17 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 23, net +75 | 6 of 42, net +151 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 23, net +44 | 2 of 42, net +32 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 of 23, net +201 | 15 of 42, net +138 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.5 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (46 of 108) | 32% (29 of 92) |
| Shooting | Points destroyed by shooting units | 32.1 | 13.7 |
| Shooting | War machine shots | 2.5 | 0.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (47 of 79) | 62% (8 of 13) |
| Shooting | Points destroyed by war machines | 22.9 | 9.8 |
| Magic | Magic missiles cast | 0.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (9 of 23) | 22% (5 of 23) |
| Magic | Wounds caused by magic missiles | 1.6 | 0.7 |
| Magic | Wounds caused by other spells | 0.6 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 20.5 | 14.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.4 / 0.3 / 0.1 | 1.3 / 0.4 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 139.7 | 149.1 |
| Combat | Points run down | 13.2 | 60.6 |
| Combat | Net points per charged fight, damage counted | +92 | +84 |
| Combat | Net per 100 charger points, damage counted | +35.0 | +28.3 |
| Combat | First round won (charged fights) | 64% | 57% |
| Combat | Net points per charged fight | +92 | +74 |
| Combat | Net points per supported fight / lone fight | +306 / +76 | +84 / +72 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 28 | 25 of 46 |
| Game | Points lost | 812.8 | 716.1 |
| Game | VP from objectives | 456.4 | 681.8 |
| Game | Lone holders (player turns) | 3.6 | 3.4 |

- Mine won / drew / lost: 2 / 3 / 6 of 11 ended games (of 31); mean margin (Mine - Opponent) -355 VP
- The side that went first won 2 of 8 games with a winner
- Points traded per game (both sides' losses): 1529
- Games not ended: 20 (L0130-1, L0230-1, L0315-1, L0332-1, L0434-1, L0520-1, L0713-1, L0729-1, L0819-1, L0926-1, L1017-1, L1034-1, L1220-1, L1314-1, L1523-1, L1621-1, L1719-1, L1819-1, L1835-1, L2123-1); findings 21, warnings 0

### Opponent rules: ff-on-101d908-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| BACKUP TARGETS | 0.6 | +3.6 | 0.0 | 12.7 | 0.9 | +14.8 | 0.0 | 8.9 |
| BEST OVERALL | 0.2 | +8.5 | 0.0 | 8.5 | 0.1 | +2.6 | 0.0 | 1.9 |
| BEST PREY | 2.8 | +173.5 | 45.0 | 37.2 | 3.0 | +209.4 | 34.2 | 46.7 |
| BEST PRIZE | - | - | - | - | 0.1 | +8.3 | 7.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 8.5 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | -0.2 | 0.0 | 0.0 | 0.4 | +1.4 | 0.0 | 10.6 |
| BOMBING RUN | 0.0 | +0.5 | 1.3 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.6 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 15.2 | 3.2 | 0.1 | +0.0 | 15.3 | 0.0 |
| CANNON PLANNED TARGET | 3.2 | +37.3 | 142.5 | 22.3 | 0.3 | +15.4 | 24.4 | 8.1 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 3.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +4.7 | 4.4 | 3.6 | 0.4 | +8.0 | 33.7 | 1.9 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +39.2 | 26.2 | 10.4 | 0.0 | +0.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 33.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 0.0 | 0.1 | -0.3 | 14.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.2 | -12.5 | 8.2 | 0.0 | 0.3 | -24.2 | 0.0 | 0.0 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 27.5 | 11.0 | 0.4 | +0.0 | 0.0 | 2.4 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 21.3 | 3.6 |
| COMBAT PIVOT | 0.3 | +0.0 | 4.5 | 35.5 | 0.2 | +0.0 | 12.9 | 5.6 |
| CONVEYANCE SEARCH | 0.5 | +82.0 | 13.1 | 33.7 | 0.2 | +28.1 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 4.9 | +266.9 | 0.0 | 103.6 | 4.2 | +317.3 | 0.0 | 59.8 |
| EDGE GIVE GROUND | - | - | - | - | 0.0 | +3.7 | 0.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +2.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.7 | +61.7 | 0.0 | 18.5 | 0.2 | +5.8 | 0.0 | 0.0 |
| FALLBACK BY WORTH | 3.9 | +46.8 | 0.0 | 58.9 | 4.1 | +43.3 | 0.0 | 8.1 |
| FIGHT LIFT | 0.2 | +1.0 | 6.6 | 11.5 | - | - | - | - |
| FLANK NOT WEIGHED | 2.6 | +0.0 | 0.0 | 105.4 | 2.8 | +0.0 | 0.0 | 42.3 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +73.4 | 0.0 | 29.6 | 0.7 | +86.5 | 0.0 | 32.1 |
| FRIENDS SHOTS CHECKED | 0.3 | +12.1 | 0.0 | 15.1 | 0.0 | +0.5 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -7.6 | 38.9 | 1.9 | 0.6 | -20.8 | 71.3 | 45.4 |
| GIVES UP ITS SCREEN | 0.4 | -8.7 | 49.4 | 8.9 | 0.5 | -11.8 | 39.6 | 8.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 26.3 | 1.3 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 10.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 6.1 | 0.0 | 0.0 | +2.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +15.5 | 0.0 | 0.0 | 0.4 | +12.4 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.0 | +6.4 | 6.1 | 0.0 | 0.0 | +10.8 | 0.0 | 0.0 |
| JOINT CHARGE PLAN | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 4.0 | 0.0 | 0.2 | +1.9 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 0.8 | +25.2 | 63.3 | 13.7 | 0.9 | +27.1 | 57.7 | 27.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.7 | +27.7 | 92.8 | 6.2 | 1.0 | +50.6 | 113.7 | 24.1 |
| KILLS COUNT NEXT TURN | 4.4 | +212.4 | 81.5 | 134.6 | 6.5 | +410.6 | 84.7 | 66.3 |
| LONE CHARACTER SAFE SPOT | 0.5 | +17.8 | 4.0 | 10.4 | 0.2 | +21.0 | 4.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 31.5 | 7.5 | 1.0 | +0.0 | 13.2 | 30.3 |
| LONE WIZARD KEPT IN | 0.6 | +29.2 | 0.0 | 0.0 | 0.2 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +22.5 | 0.0 | 11.2 | 0.3 | +4.1 | 0.0 | 0.0 |
| MANOEUVRE | 0.1 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH AT ESCAPER | 0.2 | +0.8 | 0.0 | 10.4 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +15.8 | 0.0 | 0.0 | 0.4 | +32.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.4 | +27.6 | 4.4 | 11.1 | 0.3 | +34.2 | 10.0 | 30.3 |
| MARCH OVER CASTS | 0.5 | +39.4 | 0.0 | 17.9 | 0.2 | +19.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.6 | +81.1 | 0.0 | 62.5 | 3.0 | +104.0 | 0.0 | 54.5 |
| MISSILES IN THE MOVE | 1.9 | +51.5 | 0.0 | 14.0 | 1.7 | +31.7 | 0.0 | 17.1 |
| MISSILES NEXT TURN | 2.9 | +44.6 | 0.0 | 31.9 | 2.3 | +24.1 | 0.0 | 17.1 |
| MODEL FACING | 0.2 | +30.3 | 0.0 | 1.9 | - | - | - | - |
| MOVE AND CAST | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +7.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.9 | 0.0 | 11.5 | 0.0 | -1.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.7 | 15.2 | 0.0 | 0.1 | +2.2 | 10.3 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +8.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -4.5 | 34.3 | 8.0 | 0.0 | -0.9 | 0.0 | 0.0 |
| NOT TURNED | 2.5 | +22.3 | 0.0 | 99.5 | 2.9 | +64.6 | 0.0 | 37.9 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 9.0 | -374.3 | 0.0 | 154.6 | 8.7 | -519.9 | 17.1 | 109.7 |
| OPENS A LANE | 0.0 | +0.1 | 4.0 | 0.0 | 0.2 | +2.3 | 9.0 | 0.0 |
| OPENS UP | 0.1 | +1.8 | 3.0 | 7.5 | 0.1 | +9.8 | 2.1 | 0.0 |
| OVERRUNS AWAY | 0.2 | +6.1 | 8.8 | 0.0 | 0.1 | +3.8 | 18.5 | 19.3 |
| PATHS CROSS | 1.3 | +55.8 | 0.0 | 16.0 | 1.9 | +165.6 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.0 | +1.3 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.0 | -0.1 | 0.0 | 2.4 |
| PLAN LEADS | 1.1 | +81.5 | 9.5 | 0.0 | 0.9 | +77.2 | 0.0 | 0.0 |
| PLAN RESULT | 19.4 | +585.6 | 587.2 | 407.1 | 18.6 | +684.8 | 491.6 | 416.7 |
| PURSUES BIG PREY | 0.1 | -5.2 | 0.0 | 0.0 | 0.0 | -5.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.8 | 0.0 | 0.0 | 0.1 | +9.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.8 | +65.5 | 0.0 | 37.1 | 2.2 | +137.2 | 0.0 | 27.7 |
| REDIRECT WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +8.7 | 4.9 | 5.6 |
| RESTRAINS TO SHOOT | 0.0 | +1.1 | 0.0 | 5.3 | - | - | - | - |
| RISK BY ARC | 1.2 | +41.3 | 131.3 | 20.2 | 1.3 | +14.9 | 114.8 | 83.9 |
| SAFER THAN THE JOB | 0.6 | +20.6 | 0.0 | 15.3 | 0.5 | +22.0 | 0.0 | 17.8 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +62.8 | 0.0 | 34.8 | 1.0 | +83.3 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.0 | +3.4 | 0.0 | 0.0 | 0.2 | +10.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +23.0 | 0.0 | 11.2 | 0.4 | +4.9 | 0.0 | 22.6 |
| SET-UP ANY TARGET | 0.3 | +46.3 | 0.0 | 0.0 | 0.1 | +10.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +16.9 | 0.0 | 0.0 | 0.1 | +5.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 3.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 20.6 | 0.0 |
| SHOTS IN THE MOVE | 8.7 | +259.6 | 0.0 | 105.3 | 3.9 | +113.2 | 0.0 | 36.0 |
| SPELL SETS UP CHARGE | 0.3 | +46.3 | 0.0 | 0.0 | 0.1 | +10.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +16.2 | 10.6 | 22.3 | 1.9 | +32.3 | 55.2 | 55.2 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.1 | +4.0 | 0.0 | 0.0 | 0.2 | +11.6 | 0.0 | 4.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 6.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -8.2 | 24.5 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.2 | -0.2 | 0.0 | 11.2 | 0.2 | +2.6 | 0.0 | 3.7 |
| THROUGH LINE OF FIRE | 0.4 | +6.9 | 0.0 | 8.1 | 0.3 | +15.6 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -10.5 | 8.1 | 2.3 | 0.1 | -7.4 | 7.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.5 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| WEARS DOWN | 0.5 | +6.4 | 32.4 | 2.7 | 0.7 | +20.7 | 62.9 | 39.4 |
| WHO HITS BACK | 0.0 | +1.0 | 0.0 | 2.3 | 0.0 | +2.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +5.8 | 0.0 | 6.1 | 0.3 | +10.4 | 17.5 | 9.7 |
| WHOLE FIGHT GAIN | 0.1 | +0.9 | 0.0 | 0.0 | 0.4 | +31.4 | 59.7 | 11.6 |

### Rule changes: ff-on-101d908-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 551 | 551 | 551 | 17.77 | -27722 | -50.3 |
| KILLS COUNT NEXT TURN | 339 | 339 | 118 | 3.81 | +4657 | +39.5 |
| PATHS CROSS | 97 | 97 | 97 | 3.13 | +6864 | +70.8 |
| BEST PREY | 179 | 179 | 73 | 2.35 | +2255 | +30.9 |
| SEARCH SPOT | 63 | 63 | 62 | 2.00 | +4528 | +73.0 |
| COUNTER-CHARGE COVER | 282 | 142 | 57 | 1.84 | +2726 | +47.8 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.55 | +0 | +0.0 |
| FALLBACK BY WORTH | 247 | 247 | 44 | 1.42 | +2793 | +63.5 |
| FOLLOW UP WEIGHED | 39 | 39 | 39 | 1.26 | +4957 | +127.1 |
| ADVANCE LANE KEPT | 33 | 33 | 33 | 1.06 | +0 | +0.0 |
| SAFER THAN THE JOB | 33 | 33 | 33 | 1.06 | +1321 | +40.0 |
| FACES THE THREAT | 29 | 29 | 29 | 0.94 | +2091 | +72.1 |
| HOLDS AMBUSHERS | 27 | 27 | 27 | 0.87 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.87 | +1636 | +60.6 |
| MARCH CHECK | 24 | 23 | 23 | 0.74 | +1483 | +64.5 |
| BLOCKED WHEEL | 22 | 22 | 22 | 0.71 | +36 | +1.6 |
| MARCH ODDS | 23 | 23 | 22 | 0.71 | +573 | +26.0 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.71 | +699 | +31.8 |
| LONE WIZARD HOLDS BACK | 54 | 54 | 21 | 0.68 | -916 | -43.6 |
| ARTILLERY RE-ROLL WEIGHED | 20 | 20 | 20 | 0.65 | +0 | +0.0 |
| KILLS COUNT | 53 | 51 | 20 | 0.65 | +503 | +25.2 |
| PLAN LEADS | 60 | 60 | 20 | 0.65 | +1015 | +50.7 |
| RISK BY ARC | 76 | 71 | 20 | 0.65 | +416 | +20.8 |
| MAX FOR POSITIONING | 172 | 97 | 19 | 0.61 | +154 | +8.1 |
| SCOUT WAITS | 19 | 19 | 19 | 0.61 | +0 | +0.0 |
| SHOTS IN THE MOVE | 392 | 254 | 18 | 0.58 | +366 | +20.4 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.55 | +36 | +2.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.52 | +0 | +0.0 |
| COMBAT PIVOT | 16 | 16 | 16 | 0.52 | +0 | +0.0 |
| KEEPS ITS TARGET | 54 | 54 | 16 | 0.52 | +272 | +17.0 |
| REDIRECT COUNTER | 125 | 57 | 15 | 0.48 | +1002 | +66.8 |
| CHARGE NOW WEIGHED | 14 | 14 | 14 | 0.45 | +904 | +64.6 |
| SHOT REPLANNED | 13 | 13 | 13 | 0.42 | +0 | +0.0 |
| BEST OVERALL | 11 | 11 | 11 | 0.35 | +343 | +31.2 |
| CASTING BLOCK | 14 | 14 | 11 | 0.35 | +615 | +55.9 |
| CHARIOT NO STATIC JOB | 21 | 21 | 11 | 0.35 | -1161 | -105.5 |
| MISSILES IN THE MOVE | 112 | 64 | 11 | 0.35 | +127 | +11.6 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.35 | +481 | +43.7 |
| CANNON PLANNED TARGET | 108 | 108 | 10 | 0.32 | +21 | +2.1 |
| CHAFF PASSED | 10 | 10 | 10 | 0.32 | -18 | -1.8 |
| CAST JOB | 19 | 19 | 9 | 0.29 | +137 | +15.2 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.29 | +390 | +43.3 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.29 | +0 | +0.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.26 | +0 | +0.0 |
| BACKUP TARGETS | 49 | 23 | 7 | 0.23 | +79 | +11.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.23 | +138 | +19.7 |
| SET UP TOGETHER | 23 | 20 | 7 | 0.23 | +69 | +9.9 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.19 | -16 | -2.7 |
| MODEL FACING | 6 | 6 | 6 | 0.19 | +938 | +156.4 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.19 | +581 | +96.8 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.16 | +0 | +0.0 |
| MAKE SURE TOGETHER | 18 | 12 | 5 | 0.16 | +67 | +13.4 |
| MOVE AND CAST | 5 | 5 | 5 | 0.16 | +292 | +58.5 |
| WHOLE FIGHT | 13 | 13 | 5 | 0.16 | +209 | +41.7 |
| WHOLE FIGHT GAIN | 13 | 9 | 5 | 0.16 | +333 | +66.5 |
| HUNT IN PAIRS | 19 | 13 | 4 | 0.13 | +166 | +41.6 |
| KEEP FALLS | 4 | 4 | 4 | 0.13 | +175 | +43.8 |
| MISSILES NEXT TURN | 159 | 94 | 4 | 0.13 | +34 | +8.4 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.13 | -254 | -63.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.10 | -144 | -48.0 |
| MANOEUVRE | 3 | 3 | 3 | 0.10 | +148 | +49.4 |
| OPENS UP | 4 | 4 | 3 | 0.10 | +205 | +68.4 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.10 | +122 | +40.6 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.10 | -341 | -113.8 |
| WEARS DOWN | 36 | 33 | 3 | 0.10 | +70 | +23.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| KEEPS ITS PREY | 10 | 10 | 2 | 0.06 | +22 | +10.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 2 | 0.06 | +110 | +55.0 |
| SURE REACH TOGETHER | 12 | 10 | 2 | 0.06 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.06 | +36 | +17.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +15 | +14.7 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.03 | -13 | -13.1 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.03 | +39 | +38.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +80 | +79.8 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +22 | +21.9 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.03 | +6 | +5.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +144 | +144.2 |
| OVERRUNS AWAY | 9 | 9 | 1 | 0.03 | +10 | +10.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.03 | -3 | -3.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +35 | +35.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +6 | +5.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 11 | 11 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 20 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 20 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 169 | not checked | - | - | - | - |
| GIVES UP | 30 | 29 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 26 | 23 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 8 | 7 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 166 | 166 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 17 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 1177 | trace | - | - | - | - |
| SCOUT SPOT | 17 | 17 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| TURN WORTH | 10 | 10 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 9 | 8 | 0 | 0.00 | - | - |

### Off best figure: ff-on-101d908-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 8.06 | 7.90 | 50.5 |
| FALLBACK | gate | 0.55 | 0.35 | 56.7 |
| LONE WIZARD HOLDS BACK | rule | 0.16 | 0.48 | 45.8 |
| TURN GATE | gate | 0.19 | 0.19 | 11.6 |
| CHARIOT NO STATIC JOB | rule | 0.19 | 0.16 | 105.5 |
| PATHS CROSS | rule | 0.19 | 0.03 | 33.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.13 | 0.03 | 102.2 |
| SUPPORT REQUEST | gate | - | 0.16 | 96.0 |
| AFTERMATH BAND | gate | 0.03 | 0.10 | 3.0 |
| BIG CHARACTER SAFETY | rule | 0.10 | 0.03 | 7.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 32.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.13 | - | 63.5 |
| THROUGH LINE OF FIRE | rule | 0.13 | - | 14.9 |
| BEST PRIZE | rule | - | 0.10 | 48.0 |
| CHAFF PASSED | rule | 0.06 | 0.03 | 6.1 |
| PURSUES BIG PREY | rule | 0.06 | 0.03 | 113.8 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.03 | 49.3 |
| SAFER THAN THE JOB | rule | 0.06 | - | 7.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 6.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 10.1 |
| CANNON PLANNED TARGET | rule | 0.03 | - | 3.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 13.1 |
| FIGHT ORDER BAND | gate | 0.03 | - | 2.2 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.5 |
| MARCH ODDS | rule | 0.03 | - | 53.3 |
| PIVOT GUARDS FLANK | rule | - | 0.03 | 3.0 |

### Plans: ff-on-101d908-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 6.8 | 18% | 267 | 159 | 59% |
| Mine | charge | 1.2 | 50% | 100 | 97 | 97% |
| Mine | close in | 2.2 | 24% | 145 | 49 | 34% |
| Mine | hold | 2.1 | 32% | 122 | 0 | 0% |
| Mine | join | 0.4 | 92% | 10 | 0 | 0% |
| Mine | shoot | 4.4 | 54% | 111 | 281 | 253% |
| Mine | support | 2.3 | 88% | 118 | 0 | 0% |
| Opponent | advance | 7.5 | 15% | 436 | 232 | 53% |
| Opponent | charge | 1.7 | 50% | 245 | 186 | 76% |
| Opponent | close in | 2.5 | 18% | 222 | 95 | 43% |
| Opponent | hold | 1.8 | 39% | 141 | 0 | 0% |
| Opponent | join | 0.3 | 100% | 15 | 0 | 0% |
| Opponent | shoot | 1.7 | 66% | 58 | 172 | 295% |
| Opponent | support | 2.9 | 87% | 102 | 0 | 0% |

### Packages: hunt the guns, ff-on-101d908-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 197 | 196 | 100% | 16 |
| Opponent | 0.0 | 1 | 1 | - | - | - | - | - | - | - | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 197 | 196 | 100% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 116 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 599 |

### Battle groups: ff-on-101d908-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 4.9 | 26% | 35% | 18% | 29% | 45% | 3% | 12% | 39% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 32% | 61% | 22% | 50% | 29% | 0% | 0% | 71% | 0% |
| Opponent | COUNTER-CHARGE COVER | 4.2 | 15% | 50% | 20% | 25% | 31% | 0% | 0% | 69% | 0% |
| Opponent | REDIRECT COUNTER | 2.2 | 15% | 80% | 10% | 0% | 22% | 0% | 0% | 78% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-on-101d908-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 16 | 81 (16) | 38 | 43 | 74 | 19% | 2.2 | 63 (9) | 258 (2) | 56 (5) | 85 (10) | 72 (6) |
| Mine | Character | 33 | 41 (33) | 41 | 0 | 43 | 24% | 2.4 | 37 (10) | 51 (10) | 97 (3) | 30 (10) | 59 (13) |
| Mine | Clean-up | 5 | 81 (5) | 10 | 71 | 21 | 60% | 3.5 | 73 (3) | 105 (1) | 75 (1) | 167 (2) | 21 (3) |
| Mine | Fast Hammer | 14 | 23 (14) | 18 | 5 | 76 | 14% | 2.4 | 28 (10) | 14 (3) | 0 (1) | 26 (12) | 0 (2) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 17 | 62 (17) | 49 | 14 | 47 | 12% | 3.1 | 0 (1) | 50 (10) | 98 (6) | 59 (12) | 70 (5) |
| Mine | Holder | 7 | 8 (7) | 0 | 8 | 67 | 14% | 3.3 | 0 (2) | 19 (4) | 0 (1) | 23 (4) | 0 (3) |
| Mine | Shooter | 16 | 54 (16) | 21 | 33 | 34 | 0% | 1.4 | 21 (6) | 99 (8) | 0 (2) | 71 (13) | 0 (3) |
| Mine | War machine | 20 | 43 (20) | 43 | 0 | 34 | 15% | 1.4 | 0 (6) | 74 (12) | 0 (2) | 0 (4) | 54 (16) |
| Mine | Wizard | 6 | 33 (6) | 33 | 0 | 27 | 0% | 1.3 | - | 58 (3) | 0 (1) | 0 (2) | 84 (2) |
| Opponent | Chaff | 23 | 50 (23) | 37 | 13 | 70 | 39% | 3.4 | 27 (11) | 8 (5) | 124 (7) | 66 (16) | 6 (7) |
| Opponent | Character | 33 | 55 (33) | 55 | 0 | 35 | 27% | 2.2 | 38 (13) | 56 (14) | 94 (4) | 60 (22) | 51 (9) |
| Opponent | Clean-up | 5 | 80 (5) | 0 | 80 | 16 | 40% | 3.0 | - | 121 (3) | 0 (2) | 45 (2) | 94 (3) |
| Opponent | Fast Hammer | 17 | 55 (17) | 43 | 13 | 45 | 18% | 2.6 | 51 (8) | 52 (6) | 81 (3) | 64 (13) | 33 (4) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Hammer | 15 | 63 (15) | 56 | 7 | 34 | 33% | 2.3 | 85 (5) | 53 (10) | - | 48 (10) | 98 (5) |
| Opponent | Holder | 8 | 31 (8) | 0 | 31 | 30 | 38% | 4.2 | 0 (3) | 54 (4) | - | 101 (2) | 8 (5) |
| Opponent | Shooter | 11 | 114 (11) | 25 | 89 | 39 | 9% | 1.5 | 65 (4) | 137 (7) | - | 137 (7) | 64 (4) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 82 | 33% | 2.8 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 4 | 34 (4) | 34 | 0 | 24 | 0% | 2.0 | 30 (3) | 46 (1) | - | 30 (3) | 46 (1) |
| Opponent | Wizard | 7 | 18 (7) | 18 | 0 | 24 | 14% | 3.0 | 0 (4) | 53 (2) | 0 (1) | 24 (5) | 0 (2) |

### Charged fights: ff-on-101d908-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 297 | 194 | 2.5 | 1.2 | 78 | 0 | +78 | 0 of 5 | 4 of 5 | +143 | +62 |
| Mine | Chaos Dwarfs | 1 | 0 | 310 | 3.0 | 1.0 | 103 | 0 | +103 | 1 of 3 | 2 of 3 | - | +103 |
| Mine | Dwarfen Mountain Holds | 2 | 62 | 372 | 3.0 | 1.2 | 124 | 0 | +124 | 4 of 6 | 4 of 6 | +470 | +55 |
| Mine | Empire of Man | 1 | 599 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 215 | 329 | 3.0 | 1.0 | 110 | 0 | +110 | 0 of 3 | 3 of 3 | - | +110 |
| Mine | High Elf Realms | 2 | 176 | 216 | 2.5 | 1.0 | 86 | 0 | +86 | 1 of 5 | 1 of 5 | - | +86 |
| Mine | Skaven | 1 | 455 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 385 | 4.0 | 1.0 | 96 | 0 | +96 | 1 of 4 | 3 of 4 | - | +96 |
| **Mine** | all armies | 11 | 213 | 235 | 2.5 | 1.1 | 92 | 0 | +92 | 8 of 28 | 18 of 28 | +306 | +76 |
| Opponent | Empire of Man | 1 | 468 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 2 | 101 | 649 | 5.0 | 1.2 | 130 | 74 | +56 | 5 of 10 | 6 of 10 | -76 | +89 |
| Opponent | Lizardmen | 1 | 0 | 874 | 5.0 | 1.0 | 175 | 28 | +147 | 4 of 5 | 3 of 5 | - | +147 |
| Opponent | Skaven | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 37 | -37 | 2 of 3 | 3 of 3 | -112 | +0 |
| Opponent | Vampire Counts | 4 | 38 | 639 | 5.2 | 1.2 | 122 | 63 | +59 | 10 of 21 | 9 of 21 | +325 | +15 |
| Opponent | Warriors of Chaos | 1 | 0 | 594 | 1.0 | 1.0 | 594 | 116 | +478 | 1 of 1 | 0 of 1 | - | +478 |
| Opponent | Wood Elf Realms | 1 | 370 | 754 | 6.0 | 1.2 | 126 | 42 | +84 | 3 of 6 | 5 of 6 | -125 | +126 |
| **Opponent** | all armies | 11 | 108 | 552 | 4.2 | 1.2 | 132 | 58 | +74 | 25 of 46 | 26 of 46 | +84 | +72 |

### Effective charges: ff-on-101d908-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +0) | 0 | 1 (net +143) | 1 (net +123) | 0 | 0 | 2 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 2 (net +68) | 0 | 1 (net +175) | 0 | 0% (0 of 3) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 3 (net +0) | 0 | 1 (net +60) | 2 (net +342) | 0 | 50% (3 of 6) |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +329) | 0 | 0% (0 of 3) |
| Mine | High Elf Realms | 5 | 0 | 0 | 1 (net +233) | 0 | 1 (net +54) | 1 (net +144) | 2 | 33% (1 of 3) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net +0) | 0 | 0 | 1 (net +250) | 1 (net +60) | 1 (net +75) | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 10 | 2 (net -127) | 0 | 0 | 1 (net +0) | 1 (net +0) | 5 (net +128) | 1 | 0% (0 of 9) |
| Opponent | Lizardmen | 5 | 0 | 0 | 0 | 2 (net +84) | 1 (net +65) | 1 (net +499) | 1 | 0% (0 of 4) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net -56) | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 21 | 3 (net +0) | 0 | 5 (net +111) | 7 (net -100) | 0 | 5 (net +179) | 1 | 25% (5 of 20) |
| Opponent | Wood Elf Realms | 6 | 1 (net +135) | 0 | 1 (net +354) | 2 (net -63) | 0 | 2 (net +70) | 0 | 17% (1 of 6) |

### Charged fights, damage counted: ff-on-101d908-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 220 | 252 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 5 | 179 | 361 | +75 | 75 | 7 | +68 | +37.8 |
| Mine | 76-89% | 5 | 220 | 153 | +102 | 102 | 6 | +95 | +43.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 225 | 257 | +201 | 201 | 8 | +193 | +85.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 371 | 58 | +44 | 70 | 0 | +70 | +18.9 |
| Mine | No odds | 5 | 371 | 123 | +25 | 26 | 0 | +26 | +6.9 |
| Mine | All fights | 28 | 262 | 204 | +92 | 96 | 5 | +92 | +35.0 |
| Opponent | Long shot (under 50%) | 7 | 240 | 202 | -17 | 67 | 84 | -17 | -7.1 |
| Opponent | Effective (55-75%) | 6 | 180 | 239 | +151 | 205 | 42 | +163 | +90.6 |
| Opponent | 76-89% | 12 | 281 | 210 | -55 | 80 | 120 | -40 | -14.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 337 | 221 | +138 | 195 | 61 | +134 | +39.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 350 | 65 | +32 | 135 | 0 | +135 | +38.7 |
| Opponent | No odds | 4 | 439 | 282 | +284 | 349 | 46 | +302 | +68.9 |
| Opponent | All fights | 46 | 297 | 216 | +74 | 158 | 74 | +84 | +28.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-on-101d908-p4 | move | 222 | 41 (18%) | 31 (14%) | 17 (8%) | 164 (74%) |
| ff-on-101d908-p4 | objective | 174 | 16 (9%) | 14 (8%) | 23 (13%) | 135 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

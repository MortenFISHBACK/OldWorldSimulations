# Doctrine scorecard: ff-off-101d908-p4

### Scorecard: ff-off-101d908-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | yes | 8 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 9 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 81 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 3 | 4 | 4 | 0 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 11 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 5 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 49 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0520 | 4 | 1 | Opponent | no | 2 | - | 1 | 6 | 2 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 4 | 2 | 2 | 1 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | yes | 2 | 1 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0819 | 3 | 1 | Opponent | no | 3 | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 560 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 13 | 1 | 6 | 2 | 1 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 56 |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 11 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 2 | 2 | 6 | 0 | 0 | 0 | 197 |
| L1314 | 6 | 1 | Mine | no | 14 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 1 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 456 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 176 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 132 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 49 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 255 |
| L1819 | 1 | 1 | Mine | no | 0 | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 4 | 4 | 3 | 0 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | 5 | 1 | 4 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 2 | 5 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 6 | 0 | 0 | 0 | 65 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 1 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | yes | 6 | 3 | 5 | 1 | 1 | 0 | 0 | 72 |
| L2331 | 3 | 1 | Opponent | no | 1 | 3 | 4 | 0 | 0 | 0 | 0 | 371 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 2 | 1 | 3 | 2 | 1 | 0 | 0 | 50 |
| L2634 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 107 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 39% | 2.7 | 3.0 | 2.4 | 1.1 | 0.4 | 0.0 | 0.0 | 239.1 |
| **Average** | | | Opponent | 32% | 3.5 | 2.2 | 3.2 | 2.0 | 0.4 | 0.0 | 0.0 | 111.9 |

### KPIs: ff-off-101d908-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 99% (77 of 78); on the table 100% | 97% (59 of 61); on the table 98% | 98% (136 of 139); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (12 of 13); on the table 100% | 94% (16 of 17); on the table 100% | 93% (28 of 30); on the table 100% |
| Winner chose to pursue after the loser fled |  | 76% (19 of 25); on the table 80% | 86% (25 of 29); on the table 93% | 81% (44 of 54); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 93% (108 of 116); on the table 96% | 93% (100 of 107); on the table 97% | 93% (208 of 223); on the table 96% |
| Magic missiles tried each own turn | 50%+ | 22% (60 of 271) | 31% (53 of 173) | 25% (113 of 444) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (60 of 161) | 45% (53 of 117) | 41% (113 of 278) |
| Points that never fought | lower | 33% (22516 of 67942) | 32% (23239 of 71984) | 33% (45755 of 139926) |
|   infantry points that never fought | lower | 41% (6267 of 15347) | 60% (8220 of 13804) | 50% (14487 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (154 of 270) | 51% (144 of 280) | 54% (298 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.7 uses a game | 78% (7 of 9); 0.5 uses a game | 84% (26 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.6 uses a game | 45% (9 of 20); 0.4 uses a game | 47% (17 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 60% (9 of 15); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30317 of 57750) | 45% (28804 of 63347) | 49% (59121 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (23%) | 0.7 (20%) | 2.0 (22%) |
| MARCHED: its unit marched | 1.1 (18%) | 0.6 (18%) | 1.7 (18%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (4%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 1.4 (25%) | 0.9 (28%) | 2.4 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.6 (11%) | 0.6 (18%) | 1.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (13%) | 0.0 (0%) | 0.8 (8%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.2 | 1.6 | 3.1 | 0.3 | 2.4 |
| not cast | 2.9 | 2.6 | 3.3 | 9.2 | 1.7 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (43%) | 0.2 (7%) | 2.0 (22%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.3 (11%) | 0.7 (22%) | 2.4 (26%) | 0.4 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.1 (3%) | 0.2 (8%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (7%) | 0.2 (6%) | 0.1 (3%) | 0.2 (2%) | 0.1 (5%) | 1.2 (6%) |
| GONE: slain | 0.7 (23%) | 0.3 (12%) | 0.5 (16%) | 1.2 (14%) | 0.2 (13%) | 3.3 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (9%) | 0.3 (12%) | 0.4 (14%) | 0.8 (8%) | 0.1 (3%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (9%) | 0.0 (0%) | 0.0 (0%) | 0.2 (13%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (49%) | 0.1 (5%) | 1.0 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (63%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 69% (25 of 36) | 50% (4 of 8) | 66% (29 of 44) |
| the unit moved after it | 80% (20 of 25) | 100% (4 of 4) | 83% (24 of 29) |
| it charged on its next turn | 8% (2 of 25) | 0% (0 of 4) | 7% (2 of 29) |
| the enemy charged it first | 28% (7 of 25) | 0% (0 of 4) | 24% (7 of 29) |
| it fought by the end of its next turn | 40% (10 of 25) | 0% (0 of 4) | 34% (10 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 16% (4 of 25) | 0% (0 of 4) | 14% (4 of 29) |
| none of these (no charge, no fight, no charge escaped) | 32% (8 of 25) | 100% (4 of 4) | 41% (12 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (534 of 867) | 56% (298 of 532) | 59% (832 of 1399) |
|   cavalry | 54% (40 of 74) | 75% (83 of 110) | 67% (123 of 184) |
|   character | 36% (34 of 95) | 16% (19 of 122) | 24% (53 of 217) |
|   chariot | 43% (46 of 106) | 62% (13 of 21) | 46% (59 of 127) |
|   infantry | 58% (156 of 267) | 67% (153 of 228) | 62% (309 of 495) |
|   monster | 47% (21 of 45) | 28% (5 of 18) | 41% (26 of 63) |
|   war machine | 85% (237 of 280) | 76% (25 of 33) | 84% (262 of 313) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (30%) | 1.7 (26%) | 4.5 (29%) |
| CHARGED: it charged | 1.2 (14%) | 1.8 (28%) | 3.1 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.3 (5%) | 1.1 (7%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.2 (23%) | 1.0 (15%) | 3.1 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (8%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (12%) | 1.1 (17%) | 2.2 (14%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.6 | 77% | 7.3 pts | 39 pts |
| character | 1.9 | 0.5 | 77% | 6.6 pts | 13 pts |
| chariot | 1.6 | 1.2 | 59% | 19.2 pts | 32 pts |
| infantry | 12.8 | 4.8 | 75% | 10.5 pts | 134 pts |
| monster | 0.8 | 0.1 | 87% | 1.5 pts | 1 pts |
| war machine | 7.3 | 6.1 | 63% | 27.9 pts | 203 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.2 | 5.2 |
| Charges that made contact a game | 3.3 | 4.4 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.94 contact (16 units) | 1.41 declared, 1.12 contact (17 units) | 1.21 declared, 1.03 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.78 declared, 0.67 contact (9 units) | 0.91 declared, 0.91 contact (11 units) | 0.85 declared, 0.80 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.39 contact (251 units) | 0.62 declared, 0.43 contact (302 units) | 0.58 declared, 0.41 contact (553 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 41% (33 of 81) | 44% (7 of 16) | 83% (5 of 6) | 44% (45 of 103) |
| Character in a unit | 70% (19 of 27) | 46% (6 of 13) | 100% (1 of 1) | 63% (26 of 41) |
| Character on its own | 79% (30 of 38) | 66% (19 of 29) | 26% (20 of 77) | 48% (69 of 144) |
| Chariot | 47% (7 of 15) | 50% (6 of 12) | - | 48% (13 of 27) |
| Infantry | 59% (49 of 83) | 48% (12 of 25) | 17% (1 of 6) | 54% (62 of 114) |
| Monster | 65% (22 of 34) | 64% (9 of 14) | - | 65% (31 of 48) |
| Monstrous | 64% (9 of 14) | 79% (11 of 14) | - | 71% (20 of 28) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (10 of 12); on the table 83% | 22% (22 of 102) | 10% | 64% (14 of 22) | 83% (5 of 6); 2.8 uses a game | 50% (1 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 91% (21 of 23); on the table 91% | 29% (7 of 24) | 28% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (8 of 8); on the table 100% | - | 60% | 85% (23 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 85% (17 of 20); on the table 100% | 39% (7 of 18) | 52% | 60% (37 of 62) | 0.0 uses a game | 50% (1 of 2); 1.3 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (15 of 15); on the table 100% | 18% (15 of 84) | 49% | 41% (15 of 37) | 100% (9 of 9); 8.8 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 100% (28 of 28); on the table 100% | 22% (8 of 36) | 30% | 49% (34 of 70) | 100% (7 of 7); 2.6 uses a game | 47% (14 of 30); 2.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 19% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (9 of 9); on the table 100% | 67% (4 of 6) | 28% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (7 of 7); on the table 100% | 50% (3 of 6) | 35% | 86% (12 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 17% (7 of 42) | 8% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 83% (10 of 12); on the table 100% | 36% (15 of 42) | 51% | 67% (30 of 45) | 67% (2 of 3); 0.5 uses a game | 0.0 uses a game | 83% (5 of 6); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 92% | 17% (1 of 6) | 27% | 30% (6 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (33 of 35); on the table 97% | 22% (13 of 60) | 23% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 92% (23 of 25); on the table 92% | 50% (6 of 12) | 29% | 53% (38 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 90% (9 of 10); on the table 100% | 83% (5 of 6) | 31% | 52% (29 of 56) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (ff-off-101d908-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (45) | 50% (37) | 48% (82) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.72 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.11 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.44 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.17 | 0.64 | 1.81 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.61 | 0.56 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.58 | 7.81 | 14.39 |

### Quality by phase: ff-off-101d908-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 56% (73 of 131) | 50% (91 of 181) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (151 of 347) | 34% (49 of 145) |
| Strategy | Close-in objectives charged next turn | 13% (24 of 181) | 13% (22 of 166) |
| Strategy | Support requests answered (helper made contact too) | 64% (7 of 11) | 41% (11 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (5 of 9) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 82% (27 of 33) | 42% (11 of 26) |
| Strategy | Lone characters that fought | 68% (61 of 90) | 84% (76 of 90) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 2.0 |
| Movement | Points that never moved of their own | 239.1 | 111.9 |
| Movement | Fights charged into per game | 3.1 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 100, net +85 | 11 of 110, net +17 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 100, net +129 | 19 of 110, net +86 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 18 of 100, net +78 | 12 of 110, net +63 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 100, net +89 | 42 of 110, net +127 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (141 of 327) | 47% (157 of 331) |
| Shooting | Points destroyed by shooting units | 85.4 | 45.6 |
| Shooting | War machine shots | 6.6 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (151 of 237) | 56% (14 of 25) |
| Shooting | Points destroyed by war machines | 95.6 | 8.4 |
| Magic | Magic missiles cast | 1.0 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (24 of 36) | 29% (11 of 38) |
| Magic | Wounds caused by magic missiles | 2.3 | 0.9 |
| Magic | Wounds caused by other spells | 1.2 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 59.1 | 35.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.3 / 0.7 / 0.1 | 2.1 / 0.4 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 347.0 | 438.7 |
| Combat | Points run down | 121.5 | 136.3 |
| Combat | Net points per charged fight, damage counted | +76 | +86 |
| Combat | Net per 100 charger points, damage counted | +27.1 | +27.4 |
| Combat | First round won (charged fights) | 74% | 62% |
| Combat | Net points per charged fight | +79 | +86 |
| Combat | Net points per supported fight / lone fight | +113 / +75 | +159 / +74 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 110 | 57 of 133 |
| Game | Points lost | 826.1 | 738.8 |
| Game | VP from objectives | 560.8 | 610.3 |
| Game | Lone holders (player turns) | 2.7 | 3.5 |

- Mine won / drew / lost: 14 / 4 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -181 VP
- The side that went first won 17 of 32 games with a winner
- Points traded per game (both sides' losses): 1565
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ff-off-101d908-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 7.1 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.0 | +5.7 | 0.0 | 11.9 | 1.3 | +17.0 | 0.0 | 4.5 |
| BEST PREY | 4.4 | +280.0 | 165.6 | 173.8 | 5.8 | +374.7 | 293.1 | 189.8 |
| BEST PRIZE | - | - | - | - | 0.1 | +8.6 | 26.8 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | +0.5 | 0.0 | 9.9 | 0.3 | +6.1 | 0.0 | 10.8 |
| BOMBING RUN | 0.0 | +0.4 | 1.1 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 57.2 | 12.8 | 0.2 | +0.0 | 20.1 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +146.5 | 446.7 | 87.1 | 0.4 | +13.3 | 36.6 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 13.7 | 0.1 | +0.0 | 14.9 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 3.4 | 5.2 | - | - | - | - |
| CAST JOB | 0.7 | +24.4 | 44.4 | 4.5 | 0.4 | +10.1 | 27.6 | 16.7 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +48.4 | 32.1 | 8.9 | 0.0 | +0.4 | 0.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 57.5 | 0.2 | +0.0 | 0.0 | 11.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.6 | 9.1 | 0.0 | 0.1 | -0.4 | 23.3 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.5 | -32.9 | 28.9 | 19.9 | 0.6 | -58.9 | 7.6 | 14.2 |
| CHARIOT NO STATIC JOB | 0.5 | +0.0 | 29.2 | 11.2 | 0.2 | +0.0 | 0.0 | 7.4 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 60.0 | 1.5 |
| COMBAT PIVOT | 0.5 | +0.0 | 43.6 | 72.3 | 0.7 | +0.0 | 65.9 | 43.8 |
| CONVEYANCE SEARCH | 0.8 | +106.3 | 31.2 | 49.4 | 0.1 | +20.4 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.7 | +583.3 | 0.0 | 237.3 | 6.9 | +596.6 | 0.0 | 125.9 |
| EDGE GIVE GROUND | 0.1 | +9.7 | 39.6 | 5.2 | 0.2 | +6.3 | 19.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.2 | +115.2 | 0.0 | 61.9 | 0.6 | +62.2 | 0.0 | 25.7 |
| FALLBACK BY WORTH | 7.1 | +99.2 | 0.0 | 116.7 | 7.8 | +76.1 | 0.0 | 68.9 |
| FIGHT LIFT | 0.1 | +1.1 | 16.5 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.9 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 191.1 | 6.4 | +0.0 | 0.0 | 122.9 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +170.2 | 0.0 | 68.8 | 1.4 | +185.3 | 0.0 | 25.3 |
| FRIENDS SHOTS CHECKED | 0.4 | +27.4 | 0.0 | 35.8 | 0.1 | +6.0 | 0.0 | 0.0 |
| GIVES UP | 0.9 | -25.2 | 138.1 | 44.1 | 1.4 | -69.5 | 250.7 | 14.8 |
| GIVES UP ITS SCREEN | 0.5 | -10.8 | 34.1 | 7.8 | 1.1 | -17.4 | 139.6 | 11.3 |
| GROUND FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 36.6 | 1.9 |
| HELPER UNSEEN | 0.2 | +0.0 | 20.6 | 1.1 | 0.2 | +0.0 | 17.4 | 9.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 5.3 | 0.0 | 0.2 | +2.9 | 3.5 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +15.6 | 0.0 | 19.6 | 0.6 | +15.2 | 0.0 | 16.6 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +5.4 | 0.0 | 0.0 | 0.1 | +8.1 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +11.6 | 5.3 | 0.0 | 0.1 | +40.7 | 3.5 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +12.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.8 | 0.0 | 13.6 | 0.0 | +1.5 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.2 | +1.0 | 3.4 | 8.2 | 0.4 | +4.2 | 8.6 | 19.5 |
| KEEPS ITS TARGET | 2.1 | +61.7 | 207.1 | 85.7 | 1.9 | +57.5 | 238.4 | 36.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +83.0 | 141.6 | 50.5 | 2.0 | +137.7 | 198.4 | 19.5 |
| KILLS COUNT NEXT TURN | 9.1 | +343.9 | 418.5 | 345.7 | 11.0 | +581.9 | 391.6 | 224.3 |
| LONE CHARACTER SAFE SPOT | 0.6 | +63.2 | 46.7 | 25.2 | 0.4 | +14.9 | 18.1 | 16.6 |
| LONE WIZARD HOLDS BACK | 1.2 | +0.0 | 80.7 | 100.5 | 1.2 | +0.0 | 36.3 | 37.9 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +25.6 | 10.5 | 15.9 | 0.3 | +12.3 | 0.0 | 1.7 |
| MANOEUVRE | 0.2 | +5.9 | 0.0 | 4.4 | 0.1 | +8.2 | 0.0 | 1.8 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 8.2 | 0.1 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +27.4 | 0.0 | 9.6 | 0.4 | +5.7 | 0.0 | 18.6 |
| MARCH ODDS | 0.8 | +44.4 | 27.6 | 21.5 | 0.6 | +63.3 | 20.7 | 0.0 |
| MARCH OVER CASTS | 0.6 | +54.1 | 0.0 | 14.7 | 0.4 | +30.0 | 0.0 | 11.0 |
| MAX FOR POSITIONING | 5.0 | +155.7 | 0.0 | 133.8 | 4.7 | +188.8 | 0.0 | 97.4 |
| MISSILES IN THE MOVE | 3.6 | +142.5 | 0.0 | 105.2 | 2.1 | +39.7 | 0.0 | 87.6 |
| MISSILES NEXT TURN | 4.6 | +93.2 | 0.0 | 125.3 | 2.7 | +26.6 | 0.0 | 77.9 |
| MODEL FACING | 0.2 | +26.1 | 0.0 | 1.7 | - | - | - | - |
| MOVE AND CAST | 0.2 | +8.9 | 0.0 | 4.5 | 0.2 | +3.7 | 0.0 | 6.1 |
| MOVE SPELL IN RANGE | 0.2 | +5.1 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.5 | -21.5 | 26.1 | 17.2 | 0.1 | -2.7 | 0.0 | 10.2 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 26.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +7.6 | 16.6 | 0.0 | 0.2 | +6.8 | 25.2 | 0.0 |
| NOT NEEDED | 0.3 | -14.5 | 28.1 | 2.8 | 0.1 | -6.9 | 14.8 | 16.4 |
| NOT TURNED | 6.6 | +120.1 | 0.0 | 147.9 | 7.8 | +165.4 | 0.0 | 150.7 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 18.6 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 18.6 | -1015.9 | 49.2 | 436.6 | 16.3 | -907.1 | 65.2 | 281.0 |
| OPENS A LANE | 0.1 | +0.1 | 4.5 | 0.0 | 0.1 | +1.8 | 6.2 | 0.0 |
| OPENS UP | 0.2 | +15.8 | 15.6 | 6.5 | 0.2 | +22.3 | 19.1 | 0.0 |
| OVERRUN THREAT | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +15.8 | 57.8 | 27.0 | 0.6 | +6.3 | 50.1 | 28.3 |
| PATHS CROSS | 2.4 | +164.0 | 0.0 | 45.8 | 3.2 | +277.3 | 0.0 | 41.0 |
| PERIAPT WORTH | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +7.6 | 0.0 | 15.0 |
| PLAN LEADS | 1.2 | +114.4 | 42.8 | 20.2 | 0.9 | +72.5 | 34.5 | 10.3 |
| PLAN RESULT | 39.2 | +1728.1 | 1503.5 | 1242.6 | 38.8 | +1433.5 | 1467.0 | 1150.8 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -5.3 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.1 | 0.0 | 3.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.6 | 0.0 | 0.0 | 0.2 | +14.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.2 | +172.9 | 0.0 | 66.9 | 4.7 | +307.7 | 0.0 | 81.6 |
| REDIRECT WEIGHED | 0.2 | +7.4 | 13.9 | 3.4 | 0.4 | +11.8 | 15.8 | 26.9 |
| RESTRAINS TO SHOOT | 0.1 | +4.4 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +71.1 | 200.8 | 101.4 | 2.8 | +39.8 | 308.4 | 91.5 |
| SAFER THAN THE JOB | 0.6 | +25.3 | 0.0 | 19.9 | 0.6 | +31.3 | 0.0 | 20.2 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.9 | +117.5 | 0.0 | 62.2 | 1.9 | +107.6 | 0.0 | 49.9 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +38.2 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 40.1 |
| SET UP TOGETHER | 0.8 | +37.7 | 10.5 | 19.4 | 0.5 | +15.0 | 0.0 | 1.7 |
| SET-UP ANY TARGET | 0.6 | +103.1 | 26.5 | 35.8 | 0.1 | +13.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +20.1 | 1.8 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.4 | +0.0 | 116.8 | 19.6 | 0.3 | +0.0 | 42.1 | 1.8 |
| SHOTS IN THE MOVE | 13.9 | +512.0 | 0.0 | 239.7 | 7.3 | +235.5 | 0.0 | 134.6 |
| SPELL SETS UP CHARGE | 0.6 | +103.1 | 26.5 | 35.8 | 0.1 | +13.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +23.9 | 185.3 | 172.5 | 2.5 | +52.9 | 101.6 | 98.9 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +3.5 | 0.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 14.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -10.0 | 34.5 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.8 | 13.9 | 10.2 | 0.5 | +9.8 | 10.3 | 27.0 |
| THROUGH LINE OF FIRE | 0.5 | +21.2 | 0.0 | 7.0 | 0.3 | +18.2 | 0.0 | 1.9 |
| TURN WORTH | 0.6 | -48.5 | 51.4 | 8.6 | 0.3 | -24.8 | 15.9 | 8.1 |
| TWO OR MORE ARRIVE | 0.2 | +0.4 | 6.8 | 5.7 | 0.1 | +0.2 | 0.0 | 0.0 |
| WEARS DOWN | 0.9 | +28.1 | 157.1 | 43.3 | 1.4 | +43.4 | 175.8 | 62.5 |
| WHO HITS BACK | 0.1 | +7.5 | 0.0 | 5.2 | 0.3 | +15.3 | 0.0 | 7.8 |
| WHOLE FIGHT | 0.2 | +3.0 | 65.1 | 3.3 | 0.6 | +43.6 | 115.0 | 5.9 |
| WHOLE FIGHT GAIN | 0.1 | +17.0 | 8.1 | 7.8 | 0.6 | +50.2 | 83.2 | 13.8 |

### Rule changes: ff-off-101d908-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1257 | 1257 | 1257 | 34.92 | -69227 | -55.1 |
| KILLS COUNT NEXT TURN | 723 | 713 | 224 | 6.22 | +8097 | +36.1 |
| PATHS CROSS | 202 | 202 | 202 | 5.61 | +15885 | +78.6 |
| BEST PREY | 370 | 363 | 155 | 4.31 | +5413 | +34.9 |
| SEARCH SPOT | 136 | 136 | 132 | 3.67 | +8110 | +61.4 |
| FALLBACK BY WORTH | 536 | 536 | 113 | 3.14 | +6309 | +55.8 |
| COUNTER-CHARGE COVER | 563 | 273 | 112 | 3.11 | +6269 | +56.0 |
| FOLLOW UP WEIGHED | 90 | 90 | 90 | 2.50 | +12798 | +142.2 |
| FACES THE THREAT | 65 | 65 | 65 | 1.81 | +6385 | +98.2 |
| KILLS COUNT | 137 | 129 | 50 | 1.39 | +2639 | +52.8 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| MARCH ODDS | 50 | 49 | 46 | 1.28 | +725 | +15.8 |
| SHOTS IN THE MOVE | 763 | 489 | 45 | 1.25 | +1058 | +23.5 |
| COMBAT PIVOT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SAFER THAN THE JOB | 42 | 42 | 42 | 1.17 | +2038 | +48.5 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| MAX FOR POSITIONING | 348 | 180 | 40 | 1.11 | +204 | +5.1 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +1952 | +50.1 |
| RISK BY ARC | 177 | 163 | 38 | 1.06 | +1092 | +28.7 |
| KEEPS ITS TARGET | 143 | 142 | 36 | 1.00 | +662 | +18.4 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 88 | 88 | 31 | 0.86 | -1367 | -44.1 |
| REDIRECT COUNTER | 284 | 120 | 31 | 0.86 | +2709 | +87.4 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +1415 | +45.7 |
| CANNON PLANNED TARGET | 206 | 206 | 29 | 0.81 | -500 | -17.2 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +236 | +8.4 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MARCH CHECK | 32 | 29 | 28 | 0.78 | +1546 | +55.2 |
| SHOT REPLANNED | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| PLAN LEADS | 77 | 77 | 23 | 0.64 | +1243 | +54.0 |
| MISSILES IN THE MOVE | 205 | 108 | 22 | 0.61 | +532 | +24.2 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +947 | +47.3 |
| CAST JOB | 38 | 37 | 19 | 0.53 | +280 | +14.7 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1199 | +63.1 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 27 | 27 | 18 | 0.50 | -2223 | -123.5 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +453 | +28.3 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -39 | -2.6 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +560 | +37.4 |
| MANOEUVRE | 13 | 13 | 13 | 0.36 | +509 | +39.1 |
| SET UP TOGETHER | 46 | 36 | 13 | 0.36 | +435 | +33.4 |
| CASTING BLOCK | 15 | 15 | 12 | 0.33 | +1214 | +101.2 |
| WHOLE FIGHT GAIN | 25 | 19 | 12 | 0.33 | +1096 | +91.3 |
| WEARS DOWN | 81 | 75 | 10 | 0.28 | +320 | +32.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MAKE SURE TOGETHER | 29 | 19 | 9 | 0.25 | +271 | +30.1 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| HUNT IN PAIRS | 37 | 29 | 8 | 0.22 | +211 | +26.4 |
| WHOLE FIGHT | 31 | 30 | 8 | 0.22 | +735 | +91.9 |
| BACKUP TARGETS | 82 | 43 | 7 | 0.19 | +35 | +5.0 |
| MISSILES NEXT TURN | 262 | 138 | 7 | 0.19 | +30 | +4.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OPENS UP | 18 | 16 | 7 | 0.19 | +380 | +54.3 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -367 | -52.5 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +938 | +156.4 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +416 | +69.2 |
| RAIDS THE BAGGAGE NEXT TURN | 8 | 8 | 6 | 0.17 | +220 | +36.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -477 | -95.5 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +236 | +47.2 |
| NEEDED THERE | 7 | 7 | 5 | 0.14 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +178 | +35.7 |
| SURE REACH TOGETHER | 29 | 23 | 5 | 0.14 | +8 | +1.6 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| KEEPS ITS PREY | 20 | 19 | 4 | 0.11 | +14 | +3.5 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| EDGE GIVE GROUND | 10 | 8 | 2 | 0.06 | +56 | +28.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +47 | +23.4 |
| HUNT ADVANCE | 10 | 10 | 2 | 0.06 | +14 | +7.2 |
| JOINT CHARGE PLAN | 4 | 4 | 2 | 0.06 | +338 | +169.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 38 | 36 | 2 | 0.06 | +22 | +11.2 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -191 | -95.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -59 | -29.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +15 | +14.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +80 | +79.8 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +22 | +21.9 |
| GIVES UP | 85 | 78 | 1 | 0.03 | +18 | +17.5 |
| GIVES UP ITS SCREEN | 57 | 54 | 1 | 0.03 | +2 | +1.7 |
| MOVE SPELL IN RANGE | 9 | 5 | 1 | 0.03 | +11 | +11.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +2 | +2.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 30 | 30 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 448 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 15 | 14 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 36 | 36 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 518 | 518 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 6 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2809 | trace | - | - | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| TURN WORTH | 34 | 31 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: ff-off-101d908-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.58 | 13.50 | 57.1 |
| FALLBACK | gate | 1.22 | 1.03 | 49.6 |
| RULE SWITCHED OFF | gate | 0.58 | 0.64 | 21.3 |
| TURN GATE | gate | 0.53 | 0.50 | 37.3 |
| LONE WIZARD HOLDS BACK | rule | 0.36 | 0.47 | 45.6 |
| CHARIOT NO STATIC JOB | rule | 0.36 | 0.14 | 123.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | 0.17 | 82.2 |
| PATHS CROSS | rule | 0.17 | 0.22 | 30.2 |
| AFTERMATH BAND | gate | 0.11 | 0.17 | 2.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.22 | 60.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.03 | 52.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.06 | 161.6 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 6.4 |
| BEST PRIZE | rule | - | 0.14 | 95.5 |
| BLOCKED WHEEL | rule | 0.11 | 0.03 | 9.3 |
| CANNON PLANNED TARGET | rule | 0.06 | 0.08 | 115.0 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 62.8 |
| THROUGH LINE OF FIRE | rule | 0.11 | - | 14.9 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.8 |
| FOLLOW UP WEIGHED | rule | - | 0.06 | 2.8 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.1 |
| PURSUES BIG PREY | rule | - | 0.06 | 95.5 |
| REDIRECT WEIGHED | rule | - | 0.06 | 166.7 |
| STAYS FIRST | gate | 0.03 | 0.03 | 35.6 |
| MARCH ODDS | rule | - | 0.03 | 177.3 |
| STANDS TO CAST | rule | - | 0.03 | 64.6 |

### Plans: ff-off-101d908-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.5 | 27% | 583 | 538 | 92% |
| Mine | charge | 2.9 | 67% | 283 | 289 | 102% |
| Mine | close in | 5.0 | 29% | 288 | 198 | 69% |
| Mine | hold | 4.2 | 38% | 390 | 0 | 0% |
| Mine | join | 0.7 | 88% | 27 | 0 | 0% |
| Mine | shoot | 8.3 | 61% | 302 | 702 | 232% |
| Mine | support | 4.6 | 89% | 273 | 0 | 0% |
| Opponent | advance | 15.4 | 17% | 798 | 506 | 63% |
| Opponent | charge | 4.2 | 56% | 588 | 488 | 83% |
| Opponent | close in | 4.6 | 19% | 404 | 139 | 34% |
| Opponent | hold | 3.9 | 34% | 368 | 0 | 0% |
| Opponent | join | 0.5 | 83% | 38 | 0 | 0% |
| Opponent | shoot | 3.5 | 65% | 109 | 302 | 278% |
| Opponent | support | 6.6 | 85% | 226 | 0 | 0% |

### Packages: hunt the guns, ff-off-101d908-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 50% | 0% | 2.0 | 209 | 98 | 50% | 5 |
| Opponent | 0.1 | 4 | 0 | 0% | 25% | 0% | 2.0 | 366 | 73 | 25% | 135 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 123 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 301 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 160 |
| Tomb Kings of Khemri | 1.0 | 4 | 0 | 0% | 25% | 0% | 2.0 | 327 | 49 | 25% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 334 | 292 | 100% | 14 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 32 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |

### Battle groups: ff-off-101d908-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 26% | 48% | 13% | 9% | 37% | 11% | 8% | 44% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 30% | 66% | 11% | 50% | 32% | 0% | 10% | 55% | 3% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 17% | 69% | 36% | 33% | 37% | 11% | 7% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 21% | 71% | 14% | 0% | 10% | 0% | 13% | 73% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-off-101d908-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 79 | 0% | 3.0 | - | 0 (1) | 0 (3) | - | 0 (4) |
| Mine | Chaff | 49 | 66 (49) | 36 | 30 | 56 | 24% | 2.5 | 81 (21) | 79 (11) | 39 (17) | 75 (32) | 49 (17) |
| Mine | Character | 106 | 41 (106) | 40 | 1 | 48 | 20% | 2.3 | 36 (32) | 52 (46) | 78 (8) | 34 (42) | 60 (44) |
| Mine | Clean-up | 14 | 61 (14) | 30 | 31 | 53 | 14% | 3.3 | 62 (6) | 39 (5) | 101 (3) | 58 (7) | 64 (7) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 39 | 48 (39) | 39 | 9 | 45 | 13% | 2.7 | 42 (24) | 66 (9) | 45 (6) | 34 (28) | 87 (11) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 50% | 1.5 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 43 (64) | 33 | 9 | 50 | 11% | 2.5 | 55 (10) | 40 (44) | 43 (10) | 55 (39) | 28 (25) |
| Mine | Holder | 30 | 105 (30) | 2 | 103 | 30 | 37% | 3.1 | 4 (7) | 169 (18) | 21 (5) | 151 (18) | 34 (12) |
| Mine | Shooter | 35 | 63 (35) | 25 | 37 | 35 | 6% | 1.5 | 48 (11) | 84 (19) | 14 (5) | 79 (23) | 33 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 71 (56) | 71 | 0 | 42 | 7% | 1.2 | 48 (20) | 93 (31) | 52 (5) | 40 (7) | 75 (49) |
| Mine | Wizard | 17 | 11 (17) | 11 | 0 | 48 | 12% | 1.9 | 0 (5) | 29 (7) | - | 0 (3) | 22 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 82 | 58 (82) | 28 | 30 | 63 | 32% | 3.0 | 73 (30) | 35 (21) | 63 (31) | 73 (62) | 5 (20) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 33 | 19% | 2.2 | 56 (40) | 64 (41) | 77 (7) | 56 (47) | 67 (41) |
| Opponent | Clean-up | 12 | 101 (12) | 12 | 89 | 12 | 50% | 3.0 | 10 (3) | 137 (6) | 61 (3) | 84 (7) | 116 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 51 (54) | 37 | 15 | 45 | 28% | 2.8 | 40 (27) | 55 (17) | 89 (10) | 56 (34) | 45 (20) |
| Opponent | Fragile | 16 | 58 (16) | 58 | 0 | 61 | 19% | 2.1 | 0 (2) | 94 (8) | 41 (3) | 96 (9) | 0 (4) |
| Opponent | Hammer | 64 | 36 (64) | 26 | 10 | 44 | 36% | 3.0 | 58 (20) | 30 (38) | 29 (6) | 33 (42) | 42 (22) |
| Opponent | Holder | 27 | 31 (27) | 1 | 30 | 28 | 56% | 3.9 | 13 (9) | 44 (15) | 8 (3) | 36 (13) | 25 (14) |
| Opponent | Shooter | 34 | 89 (34) | 25 | 64 | 38 | 3% | 1.4 | 74 (9) | 102 (23) | 10 (2) | 74 (20) | 111 (14) |
| Opponent | Support | 6 | 193 (6) | 193 | 0 | 51 | 33% | 3.0 | 444 (2) | 0 (1) | 0 (2) | 286 (3) | 0 (2) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 19 | 0% | 1.7 | 30 (3) | 22 (3) | - | 30 (3) | 22 (3) |
| Opponent | Wizard | 20 | 10 (20) | 10 | 0 | 49 | 5% | 2.6 | 22 (9) | 4 (4) | 0 (2) | 18 (10) | 0 (5) |

### Charged fights: ff-off-101d908-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 104 | 228 | 2.2 | 1.2 | 101 | 45 | +56 | 1 of 9 | 6 of 9 | +106 | +42 |
| Mine | Chaos Dwarfs | 4 | 211 | 279 | 3.2 | 1.1 | 86 | 45 | +41 | 3 of 13 | 10 of 13 | +599 | -5 |
| Mine | Dwarfen Mountain Holds | 3 | 335 | 71 | 1.7 | 1.0 | 43 | 0 | +43 | 3 of 5 | 3 of 5 | - | +43 |
| Mine | Empire of Man | 5 | 398 | 415 | 2.2 | 1.0 | 189 | 46 | +142 | 4 of 11 | 8 of 11 | - | +142 |
| Mine | Grand Cathay | 4 | 222 | 258 | 3.0 | 1.2 | 86 | 46 | +40 | 3 of 12 | 10 of 12 | -148 | +103 |
| Mine | High Elf Realms | 4 | 416 | 159 | 2.8 | 1.1 | 58 | 0 | +58 | 2 of 11 | 9 of 11 | +54 | +58 |
| Mine | Kingdom of Bretonnia | 1 | 355 | 436 | 5.0 | 1.2 | 87 | 55 | +32 | 3 of 5 | 3 of 5 | +73 | +22 |
| Mine | Lizardmen | 1 | 465 | 1524 | 3.0 | 1.3 | 508 | 0 | +508 | 2 of 3 | 2 of 3 | +290 | +617 |
| Mine | Ogre Kingdoms | 2 | 0 | 202 | 2.0 | 1.2 | 101 | 8 | +93 | 1 of 4 | 2 of 4 | -34 | +135 |
| Mine | Skaven | 2 | 318 | 408 | 1.5 | 1.0 | 272 | 70 | +202 | 1 of 3 | 2 of 3 | - | +202 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 434 | 4.0 | 1.0 | 108 | 24 | +84 | 3 of 8 | 4 of 8 | - | +84 |
| Mine | Vampire Counts | 2 | 188 | 505 | 6.5 | 1.2 | 78 | 25 | +52 | 4 of 13 | 12 of 13 | +304 | +7 |
| Mine | Warriors of Chaos | 2 | 0 | 640 | 6.5 | 1.1 | 98 | 38 | +60 | 4 of 13 | 10 of 13 | +109 | +56 |
| **Mine** | all armies | 36 | 240 | 342 | 3.1 | 1.1 | 112 | 33 | +79 | 34 of 110 | 81 of 110 | +113 | +75 |
| Opponent | Empire of Man | 1 | 468 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 65 | 556 | 4.2 | 1.1 | 132 | 42 | +90 | 9 of 21 | 14 of 21 | -76 | +107 |
| Opponent | Lizardmen | 2 | 82 | 839 | 5.0 | 1.2 | 168 | 33 | +135 | 6 of 10 | 5 of 10 | +190 | +121 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 440 | 5.3 | 1.1 | 82 | 3 | +79 | 3 of 16 | 11 of 16 | +117 | +74 |
| Opponent | Skaven | 4 | 189 | 0 | 1.5 | 1.3 | 0 | 35 | -35 | 4 of 6 | 2 of 6 | +0 | -42 |
| Opponent | Tomb Kings of Khemri | 2 | 132 | 612 | 3.5 | 1.0 | 175 | 0 | +175 | 2 of 7 | 6 of 7 | - | +175 |
| Opponent | Vampire Counts | 6 | 49 | 504 | 4.2 | 1.3 | 121 | 67 | +54 | 15 of 25 | 15 of 25 | +240 | +8 |
| Opponent | Warriors of Chaos | 7 | 0 | 415 | 3.0 | 1.2 | 138 | 50 | +89 | 11 of 21 | 12 of 21 | +213 | +68 |
| Opponent | Wood Elf Realms | 6 | 160 | 522 | 4.5 | 1.1 | 116 | 16 | +100 | 7 of 27 | 18 of 27 | +188 | +89 |
| **Opponent** | all armies | 36 | 90 | 446 | 3.7 | 1.2 | 121 | 35 | +86 | 57 of 133 | 83 of 133 | +159 | +74 |

### Effective charges: ff-off-101d908-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net +240) | 0 | 2 (net +72) | 1 (net +123) | 0 | 2 (net +58) | 2 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 13 | 3 (net +200) | 0 | 0 | 2 (net +0) | 3 (net +36) | 5 (net -34) | 0 | 0% (0 of 13) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0 | 2 (net +107) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 11 | 2 (net +0) | 0 | 2 (net +261) | 3 (net +189) | 1 (net +40) | 2 (net +133) | 1 | 20% (2 of 10) |
| Mine | Grand Cathay | 12 | 0 | 0 | 2 (net +84) | 2 (net -213) | 2 (net +0) | 5 (net +148) | 1 | 18% (2 of 11) |
| Mine | High Elf Realms | 11 | 0 | 0 | 1 (net +0) | 0 | 3 (net +78) | 5 (net +70) | 2 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +45) | 1 (net +0) | 1 (net +41) | 2 (net +36) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 3 | 0 | 0 | 1 (net +979) | 1 (net +290) | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 4 | 1 (net -34) | 0 | 1 (net +350) | 0 | 0 | 1 (net +55) | 1 | 33% (1 of 3) |
| Mine | Skaven | 3 | 2 (net +33) | 0 | 0 | 0 | 0 | 1 (net +540) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 1 (net +56) | 2 (net +58) | 1 (net +250) | 1 (net +60) | 1 (net +75) | 1 | 29% (2 of 7) |
| Mine | Vampire Counts | 13 | 1 (net +0) | 0 | 4 (net +28) | 2 (net +86) | 4 (net +27) | 2 (net +146) | 0 | 31% (4 of 13) |
| Mine | Warriors of Chaos | 13 | 0 | 0 | 1 (net +27) | 4 (net -88) | 3 (net +272) | 4 (net +74) | 1 | 8% (1 of 12) |
| Opponent | High Elf Realms | 21 | 2 (net +0) | 0 | 2 (net +210) | 2 (net -24) | 2 (net +0) | 8 (net +148) | 5 | 12% (2 of 16) |
| Opponent | Lizardmen | 10 | 1 (net +0) | 0 | 0 | 5 (net +145) | 0 | 3 (net +207) | 1 | 0% (0 of 9) |
| Opponent | Orc & Goblin Tribes | 16 | 1 (net +297) | 0 | 0 | 2 (net +0) | 1 (net +49) | 2 (net +117) | 10 | 0% (0 of 6) |
| Opponent | Skaven | 6 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 3 (net -70) | 0 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +199) | 2 (net +321) | 1 (net +112) | 1 (net +0) | 2 | 20% (1 of 5) |
| Opponent | Vampire Counts | 25 | 2 (net -116) | 0 | 4 (net +10) | 9 (net +7) | 2 (net +114) | 7 (net +109) | 1 | 17% (4 of 24) |
| Opponent | Warriors of Chaos | 21 | 4 (net +32) | 0 | 2 (net +40) | 1 (net +499) | 4 (net +77) | 7 (net +159) | 3 | 11% (2 of 18) |
| Opponent | Wood Elf Realms | 27 | 1 (net +0) | 0 | 9 (net +100) | 4 (net +5) | 1 (net +63) | 11 (net +147) | 1 | 35% (9 of 26) |

### Charged fights, damage counted: ff-off-101d908-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 233 | 301 | +85 | 116 | 19 | +97 | +41.6 |
| Mine | 50-54% | 1 | 195 | 201 | +56 | 251 | 195 | +56 | +28.7 |
| Mine | Effective (55-75%) | 19 | 237 | 218 | +129 | 144 | 26 | +118 | +49.9 |
| Mine | 76-89% | 17 | 326 | 274 | +37 | 136 | 116 | +20 | +6.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 226 | 174 | +89 | 146 | 58 | +88 | +39.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 18 | 418 | 89 | +78 | 94 | 5 | +88 | +21.1 |
| Mine | No odds | 10 | 276 | 205 | +24 | 79 | 76 | +3 | +1.2 |
| Mine | All fights | 110 | 280 | 201 | +79 | 127 | 51 | +76 | +27.1 |
| Opponent | Long shot (under 50%) | 11 | 244 | 283 | +17 | 120 | 122 | -2 | -0.6 |
| Opponent | 50-54% | 1 | 440 | 205 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 19 | 269 | 255 | +86 | 121 | 49 | +72 | +26.8 |
| Opponent | 76-89% | 25 | 335 | 232 | +76 | 192 | 94 | +98 | +29.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 | 299 | 199 | +127 | 160 | 40 | +120 | +40.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 418 | 93 | +63 | 69 | 0 | +69 | +16.6 |
| Opponent | No odds | 23 | 324 | 163 | +70 | 104 | 28 | +76 | +23.5 |
| Opponent | All fights | 133 | 313 | 205 | +86 | 138 | 52 | +86 | +27.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-off-101d908-p4 | move | 466 | 110 (24%) | 86 (18%) | 53 (11%) | 303 (65%) |
| ff-off-101d908-p4 | objective | 347 | 46 (13%) | 36 (10%) | 40 (12%) | 261 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Join the parts' records.db (only GameRecords + GameRecordUnits hold rows) into one, ids shifted.
import sqlite3, shutil, sys
out, parts = sys.argv[1], sys.argv[2:]
shutil.copy(parts[0], out); c = sqlite3.connect(out)
for p in parts[1:]:
    c.execute("attach ? as p", (p,))
    off = c.execute("select coalesce(max(Id),0) from GameRecords").fetchone()[0]
    uoff = c.execute("select coalesce(max(Id),0) from GameRecordUnits").fetchone()[0]
    gcols = [r[1] for r in c.execute("pragma table_info(GameRecords)")]
    ucols = [r[1] for r in c.execute("pragma table_info(GameRecordUnits)")]
    gsel = ",".join(f'"{x}"+{off}' if x == "Id" else f'"{x}"' for x in gcols)
    usel = ",".join(f'"{x}"+{uoff}' if x == "Id" else (f'"{x}"+{off}' if x == "GameRecordId" else f'"{x}"') for x in ucols)
    c.execute(f'insert into GameRecords ({",".join(chr(34)+x+chr(34) for x in gcols)}) select {gsel} from p.GameRecords')
    c.execute(f'insert into GameRecordUnits ({",".join(chr(34)+x+chr(34) for x in ucols)}) select {usel} from p.GameRecordUnits')
    c.commit(); c.execute("detach p")
print(out, c.execute("select count(*) from GameRecords").fetchone()[0], "games")

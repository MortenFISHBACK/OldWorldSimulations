#!/bin/bash
# Merge the four parts of one arm into one batch folder compare-batches.py can read: games.csv/plays.csv joined, game files linked.
D=/mnt/project-files/enemy-forecast-2-batch-2026-11-13; OUT=${OUT:-$HOME/ef2-merged}
for arm in mine opp; do
  M=$OUT/ef2-$arm-f5fe7c8-all; rm -rf $M; mkdir -p $M
  first=1
  for n in 1 2 3 4; do
    P=$D/$arm-$n/ef2-$arm-f5fe7c8-p$n
    [ -d $P ] || { echo "missing $P"; continue; }
    for f in games.csv plays.csv; do [ -f $P/$f ] || continue
      if [ $first = 1 ]; then cat $P/$f >> $M/$f; else tail -n +2 $P/$f >> $M/$f; fi; done
    first=0
    ln -s $P/game-* $M/
    for f in commit.txt look-for.md rules-off.txt; do [ -f $P/$f ] && cp $P/$f $M/; done
  done
  python3 $D/compare/merge-records.py $M/records.db $D/$arm-*/ef2-$arm-f5fe7c8-p*/records.db
  echo "$arm: $(($(wc -l < $M/games.csv)-1)) games"
done

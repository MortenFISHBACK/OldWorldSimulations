# Mine predicts vs Opponent predicts

A = Mine predicts: ef2-mine-f5fe7c8-all, 144 of 144 games ended
B = Opponent predicts: ef2-opp-f5fe7c8-all, 144 of 144 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine 1288-675 | Mine 1424-593 | +613 | +831 | -218 | 0.00 | 0.00 |
| L0106 | 4 | 1 | Mine 1864-795 | Mine 1873-730 | +1069 | +1143 | -74 | 0.00 | 0.00 |
| L0110 | 2 | 1 | Opponent 937-1628 | draw 1426-1467 | -691 | -41 | -650 | 0.00 | 0.00 |
| L0114 | 6 | 1 | Opponent 1427-2868 | Opponent 1306-2394 | -1441 | -1088 | -353 | 0.00 | 0.00 |
| L0118 | 4 | 1 | Opponent 748-2447 | Opponent 1180-2005 | -1699 | -825 | -874 | 0.00 | 0.00 |
| L0122 | 2 | 1 | Opponent 848-3195 | Opponent 667-2622 | -2347 | -1955 | -392 | 0.00 | 0.00 |
| L0126 | 6 | 1 | Opponent 955-2012 | Opponent 955-2012 | -1057 | -1057 | +0 | 0.00 | 0.00 |
| L0130 | 4 | 1 | Mine 2210-1107 | Mine 1824-1248 | +1103 | +576 | +527 | 0.00 | 0.00 |
| L0135 | 3 | 1 | draw 1410-1275 | Opponent 479-3800 | +135 | -3321 | +3456 | 0.00 | 0.00 |
| L0206 | 2 | 1 | Opponent 170-2164 | Opponent 440-1721 | -1994 | -1281 | -713 | 0.00 | 0.00 |
| L0210 | 6 | 1 | draw 1594-1612 | Opponent 890-1555 | -18 | -665 | +647 | 0.00 | 0.00 |
| L0214 | 4 | 1 | Mine 1471-996 | Mine 2005-1006 | +475 | +999 | -524 | 0.00 | 0.00 |
| L0218 | 2 | 1 | Mine 1366-507 | draw 1090-811 | +859 | +279 | +580 | 0.00 | 0.00 |
| L0222 | 6 | 1 | Mine 2085-1244 | Mine 1639-943 | +841 | +696 | +145 | 0.00 | 0.00 |
| L0226 | 4 | 1 | Opponent 610-2287 | Opponent 1115-1581 | -1677 | -466 | -1211 | 0.00 | 0.00 |
| L0230 | 2 | 1 | Opponent 368-1018 | Mine 1158-816 | -650 | +342 | -992 | 0.00 | 0.00 |
| L0235 | 1 | 1 | draw 1572-1705 | draw 1421-1583 | -133 | -162 | +29 | 0.00 | 0.00 |
| L0307 | 1 | 1 | Opponent 290-2071 | Mine 1816-1335 | -1781 | +481 | -2262 | 0.00 | 0.00 |
| L0311 | 5 | 1 | Mine 1819-825 | draw 1536-1245 | +994 | +291 | +703 | 0.00 | 0.00 |
| L0315 | 3 | 1 | Opponent 1420-2178 | Opponent 879-2056 | -758 | -1177 | +419 | 0.00 | 0.00 |
| L0319 | 1 | 1 | Opponent 1090-1866 | Mine 1939-1331 | -776 | +608 | -1384 | 0.00 | 0.00 |
| L0323 | 5 | 1 | Opponent 1196-2178 | Opponent 596-2689 | -982 | -2093 | +1111 | 0.00 | 0.00 |
| L0327 | 3 | 1 | Opponent 731-2104 | Mine 2093-835 | -1373 | +1258 | -2631 | 0.00 | 0.00 |
| L0332 | 2 | 1 | Opponent 1005-1702 | Opponent 937-1403 | -697 | -466 | -231 | 0.00 | 0.00 |
| L0405 | 3 | 1 | Mine 2543-776 | Mine 2665-1047 | +1767 | +1618 | +149 | 0.00 | 0.00 |
| L0409 | 1 | 1 | draw 2111-2263 | draw 2097-1930 | -152 | +167 | -319 | 0.00 | 0.00 |
| L0413 | 5 | 1 | draw 1165-946 | Mine 1548-150 | +219 | +1398 | -1179 | 0.00 | 0.00 |
| L0417 | 3 | 1 | Opponent 1695-2005 | Opponent 365-2460 | -310 | -2095 | +1785 | 0.00 | 0.00 |
| L0421 | 1 | 1 | Mine 2250-1003 | Mine 3108-610 | +1247 | +2498 | -1251 | 0.00 | 0.00 |
| L0425 | 5 | 1 | Mine 2854-150 | Mine 2803-460 | +2704 | +2343 | +361 | 0.00 | 0.00 |
| L0429 | 3 | 1 | Opponent 544-1731 | draw 1589-1292 | -1187 | +297 | -1484 | 0.00 | 0.00 |
| L0434 | 2 | 1 | Opponent 758-2041 | Mine 2130-465 | -1283 | +1665 | -2948 | 0.00 | 0.00 |
| L0508 | 4 | 1 | Mine 2033-1034 | Opponent 910-1832 | +999 | -922 | +1921 | 0.00 | 0.00 |
| L0512 | 2 | 1 | Mine 1609-874 | Mine 1418-830 | +735 | +588 | +147 | 0.00 | 0.00 |
| L0516 | 6 | 1 | Mine 1203-851 | draw 1043-1084 | +352 | -41 | +393 | 0.00 | 0.00 |
| L0520 | 4 | 1 | Opponent 1110-2137 | Opponent 901-1727 | -1027 | -826 | -201 | 0.00 | 0.00 |
| L0524 | 2 | 1 | draw 1313-1157 | Opponent 410-1194 | +156 | -784 | +940 | 0.00 | 0.00 |
| L0528 | 6 | 1 | Mine 1840-1148 | Mine 1749-945 | +692 | +804 | -112 | 0.00 | 0.00 |
| L0533 | 5 | 1 | Mine 1288-490 | Mine 1139-445 | +798 | +694 | +104 | 0.00 | 0.00 |
| L0608 | 2 | 1 | Opponent 591-1640 | Opponent 439-2453 | -1049 | -2014 | +965 | 0.00 | 0.00 |
| L0612 | 6 | 1 | draw 1315-1396 | Mine 1793-1347 | -81 | +446 | -527 | 0.00 | 0.00 |
| L0616 | 4 | 1 | Opponent 1101-2029 | Mine 1588-930 | -928 | +658 | -1586 | 0.00 | 0.00 |
| L0620 | 2 | 1 | Opponent 873-1633 | draw 1083-1193 | -760 | -110 | -650 | 0.00 | 0.00 |
| L0624 | 6 | 1 | Opponent 632-1048 | Mine 2009-710 | -416 | +1299 | -1715 | 0.00 | 0.00 |
| L0628 | 4 | 1 | Mine 1640-1334 | Mine 1763-908 | +306 | +855 | -549 | 0.00 | 0.00 |
| L0632 | 2 | 1 | Opponent 656-2390 | Opponent 1227-1749 | -1734 | -522 | -1212 | 0.00 | 0.00 |
| L0709 | 1 | 1 | draw 1822-1699 | Opponent 983-1918 | +123 | -935 | +1058 | 0.00 | 0.00 |
| L0713 | 5 | 1 | draw 1357-1190 | Opponent 974-1481 | +167 | -507 | +674 | 0.00 | 0.00 |
| L0717 | 3 | 1 | Opponent 1618-2708 | Mine 2362-1257 | -1090 | +1105 | -2195 | 0.00 | 0.00 |
| L0721 | 1 | 1 | Mine 2230-1789 | Mine 2266-1156 | +441 | +1110 | -669 | 0.00 | 0.00 |
| L0725 | 5 | 1 | Opponent 549-919 | Opponent 723-1069 | -370 | -346 | -24 | 0.00 | 0.00 |
| L0729 | 3 | 1 | Opponent 303-2739 | Mine 3319-172 | -2436 | +3147 | -5583 | 0.00 | 0.00 |
| L0733 | 1 | 1 | Mine 1905-1071 | Mine 2069-1151 | +834 | +918 | -84 | 0.00 | 0.00 |
| L0810 | 6 | 1 | Mine 1826-1364 | Opponent 368-2474 | +462 | -2106 | +2568 | 0.00 | 0.00 |
| L0815 | 5 | 1 | Opponent 800-1635 | Opponent 774-1947 | -835 | -1173 | +338 | 0.00 | 0.00 |
| L0819 | 3 | 1 | Mine 2471-1385 | Opponent 1275-1764 | +1086 | -489 | +1575 | 0.00 | 0.00 |
| L0823 | 1 | 1 | Opponent 1801-2366 | Opponent 561-3687 | -565 | -3126 | +2561 | 0.00 | 0.00 |
| L0827 | 5 | 1 | Opponent 616-1262 | Opponent 934-1619 | -646 | -685 | +39 | 0.00 | 0.00 |
| L0831 | 3 | 1 | Mine 1982-527 | Mine 2056-747 | +1455 | +1309 | +146 | 0.00 | 0.00 |
| L0835 | 1 | 1 | Opponent 626-2556 | Opponent 335-2777 | -1930 | -2442 | +512 | 0.00 | 0.00 |
| L0913 | 1 | 1 | Mine 2149-832 | Mine 2510-1479 | +1317 | +1031 | +286 | 0.00 | 0.00 |
| L0918 | 6 | 1 | Mine 1720-835 | draw 1315-1581 | +885 | -266 | +1151 | 0.00 | 0.00 |
| L0922 | 4 | 1 | Opponent 609-2905 | Opponent 342-3290 | -2296 | -2948 | +652 | 0.00 | 0.00 |
| L0926 | 2 | 1 | Opponent 595-1816 | Opponent 185-2772 | -1221 | -2587 | +1366 | 0.00 | 0.00 |
| L0930 | 6 | 1 | Opponent 1088-2188 | Opponent 1187-1611 | -1100 | -424 | -676 | 0.00 | 0.00 |
| L0934 | 4 | 1 | Opponent 1334-2534 | Opponent 265-3495 | -1200 | -3230 | +2030 | 0.00 | 0.00 |
| L1013 | 5 | 1 | Mine 2949-900 | Mine 2653-550 | +2049 | +2103 | -54 | 0.00 | 0.00 |
| L1017 | 3 | 1 | Mine 2118-1381 | draw 1368-1602 | +737 | -234 | +971 | 0.00 | 0.00 |
| L1021 | 1 | 1 | Mine 2430-890 | Mine 3483-300 | +1540 | +3183 | -1643 | 0.00 | 0.00 |
| L1026 | 6 | 1 | Opponent 969-1527 | draw 1114-950 | -558 | +164 | -722 | 0.00 | 0.00 |
| L1030 | 4 | 1 | Mine 1617-1281 | Opponent 971-1872 | +336 | -901 | +1237 | 0.00 | 0.00 |
| L1034 | 2 | 1 | Opponent 951-1457 | Mine 1190-629 | -506 | +561 | -1067 | 0.00 | 0.00 |
| L1114 | 4 | 1 | Opponent 827-2542 | Mine 2871-670 | -1715 | +2201 | -3916 | 0.00 | 0.00 |
| L1118 | 2 | 1 | Opponent 1064-2145 | Mine 3112-572 | -1081 | +2540 | -3621 | 0.00 | 0.00 |
| L1122 | 6 | 1 | Mine 1403-970 | Opponent 372-2338 | +433 | -1966 | +2399 | 0.00 | 0.00 |
| L1126 | 4 | 1 | Opponent 1195-1787 | draw 1030-857 | -592 | +173 | -765 | 0.00 | 0.00 |
| L1131 | 3 | 1 | Mine 2232-550 | Mine 2564-190 | +1682 | +2374 | -692 | 0.00 | 0.00 |
| L1135 | 1 | 1 | Mine 2236-1720 | Opponent 734-2099 | +516 | -1365 | +1881 | 0.00 | 0.00 |
| L1216 | 4 | 1 | draw 2006-1721 | Mine 2755-479 | +285 | +2276 | -1991 | 0.00 | 0.00 |
| L1220 | 2 | 1 | Mine 1909-600 | Mine 2140-734 | +1309 | +1406 | -97 | 0.00 | 0.00 |
| L1224 | 6 | 1 | draw 1059-1103 | Opponent 1064-1681 | -44 | -617 | +573 | 0.00 | 0.00 |
| L1228 | 4 | 1 | Mine 2349-430 | Mine 2011-527 | +1919 | +1484 | +435 | 0.00 | 0.00 |
| L1232 | 2 | 1 | Mine 1209-734 | Opponent 137-1194 | +475 | -1057 | +1532 | 0.00 | 0.00 |
| L1314 | 6 | 1 | Opponent 1004-1849 | draw 1656-1440 | -845 | +216 | -1061 | 0.00 | 0.00 |
| L1319 | 5 | 1 | Opponent 1243-2287 | Opponent 495-2343 | -1044 | -1848 | +804 | 0.00 | 0.00 |
| L1323 | 3 | 1 | Opponent 873-2277 | Opponent 635-3040 | -1404 | -2405 | +1001 | 0.00 | 0.00 |
| L1327 | 1 | 1 | Opponent 1517-1871 | Mine 1677-972 | -354 | +705 | -1059 | 0.00 | 0.00 |
| L1331 | 5 | 1 | Mine 1952-250 | Mine 1740-497 | +1702 | +1243 | +459 | 0.00 | 0.00 |
| L1335 | 3 | 1 | Mine 2237-821 | draw 1653-1795 | +1416 | -142 | +1558 | 0.00 | 0.00 |
| L1418 | 2 | 1 | draw 1367-1573 | Mine 1524-574 | -206 | +950 | -1156 | 0.00 | 0.00 |
| L1422 | 6 | 1 | Mine 1848-1273 | Mine 2710-731 | +575 | +1979 | -1404 | 0.00 | 0.00 |
| L1427 | 5 | 1 | Opponent 865-1386 | draw 997-1072 | -521 | -75 | -446 | 0.00 | 0.00 |
| L1431 | 3 | 1 | Mine 1948-1572 | Mine 2664-748 | +376 | +1916 | -1540 | 0.00 | 0.00 |
| L1435 | 1 | 1 | Opponent 1440-2543 | Opponent 495-2301 | -1103 | -1806 | +703 | 0.00 | 0.00 |
| L1519 | 1 | 1 | Mine 1130-724 | Mine 1885-336 | +406 | +1549 | -1143 | 0.00 | 0.00 |
| L1523 | 5 | 1 | Opponent 456-2603 | draw 1158-1321 | -2147 | -163 | -1984 | 0.00 | 0.00 |
| L1527 | 3 | 1 | Opponent 578-1563 | draw 1288-1520 | -985 | -232 | -753 | 0.00 | 0.00 |
| L1531 | 1 | 1 | Mine 2029-785 | Opponent 520-2903 | +1244 | -2383 | +3627 | 0.00 | 0.00 |
| L1535 | 5 | 1 | Mine 2158-148 | Opponent 1183-2204 | +2010 | -1021 | +3031 | 0.00 | 0.00 |
| L1621 | 1 | 1 | Mine 1824-1433 | Opponent 1535-2381 | +391 | -846 | +1237 | 0.00 | 0.00 |
| L1625 | 5 | 1 | Mine 2650-903 | Mine 2535-650 | +1747 | +1885 | -138 | 0.00 | 0.00 |
| L1629 | 3 | 1 | draw 1899-2048 | Opponent 537-2488 | -149 | -1951 | +1802 | 0.00 | 0.00 |
| L1633 | 1 | 1 | Mine 1592-888 | Opponent 921-1542 | +704 | -621 | +1325 | 0.00 | 0.00 |
| L1719 | 3 | 1 | Mine 2703-1393 | Mine 3103-988 | +1310 | +2115 | -805 | 0.00 | 0.00 |
| L1723 | 1 | 1 | Mine 2990-655 | draw 1786-1802 | +2335 | -16 | +2351 | 0.00 | 0.00 |
| L1727 | 5 | 1 | Mine 1356-558 | draw 1256-1134 | +798 | +122 | +676 | 0.00 | 0.00 |
| L1731 | 3 | 1 | Opponent 1342-1959 | Mine 2964-1224 | -617 | +1740 | -2357 | 0.00 | 0.00 |
| L1819 | 1 | 1 | Opponent 520-2152 | Opponent 645-2131 | -1632 | -1486 | -146 | 0.00 | 0.00 |
| L1823 | 5 | 1 | Opponent 286-1333 | Opponent 452-2547 | -1047 | -2095 | +1048 | 0.00 | 0.00 |
| L1827 | 3 | 1 | Opponent 731-2064 | Opponent 939-2942 | -1333 | -2003 | +670 | 0.00 | 0.00 |
| L1831 | 1 | 1 | draw 1770-1536 | draw 1897-1801 | +234 | +96 | +138 | 0.00 | 0.00 |
| L1835 | 5 | 1 | Opponent 489-1946 | Opponent 638-1124 | -1457 | -486 | -971 | 0.00 | 0.00 |
| L1923 | 3 | 1 | Opponent 547-3090 | Opponent 1336-2270 | -2543 | -934 | -1609 | 0.00 | 0.00 |
| L1927 | 1 | 1 | Mine 2130-1695 | Opponent 871-2245 | +435 | -1374 | +1809 | 0.00 | 0.00 |
| L1932 | 6 | 1 | draw 1286-1244 | Opponent 560-1785 | +42 | -1225 | +1267 | 0.00 | 0.00 |
| L2021 | 5 | 1 | Opponent 835-1218 | draw 1239-1015 | -383 | +224 | -607 | 0.00 | 0.00 |
| L2025 | 3 | 1 | Mine 2605-837 | Opponent 1529-2044 | +1768 | -515 | +2283 | 0.00 | 0.00 |
| L2029 | 1 | 1 | Opponent 530-3041 | Opponent 725-2973 | -2511 | -2248 | -263 | 0.00 | 0.00 |
| L2033 | 5 | 1 | Opponent 1110-2111 | draw 1084-893 | -1001 | +191 | -1192 | 0.00 | 0.00 |
| L2123 | 5 | 1 | Opponent 650-2189 | Opponent 320-2971 | -1539 | -2651 | +1112 | 0.00 | 0.00 |
| L2127 | 3 | 1 | Opponent 300-3482 | Opponent 1046-2776 | -3182 | -1730 | -1452 | 0.00 | 0.00 |
| L2131 | 1 | 1 | Opponent 280-2789 | Opponent 261-3338 | -2509 | -3077 | +568 | 0.00 | 0.00 |
| L2223 | 3 | 1 | Opponent 991-1653 | Opponent 1559-1994 | -662 | -435 | -227 | 0.00 | 0.00 |
| L2227 | 1 | 1 | Opponent 1047-1541 | Mine 2283-1048 | -494 | +1235 | -1729 | 0.00 | 0.00 |
| L2231 | 5 | 1 | Opponent 1043-1958 | draw 891-1015 | -915 | -124 | -791 | 0.00 | 0.00 |
| L2235 | 3 | 1 | Mine 2776-527 | draw 1659-1948 | +2249 | -289 | +2538 | 0.00 | 0.00 |
| L2327 | 5 | 1 | draw 878-1124 | Opponent 1113-1439 | -246 | -326 | +80 | 0.00 | 0.00 |
| L2331 | 3 | 1 | draw 1443-1228 | Mine 2380-642 | +215 | +1738 | -1523 | 0.00 | 0.00 |
| L2335 | 1 | 1 | Mine 2251-936 | Mine 2222-716 | +1315 | +1506 | -191 | 0.00 | 0.00 |
| L2429 | 5 | 1 | Opponent 0-3113 | Opponent 103-2936 | -3113 | -2833 | -280 | 0.00 | 0.00 |
| L2433 | 3 | 1 | Mine 2114-1349 | Mine 1566-786 | +765 | +780 | -15 | 0.00 | 0.00 |
| L2527 | 1 | 1 | draw 1605-1398 | draw 991-874 | +207 | +117 | +90 | 0.00 | 0.00 |
| L2531 | 5 | 1 | draw 1153-935 | Mine 1262-395 | +218 | +867 | -649 | 0.00 | 0.00 |
| L2535 | 3 | 1 | Opponent 972-2229 | Opponent 682-2496 | -1257 | -1814 | +557 | 0.00 | 0.00 |
| L2630 | 2 | 1 | Opponent 1353-2680 | Mine 1885-495 | -1327 | +1390 | -2717 | 0.00 | 0.00 |
| L2634 | 6 | 1 | Mine 1750-814 | Mine 2138-504 | +936 | +1634 | -698 | 0.00 | 0.00 |
| L2730 | 6 | 1 | Opponent 395-1714 | Mine 1469-831 | -1319 | +638 | -1957 | 0.00 | 0.00 |
| L2735 | 5 | 1 | Mine 1257-739 | Opponent 692-1753 | +518 | -1061 | +1579 | 0.00 | 0.00 |
| L2832 | 6 | 1 | draw 350-572 | Opponent 410-2920 | -222 | -2510 | +2288 | 0.00 | 0.00 |
| L2930 | 2 | 1 | Mine 1510-1075 | Opponent 1207-1544 | +435 | -337 | +772 | 0.00 | 0.00 |
| L2934 | 6 | 1 | Opponent 896-1253 | Mine 1867-750 | -357 | +1117 | -1474 | 0.00 | 0.00 |
| L3033 | 3 | 1 | Mine 1745-1082 | Mine 2270-1003 | +663 | +1267 | -604 | 0.00 | 0.00 |
| L3133 | 1 | 1 | Opponent 1397-1739 | Opponent 369-1992 | -342 | -1623 | +1281 | 0.00 | 0.00 |
| L3234 | 6 | 1 | Mine 1451-826 | Mine 2108-552 | +625 | +1556 | -931 | 0.00 | 0.00 |

## Totals

| | A: Mine predicts | B: Opponent predicts |
| --- | --- | --- |
| Mine won / drew / lost | 56 / 20 / 68 | 56 / 25 / 63 |
| Mean margin (Mine - Opponent) | -168 | -106 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 550 | 563 |
| VP from objectives, Opponent | 603 | 595 |
| VP from kills, Mine | 768 | 781 |
| VP from kills, Opponent | 859 | 830 |
| VP from leaders, Mine | 48 | 47 |
| VP from leaders, Opponent | 72 | 72 |
| VP from other, Mine | 1 | 1 |
| VP from other, Opponent | 2 | 1 |
| Units lost, Mine | 5.3 | 5.2 |
| Units lost, Opponent | 4.8 | 4.8 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 30% | 27% |
| Scorecard: Lone holders (player turns) (both sides) | 2.6 | 2.5 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.5 | 2.5 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 2.8 | 2.8 |
| Scorecard: Idle units (both sides) | 1.5 | 1.5 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.3 | 0.4 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 232.4 | 233.0 |

## Is the difference more than noise?

144 pairs of games: A's margin is -62 VP a game against B's, give or take 241 VP (two standard errors). Verdict: within noise (could be chance).

## KPIs (Morten 2026-11-10)

A = Mine predicts (144 games), B = Opponent predicts (144 games).

| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 95%; on the table 96% | 99%; on the table 99% | 97%; on the table 97% | 97%; on the table 98% | 97%; on the table 99% | 97%; on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 85%; on the table 87% | 86%; on the table 90% | 86%; on the table 89% | 90%; on the table 90% | 94%; on the table 94% | 92%; on the table 92% |
| Winner chose to pursue after the loser fled |  | 79%; on the table 82% | 73%; on the table 77% | 75%; on the table 79% | 73%; on the table 81% | 76%; on the table 83% | 75%; on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 90%; on the table 91% | 88%; on the table 90% | 89%; on the table 90% | 89%; on the table 92% | 89%; on the table 92% | 89%; on the table 92% |
| Magic missiles tried each own turn | 50%+ | 28% | 32% | 30% | 27% | 29% | 28% |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% | 45% | 43% | 40% | 42% | 41% |
| Points that never fought | lower | 34% | 36% | 35% | 35% | 36% | 36% |
|   infantry points that never fought | lower | 39% | 57% | 48% | 46% | 56% | 51% |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% | 57% | 57% | 59% | 58% | 59% |
| Bound items with a magic missile used (at least once a game) |  | 92% | 85% | 89% | 90% | 85% | 88% |
| Bound items with another spell used |  | 53% | 56% | 54% | 58% | 50% | 55% |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% | 52% | 55% | 58% | 46% | 53% |
|   their share of the points of units over 100 pts | lower | 52% | 49% | 51% | 53% | 51% | 52% |

Flank and rear charges a unit could have turned to face (the side is the charged unit's):

| Measure | Mine predicts Mine | Mine predicts Opponent | Opponent predicts Mine | Opponent predicts Opponent |
| --- | --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (183) | 52% (158) | 51% (184) | 50% (141) |
| ...free all their last turn and able to turn (per game) | 0.77 | 0.68 | 0.79 | 0.66 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.24 | 0.15 | 0.24 | 0.12 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.47 | 0.54 | 0.39 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.24 | 0.93 | 1.34 | 0.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.59 | 0.59 | 0.64 | 0.60 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.64 | 7.77 | 7.58 | 7.38 |

### Charges a game and per unit by the wizard it carries

| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.2 | 5.2 | 4.4 | 5.9 | 5.1 |
| Charges that made contact a game | 3.2 | 4.3 | 3.7 | 3.2 | 4.2 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.90 declared, 0.66 contact (89 units) | 0.84 declared, 0.56 contact (64 units) | 0.88 declared, 0.62 contact (153 units) | 0.84 declared, 0.72 contact (89 units) | 0.77 declared, 0.56 contact (66 units) | 0.81 declared, 0.65 contact (155 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.08 declared, 0.85 contact (26 units) | 1.39 declared, 1.05 contact (44 units) | 1.27 declared, 0.97 contact (70 units) | 0.78 declared, 0.56 contact (27 units) | 1.22 declared, 0.93 contact (46 units) | 1.05 declared, 0.79 contact (73 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.38 contact (975 units) | 0.67 declared, 0.47 contact (1144 units) | 0.60 declared, 0.43 contact (2119 units) | 0.55 declared, 0.39 contact (973 units) | 0.65 declared, 0.46 contact (1147 units) | 0.60 declared, 0.43 contact (2120 units) |

## Movement (Morten 2026-11-11)

A = Mine predicts (144 games), B = Opponent predicts (144 games); per side and game.

| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Games where this side made the first charge contact | 44% (64 of 144) | 56% (80 of 144) | 50% (144 of 288) | 44% (63 of 144) | 56% (81 of 144) | 50% (144 of 288) |
| Round of a side's first charge contact (sides that made one) | 2.6 | 2.4 | 2.5 | 2.7 | 2.5 | 2.6 |
| Sides that never declared a charge | 6% (9 of 144) | 2% (3 of 144) | 4% (12 of 288) | 7% (10 of 144) | 2% (3 of 144) | 5% (13 of 288) |
| Sides that never made charge contact | 12% (17 of 144) | 6% (8 of 144) | 9% (25 of 288) | 13% (19 of 144) | 4% (6 of 144) | 9% (25 of 288) |
| Charges declared a game | 4.3 | 6.1 | 5.2 | 4.5 | 5.8 | 5.1 |
| Charge contacts made a game | 3.2 | 4.2 | 3.7 | 3.3 | 4.2 | 3.7 |
| Charge contacts received a game | 4.2 | 3.2 | 3.7 | 4.2 | 3.3 | 3.7 |
| Joint charges a game (2+ units on one target in one turn) | 0.3 | 0.5 | 0.4 | 0.4 | 0.5 | 0.5 |
|   share of charged targets hit by 2+ units | 9% (39 of 426) | 14% (74 of 514) | 12% (113 of 940) | 14% (56 of 409) | 15% (76 of 517) | 14% (132 of 926) |
| Lone charges that a friend follows on the same target next turn | 8% (30 of 387) | 7% (31 of 440) | 7% (61 of 827) | 5% (17 of 353) | 7% (33 of 441) | 6% (50 of 794) |
| Set-ups (close in to charge next turn) that charged that target next turn | 17% (99 of 592) | 15% (121 of 795) | 16% (220 of 1387) | 15% (95 of 644) | 14% (108 of 767) | 14% (203 of 1411) |
|   ... and made contact | 13% (78 of 592) | 11% (90 of 795) | 12% (168 of 1387) | 11% (74 of 644) | 10% (79 of 767) | 11% (153 of 1411) |
|   ... with a friend on it too | 3% (20 of 592) | 3% (27 of 795) | 3% (47 of 1387) | 2% (14 of 644) | 4% (27 of 767) | 3% (41 of 1411) |
| Set-ups missed (no charge on that target next turn) | 83% (493 of 592) | 85% (674 of 795) | 84% (1167 of 1387) | 85% (549 of 644) | 86% (659 of 767) | 86% (1208 of 1411) |
| Charge contacts in the flank or rear (arc known) | 52% (242 of 467) | 48% (290 of 603) | 50% (532 of 1070) | 50% (233 of 469) | 52% (315 of 603) | 51% (548 of 1072) |
|   in the rear | 11% (50 of 467) | 12% (71 of 603) | 11% (121 of 1070) | 9% (43 of 469) | 10% (59 of 603) | 10% (102 of 1072) |
| Declared charges in the flank or rear (arc known) | 50% (309 of 624) | 51% (443 of 872) | 50% (752 of 1496) | 48% (307 of 643) | 51% (427 of 839) | 50% (734 of 1482) |

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: Mine predicts

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 3 | 3 | 0 | 0 | 0 | 0 | 0 | 387 |
| L0102 | 6 | 1 | Opponent | no | 3 | 4 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Mine | no | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 1109 |
| L0110 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0114 | 6 | 1 | Mine | no | 13 | 6 | 1 | 2 | 1 | 0 | 0 | 350 |
| L0114 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 123 |
| L0118 | 4 | 1 | Mine | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 95 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 6 | - | 0 | 0 | 1 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 322 |
| L0135 | 3 | 1 | Opponent | no | 4 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0210 | 6 | 1 | Mine | no | 4 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0214 | 4 | 1 | Mine | yes | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | yes | 2 | 1 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 3 | 6 | 0 | 0 | 0 | 81 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 5 | 2 | 1 | 3 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0311 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 526 |
| L0315 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 8 | 3 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 140 |
| L0327 | 3 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 1 | 0 | 0 | 709 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 5 | 2 | 1 | 0 | 0 | 170 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 1019 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 12 | 4 | 1 | 0 | 0 | 0 | 0 | 1122 |
| L0413 | 5 | 1 | Mine | yes | - | 3 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 479 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 135 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 4 | 2 | 0 | 0 | 447 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 2 | 0 | 0 | 348 |
| L0429 | 3 | 1 | Mine | yes | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0508 | 4 | 1 | Mine | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 605 |
| L0512 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 686 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L0516 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 686 |
| L0516 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 200 |
| L0520 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 771 |
| L0520 | 4 | 1 | Opponent | no | 2 | 4 | 0 | 5 | 0 | 0 | 0 | 420 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 889 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 970 |
| L0528 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 351 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0612 | 6 | 1 | Mine | no | 3 | - | 3 | 2 | 1 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 6 | 2 | 4 | 1 | 0 | 0 | 95 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 743 |
| L0624 | 6 | 1 | Opponent | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 1292 |
| L0628 | 4 | 1 | Opponent | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 524 |
| L0713 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 302 |
| L0717 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 224 |
| L0721 | 1 | 1 | Mine | yes | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 4 | 1 | 0 | 0 | 290 |
| L0725 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 2 | 1 | 0 | 1 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Mine | no | 5 | 5 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0810 | 6 | 1 | Mine | no | 9 | 3 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 19 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0815 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 605 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 3 | 2 | 0 | 0 | 226 |
| L0823 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 66 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 435 |
| L0827 | 5 | 1 | Opponent | yes | - | 1 | 4 | 6 | 0 | 0 | 0 | 60 |
| L0831 | 3 | 1 | Mine | yes | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 170 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 717 |
| L0835 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 1 | 0 | 0 | 140 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 1 | 0 | 0 | 234 |
| L0922 | 4 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 515 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 677 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 1 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 2 | 1 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 4 | 0 | 0 | 0 | 216 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 3 | 0 | 0 | 317 |
| L1017 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 5 | 1 | 7 | 2 | 0 | 0 | 0 | 175 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 5 | - | 2 | 4 | 1 | 0 | 0 | 355 |
| L1026 | 6 | 1 | Mine | no | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 627 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 251 |
| L1122 | 6 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 242 |
| L1126 | 4 | 1 | Mine | no | 4 | 6 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 4 | - | 4 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | 4 | 3 | 0 | 2 | 0 | 0 | 170 |
| L1135 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 158 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 2 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 260 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 715 |
| L1224 | 6 | 1 | Mine | no | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 9 | 6 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 1 | 4 | 3 | 1 | 0 | 0 | 170 |
| L1314 | 6 | 1 | Mine | no | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 7 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 3 | 3 | 0 | 0 | 0 | 317 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 132 |
| L1327 | 1 | 1 | Mine | no | 6 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 5 | 0 | 0 | 0 | 50 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 1 | 4 | 0 | 0 | 340 |
| L1335 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 177 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 3 | 1 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | yes | 2 | - | 1 | 1 | 1 | 0 | 0 | 170 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 3 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 60 |
| L1527 | 3 | 1 | Mine | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 639 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 475 |
| L1621 | 1 | 1 | Opponent | no | 0 | 5 | 0 | 2 | 0 | 0 | 0 | 290 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 7 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 170 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 144 |
| L1719 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 490 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 8 | 0 | 0 | 0 | 0 | 49 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 98 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 5 | 4 | 0 | 0 | 0 | 60 |
| L1731 | 3 | 1 | Mine | no | 1 | 4 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 340 |
| L1819 | 1 | 1 | Mine | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Mine | no | 10 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 305 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 140 |
| L1923 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 226 |
| L1927 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 60 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 1 | 0 | 0 | 340 |
| L2021 | 5 | 1 | Mine | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 5 | 3 | 0 | 0 | 0 | 145 |
| L2025 | 3 | 1 | Mine | yes | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | yes | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 207 |
| L2033 | 5 | 1 | Mine | no | - | - | 1 | 7 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | - | 0 | 5 | 1 | 0 | 0 | 405 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 6 | 1 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 0 | 2 | 1 | 0 | 0 | 420 |
| L2127 | 3 | 1 | Opponent | yes | 11 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 2 | 2 | 0 | 3 | 1 | 0 | 0 | 787 |
| L2131 | 1 | 1 | Opponent | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 332 |
| L2223 | 3 | 1 | Opponent | no | 4 | 1 | 6 | 0 | 1 | 0 | 0 | 185 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 1 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | yes | 5 | - | 1 | 0 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 132 |
| L2335 | 1 | 1 | Opponent | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | - | 5 | 0 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 4 | 5 | 0 | 0 | 0 | 170 |
| L2433 | 3 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 236 |
| L2527 | 1 | 1 | Mine | yes | 4 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 3 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 68 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 519 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 163 |
| L2730 | 6 | 1 | Mine | no | 0 | - | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 140 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 207 |
| L2934 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 1 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 6 | 2 | 2 | 1 | 0 | 0 | 120 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 334 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 35% | 2.8 | 2.7 | 2.5 | 1.2 | 0.3 | 0.0 | 0.0 | 301.8 |
| **Average** | | | Opponent | 25% | 2.4 | 2.4 | 3.0 | 1.9 | 0.4 | 0.0 | 0.0 | 162.9 |

### Scorecard: Opponent predicts

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | 5 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 2 | 1 | 1 | 7 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 377 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 1011 |
| L0110 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 95 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0114 | 6 | 1 | Mine | no | 11 | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 5 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 4 | 1 | 0 | 0 | 302 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 55 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 9 | 3 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | yes | 3 | - | 0 | 1 | 0 | 0 | 0 | 639 |
| L0135 | 3 | 1 | Opponent | yes | 4 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0210 | 6 | 1 | Mine | no | 4 | 3 | 0 | 6 | 1 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0214 | 4 | 1 | Mine | yes | 5 | - | 1 | 6 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 81 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 2 | - | 2 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 2 | 1 | 0 | 0 | 0 | 330 |
| L0315 | 3 | 1 | Mine | no | 1 | 6 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 3 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 140 |
| L0327 | 3 | 1 | Mine | yes | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 2 | - | 1 | 3 | 2 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 13 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 1120 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 3 | 0 | 2 | 1 | 0 | 0 | 140 |
| L0417 | 3 | 1 | Mine | no | 2 | 2 | 9 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 285 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 1 | 0 | 0 | 516 |
| L0429 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 2 | 0 | 0 | 170 |
| L0434 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 115 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 698 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0512 | 2 | 1 | Mine | - | - | 5 | 4 | 2 | 0 | 0 | 0 | 548 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0516 | 6 | 1 | Mine | no | 5 | 6 | 1 | 1 | 0 | 0 | 0 | 771 |
| L0516 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 280 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 1258 |
| L0520 | 4 | 1 | Opponent | no | 5 | - | 0 | 2 | 2 | 0 | 0 | 210 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 771 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | no | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 678 |
| L0528 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 5 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 0 | 5 | 1 | 0 | 0 | 0 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 4 | 1 | 2 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 1 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 139 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 3 | 6 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 1 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 479 |
| L0717 | 3 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 2 | 0 | 0 | 175 |
| L0721 | 1 | 1 | Mine | yes | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 290 |
| L0725 | 5 | 1 | Mine | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | yes | 6 | 1 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Mine | no | 4 | 5 | 2 | 1 | 1 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 108 |
| L0810 | 6 | 1 | Mine | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 805 |
| L0819 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 60 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 753 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 11 | 2 | 3 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 4 | 2 | 0 | 0 | 170 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 8 | - | 1 | 0 | 0 | 0 | 0 | 140 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 8 | 2 | 5 | 3 | 0 | 0 | 0 | 234 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 515 |
| L0922 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 55 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 560 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 1 | 4 | 2 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 736 |
| L0934 | 4 | 1 | Opponent | yes | 0 | 2 | 8 | 4 | 0 | 0 | 0 | 160 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 4 | 2 | 0 | 2 | 0 | 0 | 302 |
| L1017 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 5 | 1 | 5 | 2 | 1 | 0 | 0 | 175 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 577 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 623 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1030 | 4 | 1 | Mine | no | 2 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 2 | 0 | 0 | 562 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 1 | - | 1 | 1 | 1 | 0 | 0 | 200 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 2 | 4 | 6 | 1 | 0 | 0 | 210 |
| L1224 | 6 | 1 | Mine | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 524 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 351 |
| L1232 | 2 | 1 | Mine | - | - | 6 | 0 | 0 | 0 | 0 | 0 | 498 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 317 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 123 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 2 | 3 | 2 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 132 |
| L1327 | 1 | 1 | Mine | no | 18 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 5 | 1 | 0 | 0 | 50 |
| L1331 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 1 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | 3 | 1 | 4 | 0 | 0 | 0 | 286 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 158 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 2 | 0 | 0 | 297 |
| L1422 | 6 | 1 | Mine | no | 11 | 2 | 7 | 0 | 0 | 0 | 0 | 123 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 2 | 3 | 0 | 0 | 562 |
| L1435 | 1 | 1 | Mine | no | 7 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 4 | 5 | 2 | 1 | 0 | 0 | 192 |
| L1527 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 408 |
| L1621 | 1 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 290 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 4 | 2 | 0 | 0 | 0 | 211 |
| L1629 | 3 | 1 | Mine | no | 0 | 5 | 3 | 0 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 170 |
| L1633 | 1 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 236 |
| L1719 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 490 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 98 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 3 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 5 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 4 | 3 | 1 | 0 | 0 | 60 |
| L1731 | 3 | 1 | Mine | no | 3 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 628 |
| L1819 | 1 | 1 | Mine | no | 0 | 5 | 5 | 1 | 2 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Mine | no | 9 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 2 | 0 | 0 | 170 |
| L1835 | 5 | 1 | Mine | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 1 | 0 | 0 | 226 |
| L1923 | 3 | 1 | Opponent | no | 0 | 1 | 9 | 1 | 2 | 0 | 0 | 245 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 60 |
| L1932 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 340 |
| L2021 | 5 | 1 | Mine | no | - | - | 1 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 3 | 4 | 0 | 0 | 0 | 355 |
| L2025 | 3 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 402 |
| L2025 | 3 | 1 | Opponent | no | 3 | 4 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 402 |
| L2029 | 1 | 1 | Opponent | no | 6 | 3 | 2 | 2 | 0 | 0 | 0 | 377 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 1 | 0 | 0 | 248 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 3 | 2 | 1 | 0 | 0 | 234 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 4 | 0 | 0 | 0 | 420 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 60 |
| L2127 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 1162 |
| L2127 | 3 | 1 | Opponent | no | 9 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 1 | - | 3 | 3 | 0 | 0 | 0 | 722 |
| L2131 | 1 | 1 | Opponent | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Mine | no | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 242 |
| L2223 | 3 | 1 | Opponent | no | 1 | 1 | 11 | 0 | 0 | 0 | 0 | 185 |
| L2227 | 1 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 2 | 0 | 0 | 60 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 144 |
| L2231 | 5 | 1 | Opponent | yes | - | 1 | 6 | 1 | 2 | 0 | 0 | 340 |
| L2235 | 3 | 1 | Mine | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 225 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | yes | 1 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 2 | 0 | 0 | 562 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | 5 | 2 | 2 | 0 | 0 | 0 | 343 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 250 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 0 | 2 | 0 | 0 | 2 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 7 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 107 |
| L2730 | 6 | 1 | Mine | no | 2 | 3 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 50 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 2 | 0 | 0 | 357 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 267 |
| L3033 | 3 | 1 | Mine | no | 7 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 144 |
| L3133 | 1 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 641 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 28% | 2.8 | 2.7 | 2.5 | 1.1 | 0.3 | 0.0 | 0.0 | 301.4 |
| **Average** | | | Opponent | 25% | 2.1 | 2.3 | 3.1 | 1.9 | 0.5 | 0.0 | 0.0 | 164.7 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: Mine predicts

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 17 | 161 | 60 | 1.2 | 1.1 | 51 | 11 | +40 | 2 of 20 | 13 of 20 | -85 | +46 |
| Mine | Chaos Dwarfs | 15 | 156 | 327 | 2.8 | 1.1 | 117 | 34 | +83 | 23 of 42 | 30 of 42 | +204 | +73 |
| Mine | Dwarfen Mountain Holds | 14 | 469 | 89 | 1.6 | 1.0 | 54 | 32 | +22 | 10 of 23 | 7 of 23 | +0 | +23 |
| Mine | Empire of Man | 20 | 394 | 184 | 2.2 | 1.1 | 84 | 40 | +44 | 12 of 44 | 26 of 43 | +263 | +28 |
| Mine | Grand Cathay | 17 | 375 | 380 | 3.4 | 1.1 | 113 | 19 | +94 | 17 of 57 | 41 of 57 | +316 | +63 |
| Mine | High Elf Realms | 16 | 207 | 347 | 3.6 | 1.1 | 97 | 33 | +65 | 17 of 57 | 41 of 57 | +132 | +61 |
| Mine | Kingdom of Bretonnia | 4 | 156 | 728 | 5.5 | 1.1 | 132 | 0 | +132 | 7 of 22 | 16 of 22 | +209 | +125 |
| Mine | Lizardmen | 4 | 149 | 668 | 4.8 | 1.1 | 141 | 43 | +97 | 5 of 19 | 10 of 19 | +93 | +98 |
| Mine | Ogre Kingdoms | 5 | 37 | 226 | 4.6 | 1.2 | 49 | 52 | -3 | 7 of 23 | 12 of 22 | -37 | +4 |
| Mine | Orc & Goblin Tribes | 3 | 0 | 750 | 7.0 | 1.1 | 107 | 62 | +45 | 6 of 21 | 15 of 21 | +424 | +5 |
| Mine | Skaven | 7 | 74 | 204 | 1.4 | 1.1 | 143 | 102 | +40 | 3 of 10 | 5 of 10 | +205 | +22 |
| Mine | Tomb Kings of Khemri | 7 | 145 | 430 | 4.3 | 1.0 | 100 | 64 | +36 | 10 of 30 | 15 of 30 | -431 | +52 |
| Mine | Vampire Counts | 9 | 57 | 494 | 4.3 | 1.2 | 114 | 70 | +44 | 14 of 39 | 22 of 39 | +185 | +8 |
| Mine | Warriors of Chaos | 6 | 0 | 544 | 3.2 | 1.1 | 172 | 39 | +133 | 5 of 19 | 8 of 19 | +290 | +124 |
| **Mine** | all armies | 144 | 227 | 305 | 3.0 | 1.1 | 103 | 40 | +64 | 138 of 426 | 261 of 424 | +174 | +53 |
| Opponent | Beastmen Brayherds | 1 | 0 | 77 | 3.0 | 1.0 | 26 | 0 | +26 | 2 of 3 | 2 of 3 | - | +26 |
| Opponent | Dwarfen Mountain Holds | 3 | 353 | 95 | 1.3 | 1.5 | 72 | 0 | +72 | 0 of 4 | 3 of 4 | +85 | +67 |
| Opponent | Empire of Man | 5 | 509 | 43 | 1.2 | 1.3 | 36 | 36 | +0 | 4 of 6 | 4 of 6 | +95 | -19 |
| Opponent | Grand Cathay | 6 | 216 | 383 | 3.3 | 1.2 | 115 | 73 | +42 | 11 of 20 | 10 of 20 | +87 | +27 |
| Opponent | High Elf Realms | 10 | 258 | 424 | 2.6 | 1.0 | 163 | 65 | +98 | 15 of 26 | 15 of 26 | -651 | +128 |
| Opponent | Kingdom of Bretonnia | 3 | 40 | 584 | 3.3 | 1.1 | 175 | 26 | +149 | 4 of 10 | 5 of 10 | -264 | +195 |
| Opponent | Lizardmen | 3 | 0 | 737 | 4.3 | 1.1 | 170 | 53 | +117 | 8 of 13 | 5 of 13 | +238 | +107 |
| Opponent | Ogre Kingdoms | 5 | 169 | 550 | 4.4 | 1.5 | 125 | 29 | +96 | 8 of 22 | 13 of 22 | +166 | +64 |
| Opponent | Orc & Goblin Tribes | 6 | 56 | 690 | 5.0 | 1.0 | 138 | 14 | +124 | 8 of 30 | 17 of 30 | - | +124 |
| Opponent | Skaven | 8 | 112 | 140 | 2.0 | 1.2 | 70 | 33 | +37 | 9 of 16 | 11 of 16 | +186 | -13 |
| Opponent | Tomb Kings of Khemri | 14 | 114 | 777 | 4.4 | 1.2 | 178 | 54 | +124 | 30 of 61 | 39 of 61 | +258 | +91 |
| Opponent | Vampire Counts | 24 | 46 | 509 | 4.1 | 1.1 | 125 | 43 | +82 | 46 of 98 | 61 of 97 | +225 | +64 |
| Opponent | Warriors of Chaos | 31 | 2 | 518 | 3.5 | 1.2 | 147 | 17 | +130 | 55 of 109 | 78 of 109 | +138 | +129 |
| Opponent | Wood Elf Realms | 25 | 113 | 410 | 3.8 | 1.2 | 107 | 21 | +86 | 41 of 96 | 53 of 96 | +195 | +66 |
| **Opponent** | all armies | 144 | 106 | 476 | 3.6 | 1.2 | 133 | 34 | +100 | 241 of 514 | 316 of 513 | +168 | +88 |

### Charged fights: Opponent predicts

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 17 | 178 | 166 | 1.6 | 1.3 | 105 | 21 | +83 | 8 of 27 | 23 of 27 | +39 | +98 |
| Mine | Chaos Dwarfs | 15 | 212 | 315 | 2.9 | 1.2 | 107 | 26 | +81 | 25 of 44 | 27 of 44 | +146 | +62 |
| Mine | Dwarfen Mountain Holds | 14 | 476 | 85 | 1.7 | 1.1 | 50 | 55 | -6 | 10 of 24 | 12 of 24 | +115 | -23 |
| Mine | Empire of Man | 20 | 387 | 100 | 1.9 | 1.1 | 51 | 55 | -4 | 8 of 39 | 28 of 39 | +69 | -12 |
| Mine | Grand Cathay | 17 | 375 | 393 | 3.1 | 1.1 | 128 | 13 | +116 | 16 of 52 | 38 of 52 | +247 | +102 |
| Mine | High Elf Realms | 16 | 224 | 505 | 3.8 | 1.2 | 133 | 43 | +90 | 17 of 61 | 46 of 61 | +199 | +71 |
| Mine | Kingdom of Bretonnia | 4 | 48 | 400 | 3.0 | 1.1 | 133 | 94 | +39 | 5 of 12 | 8 of 12 | +0 | +43 |
| Mine | Lizardmen | 4 | 120 | 836 | 4.2 | 1.1 | 197 | 34 | +162 | 4 of 17 | 10 of 17 | +158 | +163 |
| Mine | Ogre Kingdoms | 5 | 88 | 87 | 3.0 | 1.2 | 29 | 87 | -58 | 5 of 15 | 8 of 15 | -210 | -35 |
| Mine | Orc & Goblin Tribes | 3 | 0 | 334 | 4.0 | 1.0 | 84 | 52 | +32 | 3 of 12 | 9 of 12 | - | +32 |
| Mine | Skaven | 7 | 209 | 46 | 1.7 | 1.2 | 27 | 164 | -138 | 7 of 12 | 6 of 12 | +2 | -166 |
| Mine | Tomb Kings of Khemri | 7 | 176 | 638 | 5.3 | 1.1 | 121 | 21 | +100 | 9 of 37 | 29 of 37 | +58 | +104 |
| Mine | Vampire Counts | 9 | 82 | 433 | 4.1 | 1.2 | 105 | 16 | +89 | 7 of 37 | 21 of 37 | +179 | +72 |
| Mine | Warriors of Chaos | 6 | 0 | 453 | 3.3 | 1.1 | 136 | 40 | +96 | 7 of 20 | 19 of 20 | +140 | +92 |
| **Mine** | all armies | 144 | 244 | 301 | 2.8 | 1.1 | 106 | 40 | +66 | 131 of 409 | 284 of 409 | +122 | +57 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Dwarfen Mountain Holds | 3 | 273 | 95 | 1.7 | 1.0 | 57 | 0 | +57 | 0 of 5 | 4 of 5 | - | +57 |
| Opponent | Empire of Man | 5 | 570 | 86 | 1.4 | 1.0 | 61 | 79 | -18 | 2 of 7 | 3 of 7 | - | -18 |
| Opponent | Grand Cathay | 6 | 277 | 523 | 2.8 | 1.3 | 184 | 10 | +175 | 10 of 17 | 11 of 17 | +498 | +106 |
| Opponent | High Elf Realms | 10 | 136 | 376 | 3.5 | 1.1 | 107 | 61 | +47 | 22 of 35 | 19 of 35 | +50 | +46 |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 91 | 1.3 | 1.2 | 68 | 0 | +68 | 1 of 4 | 2 of 4 | +117 | +52 |
| Opponent | Lizardmen | 3 | 0 | 505 | 4.7 | 1.1 | 108 | 33 | +75 | 10 of 14 | 7 of 14 | +369 | +52 |
| Opponent | Ogre Kingdoms | 5 | 42 | 456 | 4.8 | 1.2 | 95 | 68 | +27 | 8 of 24 | 14 of 24 | -22 | +37 |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 503 | 4.2 | 1.0 | 121 | 15 | +106 | 9 of 25 | 13 of 25 | -310 | +124 |
| Opponent | Skaven | 8 | 87 | 12 | 1.4 | 1.1 | 9 | 72 | -63 | 5 of 11 | 5 of 11 | +0 | -69 |
| Opponent | Tomb Kings of Khemri | 14 | 122 | 754 | 4.2 | 1.2 | 179 | 29 | +150 | 32 of 59 | 39 of 59 | +260 | +125 |
| Opponent | Vampire Counts | 24 | 13 | 558 | 4.7 | 1.2 | 120 | 57 | +63 | 57 of 112 | 59 of 112 | +83 | +58 |
| Opponent | Warriors of Chaos | 31 | 16 | 500 | 3.2 | 1.2 | 158 | 28 | +130 | 41 of 98 | 62 of 97 | +307 | +100 |
| Opponent | Wood Elf Realms | 25 | 125 | 521 | 4.2 | 1.1 | 124 | 21 | +103 | 42 of 105 | 65 of 105 | +159 | +95 |
| **Opponent** | all armies | 144 | 92 | 467 | 3.6 | 1.2 | 130 | 37 | +93 | 239 of 517 | 303 of 516 | +169 | +80 |


## Effective charges (55-75% to win the first round: just enough force)

### Effective charges: Mine predicts

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 20 | 2 (net +0) | 1 (net +0) | 1 (net +0) | 4 (net +77) | 0 | 11 (net +11) | 1 | 5% (1 of 19) |
| Mine | Chaos Dwarfs | 42 | 6 (net +173) | 0 | 8 (net +96) | 10 (net -27) | 3 (net +254) | 9 (net +61) | 6 | 22% (8 of 36) |
| Mine | Dwarfen Mountain Holds | 23 | 1 (net +0) | 1 (net +351) | 8 (net -18) | 5 (net +37) | 0 | 7 (net +32) | 1 | 36% (8 of 22) |
| Mine | Empire of Man | 44 | 3 (net +36) | 2 (net +54) | 9 (net -65) | 11 (net +40) | 1 (net +72) | 14 (net +132) | 4 | 22% (9 of 40) |
| Mine | Grand Cathay | 57 | 6 (net +72) | 1 (net +386) | 9 (net +124) | 12 (net +109) | 4 (net -64) | 24 (net +98) | 1 | 16% (9 of 56) |
| Mine | High Elf Realms | 57 | 3 (net +19) | 0 | 3 (net -3) | 12 (net +100) | 5 (net +149) | 26 (net +59) | 8 | 6% (3 of 49) |
| Mine | Kingdom of Bretonnia | 22 | 4 (net +136) | 0 | 0 | 6 (net +97) | 2 (net +68) | 8 (net +149) | 2 | 0% (0 of 20) |
| Mine | Lizardmen | 19 | 3 (net +113) | 0 | 6 (net -3) | 3 (net +450) | 2 (net +30) | 3 (net +85) | 2 | 35% (6 of 17) |
| Mine | Ogre Kingdoms | 23 | 3 (net -127) | 0 | 6 (net -45) | 2 (net +33) | 0 | 6 (net +67) | 6 | 35% (6 of 17) |
| Mine | Orc & Goblin Tribes | 21 | 3 (net +304) | 0 | 2 (net +263) | 1 (net -165) | 3 (net +37) | 4 (net +103) | 8 | 15% (2 of 13) |
| Mine | Skaven | 10 | 4 (net -66) | 0 | 0 | 2 (net +102) | 1 (net +0) | 3 (net +155) | 0 | 0% (0 of 10) |
| Mine | Tomb Kings of Khemri | 30 | 3 (net +37) | 0 | 6 (net -132) | 5 (net +24) | 3 (net +40) | 9 (net +148) | 4 | 23% (6 of 26) |
| Mine | Vampire Counts | 39 | 6 (net +92) | 0 | 7 (net -22) | 5 (net +30) | 4 (net +144) | 14 (net +55) | 3 | 19% (7 of 36) |
| Mine | Warriors of Chaos | 19 | 0 | 0 | 2 (net +145) | 2 (net +179) | 4 (net +53) | 10 (net +166) | 1 | 11% (2 of 18) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +38) | 0 | 33% (1 of 3) |
| Opponent | Dwarfen Mountain Holds | 4 | 1 (net +85) | 0 | 2 (net +73) | 0 | 0 | 1 (net +55) | 0 | 50% (2 of 4) |
| Opponent | Empire of Man | 6 | 0 | 0 | 3 (net +40) | 1 (net -214) | 1 (net +95) | 1 (net +0) | 0 | 50% (3 of 6) |
| Opponent | Grand Cathay | 20 | 5 (net +121) | 0 | 2 (net -32) | 5 (net +43) | 0 | 5 (net +104) | 3 | 12% (2 of 17) |
| Opponent | High Elf Realms | 26 | 6 (net -66) | 1 (net +0) | 3 (net +84) | 6 (net +263) | 1 (net +0) | 6 (net +153) | 3 | 13% (3 of 23) |
| Opponent | Kingdom of Bretonnia | 10 | 1 (net +138) | 0 | 2 (net +79) | 0 | 0 | 5 (net +180) | 2 | 25% (2 of 8) |
| Opponent | Lizardmen | 13 | 2 (net +0) | 1 (net +238) | 1 (net +661) | 6 (net +50) | 0 | 1 (net +189) | 2 | 9% (1 of 11) |
| Opponent | Ogre Kingdoms | 22 | 5 (net +205) | 0 | 3 (net +131) | 4 (net +120) | 0 | 4 (net +137) | 6 | 19% (3 of 16) |
| Opponent | Orc & Goblin Tribes | 30 | 3 (net +97) | 0 | 2 (net +376) | 3 (net +235) | 0 | 4 (net +144) | 18 | 17% (2 of 12) |
| Opponent | Skaven | 16 | 3 (net +164) | 0 | 0 | 3 (net -134) | 2 (net +18) | 8 (net +59) | 0 | 0% (0 of 16) |
| Opponent | Tomb Kings of Khemri | 61 | 5 (net +362) | 0 | 9 (net -81) | 15 (net +80) | 7 (net +38) | 20 (net +219) | 5 | 16% (9 of 56) |
| Opponent | Vampire Counts | 98 | 19 (net -48) | 2 (net -116) | 17 (net +86) | 19 (net +154) | 9 (net +81) | 26 (net +143) | 6 | 18% (17 of 92) |
| Opponent | Warriors of Chaos | 109 | 5 (net +158) | 2 (net -4) | 19 (net +88) | 15 (net +196) | 9 (net +72) | 40 (net +161) | 19 | 21% (19 of 90) |
| Opponent | Wood Elf Realms | 96 | 13 (net +76) | 1 (net +0) | 12 (net +25) | 20 (net +162) | 5 (net +125) | 27 (net +112) | 18 | 15% (12 of 78) |

### Effective charges: Opponent predicts

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 27 | 2 (net -111) | 1 (net -137) | 1 (net +0) | 1 (net +110) | 2 (net +0) | 18 (net +129) | 2 | 4% (1 of 25) |
| Mine | Chaos Dwarfs | 44 | 7 (net +156) | 1 (net -95) | 4 (net +34) | 8 (net +127) | 4 (net +36) | 14 (net +88) | 6 | 11% (4 of 38) |
| Mine | Dwarfen Mountain Holds | 24 | 2 (net -32) | 2 (net -356) | 5 (net +136) | 3 (net -20) | 1 (net -138) | 9 (net +50) | 2 | 23% (5 of 22) |
| Mine | Empire of Man | 39 | 2 (net +0) | 0 | 9 (net -91) | 9 (net -31) | 1 (net +40) | 16 (net +56) | 2 | 24% (9 of 37) |
| Mine | Grand Cathay | 52 | 1 (net +0) | 0 | 9 (net +208) | 17 (net +91) | 4 (net +15) | 18 (net +114) | 3 | 18% (9 of 49) |
| Mine | High Elf Realms | 61 | 2 (net +68) | 0 | 6 (net +205) | 15 (net +50) | 15 (net +95) | 19 (net +89) | 4 | 11% (6 of 57) |
| Mine | Kingdom of Bretonnia | 12 | 2 (net +196) | 0 | 0 | 2 (net -236) | 3 (net -78) | 5 (net +156) | 0 | 0% (0 of 12) |
| Mine | Lizardmen | 17 | 2 (net +140) | 0 | 0 | 5 (net +115) | 4 (net +182) | 6 (net +197) | 0 | 0% (0 of 17) |
| Mine | Ogre Kingdoms | 15 | 0 | 1 (net +0) | 0 | 1 (net -405) | 1 (net +0) | 5 (net -118) | 7 | 0% (0 of 8) |
| Mine | Orc & Goblin Tribes | 12 | 1 (net +250) | 0 | 0 | 0 | 1 (net +45) | 2 (net -74) | 8 | 0% (0 of 4) |
| Mine | Skaven | 12 | 5 (net -284) | 0 | 1 (net +0) | 2 (net +35) | 1 (net +0) | 1 (net +0) | 2 | 10% (1 of 10) |
| Mine | Tomb Kings of Khemri | 37 | 3 (net +58) | 0 | 5 (net +35) | 5 (net +316) | 9 (net +64) | 10 (net +78) | 5 | 16% (5 of 32) |
| Mine | Vampire Counts | 37 | 3 (net -52) | 2 (net +360) | 3 (net +284) | 6 (net +37) | 9 (net +78) | 11 (net +65) | 3 | 9% (3 of 34) |
| Mine | Warriors of Chaos | 20 | 0 | 0 | 5 (net +11) | 4 (net +23) | 3 (net +182) | 7 (net +161) | 1 | 26% (5 of 19) |
| Opponent | Beastmen Brayherds | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +75) | 0 | 1 (net +55) | 1 | 25% (1 of 4) |
| Opponent | Empire of Man | 7 | 2 (net -276) | 0 | 1 (net +140) | 1 (net +0) | 0 | 3 (net +96) | 0 | 14% (1 of 7) |
| Opponent | Grand Cathay | 17 | 5 (net +30) | 0 | 3 (net +286) | 5 (net +302) | 1 (net +84) | 3 (net +123) | 0 | 18% (3 of 17) |
| Opponent | High Elf Realms | 35 | 5 (net -173) | 1 (net -500) | 3 (net +99) | 7 (net +102) | 1 (net +0) | 12 (net +89) | 6 | 10% (3 of 29) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 1 (net +117) | 0 | 1 (net +95) | 1 | 0% (0 of 3) |
| Opponent | Lizardmen | 14 | 2 (net +155) | 0 | 2 (net +48) | 4 (net -70) | 0 | 2 (net +217) | 4 | 20% (2 of 10) |
| Opponent | Ogre Kingdoms | 24 | 2 (net +82) | 1 (net -90) | 4 (net +75) | 6 (net +84) | 0 | 5 (net +74) | 6 | 22% (4 of 18) |
| Opponent | Orc & Goblin Tribes | 25 | 0 | 0 | 1 (net -310) | 4 (net +152) | 0 | 3 (net +140) | 17 | 12% (1 of 8) |
| Opponent | Skaven | 11 | 2 (net -22) | 1 (net +0) | 2 (net +0) | 1 (net -92) | 0 | 5 (net -111) | 0 | 18% (2 of 11) |
| Opponent | Tomb Kings of Khemri | 59 | 3 (net -170) | 2 (net +0) | 4 (net +155) | 15 (net +191) | 7 (net +86) | 20 (net +226) | 8 | 8% (4 of 51) |
| Opponent | Vampire Counts | 112 | 20 (net +9) | 4 (net -280) | 20 (net +159) | 21 (net +59) | 15 (net +86) | 22 (net +81) | 10 | 20% (20 of 102) |
| Opponent | Warriors of Chaos | 98 | 11 (net +82) | 1 (net +636) | 15 (net +92) | 13 (net +114) | 6 (net +71) | 41 (net +183) | 11 | 17% (15 of 87) |
| Opponent | Wood Elf Realms | 105 | 7 (net +153) | 1 (net +0) | 17 (net +67) | 23 (net +157) | 5 (net +126) | 32 (net +98) | 20 | 20% (17 of 85) |


## Charged fights by odds band, damage counted (Morten 2026-11-10)

### Charged fights, damage counted: Mine predicts

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 47 | 249 | 219 | +73 | 140 | 80 | +61 | +24.3 |
| Mine | 50-54% | 5 | 167 | 250 | +169 | 180 | 31 | +149 | +89.4 |
| Mine | Effective (55-75%) | 67 | 268 | 207 | +11 | 104 | 91 | +13 | +5.0 |
| Mine | 76-89% | 80 | 275 | 182 | +73 | 111 | 33 | +78 | +28.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 148 | 249 | 180 | +89 | 141 | 44 | +97 | +39.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 32 | 399 | 92 | +79 | 113 | 20 | +93 | +23.3 |
| Mine | No odds | 47 | 249 | 160 | +12 | 95 | 76 | +19 | +7.5 |
| Mine | All fights | 426 | 267 | 181 | +64 | 123 | 55 | +68 | +25.5 |
| Opponent | Long shot (under 50%) | 68 | 278 | 263 | +72 | 173 | 123 | +49 | +17.8 |
| Opponent | 50-54% | 7 | 218 | 277 | -0 | 154 | 147 | +7 | +3.1 |
| Opponent | Effective (55-75%) | 76 | 287 | 241 | +67 | 129 | 62 | +67 | +23.5 |
| Opponent | 76-89% | 97 | 317 | 229 | +134 | 185 | 56 | +129 | +40.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 150 | 291 | 213 | +145 | 176 | 31 | +145 | +49.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 34 | 381 | 79 | +70 | 96 | 33 | +63 | +16.6 |
| Opponent | No odds | 82 | 222 | 193 | +50 | 96 | 51 | +44 | +20.1 |
| Opponent | All fights | 514 | 288 | 216 | +100 | 152 | 58 | +95 | +32.9 |

### Charged fights, damage counted: Opponent predicts

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 32 | 251 | 281 | +14 | 122 | 118 | +4 | +1.6 |
| Mine | 50-54% | 7 | 158 | 259 | -32 | 113 | 147 | -34 | -21.5 |
| Mine | Effective (55-75%) | 48 | 269 | 242 | +87 | 162 | 80 | +82 | +30.5 |
| Mine | 76-89% | 78 | 287 | 202 | +61 | 140 | 70 | +70 | +24.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 141 | 255 | 166 | +89 | 137 | 40 | +97 | +38.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 58 | 440 | 96 | +67 | 101 | 32 | +69 | +15.7 |
| Mine | No odds | 45 | 286 | 180 | +33 | 86 | 40 | +46 | +16.1 |
| Mine | All fights | 409 | 290 | 184 | +66 | 128 | 57 | +71 | +24.5 |
| Opponent | Long shot (under 50%) | 60 | 233 | 293 | +13 | 138 | 132 | +6 | +2.4 |
| Opponent | 50-54% | 12 | 268 | 265 | -90 | 133 | 187 | -54 | -20.2 |
| Opponent | Effective (55-75%) | 73 | 314 | 246 | +106 | 158 | 55 | +103 | +32.8 |
| Opponent | 76-89% | 103 | 282 | 208 | +121 | 171 | 50 | +121 | +42.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 150 | 280 | 204 | +130 | 171 | 35 | +136 | +48.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 35 | 422 | 89 | +86 | 107 | 28 | +79 | +18.7 |
| Opponent | No odds | 84 | 253 | 198 | +68 | 110 | 42 | +68 | +26.9 |
| Opponent | All fights | 517 | 285 | 214 | +93 | 150 | 56 | +94 | +33.0 |


## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| Mine predicts | move | 1870 | 438 (23%) | 315 (17%) | 223 (12%) | 1209 (65%) |
| Mine predicts | objective | 1387 | 223 (16%) | 168 (12%) | 196 (14%) | 968 (70%) |
| Opponent predicts | move | 1850 | 438 (24%) | 320 (17%) | 207 (11%) | 1205 (65%) |
| Opponent predicts | objective | 1411 | 205 (15%) | 153 (11%) | 183 (13%) | 1023 (73%) |

## Combined arms (paper 2026-11-09, item 8)

### Combined arms: Mine predicts (144 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 39 of 426 (9%) | 36 of 590 (6%) | 704 of 1376 (51%) | 0.32 per game | 0.24 / 0.08 per game |
| Opponent | 74 of 514 (14%) | 52 of 467 (11%) | 662 of 1394 (47%) | 0.33 per game | 0.08 / 0.07 per game |

### Combined arms: Opponent predicts (144 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 56 of 409 (14%) | 40 of 581 (7%) | 786 of 1411 (56%) | 0.28 per game | 0.12 / 0.03 per game |
| Opponent | 76 of 517 (15%) | 48 of 469 (10%) | 671 of 1255 (53%) | 0.42 per game | 0.08 / 0.06 per game |


## Quality by phase (per game and side)

| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 3.5 | 3.0 | 3.5 |
| Strategy | Charge objectives carried out (made contact) | 53% (282 of 534) | 44% (326 of 739) | 55% (292 of 534) | 44% (321 of 724) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (604 of 1352) | 55% (338 of 620) | 46% (635 of 1366) | 53% (334 of 629) |
| Strategy | Close-in objectives charged next turn | 17% (102 of 592) | 15% (122 of 795) | 15% (96 of 644) | 14% (111 of 767) |
| Strategy | Support requests answered (helper made contact too) | 43% (26 of 60) | 50% (54 of 107) | 62% (34 of 55) | 43% (46 of 108) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (9 of 9) | 75% (3 of 4) | 75% (6 of 8) | 67% (4 of 6) |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (18 of 40) | 75% (18 of 24) | 48% (26 of 54) | 52% (17 of 33) |
| Strategy | Joined characters whose unit fought | 51% (81 of 158) | 41% (55 of 133) | 51% (81 of 160) | 46% (71 of 156) |
| Strategy | Lone characters that fought | 79% (307 of 391) | 80% (299 of 376) | 79% (307 of 389) | 78% (276 of 353) |
| Movement | Charges halted short of contact | 0.2 | 0.3 | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.9 | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 301.8 | 162.9 | 301.4 | 164.7 |
| Movement | Fights charged into per game | 3.0 | 3.6 | 2.8 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 47 of 379, net +73 | 68 of 432, net +72 | 32 of 364, net +14 | 60 of 433, net +13 |
| Movement | Charges with odds: sweet spot (55-75%) | 67 of 379, net +11 | 76 of 432, net +67 | 48 of 364, net +87 | 73 of 433, net +106 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 32 of 379, net +79 | 34 of 432, net +70 | 58 of 364, net +67 | 35 of 433, net +86 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 148 of 379, net +89 | 150 of 432, net +145 | 141 of 364, net +89 | 150 of 433, net +130 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 9.1 | 9.1 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (524 of 975) | 37% (86 of 230) | 56% (523 of 936) | 42% (95 of 225) |
| Shooting | Points destroyed by shooting units | 60.9 | 48.3 | 81.2 | 43.2 |
| Shooting | War machine shots | 6.8 | 1.6 | 6.5 | 1.6 |
| Shooting | Points destroyed by war machines | 81.3 | 23.2 | 79.4 | 26.0 |
| Magic | Magic missiles cast | 1.7 | 1.1 | 1.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (88 of 238) | 41% (65 of 157) | 31% (74 of 238) | 31% (44 of 143) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.5 | 3.4 | 1.7 |
| Magic | Wounds caused by other spells | 1.7 | 1.3 | 1.8 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 84.6 | 34.6 | 83.3 | 22.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.8 / 0.1 | 1.9 / 0.3 / 0.5 / 0.2 | 1.1 / 0.4 / 0.8 / 0.1 | 1.7 / 0.3 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 334.2 | 448.8 | 333.5 | 414.8 |
| Combat | Points run down | 88.1 | 103.8 | 97.2 | 141.7 |
| Combat | Net points per charged fight, damage counted | +68 | +95 | +71 | +94 |
| Combat | Net per 100 charger points, damage counted | +25.5 | +32.9 | +24.5 | +33.0 |
| Combat | First round won (charged fights) | 62% | 62% | 69% | 59% |
| Combat | Net points per charged fight | +64 | +100 | +66 | +93 |
| Combat | Net points per supported fight / lone fight | +174 / +53 | +168 / +88 | +122 / +57 | +169 / +80 |
| Combat | Charged fights on a top-3 enemy unit | 138 of 426 | 241 of 514 | 131 of 409 | 239 of 517 |
| Game | Points lost | 812.8 | 706.5 | 788.5 | 737.4 |
| Game | VP from objectives | 550.2 | 602.8 | 563.2 | 595.2 |
| Game | Lone holders (player turns) | 2.8 | 2.4 | 2.8 | 2.1 |

A = Mine predicts:
- Mine won / drew / lost: 56 / 20 / 68 of 144 ended games (of 144); mean margin (Mine - Opponent) -168 VP
- The side that went first won 60 of 124 games with a winner
- Points traded per game (both sides' losses): 1519
- Games not ended: 0; findings 0, warnings 1

B = Opponent predicts:
- Mine won / drew / lost: 56 / 25 / 63 of 144 ended games (of 144); mean margin (Mine - Opponent) -106 VP
- The side that went first won 56 of 119 games with a winner
- Points traded per game (both sides' losses): 1526
- Games not ended: 0; findings 1, warnings 1

## Opponent rules (fired a game, figure / won / lost VP a game)

| Rule | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 (+0 / 0 / 0) | 0.5 (+0 / 0 / 1) | 0.6 (+0 / 0 / 0) | 0.5 (+0 / 0 / 1) |
| ALREADY CARRIED | 0.0 (+0 / 0 / 2) | - | 0.1 (+0 / 0 / 0) | - |
| ARRIVAL HUNT | 0.0 (+0 / 0 / 1) | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+2 / 0 / 0) |
| ARTILLERY RE-ROLL WEIGHED | 1.4 (+0 / 0 / 15) | 0.2 (+0 / 0 / 1) | 1.4 (+0 / 0 / 14) | 0.3 (+0 / 0 / 2) |
| BACKUP TARGETS | 0.9 (+6 / 0 / 26) | 0.9 (+10 / 0 / 14) | 0.9 (+6 / 0 / 33) | 0.9 (+10 / 0 / 21) |
| BEST PREY | 3.8 (+204 / 120 / 120) | 4.5 (+306 / 194 / 112) | 4.2 (+255 / 152 / 150) | 4.4 (+280 / 228 / 123) |
| BEST PRIZE | 0.0 (+1 / 1 / 0) | 0.1 (+2 / 8 / 3) | 0.0 (-2 / 3 / 8) | 0.0 (-2 / 3 / 3) |
| BLOCKED CHARGE HANDED OVER | 0.0 (+0 / 0 / 0) | - | 0.0 (+1 / 3 / 0) | - |
| BLOCKED CHARGE SKIPPED | 0.1 (+0 / 7 / 0) | 0.1 (+0 / 17 / 2) | 0.2 (+0 / 12 / 2) | 0.1 (+0 / 4 / 4) |
| BLOCKED WHEEL | 0.5 (+6 / 0 / 6) | 0.4 (+14 / 0 / 7) | 0.5 (+8 / 0 / 5) | 0.4 (+16 / 0 / 7) |
| BOMBING RUN | 0.0 (+1 / 0 / 1) | 0.0 (+0 / 1 / 0) | 0.0 (+1 / 1 / 0) | 0.0 (+0 / 0 / 1) |
| BOUND ASSAILMENT | 0.0 (+0 / 0 / 1) | 0.0 (+0 / 0 / 1) | 0.0 (+0 / 0 / 6) | - |
| CANNON PLAN MISSED | 1.0 (+0 / 100 / 10) | 0.1 (+0 / 11 / 4) | 0.9 (+0 / 85 / 12) | 0.2 (+0 / 24 / 2) |
| CANNON PLANNED TARGET | 5.3 (+196 / 357 / 82) | 1.1 (+46 / 84 / 24) | 5.1 (+147 / 327 / 77) | 1.1 (+47 / 80 / 16) |
| CANNON SIGHT KEPT | 1.2 (+0 / 0 / 3) | 0.3 (+0 / 0 / 0) | 1.2 (+0 / 0 / 1) | 0.3 (+0 / 0 / 0) |
| CARRIES OUT COUNTER | 0.1 (-0 / 8 / 6) | 0.0 (+0 / 6 / 1) | 0.1 (-1 / 5 / 4) | 0.0 (-0 / 0 / 1) |
| CARRIES OUT SET-UP | 0.1 (-2 / 21 / 2) | 0.1 (-2 / 8 / 1) | 0.1 (-2 / 13 / 1) | 0.1 (-2 / 13 / 1) |
| CAST JOB | 0.8 (+22 / 45 / 20) | 0.4 (+8 / 22 / 9) | 0.8 (+22 / 78 / 20) | 0.4 (+8 / 34 / 5) |
| CASTER AWAY FROM SCREEN | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| CASTING BLOCK | 0.5 (+58 / 27 / 10) | 0.1 (+5 / 9 / 1) | 0.5 (+47 / 21 / 14) | 0.1 (+3 / 4 / 0) |
| CASTS AFTER FRIENDS | 0.7 (+0 / 0 / 26) | 0.3 (+0 / 0 / 20) | 0.7 (+0 / 0 / 46) | 0.3 (+0 / 0 / 14) |
| CASTS FROM BEHIND | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| CATCH FLIERS | 0.0 (+0 / 0 / 2) | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 0 / 2) | 0.0 (+0 / 0 / 0) |
| CATCH ODDS | 0.0 (+1 / 0 / 4) | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) | - |
| CHAFF PASSED | 0.3 (-1 / 2 / 10) | 0.2 (-0 / 4 / 6) | 0.2 (-0 / 10 / 1) | 0.2 (-0 / 10 / 4) |
| CHAMPION TAKES THE CHALLENGE | 0.0 (+1 / 1 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+4 / 1 / 1) | 0.0 (+0 / 2 / 0) |
| CHARGE NOW WEIGHED | 0.4 (-34 / 13 / 29) | 0.7 (-58 / 31 / 31) | 0.5 (-41 / 14 / 26) | 0.6 (-48 / 19 / 34) |
| CHARIOT NO STATIC JOB | 0.8 (+0 / 6 / 19) | 0.5 (+0 / 10 / 3) | 0.8 (+0 / 8 / 14) | 0.5 (+0 / 5 / 11) |
| CHEAP HELPER | 0.1 (+0 / 4 / 2) | 0.2 (+0 / 14 / 3) | 0.1 (+0 / 8 / 1) | 0.2 (+0 / 9 / 3) |
| CONTINUE AHEAD WEIGHED | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | - |
| CONVEYANCE SEARCH | 0.7 (+85 / 16 / 23) | 0.4 (+63 / 12 / 22) | 0.6 (+64 / 26 / 36) | 0.3 (+56 / 9 / 8) |
| COUNTER-CHARGE COVER | 7.1 (+251 / 0 / 198) | 7.3 (+623 / 0 / 133) | 9.0 (+693 / 0 / 221) | 5.6 (+272 / 0 / 129) |
| EDGE GIVE GROUND | 0.1 (+5 / 14 / 3) | 0.2 (+8 / 22 / 5) | 0.1 (+6 / 14 / 0) | 0.2 (+7 / 13 / 4) |
| ELIXIR WORTH | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 0) |
| ENEMY FORECAST | 10.5 (+299 / 106 / 330) | - | - | 7.1 (+165 / 96 / 170) |
| ENGINEER BY LORE | 0.1 (+0 / 0 / 1) | - | 0.1 (+0 / 0 / 1) | - |
| FACES THE THREAT | 1.2 (+86 / 0 / 41) | 0.9 (+77 / 0 / 27) | 1.3 (+121 / 0 / 51) | 0.8 (+67 / 0 / 35) |
| FALLBACK BY WORTH | 6.4 (+76 / 0 / 111) | 7.7 (+111 / 0 / 81) | 6.2 (+96 / 0 / 97) | 7.1 (+73 / 0 / 96) |
| FIGHT LIFT | 0.1 (+1 / 1 / 4) | 0.0 (+1 / 0 / 0) | 0.1 (+1 / 5 / 7) | 0.0 (+1 / 5 / 0) |
| FIRE AND FLEE | 0.0 (+1 / 0 / 2) | 0.0 (+1 / 1 / 3) | 0.0 (+0 / 0 / 1) | 0.1 (+1 / 7 / 7) |
| FLANK NOT WEIGHED | 0.4 (+0 / 0 / 9) | 0.3 (+0 / 0 / 15) | 0.4 (+0 / 0 / 13) | 0.2 (+0 / 0 / 7) |
| FOCUS FIRE | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 1 / 0) | 0.0 (+2 / 2 / 0) | 0.0 (+0 / 0 / 0) |
| FOLLOW UP WEIGHED | 1.1 (+143 / 0 / 37) | 1.1 (+168 / 0 / 29) | 1.0 (+135 / 0 / 46) | 1.1 (+172 / 0 / 37) |
| FORECAST RESULT | 40.7 (+2228 / 647 / 946) | 40.3 (+2162 / 952 / 1110) | 40.0 (+2381 / 654 / 994) | 40.6 (+2000 / 1115 / 1080) |
| FRIENDS SHOTS CHECKED | 0.2 (+9 / 0 / 9) | 0.2 (+10 / 0 / 1) | 0.3 (+26 / 0 / 5) | 0.1 (+13 / 0 / 0) |
| GIVES UP | 1.2 (-32 / 137 / 63) | 1.5 (-57 / 210 / 39) | 1.1 (-30 / 155 / 30) | 1.5 (-53 / 159 / 56) |
| GIVES UP ITS SCREEN | 0.6 (-10 / 30 / 14) | 1.0 (-22 / 70 / 11) | 0.5 (-10 / 49 / 9) | 1.1 (-27 / 83 / 14) |
| GROUND FLIERS | 0.0 (+0 / 0 / 0) | - | 0.0 (+1 / 0 / 0) | 0.0 (+1 / 0 / 0) |
| HELPER ALREADY ASKED | 0.0 (+0 / 3 / 2) | 0.0 (+0 / 1 / 0) | 0.0 (+0 / 5 / 2) | 0.1 (+0 / 12 / 1) |
| HELPER UNSEEN | 0.2 (+0 / 8 / 7) | 0.4 (+0 / 34 / 7) | 0.2 (+0 / 24 / 4) | 0.5 (+0 / 29 / 13) |
| HOLDS AMBUSHERS | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) |
| HORN WORTH | - | 0.0 (+1 / 0 / 0) | - | 0.0 (+0 / 0 / 0) |
| HUNT ADVANCE | 0.1 (+4 / 4 / 3) | 0.2 (+6 / 9 / 4) | 0.1 (+2 / 6 / 3) | 0.1 (+4 / 10 / 2) |
| HUNT DROPPED | 0.0 (+0 / 1 / 1) | 0.1 (+0 / 3 / 1) | 0.0 (+0 / 5 / 1) | 0.1 (+0 / 4 / 0) |
| HUNT IN PAIRS | 0.4 (+18 / 0 / 11) | 0.5 (+27 / 0 / 8) | 0.3 (+17 / 0 / 7) | 0.6 (+24 / 0 / 9) |
| HUNT KEPT | 0.0 (+1 / 2 / 1) | 0.1 (+2 / 7 / 0) | 0.0 (+1 / 5 / 1) | 0.0 (+2 / 11 / 0) |
| HUNT RESULT | 0.1 (+14 / 5 / 2) | 0.2 (+21 / 7 / 5) | 0.1 (+18 / 17 / 2) | 0.2 (+36 / 8 / 1) |
| HUNT THE GUNS | 0.1 (+36 / 7 / 3) | 0.2 (+81 / 12 / 5) | 0.1 (+54 / 15 / 3) | 0.2 (+74 / 22 / 2) |
| JOINT CHARGE PLAN | 0.0 (+3 / 7 / 1) | 0.1 (+5 / 6 / 6) | 0.1 (+5 / 3 / 1) | 0.1 (+6 / 5 / 0) |
| KEEP FALLS | 0.1 (+1 / 0 / 5) | 0.0 (+0 / 0 / 0) | 0.1 (+1 / 0 / 2) | 0.0 (+1 / 0 / 0) |
| KEEPS ITS PREY | 0.2 (+1 / 6 / 7) | 0.2 (+2 / 3 / 1) | 0.2 (+2 / 11 / 9) | 0.3 (+3 / 11 / 14) |
| KEEPS ITS TARGET | 1.8 (+53 / 164 / 74) | 2.3 (+70 / 203 / 56) | 1.7 (+51 / 156 / 52) | 2.2 (+67 / 205 / 47) |
| KEEPS SCOUTS OR AMBUSH | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| KILLS COUNT | 1.6 (+69 / 111 / 48) | 2.2 (+111 / 189 / 44) | 1.8 (+84 / 134 / 49) | 2.1 (+106 / 147 / 42) |
| KILLS COUNT NEXT TURN | 7.9 (+306 / 304 / 269) | 10.8 (+501 / 481 / 237) | 8.4 (+301 / 357 / 263) | 10.2 (+489 / 491 / 259) |
| LONE CHARACTER SAFE SPOT | 0.3 (+8 / 9 / 3) | 0.3 (+16 / 9 / 13) | 0.4 (+24 / 9 / 15) | 0.3 (+4 / 10 / 10) |
| LONE WIZARD HOLDS BACK | 1.0 (+0 / 73 / 54) | 1.1 (+0 / 46 / 33) | 1.1 (+0 / 65 / 39) | 1.0 (+0 / 47 / 42) |
| LONE WIZARD KEPT IN | 0.6 (+38 / 0 / 1) | 0.3 (+23 / 0 / 0) | 0.6 (+38 / 0 / 0) | 0.3 (+23 / 0 / 0) |
| MAKE SURE TOGETHER | 0.6 (+37 / 37 / 21) | 0.8 (+39 / 18 / 10) | 0.6 (+35 / 14 / 8) | 0.8 (+41 / 35 / 20) |
| MANOEUVRE | 0.2 (+4 / 0 / 3) | 0.2 (+5 / 0 / 1) | 0.2 (+9 / 0 / 3) | 0.1 (+5 / 0 / 2) |
| MARCH AT ESCAPER | 0.1 (+1 / 0 / 2) | 0.1 (+1 / 0 / 2) | 0.1 (+1 / 0 / 3) | 0.1 (+1 / 0 / 5) |
| MARCH CHECK | 0.5 (+12 / 0 / 14) | 0.6 (+34 / 0 / 13) | 0.6 (+29 / 0 / 13) | 0.6 (+21 / 0 / 7) |
| MARCH ODDS | 0.7 (+51 / 32 / 23) | 0.6 (+43 / 19 / 12) | 0.8 (+48 / 42 / 18) | 0.6 (+47 / 30 / 16) |
| MARCH OVER CASTS | 1.0 (+18 / 0 / 31) | 0.8 (+8 / 0 / 21) | 1.0 (+18 / 0 / 27) | 0.9 (-7 / 0 / 28) |
| MAX FOR POSITIONING | 4.3 (+96 / 0 / 145) | 5.1 (+194 / 0 / 104) | 4.9 (+178 / 0 / 123) | 4.3 (+127 / 0 / 95) |
| MISSILES IN THE MOVE | 3.4 (+119 / 0 / 94) | 2.7 (+42 / 0 / 51) | 3.4 (+114 / 0 / 97) | 2.7 (+41 / 0 / 51) |
| MISSILES NEXT TURN | 4.7 (+92 / 0 / 138) | 3.9 (+42 / 0 / 77) | 4.8 (+84 / 0 / 145) | 3.8 (+38 / 0 / 91) |
| MODEL FACING | 0.2 (+49 / 0 / 3) | 0.1 (+14 / 0 / 0) | 0.2 (+44 / 0 / 2) | 0.1 (+11 / 0 / 0) |
| MOVE AND CAST | 0.3 (+10 / 0 / 10) | 0.2 (+11 / 0 / 4) | 0.2 (+17 / 0 / 8) | 0.2 (+9 / 0 / 2) |
| MOVE SPELL IN RANGE | 0.2 (+5 / 0 / 7) | 0.0 (+0 / 0 / 2) | 0.2 (+6 / 0 / 13) | 0.0 (+0 / 0 / 2) |
| MOVE SPELL NOT WORTH | 0.0 (-0 / 0 / 0) | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 (-41 / 7 / 34) | 0.1 (-4 / 0 / 7) | 0.5 (-45 / 1 / 35) | 0.1 (-3 / 5 / 4) |
| MOVE SPELL SPOT | 0.4 (+0 / 0 / 11) | 0.1 (+0 / 0 / 9) | 0.4 (+0 / 0 / 14) | 0.1 (+0 / 0 / 6) |
| MOVES UNITS SPELL | 0.1 (+3 / 0 / 0) | 0.1 (+1 / 0 / 0) | 0.1 (+3 / 0 / 0) | 0.1 (+1 / 0 / 0) |
| NEEDED THERE | 0.0 (+1 / 1 / 0) | 0.1 (+12 / 5 / 0) | 0.0 (+3 / 2 / 0) | 0.1 (+6 / 6 / 0) |
| NO RALLY LEFT | 0.0 (+4 / 0 / 1) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 1) | 0.0 (+0 / 0 / 1) |
| NOT NEEDED | 0.2 (-9 / 26 / 5) | 0.3 (-15 / 41 / 1) | 0.3 (-13 / 33 / 5) | 0.4 (-25 / 52 / 3) |
| NOT TURNED | 7.6 (+118 / 0 / 246) | 7.8 (+111 / 0 / 142) | 7.6 (+127 / 0 / 216) | 7.4 (+98 / 0 / 151) |
| NOT WORTH A CAST | 0.6 (-0 / 0 / 39) | 0.5 (-0 / 0 / 0) | 0.7 (-0 / 0 / 25) | 0.5 (-1 / 0 / 2) |
| OPENS A LANE | 0.2 (+2 / 15 / 8) | 0.1 (+0 / 8 / 0) | 0.1 (+1 / 9 / 1) | 0.1 (+1 / 10 / 1) |
| OPENS UP | 0.3 (+23 / 15 / 4) | 0.2 (+17 / 13 / 5) | 0.2 (+21 / 15 / 3) | 0.2 (+12 / 6 / 5) |
| OVERRUNS AWAY | 0.6 (+10 / 39 / 27) | 0.6 (+11 / 51 / 15) | 0.5 (+18 / 55 / 14) | 0.4 (+7 / 45 / 6) |
| PATHS CROSS | 2.2 (+126 / 0 / 51) | 2.8 (+193 / 0 / 29) | 2.3 (+141 / 0 / 35) | 2.8 (+182 / 0 / 36) |
| PERIAPT WORTH | 0.0 (+2 / 0 / 0) | 0.0 (+2 / 0 / 4) | 0.0 (+3 / 0 / 4) | 0.0 (+3 / 0 / 8) |
| PLAN LEADS | 1.3 (+116 / 22 / 32) | 0.9 (+76 / 33 / 3) | 1.2 (+118 / 33 / 18) | 1.1 (+91 / 24 / 16) |
| PLAN RESULT | 37.2 (+1360 / 1203 / 1091) | 39.0 (+1399 / 1423 / 926) | 37.6 (+1558 / 1372 / 1063) | 38.5 (+1346 / 1403 / 1019) |
| PURSUES BIG PREY | 0.1 (-7 / 0 / 3) | 0.1 (-7 / 0 / 0) | 0.1 (-5 / 0 / 0) | 0.2 (-13 / 0 / 3) |
| PURSUES ON | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 2) | - | - |
| RAIDS THE BAGGAGE | 0.0 (+1 / 0 / 1) | 0.0 (+7 / 0 / 0) | - | 0.0 (+4 / 0 / 0) |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 (+8 / 0 / 2) | 0.1 (+5 / 0 / 1) | 0.1 (+8 / 0 / 0) | 0.1 (+9 / 0 / 2) |
| REDIRECT COUNTER | 2.8 (+85 / 0 / 43) | 4.8 (+334 / 0 / 71) | 3.2 (+166 / 0 / 46) | 3.9 (+175 / 0 / 73) |
| REDIRECT WEIGHED | 0.2 (+3 / 4 / 11) | 0.4 (+11 / 15 / 11) | 0.3 (+8 / 10 / 6) | 0.4 (+11 / 12 / 12) |
| RESTRAINS TO SHOOT | 0.1 (+5 / 0 / 9) | 0.1 (+3 / 0 / 1) | 0.1 (+4 / 0 / 6) | 0.1 (+2 / 0 / 1) |
| RISK BY ARC | 2.5 (+87 / 230 / 105) | 3.0 (+58 / 274 / 84) | 2.5 (+81 / 232 / 88) | 2.9 (+56 / 262 / 82) |
| SAFE SURE CHARGE | 0.0 (-0 / 0 / 0) | 0.0 (-3 / 1 / 0) | - | - |
| SAFER THAN THE JOB | 0.6 (+25 / 0 / 9) | 0.6 (+39 / 0 / 11) | 0.6 (+41 / 0 / 17) | 0.6 (+23 / 0 / 21) |
| SCOUT SPOT | 0.4 (+1 / 0 / 1) | 0.3 (+1 / 0 / 0) | 0.4 (+1 / 0 / 1) | 0.3 (+1 / 0 / 1) |
| SCOUT WAITS | 0.4 (+0 / 0 / 1) | 0.3 (+0 / 0 / 0) | 0.4 (+0 / 0 / 1) | 0.3 (+0 / 0 / 1) |
| SEARCH SPOT | 1.6 (+69 / 0 / 37) | 1.8 (+114 / 0 / 33) | 1.5 (+77 / 0 / 38) | 1.6 (+77 / 0 / 33) |
| SECOND HUNTER | 0.0 (-0 / 0 / 0) | 0.0 (-0 / 1 / 0) | 0.0 (-0 / 3 / 0) | 0.0 (-0 / 5 / 0) |
| SELF MOVE SPELL | 0.3 (+33 / 0 / 8) | 0.2 (+25 / 0 / 9) | 0.2 (+35 / 0 / 18) | 0.2 (+20 / 0 / 9) |
| SET UP TOGETHER | 0.8 (+50 / 39 / 26) | 1.4 (+70 / 23 / 18) | 0.9 (+54 / 19 / 17) | 1.7 (+81 / 41 / 42) |
| SET-UP ANY TARGET | 0.4 (+53 / 10 / 10) | 0.1 (+12 / 0 / 4) | 0.3 (+54 / 14 / 19) | 0.1 (+18 / 5 / 5) |
| SET-UP MISSED | 0.1 (+10 / 2 / 1) | 0.0 (+5 / 1 / 7) | 0.0 (+5 / 0 / 3) | 0.0 (+5 / 0 / 0) |
| SHOOTERS IN TWO RANKS | 0.4 (+1 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.4 (+1 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| SHORT GUN FORWARD | 0.2 (+0 / 0 / 2) | 0.1 (+0 / 0 / 1) | 0.2 (+0 / 0 / 2) | 0.1 (+0 / 0 / 1) |
| SHOT REPLANNED | 0.7 (+0 / 150 / 11) | 0.3 (+0 / 60 / 5) | 0.5 (+0 / 115 / 7) | 0.3 (+0 / 50 / 3) |
| SHOTS IN THE MOVE | 13.4 (+550 / 0 / 224) | 8.3 (+245 / 0 / 105) | 12.9 (+511 / 0 / 213) | 8.8 (+228 / 0 / 124) |
| SPELL CATCH ODDS | 0.0 (-0 / 0 / 0) | - | 0.0 (-0 / 1 / 1) | 0.0 (-0 / 1 / 0) |
| SPELL OFF EDGE | 0.0 (+3 / 0 / 2) | - | - | - |
| SPELL SETS UP CHARGE | 0.5 (+85 / 10 / 13) | 0.2 (+44 / 6 / 8) | 0.4 (+66 / 18 / 22) | 0.2 (+43 / 5 / 5) |
| SPELL WORTH | 1.0 (+19 / 80 / 76) | 2.1 (+37 / 63 / 65) | 1.2 (+23 / 97 / 98) | 1.9 (+34 / 96 / 87) |
| STANDS TO CAST | 0.0 (+2 / 4 / 0) | 0.0 (+1 / 1 / 0) | 0.0 (+2 / 3 / 4) | 0.0 (+2 / 0 / 0) |
| STOPS | 0.0 (+0 / 5 / 0) | 0.1 (+3 / 9 / 1) | 0.1 (+2 / 12 / 1) | 0.1 (+4 / 18 / 0) |
| STUCK PIVOT | 0.2 (+0 / 0 / 3) | 0.3 (+0 / 0 / 6) | 0.1 (+0 / 0 / 5) | 0.3 (+0 / 0 / 5) |
| SUPPORT JOB KEPT | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 3 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| SURE CHARGE BEATS ADVANCE | 0.1 (-4 / 9 / 4) | 0.1 (-6 / 17 / 8) | 0.2 (-8 / 8 / 9) | 0.1 (-6 / 13 / 2) |
| SURE REACH TOGETHER | 0.4 (-1 / 1 / 16) | 0.7 (-0 / 9 / 11) | 0.4 (-0 / 5 / 12) | 0.7 (+5 / 7 / 20) |
| THROUGH LINE OF FIRE | 0.5 (+14 / 0 / 11) | 0.2 (+10 / 0 / 4) | 0.5 (+17 / 0 / 17) | 0.2 (+11 / 0 / 11) |
| TURN WORTH | 0.5 (-32 / 38 / 17) | 0.4 (-29 / 28 / 6) | 0.5 (-37 / 48 / 6) | 0.4 (-25 / 26 / 4) |
| TWO OR MORE ARRIVE | 0.2 (+2 / 24 / 5) | 0.4 (+3 / 4 / 4) | 0.3 (+3 / 4 / 4) | 0.4 (+3 / 10 / 13) |
| WEARS DOWN | 1.0 (+49 / 116 / 46) | 1.3 (+38 / 122 / 56) | 0.9 (+47 / 121 / 28) | 1.3 (+42 / 150 / 54) |
| WHO HITS BACK | 0.2 (+12 / 0 / 10) | 0.2 (+18 / 0 / 12) | 0.2 (+19 / 0 / 11) | 0.1 (+6 / 0 / 3) |
| WHOLE FIGHT | 0.3 (+19 / 62 / 14) | 0.5 (+23 / 62 / 17) | 0.4 (+19 / 46 / 6) | 0.5 (+20 / 77 / 3) |
| WHOLE FIGHT GAIN | 0.3 (+19 / 35 / 8) | 0.5 (+33 / 46 / 12) | 0.3 (+21 / 28 / 9) | 0.6 (+52 / 51 / 12) |

A = Mine predicts, B = Opponent predicts.

## Rule changes (changed a game, VP a change)

| Rule | A | B |
| --- | --- | --- |
| ADVANCE LANE KEPT | 1.13 (+0.0) | 1.13 (+0.0) |
| ALREADY CARRIED | - | - |
| ARRIVAL HUNT | 0.00 (-) | 0.00 (-) |
| ARTILLERY RE-ROLL WEIGHED | 1.62 (+0.0) | 1.64 (+0.0) |
| BACKUP TARGETS | 0.12 (+5.4) | 0.11 (+2.5) |
| BEST PREY | 3.66 (+40.5) | 3.70 (+42.2) |
| BEST PRIZE | 0.08 (-63.8) | 0.07 (-93.9) |
| BLOCKED CHARGE HANDED OVER | 0.01 (+39.0) | 0.01 (+41.3) |
| BLOCKED CHARGE SKIPPED | 0.24 (+0.0) | 0.22 (+0.0) |
| BLOCKED WHEEL | 0.90 (+21.8) | 0.91 (+26.0) |
| BOMBING RUN | 0.04 (+34.6) | 0.03 (+23.7) |
| BOUND ASSAILMENT | 0.03 (+0.1) | 0.04 (+0.2) |
| CANNON PLAN MISSED | 0.00 (-) | 0.00 (-) |
| CANNON PLANNED TARGET | 1.32 (-7.5) | 1.00 (-14.4) |
| CANNON SIGHT KEPT | 1.50 (+0.0) | 1.50 (+0.0) |
| CARRIES OUT COUNTER | 0.01 (-30.5) | 0.03 (-47.1) |
| CARRIES OUT SET-UP | 0.07 (-70.2) | 0.05 (-73.5) |
| CAST JOB | 0.62 (+17.5) | 0.67 (+18.4) |
| CASTER AWAY FROM SCREEN | 0.39 (+0.0) | 0.39 (+0.0) |
| CASTING BLOCK | 0.53 (+68.2) | 0.44 (+59.6) |
| CASTS AFTER FRIENDS | - | - |
| CASTS FROM BEHIND | 0.33 (+0.0) | 0.33 (+0.0) |
| CATCH FLIERS | - | - |
| CATCH ODDS | 0.03 (-29.7) | 0.01 (-0.3) |
| CHAFF PASSED | 0.49 (-2.4) | 0.40 (-2.0) |
| CHAMPION TAKES THE CHALLENGE | 0.01 (+0.0) | 0.01 (+5.0) |
| CHARGE NOW WEIGHED | 1.15 (+66.1) | 1.12 (+63.3) |
| CHARIOT NO STATIC JOB | 0.74 (-86.3) | 0.78 (-81.4) |
| CHEAP HELPER | - | - |
| CONTINUE AHEAD WEIGHED | 0.02 (+0.0) | 0.01 (+0.0) |
| CONVEYANCE SEARCH | - | - |
| COUNTER-CHARGE COVER | 2.92 (+46.7) | 2.93 (+43.9) |
| EDGE GIVE GROUND | 0.08 (+47.0) | 0.04 (+79.2) |
| ELIXIR WORTH | 0.05 (+9.5) | 0.03 (+29.0) |
| ENEMY FORECAST | 1.73 (+8.2) | 1.31 (+5.9) |
| ENGINEER BY LORE | 0.00 (-) | 0.00 (-) |
| FACES THE THREAT | 2.17 (+75.1) | 2.17 (+87.0) |
| FALLBACK BY WORTH | 3.44 (+54.5) | 3.19 (+52.9) |
| FIGHT LIFT | - | - |
| FIRE AND FLEE | 0.08 (+18.2) | 0.10 (+11.5) |
| FLANK NOT WEIGHED | - | - |
| FOCUS FIRE | 0.03 (+32.3) | 0.05 (+37.8) |
| FOLLOW UP WEIGHED | 2.19 (+142.1) | 2.15 (+143.1) |
| FORECAST RESULT | - | - |
| FRIENDS SHOTS CHECKED | 0.38 (+50.9) | 0.49 (+79.6) |
| GIVES UP | 0.03 (+13.4) | 0.03 (+25.1) |
| GIVES UP ITS SCREEN | 0.01 (+12.8) | 0.01 (+16.6) |
| GROUND FLIERS | - | - |
| HELPER ALREADY ASKED | - | - |
| HELPER UNSEEN | 0.00 (-) | 0.00 (-) |
| HOLDS AMBUSHERS | 1.10 (+0.0) | 1.10 (+0.0) |
| HORN WORTH | 0.03 (+21.9) | 0.03 (+16.7) |
| HUNT ADVANCE | 0.12 (+39.6) | 0.07 (+42.9) |
| HUNT DROPPED | - | - |
| HUNT IN PAIRS | 0.15 (+67.9) | 0.13 (+50.7) |
| HUNT KEPT | - | - |
| HUNT RESULT | - | - |
| HUNT THE GUNS | - | - |
| JOINT CHARGE PLAN | 0.03 (+93.8) | 0.08 (+33.5) |
| KEEP FALLS | 0.10 (+30.4) | 0.11 (+53.5) |
| KEEPS ITS PREY | 0.03 (+4.7) | 0.04 (+7.8) |
| KEEPS ITS TARGET | 1.16 (+16.4) | 0.87 (+17.6) |
| KEEPS SCOUTS OR AMBUSH | 0.06 (+0.0) | 0.06 (+0.0) |
| KILLS COUNT | 1.20 (+42.9) | 1.11 (+47.1) |
| KILLS COUNT NEXT TURN | 5.42 (+35.3) | 5.40 (+37.7) |
| LONE CHARACTER SAFE SPOT | - | - |
| LONE WIZARD HOLDS BACK | 0.65 (-69.9) | 0.72 (-68.6) |
| LONE WIZARD KEPT IN | 0.88 (+68.9) | 0.88 (+68.9) |
| MAKE SURE TOGETHER | 0.47 (+54.4) | 0.43 (+49.9) |
| MANOEUVRE | 0.34 (+25.9) | 0.33 (+41.9) |
| MARCH AT ESCAPER | - | - |
| MARCH CHECK | 0.62 (+30.0) | 0.65 (+24.7) |
| MARCH ODDS | 1.19 (+21.1) | 1.30 (+19.9) |
| MARCH OVER CASTS | 0.00 (-) | 0.00 (-) |
| MAX FOR POSITIONING | 1.42 (+8.2) | 1.39 (+7.2) |
| MISSILES IN THE MOVE | 0.64 (+26.1) | 0.58 (+28.9) |
| MISSILES NEXT TURN | 0.17 (+6.0) | 0.19 (+5.6) |
| MODEL FACING | 0.28 (+222.4) | 0.26 (+214.7) |
| MOVE AND CAST | 0.51 (+41.0) | 0.42 (+61.0) |
| MOVE SPELL IN RANGE | 0.01 (+0.3) | 0.02 (+23.7) |
| MOVE SPELL NOT WORTH | - | - |
| MOVE SPELL OUT OF RANGE | - | - |
| MOVE SPELL SPOT | - | - |
| MOVES UNITS SPELL | 0.17 (+23.4) | 0.17 (+23.4) |
| NEEDED THERE | 0.07 (+0.0) | 0.08 (+0.0) |
| NO RALLY LEFT | 0.05 (+68.7) | 0.05 (+9.2) |
| NOT NEEDED | 0.01 (+8.9) | 0.00 (-) |
| NOT TURNED | 0.00 (-) | 0.00 (-) |
| NOT WORTH A CAST | - | - |
| OPENS A LANE | 0.01 (+19.1) | 0.02 (+22.7) |
| OPENS UP | 0.22 (+45.6) | 0.17 (+52.5) |
| OVERRUNS AWAY | 0.12 (+19.3) | 0.13 (+26.4) |
| PATHS CROSS | 4.94 (+64.5) | 5.06 (+63.9) |
| PERIAPT WORTH | 0.05 (+85.7) | 0.07 (+78.5) |
| PLAN LEADS | 0.90 (+53.5) | 0.94 (+56.2) |
| PLAN RESULT | - | - |
| PURSUES BIG PREY | 0.17 (-82.1) | 0.22 (-83.1) |
| PURSUES ON | 0.01 (+14.9) | - |
| RAIDS THE BAGGAGE | 0.03 (+202.5) | 0.02 (+173.7) |
| RAIDS THE BAGGAGE NEXT TURN | 0.14 (+44.6) | 0.16 (+40.0) |
| REDIRECT COUNTER | 0.89 (+58.4) | 0.85 (+51.0) |
| REDIRECT WEIGHED | 0.57 (+42.8) | 0.62 (+59.3) |
| RESTRAINS TO SHOOT | 0.19 (+40.0) | 0.14 (+42.5) |
| RISK BY ARC | 1.38 (+30.5) | 1.19 (+29.1) |
| SAFE SURE CHARGE | 0.03 (-165.7) | - |
| SAFER THAN THE JOB | 1.18 (+54.0) | 1.24 (+51.9) |
| SCOUT SPOT | 0.00 (-) | 0.00 (-) |
| SCOUT WAITS | 0.72 (+0.0) | 0.72 (+0.0) |
| SEARCH SPOT | 3.38 (+54.2) | 3.02 (+51.3) |
| SECOND HUNTER | 0.00 (-) | 0.00 (-) |
| SELF MOVE SPELL | - | - |
| SET UP TOGETHER | 0.84 (+56.8) | 0.93 (+48.3) |
| SET-UP ANY TARGET | - | - |
| SET-UP MISSED | - | - |
| SHOOTERS IN TWO RANKS | 0.56 (+2.0) | 0.56 (+2.0) |
| SHORT GUN FORWARD | 0.25 (+0.0) | 0.25 (+0.0) |
| SHOT REPLANNED | 1.00 (+0.0) | 0.79 (+0.0) |
| SHOTS IN THE MOVE | 1.71 (+24.8) | 1.67 (+24.5) |
| SPELL CATCH ODDS | - | - |
| SPELL OFF EDGE | - | - |
| SPELL SETS UP CHARGE | - | - |
| SPELL WORTH | - | - |
| STANDS TO CAST | 0.06 (+12.9) | 0.07 (-17.2) |
| STOPS | 0.01 (+1.8) | 0.03 (+40.6) |
| STUCK PIVOT | 0.45 (+0.0) | 0.42 (+0.0) |
| SUPPORT JOB KEPT | 0.02 (+39.9) | 0.01 (-2.2) |
| SURE CHARGE BEATS ADVANCE | 0.26 (-39.8) | 0.31 (-47.5) |
| SURE REACH TOGETHER | 0.11 (+11.6) | 0.16 (+9.2) |
| THROUGH LINE OF FIRE | 0.70 (+34.6) | 0.74 (+38.7) |
| TURN WORTH | 0.00 (-) | 0.00 (-) |
| TWO OR MORE ARRIVE | 0.02 (+3.0) | 0.03 (+8.9) |
| WEARS DOWN | 0.47 (+38.5) | 0.44 (+30.7) |
| WHO HITS BACK | 0.39 (-57.6) | 0.33 (-63.9) |
| WHOLE FIGHT | 0.24 (+91.4) | 0.19 (+80.9) |
| WHOLE FIGHT GAIN | 0.28 (+44.8) | 0.47 (+38.7) |

A = Mine predicts, B = Opponent predicts.

## Plans (happened, won of planned)

| Side | Plan | A | B |
| --- | --- | --- | --- |
| Mine | advance | 16% (57%) | 19% (74%) |
| Mine | charge | 58% (87%) | 64% (100%) |
| Mine | close in | 27% (45%) | 28% (51%) |
| Mine | hold | 39% (0%) | 40% (0%) |
| Mine | join | 97% (0%) | 92% (0%) |
| Mine | shoot | 65% (189%) | 63% (240%) |
| Mine | support | 91% (0%) | 88% (0%) |
| Opponent | advance | 20% (65%) | 19% (64%) |
| Opponent | charge | 57% (94%) | 57% (87%) |
| Opponent | close in | 28% (50%) | 25% (38%) |
| Opponent | hold | 40% (0%) | 38% (0%) |
| Opponent | join | 94% (0%) | 95% (0%) |
| Opponent | shoot | 64% (283%) | 68% (283%) |
| Opponent | support | 91% (0%) | 91% (0%) |

A = Mine predicts, B = Opponent predicts.

## Enemy forecast (right of judged, forecasts a game)

| Side | Expected | A | B |
| --- | --- | --- | --- |
| Mine | charge | 59% (4.0) | 58% (3.8) |
| Mine | shoot | 38% (6.8) | 36% (7.1) |
| Mine | move | 76% (29.8) | 77% (29.1) |
| Opponent | charge | 65% (2.9) | 64% (2.8) |
| Opponent | shoot | 41% (13.9) | 44% (13.8) |
| Opponent | move | 71% (23.4) | 71% (23.9) |

A = Mine predicts, B = Opponent predicts.

## Packages: hunt the guns (per side)

| Batch | Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Mine | 0.1 | 15 | 1 | 36% | 43% | 0% | 2.3 | 351 | 145 | 36% | 29 |
| A | Opponent | 0.2 | 28 | 3 | 20% | 28% | 0% | 2.4 | 435 | 119 | 28% | 86 |
| B | Mine | 0.1 | 21 | 1 | 35% | 40% | 5% | 2.5 | 377 | 128 | 35% | 27 |
| B | Opponent | 0.2 | 26 | 0 | 35% | 50% | 0% | 2.5 | 411 | 201 | 50% | 94 |

A = Mine predicts, B = Opponent predicts.

### Battle groups: Mine predicts

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.1 | 26% | 50% | 10% | 42% | 30% | 12% | 9% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.8 | 27% | 73% | 10% | 36% | 20% | 3% | 4% | 65% | 8% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 18% | 57% | 18% | 36% | 34% | 9% | 14% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 4.8 | 20% | 73% | 21% | 21% | 26% | 0% | 9% | 62% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Battle groups: Opponent predicts

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.0 | 24% | 44% | 10% | 53% | 36% | 14% | 10% | 40% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 26% | 55% | 8% | 0% | 21% | 5% | 8% | 62% | 4% |
| Opponent | COUNTER-CHARGE COVER | 5.6 | 21% | 60% | 19% | 22% | 30% | 12% | 12% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 22% | 70% | 14% | 12% | 24% | 1% | 10% | 59% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: Mine predicts

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 13 | 35 (13) | 35 | 0 | 63 | 31% | 4.2 | 72 (5) | 23 (3) | 0 (1) | 82 (5) | 0 (4) |
| Mine | Chaff | 178 | 45 (178) | 17 | 28 | 65 | 39% | 2.6 | 55 (81) | 39 (32) | 35 (65) | 59 (124) | 14 (54) |
| Mine | Character | 473 | 50 (473) | 50 | 0 | 44 | 15% | 2.4 | 47 (142) | 61 (221) | 39 (34) | 54 (225) | 55 (172) |
| Mine | Clean-up | 61 | 58 (61) | 17 | 41 | 40 | 31% | 3.0 | 54 (26) | 59 (25) | 69 (10) | 73 (33) | 40 (28) |
| Mine | Early | 1 | 139 (1) | 139 | 0 | 0 | 0% | 5.0 | - | 139 (1) | - | - | 139 (1) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 167 | 35 (167) | 20 | 15 | 46 | 24% | 2.9 | 32 (93) | 40 (38) | 36 (36) | 37 (120) | 30 (47) |
| Mine | Fragile | 17 | 6 (17) | 6 | 0 | 60 | 24% | 2.3 | 0 (6) | 12 (9) | 0 (2) | 13 (8) | 0 (9) |
| Mine | Hammer | 228 | 35 (228) | 24 | 11 | 47 | 12% | 2.7 | 36 (48) | 30 (145) | 58 (35) | 35 (148) | 34 (80) |
| Mine | Holder | 109 | 60 (109) | 8 | 53 | 37 | 40% | 3.2 | 32 (31) | 75 (55) | 68 (21) | 81 (57) | 38 (50) |
| Mine | Shooter | 161 | 98 (161) | 43 | 55 | 43 | 2% | 1.8 | 86 (36) | 98 (101) | 117 (24) | 124 (99) | 58 (62) |
| Mine | Support | 12 | 9 (12) | 9 | 0 | 28 | 42% | 2.6 | 0 (2) | 0 (4) | 78 (2) | 24 (4) | 0 (4) |
| Mine | War machine | 223 | 46 (223) | 46 | 0 | 37 | 4% | 1.2 | 49 (60) | 43 (139) | 54 (24) | 46 (41) | 46 (182) |
| Mine | Wizard | 76 | 22 (76) | 22 | 0 | 43 | 12% | 2.4 | 38 (22) | 30 (27) | 6 (6) | 37 (21) | 25 (34) |
| Opponent | Blocker | 5 | 0 (5) | 0 | 0 | 53 | 60% | 5.5 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |
| Opponent | Chaff | 325 | 49 (325) | 20 | 29 | 50 | 39% | 2.7 | 62 (125) | 37 (75) | 45 (125) | 56 (233) | 32 (92) |
| Opponent | Character | 405 | 64 (405) | 64 | 0 | 32 | 20% | 2.3 | 72 (161) | 66 (169) | 45 (31) | 70 (225) | 63 (136) |
| Opponent | Clean-up | 43 | 61 (43) | 19 | 42 | 49 | 33% | 2.8 | 43 (17) | 71 (20) | 76 (6) | 64 (28) | 57 (15) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 212 | 44 (212) | 28 | 16 | 44 | 26% | 2.9 | 39 (109) | 49 (57) | 50 (46) | 44 (132) | 43 (80) |
| Opponent | Fragile | 33 | 6 (33) | 6 | 0 | 68 | 27% | 2.2 | 0 (2) | 3 (19) | 15 (9) | 8 (22) | 0 (8) |
| Opponent | Hammer | 243 | 34 (243) | 25 | 9 | 39 | 30% | 2.7 | 18 (74) | 41 (141) | 19 (28) | 33 (144) | 35 (99) |
| Opponent | Holder | 135 | 55 (135) | 5 | 50 | 23 | 44% | 3.2 | 34 (32) | 77 (73) | 22 (28) | 73 (69) | 36 (64) |
| Opponent | Shooter | 128 | 77 (128) | 30 | 47 | 38 | 3% | 1.5 | 92 (34) | 78 (79) | 40 (15) | 88 (77) | 62 (51) |
| Opponent | Support | 15 | 0 (15) | 0 | 0 | 32 | 60% | 3.5 | 0 (3) | 0 (5) | 0 (4) | 0 (4) | 0 (8) |
| Opponent | War machine | 60 | 60 (60) | 60 | 0 | 43 | 12% | 1.5 | 69 (15) | 62 (35) | 40 (10) | 40 (10) | 63 (50) |
| Opponent | Wizard | 106 | 15 (106) | 15 | 0 | 42 | 9% | 1.8 | 17 (39) | 23 (25) | 5 (19) | 24 (44) | 5 (39) |

### Deployment: positions vs output by unit type: Opponent predicts

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 13 | 25 (13) | 25 | 0 | 33 | 69% | 4.5 | 0 (1) | 38 (8) | 0 (1) | 45 (7) | 0 (3) |
| Mine | Chaff | 178 | 46 (178) | 28 | 18 | 61 | 39% | 2.7 | 45 (81) | 32 (32) | 55 (65) | 46 (124) | 47 (54) |
| Mine | Character | 473 | 48 (473) | 48 | 0 | 41 | 16% | 2.4 | 46 (139) | 59 (222) | 24 (33) | 55 (224) | 49 (170) |
| Mine | Clean-up | 61 | 79 (61) | 26 | 53 | 35 | 31% | 3.5 | 75 (26) | 79 (25) | 93 (10) | 103 (33) | 50 (28) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 167 | 43 (167) | 26 | 17 | 44 | 21% | 2.9 | 46 (93) | 49 (38) | 23 (36) | 45 (120) | 36 (47) |
| Mine | Fragile | 17 | 6 (17) | 6 | 0 | 58 | 12% | 2.9 | 18 (6) | 0 (9) | 0 (2) | 0 (8) | 12 (9) |
| Mine | Hammer | 228 | 38 (228) | 25 | 13 | 49 | 16% | 2.6 | 21 (48) | 40 (145) | 58 (35) | 35 (148) | 44 (80) |
| Mine | Holder | 109 | 58 (109) | 7 | 50 | 34 | 39% | 3.2 | 24 (32) | 86 (51) | 39 (25) | 80 (61) | 30 (47) |
| Mine | Shooter | 161 | 81 (161) | 33 | 47 | 41 | 2% | 1.7 | 49 (35) | 91 (101) | 84 (25) | 95 (100) | 57 (61) |
| Mine | Support | 12 | 13 (12) | 13 | 0 | 34 | 25% | 3.2 | 0 (1) | 0 (4) | 0 (4) | 0 (6) | 0 (3) |
| Mine | War machine | 223 | 50 (223) | 50 | 0 | 38 | 4% | 1.2 | 52 (60) | 51 (139) | 38 (24) | 32 (41) | 54 (182) |
| Mine | Wizard | 76 | 42 (76) | 42 | 0 | 50 | 13% | 2.4 | 33 (20) | 77 (31) | 27 (7) | 48 (24) | 62 (34) |
| Opponent | Blocker | 5 | 0 (5) | 0 | 0 | 42 | 60% | 4.5 | 0 (1) | 0 (4) | - | 0 (1) | 0 (4) |
| Opponent | Chaff | 325 | 43 (325) | 16 | 27 | 53 | 41% | 2.8 | 49 (125) | 47 (75) | 33 (125) | 54 (233) | 14 (92) |
| Opponent | Character | 405 | 58 (405) | 58 | 0 | 35 | 21% | 2.3 | 74 (168) | 52 (183) | 30 (25) | 68 (233) | 51 (143) |
| Opponent | Clean-up | 43 | 65 (43) | 22 | 43 | 44 | 26% | 2.8 | 48 (17) | 71 (20) | 92 (6) | 65 (28) | 64 (15) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 33 | 33% | 4.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 212 | 43 (212) | 29 | 14 | 45 | 29% | 2.9 | 33 (109) | 48 (57) | 63 (46) | 46 (132) | 37 (80) |
| Opponent | Fragile | 33 | 34 (33) | 34 | 0 | 66 | 21% | 2.3 | 0 (3) | 12 (16) | 35 (8) | 23 (21) | 0 (6) |
| Opponent | Hammer | 243 | 44 (243) | 35 | 8 | 46 | 26% | 3.0 | 51 (74) | 38 (141) | 69 (28) | 38 (144) | 51 (99) |
| Opponent | Holder | 135 | 60 (135) | 16 | 44 | 24 | 49% | 3.0 | 16 (27) | 80 (81) | 43 (25) | 81 (72) | 36 (61) |
| Opponent | Shooter | 128 | 74 (128) | 28 | 47 | 35 | 2% | 1.5 | 70 (34) | 80 (79) | 49 (15) | 87 (77) | 55 (51) |
| Opponent | Support | 15 | 13 (15) | 13 | 0 | 16 | 60% | 3.8 | 30 (7) | 0 (6) | 0 (1) | 0 (6) | 29 (8) |
| Opponent | War machine | 60 | 55 (60) | 55 | 0 | 27 | 5% | 1.7 | 75 (15) | 43 (35) | 67 (10) | 20 (10) | 61 (50) |
| Opponent | Wizard | 106 | 14 (106) | 14 | 0 | 41 | 8% | 2.1 | 9 (43) | 20 (29) | 26 (18) | 20 (50) | 9 (40) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0106, L0110, L0114, L0118, L0122, L0126, L0130, L0135, L2429, L2433, L2527, L2531, L2535, L2630, L2634, L2730, L2735 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0425, L0434, L0524, L0624, L0725, L0827, L0926, L0934, L1026, L1034, L1126, L1224, L1327, L1427, L1527, L1625, L1727, L1827, L1927, L2025, L2127, L2227, L2327, L2527, L2634, L2934, L3234 |
| Clockwork Compass | Mine | L1216, L1220, L1224, L1228, L1232 |
| Clockwork Compass | Opponent | L0512, L0612 |
| Elixir of Power | Mine | L1114, L1118, L1122, L1126, L1131, L1135, L1923, L1927, L1932 |
| Elixir of Power | Opponent | L0311, L0319, L0819, L1319, L1519, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1823, L1827, L1831, L1835 |
| Fistful of Laurels | Opponent | L0118, L0218, L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L0533, L0733, L1633, L2033, L2433, L3033, L3133 |
| Invocation of Nehek | Mine | L2429, L2433, L2527, L2531, L2535, L2730, L2735 |
| Invocation of Nehek | Opponent | L0327, L0425, L0524, L0624, L0725, L0827, L1224, L1327, L1427, L1527, L1625, L1727, L1827, L1927, L2025, L2127, L2227, L2327, L2527 |
| Opal Amulet | Mine | L1418, L1422, L1427, L1431, L1435 |
| Opal Amulet | Opponent | L0114, L0214, L1114, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2025, L2029, L2033, L2123, L2127, L2131 |
| Periapt of Soul Exchange | Opponent | L0421, L0520, L0620, L0721, L1021, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0206, L0210, L0214, L0218, L0222, L0226, L0230, L0235, L1114, L1118, L1122, L1126, L1131, L1135, L1216, L1220, L1224, L1228, L1232, L1519, L1523, L1527, L1531, L1535, L3133 |
| Ring of Doom | Opponent | L0102, L0311, L0315, L0512, L0533, L0612, L0733, L0815, L0831, L1131, L1331, L1431, L1531, L1633, L1731, L1831, L2033, L2131, L2231, L2331, L2433, L2531, L3033, L3133 |
| Ring of Jet | Mine | L1013, L1017, L1021, L1026, L1030, L1034, L1114, L1118, L1122, L1126, L1131, L1135, L1216, L1220, L1224, L1228, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311, L0512, L0612, L0810 |
| Standard of the Fell Warrior | Mine | L1314, L1319, L1323, L1327, L1331, L1335 |
| Standard of the Fell Warrior | Opponent | L0413, L0713, L0913, L1013 |
| Storm Daemon (Renegade 2.0) | Mine | L2123, L2127, L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L0721, L1021, L1621, L2021 |
| Twice-Blessed Armour | Mine | L0709, L0713, L0717, L0721, L0725, L0729, L0733, L1013, L1017, L1021, L1026, L1030, L1034 |
| Twice-Blessed Armour | Opponent | L0110, L0210, L0307, L0810 |
| Witch Hunter's Ward | Mine | L0709, L0713, L0717, L0721, L0725, L0729, L0733, L0810, L0815, L0819, L0823, L0827, L0831, L0835 |
| Witch Hunter's Ward | Opponent | L0307, L0508, L0608 |

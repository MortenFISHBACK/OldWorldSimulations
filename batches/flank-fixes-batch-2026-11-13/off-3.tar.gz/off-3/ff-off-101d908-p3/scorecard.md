# Doctrine scorecard: ff-off-101d908-p3

### Scorecard: ff-off-101d908-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 77 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 9 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 8 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 2 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 8 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 1 | 3 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 7 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 1 | 4 | 4 | 1 | 0 | 0 | 0 | 836 |
| L0516 | 6 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 1 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 1011 |
| L0620 | 2 | 1 | Opponent | - | - | 6 | 2 | 4 | 1 | 0 | 0 | 95 |
| L0709 | 1 | 1 | Mine | yes | 3 | - | 0 | 1 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 726 |
| L0725 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 560 |
| L0831 | 3 | 1 | Opponent | no | 1 | - | 1 | 2 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 560 |
| L0922 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 2 | 0 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 6 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 11 | 4 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 5 | 0 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 6 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 4 | 1 | 4 | 0 | 0 | 0 | 0 | 352 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 1 | 2 | 2 | 0 | 0 | 0 | 298 |
| L1633 | 1 | 1 | Mine | yes | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | no | 7 | 3 | 5 | 0 | 1 | 0 | 0 | 49 |
| L1731 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 5 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 7 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 3 | 3 | 3 | 1 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 2 | 0 | 0 | 458 |
| L2033 | 5 | 1 | Opponent | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 0 | 1 | 8 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 190 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 2 | 0 | 0 | 357 |
| L2832 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 3 | 3 | 3 | 2 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 380 |
| **Average** | | | Mine | 31% | 3.4 | 2.7 | 2.5 | 1.1 | 0.3 | 0.0 | 0.0 | 278.3 |
| **Average** | | | Opponent | 22% | 2.9 | 2.3 | 2.9 | 1.9 | 0.5 | 0.0 | 0.0 | 155.1 |

### KPIs: ff-off-101d908-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 90% (56 of 62); on the table 95% | 88% (46 of 52); on the table 88% | 89% (102 of 114); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (12 of 12); on the table 100% | 95% (18 of 19); on the table 95% | 97% (30 of 31); on the table 97% |
| Winner chose to pursue after the loser fled |  | 72% (21 of 29); on the table 76% | 47% (16 of 34); on the table 56% | 59% (37 of 63); on the table 65% |
| Winner chose to follow up or pursue (all three) |  | 86% (89 of 103); on the table 90% | 76% (80 of 105); on the table 79% | 81% (169 of 208); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 28% (96 of 342) | 35% (67 of 192) | 31% (163 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (96 of 233) | 44% (67 of 153) | 42% (163 of 386) |
| Points that never fought | lower | 37% (25526 of 68801) | 39% (27914 of 71990) | 38% (53440 of 140791) |
|   infantry points that never fought | lower | 43% (6056 of 14174) | 60% (8490 of 14220) | 51% (14546 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (157 of 272) | 61% (175 of 285) | 60% (332 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 1.8 uses a game | 92% (22 of 24); 2.2 uses a game | 96% (47 of 49); 2.0 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.3 uses a game | 17% (1 of 6); 0.0 uses a game | 40% (8 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 36% (5 of 14); 0.1 uses a game | 53% (18 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32405 of 59391) | 55% (35243 of 64043) | 55% (67648 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (21%) | 1.5 (43%) | 2.9 (29%) |
| MARCHED: its unit marched | 1.6 (24%) | 0.6 (17%) | 2.2 (21%) |
| CHARGED: its unit charged | 0.4 (5%) | 0.2 (6%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.2 (17%) | 0.7 (21%) | 1.9 (18%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (2%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 1.0 (14%) | 0.2 (6%) | 1.2 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (11%) | 0.1 (3%) | 0.8 (8%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.2 | 1.9 | 4.5 | 0.9 | 1.6 |
| not cast | 3.9 | 1.6 | 4.2 | 10.3 | 2.4 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (49%) | 0.4 (10%) | 2.9 (29%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (21%) | 0.6 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (9%) | 0.5 (11%) | 1.9 (18%) | 0.4 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.1 (6%) | 0.5 (3%) |
| GONE: slain | 1.1 (29%) | 0.1 (5%) | 0.7 (16%) | 1.2 (11%) | 0.2 (10%) | 2.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.3 (19%) | 0.4 (8%) | 0.8 (8%) | 0.1 (2%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (7%) | 0.1 (1%) | 0.1 (1%) | 0.6 (23%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (51%) | 0.2 (11%) | 1.8 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 56% (19 of 34) | 78% (14 of 18) | 63% (33 of 52) |
| the unit moved after it | 89% (17 of 19) | 93% (13 of 14) | 91% (30 of 33) |
| it charged on its next turn | 5% (1 of 19) | 7% (1 of 14) | 6% (2 of 33) |
| the enemy charged it first | 11% (2 of 19) | 14% (2 of 14) | 12% (4 of 33) |
| it fought by the end of its next turn | 11% (2 of 19) | 0% (0 of 14) | 6% (2 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (4 of 19) | 29% (4 of 14) | 24% (8 of 33) |
| none of these (no charge, no fight, no charge escaped) | 58% (11 of 19) | 50% (7 of 14) | 55% (18 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (499 of 794) | 53% (333 of 627) | 59% (832 of 1421) |
|   cavalry | 69% (47 of 68) | 47% (55 of 118) | 55% (102 of 186) |
|   character | 43% (49 of 114) | 20% (25 of 122) | 31% (74 of 236) |
|   chariot | 35% (35 of 101) | 67% (20 of 30) | 42% (55 of 131) |
|   infantry | 59% (117 of 198) | 63% (171 of 273) | 61% (288 of 471) |
|   monster | 48% (16 of 33) | 100% (3 of 3) | 53% (19 of 36) |
|   war machine | 84% (235 of 280) | 73% (59 of 81) | 81% (294 of 361) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (31%) | 1.6 (20%) | 4.2 (25%) |
| CHARGED: it charged | 1.2 (15%) | 1.6 (20%) | 2.9 (17%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.7 (9%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (13%) | 1.3 (16%) | 2.4 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.6 (7%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 1.5 (18%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.6 (7%) | 0.2 (2%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.2 | 1.2 | 79% | 8.3 pts | 35 pts |
| character | 2.5 | 0.9 | 79% | 9.1 pts | 23 pts |
| chariot | 1.5 | 0.8 | 73% | 14.2 pts | 22 pts |
| infantry | 12.5 | 3.9 | 76% | 8.6 pts | 107 pts |
| monster | 0.7 | 0.1 | 92% | 5.3 pts | 4 pts |
| war machine | 8.5 | 6.8 | 63% | 24.0 pts | 204 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.9 | 5.1 |
| Charges that made contact a game | 3.1 | 4.4 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.84 declared, 0.52 contact (25 units) | 1.05 declared, 0.79 contact (19 units) | 0.93 declared, 0.64 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.20 declared, 0.20 contact (5 units) | 1.09 declared, 0.73 contact (11 units) | 0.81 declared, 0.56 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.63 declared, 0.45 contact (214 units) | 0.68 declared, 0.52 contact (263 units) | 0.66 declared, 0.49 contact (477 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (45 of 77) | 53% (8 of 15) | 50% (5 of 10) | 57% (58 of 102) |
| Character in a unit | 84% (32 of 38) | 69% (11 of 16) | 80% (4 of 5) | 80% (47 of 59) |
| Character on its own | 77% (30 of 39) | 52% (21 of 40) | 37% (26 of 70) | 52% (77 of 149) |
| Chariot | 91% (10 of 11) | 67% (8 of 12) | - | 78% (18 of 23) |
| Infantry | 61% (43 of 70) | 52% (22 of 42) | 20% (1 of 5) | 56% (66 of 117) |
| Monster | 65% (22 of 34) | 71% (5 of 7) | - | 66% (27 of 41) |
| Monstrous | 60% (6 of 10) | 55% (6 of 11) | - | 57% (12 of 21) |
| War Machines | 60% (26 of 43) | 50% (1 of 2) | - | 60% (27 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 23% (22 of 96) | 29% | 55% (12 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 0.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 60% (6 of 10); on the table 80% | 58% (21 of 36) | 45% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (6 of 6); on the table 100% | - | 58% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (6 of 9); on the table 89% | 30% (9 of 30) | 48% | 63% (37 of 59) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 83% (15 of 18); on the table 83% | 30% (57 of 192) | 50% | 57% (42 of 74) | 94% (17 of 18); 5.8 uses a game | 25% (1 of 4); 0.1 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 90% (18 of 20); on the table 90% | 29% (12 of 42) | 43% | 63% (34 of 54) | 100% (9 of 9); 3.7 uses a game | 33% (4 of 12); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 62% (8 of 13); on the table 62% | - | 37% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 92% (12 of 13); on the table 92% | 83% (5 of 6) | 12% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 44% | 86% (6 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (8 of 8); on the table 100% | 0% (0 of 12) | 2% | 31% (5 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 75% (3 of 4); on the table 75% | 33% (4 of 12) | 60% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 83% (10 of 12); on the table 83% | 0% (0 of 6) | 24% | 50% (13 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 77% (24 of 31); on the table 81% | 43% (23 of 54) | 34% | 57% (26 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 79% (42 of 53); on the table 83% | 23% (7 of 30) | 30% | 61% (59 of 96) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (6 of 6); on the table 100% | 25% (3 of 12) | 38% | 79% (49 of 62) | 91% (10 of 11); 6.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ff-off-101d908-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (42) | 47% (26) | 46% (68) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.53 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.06 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.39 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.08 | 2.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.78 | 0.58 | 1.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.22 | 6.25 | 13.47 |

### Quality by phase: ff-off-101d908-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 48% (59 of 122) | 50% (81 of 162) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (152 of 356) | 54% (89 of 165) |
| Strategy | Close-in objectives charged next turn | 11% (21 of 191) | 15% (31 of 206) |
| Strategy | Support requests answered (helper made contact too) | 30% (3 of 10) | 41% (12 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 30% (3 of 10) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 52% (21 of 40) | 32% (13 of 41) |
| Strategy | Lone characters that fought | 75% (71 of 95) | 81% (75 of 93) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 278.3 | 155.1 |
| Movement | Fights charged into per game | 2.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 78, net +50 | 10 of 110, net +106 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 78, net +90 | 24 of 110, net +37 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 78, net +108 | 11 of 110, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 78, net +121 | 40 of 110, net +94 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.1 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (133 of 291) | 43% (143 of 329) |
| Shooting | Points destroyed by shooting units | 60.7 | 21.5 |
| Shooting | War machine shots | 6.5 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (122 of 235) | 37% (26 of 71) |
| Shooting | Points destroyed by war machines | 73.8 | 24.9 |
| Magic | Magic missiles cast | 1.9 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (23 of 67) | 33% (16 of 48) |
| Magic | Wounds caused by magic missiles | 3.9 | 2.3 |
| Magic | Wounds caused by other spells | 1.4 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 68.5 | 36.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.6 / 0.1 | 2.0 / 0.3 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 315.1 | 323.6 |
| Combat | Points run down | 109.0 | 107.5 |
| Combat | Net points per charged fight, damage counted | +76 | +73 |
| Combat | Net per 100 charger points, damage counted | +27.1 | +24.9 |
| Combat | First round won (charged fights) | 73% | 56% |
| Combat | Net points per charged fight | +83 | +64 |
| Combat | Net points per supported fight / lone fight | +163 / +69 | +98 / +57 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 97 | 64 of 132 |
| Game | Points lost | 684.1 | 665.1 |
| Game | VP from objectives | 591.9 | 550.6 |
| Game | Lone holders (player turns) | 3.4 | 2.9 |

- Mine won / drew / lost: 13 / 11 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +49 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1349
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ff-off-101d908-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 21.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +7.8 | 0.0 | 15.3 | 0.7 | +7.7 | 0.0 | 5.4 |
| BEST PREY | 3.7 | +295.8 | 123.0 | 88.9 | 4.2 | +275.2 | 158.8 | 77.6 |
| BEST PRIZE | 0.1 | +3.3 | 6.9 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | +14.6 | 0.0 | 0.0 | 0.5 | +7.8 | 0.0 | 4.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 80.4 | 3.9 | 0.2 | +0.0 | 24.2 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +216.2 | 306.9 | 58.5 | 1.1 | +83.8 | 78.3 | 16.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 12.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -4.8 | 21.2 | 0.0 | 0.2 | -5.4 | 20.8 | 12.0 |
| CAST JOB | 1.1 | +33.1 | 94.0 | 40.9 | 0.7 | +18.4 | 21.1 | 14.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +32.6 | 9.9 | 8.9 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 31.0 | 0.5 | +0.0 | 0.0 | 14.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +4.0 | 0.0 | 7.2 | 0.0 | +1.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 5.4 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 1.0 | -115.1 | 15.8 | 40.7 | 0.5 | -49.9 | 36.3 | 35.0 |
| CHARIOT NO STATIC JOB | 0.8 | +0.0 | 12.8 | 11.3 | 0.7 | +0.0 | 20.5 | 16.4 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 11.0 | 6.1 |
| COMBAT PIVOT | 0.5 | +0.0 | 25.0 | 26.5 | 0.7 | +0.0 | 11.0 | 49.6 |
| CONVEYANCE SEARCH | 0.6 | +59.5 | 26.3 | 40.8 | 0.4 | +51.5 | 6.5 | 14.1 |
| COUNTER-CHARGE COVER | 9.0 | +744.6 | 0.0 | 188.8 | 7.0 | +640.4 | 0.0 | 83.2 |
| EDGE GIVE GROUND | 0.2 | +16.2 | 30.3 | 0.0 | 0.1 | +2.6 | 7.4 | 0.0 |
| ELIXIR WORTH | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +138.5 | 0.0 | 30.5 | 1.1 | +88.7 | 0.0 | 8.9 |
| FALLBACK BY WORTH | 5.9 | +79.8 | 0.0 | 75.8 | 6.6 | +106.9 | 0.0 | 97.9 |
| FIGHT LIFT | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 102.7 | 5.7 | +0.0 | 0.0 | 67.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +137.4 | 0.0 | 14.4 | 0.9 | +129.5 | 0.0 | 39.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +6.3 | 0.0 | 25.4 | 0.1 | +12.4 | 0.0 | 0.0 |
| GIVES UP | 1.1 | -26.5 | 120.0 | 14.4 | 1.5 | -47.2 | 201.7 | 39.8 |
| GIVES UP ITS SCREEN | 0.5 | -6.4 | 17.2 | 9.2 | 0.8 | -15.2 | 48.9 | 11.7 |
| GROUND FLIERS | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 3.9 | 19.9 | 0.6 | +0.0 | 20.8 | 13.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +15.2 | 9.2 | 2.5 | 0.1 | +7.3 | 0.0 | 9.0 |
| HUNT DROPPED | 0.1 | +0.0 | 4.6 | 3.1 | 0.0 | +0.0 | 0.0 | 2.0 |
| HUNT IN PAIRS | 0.2 | +2.2 | 0.0 | 0.0 | 0.4 | +32.5 | 0.0 | 0.0 |
| HUNT KEPT | 0.3 | +6.5 | 22.9 | 2.5 | 0.1 | +1.4 | 0.0 | 2.9 |
| HUNT RESULT | 0.1 | +6.2 | 10.0 | 3.1 | 0.1 | +0.0 | 3.6 | 2.0 |
| HUNT THE GUNS | 0.2 | +82.0 | 9.2 | 2.5 | 0.1 | +31.5 | 0.0 | 6.1 |
| JOINT CHARGE PLAN | 0.1 | +5.9 | 0.0 | 3.2 | 0.2 | +3.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +4.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +0.7 | 4.7 | 6.6 | 0.3 | +2.2 | 11.3 | 0.0 |
| KEEPS ITS TARGET | 2.2 | +65.0 | 156.8 | 69.2 | 2.1 | +64.2 | 230.4 | 39.6 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +60.4 | 103.6 | 30.3 | 2.1 | +93.4 | 148.9 | 50.1 |
| KILLS COUNT NEXT TURN | 9.0 | +286.6 | 343.3 | 216.5 | 10.0 | +417.3 | 363.5 | 156.0 |
| LONE CHARACTER SAFE SPOT | 0.7 | +54.2 | 11.6 | 29.4 | 0.4 | +8.1 | 4.3 | 32.1 |
| LONE WIZARD HOLDS BACK | 1.5 | +0.0 | 68.2 | 33.1 | 1.7 | +0.0 | 25.5 | 27.6 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.1 | +81.0 | 70.7 | 22.6 | 0.9 | +42.9 | 38.9 | 10.7 |
| MANOEUVRE | 0.2 | +3.4 | 0.0 | 3.8 | 0.2 | +4.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +26.6 | 0.0 | 24.7 | 0.9 | +48.7 | 0.0 | 3.2 |
| MARCH ODDS | 1.1 | +59.7 | 25.1 | 10.6 | 0.8 | +55.7 | 21.5 | 7.4 |
| MARCH OVER CASTS | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | -0.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.1 | +201.9 | 0.0 | 98.3 | 4.6 | +221.0 | 0.0 | 111.2 |
| MISSILES IN THE MOVE | 4.2 | +126.3 | 0.0 | 99.3 | 4.2 | +74.3 | 0.0 | 51.4 |
| MISSILES NEXT TURN | 5.4 | +86.2 | 0.0 | 107.9 | 5.1 | +52.9 | 0.0 | 59.3 |
| MODEL FACING | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.6 | +41.3 | 0.0 | 26.6 | 0.3 | +12.2 | 0.0 | 11.0 |
| MOVE SPELL IN RANGE | 0.3 | +12.0 | 0.0 | 31.7 | 0.0 | +0.7 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.2 | -4.7 | 8.0 | 40.8 | 0.1 | -0.9 | 2.9 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +1.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -11.6 | 26.8 | 0.0 | 0.2 | -14.7 | 33.3 | 0.0 |
| NOT TURNED | 7.2 | +94.2 | 0.0 | 107.0 | 6.2 | +91.9 | 0.0 | 78.8 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 40.7 | 0.6 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 18.1 | -1015.0 | 37.4 | 258.9 | 17.2 | -1031.0 | 45.9 | 218.6 |
| OPENS A LANE | 0.2 | +1.0 | 9.0 | 8.2 | 0.1 | +0.1 | 2.3 | 0.0 |
| OPENS UP | 0.4 | +31.5 | 17.0 | 6.5 | 0.1 | +10.8 | 12.8 | 0.0 |
| OVERRUNS AWAY | 0.7 | +20.3 | 56.4 | 8.1 | 0.4 | +7.2 | 49.6 | 31.6 |
| PATHS CROSS | 2.3 | +139.6 | 0.0 | 21.9 | 2.4 | +198.5 | 0.0 | 42.9 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.9 | 0.0 | 0.0 |
| PLAN LEADS | 1.3 | +111.7 | 32.0 | 27.4 | 0.8 | +65.4 | 7.0 | 5.4 |
| PLAN RESULT | 37.0 | +1364.2 | 1165.7 | 913.0 | 37.4 | +1355.9 | 1219.8 | 866.7 |
| PURSUES BIG PREY | 0.1 | -4.2 | 0.0 | 0.0 | 0.2 | -11.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.2 | 0.0 | 1.5 | 0.0 | +0.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.9 | +131.0 | 0.0 | 45.3 | 3.0 | +167.2 | 0.0 | 41.2 |
| REDIRECT WEIGHED | 0.3 | +6.9 | 11.0 | 12.2 | 0.2 | +0.8 | 1.5 | 1.1 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +87.9 | 196.6 | 50.2 | 2.8 | +71.3 | 264.3 | 98.0 |
| SAFE SURE CHARGE | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -1.5 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.8 | +43.4 | 0.0 | 13.6 | 0.6 | +48.8 | 0.0 | 1.5 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +88.1 | 0.0 | 28.8 | 1.4 | +98.5 | 0.0 | 37.4 |
| SECOND HUNTER | 0.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +79.0 | 0.0 | 0.0 | 0.2 | +65.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.5 | +142.6 | 78.3 | 40.2 | 1.4 | +93.7 | 59.2 | 20.9 |
| SET-UP ANY TARGET | 0.4 | +51.0 | 0.0 | 0.0 | 0.2 | +16.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +7.5 | 0.0 | 10.6 | 0.1 | +6.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 73.6 | 10.6 | 0.2 | +0.0 | 40.8 | 0.0 |
| SHOTS IN THE MOVE | 13.1 | +649.4 | 0.0 | 187.8 | 9.2 | +301.8 | 0.0 | 129.5 |
| SPELL SETS UP CHARGE | 0.4 | +59.8 | 10.6 | 10.6 | 0.2 | +27.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +24.8 | 50.6 | 60.4 | 2.6 | +44.3 | 82.7 | 76.8 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| STOPS | 0.1 | +4.1 | 9.2 | 2.5 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.3 | 15.1 | 1.8 | 0.1 | -2.4 | 1.8 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -1.8 | 15.2 | 12.1 | 0.8 | +19.4 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.6 | +13.5 | 0.0 | 15.2 | 0.2 | +14.9 | 0.0 | 10.1 |
| TURN WORTH | 0.4 | -30.2 | 27.8 | 4.0 | 0.5 | -35.9 | 32.4 | 11.1 |
| TWO OR MORE ARRIVE | 0.5 | +6.2 | 21.2 | 12.0 | 0.3 | +5.3 | 6.9 | 8.0 |
| WEARS DOWN | 0.9 | +55.9 | 80.6 | 23.7 | 0.9 | +31.8 | 84.4 | 56.1 |
| WHO HITS BACK | 0.2 | +28.7 | 0.0 | 1.4 | 0.2 | +21.1 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.2 | +6.2 | 34.2 | 8.6 | 0.7 | +9.4 | 127.9 | 10.0 |
| WHOLE FIGHT GAIN | 0.2 | +46.1 | 10.9 | 0.0 | 0.5 | +21.9 | 28.7 | 2.2 |

### Rule changes: ff-off-101d908-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1271 | 1271 | 1271 | 35.31 | -73658 | -58.0 |
| PATHS CROSS | 171 | 171 | 171 | 4.75 | +12169 | +71.2 |
| KILLS COUNT NEXT TURN | 684 | 679 | 169 | 4.69 | +5299 | +31.4 |
| BEST PREY | 284 | 278 | 125 | 3.47 | +5391 | +43.1 |
| COUNTER-CHARGE COVER | 574 | 258 | 116 | 3.22 | +7649 | +65.9 |
| SEARCH SPOT | 107 | 107 | 106 | 2.94 | +6732 | +63.5 |
| FACES THE THREAT | 100 | 100 | 100 | 2.78 | +8180 | +81.8 |
| FALLBACK BY WORTH | 449 | 449 | 94 | 2.61 | +6721 | +71.5 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +9612 | +135.4 |
| ARTILLERY RE-ROLL WEIGHED | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| MARCH ODDS | 67 | 65 | 60 | 1.67 | +691 | +11.5 |
| SHOTS IN THE MOVE | 803 | 501 | 60 | 1.67 | +1849 | +30.8 |
| MAX FOR POSITIONING | 351 | 176 | 58 | 1.61 | +926 | +16.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 54 | 54 | 54 | 1.50 | +5198 | +96.3 |
| MARCH CHECK | 67 | 59 | 54 | 1.50 | +3101 | +57.4 |
| RISK BY ARC | 187 | 174 | 54 | 1.50 | +1804 | +33.4 |
| SAFER THAN THE JOB | 49 | 49 | 49 | 1.36 | +3319 | +67.7 |
| COMBAT PIVOT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 116 | 116 | 42 | 1.17 | -3587 | -85.4 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SET UP TOGETHER | 104 | 86 | 39 | 1.08 | +3088 | +79.2 |
| PLAN LEADS | 76 | 76 | 38 | 1.06 | +2518 | +66.3 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +806 | +23.0 |
| CANNON PLANNED TARGET | 244 | 244 | 35 | 0.97 | -1058 | -30.2 |
| CAST JOB | 63 | 60 | 35 | 0.97 | +626 | +17.9 |
| KILLS COUNT | 125 | 114 | 35 | 0.97 | +1648 | +47.1 |
| CHARIOT NO STATIC JOB | 52 | 52 | 34 | 0.94 | -2164 | -63.6 |
| KEEPS ITS TARGET | 155 | 150 | 34 | 0.94 | +570 | +16.8 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| MISSILES IN THE MOVE | 302 | 153 | 32 | 0.89 | +676 | +21.1 |
| MOVE AND CAST | 32 | 32 | 32 | 0.89 | +1928 | +60.2 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +1025 | +35.3 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOT REPLANNED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| REDIRECT COUNTER | 212 | 82 | 24 | 0.67 | +918 | +38.3 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +830 | +43.7 |
| WEARS DOWN | 64 | 61 | 18 | 0.50 | +746 | +41.4 |
| MAKE SURE TOGETHER | 71 | 49 | 17 | 0.47 | +917 | +53.9 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MANOEUVRE | 16 | 16 | 16 | 0.44 | +286 | +17.9 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.44 | +27 | +1.7 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1329 | +83.0 |
| CASTING BLOCK | 19 | 19 | 15 | 0.42 | +464 | +30.9 |
| OPENS UP | 18 | 15 | 13 | 0.36 | +739 | +56.8 |
| WHOLE FIGHT GAIN | 25 | 24 | 13 | 0.36 | +1002 | +77.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -25 | -2.1 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +674 | +61.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -241 | -26.8 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -581 | -72.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +310 | +44.2 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| HUNT ADVANCE | 15 | 15 | 6 | 0.17 | +365 | +60.8 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +220 | +36.7 |
| OVERRUNS AWAY | 39 | 37 | 6 | 0.17 | +199 | +33.1 |
| WHOLE FIGHT | 30 | 27 | 6 | 0.17 | +736 | +122.7 |
| HUNT IN PAIRS | 24 | 13 | 5 | 0.14 | +74 | +14.9 |
| KEEPS ITS PREY | 20 | 19 | 5 | 0.14 | +9 | +1.7 |
| MISSILES NEXT TURN | 377 | 177 | 5 | 0.14 | +41 | +8.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE REACH TOGETHER | 43 | 32 | 4 | 0.11 | +12 | +3.0 |
| CARRIES OUT SET-UP | 12 | 12 | 3 | 0.08 | -367 | -122.3 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -52 | -17.3 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +74 | +24.8 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +18 | +6.1 |
| BACKUP TARGETS | 62 | 31 | 2 | 0.06 | +3 | +1.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -46 | -23.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +44 | +22.1 |
| EDGE GIVE GROUND | 12 | 10 | 2 | 0.06 | +126 | +62.9 |
| GIVES UP | 95 | 89 | 2 | 0.06 | +81 | +40.6 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -193 | -96.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +1 | +0.6 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +35 | +34.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +11 | +11.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +13 | +13.0 |
| GIVES UP ITS SCREEN | 46 | 45 | 1 | 0.03 | +13 | +13.0 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +132 | +131.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MODEL FACING | 1 | 1 | 1 | 0.03 | +105 | +105.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +106 | +105.9 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 40 | trace | - | - | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 430 | not checked | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 33 | 28 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 12 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 39 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 12 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 485 | 485 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2681 | trace | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 27 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 140 | not checked | - | - | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TURN WORTH | 32 | 28 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 31 | 30 | 0 | 0.00 | - | - |

### Off best figure: ff-off-101d908-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.14 | 14.44 | 61.3 |
| FALLBACK | gate | 0.92 | 1.03 | 53.4 |
| RULE SWITCHED OFF | gate | 0.86 | 0.72 | 17.6 |
| TURN GATE | gate | 0.67 | 0.44 | 46.7 |
| LONE WIZARD HOLDS BACK | rule | 0.50 | 0.50 | 99.6 |
| CHARIOT NO STATIC JOB | rule | 0.56 | 0.39 | 63.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.14 | 83.1 |
| PATHS CROSS | rule | 0.22 | 0.11 | 60.3 |
| CHARGE NOW WEIGHED | rule | 0.22 | 0.08 | 56.7 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 109.6 |
| AFTERMATH BAND | gate | 0.14 | 0.11 | 3.6 |
| CHAFF PASSED | rule | 0.14 | 0.11 | 2.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.11 | 26.8 |
| PURSUES BIG PREY | rule | 0.06 | 0.17 | 72.6 |
| THROUGH LINE OF FIRE | rule | 0.11 | 0.08 | 12.9 |
| BLOCKED WHEEL | rule | 0.06 | 0.11 | 15.9 |
| MARCH ODDS | rule | 0.08 | 0.08 | 41.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 52.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.08 | 86.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.8 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 122.3 |
| CATCH ODDS | rule | 0.06 | 0.03 | 17.3 |
| BEST PRIZE | rule | 0.06 | - | 23.1 |
| SAFE SURE CHARGE | rule | 0.03 | 0.03 | 96.3 |
| STAYS FIRST | gate | 0.06 | - | 4.7 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 4.7 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.9 |
| STANDS TO CAST | rule | 0.03 | - | 4.0 |
| WHO HITS BACK | rule | 0.03 | - | 3.6 |

### Plans: ff-off-101d908-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.5 | 16% | 544 | 337 | 62% |
| Mine | charge | 2.7 | 56% | 292 | 231 | 79% |
| Mine | close in | 5.3 | 19% | 391 | 144 | 37% |
| Mine | hold | 3.6 | 47% | 235 | 0 | 0% |
| Mine | join | 0.7 | 96% | 23 | 0 | 0% |
| Mine | shoot | 8.4 | 64% | 228 | 651 | 286% |
| Mine | support | 3.8 | 88% | 195 | 0 | 0% |
| Opponent | advance | 12.9 | 14% | 583 | 449 | 77% |
| Opponent | charge | 3.9 | 67% | 320 | 422 | 132% |
| Opponent | close in | 5.6 | 26% | 379 | 189 | 50% |
| Opponent | hold | 4.1 | 39% | 335 | 0 | 0% |
| Opponent | join | 1.0 | 94% | 45 | 0 | 0% |
| Opponent | shoot | 4.0 | 58% | 115 | 296 | 258% |
| Opponent | support | 5.9 | 89% | 202 | 0 | 0% |

### Packages: hunt the guns, ff-off-101d908-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 3 | 20% | 20% | 0% | 5.0 | 400 | 44 | 0% | 28 |
| Opponent | 0.1 | 3 | 0 | 0% | 0% | 0% | - | 378 | 0 | 0% | 107 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 3 | 33% | 33% | 0% | 5.0 | 411 | 74 | 0% | 24 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 542 | 0 | 0% | 131 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 110 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 159 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 229 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 298 | 0 | 0% | 77 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 54 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 102 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 253 | 0 | 0% | 60 |

### Battle groups: ff-off-101d908-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.0 | 23% | 49% | 3% | 0% | 56% | 1% | 8% | 34% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 33% | 71% | 15% | 60% | 17% | 3% | 14% | 62% | 3% |
| Opponent | COUNTER-CHARGE COVER | 7.0 | 20% | 53% | 18% | 33% | 28% | 15% | 10% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 25% | 70% | 19% | 20% | 36% | 0% | 5% | 50% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-off-101d908-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 40 | 39 (40) | 8 | 31 | 47 | 48% | 2.7 | 57 (20) | 0 (8) | 34 (12) | 50 (32) | 0 (8) |
| Mine | Character | 120 | 52 (120) | 52 | 0 | 26 | 18% | 2.5 | 51 (42) | 61 (57) | 33 (7) | 54 (57) | 57 (49) |
| Mine | Clean-up | 15 | 66 (15) | 11 | 55 | 25 | 27% | 3.2 | 76 (7) | 44 (6) | 125 (2) | 97 (8) | 26 (7) |
| Mine | Fast Hammer | 43 | 30 (43) | 11 | 19 | 57 | 21% | 3.0 | 30 (24) | 32 (13) | 23 (6) | 38 (31) | 5 (12) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 33% | 6.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 38 (50) | 24 | 15 | 40 | 12% | 3.0 | 8 (13) | 45 (32) | 75 (5) | 29 (34) | 57 (16) |
| Mine | Holder | 25 | 55 (25) | 11 | 44 | 25 | 56% | 3.3 | 6 (8) | 99 (11) | 9 (6) | 66 (14) | 40 (11) |
| Mine | Shooter | 38 | 62 (38) | 26 | 37 | 53 | 3% | 1.7 | 54 (10) | 72 (25) | 6 (3) | 64 (24) | 59 (14) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 39 | 25% | 2.0 | 0 (1) | 0 (1) | 0 (2) | 0 (3) | 0 (1) |
| Mine | War machine | 52 | 59 (52) | 59 | 0 | 27 | 0% | 1.2 | 90 (14) | 52 (34) | 0 (4) | 52 (14) | 62 (38) |
| Mine | Wizard | 15 | 9 (15) | 9 | 0 | 45 | 0% | 2.5 | 0 (2) | 18 (8) | 10 (1) | 2 (6) | 35 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 62 (73) | 23 | 39 | 57 | 37% | 3.1 | 35 (31) | 166 (13) | 32 (29) | 73 (52) | 37 (21) |
| Opponent | Character | 101 | 45 (101) | 45 | 0 | 31 | 19% | 2.2 | 42 (38) | 54 (50) | 27 (6) | 47 (53) | 48 (41) |
| Opponent | Clean-up | 9 | 55 (9) | 20 | 35 | 10 | 33% | 3.0 | 32 (3) | 39 (4) | 156 (2) | 70 (5) | 41 (4) |
| Opponent | Fast Hammer | 60 | 51 (60) | 28 | 23 | 38 | 33% | 2.7 | 45 (31) | 45 (17) | 84 (12) | 56 (32) | 44 (28) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 36 (47) | 28 | 8 | 47 | 30% | 3.0 | 16 (15) | 46 (28) | 0 (4) | 34 (25) | 39 (22) |
| Opponent | Holder | 40 | 68 (40) | 14 | 54 | 30 | 42% | 2.7 | 46 (10) | 86 (18) | 55 (12) | 75 (30) | 47 (10) |
| Opponent | Shooter | 28 | 21 (28) | 11 | 10 | 35 | 0% | 1.2 | 25 (7) | 21 (20) | 0 (1) | 25 (17) | 16 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (2) | 0 (2) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 48 (17) | 48 | 0 | 46 | 6% | 1.4 | 0 (3) | 41 (10) | 90 (4) | 36 (3) | 51 (14) |
| Opponent | Wizard | 33 | 12 (33) | 12 | 0 | 28 | 18% | 2.0 | 4 (15) | 53 (7) | 0 (4) | 5 (14) | 27 (12) |

### Charged fights: ff-off-101d908-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 113 | 94 | 1.0 | 1.2 | 94 | 0 | +94 | 0 of 4 | 3 of 4 | +45 | +110 |
| Mine | Chaos Dwarfs | 4 | 277 | 101 | 1.8 | 1.1 | 58 | 0 | +58 | 3 of 7 | 6 of 7 | +0 | +68 |
| Mine | Dwarfen Mountain Holds | 3 | 413 | 22 | 2.7 | 1.0 | 8 | 31 | -23 | 2 of 8 | 6 of 8 | - | -23 |
| Mine | Empire of Man | 5 | 359 | 106 | 2.0 | 1.0 | 53 | 58 | -5 | 3 of 10 | 9 of 10 | - | -5 |
| Mine | Grand Cathay | 5 | 398 | 314 | 2.6 | 1.2 | 121 | 0 | +121 | 2 of 13 | 10 of 13 | +221 | +103 |
| Mine | High Elf Realms | 4 | 137 | 497 | 4.2 | 1.3 | 117 | 48 | +68 | 8 of 17 | 13 of 17 | +62 | +71 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 731 | 4.0 | 1.2 | 183 | 0 | +183 | 0 of 4 | 3 of 4 | +418 | +104 |
| Mine | Lizardmen | 1 | 116 | 1890 | 6.0 | 1.5 | 315 | 8 | +307 | 2 of 6 | 5 of 6 | +387 | +226 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 62 | -62 | 1 of 2 | 0 of 2 | - | -62 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 844 | 8.0 | 1.1 | 106 | 97 | +8 | 3 of 8 | 5 of 8 | -55 | +18 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 492 | 4.0 | 1.0 | 123 | 24 | +100 | 2 of 8 | 3 of 8 | - | +100 |
| Mine | Vampire Counts | 2 | 0 | 314 | 4.0 | 1.1 | 78 | 8 | +71 | 1 of 8 | 6 of 8 | +19 | +78 |
| Mine | Warriors of Chaos | 2 | 19 | 422 | 1.0 | 1.0 | 422 | 0 | +422 | 1 of 2 | 2 of 2 | - | +422 |
| **Mine** | all armies | 36 | 203 | 301 | 2.7 | 1.2 | 112 | 29 | +83 | 28 of 97 | 71 of 97 | +163 | +69 |
| Opponent | Empire of Man | 1 | 380 | 398 | 4.0 | 1.0 | 100 | 0 | +100 | 2 of 4 | 1 of 4 | - | +100 |
| Opponent | Grand Cathay | 3 | 232 | 281 | 3.0 | 1.0 | 94 | 15 | +79 | 3 of 9 | 5 of 9 | - | +79 |
| Opponent | High Elf Realms | 3 | 158 | 230 | 1.3 | 1.0 | 173 | 274 | -101 | 3 of 4 | 2 of 4 | - | -101 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 648 | 2.5 | 1.4 | 259 | 0 | +259 | 4 of 5 | 2 of 5 | +406 | +161 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 302 | 5.0 | 1.2 | 60 | 0 | +60 | 1 of 5 | 4 of 5 | +0 | +76 |
| Opponent | Skaven | 1 | 275 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 42 | 592 | 5.0 | 1.1 | 118 | 27 | +91 | 11 of 20 | 12 of 20 | +8 | +101 |
| Opponent | Vampire Counts | 6 | 65 | 543 | 5.2 | 1.4 | 105 | 66 | +39 | 18 of 31 | 18 of 31 | +1 | +54 |
| Opponent | Warriors of Chaos | 9 | 5 | 356 | 4.0 | 1.2 | 89 | 11 | +78 | 15 of 36 | 22 of 36 | +104 | +71 |
| Opponent | Wood Elf Realms | 6 | 91 | 155 | 2.8 | 1.1 | 55 | 32 | +22 | 7 of 17 | 8 of 17 | +346 | -21 |
| **Opponent** | all armies | 36 | 83 | 369 | 3.7 | 1.2 | 101 | 36 | +64 | 64 of 132 | 74 of 132 | +98 | +57 |

### Effective charges: ff-off-101d908-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 3 (net +110) | 1 (net +45) | 0 | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 7 | 1 (net +170) | 0 | 0 | 3 (net +23) | 1 (net +0) | 2 (net +82) | 0 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 8 | 0 | 0 | 2 (net -123) | 3 (net +22) | 0 | 1 (net +0) | 2 | 33% (2 of 6) |
| Mine | Empire of Man | 10 | 1 (net +0) | 0 | 1 (net +0) | 4 (net -26) | 0 | 4 (net +12) | 0 | 10% (1 of 10) |
| Mine | Grand Cathay | 13 | 0 | 0 | 2 (net +328) | 2 (net +35) | 1 (net +127) | 8 (net +90) | 0 | 15% (2 of 13) |
| Mine | High Elf Realms | 17 | 2 (net -22) | 2 (net -241) | 0 | 3 (net +344) | 4 (net +159) | 4 (net -8) | 2 | 0% (0 of 15) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +190) | 0 | 0 | 1 (net +19) | 0 | 1 (net +418) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 6 | 0 | 0 | 0 | 2 (net +48) | 0 | 0 | 4 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 8 | 0 | 0 | 1 (net +340) | 0 | 0 | 0 | 7 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 0 | 1 (net -122) | 3 (net +18) | 1 (net +60) | 2 (net +402) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 8 | 3 (net +43) | 0 | 0 | 0 | 0 | 4 (net +104) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +422) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 4 | 0 | 0 | 1 (net +288) | 0 | 0 | 3 (net +37) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 9 | 2 (net +110) | 0 | 2 (net +70) | 1 (net +0) | 2 (net +81) | 1 (net +130) | 1 | 25% (2 of 8) |
| Opponent | High Elf Realms | 4 | 0 | 0 | 2 (net -347) | 1 (net +691) | 1 (net -400) | 0 | 0 | 50% (2 of 4) |
| Opponent | Kingdom of Bretonnia | 5 | 1 (net +388) | 1 (net +95) | 0 | 1 (net +0) | 0 | 2 (net +406) | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 1 (net +176) | 4 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 20 | 2 (net +0) | 0 | 1 (net +0) | 2 (net +412) | 3 (net +40) | 9 (net +73) | 3 | 6% (1 of 17) |
| Opponent | Vampire Counts | 31 | 2 (net -70) | 3 (net -406) | 6 (net +173) | 6 (net +92) | 3 (net +134) | 9 (net +63) | 2 | 21% (6 of 29) |
| Opponent | Warriors of Chaos | 36 | 3 (net +196) | 0 | 5 (net -20) | 7 (net +85) | 2 (net +88) | 14 (net +94) | 5 | 16% (5 of 31) |
| Opponent | Wood Elf Realms | 17 | 0 | 0 | 7 (net +30) | 2 (net +329) | 0 | 1 (net +0) | 7 | 70% (7 of 10) |

### Charged fights, damage counted: ff-off-101d908-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 360 | 362 | +50 | 94 | 59 | +35 | +9.7 |
| Mine | 50-54% | 2 | 464 | 421 | -241 | 53 | 462 | -408 | -87.9 |
| Mine | Effective (55-75%) | 7 | 235 | 264 | +90 | 158 | 66 | +92 | +39.1 |
| Mine | 76-89% | 24 | 232 | 155 | +68 | 94 | 24 | +70 | +30.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 274 | 172 | +121 | 149 | 28 | +121 | +44.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 425 | 87 | +108 | 114 | 5 | +109 | +25.7 |
| Mine | No odds | 19 | 249 | 162 | +80 | 138 | 70 | +67 | +26.9 |
| Mine | All fights | 97 | 280 | 188 | +83 | 124 | 48 | +76 | +27.1 |
| Opponent | Long shot (under 50%) | 10 | 264 | 352 | +106 | 202 | 140 | +62 | +23.4 |
| Opponent | 50-54% | 4 | 245 | 220 | -280 | 30 | 304 | -274 | -112.0 |
| Opponent | Effective (55-75%) | 24 | 316 | 243 | +37 | 112 | 56 | +56 | +17.5 |
| Opponent | 76-89% | 21 | 349 | 238 | +158 | 172 | 12 | +160 | +46.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 | 304 | 219 | +94 | 153 | 24 | +129 | +42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 392 | 103 | +42 | 129 | 109 | +20 | +5.2 |
| Opponent | No odds | 22 | 171 | 241 | +7 | 53 | 51 | +2 | +1.2 |
| Opponent | All fights | 132 | 294 | 230 | +64 | 130 | 57 | +73 | +24.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-off-101d908-p3 | move | 462 | 110 (24%) | 83 (18%) | 54 (12%) | 298 (65%) |
| ff-off-101d908-p3 | objective | 397 | 51 (13%) | 38 (10%) | 41 (10%) | 305 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

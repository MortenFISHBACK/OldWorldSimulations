# Doctrine scorecard: ff-off-101d908-p2

### Scorecard: ff-off-101d908-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 7 | 5 | 1 | 1 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | 6 | 3 | 0 | 0 | 0 | 0 | 1011 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 55 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 2 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 3 | - | 1 | 2 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 1 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 4 | 4 | 0 | 0 | 0 | 0 | 0 | 958 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 4 | 2 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 836 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 3 | 3 | 1 | 2 | 0 | 0 | 0 | 966 |
| L0528 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 2 | 5 | 1 | 4 | 1 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 6 | 0 | 0 | 0 | 0 | 501 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 0 | 1 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 2 | 5 | 4 | 1 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 1105 |
| L0934 | 4 | 1 | Opponent | no | 5 | 2 | 5 | 4 | 0 | 0 | 0 | 216 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 623 |
| L1026 | 6 | 1 | Opponent | no | 3 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 5 | 1 | 2 | 0 | 0 | 305 |
| L1135 | 1 | 1 | Mine | yes | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 432 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 3 | 5 | 1 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 2 | 0 | 0 | 60 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 4 | 2 | 0 | 3 | 0 | 0 | 0 | 432 |
| L1531 | 1 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 290 |
| L1629 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 98 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 60 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 3 | 0 | 0 | 0 | 0 | 525 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 0 | 6 | 3 | 3 | 0 | 0 | 0 | 722 |
| L2131 | 1 | 1 | Opponent | yes | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 392 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 7 | 0 | 0 | 0 | 0 | 55 |
| L2235 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 274 |
| L2429 | 5 | 1 | Mine | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 158 |
| L2735 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 75 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 2.3 | 2.8 | 2.4 | 1.4 | 0.2 | 0.0 | 0.0 | 345.1 |
| **Average** | | | Opponent | 27% | 1.9 | 2.7 | 3.2 | 1.7 | 0.4 | 0.0 | 0.0 | 225.6 |

### KPIs: ff-off-101d908-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 100% (61 of 61); on the table 100% | 97% (56 of 58); on the table 97% | 98% (117 of 119); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 96% (23 of 24); on the table 100% | 97% (33 of 34); on the table 100% |
| Winner chose to pursue after the loser fled |  | 65% (17 of 26); on the table 65% | 93% (41 of 44); on the table 95% | 83% (58 of 70); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 91% (88 of 97); on the table 91% | 95% (120 of 126); on the table 97% | 93% (208 of 223); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 27% (92 of 342) | 28% (43 of 156) | 27% (135 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (92 of 221) | 42% (43 of 102) | 42% (135 of 323) |
| Points that never fought | lower | 32% (22783 of 71583) | 37% (26879 of 71989) | 35% (49662 of 143572) |
|   infantry points that never fought | lower | 44% (7112 of 16324) | 57% (8027 of 14029) | 50% (15139 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (160 of 284) | 58% (172 of 297) | 57% (332 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 80% (16 of 20); 1.5 uses a game | 83% (15 of 18); 1.4 uses a game | 82% (31 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 50% (9 of 18); 0.6 uses a game | 50% (1 of 2); 0.0 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 52% (14 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30753 of 60231) | 51% (32532 of 63281) | 51% (63285 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (28%) | 0.8 (24%) | 2.7 (26%) |
| MARCHED: its unit marched | 1.2 (17%) | 0.5 (17%) | 1.7 (17%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.9 (27%) | 0.8 (25%) | 2.7 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.8 (11%) | 0.5 (15%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (10%) | 0.2 (5%) | 0.9 (9%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (1%) | 0.3 (3%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.5 | 1.3 | 3.8 | 0.4 | 2.2 |
| not cast | 3.9 | 3.4 | 3.7 | 10.1 | 1.9 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.7 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.3 (39%) | 0.2 (6%) | 2.7 (26%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (17%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.4 (11%) | 0.9 (25%) | 2.7 (26%) | 0.5 (28%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.4 (11%) | 0.2 (7%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.2 (7%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.5 (3%) |
| GONE: slain | 1.2 (30%) | 0.4 (12%) | 0.6 (17%) | 1.2 (12%) | 0.1 (4%) | 3.4 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (6%) | 0.4 (11%) | 0.9 (9%) | 0.2 (9%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.2 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (46%) | 0.1 (3%) | 1.1 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.9 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 55% (12 of 22) | 48% (12 of 25) | 51% (24 of 47) |
| the unit moved after it | 75% (9 of 12) | 58% (7 of 12) | 67% (16 of 24) |
| it charged on its next turn | 17% (2 of 12) | 8% (1 of 12) | 12% (3 of 24) |
| the enemy charged it first | 17% (2 of 12) | 17% (2 of 12) | 17% (4 of 24) |
| it fought by the end of its next turn | 8% (1 of 12) | 17% (2 of 12) | 12% (3 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (2 of 12) | 8% (1 of 12) | 12% (3 of 24) |
| none of these (no charge, no fight, no charge escaped) | 58% (7 of 12) | 67% (8 of 12) | 62% (15 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (564 of 852) | 50% (408 of 808) | 59% (972 of 1660) |
|   cavalry | 54% (36 of 67) | 50% (86 of 171) | 51% (122 of 238) |
|   character | 49% (44 of 89) | 27% (30 of 111) | 37% (74 of 200) |
|   chariot | 49% (46 of 94) | 60% (28 of 47) | 52% (74 of 141) |
|   infantry | 62% (167 of 269) | 54% (165 of 306) | 58% (332 of 575) |
|   monster | 43% (19 of 44) | 43% (18 of 42) | 43% (37 of 86) |
|   war machine | 87% (252 of 289) | 62% (81 of 131) | 79% (333 of 420) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (29%) | 3.3 (30%) | 5.6 (30%) |
| CHARGED: it charged | 1.4 (17%) | 2.0 (18%) | 3.4 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.7 (6%) | 1.5 (8%) |
| NO TARGET IN RANGE | 1.1 (13%) | 1.8 (16%) | 2.8 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.6 (5%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (23%) | 2.1 (18%) | 3.9 (20%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| OTHER BAR | 0.1 (2%) | 0.4 (4%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.0 | 85% | 3.9 pts | 20 pts |
| character | 2.2 | 0.9 | 74% | 10.0 pts | 22 pts |
| chariot | 2.1 | 1.4 | 73% | 12.6 pts | 26 pts |
| infantry | 12.5 | 5.3 | 71% | 9.6 pts | 119 pts |
| monster | 1.2 | 0.4 | 82% | 3.9 pts | 5 pts |
| war machine | 9.2 | 7.2 | 65% | 23.1 pts | 213 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.3 | 5.2 |
| Charges that made contact a game | 3.4 | 4.7 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.88 contact (25 units) | 1.54 declared, 1.31 contact (13 units) | 1.18 declared, 1.03 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.12 declared, 1.00 contact (8 units) | 1.08 declared, 0.75 contact (12 units) | 1.10 declared, 0.85 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.37 contact (246 units) | 0.65 declared, 0.48 contact (295 units) | 0.57 declared, 0.43 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (43 of 73) | 61% (11 of 18) | 58% (7 of 12) | 59% (61 of 103) |
| Character in a unit | 91% (21 of 23) | 73% (8 of 11) | 50% (1 of 2) | 83% (30 of 36) |
| Character on its own | 73% (36 of 49) | 47% (20 of 43) | 22% (14 of 64) | 45% (70 of 156) |
| Chariot | 76% (13 of 17) | 77% (10 of 13) | - | 77% (23 of 30) |
| Infantry | 52% (49 of 94) | 56% (19 of 34) | 0% (0 of 3) | 52% (68 of 131) |
| Monster | 66% (19 of 29) | 67% (6 of 9) | - | 66% (25 of 38) |
| Monstrous | 57% (8 of 14) | 43% (6 of 14) | - | 50% (14 of 28) |
| War Machines | 70% (40 of 57) | 50% (1 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 86% (6 of 7); on the table 86% | 16% (16 of 102) | 38% | 45% (10 of 22) | 50% (3 of 6); 2.0 uses a game | 50% (1 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (12 of 12); on the table 100% | 42% (15 of 36) | 38% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (13 of 13); on the table 100% | - | 54% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 94% (16 of 17); on the table 94% | 31% (15 of 48) | 37% | 54% (41 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 86% (19 of 22); on the table 86% | 32% (44 of 138) | 36% | 48% (26 of 54) | 93% (13 of 14); 7.7 uses a game | 50% (1 of 2); 0.2 uses a game | 33% (2 of 6); 0.3 uses a game |
| High Elf Realms | 4 | 83% (10 of 12); on the table 83% | 17% (3 of 18) | 28% | 42% (14 of 33) | 100% (3 of 3); 3.5 uses a game | 43% (6 of 14); 4.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (2 of 2); on the table 100% | - | 53% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | - | 21% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (10 of 10); on the table 100% | 6% (1 of 18) | 27% | 79% (22 of 28) | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 8% (1 of 12) | 3% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 83% (5 of 6); on the table 100% | 39% (7 of 18) | 35% | 60% (15 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 84% (16 of 19); on the table 84% | - | 33% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 95% (37 of 39); on the table 97% | 26% (17 of 66) | 22% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 93% (27 of 29); on the table 93% | 50% (9 of 18) | 35% | 51% (37 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 100% (28 of 28); on the table 100% | 29% (7 of 24) | 39% | 60% (47 of 78) | 57% (4 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ff-off-101d908-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (55) | 56% (36) | 53% (91) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.56 | 1.22 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.14 | 0.78 | 1.92 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.53 | 0.64 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.17 | 7.28 | 14.44 |

### Quality by phase: ff-off-101d908-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 54% (74 of 136) | 51% (103 of 202) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (152 of 343) | 50% (86 of 173) |
| Strategy | Close-in objectives charged next turn | 18% (28 of 154) | 16% (33 of 207) |
| Strategy | Support requests answered (helper made contact too) | 33% (5 of 15) | 50% (20 of 40) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (4 of 11) | 85% (11 of 13) |
| Strategy | Joined characters whose unit fought | 46% (18 of 39) | 26% (7 of 27) |
| Strategy | Lone characters that fought | 89% (94 of 106) | 80% (77 of 96) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 1.4 | 1.7 |
| Movement | Points that never moved of their own | 345.1 | 225.6 |
| Movement | Fights charged into per game | 3.0 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 97, net +67 | 18 of 126, net +160 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 97, net +147 | 29 of 126, net +90 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 97, net +116 | 10 of 126, net +145 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 97, net +101 | 41 of 126, net +121 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (133 of 335) | 46% (168 of 369) |
| Shooting | Points destroyed by shooting units | 79.6 | 35.8 |
| Shooting | War machine shots | 7.0 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (138 of 252) | 40% (32 of 81) |
| Shooting | Points destroyed by war machines | 103.6 | 46.1 |
| Magic | Magic missiles cast | 1.8 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (24 of 66) | 68% (19 of 28) |
| Magic | Wounds caused by magic missiles | 3.9 | 0.6 |
| Magic | Wounds caused by other spells | 2.3 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 79.8 | 43.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.4 / 0.9 / 0.1 | 2.0 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 364.4 | 428.6 |
| Combat | Points run down | 75.9 | 140.2 |
| Combat | Net points per charged fight, damage counted | +80 | +108 |
| Combat | Net per 100 charger points, damage counted | +26.2 | +39.8 |
| Combat | First round won (charged fights) | 63% | 58% |
| Combat | Net points per charged fight | +90 | +116 |
| Combat | Net points per supported fight / lone fight | +336 / +60 | +137 / +111 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 109 | 59 of 142 |
| Game | Points lost | 855.4 | 776.0 |
| Game | VP from objectives | 500.3 | 600.0 |
| Game | Lone holders (player turns) | 2.3 | 1.9 |

- Mine won / drew / lost: 16 / 2 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -198 VP
- The side that went first won 19 of 34 games with a winner
- Points traded per game (both sides' losses): 1631
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ff-off-101d908-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +4.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 37.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +5.9 | 0.0 | 11.0 | 1.0 | +17.0 | 0.0 | 13.7 |
| BEST PREY | 3.9 | +206.4 | 174.8 | 100.5 | 4.5 | +387.6 | 225.8 | 105.8 |
| BEST PRIZE | - | - | - | - | 0.1 | +8.0 | 10.6 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 8.2 | 0.0 | 0.2 | +0.0 | 3.4 | 0.0 |
| BLOCKED WHEEL | 0.2 | +5.2 | 0.0 | 19.8 | 0.6 | +5.7 | 0.0 | 9.2 |
| BOMBING RUN | 0.1 | +1.7 | 6.3 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 126.9 | 17.8 | 0.3 | +0.0 | 32.7 | 3.5 |
| CANNON PLANNED TARGET | 5.4 | +192.0 | 425.2 | 110.3 | 1.6 | +44.6 | 166.2 | 25.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.9 | 23.5 | 7.4 | 0.0 | +0.0 | 7.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.9 | 10.4 | 0.0 | 0.1 | +0.0 | 8.2 | 0.0 |
| CAST JOB | 0.8 | +12.8 | 43.9 | 7.5 | 0.4 | +11.3 | 27.4 | 12.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +24.3 | 15.4 | 8.2 | 0.2 | +11.9 | 19.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -0.6 | 19.1 | 2.2 | 0.2 | -0.3 | 0.0 | 3.2 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +2.8 | 8.9 | 0.0 |
| CHARGE NOW WEIGHED | 0.5 | -27.6 | 11.1 | 16.7 | 0.6 | -66.9 | 6.7 | 26.8 |
| CHARIOT NO STATIC JOB | 0.8 | +0.0 | 3.2 | 17.6 | 0.4 | +0.0 | 0.0 | 3.4 |
| CHEAP HELPER | 0.1 | +0.0 | 6.2 | 2.9 | 0.2 | +0.0 | 32.3 | 6.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 13.9 | 38.7 | 0.3 | +0.0 | 25.9 | 30.8 |
| CONVEYANCE SEARCH | 0.5 | +52.7 | 2.2 | 0.0 | 0.6 | +81.0 | 11.4 | 20.5 |
| COUNTER-CHARGE COVER | 10.8 | +797.4 | 0.0 | 222.1 | 7.5 | +676.4 | 0.0 | 178.8 |
| EDGE GIVE GROUND | 0.1 | +0.4 | 3.3 | 0.0 | 0.3 | +12.4 | 37.6 | 21.2 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| FACES THE THREAT | 1.1 | +85.9 | 0.0 | 54.6 | 0.8 | +75.0 | 0.0 | 19.0 |
| FALLBACK BY WORTH | 6.0 | +106.8 | 0.0 | 67.1 | 7.9 | +147.5 | 0.0 | 110.0 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 16.1 | 0.1 | +2.2 | 13.1 | 9.8 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.1 | 10.9 | 0.0 |
| FLANK NOT WEIGHED | 6.9 | +0.0 | 0.0 | 135.5 | 6.1 | +0.0 | 0.0 | 167.6 |
| FOCUS FIRE | 0.1 | +3.1 | 4.7 | 2.3 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.1 | +149.7 | 0.0 | 33.1 | 1.4 | +218.4 | 0.0 | 56.5 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.6 | 0.0 | 6.5 | 0.1 | +9.5 | 0.0 | 16.6 |
| GIVES UP | 1.2 | -35.7 | 132.6 | 39.8 | 1.2 | -38.4 | 160.2 | 60.6 |
| GIVES UP ITS SCREEN | 0.4 | -5.1 | 6.7 | 3.0 | 1.5 | -48.0 | 155.7 | 15.6 |
| GROUND FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.2 | 2.3 | 0.0 | +0.0 | 6.3 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 1.2 | 16.5 | 0.6 | +0.0 | 38.1 | 21.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +2.3 | 0.0 | 6.2 | 0.1 | +3.0 | 11.1 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +18.7 | 0.0 | 0.0 | 0.4 | +19.0 | 0.0 | 13.9 |
| HUNT KEPT | 0.0 | +0.6 | 0.0 | 2.4 | 0.1 | +4.4 | 31.4 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.4 | 0.2 | +47.6 | 0.0 | 2.8 |
| HUNT THE GUNS | 0.1 | +37.1 | 0.0 | 3.8 | 0.2 | +89.3 | 16.5 | 0.8 |
| JOINT CHARGE PLAN | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +3.4 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.3 | +1.4 | 10.1 | 8.5 | 0.2 | +3.0 | 1.7 | 16.1 |
| KEEPS ITS TARGET | 1.9 | +55.8 | 147.0 | 39.6 | 2.7 | +80.0 | 283.9 | 97.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +82.8 | 107.8 | 46.3 | 2.2 | +87.8 | 223.0 | 63.9 |
| KILLS COUNT NEXT TURN | 7.5 | +265.5 | 309.7 | 218.2 | 10.2 | +498.3 | 413.3 | 308.8 |
| LONE CHARACTER SAFE SPOT | 0.4 | +14.8 | 12.9 | 5.6 | 0.1 | +3.3 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 1.1 | +0.0 | 35.2 | 37.6 | 1.1 | +0.0 | 68.2 | 23.8 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +41.8 | 17.3 | 11.7 | 0.8 | +39.7 | 34.0 | 24.2 |
| MANOEUVRE | 0.1 | +2.6 | 0.0 | 0.0 | 0.2 | +3.1 | 0.0 | 6.2 |
| MARCH AT ESCAPER | 0.0 | +0.1 | 0.0 | 2.2 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +20.0 | 0.0 | 2.4 | 0.7 | +41.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.6 | +62.0 | 24.7 | 21.6 | 0.5 | +42.9 | 17.6 | 31.1 |
| MARCH OVER CASTS | 0.6 | +58.8 | 0.0 | 13.4 | 0.2 | +38.5 | 0.0 | 9.9 |
| MAX FOR POSITIONING | 5.1 | +165.2 | 0.0 | 135.1 | 5.0 | +206.0 | 0.0 | 120.1 |
| MISSILES IN THE MOVE | 3.7 | +86.6 | 0.0 | 91.8 | 3.0 | +70.3 | 0.0 | 65.4 |
| MISSILES NEXT TURN | 4.5 | +62.1 | 0.0 | 102.8 | 3.3 | +49.7 | 0.0 | 83.6 |
| MODEL FACING | 0.2 | +67.9 | 0.0 | 3.3 | 0.3 | +93.9 | 0.0 | 3.3 |
| MOVE AND CAST | 0.2 | +8.8 | 0.0 | 0.0 | 0.2 | +9.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +2.1 | 0.0 | 16.1 | 0.0 | +1.1 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -28.3 | 9.4 | 45.1 | 0.2 | -8.5 | 5.1 | 26.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +12.7 | 1.1 | 0.0 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.0 |
| NOT NEEDED | 0.2 | -21.3 | 49.4 | 0.0 | 0.4 | -21.2 | 51.1 | 5.7 |
| NOT TURNED | 7.2 | +131.1 | 0.0 | 147.1 | 7.3 | +98.4 | 0.0 | 166.7 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 15.0 | 0.6 | -0.5 | 0.0 | 9.8 |
| OFF BEST | 19.2 | -1073.8 | 26.2 | 312.3 | 18.2 | -1129.9 | 34.7 | 342.2 |
| OPENS A LANE | 0.2 | +0.4 | 13.2 | 0.0 | 0.1 | +0.2 | 5.1 | 6.3 |
| OPENS UP | 0.0 | +3.2 | 3.2 | 0.0 | 0.3 | +29.3 | 14.6 | 18.3 |
| OVERRUNS AWAY | 0.4 | +15.2 | 43.0 | 14.0 | 0.6 | +11.4 | 58.9 | 22.0 |
| PATHS CROSS | 1.9 | +122.6 | 0.0 | 12.9 | 3.0 | +196.8 | 0.0 | 48.2 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| PLAN LEADS | 1.4 | +159.2 | 32.8 | 18.9 | 1.2 | +77.6 | 10.6 | 5.4 |
| PLAN RESULT | 37.0 | +1462.0 | 1390.6 | 1072.3 | 40.8 | +1336.8 | 1499.3 | 1022.7 |
| PURSUES BIG PREY | 0.1 | -8.5 | 0.0 | 0.0 | 0.2 | -8.7 | 0.0 | 16.6 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.2 | +207.7 | 0.0 | 66.4 | 4.2 | +336.4 | 0.0 | 64.5 |
| REDIRECT WEIGHED | 0.2 | +5.1 | 9.9 | 13.8 | 0.4 | +21.9 | 22.8 | 5.4 |
| RESTRAINS TO SHOOT | 0.1 | +2.9 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +118.7 | 198.7 | 53.9 | 3.2 | +45.9 | 334.0 | 110.9 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -9.9 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.5 | +36.7 | 0.0 | 17.9 | 0.6 | +49.3 | 0.0 | 10.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 1.5 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.8 | +90.7 | 0.0 | 54.1 | 2.4 | +168.1 | 0.0 | 52.5 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.5 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.2 | +13.4 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.8 | +44.3 | 17.3 | 11.7 | 1.6 | +78.7 | 40.3 | 56.8 |
| SET-UP ANY TARGET | 0.2 | +20.5 | 2.2 | 0.0 | 0.2 | +19.4 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +7.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 119.0 | 15.0 | 0.5 | +0.0 | 59.8 | 11.8 |
| SHOTS IN THE MOVE | 14.0 | +574.8 | 0.0 | 256.8 | 10.4 | +296.8 | 0.0 | 163.4 |
| SPELL SETS UP CHARGE | 0.3 | +65.3 | 2.2 | 0.0 | 0.3 | +58.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +16.6 | 60.0 | 60.0 | 1.8 | +36.5 | 68.9 | 62.2 |
| STANDS TO CAST | - | - | - | - | 0.1 | +3.5 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +10.2 | 36.8 | 0.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT JOB KEPT | - | - | - | - | 0.1 | +0.0 | 8.7 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -16.4 | 16.5 | 8.7 | 0.2 | -9.5 | 8.9 | 7.0 |
| SURE REACH TOGETHER | 0.6 | +1.3 | 8.5 | 10.7 | 0.7 | -7.5 | 0.0 | 8.4 |
| THROUGH LINE OF FIRE | 0.2 | +25.5 | 0.0 | 5.9 | 0.2 | -0.2 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -12.7 | 21.1 | 4.2 | 0.4 | -21.9 | 28.0 | 12.9 |
| TWO OR MORE ARRIVE | 0.2 | +0.9 | 7.0 | 1.8 | 0.2 | +0.7 | 6.5 | 3.8 |
| WEARS DOWN | 1.0 | +55.1 | 143.1 | 28.8 | 1.8 | +51.6 | 175.4 | 55.9 |
| WHO HITS BACK | 0.2 | +18.3 | 0.0 | 27.8 | 0.1 | +2.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +10.9 | 98.8 | 14.2 | 0.4 | +16.7 | 66.2 | 1.4 |
| WHOLE FIGHT GAIN | 0.3 | +30.6 | 30.9 | 5.8 | 0.6 | +52.5 | 74.9 | 14.1 |

### Rule changes: ff-off-101d908-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1345 | 1345 | 1345 | 37.36 | -79334 | -59.0 |
| KILLS COUNT NEXT TURN | 636 | 624 | 200 | 5.56 | +6612 | +33.1 |
| PATHS CROSS | 178 | 178 | 178 | 4.94 | +11500 | +64.6 |
| SEARCH SPOT | 150 | 150 | 148 | 4.11 | +9314 | +62.9 |
| BEST PREY | 302 | 293 | 136 | 3.78 | +6159 | +45.3 |
| FALLBACK BY WORTH | 502 | 502 | 131 | 3.64 | +9155 | +69.9 |
| COUNTER-CHARGE COVER | 658 | 308 | 128 | 3.56 | +6941 | +54.2 |
| FOLLOW UP WEIGHED | 87 | 87 | 87 | 2.42 | +13252 | +152.3 |
| ARTILLERY RE-ROLL WEIGHED | 79 | 79 | 79 | 2.19 | +0 | +0.0 |
| FACES THE THREAT | 69 | 69 | 69 | 1.92 | +5796 | +84.0 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KILLS COUNT | 136 | 127 | 44 | 1.22 | +1497 | +34.0 |
| SHOTS IN THE MOVE | 880 | 518 | 44 | 1.22 | +1226 | +27.9 |
| MAX FOR POSITIONING | 366 | 184 | 42 | 1.17 | +237 | +5.7 |
| RISK BY ARC | 201 | 189 | 42 | 1.17 | +1558 | +37.1 |
| SAFER THAN THE JOB | 42 | 42 | 42 | 1.17 | +3097 | +73.7 |
| MARCH CHECK | 43 | 42 | 41 | 1.14 | +2362 | +57.6 |
| CHARGE NOW WEIGHED | 40 | 40 | 40 | 1.11 | +3561 | +89.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KEEPS ITS TARGET | 163 | 162 | 38 | 1.06 | +662 | +17.4 |
| MARCH ODDS | 40 | 39 | 38 | 1.06 | +1232 | +32.4 |
| SET UP TOGETHER | 85 | 73 | 38 | 1.06 | +1571 | +41.4 |
| SHOT REPLANNED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| PLAN LEADS | 94 | 94 | 37 | 1.03 | +1815 | +49.1 |
| MISSILES IN THE MOVE | 240 | 132 | 36 | 1.00 | +684 | +19.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| REDIRECT COUNTER | 268 | 94 | 32 | 0.89 | +1843 | +57.6 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +392 | +13.1 |
| CANNON PLANNED TARGET | 251 | 251 | 30 | 0.83 | -589 | -19.6 |
| CHARIOT NO STATIC JOB | 44 | 44 | 26 | 0.72 | -1733 | -66.7 |
| LONE WIZARD HOLDS BACK | 77 | 77 | 26 | 0.72 | -2000 | -76.9 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +1139 | +47.5 |
| WEARS DOWN | 102 | 96 | 24 | 0.67 | +561 | +23.4 |
| CHAFF PASSED | 23 | 23 | 23 | 0.64 | -35 | -1.5 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| CAST JOB | 42 | 41 | 19 | 0.53 | +226 | +11.9 |
| MODEL FACING | 19 | 19 | 19 | 0.53 | +5826 | +306.6 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +908 | +56.7 |
| CASTING BLOCK | 21 | 21 | 15 | 0.42 | +647 | +43.2 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MAKE SURE TOGETHER | 52 | 33 | 15 | 0.42 | +669 | +44.6 |
| MOVE AND CAST | 14 | 14 | 14 | 0.39 | +657 | +46.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 14 | 14 | 14 | 0.39 | -933 | -66.6 |
| WHOLE FIGHT GAIN | 32 | 24 | 14 | 0.39 | +877 | +62.6 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +430 | +33.1 |
| BLOCKED CHARGE SKIPPED | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 283 | 148 | 11 | 0.31 | +42 | +3.8 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -618 | -61.9 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +508 | +56.4 |
| MANOEUVRE | 8 | 8 | 8 | 0.22 | +206 | +25.8 |
| WHOLE FIGHT | 30 | 27 | 7 | 0.19 | +190 | +27.2 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +283 | +47.2 |
| SURE REACH TOGETHER | 47 | 33 | 6 | 0.17 | +118 | +19.6 |
| BACKUP TARGETS | 71 | 32 | 5 | 0.14 | +64 | +12.8 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +214 | +42.8 |
| OPENS UP | 13 | 12 | 5 | 0.14 | +329 | +65.8 |
| OVERRUNS AWAY | 38 | 36 | 5 | 0.14 | +32 | +6.5 |
| HUNT IN PAIRS | 22 | 16 | 4 | 0.11 | +227 | +56.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| EDGE GIVE GROUND | 14 | 14 | 3 | 0.08 | +83 | +27.7 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +41 | +13.6 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -44 | -22.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +110 | +55.2 |
| HUNT ADVANCE | 8 | 8 | 2 | 0.06 | +62 | +30.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +20 | +10.0 |
| SUPPORT JOB KEPT | 2 | 2 | 2 | 0.06 | +74 | +37.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 6 | 6 | 1 | 0.03 | -31 | -31.0 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -70 | -69.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +14 | +14.5 |
| GIVES UP | 87 | 86 | 1 | 0.03 | +15 | +14.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +9 | +8.7 |
| KEEPS ITS PREY | 18 | 15 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 3 | 3 | 1 | 0.03 | +0 | +0.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| OPENS A LANE | 10 | 4 | 1 | 0.03 | +2 | +1.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +49 | +49.2 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -449 | -448.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 44 | 44 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 13 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 471 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 69 | 62 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 24 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 520 | 520 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| PLAN RESULT | 2799 | trace | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STOPS | 8 | 8 | 0 | 0.00 | - | - |
| TURN WORTH | 20 | 20 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: ff-off-101d908-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.44 | 15.72 | 61.4 |
| FALLBACK | gate | 1.17 | 0.94 | 45.1 |
| RULE SWITCHED OFF | gate | 0.56 | 0.67 | 14.1 |
| TURN GATE | gate | 0.50 | 0.39 | 35.6 |
| CHARIOT NO STATIC JOB | rule | 0.39 | 0.33 | 66.6 |
| LONE WIZARD HOLDS BACK | rule | 0.28 | 0.25 | 105.2 |
| PATHS CROSS | rule | 0.17 | 0.25 | 44.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.19 | 66.6 |
| SUPPORT REQUEST | gate | 0.14 | 0.22 | 151.8 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 59.7 |
| PURSUES BIG PREY | rule | 0.11 | 0.17 | 61.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.08 | 66.6 |
| CHAFF PASSED | rule | 0.14 | 0.08 | 4.4 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.0 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.03 | 24.4 |
| BLOCKED WHEEL | rule | 0.06 | 0.08 | 35.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 126.0 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.8 |
| BEST PRIZE | rule | - | 0.06 | 22.0 |
| MARCH ODDS | rule | 0.06 | - | 35.5 |
| REDIRECT WEIGHED | rule | - | 0.06 | 22.0 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 94.9 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 31.0 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 69.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 22.6 |
| SAFE SURE CHARGE | rule | - | 0.03 | 448.8 |
| STANDS TO CAST | rule | - | 0.03 | 4.1 |
| STAYS FIRST | gate | 0.03 | - | 90.0 |

### Plans: ff-off-101d908-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 17% | 594 | 366 | 62% |
| Mine | charge | 3.1 | 58% | 324 | 305 | 94% |
| Mine | close in | 4.3 | 26% | 268 | 88 | 33% |
| Mine | hold | 4.1 | 37% | 325 | 0 | 0% |
| Mine | join | 0.5 | 95% | 14 | 0 | 0% |
| Mine | shoot | 8.2 | 62% | 307 | 703 | 229% |
| Mine | support | 4.8 | 88% | 245 | 0 | 0% |
| Opponent | advance | 14.9 | 16% | 674 | 417 | 62% |
| Opponent | charge | 4.7 | 53% | 504 | 405 | 80% |
| Opponent | close in | 5.6 | 27% | 484 | 207 | 43% |
| Opponent | hold | 4.3 | 34% | 369 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 38 | 0 | 0% |
| Opponent | shoot | 3.9 | 65% | 147 | 307 | 209% |
| Opponent | support | 6.5 | 93% | 336 | 0 | 0% |

### Packages: hunt the guns, ff-off-101d908-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 334 | 0 | 0% | 48 |
| Opponent | 0.2 | 7 | 0 | 57% | 71% | 0% | 2.8 | 459 | 245 | 57% | 134 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 360 | 0 | 0% | 20 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 321 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 416 | 0 | 0% | 20 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 137 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 276 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 75% | 75% | 0% | 2.7 | 461 | 291 | 50% | 67 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 4.0 | 431 | 415 | 100% | 28 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 345 | 66 | 50% | 250 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 446 | 0 | 0% | 71 |

### Battle groups: ff-off-101d908-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.8 | 19% | 57% | 19% | 57% | 40% | 9% | 5% | 47% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 26% | 60% | 17% | 0% | 20% | 4% | 8% | 68% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 19% | 65% | 23% | 17% | 48% | 2% | 10% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 4.2 | 19% | 83% | 17% | 20% | 42% | 0% | 4% | 54% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ff-off-101d908-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 67 | 20% | 3.0 | 0 (3) | 0 (1) | - | - | 0 (4) |
| Mine | Chaff | 44 | 17 (44) | 4 | 13 | 69 | 34% | 3.3 | 30 (24) | 0 (5) | 0 (15) | 24 (30) | 0 (14) |
| Mine | Character | 123 | 57 (123) | 57 | 0 | 46 | 11% | 2.5 | 61 (34) | 64 (52) | 34 (10) | 76 (56) | 38 (40) |
| Mine | Clean-up | 12 | 38 (12) | 8 | 30 | 47 | 50% | 2.5 | 52 (3) | 22 (6) | 65 (3) | 60 (7) | 10 (5) |
| Mine | Fast Hammer | 45 | 40 (45) | 20 | 20 | 46 | 27% | 3.0 | 36 (24) | 71 (10) | 12 (11) | 45 (31) | 29 (14) |
| Mine | Fragile | 5 | 26 (5) | 26 | 0 | 40 | 0% | 2.0 | - | 44 (3) | 0 (2) | 26 (5) | - |
| Mine | Hammer | 58 | 36 (58) | 30 | 6 | 49 | 19% | 2.8 | 20 (15) | 38 (33) | 57 (10) | 38 (38) | 32 (20) |
| Mine | Holder | 28 | 27 (28) | 0 | 27 | 38 | 39% | 3.2 | 5 (9) | 42 (14) | 27 (5) | 41 (16) | 9 (12) |
| Mine | Shooter | 43 | 100 (43) | 25 | 75 | 45 | 2% | 1.8 | 73 (7) | 121 (26) | 56 (10) | 141 (27) | 27 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 34 | 50% | 6.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 67 (59) | 67 | 0 | 43 | 2% | 1.2 | 145 (13) | 59 (36) | 3 (10) | 85 (10) | 63 (49) |
| Mine | Wizard | 22 | 16 (22) | 16 | 0 | 58 | 14% | 2.3 | 6 (7) | 40 (8) | 5 (3) | 41 (8) | 5 (10) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 0% | 5.5 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 46 (89) | 22 | 24 | 46 | 35% | 2.7 | 50 (35) | 26 (20) | 55 (34) | 47 (63) | 42 (26) |
| Opponent | Character | 94 | 68 (94) | 68 | 0 | 38 | 22% | 2.5 | 84 (48) | 55 (32) | 50 (6) | 61 (61) | 93 (25) |
| Opponent | Clean-up | 10 | 46 (10) | 18 | 28 | 78 | 30% | 3.3 | 31 (6) | 91 (3) | 0 (1) | 27 (7) | 106 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 45 | 32 (45) | 24 | 9 | 50 | 24% | 3.2 | 26 (28) | 46 (8) | 40 (9) | 39 (28) | 20 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 3.0 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 69 | 32 (69) | 22 | 10 | 41 | 29% | 2.9 | 29 (19) | 34 (37) | 28 (13) | 33 (40) | 30 (29) |
| Opponent | Holder | 33 | 65 (33) | 17 | 48 | 25 | 39% | 2.9 | 15 (8) | 84 (21) | 45 (3) | 70 (18) | 61 (14) |
| Opponent | Shooter | 35 | 101 (35) | 38 | 63 | 31 | 0% | 1.9 | 42 (11) | 143 (17) | 74 (7) | 128 (23) | 60 (12) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 67% | 5.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 61 (24) | 61 | 0 | 18 | 8% | 1.9 | 153 (6) | 36 (15) | 30 (3) | 0 (2) | 67 (22) |
| Opponent | Wizard | 29 | 31 (29) | 31 | 0 | 62 | 3% | 1.6 | 21 (13) | 83 (5) | 0 (5) | 59 (12) | 8 (11) |

### Charged fights: ff-off-101d908-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 30 | 232 | 0.8 | 1.0 | 310 | 28 | +282 | 2 of 3 | 3 of 3 | - | +282 |
| Mine | Chaos Dwarfs | 4 | 351 | 575 | 2.5 | 1.2 | 230 | 34 | +196 | 8 of 10 | 8 of 10 | +530 | +113 |
| Mine | Dwarfen Mountain Holds | 4 | 822 | 76 | 1.5 | 1.2 | 51 | 134 | -83 | 3 of 6 | 4 of 6 | +0 | -99 |
| Mine | Empire of Man | 5 | 279 | 192 | 2.0 | 1.1 | 96 | 55 | +41 | 5 of 10 | 5 of 10 | +522 | -13 |
| Mine | Grand Cathay | 4 | 430 | 546 | 3.8 | 1.2 | 145 | 16 | +130 | 4 of 15 | 13 of 15 | +378 | +92 |
| Mine | High Elf Realms | 4 | 197 | 553 | 5.0 | 1.2 | 111 | 14 | +97 | 6 of 20 | 17 of 20 | +314 | +24 |
| Mine | Kingdom of Bretonnia | 1 | 494 | 440 | 6.0 | 1.0 | 73 | 0 | +73 | 2 of 6 | 3 of 6 | - | +73 |
| Mine | Lizardmen | 1 | 45 | 54 | 5.0 | 1.0 | 11 | 0 | +11 | 1 of 5 | 2 of 5 | - | +11 |
| Mine | Ogre Kingdoms | 1 | 0 | 186 | 3.0 | 1.0 | 62 | 11 | +51 | 1 of 3 | 0 of 3 | - | +51 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 535 | 6.0 | 1.0 | 89 | 28 | +62 | 1 of 6 | 4 of 6 | - | +62 |
| Mine | Skaven | 2 | 100 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 1136 | 8.0 | 1.0 | 142 | 64 | +78 | 4 of 8 | 2 of 8 | - | +78 |
| Mine | Vampire Counts | 3 | 0 | 453 | 4.0 | 1.1 | 113 | 70 | +44 | 2 of 12 | 6 of 12 | +120 | +37 |
| Mine | Warriors of Chaos | 1 | 19 | 1042 | 3.0 | 1.0 | 347 | 0 | +347 | 1 of 3 | 2 of 3 | - | +347 |
| **Mine** | all armies | 36 | 263 | 379 | 3.0 | 1.1 | 125 | 35 | +90 | 41 of 109 | 69 of 109 | +336 | +60 |
| Opponent | Dwarfen Mountain Holds | 2 | 110 | 186 | 3.0 | 1.5 | 62 | 0 | +62 | 0 of 6 | 6 of 6 | +55 | +68 |
| Opponent | Empire of Man | 2 | 675 | 388 | 4.0 | 1.4 | 97 | 0 | +97 | 0 of 8 | 6 of 8 | +87 | +103 |
| Opponent | Grand Cathay | 2 | 238 | 790 | 6.0 | 1.3 | 132 | 0 | +132 | 7 of 12 | 8 of 12 | +142 | +128 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 3 | 41 | 292 | 6.0 | 1.1 | 49 | 0 | +49 | 5 of 18 | 10 of 18 | +52 | +48 |
| Opponent | Skaven | 1 | 188 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 126 | 1008 | 3.8 | 1.3 | 269 | 88 | +181 | 9 of 15 | 7 of 15 | +173 | +184 |
| Opponent | Vampire Counts | 6 | 15 | 609 | 3.7 | 1.1 | 166 | 56 | +110 | 13 of 22 | 9 of 22 | +220 | +99 |
| Opponent | Warriors of Chaos | 8 | 0 | 562 | 3.5 | 1.2 | 160 | 45 | +115 | 14 of 28 | 20 of 28 | +231 | +90 |
| Opponent | Wood Elf Realms | 7 | 205 | 654 | 4.4 | 1.1 | 148 | 3 | +144 | 9 of 31 | 15 of 31 | +62 | +153 |
| **Opponent** | all armies | 36 | 125 | 565 | 3.9 | 1.2 | 143 | 28 | +116 | 59 of 142 | 82 of 142 | +137 | +111 |

### Effective charges: ff-off-101d908-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +282) | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 10 | 2 (net +184) | 0 | 2 (net +366) | 3 (net +193) | 1 (net +85) | 2 (net +98) | 0 | 20% (2 of 10) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 2 (net -164) | 0 | 0 | 0 | 2 (net +138) | 2 | 0% (0 of 4) |
| Mine | Empire of Man | 10 | 3 (net +62) | 0 | 1 (net -265) | 2 (net +314) | 0 | 4 (net -36) | 0 | 10% (1 of 10) |
| Mine | Grand Cathay | 15 | 0 | 0 | 2 (net +495) | 6 (net +62) | 0 | 7 (net +84) | 0 | 13% (2 of 15) |
| Mine | High Elf Realms | 20 | 0 | 0 | 3 (net +47) | 3 (net +0) | 6 (net +176) | 5 (net +123) | 3 | 18% (3 of 17) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 1 (net +30) | 0 | 2 | 25% (1 of 4) |
| Mine | Lizardmen | 5 | 3 (net +0) | 0 | 0 | 0 | 1 (net +0) | 1 (net +54) | 0 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 6 | 1 (net +250) | 0 | 0 | 1 (net -55) | 2 (net +50) | 0 | 2 | 0% (0 of 4) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 2 (net +0) | 3 (net +109) | 0 | 3 (net +99) | 0 | 25% (2 of 8) |
| Mine | Vampire Counts | 12 | 1 (net +0) | 0 | 2 (net +156) | 4 (net +62) | 1 (net +125) | 4 (net -41) | 0 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +350) | 1 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 6 | 0 | 0 | 2 (net +32) | 2 (net +85) | 0 | 2 (net +68) | 0 | 33% (2 of 6) |
| Opponent | Empire of Man | 8 | 0 | 0 | 3 (net +123) | 1 (net +120) | 1 (net +85) | 1 (net +110) | 2 | 50% (3 of 6) |
| Opponent | Grand Cathay | 12 | 2 (net +253) | 0 | 2 (net +69) | 2 (net +126) | 4 (net +95) | 2 (net +152) | 0 | 17% (2 of 12) |
| Opponent | Ogre Kingdoms | 18 | 2 (net +165) | 0 | 4 (net +0) | 2 (net +76) | 0 | 6 (net +58) | 4 | 29% (4 of 14) |
| Opponent | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 15 | 1 (net +219) | 1 (net +0) | 2 (net +87) | 3 (net +52) | 1 (net +594) | 6 (net +234) | 1 | 14% (2 of 14) |
| Opponent | Vampire Counts | 22 | 4 (net +182) | 1 (net +0) | 6 (net +98) | 3 (net +317) | 0 | 5 (net +8) | 3 | 32% (6 of 19) |
| Opponent | Warriors of Chaos | 28 | 4 (net +110) | 0 | 5 (net +9) | 6 (net +118) | 3 (net +110) | 8 (net +147) | 2 | 19% (5 of 26) |
| Opponent | Wood Elf Realms | 31 | 3 (net +221) | 0 | 5 (net +244) | 7 (net +163) | 1 (net +60) | 11 (net +130) | 4 | 19% (5 of 27) |

### Charged fights, damage counted: ff-off-101d908-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 232 | 230 | +67 | 122 | 69 | +52 | +22.6 |
| Mine | 50-54% | 2 | 50 | 434 | -164 | 27 | 164 | -137 | -273.9 |
| Mine | Effective (55-75%) | 13 | 413 | 280 | +147 | 181 | 42 | +139 | +33.8 |
| Mine | 76-89% | 24 | 284 | 216 | +88 | 153 | 69 | +83 | +29.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 300 | 180 | +101 | 157 | 75 | +81 | +27.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 453 | 85 | +116 | 125 | 29 | +96 | +21.2 |
| Mine | No odds | 12 | 202 | 224 | +39 | 105 | 57 | +48 | +23.8 |
| Mine | All fights | 109 | 304 | 204 | +90 | 143 | 64 | +80 | +26.2 |
| Opponent | Long shot (under 50%) | 18 | 252 | 275 | +160 | 238 | 89 | +149 | +59.1 |
| Opponent | 50-54% | 2 | 232 | 237 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 29 | 260 | 217 | +90 | 151 | 62 | +89 | +34.2 |
| Opponent | 76-89% | 26 | 217 | 154 | +140 | 149 | 23 | +126 | +58.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 293 | 206 | +121 | 160 | 40 | +120 | +41.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 507 | 102 | +145 | 145 | 22 | +123 | +24.3 |
| Opponent | No odds | 16 | 199 | 164 | +57 | 93 | 55 | +38 | +19.0 |
| Opponent | All fights | 142 | 271 | 196 | +116 | 155 | 48 | +108 | +39.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ff-off-101d908-p2 | move | 497 | 118 (24%) | 95 (19%) | 49 (10%) | 330 (66%) |
| ff-off-101d908-p2 | objective | 361 | 61 (17%) | 51 (14%) | 43 (12%) | 257 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

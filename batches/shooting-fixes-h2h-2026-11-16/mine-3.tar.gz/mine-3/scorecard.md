# Doctrine scorecard: sf-h2h-mine-4394159-p3

### Scorecard: sf-h2h-mine-4394159-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0203 | 5 | 1 | Mine | yes | - | 3 | 2 | 6 | 0 | 0 | 0 | 170 |
| L0203 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 675 |
| L0215 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0215 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 84 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 4 | 4 | 0 | 2 | 2 | 0 | 0 | 375 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0308 | 2 | 1 | Opponent | - | - | 6 | 1 | 1 | 1 | 0 | 0 | 605 |
| L0313 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 675 |
| L0313 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 3 | 0 | 0 | 0 | 0 | 0 | 564 |
| L0528 | 6 | 1 | Mine | no | 5 | 6 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0613 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 615 |
| L0613 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 140 |
| L0617 | 5 | 1 | Mine | no | - | - | 2 | 2 | 1 | 0 | 0 | 515 |
| L0617 | 5 | 1 | Opponent | no | - | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 1362 |
| L0621 | 3 | 1 | Opponent | yes | 8 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L0711 | 3 | 1 | Mine | no | 10 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0711 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 501 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 375 |
| L0722 | 2 | 1 | Opponent | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 55 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 115 |
| L0819 | 3 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 2 | 0 | 0 | 0 |
| L0822 | 6 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0822 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0826 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0826 | 4 | 1 | Opponent | no | 7 | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0829 | 1 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 724 |
| L0829 | 1 | 1 | Opponent | no | 10 | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L0834 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0834 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 4 | 2 | 0 | 0 | 0 |
| L0920 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0920 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 3 | 0 | 0 | 420 |
| L0921 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 537 |
| L0921 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 4 | 0 | 0 | 0 | 290 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 596 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 55 |
| L0931 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 560 |
| L0931 | 1 | 1 | Opponent | no | 0 | - | 4 | 3 | 1 | 0 | 0 | 170 |
| L1022 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 497 |
| L1022 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1115 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1115 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Opponent | no | - | 3 | 1 | 1 | 1 | 0 | 0 | 395 |
| L1422 | 6 | 1 | Mine | no | 6 | 4 | 3 | 1 | 0 | 0 | 0 | 123 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 260 |
| L1518 | 6 | 1 | Mine | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1518 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 297 |
| L1524 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Mine | no | 1 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 3 | 4 | 1 | 1 | 0 | 0 | 305 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 70 |
| L1829 | 5 | 1 | Mine | yes | - | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 170 |
| L1834 | 4 | 1 | Mine | no | 0 | 3 | 5 | 0 | 2 | 0 | 0 | 0 |
| L1834 | 4 | 1 | Opponent | no | 3 | 2 | 7 | 2 | 0 | 0 | 0 | 716 |
| L2227 | 1 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | yes | 4 | 1 | 4 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 17% | 2.0 | 2.9 | 2.2 | 1.0 | 0.2 | 0.0 | 0.0 | 404.4 |
| **Average** | | | Opponent | 31% | 3.0 | 2.5 | 2.4 | 1.8 | 0.8 | 0.0 | 0.0 | 202.4 |

### KPIs: sf-h2h-mine-4394159-p3

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (80 of 177) | 9% (15 of 174) | 27% (95 of 351) |
| Winner chose to follow up after the loser gave ground |  | 95% (63 of 66); on the table 95% | 97% (57 of 59); on the table 100% | 96% (120 of 125); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 88% (15 of 17); on the table 88% | 93% (25 of 27); on the table 93% |
| Winner chose to pursue after the loser fled |  | 82% (18 of 22); on the table 86% | 75% (27 of 36); on the table 81% | 78% (45 of 58); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 93% (91 of 98); on the table 94% | 88% (99 of 112); on the table 92% | 90% (190 of 210); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 35% (73 of 210) | 28% (49 of 174) | 32% (122 of 384) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (73 of 161) | 39% (49 of 126) | 43% (122 of 287) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 29% (21 of 72) | 26% (25 of 96) | 27% (46 of 168) |
|     round 1 |  | 33% (4 of 12) | 12% (2 of 16) | 21% (6 of 28) |
|     rounds 2+ |  | 28% (17 of 60) | 29% (23 of 80) | 29% (40 of 140) |
|   other wizards | 50%+ | 38% (52 of 138) | 31% (24 of 78) | 35% (76 of 216) |
|     round 1 |  | 9% (2 of 23) | 31% (4 of 13) | 17% (6 of 36) |
|     rounds 2+ |  | 43% (50 of 115) | 31% (20 of 65) | 39% (70 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (10 of 15) | 57% (34 of 60) | 59% (44 of 75) |
| Points that never fought | lower | 41% (29275 of 70695) | 41% (29653 of 71984) | 41% (58928 of 142679) |
|   infantry points that never fought | lower | 43% (6813 of 15862) | 59% (8077 of 13803) | 50% (14890 of 29665) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (181 of 314) | 55% (146 of 267) | 56% (327 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (18 of 19); 1.5 uses a game | 88% (15 of 17); 1.0 uses a game | 92% (33 of 36); 1.3 uses a game |
| Bound items with another spell used |  | 40% (6 of 15); 0.2 uses a game | 20% (1 of 5); 0.1 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (8 of 20); 0.2 uses a game | 36% (4 of 11); 0.1 uses a game | 39% (12 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (31363 of 60076) | 50% (31051 of 62051) | 51% (62414 of 122127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (43%) | 1.1 (31%) | 2.7 (37%) |
| MARCHED: its unit marched | 0.6 (15%) | 0.5 (15%) | 1.1 (15%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.2 (5%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.8 (22%) | 0.6 (16%) | 1.4 (19%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.3 (8%) | 0.3 (5%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 0.4 (11%) | 0.6 (18%) | 1.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (3%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.1 (2%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.2 | 1.0 | 1.8 | 3.4 | 0.3 | 1.5 |
| not cast | 3.3 | 2.1 | 2.7 | 7.3 | 0.7 | 16.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (38%) | 0.2 (6%) | 2.7 (37%) | 0.1 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (15%) | 0.1 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.1 (5%) | 0.5 (19%) | 1.4 (19%) | 0.1 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (11%) | 0.4 (19%) | 0.6 (23%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (5%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.9 (29%) | 0.2 (10%) | 0.4 (16%) | 1.1 (15%) | 0.1 (15%) | 2.4 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (11%) | 0.1 (6%) | 0.1 (4%) | 0.2 (3%) | 0.0 (0%) | 0.8 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (13%) | 0.0 (0%) | 0.1 (1%) | 0.3 (38%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (36%) | 0.1 (3%) | 0.7 (24%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.7 (65%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 52% (17 of 33) | 75% (6 of 8) | 56% (23 of 41) |
| the unit moved after it | 71% (12 of 17) | 100% (6 of 6) | 78% (18 of 23) |
| it charged on its next turn | 6% (1 of 17) | 0% (0 of 6) | 4% (1 of 23) |
| the enemy charged it first | 12% (2 of 17) | 17% (1 of 6) | 13% (3 of 23) |
| it fought by the end of its next turn | 12% (2 of 17) | 17% (1 of 6) | 13% (3 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 24% (4 of 17) | 17% (1 of 6) | 22% (5 of 23) |
| none of these (no charge, no fight, no charge escaped) | 65% (11 of 17) | 67% (4 of 6) | 65% (15 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (819 of 1237) | 57% (473 of 834) | 62% (1292 of 2071) |
|   cavalry | 61% (69 of 114) | 76% (72 of 95) | 67% (141 of 209) |
|   character | 51% (53 of 103) | 18% (27 of 151) | 31% (80 of 254) |
|   chariot | 54% (92 of 169) | 44% (42 of 96) | 51% (134 of 265) |
|   infantry | 53% (173 of 329) | 64% (216 of 335) | 59% (389 of 664) |
|   monster | 71% (44 of 62) | 48% (20 of 42) | 62% (64 of 104) |
|   war machine | 84% (388 of 460) | 83% (96 of 115) | 84% (484 of 575) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.9 (25%) | 2.2 (22%) | 5.1 (23%) |
| CHARGED: it charged | 1.5 (13%) | 2.1 (21%) | 3.7 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (1%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.3 (11%) | 0.9 (9%) | 2.2 (10%) |
| MOVED: a war machine that moved | 0.2 (1%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.3 (20%) | 1.9 (19%) | 4.2 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.9 (9%) | 1.5 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (17%) | 1.3 (13%) | 3.2 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.3 (3%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.5 | 2.2 | 78% | 7.0 pts | 52 pts |
| character | 2.6 | 0.8 | 71% | 10.5 pts | 27 pts |
| chariot | 3.7 | 2.9 | 57% | 18.9 pts | 70 pts |
| infantry | 15.0 | 5.1 | 73% | 8.7 pts | 131 pts |
| monster | 2.3 | 1.0 | 71% | 9.0 pts | 21 pts |
| war machine | 13.4 | 10.3 | 62% | 28.0 pts | 377 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 6.1 | 4.7 |
| Charges that made contact a game | 2.6 | 4.1 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (14 units) | 0.68 declared, 0.47 contact (19 units) | 0.61 declared, 0.48 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 1.29 declared, 0.86 contact (7 units) | 0.92 declared, 0.69 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.31 contact (262 units) | 0.71 declared, 0.46 contact (282 units) | 0.57 declared, 0.39 contact (544 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (31 of 58) | 33% (6 of 18) | 46% (6 of 13) | 48% (43 of 89) |
| Character in a unit | 82% (28 of 34) | 50% (5 of 10) | 50% (1 of 2) | 74% (34 of 46) |
| Character on its own | 74% (29 of 39) | 40% (8 of 20) | 32% (19 of 60) | 47% (56 of 119) |
| Chariot | 62% (15 of 24) | 60% (15 of 25) | - | 61% (30 of 49) |
| Infantry | 52% (42 of 81) | 30% (8 of 27) | 33% (3 of 9) | 45% (53 of 117) |
| Monster | 58% (18 of 31) | 78% (7 of 9) | - | 62% (25 of 40) |
| Monstrous | 60% (3 of 5) | 61% (11 of 18) | - | 61% (14 of 23) |
| War Machines | 73% (68 of 93) | 80% (4 of 5) | - | 73% (72 of 98) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (17 of 17); on the table 100% | 45% (19 of 42) | 37% | 44% (8 of 18) | 100% (6 of 6); 5.7 uses a game | 0.0 uses a game | 50% (3 of 6); 1.0 uses a game |
| Chaos Dwarfs | 6 | 93% (14 of 15); on the table 93% | 35% (19 of 54) | 44% | 62% (30 of 48) | 0.0 uses a game | 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
| Dwarfen Mountain Holds | 5 | 83% (10 of 12); on the table 83% | - | 59% | 70% (33 of 47) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 16 | 90% (26 of 29); on the table 93% | 31% (24 of 78) | 44% | 62% (106 of 170) | 0.0 uses a game | 100% (3 of 3); 0.4 uses a game | 36% (4 of 11); 0.2 uses a game |
| Grand Cathay | 3 | 90% (9 of 10); on the table 90% | 45% (30 of 66) | 38% | 50% (13 of 26) | 67% (4 of 6); 4.0 uses a game | 0% (0 of 1); 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 11 | 94% (16 of 17); on the table 94% | 26% (11 of 42) | 38% | 49% (40 of 81) | 94% (15 of 16); 4.0 uses a game | 25% (4 of 16); 0.4 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 43% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 94% (17 of 18); on the table 100% | 8% (1 of 12) | 37% | 66% (23 of 35) | 100% (5 of 5); 2.6 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 8% (1 of 12) | 33% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 57% (4 of 7); on the table 71% | 17% (3 of 18) | 62% | 52% (13 of 25) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 7 | 85% (28 of 33); on the table 91% | 8% (1 of 12) | 28% | 43% (15 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (18 of 18); on the table 100% | 25% (9 of 36) | 37% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 92% (23 of 25); on the table 92% | 33% (4 of 12) | 33% | 44% (18 of 41) | 100% (1 of 1); 0.6 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 88% (7 of 8); on the table 88% | - | 55% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-mine-4394159-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (39) | 37% (19) | 46% (58) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.39 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.06 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.33 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.33 | 1.56 | 3.89 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.78 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.17 | 4.83 | 10.00 |

### Quality by phase: sf-h2h-mine-4394159-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 61% (68 of 112) | 47% (94 of 199) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (188 of 529) | 51% (124 of 242) |
| Strategy | Close-in objectives charged next turn | 10% (15 of 152) | 16% (39 of 238) |
| Strategy | Support requests answered (helper made contact too) | 50% (6 of 12) | 41% (15 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 55% (27 of 49) | 50% (13 of 26) |
| Strategy | Lone characters that fought | 58% (50 of 86) | 74% (70 of 95) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 404.4 | 202.4 |
| Movement | Fights charged into per game | 2.4 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 75, net +31 | 18 of 106, net +20 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 75, net +80 | 17 of 106, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 75, net +70 | 6 of 106, net +129 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 75, net +61 | 45 of 106, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.1 | 11.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (187 of 471) | 39% (168 of 427) |
| Shooting | Points destroyed by shooting units | 175.8 | 53.9 |
| Shooting | War machine shots | 10.8 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (206 of 388) | 44% (42 of 96) |
| Shooting | Points destroyed by war machines | 114.4 | 32.7 |
| Magic | Magic missiles cast | 1.1 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (7 of 41) | 26% (9 of 34) |
| Magic | Wounds caused by magic missiles | 2.6 | 1.6 |
| Magic | Wounds caused by other spells | 0.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 67.9 | 22.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.5 / 0.4 / 0.1 | 1.6 / 0.1 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 240.6 | 349.6 |
| Combat | Points run down | 45.8 | 74.4 |
| Combat | Net points per charged fight, damage counted | +53 | +74 |
| Combat | Net per 100 charger points, damage counted | +22.2 | +24.0 |
| Combat | First round won (charged fights) | 66% | 69% |
| Combat | Net points per charged fight | +53 | +81 |
| Combat | Net points per supported fight / lone fight | +4 / +59 | +113 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 85 | 58 of 118 |
| Game | Points lost | 708.4 | 777.0 |
| Game | VP from objectives | 530.8 | 637.8 |
| Game | Lone holders (player turns) | 2.0 | 3.0 |

- Mine won / drew / lost: 14 / 8 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -35 VP
- The side that went first won 14 of 28 games with a winner
- Points traded per game (both sides' losses): 1485
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-mine-4394159-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 27.9 | 0.8 | +0.0 | 0.0 | 19.0 |
| BACKUP TARGETS | 1.0 | +9.2 | 0.0 | 54.7 | 1.2 | +14.3 | 0.0 | 39.8 |
| BEST FACING | 0.8 | +44.8 | 0.0 | 28.7 | 0.8 | +31.5 | 0.0 | 6.8 |
| BEST FIRST | 4.5 | +202.8 | 233.9 | 70.4 | 4.0 | +151.4 | 74.3 | 46.4 |
| BEST MOVE FOR SHOOTERS | 1.4 | +113.8 | 0.0 | 9.7 | - | - | - | - |
| BEST OVERALL | 0.6 | +40.3 | 0.0 | 21.2 | 0.7 | +35.9 | 0.0 | 14.9 |
| BEST PREY | 0.7 | +34.8 | 17.3 | 6.5 | 1.0 | +63.7 | 70.7 | 23.1 |
| BEST PRIZE | 0.1 | -3.2 | 0.0 | 1.4 | 0.1 | -2.2 | 3.5 | 7.8 |
| BIG CHARACTER SAFETY | 0.2 | -1.3 | 0.0 | 16.1 | 0.1 | -1.4 | 0.0 | 37.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 1.7 | 11.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| BLOCKED WHEEL | 0.4 | +9.1 | 0.0 | 2.1 | 0.3 | +3.4 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 34.6 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 2.1 | +92.0 | 131.2 | 47.5 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.1 | 3.4 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -4.1 | 8.6 | 1.7 | 0.3 | +0.0 | 29.5 | 0.9 |
| CAST JOB | 0.8 | +20.1 | 42.8 | 5.2 | 0.4 | +4.3 | 33.7 | 4.7 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +14.6 | 3.5 | 0.0 | 0.1 | +1.2 | 1.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 35.8 | 0.4 | +0.0 | 0.0 | 55.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.4 | -2.1 | 6.5 | 16.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 181.9 | 15.9 | 3.3 | +0.0 | 273.6 | 72.3 |
| CHARGE NOW WEIGHED | 0.5 | -37.6 | 52.6 | 6.1 | 0.6 | -91.3 | 14.3 | 66.1 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 22.1 |
| CHEAP HELPER | 0.1 | +0.0 | 2.5 | 4.9 | 0.2 | +0.0 | 11.3 | 3.2 |
| COMBAT PIVOT | 0.5 | +0.0 | 16.2 | 23.8 | 0.4 | +0.0 | 25.0 | 38.3 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 5.4 |
| CONVEYANCE SEARCH | 0.9 | +107.9 | 36.0 | 18.6 | 0.1 | +7.8 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 10.3 | +932.4 | 0.0 | 266.6 | 7.7 | +644.3 | 0.0 | 221.4 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 22.2 | 5.4 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +8.2 | 9.6 | 0.0 | 0.4 | +7.0 | 33.0 | 8.3 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 2.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | 16.1 | +0.0 | 1071.9 | 263.5 | - | - | - | - |
| FACE THE CAST | 0.0 | +0.1 | 0.0 | 6.6 | - | - | - | - |
| FACES THE THREAT | 2.3 | +229.7 | 0.0 | 77.0 | 1.6 | +110.7 | 0.0 | 55.4 |
| FALLBACK BY WORTH | 5.6 | +100.9 | 0.0 | 104.3 | 5.4 | +55.1 | 0.0 | 40.1 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 27.1 | 0.1 | +0.2 | 4.9 | 0.0 |
| FIRE IN ORDER | 1.2 | +0.0 | 89.6 | 32.8 | - | - | - | - |
| FIRE PLAN | 24.4 | +71.7 | 1602.1 | 411.8 | - | - | - | - |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 132.9 | 5.1 | +0.0 | 0.0 | 182.2 |
| FOCUS FIRE | - | - | - | - | 0.1 | +3.3 | 6.3 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +224.3 | 0.0 | 36.8 | 1.4 | +167.0 | 0.0 | 35.4 |
| FRIENDS SHOTS CHECKED | 0.3 | +9.1 | 0.0 | 16.4 | 0.2 | +11.5 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -2.5 | 18.6 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 1.7 | 0.0 | 0.0 | -4.3 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 13.7 | 7.4 |
| HELPER UNSEEN | 0.1 | +0.0 | 7.6 | 0.0 | 0.3 | +0.0 | 30.4 | 3.7 |
| HILL BY ITS CHANCE | 0.2 | -17.8 | 0.0 | 2.5 | 0.4 | -27.0 | 0.0 | 5.1 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 16.1 | +2475.0 | 1071.9 | 263.5 | - | - | - | - |
| HUNT ADVANCE | 0.5 | +6.2 | 26.9 | 3.8 | 0.4 | +29.8 | 21.4 | 15.7 |
| HUNT DROPPED | 0.2 | +0.0 | 14.2 | 6.0 | 0.1 | +0.0 | 15.6 | 6.6 |
| HUNT IN PAIRS | - | - | - | - | 0.5 | +25.6 | 0.0 | 5.4 |
| HUNT KEPT | 0.3 | +2.3 | 33.8 | 2.4 | 0.2 | +19.5 | 26.0 | 9.6 |
| HUNT RESULT | 0.4 | +17.0 | 28.2 | 9.8 | 0.4 | +45.0 | 49.0 | 21.9 |
| HUNT THE GUNS | 0.4 | +105.7 | 13.3 | 2.9 | 0.4 | +177.2 | 29.0 | 12.0 |
| INVITES THE FIGHT | 1.2 | +26.1 | 57.8 | 20.5 | 1.1 | +18.3 | 39.5 | 45.6 |
| JOINT CHARGE PLAN | 0.1 | +0.6 | 0.0 | 0.0 | 0.2 | +10.0 | 10.3 | 1.7 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.2 | 2.4 | 2.4 | 0.1 | +1.1 | 0.0 | 5.8 |
| KEEPS ITS TARGET | 1.3 | +38.3 | 59.1 | 15.6 | 2.6 | +76.7 | 225.8 | 26.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 2.1 | -98.8 | 262.8 | 52.6 | - | - | - | - |
| KILLS COUNT | 1.6 | +76.0 | 119.0 | 24.3 | 2.3 | +94.0 | 163.9 | 75.4 |
| KILLS COUNT NEXT TURN | 5.3 | +168.7 | 153.4 | 87.8 | 7.4 | +296.7 | 365.5 | 227.9 |
| LONE CHARACTER SAFE SPOT | 0.5 | +5.6 | 3.1 | 5.0 | 0.4 | +19.5 | 14.8 | 55.5 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 4.9 | 12.2 |
| LONE WIZARD KEPT IN | 0.6 | +33.8 | 0.0 | 0.0 | 0.5 | +45.6 | 0.0 | 2.6 |
| LONG SHOT | 0.5 | -6.4 | 24.9 | 7.2 | 0.7 | +2.9 | 29.1 | 7.1 |
| LOST CHARGE | 3.6 | -73.6 | 105.1 | 77.7 | 1.9 | -34.2 | 31.2 | 72.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -1.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +44.3 | 18.1 | 1.7 | 1.2 | +110.7 | 42.8 | 53.3 |
| MANOEUVRE | 0.4 | +10.8 | 0.0 | 5.1 | 0.2 | +13.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.2 | +32.4 | 0.0 | 0.0 | 0.4 | +15.4 | 0.0 | 36.7 |
| MARCH ODDS | 0.3 | +16.3 | 12.6 | 30.0 | 0.1 | +20.4 | 11.5 | 11.0 |
| MARCH OVER CASTS | 0.4 | +55.3 | 0.0 | 7.2 | 0.3 | +25.7 | 0.0 | 5.5 |
| MAX FOR POSITIONING | 4.5 | +158.3 | 0.0 | 142.9 | 5.2 | +228.0 | 0.0 | 157.6 |
| MISSILES IN THE FIRE PLAN | 1.5 | +11.1 | 58.2 | 37.5 | - | - | - | - |
| MISSILES IN THE MOVE | 3.5 | +93.0 | 0.0 | 92.0 | 2.8 | +39.3 | 0.0 | 92.2 |
| MISSILES NEXT TURN | 4.0 | +68.3 | 0.0 | 99.2 | 3.6 | +28.4 | 0.0 | 112.8 |
| MODEL FACING | 0.6 | +111.5 | 0.0 | 10.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 12.0 | 0.0 | 0.1 | +0.0 | 10.3 | 0.0 |
| MOVE AND CAST | 0.2 | +3.2 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 15.7 |
| MOVE SPELL IN RANGE | 0.2 | +5.3 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -5.8 | 10.1 | 4.7 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 13.9 | 0.2 | +0.0 | 0.0 | 22.2 |
| MOVE TO CHARGE | 3.7 | +150.4 | 90.0 | 96.1 | 5.2 | +450.4 | 254.8 | 180.1 |
| MOVES UNITS SPELL | 0.2 | +5.2 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +11.5 | 2.1 | 0.0 |
| NOT NEEDED | 0.1 | -2.6 | 6.5 | 0.0 | 0.4 | -19.9 | 36.1 | 4.2 |
| NOT TURNED | 5.2 | +126.7 | 0.0 | 137.8 | 4.8 | +35.3 | 0.0 | 108.1 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 23.5 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.0 | -869.0 | 0.0 | 287.8 | 15.0 | -790.8 | 22.9 | 309.7 |
| ONE YARDSTICK | 22.2 | -771.6 | 598.2 | 338.8 | - | - | - | - |
| OPENS A LANE | 0.3 | +2.4 | 18.2 | 2.1 | 0.1 | +0.9 | 5.8 | 3.5 |
| OPENS UP | 0.1 | +8.4 | 6.3 | 0.0 | 0.3 | +22.6 | 18.3 | 0.0 |
| OVERRUNS AWAY | 0.5 | +9.3 | 10.8 | 4.0 | 0.5 | +10.8 | 23.3 | 32.9 |
| PATHS CROSS | 1.8 | +112.4 | 0.0 | 46.4 | 2.6 | +204.2 | 0.0 | 36.7 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.5 | 0.0 | 5.1 | 0.1 | -0.8 | 0.0 | 0.0 |
| PLAN RESULT | 40.4 | +1818.9 | 1788.4 | 938.5 | 39.9 | +1292.3 | 1487.0 | 1043.0 |
| PURSUES BIG PREY | 0.0 | -3.6 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +9.5 | 0.0 | 4.7 | 1.7 | +25.4 | 0.0 | 72.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -3.6 | 0.0 | 0.0 | 0.2 | -11.0 | 29.3 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.0 | 0.0 | 1.0 | 0.4 | -10.0 | 0.0 | 7.9 |
| REDIRECT COUNTER | 2.3 | +169.5 | 0.0 | 40.6 | 3.2 | +253.1 | 0.0 | 55.7 |
| REDIRECT WEIGHED | 0.2 | +4.4 | 4.9 | 0.0 | 0.4 | +4.2 | 3.5 | 8.6 |
| RESERVE FALL BACK | 0.1 | +4.5 | 0.0 | 2.0 | 0.8 | +21.8 | 0.0 | 23.1 |
| RESTRAINS TO SHOOT | 0.2 | +8.1 | 0.0 | 3.5 | 0.2 | +9.3 | 0.0 | 9.5 |
| RISK BY ARC | 2.2 | +83.5 | 143.8 | 35.9 | 3.2 | +69.3 | 219.8 | 117.1 |
| SAFER THAN THE JOB | 1.1 | +65.8 | 0.0 | 22.4 | 0.8 | +35.1 | 0.0 | 38.3 |
| SCOUT SPOT | 0.5 | +1.4 | 0.0 | 0.0 | 0.6 | +2.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.3 | 0.0 | 0.0 | 0.4 | -32.4 | 0.0 | 2.7 |
| SEARCH SPOT | 3.0 | +150.6 | 0.0 | 49.8 | 2.5 | +103.2 | 0.0 | 31.0 |
| SECOND HUNTER | 0.2 | -0.6 | 0.0 | 0.0 | 0.0 | -4.1 | 0.0 | 3.2 |
| SELF MOVE SPELL | 0.4 | +72.7 | 0.0 | 43.9 | 0.5 | +103.2 | 0.0 | 83.9 |
| SET UP TOGETHER | 1.1 | +50.3 | 21.8 | 3.3 | 1.6 | +137.6 | 58.2 | 90.1 |
| SET-UP ANY TARGET | 0.5 | +65.2 | 33.9 | 18.6 | 0.1 | +7.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +16.4 | 2.5 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 1.1 |
| SHOOTERS ARE THREATS | 3.6 | +184.4 | 317.4 | 58.2 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 3.3 | +38.9 | 0.0 | 39.9 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.7 | +26.0 | 55.0 | 3.5 | 1.0 | +30.1 | 58.2 | 8.9 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 22.9 | +0.0 | 1424.5 | 457.8 | 13.8 | +0.0 | 400.9 | 256.1 |
| SHOT REPLANNED | - | - | - | - | 0.4 | +0.0 | 70.6 | 17.8 |
| SHOTS IN THE MOVE | 21.4 | +1211.6 | 0.0 | 378.9 | 12.8 | +365.3 | 0.0 | 205.0 |
| SPELL SETS UP CHARGE | 0.5 | +65.2 | 33.9 | 18.6 | 0.1 | +13.2 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +8.1 | 11.8 | 22.8 | 1.6 | +34.8 | 75.1 | 58.6 |
| STABLE ROLE | 12.6 | +0.0 | 428.5 | 153.3 | 10.5 | +0.0 | 323.4 | 170.2 |
| STAY WEIGHED | 0.1 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 25.6 | +187.0 | 585.1 | 267.4 | - | - | - | - |
| STOPS | 0.1 | +0.4 | 14.0 | 1.4 | 0.2 | +12.5 | 22.6 | 6.0 |
| STOPS SHORT OF THE FLANK | 0.2 | +12.4 | 0.0 | 6.3 | 0.4 | +19.0 | 0.0 | 52.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 4.3 | -30.1 | 202.3 | 58.9 | 6.2 | -36.4 | 227.9 | 98.1 |
| SUPPORTS | 2.6 | +30.1 | 127.6 | 46.0 | 3.7 | +36.4 | 67.3 | 41.4 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -1.5 | 0.0 | 0.0 | 0.1 | -2.1 | 10.3 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +8.0 | 3.1 | 14.1 | 0.8 | +5.8 | 4.9 | 28.2 |
| THROUGH LINE OF FIRE | 0.5 | +39.9 | 0.0 | 24.9 | 0.3 | +6.9 | 0.0 | 3.2 |
| TURN WORTH | 0.4 | -35.4 | 25.8 | 0.0 | 0.7 | -56.4 | 41.3 | 17.2 |
| TWO OR MORE ARRIVE | 0.2 | +1.6 | 7.9 | 1.7 | 0.4 | +2.3 | 25.7 | 35.5 |
| WAIT AFTER COSTS | 7.4 | -295.7 | 201.5 | 149.6 | 8.0 | -469.3 | 335.4 | 236.1 |
| WALKS TO THE FIGHT | 2.6 | +57.4 | 45.7 | 31.5 | 1.1 | +20.4 | 22.0 | 18.8 |
| WAR ENGINE CHARGES | 0.2 | +23.1 | 4.7 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 26.9 | 5.1 | 0.3 | +0.0 | 1.7 | 14.3 |
| WEARS DOWN | 0.9 | +34.4 | 49.2 | 13.6 | 1.8 | +57.4 | 143.6 | 42.6 |
| WHO HITS BACK | 0.2 | +18.0 | 0.0 | 6.5 | 0.1 | +24.5 | 0.0 | 16.6 |
| WHOLE FIGHT | 0.2 | +22.8 | 19.6 | 0.0 | 0.2 | +6.7 | 25.4 | 1.5 |
| WHOLE FIGHT GAIN | 0.2 | +9.3 | 4.2 | 3.1 | 0.8 | +49.7 | 58.2 | 22.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 3.1 | 0.0 |

### Rule changes: sf-h2h-mine-4394159-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1117 | 1117 | 1117 | 31.03 | -59754 | -53.5 |
| BEST FIRST | 307 | 307 | 307 | 8.53 | +12755 | +41.5 |
| SEARCH SPOT | 198 | 198 | 196 | 5.44 | +9192 | +46.9 |
| FIRE PLAN | 879 | 879 | 187 | 5.19 | -224 | -1.2 |
| MOVE TO CHARGE | 319 | 319 | 180 | 5.00 | +7423 | +41.2 |
| KILLS COUNT NEXT TURN | 457 | 457 | 164 | 4.56 | +4725 | +28.8 |
| PATHS CROSS | 158 | 158 | 158 | 4.39 | +11398 | +72.1 |
| COUNTER-CHARGE COVER | 650 | 366 | 147 | 4.08 | +9018 | +61.3 |
| FACES THE THREAT | 140 | 140 | 140 | 3.89 | +12253 | +87.5 |
| SHOTS IN THE MOVE | 1233 | 837 | 139 | 3.86 | +4547 | +32.7 |
| EVERY WOUND COUNTS | 581 | 581 | 136 | 3.78 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 123 | 123 | 123 | 3.42 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 99 | 99 | 99 | 2.75 | +14086 | +142.3 |
| FALLBACK BY WORTH | 393 | 393 | 98 | 2.72 | +5615 | +57.3 |
| SUPPORTS | 228 | 228 | 89 | 2.47 | +761 | +8.6 |
| WALKS TO THE FIGHT | 134 | 134 | 77 | 2.14 | +1226 | +15.9 |
| WAIT AFTER COSTS | 555 | 555 | 72 | 2.00 | +1202 | +16.7 |
| ONE YARDSTICK | 799 | 376 | 70 | 1.94 | +750 | +10.7 |
| CANNON SIGHT KEPT | 67 | 67 | 67 | 1.86 | +0 | +0.0 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +3632 | +54.2 |
| BEST FACING | 55 | 55 | 55 | 1.53 | +2748 | +50.0 |
| REDIRECT COUNTER | 198 | 113 | 52 | 1.44 | +3699 | +71.1 |
| BEST MOVE FOR SHOOTERS | 50 | 50 | 50 | 1.39 | +4098 | +82.0 |
| STAY WORTH | 922 | 761 | 49 | 1.36 | +768 | +15.7 |
| BEST OVERALL | 47 | 47 | 47 | 1.31 | +2742 | +58.3 |
| KEEPS THE TARGET | 76 | 76 | 46 | 1.28 | -3901 | -84.8 |
| RISK BY ARC | 193 | 181 | 45 | 1.25 | +1089 | +24.2 |
| FIRE IN ORDER | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 44 | 1.22 | +1253 | +28.5 |
| LONE WIZARD KEPT IN | 42 | 42 | 42 | 1.17 | +2858 | +68.0 |
| MAX FOR POSITIONING | 350 | 202 | 42 | 1.17 | +396 | +9.4 |
| SCOUT WAITS | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 40 | 40 | 40 | 1.11 | +2250 | +56.3 |
| SET UP TOGETHER | 97 | 86 | 38 | 1.06 | +2032 | +53.5 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| MISSILES IN THE MOVE | 226 | 140 | 36 | 1.00 | +886 | +24.6 |
| HONEST THREAT | 581 | 581 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 140 | 136 | 35 | 0.97 | +1432 | +40.9 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| RESERVE FALL BACK | 33 | 33 | 33 | 0.92 | +947 | +28.7 |
| THROUGH LINE OF FIRE | 30 | 30 | 30 | 0.83 | +1686 | +56.2 |
| SHOOTERS IN TWO RANKS | 29 | 29 | 29 | 0.81 | +48 | +1.7 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +452 | +16.7 |
| KEEPS ITS TARGET | 138 | 137 | 25 | 0.69 | +334 | +13.3 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +1129 | +47.0 |
| MAKE SURE TOGETHER | 74 | 58 | 23 | 0.64 | +1083 | +47.1 |
| MARCH CHECK | 24 | 23 | 23 | 0.64 | +1193 | +51.9 |
| CHARGE NOW FIRST | 195 | 195 | 22 | 0.61 | -1097 | -49.9 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +365 | +16.6 |
| SHOOTS FROM THE BEST SPOT | 60 | 60 | 22 | 0.61 | +694 | +31.6 |
| BEST PREY | 62 | 62 | 21 | 0.58 | +1203 | +57.3 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +4013 | +200.6 |
| SHORT GUN FORWARD | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| SHOOTERS ARE THREATS | 129 | 129 | 19 | 0.53 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| MANOEUVRE | 22 | 22 | 18 | 0.50 | +882 | +49.0 |
| CAST JOB | 43 | 43 | 17 | 0.47 | +291 | +17.1 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +742 | +43.6 |
| WHOLE FIGHT GAIN | 34 | 29 | 17 | 0.47 | +742 | +43.7 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +387 | +24.2 |
| RESTRAINS TO SHOOT | 16 | 16 | 16 | 0.44 | +626 | +39.1 |
| SHOT REPLANNED | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| INVITES THE FIGHT | 81 | 81 | 15 | 0.42 | +325 | +21.7 |
| MARCH ODDS | 15 | 15 | 15 | 0.42 | +397 | +26.5 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -77 | -5.5 |
| WEARS DOWN | 94 | 89 | 13 | 0.36 | +428 | +33.0 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +1118 | +86.0 |
| MOVES UNITS SPELL | 11 | 11 | 11 | 0.31 | +221 | +20.1 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -96 | -9.6 |
| CANNON PLANNED TARGET | 77 | 77 | 9 | 0.25 | -24 | -2.6 |
| HUNT ADVANCE | 33 | 33 | 9 | 0.25 | +461 | +51.2 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -157 | -17.5 |
| OPENS UP | 15 | 15 | 8 | 0.22 | +308 | +38.5 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 379 | 379 | 8 | 0.22 | -121 | -15.2 |
| BACKUP TARGETS | 81 | 46 | 7 | 0.19 | +74 | +10.6 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| CASTING BLOCK | 10 | 10 | 7 | 0.19 | +176 | +25.1 |
| LOST CHARGE | 198 | 198 | 7 | 0.19 | +178 | +25.4 |
| SURE REACH TOGETHER | 49 | 34 | 7 | 0.19 | +233 | +33.2 |
| HUNT IN PAIRS | 19 | 11 | 6 | 0.17 | +154 | +25.7 |
| MISSILES NEXT TURN | 272 | 165 | 6 | 0.17 | +11 | +1.8 |
| OVERRUNS AWAY | 35 | 35 | 6 | 0.17 | +129 | +21.6 |
| WAR ENGINE JOBS | 27 | 27 | 6 | 0.17 | -585 | -97.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -192 | -38.4 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| EDGE GIVE GROUND | 16 | 15 | 4 | 0.11 | +149 | +37.2 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +158 | +39.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -175 | -43.8 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -127 | -31.7 |
| WAR ENGINE CHARGES | 6 | 6 | 4 | 0.11 | +314 | +78.6 |
| WHOLE FIGHT | 15 | 15 | 4 | 0.11 | +178 | +44.4 |
| DEFENSIVE ARMY | 12 | 12 | 3 | 0.08 | -126 | -41.8 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +120 | +39.9 |
| JOINT CHARGE PLAN | 11 | 11 | 3 | 0.08 | +200 | +66.8 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +114 | +38.2 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.08 | -178 | -59.3 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +57 | +28.4 |
| CARRIES OUT SET-UP | 13 | 13 | 2 | 0.06 | -149 | -74.6 |
| LONG SHOT | 41 | 40 | 2 | 0.06 | +3 | +1.3 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +100 | +50.2 |
| STOPS | 9 | 8 | 2 | 0.06 | +297 | +148.6 |
| TWO OR MORE ARRIVE | 22 | 22 | 2 | 0.06 | +23 | +11.4 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -40 | -40.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +3 | +2.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +10 | +9.6 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +3 | +3.1 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 7 | 5 | 1 | 0.03 | +0 | +0.3 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 14 | 9 | 1 | 0.03 | +30 | +29.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 1 | 0.03 | +1 | +1.1 |
| SHOOTERS TO THE PRIMARY | 119 | 89 | 1 | 0.03 | +2 | +1.6 |
| TURN WORTH | 39 | 38 | 1 | 0.03 | +3 | +3.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 12 | 12 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 14 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 375 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 15 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 18 | trace | - | - | - | - |
| HUNT RESULT | 27 | trace | - | - | - | - |
| HUNT THE GUNS | 27 | trace | - | - | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 53 | 4 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 20 | 0 | 0.00 | - | - |
| NOT TURNED | 360 | 360 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| PLAN RESULT | 2891 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 38 | 38 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SECOND HUNTER | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 32 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1321 | 1321 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 80 | not checked | - | - | - | - |
| STABLE ROLE | 832 | 830 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-mine-4394159-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.19 | 13.11 | 55.1 |
| FALLBACK | gate | 0.78 | 0.69 | 36.0 |
| TURN GATE | gate | 0.56 | 0.56 | 37.3 |
| KEEPS THE TARGET | rule | 0.97 | - | 128.8 |
| CHARGE NOW FIRST | rule | 0.31 | 0.31 | 49.9 |
| FIRE PLAN | rule | 0.58 | - | 154.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.22 | 53.0 |
| CHAFF PASSED | rule | - | 0.31 | 7.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.17 | 33.1 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 17.5 |
| SUPPORT REQUEST | gate | - | 0.25 | 130.5 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.08 | 12.6 |
| SUPPORT NARROWED | rule | 0.08 | 0.11 | 17.2 |
| WAR ENGINE JOBS | rule | 0.06 | 0.11 | 97.5 |
| AFTERMATH BAND | gate | 0.14 | - | 2.4 |
| BEST PRIZE | rule | 0.08 | 0.06 | 38.4 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 2.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.08 | 15.3 |
| PATHS CROSS | rule | 0.06 | 0.06 | 31.4 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 43.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.08 | 31.7 |
| DEFENSIVE ARMY | rule | 0.08 | - | 41.8 |
| FACES THE THREAT | rule | 0.08 | - | 8.9 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 14.3 |
| WOUNDED STAYS OUT | rule | - | 0.08 | 59.3 |
| CANNON PLANNED TARGET | rule | - | 0.06 | 11.9 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 74.6 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 2.5 |
| NO REASON | gate | 0.06 | - | 35.2 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 15.7 |
| WHO HITS BACK | rule | 0.06 | - | 1.3 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 40.3 |
| CATCH ODDS | rule | 0.03 | - | 1.5 |
| MARCH ODDS | rule | 0.03 | - | 3.8 |
| REDIRECT WEIGHED | rule | - | 0.03 | 7.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 26.4 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 7.5 |

### Plans: sf-h2h-mine-4394159-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.9 | 16% | 514 | 478 | 93% |
| Mine | charge | 2.7 | 57% | 258 | 177 | 68% |
| Mine | close in | 4.2 | 26% | 175 | 117 | 67% |
| Mine | hold | 4.3 | 27% | 243 | 0 | 0% |
| Mine | join | 1.1 | 92% | 15 | 0 | 0% |
| Mine | shoot | 12.4 | 63% | 592 | 1047 | 177% |
| Mine | support | 2.8 | 89% | 12 | 0 | 0% |
| Opponent | advance | 11.9 | 17% | 368 | 331 | 90% |
| Opponent | charge | 4.9 | 55% | 529 | 397 | 75% |
| Opponent | close in | 6.6 | 26% | 557 | 184 | 33% |
| Opponent | hold | 5.9 | 36% | 425 | 0 | 0% |
| Opponent | join | 0.4 | 94% | 14 | 0 | 0% |
| Opponent | shoot | 5.9 | 59% | 181 | 379 | 210% |
| Opponent | support | 4.2 | 91% | 23 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-mine-4394159-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.4 | 13 | 0 | 8% | 23% | 0% | 4.7 | 293 | 47 | 15% | 34 |
| Opponent | 0.4 | 14 | 0 | 29% | 36% | 0% | 2.8 | 456 | 116 | 29% | 142 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2.3 | 7 | 0 | 14% | 29% | 0% | 4.5 | 199 | 30 | 14% | 17 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 115 |
| Dwarfen Mountain Holds | 0.8 | 4 | 0 | 0% | 25% | 0% | 5.0 | 406 | 100 | 25% | 93 |
| Empire of Man | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 349 | 0 | 0% | 16 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| High Elf Realms | 0.3 | 3 | 0 | 0% | 0% | 0% | - | 520 | 0 | 0% | 96 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.4 | 2 | 0 | 100% | 100% | 0% | 2.5 | 509 | 471 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 252 |
| Tomb Kings of Khemri | 0.4 | 3 | 0 | 33% | 33% | 0% | 5.0 | 313 | 42 | 0% | 94 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 297 | 255 | 100% | 21 |
| Warriors of Chaos | 0.8 | 4 | 0 | 0% | 25% | 0% | 2.0 | 537 | 75 | 25% | 99 |
| Wood Elf Realms | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 510 | 0 | 0% | 666 |

### Battle groups: sf-h2h-mine-4394159-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.3 | 26% | 46% | 7% | 43% | 42% | 11% | 9% | 38% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 40% | 67% | 12% | 0% | 10% | 3% | 3% | 76% | 7% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 17% | 74% | 11% | 20% | 49% | 7% | 15% | 29% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 21% | 75% | 17% | 25% | 15% | 0% | 10% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-mine-4394159-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 24 (3) | 24 | 0 | 33 | 0% | 4.0 | - | 24 (3) | - | 73 (1) | 0 (2) |
| Mine | Chaff | 30 | 4 (30) | 4 | 0 | 46 | 23% | 2.9 | 3 (16) | 0 (6) | 8 (8) | 0 (17) | 8 (13) |
| Mine | Character | 107 | 38 (107) | 38 | 0 | 45 | 29% | 2.8 | 47 (34) | 44 (47) | 18 (6) | 42 (43) | 43 (44) |
| Mine | Clean-up | 15 | 71 (15) | 23 | 48 | 44 | 33% | 2.5 | 33 (6) | 81 (8) | 200 (1) | 111 (10) | 0 (5) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 25% | 2.0 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 52 | 45 (52) | 31 | 14 | 28 | 23% | 2.6 | 43 (19) | 51 (23) | 33 (10) | 52 (35) | 35 (17) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 75 | 53 (75) | 39 | 14 | 35 | 17% | 2.5 | 55 (18) | 55 (50) | 32 (7) | 70 (46) | 26 (29) |
| Mine | Holder | 24 | 41 (24) | 9 | 32 | 39 | 33% | 3.1 | 63 (5) | 48 (12) | 16 (7) | 63 (13) | 21 (11) |
| Mine | Shooter | 42 | 77 (42) | 38 | 40 | 40 | 0% | 1.5 | 43 (15) | 109 (21) | 37 (6) | 78 (29) | 76 (13) |
| Mine | War machine | 91 | 45 (91) | 45 | 0 | 45 | 4% | 1.1 | 48 (37) | 35 (45) | 95 (9) | 101 (22) | 29 (69) |
| Mine | Wizard | 28 | 34 (28) | 34 | 0 | 25 | 14% | 2.8 | 4 (9) | 62 (12) | 0 (1) | 0 (5) | 46 (17) |
| Opponent | Blocker | 2 | 239 (2) | 239 | 0 | 0 | 0% | 4.5 | 479 (1) | 0 (1) | - | 0 (1) | 479 (1) |
| Opponent | Chaff | 68 | 79 (68) | 35 | 44 | 60 | 40% | 1.9 | 117 (29) | 55 (13) | 57 (26) | 98 (55) | 0 (13) |
| Opponent | Character | 96 | 46 (96) | 46 | 0 | 34 | 18% | 2.5 | 45 (37) | 54 (44) | 8 (7) | 34 (49) | 61 (39) |
| Opponent | Clean-up | 18 | 74 (18) | 3 | 71 | 35 | 78% | 3.2 | 52 (4) | 95 (10) | 23 (4) | 111 (13) | 18 (5) |
| Opponent | Fast | 2 | 25 (2) | 25 | 0 | 50 | 50% | 5.0 | - | 25 (2) | - | 25 (2) | - |
| Opponent | Fast Hammer | 46 | 45 (46) | 36 | 9 | 52 | 35% | 2.7 | 49 (23) | 41 (16) | 37 (7) | 61 (24) | 27 (22) |
| Opponent | Fragile | 14 | 20 (14) | 20 | 0 | 72 | 50% | 2.0 | - | 44 (6) | 0 (5) | 53 (5) | 0 (6) |
| Opponent | Hammer | 52 | 30 (52) | 24 | 6 | 45 | 29% | 2.8 | 20 (18) | 32 (30) | 80 (4) | 20 (38) | 58 (14) |
| Opponent | Holder | 44 | 109 (44) | 20 | 88 | 21 | 30% | 2.4 | 130 (10) | 103 (24) | 103 (10) | 145 (29) | 54 (15) |
| Opponent | Shooter | 34 | 66 (34) | 26 | 40 | 30 | 6% | 1.3 | 11 (9) | 85 (23) | 102 (2) | 81 (21) | 40 (13) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 24 | 41 (24) | 41 | 0 | 60 | 0% | 1.3 | 103 (6) | 8 (16) | 82 (2) | 51 (8) | 35 (16) |
| Opponent | Wizard | 26 | 9 (26) | 9 | 0 | 61 | 12% | 2.3 | 0 (10) | 32 (4) | 7 (2) | 14 (8) | 0 (8) |

### Charged fights: sf-h2h-mine-4394159-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 28 | 394 | 2.3 | 1.1 | 169 | 36 | +133 | 2 of 7 | 6 of 7 | +40 | +149 |
| Mine | Chaos Dwarfs | 5 | 363 | 236 | 1.8 | 1.2 | 131 | 0 | +131 | 6 of 9 | 3 of 9 | +0 | +169 |
| Mine | Dwarfen Mountain Holds | 5 | 561 | 45 | 1.4 | 1.3 | 32 | 41 | -9 | 1 of 7 | 5 of 7 | +0 | -13 |
| Mine | Empire of Man | 12 | 492 | 114 | 1.7 | 1.1 | 68 | 119 | -51 | 6 of 20 | 11 of 20 | -2 | -60 |
| Mine | Grand Cathay | 2 | 522 | 345 | 4.5 | 1.0 | 77 | 0 | +77 | 0 of 9 | 7 of 9 | - | +77 |
| Mine | High Elf Realms | 5 | 148 | 507 | 3.6 | 1.0 | 141 | 0 | +141 | 5 of 18 | 15 of 18 | - | +141 |
| Mine | Ogre Kingdoms | 3 | 164 | 125 | 4.3 | 1.1 | 29 | 30 | -1 | 3 of 13 | 7 of 13 | +0 | -1 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 250 | 2.0 | 1.0 | 125 | 0 | +125 | 1 of 2 | 2 of 2 | - | +125 |
| **Mine** | all armies | 36 | 358 | 217 | 2.4 | 1.1 | 92 | 39 | +53 | 24 of 85 | 56 of 85 | +4 | +59 |
| Opponent | Chaos Dwarfs | 1 | 137 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 4 | 344 | 67 | 1.5 | 1.3 | 45 | 128 | -83 | 4 of 6 | 1 of 6 | -119 | -66 |
| Opponent | Grand Cathay | 1 | 0 | 110 | 1.0 | 1.0 | 110 | 0 | +110 | 0 of 1 | 1 of 1 | - | +110 |
| Opponent | High Elf Realms | 6 | 170 | 223 | 3.7 | 1.2 | 61 | 41 | +20 | 10 of 22 | 13 of 22 | +44 | +14 |
| Opponent | Lizardmen | 1 | 60 | 185 | 4.0 | 1.0 | 46 | 0 | +46 | 4 of 4 | 2 of 4 | - | +46 |
| Opponent | Ogre Kingdoms | 2 | 82 | 318 | 5.0 | 1.6 | 64 | 22 | +42 | 2 of 10 | 7 of 10 | +90 | -7 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 36 | 3.0 | 1.0 | 12 | 345 | -333 | 2 of 3 | 3 of 3 | - | -333 |
| Opponent | Skaven | 3 | 38 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 6 | 58 | 764 | 3.8 | 1.2 | 199 | 9 | +191 | 14 of 23 | 17 of 23 | +405 | +158 |
| Opponent | Vampire Counts | 4 | 45 | 385 | 4.8 | 1.4 | 81 | 37 | +44 | 7 of 19 | 15 of 19 | +88 | +24 |
| Opponent | Warriors of Chaos | 5 | 24 | 793 | 4.0 | 1.1 | 198 | 10 | +188 | 11 of 20 | 14 of 20 | +177 | +189 |
| Opponent | Wood Elf Realms | 2 | 199 | 500 | 4.5 | 1.0 | 111 | 12 | +99 | 4 of 9 | 7 of 9 | - | +99 |
| **Opponent** | all armies | 36 | 109 | 379 | 3.3 | 1.2 | 116 | 35 | +81 | 58 of 118 | 81 of 118 | +113 | +73 |

### Effective charges: sf-h2h-mine-4394159-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 1 (net +185) | 3 (net +208) | 1 (net +40) | 1 (net +85) | 0 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 9 | 2 (net +203) | 0 | 0 | 1 (net +0) | 1 (net +0) | 5 (net +155) | 0 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 2 (net +36) | 1 (net -105) | 0 | 4 (net -8) | 0 | 29% (2 of 7) |
| Mine | Empire of Man | 20 | 3 (net -150) | 1 (net +195) | 2 (net +105) | 2 (net +15) | 3 (net +75) | 7 (net -89) | 2 | 11% (2 of 18) |
| Mine | Grand Cathay | 9 | 1 (net +90) | 1 (net +122) | 0 | 0 | 2 (net +64) | 4 (net +88) | 1 | 0% (0 of 8) |
| Mine | High Elf Realms | 18 | 1 (net +233) | 0 | 5 (net +113) | 2 (net +178) | 2 (net +28) | 7 (net +164) | 1 | 29% (5 of 17) |
| Mine | Ogre Kingdoms | 13 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +0) | 0 | 3 (net +67) | 6 | 29% (2 of 7) |
| Mine | Tomb Kings of Khemri | 2 | 0 | 0 | 1 (net +0) | 0 | 1 (net +250) | 0 | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 6 | 1 (net -265) | 0 | 2 (net +70) | 2 (net -188) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1 (net +110) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 22 | 4 (net -15) | 0 | 1 (net +230) | 6 (net -48) | 1 (net +0) | 10 (net +55) | 0 | 5% (1 of 22) |
| Opponent | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 10 | 1 (net +0) | 0 | 3 (net -73) | 1 (net +395) | 0 | 3 (net +80) | 2 | 38% (3 of 8) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 23 | 4 (net -4) | 0 | 1 (net +270) | 3 (net +154) | 1 (net +526) | 11 (net +229) | 3 | 5% (1 of 20) |
| Opponent | Vampire Counts | 19 | 2 (net +98) | 0 | 5 (net +162) | 5 (net -25) | 3 (net +83) | 4 (net -71) | 0 | 26% (5 of 19) |
| Opponent | Warriors of Chaos | 20 | 3 (net +177) | 0 | 2 (net -32) | 1 (net +265) | 0 | 12 (net +216) | 2 | 11% (2 of 18) |
| Opponent | Wood Elf Realms | 9 | 2 (net -12) | 0 | 2 (net +68) | 0 | 1 (net +0) | 3 (net +260) | 1 | 25% (2 of 8) |

### Charged fights, damage counted: sf-h2h-mine-4394159-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 259 | 257 | +31 | 140 | 136 | +4 | +1.7 |
| Mine | 50-54% | 2 | 176 | 134 | +158 | 158 | 0 | +158 | +90.3 |
| Mine | Effective (55-75%) | 13 | 224 | 160 | +80 | 96 | 58 | +38 | +17.0 |
| Mine | 76-89% | 10 | 190 | 137 | +90 | 154 | 50 | +104 | +54.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 244 | 201 | +61 | 128 | 51 | +77 | +31.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 348 | 78 | +70 | 82 | 6 | +76 | +21.8 |
| Mine | No odds | 10 | 177 | 201 | -64 | 70 | 122 | -52 | -29.1 |
| Mine | All fights | 85 | 239 | 177 | +53 | 116 | 63 | +53 | +22.2 |
| Opponent | Long shot (under 50%) | 18 | 223 | 273 | +20 | 91 | 77 | +14 | +6.1 |
| Opponent | Effective (55-75%) | 17 | 224 | 202 | +83 | 126 | 57 | +70 | +31.0 |
| Opponent | 76-89% | 20 | 336 | 184 | +16 | 99 | 85 | +13 | +4.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 319 | 199 | +142 | 177 | 41 | +136 | +42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 636 | 136 | +129 | 129 | 40 | +89 | +14.0 |
| Opponent | No odds | 12 | 312 | 187 | +20 | 142 | 109 | +33 | +10.7 |
| Opponent | All fights | 118 | 309 | 204 | +81 | 137 | 63 | +74 | +24.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-mine-4394159-p3 | move | 459 | 110 (24%) | 72 (16%) | 54 (12%) | 295 (64%) |
| sf-h2h-mine-4394159-p3 | objective | 390 | 54 (14%) | 40 (10%) | 57 (15%) | 279 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0826, L0834, L1524, L1527, L1834, L2227 |
| Elixir of Power | Mine | L1115 |
| Elixir of Power | Opponent | L0711, L0819 |
| Fistful of Laurels | Mine | L1823, L1829, L1834 |
| Fistful of Laurels | Opponent | L0218, L1518 |
| Invocation of Nehek | Opponent | L1524, L1527, L2227 |
| Opal Amulet | Mine | L1415, L1422 |
| Periapt of Soul Exchange | Opponent | L0621, L0920, L0921 |
| Ring of Doom | Mine | L0203, L0215, L0218, L1115, L1518, L1524, L1527 |
| Ring of Doom | Opponent | L0215, L0711, L0815, L0931, L1115, L1415 |
| Ring of Jet | Mine | L1022, L1115 |
| Ring of Jet | Opponent | L0711 |
| Standard of the Fell Warrior | Opponent | L0313, L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621, L0921 |
| Twice-Blessed Armour | Mine | L0711, L0722, L1022 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Mine | L0711, L0722, L0815, L0819, L0822, L0826, L0829, L0834 |
| Witch Hunter's Ward | Opponent | L0307, L0308, L0608 |

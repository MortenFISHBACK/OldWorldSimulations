# Doctrine scorecard: sf-h2h-mine-4394159-p4

### Scorecard: sf-h2h-mine-4394159-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0122 | 2 | 1 | Mine | - | - | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Mine | no | 5 | 5 | 0 | 4 | 0 | 0 | 0 | 30 |
| L0208 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0304 | 4 | 1 | Mine | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 794 |
| L0304 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 124 |
| L0305 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 760 |
| L0305 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0306 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 685 |
| L0306 | 6 | 1 | Opponent | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 615 |
| L0309 | 3 | 1 | Mine | yes | 6 | 3 | 4 | 3 | 0 | 0 | 0 | 760 |
| L0309 | 3 | 1 | Opponent | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0318 | 6 | 1 | Mine | no | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0318 | 6 | 1 | Opponent | no | 16 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0329 | 5 | 1 | Mine | no | - | 5 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0329 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0335 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 590 |
| L0335 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 140 |
| L0415 | 1 | 1 | Mine | no | 12 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0515 | 5 | 1 | Mine | no | - | 5 | 4 | 0 | 0 | 0 | 0 | 613 |
| L0515 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0517 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 613 |
| L0517 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 83 |
| L0519 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 771 |
| L0519 | 3 | 1 | Opponent | yes | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0521 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0521 | 5 | 1 | Opponent | yes | - | - | 1 | 8 | 0 | 0 | 0 | 787 |
| L0525 | 3 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0525 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0533 | 5 | 1 | Opponent | no | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0607 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 798 |
| L0607 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0610 | 4 | 1 | Mine | no | 1 | - | 2 | 3 | 0 | 0 | 0 | 966 |
| L0610 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 501 |
| L0629 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 615 |
| L0629 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 6 | 3 | 3 | 1 | 0 | 0 | 0 | 615 |
| L0633 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0635 | 5 | 1 | Mine | yes | - | 5 | 2 | 4 | 0 | 0 | 0 | 615 |
| L0635 | 5 | 1 | Opponent | no | - | 4 | 1 | 4 | 0 | 0 | 0 | 265 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0723 | 3 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 613 |
| L0723 | 3 | 1 | Opponent | no | 6 | 2 | 6 | 1 | 2 | 0 | 0 | 0 |
| L0728 | 2 | 1 | Mine | - | - | 3 | 6 | 2 | 1 | 0 | 0 | 375 |
| L0728 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0732 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 452 |
| L0732 | 6 | 1 | Opponent | no | 1 | 1 | 6 | 3 | 1 | 0 | 0 | 137 |
| L0917 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0917 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 2 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 726 |
| L0918 | 6 | 1 | Opponent | no | 9 | 3 | 3 | 2 | 0 | 0 | 0 | 419 |
| L0928 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 1098 |
| L0928 | 4 | 1 | Opponent | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 748 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1018 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1018 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1322 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 302 |
| L1322 | 2 | 1 | Opponent | - | - | 1 | 4 | 0 | 1 | 0 | 0 | 225 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1522 | 4 | 1 | Mine | no | 7 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1522 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1525 | 1 | 1 | Mine | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Opponent | no | 1 | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Mine | - | - | 3 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 17% | 2.4 | 3.1 | 1.9 | 1.3 | 0.1 | 0.0 | 0.0 | 513.8 |
| **Average** | | | Opponent | 23% | 2.5 | 2.5 | 2.2 | 1.6 | 0.5 | 0.0 | 0.0 | 169.3 |

### KPIs: sf-h2h-mine-4394159-p4

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 44% (73 of 166) | 9% (15 of 164) | 27% (88 of 330) |
| Winner chose to follow up after the loser gave ground |  | 91% (49 of 54); on the table 93% | 93% (43 of 46); on the table 96% | 92% (92 of 100); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 100% (14 of 14); on the table 100% | 95% (20 of 21); on the table 95% |
| Winner chose to pursue after the loser fled |  | 59% (10 of 17); on the table 71% | 69% (11 of 16); on the table 69% | 64% (21 of 33); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 83% (65 of 78); on the table 87% | 89% (68 of 76); on the table 91% | 86% (133 of 154); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 37% (87 of 234) | 37% (58 of 156) | 37% (145 of 390) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (81 of 152) | 53% (58 of 110) | 53% (139 of 262) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 32% (23 of 72) | 23% (18 of 78) | 27% (41 of 150) |
|     round 1 |  | 33% (4 of 12) | 15% (2 of 13) | 24% (6 of 25) |
|     rounds 2+ |  | 32% (19 of 60) | 25% (16 of 65) | 28% (35 of 125) |
|   other wizards | 50%+ | 37% (58 of 156) | 51% (40 of 78) | 42% (98 of 234) |
|     round 1 |  | 50% (13 of 26) | 46% (6 of 13) | 49% (19 of 39) |
|     rounds 2+ |  | 35% (45 of 130) | 52% (34 of 65) | 41% (79 of 195) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | 53% (19 of 36) | 52% (22 of 42) |
| Points that never fought | lower | 50% (35253 of 70083) | 47% (34096 of 71988) | 49% (69349 of 142071) |
|   infantry points that never fought | lower | 55% (9725 of 17810) | 70% (9808 of 14065) | 61% (19533 of 31875) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (186 of 303) | 60% (169 of 282) | 61% (355 of 585) |
| Bound items with a magic missile used (at least once a game) |  | 100% (13 of 13); 1.0 uses a game | 76% (13 of 17); 1.2 uses a game | 87% (26 of 30); 1.1 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.5 uses a game | 100% (2 of 2); 0.1 uses a game | 62% (10 of 16); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 27% (4 of 15); 0.1 uses a game | 67% (6 of 9); 0.2 uses a game | 42% (10 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32917 of 57540) | 54% (34151 of 62687) | 56% (67068 of 120227) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (29%) | 0.7 (24%) | 1.9 (27%) |
| MARCHED: its unit marched | 0.4 (11%) | 0.4 (15%) | 0.9 (13%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.1 (3%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | 0.7 (27%) | 1.8 (26%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.1 (3%) | 0.1 (2%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (1%) | 0.2 (3%) |
| GONE: slain | 0.8 (18%) | 0.5 (19%) | 1.3 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (3%) | 0.2 (6%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.5 | 0.9 | 1.4 | 4.0 | 0.2 | 1.5 |
| not cast | 3.5 | 2.4 | 2.9 | 6.8 | 1.1 | 14.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (27%) | 0.2 (7%) | 1.9 (27%) | 0.3 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (13%) | 0.1 (8%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (3%) | 0.5 (18%) | 1.8 (26%) | 0.3 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (13%) | 0.5 (22%) | 0.1 (5%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.2 (6%) | 0.2 (3%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 1.0 (29%) | 0.6 (25%) | 0.8 (26%) | 1.3 (19%) | 0.2 (20%) | 3.2 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.2 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (50%) | 0.2 (7%) | 1.1 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.5 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.8 a game | 0.7 a game |
| stood (cast and not dispelled) | 73% (11 of 15) | 68% (13 of 19) | 71% (24 of 34) |
| the unit moved after it | 45% (5 of 11) | 31% (4 of 13) | 38% (9 of 24) |
| it charged on its next turn | 18% (2 of 11) | 15% (2 of 13) | 17% (4 of 24) |
| the enemy charged it first | 0% (0 of 11) | 8% (1 of 13) | 4% (1 of 24) |
| it fought by the end of its next turn | 0% (0 of 11) | 8% (1 of 13) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (3 of 11) | 8% (1 of 13) | 17% (4 of 24) |
| none of these (no charge, no fight, no charge escaped) | 55% (6 of 11) | 69% (9 of 13) | 62% (15 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (950 of 1351) | 54% (494 of 917) | 64% (1444 of 2268) |
|   cavalry | 53% (28 of 53) | 51% (58 of 114) | 51% (86 of 167) |
|   character | 80% (160 of 201) | 39% (52 of 133) | 63% (212 of 334) |
|   chariot | 55% (66 of 119) | 54% (43 of 80) | 55% (109 of 199) |
|   infantry | 55% (194 of 352) | 54% (209 of 385) | 55% (403 of 737) |
|   monster | 60% (33 of 55) | 50% (30 of 60) | 55% (63 of 115) |
|   war machine | 82% (469 of 571) | 70% (102 of 145) | 80% (571 of 716) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.9 (26%) | 2.8 (24%) | 5.7 (25%) |
| CHARGED: it charged | 1.4 (12%) | 2.1 (18%) | 3.5 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.5 (4%) | 1.2 (5%) |
| NO TARGET IN RANGE | 2.3 (21%) | 3.0 (25%) | 5.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (4%) | 0.5 (4%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (22%) | 1.9 (16%) | 4.3 (19%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.4 (3%) | 0.6 (3%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.5 (4%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.5 | 1.2 | 78% | 5.6 pts | 19 pts |
| character | 6.4 | 2.7 | 76% | 8.3 pts | 53 pts |
| chariot | 3.1 | 2.8 | 58% | 18.4 pts | 57 pts |
| infantry | 17.2 | 6.5 | 73% | 8.2 pts | 141 pts |
| monster | 2.3 | 0.7 | 78% | 8.4 pts | 19 pts |
| war machine | 16.2 | 13.8 | 59% | 21.3 pts | 345 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.5 | 4.4 |
| Charges that made contact a game | 2.5 | 3.6 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.41 declared, 0.29 contact (17 units) | 0.90 declared, 0.70 contact (10 units) | 0.59 declared, 0.44 contact (27 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.80 contact (5 units) | 1.38 declared, 1.12 contact (8 units) | 1.15 declared, 1.00 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.35 contact (227 units) | 0.62 declared, 0.39 contact (287 units) | 0.55 declared, 0.37 contact (514 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (27 of 51) | 47% (7 of 15) | 44% (4 of 9) | 51% (38 of 75) |
| Character in a unit | 80% (40 of 50) | 65% (13 of 20) | 25% (1 of 4) | 73% (54 of 74) |
| Character on its own | 71% (24 of 34) | 73% (16 of 22) | 24% (12 of 50) | 49% (52 of 106) |
| Chariot | 74% (14 of 19) | 70% (16 of 23) | - | 71% (30 of 42) |
| Infantry | 54% (48 of 89) | 65% (30 of 46) | 50% (1 of 2) | 58% (79 of 137) |
| Monster | 50% (13 of 26) | 78% (7 of 9) | - | 57% (20 of 35) |
| Monstrous | 71% (5 of 7) | 53% (10 of 19) | - | 58% (15 of 26) |
| War Machines | 75% (62 of 83) | 71% (5 of 7) | - | 74% (67 of 90) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (7 of 7); on the table 100% | 31% (17 of 54) | 21% | 45% (5 of 11) | 100% (3 of 3); 2.5 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Chaos Dwarfs | 9 | 90% (9 of 10); on the table 100% | 47% (34 of 72) | 64% | 71% (50 of 70) | 0.0 uses a game | 0.0 uses a game | 14% (1 of 7); 0.1 uses a game |
| Dwarfen Mountain Holds | 13 | 76% (19 of 25); on the table 84% | - | 64% | 63% (69 of 109) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 12 | 54% (7 of 13); on the table 62% | 43% (41 of 96) | 54% | 67% (85 of 127) | 0.0 uses a game | 80% (4 of 5); 1.0 uses a game | 33% (2 of 6); 0.2 uses a game |
| Grand Cathay | 2 | 82% (9 of 11); on the table 82% | 28% (15 of 54) | 36% | 35% (7 of 20) | 100% (4 of 4); 7.5 uses a game | 100% (2 of 2); 1.5 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 7 | 92% (24 of 26); on the table 92% | 22% (4 of 18) | 24% | 46% (24 of 52) | 91% (10 of 11); 3.9 uses a game | 50% (4 of 8); 0.9 uses a game | 0.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 46% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 100% (6 of 6); on the table 100% | 0% (0 of 18) | 40% | 71% (25 of 35) | 100% (5 of 5); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 20% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 100% (4 of 4); on the table 100% | 42% (5 of 12) | 42% | 69% (11 of 16) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 83% (10 of 12); on the table 83% | 17% (1 of 6) | 40% | 20% (4 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 100% (5 of 5); on the table 100% | 42% (10 of 24) | 41% | 76% (13 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 96% (22 of 23); on the table 96% | 50% (6 of 12) | 41% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 80% (4 of 5); on the table 80% | 56% (10 of 18) | 63% | 75% (33 of 44) | 50% (3 of 6); 3.8 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-mine-4394159-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (33) | 43% (20) | 46% (53) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.31 | 0.86 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.08 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.22 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.47 | 1.28 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.97 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.39 | 3.83 | 8.22 |

### Quality by phase: sf-h2h-mine-4394159-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 56% (59 of 106) | 43% (72 of 167) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (255 of 621) | 52% (147 of 281) |
| Strategy | Close-in objectives charged next turn | 18% (20 of 109) | 18% (36 of 200) |
| Strategy | Support requests answered (helper made contact too) | 59% (10 of 17) | 48% (14 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (7 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (2 of 6) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 39% (25 of 64) | 39% (16 of 41) |
| Strategy | Lone characters that fought | 68% (53 of 78) | 72% (57 of 79) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.3 | 1.6 |
| Movement | Points that never moved of their own | 513.8 | 169.3 |
| Movement | Fights charged into per game | 2.0 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 65, net +121 | 16 of 86, net -27 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 65, net +8 | 20 of 86, net +70 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 65, net +65 | 8 of 86, net +126 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 65, net +98 | 30 of 86, net +195 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.2 | 12.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (196 of 512) | 41% (178 of 434) |
| Shooting | Points destroyed by shooting units | 134.7 | 40.5 |
| Shooting | War machine shots | 13.0 | 3.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (199 of 469) | 39% (45 of 115) |
| Shooting | Points destroyed by war machines | 127.5 | 39.6 |
| Magic | Magic missiles cast | 1.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (16 of 39) | 51% (22 of 43) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.0 |
| Magic | Wounds caused by other spells | 1.3 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 43.2 | 26.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.2 / 0.2 / 0.5 / 0.0 | 1.7 / 0.2 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 282.2 | 330.8 |
| Combat | Points run down | 69.6 | 89.3 |
| Combat | Net points per charged fight, damage counted | +85 | +91 |
| Combat | Net per 100 charger points, damage counted | +31.0 | +30.3 |
| Combat | First round won (charged fights) | 78% | 66% |
| Combat | Net points per charged fight | +76 | +98 |
| Combat | Net points per supported fight / lone fight | +105 / +68 | +118 / +94 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 73 | 51 of 104 |
| Game | Points lost | 643.0 | 697.1 |
| Game | VP from objectives | 535.8 | 548.9 |
| Game | Lone holders (player turns) | 2.4 | 2.5 |

- Mine won / drew / lost: 14 / 11 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +50 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1340
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-mine-4394159-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +2.5 | 0.0 | 0.0 | 0.1 | +5.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.8 | +0.0 | 0.0 | 29.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +5.0 | 0.0 | 32.6 | 0.8 | +5.7 | 0.0 | 4.6 |
| BEST FACING | 0.6 | +35.1 | 0.0 | 11.7 | 0.7 | +22.8 | 0.0 | 50.9 |
| BEST FIRST | 4.7 | +209.6 | 98.6 | 43.6 | 4.1 | +149.7 | 159.4 | 91.3 |
| BEST MOVE FOR SHOOTERS | 1.1 | +76.5 | 0.0 | 0.0 | - | - | - | - |
| BEST OVERALL | 0.5 | +31.1 | 0.0 | 8.1 | 0.6 | +31.4 | 0.0 | 74.4 |
| BEST PREY | 0.8 | +79.9 | 40.9 | 6.7 | 0.7 | +35.2 | 16.8 | 4.8 |
| BEST PRIZE | 0.1 | +1.6 | 2.9 | 0.0 | 0.1 | -10.3 | 5.4 | 9.7 |
| BIG CHARACTER SAFETY | 0.1 | +0.2 | 0.0 | 0.0 | 0.2 | -0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 13.2 | 10.8 |
| BLOCKED WHEEL | 0.2 | +1.4 | 0.0 | 6.9 | 0.5 | -2.8 | 0.0 | 5.4 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 7.8 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 28.5 | 6.9 |
| CANNON PLANNED TARGET | - | - | - | - | 2.1 | +76.7 | 106.0 | 9.6 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 8.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 1.7 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -2.2 | 13.4 | 5.2 | 0.1 | -10.2 | 8.3 | 0.0 |
| CAST JOB | 1.2 | +30.8 | 84.1 | 4.7 | 0.4 | +9.3 | 28.3 | 18.6 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +8.1 | 16.0 | 10.3 | 0.1 | +1.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 13.2 | 0.5 | +0.0 | 0.0 | 11.2 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.3 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.5 | 14.0 | 0.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 201.6 | 24.2 | 2.8 | +0.0 | 271.1 | 95.5 |
| CHARGE NOW WEIGHED | 0.6 | -27.5 | 58.6 | 28.6 | 0.5 | -56.6 | 5.3 | 33.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.9 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.9 | 0.0 | 0.1 | +0.0 | 1.5 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 2.9 | 23.3 | 0.2 | +0.0 | 20.5 | 17.1 |
| CONVEYANCE SEARCH | 0.3 | +45.7 | 20.9 | 13.2 | 0.4 | +30.9 | 4.4 | 11.2 |
| COUNTER-CHARGE COVER | 10.0 | +771.9 | 0.0 | 198.1 | 6.0 | +555.1 | 0.0 | 135.2 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 7.4 | 9.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +8.5 | 22.5 | 0.0 | 0.0 | +0.2 | 1.8 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.2 | 6.9 | 1.7 | 0.2 | +1.2 | 6.8 | 13.8 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 17.2 | +0.0 | 1084.5 | 206.1 | - | - | - | - |
| FACE THE CAST | 0.1 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.5 | +118.9 | 0.0 | 41.0 | 1.3 | +103.7 | 0.0 | 72.6 |
| FALLBACK BY WORTH | 4.6 | +29.7 | 0.0 | 38.9 | 5.3 | +29.4 | 0.0 | 48.1 |
| FIGHT LIFT | 0.1 | +1.2 | 5.4 | 9.9 | 0.0 | +0.1 | 5.1 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.8 | 0.0 | 1.7 | 0.1 | +8.0 | 0.0 | 10.1 |
| FIRE IN ORDER | 1.3 | +0.0 | 125.8 | 12.5 | - | - | - | - |
| FIRE PLAN | 27.4 | +140.2 | 1538.2 | 349.8 | - | - | - | - |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 104.5 | 3.9 | +0.0 | 0.0 | 87.7 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.3 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +100.8 | 0.0 | 44.9 | 0.9 | +195.2 | 0.0 | 26.1 |
| FRIENDS SHOTS CHECKED | 0.5 | +33.4 | 0.0 | 1.7 | 0.2 | +14.1 | 0.0 | 5.4 |
| GIVES UP | 0.1 | -1.7 | 15.4 | 0.0 | 0.2 | -1.3 | 20.3 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.2 | 6.4 | 0.8 |
| GROUND FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 12.9 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.4 | +0.0 | 6.0 | 10.8 |
| HILL BY ITS CHANCE | 0.5 | -46.2 | 0.0 | 0.0 | 0.4 | -36.7 | 0.0 | 4.8 |
| HOLDS AMBUSHERS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 17.2 | +2187.3 | 1084.5 | 206.1 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.4 | +16.2 | 25.4 | 1.4 | 0.4 | +6.1 | 14.9 | 14.5 |
| HUNT DROPPED | 0.1 | +0.0 | 3.5 | 1.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.1 | +7.3 | 0.0 | 0.0 | 0.3 | +31.0 | 0.0 | 0.0 |
| HUNT KEPT | 0.2 | +3.4 | 11.0 | 0.0 | 0.4 | +2.2 | 20.7 | 8.7 |
| HUNT RESULT | 0.2 | +19.8 | 3.5 | 3.1 | 0.5 | +11.0 | 10.4 | 8.7 |
| HUNT THE GUNS | 0.3 | +111.2 | 17.9 | 3.1 | 0.5 | +134.9 | 11.4 | 17.9 |
| INVITES THE FIGHT | 1.2 | +20.3 | 31.5 | 37.9 | 0.9 | +14.5 | 26.9 | 11.4 |
| JOINT CHARGE PLAN | 0.1 | +2.2 | 48.2 | 0.0 | 0.1 | +3.9 | 6.5 | 3.8 |
| KEEP FALLS | 0.1 | +2.6 | 0.0 | 12.7 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +34.2 | 133.9 | 15.8 | 1.9 | +55.8 | 135.1 | 31.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | 2.3 | -8.8 | 300.2 | 38.1 | - | - | - | - |
| KILLS COUNT | 0.8 | +53.7 | 64.1 | 14.2 | 2.2 | +95.8 | 152.3 | 24.8 |
| KILLS COUNT NEXT TURN | 4.4 | +140.0 | 308.4 | 95.6 | 6.6 | +234.6 | 200.1 | 147.3 |
| LONE CHARACTER SAFE SPOT | 0.4 | +8.7 | 4.1 | 1.2 | 0.2 | +0.7 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 6.6 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +15.3 | 0.0 | 0.0 | 0.4 | +30.2 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -3.2 | 38.8 | 6.2 | 0.6 | -2.3 | 20.8 | 0.0 |
| LOST CHARGE | 2.8 | -48.1 | 125.8 | 66.4 | 1.8 | -36.7 | 36.9 | 61.9 |
| MAKE SURE TOGETHER | 0.9 | +57.8 | 57.8 | 6.7 | 0.7 | +66.8 | 19.2 | 39.1 |
| MANOEUVRE | 0.2 | +3.9 | 0.0 | 0.0 | 0.2 | +8.4 | 0.0 | 0.9 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +18.4 | 0.0 | 5.5 | 0.4 | +9.8 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +21.8 | 13.4 | 10.6 | 0.2 | +11.1 | 2.0 | 11.1 |
| MARCH OVER CASTS | 0.4 | +37.8 | 0.0 | 11.0 | 0.3 | +27.9 | 0.0 | 9.6 |
| MAX FOR POSITIONING | 3.8 | +94.8 | 0.0 | 79.1 | 3.8 | +158.8 | 0.0 | 117.8 |
| MISSILES IN THE FIRE PLAN | 1.3 | +10.4 | 50.2 | 16.5 | - | - | - | - |
| MISSILES IN THE MOVE | 3.6 | +87.9 | 0.0 | 61.2 | 2.7 | +40.0 | 0.0 | 76.0 |
| MISSILES NEXT TURN | 3.9 | +60.3 | 0.0 | 69.8 | 3.4 | +34.9 | 0.0 | 76.8 |
| MODEL FACING | 0.6 | +105.7 | 0.0 | 6.7 | 0.1 | +27.2 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 28.9 | 0.0 | 0.4 | +0.0 | 12.9 | 10.6 |
| MOVE AND CAST | 0.5 | +12.9 | 0.0 | 4.7 | 0.2 | +6.9 | 0.0 | 8.9 |
| MOVE SPELL IN RANGE | 0.4 | +7.0 | 0.0 | 10.6 | 0.1 | +2.5 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -13.3 | 6.6 | 21.1 | 0.3 | -8.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 10.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +176.3 | 157.4 | 47.0 | 5.2 | +292.8 | 187.1 | 113.8 |
| MOVES UNITS SPELL | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +2.1 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -10.5 | 39.3 | 8.1 | 0.3 | -10.0 | 19.3 | 5.4 |
| NOT TURNED | 4.4 | +122.2 | 0.0 | 66.0 | 3.8 | +63.8 | 0.0 | 81.3 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 21.5 |
| OFF BEST | 16.6 | -739.3 | 0.0 | 263.7 | 14.2 | -679.5 | 6.6 | 208.1 |
| ONE YARDSTICK | 26.3 | -813.1 | 802.8 | 337.7 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.9 | 25.7 | 0.0 | 0.1 | +0.2 | 0.0 | 8.6 |
| OPENS UP | 0.0 | +1.2 | 3.1 | 0.0 | 0.3 | +40.6 | 8.2 | 7.9 |
| OVERRUNS AWAY | 0.2 | +4.9 | 19.3 | 5.2 | 0.6 | +4.9 | 42.5 | 25.8 |
| PATHS CROSS | 1.5 | +75.4 | 0.0 | 45.6 | 2.7 | +107.6 | 0.0 | 23.8 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.5 | 0.0 | 1.8 | 0.1 | -0.9 | 0.0 | 8.6 |
| PLAN RESULT | 40.0 | +1951.7 | 1400.1 | 782.9 | 37.2 | +917.4 | 1090.8 | 961.9 |
| PURSUES BIG PREY | 0.0 | -5.8 | 0.0 | 0.0 | 0.1 | -15.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.2 | +0.0 | 0.0 | 0.0 | 1.0 | +11.3 | 0.0 | 14.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.3 | 14.0 | 0.0 | 0.1 | -10.1 | 2.1 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -8.0 | 0.0 | 1.4 |
| REDIRECT COUNTER | 1.1 | +70.8 | 0.0 | 7.2 | 1.9 | +140.2 | 0.0 | 51.6 |
| REDIRECT WEIGHED | 0.2 | +9.2 | 0.0 | 5.2 | 0.5 | +18.7 | 36.2 | 19.0 |
| RESERVE FALL BACK | 0.2 | +4.5 | 0.0 | 0.0 | 0.6 | +20.3 | 0.0 | 8.7 |
| RESTRAINS TO SHOOT | 0.2 | +12.1 | 0.0 | 10.1 | 0.1 | +4.1 | 0.0 | 4.0 |
| RISK BY ARC | 2.1 | +85.3 | 206.8 | 35.5 | 2.8 | +70.1 | 196.3 | 66.9 |
| SAFER THAN THE JOB | 0.6 | +39.9 | 0.0 | 16.3 | 1.0 | +74.9 | 0.0 | 39.7 |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 0.0 | 0.6 | +2.1 | 0.0 | 1.8 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.2 | 0.0 | 0.0 | 0.4 | -31.4 | 0.0 | 1.2 |
| SEARCH SPOT | 2.4 | +129.5 | 0.0 | 19.4 | 1.9 | +65.9 | 0.0 | 35.8 |
| SECOND HUNTER | 0.1 | -4.9 | 0.0 | 0.0 | 0.1 | -0.1 | 4.7 | 0.0 |
| SELF MOVE SPELL | 0.4 | +43.9 | 0.0 | 21.9 | 0.4 | +47.2 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.3 | +73.3 | 67.5 | 6.7 | 1.5 | +168.4 | 38.7 | 56.1 |
| SET-UP ANY TARGET | 0.2 | +25.9 | 10.6 | 10.6 | 0.1 | +5.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.8 | 0.0 | 0.0 | 0.0 | +1.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 5.0 | +268.1 | 292.9 | 72.4 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.8 | +1.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 3.3 | +59.7 | 0.0 | 44.7 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +43.0 | 91.4 | 11.6 | 1.1 | +17.7 | 27.6 | 19.8 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 24.8 | +0.0 | 1302.0 | 327.2 | 13.8 | +0.0 | 412.6 | 250.4 |
| SHOT REPLANNED | - | - | - | - | 0.4 | +0.0 | 66.7 | 2.3 |
| SHOTS IN THE MOVE | 22.8 | +919.1 | 0.0 | 293.4 | 12.7 | +443.6 | 0.0 | 247.7 |
| SPELL SETS UP CHARGE | 0.2 | +34.0 | 20.9 | 13.2 | 0.1 | +5.9 | 0.0 | 0.0 |
| SPELL WORTH | 0.2 | +6.7 | 8.8 | 9.9 | 1.2 | +25.5 | 66.2 | 61.1 |
| STABLE ROLE | 13.2 | +0.0 | 456.9 | 164.3 | 9.3 | +0.0 | 318.6 | 135.1 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| STAY WORTH | 27.7 | +133.0 | 789.5 | 298.3 | - | - | - | - |
| STOPS | 0.1 | +1.9 | 3.5 | 1.7 | 0.4 | +5.3 | 8.6 | 10.4 |
| STOPS SHORT OF THE FLANK | 0.4 | +13.9 | 0.0 | 1.7 | 0.2 | +1.3 | 0.0 | 5.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.6 |
| SUPPORT NARROWED | 3.6 | -21.3 | 222.9 | 46.1 | 4.7 | -31.1 | 256.6 | 90.8 |
| SUPPORTS | 2.0 | +25.4 | 61.9 | 18.8 | 2.8 | +31.1 | 133.1 | 44.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.8 | 16.7 | 0.0 | 0.1 | -5.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.9 | +2.1 | 51.0 | 1.7 | 0.5 | +5.7 | 0.0 | 9.6 |
| THROUGH LINE OF FIRE | 0.4 | +24.7 | 0.0 | 9.8 | 0.2 | +10.7 | 0.0 | 3.5 |
| TURN WORTH | 0.4 | -27.3 | 42.7 | 5.2 | 0.3 | -32.2 | 32.2 | 5.4 |
| TWO OR MORE ARRIVE | 0.1 | +0.8 | 48.2 | 0.0 | 0.8 | +6.7 | 29.5 | 13.4 |
| WAIT AFTER COSTS | 6.1 | -239.7 | 259.8 | 121.2 | 7.8 | -356.8 | 249.6 | 158.3 |
| WALKS TO THE FIGHT | 2.2 | +45.7 | 41.7 | 39.5 | 1.2 | +21.6 | 6.4 | 39.8 |
| WAR ENGINE CHARGES | 0.0 | +5.3 | 0.0 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 24.7 | 19.0 | 0.4 | +0.0 | 4.9 | 38.3 |
| WEARS DOWN | 1.2 | +43.2 | 89.0 | 40.8 | 1.0 | +26.9 | 117.9 | 65.5 |
| WHO HITS BACK | 0.1 | +9.1 | 0.0 | 10.3 | 0.1 | +10.9 | 0.0 | 23.9 |
| WHOLE FIGHT | 0.2 | +22.4 | 65.8 | 10.6 | 0.1 | +13.3 | 24.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +31.7 | 16.9 | 14.6 | 0.6 | +62.2 | 60.5 | 9.0 |

### Rule changes: sf-h2h-mine-4394159-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1112 | 1112 | 1112 | 30.89 | -51075 | -45.9 |
| BEST FIRST | 317 | 317 | 317 | 8.81 | +12933 | +40.8 |
| FIRE PLAN | 988 | 988 | 269 | 7.47 | +2879 | +10.7 |
| EVERY WOUND COUNTS | 619 | 619 | 173 | 4.81 | +0 | +0.0 |
| SEARCH SPOT | 157 | 157 | 155 | 4.31 | +7068 | +45.6 |
| PATHS CROSS | 151 | 151 | 151 | 4.19 | +6588 | +43.6 |
| COUNTER-CHARGE COVER | 576 | 337 | 143 | 3.97 | +7740 | +54.1 |
| MOVE TO CHARGE | 279 | 279 | 139 | 3.86 | +6934 | +49.9 |
| SHOTS IN THE MOVE | 1280 | 858 | 133 | 3.69 | +4411 | +33.2 |
| ONE YARDSTICK | 948 | 471 | 122 | 3.39 | +1200 | +9.8 |
| ARTILLERY RE-ROLL WEIGHED | 117 | 117 | 117 | 3.25 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 399 | 399 | 107 | 2.97 | +3579 | +33.4 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +8016 | +81.0 |
| CANNON SIGHT KEPT | 88 | 88 | 88 | 2.44 | +0 | +0.0 |
| WAIT AFTER COSTS | 501 | 501 | 81 | 2.25 | +1509 | +18.6 |
| SUPPORTS | 172 | 172 | 69 | 1.92 | +651 | +9.4 |
| WALKS TO THE FIGHT | 125 | 125 | 65 | 1.81 | +688 | +10.6 |
| HONEST THREAT | 619 | 619 | 58 | 1.61 | +0 | +0.0 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +4133 | +71.3 |
| FOLLOW UP WEIGHED | 56 | 56 | 56 | 1.56 | +10656 | +190.3 |
| FALLBACK BY WORTH | 356 | 356 | 55 | 1.53 | +2128 | +38.7 |
| BEST FACING | 47 | 47 | 47 | 1.31 | +2086 | +44.4 |
| FIRE IN ORDER | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| SET UP TOGETHER | 99 | 81 | 47 | 1.31 | +3763 | +80.1 |
| MISSILES IN THE MOVE | 228 | 147 | 45 | 1.25 | +970 | +21.6 |
| MAX FOR POSITIONING | 273 | 172 | 43 | 1.19 | +476 | +11.1 |
| STAY WORTH | 997 | 814 | 42 | 1.17 | +764 | +18.2 |
| SHOOTERS IN TWO RANKS | 41 | 41 | 41 | 1.14 | +74 | +1.8 |
| BEST OVERALL | 40 | 40 | 40 | 1.11 | +2249 | +56.2 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 39 | 39 | 39 | 1.08 | +2756 | +70.7 |
| CHARGE NOW FIRST | 178 | 178 | 39 | 1.08 | -2981 | -76.4 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +2818 | +74.1 |
| SHOOTS FROM THE BEST SPOT | 74 | 74 | 37 | 1.03 | +657 | +17.8 |
| KEEPS THE TARGET | 82 | 82 | 32 | 0.89 | -916 | -28.6 |
| ADVANCE LANE KEPT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| RESERVE FALL BACK | 29 | 29 | 29 | 0.81 | +894 | +30.8 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | -51 | -1.8 |
| RISK BY ARC | 176 | 166 | 28 | 0.78 | +1057 | +37.8 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.75 | +1639 | +60.7 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +714 | +26.4 |
| FRIENDS SHOTS CHECKED | 25 | 25 | 25 | 0.69 | +1709 | +68.4 |
| KILLS COUNT | 110 | 106 | 25 | 0.69 | +778 | +31.1 |
| MARCH CHECK | 27 | 25 | 25 | 0.69 | +663 | +26.5 |
| CAST JOB | 60 | 60 | 24 | 0.67 | +381 | +15.9 |
| REDIRECT COUNTER | 106 | 53 | 24 | 0.67 | +1653 | +68.9 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +4783 | +208.0 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +1480 | +64.4 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1275 | +55.4 |
| RANDOM MOVE BY FIGURES | 42 | 42 | 22 | 0.61 | +407 | +18.5 |
| BEST PREY | 53 | 53 | 21 | 0.58 | +1270 | +60.5 |
| KEEPS ITS TARGET | 108 | 104 | 20 | 0.56 | +371 | +18.5 |
| MAKE SURE TOGETHER | 60 | 32 | 20 | 0.56 | +1345 | +67.2 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.56 | +549 | +27.4 |
| HOLDS AMBUSHERS | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| INVITES THE FIGHT | 75 | 75 | 19 | 0.53 | +274 | +14.4 |
| SHOOTERS ARE THREATS | 180 | 180 | 19 | 0.53 | +0 | +0.0 |
| SHORT GUN FORWARD | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| COMBAT PIVOT | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +144 | +8.0 |
| MANOEUVRE | 17 | 17 | 17 | 0.47 | +446 | +26.2 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 13 | 13 | 13 | 0.36 | +584 | +44.9 |
| SHOT REPLANNED | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| WAR ENGINE JOBS | 32 | 32 | 13 | 0.36 | -1429 | -109.9 |
| WHOLE FIGHT GAIN | 33 | 27 | 13 | 0.36 | +1287 | +99.0 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -23 | -2.0 |
| CANNON PLANNED TARGET | 77 | 77 | 12 | 0.33 | -392 | -32.7 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 49 | 37 | 11 | 0.31 | +83 | +7.5 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -19 | -1.9 |
| HUNT ADVANCE | 29 | 29 | 9 | 0.25 | +300 | +33.4 |
| LOST CHARGE | 165 | 162 | 9 | 0.25 | +383 | +42.6 |
| WHO HITS BACK | 9 | 9 | 9 | 0.25 | +347 | +38.6 |
| MISSILES NEXT TURN | 264 | 172 | 8 | 0.22 | +7 | +0.9 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -406 | -50.8 |
| WEARS DOWN | 81 | 77 | 8 | 0.22 | +125 | +15.7 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -649 | -92.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +96 | +13.7 |
| SUPPORT NARROWED | 297 | 297 | 7 | 0.19 | -210 | -30.0 |
| FIRE AND FLEE | 6 | 6 | 6 | 0.17 | +317 | +52.9 |
| KEEPS SCOUTS OR AMBUSH | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| OPENS UP | 11 | 11 | 6 | 0.17 | +541 | +90.2 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -758 | -126.4 |
| WHOLE FIGHT | 12 | 12 | 6 | 0.17 | +533 | +88.9 |
| CARRIES OUT SET-UP | 8 | 8 | 5 | 0.14 | -446 | -89.2 |
| CASTING BLOCK | 11 | 11 | 5 | 0.14 | +71 | +14.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| HUNT IN PAIRS | 17 | 10 | 4 | 0.11 | +175 | +43.9 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +170 | +42.5 |
| OVERRUNS AWAY | 29 | 28 | 4 | 0.11 | +76 | +18.9 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -53 | -13.2 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| DEFENSIVE ARMY | 17 | 17 | 3 | 0.08 | -41 | -13.7 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +125 | +41.8 |
| TWO OR MORE ARRIVE | 32 | 32 | 3 | 0.08 | +18 | +6.0 |
| BACKUP TARGETS | 49 | 22 | 2 | 0.06 | +18 | +8.8 |
| DEFENSIVE FLOOR | 3 | 2 | 2 | 0.06 | +111 | +55.4 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +90 | +44.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +47 | +23.7 |
| LONG SHOT | 39 | 38 | 2 | 0.06 | +3 | +1.5 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +108 | +54.2 |
| SHOOTERS TO THE PRIMARY | 118 | 89 | 2 | 0.06 | +15 | +7.4 |
| STOPS | 15 | 15 | 2 | 0.06 | +31 | +15.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +6.3 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -9 | -9.3 |
| EDGE GIVE GROUND | 9 | 9 | 1 | 0.03 | +9 | +9.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +21 | +21.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.0 |
| JOINT CHARGE PLAN | 8 | 8 | 1 | 0.03 | +48 | +48.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +63 | +63.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +8 | +8.4 |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 12 | 12 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 10 | 10 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| ENGINEER BY LORE | 14 | 14 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 301 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 14 | 13 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 32 | 32 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 20 | trace | - | - | - | - |
| HUNT RESULT | 26 | trace | - | - | - | - |
| HUNT THE GUNS | 31 | trace | - | - | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 47 | 6 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 15 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 296 | 296 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 20 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2779 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 35 | 35 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SECOND HUNTER | 9 | 9 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 28 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1390 | 1390 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 51 | not checked | - | - | - | - |
| STABLE ROLE | 808 | 805 | 0 | 0.00 | - | - |
| TURN WORTH | 28 | 27 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-mine-4394159-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.94 | 12.61 | 47.5 |
| TURN GATE | gate | 0.67 | 0.56 | 37.0 |
| FALLBACK | gate | 0.47 | 0.72 | 34.3 |
| CHARGE NOW FIRST | rule | 0.44 | 0.64 | 76.4 |
| KEEPS THE TARGET | rule | 0.56 | - | 99.3 |
| FIRE PLAN | rule | 0.47 | - | 82.6 |
| WAR ENGINE JOBS | rule | 0.28 | 0.08 | 109.9 |
| AFTERMATH BAND | gate | 0.19 | 0.14 | 3.2 |
| PATHS CROSS | rule | 0.11 | 0.14 | 22.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.08 | 31.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.08 | 50.8 |
| BEST PRIZE | rule | 0.06 | 0.14 | 92.7 |
| CANNON PLANNED TARGET | rule | - | 0.19 | 56.0 |
| SUPPORT NARROWED | rule | 0.14 | 0.06 | 30.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 31.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.14 | 126.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 82.0 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.11 | 10.1 |
| BLOCKED WHEEL | rule | 0.03 | 0.11 | 37.3 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.08 | 89.2 |
| FIGHT ORDER BAND | gate | 0.08 | 0.03 | 1.8 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 13.2 |
| CHAFF PASSED | rule | - | 0.08 | 6.2 |
| DEFENSIVE ARMY | rule | 0.08 | - | 13.7 |
| MARCH ODDS | rule | 0.03 | 0.06 | 45.3 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 3.7 |
| SAFER THAN THE JOB | rule | - | 0.06 | 14.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 9.4 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 38.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 9.6 |
| CATCH ODDS | rule | - | 0.03 | 9.3 |
| FACES THE THREAT | rule | - | 0.03 | 2.5 |
| FALLBACK BY WORTH | rule | 0.03 | - | 44.7 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.8 |
| MOVE AND CAST | rule | - | 0.03 | 6.7 |
| NO REASON | gate | 0.03 | - | 4.5 |
| REDIRECT WEIGHED | rule | - | 0.03 | 182.7 |
| RULE SWITCHED OFF | gate | - | 0.03 | 22.8 |
| WHO HITS BACK | rule | 0.03 | - | 3.9 |

### Plans: sf-h2h-mine-4394159-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.2 | 18% | 391 | 365 | 93% |
| Mine | charge | 2.5 | 64% | 213 | 272 | 128% |
| Mine | close in | 3.0 | 37% | 181 | 123 | 68% |
| Mine | hold | 5.6 | 35% | 367 | 0 | 0% |
| Mine | join | 0.9 | 94% | 23 | 0 | 0% |
| Mine | shoot | 14.8 | 63% | 490 | 1192 | 243% |
| Mine | support | 2.1 | 92% | 14 | 0 | 0% |
| Opponent | advance | 12.6 | 12% | 344 | 203 | 59% |
| Opponent | charge | 4.1 | 49% | 496 | 333 | 67% |
| Opponent | close in | 5.5 | 18% | 462 | 94 | 20% |
| Opponent | hold | 4.8 | 38% | 337 | 0 | 0% |
| Opponent | join | 0.2 | 100% | 8 | 0 | 0% |
| Opponent | shoot | 6.5 | 50% | 159 | 299 | 188% |
| Opponent | support | 3.3 | 86% | 20 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-mine-4394159-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 12 | 3 | 0% | 22% | 0% | 2.5 | 353 | 79 | 22% | 40 |
| Opponent | 0.5 | 19 | 2 | 24% | 24% | 0% | 3.0 | 265 | 23 | 24% | 177 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4.0 | 8 | 3 | 0% | 20% | 0% | 2.0 | 387 | 48 | 20% | 66 |
| Chaos Dwarfs | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 94 | 0 | 0% | 97 |
| Dwarfen Mountain Holds | 0.6 | 8 | 0 | 25% | 25% | 0% | 3.5 | 204 | 70 | 25% | 39 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 119 | 118 | 100% | 48 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 396 | 0 | 0% | 65 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 355 |
| Ogre Kingdoms | 1.4 | 7 | 1 | 33% | 33% | 0% | 3.0 | 353 | 32 | 33% | 88 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 471 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 255 |
| Tomb Kings of Khemri | 0.8 | 3 | 0 | 0% | 0% | 0% | - | 371 | 0 | 0% | 49 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 306 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 275 | 0 | 0% | 278 |

### Battle groups: sf-h2h-mine-4394159-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.0 | 24% | 64% | 8% | 14% | 47% | 13% | 5% | 35% | 0% |
| Mine | REDIRECT COUNTER | 1.1 | 32% | 92% | 0% | - | 67% | 0% | 17% | 17% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.0 | 22% | 53% | 11% | 40% | 31% | 14% | 2% | 52% | 0% |
| Opponent | REDIRECT COUNTER | 1.9 | 31% | 86% | 0% | - | 10% | 5% | 0% | 86% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-mine-4394159-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 15 | 44 (15) | 11 | 33 | 39 | 33% | 1.9 | 74 (7) | 0 (4) | 28 (4) | 59 (11) | 0 (4) |
| Mine | Character | 123 | 43 (123) | 43 | 0 | 32 | 20% | 2.3 | 62 (47) | 39 (52) | 47 (8) | 47 (74) | 51 (33) |
| Mine | Clean-up | 22 | 85 (22) | 17 | 68 | 57 | 55% | 2.3 | 60 (6) | 111 (10) | 90 (6) | 94 (17) | 60 (5) |
| Mine | Fast | 6 | 0 (6) | 0 | 0 | 70 | 17% | 1.4 | - | 0 (5) | 0 (1) | 0 (5) | 0 (1) |
| Mine | Fast Hammer | 34 | 41 (34) | 17 | 24 | 33 | 18% | 3.1 | 42 (13) | 42 (15) | 34 (6) | 44 (27) | 30 (7) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 69 | 29 (69) | 22 | 7 | 33 | 26% | 2.3 | 12 (14) | 33 (47) | 40 (8) | 21 (45) | 42 (24) |
| Mine | Holder | 12 | 91 (12) | 0 | 91 | 23 | 75% | 5.0 | 0 (3) | 89 (8) | 396 (1) | 173 (6) | 5 (6) |
| Mine | Shooter | 52 | 83 (52) | 37 | 47 | 29 | 8% | 1.7 | 66 (12) | 102 (28) | 46 (12) | 114 (28) | 47 (24) |
| Mine | War machine | 113 | 48 (113) | 48 | 0 | 40 | 5% | 1.2 | 51 (34) | 53 (70) | 0 (9) | 40 (30) | 52 (83) |
| Mine | Wizard | 19 | 6 (19) | 6 | 0 | 43 | 42% | 2.7 | 22 (5) | 0 (11) | 0 (2) | 10 (4) | 5 (14) |
| Opponent | Blocker | 2 | 78 (2) | 78 | 0 | 0 | 50% | 5.0 | 156 (1) | - | 0 (1) | 78 (2) | - |
| Opponent | Chaff | 72 | 69 (72) | 13 | 56 | 54 | 36% | 2.9 | 51 (28) | 75 (13) | 82 (31) | 76 (48) | 56 (24) |
| Opponent | Character | 93 | 48 (93) | 48 | 0 | 28 | 20% | 2.4 | 56 (35) | 45 (41) | 52 (8) | 51 (48) | 50 (36) |
| Opponent | Clean-up | 31 | 21 (31) | 14 | 7 | 30 | 42% | 3.1 | 20 (11) | 24 (17) | 11 (3) | 32 (21) | 2 (10) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast | 5 | 25 (5) | 25 | 0 | 70 | 0% | 1.6 | - | 30 (4) | 0 (1) | 0 (3) | 52 (2) |
| Opponent | Fast Hammer | 39 | 50 (39) | 33 | 17 | 41 | 31% | 2.9 | 33 (15) | 60 (15) | 63 (9) | 47 (27) | 56 (12) |
| Opponent | Fragile | 12 | 0 (12) | 0 | 0 | 46 | 67% | 1.8 | 0 (3) | 0 (7) | 0 (2) | 0 (3) | 0 (9) |
| Opponent | Hammer | 58 | 19 (58) | 12 | 6 | 56 | 36% | 2.0 | 3 (13) | 21 (40) | 28 (5) | 21 (30) | 16 (28) |
| Opponent | Holder | 31 | 79 (31) | 22 | 58 | 14 | 29% | 2.7 | 84 (5) | 76 (19) | 101 (6) | 114 (17) | 31 (13) |
| Opponent | Shooter | 34 | 53 (34) | 11 | 42 | 31 | 6% | 1.8 | 0 (9) | 75 (21) | 80 (4) | 50 (23) | 58 (11) |
| Opponent | War machine | 26 | 47 (26) | 47 | 0 | 24 | 4% | 1.6 | 79 (6) | 41 (18) | 0 (2) | 69 (7) | 39 (19) |
| Opponent | Wizard | 28 | 26 (28) | 26 | 0 | 48 | 4% | 1.9 | 17 (7) | 61 (8) | 34 (5) | 34 (10) | 41 (10) |

### Charged fights: sf-h2h-mine-4394159-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 62 | 28 | 1.0 | 1.0 | 28 | 0 | +28 | 0 of 2 | 2 of 2 | - | +28 |
| Mine | Chaos Dwarfs | 8 | 245 | 127 | 1.1 | 1.0 | 113 | 66 | +47 | 6 of 9 | 7 of 9 | - | +47 |
| Mine | Dwarfen Mountain Holds | 11 | 439 | 34 | 1.4 | 1.1 | 25 | 24 | +1 | 6 of 15 | 9 of 15 | +0 | +1 |
| Mine | Empire of Man | 8 | 333 | 128 | 1.8 | 1.2 | 73 | 61 | +12 | 6 of 14 | 11 of 14 | -88 | +29 |
| Mine | Grand Cathay | 1 | 470 | 649 | 7.0 | 1.3 | 93 | 0 | +93 | 2 of 7 | 6 of 7 | +0 | +130 |
| Mine | High Elf Realms | 5 | 164 | 883 | 3.8 | 1.4 | 232 | 10 | +222 | 8 of 19 | 18 of 19 | +266 | +196 |
| Mine | Ogre Kingdoms | 1 | 130 | 313 | 7.0 | 1.4 | 45 | 43 | +2 | 1 of 7 | 4 of 7 | +1 | +2 |
| **Mine** | all armies | 36 | 305 | 218 | 2.0 | 1.2 | 107 | 32 | +76 | 29 of 73 | 57 of 73 | +105 | +68 |
| Opponent | Chaos Dwarfs | 1 | 230 | 219 | 4.0 | 1.0 | 55 | 0 | +55 | 3 of 4 | 3 of 4 | - | +55 |
| Opponent | Dwarfen Mountain Holds | 2 | 562 | 42 | 1.0 | 1.0 | 42 | 30 | +12 | 0 of 2 | 2 of 2 | - | +12 |
| Opponent | Empire of Man | 4 | 267 | 40 | 2.0 | 1.1 | 20 | 69 | -49 | 3 of 8 | 4 of 8 | +0 | -56 |
| Opponent | Grand Cathay | 1 | 400 | 433 | 4.0 | 2.0 | 108 | 0 | +108 | 3 of 4 | 3 of 4 | +164 | +52 |
| Opponent | High Elf Realms | 2 | 0 | 472 | 4.0 | 1.2 | 118 | 22 | +96 | 5 of 8 | 5 of 8 | +32 | +117 |
| Opponent | Lizardmen | 2 | 32 | 764 | 4.5 | 1.1 | 170 | 25 | +145 | 4 of 9 | 7 of 9 | +471 | +104 |
| Opponent | Ogre Kingdoms | 4 | 28 | 117 | 3.8 | 1.3 | 31 | 31 | +0 | 4 of 15 | 5 of 15 | -43 | +16 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 707 | 3.0 | 1.7 | 236 | 0 | +236 | 1 of 3 | 3 of 3 | +306 | +95 |
| Opponent | Skaven | 2 | 0 | 176 | 1.5 | 1.0 | 118 | 0 | +118 | 0 of 3 | 3 of 3 | - | +118 |
| Opponent | Tomb Kings of Khemri | 4 | 45 | 1082 | 4.2 | 1.2 | 255 | 78 | +176 | 11 of 17 | 13 of 17 | +154 | +179 |
| Opponent | Vampire Counts | 3 | 0 | 219 | 2.0 | 1.3 | 110 | 58 | +51 | 3 of 6 | 4 of 6 | +258 | -52 |
| Opponent | Warriors of Chaos | 6 | 31 | 476 | 2.3 | 1.1 | 204 | 33 | +171 | 9 of 14 | 9 of 14 | +0 | +184 |
| Opponent | Wood Elf Realms | 4 | 117 | 280 | 2.8 | 1.1 | 102 | 0 | +102 | 5 of 11 | 8 of 11 | +0 | +112 |
| **Opponent** | all armies | 36 | 106 | 385 | 2.9 | 1.2 | 133 | 35 | +98 | 51 of 104 | 69 of 104 | +118 | +94 |

### Effective charges: sf-h2h-mine-4394159-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +55) | 0 | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 2 (net -297) | 1 (net +752) | 0 | 6 (net +44) | 0 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 15 | 1 (net +0) | 0 | 3 (net -62) | 1 (net -65) | 0 | 7 (net +38) | 3 | 25% (3 of 12) |
| Mine | Empire of Man | 14 | 4 (net -38) | 0 | 2 (net +35) | 3 (net -31) | 1 (net +104) | 1 (net +111) | 3 | 18% (2 of 11) |
| Mine | Grand Cathay | 7 | 0 | 0 | 1 (net +0) | 3 (net +177) | 1 (net +40) | 2 (net +38) | 0 | 14% (1 of 7) |
| Mine | High Elf Realms | 19 | 1 (net +877) | 0 | 5 (net +122) | 4 (net +191) | 3 (net +73) | 6 (net +291) | 0 | 26% (5 of 19) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 1 (net +210) | 0 | 1 (net +38) | 3 (net -3) | 2 | 20% (1 of 5) |
| Opponent | Chaos Dwarfs | 4 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +219) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 1 (net -60) | 1 (net +85) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 8 | 2 (net +0) | 0 | 2 (net -276) | 1 (net +0) | 0 | 2 (net +30) | 1 | 29% (2 of 7) |
| Opponent | Grand Cathay | 4 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +105) | 1 (net +328) | 0 | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 8 | 0 | 0 | 1 (net +5) | 1 (net +0) | 2 (net +32) | 2 (net +224) | 2 | 17% (1 of 6) |
| Opponent | Lizardmen | 9 | 2 (net -42) | 0 | 2 (net +110) | 0 | 2 (net +95) | 2 (net +488) | 1 | 25% (2 of 8) |
| Opponent | Ogre Kingdoms | 15 | 1 (net +0) | 0 | 3 (net +17) | 3 (net -44) | 0 | 3 (net +66) | 5 | 30% (3 of 10) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 2 (net +306) | 0 | 0 | 1 (net +95) | 0 | 67% (2 of 3) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +118) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 17 | 2 (net -96) | 1 (net +0) | 2 (net +244) | 0 | 1 (net +110) | 9 (net +239) | 2 | 13% (2 of 15) |
| Opponent | Vampire Counts | 6 | 2 (net -152) | 0 | 2 (net +48) | 1 (net +517) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Warriors of Chaos | 14 | 3 (net +51) | 0 | 3 (net +135) | 1 (net +91) | 1 (net +202) | 4 (net +232) | 2 | 25% (3 of 12) |
| Opponent | Wood Elf Realms | 11 | 2 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +110) | 2 (net +322) | 5 | 17% (1 of 6) |

### Charged fights, damage counted: sf-h2h-mine-4394159-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 263 | 404 | +121 | 236 | 92 | +144 | +54.5 |
| Mine | Effective (55-75%) | 14 | 252 | 230 | +8 | 86 | 105 | -19 | -7.6 |
| Mine | 76-89% | 13 | 355 | 234 | +145 | 208 | 49 | +158 | +44.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 231 | 159 | +98 | 131 | 9 | +122 | +53.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 472 | 76 | +65 | 65 | 18 | +47 | +9.9 |
| Mine | No odds | 8 | 145 | 203 | -12 | 76 | 57 | +19 | +13.1 |
| Mine | All fights | 73 | 274 | 203 | +76 | 132 | 48 | +85 | +31.0 |
| Opponent | Long shot (under 50%) | 16 | 236 | 214 | -27 | 65 | 87 | -22 | -9.5 |
| Opponent | 50-54% | 3 | 270 | 276 | -20 | 14 | 35 | -21 | -7.6 |
| Opponent | Effective (55-75%) | 20 | 330 | 210 | +70 | 130 | 77 | +52 | +15.8 |
| Opponent | 76-89% | 9 | 366 | 192 | +89 | 152 | 47 | +105 | +28.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 311 | 207 | +195 | 234 | 54 | +180 | +57.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 581 | 122 | +126 | 146 | 30 | +116 | +20.0 |
| Opponent | No odds | 18 | 156 | 176 | +92 | 113 | 25 | +88 | +56.2 |
| Opponent | All fights | 104 | 301 | 198 | +98 | 147 | 56 | +91 | +30.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-mine-4394159-p4 | move | 386 | 87 (23%) | 58 (15%) | 45 (12%) | 254 (66%) |
| sf-h2h-mine-4394159-p4 | objective | 309 | 56 (18%) | 42 (14%) | 44 (14%) | 209 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0122 |
| Charmed Shield | Opponent | L0525, L1525, L1526 |
| Elixir of Power | Opponent | L0519 |
| Fistful of Laurels | Mine | L1820 |
| Fistful of Laurels | Opponent | L0318, L0918, L1018, L1418 |
| Horn of the Wild Hunt | Opponent | L0533, L0633 |
| Invocation of Nehek | Opponent | L0525, L1525 |
| Opal Amulet | Mine | L1418 |
| Periapt of Soul Exchange | Opponent | L0521, L1820 |
| Ring of Doom | Mine | L0208, L1522, L1525, L1526 |
| Ring of Doom | Opponent | L0415, L0515, L0533, L0633 |
| Ring of Jet | Mine | L1018 |
| Ring of Jet | Opponent | L0610 |
| Standard of the Fell Warrior | Mine | L1322 |
| Storm Daemon (Renegade 2.0) | Opponent | L0521 |
| Twice-Blessed Armour | Mine | L0709, L0723, L0728, L0732, L1018 |
| Twice-Blessed Armour | Opponent | L0607, L0610 |
| Witch Hunter's Ward | Mine | L0709, L0723, L0728, L0732 |
| Witch Hunter's Ward | Opponent | L0208, L0607 |

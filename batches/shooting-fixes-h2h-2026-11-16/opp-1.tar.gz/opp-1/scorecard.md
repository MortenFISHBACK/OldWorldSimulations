# Doctrine scorecard: sf-h2h-opp-4394159-p1

### Scorecard: sf-h2h-opp-4394159-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 8 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 2 | 5 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0108 | 6 | 1 | Mine | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 65 |
| L0108 | 6 | 1 | Opponent | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 515 |
| L0109 | 1 | 1 | Mine | no | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0109 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 354 |
| L0315 | 3 | 1 | Mine | no | 5 | 5 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 675 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 200 |
| L0322 | 4 | 1 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0322 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 55 |
| L0323 | 5 | 1 | Mine | no | - | 6 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 66 |
| L0506 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0506 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 1 | 0 | 0 | 1231 |
| L0507 | 3 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 1258 |
| L0507 | 3 | 1 | Opponent | yes | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 5 | 0 | 0 | 0 | 515 |
| L0509 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0509 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 0 | 0 | 0 | 609 |
| L0510 | 6 | 1 | Mine | yes | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 1019 |
| L0510 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0511 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 836 |
| L0511 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 1 | 0 | 0 | 330 |
| L0522 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1205 |
| L0522 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 72 |
| L0614 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 700 |
| L0614 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0615 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 801 |
| L0615 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0619 | 1 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 828 |
| L0619 | 1 | 1 | Opponent | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0627 | 3 | 1 | Mine | no | 0 | 6 | 3 | 0 | 0 | 0 | 0 | 1197 |
| L0627 | 3 | 1 | Opponent | no | 14 | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 6% | 1.6 | 3.7 | 1.6 | 1.0 | 0.1 | 0.0 | 0.0 | 678.9 |
| **Average** | | | Opponent | 31% | 2.6 | 2.5 | 2.2 | 1.5 | 0.5 | 0.0 | 0.0 | 298.4 |

### KPIs: sf-h2h-opp-4394159-p1

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 18 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (27 of 68) | 11% (9 of 83) | 24% (36 of 151) |
| Winner chose to follow up after the loser gave ground |  | 78% (14 of 18); on the table 83% | 96% (23 of 24); on the table 100% | 88% (37 of 42); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 33% (1 of 3); on the table 33% | 89% (8 of 9); on the table 89% | 75% (9 of 12); on the table 75% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 88% (15 of 17); on the table 100% | 85% (17 of 20); on the table 95% |
| Winner chose to follow up or pursue (all three) |  | 71% (17 of 24); on the table 75% | 92% (46 of 50); on the table 98% | 85% (63 of 74); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 36% (49 of 138) | 28% (34 of 120) | 32% (83 of 258) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (49 of 113) | 43% (34 of 79) | 43% (83 of 192) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | - | 27% (18 of 66) | 27% (18 of 66) |
|     round 1 |  | - | 36% (4 of 11) | 36% (4 of 11) |
|     rounds 2+ |  | - | 25% (14 of 55) | 25% (14 of 55) |
|   other wizards | 50%+ | 36% (49 of 138) | 30% (16 of 54) | 34% (65 of 192) |
|     round 1 |  | 17% (4 of 23) | 22% (2 of 9) | 19% (6 of 32) |
|     rounds 2+ |  | 39% (45 of 115) | 31% (14 of 45) | 37% (59 of 160) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 46% (15896 of 34853) | 50% (18000 of 35994) | 48% (33896 of 70847) |
|   infantry points that never fought | lower | 39% (4385 of 11279) | 80% (5657 of 7042) | 55% (10042 of 18321) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 72% (95 of 132) | 51% (75 of 148) | 61% (170 of 280) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 0.6 uses a game | 100% (8 of 8); 1.3 uses a game | 100% (11 of 11); 1.0 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 0.4 uses a game | 75% (6 of 8); 0.7 uses a game | 82% (9 of 11); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 86% (6 of 7); 0.3 uses a game | 50% (4 of 8); 0.2 uses a game | 67% (10 of 15); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (16173 of 24665) | 42% (13131 of 31071) | 53% (29304 of 55736) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.9 (60%) | 1.4 (29%) | 4.3 (45%) |
| MARCHED: its unit marched | 0.5 (10%) | 0.8 (17%) | 1.3 (14%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.3 (6%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 0.5 (10%) | 1.2 (24%) | 1.7 (17%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |
| GONE: slain | 0.7 (15%) | 1.1 (22%) | 1.8 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 0.7 | 1.7 | 4.6 | 0.2 | 1.4 |
| not cast | 2.2 | 1.7 | 1.3 | 9.7 | 1.8 | 13.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (37%) | 0.0 (0%) | 4.3 (45%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (10%) | 0.1 (7%) | 0.1 (4%) | 1.7 (17%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.4 (18%) | 0.2 (13%) | 0.2 (12%) | 1.8 (18%) | 0.2 (12%) | 1.7 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.5 (28%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (52%) | 0.4 (23%) | 1.1 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.3 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 64% (16 of 25) | - | 64% (16 of 25) |
| the unit moved after it | 69% (11 of 16) | - | 69% (11 of 16) |
| it charged on its next turn | 0% (0 of 16) | - | 0% (0 of 16) |
| the enemy charged it first | 6% (1 of 16) | - | 6% (1 of 16) |
| it fought by the end of its next turn | 0% (0 of 16) | - | 0% (0 of 16) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 16) | - | 12% (2 of 16) |
| none of these (no charge, no fight, no charge escaped) | 81% (13 of 16) | - | 81% (13 of 16) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (494 of 716) | 55% (304 of 557) | 63% (798 of 1273) |
|   cavalry | 30% (10 of 33) | 68% (59 of 87) | 58% (69 of 120) |
|   character | 79% (89 of 112) | 20% (11 of 56) | 60% (100 of 168) |
|   chariot | 32% (14 of 44) | 59% (29 of 49) | 46% (43 of 93) |
|   infantry | 47% (74 of 158) | 52% (113 of 218) | 50% (187 of 376) |
|   monster | 44% (7 of 16) | 27% (4 of 15) | 35% (11 of 31) |
|   war machine | 85% (300 of 353) | 67% (88 of 132) | 80% (388 of 485) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (23%) | 2.6 (19%) | 5.4 (20%) |
| CHARGED: it charged | 1.2 (10%) | 2.4 (17%) | 3.6 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 1.5 (12%) | 0.3 (2%) | 1.8 (7%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.1 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 2.7 (22%) | 2.7 (19%) | 5.4 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.9 (6%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (18%) | 3.3 (24%) | 5.6 (21%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.9 (7%) | 1.2 (4%) |
| OTHER BAR | 0.8 (7%) | 0.7 (5%) | 1.6 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 2.1 | 78% | 5.1 pts | 33 pts |
| character | 6.0 | 1.7 | 78% | 7.7 pts | 46 pts |
| chariot | 2.4 | 2.1 | 58% | 14.9 pts | 36 pts |
| infantry | 17.2 | 5.3 | 77% | 8.5 pts | 146 pts |
| monster | 0.8 | 0.1 | 87% | 3.1 pts | 3 pts |
| war machine | 21.6 | 17.8 | 63% | 23.7 pts | 510 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 6.2 | 4.1 |
| Charges that made contact a game | 1.5 | 4.3 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (7 units) | 0.71 declared, 0.29 contact (7 units) | 0.36 declared, 0.14 contact (14 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.50 contact (2 units) | 2.00 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.27 contact (99 units) | 0.83 declared, 0.59 contact (123 units) | 0.63 declared, 0.45 contact (222 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 29% (5 of 17) | 0% (0 of 4) | 25% (1 of 4) | 24% (6 of 25) |
| Character in a unit | 86% (30 of 35) | 70% (7 of 10) | - | 82% (37 of 45) |
| Character on its own | 95% (20 of 21) | 44% (4 of 9) | 17% (3 of 18) | 56% (27 of 48) |
| Chariot | 75% (3 of 4) | 57% (8 of 14) | - | 61% (11 of 18) |
| Infantry | 53% (18 of 34) | 44% (14 of 32) | 50% (1 of 2) | 49% (33 of 68) |
| Monster | 73% (8 of 11) | - | - | 73% (8 of 11) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |
| War Machines | 71% (40 of 56) | 80% (4 of 5) | - | 72% (44 of 61) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 75% (3 of 4); on the table 75% | 30% (29 of 96) | 42% | 47% (7 of 15) | 100% (3 of 3); 3.7 uses a game | 100% (3 of 3); 2.3 uses a game | 100% (3 of 3); 1.0 uses a game |
| Chaos Dwarfs | 5 | 60% (3 of 5); on the table 60% | 43% (23 of 54) | 43% | 70% (28 of 40) | 0.0 uses a game | 0.0 uses a game | 80% (4 of 5); 0.8 uses a game |
| Dwarfen Mountain Holds | 12 | 75% (12 of 16); on the table 81% | - | 53% | 75% (71 of 95) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 100% (3 of 3); on the table 100% | 31% (11 of 36) | 84% | 69% (37 of 54) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 2 | 83% (5 of 6); on the table 100% | 33% (16 of 48) | 39% | 44% (8 of 18) | 100% (4 of 4); 6.5 uses a game | 100% (1 of 1); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 3 | 86% (18 of 21); on the table 95% | 8% (1 of 12) | 14% | 30% (7 of 23) | 100% (4 of 4); 3.7 uses a game | 83% (5 of 6); 3.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 34% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 6% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (8 of 8); on the table 100% | - | 43% | 40% (6 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 44% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-opp-4394159-p1, 18 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (21) | 41% (7) | 47% (28) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.22 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.17 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 0.72 | 2.50 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.78 | 0.39 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.39 | 3.17 | 7.56 |

### Quality by phase: sf-h2h-opp-4394159-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.6 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 56% (20 of 36) | 44% (48 of 108) |
| Strategy | Shoot objectives carried out (shot that target) | 63% (229 of 362) | 45% (75 of 165) |
| Strategy | Close-in objectives charged next turn | 4% (1 of 24) | 20% (24 of 119) |
| Strategy | Support requests answered (helper made contact too) | 57% (4 of 7) | 27% (3 of 11) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 48% (21 of 44) | 24% (8 of 34) |
| Strategy | Lone characters that fought | 64% (28 of 44) | 72% (26 of 36) |
| Movement | Charges halted short of contact | 0.0 | 0.6 |
| Movement | Idle units | 1.0 | 1.5 |
| Movement | Points that never moved of their own | 678.9 | 298.4 |
| Movement | Fights charged into per game | 1.3 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 21, net -144 | 9 of 54, net +164 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 21, net +180 | 9 of 54, net +173 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 21, net +95 | 4 of 54, net +96 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 21, net +94 | 14 of 54, net +114 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.4 | 13.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (134 of 205) | 41% (100 of 243) |
| Shooting | Points destroyed by shooting units | 189.6 | 60.2 |
| Shooting | War machine shots | 16.7 | 4.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (142 of 300) | 36% (32 of 88) |
| Shooting | Points destroyed by war machines | 200.4 | 54.6 |
| Magic | Magic missiles cast | 1.1 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (7 of 19) | 59% (10 of 17) |
| Magic | Wounds caused by magic missiles | 2.7 | 1.1 |
| Magic | Wounds caused by other spells | 1.1 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 25.0 | 21.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.0 / 0.7 / 0.1 | 1.9 / 0.1 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 133.8 | 379.3 |
| Combat | Points run down | 8.3 | 159.6 |
| Combat | Net points per charged fight, damage counted | +59 | +152 |
| Combat | Net per 100 charger points, damage counted | +22.5 | +43.4 |
| Combat | First round won (charged fights) | 71% | 77% |
| Combat | Net points per charged fight | +46 | +158 |
| Combat | Net points per supported fight / lone fight | -203 / +81 | +340 / +114 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 24 | 31 of 62 |
| Game | Points lost | 872.8 | 560.2 |
| Game | VP from objectives | 537.2 | 811.7 |
| Game | Lone holders (player turns) | 1.6 | 2.6 |

- Mine won / drew / lost: 3 / 5 / 10 of 18 ended games (of 18); mean margin (Mine - Opponent) -573 VP
- The side that went first won 7 of 13 games with a winner
- Points traded per game (both sides' losses): 1433
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: sf-h2h-opp-4394159-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 39.4 | 1.1 | +0.0 | 0.0 | 38.1 |
| BACKUP TARGETS | 0.2 | +0.8 | 0.0 | 3.6 | 0.6 | +4.1 | 0.0 | 0.0 |
| BEST FACING | 0.9 | +35.5 | 0.0 | 35.0 | 0.3 | +7.4 | 0.0 | 40.7 |
| BEST FIRST | 2.6 | +102.2 | 104.6 | 49.5 | 4.0 | +165.0 | 110.2 | 48.9 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.4 | +89.8 | 0.0 | 0.0 |
| BEST OVERALL | 0.6 | +45.8 | 0.0 | 37.1 | 0.2 | +3.9 | 0.0 | 12.9 |
| BEST PREY | 0.4 | +15.5 | 0.0 | 7.2 | 0.7 | +25.3 | 7.8 | 3.9 |
| BEST PRIZE | - | - | - | - | 0.3 | +13.2 | 47.0 | 10.8 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | +0.3 | 0.0 | 31.7 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +0.6 | 0.0 | 0.0 | 0.4 | +5.8 | 0.0 | 0.0 |
| BOMBING RUN | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.9 | +0.0 | 301.1 | 43.6 | - | - | - | - |
| CANNON PLANNED TARGET | 14.2 | +250.8 | 935.2 | 239.4 | - | - | - | - |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 8.9 | 1.9 | +0.0 | 0.0 | 23.6 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | -10.5 | 78.1 | 0.0 |
| CAST JOB | 0.9 | +13.8 | 21.7 | 14.2 | 0.6 | +7.5 | 16.8 | 34.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +52.9 | 39.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 18.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +1.1 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.6 | 6.9 | 5.3 | - | - | - | - |
| CHARGE NOW FIRST | 1.2 | +0.0 | 57.1 | 39.9 | 4.2 | +0.0 | 304.9 | 169.9 |
| CHARGE NOW WEIGHED | 0.4 | -40.6 | 6.1 | 19.7 | 0.8 | -98.9 | 81.7 | 63.9 |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 21.9 | 0.0 | 0.5 | +0.0 | 0.0 | 47.4 |
| CONVEYANCE SEARCH | 0.9 | +323.4 | 0.0 | 0.0 | - | - | - | - |
| COUNTER-CHARGE COVER | 9.4 | +904.6 | 0.0 | 230.0 | 6.6 | +317.5 | 0.0 | 98.9 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 16.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +31.6 | 43.9 | 17.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | - | - | - | - | 12.9 | +0.0 | 300.9 | 97.2 |
| FACE THE CAST | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| FACES THE THREAT | 1.8 | +171.9 | 0.0 | 97.0 | 0.7 | +23.2 | 0.0 | 45.4 |
| FALLBACK BY WORTH | 3.5 | +45.8 | 0.0 | 6.7 | 4.3 | +46.9 | 0.0 | 39.8 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.8 | +0.0 | 28.2 | 13.1 |
| FIRE PLAN | - | - | - | - | 17.2 | +49.2 | 400.0 | 137.3 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 136.4 | 2.9 | +0.0 | 0.0 | 73.2 |
| FOLLOW UP WEIGHED | 0.5 | +78.8 | 0.0 | 12.9 | 0.9 | +132.9 | 0.0 | 53.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +18.6 | 0.0 | 0.0 | 0.4 | +33.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.9 | 16.1 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.0 | 4.7 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 15.2 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 61.0 | 0.0 |
| HILL BY ITS CHANCE | 0.1 | -5.9 | 0.0 | 10.3 | 0.4 | -22.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 12.9 | +1410.8 | 300.9 | 97.2 |
| HUNT ADVANCE | 0.4 | +6.4 | 4.7 | 0.0 | 0.4 | +2.4 | 0.0 | 3.9 |
| HUNT DROPPED | 0.2 | +0.0 | 38.3 | 0.0 | 0.4 | +0.0 | 13.9 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.6 | +32.3 | 0.0 | 32.7 |
| HUNT KEPT | 0.3 | +1.6 | 25.8 | 6.7 | 0.2 | +0.6 | 13.9 | 7.8 |
| HUNT RESULT | 0.4 | +5.3 | 59.4 | 0.0 | 0.6 | +7.4 | 20.0 | 0.0 |
| HUNT THE GUNS | 0.4 | +148.3 | 4.7 | 0.0 | 0.6 | +86.1 | 6.1 | 0.0 |
| INVITES THE FIGHT | 1.7 | +29.7 | 83.9 | 42.1 | 1.2 | +13.4 | 12.8 | 0.0 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +13.2 | 32.1 | 15.6 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 12.2 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 0.6 | +16.7 | 43.7 | 33.3 | 2.7 | +80.0 | 293.3 | 99.1 |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | - | - | - | - | 1.8 | -14.1 | 106.9 | 6.1 |
| KILLS COUNT | 0.7 | +59.2 | 59.6 | 19.7 | 2.6 | +88.6 | 191.1 | 39.6 |
| KILLS COUNT NEXT TURN | 1.9 | +52.0 | 9.4 | 34.2 | 5.8 | +232.9 | 291.4 | 137.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.1 | 15.6 | 10.6 | 0.6 | +4.2 | 23.9 | 31.2 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +57.8 | 0.0 | 0.0 | 0.7 | +55.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -7.2 | 15.6 | 21.1 | 0.3 | +0.3 | 19.7 | 0.0 |
| LOST CHARGE | 1.8 | -53.3 | 19.6 | 24.2 | 2.2 | -29.4 | 50.6 | 47.3 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.0 | 0.0 | 3.6 | 0.1 | -1.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +0.8 | 0.0 | 0.0 | 1.9 | +348.3 | 155.9 | 72.3 |
| MANOEUVRE | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.7 |
| MARCH CHECK | 0.2 | +17.9 | 0.0 | 0.0 | 0.4 | +43.2 | 0.0 | 4.7 |
| MARCH ODDS | 0.2 | +34.4 | 5.3 | 0.0 | 0.1 | +6.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.1 | +1.3 | 0.0 | 0.0 | 0.5 | +22.0 | 0.0 | 26.7 |
| MAX FOR POSITIONING | 2.4 | +105.2 | 0.0 | 55.8 | 3.7 | +104.1 | 0.0 | 73.2 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.4 | +5.5 | 43.3 | 25.2 |
| MISSILES IN THE MOVE | 2.3 | +114.9 | 0.0 | 23.6 | 3.2 | +36.8 | 0.0 | 38.9 |
| MISSILES NEXT TURN | 2.6 | +82.4 | 0.0 | 23.6 | 4.3 | +36.8 | 0.0 | 106.3 |
| MODEL FACING | 1.1 | +458.6 | 0.0 | 10.0 | 0.2 | +60.0 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.8 | +0.0 | 112.4 | 31.7 |
| MOVE AND CAST | 0.3 | +12.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -18.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 0.9 | +14.5 | 6.1 | 6.4 | 6.7 | +691.6 | 521.2 | 166.8 |
| MOVES UNITS SPELL | - | - | - | - | 0.2 | +1.0 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +26.7 | 17.2 | 0.0 |
| NOT NEEDED | 0.1 | -2.5 | 0.0 | 0.0 | 0.1 | -2.0 | 7.8 | 0.0 |
| NOT TURNED | 4.4 | +105.8 | 0.0 | 75.9 | 3.2 | +85.2 | 0.0 | 98.0 |
| NOT WORTH A CAST | 0.4 | -0.6 | 0.0 | 0.0 | 0.7 | -0.3 | 0.0 | 42.2 |
| OFF BEST | 15.0 | -887.9 | 0.0 | 242.3 | 17.0 | -632.2 | 35.8 | 305.1 |
| ONE YARDSTICK | - | - | - | - | 17.9 | -349.3 | 196.3 | 218.6 |
| OPENS A LANE | 0.2 | +1.2 | 0.0 | 5.3 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.6 | +35.2 | 22.0 | 10.8 |
| OVERRUNS AWAY | 0.2 | +0.3 | 41.1 | 20.8 | 1.0 | +7.5 | 50.2 | 42.2 |
| PATHS CROSS | 1.2 | +76.4 | 0.0 | 21.9 | 2.5 | +205.4 | 0.0 | 25.8 |
| PIVOT GUARDS FLANK | 0.1 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.2 | +1927.9 | 1266.8 | 963.3 | 39.4 | +1034.2 | 1370.4 | 787.2 |
| PURSUES BIG PREY | 0.1 | -15.0 | 0.0 | 0.0 | 0.3 | -18.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.9 | +76.8 | 0.0 | 7.2 | 1.2 | +62.2 | 0.0 | 16.0 |
| REDIRECT WEIGHED | 0.2 | +1.4 | 0.0 | 16.1 | 0.6 | +30.4 | 39.3 | 21.2 |
| RESERVE FALL BACK | - | - | - | - | 0.6 | +7.9 | 0.0 | 4.0 |
| RESTRAINS TO SHOOT | 0.3 | +15.5 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.2 | +21.5 | 61.8 | 39.9 | 3.2 | +106.6 | 258.9 | 114.3 |
| SAFER THAN THE JOB | 0.8 | +33.0 | 0.0 | 18.2 | 0.4 | +23.7 | 0.0 | 8.9 |
| SCOUT SPOT | 0.2 | +1.5 | 0.0 | 0.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -35.6 | 0.0 | 6.1 | 0.2 | -4.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +99.2 | 0.0 | 3.6 | 2.1 | +92.4 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 0.8 | +86.5 | 0.0 | 58.2 |
| SET UP TOGETHER | 0.3 | +4.7 | 0.0 | 3.3 | 4.8 | +836.7 | 390.8 | 140.4 |
| SET-UP ANY TARGET | 0.4 | +40.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | - | - | - | - | 6.3 | +386.7 | 139.7 | 61.3 |
| SHOOTERS IN TWO RANKS | 1.1 | +2.2 | 0.0 | 0.0 | 0.4 | +0.7 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.2 | +11.6 | 0.0 | 7.2 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +30.0 | 0.0 | 9.4 | 0.8 | +3.4 | 11.4 | 4.7 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 7.5 |
| SHOT OPTIONS | 24.7 | +0.0 | 1459.2 | 506.3 | 17.6 | +0.0 | 356.6 | 209.4 |
| SHOT REPLANNED | 1.4 | +0.0 | 327.8 | 24.8 | - | - | - | - |
| SHOTS IN THE MOVE | 23.7 | +937.6 | 0.0 | 454.8 | 17.8 | +427.3 | 0.0 | 165.7 |
| SPELL SETS UP CHARGE | 0.7 | +228.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +6.3 | 0.0 | 0.0 | 0.8 | +10.0 | 63.4 | 63.4 |
| STABLE ROLE | 9.1 | +0.0 | 269.3 | 166.3 | 11.3 | +0.0 | 316.2 | 135.8 |
| STANDS TO CAST | 0.1 | +4.0 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.2 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 22.6 | +224.0 | 177.2 | 244.4 |
| STOPS | 0.3 | +0.5 | 15.3 | 3.3 | 0.2 | +1.6 | 13.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.2 | +9.1 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 3.2 | -20.8 | 179.9 | 51.1 | 4.5 | -13.7 | 235.3 | 138.2 |
| SUPPORTS | 2.0 | +20.8 | 103.6 | 23.6 | 2.2 | +13.7 | 79.6 | 34.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | -22.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.1 | +0.5 | 0.0 | 0.0 | 0.8 | +40.2 | 32.1 | 24.1 |
| THROUGH LINE OF FIRE | 0.9 | +45.4 | 0.0 | 16.1 | 0.7 | +14.4 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -4.7 | 10.8 | 0.0 | 0.3 | -28.6 | 19.5 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 1.2 | +11.7 | 152.5 | 37.3 |
| WAIT AFTER COSTS | 4.2 | -195.7 | 134.2 | 80.6 | 9.8 | -558.8 | 545.9 | 166.8 |
| WALKS TO THE FIGHT | 1.6 | +30.8 | 42.8 | 32.1 | 1.4 | +46.6 | 11.9 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +32.0 | 35.8 | 20.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.9 | +0.0 | 55.8 | 14.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.8 | +28.0 | 47.9 | 27.2 | 1.3 | +49.2 | 140.3 | 53.1 |
| WHO HITS BACK | 0.2 | +17.7 | 0.0 | 17.2 | 0.2 | +1.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +0.3 | 26.8 | 17.2 | 0.3 | -5.4 | 66.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +8.9 | 6.1 | 0.0 | 0.7 | +55.8 | 104.4 | 6.8 |
| WIZARD FRONT RANK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 4.7 | 32.7 |

### Rule changes: sf-h2h-opp-4394159-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 576 | 576 | 576 | 32.00 | -27361 | -47.5 |
| BEST FIRST | 119 | 119 | 119 | 6.61 | +4810 | +40.4 |
| CANNON SIGHT KEPT | 83 | 83 | 83 | 4.61 | +0 | +0.0 |
| COUNTER-CHARGE COVER | 287 | 137 | 69 | 3.83 | +4539 | +65.8 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 3.78 | +0 | +0.0 |
| PATHS CROSS | 67 | 67 | 67 | 3.72 | +5073 | +75.7 |
| CANNON PLANNED TARGET | 255 | 255 | 65 | 3.61 | -877 | -13.5 |
| SHOTS IN THE MOVE | 747 | 514 | 65 | 3.61 | +1600 | +24.6 |
| MOVE TO CHARGE | 136 | 136 | 63 | 3.50 | +5953 | +94.5 |
| SEARCH SPOT | 64 | 64 | 63 | 3.50 | +3458 | +54.9 |
| FIRE PLAN | 310 | 310 | 55 | 3.06 | +485 | +8.8 |
| EVERY WOUND COUNTS | 233 | 233 | 51 | 2.83 | +0 | +0.0 |
| FACES THE THREAT | 45 | 45 | 45 | 2.50 | +3511 | +78.0 |
| SET UP TOGETHER | 92 | 79 | 40 | 2.22 | +6447 | +161.2 |
| KILLS COUNT NEXT TURN | 139 | 139 | 39 | 2.17 | +1000 | +25.6 |
| WALKS TO THE FIGHT | 54 | 54 | 30 | 1.67 | +570 | +19.0 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 1.61 | +1077 | +37.2 |
| SHOOTERS IN TWO RANKS | 28 | 28 | 28 | 1.56 | +52 | +1.9 |
| SUPPORTS | 75 | 75 | 27 | 1.50 | +199 | +7.4 |
| WAIT AFTER COSTS | 252 | 252 | 27 | 1.50 | +345 | +12.8 |
| BEST MOVE FOR SHOOTERS | 25 | 25 | 25 | 1.39 | +1616 | +64.6 |
| CHARGE NOW FIRST | 98 | 98 | 25 | 1.39 | -1679 | -67.2 |
| FALLBACK BY WORTH | 140 | 140 | 25 | 1.39 | +1668 | +66.7 |
| FOLLOW UP WEIGHED | 25 | 25 | 25 | 1.39 | +3811 | +152.4 |
| SHOT REPLANNED | 25 | 25 | 25 | 1.39 | +0 | +0.0 |
| MODEL FACING | 24 | 24 | 24 | 1.33 | +9335 | +388.9 |
| MAX FOR POSITIONING | 110 | 61 | 23 | 1.28 | +382 | +16.6 |
| LONE WIZARD KEPT IN | 22 | 22 | 22 | 1.22 | +2036 | +92.6 |
| BEST FACING | 21 | 21 | 21 | 1.17 | +772 | +36.8 |
| CHARGE NOW WEIGHED | 21 | 21 | 21 | 1.17 | +2293 | +109.2 |
| SAFER THAN THE JOB | 21 | 21 | 21 | 1.17 | +1021 | +48.6 |
| MAKE SURE TOGETHER | 37 | 33 | 20 | 1.11 | +3229 | +161.4 |
| MISSILES IN THE MOVE | 99 | 51 | 19 | 1.06 | +554 | +29.1 |
| HONEST THREAT | 233 | 233 | 17 | 0.94 | +0 | +0.0 |
| RISK BY ARC | 78 | 76 | 17 | 0.94 | +630 | +37.1 |
| SHORT GUN FORWARD | 17 | 17 | 17 | 0.94 | +0 | +0.0 |
| KILLS COUNT | 59 | 57 | 16 | 0.89 | +509 | +31.8 |
| ADVANCE LANE KEPT | 15 | 15 | 15 | 0.83 | +0 | +0.0 |
| FIRE IN ORDER | 15 | 15 | 15 | 0.83 | +0 | +0.0 |
| SCOUT WAITS | 15 | 15 | 15 | 0.83 | +0 | +0.0 |
| BEST OVERALL | 14 | 14 | 14 | 0.78 | +895 | +63.9 |
| KEEPS THE TARGET | 33 | 33 | 14 | 0.78 | -333 | -23.8 |
| ONE YARDSTICK | 322 | 119 | 14 | 0.78 | +135 | +9.6 |
| STAY WORTH | 406 | 303 | 14 | 0.78 | +101 | +7.2 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.72 | +592 | +45.5 |
| BLOCKED WHEEL | 12 | 12 | 12 | 0.67 | +115 | +9.6 |
| COMBAT PIVOT | 12 | 12 | 12 | 0.67 | +0 | +0.0 |
| SHOOTERS ARE THREATS | 114 | 114 | 12 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.61 | +930 | +84.5 |
| MARCH CHECK | 12 | 11 | 11 | 0.61 | +696 | +63.3 |
| REDIRECT COUNTER | 37 | 22 | 11 | 0.61 | +775 | +70.4 |
| RESERVE FALL BACK | 11 | 11 | 11 | 0.61 | +141 | +12.9 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.56 | +0 | +0.0 |
| INVITES THE FIGHT | 52 | 52 | 10 | 0.56 | +81 | +8.1 |
| KEEPS ITS TARGET | 58 | 58 | 10 | 0.56 | +214 | +21.4 |
| WAR ENGINE JOBS | 20 | 20 | 9 | 0.50 | -179 | -19.8 |
| CASTING BLOCK | 9 | 9 | 8 | 0.44 | +362 | +45.3 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.44 | -607 | -75.9 |
| WHO HITS BACK | 8 | 8 | 8 | 0.44 | +274 | +34.2 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.39 | +0 | +0.0 |
| MOVE AND CAST | 7 | 7 | 7 | 0.39 | +216 | +30.9 |
| MARCH ODDS | 6 | 6 | 6 | 0.33 | +84 | +14.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.33 | +305 | +50.8 |
| WHOLE FIGHT GAIN | 17 | 15 | 6 | 0.33 | +282 | +47.0 |
| BEST PREY | 20 | 20 | 5 | 0.28 | +201 | +40.2 |
| BEST PRIZE | 5 | 5 | 5 | 0.28 | -170 | -34.1 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.28 | +0 | +0.0 |
| OPENS UP | 10 | 10 | 5 | 0.28 | +155 | +31.1 |
| STOPS SHORT OF THE FLANK | 5 | 5 | 5 | 0.28 | +214 | +42.8 |
| SURE REACH TOGETHER | 16 | 13 | 5 | 0.28 | +104 | +20.8 |
| WEARS DOWN | 39 | 37 | 5 | 0.28 | +175 | +35.1 |
| CAST JOB | 26 | 26 | 4 | 0.22 | +42 | +10.4 |
| MISSILES NEXT TURN | 124 | 61 | 4 | 0.22 | +24 | +5.9 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 4 | 0.22 | +308 | +76.9 |
| STAY WEIGHED | 4 | 4 | 4 | 0.22 | +137 | +34.3 |
| WHOLE FIGHT | 7 | 7 | 4 | 0.22 | +250 | +62.4 |
| BIG CHARACTER SAFETY | 3 | 3 | 3 | 0.17 | +6 | +1.9 |
| MANOEUVRE | 3 | 3 | 3 | 0.17 | +129 | +42.9 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.17 | +19 | +6.3 |
| OVERRUNS AWAY | 22 | 21 | 3 | 0.17 | +6 | +2.1 |
| STOPS | 9 | 9 | 3 | 0.17 | +12 | +4.1 |
| SUPPORT NARROWED | 138 | 138 | 3 | 0.17 | -118 | -39.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.11 | -10 | -5.1 |
| DEFENSIVE ARMY | 7 | 7 | 2 | 0.11 | -36 | -18.2 |
| EDGE GIVE GROUND | 5 | 5 | 2 | 0.11 | +188 | +94.2 |
| FACE THE CAST | 2 | 2 | 2 | 0.11 | +29 | +14.7 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.11 | +21 | +10.3 |
| HUNT IN PAIRS | 11 | 7 | 2 | 0.11 | +0 | +0.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.11 | +131 | +65.4 |
| LOST CHARGE | 72 | 71 | 2 | 0.11 | +4 | +2.1 |
| NEEDED THERE | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.11 | +154 | +77.1 |
| STANDS TO CAST | 2 | 2 | 2 | 0.11 | +13 | +6.4 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.11 | -411 | -205.4 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.06 | +40 | +39.7 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.06 | -190 | -189.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.06 | +65 | +65.3 |
| HUNT ADVANCE | 15 | 15 | 1 | 0.06 | +0 | +0.2 |
| MISSILES IN THE FIRE PLAN | 25 | 2 | 1 | 0.06 | +3 | +2.7 |
| OPENS A LANE | 4 | 2 | 1 | 0.06 | +6 | +6.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.06 | -5 | -4.9 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.06 | +34 | +33.7 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.06 | -169 | -168.9 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 13 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 146 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 11 | 11 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT DROPPED | 11 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 11 | 11 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 136 | 136 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| PLAN RESULT | 1362 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 15 | 15 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SHOOTERS TO THE PRIMARY | 22 | 14 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 760 | 760 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 27 | not checked | - | - | - | - |
| STABLE ROLE | 367 | 366 | 0 | 0.00 | - | - |
| TURN WORTH | 7 | 7 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 21 | 20 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-opp-4394159-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 15.56 | 47.6 |
| CHARGE NOW FIRST | rule | 0.17 | 1.22 | 67.2 |
| FALLBACK | gate | 0.44 | 0.44 | 20.5 |
| TURN GATE | gate | 0.33 | 0.28 | 79.3 |
| CANNON PLANNED TARGET | rule | 0.50 | - | 113.3 |
| WAR ENGINE JOBS | rule | 0.33 | 0.17 | 19.8 |
| KEEPS THE TARGET | rule | - | 0.44 | 58.6 |
| PURSUES BIG PREY | rule | 0.11 | 0.33 | 75.9 |
| THROUGH LINE OF FIRE | rule | 0.22 | 0.17 | 24.2 |
| FIRE PLAN | rule | - | 0.33 | 36.6 |
| PATHS CROSS | rule | 0.28 | 0.06 | 11.2 |
| BEST PRIZE | rule | - | 0.28 | 34.1 |
| AFTERMATH BAND | gate | - | 0.22 | 1.7 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 149.8 |
| BLOCKED WHEEL | rule | 0.11 | 0.06 | 11.0 |
| FIGHT ORDER BAND | gate | - | 0.17 | 4.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.11 | 46.2 |
| CHAFF PASSED | rule | 0.11 | - | 5.1 |
| CHARGE NOW WEIGHED | rule | - | 0.11 | 10.0 |
| DEFENSIVE ARMY | rule | 0.11 | - | 18.2 |
| REDIRECT WEIGHED | rule | - | 0.11 | 49.1 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 59.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 205.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 36.1 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 1.4 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 189.7 |
| FACES THE THREAT | rule | - | 0.06 | 1.4 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 1.0 |
| MARCH ODDS | rule | 0.06 | - | 1.3 |
| NO REASON | gate | - | 0.06 | 55.8 |
| PIVOT GUARDS FLANK | rule | 0.06 | - | 4.9 |
| RULE SWITCHED OFF | gate | 0.06 | - | 11.7 |
| WOUNDED STAYS OUT | rule | - | 0.06 | 168.9 |

### Plans: sf-h2h-opp-4394159-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.6 | 9% | 358 | 255 | 71% |
| Mine | charge | 1.6 | 54% | 145 | 144 | 100% |
| Mine | close in | 1.3 | 25% | 25 | 58 | 236% |
| Mine | hold | 2.7 | 55% | 217 | 0 | 0% |
| Mine | join | 0.8 | 100% | 25 | 0 | 0% |
| Mine | shoot | 18.0 | 69% | 410 | 1470 | 359% |
| Mine | support | 2.2 | 92% | 4 | 0 | 0% |
| Opponent | advance | 10.5 | 20% | 323 | 218 | 67% |
| Opponent | charge | 5.1 | 57% | 700 | 414 | 59% |
| Opponent | close in | 6.6 | 24% | 1078 | 222 | 21% |
| Opponent | hold | 6.4 | 46% | 432 | 0 | 0% |
| Opponent | join | 0.7 | 100% | 31 | 0 | 0% |
| Opponent | shoot | 7.6 | 49% | 255 | 183 | 72% |
| Opponent | support | 2.5 | 93% | 10 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-opp-4394159-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.4 | 8 | 1 | 14% | 14% | 0% | 3.0 | 354 | 14 | 14% | 65 |
| Opponent | 0.6 | 10 | 0 | 10% | 10% | 10% | 2.0 | 155 | 13 | 10% | 227 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.3 | 1 | 0 | 100% | 100% | 0% | 3.0 | 105 | 95 | 100% | 47 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Dwarfen Mountain Holds | 0.7 | 8 | 1 | 0% | 0% | 0% | - | 357 | 0 | 0% | 106 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 139 | 0 | 0% | 184 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 432 |
| High Elf Realms | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 58 |
| Kingdom of Bretonnia | 3.0 | 3 | 0 | 33% | 33% | 0% | 2.0 | 146 | 43 | 33% | 277 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 326 |
| Tomb Kings of Khemri | 1.3 | 4 | 0 | 0% | 0% | 25% | - | 150 | 1 | 0% | 201 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 571 |

### Battle groups: sf-h2h-opp-4394159-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.4 | 28% | 51% | 6% | 67% | 27% | 14% | 9% | 50% | 0% |
| Mine | REDIRECT COUNTER | 0.9 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 11% | 54% | 23% | 33% | 50% | 0% | 20% | 30% | 0% |
| Opponent | REDIRECT COUNTER | 1.2 | 10% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-opp-4394159-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 10 | 26 (10) | 26 | 0 | 81 | 80% | 3.5 | 0 (3) | 43 (6) | 0 (1) | 33 (8) | 0 (2) |
| Mine | Character | 81 | 10 (81) | 10 | 0 | 48 | 14% | 2.5 | 15 (26) | 6 (41) | 41 (4) | 10 (44) | 13 (27) |
| Mine | Clean-up | 11 | 56 (11) | 32 | 23 | 67 | 27% | 2.4 | 66 (2) | 54 (9) | - | 0 (6) | 136 (5) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.5 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Hammer | 41 | 38 (41) | 20 | 18 | 40 | 20% | 2.8 | 31 (12) | 42 (26) | 38 (3) | 32 (25) | 47 (16) |
| Mine | Holder | 7 | 88 (7) | 0 | 88 | 48 | 43% | 3.8 | - | 128 (5) | 0 (2) | 112 (5) | 36 (2) |
| Mine | Shooter | 22 | 100 (22) | 60 | 40 | 53 | 0% | 2.0 | 122 (6) | 94 (16) | - | 131 (10) | 80 (12) |
| Mine | War machine | 75 | 50 (75) | 50 | 0 | 53 | 1% | 1.2 | 40 (25) | 47 (44) | 132 (6) | 27 (18) | 57 (57) |
| Mine | Wizard | 7 | 43 (7) | 43 | 0 | 41 | 29% | 2.6 | 61 (2) | 0 (4) | 163 (1) | 74 (4) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 21 | 73 (21) | 15 | 58 | 44 | 38% | 2.1 | 82 (11) | 105 (6) | 0 (4) | 85 (17) | 0 (4) |
| Opponent | Character | 51 | 78 (51) | 78 | 0 | 29 | 43% | 2.7 | 104 (20) | 59 (23) | 54 (8) | 83 (24) | 75 (27) |
| Opponent | Clean-up | 16 | 99 (16) | 47 | 52 | 24 | 31% | 3.5 | 39 (3) | 56 (8) | 209 (5) | 85 (7) | 106 (9) |
| Opponent | Fast | 5 | 19 (5) | 19 | 0 | 65 | 40% | 1.3 | 108 (1) | 0 (4) | - | 19 (5) | - |
| Opponent | Fast Hammer | 22 | 60 (22) | 43 | 17 | 33 | 32% | 2.7 | 18 (11) | 106 (6) | 103 (5) | 68 (15) | 46 (7) |
| Opponent | Hammer | 16 | 14 (16) | 6 | 8 | 20 | 31% | 2.4 | 22 (5) | 12 (9) | 0 (2) | 12 (12) | 18 (4) |
| Opponent | Holder | 21 | 129 (21) | 8 | 121 | 0 | 5% | 2.0 | 0 (2) | 76 (14) | 346 (5) | 87 (15) | 247 (6) |
| Opponent | Shooter | 16 | 91 (16) | 18 | 73 | 4 | 0% | 2.2 | 0 (4) | 130 (11) | 0 (1) | 92 (9) | 90 (7) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 33 | 28 (33) | 28 | 0 | 53 | 24% | 1.4 | 50 (9) | 21 (23) | 0 (1) | 39 (11) | 23 (22) |
| Opponent | Wizard | 19 | 37 (19) | 37 | 0 | 42 | 16% | 2.2 | 2 (10) | 104 (5) | 29 (3) | 67 (9) | 24 (9) |

### Charged fights: sf-h2h-opp-4394159-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 153 | 148 | 1.3 | 1.0 | 111 | 0 | +111 | 2 of 4 | 4 of 4 | - | +111 |
| Mine | Chaos Dwarfs | 4 | 138 | 218 | 1.2 | 1.0 | 174 | 18 | +156 | 4 of 5 | 4 of 5 | - | +156 |
| Mine | Dwarfen Mountain Holds | 11 | 587 | 59 | 1.4 | 1.2 | 43 | 52 | -9 | 4 of 15 | 9 of 15 | -203 | +40 |
| **Mine** | all armies | 18 | 415 | 109 | 1.3 | 1.1 | 82 | 36 | +46 | 10 of 24 | 17 of 24 | -203 | +81 |
| Opponent | Chaos Dwarfs | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 155 | -155 | 2 of 2 | 0 of 2 | - | -155 |
| Opponent | Dwarfen Mountain Holds | 1 | 95 | 65 | 4.0 | 1.0 | 16 | 0 | +16 | 1 of 4 | 2 of 4 | - | +16 |
| Opponent | Empire of Man | 5 | 198 | 66 | 0.6 | 1.0 | 110 | 0 | +110 | 2 of 3 | 2 of 3 | - | +110 |
| Opponent | Grand Cathay | 2 | 128 | 762 | 4.0 | 1.5 | 190 | 0 | +190 | 4 of 8 | 8 of 8 | +608 | +51 |
| Opponent | High Elf Realms | 3 | 258 | 775 | 7.0 | 1.2 | 111 | 6 | +105 | 11 of 21 | 16 of 21 | +159 | +96 |
| Opponent | Kingdom of Bretonnia | 1 | 110 | 321 | 3.0 | 1.3 | 107 | 0 | +107 | 0 of 3 | 3 of 3 | +0 | +160 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 749 | 2.0 | 1.5 | 374 | 0 | +374 | 2 of 2 | 2 of 2 | +186 | +563 |
| Opponent | Tomb Kings of Khemri | 3 | 74 | 1336 | 4.3 | 1.2 | 308 | 0 | +308 | 7 of 13 | 11 of 13 | +530 | +242 |
| Opponent | Vampire Counts | 1 | 0 | 919 | 6.0 | 1.3 | 153 | 0 | +153 | 2 of 6 | 4 of 6 | +306 | +76 |
| **Opponent** | all armies | 18 | 136 | 569 | 3.4 | 1.2 | 165 | 7 | +158 | 31 of 62 | 48 of 62 | +340 | +114 |

### Effective charges: sf-h2h-opp-4394159-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 0 | 1 (net +95) | 2 (net +132) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net +482) | 0 | 0 | 3 (net +100) | 1 | 25% (1 of 4) |
| Mine | Dwarfen Mountain Holds | 15 | 5 (net -144) | 0 | 3 (net +80) | 3 (net +54) | 0 | 3 (net +62) | 1 | 21% (3 of 14) |
| Opponent | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -155) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 4 | 2 (net +0) | 0 | 0 | 2 (net +32) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | Empire of Man | 3 | 1 (net +118) | 0 | 0 | 1 (net +73) | 0 | 1 (net +138) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 8 | 0 | 0 | 2 (net +95) | 4 (net +227) | 0 | 2 (net +214) | 0 | 25% (2 of 8) |
| Opponent | High Elf Realms | 21 | 1 (net +0) | 0 | 4 (net +111) | 4 (net +139) | 2 (net +123) | 7 (net +104) | 3 | 22% (4 of 18) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +91) | 1 (net +230) | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 2 | 1 (net +563) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 1 (net +95) | 1 (net +975) | 2 (net +461) | 3 (net +352) | 1 (net +140) | 2 (net +307) | 3 | 20% (2 of 10) |
| Opponent | Vampire Counts | 6 | 2 (net +306) | 0 | 1 (net +0) | 2 (net +60) | 0 | 0 | 1 | 20% (1 of 5) |

### Charged fights, damage counted: sf-h2h-opp-4394159-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 102 | 284 | -144 | 61 | 150 | -88 | -86.7 |
| Mine | Effective (55-75%) | 4 | 149 | 234 | +180 | 205 | 101 | +104 | +69.9 |
| Mine | 76-89% | 3 | 77 | 137 | +54 | 54 | 0 | +54 | +70.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 363 | 246 | +94 | 178 | 33 | +145 | +39.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 836 | 95 | +95 | 95 | 0 | +95 | +11.4 |
| Mine | No odds | 3 | 417 | 162 | +28 | 28 | 16 | +12 | +3.0 |
| Mine | All fights | 24 | 264 | 222 | +46 | 121 | 61 | +59 | +22.5 |
| Opponent | Long shot (under 50%) | 9 | 231 | 161 | +164 | 164 | 32 | +132 | +57.2 |
| Opponent | 50-54% | 2 | 450 | 234 | +602 | 602 | 40 | +562 | +124.8 |
| Opponent | Effective (55-75%) | 9 | 278 | 187 | +173 | 195 | 17 | +178 | +64.1 |
| Opponent | 76-89% | 16 | 320 | 165 | +174 | 176 | 5 | +171 | +53.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 387 | 272 | +114 | 167 | 46 | +121 | +31.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 708 | 120 | +96 | 112 | 42 | +69 | +9.8 |
| Opponent | No odds | 8 | 359 | 118 | +100 | 100 | 0 | +100 | +27.9 |
| Opponent | All fights | 62 | 350 | 185 | +158 | 175 | 23 | +152 | +43.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-opp-4394159-p1 | move | 159 | 37 (23%) | 24 (15%) | 25 (16%) | 97 (61%) |
| sf-h2h-opp-4394159-p1 | objective | 143 | 25 (17%) | 17 (12%) | 18 (13%) | 100 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0108, L0109 |
| Charmed Shield | Opponent | L0627 |
| Elixir of Power | Opponent | L0511, L0619 |
| Invocation of Nehek | Opponent | L0627 |
| Opal Amulet | Opponent | L0614 |
| Ring of Doom | Opponent | L0315, L0511, L0615 |
| Ring of Jet | Opponent | L0510, L0511 |
| Twice-Blessed Armour | Opponent | L0507, L0510 |
| Witch Hunter's Ward | Opponent | L0108, L0507, L0508 |

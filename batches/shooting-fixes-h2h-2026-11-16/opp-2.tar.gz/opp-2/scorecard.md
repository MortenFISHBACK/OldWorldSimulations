# Doctrine scorecard: sf-h2h-opp-4394159-p2

### Scorecard: sf-h2h-opp-4394159-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0312 | 6 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 445 |
| L0312 | 6 | 1 | Opponent | no | 10 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L0314 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0314 | 2 | 1 | Opponent | - | - | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0334 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 160 |
| L0407 | 5 | 1 | Mine | no | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | no | - | 3 | 2 | 1 | 1 | 0 | 0 | 375 |
| L0518 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0518 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0527 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 548 |
| L0527 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 208 |
| L0531 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 1010 |
| L0531 | 3 | 1 | Opponent | yes | 7 | 5 | 2 | 3 | 1 | 0 | 0 | 484 |
| L0609 | 3 | 1 | Mine | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 615 |
| L0609 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 295 |
| L0618 | 6 | 1 | Mine | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 615 |
| L0618 | 6 | 1 | Opponent | no | 3 | - | 2 | 0 | 1 | 0 | 0 | 0 |
| L0622 | 4 | 1 | Mine | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 1112 |
| L0622 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L0626 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 7 | - | 3 | 2 | 0 | 0 | 0 | 798 |
| L0630 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 420 |
| L0715 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 1 | 0 | 0 | 115 |
| L0718 | 4 | 1 | Mine | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0718 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0720 | 6 | 1 | Mine | no | 3 | 1 | 6 | 0 | 0 | 0 | 0 | 375 |
| L0720 | 6 | 1 | Opponent | no | 9 | 3 | 3 | 1 | 1 | 0 | 0 | 420 |
| L0724 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0724 | 4 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0809 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 807 |
| L0809 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L0818 | 2 | 1 | Mine | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 515 |
| L0818 | 2 | 1 | Opponent | - | - | 4 | 2 | 4 | 1 | 0 | 0 | 225 |
| L0823 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 908 |
| L0913 | 1 | 1 | Opponent | no | 5 | 3 | 4 | 0 | 0 | 0 | 0 | 317 |
| L0915 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 647 |
| L0915 | 3 | 1 | Opponent | yes | 17 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0916 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 641 |
| L0916 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 2 | 0 | 0 | 200 |
| L0925 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 619 |
| L0925 | 1 | 1 | Opponent | no | 0 | 3 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 632 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 216 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1215 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1215 | 3 | 1 | Opponent | yes | 2 | 1 | 0 | 0 | 1 | 0 | 0 | 176 |
| L1222 | 4 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 697 |
| L1222 | 4 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 55 |
| L1533 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1722 | 6 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1722 | 6 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1819 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1832 | 2 | 1 | Mine | - | - | 1 | 5 | 0 | 1 | 0 | 0 | 251 |
| L1832 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2122 | 4 | 1 | Mine | no | 3 | - | 0 | 6 | 1 | 0 | 0 | 145 |
| L2122 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 55 |
| L2226 | 6 | 1 | Mine | no | 4 | 2 | 3 | 1 | 1 | 0 | 0 | 55 |
| L2226 | 6 | 1 | Opponent | no | 10 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 3% | 1.7 | 2.5 | 2.1 | 0.9 | 0.2 | 0.0 | 0.0 | 507.8 |
| **Average** | | | Opponent | 17% | 3.4 | 2.2 | 3.1 | 1.7 | 0.5 | 0.0 | 0.0 | 124.6 |

### KPIs: sf-h2h-opp-4394159-p2

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 53% (97 of 182) | 2% (3 of 177) | 28% (100 of 359) |
| Winner chose to follow up after the loser gave ground |  | 91% (59 of 65); on the table 91% | 98% (44 of 45); on the table 98% | 94% (103 of 110); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 40% (2 of 5); on the table 80% | 93% (14 of 15); on the table 100% | 80% (16 of 20); on the table 95% |
| Winner chose to pursue after the loser fled |  | 70% (21 of 30); on the table 80% | 82% (33 of 40); on the table 85% | 77% (54 of 70); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 82% (82 of 100); on the table 87% | 91% (91 of 100); on the table 93% | 86% (173 of 200); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 32% (70 of 222) | 21% (38 of 180) | 27% (108 of 402) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (70 of 157) | 27% (38 of 140) | 36% (108 of 297) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 20% (24 of 120) | 14% (16 of 114) | 17% (40 of 234) |
|     round 1 |  | 0% (0 of 20) | 5% (1 of 19) | 3% (1 of 39) |
|     rounds 2+ |  | 24% (24 of 100) | 16% (15 of 95) | 20% (39 of 195) |
|   other wizards | 50%+ | 45% (46 of 102) | 33% (22 of 66) | 40% (68 of 168) |
|     round 1 |  | 35% (6 of 17) | 27% (3 of 11) | 32% (9 of 28) |
|     rounds 2+ |  | 47% (40 of 85) | 35% (19 of 55) | 42% (59 of 140) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (10 of 16) | 49% (19 of 39) | 53% (29 of 55) |
| Points that never fought | lower | 42% (30075 of 71134) | 42% (30561 of 71985) | 42% (60636 of 143119) |
|   infantry points that never fought | lower | 46% (7922 of 17321) | 71% (9832 of 13831) | 57% (17754 of 31152) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (210 of 317) | 55% (149 of 269) | 61% (359 of 586) |
| Bound items with a magic missile used (at least once a game) |  | 93% (14 of 15); 0.9 uses a game | 79% (15 of 19); 1.4 uses a game | 85% (29 of 34); 1.2 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.2 uses a game | 33% (3 of 9); 0.1 uses a game | 46% (6 of 13); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 21% (3 of 14); 0.1 uses a game | 40% (4 of 10); 0.1 uses a game | 29% (7 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (37384 of 59205) | 48% (29818 of 62613) | 55% (67202 of 121818) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (30%) | 1.1 (28%) | 2.4 (29%) |
| MARCHED: its unit marched | 0.9 (22%) | 0.8 (20%) | 1.7 (21%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.2 (6%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.6 (13%) | 0.8 (20%) | 1.4 (17%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.2 (6%) | 0.4 (4%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (18%) | 0.3 (8%) | 1.1 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.0 (0%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.4 (11%) | 0.4 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.9 | 1.5 | 3.0 | 0.2 | 1.4 |
| not cast | 2.9 | 2.4 | 2.3 | 8.2 | 1.0 | 14.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.2 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (28%) | 0.1 (6%) | 2.4 (29%) | 0.3 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (21%) | 0.2 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (4%) | 0.5 (21%) | 1.4 (17%) | 0.2 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (13%) | 1.0 (41%) | 0.6 (24%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.1 (6%) | 0.3 (2%) |
| GONE: slain | 0.9 (31%) | 0.4 (15%) | 0.4 (19%) | 1.1 (13%) | 0.2 (17%) | 2.1 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (11%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (44%) | 0.0 (0%) | 0.5 (23%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.0 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 1.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 71% (5 of 7) | 77% (17 of 22) | 76% (22 of 29) |
| the unit moved after it | 80% (4 of 5) | 29% (5 of 17) | 41% (9 of 22) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 17) | 0% (0 of 22) |
| the enemy charged it first | 20% (1 of 5) | 6% (1 of 17) | 9% (2 of 22) |
| it fought by the end of its next turn | 20% (1 of 5) | 0% (0 of 17) | 5% (1 of 22) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (1 of 5) | 6% (1 of 17) | 9% (2 of 22) |
| none of these (no charge, no fight, no charge escaped) | 60% (3 of 5) | 88% (15 of 17) | 82% (18 of 22) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (936 of 1376) | 55% (482 of 876) | 63% (1418 of 2252) |
|   cavalry | 71% (49 of 69) | 62% (77 of 125) | 65% (126 of 194) |
|   character | 75% (118 of 158) | 26% (41 of 160) | 50% (159 of 318) |
|   chariot | 50% (59 of 118) | 71% (53 of 75) | 58% (112 of 193) |
|   infantry | 55% (227 of 416) | 55% (214 of 389) | 55% (441 of 805) |
|   monster | 58% (41 of 71) | 62% (29 of 47) | 59% (70 of 118) |
|   war machine | 81% (442 of 544) | 85% (68 of 80) | 82% (510 of 624) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.2 (26%) | 2.8 (26%) | 6.0 (26%) |
| CHARGED: it charged | 1.2 (10%) | 2.4 (22%) | 3.7 (16%) |
| FLEEING: it fled or was fleeing | 0.3 (2%) | 0.1 (1%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.2 (10%) | 0.7 (6%) | 1.9 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (15%) | 2.5 (23%) | 4.4 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (5%) | 0.6 (5%) | 1.2 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (20%) | 1.4 (13%) | 3.8 (17%) |
| SHELTERED: the target was sheltered | 0.6 (5%) | 0.2 (2%) | 0.8 (3%) |
| STUPIDITY | 0.1 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.8 (6%) | 0.1 (1%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 2.2 | 79% | 7.8 pts | 46 pts |
| character | 4.8 | 1.4 | 77% | 8.8 pts | 43 pts |
| chariot | 3.2 | 1.9 | 62% | 14.5 pts | 46 pts |
| infantry | 17.2 | 5.9 | 75% | 6.8 pts | 117 pts |
| monster | 2.3 | 0.8 | 77% | 10.3 pts | 24 pts |
| war machine | 14.4 | 11.5 | 64% | 24.8 pts | 357 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.4 | 6.5 | 5.0 |
| Charges that made contact a game | 2.5 | 4.8 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.45 contact (20 units) | 1.50 declared, 1.17 contact (12 units) | 0.88 declared, 0.72 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 0.75 declared, 0.50 contact (8 units) | 0.82 declared, 0.55 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.32 contact (244 units) | 0.70 declared, 0.51 contact (301 units) | 0.59 declared, 0.43 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (30 of 57) | 29% (4 of 14) | 71% (5 of 7) | 50% (39 of 78) |
| Character in a unit | 88% (38 of 43) | 62% (10 of 16) | 50% (1 of 2) | 80% (49 of 61) |
| Character on its own | 85% (29 of 34) | 54% (14 of 26) | 31% (18 of 58) | 52% (61 of 118) |
| Chariot | 73% (16 of 22) | 59% (10 of 17) | - | 67% (26 of 39) |
| Infantry | 57% (52 of 92) | 56% (20 of 36) | 60% (3 of 5) | 56% (75 of 133) |
| Monster | 58% (15 of 26) | 77% (10 of 13) | - | 64% (25 of 39) |
| Monstrous | 100% (8 of 8) | 48% (12 of 25) | - | 61% (20 of 33) |
| War Machines | 74% (61 of 82) | 100% (3 of 3) | - | 75% (64 of 85) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 4 | 67% (6 of 9); on the table 78% | 33% (12 of 36) | 34% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Dwarfen Mountain Holds | 10 | 83% (15 of 18); on the table 83% | - | 61% | 73% (62 of 85) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 15 | 80% (28 of 35); on the table 80% | 39% (45 of 114) | 46% | 70% (111 of 159) | 0.0 uses a game | 60% (3 of 5); 0.5 uses a game | 12% (1 of 8); 0.1 uses a game |
| Grand Cathay | 4 | 87% (13 of 15); on the table 100% | 19% (18 of 96) | 53% | 49% (17 of 35) | 91% (10 of 11); 6.0 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 7 | 93% (14 of 15); on the table 93% | 25% (6 of 24) | 35% | 60% (31 of 52) | 82% (9 of 11); 3.7 uses a game | 38% (3 of 8); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 18% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 8% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 7 | 87% (20 of 23); on the table 96% | 6% (2 of 36) | 50% | 69% (34 of 49) | 86% (6 of 7); 2.4 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (7 of 7); on the table 100% | 50% (6 of 12) | 0% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 62% (5 of 8); on the table 75% | 39% (7 of 18) | 48% | 39% (9 of 23) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 6 | 95% (20 of 21); on the table 95% | 17% (1 of 6) | 33% | 43% (13 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 95% (19 of 20); on the table 100% | 21% (10 of 48) | 26% | 36% (13 of 36) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 44% | 65% (17 of 26) | 100% (1 of 1); 1.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 4 | 80% (12 of 15); on the table 80% | 17% (1 of 6) | 39% | 55% (21 of 38) | 100% (3 of 3); 3.2 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-opp-4394159-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (40) | 62% (32) | 53% (72) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.47 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.22 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.28 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 0.69 | 2.69 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 0.47 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.06 | 5.39 | 10.44 |

### Quality by phase: sf-h2h-opp-4394159-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 63% (62 of 98) | 51% (107 of 211) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (326 of 603) | 41% (97 of 238) |
| Strategy | Close-in objectives charged next turn | 11% (13 of 119) | 19% (47 of 249) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | 44% (16 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 40% (23 of 57) | 45% (18 of 40) |
| Strategy | Lone characters that fought | 67% (60 of 89) | 72% (55 of 76) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 507.8 | 124.6 |
| Movement | Fights charged into per game | 2.1 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 71, net -258 | 20 of 123, net +24 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 71, net +15 | 21 of 123, net +116 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 71, net +99 | 14 of 123, net +189 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 71, net +50 | 37 of 123, net +111 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.8 | 12.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (225 of 532) | 40% (183 of 455) |
| Shooting | Points destroyed by shooting units | 141.1 | 65.8 |
| Shooting | War machine shots | 12.3 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (232 of 442) | 29% (22 of 75) |
| Shooting | Points destroyed by war machines | 142.9 | 37.6 |
| Magic | Magic missiles cast | 1.0 | 0.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (14 of 36) | 48% (10 of 21) |
| Magic | Wounds caused by magic missiles | 2.6 | 2.1 |
| Magic | Wounds caused by other spells | 0.4 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 35.5 | 46.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.1 / 0.2 / 0.0 | 2.5 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 191.2 | 448.5 |
| Combat | Points run down | 56.3 | 113.4 |
| Combat | Net points per charged fight, damage counted | +11 | +86 |
| Combat | Net per 100 charger points, damage counted | +4.9 | +28.4 |
| Combat | First round won (charged fights) | 71% | 68% |
| Combat | Net points per charged fight | -6 | +86 |
| Combat | Net points per supported fight / lone fight | +9 / -8 | +156 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 23 of 77 | 71 of 145 |
| Game | Points lost | 865.9 | 595.2 |
| Game | VP from objectives | 398.3 | 730.8 |
| Game | Lone holders (player turns) | 1.7 | 3.4 |

- Mine won / drew / lost: 7 / 6 / 23 of 36 ended games (of 36); mean margin (Mine - Opponent) -624 VP
- The side that went first won 12 of 30 games with a winner
- Points traded per game (both sides' losses): 1461
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-opp-4394159-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +10.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 50.3 | 0.4 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.8 | +6.2 | 0.0 | 41.7 | 1.0 | +8.0 | 0.0 | 35.6 |
| BEST FACING | 0.8 | +42.5 | 0.0 | 27.8 | 0.3 | +6.1 | 0.0 | 5.1 |
| BEST FIRST | 3.8 | +140.8 | 113.6 | 95.0 | 4.8 | +210.9 | 128.8 | 65.2 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.9 | +76.7 | 0.0 | 22.0 |
| BEST OVERALL | 0.9 | +66.0 | 0.0 | 54.3 | 0.4 | +16.6 | 0.0 | 10.2 |
| BEST PREY | 0.7 | +30.7 | 14.6 | 17.4 | 0.9 | +29.8 | 26.9 | 29.7 |
| BEST PRIZE | 0.1 | +7.0 | 0.0 | 0.0 | 0.1 | -2.0 | 2.6 | 3.2 |
| BIG CHARACTER SAFETY | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 15.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +4.6 | 0.0 | 1.8 | 0.7 | +19.8 | 0.0 | 25.6 |
| BOMBING RUN | 0.1 | +1.2 | 0.0 | 5.8 | - | - | - | - |
| CANNON PLAN MISSED | 1.4 | +0.0 | 172.5 | 24.2 | - | - | - | - |
| CANNON PLANNED TARGET | 10.2 | +309.0 | 744.8 | 231.8 | - | - | - | - |
| CANNON SIGHT KEPT | 2.1 | +0.0 | 0.0 | 2.8 | 0.5 | +0.0 | 0.0 | 4.6 |
| CARRIES OUT COUNTER | 0.0 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -0.7 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +36.8 | 47.7 | 12.9 | 0.2 | +3.4 | 20.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.0 | +0.9 | 0.0 | 0.0 | 0.2 | +5.9 | 18.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 21.1 | 0.7 | +0.0 | 0.0 | 28.4 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.6 | -1.1 | 10.3 | 4.9 | - | - | - | - |
| CHARGE NOW FIRST | 2.1 | +0.0 | 171.5 | 114.0 | 3.4 | +0.0 | 289.6 | 68.9 |
| CHARGE NOW WEIGHED | 0.4 | -14.7 | 14.8 | 13.3 | 0.4 | -46.9 | 15.8 | 26.5 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.8 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.8 | 0.2 | +0.0 | 11.7 | 7.1 |
| COMBAT PIVOT | 0.2 | +0.0 | 16.5 | 16.1 | 0.4 | +0.0 | 19.6 | 25.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.1 | +15.8 | 10.5 | 21.1 | 0.6 | +103.2 | 12.5 | 10.5 |
| COUNTER-CHARGE COVER | 11.2 | +894.4 | 0.0 | 288.9 | 6.9 | +659.1 | 0.0 | 140.5 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 21.4 | 5.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +0.0 | 6.1 | 0.0 | 0.4 | +5.4 | 31.1 | 5.4 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 8.9 | +0.0 | 487.6 | 97.6 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FACES THE THREAT | 2.0 | +190.1 | 0.0 | 86.4 | 0.7 | +63.4 | 0.0 | 15.4 |
| FALLBACK BY WORTH | 4.3 | +46.2 | 0.0 | 79.0 | 5.8 | +68.6 | 0.0 | 42.2 |
| FIGHT LIFT | - | - | - | - | 0.1 | +2.3 | 13.1 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 30.6 | 13.4 |
| FIRE PLAN | - | - | - | - | 12.8 | +23.4 | 631.4 | 121.7 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 231.0 | 4.9 | +0.0 | 0.0 | 136.9 |
| FOLLOW UP WEIGHED | 0.9 | +161.4 | 0.0 | 58.3 | 1.1 | +186.9 | 0.0 | 57.3 |
| FRIENDS SHOTS CHECKED | 0.4 | +17.8 | 0.0 | 18.9 | 0.3 | +26.4 | 0.0 | 16.2 |
| GIVES UP | 0.1 | -0.2 | 1.8 | 0.0 | 0.1 | -1.0 | 5.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 3.8 | 0.0 | 0.0 | -0.8 | 2.9 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 21.5 | 0.8 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 5.4 | 0.4 | +0.0 | 67.6 | 3.9 |
| HILL BY ITS CHANCE | 0.2 | -14.3 | 0.0 | 2.6 | 0.5 | -44.8 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 8.9 | +1009.7 | 487.6 | 97.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.4 | 0.0 | 0.0 | 0.5 | +17.1 | 35.9 | 14.8 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 2.4 | 3.2 |
| HUNT IN PAIRS | 0.3 | +8.5 | 0.0 | 19.9 | 0.6 | +19.2 | 0.0 | 27.4 |
| HUNT KEPT | - | - | - | - | 0.3 | +17.3 | 19.9 | 6.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.5 | +56.4 | 2.4 | 8.8 |
| HUNT THE GUNS | 0.0 | +7.7 | 0.0 | 0.0 | 0.6 | +195.2 | 37.1 | 14.8 |
| INVITES THE FIGHT | 1.4 | +28.8 | 33.0 | 31.7 | 1.4 | +17.4 | 41.0 | 20.4 |
| JOINT CHARGE PLAN | 0.1 | +0.0 | 0.0 | 3.3 | 0.2 | +5.8 | 0.0 | 3.1 |
| KEEP FALLS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.0 | +30.0 | 50.8 | 48.3 | 2.6 | +79.2 | 153.5 | 63.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 1.2 | -14.5 | 74.6 | 19.1 |
| KILLS COUNT | 1.3 | +63.3 | 95.2 | 60.3 | 2.7 | +127.2 | 192.7 | 49.2 |
| KILLS COUNT NEXT TURN | 4.0 | +132.5 | 132.0 | 129.8 | 7.3 | +264.2 | 198.6 | 171.7 |
| LONE CHARACTER SAFE SPOT | 0.6 | +13.4 | 15.0 | 16.2 | 0.2 | +9.4 | 14.4 | 6.3 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +24.0 | 0.0 | 0.0 | 0.4 | +32.7 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -2.6 | 14.7 | 11.4 | 0.6 | -3.9 | 53.8 | 9.5 |
| LOST CHARGE | 2.8 | -50.0 | 102.5 | 155.3 | 2.6 | -43.0 | 38.9 | 72.9 |
| LURE BY WHAT IT DRAWS | 0.2 | -5.7 | 0.0 | 1.0 | 0.0 | -11.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +11.6 | 20.4 | 10.1 | 1.0 | +92.8 | 16.6 | 41.3 |
| MANOEUVRE | 0.3 | +12.9 | 0.0 | 2.9 | 0.2 | +9.4 | 0.0 | 2.0 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +29.7 | 0.0 | 17.6 | 0.3 | +16.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +6.0 | 6.0 | 0.0 | 0.3 | +26.7 | 13.3 | 15.0 |
| MARCH OVER CASTS | 0.7 | +42.2 | 0.0 | 31.7 | 0.6 | +25.5 | 0.0 | 21.5 |
| MAX FOR POSITIONING | 4.1 | +113.5 | 0.0 | 108.9 | 4.8 | +205.9 | 0.0 | 149.0 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.8 | +3.0 | 48.5 | 0.0 |
| MISSILES IN THE MOVE | 3.1 | +106.0 | 0.0 | 98.0 | 3.1 | +47.0 | 0.0 | 34.1 |
| MISSILES NEXT TURN | 3.9 | +73.0 | 0.0 | 133.8 | 3.9 | +37.9 | 0.0 | 55.6 |
| MODEL FACING | 0.7 | +240.7 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 10.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +20.6 | 0.0 | 4.7 | 0.3 | +11.2 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +4.4 | 0.0 | 16.1 | 0.0 | +0.3 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.4 | 3.3 | 64.6 | 0.3 | -12.5 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 21.1 | 0.2 | +0.0 | 0.0 | 6.0 |
| MOVE TO CHARGE | 2.5 | +152.3 | 89.5 | 98.9 | 5.6 | +396.0 | 162.7 | 154.5 |
| MOVES UNITS SPELL | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +2.7 | 5.1 | 5.4 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -9.9 | 21.5 | 13.7 | 0.6 | -36.2 | 95.9 | 10.8 |
| NOT TURNED | 5.1 | +69.5 | 0.0 | 159.3 | 5.4 | +64.6 | 0.0 | 129.2 |
| NOT WORTH A CAST | 0.5 | -0.2 | 0.0 | 34.0 | 0.2 | -5.0 | 0.0 | 16.2 |
| OFF BEST | 17.0 | -751.2 | 0.0 | 367.6 | 15.7 | -769.7 | 6.6 | 260.4 |
| ONE YARDSTICK | - | - | - | - | 12.5 | -404.7 | 335.1 | 116.6 |
| OPENS A LANE | 0.1 | +0.8 | 20.9 | 0.0 | 0.1 | +2.2 | 3.5 | 0.0 |
| OPENS UP | 0.1 | +5.4 | 2.5 | 0.0 | 0.3 | +22.7 | 12.6 | 5.4 |
| OVERRUNS AWAY | 0.3 | +5.8 | 15.6 | 0.0 | 0.4 | +2.2 | 34.6 | 21.7 |
| PATHS CROSS | 1.9 | +106.1 | 0.0 | 60.2 | 2.9 | +199.5 | 0.0 | 17.9 |
| PERIAPT WORTH | 0.0 | +3.5 | 0.0 | 0.0 | 0.0 | +1.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.4 | 0.0 | 10.5 | 0.2 | -4.1 | 0.0 | 2.6 |
| PLAN RESULT | 39.4 | +1658.5 | 1544.3 | 1155.6 | 40.6 | +1465.1 | 1331.8 | 928.5 |
| PURSUES BIG PREY | 0.0 | -0.7 | 0.0 | 0.0 | 0.2 | -12.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +10.6 | 0.0 | 8.9 |
| RANDOM MOVE BY FIGURES | 0.4 | +5.0 | 0.0 | 0.0 | 1.1 | +15.7 | 0.0 | 42.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -5.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +0.4 | 0.0 | 4.2 | 0.3 | -11.1 | 0.0 | 4.7 |
| REDIRECT COUNTER | 1.2 | +62.6 | 0.0 | 23.1 | 3.1 | +283.7 | 0.0 | 53.5 |
| REDIRECT WEIGHED | 0.2 | +10.4 | 0.0 | 0.0 | 0.6 | +18.3 | 17.5 | 6.5 |
| RESERVE FALL BACK | 0.1 | +2.2 | 0.0 | 8.3 | 1.1 | +41.1 | 0.0 | 15.5 |
| RESTRAINS TO SHOOT | 0.3 | +13.2 | 0.0 | 8.6 | 0.1 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +80.7 | 131.1 | 118.8 | 3.6 | +77.3 | 262.2 | 86.2 |
| SAFER THAN THE JOB | 1.1 | +66.6 | 0.0 | 23.4 | 0.5 | +36.5 | 0.0 | 10.2 |
| SCOUT SPOT | 0.6 | +0.4 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -14.4 | 0.0 | 3.8 |
| SEARCH SPOT | 2.1 | +105.3 | 0.0 | 34.6 | 3.1 | +142.7 | 0.0 | 42.4 |
| SECOND HUNTER | - | - | - | - | 0.1 | -2.9 | 4.6 | 3.2 |
| SELF MOVE SPELL | 0.3 | +92.8 | 0.0 | 0.0 | 0.5 | +111.3 | 0.0 | 32.9 |
| SET UP TOGETHER | 0.7 | +21.8 | 20.4 | 18.5 | 1.5 | +156.9 | 16.6 | 45.5 |
| SET-UP ANY TARGET | 0.1 | +6.9 | 10.5 | 21.1 | 0.4 | +57.1 | 12.5 | 10.5 |
| SET-UP MISSED | 0.1 | +7.8 | 10.6 | 10.6 | 0.1 | +16.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 3.8 | +257.4 | 256.4 | 41.8 |
| SHOOTERS IN TWO RANKS | 0.8 | +1.5 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.9 | +33.4 | 0.0 | 19.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +53.3 | 68.2 | 24.7 | 1.0 | +24.8 | 33.6 | 6.3 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 25.4 | +0.0 | 1215.4 | 492.6 | 13.8 | +0.0 | 617.9 | 179.0 |
| SHOT REPLANNED | 1.4 | +0.0 | 257.8 | 19.8 | - | - | - | - |
| SHOTS IN THE MOVE | 22.4 | +1050.9 | 0.0 | 468.3 | 12.9 | +472.5 | 0.0 | 140.2 |
| SPELL CATCH ODDS | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +12.6 | 10.5 | 21.1 | 0.4 | +57.1 | 12.5 | 10.5 |
| SPELL WORTH | 0.6 | +13.2 | 33.3 | 33.3 | 2.4 | +64.2 | 41.1 | 28.1 |
| STABLE ROLE | 11.6 | +0.0 | 333.4 | 257.9 | 10.9 | +0.0 | 319.8 | 144.9 |
| STANDS TO CAST | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 15.2 | +166.2 | 305.6 | 170.5 |
| STOPS | - | - | - | - | 0.3 | +18.4 | 17.9 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.6 | +22.8 | 0.0 | 23.2 | 0.3 | +16.1 | 0.0 | 7.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.0 | -48.2 | 286.4 | 94.3 | 6.7 | -38.2 | 333.7 | 105.6 |
| SUPPORTS | 3.3 | +64.2 | 164.6 | 42.2 | 3.7 | +41.3 | 94.2 | 28.7 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.3 | 9.1 | 5.4 | 0.1 | -1.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +0.9 | 0.0 | 8.5 | 0.8 | -3.1 | 0.0 | 30.2 |
| THROUGH LINE OF FIRE | 0.6 | +44.6 | 0.0 | 5.2 | 0.3 | +10.1 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -20.3 | 33.5 | 2.9 | 0.4 | -31.9 | 27.2 | 5.4 |
| TWO OR MORE ARRIVE | 0.2 | +0.5 | 7.6 | 1.7 | 0.5 | +18.4 | 8.0 | 11.1 |
| WAIT AFTER COSTS | 6.1 | -258.4 | 185.1 | 202.7 | 9.3 | -471.3 | 276.7 | 210.4 |
| WALKS TO THE FIGHT | 2.3 | +50.6 | 59.1 | 76.5 | 1.2 | +24.3 | 26.3 | 17.5 |
| WAR ENGINE CHARGES | 0.2 | +22.5 | 13.1 | 19.0 | 0.1 | +8.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 26.2 | 45.0 | 0.2 | +0.0 | 1.8 | 0.0 |
| WEARS DOWN | 0.8 | +34.9 | 27.8 | 77.3 | 1.1 | +43.9 | 62.3 | 27.2 |
| WHO HITS BACK | 0.2 | +15.0 | 0.0 | 26.7 | 0.3 | +22.2 | 0.0 | 13.1 |
| WHOLE FIGHT | 0.2 | +8.4 | 33.5 | 4.3 | 0.3 | +5.4 | 32.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +16.7 | 10.6 | 3.5 | 0.8 | +73.5 | 110.5 | 14.0 |

### Rule changes: sf-h2h-opp-4394159-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1178 | 1178 | 1178 | 32.72 | -54751 | -46.5 |
| BEST FIRST | 308 | 308 | 308 | 8.56 | +12662 | +41.1 |
| SEARCH SPOT | 186 | 186 | 184 | 5.11 | +8958 | +48.7 |
| PATHS CROSS | 172 | 172 | 172 | 4.78 | +11002 | +64.0 |
| COUNTER-CHARGE COVER | 652 | 343 | 156 | 4.33 | +9148 | +58.6 |
| MOVE TO CHARGE | 291 | 291 | 148 | 4.11 | +6752 | +45.6 |
| KILLS COUNT NEXT TURN | 406 | 406 | 137 | 3.81 | +4533 | +33.1 |
| SHOTS IN THE MOVE | 1273 | 838 | 129 | 3.58 | +4558 | +35.3 |
| ARTILLERY RE-ROLL WEIGHED | 108 | 108 | 108 | 3.00 | +0 | +0.0 |
| FACES THE THREAT | 97 | 97 | 97 | 2.69 | +9126 | +94.1 |
| FIRE PLAN | 462 | 462 | 97 | 2.69 | +245 | +2.5 |
| CANNON SIGHT KEPT | 95 | 95 | 95 | 2.64 | +0 | +0.0 |
| SUPPORTS | 253 | 253 | 89 | 2.47 | +1107 | +12.4 |
| FOLLOW UP WEIGHED | 74 | 74 | 74 | 2.06 | +12541 | +169.5 |
| FALLBACK BY WORTH | 365 | 365 | 73 | 2.03 | +4131 | +56.6 |
| EVERY WOUND COUNTS | 322 | 322 | 69 | 1.92 | +0 | +0.0 |
| CANNON PLANNED TARGET | 367 | 367 | 68 | 1.89 | -271 | -4.0 |
| WAIT AFTER COSTS | 556 | 556 | 67 | 1.86 | +1135 | +16.9 |
| WALKS TO THE FIGHT | 127 | 127 | 64 | 1.78 | +762 | +11.9 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +3713 | +64.0 |
| SCOUT WAITS | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +2973 | +60.7 |
| SHOT REPLANNED | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| HONEST THREAT | 322 | 322 | 47 | 1.31 | +0 | +0.0 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1560 | +34.7 |
| CHARGE NOW FIRST | 197 | 197 | 43 | 1.19 | -3293 | -76.6 |
| RISK BY ARC | 202 | 198 | 43 | 1.19 | +1430 | +33.3 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| BEST FACING | 40 | 40 | 40 | 1.11 | +1751 | +43.8 |
| SHOOTERS IN TWO RANKS | 38 | 38 | 38 | 1.06 | +70 | +1.8 |
| SET UP TOGETHER | 77 | 62 | 36 | 1.00 | +2661 | +73.9 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +880 | +25.2 |
| KILLS COUNT | 143 | 140 | 35 | 0.97 | +1052 | +30.1 |
| BEST MOVE FOR SHOOTERS | 34 | 34 | 34 | 0.94 | +2762 | +81.2 |
| SHOOTS FROM THE BEST SPOT | 72 | 72 | 34 | 0.94 | +1040 | +30.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2039 | +61.8 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1400 | +45.2 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +1970 | +63.5 |
| MISSILES IN THE MOVE | 221 | 118 | 30 | 0.83 | +642 | +21.4 |
| STAY WORTH | 546 | 403 | 30 | 0.83 | +440 | +14.7 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +527 | +18.2 |
| RANDOM MOVE BY FIGURES | 55 | 55 | 29 | 0.81 | +746 | +25.7 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| MAX FOR POSITIONING | 322 | 183 | 28 | 0.78 | +373 | +13.3 |
| ONE YARDSTICK | 450 | 144 | 28 | 0.78 | +385 | +13.8 |
| REDIRECT COUNTER | 156 | 77 | 27 | 0.75 | +2328 | +86.2 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +1025 | +38.0 |
| MODEL FACING | 26 | 26 | 26 | 0.72 | +8664 | +333.2 |
| MARCH CHECK | 32 | 28 | 25 | 0.69 | +1294 | +51.8 |
| MOVE AND CAST | 25 | 25 | 25 | 0.69 | +1145 | +45.8 |
| FIRE IN ORDER | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1590 | +66.3 |
| KEEPS ITS TARGET | 131 | 130 | 24 | 0.67 | +450 | +18.8 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| INVITES THE FIGHT | 102 | 102 | 22 | 0.61 | +361 | +16.4 |
| CHAFF PASSED | 21 | 21 | 21 | 0.58 | -39 | -1.9 |
| SHOOTERS ARE THREATS | 138 | 138 | 20 | 0.56 | +0 | +0.0 |
| BEST PREY | 58 | 58 | 19 | 0.53 | +826 | +43.5 |
| KEEPS THE TARGET | 42 | 42 | 18 | 0.50 | -759 | -42.2 |
| SHORT GUN FORWARD | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| CAST JOB | 38 | 38 | 17 | 0.47 | +457 | +26.9 |
| MAKE SURE TOGETHER | 51 | 35 | 17 | 0.47 | +1256 | +73.9 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +804 | +47.3 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1073 | +63.1 |
| WHOLE FIGHT GAIN | 31 | 29 | 17 | 0.47 | +717 | +42.2 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +52 | +3.3 |
| WEARS DOWN | 67 | 65 | 16 | 0.44 | +624 | +39.0 |
| RESTRAINS TO SHOOT | 15 | 15 | 15 | 0.42 | +583 | +38.9 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| LOST CHARGE | 193 | 192 | 14 | 0.39 | +486 | +34.7 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -160 | -17.8 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | -22 | -2.7 |
| OPENS UP | 14 | 14 | 8 | 0.22 | +220 | +27.5 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -472 | -59.0 |
| WAR ENGINE JOBS | 34 | 34 | 8 | 0.22 | -679 | -84.9 |
| CASTING BLOCK | 8 | 8 | 7 | 0.19 | +73 | +10.5 |
| HUNT IN PAIRS | 32 | 19 | 7 | 0.19 | +223 | +31.8 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -402 | -67.0 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| DEFENSIVE ARMY | 19 | 19 | 6 | 0.17 | -186 | -30.9 |
| MISSILES NEXT TURN | 279 | 153 | 6 | 0.17 | +10 | +1.6 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +41 | +6.8 |
| HUNT ADVANCE | 18 | 18 | 5 | 0.14 | +60 | +11.9 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SHOOTERS TO THE PRIMARY | 70 | 48 | 5 | 0.14 | +25 | +5.0 |
| SUPPORT NARROWED | 420 | 420 | 5 | 0.14 | -49 | -9.8 |
| SURE REACH TOGETHER | 37 | 29 | 5 | 0.14 | +19 | +3.7 |
| BACKUP TARGETS | 64 | 31 | 4 | 0.11 | +13 | +3.2 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 27 | 26 | 4 | 0.11 | +94 | +23.4 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +106 | +26.4 |
| STOPS | 11 | 11 | 4 | 0.11 | +283 | +70.8 |
| WAR ENGINE CHARGES | 9 | 9 | 4 | 0.11 | +362 | +90.5 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -79 | -26.3 |
| WHOLE FIGHT | 20 | 20 | 3 | 0.08 | +52 | +17.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +42 | +20.9 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -89 | -44.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +14 | +7.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +148 | +74.0 |
| LONG SHOT | 36 | 35 | 2 | 0.06 | +4 | +1.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +189 | +94.6 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -140 | -139.5 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -24 | -24.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +27 | +26.7 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +4 | +4.0 |
| HILL BY ITS CHANCE | 28 | 28 | 1 | 0.03 | +22 | +22.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +18 | +18.5 |
| MISSILES IN THE FIRE PLAN | 28 | 2 | 1 | 0.03 | +0 | +0.4 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +32 | +32.5 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 1 | 0.03 | +69 | +69.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -12 | -11.5 |
| ARRIVAL HUNT | 7 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 50 | 50 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 14 | 14 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 372 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 17 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 8 | 8 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 46 | 46 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 27 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 376 | 376 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 23 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2880 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 44 | 44 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 30 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1412 | 1412 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 109 | not checked | - | - | - | - |
| STABLE ROLE | 813 | 813 | 0 | 0.00 | - | - |
| TURN WORTH | 27 | 27 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 22 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-opp-4394159-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.97 | 13.97 | 46.7 |
| FALLBACK | gate | 0.78 | 0.72 | 45.0 |
| TURN GATE | gate | 0.75 | 0.58 | 54.5 |
| CHARGE NOW FIRST | rule | 0.50 | 0.69 | 76.6 |
| CANNON PLANNED TARGET | rule | 0.39 | - | 51.6 |
| KEEPS THE TARGET | rule | - | 0.36 | 76.2 |
| PATHS CROSS | rule | 0.22 | 0.14 | 21.2 |
| FIRE PLAN | rule | - | 0.33 | 56.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.14 | 34.0 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.19 | 17.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.17 | 23.8 |
| PURSUES BIG PREY | rule | 0.03 | 0.19 | 59.0 |
| WAR ENGINE JOBS | rule | 0.14 | 0.08 | 84.9 |
| CHAFF PASSED | rule | 0.19 | - | 5.4 |
| AFTERMATH BAND | gate | 0.11 | 0.06 | 2.2 |
| BEST PRIZE | rule | 0.06 | 0.11 | 67.0 |
| DEFENSIVE ARMY | rule | 0.17 | - | 30.9 |
| FIGHT ORDER BAND | gate | 0.14 | 0.03 | 1.8 |
| THROUGH LINE OF FIRE | rule | 0.14 | 0.03 | 8.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.11 | 65.1 |
| SUPPORT NARROWED | rule | 0.11 | 0.03 | 9.8 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 10.2 |
| BLOCKED WHEEL | rule | - | 0.11 | 32.6 |
| FACES THE THREAT | rule | 0.06 | 0.03 | 10.8 |
| MARCH ODDS | rule | - | 0.08 | 37.8 |
| SUPPORT REQUEST | gate | 0.03 | 0.06 | 77.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.06 | 26.3 |
| CATCH ODDS | rule | - | 0.06 | 44.5 |
| NO REASON | gate | - | 0.06 | 46.1 |
| REDIRECT WEIGHED | rule | 0.06 | - | 53.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 139.5 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 24.5 |
| FALLBACK BY WORTH | rule | - | 0.03 | 7.8 |
| LONG SHOT | rule | 0.03 | - | 12.9 |
| RULE SWITCHED OFF | gate | 0.03 | - | 19.5 |
| STANDS TO CAST | rule | 0.03 | - | 11.5 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 8.2 |

### Plans: sf-h2h-opp-4394159-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.7 | 12% | 345 | 250 | 73% |
| Mine | charge | 2.4 | 59% | 217 | 174 | 80% |
| Mine | close in | 3.3 | 21% | 185 | 128 | 69% |
| Mine | hold | 4.5 | 35% | 259 | 0 | 0% |
| Mine | join | 0.8 | 96% | 18 | 0 | 0% |
| Mine | shoot | 14.3 | 62% | 431 | 1106 | 256% |
| Mine | support | 3.5 | 91% | 50 | 0 | 0% |
| Opponent | advance | 13.4 | 21% | 436 | 426 | 98% |
| Opponent | charge | 5.2 | 57% | 550 | 520 | 95% |
| Opponent | close in | 6.9 | 27% | 523 | 158 | 30% |
| Opponent | hold | 5.0 | 45% | 358 | 0 | 0% |
| Opponent | join | 0.3 | 100% | 14 | 0 | 0% |
| Opponent | shoot | 5.3 | 55% | 219 | 370 | 169% |
| Opponent | support | 4.3 | 90% | 35 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-opp-4394159-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 278 | 0 | 0% | 29 |
| Opponent | 0.6 | 20 | 2 | 17% | 39% | 0% | 2.7 | 373 | 113 | 33% | 146 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 278 | 0 | 0% | 44 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| High Elf Realms | 0.6 | 4 | 0 | 25% | 25% | 0% | 2.0 | 360 | 76 | 25% | 135 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.6 | 4 | 0 | 25% | 25% | 0% | 2.0 | 551 | 103 | 25% | 283 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Tomb Kings of Khemri | 1.0 | 6 | 1 | 20% | 80% | 0% | 3.0 | 392 | 228 | 60% | 110 |
| Vampire Counts | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 211 | 0 | 0% | 61 |
| Warriors of Chaos | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 274 | 0 | 0% | 143 |
| Wood Elf Realms | 0.8 | 3 | 1 | 0% | 50% | 0% | 3.0 | 171 | 89 | 50% | 0 |

### Battle groups: sf-h2h-opp-4394159-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.2 | 27% | 51% | 13% | 14% | 39% | 15% | 11% | 35% | 0% |
| Mine | REDIRECT COUNTER | 1.2 | 23% | 50% | 10% | 100% | 22% | 0% | 11% | 44% | 22% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 14% | 71% | 20% | 14% | 29% | 4% | 14% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 3.1 | 27% | 73% | 7% | 0% | 4% | 0% | 18% | 79% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-opp-4394159-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 22 | 26 (22) | 16 | 10 | 57 | 23% | 2.2 | 39 (10) | 0 (6) | 34 (6) | 33 (17) | 0 (5) |
| Mine | Character | 132 | 31 (132) | 31 | 0 | 46 | 26% | 2.3 | 40 (36) | 34 (72) | 0 (8) | 35 (69) | 33 (47) |
| Mine | Clean-up | 18 | 51 (18) | 6 | 45 | 53 | 28% | 2.2 | 0 (2) | 56 (15) | 0 (1) | 56 (15) | 0 (3) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 50% | 1.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Mine | Fast Hammer | 30 | 44 (30) | 21 | 23 | 47 | 13% | 2.7 | 35 (10) | 45 (16) | 66 (4) | 54 (19) | 28 (11) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 67% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 71 | 39 (71) | 29 | 10 | 47 | 15% | 2.2 | 37 (16) | 45 (48) | 4 (7) | 38 (47) | 39 (24) |
| Mine | Holder | 11 | 44 (11) | 0 | 44 | 23 | 45% | 3.3 | 0 (3) | 50 (6) | 110 (2) | 72 (7) | 0 (4) |
| Mine | Shooter | 68 | 72 (68) | 22 | 50 | 39 | 3% | 1.7 | 86 (12) | 74 (41) | 52 (15) | 102 (40) | 33 (28) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | - | - | - | - | - |
| Mine | War machine | 109 | 41 (109) | 41 | 0 | 46 | 8% | 1.2 | 49 (23) | 45 (71) | 13 (15) | 58 (25) | 36 (84) |
| Mine | Wizard | 14 | 26 (14) | 26 | 0 | 65 | 7% | 2.7 | 55 (3) | 31 (7) | - | 126 (2) | 20 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 85 | 48 (85) | 13 | 35 | 45 | 32% | 2.6 | 40 (44) | 73 (11) | 50 (30) | 51 (67) | 36 (18) |
| Opponent | Character | 89 | 71 (89) | 71 | 0 | 25 | 18% | 2.2 | 71 (33) | 70 (46) | 61 (5) | 70 (54) | 70 (30) |
| Opponent | Clean-up | 24 | 62 (24) | 32 | 30 | 20 | 42% | 3.1 | 49 (7) | 40 (13) | 173 (4) | 63 (15) | 60 (9) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 0 | 33% | 5.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Fast | 2 | 328 (2) | 328 | 0 | 100 | 50% | 4.0 | - | 328 (2) | - | 328 (2) | - |
| Opponent | Fast Hammer | 38 | 46 (38) | 33 | 13 | 39 | 29% | 3.0 | 22 (17) | 90 (11) | 52 (10) | 47 (23) | 44 (15) |
| Opponent | Fragile | 10 | 6 (10) | 6 | 0 | 33 | 20% | 2.1 | - | 7 (8) | 0 (2) | 0 (6) | 11 (4) |
| Opponent | Hammer | 62 | 31 (62) | 14 | 17 | 43 | 29% | 2.4 | 5 (12) | 36 (42) | 23 (8) | 31 (39) | 30 (23) |
| Opponent | Holder | 37 | 115 (37) | 26 | 89 | 22 | 38% | 2.3 | 105 (9) | 143 (22) | 32 (4) | 171 (24) | 50 (11) |
| Opponent | Shooter | 29 | 70 (29) | 30 | 40 | 27 | 0% | 1.5 | 31 (6) | 87 (20) | 29 (3) | 92 (18) | 43 (11) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 66 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 15 | 59 (15) | 59 | 0 | 44 | 0% | 1.0 | 88 (4) | 70 (7) | 0 (4) | 49 (5) | 64 (10) |
| Opponent | Wizard | 27 | 21 (27) | 21 | 0 | 24 | 19% | 2.0 | 9 (10) | 52 (7) | 0 (5) | 47 (11) | 1 (11) |

### Charged fights: sf-h2h-opp-4394159-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 350 | 31 | 2.0 | 1.1 | 16 | 165 | -149 | 5 of 8 | 7 of 8 | +0 | -171 |
| Mine | Dwarfen Mountain Holds | 10 | 429 | 57 | 1.7 | 1.1 | 34 | 40 | -6 | 3 of 17 | 10 of 16 | -467 | +22 |
| Mine | Empire of Man | 12 | 382 | 46 | 1.2 | 1.1 | 40 | 80 | -40 | 6 of 14 | 10 of 14 | +0 | -47 |
| Mine | Grand Cathay | 3 | 270 | 417 | 3.7 | 1.1 | 114 | 0 | +114 | 2 of 11 | 8 of 11 | +55 | +120 |
| Mine | High Elf Realms | 2 | 62 | 466 | 2.5 | 1.4 | 186 | 0 | +186 | 0 of 5 | 4 of 5 | +0 | +233 |
| Mine | Lizardmen | 1 | 0 | 547 | 6.0 | 1.0 | 91 | 60 | +31 | 2 of 6 | 3 of 6 | - | +31 |
| Mine | Ogre Kingdoms | 2 | 28 | 294 | 6.0 | 1.4 | 49 | 68 | -19 | 4 of 12 | 9 of 12 | +39 | -60 |
| Mine | Skaven | 1 | 195 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 40 | 434 | 4.0 | 1.2 | 108 | 284 | -176 | 1 of 4 | 3 of 4 | +329 | -344 |
| **Mine** | all armies | 36 | 319 | 139 | 2.1 | 1.2 | 65 | 70 | -6 | 23 of 77 | 54 of 76 | +9 | -8 |
| Opponent | Empire of Man | 3 | 325 | 35 | 1.7 | 1.2 | 21 | 48 | -27 | 2 of 5 | 3 of 5 | +105 | -60 |
| Opponent | Grand Cathay | 1 | 395 | 230 | 1.0 | 1.0 | 230 | 0 | +230 | 0 of 1 | 1 of 1 | - | +230 |
| Opponent | High Elf Realms | 5 | 71 | 523 | 3.6 | 1.2 | 145 | 30 | +115 | 10 of 18 | 13 of 18 | +255 | +87 |
| Opponent | Kingdom of Bretonnia | 1 | 45 | 902 | 9.0 | 1.1 | 100 | 124 | -24 | 3 of 9 | 6 of 9 | -531 | +39 |
| Opponent | Ogre Kingdoms | 5 | 155 | 206 | 4.0 | 1.4 | 52 | 21 | +31 | 13 of 20 | 10 of 20 | +69 | +18 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 499 | 6.0 | 1.3 | 83 | 0 | +83 | 1 of 6 | 5 of 6 | +230 | +10 |
| Opponent | Skaven | 2 | 165 | 188 | 1.5 | 1.0 | 125 | 0 | +125 | 1 of 3 | 3 of 3 | - | +125 |
| Opponent | Tomb Kings of Khemri | 5 | 226 | 872 | 4.6 | 1.1 | 190 | 31 | +159 | 13 of 23 | 18 of 23 | +286 | +147 |
| Opponent | Vampire Counts | 6 | 50 | 444 | 5.7 | 1.2 | 78 | 16 | +62 | 19 of 34 | 22 of 33 | +131 | +47 |
| Opponent | Warriors of Chaos | 3 | 0 | 243 | 2.0 | 1.2 | 121 | 42 | +79 | 4 of 6 | 3 of 6 | +185 | +58 |
| Opponent | Wood Elf Realms | 4 | 274 | 756 | 5.0 | 1.1 | 151 | 12 | +139 | 5 of 20 | 14 of 20 | +454 | +104 |
| **Opponent** | all armies | 36 | 150 | 459 | 4.0 | 1.2 | 114 | 28 | +86 | 71 of 145 | 98 of 144 | +156 | +73 |

### Effective charges: sf-h2h-opp-4394159-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 2 (net -155) | 3 (net -337) | 0 | 2 (net +0) | 1 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 17 | 1 (net +0) | 0 | 3 (net +33) | 5 (net -79) | 0 | 8 (net +24) | 0 | 18% (3 of 17) |
| Mine | Empire of Man | 14 | 2 (net -140) | 0 | 0 | 5 (net +17) | 0 | 5 (net -58) | 2 | 0% (0 of 12) |
| Mine | Grand Cathay | 11 | 1 (net +365) | 0 | 1 (net +115) | 6 (net +113) | 2 (net +48) | 0 | 1 | 10% (1 of 10) |
| Mine | High Elf Realms | 5 | 0 | 0 | 0 | 1 (net +125) | 2 (net +171) | 2 (net +232) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 6 | 0 | 1 (net -175) | 2 (net +90) | 2 (net +28) | 0 | 1 (net +127) | 0 | 33% (2 of 6) |
| Mine | Ogre Kingdoms | 12 | 1 (net -495) | 0 | 1 (net +55) | 1 (net -228) | 1 (net +110) | 6 (net +70) | 2 | 10% (1 of 10) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net -1137) | 0 | 0 | 0 | 1 (net +45) | 2 (net +194) | 0 | 0% (0 of 4) |
| Opponent | Empire of Man | 5 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +105) | 1 (net -238) | 1 | 25% (1 of 4) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1 (net +230) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 18 | 3 (net +175) | 0 | 2 (net +108) | 6 (net +110) | 1 (net +91) | 2 (net +38) | 4 | 14% (2 of 14) |
| Opponent | Kingdom of Bretonnia | 9 | 1 (net -531) | 0 | 1 (net +250) | 5 (net +34) | 1 (net +0) | 0 | 1 | 12% (1 of 8) |
| Opponent | Ogre Kingdoms | 20 | 3 (net +0) | 0 | 2 (net +149) | 3 (net +28) | 0 | 5 (net +83) | 7 | 15% (2 of 13) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +234) | 2 (net +132) | 1 (net +0) | 2 | 0% (0 of 4) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +188) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 23 | 1 (net +746) | 0 | 1 (net +278) | 4 (net -43) | 3 (net +243) | 14 (net +148) | 0 | 4% (1 of 23) |
| Opponent | Vampire Counts | 34 | 6 (net -33) | 2 (net +0) | 9 (net +81) | 5 (net +63) | 3 (net +104) | 7 (net +97) | 2 | 28% (9 of 32) |
| Opponent | Warriors of Chaos | 6 | 0 | 0 | 2 (net -70) | 0 | 1 (net +185) | 2 (net +202) | 1 | 40% (2 of 5) |
| Opponent | Wood Elf Realms | 20 | 6 (net -10) | 1 (net +0) | 2 (net +286) | 3 (net +37) | 2 (net +479) | 3 (net +103) | 3 | 12% (2 of 17) |

### Charged fights, damage counted: sf-h2h-opp-4394159-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 176 | 297 | -258 | 139 | 319 | -180 | -102.3 |
| Mine | 50-54% | 1 | 175 | 195 | -175 | 65 | 175 | -110 | -62.9 |
| Mine | Effective (55-75%) | 9 | 203 | 251 | +15 | 112 | 77 | +34 | +16.9 |
| Mine | 76-89% | 23 | 237 | 213 | -30 | 84 | 102 | -18 | -7.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 190 | 168 | +50 | 80 | 20 | +60 | +31.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 446 | 89 | +99 | 99 | 0 | +99 | +22.1 |
| Mine | No odds | 6 | 207 | 218 | -7 | 65 | 67 | -2 | -1.0 |
| Mine | All fights | 77 | 226 | 199 | -6 | 90 | 79 | +11 | +4.9 |
| Opponent | Long shot (under 50%) | 20 | 209 | 189 | +24 | 101 | 95 | +6 | +3.0 |
| Opponent | 50-54% | 3 | 287 | 268 | +0 | 35 | 52 | -18 | -6.2 |
| Opponent | Effective (55-75%) | 21 | 301 | 166 | +116 | 149 | 35 | +114 | +37.9 |
| Opponent | 76-89% | 28 | 320 | 186 | +50 | 104 | 50 | +54 | +16.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 316 | 224 | +111 | 177 | 43 | +134 | +42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 562 | 128 | +189 | 194 | 21 | +173 | +30.7 |
| Opponent | No odds | 22 | 188 | 207 | +63 | 92 | 40 | +52 | +27.7 |
| Opponent | All fights | 145 | 303 | 192 | +86 | 134 | 48 | +86 | +28.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-opp-4394159-p2 | move | 447 | 100 (22%) | 75 (17%) | 48 (11%) | 299 (67%) |
| sf-h2h-opp-4394159-p2 | objective | 368 | 60 (16%) | 36 (10%) | 44 (12%) | 264 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0334, L0524, L0527, L0626, L0724, L0925, L0934, L2226 |
| Clockwork Compass | Mine | L1215, L1222 |
| Clockwork Compass | Opponent | L0312 |
| Elixir of Power | Mine | L1118 |
| Elixir of Power | Opponent | L1819 |
| Fistful of Laurels | Mine | L1819, L1832 |
| Fistful of Laurels | Opponent | L0518, L0618, L0718, L0818, L1118 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Opponent | L0524, L0527, L0724, L0925 |
| Opal Amulet | Opponent | L0314 |
| Periapt of Soul Exchange | Mine | L2122 |
| Periapt of Soul Exchange | Opponent | L0520, L0720 |
| Ring of Doom | Mine | L1118, L1215, L1222, L1533, L1535 |
| Ring of Doom | Opponent | L0312, L0531, L0715, L0915, L1215, L1533 |
| Ring of Jet | Mine | L1118, L1215, L1222 |
| Ring of Jet | Opponent | L0312 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2122 |
| Twice-Blessed Armour | Mine | L0715, L0718, L0720, L0724 |
| Twice-Blessed Armour | Opponent | L0407 |
| Witch Hunter's Ward | Mine | L0715, L0718, L0720, L0724, L0809, L0818, L0823 |
| Witch Hunter's Ward | Opponent | L0407 |

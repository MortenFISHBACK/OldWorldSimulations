import pickle,re,collections,statistics as st
G=pickle.load(open('sp.pkl','rb'))
C=collections.defaultdict(collections.Counter)
wre=re.compile(r'(\d+) wound\(s\)')
ex=[]
for g in G:
    U={u['id']:u for u in g['units']}
    for side in ('Mine','Opponent'):
        enemy='Opponent' if side=='Mine' else 'Mine'
        free=[u for u in g['units'] if u['side']==enemy and not u['joinedTo']]
        ham=[u for u in free if 'Hammer' in u['kind']] or free
        heavy=max(ham,key=lambda u:u['points'])
        for r in g['acts']:
            if r['side']!=side or r['phase']!='Shooting' or r['type'] not in ('WarMachineShot','Shooting'): continue
            s=r.get('summary') or ''
            if 'cannot shoot' in s: continue
            t=U.get(r['target_id']); a=U.get(r['actor_id'])
            if not t or not a: continue
            cls='heavy' if t is heavy else ('cheap' if t['points']<150 else 'mid')
            wk='wm' if a['tt'].startswith('War Machine') else 'sh'
            key=(('plan' if side==g['plan'] else 'main'),wk,cls)
            m=wre.search(s); w=int(m[1]) if m else 0
            for k in (key,('both',wk,cls)):
                C[k]['n']+=1; C[k]['wounds']+=w; C[k]['kills']+='destroyed' in s; C[k]['pts']+=t['points']*('destroyed' in s)
                C[k]['tw']+= (t['w'] or 1)*(t['mc'] or 1)
for k in sorted(C):
    c=C[k]; print(k,'shots',c['n'],'wounds/shot %.2f'%(c['wounds']/c['n']),'kills per 100 shots %.1f'%(100*c['kills']/c['n']),'points killed per shot %.1f'%(c['pts']/c['n']),'target wounds at start %.1f'%(c['tw']/c['n']))

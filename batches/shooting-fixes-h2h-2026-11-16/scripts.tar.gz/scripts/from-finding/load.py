import json,glob,os,re,collections,csv,pickle
R='/root/an'
def games():
    for part in sorted(glob.glob(R+'/[mo]*-*')):
        plan='Mine' if os.path.basename(part).startswith('mine') else 'Opponent'
        U=collections.defaultdict(list)
        for l in open(part+'/units.jsonl'):
            d=json.loads(l); U[d['game']].append(d)
        bykey=collections.defaultdict(list)
        for g,us in U.items(): bykey[tuple((u['side'],u['unit']) for u in us)].append(g)
        gcsv={r['pair']:r for r in csv.DictReader(open(part+'/games.csv'))}
        for lf in sorted(glob.glob(part+'/game-*.log.jsonl')):
            pair=re.search(r'game-(L\d+)-',lf).group(1)
            rows=[json.loads(l) for l in open(lf)]
            board=next(r for r in rows if r.get('kind')=='board')
            k=tuple((u['s'],u['lk']['cn']) for u in board['units'])
            if not bykey.get(k): print('nomatch',lf); continue
            us=U[bykey[k].pop(0)]
            for b,u in zip(board['units'],us): u['id']=b['id']; u['name']=b['n']; u['w']=b['lk'].get('w'); u['mc']=b['lk'].get('mc'); u['tt']=b['lk']['tt']; u['mt']=b['lk'].get('mt')
            g=gcsv.get(pair)
            if not g or g['ended']!='yes': continue
            m,o=map(int,g['vp_mine_opponent'].split('-'))
            yield dict(part=os.path.basename(part),pair=pair,plan=plan,units=us,acts=[r for r in rows if r.get('kind')=='action'],vp={'Mine':m,'Opponent':o},first=g['first_player'],csv=g)
if __name__=='__main__':
    G=list(games()); print(len(G)); pickle.dump(G,open('sp.pkl','wb'))

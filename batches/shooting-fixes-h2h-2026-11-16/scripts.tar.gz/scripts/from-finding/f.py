import pickle,collections,importlib.util,statistics as st,math,re
spec=importlib.util.spec_from_file_location('cb','/home/user/WarhammerOldWorldSimulator/scripts/compare-batches.py'); cb=importlib.util.module_from_spec(spec)
import sys; sys.argv=['x']
try: spec.loader.exec_module(cb)
except SystemExit: pass
G=pickle.load(open('sp.pkl','rb'))
C=collections.defaultdict(lambda: collections.defaultdict(lambda:[0,0]))
odds=re.compile(r'(\d+)% to win')
for g in G:
    units={u['name']:{'side':u['side'],'points':u['points'],'gone':u['gone'],'round':u['goneRound'],'cause':u['goneCause'],'vp':u['vpGivenUp'],'army':u['army']} for u in g['units']}
    U={u['name']:u for u in g['units']}
    fights=cb._game_fights(g['acts'],units)
    # army-level: did the side shoot / have shoot rows this turn before
    for f in fights:
        if 'first_round' not in f: continue
        key='plan' if f['side']==g['plan'] else 'main'
        ch=[U[c] for c in f['chargers']]; t=U[f['target']]
        cp=sum(c['points'] for c in ch)
        cats={'all':1,
              'side '+f['side']:1,
              'chargers '+('1' if len(ch)==1 else '2+'):1,
              'round '+('1-2' if f['turn']<=2 else '3-4' if f['turn']<=4 else '5-6'):1,
              'charger is shooter/wizard' if any('Shooter' in (c['purposes'] or '') or 'Wizard' in (c['purposes'] or '') for c in ch) else 'charger no missiles':1,
              'target '+('<150' if t['points']<150 else '150-299' if t['points']<300 else '300+'):1,
              'charger pts '+('<150' if cp<150 else '150-299' if cp<300 else '300+'):1,
              'first player' if g['first']==f['side'] else 'second player':1}
        for c in cats:
            C[c][key][0]+=1; C[c][key][1]+=bool(f['first_round'])
for c in sorted(C):
    p,m=C[c]['plan'],C[c]['main']
    if p[0] and m[0]:
        se=100*math.sqrt(p[1]/p[0]*(1-p[1]/p[0])/p[0]+m[1]/m[0]*(1-m[1]/m[0])/m[0])
        print(f"{c:32s} plan {100*p[1]/p[0]:.0f}% of {p[0]:4d} | main {100*m[1]/m[0]:.0f}% of {m[0]:4d} | diff {100*p[1]/p[0]-100*m[1]/m[0]:+.0f} ±{1.96*se:.0f}")
print()
D=collections.Counter()
for g in G:
    units={u['name']:{'side':u['side'],'points':u['points'],'gone':u['gone'],'round':u['goneRound'],'cause':u['goneCause'],'vp':u['vpGivenUp'],'army':u['army']} for u in g['units']}
    U={u['name']:u for u in g['units']}
    for f in cb._game_fights(g['acts'],units):
        key='plan' if f['side']==g['plan'] else 'main'
        ch=[U[c] for c in f['chargers']]
        D[key,'fights']+=1
        mis=[c for c in ch if 'Shooter' in (c['purposes'] or '') or 'Wizard' in (c['purposes'] or '')]
        D[key,'fights with a missile unit charging']+=bool(mis)
        D[key,'joint']+=len(ch)>1; D[key,'joint with missile unit']+= len(ch)>1 and bool(mis)
        D[key,'charger points']+=sum(c['points'] for c in ch)
    for side in ('Mine','Opponent'):
        key='plan' if side==g['plan'] else 'main'
        for u in g['units']:
            if u['side']==side and ('Shooter' in (u['purposes'] or '')) and not u['tt'].startswith('War Machine'):
                D[key,'shooter units']+=1; D[key,'shooter units that fought']+=bool(u['fought']); D[key,'shooter charges declared']+=u['chargesDeclared']
for k in sorted(D): print(k,D[k])

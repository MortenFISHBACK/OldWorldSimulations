import pickle,re,collections,statistics as st
G=pickle.load(open('sp.pkl','rb'))
add=re.compile(r'\| \w+: \+([\d.]+) VP v')
C=collections.defaultdict(collections.Counter); wre=re.compile(r'(\d+) wound\(s\)')
opt=re.compile(r'\d\) #(\d+) (.*?) ~([\d.]+) VP(?: \(threat ~([\d.]+)\))?')
for g in G:
    side=g['plan']; enemy='Opponent' if side=='Mine' else 'Mine'
    U={u['id']:u for u in g['units']}
    free=[u for u in g['units'] if u['side']==enemy and not u['joinedTo']]
    ham=[u for u in free if 'Hammer' in u['kind']] or free
    heavy=max(ham,key=lambda u:u['points'])
    pend={}
    for r in g['acts']:
        if r['side']!=side or r['phase']!='Shooting': continue
        s=r.get('summary') or ''
        if r['type']=='OpponentRule' and s.startswith('FIRE PLAN:'):
            m=add.search(s)
            if m: pend[r['actor_id']]=[float(m[1]),None]
        if r['type']=='OpponentRule' and s.startswith('SHOT OPTIONS') and r['actor_id'] in pend:
            for m in opt.finditer(s):
                if int(m[1])==r['target_id']: pend[r['actor_id']][1]=float(m[4] or 0)
        if r['type'] in ('WarMachineShot','Shooting') and r['actor_id'] in pend and 'cannot shoot' not in s:
            a=U.get(r['actor_id']); t=U.get(r['target_id']); claim,thr=pend.pop(r['actor_id'])
            if not a or not t: continue
            cls='heavy' if t is heavy else ('cheap' if t['points']<150 else 'mid')
            wk='wm' if a['tt'].startswith('War Machine') else 'sh'
            for k in ((wk,cls),(wk,'all')):
                c=C[k]; c['n']+=1; c['claim']+=claim; c['pts']+=t['points']*('destroyed' in s); c['tp']+=t['points']; c['earn']+=t['vpEarned']
                if thr is not None: c['thr']+=thr; c['thrn']+=1
for k in sorted(C):
    c=C[k]; n=c['n']; print(k,'shots',n,'plan says the shot adds %.0f VP; points really destroyed by the shot %.1f; target points %.0f; threat figure %.0f; target really took %.0f'%(c['claim']/n,c['pts']/n,c['tp']/n,c['thr']/max(1,c['thrn']),c['earn']/n))

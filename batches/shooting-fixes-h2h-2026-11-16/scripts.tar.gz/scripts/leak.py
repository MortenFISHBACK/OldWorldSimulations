import json,glob,os,collections
T=('FIRE PLAN','EVERY WOUND COUNTS','HONEST THREAT','ONE YARDSTICK','SHOOTERS TO THE PRIMARY','KEEPS THE TARGET','FIRE IN ORDER','STAY WORTH','BEST MOVE FOR SHOOTERS','MISSILES IN THE FIRE PLAN','SHOOTERS ARE THREATS','THREAT AT FULL SIZE')
c=collections.Counter(); n=collections.Counter()
for part in sorted(glob.glob(os.path.expanduser('~/an/*-*'))):
  plan='Mine' if os.path.basename(part).startswith('mine') else 'Opponent'
  for f in glob.glob(part+'/game-*.log.jsonl'):
    n[plan]+=1
    for l in open(f):
      if '"OpponentRule"' not in l: continue
      d=json.loads(l); s=d['summary'].split(':')[0]
      if s in T: c[('plan' if d['side']==plan else 'main',s)]+=1
for k,v in sorted(c.items()): print(k,v)
print(n)

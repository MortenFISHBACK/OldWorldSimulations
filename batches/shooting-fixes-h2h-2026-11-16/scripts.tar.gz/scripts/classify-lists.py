import json,glob,collections,sys
R=collections.defaultdict(dict)
for f in glob.glob('/mnt/project-files/shooting-plan-h2h-2026-11-15/*/units.jsonl'):
    for l in open(f):
        d=json.loads(l); key=(d['game'],d['side'])
        R[d['list'].split(': ',1)[1]].setdefault(key,[]).append(d)
tt=collections.Counter()
out=[]
for lst,games in sorted(R.items()):
    us=max(games.values(),key=len)
    tot=sum(u['points'] for u in us)
    wm=[u for u in us if 'War Machine' in u['troopType']]
    sh=[u for u in us if ('Shooter' in (u['purposes'] or '') and not ('Wizard' in (u['purposes'] or '') and u['isCharacter'])) or 'War Machine' in u['troopType']]
    shp=sum(u['points'] for u in sh)
    for u in us: tt[u['troopType']]+=1
    out.append((lst,tot,len(wm),round(100*shp/tot)))
for o in out: print(*o,sep='\t')
print(len(out)); print(tt.most_common())

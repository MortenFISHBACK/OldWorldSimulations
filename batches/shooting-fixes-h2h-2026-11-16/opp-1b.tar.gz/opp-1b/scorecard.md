# Doctrine scorecard: sf-h2h-opp-4394159-p1b

### Scorecard: sf-h2h-opp-4394159-p1b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0708 | 6 | 1 | Mine | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 497 |
| L0708 | 6 | 1 | Opponent | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 605 |
| L0712 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 609 |
| L0712 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L0716 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0716 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 200 |
| L0725 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 513 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0730 | 4 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 375 |
| L0730 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0731 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0731 | 5 | 1 | Opponent | no | - | 2 | 1 | 1 | 2 | 0 | 0 | 340 |
| L0810 | 6 | 1 | Mine | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 679 |
| L0810 | 6 | 1 | Opponent | no | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0832 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 560 |
| L0832 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0833 | 5 | 1 | Mine | no | - | 5 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0833 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1318 | 4 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1318 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 2 | 0 | 0 | 305 |
| L1516 | 4 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1822 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 1 | 0 | 0 | 90 |
| L1822 | 4 | 1 | Opponent | no | 0 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 7 | 5 | 0 | 0 | 0 | 0 | 0 | 170 |
| L2224 | 4 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 165 |
| L2224 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Mine | - | - | 1 | 6 | 4 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 6% | 1.1 | 2.6 | 2.4 | 0.9 | 0.1 | 0.0 | 0.0 | 352.2 |
| **Average** | | | Opponent | 19% | 3.2 | 2.1 | 2.9 | 1.7 | 0.4 | 0.0 | 0.0 | 137.8 |

### KPIs: sf-h2h-opp-4394159-p1b

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 18 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (36 of 88) | 5% (4 of 82) | 24% (40 of 170) |
| Winner chose to follow up after the loser gave ground |  | 100% (30 of 30); on the table 100% | 93% (25 of 27); on the table 96% | 96% (55 of 57); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 100% (12 of 12); on the table 100% | 100% (19 of 19); on the table 100% |
| Winner chose to pursue after the loser fled |  | 71% (10 of 14); on the table 86% | 46% (6 of 13); on the table 62% | 59% (16 of 27); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 92% (47 of 51); on the table 96% | 83% (43 of 52); on the table 88% | 87% (90 of 103); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 36% (13 of 36) | 26% (22 of 84) | 29% (35 of 120) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (13 of 23) | 41% (22 of 54) | 45% (35 of 77) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 36% (13 of 36) | 25% (15 of 60) | 29% (28 of 96) |
|     round 1 |  | 50% (3 of 6) | 10% (1 of 10) | 25% (4 of 16) |
|     rounds 2+ |  | 33% (10 of 30) | 28% (14 of 50) | 30% (24 of 80) |
|   other wizards | 50%+ | - | 29% (7 of 24) | 29% (7 of 24) |
|     round 1 |  | - | 25% (1 of 4) | 25% (1 of 4) |
|     rounds 2+ |  | - | 30% (6 of 20) | 30% (6 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 55% (11 of 20) | 55% (11 of 20) |
| Points that never fought | lower | 39% (13842 of 35438) | 39% (13945 of 35995) | 39% (27787 of 71433) |
|   infantry points that never fought | lower | 52% (2773 of 5365) | 59% (3567 of 6081) | 55% (6340 of 11446) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (100 of 150) | 53% (77 of 145) | 60% (177 of 295) |
| Bound items with a magic missile used (at least once a game) |  | 60% (3 of 5); 0.4 uses a game | 91% (10 of 11); 1.6 uses a game | 81% (13 of 16); 1.0 uses a game |
| Bound items with another spell used |  | 62% (5 of 8); 0.9 uses a game | 0% (0 of 1); 0.0 uses a game | 56% (5 of 9); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 36% (4 of 11); 0.2 uses a game | 75% (6 of 8); 0.3 uses a game | 53% (10 of 19); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (18967 of 30565) | 47% (15062 of 32122) | 54% (34029 of 62687) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (4%) | 0.9 (27%) | 1.0 (21%) |
| MARCHED: its unit marched | 0.1 (4%) | 0.7 (19%) | 0.7 (15%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (3%) | 0.1 (2%) |
| IN COMBAT: engaged in combat | 0.2 (17%) | 0.9 (27%) | 1.2 (25%) |
| REAR RANK: in a rear rank | 0.3 (26%) | 0.0 (0%) | 0.3 (7%) |
| FLEEING: fleeing | 0.2 (17%) | 0.0 (0%) | 0.2 (5%) |
| GONE: slain | 0.1 (4%) | 0.6 (18%) | 0.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (17%) | 0.1 (3%) | 0.3 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (9%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.2 | 0.7 | 1.9 | 1.9 | 0.3 | 1.6 |
| not cast | 4.2 | 2.5 | 4.1 | 4.7 | 1.3 | 15.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (42%) | 0.5 (12%) | 1.0 (21%) | 0.1 (4%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.1 (2%) | 0.7 (18%) | 1.2 (25%) | 0.3 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.4 (18%) | 0.6 (15%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.1 (4%) | 0.1 (1%) | 0.2 (5%) | 0.0 (0%) | 0.7 (5%) |
| GONE: slain | 0.9 (23%) | 0.2 (7%) | 0.3 (7%) | 0.7 (14%) | 0.5 (38%) | 1.0 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.3 (13%) | 0.3 (8%) | 0.3 (7%) | 0.0 (0%) | 0.9 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (9%) | 0.0 (0%) | 0.0 (0%) | 0.1 (8%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (53%) | 0.1 (2%) | 1.4 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.1 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 53% (8 of 15) | 50% (7 of 14) | 52% (15 of 29) |
| the unit moved after it | 12% (1 of 8) | 57% (4 of 7) | 33% (5 of 15) |
| it charged on its next turn | 0% (0 of 8) | 29% (2 of 7) | 13% (2 of 15) |
| the enemy charged it first | 0% (0 of 8) | 14% (1 of 7) | 7% (1 of 15) |
| it fought by the end of its next turn | 12% (1 of 8) | 14% (1 of 7) | 13% (2 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (2 of 8) | 0% (0 of 7) | 13% (2 of 15) |
| none of these (no charge, no fight, no charge escaped) | 62% (5 of 8) | 57% (4 of 7) | 60% (9 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (347 of 579) | 60% (160 of 265) | 60% (507 of 844) |
|   cavalry | 71% (56 of 79) | 70% (42 of 60) | 71% (98 of 139) |
|   character | 21% (14 of 66) | 20% (9 of 44) | 21% (23 of 110) |
|   chariot | 59% (40 of 68) | 69% (11 of 16) | 61% (51 of 84) |
|   infantry | 50% (94 of 187) | 65% (54 of 83) | 55% (148 of 270) |
|   monster | 81% (13 of 16) | 62% (5 of 8) | 75% (18 of 24) |
|   war machine | 80% (130 of 163) | 72% (39 of 54) | 78% (169 of 217) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (21%) | 1.6 (27%) | 4.3 (23%) |
| CHARGED: it charged | 1.6 (12%) | 1.2 (20%) | 2.8 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (0%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (7%) | 0.4 (8%) | 1.4 (7%) |
| MOVED: a war machine that moved | 0.1 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 3.3 (25%) | 1.1 (19%) | 4.4 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (10%) | 0.3 (5%) | 1.6 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (14%) | 0.7 (12%) | 2.5 (13%) |
| SHELTERED: the target was sheltered | 0.4 (3%) | 0.1 (2%) | 0.6 (3%) |
| OTHER BAR | 0.7 (6%) | 0.3 (6%) | 1.1 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.2 | 2.7 | 80% | 6.5 pts | 67 pts |
| character | 1.5 | 0.3 | 81% | 4.7 pts | 7 pts |
| chariot | 2.8 | 0.9 | 78% | 7.6 pts | 22 pts |
| infantry | 10.4 | 3.3 | 79% | 6.9 pts | 72 pts |
| monster | 1.0 | 0.4 | 72% | 10.0 pts | 10 pts |
| war machine | 9.7 | 9.0 | 54% | 29.9 pts | 290 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 5.3 | 4.5 |
| Charges that made contact a game | 2.9 | 3.6 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.75 declared, 0.75 contact (4 units) | 1.29 declared, 1.29 contact (7 units) | 1.09 declared, 1.09 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.00 contact (4 units) | 2.00 declared, 0.75 contact (4 units) | 1.62 declared, 0.88 contact (8 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.32 contact (139 units) | 0.65 declared, 0.44 contact (121 units) | 0.52 declared, 0.38 contact (260 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (33 of 49) | 47% (8 of 17) | 75% (3 of 4) | 63% (44 of 70) |
| Character in a unit | 100% (14 of 14) | 57% (4 of 7) | 100% (2 of 2) | 87% (20 of 23) |
| Character on its own | 76% (19 of 25) | 25% (5 of 20) | 29% (9 of 31) | 43% (33 of 76) |
| Chariot | 62% (5 of 8) | 83% (5 of 6) | - | 71% (10 of 14) |
| Infantry | 62% (15 of 24) | 30% (3 of 10) | 67% (4 of 6) | 55% (22 of 40) |
| Monster | 57% (8 of 14) | 100% (5 of 5) | - | 68% (13 of 19) |
| Monstrous | 75% (3 of 4) | 50% (3 of 6) | - | 60% (6 of 10) |
| War Machines | 67% (29 of 43) | - | - | 67% (29 of 43) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 12 | 92% (23 of 25); on the table 96% | 61% (11 of 18) | 50% | 75% (87 of 116) | 0.0 uses a game | 50% (3 of 6); 0.9 uses a game | 42% (5 of 12); 0.4 uses a game |
| Grand Cathay | 2 | 79% (11 of 14); on the table 79% | 19% (8 of 42) | 28% | 26% (5 of 19) | 80% (4 of 5); 4.5 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 2 | 100% (12 of 12); on the table 100% | 33% (2 of 6) | 18% | 20% (3 of 15) | 67% (2 of 3); 3.0 uses a game | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 67% (4 of 6); on the table 100% | - | 26% | 25% (3 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Ogre Kingdoms | 3 | 83% (5 of 6); on the table 100% | 0% (0 of 12) | 25% | 57% (12 of 21) | 67% (2 of 3); 1.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 4 | 81% (13 of 16); on the table 88% | - | 33% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 100% (10 of 10); on the table 100% | 22% (4 of 18) | 41% | 53% (10 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 90% (9 of 10); on the table 90% | 56% (10 of 18) | 34% | 65% (33 of 51) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 2 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 67% | 64% (14 of 22) | 100% (3 of 3); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-opp-4394159-p1b, 18 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (16) | 32% (11) | 39% (27) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.56 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.00 | 0.11 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.44 | 1.06 | 3.50 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 0.50 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.28 | 5.17 | 10.44 |

### Quality by phase: sf-h2h-opp-4394159-p1b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.5 |
| Strategy | Charge objectives carried out (made contact) | 61% (36 of 59) | 48% (40 of 84) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (96 of 208) | 47% (47 of 99) |
| Strategy | Close-in objectives charged next turn | 15% (15 of 99) | 13% (12 of 95) |
| Strategy | Support requests answered (helper made contact too) | 33% (2 of 6) | 30% (3 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 33% (4 of 12) | 25% (6 of 24) |
| Strategy | Lone characters that fought | 65% (37 of 57) | 83% (38 of 46) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 352.2 | 137.8 |
| Movement | Fights charged into per game | 2.7 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 44, net +54 | 9 of 50, net +137 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 44, net +58 | 7 of 50, net +148 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 44, net +73 | 5 of 50, net +29 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 44, net +180 | 14 of 50, net +145 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.6 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (108 of 226) | 37% (49 of 131) |
| Shooting | Points destroyed by shooting units | 48.3 | 63.1 |
| Shooting | War machine shots | 7.2 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (62 of 130) | 30% (13 of 44) |
| Shooting | Points destroyed by war machines | 144.7 | 54.9 |
| Magic | Magic missiles cast | 0.7 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (4 of 12) | 31% (5 of 16) |
| Magic | Wounds caused by magic missiles | 1.4 | 1.8 |
| Magic | Wounds caused by other spells | 1.7 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 24.7 | 37.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.1 / 0.4 / 0.0 | 2.0 / 0.3 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 281.5 | 370.9 |
| Combat | Points run down | 78.8 | 119.3 |
| Combat | Net points per charged fight, damage counted | +100 | +111 |
| Combat | Net per 100 charger points, damage counted | +36.0 | +42.8 |
| Combat | First round won (charged fights) | 71% | 74% |
| Combat | Net points per charged fight | +97 | +112 |
| Combat | Net points per supported fight / lone fight | +148 / +94 | +231 / +98 |
| Combat | Charged fights on a top-3 enemy unit | 16 of 49 | 27 of 58 |
| Game | Points lost | 890.4 | 644.0 |
| Game | VP from objectives | 556.1 | 687.8 |
| Game | Lone holders (player turns) | 1.1 | 3.2 |

- Mine won / drew / lost: 4 / 6 / 8 of 18 ended games (of 18); mean margin (Mine - Opponent) -405 VP
- The side that went first won 3 of 12 games with a winner
- Points traded per game (both sides' losses): 1534
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-opp-4394159-p1b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 56.4 | 0.2 | +0.0 | 0.0 | 7.2 |
| BACKUP TARGETS | 0.7 | +6.3 | 0.0 | 26.0 | 1.3 | +16.5 | 0.0 | 48.8 |
| BEST FACING | 0.9 | +22.1 | 0.0 | 39.5 | 0.5 | +18.8 | 0.0 | 30.7 |
| BEST FIRST | 4.9 | +258.4 | 128.5 | 159.9 | 3.4 | +129.3 | 49.3 | 37.7 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.8 | +75.8 | 0.0 | 10.3 |
| BEST OVERALL | 0.6 | +30.0 | 0.0 | 41.7 | 0.5 | +24.7 | 0.0 | 10.8 |
| BEST PREY | 0.9 | +48.8 | 0.0 | 0.0 | 0.5 | +20.6 | 22.2 | 14.4 |
| BEST PRIZE | 0.1 | -17.6 | 0.0 | 16.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.1 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.5 | 0.0 |
| BLOCKED WHEEL | 0.8 | +2.5 | 0.0 | 6.1 | 0.7 | -0.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 35.2 | 6.9 | - | - | - | - |
| CANNON PLANNED TARGET | 5.8 | +232.0 | 362.4 | 118.9 | - | - | - | - |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | +0.0 | 23.7 | 6.4 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 10.5 | 0.1 | +0.0 | 6.1 | 0.0 |
| CAST JOB | 0.5 | +29.6 | 0.0 | 32.2 | 0.5 | +5.1 | 27.9 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 22.5 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.1 | +0.0 | 198.5 | 150.6 | 3.1 | +0.0 | 332.4 | 97.4 |
| CHARGE NOW WEIGHED | 0.5 | -55.1 | 13.6 | 65.5 | 0.3 | -23.2 | 13.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 24.8 | 6.4 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 41.9 | 29.4 | 0.4 | +0.0 | 49.6 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 10.8 |
| CONVEYANCE SEARCH | 0.8 | +102.3 | 6.1 | 0.0 | 0.6 | +83.7 | 38.6 | 45.0 |
| COUNTER-CHARGE COVER | 9.9 | +711.2 | 0.0 | 292.9 | 7.2 | +857.9 | 0.0 | 97.0 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 4.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +22.2 | 30.2 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.4 | +9.2 | 52.4 | 6.4 | 0.5 | +9.6 | 74.5 | 5.4 |
| EVERY WOUND COUNTS | - | - | - | - | 6.2 | +0.0 | 253.2 | 115.8 |
| FACE THE CAST | - | - | - | - | 0.2 | +0.5 | 0.0 | 0.0 |
| FACES THE THREAT | 2.4 | +203.7 | 0.0 | 118.3 | 1.1 | +84.8 | 0.0 | 43.7 |
| FALLBACK BY WORTH | 4.6 | +33.2 | 0.0 | 72.2 | 4.4 | +111.6 | 0.0 | 74.6 |
| FIGHT LIFT | - | - | - | - | 0.1 | +5.6 | 0.0 | 19.5 |
| FIRE AND FLEE | 0.1 | +5.0 | 2.5 | 0.0 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.6 | +0.0 | 21.1 | 0.0 |
| FIRE PLAN | - | - | - | - | 8.6 | -6.2 | 354.7 | 145.9 |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 209.2 | 4.7 | +0.0 | 0.0 | 89.9 |
| FOLLOW UP WEIGHED | 1.2 | +135.4 | 0.0 | 42.5 | 1.3 | +117.4 | 0.0 | 30.4 |
| FRIENDS SHOTS CHECKED | 0.5 | +35.7 | 0.0 | 0.0 | 0.3 | +31.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.8 | 10.8 | 10.5 | 0.2 | -7.0 | 31.2 | 0.0 |
| GROUND FLIERS | 0.1 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 5.4 | 3.1 | - | - | - | - |
| HELPER UNSEEN | 0.2 | +0.0 | 13.6 | 23.9 | 0.4 | +0.0 | 39.4 | 9.9 |
| HILL BY ITS CHANCE | 0.4 | -26.3 | 0.0 | 0.0 | 0.2 | -4.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 6.2 | +1073.1 | 253.2 | 115.8 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +8.2 | 5.6 | 0.0 | 0.1 | +0.1 | 0.0 | 5.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 22.2 | 5.0 |
| HUNT IN PAIRS | 0.4 | +21.1 | 0.0 | 21.7 | 0.3 | +4.2 | 0.0 | 20.5 |
| HUNT KEPT | 0.1 | +8.0 | 5.6 | 6.4 | - | - | - | - |
| HUNT RESULT | 0.1 | +22.3 | 0.0 | 6.4 | 0.2 | +37.8 | 29.2 | 10.4 |
| HUNT THE GUNS | 0.1 | +30.6 | 5.6 | 0.0 | 0.2 | +71.5 | 13.9 | 10.4 |
| INVITES THE FIGHT | 1.6 | +24.1 | 22.3 | 47.6 | 1.8 | +34.8 | 22.1 | 65.3 |
| JOINT CHARGE PLAN | 0.4 | +9.9 | 0.0 | 10.5 | 0.2 | +3.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.6 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.1 | +61.7 | 175.6 | 55.6 | 1.4 | +41.7 | 128.2 | 4.4 |
| KEEPS THE TARGET | - | - | - | - | 1.3 | -48.7 | 114.3 | 19.2 |
| KILLS COUNT | 1.4 | +48.2 | 92.2 | 81.9 | 2.1 | +120.3 | 160.6 | 67.4 |
| KILLS COUNT NEXT TURN | 6.0 | +195.3 | 142.1 | 102.0 | 6.0 | +181.0 | 218.3 | 96.1 |
| LONE CHARACTER SAFE SPOT | 0.7 | +18.0 | 25.4 | 2.5 | 0.4 | +8.3 | 6.0 | 13.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.4 | +0.0 | 36.5 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +25.4 | 0.0 | 0.0 | 0.3 | +19.6 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -1.8 | 50.5 | 3.1 | 0.2 | -0.6 | 34.6 | 5.0 |
| LOST CHARGE | 3.6 | -68.1 | 152.8 | 106.4 | 2.4 | -65.5 | 47.7 | 132.3 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.7 | 0.0 | 2.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.4 | +20.6 | 0.0 | 0.0 | 0.7 | +55.2 | 2.0 | 0.0 |
| MANOEUVRE | 0.3 | +10.2 | 0.0 | 0.0 | 0.2 | +2.6 | 0.0 | 4.3 |
| MARCH CHECK | 0.1 | +0.0 | 0.0 | 16.5 | 0.2 | +3.2 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +35.3 | 0.0 | 0.0 | 0.2 | +18.7 | 2.0 | 0.0 |
| MARCH OVER CASTS | 0.2 | +21.0 | 0.0 | 0.0 | 0.2 | +4.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.6 | +180.1 | 0.0 | 88.1 | 6.1 | +255.5 | 0.0 | 80.8 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.6 | +6.0 | 36.9 | 0.0 |
| MISSILES IN THE MOVE | 1.4 | +54.6 | 0.0 | 37.6 | 3.5 | +61.6 | 0.0 | 107.0 |
| MISSILES NEXT TURN | 1.6 | +34.7 | 0.0 | 65.2 | 3.9 | +42.3 | 0.0 | 107.0 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +12.3 | 0.0 | 11.1 | 0.3 | +11.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 1.0 | +33.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -23.0 | 16.0 | 0.0 | 0.2 | -27.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.9 | +211.5 | 103.5 | 48.3 | 3.9 | +334.4 | 137.8 | 76.0 |
| MOVES UNITS SPELL | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +20.3 | 11.2 | 0.0 |
| NOT NEEDED | 0.2 | -10.4 | 32.1 | 0.0 | 0.5 | -27.2 | 79.9 | 4.7 |
| NOT TURNED | 5.3 | +50.3 | 0.0 | 116.7 | 5.2 | +46.0 | 0.0 | 92.2 |
| NOT WORTH A CAST | 1.2 | -0.6 | 0.0 | 46.9 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -734.5 | 0.0 | 277.6 | 13.0 | -746.7 | 10.3 | 148.8 |
| ONE YARDSTICK | - | - | - | - | 10.6 | -446.8 | 243.7 | 198.5 |
| OPENS A LANE | 0.2 | +0.3 | 7.0 | 42.2 | 0.1 | +0.2 | 4.3 | 0.0 |
| OPENS UP | 0.1 | +14.4 | 9.9 | 0.0 | 0.4 | +44.3 | 19.7 | 0.0 |
| OVERRUNS AWAY | 0.2 | +2.6 | 19.3 | 40.0 | 0.5 | +3.6 | 59.5 | 19.9 |
| PATHS CROSS | 2.2 | +210.1 | 0.0 | 45.1 | 2.2 | +178.4 | 0.0 | 20.8 |
| PIVOT GUARDS FLANK | 0.2 | -4.4 | 0.0 | 0.0 | 0.3 | -7.4 | 0.0 | 6.0 |
| PLAN RESULT | 39.5 | +1551.6 | 1564.2 | 1102.0 | 34.6 | +1090.4 | 1534.7 | 894.6 |
| PURSUES BIG PREY | 0.1 | -7.3 | 0.0 | 22.2 | 0.1 | -21.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.1 | +13.7 | 0.0 | 47.2 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -5.1 | 0.0 | 6.0 | 0.1 | +0.8 | 0.0 | 6.0 |
| REDIRECT COUNTER | 2.5 | +210.3 | 0.0 | 7.9 | 3.6 | +382.2 | 0.0 | 109.6 |
| REDIRECT WEIGHED | 0.1 | -11.9 | 0.0 | 0.0 | 0.3 | +16.0 | 14.7 | 5.0 |
| RESERVE FALL BACK | 0.3 | +12.9 | 0.0 | 4.0 | 0.9 | +55.8 | 0.0 | 12.9 |
| RESTRAINS TO SHOOT | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.9 | +87.5 | 164.4 | 139.9 | 2.6 | +62.0 | 301.8 | 85.2 |
| SAFER THAN THE JOB | 1.3 | +96.6 | 0.0 | 57.2 | 0.5 | +50.6 | 0.0 | 21.4 |
| SCOUT SPOT | 1.0 | +1.6 | 0.0 | 1.9 | 0.2 | +0.2 | 0.0 | 0.0 |
| SCOUT WAITS | 1.1 | +0.0 | 0.0 | 1.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -1.5 | 0.0 | 0.0 | 0.3 | -15.4 | 0.0 | 7.7 |
| SEARCH SPOT | 2.4 | +92.4 | 0.0 | 19.1 | 3.7 | +216.5 | 0.0 | 61.6 |
| SELF MOVE SPELL | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.7 | +166.6 | 0.0 | 10.5 | 1.2 | +138.9 | 2.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +40.0 | 0.0 | 0.0 | 0.2 | +29.7 | 19.3 | 22.5 |
| SET-UP MISSED | 0.1 | +24.8 | 10.5 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | - | - | - | - | 3.2 | +381.6 | 123.5 | 41.1 |
| SHOOTERS IN TWO RANKS | 0.2 | +0.3 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.2 | +13.6 | 0.0 | 6.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +68.8 | 65.8 | 23.7 | 0.5 | +10.4 | 25.6 | 9.3 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 19.6 | +0.0 | 910.5 | 401.7 | 8.9 | +0.0 | 355.7 | 136.4 |
| SHOT REPLANNED | 0.6 | +0.0 | 149.2 | 9.1 | - | - | - | - |
| SHOTS IN THE MOVE | 18.9 | +838.4 | 0.0 | 408.1 | 8.6 | +505.4 | 0.0 | 138.1 |
| SPELL SETS UP CHARGE | 0.4 | +89.8 | 0.0 | 0.0 | 0.2 | +29.7 | 19.3 | 22.5 |
| SPELL WORTH | 0.9 | +20.3 | 58.6 | 58.6 | 2.9 | +60.3 | 58.0 | 88.1 |
| STABLE ROLE | 10.0 | +0.0 | 537.4 | 162.8 | 10.4 | +0.0 | 286.0 | 124.0 |
| STAY WORTH | - | - | - | - | 10.6 | +133.0 | 235.2 | 155.2 |
| STOPS | 0.1 | +8.0 | 5.6 | 6.4 | 0.1 | +7.1 | 13.9 | 5.4 |
| STOPS SHORT OF THE FLANK | 0.8 | +30.0 | 0.0 | 16.7 | 0.1 | +1.6 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 9.4 |
| SUPPORT NARROWED | 5.9 | -40.1 | 338.3 | 99.0 | 6.7 | -58.6 | 552.2 | 138.4 |
| SUPPORTS | 4.3 | +81.6 | 206.3 | 26.4 | 3.8 | +58.6 | 275.4 | 74.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.3 | 0.0 | 0.0 | 0.1 | -2.6 | 16.0 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +22.7 | 0.0 | 0.0 | 0.4 | +0.7 | 0.0 | 19.3 |
| THROUGH LINE OF FIRE | 0.7 | +39.9 | 0.0 | 27.6 | 0.4 | +31.2 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -20.9 | 40.5 | 0.0 | 0.7 | -61.4 | 88.2 | 16.9 |
| TWO OR MORE ARRIVE | 1.0 | +5.5 | 0.0 | 10.5 | 0.4 | +12.0 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 7.6 | -322.6 | 214.9 | 165.4 | 7.7 | -409.5 | 219.0 | 172.5 |
| WALKS TO THE FIGHT | 1.2 | +28.9 | 44.3 | 53.8 | 1.3 | +25.2 | 15.6 | 31.2 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 16.7 | 0.0 | 0.1 | +0.0 | 0.0 | 10.3 |
| WEARS DOWN | 1.2 | +65.8 | 171.7 | 114.2 | 1.2 | +32.0 | 135.7 | 40.9 |
| WHO HITS BACK | 0.2 | +16.0 | 0.0 | 11.2 | 0.3 | +26.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +66.4 | 95.3 | 0.0 | 0.3 | +18.6 | 50.9 | 16.1 |
| WHOLE FIGHT GAIN | 0.2 | +13.2 | 10.9 | 40.2 | 0.5 | +44.4 | 55.1 | 9.0 |

### Rule changes: sf-h2h-opp-4394159-p1b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 515 | 515 | 515 | 28.61 | -26662 | -51.8 |
| BEST FIRST | 151 | 151 | 151 | 8.39 | +6977 | +46.2 |
| SEARCH SPOT | 109 | 109 | 106 | 5.89 | +5594 | +52.8 |
| COUNTER-CHARGE COVER | 307 | 183 | 92 | 5.11 | +5179 | +56.3 |
| PATHS CROSS | 79 | 79 | 79 | 4.39 | +6993 | +88.5 |
| MOVE TO CHARGE | 140 | 140 | 73 | 4.06 | +3433 | +47.0 |
| FACES THE THREAT | 63 | 63 | 63 | 3.50 | +5193 | +82.4 |
| KILLS COUNT NEXT TURN | 216 | 216 | 60 | 3.33 | +1685 | +28.1 |
| SHOTS IN THE MOVE | 495 | 344 | 50 | 2.78 | +1652 | +33.0 |
| SUPPORTS | 147 | 147 | 50 | 2.78 | +827 | +16.5 |
| CANNON SIGHT KEPT | 45 | 45 | 45 | 2.50 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 44 | 44 | 44 | 2.44 | +4551 | +103.4 |
| WAIT AFTER COSTS | 275 | 275 | 43 | 2.39 | +957 | +22.3 |
| FALLBACK BY WORTH | 162 | 162 | 37 | 2.06 | +2608 | +70.5 |
| FIRE PLAN | 155 | 155 | 37 | 2.06 | -286 | -7.7 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 1.94 | +0 | +0.0 |
| SAFER THAN THE JOB | 32 | 32 | 32 | 1.78 | +2650 | +82.8 |
| EVERY WOUND COUNTS | 112 | 112 | 29 | 1.61 | +0 | +0.0 |
| BLOCKED WHEEL | 26 | 26 | 26 | 1.44 | +37 | +1.4 |
| BEST FACING | 25 | 25 | 25 | 1.39 | +736 | +29.4 |
| MAX FOR POSITIONING | 209 | 124 | 25 | 1.39 | +349 | +14.0 |
| SCOUT WAITS | 25 | 25 | 25 | 1.39 | +0 | +0.0 |
| WALKS TO THE FIGHT | 45 | 45 | 24 | 1.33 | +300 | +12.5 |
| RESERVE FALL BACK | 23 | 23 | 23 | 1.28 | +1237 | +53.8 |
| KILLS COUNT | 63 | 63 | 22 | 1.22 | +889 | +40.4 |
| RISK BY ARC | 80 | 79 | 22 | 1.22 | +795 | +36.2 |
| HOLDS AMBUSHERS | 21 | 21 | 21 | 1.17 | +0 | +0.0 |
| REDIRECT COUNTER | 109 | 55 | 21 | 1.17 | +1953 | +93.0 |
| SET UP TOGETHER | 52 | 39 | 21 | 1.17 | +2001 | +95.3 |
| BEST OVERALL | 20 | 20 | 20 | 1.11 | +983 | +49.2 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 1.11 | +1278 | +63.9 |
| ADVANCE LANE KEPT | 19 | 19 | 19 | 1.06 | +0 | +0.0 |
| SHOOTERS ARE THREATS | 58 | 58 | 19 | 1.06 | +0 | +0.0 |
| CHARGE NOW FIRST | 92 | 92 | 17 | 0.94 | -1105 | -65.0 |
| MISSILES IN THE MOVE | 88 | 49 | 17 | 0.94 | +434 | +25.5 |
| SHOOTS FROM THE BEST SPOT | 31 | 31 | 17 | 0.94 | +789 | +46.4 |
| LONE WIZARD KEPT IN | 16 | 16 | 16 | 0.89 | +809 | +50.6 |
| BEST MOVE FOR SHOOTERS | 15 | 15 | 15 | 0.83 | +1365 | +91.0 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.83 | +1207 | +80.5 |
| STOPS SHORT OF THE FLANK | 15 | 15 | 15 | 0.83 | +569 | +38.0 |
| CHARGE NOW WEIGHED | 14 | 14 | 14 | 0.78 | +1346 | +96.1 |
| COMBAT PIVOT | 14 | 14 | 14 | 0.78 | +0 | +0.0 |
| INVITES THE FIGHT | 61 | 61 | 13 | 0.72 | +181 | +14.0 |
| CAST JOB | 18 | 18 | 11 | 0.61 | +296 | +26.9 |
| KEEPS ITS TARGET | 62 | 62 | 11 | 0.61 | +165 | +15.0 |
| RANDOM MOVE BY FIGURES | 20 | 20 | 11 | 0.61 | +247 | +22.5 |
| SHOT REPLANNED | 11 | 11 | 11 | 0.61 | +0 | +0.0 |
| STAY WORTH | 190 | 157 | 11 | 0.61 | +162 | +14.7 |
| BEST PREY | 26 | 26 | 10 | 0.56 | +299 | +29.9 |
| CANNON PLANNED TARGET | 105 | 105 | 10 | 0.56 | -140 | -14.0 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.56 | +0 | +0.0 |
| MOVE AND CAST | 10 | 10 | 10 | 0.56 | +419 | +41.9 |
| WEARS DOWN | 42 | 41 | 10 | 0.56 | +334 | +33.4 |
| MANOEUVRE | 9 | 9 | 9 | 0.50 | +230 | +25.6 |
| MARCH ODDS | 9 | 9 | 9 | 0.50 | +268 | +29.8 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.50 | -213 | -23.6 |
| WHO HITS BACK | 9 | 9 | 9 | 0.50 | +554 | +61.5 |
| OPENS UP | 10 | 10 | 8 | 0.44 | +389 | +48.6 |
| BACKUP TARGETS | 36 | 20 | 7 | 0.39 | +78 | +11.1 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.39 | +306 | +43.8 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.33 | -13 | -2.1 |
| KEEPS THE TARGET | 24 | 24 | 6 | 0.33 | -1046 | -174.4 |
| LOST CHARGE | 108 | 108 | 6 | 0.33 | +88 | +14.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.28 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 0.28 | -20 | -4.1 |
| HONEST THREAT | 112 | 112 | 5 | 0.28 | +0 | +0.0 |
| ONE YARDSTICK | 190 | 62 | 5 | 0.28 | +61 | +12.2 |
| STUCK PIVOT | 5 | 5 | 5 | 0.28 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.22 | +0 | +0.0 |
| EDGE GIVE GROUND | 16 | 16 | 4 | 0.22 | +61 | +15.3 |
| MAKE SURE TOGETHER | 21 | 10 | 4 | 0.22 | +464 | +116.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.22 | -524 | -130.9 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 0.22 | +7 | +1.8 |
| SHOOTERS TO THE PRIMARY | 22 | 15 | 4 | 0.22 | +17 | +4.2 |
| SURE REACH TOGETHER | 18 | 10 | 4 | 0.22 | +19 | +4.7 |
| WHOLE FIGHT | 13 | 12 | 4 | 0.22 | +373 | +93.2 |
| WHOLE FIGHT GAIN | 13 | 13 | 4 | 0.22 | +226 | +56.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.17 | -345 | -115.1 |
| FACE THE CAST | 3 | 3 | 3 | 0.17 | +10 | +3.2 |
| KEEP FALLS | 3 | 3 | 3 | 0.17 | +80 | +26.5 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 3 | 0.17 | -284 | -94.8 |
| MARCH CHECK | 4 | 3 | 3 | 0.17 | +43 | +14.4 |
| STOPS | 3 | 3 | 3 | 0.17 | +163 | +54.2 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.11 | +90 | +44.8 |
| MOVE SPELL IN RANGE | 18 | 8 | 2 | 0.11 | +23 | +11.7 |
| NEEDED THERE | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.11 | -87 | -43.6 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.06 | -30 | -29.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| DEFENSIVE ARMY | 4 | 4 | 1 | 0.06 | -3 | -2.8 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.06 | +198 | +198.1 |
| HORN WORTH | 1 | 1 | 1 | 0.06 | +14 | +13.6 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.06 | +134 | +133.5 |
| HUNT IN PAIRS | 14 | 12 | 1 | 0.06 | +190 | +189.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.06 | +7 | +7.3 |
| OVERRUNS AWAY | 13 | 13 | 1 | 0.06 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.06 | +68 | +67.9 |
| SUPPORT NARROWED | 227 | 227 | 1 | 0.06 | -13 | -12.7 |
| TWO OR MORE ARRIVE | 25 | 22 | 1 | 0.06 | +24 | +23.5 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.06 | -30 | -30.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 3 | 3 | 0 | 0.00 | - | - |
| CASTING BLOCK | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 189 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 11 | 11 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 11 | 11 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 10 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| LONG SHOT | 11 | 11 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 10 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 99 | 53 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 188 | 188 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 25 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 1333 | trace | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 513 | 513 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 68 | not checked | - | - | - | - |
| STABLE ROLE | 367 | 367 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-opp-4394159-p1b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.72 | 11.33 | 53.9 |
| TURN GATE | gate | 0.56 | 0.67 | 47.3 |
| FALLBACK | gate | 0.67 | 0.50 | 30.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.61 | 65.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.39 | 0.28 | 53.8 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.28 | 23.6 |
| FIGHT ORDER BAND | gate | 0.17 | 0.11 | 2.0 |
| FIRE PLAN | rule | - | 0.28 | 227.9 |
| KEEPS THE TARGET | rule | - | 0.28 | 261.7 |
| BLOCKED WHEEL | rule | 0.11 | 0.11 | 50.2 |
| PURSUES BIG PREY | rule | 0.11 | 0.11 | 130.9 |
| BEST PRIZE | rule | 0.11 | 0.06 | 115.1 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 11.3 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 56.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.17 | 94.8 |
| THROUGH LINE OF FIRE | rule | 0.11 | 0.06 | 16.5 |
| CHAFF PASSED | rule | 0.11 | - | 10.1 |
| FACES THE THREAT | rule | - | 0.11 | 6.9 |
| PATHS CROSS | rule | 0.06 | 0.06 | 14.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 43.6 |
| AFTERMATH BAND | gate | 0.06 | - | 1.0 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 29.9 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 20.7 |
| DEFENSIVE ARMY | rule | 0.06 | - | 2.8 |
| MARCH ODDS | rule | - | 0.06 | 1.1 |
| NO REASON | gate | - | 0.06 | 3.7 |
| REDIRECT WEIGHED | rule | - | 0.06 | 28.3 |
| RULE SWITCHED OFF | gate | 0.06 | - | 1.9 |
| SAFER THAN THE JOB | rule | 0.06 | - | 19.9 |
| SUPPORT NARROWED | rule | - | 0.06 | 12.7 |
| SUPPORT REQUEST | gate | - | 0.06 | 19.9 |
| WAR ENGINE JOBS | rule | 0.06 | - | 30.4 |

### Plans: sf-h2h-opp-4394159-p1b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.5 | 20% | 363 | 437 | 120% |
| Mine | charge | 3.2 | 59% | 458 | 320 | 70% |
| Mine | close in | 5.4 | 29% | 395 | 164 | 41% |
| Mine | hold | 4.4 | 34% | 318 | 0 | 0% |
| Mine | join | 1.3 | 96% | 18 | 0 | 0% |
| Mine | shoot | 10.1 | 52% | 343 | 631 | 184% |
| Mine | support | 4.6 | 95% | 56 | 0 | 0% |
| Opponent | advance | 12.3 | 12% | 513 | 207 | 40% |
| Opponent | charge | 4.2 | 57% | 442 | 446 | 101% |
| Opponent | close in | 5.3 | 26% | 367 | 118 | 32% |
| Opponent | hold | 2.9 | 56% | 207 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 36 | 0 | 0% |
| Opponent | shoot | 4.7 | 60% | 280 | 319 | 114% |
| Opponent | support | 4.2 | 83% | 36 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-opp-4394159-p1b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 551 | 401 | 100% | 62 |
| Opponent | 0.2 | 3 | 0 | 67% | 67% | 0% | 2.0 | 429 | 227 | 67% | 157 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 354 |
| High Elf Realms | 0.5 | 1 | 0 | 100% | 100% | 0% | 3.0 | 551 | 401 | 100% | 58 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Ogre Kingdoms | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 457 | 0 | 0% | 89 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.3 | 2 | 0 | 100% | 100% | 0% | 2.0 | 415 | 340 | 100% | 95 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 592 |

### Battle groups: sf-h2h-opp-4394159-p1b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 26% | 52% | 15% | 57% | 26% | 13% | 13% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 7% | 33% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 17% | 59% | 23% | 40% | 41% | 24% | 6% | 29% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 25% | 69% | 19% | 0% | 15% | 0% | 15% | 62% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-opp-4394159-p1b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 50 | 0% | 4.5 | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 24 | 52 (24) | 15 | 38 | 25 | 25% | 2.4 | 63 (17) | 41 (3) | 0 (4) | 58 (19) | 34 (5) |
| Mine | Character | 58 | 52 (58) | 52 | 0 | 40 | 36% | 2.6 | 87 (19) | 53 (25) | 0 (3) | 68 (24) | 54 (23) |
| Mine | Clean-up | 5 | 13 (5) | 13 | 0 | 53 | 20% | 2.8 | 0 (2) | 29 (3) | - | 47 (2) | 0 (3) |
| Mine | Fast Hammer | 35 | 28 (35) | 18 | 11 | 53 | 26% | 2.9 | 14 (13) | 47 (17) | 12 (5) | 31 (22) | 25 (13) |
| Mine | Hammer | 20 | 19 (20) | 11 | 8 | 58 | 5% | 2.3 | 13 (7) | 27 (11) | 0 (2) | 24 (16) | 4 (4) |
| Mine | Holder | 18 | 155 (18) | 25 | 130 | 34 | 22% | 1.5 | 0 (2) | 183 (15) | 0 (1) | 197 (13) | 46 (5) |
| Mine | Shooter | 20 | 38 (20) | 7 | 31 | 48 | 5% | 1.8 | 18 (5) | 57 (9) | 24 (6) | 40 (14) | 34 (6) |
| Mine | War machine | 37 | 62 (37) | 62 | 0 | 56 | 3% | 1.3 | 50 (11) | 68 (24) | 50 (2) | 25 (11) | 78 (26) |
| Mine | Wizard | 11 | 0 (11) | 0 | 0 | 56 | 18% | 2.1 | 0 (2) | - | 0 (3) | 0 (3) | 0 (2) |
| Opponent | Chaff | 38 | 60 (38) | 53 | 7 | 58 | 45% | 2.6 | 30 (17) | 73 (9) | 90 (12) | 81 (27) | 0 (11) |
| Opponent | Character | 55 | 63 (55) | 63 | 0 | 22 | 25% | 2.5 | 52 (20) | 79 (26) | 37 (5) | 72 (37) | 50 (14) |
| Opponent | Clean-up | 8 | 62 (8) | 45 | 17 | 40 | 12% | 3.7 | 79 (5) | 39 (3) | - | 82 (6) | 0 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 25 | 46 (25) | 18 | 28 | 37 | 32% | 2.2 | 47 (8) | 47 (13) | 44 (4) | 35 (20) | 115 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 24 | 40 (24) | 18 | 22 | 53 | 42% | 2.1 | 0 (6) | 45 (17) | 73 (1) | 44 (17) | 28 (7) |
| Opponent | Holder | 18 | 78 (18) | 10 | 68 | 23 | 33% | 3.5 | 6 (4) | 129 (11) | 0 (2) | 126 (11) | 0 (6) |
| Opponent | Shooter | 6 | 93 (6) | 73 | 20 | 25 | 0% | 1.2 | 0 (2) | 116 (3) | 171 (1) | 58 (3) | 124 (3) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 12 | 71 (12) | 71 | 0 | 55 | 8% | 1.2 | - | 58 (6) | 85 (6) | 304 (1) | 51 (11) |
| Opponent | Wizard | 15 | 2 (15) | 2 | 0 | 34 | 20% | 1.5 | 0 (7) | 4 (5) | 0 (1) | 4 (6) | 0 (7) |

### Charged fights: sf-h2h-opp-4394159-p1b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 11 | 283 | 72 | 1.7 | 1.1 | 41 | 47 | -6 | 7 of 19 | 12 of 19 | +0 | -6 |
| Mine | High Elf Realms | 2 | 272 | 1109 | 5.5 | 1.1 | 202 | 11 | +190 | 3 of 11 | 9 of 11 | +347 | +174 |
| Mine | Ogre Kingdoms | 2 | 134 | 218 | 2.5 | 1.0 | 87 | 7 | +81 | 1 of 5 | 4 of 5 | - | +81 |
| Mine | Tomb Kings of Khemri | 3 | 0 | 1006 | 4.7 | 1.1 | 216 | 45 | +171 | 5 of 14 | 10 of 14 | +98 | +177 |
| **Mine** | all armies | 18 | 218 | 359 | 2.7 | 1.1 | 132 | 34 | +97 | 16 of 49 | 35 of 49 | +148 | +94 |
| Opponent | Empire of Man | 1 | 425 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Grand Cathay | 2 | 562 | 750 | 6.0 | 1.2 | 125 | 14 | +111 | 6 of 12 | 10 of 12 | +368 | +60 |
| Opponent | Kingdom of Bretonnia | 2 | 58 | 362 | 3.5 | 1.1 | 103 | 0 | +103 | 3 of 7 | 6 of 7 | +0 | +120 |
| Opponent | Ogre Kingdoms | 1 | 151 | 400 | 3.0 | 1.0 | 133 | 11 | +122 | 1 of 3 | 1 of 3 | - | +122 |
| Opponent | Tomb Kings of Khemri | 1 | 234 | 688 | 3.0 | 1.0 | 229 | 0 | +229 | 2 of 3 | 3 of 3 | - | +229 |
| Opponent | Vampire Counts | 3 | 0 | 680 | 5.0 | 1.2 | 136 | 17 | +119 | 7 of 15 | 11 of 15 | +232 | +101 |
| Opponent | Warriors of Chaos | 6 | 0 | 281 | 2.0 | 1.1 | 141 | 30 | +110 | 4 of 12 | 11 of 12 | +185 | +104 |
| Opponent | Wood Elf Realms | 2 | 375 | 144 | 2.5 | 1.0 | 58 | 0 | +58 | 3 of 5 | 1 of 5 | - | +58 |
| **Opponent** | all armies | 18 | 156 | 407 | 3.2 | 1.1 | 126 | 14 | +112 | 27 of 58 | 43 of 58 | +231 | +98 |

### Effective charges: sf-h2h-opp-4394159-p1b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 19 | 4 (net -153) | 1 (net +0) | 6 (net +28) | 5 (net +73) | 0 | 1 (net +258) | 2 | 35% (6 of 17) |
| Mine | High Elf Realms | 11 | 1 (net +706) | 0 | 3 (net +62) | 3 (net +176) | 1 (net +40) | 2 (net +44) | 1 | 30% (3 of 10) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 0 | 0 | 4 (net +109) | 1 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 14 | 1 (net +227) | 1 (net -431) | 2 (net +142) | 2 (net +330) | 2 (net +89) | 5 (net +275) | 1 | 15% (2 of 13) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 12 | 1 (net +238) | 0 | 2 (net +106) | 5 (net +116) | 2 (net +18) | 2 (net +132) | 0 | 17% (2 of 12) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +238) | 0 | 0 | 2 (net +0) | 1 (net +0) | 3 (net +162) | 0 | 0% (0 of 7) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 1 (net -34) | 1 (net +400) | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 15 | 3 (net +160) | 1 (net -54) | 3 (net +182) | 4 (net +71) | 1 (net +55) | 2 (net +171) | 1 | 21% (3 of 14) |
| Opponent | Warriors of Chaos | 12 | 3 (net +92) | 0 | 1 (net +310) | 0 | 1 (net +55) | 4 (net +172) | 3 | 11% (1 of 9) |
| Opponent | Wood Elf Realms | 5 | 1 (net +0) | 0 | 0 | 1 (net +36) | 0 | 1 (net +252) | 2 | 0% (0 of 3) |

### Charged fights, damage counted: sf-h2h-opp-4394159-p1b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 270 | 284 | +54 | 165 | 140 | +25 | +9.3 |
| Mine | 50-54% | 2 | 298 | 427 | -216 | 8 | 216 | -207 | -69.7 |
| Mine | Effective (55-75%) | 11 | 324 | 278 | +58 | 79 | 30 | +50 | +15.4 |
| Mine | 76-89% | 10 | 244 | 156 | +155 | 175 | 0 | +175 | +71.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 249 | 225 | +180 | 245 | 51 | +195 | +78.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 380 | 73 | +73 | 73 | 0 | +73 | +19.1 |
| Mine | No odds | 5 | 269 | 180 | +64 | 187 | 120 | +67 | +24.9 |
| Mine | All fights | 49 | 279 | 224 | +97 | 158 | 57 | +100 | +36.0 |
| Opponent | Long shot (under 50%) | 9 | 158 | 223 | +137 | 184 | 60 | +124 | +78.6 |
| Opponent | 50-54% | 1 | 54 | 164 | -54 | 0 | 99 | -99 | -183.3 |
| Opponent | Effective (55-75%) | 7 | 238 | 176 | +148 | 190 | 37 | +153 | +64.4 |
| Opponent | 76-89% | 14 | 260 | 205 | +93 | 134 | 73 | +60 | +23.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 307 | 191 | +145 | 191 | 29 | +162 | +52.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 390 | 76 | +29 | 29 | 0 | +29 | +7.5 |
| Opponent | No odds | 8 | 258 | 202 | +102 | 163 | 25 | +138 | +53.2 |
| Opponent | All fights | 58 | 260 | 189 | +112 | 155 | 44 | +111 | +42.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-opp-4394159-p1b | move | 250 | 36 (14%) | 28 (11%) | 26 (10%) | 188 (75%) |
| sf-h2h-opp-4394159-p1b | objective | 194 | 27 (14%) | 21 (11%) | 25 (13%) | 142 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0725, L0827, L2224 |
| Clockwork Compass | Opponent | L0712 |
| Fistful of Laurels | Mine | L1822, L1831 |
| Fistful of Laurels | Opponent | L1318 |
| Horn of the Wild Hunt | Opponent | L0833 |
| Invocation of Nehek | Opponent | L0725, L0827, L2224 |
| Ring of Doom | Mine | L1516 |
| Ring of Doom | Opponent | L0712, L0731, L0833, L1831 |
| Ring of Jet | Opponent | L0712, L0810 |
| Standard of the Fell Warrior | Mine | L1318 |
| Twice-Blessed Armour | Mine | L0708, L0712, L0716, L0725, L0730, L0731 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0708, L0712, L0716, L0725, L0730, L0731, L0810, L0827, L0832, L0833, L0835 |
| Witch Hunter's Ward | Opponent | L0708 |

# Doctrine scorecard: sf-h2h-opp-4394159-p4

### Scorecard: sf-h2h-opp-4394159-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0122 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 372 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Mine | no | 1 | - | 1 | 5 | 0 | 0 | 0 | 30 |
| L0208 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 605 |
| L0304 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0304 | 4 | 1 | Opponent | no | 1 | 2 | 5 | 2 | 0 | 0 | 0 | 124 |
| L0305 | 5 | 1 | Mine | no | - | - | 0 | 4 | 0 | 0 | 0 | 675 |
| L0305 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0306 | 6 | 1 | Mine | no | 11 | 3 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0306 | 6 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 801 |
| L0309 | 3 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 760 |
| L0309 | 3 | 1 | Opponent | no | 4 | 5 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0318 | 6 | 1 | Mine | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0318 | 6 | 1 | Opponent | no | 2 | 5 | 6 | 1 | 1 | 0 | 0 | 0 |
| L0329 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0329 | 5 | 1 | Opponent | yes | - | 3 | 0 | 6 | 1 | 0 | 0 | 0 |
| L0335 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0335 | 5 | 1 | Opponent | yes | - | 3 | 2 | 5 | 0 | 0 | 0 | 140 |
| L0415 | 1 | 1 | Mine | no | 5 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0515 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 881 |
| L0515 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L0517 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 698 |
| L0517 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0519 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 771 |
| L0519 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 55 |
| L0521 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 925 |
| L0521 | 5 | 1 | Opponent | yes | - | - | 2 | 9 | 1 | 0 | 0 | 565 |
| L0525 | 3 | 1 | Mine | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 771 |
| L0525 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0607 | 1 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 798 |
| L0607 | 1 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0610 | 4 | 1 | Mine | no | 0 | - | 2 | 3 | 0 | 0 | 0 | 966 |
| L0610 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 501 |
| L0629 | 5 | 1 | Mine | no | - | 6 | 0 | 1 | 0 | 0 | 0 | 929 |
| L0629 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 6 | 4 | 7 | 1 | 1 | 0 | 0 | 615 |
| L0633 | 3 | 1 | Opponent | no | 3 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0635 | 5 | 1 | Mine | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 615 |
| L0635 | 5 | 1 | Opponent | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 713 |
| L0723 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 751 |
| L0723 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 2 | 0 | 0 | 0 |
| L0728 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 295 |
| L0728 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0732 | 6 | 1 | Mine | no | 1 | 3 | 0 | 0 | 0 | 0 | 0 | 497 |
| L0732 | 6 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 170 |
| L0917 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 620 |
| L0917 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 10 | 4 | 2 | 2 | 0 | 0 | 0 | 234 |
| L0928 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 994 |
| L0928 | 4 | 1 | Opponent | no | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 994 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1018 | 4 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 497 |
| L1018 | 4 | 1 | Opponent | no | 0 | - | 3 | 0 | 2 | 0 | 0 | 305 |
| L1322 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 370 |
| L1322 | 2 | 1 | Opponent | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 55 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 5 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1522 | 4 | 1 | Mine | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1522 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Mine | no | 1 | 1 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Opponent | no | 2 | 4 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Mine | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Opponent | - | - | - | 1 | 0 | 0 | 0 | 0 | 65 |
| **Average** | | | Mine | 10% | 2.3 | 2.9 | 1.9 | 1.2 | 0.1 | 0.0 | 0.0 | 558.4 |
| **Average** | | | Opponent | 27% | 2.2 | 2.5 | 2.6 | 1.8 | 0.5 | 0.0 | 0.0 | 158.9 |

### KPIs: sf-h2h-opp-4394159-p4

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 42% (70 of 166) | 11% (17 of 156) | 27% (87 of 322) |
| Winner chose to follow up after the loser gave ground |  | 97% (61 of 63); on the table 98% | 98% (57 of 58); on the table 98% | 98% (118 of 121); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (7 of 8); on the table 88% | 82% (23 of 28); on the table 86% | 83% (30 of 36); on the table 86% |
| Winner chose to pursue after the loser fled |  | 62% (8 of 13); on the table 62% | 80% (28 of 35); on the table 86% | 75% (36 of 48); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 90% (76 of 84); on the table 92% | 89% (108 of 121); on the table 92% | 90% (184 of 205); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 37% (87 of 234) | 32% (50 of 156) | 35% (137 of 390) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (75 of 157) | 50% (50 of 101) | 48% (125 of 258) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 20% (13 of 66) | 24% (19 of 78) | 22% (32 of 144) |
|     round 1 |  | 36% (4 of 11) | 15% (2 of 13) | 25% (6 of 24) |
|     rounds 2+ |  | 16% (9 of 55) | 26% (17 of 65) | 22% (26 of 120) |
|   other wizards | 50%+ | 40% (62 of 156) | 40% (31 of 78) | 40% (93 of 234) |
|     round 1 |  | 54% (14 of 26) | 54% (7 of 13) | 54% (21 of 39) |
|     rounds 2+ |  | 37% (48 of 130) | 37% (24 of 65) | 37% (72 of 195) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (2 of 5) | 54% (20 of 37) | 52% (22 of 42) |
| Points that never fought | lower | 50% (34735 of 70083) | 41% (29762 of 71988) | 45% (64497 of 142071) |
|   infantry points that never fought | lower | 49% (8812 of 17810) | 62% (8747 of 14065) | 55% (17559 of 31875) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (203 of 303) | 60% (170 of 282) | 64% (373 of 585) |
| Bound items with a magic missile used (at least once a game) |  | 100% (13 of 13); 1.0 uses a game | 76% (13 of 17); 1.1 uses a game | 87% (26 of 30); 1.0 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.4 uses a game | 100% (2 of 2); 0.2 uses a game | 50% (8 of 16); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (6 of 15); 0.2 uses a game | 78% (7 of 9); 0.2 uses a game | 54% (13 of 24); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (35662 of 57540) | 54% (33902 of 62687) | 58% (69564 of 120227) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (38%) | 0.6 (19%) | 2.1 (30%) |
| MARCHED: its unit marched | 0.5 (13%) | 0.3 (10%) | 0.8 (12%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.2 (8%) | 0.2 (4%) |
| IN COMBAT: engaged in combat | 1.1 (26%) | 0.9 (30%) | 1.9 (28%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |
| GONE: slain | 0.3 (7%) | 0.4 (14%) | 0.7 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.2 (8%) | 0.6 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.4 | 1.1 | 1.7 | 3.8 | 0.3 | 1.2 |
| not cast | 3.6 | 2.3 | 2.7 | 7.0 | 1.0 | 14.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (25%) | 0.2 (6%) | 2.1 (30%) | 0.2 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (12%) | 0.1 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (5%) | 0.6 (21%) | 1.9 (28%) | 0.3 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (15%) | 0.6 (28%) | 0.2 (8%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (7%) | 0.2 (8%) | 0.1 (2%) | 0.0 (0%) | 0.6 (4%) |
| GONE: slain | 0.7 (18%) | 0.1 (2%) | 0.2 (8%) | 0.7 (10%) | 0.1 (14%) | 1.5 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (5%) | 0.2 (8%) | 0.6 (8%) | 0.1 (14%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.1 (8%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (54%) | 0.2 (11%) | 1.0 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.6 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.8 a game | 0.8 a game |
| stood (cast and not dispelled) | 75% (15 of 20) | 61% (11 of 18) | 68% (26 of 38) |
| the unit moved after it | 73% (11 of 15) | 45% (5 of 11) | 62% (16 of 26) |
| it charged on its next turn | 7% (1 of 15) | 0% (0 of 11) | 4% (1 of 26) |
| the enemy charged it first | 0% (0 of 15) | 9% (1 of 11) | 4% (1 of 26) |
| it fought by the end of its next turn | 0% (0 of 15) | 9% (1 of 11) | 4% (1 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (3 of 15) | 9% (1 of 11) | 15% (4 of 26) |
| none of these (no charge, no fight, no charge escaped) | 73% (11 of 15) | 82% (9 of 11) | 77% (20 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (859 of 1310) | 57% (528 of 922) | 62% (1387 of 2232) |
|   cavalry | 36% (14 of 39) | 61% (72 of 119) | 54% (86 of 158) |
|   character | 69% (130 of 188) | 37% (47 of 128) | 56% (177 of 316) |
|   chariot | 49% (58 of 118) | 60% (53 of 88) | 54% (111 of 206) |
|   infantry | 48% (176 of 364) | 54% (209 of 384) | 51% (385 of 748) |
|   monster | 48% (23 of 48) | 59% (35 of 59) | 54% (58 of 107) |
|   war machine | 83% (458 of 553) | 78% (112 of 144) | 82% (570 of 697) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (32%) | 2.6 (24%) | 6.7 (28%) |
| CHARGED: it charged | 1.3 (11%) | 1.8 (17%) | 3.2 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (8%) | 0.5 (5%) | 1.4 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.3 (18%) | 2.9 (26%) | 5.2 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (4%) | 0.4 (4%) | 0.9 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (18%) | 1.9 (17%) | 4.1 (18%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.3 (3%) | 0.6 (2%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.6 (5%) | 0.4 (4%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.5 | 1.2 | 72% | 6.3 pts | 22 pts |
| character | 5.6 | 1.7 | 78% | 7.9 pts | 44 pts |
| chariot | 3.1 | 2.9 | 58% | 15.6 pts | 49 pts |
| infantry | 15.7 | 5.8 | 72% | 8.9 pts | 139 pts |
| monster | 2.0 | 0.6 | 77% | 9.1 pts | 18 pts |
| war machine | 16.1 | 15.1 | 64% | 31.9 pts | 513 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.8 | 5.5 | 4.2 |
| Charges that made contact a game | 2.4 | 3.7 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.47 declared, 0.41 contact (17 units) | 1.40 declared, 1.00 contact (10 units) | 0.81 declared, 0.63 contact (27 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 1.40 declared, 1.20 contact (5 units) | 1.00 declared, 0.90 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.33 contact (230 units) | 0.63 declared, 0.41 contact (283 units) | 0.52 declared, 0.38 contact (513 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (32 of 51) | 47% (7 of 15) | 78% (7 of 9) | 61% (46 of 75) |
| Character in a unit | 85% (46 of 54) | 65% (13 of 20) | 0% (0 of 3) | 77% (59 of 77) |
| Character on its own | 77% (23 of 30) | 68% (15 of 22) | 22% (11 of 51) | 48% (49 of 103) |
| Chariot | 63% (12 of 19) | 83% (19 of 23) | - | 74% (31 of 42) |
| Infantry | 60% (53 of 89) | 57% (26 of 46) | 50% (1 of 2) | 58% (80 of 137) |
| Monster | 58% (15 of 26) | 67% (6 of 9) | - | 60% (21 of 35) |
| Monstrous | 86% (6 of 7) | 68% (13 of 19) | - | 73% (19 of 26) |
| War Machines | 77% (64 of 83) | 57% (4 of 7) | - | 76% (68 of 90) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (2 of 2); on the table 100% | 39% (21 of 54) | 48% | 45% (5 of 11) | 100% (3 of 3); 4.5 uses a game | 100% (1 of 1); 0.5 uses a game | 67% (2 of 3); 1.0 uses a game |
| Chaos Dwarfs | 9 | 93% (13 of 14); on the table 93% | 42% (30 of 72) | 58% | 69% (48 of 70) | 0.0 uses a game | 0.0 uses a game | 43% (3 of 7); 0.3 uses a game |
| Dwarfen Mountain Holds | 13 | 96% (25 of 26); on the table 96% | - | 62% | 73% (80 of 109) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 12 | 80% (12 of 15); on the table 87% | 49% (47 of 96) | 55% | 69% (87 of 127) | 0.0 uses a game | 80% (4 of 5); 1.2 uses a game | 50% (3 of 6); 0.2 uses a game |
| Grand Cathay | 2 | 75% (6 of 8); on the table 75% | 17% (9 of 54) | 39% | 45% (9 of 20) | 75% (3 of 4); 4.5 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 7 | 89% (31 of 35); on the table 91% | 22% (4 of 18) | 31% | 40% (21 of 52) | 100% (11 of 11); 3.7 uses a game | 25% (2 of 8); 0.4 uses a game | 0.0 uses a game |
| Lizardmen | 2 | 83% (10 of 12); on the table 83% | - | 40% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 100% (13 of 13); on the table 100% | 0% (0 of 18) | 35% | 83% (29 of 35) | 100% (5 of 5); 2.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 6% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 90% (9 of 10); on the table 100% | 50% (6 of 12) | 49% | 56% (9 of 16) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 83% (15 of 18); on the table 83% | 17% (1 of 6) | 23% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 89% (16 of 18); on the table 89% | 29% (7 of 24) | 16% | 71% (12 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 90% (18 of 20); on the table 95% | 50% (6 of 12) | 36% | 50% (21 of 42) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 100% (11 of 11); on the table 100% | 22% (4 of 18) | 44% | 77% (34 of 44) | 50% (3 of 6); 3.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-opp-4394159-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (38) | 48% (21) | 47% (59) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.39 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.06 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.31 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 0.81 | 2.61 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.56 | 1.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.11 | 4.06 | 9.17 |

### Quality by phase: sf-h2h-opp-4394159-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 60% (56 of 93) | 45% (71 of 159) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (317 of 580) | 42% (109 of 261) |
| Strategy | Close-in objectives charged next turn | 17% (23 of 132) | 12% (27 of 220) |
| Strategy | Support requests answered (helper made contact too) | 43% (6 of 14) | 33% (7 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 57% (4 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 33% (20 of 60) | 47% (20 of 43) |
| Strategy | Lone characters that fought | 71% (58 of 82) | 81% (62 of 77) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 558.4 | 158.9 |
| Movement | Fights charged into per game | 2.2 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 73, net +14 | 24 of 89, net +129 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 73, net +44 | 13 of 89, net +35 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 73, net +110 | 12 of 89, net +172 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 73, net +95 | 18 of 89, net +159 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.2 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (171 of 438) | 35% (159 of 458) |
| Shooting | Points destroyed by shooting units | 141.3 | 45.2 |
| Shooting | War machine shots | 12.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (209 of 458) | 48% (58 of 120) |
| Shooting | Points destroyed by war machines | 80.1 | 52.1 |
| Magic | Magic missiles cast | 1.3 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (20 of 46) | 47% (16 of 34) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.1 |
| Magic | Wounds caused by other spells | 1.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 37.2 | 13.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.2 / 0.4 / 0.4 / 0.0 | 1.5 / 0.2 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 249.4 | 344.2 |
| Combat | Points run down | 63.7 | 68.8 |
| Combat | Net points per charged fight, damage counted | +101 | +113 |
| Combat | Net per 100 charger points, damage counted | +43.2 | +37.2 |
| Combat | First round won (charged fights) | 78% | 64% |
| Combat | Net points per charged fight | +95 | +112 |
| Combat | Net points per supported fight / lone fight | +222 / +81 | +196 / +99 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 80 | 55 of 111 |
| Game | Points lost | 683.8 | 651.7 |
| Game | VP from objectives | 520.6 | 615.0 |
| Game | Lone holders (player turns) | 2.3 | 2.2 |

- Mine won / drew / lost: 13 / 7 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -145 VP
- The side that went first won 15 of 29 games with a winner
- Points traded per game (both sides' losses): 1336
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-opp-4394159-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +2.6 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.4 | +0.0 | 0.0 | 73.2 | 0.8 | +0.0 | 0.0 | 18.5 |
| BACKUP TARGETS | 0.5 | +3.8 | 0.0 | 18.7 | 0.7 | +6.6 | 0.0 | 20.1 |
| BEST FACING | 0.9 | +26.9 | 0.0 | 26.4 | 0.4 | +24.1 | 0.0 | 10.1 |
| BEST FIRST | 4.5 | +176.2 | 102.7 | 39.3 | 4.5 | +179.8 | 49.8 | 70.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.2 | +100.3 | 0.0 | 42.1 |
| BEST OVERALL | 0.9 | +83.8 | 0.0 | 8.8 | 0.4 | +12.8 | 0.0 | 14.6 |
| BEST PREY | 0.9 | +61.0 | 15.0 | 17.6 | 0.8 | +30.3 | 34.8 | 13.5 |
| BEST PRIZE | 0.0 | -5.8 | 3.5 | 0.0 | 0.1 | -1.3 | 10.6 | 6.5 |
| BIG CHARACTER SAFETY | 0.2 | -0.8 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 6.5 | 0.0 |
| BLOCKED WHEEL | 0.2 | +6.4 | 0.0 | 8.0 | 0.4 | -0.0 | 0.0 | 2.8 |
| BOMBING RUN | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 211.0 | 22.9 | - | - | - | - |
| CANNON PLANNED TARGET | 10.5 | +325.0 | 598.7 | 179.4 | - | - | - | - |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 2.8 | 0.4 | +0.0 | 0.0 | 2.6 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 2.6 | 6.5 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 9.6 | 0.0 | 0.1 | -7.1 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +32.3 | 36.4 | 26.5 | 0.3 | +4.7 | 8.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +9.5 | 9.4 | 0.0 | 0.1 | +0.3 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 0.0 | 30.9 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 3.5 | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 167.2 | 21.9 | 2.5 | +0.0 | 220.8 | 20.3 |
| CHARGE NOW WEIGHED | 0.6 | -73.9 | 21.5 | 7.7 | 0.6 | -79.0 | 10.4 | 43.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -1.4 | 0.0 | 11.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 2.0 | 0.1 | +0.0 | 4.9 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 0.0 | 41.8 | 0.4 | +0.0 | 20.9 | 14.2 |
| CONVEYANCE SEARCH | 0.4 | +67.6 | 10.6 | 10.6 | 0.4 | +29.7 | 11.3 | 18.9 |
| COUNTER-CHARGE COVER | 9.9 | +806.7 | 0.0 | 243.8 | 6.3 | +527.9 | 0.0 | 152.4 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 29.8 | 12.7 | 0.1 | +0.0 | 3.3 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.4 | 1.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +3.8 | 35.5 | 1.7 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 10.0 | +0.0 | 358.2 | 155.8 |
| FACE THE CAST | - | - | - | - | 0.1 | +0.6 | 0.0 | 6.1 |
| FACES THE THREAT | 1.8 | +182.7 | 0.0 | 44.2 | 0.8 | +61.6 | 0.0 | 18.4 |
| FALLBACK BY WORTH | 5.1 | +74.6 | 0.0 | 71.6 | 5.6 | +68.1 | 0.0 | 47.5 |
| FIGHT LIFT | 0.0 | +1.9 | 3.1 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.7 | 0.0 | 1.7 | 0.0 | +0.9 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.6 | +0.0 | 25.2 | 21.8 |
| FIRE PLAN | - | - | - | - | 13.9 | +41.3 | 480.2 | 243.9 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 141.2 | 3.9 | +0.0 | 0.0 | 78.3 |
| FOLLOW UP WEIGHED | 1.1 | +179.8 | 0.0 | 55.8 | 1.2 | +146.1 | 0.0 | 26.3 |
| FRIENDS SHOTS CHECKED | 0.4 | +30.9 | 0.0 | 4.6 | 0.2 | +15.8 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -1.5 | 0.0 | 0.0 | 0.2 | -2.6 | 20.8 | 7.9 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 0.0 | 1.7 | - | - | - | - |
| GROUND FLIERS | 0.1 | +5.4 | 0.0 | 6.6 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 8.4 | 0.0 | 0.0 | +0.0 | 8.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 15.0 | 0.0 | 0.3 | +0.0 | 28.7 | 3.2 |
| HILL BY ITS CHANCE | 0.6 | -48.5 | 0.0 | 4.2 | 0.4 | -29.3 | 0.0 | 4.6 |
| HOLDS AMBUSHERS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 10.0 | +1144.4 | 358.2 | 155.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +8.2 | 0.0 | 7.6 | 0.3 | +7.2 | 6.9 | 9.7 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.8 | 0.2 | +0.0 | 6.9 | 8.6 |
| HUNT IN PAIRS | 0.1 | +9.6 | 0.0 | 0.0 | 0.4 | +36.6 | 0.0 | 11.9 |
| HUNT KEPT | 0.0 | +2.2 | 0.0 | 2.4 | 0.1 | +1.9 | 0.0 | 4.8 |
| HUNT RESULT | 0.2 | +0.0 | 11.0 | 12.2 | 0.4 | +27.5 | 15.0 | 14.4 |
| HUNT THE GUNS | 0.2 | +66.9 | 0.0 | 8.4 | 0.4 | +132.4 | 24.9 | 7.4 |
| INVITES THE FIGHT | 1.2 | +19.4 | 24.6 | 30.6 | 1.0 | +16.5 | 20.6 | 25.4 |
| JOINT CHARGE PLAN | 0.2 | +28.1 | 0.0 | 0.0 | 0.4 | +11.8 | 15.2 | 4.3 |
| KEEP FALLS | 0.1 | +0.7 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 2.1 | 0.1 | +0.6 | 3.5 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +47.5 | 138.4 | 29.0 | 1.8 | +55.0 | 138.8 | 35.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | - | - | - | - | 1.4 | +1.1 | 118.3 | 16.7 |
| KILLS COUNT | 1.0 | +39.9 | 69.6 | 10.3 | 2.1 | +83.0 | 146.7 | 17.9 |
| KILLS COUNT NEXT TURN | 5.1 | +142.5 | 201.8 | 80.7 | 6.2 | +211.1 | 197.3 | 107.0 |
| LONE CHARACTER SAFE SPOT | 0.4 | +8.4 | 3.5 | 13.8 | 0.3 | +11.5 | 4.6 | 14.4 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +15.3 | 0.0 | 0.0 | 0.4 | +30.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -3.3 | 29.7 | 0.0 | 0.6 | +1.1 | 27.4 | 3.5 |
| LOST CHARGE | 2.7 | -59.3 | 112.6 | 76.2 | 2.0 | -50.0 | 48.6 | 95.2 |
| MAKE SURE TOGETHER | 0.5 | +42.8 | 6.5 | 3.3 | 1.3 | +176.9 | 57.5 | 23.6 |
| MANOEUVRE | 0.1 | +7.2 | 0.0 | 7.4 | 0.3 | +7.9 | 0.0 | 5.1 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +15.7 | 0.0 | 10.1 | 0.3 | +13.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +14.2 | 2.2 | 0.0 | 0.2 | +20.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +45.7 | 0.0 | 5.5 | 0.3 | +28.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +105.9 | 0.0 | 91.5 | 4.4 | +180.4 | 0.0 | 117.3 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.4 | +2.1 | 11.4 | 11.0 |
| MISSILES IN THE MOVE | 3.6 | +99.5 | 0.0 | 61.8 | 2.7 | +31.2 | 0.0 | 86.6 |
| MISSILES NEXT TURN | 4.0 | +70.1 | 0.0 | 59.5 | 3.3 | +32.7 | 0.0 | 93.9 |
| MODEL FACING | 0.5 | +106.3 | 0.0 | 10.0 | 0.1 | +35.6 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 19.3 | 0.0 | 0.3 | +0.0 | 5.1 | 0.0 |
| MOVE AND CAST | 0.6 | +19.1 | 0.0 | 14.2 | 0.3 | +14.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +9.6 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -7.1 | 33.5 | 10.6 | 0.3 | -6.4 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 12.1 |
| MOVE TO CHARGE | 2.8 | +224.6 | 155.0 | 53.7 | 5.9 | +459.7 | 189.1 | 103.5 |
| MOVES UNITS SPELL | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.9 | 0.0 | 0.0 | 0.1 | +7.4 | 12.1 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.9 | 0.0 | 1.7 | - | - | - | - |
| NOT NEEDED | 0.1 | -2.8 | 14.5 | 0.0 | 0.3 | -19.0 | 40.7 | 6.6 |
| NOT TURNED | 5.1 | +97.5 | 0.0 | 152.6 | 4.1 | +122.0 | 0.0 | 61.1 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.5 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -769.5 | 0.0 | 252.6 | 14.5 | -742.4 | 0.0 | 235.6 |
| ONE YARDSTICK | - | - | - | - | 12.8 | -362.8 | 168.0 | 174.2 |
| OPENS A LANE | 0.1 | +0.9 | 0.5 | 10.6 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.5 | +62.6 | 30.4 | 14.4 |
| OVERRUNS AWAY | 0.2 | +4.7 | 28.8 | 4.2 | 0.4 | +15.7 | 31.7 | 14.6 |
| PATHS CROSS | 1.7 | +99.0 | 0.0 | 11.9 | 2.8 | +199.9 | 0.0 | 53.5 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +6.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -4.4 | 0.0 | 19.7 | 0.0 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +1681.6 | 1518.1 | 831.0 | 38.4 | +1063.2 | 1005.1 | 831.8 |
| PURSUES BIG PREY | 0.1 | -1.8 | 0.0 | 0.0 | 0.1 | -35.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.1 | +0.2 | 0.0 | 0.0 | 1.0 | +19.5 | 0.0 | 12.1 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -18.0 | 2.1 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.0 | -1.0 | 0.0 | 0.9 | 0.3 | -7.3 | 0.0 | 5.9 |
| REDIRECT COUNTER | 1.1 | +91.6 | 0.0 | 22.3 | 2.7 | +230.8 | 0.0 | 47.1 |
| REDIRECT WEIGHED | 0.2 | -1.9 | 4.6 | 2.5 | 0.3 | +5.7 | 7.3 | 1.2 |
| RESERVE FALL BACK | 0.1 | +2.4 | 0.0 | 0.0 | 0.8 | +15.0 | 0.0 | 14.8 |
| RESTRAINS TO SHOOT | 0.2 | +5.5 | 0.0 | 5.8 | 0.1 | +3.0 | 0.0 | 3.2 |
| RISK BY ARC | 1.8 | +69.1 | 165.7 | 19.6 | 2.9 | +29.9 | 220.3 | 53.1 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.4 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +51.9 | 0.0 | 21.8 | 0.6 | +23.9 | 0.0 | 26.1 |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 1.5 | 0.6 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.5 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.6 | 0.0 | 0.9 | 0.4 | -23.3 | 0.0 | 0.0 |
| SEARCH SPOT | 2.1 | +126.9 | 0.0 | 41.2 | 3.0 | +110.5 | 0.0 | 66.7 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.5 | +78.2 | 0.0 | 0.0 | 0.4 | +64.8 | 0.0 | 11.0 |
| SET UP TOGETHER | 0.7 | +69.4 | 34.0 | 3.3 | 2.3 | +295.5 | 57.5 | 43.9 |
| SET-UP ANY TARGET | 0.2 | +32.0 | 10.6 | 10.6 | 0.1 | +17.1 | 3.5 | 11.2 |
| SET-UP MISSED | 0.1 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | - | - | - | - | 3.1 | +156.4 | 110.8 | 62.2 |
| SHOOTERS IN TWO RANKS | 0.8 | +1.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 2.3 | +34.1 | 0.0 | 36.8 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +35.9 | 34.4 | 3.8 | 0.9 | +36.3 | 20.2 | 22.4 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 22.9 | +0.0 | 995.4 | 438.9 | 14.6 | +0.0 | 480.9 | 255.0 |
| SHOT REPLANNED | 1.3 | +0.0 | 315.1 | 20.0 | - | - | - | - |
| SHOTS IN THE MOVE | 20.9 | +927.7 | 0.0 | 397.4 | 13.9 | +528.7 | 0.0 | 244.5 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.0 | 3.5 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +46.8 | 10.6 | 10.6 | 0.1 | +20.1 | 6.9 | 11.2 |
| SPELL WORTH | 0.2 | +4.4 | 3.7 | 0.0 | 1.1 | +25.4 | 74.8 | 74.8 |
| STABLE ROLE | 13.5 | +0.0 | 345.1 | 163.8 | 10.5 | +0.0 | 317.5 | 127.1 |
| STAY WEIGHED | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 16.5 | +205.1 | 217.5 | 273.4 |
| STOPS | 0.0 | +0.2 | 0.0 | 3.1 | 0.2 | +4.6 | 17.9 | 2.6 |
| STOPS SHORT OF THE FLANK | 0.5 | +17.2 | 0.0 | 1.7 | 0.2 | +3.1 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 3.6 | -27.8 | 152.2 | 43.9 | 5.7 | -39.8 | 380.8 | 91.5 |
| SUPPORTS | 2.3 | +30.4 | 28.6 | 30.8 | 3.6 | +42.4 | 231.5 | 69.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -6.7 | 1.9 | 6.6 | - | - | - | - |
| SURE REACH TOGETHER | 0.5 | -1.7 | 9.6 | 1.7 | 0.4 | +4.3 | 0.0 | 7.0 |
| THROUGH LINE OF FIRE | 0.6 | +18.3 | 0.0 | 0.0 | 0.2 | +13.3 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -14.0 | 14.5 | 4.2 | 0.3 | -24.3 | 23.5 | 6.5 |
| TWO OR MORE ARRIVE | 0.2 | +3.6 | 27.5 | 0.0 | 0.7 | +6.3 | 35.6 | 15.8 |
| WAIT AFTER COSTS | 6.3 | -259.1 | 240.6 | 112.8 | 8.6 | -485.6 | 293.1 | 173.4 |
| WALKS TO THE FIGHT | 2.3 | +39.2 | 50.0 | 44.3 | 1.4 | +23.1 | 52.7 | 42.8 |
| WAR ENGINE CHARGES | 0.1 | +9.8 | 0.0 | 0.0 | 0.1 | +5.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 11.3 | 5.4 | 0.3 | +0.0 | 28.1 | 23.2 |
| WEARS DOWN | 1.1 | +33.9 | 126.7 | 9.4 | 1.0 | +24.2 | 108.8 | 19.6 |
| WHO HITS BACK | 0.1 | +4.1 | 0.0 | 0.0 | 0.1 | +17.5 | 0.0 | 3.1 |
| WHOLE FIGHT | 0.2 | +9.5 | 12.1 | 0.0 | 0.3 | +29.9 | 58.6 | 5.6 |
| WHOLE FIGHT GAIN | 0.2 | +19.0 | 44.6 | 2.6 | 0.3 | +29.5 | 29.4 | 10.2 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 16.6 | 0.0 | - | - | - | - |

### Rule changes: sf-h2h-opp-4394159-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1110 | 1110 | 1110 | 30.83 | -54429 | -49.0 |
| BEST FIRST | 325 | 325 | 325 | 9.03 | +12818 | +39.4 |
| SEARCH SPOT | 184 | 184 | 180 | 5.00 | +8544 | +47.5 |
| PATHS CROSS | 162 | 162 | 162 | 4.50 | +10758 | +66.4 |
| MOVE TO CHARGE | 312 | 312 | 158 | 4.39 | +9890 | +62.6 |
| ARTILLERY RE-ROLL WEIGHED | 152 | 152 | 152 | 4.22 | +0 | +0.0 |
| COUNTER-CHARGE COVER | 582 | 325 | 138 | 3.83 | +8914 | +64.6 |
| FIRE PLAN | 502 | 502 | 119 | 3.31 | +766 | +6.4 |
| KILLS COUNT NEXT TURN | 405 | 405 | 119 | 3.31 | +2611 | +21.9 |
| SHOTS IN THE MOVE | 1250 | 855 | 107 | 2.97 | +4245 | +39.7 |
| FACES THE THREAT | 94 | 94 | 94 | 2.61 | +8795 | +93.6 |
| CANNON SIGHT KEPT | 88 | 88 | 88 | 2.44 | +0 | +0.0 |
| EVERY WOUND COUNTS | 360 | 360 | 82 | 2.28 | +0 | +0.0 |
| WAIT AFTER COSTS | 538 | 538 | 82 | 2.28 | +1321 | +16.1 |
| FOLLOW UP WEIGHED | 81 | 81 | 81 | 2.25 | +11735 | +144.9 |
| FALLBACK BY WORTH | 385 | 385 | 80 | 2.22 | +5136 | +64.2 |
| SUPPORTS | 215 | 215 | 73 | 2.03 | +722 | +9.9 |
| WALKS TO THE FIGHT | 133 | 133 | 71 | 1.97 | +815 | +11.5 |
| CANNON PLANNED TARGET | 379 | 379 | 61 | 1.69 | -830 | -13.6 |
| SET UP TOGETHER | 110 | 96 | 59 | 1.64 | +6182 | +104.8 |
| SAFER THAN THE JOB | 52 | 52 | 52 | 1.44 | +2730 | +52.5 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +3479 | +71.0 |
| SHOT REPLANNED | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 158 | 158 | 45 | 1.25 | -2526 | -56.1 |
| BEST FACING | 44 | 44 | 44 | 1.22 | +1836 | +41.7 |
| CHARGE NOW WEIGHED | 43 | 43 | 43 | 1.19 | +4190 | +97.4 |
| BEST MOVE FOR SHOOTERS | 42 | 42 | 42 | 1.17 | +3612 | +86.0 |
| SHOOTERS IN TWO RANKS | 41 | 41 | 41 | 1.14 | +74 | +1.8 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| HONEST THREAT | 360 | 360 | 39 | 1.08 | +0 | +0.0 |
| MAX FOR POSITIONING | 302 | 163 | 39 | 1.08 | +778 | +20.0 |
| STAY WORTH | 593 | 472 | 38 | 1.06 | +455 | +12.0 |
| RESERVE FALL BACK | 34 | 34 | 34 | 0.94 | +627 | +18.4 |
| MAKE SURE TOGETHER | 65 | 48 | 33 | 0.92 | +3710 | +112.4 |
| MISSILES IN THE MOVE | 224 | 145 | 33 | 0.92 | +589 | +17.9 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 32 | 32 | 32 | 0.89 | +1138 | +35.6 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 31 | 0.86 | +825 | +26.6 |
| ADVANCE LANE KEPT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| MOVE AND CAST | 30 | 30 | 30 | 0.83 | +1196 | +39.9 |
| RISK BY ARC | 169 | 165 | 29 | 0.81 | +859 | +29.6 |
| BEST PREY | 62 | 62 | 27 | 0.75 | +892 | +33.1 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.75 | +1639 | +60.7 |
| KILLS COUNT | 111 | 110 | 26 | 0.72 | +1069 | +41.1 |
| FRIENDS SHOTS CHECKED | 25 | 25 | 25 | 0.69 | +1681 | +67.2 |
| MARCH CHECK | 29 | 27 | 25 | 0.69 | +1009 | +40.3 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +734 | +29.4 |
| ONE YARDSTICK | 462 | 168 | 24 | 0.67 | +316 | +13.2 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +5109 | +222.1 |
| BLOCKED WHEEL | 22 | 22 | 22 | 0.61 | +227 | +10.3 |
| KEEPS ITS TARGET | 123 | 122 | 22 | 0.61 | +313 | +14.2 |
| RANDOM MOVE BY FIGURES | 42 | 42 | 22 | 0.61 | +708 | +32.2 |
| FIRE IN ORDER | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| REDIRECT COUNTER | 136 | 82 | 21 | 0.58 | +2110 | +100.5 |
| CAST JOB | 45 | 45 | 20 | 0.56 | +261 | +13.1 |
| HOLDS AMBUSHERS | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| INVITES THE FIGHT | 79 | 79 | 19 | 0.53 | +199 | +10.5 |
| SHORT GUN FORWARD | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +801 | +44.5 |
| WAR ENGINE JOBS | 38 | 38 | 18 | 0.50 | -767 | -42.6 |
| KEEPS THE TARGET | 50 | 50 | 16 | 0.44 | -284 | -17.7 |
| WHOLE FIGHT GAIN | 18 | 18 | 16 | 0.44 | +717 | +44.8 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WEARS DOWN | 76 | 73 | 15 | 0.42 | +282 | +18.8 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +333 | +23.8 |
| LOST CHARGE | 170 | 170 | 12 | 0.33 | +276 | +23.0 |
| OPENS UP | 18 | 18 | 12 | 0.33 | +866 | +72.1 |
| SHOOTERS ARE THREATS | 112 | 112 | 12 | 0.33 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -48 | -4.4 |
| MANOEUVRE | 13 | 13 | 9 | 0.25 | +545 | +60.6 |
| WHO HITS BACK | 9 | 9 | 9 | 0.25 | +542 | +60.3 |
| CASTING BLOCK | 10 | 10 | 8 | 0.22 | +140 | +17.5 |
| MISSILES NEXT TURN | 264 | 157 | 8 | 0.22 | +38 | +4.8 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -161 | -20.2 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +307 | +38.4 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -12 | -1.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +96 | +13.7 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SUPPORT NARROWED | 336 | 336 | 7 | 0.19 | -184 | -26.3 |
| KEEPS SCOUTS OR AMBUSH | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -1338 | -223.0 |
| WHOLE FIGHT | 19 | 19 | 6 | 0.17 | +294 | +49.0 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -444 | -88.7 |
| DEFENSIVE ARMY | 17 | 17 | 5 | 0.14 | -154 | -30.8 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +57 | +11.4 |
| HUNT ADVANCE | 19 | 19 | 5 | 0.14 | +164 | +32.9 |
| HUNT IN PAIRS | 18 | 10 | 5 | 0.14 | +533 | +106.7 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 23 | 22 | 4 | 0.11 | +73 | +18.2 |
| SHOOTERS TO THE PRIMARY | 82 | 62 | 4 | 0.11 | +37 | +9.2 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -241 | -60.3 |
| SURE REACH TOGETHER | 31 | 22 | 4 | 0.11 | +35 | +8.7 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +22 | +7.2 |
| JOINT CHARGE PLAN | 20 | 20 | 3 | 0.08 | +550 | +183.4 |
| WAR ENGINE CHARGES | 7 | 7 | 3 | 0.08 | +203 | +67.5 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +52 | +26.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +66 | +32.8 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +45 | +22.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +221 | +110.5 |
| STOPS | 7 | 7 | 2 | 0.06 | +48 | +24.0 |
| TWO OR MORE ARRIVE | 35 | 31 | 2 | 0.06 | +71 | +35.3 |
| BACKUP TARGETS | 42 | 19 | 1 | 0.03 | +2 | +1.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +17 | +17.2 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.03 | -255 | -254.8 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +14 | +13.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +24 | +24.1 |
| GIVES UP ITS SCREEN | 1 | 1 | 1 | 0.03 | +4 | +3.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.4 |
| KEEPS ITS PREY | 5 | 5 | 1 | 0.03 | +3 | +3.1 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 31 | 31 | 1 | 0.03 | +0 | +0.1 |
| MOVE SPELL IN RANGE | 15 | 9 | 1 | 0.03 | +8 | +7.8 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +85 | +85.1 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -46 | -45.5 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +38 | +38.5 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 60 | 60 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 14 | 14 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 323 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 35 | 35 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 21 | trace | - | - | - | - |
| HUNT THE GUNS | 22 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 16 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 330 | 330 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 28 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2799 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 35 | 35 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 33 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OPTIONS | 1350 | 1350 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 47 | not checked | - | - | - | - |
| STABLE ROLE | 865 | 863 | 0 | 0.00 | - | - |
| TURN WORTH | 23 | 23 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-opp-4394159-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.58 | 13.31 | 50.1 |
| FALLBACK | gate | 0.83 | 0.58 | 51.3 |
| CHARGE NOW FIRST | rule | 0.47 | 0.72 | 58.7 |
| TURN GATE | gate | 0.58 | 0.11 | 23.5 |
| WAR ENGINE JOBS | rule | 0.39 | 0.11 | 42.6 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 79.5 |
| FIGHT ORDER BAND | gate | 0.11 | 0.17 | 2.1 |
| FIRE PLAN | rule | - | 0.28 | 58.4 |
| KEEPS THE TARGET | rule | - | 0.25 | 59.9 |
| PATHS CROSS | rule | 0.17 | 0.08 | 14.6 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.14 | 33.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.11 | 36.2 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.03 | 20.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.14 | 26.3 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 2.9 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 10.6 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 223.0 |
| BEST PRIZE | rule | 0.03 | 0.11 | 88.7 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 15.0 |
| DEFENSIVE ARMY | rule | 0.11 | - | 38.4 |
| FRIENDS SHOTS CHECKED | rule | 0.08 | 0.03 | 3.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | - | 60.3 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 31.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 6.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 75.1 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 127.4 |
| SAFER THAN THE JOB | rule | 0.06 | - | 13.7 |
| SUPPORT REQUEST | gate | - | 0.06 | 222.6 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 254.8 |
| CHAFF PASSED | rule | 0.03 | - | 12.4 |
| FACES THE THREAT | rule | - | 0.03 | 15.6 |
| MARCH ODDS | rule | - | 0.03 | 119.4 |
| NO REASON | gate | - | 0.03 | 26.7 |
| RULE SWITCHED OFF | gate | 0.03 | - | 3.8 |
| SAFE SURE CHARGE | rule | - | 0.03 | 45.5 |

### Plans: sf-h2h-opp-4394159-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.2 | 13% | 373 | 271 | 73% |
| Mine | charge | 2.2 | 65% | 197 | 237 | 121% |
| Mine | close in | 3.6 | 33% | 244 | 114 | 47% |
| Mine | hold | 5.3 | 32% | 371 | 0 | 0% |
| Mine | join | 0.8 | 93% | 20 | 0 | 0% |
| Mine | shoot | 13.8 | 62% | 391 | 1062 | 271% |
| Mine | support | 2.4 | 91% | 15 | 0 | 0% |
| Opponent | advance | 12.8 | 12% | 407 | 270 | 66% |
| Opponent | charge | 3.8 | 59% | 401 | 329 | 82% |
| Opponent | close in | 6.1 | 20% | 615 | 156 | 25% |
| Opponent | hold | 4.9 | 42% | 329 | 0 | 0% |
| Opponent | join | 0.2 | 100% | 8 | 0 | 0% |
| Opponent | shoot | 6.1 | 51% | 275 | 315 | 115% |
| Opponent | support | 4.2 | 88% | 27 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-opp-4394159-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 7 | 0 | 0% | 0% | 0% | - | 344 | 0 | 0% | 53 |
| Opponent | 0.4 | 15 | 1 | 14% | 21% | 0% | 2.0 | 334 | 71 | 21% | 94 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2.5 | 5 | 0 | 0% | 0% | 0% | - | 289 | 0 | 0% | 94 |
| Chaos Dwarfs | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 439 | 0 | 0% | 94 |
| Dwarfen Mountain Holds | 0.3 | 4 | 1 | 33% | 33% | 0% | 2.0 | 297 | 88 | 33% | 86 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 68 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 396 | 0 | 0% | 9 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 246 |
| Ogre Kingdoms | 1.2 | 6 | 0 | 17% | 17% | 0% | 2.0 | 368 | 72 | 17% | 54 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 350 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.0 | 4 | 0 | 0% | 25% | 0% | 2.0 | 352 | 75 | 25% | 18 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 163 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 63 |

### Battle groups: sf-h2h-opp-4394159-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 25% | 59% | 5% | 75% | 33% | 7% | 12% | 48% | 0% |
| Mine | REDIRECT COUNTER | 1.1 | 25% | 30% | 10% | 0% | 33% | 0% | 11% | 56% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.3 | 15% | 60% | 14% | 40% | 40% | 10% | 3% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 21% | 75% | 5% | 0% | 26% | 0% | 16% | 58% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-opp-4394159-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 64 | 50% | 3.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Mine | Chaff | 15 | 16 (15) | 10 | 6 | 74 | 33% | 2.7 | 32 (7) | 0 (4) | 0 (4) | 21 (11) | 0 (4) |
| Mine | Character | 123 | 49 (123) | 49 | 0 | 28 | 21% | 2.4 | 67 (47) | 49 (58) | 6 (7) | 49 (79) | 60 (33) |
| Mine | Clean-up | 22 | 73 (22) | 23 | 50 | 54 | 45% | 3.0 | 108 (6) | 35 (10) | 68 (6) | 84 (17) | 36 (5) |
| Mine | Fast | 6 | 7 (6) | 7 | 0 | 85 | 17% | 1.6 | - | 9 (5) | 0 (1) | 0 (5) | 50 (1) |
| Mine | Fast Hammer | 34 | 54 (34) | 14 | 40 | 44 | 35% | 3.0 | 36 (13) | 78 (15) | 32 (6) | 46 (27) | 78 (7) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 69 | 37 (69) | 25 | 12 | 33 | 19% | 2.6 | 30 (14) | 43 (47) | 17 (8) | 44 (45) | 27 (24) |
| Mine | Holder | 12 | 101 (12) | 0 | 101 | 30 | 75% | 4.3 | 0 (3) | 113 (7) | 214 (2) | 195 (5) | 27 (7) |
| Mine | Shooter | 52 | 73 (52) | 35 | 37 | 39 | 4% | 2.1 | 1 (12) | 114 (28) | 31 (12) | 100 (28) | 40 (24) |
| Mine | War machine | 113 | 26 (113) | 26 | 0 | 43 | 4% | 1.2 | 32 (34) | 26 (70) | 0 (9) | 18 (30) | 29 (83) |
| Mine | Wizard | 19 | 12 (19) | 12 | 0 | 31 | 47% | 2.6 | 18 (5) | 8 (11) | 0 (1) | 11 (4) | 10 (13) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 72 | 62 (72) | 26 | 36 | 59 | 40% | 2.5 | 27 (28) | 61 (13) | 96 (31) | 94 (48) | 5 (24) |
| Opponent | Character | 93 | 49 (93) | 49 | 0 | 30 | 20% | 2.7 | 64 (39) | 48 (38) | 10 (6) | 45 (48) | 62 (35) |
| Opponent | Clean-up | 31 | 24 (31) | 7 | 17 | 25 | 35% | 2.6 | 27 (11) | 18 (17) | 39 (3) | 32 (21) | 8 (10) |
| Opponent | Early | 2 | 37 (2) | 37 | 0 | 50 | 0% | 4.5 | - | 37 (2) | - | 73 (1) | 0 (1) |
| Opponent | Fast | 5 | 86 (5) | 86 | 0 | 35 | 20% | 1.8 | - | 23 (4) | 383 (1) | 164 (3) | 0 (2) |
| Opponent | Fast Hammer | 39 | 43 (39) | 27 | 17 | 26 | 31% | 3.2 | 24 (15) | 57 (15) | 54 (9) | 43 (27) | 44 (12) |
| Opponent | Fragile | 12 | 0 (12) | 0 | 0 | 36 | 50% | 2.8 | 0 (2) | 0 (8) | 0 (2) | 0 (3) | 0 (9) |
| Opponent | Hammer | 58 | 25 (58) | 23 | 2 | 48 | 24% | 2.4 | 25 (13) | 27 (40) | 4 (5) | 31 (30) | 18 (28) |
| Opponent | Holder | 31 | 76 (31) | 3 | 72 | 13 | 32% | 2.5 | 64 (9) | 81 (15) | 91 (6) | 115 (16) | 25 (14) |
| Opponent | Shooter | 34 | 66 (34) | 11 | 55 | 37 | 12% | 1.4 | 21 (9) | 97 (21) | 37 (4) | 82 (23) | 42 (11) |
| Opponent | War machine | 26 | 63 (26) | 63 | 0 | 33 | 4% | 1.5 | 75 (6) | 46 (18) | 176 (2) | 80 (7) | 57 (19) |
| Opponent | Wizard | 28 | 17 (28) | 17 | 0 | 48 | 7% | 2.0 | 18 (8) | 36 (8) | 0 (4) | 13 (9) | 35 (11) |

### Charged fights: sf-h2h-opp-4394159-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 137 | 234 | 1.5 | 1.0 | 156 | 0 | +156 | 0 of 3 | 3 of 3 | - | +156 |
| Mine | Chaos Dwarfs | 8 | 202 | 94 | 1.1 | 1.2 | 84 | 47 | +36 | 4 of 9 | 6 of 9 | +657 | -41 |
| Mine | Dwarfen Mountain Holds | 11 | 454 | 101 | 1.9 | 1.0 | 53 | 9 | +44 | 7 of 21 | 14 of 21 | +0 | +46 |
| Mine | Empire of Man | 8 | 192 | 196 | 1.5 | 1.0 | 131 | 10 | +120 | 3 of 12 | 9 of 12 | - | +120 |
| Mine | Grand Cathay | 1 | 219 | 1006 | 6.0 | 1.2 | 168 | 0 | +168 | 2 of 6 | 6 of 6 | +234 | +154 |
| Mine | High Elf Realms | 5 | 122 | 810 | 4.2 | 1.2 | 193 | 3 | +190 | 8 of 21 | 20 of 21 | +325 | +167 |
| Mine | Ogre Kingdoms | 1 | 65 | 35 | 8.0 | 1.2 | 4 | 73 | -69 | 3 of 8 | 4 of 8 | -45 | -77 |
| **Mine** | all armies | 36 | 259 | 250 | 2.2 | 1.1 | 112 | 17 | +95 | 27 of 80 | 62 of 80 | +222 | +81 |
| Opponent | Chaos Dwarfs | 1 | 85 | 480 | 5.0 | 1.0 | 96 | 0 | +96 | 4 of 5 | 4 of 5 | - | +96 |
| Opponent | Dwarfen Mountain Holds | 2 | 422 | 115 | 0.5 | 1.0 | 230 | 60 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| Opponent | Empire of Man | 4 | 371 | 234 | 2.2 | 1.2 | 104 | 0 | +104 | 3 of 9 | 5 of 9 | +208 | +74 |
| Opponent | Grand Cathay | 1 | 345 | 621 | 6.0 | 1.2 | 104 | 0 | +104 | 3 of 6 | 4 of 6 | +301 | +64 |
| Opponent | High Elf Realms | 2 | 138 | 573 | 3.0 | 1.7 | 191 | 0 | +191 | 2 of 6 | 6 of 6 | +154 | +209 |
| Opponent | Lizardmen | 2 | 62 | 830 | 4.0 | 1.2 | 208 | 0 | +208 | 6 of 8 | 7 of 8 | +427 | +176 |
| Opponent | Ogre Kingdoms | 4 | 72 | 182 | 3.8 | 1.1 | 49 | 26 | +23 | 5 of 15 | 4 of 15 | +265 | +5 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 677 | 3.0 | 1.3 | 226 | 0 | +226 | 2 of 3 | 2 of 3 | +65 | +306 |
| Opponent | Skaven | 2 | 48 | 20 | 1.0 | 1.0 | 20 | 32 | -12 | 0 of 2 | 1 of 2 | - | -12 |
| Opponent | Tomb Kings of Khemri | 4 | 43 | 708 | 3.2 | 1.4 | 218 | 44 | +174 | 9 of 13 | 11 of 13 | +181 | +171 |
| Opponent | Vampire Counts | 3 | 0 | 372 | 4.3 | 1.2 | 86 | 23 | +63 | 7 of 13 | 7 of 13 | +214 | +35 |
| Opponent | Warriors of Chaos | 6 | 0 | 575 | 3.0 | 1.0 | 192 | 26 | +166 | 9 of 18 | 13 of 18 | - | +166 |
| Opponent | Wood Elf Realms | 4 | 70 | 226 | 3.0 | 1.1 | 75 | 46 | +29 | 5 of 12 | 6 of 12 | +0 | +31 |
| **Opponent** | all armies | 36 | 111 | 412 | 3.1 | 1.2 | 134 | 22 | +112 | 55 of 111 | 71 of 111 | +196 | +99 |

### Effective charges: sf-h2h-opp-4394159-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 0 | 1 (net +55) | 2 (net +206) | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 9 | 1 (net -112) | 0 | 1 (net +0) | 3 (net +219) | 0 | 4 (net -55) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 21 | 1 (net +0) | 1 (net +0) | 5 (net -3) | 4 (net +0) | 0 | 8 (net +85) | 2 | 26% (5 of 19) |
| Mine | Empire of Man | 12 | 3 (net +61) | 0 | 1 (net +0) | 2 (net +64) | 0 | 3 (net +128) | 3 | 11% (1 of 9) |
| Mine | Grand Cathay | 6 | 0 | 1 (net +335) | 3 (net +194) | 1 (net +0) | 1 (net +90) | 0 | 0 | 50% (3 of 6) |
| Mine | High Elf Realms | 21 | 0 | 0 | 4 (net +14) | 6 (net +314) | 4 (net +130) | 7 (net +218) | 0 | 19% (4 of 21) |
| Mine | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +35) | 2 (net +0) | 0 | 3 (net -76) | 2 | 17% (1 of 6) |
| Opponent | Chaos Dwarfs | 5 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +110) | 0 | 0 | 2 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 1 (net +170) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 9 | 0 | 0 | 1 (net +95) | 6 (net +91) | 2 (net +146) | 0 | 0 | 11% (1 of 9) |
| Opponent | Grand Cathay | 6 | 2 (net +0) | 0 | 1 (net +105) | 3 (net +172) | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | High Elf Realms | 6 | 1 (net +677) | 0 | 2 (net +32) | 0 | 2 (net +154) | 0 | 1 | 40% (2 of 5) |
| Opponent | Lizardmen | 8 | 1 (net +240) | 0 | 0 | 1 (net +73) | 1 (net +427) | 2 (net +132) | 3 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 15 | 4 (net +31) | 0 | 2 (net +0) | 0 | 0 | 2 (net +132) | 7 | 25% (2 of 8) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net +612) | 0 | 0 | 0 | 1 (net +65) | 0 | 1 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 1 (net -25) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 3 (net +277) | 1 (net +0) | 0 | 3 (net +67) | 1 (net +177) | 4 (net +169) | 1 | 0% (0 of 12) |
| Opponent | Vampire Counts | 13 | 6 (net +34) | 0 | 1 (net +0) | 2 (net +0) | 2 (net +306) | 2 (net +0) | 0 | 8% (1 of 13) |
| Opponent | Warriors of Chaos | 18 | 3 (net +88) | 0 | 3 (net +135) | 2 (net +318) | 2 (net +90) | 7 (net +203) | 1 | 18% (3 of 17) |
| Opponent | Wood Elf Realms | 12 | 0 | 0 | 3 (net -71) | 2 (net +30) | 1 (net +0) | 1 (net +238) | 5 | 43% (3 of 7) |

### Charged fights, damage counted: sf-h2h-opp-4394159-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 184 | 240 | +14 | 65 | 77 | -12 | -6.6 |
| Mine | 50-54% | 2 | 237 | 244 | +168 | 168 | 0 | +168 | +70.7 |
| Mine | Effective (55-75%) | 15 | 158 | 133 | +44 | 63 | 31 | +33 | +20.6 |
| Mine | 76-89% | 18 | 310 | 259 | +148 | 193 | 18 | +174 | +56.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 213 | 163 | +95 | 135 | 29 | +106 | +49.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 411 | 80 | +110 | 113 | 0 | +113 | +27.5 |
| Mine | No odds | 7 | 171 | 201 | +92 | 169 | 70 | +98 | +57.4 |
| Mine | All fights | 80 | 235 | 183 | +95 | 132 | 31 | +101 | +43.2 |
| Opponent | Long shot (under 50%) | 24 | 258 | 239 | +129 | 218 | 88 | +131 | +50.6 |
| Opponent | 50-54% | 2 | 375 | 371 | +0 | 0 | 89 | -89 | -23.6 |
| Opponent | Effective (55-75%) | 13 | 203 | 185 | +35 | 96 | 67 | +29 | +14.3 |
| Opponent | 76-89% | 20 | 285 | 141 | +107 | 111 | 7 | +104 | +36.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 362 | 222 | +159 | 215 | 34 | +181 | +50.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 613 | 128 | +172 | 174 | 23 | +151 | +24.6 |
| Opponent | No odds | 22 | 206 | 177 | +81 | 119 | 25 | +93 | +45.2 |
| Opponent | All fights | 111 | 303 | 191 | +112 | 156 | 43 | +113 | +37.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-opp-4394159-p4 | move | 412 | 97 (24%) | 72 (17%) | 32 (8%) | 283 (69%) |
| sf-h2h-opp-4394159-p4 | objective | 352 | 50 (14%) | 41 (12%) | 58 (16%) | 244 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0122 |
| Charmed Shield | Opponent | L0525, L1525, L1526 |
| Elixir of Power | Opponent | L0519 |
| Fistful of Laurels | Mine | L1820 |
| Fistful of Laurels | Opponent | L0318, L0918, L1018, L1418 |
| Horn of the Wild Hunt | Opponent | L0533, L0633 |
| Invocation of Nehek | Opponent | L0525, L1525 |
| Opal Amulet | Mine | L1418 |
| Periapt of Soul Exchange | Opponent | L0521, L1820 |
| Ring of Doom | Mine | L0208, L1522, L1525, L1526 |
| Ring of Doom | Opponent | L0415, L0515, L0533, L0633 |
| Ring of Jet | Mine | L1018 |
| Ring of Jet | Opponent | L0610 |
| Standard of the Fell Warrior | Mine | L1322 |
| Storm Daemon (Renegade 2.0) | Opponent | L0521 |
| Twice-Blessed Armour | Mine | L0709, L0723, L0728, L0732, L1018 |
| Twice-Blessed Armour | Opponent | L0607, L0610 |
| Witch Hunter's Ward | Mine | L0709, L0723, L0728, L0732 |
| Witch Hunter's Ward | Opponent | L0208, L0607 |

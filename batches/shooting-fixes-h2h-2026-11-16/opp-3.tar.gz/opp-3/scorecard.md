# Doctrine scorecard: sf-h2h-opp-4394159-p3

### Scorecard: sf-h2h-opp-4394159-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0203 | 5 | 1 | Mine | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 170 |
| L0203 | 5 | 1 | Opponent | yes | - | 5 | 2 | 2 | 1 | 0 | 0 | 675 |
| L0215 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0215 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 104 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 760 |
| L0308 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 1 | 0 | 0 | 605 |
| L0313 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0313 | 1 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 958 |
| L0528 | 6 | 1 | Mine | yes | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0613 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 801 |
| L0613 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 140 |
| L0617 | 5 | 1 | Mine | no | - | - | 4 | 1 | 0 | 0 | 0 | 615 |
| L0617 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 2 | - | 2 | 3 | 1 | 0 | 0 | 801 |
| L0621 | 3 | 1 | Opponent | yes | 8 | 5 | 1 | 5 | 0 | 0 | 0 | 500 |
| L0711 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0711 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 250 |
| L0722 | 2 | 1 | Opponent | - | - | 1 | 3 | 0 | 1 | 0 | 0 | 55 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 679 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 115 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0822 | 6 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 515 |
| L0822 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 1 | 0 | 0 | 72 |
| L0826 | 4 | 1 | Mine | yes | 4 | - | 0 | 1 | 1 | 0 | 0 | 560 |
| L0826 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 2 | 0 | 0 | 0 |
| L0829 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 679 |
| L0829 | 1 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0834 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0834 | 6 | 1 | Opponent | no | 4 | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0920 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 492 |
| L0920 | 2 | 1 | Opponent | - | - | - | 3 | 5 | 2 | 0 | 0 | 210 |
| L0921 | 3 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 537 |
| L0921 | 3 | 1 | Opponent | yes | 4 | 3 | 2 | 5 | 0 | 0 | 0 | 145 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 713 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 55 |
| L0931 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0931 | 1 | 1 | Opponent | no | 6 | - | 3 | 0 | 1 | 0 | 0 | 0 |
| L1022 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 497 |
| L1022 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1115 | 5 | 1 | Mine | yes | - | 1 | 4 | 0 | 1 | 0 | 0 | 427 |
| L1115 | 5 | 1 | Opponent | yes | - | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Mine | yes | - | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Opponent | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 72 |
| L1518 | 6 | 1 | Mine | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1518 | 6 | 1 | Opponent | no | 10 | 3 | 3 | 2 | 2 | 0 | 0 | 297 |
| L1524 | 6 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 60 |
| L1524 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 6 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 70 |
| L1829 | 5 | 1 | Mine | no | - | 6 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 170 |
| L1834 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1834 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 716 |
| L2227 | 1 | 1 | Mine | no | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 2 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 1.9 | 3.0 | 2.3 | 1.0 | 0.2 | 0.0 | 0.0 | 377.0 |
| **Average** | | | Opponent | 41% | 3.2 | 2.4 | 2.1 | 1.6 | 0.5 | 0.0 | 0.0 | 181.1 |

### KPIs: sf-h2h-opp-4394159-p3

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (82 of 175) | 12% (21 of 178) | 29% (103 of 353) |
| Winner chose to follow up after the loser gave ground |  | 100% (44 of 44); on the table 100% | 100% (60 of 60); on the table 100% | 100% (104 of 104); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 100% (11 of 11); on the table 100% | 95% (19 of 20); on the table 95% |
| Winner chose to pursue after the loser fled |  | 92% (23 of 25); on the table 96% | 69% (25 of 36); on the table 78% | 79% (48 of 61); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 96% (75 of 78); on the table 97% | 90% (96 of 107); on the table 93% | 92% (171 of 185); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 36% (75 of 210) | 30% (52 of 174) | 33% (127 of 384) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (75 of 162) | 41% (52 of 126) | 44% (127 of 288) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 39% (28 of 72) | 26% (25 of 96) | 32% (53 of 168) |
|     round 1 |  | 25% (3 of 12) | 12% (2 of 16) | 18% (5 of 28) |
|     rounds 2+ |  | 42% (25 of 60) | 29% (23 of 80) | 34% (48 of 140) |
|   other wizards | 50%+ | 34% (47 of 138) | 35% (27 of 78) | 34% (74 of 216) |
|     round 1 |  | 9% (2 of 23) | 31% (4 of 13) | 17% (6 of 36) |
|     rounds 2+ |  | 39% (45 of 115) | 35% (23 of 65) | 38% (68 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (12 of 16) | 68% (42 of 62) | 69% (54 of 78) |
| Points that never fought | lower | 41% (29156 of 70695) | 40% (29150 of 71984) | 41% (58306 of 142679) |
|   infantry points that never fought | lower | 45% (7107 of 15862) | 60% (8243 of 13803) | 52% (15350 of 29665) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (182 of 314) | 51% (137 of 267) | 55% (319 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 84% (16 of 19); 1.4 uses a game | 94% (16 of 17); 1.6 uses a game | 89% (32 of 36); 1.5 uses a game |
| Bound items with another spell used |  | 40% (6 of 15); 0.4 uses a game | 40% (2 of 5); 0.1 uses a game | 40% (8 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 45% (5 of 11); 0.1 uses a game | 45% (14 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32872 of 60076) | 47% (29156 of 62051) | 51% (62028 of 122127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (46%) | 0.9 (27%) | 2.6 (37%) |
| MARCHED: its unit marched | 0.6 (17%) | 0.8 (22%) | 1.4 (19%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.7 (19%) | 0.7 (20%) | 1.4 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| GONE: slain | 0.3 (9%) | 0.5 (16%) | 0.9 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.2 | 1.9 | 3.5 | 0.2 | 1.8 |
| not cast | 3.2 | 2.0 | 2.6 | 7.1 | 0.8 | 16.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (31%) | 0.2 (7%) | 2.6 (37%) | 0.1 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (19%) | 0.2 (31%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (8%) | 0.5 (18%) | 1.4 (19%) | 0.3 (34%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (10%) | 0.4 (21%) | 0.5 (20%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) | 0.2 (3%) | 0.1 (7%) | 0.3 (2%) |
| GONE: slain | 1.1 (33%) | 0.2 (8%) | 0.4 (16%) | 0.9 (12%) | 0.0 (0%) | 2.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (4%) | 0.1 (4%) | 0.2 (3%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) | 0.0 (0%) | 0.1 (17%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (50%) | 0.0 (1%) | 0.9 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.2 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 56% (18 of 32) | 71% (5 of 7) | 59% (23 of 39) |
| the unit moved after it | 78% (14 of 18) | 100% (5 of 5) | 83% (19 of 23) |
| it charged on its next turn | 17% (3 of 18) | 0% (0 of 5) | 13% (3 of 23) |
| the enemy charged it first | 17% (3 of 18) | 0% (0 of 5) | 13% (3 of 23) |
| it fought by the end of its next turn | 11% (2 of 18) | 20% (1 of 5) | 13% (3 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (4 of 18) | 0% (0 of 5) | 17% (4 of 23) |
| none of these (no charge, no fight, no charge escaped) | 44% (8 of 18) | 80% (4 of 5) | 52% (12 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (809 of 1229) | 62% (528 of 847) | 64% (1337 of 2076) |
|   cavalry | 62% (64 of 103) | 74% (75 of 101) | 68% (139 of 204) |
|   character | 60% (72 of 121) | 21% (30 of 141) | 39% (102 of 262) |
|   chariot | 56% (87 of 155) | 64% (58 of 90) | 59% (145 of 245) |
|   infantry | 52% (167 of 321) | 69% (244 of 353) | 61% (411 of 674) |
|   monster | 59% (36 of 61) | 54% (19 of 35) | 57% (55 of 96) |
|   war machine | 82% (383 of 468) | 80% (102 of 127) | 82% (485 of 595) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.9 (33%) | 1.5 (17%) | 5.4 (26%) |
| CHARGED: it charged | 1.3 (11%) | 2.0 (22%) | 3.2 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (9%) | 0.6 (7%) | 1.7 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.2 (19%) | 1.7 (19%) | 3.9 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.8 (8%) | 1.2 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (15%) | 1.8 (20%) | 3.5 (17%) |
| SHELTERED: the target was sheltered | 0.5 (4%) | 0.2 (3%) | 0.8 (4%) |
| OTHER BAR | 0.2 (2%) | 0.3 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.2 | 2.3 | 77% | 5.3 pts | 39 pts |
| character | 3.4 | 1.3 | 74% | 9.8 pts | 34 pts |
| chariot | 4.0 | 2.5 | 63% | 12.3 pts | 50 pts |
| infantry | 15.5 | 6.1 | 72% | 9.6 pts | 149 pts |
| monster | 1.9 | 0.8 | 73% | 8.1 pts | 16 pts |
| war machine | 13.5 | 11.6 | 61% | 30.2 pts | 407 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.5 | 4.4 |
| Charges that made contact a game | 2.8 | 4.1 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.64 declared, 0.57 contact (14 units) | 0.83 declared, 0.72 contact (18 units) | 0.75 declared, 0.66 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.83 contact (6 units) | 1.00 declared, 1.00 contact (6 units) | 0.92 declared, 0.92 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.33 contact (262 units) | 0.61 declared, 0.44 contact (290 units) | 0.51 declared, 0.39 contact (552 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 45% (26 of 58) | 44% (8 of 18) | 62% (8 of 13) | 47% (42 of 89) |
| Character in a unit | 80% (33 of 41) | 82% (9 of 11) | 67% (2 of 3) | 80% (44 of 55) |
| Character on its own | 81% (26 of 32) | 58% (11 of 19) | 25% (15 of 59) | 47% (52 of 110) |
| Chariot | 67% (16 of 24) | 60% (15 of 25) | - | 63% (31 of 49) |
| Infantry | 47% (38 of 81) | 41% (11 of 27) | 33% (3 of 9) | 44% (52 of 117) |
| Monster | 58% (18 of 31) | 56% (5 of 9) | - | 58% (23 of 40) |
| Monstrous | 100% (5 of 5) | 56% (10 of 18) | - | 65% (15 of 23) |
| War Machines | 59% (55 of 93) | 100% (5 of 5) | - | 61% (60 of 98) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 91% (10 of 11); on the table 91% | 29% (12 of 42) | 37% | 72% (13 of 18) | 83% (5 of 6); 4.0 uses a game | 0.0 uses a game | 50% (3 of 6); 1.0 uses a game |
| Chaos Dwarfs | 6 | 90% (9 of 10); on the table 100% | 41% (22 of 54) | 53% | 58% (28 of 48) | 0.0 uses a game | 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (13 of 13); on the table 100% | - | 57% | 62% (29 of 47) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 16 | 93% (27 of 29); on the table 97% | 40% (31 of 78) | 49% | 59% (100 of 170) | 0.0 uses a game | 100% (3 of 3); 0.6 uses a game | 36% (4 of 11); 0.2 uses a game |
| Grand Cathay | 3 | 100% (9 of 9); on the table 100% | 38% (25 of 66) | 32% | 62% (16 of 26) | 83% (5 of 6); 7.3 uses a game | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| High Elf Realms | 11 | 88% (15 of 17); on the table 88% | 36% (15 of 42) | 32% | 47% (38 of 81) | 100% (16 of 16); 5.3 uses a game | 25% (4 of 16); 0.5 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 67% (2 of 3); on the table 67% | - | 42% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 92% (12 of 13); on the table 92% | 25% (3 of 12) | 29% | 54% (19 of 35) | 80% (4 of 5); 1.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 39% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 86% (6 of 7); on the table 100% | 28% (5 of 18) | 57% | 56% (14 of 25) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 7 | 95% (20 of 21); on the table 95% | 8% (1 of 12) | 33% | 46% (16 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 96% (22 of 23); on the table 100% | 19% (7 of 36) | 16% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 90% (18 of 20); on the table 90% | 50% (6 of 12) | 43% | 44% (18 of 41) | 100% (1 of 1); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 86% (6 of 7); on the table 86% | - | 51% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-opp-4394159-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (41) | 44% (24) | 44% (65) |
| ...free all their last turn and able to turn (per game) | 0.86 | 0.50 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.36 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.17 | 1.08 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.56 | 0.69 | 2.25 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.61 | 5.61 | 11.22 |

### Quality by phase: sf-h2h-opp-4394159-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 59% (69 of 116) | 51% (94 of 186) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (232 of 505) | 39% (113 of 287) |
| Strategy | Close-in objectives charged next turn | 11% (15 of 135) | 17% (32 of 190) |
| Strategy | Support requests answered (helper made contact too) | 27% (3 of 11) | 54% (20 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 46% (6 of 13) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 45% (25 of 56) | 30% (10 of 33) |
| Strategy | Lone characters that fought | 59% (47 of 79) | 75% (66 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.0 | 1.6 |
| Movement | Points that never moved of their own | 377.0 | 181.1 |
| Movement | Fights charged into per game | 2.5 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 81, net +101 | 13 of 104, net +98 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 81, net +8 | 13 of 104, net +142 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 81, net +40 | 7 of 104, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 81, net +102 | 47 of 104, net +153 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.9 | 13.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (214 of 464) | 35% (171 of 483) |
| Shooting | Points destroyed by shooting units | 156.4 | 60.3 |
| Shooting | War machine shots | 10.6 | 2.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (224 of 383) | 46% (47 of 102) |
| Shooting | Points destroyed by war machines | 161.2 | 79.0 |
| Magic | Magic missiles cast | 1.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 49% (22 of 45) | 41% (13 of 32) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.8 |
| Magic | Wounds caused by other spells | 0.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 34.6 | 37.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.5 / 0.5 / 0.0 | 1.6 / 0.2 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 266.2 | 350.2 |
| Combat | Points run down | 86.5 | 152.5 |
| Combat | Net points per charged fight, damage counted | +83 | +115 |
| Combat | Net per 100 charger points, damage counted | +37.5 | +34.6 |
| Combat | First round won (charged fights) | 66% | 76% |
| Combat | Net points per charged fight | +74 | +119 |
| Combat | Net points per supported fight / lone fight | +38 / +77 | +147 / +112 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 91 | 59 of 117 |
| Game | Points lost | 802.2 | 736.7 |
| Game | VP from objectives | 520.0 | 673.6 |
| Game | Lone holders (player turns) | 1.9 | 3.2 |

- Mine won / drew / lost: 12 / 3 / 21 of 36 ended games (of 36); mean margin (Mine - Opponent) -263 VP
- The side that went first won 11 of 33 games with a winner
- Points traded per game (both sides' losses): 1539
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-opp-4394159-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 40.8 | 0.6 | +0.0 | 0.0 | 7.8 |
| BACKUP TARGETS | 1.0 | +7.7 | 0.0 | 20.6 | 0.9 | +10.1 | 0.0 | 18.9 |
| BEST FACING | 1.1 | +90.7 | 0.0 | 35.2 | 0.6 | +20.1 | 0.0 | 4.7 |
| BEST FIRST | 4.4 | +209.9 | 148.4 | 88.8 | 4.8 | +168.5 | 170.1 | 55.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.8 | +49.9 | 0.0 | 2.4 |
| BEST OVERALL | 1.0 | +61.0 | 0.0 | 33.7 | 0.4 | +33.2 | 0.0 | 14.9 |
| BEST PREY | 0.9 | +48.8 | 25.1 | 25.7 | 1.1 | +64.7 | 38.2 | 31.8 |
| BEST PRIZE | 0.1 | +1.3 | 6.5 | 0.0 | 0.1 | -0.5 | 2.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 12.3 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 22.0 | 0.0 | 0.1 | +0.0 | 12.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +4.5 | 0.0 | 18.2 | 0.3 | -8.5 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.4 | +0.0 | 218.8 | 37.6 | - | - | - | - |
| CANNON PLANNED TARGET | 7.9 | +274.4 | 920.8 | 131.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 6.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.9 | 0.0 | 1.1 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 8.2 | 1.7 | 0.2 | -1.6 | 6.5 | 17.9 |
| CAST JOB | 1.0 | +21.3 | 69.7 | 2.4 | 0.6 | +24.0 | 74.4 | 2.4 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +29.4 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 13.6 | 0.3 | +0.0 | 0.0 | 33.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.8 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.6 | 3.8 | 7.4 | - | - | - | - |
| CHARGE NOW FIRST | 2.2 | +0.0 | 194.2 | 64.4 | 3.5 | +0.0 | 364.6 | 127.8 |
| CHARGE NOW WEIGHED | 0.2 | -24.5 | 25.4 | 0.0 | 0.6 | -48.1 | 18.0 | 37.8 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.5 | 8.2 | 0.0 | 0.1 | -0.7 | 8.6 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 12.2 | 3.7 | 0.2 | +0.0 | 22.5 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 23.9 | 35.1 | 0.4 | +0.0 | 29.6 | 19.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +100.0 | 0.0 | 16.0 | 0.1 | +18.2 | 11.1 | 11.1 |
| COUNTER-CHARGE COVER | 10.6 | +964.4 | 0.0 | 322.2 | 8.0 | +706.6 | 0.0 | 186.3 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 18.7 | 2.5 | 0.1 | +0.0 | 56.9 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.5 | 6.4 | 0.9 | 0.1 | +5.6 | 7.6 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | - | - | - | - | 10.1 | +0.0 | 543.1 | 134.8 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| FACES THE THREAT | 2.2 | +201.7 | 0.0 | 79.7 | 1.1 | +108.8 | 0.0 | 27.6 |
| FALLBACK BY WORTH | 4.5 | +49.8 | 0.0 | 89.6 | 6.2 | +69.7 | 0.0 | 112.4 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 16.1 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 3.1 |
| FIRE IN ORDER | - | - | - | - | 0.5 | +0.0 | 39.8 | 12.1 |
| FIRE PLAN | - | - | - | - | 15.4 | +110.6 | 880.8 | 228.6 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 251.7 | 5.5 | +0.0 | 0.0 | 154.4 |
| FOLLOW UP WEIGHED | 0.6 | +64.9 | 0.0 | 8.1 | 1.2 | +155.7 | 0.0 | 75.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +19.9 | 0.0 | 8.6 | 0.2 | +18.5 | 0.0 | 5.1 |
| GIVES UP | 0.0 | -0.1 | 7.4 | 0.0 | 0.2 | -2.5 | 25.5 | 5.1 |
| GIVES UP ITS SCREEN | 0.1 | -0.6 | 0.0 | 1.1 | 0.1 | -1.8 | 16.2 | 0.0 |
| GROUND FLIERS | 0.1 | +2.6 | 0.0 | 7.5 | 0.0 | +0.7 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 23.5 | 1.2 |
| HELPER UNSEEN | 0.1 | +0.0 | 32.4 | 0.0 | 0.4 | +0.0 | 61.8 | 7.8 |
| HILL BY ITS CHANCE | 0.4 | -62.7 | 0.0 | 5.2 | 0.4 | -40.8 | 0.0 | 5.9 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 10.1 | +1299.1 | 543.1 | 134.8 |
| HUNT ADVANCE | 0.5 | +3.7 | 15.3 | 9.1 | 0.4 | +29.9 | 3.5 | 9.6 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 0.0 | 3.0 |
| HUNT IN PAIRS | - | - | - | - | 0.6 | +34.7 | 0.0 | 24.7 |
| HUNT KEPT | 0.3 | +2.3 | 21.4 | 4.8 | 0.2 | +14.5 | 3.5 | 5.6 |
| HUNT RESULT | 0.4 | +54.3 | 11.1 | 9.1 | 0.2 | +7.1 | 3.5 | 12.2 |
| HUNT THE GUNS | 0.4 | +118.8 | 3.1 | 10.6 | 0.3 | +142.4 | 0.0 | 6.4 |
| INVITES THE FIGHT | 1.5 | +33.1 | 74.6 | 4.9 | 1.2 | +20.5 | 45.6 | 28.4 |
| JOINT CHARGE PLAN | 0.1 | +0.5 | 8.2 | 0.0 | 0.1 | +3.3 | 0.0 | 1.7 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.3 | 6.0 | 0.0 | 0.0 | +0.4 | 0.0 | 5.8 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 110.8 | 22.2 | 1.9 | +55.8 | 144.8 | 100.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 1.0 | +8.6 | 146.2 | 16.2 |
| KILLS COUNT | 1.6 | +51.1 | 106.3 | 47.9 | 2.1 | +85.6 | 223.2 | 35.6 |
| KILLS COUNT NEXT TURN | 5.3 | +188.5 | 194.1 | 158.9 | 6.9 | +284.8 | 226.7 | 242.7 |
| LONE CHARACTER SAFE SPOT | 0.5 | +5.6 | 20.9 | 5.0 | 0.2 | +17.8 | 0.0 | 11.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 0.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +33.8 | 0.0 | 1.7 | 0.5 | +45.6 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -9.7 | 11.2 | 1.1 | 0.6 | -2.8 | 46.0 | 9.9 |
| LOST CHARGE | 3.2 | -54.6 | 103.0 | 121.1 | 1.8 | -39.0 | 84.1 | 51.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.2 |
| MAKE SURE TOGETHER | 0.6 | +51.2 | 26.6 | 45.2 | 0.9 | +88.8 | 2.4 | 51.4 |
| MANOEUVRE | 0.2 | +5.4 | 0.0 | 2.9 | 0.3 | +10.9 | 0.0 | 3.2 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +41.4 | 0.0 | 6.9 | 0.2 | +6.7 | 0.0 | 16.2 |
| MARCH ODDS | 0.2 | +9.8 | 9.4 | 16.1 | 0.4 | +59.4 | 14.4 | 0.0 |
| MARCH OVER CASTS | 0.3 | +28.2 | 0.0 | 10.6 | 0.5 | +39.4 | 0.0 | 11.0 |
| MAX FOR POSITIONING | 4.3 | +127.3 | 0.0 | 179.2 | 4.6 | +219.2 | 0.0 | 201.0 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.0 | +3.7 | 50.1 | 26.7 |
| MISSILES IN THE MOVE | 3.6 | +109.2 | 0.0 | 81.5 | 3.2 | +62.7 | 0.0 | 63.4 |
| MISSILES NEXT TURN | 4.1 | +70.4 | 0.0 | 92.0 | 3.9 | +44.9 | 0.0 | 60.9 |
| MODEL FACING | 0.3 | +73.8 | 0.0 | 10.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +10.6 | 0.0 | 2.4 | 0.3 | +8.2 | 0.0 | 2.4 |
| MOVE SPELL IN RANGE | 0.2 | +5.6 | 0.0 | 36.9 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -8.9 | 10.1 | 11.2 | 0.0 | -0.9 | 0.0 | 11.2 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 2.6 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.2 | +160.5 | 66.9 | 123.1 | 4.7 | +361.9 | 140.1 | 191.8 |
| MOVES UNITS SPELL | 0.2 | +5.2 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +5.0 | 0.0 | 0.0 | 0.1 | +1.7 | 4.2 | 0.0 |
| NO RALLY LEFT | 0.0 | +2.6 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 3.9 |
| NOT NEEDED | 0.1 | -1.6 | 10.4 | 0.0 | 0.4 | -21.5 | 54.2 | 8.0 |
| NOT TURNED | 5.6 | +97.5 | 0.0 | 180.8 | 5.6 | +143.0 | 0.0 | 114.2 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 11.0 |
| OFF BEST | 17.6 | -839.5 | 12.2 | 411.8 | 15.0 | -728.7 | 16.2 | 252.9 |
| ONE YARDSTICK | - | - | - | - | 14.8 | -412.9 | 374.6 | 198.2 |
| OPENS A LANE | 0.3 | +3.9 | 10.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +10.9 | 9.4 | 0.0 | 0.3 | +31.4 | 19.8 | 12.3 |
| OVERRUN THREAT | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.6 | +14.2 | 43.6 | 13.1 | 0.4 | +10.9 | 48.1 | 27.7 |
| PATHS CROSS | 1.9 | +132.1 | 0.0 | 58.3 | 2.5 | +216.0 | 0.0 | 72.8 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.9 | 0.0 | 8.6 | 0.1 | -0.5 | 0.0 | 0.0 |
| PLAN RESULT | 39.5 | +1816.7 | 1887.8 | 1065.9 | 40.1 | +1616.1 | 1647.4 | 1130.6 |
| PURSUES BIG PREY | 0.1 | -27.2 | 0.0 | 8.6 | 0.2 | -18.1 | 0.0 | 8.2 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +8.5 | 0.0 | 4.7 | 1.7 | +34.8 | 0.0 | 73.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.1 | 0.0 | 0.0 | 0.2 | -14.5 | 7.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.2 | 0.0 | 1.9 | 0.2 | +1.1 | 0.0 | 2.4 |
| REDIRECT COUNTER | 2.0 | +113.9 | 0.0 | 37.4 | 3.4 | +327.3 | 0.0 | 69.4 |
| REDIRECT WEIGHED | 0.2 | +2.5 | 6.5 | 1.4 | 0.2 | +13.3 | 15.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +6.6 | 0.0 | 4.0 | 1.0 | +22.3 | 0.0 | 27.8 |
| RESTRAINS TO SHOOT | 0.1 | +3.0 | 0.0 | 0.0 | 0.2 | +6.2 | 0.0 | 6.5 |
| RISK BY ARC | 2.3 | +110.5 | 192.5 | 62.1 | 2.9 | +84.3 | 265.0 | 102.6 |
| SAFER THAN THE JOB | 1.6 | +90.3 | 0.0 | 59.3 | 0.7 | +54.4 | 0.0 | 17.7 |
| SCOUT SPOT | 0.5 | +1.4 | 0.0 | 0.0 | 0.6 | +2.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.7 | 0.0 | 0.0 | 0.3 | -20.3 | 0.0 | 3.5 |
| SEARCH SPOT | 1.8 | +91.1 | 0.0 | 41.3 | 2.9 | +168.4 | 0.0 | 48.4 |
| SECOND HUNTER | 0.2 | -0.9 | 9.2 | 3.3 | 0.0 | -0.1 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.5 | +65.9 | 0.0 | 0.0 | 0.6 | +143.5 | 0.0 | 51.0 |
| SET UP TOGETHER | 1.0 | +56.1 | 26.6 | 55.1 | 1.4 | +155.5 | 15.3 | 93.6 |
| SET-UP ANY TARGET | 0.4 | +51.3 | 0.0 | 4.7 | 0.1 | +22.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +8.5 | 2.5 | 2.4 | - | - | - | - |
| SHOOTERS ARE THREATS | - | - | - | - | 4.5 | +264.6 | 293.6 | 69.5 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 2.1 | +32.0 | 0.0 | 31.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +50.2 | 34.5 | 19.9 | 1.1 | +52.5 | 69.3 | 14.9 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 22.8 | +0.0 | 1643.9 | 458.4 | 15.4 | +0.0 | 768.7 | 280.9 |
| SHOT REPLANNED | 1.6 | +0.0 | 343.8 | 16.7 | - | - | - | - |
| SHOTS IN THE MOVE | 20.7 | +959.6 | 0.0 | 375.8 | 14.6 | +592.6 | 0.0 | 223.3 |
| SPELL SETS UP CHARGE | 0.4 | +51.3 | 0.0 | 4.7 | 0.1 | +22.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.5 | +8.9 | 39.0 | 39.0 | 1.7 | +41.7 | 77.9 | 77.9 |
| STABLE ROLE | 11.5 | +0.0 | 333.5 | 270.9 | 9.9 | +0.0 | 410.2 | 202.0 |
| STANDS TO CAST | 0.0 | +1.1 | 3.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 15.8 | +210.1 | 481.1 | 211.1 |
| STOPS | 0.1 | +1.6 | 3.1 | 4.6 | 0.1 | +2.0 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +20.5 | 0.0 | 23.9 | 0.3 | +11.9 | 0.0 | 37.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 4.3 | -35.6 | 255.4 | 79.9 | 6.0 | -44.9 | 433.8 | 127.9 |
| SUPPORTS | 2.8 | +35.6 | 159.6 | 42.8 | 3.6 | +47.6 | 177.6 | 59.3 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.6 | 20.6 | 0.0 | 0.1 | -10.3 | 14.4 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.0 | 16.5 | 6.0 | 0.6 | +4.3 | 6.5 | 46.3 |
| THROUGH LINE OF FIRE | 0.6 | +19.4 | 0.0 | 11.2 | 0.4 | +13.9 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -24.6 | 31.3 | 19.3 | 0.7 | -54.0 | 62.0 | 6.9 |
| TWO OR MORE ARRIVE | 0.2 | +3.3 | 26.6 | 12.7 | 0.5 | +1.8 | 6.5 | 44.0 |
| WAIT AFTER COSTS | 6.7 | -291.9 | 189.7 | 185.6 | 7.2 | -405.0 | 220.0 | 237.0 |
| WALKS TO THE FIGHT | 2.0 | +36.6 | 33.2 | 56.2 | 1.0 | +21.5 | 7.4 | 5.1 |
| WAR ENGINE CHARGES | 0.1 | +14.5 | 11.4 | 8.6 | 0.1 | +9.0 | 0.0 | 8.6 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 9.2 | 9.3 | 0.2 | +0.0 | 4.2 | 10.3 |
| WEARS DOWN | 1.0 | +40.3 | 83.7 | 12.0 | 1.4 | +35.6 | 148.6 | 69.2 |
| WHO HITS BACK | 0.2 | +25.5 | 0.0 | 0.0 | 0.2 | +26.4 | 0.0 | 10.1 |
| WHOLE FIGHT | 0.1 | -1.4 | 31.2 | 0.0 | 0.3 | +27.7 | 31.3 | 5.4 |
| WHOLE FIGHT GAIN | 0.1 | +20.4 | 0.0 | 12.4 | 0.8 | +73.5 | 133.1 | 20.2 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 3.0 | 0.0 | 0.0 | +0.0 | 2.1 | 0.0 |

### Rule changes: sf-h2h-opp-4394159-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1173 | 1173 | 1173 | 32.58 | -56457 | -48.1 |
| BEST FIRST | 333 | 333 | 333 | 9.25 | +13625 | +40.9 |
| COUNTER-CHARGE COVER | 668 | 359 | 173 | 4.81 | +11308 | +65.4 |
| SEARCH SPOT | 167 | 167 | 166 | 4.61 | +9343 | +56.3 |
| FIRE PLAN | 555 | 555 | 160 | 4.44 | +2788 | +17.4 |
| PATHS CROSS | 159 | 159 | 159 | 4.42 | +12532 | +78.8 |
| MOVE TO CHARGE | 282 | 281 | 152 | 4.22 | +7314 | +48.1 |
| KILLS COUNT NEXT TURN | 439 | 438 | 129 | 3.58 | +4860 | +37.7 |
| SHOTS IN THE MOVE | 1272 | 853 | 127 | 3.53 | +4894 | +38.5 |
| ARTILLERY RE-ROLL WEIGHED | 117 | 117 | 117 | 3.25 | +0 | +0.0 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +11176 | +95.5 |
| EVERY WOUND COUNTS | 363 | 363 | 96 | 2.67 | +0 | +0.0 |
| SUPPORTS | 231 | 231 | 88 | 2.44 | +930 | +10.6 |
| SAFER THAN THE JOB | 81 | 81 | 81 | 2.25 | +5209 | +64.3 |
| FALLBACK BY WORTH | 387 | 387 | 73 | 2.03 | +4304 | +59.0 |
| CANNON SIGHT KEPT | 67 | 67 | 67 | 1.86 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +7942 | +122.2 |
| WAIT AFTER COSTS | 501 | 500 | 63 | 1.75 | +1236 | +19.6 |
| BEST FACING | 62 | 62 | 62 | 1.72 | +3989 | +64.3 |
| WALKS TO THE FIGHT | 110 | 110 | 60 | 1.67 | +885 | +14.7 |
| SHOT REPLANNED | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 78 | 78 | 54 | 1.50 | +1560 | +28.9 |
| RISK BY ARC | 186 | 183 | 52 | 1.44 | +1699 | +32.7 |
| BEST OVERALL | 50 | 50 | 50 | 1.39 | +3391 | +67.8 |
| MAX FOR POSITIONING | 321 | 182 | 45 | 1.25 | +471 | +10.5 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1040 | +23.6 |
| LONE WIZARD KEPT IN | 42 | 42 | 42 | 1.17 | +2858 | +68.0 |
| SCOUT WAITS | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| HONEST THREAT | 363 | 363 | 39 | 1.08 | +0 | +0.0 |
| ONE YARDSTICK | 533 | 172 | 38 | 1.06 | +517 | +13.6 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| CANNON PLANNED TARGET | 283 | 283 | 37 | 1.03 | -2 | -0.1 |
| MISSILES IN THE MOVE | 243 | 136 | 37 | 1.03 | +904 | +24.4 |
| SHOOTS FROM THE BEST SPOT | 73 | 73 | 37 | 1.03 | +1141 | +30.8 |
| CHARGE NOW FIRST | 204 | 204 | 36 | 1.00 | -1994 | -55.4 |
| REDIRECT COUNTER | 195 | 103 | 36 | 1.00 | +3529 | +98.0 |
| SHOOTERS ARE THREATS | 163 | 163 | 36 | 1.00 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 36 | 36 | 36 | 1.00 | +1197 | +33.2 |
| COMBAT PIVOT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 132 | 129 | 34 | 0.94 | +1399 | +41.2 |
| BLOCKED WHEEL | 33 | 33 | 33 | 0.92 | -144 | -4.4 |
| STAY WORTH | 567 | 445 | 32 | 0.89 | +431 | +13.5 |
| SET UP TOGETHER | 85 | 70 | 31 | 0.86 | +3253 | +104.9 |
| CHARGE NOW WEIGHED | 30 | 30 | 30 | 0.83 | +2021 | +67.4 |
| SHOOTERS IN TWO RANKS | 29 | 29 | 29 | 0.81 | +48 | +1.7 |
| BEST MOVE FOR SHOOTERS | 28 | 28 | 28 | 0.78 | +1797 | +64.2 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| CAST JOB | 59 | 59 | 25 | 0.69 | +638 | +25.5 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1167 | +46.7 |
| BEST PREY | 74 | 74 | 24 | 0.67 | +836 | +34.9 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +788 | +35.8 |
| SHORT GUN FORWARD | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| FIRE IN ORDER | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| MOVE AND CAST | 19 | 19 | 19 | 0.53 | +677 | +35.6 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| INVITES THE FIGHT | 96 | 96 | 18 | 0.50 | +224 | +12.5 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +589 | +34.7 |
| MARCH CHECK | 20 | 20 | 17 | 0.47 | +1487 | +87.5 |
| KEEPS THE TARGET | 37 | 37 | 16 | 0.44 | -7 | -0.4 |
| WHOLE FIGHT GAIN | 35 | 34 | 16 | 0.44 | +984 | +61.5 |
| KEEPS ITS TARGET | 121 | 119 | 15 | 0.42 | +292 | +19.5 |
| MAKE SURE TOGETHER | 54 | 34 | 15 | 0.42 | +1331 | +88.7 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +1104 | +78.9 |
| WEARS DOWN | 86 | 85 | 14 | 0.39 | +265 | +19.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1382 | +106.3 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +1454 | +111.8 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -58 | -4.8 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +2656 | +241.5 |
| MOVES UNITS SPELL | 11 | 11 | 11 | 0.31 | +221 | +20.1 |
| PURSUES BIG PREY | 11 | 11 | 11 | 0.31 | -1628 | -148.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +329 | +36.6 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | +7 | +0.9 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 180 | 180 | 8 | 0.22 | +128 | +16.0 |
| OVERRUNS AWAY | 37 | 36 | 8 | 0.22 | +200 | +24.9 |
| CASTING BLOCK | 10 | 10 | 7 | 0.19 | +543 | +77.6 |
| HUNT IN PAIRS | 21 | 13 | 7 | 0.19 | +181 | +25.8 |
| OPENS UP | 16 | 16 | 7 | 0.19 | +465 | +66.4 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -158 | -22.6 |
| BACKUP TARGETS | 70 | 32 | 6 | 0.17 | +11 | +1.8 |
| HUNT ADVANCE | 33 | 33 | 6 | 0.17 | +321 | +53.6 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -574 | -95.7 |
| WAR ENGINE CHARGES | 6 | 6 | 6 | 0.17 | +632 | +105.3 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -380 | -76.1 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 372 | 372 | 5 | 0.14 | -68 | -13.6 |
| DEFENSIVE ARMY | 12 | 12 | 4 | 0.11 | -113 | -28.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 288 | 163 | 4 | 0.11 | +6 | +1.6 |
| SHOOTERS TO THE PRIMARY | 76 | 49 | 4 | 0.11 | +47 | +11.7 |
| WAR ENGINE JOBS | 23 | 23 | 4 | 0.11 | -49 | -12.2 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +58 | +19.4 |
| WHOLE FIGHT | 15 | 15 | 3 | 0.08 | +74 | +24.7 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +124 | +62.1 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +24 | +12.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +178 | +88.9 |
| STOPS | 6 | 6 | 2 | 0.06 | +28 | +14.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +26.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -31 | -31.0 |
| CARRIES OUT SET-UP | 10 | 10 | 1 | 0.03 | -57 | -57.5 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +2 | +1.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +3 | +2.9 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +8 | +8.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +9 | +9.4 |
| HILL BY ITS CHANCE | 29 | 29 | 1 | 0.03 | +65 | +65.0 |
| JOINT CHARGE PLAN | 5 | 5 | 1 | 0.03 | +75 | +74.8 |
| KEEPS ITS PREY | 4 | 4 | 1 | 0.03 | +5 | +4.8 |
| LONG SHOT | 35 | 34 | 1 | 0.03 | +13 | +13.3 |
| MOVE SPELL IN RANGE | 8 | 5 | 1 | 0.03 | +0 | +0.3 |
| OPENS A LANE | 11 | 9 | 1 | 0.03 | +7 | +7.2 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +43 | +43.2 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 1 | 0.03 | +109 | +109.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +7 | +7.2 |
| SURE REACH TOGETHER | 34 | 25 | 1 | 0.03 | +6 | +6.3 |
| TURN WORTH | 38 | 38 | 1 | 0.03 | +35 | +34.8 |
| TWO OR MORE ARRIVE | 26 | 21 | 1 | 0.03 | +2 | +2.4 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -382 | -381.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 52 | 52 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 10 | 10 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 411 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 8 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 17 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 19 | trace | - | - | - | - |
| HUNT RESULT | 22 | trace | - | - | - | - |
| HUNT THE GUNS | 25 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 26 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 35 | 2 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 19 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 404 | 404 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 21 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2865 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 38 | 38 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 40 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OPTIONS | 1378 | 1378 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 79 | not checked | - | - | - | - |
| STABLE ROLE | 771 | 769 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-opp-4394159-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.47 | 13.50 | 48.0 |
| TURN GATE | gate | 0.83 | 0.44 | 47.9 |
| FALLBACK | gate | 0.64 | 0.58 | 56.2 |
| CHARGE NOW FIRST | rule | 0.31 | 0.69 | 55.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | 0.08 | 67.3 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 26.2 |
| FIRE PLAN | rule | - | 0.31 | 29.5 |
| KEEPS THE TARGET | rule | - | 0.31 | 62.8 |
| PURSUES BIG PREY | rule | 0.14 | 0.17 | 148.0 |
| PATHS CROSS | rule | 0.14 | 0.11 | 15.0 |
| CHAFF PASSED | rule | 0.22 | - | 7.2 |
| AFTERMATH BAND | gate | 0.08 | 0.11 | 4.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 52.9 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 22.6 |
| BLOCKED WHEEL | rule | 0.14 | 0.03 | 88.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.08 | 95.7 |
| THROUGH LINE OF FIRE | rule | 0.14 | 0.03 | 16.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 25.6 |
| BEST PRIZE | rule | 0.06 | 0.08 | 76.1 |
| SUPPORT NARROWED | rule | - | 0.14 | 13.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.08 | 94.9 |
| DEFENSIVE ARMY | rule | 0.11 | - | 28.2 |
| WAR ENGINE JOBS | rule | - | 0.11 | 12.2 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.06 | 5.7 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.5 |
| NO REASON | gate | - | 0.08 | 12.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 5.7 |
| MARCH ODDS | rule | 0.03 | 0.03 | 10.6 |
| RULE SWITCHED OFF | gate | 0.06 | - | 42.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 31.0 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 57.5 |
| CATCH ODDS | rule | 0.03 | - | 1.5 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.6 |
| WHO HITS BACK | rule | - | 0.03 | 3.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 381.7 |

### Plans: sf-h2h-opp-4394159-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 18% | 455 | 379 | 83% |
| Mine | charge | 2.6 | 52% | 240 | 201 | 84% |
| Mine | close in | 3.7 | 19% | 172 | 114 | 66% |
| Mine | hold | 4.6 | 29% | 279 | 0 | 0% |
| Mine | join | 1.1 | 92% | 18 | 0 | 0% |
| Mine | shoot | 12.1 | 68% | 419 | 1124 | 268% |
| Mine | support | 3.1 | 85% | 22 | 0 | 0% |
| Opponent | advance | 13.3 | 16% | 475 | 429 | 90% |
| Opponent | charge | 4.6 | 55% | 567 | 524 | 92% |
| Opponent | close in | 5.2 | 25% | 446 | 125 | 28% |
| Opponent | hold | 5.6 | 34% | 401 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 25 | 0 | 0% |
| Opponent | shoot | 6.7 | 60% | 437 | 539 | 123% |
| Opponent | support | 4.0 | 86% | 35 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-opp-4394159-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.4 | 14 | 1 | 15% | 46% | 0% | 3.2 | 319 | 150 | 46% | 82 |
| Opponent | 0.3 | 11 | 2 | 0% | 11% | 0% | 3.0 | 497 | 28 | 11% | 215 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2.7 | 8 | 1 | 14% | 43% | 0% | 4.3 | 257 | 62 | 43% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 326 |
| Dwarfen Mountain Holds | 1.0 | 5 | 0 | 0% | 60% | 0% | 2.0 | 428 | 304 | 60% | 100 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.4 | 4 | 1 | 33% | 0% | 0% | - | 540 | 0 | 0% | 114 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 501 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 343 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 280 |
| Tomb Kings of Khemri | 0.7 | 5 | 0 | 0% | 20% | 0% | 3.0 | 381 | 51 | 20% | 176 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| Warriors of Chaos | 0.4 | 2 | 1 | 0% | 0% | 0% | - | 645 | 0 | 0% | 456 |
| Wood Elf Realms | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 510 | 0 | 0% | 296 |

### Battle groups: sf-h2h-opp-4394159-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.6 | 25% | 43% | 3% | 33% | 26% | 15% | 10% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 21% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.0 | 19% | 76% | 13% | 29% | 44% | 4% | 6% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 21% | 73% | 12% | 0% | 17% | 9% | 9% | 57% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-opp-4394159-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 67 | 33% | 4.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 30 | 29 (30) | 27 | 2 | 55 | 23% | 2.7 | 28 (16) | 29 (6) | 29 (8) | 18 (17) | 40 (13) |
| Mine | Character | 107 | 42 (107) | 42 | 0 | 36 | 31% | 2.6 | 57 (33) | 41 (49) | 10 (8) | 48 (48) | 39 (42) |
| Mine | Clean-up | 15 | 89 (15) | 31 | 58 | 54 | 27% | 2.6 | 71 (6) | 63 (8) | 300 (1) | 139 (10) | 0 (5) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 25% | 1.3 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 52 | 40 (52) | 21 | 19 | 56 | 13% | 2.6 | 54 (19) | 33 (23) | 32 (10) | 60 (35) | 12 (17) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 75 | 44 (75) | 29 | 15 | 46 | 19% | 2.3 | 34 (18) | 48 (50) | 35 (7) | 50 (46) | 33 (29) |
| Mine | Holder | 24 | 68 (24) | 25 | 43 | 16 | 42% | 2.8 | 47 (5) | 115 (12) | 4 (7) | 53 (13) | 82 (11) |
| Mine | Shooter | 42 | 77 (42) | 33 | 44 | 49 | 2% | 1.7 | 89 (15) | 85 (21) | 16 (6) | 93 (29) | 37 (13) |
| Mine | War machine | 91 | 69 (91) | 69 | 0 | 41 | 4% | 1.2 | 68 (37) | 80 (45) | 0 (9) | 63 (22) | 70 (69) |
| Mine | Wizard | 28 | 29 (28) | 29 | 0 | 32 | 14% | 2.4 | 0 (8) | 68 (11) | 0 (2) | 0 (5) | 46 (16) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Chaff | 68 | 94 (68) | 23 | 71 | 63 | 34% | 2.2 | 78 (29) | 117 (13) | 93 (26) | 103 (55) | 60 (13) |
| Opponent | Character | 96 | 51 (96) | 51 | 0 | 35 | 24% | 2.2 | 56 (37) | 48 (44) | 63 (6) | 42 (48) | 63 (39) |
| Opponent | Clean-up | 18 | 76 (18) | 35 | 41 | 31 | 44% | 3.8 | 31 (4) | 105 (10) | 6 (4) | 121 (13) | 6 (5) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 46 | 37 (46) | 29 | 8 | 44 | 30% | 3.1 | 44 (23) | 31 (16) | 23 (7) | 44 (24) | 30 (22) |
| Opponent | Fragile | 14 | 45 (14) | 45 | 0 | 64 | 36% | 2.8 | 0 (1) | 69 (9) | 0 (4) | 70 (6) | 25 (8) |
| Opponent | Hammer | 52 | 35 (52) | 30 | 5 | 47 | 25% | 2.6 | 7 (18) | 52 (30) | 0 (4) | 36 (38) | 34 (14) |
| Opponent | Holder | 44 | 107 (44) | 25 | 82 | 29 | 25% | 2.5 | 189 (8) | 103 (25) | 80 (10) | 137 (28) | 74 (15) |
| Opponent | Shooter | 34 | 64 (34) | 33 | 31 | 24 | 3% | 1.4 | 14 (9) | 82 (23) | 79 (2) | 60 (21) | 70 (13) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 24 | 99 (24) | 99 | 0 | 31 | 4% | 1.5 | 141 (6) | 83 (16) | 43 (2) | 39 (8) | 130 (16) |
| Opponent | Wizard | 26 | 5 (26) | 5 | 0 | 52 | 19% | 2.2 | 12 (12) | 0 (5) | 0 (2) | 0 (8) | 13 (11) |

### Charged fights: sf-h2h-opp-4394159-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 90 | 457 | 3.3 | 1.2 | 137 | 16 | +121 | 3 of 10 | 7 of 10 | +426 | +44 |
| Mine | Chaos Dwarfs | 5 | 275 | 354 | 2.4 | 1.0 | 147 | 0 | +147 | 6 of 12 | 8 of 12 | - | +147 |
| Mine | Dwarfen Mountain Holds | 5 | 586 | 64 | 1.8 | 1.1 | 36 | 18 | +17 | 1 of 9 | 6 of 9 | +280 | -16 |
| Mine | Empire of Man | 12 | 591 | 97 | 1.5 | 1.2 | 65 | 78 | -13 | 5 of 18 | 10 of 18 | -214 | +12 |
| Mine | Grand Cathay | 2 | 163 | 368 | 3.0 | 1.0 | 122 | 0 | +122 | 3 of 6 | 6 of 6 | - | +122 |
| Mine | High Elf Realms | 5 | 54 | 653 | 3.8 | 1.1 | 172 | 29 | +143 | 5 of 19 | 13 of 19 | +55 | +148 |
| Mine | Ogre Kingdoms | 3 | 114 | 191 | 4.7 | 1.1 | 41 | 48 | -7 | 3 of 14 | 7 of 14 | -495 | +30 |
| Mine | Tomb Kings of Khemri | 1 | 75 | 483 | 3.0 | 1.0 | 161 | 0 | +161 | 2 of 3 | 3 of 3 | - | +161 |
| **Mine** | all armies | 36 | 352 | 269 | 2.5 | 1.1 | 106 | 32 | +74 | 28 of 91 | 60 of 91 | +38 | +77 |
| Opponent | Chaos Dwarfs | 1 | 82 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Empire of Man | 4 | 651 | 162 | 1.0 | 1.2 | 162 | 0 | +162 | 1 of 4 | 4 of 4 | +0 | +217 |
| Opponent | Grand Cathay | 1 | 485 | 281 | 3.0 | 1.0 | 94 | 78 | +16 | 2 of 3 | 1 of 3 | - | +16 |
| Opponent | High Elf Realms | 6 | 237 | 414 | 3.2 | 1.1 | 131 | 26 | +104 | 13 of 19 | 11 of 19 | +151 | +102 |
| Opponent | Lizardmen | 1 | 60 | 431 | 2.0 | 1.0 | 216 | 202 | +13 | 1 of 2 | 2 of 2 | - | +13 |
| Opponent | Ogre Kingdoms | 2 | 56 | 215 | 4.5 | 1.1 | 48 | 14 | +34 | 1 of 9 | 7 of 9 | +170 | +17 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 350 | 2.0 | 1.5 | 175 | 0 | +175 | 2 of 2 | 2 of 2 | +85 | +265 |
| Opponent | Skaven | 3 | 62 | 479 | 2.3 | 1.0 | 205 | 5 | +200 | 3 of 7 | 6 of 7 | - | +200 |
| Opponent | Tomb Kings of Khemri | 6 | 66 | 766 | 4.3 | 1.3 | 177 | 16 | +161 | 14 of 26 | 20 of 26 | +283 | +116 |
| Opponent | Vampire Counts | 4 | 126 | 682 | 4.8 | 1.7 | 143 | 68 | +75 | 10 of 19 | 16 of 19 | +34 | +112 |
| Opponent | Warriors of Chaos | 5 | 44 | 502 | 3.8 | 1.0 | 132 | 0 | +132 | 9 of 19 | 17 of 19 | - | +132 |
| Opponent | Wood Elf Realms | 2 | 140 | 593 | 3.0 | 1.5 | 198 | 24 | +174 | 2 of 6 | 3 of 6 | +232 | +116 |
| **Opponent** | all armies | 36 | 176 | 474 | 3.2 | 1.2 | 146 | 27 | +119 | 59 of 117 | 89 of 117 | +147 | +112 |

### Effective charges: sf-h2h-opp-4394159-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 1 (net +812) | 0 | 1 (net +0) | 4 (net +90) | 1 (net +40) | 0 | 3 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 12 | 1 (net +217) | 0 | 0 | 3 (net +98) | 0 | 6 (net +209) | 2 | 0% (0 of 10) |
| Mine | Dwarfen Mountain Holds | 9 | 3 (net -55) | 0 | 1 (net +0) | 1 (net +0) | 0 | 4 (net +80) | 0 | 11% (1 of 9) |
| Mine | Empire of Man | 18 | 3 (net -88) | 1 (net +0) | 4 (net -89) | 6 (net +18) | 1 (net +55) | 2 (net +36) | 1 | 24% (4 of 17) |
| Mine | Grand Cathay | 6 | 2 (net +72) | 0 | 2 (net +98) | 1 (net +395) | 1 (net +0) | 0 | 0 | 33% (2 of 6) |
| Mine | High Elf Realms | 19 | 1 (net +603) | 0 | 4 (net +76) | 5 (net +175) | 4 (net +47) | 4 (net +132) | 1 | 22% (4 of 18) |
| Mine | Ogre Kingdoms | 14 | 2 (net -17) | 0 | 1 (net -34) | 2 (net +13) | 0 | 6 (net +2) | 3 | 9% (1 of 11) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 1 (net +233) | 0 | 2 (net +125) | 0 | 0% (0 of 3) |
| Opponent | Chaos Dwarfs | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 4 | 0 | 0 | 0 | 0 | 2 (net +55) | 1 (net +310) | 1 | 0% (0 of 3) |
| Opponent | Grand Cathay | 3 | 1 (net -233) | 0 | 1 (net +0) | 0 | 0 | 1 (net +281) | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 19 | 3 (net +0) | 0 | 3 (net +99) | 4 (net +295) | 1 (net +52) | 5 (net +99) | 3 | 19% (3 of 16) |
| Opponent | Ogre Kingdoms | 9 | 0 | 0 | 0 | 2 (net +85) | 0 | 3 (net +52) | 4 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 2 | 1 (net +265) | 0 | 0 | 1 (net +85) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Skaven | 7 | 0 | 0 | 2 (net +35) | 1 (net +0) | 0 | 4 (net +333) | 0 | 29% (2 of 7) |
| Opponent | Tomb Kings of Khemri | 26 | 2 (net +465) | 2 (net -208) | 4 (net +143) | 4 (net +97) | 2 (net +104) | 11 (net +220) | 1 | 16% (4 of 25) |
| Opponent | Vampire Counts | 19 | 2 (net +0) | 1 (net +506) | 1 (net +597) | 6 (net +42) | 1 (net +126) | 8 (net -7) | 0 | 5% (1 of 19) |
| Opponent | Warriors of Chaos | 19 | 1 (net +73) | 0 | 1 (net +230) | 2 (net +150) | 1 (net +45) | 12 (net +129) | 2 | 6% (1 of 17) |
| Opponent | Wood Elf Realms | 6 | 3 (net +78) | 0 | 1 (net +85) | 0 | 0 | 2 (net +362) | 0 | 17% (1 of 6) |

### Charged fights, damage counted: sf-h2h-opp-4394159-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 232 | 253 | +101 | 196 | 64 | +132 | +56.8 |
| Mine | 50-54% | 1 | 189 | 233 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 13 | 208 | 188 | +8 | 74 | 92 | -18 | -8.7 |
| Mine | 76-89% | 23 | 209 | 183 | +100 | 155 | 35 | +120 | +57.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 221 | 145 | +102 | 161 | 52 | +109 | +49.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 396 | 57 | +40 | 49 | 19 | +30 | +7.5 |
| Mine | No odds | 10 | 140 | 222 | +31 | 72 | 22 | +50 | +35.8 |
| Mine | All fights | 91 | 222 | 179 | +74 | 132 | 49 | +83 | +37.5 |
| Opponent | Long shot (under 50%) | 13 | 244 | 226 | +98 | 142 | 63 | +79 | +32.3 |
| Opponent | 50-54% | 3 | 567 | 346 | +30 | 169 | 172 | -3 | -0.5 |
| Opponent | Effective (55-75%) | 13 | 411 | 277 | +142 | 181 | 73 | +107 | +26.1 |
| Opponent | 76-89% | 21 | 345 | 226 | +113 | 143 | 12 | +130 | +37.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 47 | 319 | 209 | +153 | 195 | 39 | +156 | +49.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 382 | 90 | +77 | 77 | 21 | +56 | +14.7 |
| Opponent | No odds | 13 | 293 | 183 | +45 | 124 | 79 | +46 | +15.6 |
| Opponent | All fights | 117 | 333 | 215 | +119 | 163 | 47 | +115 | +34.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-opp-4394159-p3 | move | 462 | 92 (20%) | 76 (16%) | 58 (13%) | 312 (68%) |
| sf-h2h-opp-4394159-p3 | objective | 325 | 47 (14%) | 40 (12%) | 42 (13%) | 236 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0826, L0834, L1524, L1527, L1834, L2227 |
| Elixir of Power | Mine | L1115 |
| Elixir of Power | Opponent | L0711, L0819 |
| Fistful of Laurels | Mine | L1823, L1829, L1834 |
| Fistful of Laurels | Opponent | L0218, L1518 |
| Invocation of Nehek | Opponent | L1524, L1527, L2227 |
| Opal Amulet | Mine | L1415, L1422 |
| Periapt of Soul Exchange | Opponent | L0621, L0920, L0921 |
| Ring of Doom | Mine | L0203, L0215, L0218, L1115, L1518, L1524, L1527 |
| Ring of Doom | Opponent | L0215, L0711, L0815, L0931, L1115, L1415 |
| Ring of Jet | Mine | L1022, L1115 |
| Ring of Jet | Opponent | L0711 |
| Standard of the Fell Warrior | Opponent | L0313, L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621, L0921 |
| Twice-Blessed Armour | Mine | L0711, L0722, L1022 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Mine | L0711, L0722, L0815, L0819, L0822, L0826, L0829, L0834 |
| Witch Hunter's Ward | Opponent | L0307, L0308, L0608 |

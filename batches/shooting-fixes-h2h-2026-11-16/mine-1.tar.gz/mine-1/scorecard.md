# Doctrine scorecard: sf-h2h-mine-4394159-p1

### Scorecard: sf-h2h-mine-4394159-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 3 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0108 | 6 | 1 | Mine | no | 6 | 4 | 2 | 2 | 1 | 0 | 0 | 120 |
| L0108 | 6 | 1 | Opponent | no | 5 | 4 | 2 | 1 | 0 | 0 | 0 | 560 |
| L0109 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0109 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 524 |
| L0315 | 3 | 1 | Mine | no | 5 | 6 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 709 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L0322 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 590 |
| L0322 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 55 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0506 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0506 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 861 |
| L0507 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1371 |
| L0507 | 3 | 1 | Opponent | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 5 | 6 | 0 | 1 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 971 |
| L0509 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0509 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 524 |
| L0510 | 6 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 1019 |
| L0510 | 6 | 1 | Opponent | no | 6 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0511 | 1 | 1 | Mine | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 954 |
| L0511 | 1 | 1 | Opponent | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 785 |
| L0522 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0522 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0614 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 798 |
| L0614 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0615 | 3 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0615 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0619 | 1 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 743 |
| L0619 | 1 | 1 | Opponent | yes | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0627 | 3 | 1 | Mine | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 1197 |
| L0627 | 3 | 1 | Opponent | no | 10 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0708 | 6 | 1 | Mine | no | 3 | 1 | 2 | 3 | 0 | 0 | 0 | 452 |
| L0708 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0712 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 375 |
| L0712 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 524 |
| L0716 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0716 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 200 |
| L0725 | 5 | 1 | Mine | no | - | 2 | 0 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0730 | 4 | 1 | Mine | no | 3 | 4 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0730 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0731 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 497 |
| L0731 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 1 | 0 | 0 | 484 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 14 | 4 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 679 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0832 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 515 |
| L0832 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0833 | 5 | 1 | Mine | yes | - | - | 1 | 0 | 0 | 0 | 0 | 515 |
| L0833 | 5 | 1 | Opponent | no | - | 2 | 3 | 5 | 0 | 0 | 0 | 272 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 679 |
| L0835 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1318 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1318 | 4 | 1 | Opponent | no | 4 | - | 3 | 1 | 1 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 126 |
| L1516 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1822 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1822 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 55 |
| L1831 | 1 | 1 | Mine | no | 5 | 3 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 6 | 2 | 0 | 1 | 4 | 0 | 0 | 170 |
| L2224 | 4 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 55 |
| L2224 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 3 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 72 |
| L2230 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 6% | 1.5 | 3.2 | 1.8 | 1.0 | 0.2 | 0.0 | 0.0 | 513.4 |
| **Average** | | | Opponent | 22% | 2.7 | 2.2 | 2.8 | 1.6 | 0.4 | 0.0 | 0.0 | 242.9 |

### KPIs: sf-h2h-mine-4394159-p1

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (67 of 165) | 10% (16 of 163) | 25% (83 of 328) |
| Winner chose to follow up after the loser gave ground |  | 95% (60 of 63); on the table 97% | 98% (46 of 47); on the table 98% | 96% (106 of 110); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (4 of 6); on the table 67% | 80% (12 of 15); on the table 93% | 76% (16 of 21); on the table 86% |
| Winner chose to pursue after the loser fled |  | 62% (10 of 16); on the table 75% | 61% (22 of 36); on the table 72% | 62% (32 of 52); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 87% (74 of 85); on the table 91% | 82% (80 of 98); on the table 88% | 84% (154 of 183); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 32% (55 of 174) | 28% (57 of 204) | 30% (112 of 378) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (55 of 105) | 41% (57 of 138) | 46% (112 of 243) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 22% (8 of 36) | 32% (40 of 126) | 30% (48 of 162) |
|     round 1 |  | 67% (4 of 6) | 19% (4 of 21) | 30% (8 of 27) |
|     rounds 2+ |  | 13% (4 of 30) | 34% (36 of 105) | 30% (40 of 135) |
|   other wizards | 50%+ | 34% (47 of 138) | 22% (17 of 78) | 30% (64 of 216) |
|     round 1 |  | 17% (4 of 23) | 15% (2 of 13) | 17% (6 of 36) |
|     rounds 2+ |  | 37% (43 of 115) | 23% (15 of 65) | 32% (58 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 52% (15 of 29) | 52% (15 of 29) |
| Points that never fought | lower | 42% (29633 of 70291) | 46% (32925 of 71989) | 44% (62558 of 142280) |
|   infantry points that never fought | lower | 41% (6897 of 16644) | 74% (9661 of 13123) | 56% (16558 of 29767) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (199 of 282) | 51% (149 of 293) | 61% (348 of 575) |
| Bound items with a magic missile used (at least once a game) |  | 75% (6 of 8); 0.4 uses a game | 84% (16 of 19); 1.2 uses a game | 81% (22 of 27); 0.8 uses a game |
| Bound items with another spell used |  | 73% (8 of 11); 0.5 uses a game | 56% (5 of 9); 0.5 uses a game | 65% (13 of 20); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 39% (7 of 18); 0.2 uses a game | 56% (9 of 16); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (37692 of 55230) | 44% (27862 of 63193) | 55% (65554 of 118423) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.9 (29%) | 1.1 (26%) | 2.0 (27%) |
| MARCHED: its unit marched | 0.1 (4%) | 0.9 (22%) | 1.1 (14%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.5 (16%) | 0.9 (22%) | 1.4 (20%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.2 (4%) | 0.3 (4%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (1%) | 0.2 (3%) |
| GONE: slain | 1.1 (32%) | 0.9 (22%) | 1.9 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.0 | 1.5 | 3.1 | 0.2 | 1.1 |
| not cast | 3.6 | 1.9 | 3.0 | 7.4 | 1.7 | 14.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (32%) | 0.2 (6%) | 2.0 (27%) | 0.2 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (14%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.2 (12%) | 0.7 (22%) | 1.4 (20%) | 0.2 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (12%) | 0.4 (22%) | 0.6 (19%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.2 (34%) | 0.3 (16%) | 0.5 (18%) | 1.9 (26%) | 0.4 (23%) | 2.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (1%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (10%) | 0.1 (2%) | 0.1 (1%) | 0.4 (27%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (41%) | 0.1 (4%) | 0.9 (30%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.8 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 64% (16 of 25) | 53% (9 of 17) | 60% (25 of 42) |
| the unit moved after it | 50% (8 of 16) | 78% (7 of 9) | 60% (15 of 25) |
| it charged on its next turn | 0% (0 of 16) | 11% (1 of 9) | 4% (1 of 25) |
| the enemy charged it first | 25% (4 of 16) | 0% (0 of 9) | 16% (4 of 25) |
| it fought by the end of its next turn | 6% (1 of 16) | 0% (0 of 9) | 4% (1 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 16) | 11% (1 of 9) | 12% (3 of 25) |
| none of these (no charge, no fight, no charge escaped) | 62% (10 of 16) | 78% (7 of 9) | 68% (17 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (889 of 1277) | 54% (452 of 831) | 64% (1341 of 2108) |
|   cavalry | 60% (66 of 110) | 66% (82 of 125) | 63% (148 of 235) |
|   character | 68% (120 of 177) | 22% (22 of 101) | 51% (142 of 278) |
|   chariot | 58% (58 of 100) | 55% (42 of 76) | 57% (100 of 176) |
|   infantry | 57% (195 of 343) | 50% (145 of 288) | 54% (340 of 631) |
|   monster | 67% (24 of 36) | 32% (6 of 19) | 55% (30 of 55) |
|   war machine | 83% (426 of 511) | 70% (155 of 222) | 79% (581 of 733) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (18%) | 2.6 (25%) | 4.6 (22%) |
| CHARGED: it charged | 1.3 (12%) | 1.9 (18%) | 3.2 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.3 (12%) | 0.4 (4%) | 1.7 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.8 (26%) | 1.9 (18%) | 4.7 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.9 (8%) | 1.0 (9%) | 1.8 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (13%) | 1.5 (15%) | 2.9 (14%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.8 (7%) | 1.2 (6%) |
| OTHER BAR | 0.4 (4%) | 0.3 (3%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 2.3 | 77% | 7.0 pts | 49 pts |
| character | 4.3 | 1.4 | 75% | 8.5 pts | 37 pts |
| chariot | 2.8 | 1.6 | 74% | 12.3 pts | 34 pts |
| infantry | 14.0 | 5.0 | 74% | 8.3 pts | 117 pts |
| monster | 1.0 | 0.2 | 77% | 7.0 pts | 7 pts |
| war machine | 16.3 | 14.7 | 58% | 21.7 pts | 355 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 6.0 | 4.5 |
| Charges that made contact a game | 2.2 | 4.1 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.18 declared, 0.18 contact (11 units) | 0.71 declared, 0.53 contact (17 units) | 0.50 declared, 0.39 contact (28 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (4 units) | 1.50 declared, 0.75 contact (8 units) | 1.33 declared, 0.83 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.29 contact (246 units) | 0.81 declared, 0.56 contact (236 units) | 0.61 declared, 0.43 contact (482 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (39 of 66) | 52% (11 of 21) | 50% (4 of 8) | 57% (54 of 95) |
| Character in a unit | 79% (30 of 38) | 91% (10 of 11) | 50% (1 of 2) | 80% (41 of 51) |
| Character on its own | 84% (48 of 57) | 51% (18 of 35) | 29% (14 of 49) | 57% (80 of 141) |
| Chariot | 92% (11 of 12) | 65% (13 of 20) | - | 75% (24 of 32) |
| Infantry | 55% (32 of 58) | 55% (23 of 42) | 62% (5 of 8) | 56% (60 of 108) |
| Monster | 32% (8 of 25) | 100% (5 of 5) | - | 43% (13 of 30) |
| Monstrous | 75% (3 of 4) | 20% (2 of 10) | - | 36% (5 of 14) |
| War Machines | 67% (66 of 99) | 100% (5 of 5) | - | 68% (71 of 104) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 94% (17 of 18); on the table 100% | 26% (25 of 96) | 43% | 73% (11 of 15) | 67% (2 of 3); 1.3 uses a game | 33% (1 of 3); 0.7 uses a game | 100% (3 of 3); 1.0 uses a game |
| Chaos Dwarfs | 5 | 75% (3 of 4); on the table 75% | 46% (25 of 54) | 30% | 82% (33 of 40) | 0.0 uses a game | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| Dwarfen Mountain Holds | 12 | 84% (21 of 25); on the table 88% | - | 53% | 72% (68 of 95) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 17 | 83% (24 of 29); on the table 86% | 22% (12 of 54) | 61% | 64% (109 of 170) | 0.0 uses a game | 86% (6 of 7); 0.9 uses a game | 20% (3 of 15); 0.2 uses a game |
| Grand Cathay | 4 | 86% (6 of 7); on the table 100% | 36% (32 of 90) | 56% | 43% (16 of 37) | 78% (7 of 9); 4.8 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 5 | 84% (21 of 25); on the table 84% | 28% (5 of 18) | 21% | 39% (15 of 38) | 86% (6 of 7); 3.2 uses a game | 75% (6 of 8); 3.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 55% (6 of 11); on the table 82% | - | 24% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Ogre Kingdoms | 3 | 100% (7 of 7); on the table 100% | 0% (0 of 12) | 29% | 71% (15 of 21) | 100% (3 of 3); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (7 of 7); on the table 100% | 0% (0 of 6) | 6% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 7 | 93% (14 of 15); on the table 93% | - | 36% | 40% (14 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 94% (15 of 16); on the table 94% | 21% (5 of 24) | 53% | 56% (14 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 62% (8 of 13); on the table 77% | 44% (8 of 18) | 20% | 59% (30 of 51) | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 2 | 83% (5 of 6); on the table 83% | 0% (0 of 6) | 75% | 73% (16 of 22) | 67% (2 of 3); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-mine-4394159-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (36) | 47% (23) | 44% (59) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.39 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.08 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.75 | 0.75 | 1.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.08 | 3.94 | 9.03 |

### Quality by phase: sf-h2h-mine-4394159-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.1 |
| Strategy | Charge objectives carried out (made contact) | 52% (50 of 97) | 47% (98 of 210) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (248 of 585) | 57% (160 of 283) |
| Strategy | Close-in objectives charged next turn | 15% (17 of 114) | 15% (36 of 233) |
| Strategy | Support requests answered (helper made contact too) | 64% (7 of 11) | 25% (7 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 25% (2 of 8) |
| Strategy | Joined characters whose unit fought | 39% (19 of 49) | 32% (14 of 44) |
| Strategy | Lone characters that fought | 62% (67 of 108) | 65% (62 of 96) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.6 |
| Movement | Points that never moved of their own | 513.4 | 242.9 |
| Movement | Fights charged into per game | 1.9 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 62, net +109 | 18 of 110, net +133 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 62, net -20 | 25 of 110, net +129 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 62, net +45 | 11 of 110, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 62, net +49 | 26 of 110, net +245 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.8 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (246 of 497) | 36% (121 of 333) |
| Shooting | Points destroyed by shooting units | 130.7 | 32.2 |
| Shooting | War machine shots | 11.8 | 4.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (192 of 426) | 39% (62 of 161) |
| Shooting | Points destroyed by war machines | 115.7 | 60.2 |
| Magic | Magic missiles cast | 0.8 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (11 of 27) | 33% (11 of 33) |
| Magic | Wounds caused by magic missiles | 1.9 | 1.1 |
| Magic | Wounds caused by other spells | 1.0 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 31.2 | 27.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.1 / 0.4 / 0.0 | 2.0 / 0.4 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 160.8 | 506.6 |
| Combat | Points run down | 37.1 | 203.4 |
| Combat | Net points per charged fight, damage counted | +39 | +154 |
| Combat | Net per 100 charger points, damage counted | +18.4 | +46.8 |
| Combat | First round won (charged fights) | 63% | 73% |
| Combat | Net points per charged fight | +31 | +158 |
| Combat | Net points per supported fight / lone fight | -45 / +41 | +314 / +132 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 70 | 61 of 127 |
| Game | Points lost | 989.4 | 530.4 |
| Game | VP from objectives | 434.4 | 739.4 |
| Game | Lone holders (player turns) | 1.5 | 2.7 |

- Mine won / drew / lost: 6 / 7 / 23 of 36 ended games (of 36); mean margin (Mine - Opponent) -823 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1520
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-mine-4394159-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 54.6 | 1.1 | +0.0 | 0.0 | 11.9 |
| BACKUP TARGETS | 0.6 | +5.4 | 0.0 | 15.7 | 1.1 | +8.3 | 0.0 | 25.0 |
| BEST FACING | 0.8 | +48.8 | 0.0 | 39.6 | 0.5 | +11.8 | 0.0 | 33.8 |
| BEST FIRST | 3.6 | +174.9 | 70.3 | 55.6 | 3.8 | +164.2 | 135.6 | 31.1 |
| BEST MOVE FOR SHOOTERS | 1.0 | +90.7 | 0.0 | 34.0 | - | - | - | - |
| BEST OVERALL | 0.5 | +35.6 | 0.0 | 30.3 | 0.5 | +23.1 | 0.0 | 7.4 |
| BEST PREY | 0.6 | +55.3 | 15.0 | 5.8 | 0.8 | +40.6 | 61.6 | 1.9 |
| BEST PRIZE | - | - | - | - | 0.1 | +7.3 | 15.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 12.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 22.6 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | -1.2 | 0.0 | 2.0 | 0.5 | +6.4 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.3 | 1.8 | 1.7 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 41.3 | 11.5 |
| CANNON PLANNED TARGET | - | - | - | - | 3.1 | +129.9 | 133.8 | 23.8 |
| CANNON SIGHT KEPT | 2.1 | +0.0 | 0.0 | 3.1 | 1.4 | +0.0 | 0.0 | 13.3 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 11.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 2.1 | 10.6 | 0.2 | -6.2 | 40.0 | 1.2 |
| CAST JOB | 0.6 | +12.5 | 4.2 | 46.6 | 0.3 | +6.8 | 15.1 | 2.4 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 2.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +4.7 | 0.0 | 9.6 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 0.0 | 12.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.4 | 8.0 | 3.8 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 102.4 | 79.7 | 3.8 | +0.0 | 423.8 | 15.9 |
| CHARGE NOW WEIGHED | 0.4 | -20.7 | 17.4 | 11.7 | 0.5 | -69.1 | 31.9 | 31.6 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | -0.1 | 6.5 | 11.0 |
| CHEAP HELPER | 0.1 | +0.0 | 2.1 | 2.9 | 0.1 | +0.0 | 2.5 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.2 | 27.5 | 0.7 | +0.0 | 43.9 | 13.6 |
| CONVEYANCE SEARCH | 0.6 | +155.4 | 17.3 | 21.1 | 0.4 | +61.8 | 5.0 | 0.0 |
| COUNTER-CHARGE COVER | 9.9 | +981.3 | 0.0 | 278.3 | 6.1 | +430.5 | 0.0 | 127.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 40.7 | 2.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +7.4 | 13.4 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.7 | 12.1 | 2.1 | 0.3 | +9.8 | 53.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | 17.1 | +0.0 | 667.9 | 373.6 | - | - | - | - |
| FACES THE THREAT | 2.0 | +158.5 | 0.0 | 72.3 | 1.1 | +84.6 | 0.0 | 44.7 |
| FALLBACK BY WORTH | 3.8 | +38.3 | 0.0 | 77.0 | 4.2 | +46.8 | 0.0 | 52.7 |
| FIGHT LIFT | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +3.2 | 0.0 | 5.6 | - | - | - | - |
| FIRE IN ORDER | 1.2 | +0.0 | 88.1 | 25.5 | - | - | - | - |
| FIRE PLAN | 26.5 | +152.6 | 1116.1 | 570.5 | - | - | - | - |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 198.4 | 3.8 | +0.0 | 0.0 | 90.4 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.0 | 2.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +96.3 | 0.0 | 37.0 | 0.9 | +124.2 | 0.0 | 3.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +23.7 | 0.0 | 18.6 | 0.2 | +20.1 | 0.0 | 4.0 |
| GIVES UP | 0.0 | -0.7 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 1.9 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 5.8 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.5 | 0.1 | +0.0 | 15.2 | 5.7 |
| HELPER UNSEEN | 0.1 | +0.0 | 10.7 | 2.0 | 0.6 | +0.0 | 50.3 | 11.5 |
| HILL BY ITS CHANCE | 0.3 | -2.3 | 0.0 | 0.0 | 0.2 | -13.8 | 0.0 | 6.8 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 17.1 | +2471.5 | 667.9 | 373.6 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +11.3 | 17.4 | 3.2 | 0.3 | +4.5 | 23.5 | 4.8 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 2.8 | 0.0 |
| HUNT IN PAIRS | 0.3 | +10.4 | 0.0 | 10.8 | 0.6 | +24.7 | 0.0 | 25.9 |
| HUNT KEPT | 0.1 | +8.2 | 3.5 | 3.2 | 0.2 | +1.9 | 7.6 | 0.0 |
| HUNT RESULT | 0.1 | +16.3 | 0.0 | 3.2 | 0.3 | +25.4 | 2.8 | 2.9 |
| HUNT THE GUNS | 0.1 | +65.1 | 17.4 | 0.0 | 0.3 | +69.1 | 21.1 | 7.1 |
| INVITES THE FIGHT | 1.9 | +27.5 | 36.1 | 52.4 | 1.5 | +29.3 | 72.6 | 10.9 |
| JOINT CHARGE PLAN | 0.1 | +1.4 | 0.0 | 0.0 | 0.2 | +13.1 | 29.8 | 5.7 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 3.3 | 0.1 | +0.1 | 3.1 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +40.0 | 73.5 | 54.1 | 1.8 | +55.0 | 186.3 | 1.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | 1.2 | -42.5 | 91.8 | 12.9 | - | - | - | - |
| KILLS COUNT | 1.2 | +51.5 | 68.1 | 44.2 | 2.3 | +108.3 | 215.2 | 7.5 |
| KILLS COUNT NEXT TURN | 3.5 | +106.9 | 55.7 | 96.7 | 6.5 | +211.9 | 315.6 | 110.1 |
| LONE CHARACTER SAFE SPOT | 0.7 | +16.4 | 40.5 | 17.1 | 0.3 | +15.2 | 12.3 | 9.9 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +41.6 | 0.0 | 6.2 | 0.5 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -5.4 | 35.4 | 14.2 | 0.4 | -3.7 | 8.8 | 1.9 |
| LOST CHARGE | 2.5 | -56.4 | 35.4 | 75.9 | 2.4 | -46.2 | 78.6 | 58.1 |
| LURE BY WHAT IT DRAWS | 0.0 | -6.6 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +7.8 | 0.0 | 1.7 | 1.8 | +201.3 | 45.5 | 35.4 |
| MANOEUVRE | 0.3 | +11.3 | 0.0 | 15.7 | 0.1 | +1.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +8.5 | 0.0 | 4.7 | 0.4 | +20.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +18.9 | 3.1 | 10.6 | 0.2 | +9.8 | 13.9 | 12.1 |
| MARCH OVER CASTS | 0.1 | +4.9 | 0.0 | 0.0 | 0.5 | +28.1 | 0.0 | 21.8 |
| MAX FOR POSITIONING | 4.0 | +138.1 | 0.0 | 88.1 | 4.8 | +181.4 | 0.0 | 137.6 |
| MISSILES IN THE FIRE PLAN | 0.8 | +7.2 | 5.4 | 32.8 | - | - | - | - |
| MISSILES IN THE MOVE | 1.8 | +68.6 | 0.0 | 67.5 | 3.1 | +49.3 | 0.0 | 45.9 |
| MISSILES NEXT TURN | 1.9 | +46.3 | 0.0 | 73.0 | 4.2 | +42.5 | 0.0 | 113.2 |
| MODEL FACING | 0.5 | +158.9 | 0.0 | 1.7 | 0.0 | +12.7 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 7.9 | 0.0 | 0.4 | +0.0 | 31.7 | 0.0 |
| MOVE AND CAST | 0.3 | +16.2 | 0.0 | 31.4 | 0.3 | +8.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.5 | +12.7 | 0.0 | 31.7 | 0.1 | +4.8 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -40.8 | 0.0 | 24.7 | 0.1 | -6.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 1.5 | 0.1 | +0.0 | 0.0 | 17.0 |
| MOVE TO CHARGE | 2.4 | +111.5 | 67.6 | 68.1 | 5.8 | +407.6 | 289.6 | 114.4 |
| MOVES UNITS SPELL | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +14.4 | 6.5 | 0.0 |
| NO RALLY LEFT | 0.0 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -8.6 | 19.3 | 3.1 | 0.4 | -17.6 | 52.4 | 2.2 |
| NOT TURNED | 5.1 | +115.3 | 0.0 | 180.2 | 3.9 | +72.1 | 0.0 | 87.4 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 55.1 | 0.3 | -0.1 | 0.0 | 21.5 |
| OFF BEST | 14.8 | -703.1 | 11.3 | 328.3 | 15.9 | -817.1 | 17.9 | 210.8 |
| ONE YARDSTICK | 23.9 | -781.7 | 520.0 | 592.4 | - | - | - | - |
| OPENS A LANE | 0.1 | +1.5 | 12.3 | 3.5 | 0.1 | +1.6 | 8.8 | 4.6 |
| OPENS UP | 0.1 | +2.0 | 0.0 | 10.6 | 0.6 | +77.2 | 42.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +8.7 | 13.8 | 17.1 | 0.6 | +14.8 | 85.9 | 2.2 |
| PATHS CROSS | 1.7 | +136.1 | 0.0 | 39.6 | 2.2 | +156.2 | 0.0 | 44.9 |
| PIVOT GUARDS FLANK | 0.1 | -2.6 | 0.0 | 0.9 | 0.2 | -5.4 | 0.0 | 12.1 |
| PLAN RESULT | 37.8 | +1493.2 | 1286.9 | 1177.3 | 37.3 | +1418.0 | 1620.1 | 599.3 |
| PURSUES BIG PREY | 0.0 | -1.2 | 0.0 | 0.0 | 0.3 | -40.8 | 0.0 | 5.4 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | - | - | - | - | 0.8 | +8.1 | 0.0 | 14.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -12.7 | 21.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -4.0 | 0.0 | 1.0 | 0.2 | -7.3 | 0.0 | 7.3 |
| REDIRECT COUNTER | 1.8 | +160.1 | 0.0 | 23.9 | 2.2 | +214.6 | 0.0 | 60.1 |
| REDIRECT WEIGHED | 0.1 | +0.1 | 0.0 | 0.0 | 0.5 | +29.9 | 26.1 | 0.0 |
| RESERVE FALL BACK | 0.3 | +7.9 | 0.0 | 4.0 | 0.8 | +32.6 | 0.0 | 7.6 |
| RESTRAINS TO SHOOT | 0.1 | +4.0 | 0.0 | 0.0 | 0.1 | +5.4 | 0.0 | 2.9 |
| RISK BY ARC | 1.9 | +80.6 | 93.7 | 90.1 | 3.2 | +92.7 | 314.7 | 15.7 |
| SAFER THAN THE JOB | 0.8 | +49.2 | 0.0 | 12.2 | 0.8 | +37.3 | 0.0 | 19.1 |
| SCOUT SPOT | 0.6 | +1.5 | 0.0 | 2.5 | 0.4 | +0.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 2.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -6.5 | 0.0 | 0.9 | 0.1 | -7.9 | 0.0 | 1.2 |
| SEARCH SPOT | 2.4 | +123.4 | 0.0 | 34.5 | 1.6 | +125.6 | 0.0 | 31.9 |
| SELF MOVE SPELL | 0.2 | +37.4 | 0.0 | 0.0 | 0.2 | +31.1 | 0.0 | 11.0 |
| SET UP TOGETHER | 0.9 | +62.6 | 3.1 | 17.9 | 3.2 | +371.9 | 103.9 | 48.1 |
| SET-UP ANY TARGET | 0.3 | +37.5 | 12.1 | 10.6 | 0.1 | +20.6 | 5.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +7.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | 5.3 | +243.1 | 297.9 | 108.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.6 | +1.3 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 2.7 | +40.6 | 0.0 | 67.7 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +36.9 | 60.4 | 10.9 | 1.0 | +21.5 | 44.5 | 9.5 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 3.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 23.6 | +0.0 | 879.9 | 504.2 | 12.9 | +0.0 | 489.7 | 167.4 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 36.3 | 7.2 |
| SHOTS IN THE MOVE | 22.4 | +945.2 | 0.0 | 459.4 | 11.8 | +378.6 | 0.0 | 138.1 |
| SPELL CATCH ODDS | - | - | - | - | 0.1 | -2.2 | 5.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +134.4 | 12.1 | 10.6 | 0.2 | +42.9 | 5.0 | 0.0 |
| SPELL WORTH | 0.6 | +8.1 | 8.6 | 7.1 | 1.9 | +31.5 | 10.7 | 1.7 |
| STABLE ROLE | 9.1 | +0.0 | 464.2 | 157.6 | 10.1 | +0.0 | 368.2 | 93.1 |
| STAY WEIGHED | 0.1 | +2.6 | 0.0 | 0.0 | 0.0 | +2.7 | 0.0 | 0.0 |
| STAY WORTH | 25.6 | +174.1 | 667.3 | 402.0 | - | - | - | - |
| STOPS | 0.1 | +4.2 | 3.5 | 0.0 | 0.2 | +4.3 | 5.3 | 2.2 |
| STOPS SHORT OF THE FLANK | 0.2 | +11.4 | 0.0 | 0.0 | 0.2 | +15.3 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 4.4 | -30.6 | 301.9 | 57.2 | 4.7 | -21.4 | 338.3 | 46.5 |
| SUPPORTS | 3.0 | +39.1 | 221.3 | 22.7 | 2.0 | +21.4 | 33.2 | 26.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.6 | 2.1 | 0.0 | 0.1 | -13.3 | 21.5 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +11.1 | 0.0 | 0.0 | 0.6 | +29.5 | 0.0 | 10.4 |
| THROUGH LINE OF FIRE | 0.7 | +53.3 | 0.0 | 18.7 | 0.4 | +15.5 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -8.5 | 10.6 | 10.6 | 0.5 | -52.7 | 60.8 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +1.7 | 0.0 | 4.2 | 0.9 | +21.2 | 45.1 | 6.7 |
| WAIT AFTER COSTS | 6.2 | -276.1 | 140.8 | 171.4 | 9.4 | -485.6 | 432.2 | 149.1 |
| WALKS TO THE FIGHT | 1.6 | +37.0 | 26.8 | 44.3 | 1.4 | +31.8 | 49.4 | 5.1 |
| WAR ENGINE CHARGES | 0.1 | +6.8 | 0.0 | 0.0 | 0.0 | +6.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 20.2 | 17.2 | 0.1 | +0.0 | 0.0 | 5.1 |
| WEARS DOWN | 0.8 | +31.9 | 31.1 | 49.8 | 1.1 | +33.6 | 131.9 | 9.8 |
| WHO HITS BACK | 0.3 | +30.8 | 0.0 | 16.1 | 0.2 | +18.4 | 0.0 | 9.9 |
| WHOLE FIGHT | 0.2 | +1.2 | 22.9 | 6.3 | 0.4 | +53.7 | 83.8 | 4.2 |
| WHOLE FIGHT GAIN | 0.2 | +47.7 | 0.0 | 20.5 | 0.6 | +46.1 | 65.0 | 9.8 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 3.4 | 0.0 | - | - | - | - |

### Rule changes: sf-h2h-mine-4394159-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1106 | 1106 | 1106 | 30.72 | -54728 | -49.5 |
| FIRE PLAN | 953 | 953 | 278 | 7.72 | +3390 | +12.2 |
| BEST FIRST | 267 | 267 | 267 | 7.42 | +12207 | +45.7 |
| EVERY WOUND COUNTS | 617 | 617 | 171 | 4.75 | +0 | +0.0 |
| MOVE TO CHARGE | 294 | 293 | 147 | 4.08 | +6919 | +47.1 |
| COUNTER-CHARGE COVER | 575 | 312 | 145 | 4.03 | +8544 | +58.9 |
| SEARCH SPOT | 143 | 143 | 142 | 3.94 | +8966 | +63.1 |
| PATHS CROSS | 140 | 140 | 140 | 3.89 | +10526 | +75.2 |
| CANNON SIGHT KEPT | 128 | 128 | 128 | 3.56 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 127 | 127 | 127 | 3.53 | +0 | +0.0 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +8751 | +78.8 |
| SHOTS IN THE MOVE | 1232 | 825 | 104 | 2.89 | +3230 | +31.1 |
| KILLS COUNT NEXT TURN | 358 | 358 | 99 | 2.75 | +2874 | +29.0 |
| ONE YARDSTICK | 862 | 437 | 90 | 2.50 | +1090 | +12.1 |
| WAIT AFTER COSTS | 562 | 561 | 76 | 2.11 | +1422 | +18.7 |
| WALKS TO THE FIGHT | 109 | 109 | 69 | 1.92 | +1081 | +15.7 |
| SUPPORTS | 180 | 180 | 67 | 1.86 | +511 | +7.6 |
| SET UP TOGETHER | 147 | 112 | 64 | 1.78 | +5942 | +92.8 |
| FOLLOW UP WEIGHED | 56 | 56 | 56 | 1.56 | +7940 | +141.8 |
| FALLBACK BY WORTH | 289 | 289 | 54 | 1.50 | +3062 | +56.7 |
| SAFER THAN THE JOB | 54 | 54 | 54 | 1.50 | +3114 | +57.7 |
| HONEST THREAT | 617 | 617 | 51 | 1.42 | +0 | +0.0 |
| BEST FACING | 49 | 49 | 49 | 1.36 | +2182 | +44.5 |
| MAX FOR POSITIONING | 317 | 179 | 45 | 1.25 | +757 | +16.8 |
| CHARGE NOW FIRST | 193 | 193 | 44 | 1.22 | -4044 | -91.9 |
| FIRE IN ORDER | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RISK BY ARC | 184 | 179 | 39 | 1.08 | +1454 | +37.3 |
| LONE WIZARD KEPT IN | 38 | 38 | 38 | 1.06 | +2846 | +74.9 |
| REDIRECT COUNTER | 143 | 84 | 38 | 1.06 | +3035 | +79.9 |
| RESERVE FALL BACK | 38 | 38 | 38 | 1.06 | +1458 | +38.4 |
| THROUGH LINE OF FIRE | 37 | 37 | 37 | 1.03 | +2475 | +66.9 |
| BEST MOVE FOR SHOOTERS | 36 | 36 | 36 | 1.00 | +3265 | +90.7 |
| BEST OVERALL | 35 | 35 | 35 | 0.97 | +2110 | +60.3 |
| ADVANCE LANE KEPT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 32 | 32 | 32 | 0.89 | +59 | +1.8 |
| SHOOTS FROM THE BEST SPOT | 72 | 72 | 32 | 0.89 | +884 | +27.6 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +4082 | +131.7 |
| HOLDS AMBUSHERS | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| KILLS COUNT | 128 | 127 | 31 | 0.86 | +1380 | +44.5 |
| INVITES THE FIGHT | 121 | 121 | 26 | 0.72 | +388 | +14.9 |
| MAKE SURE TOGETHER | 78 | 44 | 26 | 0.72 | +2773 | +106.6 |
| MISSILES IN THE MOVE | 174 | 101 | 25 | 0.69 | +778 | +31.1 |
| STAY WORTH | 922 | 783 | 25 | 0.69 | +630 | +25.2 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +187 | +8.1 |
| SHORT GUN FORWARD | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +888 | +40.4 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +888 | +42.3 |
| KEEPS ITS TARGET | 114 | 113 | 20 | 0.56 | +386 | +19.3 |
| BEST PREY | 51 | 51 | 19 | 0.53 | +894 | +47.1 |
| CANNON PLANNED TARGET | 113 | 113 | 19 | 0.53 | -254 | -13.4 |
| MODEL FACING | 19 | 19 | 19 | 0.53 | +6177 | +325.1 |
| OPENS UP | 25 | 25 | 19 | 0.53 | +749 | +39.4 |
| KEEPS THE TARGET | 44 | 44 | 18 | 0.50 | -1899 | -105.5 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +1399 | +77.7 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1578 | +92.8 |
| STOPS SHORT OF THE FLANK | 17 | 17 | 17 | 0.47 | +961 | +56.6 |
| MARCH CHECK | 19 | 16 | 16 | 0.44 | +759 | +47.4 |
| WHOLE FIGHT GAIN | 29 | 26 | 16 | 0.44 | +1247 | +77.9 |
| RANDOM MOVE BY FIGURES | 29 | 29 | 15 | 0.42 | +292 | +19.4 |
| SHOOTERS ARE THREATS | 190 | 190 | 15 | 0.42 | +0 | +0.0 |
| CAST JOB | 33 | 33 | 14 | 0.39 | +256 | +18.3 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +463 | +35.6 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -288 | -24.0 |
| PURSUES BIG PREY | 12 | 12 | 12 | 0.33 | -1512 | -126.0 |
| WAR ENGINE JOBS | 30 | 30 | 12 | 0.33 | -759 | -63.3 |
| WEARS DOWN | 68 | 65 | 12 | 0.33 | +303 | +25.3 |
| SHOT REPLANNED | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | +36 | +3.6 |
| MARCH ODDS | 10 | 10 | 10 | 0.28 | +173 | +17.3 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -14 | -1.6 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 175 | 173 | 8 | 0.22 | +97 | +12.1 |
| CASTS FROM BEHIND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +337 | +48.2 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -536 | -76.6 |
| BACKUP TARGETS | 61 | 30 | 6 | 0.17 | +49 | +8.2 |
| HUNT ADVANCE | 17 | 17 | 6 | 0.17 | +268 | +44.7 |
| HUNT IN PAIRS | 32 | 24 | 6 | 0.17 | +265 | +44.1 |
| SUPPORT NARROWED | 330 | 330 | 6 | 0.17 | -131 | -21.8 |
| SURE REACH TOGETHER | 33 | 21 | 6 | 0.17 | +77 | +12.9 |
| WHOLE FIGHT | 22 | 22 | 6 | 0.17 | +970 | +161.8 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| STUCK PIVOT | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -122 | -30.4 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 4 | 0.11 | -158 | -39.5 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +26 | +6.5 |
| OVERRUNS AWAY | 40 | 40 | 4 | 0.11 | +114 | +28.4 |
| SHOOTERS TO THE PRIMARY | 97 | 67 | 4 | 0.11 | +7 | +1.7 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +192 | +48.0 |
| MISSILES NEXT TURN | 219 | 123 | 3 | 0.08 | +25 | +8.3 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -223 | -111.6 |
| DEFENSIVE ARMY | 9 | 9 | 2 | 0.06 | -18 | -8.9 |
| DEFENSIVE FLOOR | 4 | 4 | 2 | 0.06 | +14 | +6.8 |
| EDGE GIVE GROUND | 16 | 16 | 2 | 0.06 | +44 | +21.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +116 | +57.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +36 | +18.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| LONG SHOT | 36 | 36 | 2 | 0.06 | +17 | +8.4 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OPENS A LANE | 10 | 8 | 2 | 0.06 | +25 | +12.4 |
| STOPS | 10 | 10 | 2 | 0.06 | +116 | +58.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +10 | +10.0 |
| CASTING BLOCK | 3 | 3 | 1 | 0.03 | +104 | +104.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -12 | -12.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +64 | +64.3 |
| HILL BY ITS CHANCE | 17 | 17 | 1 | 0.03 | +44 | +44.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +28 | +27.6 |
| JOINT CHARGE PLAN | 13 | 13 | 1 | 0.03 | +53 | +53.2 |
| MISSILES IN THE FIRE PLAN | 27 | 2 | 1 | 0.03 | +0 | +0.5 |
| MOVE SPELL IN RANGE | 20 | 9 | 1 | 0.03 | +7 | +7.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +22 | +21.6 |
| TWO OR MORE ARRIVE | 44 | 36 | 1 | 0.03 | +63 | +63.2 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +233 | +232.9 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -38 | -38.1 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 35 | not checked | - | - | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 349 | not checked | - | - | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 15 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 20 | 0 | 0.00 | - | - |
| NOT TURNED | 325 | 325 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| PLAN RESULT | 2703 | trace | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 37 | 37 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1314 | 1314 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| STABLE ROLE | 690 | 686 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-mine-4394159-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.64 | 14.78 | 50.1 |
| CHARGE NOW FIRST | rule | 0.28 | 0.94 | 91.9 |
| FALLBACK | gate | 0.36 | 0.31 | 19.1 |
| TURN GATE | gate | 0.39 | 0.22 | 29.1 |
| FIRE PLAN | rule | 0.47 | - | 78.0 |
| KEEPS THE TARGET | rule | 0.39 | - | 142.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.19 | 108.5 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.19 | 24.0 |
| PURSUES BIG PREY | rule | 0.03 | 0.31 | 126.0 |
| SUPPORT REQUEST | gate | 0.08 | 0.22 | 70.7 |
| WAR ENGINE JOBS | rule | 0.25 | 0.06 | 69.0 |
| CANNON PLANNED TARGET | rule | - | 0.19 | 71.2 |
| PATHS CROSS | rule | 0.03 | 0.17 | 23.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.08 | 76.6 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 3.1 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 28.9 |
| SUPPORT NARROWED | rule | 0.03 | 0.11 | 26.1 |
| BEST PRIZE | rule | - | 0.11 | 30.4 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 19.4 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 52.7 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 10.4 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 111.6 |
| CHAFF PASSED | rule | - | 0.06 | 7.0 |
| DEFENSIVE ARMY | rule | 0.06 | - | 8.9 |
| NO REASON | gate | 0.06 | - | 20.4 |
| REDIRECT WEIGHED | rule | - | 0.06 | 52.0 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 17.8 |
| CATCH ODDS | rule | - | 0.03 | 12.1 |
| FACES THE THREAT | rule | - | 0.03 | 11.2 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.5 |
| RULE SWITCHED OFF | gate | - | 0.03 | 3.7 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 9.7 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 38.1 |

### Plans: sf-h2h-mine-4394159-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.2 | 14% | 413 | 302 | 73% |
| Mine | charge | 2.3 | 48% | 152 | 148 | 97% |
| Mine | close in | 3.1 | 24% | 185 | 82 | 44% |
| Mine | hold | 3.4 | 32% | 279 | 0 | 0% |
| Mine | join | 1.2 | 95% | 26 | 0 | 0% |
| Mine | shoot | 14.4 | 54% | 440 | 960 | 218% |
| Mine | support | 3.2 | 90% | 22 | 0 | 0% |
| Opponent | advance | 11.9 | 20% | 343 | 334 | 97% |
| Opponent | charge | 5.0 | 66% | 613 | 509 | 83% |
| Opponent | close in | 6.4 | 26% | 600 | 193 | 32% |
| Opponent | hold | 4.3 | 48% | 336 | 0 | 0% |
| Opponent | join | 0.7 | 88% | 23 | 0 | 0% |
| Opponent | shoot | 6.6 | 64% | 189 | 388 | 205% |
| Opponent | support | 2.2 | 89% | 14 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-mine-4394159-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 1 | 0% | 25% | 0% | 2.0 | 523 | 147 | 25% | 85 |
| Opponent | 0.3 | 12 | 1 | 18% | 55% | 0% | 2.5 | 210 | 83 | 45% | 155 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 4 | 1 | 0% | 33% | 0% | 2.0 | 514 | 196 | 33% | 120 |
| Empire of Man | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 262 | 206 | 100% | 133 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 373 |
| High Elf Realms | 0.6 | 3 | 0 | 0% | 0% | 0% | - | 410 | 0 | 0% | 126 |
| Kingdom of Bretonnia | 0.7 | 2 | 1 | 0% | 0% | 0% | - | 176 | 0 | 0% | 67 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 405 |
| Tomb Kings of Khemri | 0.9 | 6 | 0 | 17% | 83% | 0% | 2.6 | 176 | 118 | 67% | 48 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Wood Elf Realms | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 139 | 0 | 0% | 489 |

### Battle groups: sf-h2h-mine-4394159-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 30% | 51% | 10% | 64% | 25% | 14% | 11% | 51% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 10% | 33% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.1 | 17% | 58% | 11% | 25% | 59% | 3% | 9% | 29% | 0% |
| Opponent | REDIRECT COUNTER | 2.2 | 31% | 84% | 12% | 0% | 32% | 0% | 9% | 59% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-mine-4394159-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 80 (2) | 80 | 0 | 50 | 0% | 5.0 | - | 160 (1) | 0 (1) | - | 80 (2) |
| Mine | Chaff | 34 | 87 (34) | 30 | 57 | 66 | 32% | 2.4 | 129 (20) | 0 (9) | 58 (5) | 96 (27) | 53 (7) |
| Mine | Character | 139 | 26 (139) | 26 | 0 | 57 | 26% | 2.5 | 27 (42) | 31 (67) | 29 (5) | 32 (65) | 27 (49) |
| Mine | Clean-up | 16 | 13 (16) | 2 | 12 | 60 | 56% | 1.6 | 0 (4) | 20 (12) | - | 4 (8) | 22 (8) |
| Mine | Fast | 2 | 102 (2) | 102 | 0 | 50 | 0% | 2.0 | - | 102 (2) | - | 102 (2) | - |
| Mine | Fast Hammer | 35 | 31 (35) | 15 | 17 | 56 | 23% | 2.7 | 28 (13) | 39 (17) | 18 (5) | 38 (22) | 21 (13) |
| Mine | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Hammer | 61 | 24 (61) | 10 | 14 | 51 | 11% | 2.5 | 8 (19) | 35 (37) | 15 (5) | 31 (41) | 10 (20) |
| Mine | Holder | 25 | 116 (25) | 28 | 88 | 32 | 20% | 2.0 | 0 (1) | 110 (20) | 162 (4) | 158 (17) | 29 (8) |
| Mine | Shooter | 42 | 68 (42) | 37 | 31 | 49 | 5% | 1.6 | 64 (11) | 77 (25) | 37 (6) | 95 (24) | 38 (18) |
| Mine | War machine | 112 | 44 (112) | 44 | 0 | 58 | 2% | 1.3 | 41 (36) | 45 (68) | 48 (8) | 49 (29) | 42 (83) |
| Mine | Wizard | 18 | 4 (18) | 4 | 0 | 48 | 22% | 2.4 | 0 (4) | 14 (5) | 0 (3) | 0 (6) | 12 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 59 | 54 (59) | 30 | 25 | 55 | 39% | 2.2 | 47 (28) | 49 (15) | 72 (16) | 70 (44) | 0 (15) |
| Opponent | Character | 106 | 78 (106) | 78 | 0 | 22 | 31% | 2.4 | 87 (37) | 87 (46) | 53 (9) | 87 (57) | 78 (35) |
| Opponent | Clean-up | 24 | 38 (24) | 15 | 23 | 14 | 46% | 3.6 | 0 (8) | 48 (11) | 82 (5) | 27 (13) | 49 (11) |
| Opponent | Early | 1 | 386 (1) | 386 | 0 | 100 | 0% | 4.0 | - | 386 (1) | - | 386 (1) | - |
| Opponent | Fast | 5 | 34 (5) | 34 | 0 | 100 | 60% | 2.0 | 97 (1) | 20 (4) | - | 34 (5) | - |
| Opponent | Fast Hammer | 47 | 69 (47) | 52 | 17 | 35 | 23% | 2.8 | 66 (19) | 53 (19) | 118 (9) | 61 (35) | 95 (12) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 40 | 45 (40) | 26 | 19 | 35 | 32% | 2.3 | 47 (11) | 43 (26) | 48 (3) | 45 (29) | 45 (11) |
| Opponent | Holder | 39 | 96 (39) | 5 | 90 | 12 | 38% | 2.3 | 27 (8) | 114 (25) | 118 (6) | 116 (26) | 47 (13) |
| Opponent | Shooter | 22 | 58 (22) | 16 | 42 | 24 | 0% | 1.8 | 0 (6) | 88 (14) | 0 (2) | 66 (12) | 50 (10) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 40 | 33% | 4.5 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 45 | 53 (45) | 53 | 0 | 34 | 9% | 1.4 | 52 (9) | 47 (29) | 78 (7) | 52 (12) | 53 (33) |
| Opponent | Wizard | 34 | 22 (34) | 22 | 0 | 17 | 15% | 2.1 | 0 (18) | 5 (9) | 101 (4) | 3 (17) | 48 (14) |

### Charged fights: sf-h2h-mine-4394159-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 149 | 142 | 1.3 | 1.0 | 106 | 84 | +22 | 2 of 4 | 3 of 4 | - | +22 |
| Mine | Chaos Dwarfs | 4 | 81 | 0 | 0.8 | 1.0 | 0 | 0 | +0 | 2 of 3 | 1 of 3 | - | +0 |
| Mine | Dwarfen Mountain Holds | 11 | 422 | 97 | 1.5 | 1.3 | 63 | 19 | +44 | 4 of 17 | 10 of 17 | +28 | +51 |
| Mine | Empire of Man | 11 | 292 | 57 | 1.9 | 1.1 | 30 | 93 | -63 | 6 of 21 | 15 of 21 | -284 | -40 |
| Mine | High Elf Realms | 2 | 415 | 275 | 4.0 | 1.0 | 69 | 74 | -5 | 4 of 8 | 5 of 8 | - | -5 |
| Mine | Ogre Kingdoms | 2 | 182 | 251 | 4.5 | 1.1 | 56 | 77 | -21 | 4 of 9 | 4 of 9 | +72 | -33 |
| Mine | Tomb Kings of Khemri | 3 | 60 | 1183 | 2.7 | 1.0 | 444 | 78 | +365 | 2 of 8 | 6 of 8 | - | +365 |
| **Mine** | all armies | 36 | 278 | 187 | 1.9 | 1.1 | 96 | 65 | +31 | 24 of 70 | 44 of 70 | -45 | +41 |
| Opponent | Chaos Dwarfs | 1 | 55 | 130 | 1.0 | 1.0 | 130 | 0 | +130 | 1 of 1 | 0 of 1 | - | +130 |
| Opponent | Dwarfen Mountain Holds | 1 | 160 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | +0 | - |
| Opponent | Empire of Man | 6 | 377 | 278 | 1.5 | 1.2 | 186 | 0 | +186 | 3 of 9 | 7 of 9 | +617 | +62 |
| Opponent | Grand Cathay | 4 | 314 | 270 | 2.5 | 1.3 | 108 | 0 | +108 | 8 of 10 | 4 of 10 | +88 | +116 |
| Opponent | High Elf Realms | 3 | 92 | 707 | 5.7 | 1.1 | 125 | 8 | +116 | 9 of 17 | 11 of 17 | +428 | +97 |
| Opponent | Kingdom of Bretonnia | 3 | 58 | 862 | 5.7 | 1.2 | 152 | 0 | +152 | 5 of 17 | 15 of 17 | +110 | +158 |
| Opponent | Ogre Kingdoms | 1 | 0 | 347 | 4.0 | 1.0 | 87 | 0 | +87 | 2 of 4 | 3 of 4 | - | +87 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 1092 | 4.0 | 1.0 | 273 | 0 | +273 | 3 of 4 | 3 of 4 | - | +273 |
| Opponent | Tomb Kings of Khemri | 4 | 17 | 1584 | 6.2 | 1.3 | 253 | 0 | +253 | 11 of 25 | 21 of 25 | +386 | +211 |
| Opponent | Vampire Counts | 4 | 0 | 728 | 4.0 | 1.1 | 182 | 9 | +173 | 7 of 16 | 13 of 16 | +195 | +172 |
| Opponent | Warriors of Chaos | 6 | 0 | 285 | 2.7 | 1.1 | 107 | 40 | +67 | 7 of 16 | 11 of 16 | +36 | +69 |
| Opponent | Wood Elf Realms | 2 | 22 | 496 | 3.5 | 1.1 | 142 | 0 | +142 | 5 of 7 | 5 of 7 | +956 | +6 |
| **Opponent** | all armies | 36 | 119 | 583 | 3.5 | 1.2 | 165 | 7 | +158 | 61 of 127 | 93 of 127 | +314 | +132 |

### Effective charges: sf-h2h-mine-4394159-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net -168) | 2 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0% (0 of 3) |
| Mine | Dwarfen Mountain Holds | 17 | 3 (net +31) | 2 (net -30) | 1 (net +0) | 8 (net +55) | 1 (net +45) | 1 (net +123) | 1 | 6% (1 of 16) |
| Mine | Empire of Man | 21 | 3 (net -163) | 1 (net +0) | 3 (net -196) | 7 (net -23) | 0 | 6 (net -14) | 1 | 15% (3 of 20) |
| Mine | High Elf Realms | 8 | 0 | 0 | 4 (net +96) | 3 (net -173) | 0 | 1 (net +90) | 0 | 50% (4 of 8) |
| Mine | Ogre Kingdoms | 9 | 0 | 0 | 4 (net -61) | 0 | 0 | 2 (net +16) | 3 | 67% (4 of 6) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +1158) | 0 | 1 (net +188) | 2 (net +232) | 0 | 3 (net +335) | 1 | 14% (1 of 7) |
| Opponent | Chaos Dwarfs | 1 | 0 | 0 | 1 (net +130) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 9 | 1 (net +0) | 1 (net +95) | 1 (net +0) | 3 (net +433) | 2 (net +32) | 1 (net +212) | 0 | 11% (1 of 9) |
| Opponent | Grand Cathay | 10 | 5 (net +138) | 0 | 2 (net +132) | 2 (net +62) | 1 (net +0) | 0 | 0 | 20% (2 of 10) |
| Opponent | High Elf Realms | 17 | 0 | 1 (net +60) | 4 (net +79) | 4 (net +112) | 0 | 4 (net +266) | 4 | 31% (4 of 13) |
| Opponent | Kingdom of Bretonnia | 17 | 2 (net +164) | 0 | 4 (net +230) | 1 (net +0) | 1 (net +0) | 6 (net +175) | 3 | 29% (4 of 14) |
| Opponent | Ogre Kingdoms | 4 | 1 (net +0) | 0 | 2 (net +174) | 0 | 0 | 0 | 1 | 67% (2 of 3) |
| Opponent | Orc & Goblin Tribes | 4 | 2 (net +423) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 25 | 1 (net +0) | 0 | 4 (net +274) | 10 (net +273) | 2 (net +140) | 6 (net +319) | 2 | 17% (4 of 23) |
| Opponent | Vampire Counts | 16 | 4 (net +134) | 1 (net -75) | 3 (net +183) | 4 (net +236) | 0 | 3 (net +201) | 1 | 20% (3 of 15) |
| Opponent | Warriors of Chaos | 16 | 1 (net +0) | 0 | 2 (net -200) | 1 (net +195) | 5 (net +85) | 4 (net +144) | 3 | 15% (2 of 13) |
| Opponent | Wood Elf Realms | 7 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +36) | 0 | 2 (net +478) | 1 | 33% (2 of 6) |

### Charged fights, damage counted: sf-h2h-mine-4394159-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 197 | 281 | +109 | 222 | 142 | +79 | +40.3 |
| Mine | 50-54% | 3 | 115 | 163 | -20 | 59 | 78 | -19 | -16.7 |
| Mine | Effective (55-75%) | 13 | 272 | 217 | -20 | 138 | 148 | -11 | -3.9 |
| Mine | 76-89% | 21 | 180 | 177 | +11 | 96 | 63 | +33 | +18.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 225 | 178 | +49 | 127 | 76 | +50 | +22.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 183 | 45 | +45 | 45 | 0 | +45 | +24.6 |
| Mine | No odds | 8 | 204 | 152 | +82 | 117 | 23 | +94 | +46.3 |
| Mine | All fights | 70 | 210 | 190 | +31 | 124 | 85 | +39 | +18.4 |
| Opponent | Long shot (under 50%) | 18 | 255 | 206 | +133 | 153 | 30 | +123 | +48.4 |
| Opponent | 50-54% | 3 | 248 | 112 | +27 | 82 | 25 | +57 | +22.9 |
| Opponent | Effective (55-75%) | 25 | 313 | 233 | +129 | 163 | 53 | +110 | +35.2 |
| Opponent | 76-89% | 27 | 300 | 156 | +214 | 220 | 19 | +201 | +66.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 391 | 229 | +245 | 272 | 25 | +247 | +63.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 437 | 82 | +70 | 82 | 1 | +81 | +18.6 |
| Opponent | No odds | 17 | 321 | 198 | +83 | 120 | 24 | +96 | +30.0 |
| Opponent | All fights | 127 | 328 | 191 | +158 | 181 | 28 | +154 | +46.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-mine-4394159-p1 | move | 390 | 77 (20%) | 52 (13%) | 61 (16%) | 252 (65%) |
| sf-h2h-mine-4394159-p1 | objective | 347 | 53 (15%) | 33 (10%) | 54 (16%) | 240 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0108, L0109 |
| Charmed Shield | Opponent | L0627, L0725, L0827, L2224 |
| Clockwork Compass | Opponent | L0712 |
| Elixir of Power | Opponent | L0511, L0619 |
| Fistful of Laurels | Mine | L1822, L1831 |
| Fistful of Laurels | Opponent | L1318 |
| Horn of the Wild Hunt | Opponent | L0833 |
| Invocation of Nehek | Opponent | L0627, L0725, L0827, L2224 |
| Opal Amulet | Opponent | L0614 |
| Ring of Doom | Mine | L1516 |
| Ring of Doom | Opponent | L0315, L0511, L0615, L0712, L0731, L0833, L1831 |
| Ring of Jet | Opponent | L0510, L0511, L0712, L0810 |
| Standard of the Fell Warrior | Mine | L1318 |
| Twice-Blessed Armour | Mine | L0708, L0712, L0716, L0725, L0730, L0731 |
| Twice-Blessed Armour | Opponent | L0507, L0510, L0810 |
| Witch Hunter's Ward | Mine | L0708, L0712, L0716, L0725, L0730, L0731, L0810, L0827, L0832, L0833, L0835 |
| Witch Hunter's Ward | Opponent | L0108, L0507, L0508, L0708 |

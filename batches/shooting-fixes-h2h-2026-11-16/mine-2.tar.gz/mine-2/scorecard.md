# Doctrine scorecard: sf-h2h-mine-4394159-p2

### Scorecard: sf-h2h-mine-4394159-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0312 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 675 |
| L0312 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L0314 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0314 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 5 | 3 | 1 | 1 | 1 | 0 | 0 | 590 |
| L0334 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 216 |
| L0407 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0518 | 2 | 1 | Mine | - | - | 4 | 0 | 0 | 0 | 0 | 0 | 836 |
| L0518 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 1 | 0 | 0 | 185 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0527 | 5 | 1 | Mine | no | - | 3 | 1 | 0 | 0 | 0 | 0 | 613 |
| L0527 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 133 |
| L0531 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0531 | 3 | 1 | Opponent | no | 8 | - | 2 | 1 | 2 | 0 | 0 | 340 |
| L0609 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 801 |
| L0609 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0618 | 6 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 801 |
| L0618 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0622 | 4 | 1 | Mine | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 1359 |
| L0622 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 55 |
| L0626 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 700 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 615 |
| L0630 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 375 |
| L0715 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 1 | 0 | 0 | 115 |
| L0718 | 4 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 420 |
| L0718 | 4 | 1 | Opponent | no | 3 | 3 | 3 | 0 | 2 | 0 | 0 | 0 |
| L0720 | 6 | 1 | Mine | yes | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0720 | 6 | 1 | Opponent | no | 3 | - | 3 | 0 | 2 | 0 | 0 | 210 |
| L0724 | 4 | 1 | Mine | no | 1 | 4 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0724 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0809 | 5 | 1 | Mine | no | - | 6 | 2 | 3 | 0 | 0 | 0 | 864 |
| L0809 | 5 | 1 | Opponent | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0818 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 605 |
| L0818 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 140 |
| L0915 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 1221 |
| L0915 | 3 | 1 | Opponent | no | 18 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0916 | 4 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 641 |
| L0916 | 4 | 1 | Opponent | no | 2 | 4 | 5 | 0 | 1 | 0 | 0 | 200 |
| L0925 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 524 |
| L0925 | 1 | 1 | Opponent | no | 0 | 3 | 8 | 3 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 619 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 160 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 40 |
| L1215 | 3 | 1 | Mine | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1215 | 3 | 1 | Opponent | yes | 6 | 1 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1222 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1222 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 280 |
| L1533 | 3 | 1 | Mine | yes | 13 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 190 |
| L1535 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 2 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 7 | 4 | 0 | 0 | 0 | 525 |
| L1722 | 6 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 72 |
| L1722 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1832 | 2 | 1 | Mine | - | - | 1 | 4 | 0 | 1 | 0 | 0 | 328 |
| L1832 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2122 | 4 | 1 | Mine | no | 1 | - | 3 | 6 | 0 | 0 | 0 | 145 |
| L2122 | 4 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2226 | 6 | 1 | Mine | no | 6 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2226 | 6 | 1 | Opponent | no | 8 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 1.9 | 2.7 | 2.1 | 0.9 | 0.4 | 0.0 | 0.0 | 532.8 |
| **Average** | | | Opponent | 17% | 2.6 | 2.1 | 3.6 | 1.6 | 0.5 | 0.0 | 0.0 | 129.4 |

### KPIs: sf-h2h-mine-4394159-p2

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 52% (92 of 177) | 3% (6 of 181) | 27% (98 of 358) |
| Winner chose to follow up after the loser gave ground |  | 90% (66 of 73); on the table 92% | 100% (50 of 50); on the table 100% | 94% (116 of 123); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 69% (9 of 13); on the table 77% | 72% (13 of 18); on the table 83% | 71% (22 of 31); on the table 81% |
| Winner chose to pursue after the loser fled |  | 68% (17 of 25); on the table 72% | 82% (37 of 45); on the table 89% | 77% (54 of 70); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 83% (92 of 111); on the table 86% | 88% (100 of 113); on the table 93% | 86% (192 of 224); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 34% (76 of 222) | 28% (50 of 180) | 31% (126 of 402) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (76 of 152) | 35% (50 of 141) | 43% (126 of 293) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 17% (20 of 120) | 19% (22 of 114) | 18% (42 of 234) |
|     round 1 |  | 10% (2 of 20) | 16% (3 of 19) | 13% (5 of 39) |
|     rounds 2+ |  | 18% (18 of 100) | 20% (19 of 95) | 19% (37 of 195) |
|   other wizards | 50%+ | 55% (56 of 102) | 42% (28 of 66) | 50% (84 of 168) |
|     round 1 |  | 47% (8 of 17) | 36% (4 of 11) | 43% (12 of 28) |
|     rounds 2+ |  | 56% (48 of 85) | 44% (24 of 55) | 51% (72 of 140) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 91% (10 of 11) | 57% (24 of 42) | 64% (34 of 53) |
| Points that never fought | lower | 41% (29037 of 71134) | 39% (27799 of 71985) | 40% (56836 of 143119) |
|   infantry points that never fought | lower | 43% (7449 of 17321) | 63% (8675 of 13831) | 52% (16124 of 31152) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (188 of 317) | 58% (155 of 269) | 59% (343 of 586) |
| Bound items with a magic missile used (at least once a game) |  | 93% (14 of 15); 1.0 uses a game | 84% (16 of 19); 1.3 uses a game | 88% (30 of 34); 1.2 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.1 uses a game | 33% (3 of 9); 0.1 uses a game | 46% (6 of 13); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 36% (5 of 14); 0.1 uses a game | 50% (5 of 10); 0.1 uses a game | 42% (10 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32714 of 59205) | 51% (31850 of 62613) | 53% (64564 of 121818) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (25%) | 0.9 (24%) | 1.9 (24%) |
| MARCHED: its unit marched | 0.8 (20%) | 0.7 (19%) | 1.5 (20%) |
| CHARGED: its unit charged | 0.2 (5%) | 0.2 (6%) | 0.4 (6%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | 0.6 (18%) | 1.7 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.4 (12%) | 0.5 (7%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.4 (11%) | 0.3 (9%) | 0.8 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (12%) | 0.0 (1%) | 0.5 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.3 (8%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 0.9 | 1.6 | 3.5 | 0.2 | 1.9 |
| not cast | 3.0 | 2.4 | 2.3 | 7.7 | 0.9 | 14.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (24%) | 0.2 (9%) | 1.9 (24%) | 0.3 (35%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (20%) | 0.1 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (6%) | 0.0 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (6%) | 0.4 (20%) | 1.7 (22%) | 0.2 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (11%) | 0.9 (38%) | 0.6 (26%) | 0.5 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.1 (6%) | 0.4 (3%) |
| GONE: slain | 0.9 (32%) | 0.4 (15%) | 0.5 (23%) | 0.8 (10%) | 0.1 (9%) | 2.0 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.1 (3%) | 0.0 (0%) | 0.5 (7%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.1 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (43%) | 0.0 (0%) | 0.4 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.1 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.4 a game | 1.2 a game | 0.8 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | 63% (17 of 27) | 63% (19 of 30) |
| the unit moved after it | 50% (1 of 2) | 71% (12 of 17) | 68% (13 of 19) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 17) | 0% (0 of 19) |
| the enemy charged it first | 0% (0 of 2) | 18% (3 of 17) | 16% (3 of 19) |
| it fought by the end of its next turn | 0% (0 of 2) | 6% (1 of 17) | 5% (1 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 50% (1 of 2) | 6% (1 of 17) | 11% (2 of 19) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 76% (13 of 17) | 74% (14 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (969 of 1391) | 51% (412 of 809) | 63% (1381 of 2200) |
|   cavalry | 63% (48 of 76) | 64% (63 of 98) | 64% (111 of 174) |
|   character | 79% (134 of 170) | 27% (42 of 158) | 54% (176 of 328) |
|   chariot | 52% (59 of 114) | 70% (39 of 56) | 58% (98 of 170) |
|   infantry | 56% (222 of 400) | 49% (180 of 367) | 52% (402 of 767) |
|   monster | 68% (52 of 76) | 56% (29 of 52) | 63% (81 of 128) |
|   war machine | 82% (454 of 555) | 76% (59 of 78) | 81% (513 of 633) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (24%) | 3.1 (28%) | 5.9 (26%) |
| CHARGED: it charged | 1.3 (11%) | 2.5 (23%) | 3.8 (17%) |
| FLEEING: it fled or was fleeing | 0.4 (3%) | 0.3 (3%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 1.5 (13%) | 0.9 (8%) | 2.4 (11%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.9 (16%) | 1.7 (15%) | 3.6 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.5 (5%) | 1.1 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (11%) | 1.8 (16%) | 3.1 (13%) |
| SHELTERED: the target was sheltered | 1.0 (9%) | 0.1 (1%) | 1.1 (5%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.8 (7%) | 0.2 (2%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.7 | 78% | 5.8 pts | 32 pts |
| character | 5.2 | 1.9 | 74% | 10.4 pts | 54 pts |
| chariot | 2.9 | 1.7 | 69% | 16.6 pts | 48 pts |
| infantry | 16.0 | 6.2 | 70% | 8.6 pts | 137 pts |
| monster | 2.8 | 0.8 | 84% | 7.1 pts | 20 pts |
| war machine | 14.5 | 13.3 | 57% | 26.6 pts | 385 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 7.5 | 5.6 |
| Charges that made contact a game | 2.5 | 5.2 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.63 contact (19 units) | 1.15 declared, 0.92 contact (13 units) | 1.00 declared, 0.75 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.25 contact (4 units) | 1.88 declared, 1.38 contact (8 units) | 1.67 declared, 1.33 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.30 contact (245 units) | 0.80 declared, 0.54 contact (301 units) | 0.64 declared, 0.43 contact (546 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (31 of 57) | 43% (6 of 14) | 43% (3 of 7) | 51% (40 of 78) |
| Character in a unit | 72% (26 of 36) | 73% (8 of 11) | 0% (0 of 1) | 71% (34 of 48) |
| Character on its own | 88% (36 of 41) | 58% (18 of 31) | 27% (16 of 59) | 53% (70 of 131) |
| Chariot | 68% (15 of 22) | 59% (10 of 17) | - | 64% (25 of 39) |
| Infantry | 51% (47 of 92) | 42% (15 of 36) | 60% (3 of 5) | 49% (65 of 133) |
| Monster | 62% (16 of 26) | 77% (10 of 13) | - | 67% (26 of 39) |
| Monstrous | 100% (8 of 8) | 64% (16 of 25) | - | 73% (24 of 33) |
| War Machines | 68% (56 of 82) | 100% (3 of 3) | - | 69% (59 of 85) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 4 | 75% (3 of 4); on the table 75% | 61% (22 of 36) | 31% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Dwarfen Mountain Holds | 10 | 100% (19 of 19); on the table 100% | - | 61% | 65% (55 of 85) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 15 | 78% (36 of 46); on the table 80% | 41% (47 of 114) | 50% | 62% (98 of 159) | 0.0 uses a game | 60% (3 of 5); 0.3 uses a game | 25% (2 of 8); 0.1 uses a game |
| Grand Cathay | 4 | 71% (15 of 21); on the table 71% | 17% (16 of 96) | 35% | 43% (15 of 35) | 100% (11 of 11); 8.2 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 7 | 80% (12 of 15); on the table 87% | 29% (7 of 24) | 29% | 42% (22 of 52) | 82% (9 of 11); 3.1 uses a game | 38% (3 of 8); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 66% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | - | 16% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 7 | 91% (21 of 23); on the table 96% | 11% (4 of 36) | 35% | 71% (35 of 49) | 71% (5 of 7); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (10 of 10); on the table 100% | 33% (4 of 12) | 3% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 62% (5 of 8); on the table 88% | 28% (5 of 18) | 37% | 61% (14 of 23) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 95% (21 of 22); on the table 95% | 33% (2 of 6) | 27% | 50% (15 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 97% (31 of 32); on the table 100% | 33% (16 of 48) | 22% | 47% (17 of 36) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 70% (7 of 10); on the table 80% | 17% (1 of 6) | 40% | 46% (12 of 26) | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 4 | 60% (3 of 5); on the table 80% | 33% (2 of 6) | 43% | 66% (25 of 38) | 100% (3 of 3); 3.2 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sf-h2h-mine-4394159-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (37) | 55% (30) | 47% (67) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.53 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.17 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.42 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.44 | 1.08 | 2.53 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.69 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.39 | 5.06 | 10.44 |

### Quality by phase: sf-h2h-mine-4394159-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (59 of 108) | 47% (118 of 252) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (218 of 580) | 48% (102 of 212) |
| Strategy | Close-in objectives charged next turn | 12% (14 of 121) | 19% (44 of 235) |
| Strategy | Support requests answered (helper made contact too) | 22% (2 of 9) | 44% (19 of 43) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 78% (7 of 9) |
| Strategy | Joined characters whose unit fought | 42% (20 of 48) | 47% (15 of 32) |
| Strategy | Lone characters that fought | 72% (71 of 98) | 74% (62 of 84) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 0.9 | 1.6 |
| Movement | Points that never moved of their own | 532.8 | 129.4 |
| Movement | Fights charged into per game | 2.2 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 73, net +7 | 25 of 131, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 73, net -3 | 21 of 131, net +76 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 73, net +134 | 12 of 131, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 73, net +118 | 41 of 131, net +208 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.5 | 11.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (223 of 558) | 43% (172 of 400) |
| Shooting | Points destroyed by shooting units | 165.3 | 59.2 |
| Shooting | War machine shots | 12.6 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (227 of 454) | 31% (21 of 68) |
| Shooting | Points destroyed by war machines | 152.2 | 32.6 |
| Magic | Magic missiles cast | 1.1 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (19 of 41) | 47% (15 of 32) |
| Magic | Wounds caused by magic missiles | 2.3 | 1.2 |
| Magic | Wounds caused by other spells | 1.1 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 71.3 | 29.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.2 / 0.9 / 0.0 | 2.5 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 264.7 | 410.4 |
| Combat | Points run down | 30.2 | 163.8 |
| Combat | Net points per charged fight, damage counted | +73 | +105 |
| Combat | Net per 100 charger points, damage counted | +28.4 | +33.4 |
| Combat | First round won (charged fights) | 76% | 72% |
| Combat | Net points per charged fight | +73 | +104 |
| Combat | Net points per supported fight / lone fight | +64 / +75 | +110 / +103 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 79 | 72 of 148 |
| Game | Points lost | 835.6 | 769.3 |
| Game | VP from objectives | 535.8 | 574.7 |
| Game | Lone holders (player turns) | 1.9 | 2.6 |

- Mine won / drew / lost: 14 / 8 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -119 VP
- The side that went first won 16 of 28 games with a winner
- Points traded per game (both sides' losses): 1605
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sf-h2h-mine-4394159-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 5.1 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +8.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 84.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +8.0 | 0.0 | 26.4 | 1.2 | +11.6 | 0.0 | 48.8 |
| BEST FACING | 0.5 | +13.4 | 0.0 | 30.2 | 0.6 | +23.5 | 0.0 | 40.1 |
| BEST FIRST | 3.9 | +152.0 | 132.8 | 82.0 | 4.3 | +169.4 | 172.0 | 56.4 |
| BEST MOVE FOR SHOOTERS | 1.2 | +118.0 | 0.0 | 30.6 | - | - | - | - |
| BEST OVERALL | 0.4 | +20.3 | 0.0 | 22.6 | 0.8 | +61.6 | 0.0 | 38.4 |
| BEST PREY | 0.6 | +32.0 | 46.0 | 19.5 | 1.0 | +42.9 | 37.8 | 11.7 |
| BEST PRIZE | 0.1 | -6.0 | 3.0 | 0.0 | 0.2 | -0.8 | 8.1 | 5.2 |
| BIG CHARACTER SAFETY | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 5.1 | 0.2 | +0.0 | 11.2 | 10.9 |
| BLOCKED WHEEL | 0.4 | +0.9 | 0.0 | 1.8 | 0.5 | +8.0 | 0.0 | 1.8 |
| BOMBING RUN | 0.0 | +0.3 | 0.9 | 1.7 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.2 | +0.0 | 7.6 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.4 | +60.0 | 90.4 | 19.4 |
| CANNON SIGHT KEPT | 2.1 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -3.1 | 0.0 | 0.0 | 0.0 | -0.2 | 2.9 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 2.9 | 2.9 | 0.1 | -1.8 | 14.7 | 0.0 |
| CAST JOB | 1.0 | +38.9 | 67.3 | 12.9 | 0.3 | +6.4 | 16.0 | 5.6 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.0 | +1.7 | 0.0 | 0.0 | 0.2 | +9.6 | 6.6 | 8.2 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 11.0 | 0.7 | +0.0 | 0.0 | 36.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -1.1 | 15.4 | 4.4 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 223.9 | 78.6 | 3.7 | +0.0 | 385.9 | 86.9 |
| CHARGE NOW WEIGHED | 0.4 | -31.4 | 28.8 | 22.1 | 0.6 | -49.9 | 17.7 | 22.6 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 6.3 | 4.6 | 0.2 | +0.0 | 17.4 | 2.9 |
| COMBAT PIVOT | 0.3 | +0.0 | 21.5 | 28.9 | 0.6 | +0.0 | 19.9 | 52.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 6.3 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.1 | +5.7 | 0.0 | 0.0 | 0.6 | +83.7 | 43.6 | 11.1 |
| COUNTER-CHARGE COVER | 11.6 | +995.3 | 0.0 | 251.9 | 6.1 | +615.0 | 0.0 | 233.1 |
| DEFENSIVE ARMY | 0.8 | -0.0 | 90.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.5 | +6.9 | 37.0 | 5.1 |
| ELIXIR WORTH | 0.0 | +3.5 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 17.5 | +0.0 | 1289.8 | 319.0 | - | - | - | - |
| FACE THE CAST | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +100.4 | 0.0 | 61.9 | 1.1 | +84.5 | 0.0 | 51.5 |
| FALLBACK BY WORTH | 4.6 | +37.2 | 0.0 | 40.9 | 6.4 | +64.1 | 0.0 | 111.2 |
| FIGHT LIFT | 0.0 | +0.2 | 1.7 | 0.0 | 0.1 | +0.4 | 1.7 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 5.6 | 0.0 | +0.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.6 | +0.0 | 120.4 | 32.3 | - | - | - | - |
| FIRE PLAN | 27.6 | +180.4 | 1948.2 | 495.3 | - | - | - | - |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 151.8 | 4.7 | +0.0 | 0.0 | 166.3 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +169.7 | 0.0 | 66.7 | 0.9 | +178.2 | 0.0 | 35.8 |
| FRIENDS SHOTS CHECKED | 0.5 | +39.9 | 0.0 | 23.8 | 0.2 | +9.9 | 0.0 | 12.1 |
| GIVES UP | 0.1 | -1.1 | 16.7 | 0.0 | 0.2 | -1.7 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 8.8 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 19.1 | 0.0 | 0.6 | +0.0 | 45.6 | 17.4 |
| HILL BY ITS CHANCE | 0.2 | -5.0 | 0.0 | 0.0 | 0.5 | -51.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 17.5 | +2928.2 | 1289.8 | 319.0 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +13.4 | 16.9 | 11.6 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 23.3 | 9.2 |
| HUNT IN PAIRS | 0.4 | +14.1 | 0.0 | 16.2 | 0.6 | +21.0 | 0.0 | 16.5 |
| HUNT KEPT | - | - | - | - | 0.2 | +7.4 | 22.2 | 3.2 |
| HUNT RESULT | 0.1 | +14.3 | 0.0 | 0.0 | 0.6 | +88.5 | 47.0 | 22.6 |
| HUNT THE GUNS | 0.1 | +24.3 | 13.1 | 1.7 | 0.6 | +223.9 | 38.1 | 17.2 |
| INVITES THE FIGHT | 2.1 | +38.3 | 66.1 | 36.5 | 1.1 | +20.3 | 45.6 | 14.8 |
| JOINT CHARGE PLAN | 0.1 | +6.5 | 12.0 | 0.0 | 0.1 | +3.0 | 19.2 | 5.7 |
| KEEP FALLS | 0.1 | +2.5 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 3.6 | 3.2 |
| KEEPS ITS TARGET | 1.2 | +35.8 | 82.1 | 3.9 | 2.6 | +78.3 | 192.3 | 76.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 5.2 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 2.7 | -13.4 | 307.5 | 80.7 | - | - | - | - |
| KILLS COUNT | 1.1 | +42.0 | 58.0 | 10.4 | 2.9 | +118.3 | 232.0 | 61.2 |
| KILLS COUNT NEXT TURN | 3.9 | +133.0 | 161.7 | 91.9 | 7.2 | +258.1 | 226.0 | 232.4 |
| LONE CHARACTER SAFE SPOT | 0.7 | +14.5 | 9.4 | 17.0 | 0.3 | +16.3 | 20.3 | 22.7 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 7.4 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +24.0 | 0.0 | 0.0 | 0.4 | +32.7 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -4.4 | 43.2 | 6.3 | 0.6 | +0.4 | 33.9 | 1.2 |
| LOST CHARGE | 2.8 | -47.2 | 143.9 | 75.3 | 2.4 | -42.8 | 84.1 | 84.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.3 | 0.0 | 2.9 | 0.0 | -0.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +23.3 | 36.0 | 19.1 | 1.0 | +149.3 | 31.9 | 36.8 |
| MANOEUVRE | 0.4 | +11.6 | 0.0 | 5.1 | 0.3 | +15.8 | 0.0 | 4.3 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.5 | +35.0 | 0.0 | 0.0 | 0.5 | +14.4 | 0.0 | 8.2 |
| MARCH ODDS | 0.1 | +8.1 | 14.6 | 5.8 | 0.2 | +23.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +53.6 | 0.0 | 36.5 | 0.6 | +35.5 | 0.0 | 11.1 |
| MAX FOR POSITIONING | 4.7 | +134.8 | 0.0 | 138.8 | 4.4 | +174.9 | 0.0 | 207.4 |
| MISSILES IN THE FIRE PLAN | 1.2 | +9.6 | 88.2 | 7.1 | - | - | - | - |
| MISSILES IN THE MOVE | 3.2 | +105.7 | 0.0 | 59.0 | 2.9 | +50.2 | 0.0 | 113.5 |
| MISSILES NEXT TURN | 3.9 | +67.7 | 0.0 | 96.5 | 3.8 | +41.2 | 0.0 | 107.9 |
| MODEL FACING | 0.7 | +203.7 | 0.0 | 11.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 12.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +7.4 | 0.0 | 2.4 | 0.2 | +3.4 | 0.0 | 5.6 |
| MOVE SPELL IN RANGE | 0.2 | +6.1 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.5 | 5.2 | 11.2 | 0.2 | -6.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 37.3 |
| MOVE TO CHARGE | 2.6 | +167.7 | 144.2 | 45.2 | 5.7 | +459.8 | 187.1 | 228.9 |
| MOVES UNITS SPELL | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +15.8 | 18.6 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.3 | 0.0 | 5.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -7.9 | 21.2 | 22.0 | 0.3 | -26.6 | 58.8 | 4.6 |
| NOT TURNED | 5.4 | +70.0 | 0.0 | 126.9 | 5.1 | +51.6 | 0.0 | 130.2 |
| NOT WORTH A CAST | 0.6 | -0.2 | 0.0 | 0.0 | 0.2 | -2.6 | 0.0 | 2.6 |
| OFF BEST | 15.0 | -688.5 | 11.3 | 257.2 | 14.6 | -712.1 | 23.1 | 246.3 |
| ONE YARDSTICK | 26.1 | -871.2 | 1001.5 | 450.0 | - | - | - | - |
| OPENS A LANE | 0.2 | +0.3 | 33.2 | 0.0 | 0.1 | +0.2 | 1.7 | 0.0 |
| OPENS UP | 0.1 | +7.5 | 10.8 | 0.0 | 0.3 | +25.7 | 15.8 | 0.0 |
| OVERRUNS AWAY | 0.4 | +10.5 | 40.4 | 23.7 | 0.6 | +13.0 | 44.1 | 10.6 |
| PATHS CROSS | 1.7 | +98.7 | 0.0 | 34.3 | 2.7 | +171.3 | 0.0 | 52.1 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | 0.1 | +6.2 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -5.6 | 0.0 | 12.8 | 0.1 | -0.3 | 0.0 | 0.0 |
| PLAN RESULT | 40.1 | +1994.7 | 1846.4 | 1108.4 | 39.8 | +1236.7 | 1637.8 | 1178.1 |
| PURSUES BIG PREY | 0.1 | -13.4 | 0.0 | 6.5 | 0.4 | -29.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +7.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.3 | +10.7 | 0.0 | 9.9 | 1.2 | +14.2 | 0.0 | 21.1 |
| RANDOM MOVER NO PROMISE | 0.1 | -1.0 | 1.5 | 0.0 | 0.2 | -12.6 | 9.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +9.8 | 0.0 | 9.2 |
| REDIRECT COUNTER | 1.4 | +90.4 | 0.0 | 27.6 | 3.5 | +262.9 | 0.0 | 44.1 |
| REDIRECT WEIGHED | 0.1 | +0.2 | 0.0 | 10.3 | 0.6 | +26.2 | 24.4 | 13.1 |
| RESERVE FALL BACK | 0.2 | +5.0 | 0.0 | 13.0 | 1.1 | +42.5 | 0.0 | 17.4 |
| RESTRAINS TO SHOOT | 0.3 | +8.7 | 0.0 | 20.2 | 0.2 | +9.9 | 0.0 | 9.2 |
| RISK BY ARC | 2.1 | +106.3 | 236.2 | 70.3 | 4.2 | +112.9 | 322.5 | 106.2 |
| SAFER THAN THE JOB | 0.9 | +40.2 | 0.0 | 12.3 | 0.7 | +49.5 | 0.0 | 7.0 |
| SCOUT SPOT | 0.6 | +0.4 | 0.0 | 0.9 | 0.7 | +3.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.9 | 0.8 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -26.2 | 0.0 | 4.8 |
| SEARCH SPOT | 3.0 | +123.7 | 0.0 | 61.4 | 3.0 | +181.3 | 0.0 | 85.9 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.9 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.3 | +83.0 | 0.0 | 21.9 | 0.5 | +144.3 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.1 | +57.5 | 51.9 | 27.4 | 1.7 | +227.9 | 40.3 | 83.4 |
| SET-UP ANY TARGET | 0.0 | +1.6 | 0.0 | 0.0 | 0.2 | +38.0 | 11.1 | 11.1 |
| SET-UP MISSED | 0.0 | +3.7 | 0.0 | 0.0 | 0.1 | +21.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 5.1 | +374.5 | 474.2 | 111.7 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.8 | +1.5 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 3.2 | +38.3 | 0.0 | 30.6 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.7 | +23.9 | 27.7 | 15.2 | 1.1 | +34.6 | 32.7 | 22.1 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 3.3 | - | - | - | - |
| SHOT OPTIONS | 25.8 | +0.0 | 1644.9 | 488.2 | 12.0 | +0.0 | 459.6 | 241.4 |
| SHOT REPLANNED | - | - | - | - | 0.2 | +0.0 | 28.6 | 1.8 |
| SHOTS IN THE MOVE | 24.0 | +1142.1 | 0.0 | 439.5 | 11.2 | +365.3 | 0.0 | 191.2 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.0 | +1.6 | 0.0 | 0.0 | 0.3 | +59.5 | 39.5 | 11.1 |
| SPELL WORTH | 0.8 | +13.3 | 31.7 | 30.0 | 2.2 | +55.2 | 135.7 | 126.3 |
| STABLE ROLE | 13.4 | +0.0 | 523.6 | 191.1 | 9.1 | +0.0 | 288.4 | 150.3 |
| STANDS TO CAST | 0.0 | +1.8 | 0.0 | 8.2 | - | - | - | - |
| STAY WORTH | 26.8 | +220.1 | 857.2 | 360.4 | - | - | - | - |
| STOPS | 0.1 | +2.9 | 13.1 | 1.7 | 0.4 | +16.7 | 37.4 | 8.8 |
| STOPS SHORT OF THE FLANK | 0.2 | +5.0 | 0.0 | 1.7 | 0.3 | +23.6 | 0.0 | 26.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 9.9 | 0.2 | +0.0 | 0.0 | 11.7 |
| SUPPORT NARROWED | 4.9 | -46.7 | 254.9 | 142.2 | 6.7 | -38.3 | 360.7 | 110.6 |
| SUPPORTS | 3.4 | +59.3 | 131.8 | 89.8 | 3.8 | +40.6 | 123.6 | 61.6 |
| SURE CHARGE BEATS ADVANCE | 0.3 | -11.6 | 33.1 | 0.0 | 0.0 | -0.1 | 1.1 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -5.0 | 13.1 | 5.0 | 0.9 | +4.3 | 29.4 | 44.8 |
| THROUGH LINE OF FIRE | 0.6 | +28.2 | 0.0 | 1.8 | 0.4 | +10.2 | 0.0 | 7.0 |
| TURN WORTH | 0.4 | -36.8 | 27.7 | 1.7 | 0.5 | -38.8 | 39.4 | 1.2 |
| TWO OR MORE ARRIVE | 0.3 | +2.0 | 8.2 | 3.3 | 0.4 | +11.3 | 12.8 | 27.7 |
| WAIT AFTER COSTS | 7.2 | -291.7 | 308.2 | 131.1 | 8.4 | -423.1 | 280.1 | 271.8 |
| WALKS TO THE FIGHT | 2.7 | +62.7 | 78.4 | 41.2 | 0.9 | +18.3 | 19.2 | 10.3 |
| WAR ENGINE CHARGES | 0.2 | +18.9 | 4.2 | 39.6 | 0.1 | +5.7 | 1.7 | 10.3 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 42.2 | 26.2 | 0.1 | +0.0 | 6.6 | 5.1 |
| WEARS DOWN | 1.0 | +52.1 | 155.0 | 52.1 | 1.4 | +57.9 | 147.6 | 30.0 |
| WHO HITS BACK | 0.4 | +20.8 | 0.0 | 11.5 | 0.2 | +15.4 | 0.0 | 8.9 |
| WHOLE FIGHT | 0.4 | +34.3 | 63.8 | 0.0 | 0.4 | +33.9 | 47.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +5.8 | 0.0 | 11.6 | 1.0 | +84.3 | 98.2 | 22.3 |

### Rule changes: sf-h2h-mine-4394159-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1064 | 1064 | 1064 | 29.56 | -50426 | -47.4 |
| BEST FIRST | 298 | 298 | 298 | 8.28 | +11569 | +38.8 |
| FIRE PLAN | 995 | 995 | 249 | 6.92 | +4166 | +16.7 |
| SEARCH SPOT | 216 | 216 | 213 | 5.92 | +11014 | +51.7 |
| COUNTER-CHARGE COVER | 638 | 360 | 166 | 4.61 | +10986 | +66.2 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +9720 | +61.9 |
| MOVE TO CHARGE | 297 | 297 | 149 | 4.14 | +8582 | +57.6 |
| SHOTS IN THE MOVE | 1268 | 853 | 134 | 3.72 | +3266 | +24.4 |
| EVERY WOUND COUNTS | 630 | 630 | 132 | 3.67 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 399 | 399 | 122 | 3.39 | +3050 | +25.0 |
| ARTILLERY RE-ROLL WEIGHED | 111 | 111 | 111 | 3.08 | +0 | +0.0 |
| ONE YARDSTICK | 938 | 439 | 103 | 2.86 | +1361 | +13.2 |
| SUPPORTS | 260 | 260 | 101 | 2.81 | +1093 | +10.8 |
| CANNON SIGHT KEPT | 95 | 95 | 95 | 2.64 | +0 | +0.0 |
| FACES THE THREAT | 91 | 91 | 91 | 2.53 | +6658 | +73.2 |
| FALLBACK BY WORTH | 393 | 393 | 81 | 2.25 | +3648 | +45.0 |
| FOLLOW UP WEIGHED | 73 | 73 | 73 | 2.03 | +12525 | +171.6 |
| WALKS TO THE FIGHT | 130 | 130 | 67 | 1.86 | +856 | +12.8 |
| WAIT AFTER COSTS | 562 | 562 | 65 | 1.81 | +1019 | +15.7 |
| FIRE IN ORDER | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +3230 | +55.7 |
| SCOUT WAITS | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| REDIRECT COUNTER | 178 | 105 | 49 | 1.36 | +3126 | +63.8 |
| RISK BY ARC | 227 | 222 | 49 | 1.36 | +2044 | +41.7 |
| RESERVE FALL BACK | 46 | 46 | 46 | 1.28 | +1707 | +37.1 |
| BEST MOVE FOR SHOOTERS | 45 | 45 | 45 | 1.25 | +4248 | +94.4 |
| SET UP TOGETHER | 98 | 85 | 44 | 1.22 | +4499 | +102.3 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +2948 | +70.2 |
| CHARGE NOW FIRST | 217 | 217 | 42 | 1.17 | -3195 | -76.1 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| KEEPS THE TARGET | 96 | 96 | 41 | 1.14 | -1377 | -33.6 |
| BEST FACING | 40 | 40 | 40 | 1.11 | +1329 | +33.2 |
| STAY WORTH | 964 | 799 | 40 | 1.11 | +543 | +13.6 |
| SHOOTERS IN TWO RANKS | 38 | 38 | 38 | 1.06 | +70 | +1.8 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2593 | +72.0 |
| MAX FOR POSITIONING | 330 | 205 | 36 | 1.00 | +363 | +10.1 |
| THROUGH LINE OF FIRE | 36 | 36 | 36 | 1.00 | +1382 | +38.4 |
| HONEST THREAT | 630 | 630 | 35 | 0.97 | +0 | +0.0 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 53 | 53 | 34 | 0.94 | +895 | +26.3 |
| BLOCKED WHEEL | 33 | 33 | 33 | 0.92 | +318 | +9.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2039 | +61.8 |
| SHOOTS FROM THE BEST SPOT | 64 | 64 | 32 | 0.89 | +1113 | +34.8 |
| MARCH CHECK | 38 | 35 | 31 | 0.86 | +1534 | +49.5 |
| MISSILES IN THE MOVE | 219 | 122 | 30 | 0.83 | +754 | +25.1 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +1504 | +53.7 |
| FRIENDS SHOTS CHECKED | 27 | 27 | 27 | 0.75 | +1792 | +66.4 |
| BEST PREY | 58 | 58 | 26 | 0.72 | +862 | +33.1 |
| KILLS COUNT | 143 | 140 | 26 | 0.72 | +988 | +38.0 |
| MODEL FACING | 26 | 26 | 26 | 0.72 | +7334 | +282.1 |
| CAST JOB | 48 | 48 | 25 | 0.69 | +709 | +28.4 |
| WHO HITS BACK | 24 | 24 | 24 | 0.67 | +743 | +31.0 |
| MANOEUVRE | 26 | 26 | 23 | 0.64 | +987 | +42.9 |
| INVITES THE FIGHT | 113 | 113 | 21 | 0.58 | +331 | +15.7 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.56 | +1028 | +51.4 |
| WHOLE FIGHT GAIN | 40 | 35 | 20 | 0.56 | +1219 | +60.9 |
| MOVE AND CAST | 19 | 19 | 19 | 0.53 | +389 | +20.5 |
| PURSUES BIG PREY | 18 | 18 | 18 | 0.50 | -1531 | -85.0 |
| SHOOTERS ARE THREATS | 185 | 185 | 18 | 0.50 | +0 | +0.0 |
| SHORT GUN FORWARD | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| WEARS DOWN | 88 | 85 | 18 | 0.50 | +721 | +40.0 |
| MAKE SURE TOGETHER | 51 | 37 | 17 | 0.47 | +2675 | +157.3 |
| RESTRAINS TO SHOOT | 17 | 17 | 17 | 0.47 | +667 | +39.2 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| KEEPS ITS TARGET | 137 | 135 | 14 | 0.39 | +264 | +18.8 |
| LOST CHARGE | 188 | 188 | 12 | 0.33 | +367 | +30.6 |
| SURE REACH TOGETHER | 52 | 40 | 12 | 0.33 | +99 | +8.2 |
| MARCH ODDS | 11 | 11 | 11 | 0.31 | +309 | +28.1 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -421 | -38.3 |
| CANNON PLANNED TARGET | 50 | 50 | 10 | 0.28 | -360 | -36.0 |
| HUNT IN PAIRS | 38 | 25 | 10 | 0.28 | +217 | +21.7 |
| OPENS UP | 15 | 15 | 10 | 0.28 | +325 | +32.5 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -703 | -78.1 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -40 | -5.0 |
| WAR ENGINE JOBS | 31 | 31 | 8 | 0.22 | -542 | -67.7 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SHOT REPLANNED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SUPPORT NARROWED | 418 | 418 | 7 | 0.19 | -80 | -11.5 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | +1 | +0.2 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| DEFENSIVE ARMY | 30 | 30 | 6 | 0.17 | -289 | -48.2 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +41 | +6.8 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -210 | -35.1 |
| STOPS | 17 | 17 | 6 | 0.17 | +128 | +21.4 |
| WHOLE FIGHT | 29 | 27 | 6 | 0.17 | +879 | +146.4 |
| HUNT ADVANCE | 11 | 11 | 5 | 0.14 | +108 | +21.6 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| MISSILES NEXT TURN | 277 | 150 | 5 | 0.14 | +2 | +0.4 |
| BACKUP TARGETS | 78 | 46 | 4 | 0.11 | +51 | +12.8 |
| OVERRUNS AWAY | 33 | 33 | 4 | 0.11 | +171 | +42.6 |
| SHOOTERS TO THE PRIMARY | 115 | 86 | 4 | 0.11 | +56 | +13.9 |
| CASTING BLOCK | 7 | 7 | 3 | 0.08 | +146 | +48.8 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -48 | -15.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +205 | +68.3 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +39 | +13.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +347 | +115.7 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +118 | +39.3 |
| REDIRECT BY WHAT IT STOPS | 11 | 11 | 3 | 0.08 | +280 | +93.5 |
| CARRIES OUT COUNTER | 2 | 2 | 2 | 0.06 | -119 | -59.6 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -64 | -32.2 |
| EDGE GIVE GROUND | 19 | 19 | 2 | 0.06 | +5 | +2.6 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +169 | +84.3 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +18 | +8.9 |
| WAR ENGINE CHARGES | 9 | 9 | 2 | 0.06 | +160 | +79.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +13 | +12.9 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +15 | +15.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +25 | +24.9 |
| JOINT CHARGE PLAN | 8 | 8 | 1 | 0.03 | +64 | +64.0 |
| MISSILES IN THE FIRE PLAN | 43 | 10 | 1 | 0.03 | +7 | +6.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -11 | -10.7 |
| TURN WORTH | 33 | 32 | 1 | 0.03 | +28 | +28.1 |
| ARRIVAL HUNT | 7 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 370 | not checked | - | - | - | - |
| GIVES UP | 10 | 9 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 23 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 23 | trace | - | - | - | - |
| HUNT THE GUNS | 23 | trace | - | - | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 34 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 7 | 7 | 0 | 0.00 | - | - |
| LONG SHOT | 34 | 33 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 42 | 42 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 376 | 376 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 28 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2876 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 44 | 44 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 29 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1361 | 1361 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 107 | not checked | - | - | - | - |
| STABLE ROLE | 812 | 810 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 23 | 0 | 0.00 | - | - |

### Off best figure: sf-h2h-mine-4394159-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.53 | 12.89 | 47.8 |
| FALLBACK | gate | 0.47 | 0.72 | 53.0 |
| CHARGE NOW FIRST | rule | 0.56 | 0.61 | 76.1 |
| TURN GATE | gate | 0.56 | 0.50 | 41.9 |
| KEEPS THE TARGET | rule | 0.75 | - | 81.0 |
| FIRE PLAN | rule | 0.50 | - | 47.0 |
| PURSUES BIG PREY | rule | 0.14 | 0.36 | 85.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.28 | 0.03 | 38.3 |
| BLOCKED WHEEL | rule | 0.08 | 0.19 | 25.6 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.22 | 24.3 |
| BEST PRIZE | rule | 0.06 | 0.19 | 78.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.06 | 41.2 |
| PATHS CROSS | rule | 0.03 | 0.22 | 32.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 48.9 |
| WAR ENGINE JOBS | rule | 0.19 | 0.03 | 67.7 |
| CHAFF PASSED | rule | - | 0.17 | 6.5 |
| DEFENSIVE ARMY | rule | 0.17 | - | 48.2 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 35.1 |
| SUPPORT NARROWED | rule | 0.11 | 0.06 | 13.4 |
| AFTERMATH BAND | gate | 0.11 | 0.03 | 1.7 |
| CANNON PLANNED TARGET | rule | - | 0.14 | 79.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.08 | 79.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.03 | 6.3 |
| CATCH ODDS | rule | 0.03 | 0.06 | 15.8 |
| NO REASON | gate | 0.08 | - | 22.9 |
| RULE SWITCHED OFF | gate | - | 0.08 | 5.7 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 59.6 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 32.2 |
| REDIRECT WEIGHED | rule | - | 0.06 | 81.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 5.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 16.5 |
| FACES THE THREAT | rule | 0.03 | - | 7.5 |
| FIGHT ORDER BAND | gate | - | 0.03 | 1.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.3 |
| STANDS TO CAST | rule | 0.03 | - | 10.7 |
| WHO HITS BACK | rule | 0.03 | - | 0.6 |

### Plans: sf-h2h-mine-4394159-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.3 | 14% | 475 | 284 | 60% |
| Mine | charge | 2.6 | 60% | 233 | 283 | 121% |
| Mine | close in | 3.4 | 31% | 203 | 176 | 87% |
| Mine | hold | 4.6 | 30% | 266 | 0 | 0% |
| Mine | join | 1.0 | 97% | 24 | 0 | 0% |
| Mine | shoot | 13.8 | 62% | 488 | 1252 | 257% |
| Mine | support | 3.5 | 86% | 38 | 0 | 0% |
| Opponent | advance | 12.9 | 19% | 362 | 327 | 90% |
| Opponent | charge | 6.0 | 52% | 659 | 479 | 73% |
| Opponent | close in | 6.4 | 29% | 532 | 148 | 28% |
| Opponent | hold | 4.5 | 43% | 315 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 30 | 0 | 0% |
| Opponent | shoot | 4.8 | 60% | 177 | 294 | 167% |
| Opponent | support | 4.4 | 88% | 42 | 0 | 0% |

### Packages: hunt the guns, sf-h2h-mine-4394159-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 50% | 2.0 | 438 | 258 | 50% | 35 |
| Opponent | 0.6 | 21 | 0 | 48% | 52% | 0% | 2.5 | 384 | 152 | 48% | 199 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 482 | 476 | 100% | 74 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.7 | 5 | 0 | 40% | 40% | 20% | 2.0 | 402 | 94 | 20% | 110 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 471 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.9 | 6 | 0 | 67% | 83% | 0% | 2.4 | 484 | 327 | 83% | 247 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Tomb Kings of Khemri | 1.2 | 7 | 0 | 29% | 29% | 0% | 2.5 | 368 | 69 | 29% | 145 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 243 |
| Warriors of Chaos | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 274 | 0 | 0% | 134 |
| Wood Elf Realms | 0.5 | 2 | 0 | 100% | 100% | 0% | 3.0 | 207 | 157 | 100% | 275 |

### Battle groups: sf-h2h-mine-4394159-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.6 | 31% | 45% | 8% | 30% | 32% | 13% | 9% | 46% | 0% |
| Mine | REDIRECT COUNTER | 1.4 | 38% | 70% | 40% | 12% | 17% | 0% | 0% | 83% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.1 | 17% | 71% | 13% | 40% | 21% | 6% | 33% | 39% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 21% | 81% | 15% | 25% | 17% | 0% | 17% | 65% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sf-h2h-mine-4394159-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 22 | 34 (22) | 22 | 12 | 59 | 32% | 2.1 | 49 (10) | 14 (6) | 34 (6) | 44 (17) | 0 (5) |
| Mine | Character | 132 | 46 (132) | 46 | 0 | 41 | 21% | 2.4 | 28 (35) | 63 (70) | 11 (8) | 51 (63) | 51 (50) |
| Mine | Clean-up | 18 | 49 (18) | 4 | 45 | 26 | 50% | 2.7 | 0 (2) | 54 (15) | 0 (1) | 55 (15) | 0 (3) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 50% | 1.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Mine | Fast Hammer | 30 | 66 (30) | 54 | 12 | 39 | 33% | 2.4 | 46 (10) | 72 (16) | 93 (4) | 54 (19) | 86 (11) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 74 | 100% | - | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Mine | Hammer | 71 | 34 (71) | 24 | 10 | 47 | 13% | 2.1 | 12 (16) | 44 (48) | 21 (7) | 27 (47) | 45 (24) |
| Mine | Holder | 11 | 99 (11) | 48 | 51 | 29 | 36% | 3.4 | 77 (2) | 129 (6) | 33 (3) | 135 (7) | 43 (4) |
| Mine | Shooter | 68 | 96 (68) | 24 | 72 | 51 | 0% | 1.8 | 48 (12) | 126 (39) | 52 (17) | 134 (40) | 46 (28) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | - | - | - | - | - |
| Mine | War machine | 109 | 56 (109) | 56 | 0 | 48 | 4% | 1.2 | 60 (23) | 51 (71) | 73 (15) | 60 (25) | 55 (84) |
| Mine | Wizard | 14 | 12 (14) | 12 | 0 | 72 | 14% | 2.5 | 0 (3) | 40 (5) | 0 (1) | 0 (3) | 30 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 85 | 61 (85) | 15 | 47 | 46 | 35% | 2.4 | 75 (44) | 48 (11) | 46 (30) | 49 (67) | 104 (18) |
| Opponent | Character | 89 | 62 (89) | 62 | 0 | 37 | 17% | 2.2 | 81 (29) | 53 (50) | 80 (5) | 55 (52) | 79 (32) |
| Opponent | Clean-up | 24 | 54 (24) | 22 | 31 | 49 | 42% | 3.7 | 40 (7) | 48 (13) | 103 (4) | 58 (15) | 49 (9) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 67 | 33% | 4.5 | - | 0 (3) | - | - | 0 (3) |
| Opponent | Fast | 2 | 275 (2) | 275 | 0 | 100 | 50% | 5.0 | - | 275 (2) | - | 275 (2) | - |
| Opponent | Fast Hammer | 38 | 38 (38) | 24 | 14 | 64 | 21% | 3.3 | 8 (17) | 91 (11) | 52 (10) | 32 (23) | 46 (15) |
| Opponent | Fragile | 10 | 79 (10) | 79 | 0 | 44 | 20% | 2.4 | - | 65 (8) | 146 (2) | 79 (6) | 78 (4) |
| Opponent | Hammer | 62 | 48 (62) | 36 | 12 | 47 | 24% | 2.7 | 5 (12) | 58 (42) | 25 (8) | 51 (39) | 42 (23) |
| Opponent | Holder | 37 | 86 (37) | 8 | 78 | 14 | 32% | 2.5 | 74 (8) | 106 (22) | 36 (6) | 125 (26) | 18 (10) |
| Opponent | Shooter | 29 | 56 (29) | 24 | 32 | 32 | 10% | 1.5 | 0 (6) | 80 (20) | 0 (3) | 57 (18) | 55 (11) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 34 | 50% | 6.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 15 | 71 (15) | 71 | 0 | 26 | 7% | 1.0 | 0 (4) | 48 (7) | 207 (4) | 54 (5) | 78 (10) |
| Opponent | Wizard | 27 | 15 (27) | 15 | 0 | 30 | 22% | 1.9 | 28 (10) | 11 (9) | 0 (5) | 15 (13) | 19 (11) |

### Charged fights: sf-h2h-mine-4394159-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 328 | 154 | 1.8 | 1.0 | 88 | 89 | -1 | 6 of 7 | 4 of 7 | - | -1 |
| Mine | Dwarfen Mountain Holds | 10 | 457 | 44 | 1.3 | 1.2 | 34 | 28 | +6 | 2 of 13 | 8 of 13 | +42 | -5 |
| Mine | Empire of Man | 12 | 568 | 271 | 1.4 | 1.2 | 191 | 31 | +161 | 9 of 17 | 16 of 17 | +150 | +162 |
| Mine | Grand Cathay | 3 | 316 | 553 | 4.0 | 1.1 | 138 | 19 | +119 | 4 of 12 | 12 of 12 | -233 | +151 |
| Mine | High Elf Realms | 2 | 175 | 383 | 3.0 | 1.2 | 128 | 80 | +47 | 1 of 6 | 6 of 6 | -18 | +60 |
| Mine | Lizardmen | 1 | 0 | 182 | 6.0 | 1.0 | 30 | 0 | +30 | 1 of 6 | 4 of 6 | - | +30 |
| Mine | Ogre Kingdoms | 2 | 0 | 328 | 6.0 | 1.1 | 55 | 29 | +26 | 3 of 12 | 5 of 12 | +0 | +28 |
| Mine | Skaven | 1 | 0 | 199 | 3.0 | 1.0 | 66 | 70 | -4 | 1 of 3 | 2 of 3 | - | -4 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 796 | 3.0 | 1.7 | 265 | 0 | +265 | 1 of 3 | 3 of 3 | +234 | +329 |
| **Mine** | all armies | 36 | 389 | 238 | 2.2 | 1.1 | 108 | 35 | +73 | 28 of 79 | 60 of 79 | +64 | +75 |
| Opponent | Empire of Man | 3 | 135 | 222 | 1.3 | 1.0 | 167 | 0 | +167 | 2 of 4 | 4 of 4 | - | +167 |
| Opponent | Grand Cathay | 1 | 420 | 550 | 5.0 | 1.0 | 110 | 128 | -18 | 0 of 5 | 4 of 5 | - | -18 |
| Opponent | High Elf Realms | 5 | 206 | 458 | 4.4 | 1.2 | 104 | 9 | +95 | 9 of 22 | 15 of 22 | +225 | +66 |
| Opponent | Kingdom of Bretonnia | 1 | 295 | 791 | 3.0 | 1.0 | 264 | 0 | +264 | 1 of 3 | 3 of 3 | - | +264 |
| Opponent | Ogre Kingdoms | 5 | 125 | 301 | 4.2 | 1.6 | 72 | 62 | +9 | 13 of 21 | 12 of 21 | -74 | +51 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 1568 | 7.0 | 1.1 | 224 | 8 | +216 | 2 of 7 | 6 of 7 | +234 | +213 |
| Opponent | Skaven | 2 | 95 | 131 | 1.5 | 1.3 | 87 | 0 | +87 | 2 of 3 | 3 of 3 | +185 | +38 |
| Opponent | Tomb Kings of Khemri | 5 | 59 | 1086 | 4.2 | 1.2 | 258 | 9 | +249 | 14 of 21 | 16 of 21 | +294 | +239 |
| Opponent | Vampire Counts | 6 | 56 | 528 | 5.7 | 1.3 | 93 | 44 | +49 | 17 of 34 | 22 of 33 | +94 | +39 |
| Opponent | Warriors of Chaos | 3 | 0 | 486 | 3.3 | 1.1 | 146 | 6 | +140 | 6 of 10 | 8 of 10 | +347 | +117 |
| Opponent | Wood Elf Realms | 4 | 189 | 463 | 4.5 | 1.3 | 103 | 7 | +96 | 6 of 18 | 13 of 18 | +70 | +109 |
| **Opponent** | all armies | 36 | 121 | 543 | 4.1 | 1.3 | 132 | 28 | +104 | 72 of 148 | 106 of 147 | +110 | +103 |

### Effective charges: sf-h2h-mine-4394159-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 7 | 1 (net +238) | 0 | 3 (net -207) | 0 | 0 | 2 (net +94) | 1 | 50% (3 of 6) |
| Mine | Dwarfen Mountain Holds | 13 | 3 (net -55) | 0 | 3 (net -35) | 2 (net -48) | 0 | 5 (net +88) | 0 | 23% (3 of 13) |
| Mine | Empire of Man | 17 | 3 (net +70) | 0 | 2 (net +235) | 4 (net +190) | 2 (net +144) | 6 (net +167) | 0 | 12% (2 of 17) |
| Mine | Grand Cathay | 12 | 1 (net +0) | 1 (net -233) | 1 (net +77) | 4 (net +252) | 2 (net +48) | 3 (net +159) | 0 | 8% (1 of 12) |
| Mine | High Elf Realms | 6 | 0 | 0 | 1 (net +144) | 0 | 3 (net -6) | 1 (net +158) | 1 | 20% (1 of 5) |
| Mine | Lizardmen | 6 | 1 (net +0) | 0 | 1 (net +0) | 3 (net +18) | 0 | 1 (net +127) | 0 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 12 | 0 | 1 (net -34) | 1 (net +0) | 1 (net +0) | 1 (net +371) | 4 (net +9) | 4 | 12% (1 of 8) |
| Mine | Skaven | 3 | 1 (net -210) | 0 | 0 | 0 | 0 | 2 (net +100) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net +467) | 1 (net +329) | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 4 | 0 | 0 | 1 (net +310) | 0 | 0 | 3 (net +119) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 5 | 1 (net -205) | 0 | 1 (net +230) | 2 (net +112) | 1 (net -339) | 0 | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 22 | 6 (net +64) | 1 (net +95) | 3 (net +83) | 3 (net +76) | 3 (net +232) | 5 (net +88) | 1 | 14% (3 of 21) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 2 (net +282) | 0 | 1 (net +227) | 0 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 21 | 7 (net -12) | 0 | 1 (net -185) | 3 (net -76) | 0 | 6 (net +142) | 4 | 6% (1 of 17) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +185) | 0 | 0 | 0 | 0 | 1 (net +234) | 5 | 0% (0 of 2) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +131) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 21 | 1 (net -195) | 0 | 3 (net +244) | 4 (net +317) | 2 (net +170) | 9 (net +319) | 2 | 16% (3 of 19) |
| Opponent | Vampire Counts | 34 | 4 (net +71) | 0 | 9 (net +4) | 11 (net +28) | 5 (net +28) | 4 (net +228) | 1 | 27% (9 of 33) |
| Opponent | Warriors of Chaos | 10 | 1 (net +0) | 0 | 1 (net +95) | 2 (net +0) | 1 (net +0) | 5 (net +260) | 0 | 10% (1 of 10) |
| Opponent | Wood Elf Realms | 18 | 4 (net +21) | 1 (net +0) | 2 (net +63) | 3 (net +108) | 0 | 5 (net +212) | 3 | 13% (2 of 15) |

### Charged fights, damage counted: sf-h2h-mine-4394159-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 225 | 297 | +7 | 89 | 42 | +47 | +20.8 |
| Mine | 50-54% | 2 | 318 | 153 | -134 | 102 | 134 | -31 | -9.9 |
| Mine | Effective (55-75%) | 12 | 294 | 304 | -3 | 74 | 78 | -4 | -1.3 |
| Mine | 76-89% | 14 | 208 | 200 | +124 | 144 | 48 | +97 | +46.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 227 | 166 | +118 | 168 | 51 | +117 | +51.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 453 | 101 | +134 | 205 | 101 | +104 | +22.9 |
| Mine | No odds | 6 | 154 | 166 | +22 | 36 | 15 | +22 | +13.9 |
| Mine | All fights | 79 | 256 | 203 | +73 | 131 | 58 | +73 | +28.4 |
| Opponent | Long shot (under 50%) | 25 | 180 | 190 | +18 | 102 | 72 | +30 | +16.4 |
| Opponent | 50-54% | 2 | 174 | 100 | +48 | 48 | 9 | +38 | +22.1 |
| Opponent | Effective (55-75%) | 21 | 335 | 209 | +76 | 125 | 43 | +82 | +24.5 |
| Opponent | 76-89% | 30 | 312 | 182 | +90 | 130 | 30 | +100 | +32.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 343 | 202 | +208 | 226 | 31 | +195 | +56.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 553 | 127 | +70 | 147 | 74 | +73 | +13.3 |
| Opponent | No odds | 17 | 276 | 182 | +75 | 103 | 32 | +71 | +25.7 |
| Opponent | All fights | 148 | 315 | 187 | +104 | 148 | 43 | +105 | +33.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sf-h2h-mine-4394159-p2 | move | 461 | 106 (23%) | 71 (15%) | 52 (11%) | 303 (66%) |
| sf-h2h-mine-4394159-p2 | objective | 356 | 58 (16%) | 36 (10%) | 40 (11%) | 258 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0334, L0524, L0527, L0626, L0724, L0925, L0934, L2226 |
| Clockwork Compass | Mine | L1215, L1222 |
| Clockwork Compass | Opponent | L0312 |
| Elixir of Power | Mine | L1118 |
| Elixir of Power | Opponent | L1819 |
| Fistful of Laurels | Mine | L1819, L1832 |
| Fistful of Laurels | Opponent | L0518, L0618, L0718, L0818, L1118 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Opponent | L0524, L0527, L0724, L0925 |
| Opal Amulet | Opponent | L0314 |
| Periapt of Soul Exchange | Mine | L2122 |
| Periapt of Soul Exchange | Opponent | L0520, L0720 |
| Ring of Doom | Mine | L1118, L1215, L1222, L1533, L1535 |
| Ring of Doom | Opponent | L0312, L0531, L0715, L0915, L1215, L1533 |
| Ring of Jet | Mine | L1118, L1215, L1222 |
| Ring of Jet | Opponent | L0312 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2122 |
| Twice-Blessed Armour | Mine | L0715, L0718, L0720, L0724 |
| Twice-Blessed Armour | Opponent | L0407 |
| Witch Hunter's Ward | Mine | L0715, L0718, L0720, L0724, L0809, L0818, L0823 |
| Witch Hunter's Ward | Opponent | L0407 |

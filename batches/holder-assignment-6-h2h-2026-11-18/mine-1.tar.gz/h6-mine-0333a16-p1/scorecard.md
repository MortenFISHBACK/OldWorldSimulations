# Doctrine scorecard: h6-mine-0333a16-p1

### Scorecard: h6-mine-0333a16-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 340 |
| L0120 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 4 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Mine | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 8 | 2 | 4 | 0 | 1 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 225 |
| L0304 | 4 | 1 | Opponent | no | 6 | 3 | 2 | 4 | 0 | 0 | 0 | 310 |
| L0321 | 3 | 1 | Mine | no | 6 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0321 | 3 | 1 | Opponent | no | 4 | - | 0 | 3 | 2 | 0 | 0 | 210 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 844 |
| **Average** | | | Mine | 0% | 2.0 | 3.8 | 1.1 | 1.4 | 0.3 | 0.0 | 0.0 | 112.9 |
| **Average** | | | Opponent | 14% | 3.1 | 3.0 | 0.9 | 1.4 | 0.3 | 0.0 | 0.0 | 243.4 |

### KPIs: h6-mine-0333a16-p1

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 7 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 35% (9 of 26) | 27% (7 of 26) | 31% (16 of 52) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (8 of 8); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (11 of 11); on the table 100% | 100% (15 of 15); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 45% (59 of 132) | 38% (16 of 42) | 43% (75 of 174) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (59 of 120) | 43% (16 of 37) | 48% (75 of 157) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 79% (19 of 24) | 71% (22 of 31) |
| Points that never fought | lower | 60% (7637 of 12789) | 60% (8412 of 13995) | 60% (16049 of 26784) |
|   infantry points that never fought | lower | 70% (2738 of 3938) | 74% (2836 of 3852) | 72% (5574 of 7790) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (24 of 44) | 53% (31 of 58) | 54% (55 of 102) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 3.3 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (7 of 7); 2.0 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.7 uses a game | 100% (4 of 4); 0.6 uses a game | 75% (9 of 12); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (4896 of 9714) | 48% (5824 of 12103) | 49% (10720 of 21817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.9 (66%) | 1.9 (50%) | 8.7 (62%) |
| MARCHED: its unit marched | 1.4 (14%) | 1.0 (27%) | 2.4 (17%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.9 (8%) | 0.4 (12%) | 1.3 (9%) |
| FLEEING: fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.6 (5%) | 0.3 (8%) | 0.9 (6%) |
| STUPIDITY: Stupidity | 0.4 (4%) | 0.0 (0%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 0.0 | 3.1 | 10.7 | 0.6 | 0.7 |
| not cast | 2.9 | 0.9 | 6.3 | 14.1 | 1.1 | 25.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.1 (17%) | 1.0 (16%) | 8.7 (62%) | 0.1 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (17%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.6 (9%) | 1.3 (9%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (75%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.9 (3%) |
| GONE: slain | 0.3 (10%) | 0.0 (0%) | 0.3 (5%) | 0.9 (6%) | 0.0 (0%) | 0.6 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.4 (3%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (85%) | 0.7 (83%) | 4.3 (68%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.3 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.1 a game | 0.7 a game | 1.9 a game |
| stood (cast and not dispelled) | 55% (12 of 22) | 0% (0 of 5) | 44% (12 of 27) |
| the unit moved after it | 33% (4 of 12) | - | 33% (4 of 12) |
| it charged on its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| the enemy charged it first | 0% (0 of 12) | - | 0% (0 of 12) |
| it fought by the end of its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 12) | - | 8% (1 of 12) |
| none of these (no charge, no fight, no charge escaped) | 92% (11 of 12) | - | 92% (11 of 12) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (59 of 93) | 67% (114 of 170) | 66% (173 of 263) |
|   cavalry | 33% (2 of 6) | 75% (12 of 16) | 64% (14 of 22) |
|   character | - | 100% (7 of 7) | 100% (7 of 7) |
|   chariot | 32% (7 of 22) | 54% (26 of 48) | 47% (33 of 70) |
|   infantry | 82% (18 of 22) | 58% (26 of 45) | 66% (44 of 67) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 74% (32 of 43) | 81% (39 of 48) | 78% (71 of 91) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (32%) | 1.9 (23%) | 3.4 (27%) |
| CHARGED: it charged | 0.3 (6%) | 0.6 (7%) | 0.9 (7%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (26%) | 0.4 (5%) | 1.7 (13%) |
| NO TARGET IN RANGE | 0.9 (18%) | 2.3 (29%) | 3.1 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (15%) | 1.6 (20%) | 2.3 (18%) |
| OTHER BAR | 0.1 (3%) | 0.7 (9%) | 0.9 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.7 | 71% | 4.4 pts | 9 pts |
| character | 1.0 | 0.4 | 71% | 10.2 pts | 10 pts |
| chariot | 4.9 | 4.0 | 53% | 15.6 pts | 76 pts |
| infantry | 8.6 | 2.4 | 82% | 5.0 pts | 43 pts |
| monster | 0.6 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 10.1 | 17.6 | 66% | 59.3 pts | 601 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 2.7 | 2.6 |
| Charges that made contact a game | 1.9 | 2.3 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.40 contact (5 units) | 0.33 declared, 0.33 contact (6 units) | 0.36 declared, 0.36 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.25 contact (44 units) | 0.31 declared, 0.25 contact (55 units) | 0.33 declared, 0.25 contact (99 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 0% (0 of 1) | - | 0% (0 of 4) |
| Character in a unit | 79% (11 of 14) | 67% (6 of 9) | - | 74% (17 of 23) |
| Character on its own | 50% (1 of 2) | 0% (0 of 3) | 33% (2 of 6) | 27% (3 of 11) |
| Chariot | 50% (1 of 2) | 70% (7 of 10) | - | 67% (8 of 12) |
| Infantry | 47% (8 of 17) | 18% (2 of 11) | - | 36% (10 of 28) |
| Monster | 100% (3 of 3) | 33% (1 of 3) | - | 67% (4 of 6) |
| Monstrous | - | 0% (0 of 2) | - | 0% (0 of 2) |
| War Machines | 85% (11 of 13) | 67% (2 of 3) | - | 81% (13 of 16) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 49% (50 of 102) | 60% | 59% (13 of 22) | 100% (6 of 6); 5.8 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 6 | 100% (4 of 4); on the table 100% | 30% (16 of 54) | 65% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Dwarfen Mountain Holds | 1 | 100% (4 of 4); on the table 100% | - | 47% | 90% (9 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 27% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 58% (7 of 12) | 69% | 50% (8 of 16) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-mine-0333a16-p1, 7 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 69% (9) | 40% (4) | 57% (13) |
| ...free all their last turn and able to turn (per game) | 0.57 | 0.14 | 0.71 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.43 | 0.43 | 0.86 |
| ...with the charger already in that arc before they moved (per game) | 0.43 | 0.14 | 0.57 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.29 | 0.29 | 0.57 |

### Quality by phase: h6-mine-0333a16-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.9 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 53% (9 of 17) | 53% (8 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (18 of 67) | 69% (52 of 75) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 32% (7 of 22) | 55% (6 of 11) |
| Strategy | Lone characters that fought | 60% (6 of 10) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.4 | 1.4 |
| Movement | Points that never moved of their own | 112.9 | 243.4 |
| Movement | Fights charged into per game | 1.7 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 12, net -35 | 5 of 12, net +15 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 12, net +0 | 0 of 12 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 12, net +0 | 3 of 12, net +140 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 12, net -9 | 3 of 12, net +230 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.9 | 11.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (11 of 27) | 48% (38 of 80) |
| Shooting | Points destroyed by shooting units | 74.3 | 103.1 |
| Shooting | War machine shots | 4.6 | 5.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (16 of 32) | 72% (28 of 39) |
| Shooting | Points destroyed by war machines | 142.1 | 0.0 |
| Magic | Magic missiles cast | 4.6 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (14 of 32) | 45% (5 of 11) |
| Magic | Wounds caused by magic missiles | 8.7 | 2.6 |
| Magic | Wounds caused by other spells | - | 0.1 |
| Magic | Points destroyed by magic (all spells) | 90.4 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.0 / 0.1 / 0.3 | 2.7 / 0.0 / 0.1 / 0.0 |
| Combat | Points destroyed in combat | 95.0 | 222.0 |
| Combat | Points run down | 20.7 | 26.6 |
| Combat | Net points per charged fight, damage counted | +16 | +48 |
| Combat | Net per 100 charger points, damage counted | +6.8 | +18.0 |
| Combat | First round won (charged fights) | 67% | 64% |
| Combat | Net points per charged fight | +6 | +72 |
| Combat | Net points per supported fight / lone fight | +65 / +1 | -185 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 12 | 8 of 15 |
| Game | Points lost | 352.3 | 449.6 |
| Game | VP from objectives | 801.4 | 737.1 |
| Game | Lone holders (player turns) | 2.0 | 3.1 |

- Mine won / drew / lost: 2 / 3 / 2 of 7 ended games (of 7); mean margin (Mine - Opponent) +123 VP
- The side that went first won 1 of 4 games with a winner
- Points traded per game (both sides' losses): 802
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-mine-0333a16-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 18.6 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.9 | +0.0 | 0.0 | 72.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.4 | +8.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.1 | +0.0 | 263.6 | 52.9 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +157.2 | 892.1 | 40.0 | 5.6 | +5.5 | 39.7 | 45.7 |
| CANNON SIGHT KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -47.3 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.6 | +7.1 | 0.0 | 12.1 | 0.4 | +2.8 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +87.9 | 9.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +24.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +21.5 | 0.0 | 24.3 | 0.3 | +9.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.7 |
| CHARACTER GUNS | - | - | - | - | 1.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.6 | -143.8 | 0.0 | 181.9 | 8.4 | -310.0 | 0.0 | 259.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 18.6 | 0.0 | 0.4 | +0.0 | 35.9 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 14.3 | 22.3 | 1.4 | +0.0 | 126.0 | 0.0 |
| CHARGER SLAIN LOST | 0.4 | -2.2 | 17.1 | 7.4 | 0.3 | -20.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 24.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.6 | +164.1 | 0.0 | 18.6 | 0.3 | +40.4 | 0.0 | 0.0 |
| COVER ONCE | 4.1 | -129.3 | 0.0 | 185.3 | 7.0 | -450.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.1 | +39.2 | 0.0 | 0.0 | 9.1 | +17.2 | 0.0 | 7.9 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.2 | 12.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.4 | +8.9 | 52.1 | 27.9 | 1.3 | +1.0 | 122.3 | 0.0 |
| FALLS SHORT | 10.1 | +198.5 | 0.0 | 66.1 | 13.4 | +204.1 | 0.0 | 199.0 |
| FEATURE BUFFS | 3.0 | +113.5 | 0.0 | 15.7 | 0.7 | +9.9 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.4 | +0.5 | 9.3 | 7.4 | 0.4 | +32.5 | 101.4 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 42.0 | +3137.0 | 1084.3 | 653.4 | 51.1 | +2246.5 | 321.7 | 527.6 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 127.4 | 4.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +15.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.4 | +121.3 | 67.1 | 42.7 | 2.1 | +129.2 | 158.1 | 0.0 |
| FRIEND CHARGES FIRST | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -30.3 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -49.5 | 0.0 | 88.6 | 0.3 | -1.6 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.4 | 0.0 | 7.4 | - | - | - | - |
| GROUND FLIERS | 0.1 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.3 | +3.3 | 36.7 | 132.9 | 3.0 | +27.4 | 86.9 | 26.4 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 44.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 3.7 | +0.0 | 0.0 | 84.1 | 2.3 | +0.0 | 0.0 | 67.9 |
| HIS CHARGE DENIED | 0.1 | +5.0 | 0.0 | 0.0 | 0.1 | +5.9 | 12.1 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 51.3 | 2.0 | +0.0 | 0.0 | 22.6 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 7.9 | 3.6 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.6 | -27.0 | 0.0 | 7.9 | 1.6 | -61.8 | 0.0 | 52.1 |
| HIS RANDOM MOVE | 3.3 | +0.0 | 0.0 | 109.4 | 2.7 | +0.0 | 0.0 | 33.6 |
| HIS SHOT LIST | 18.9 | +545.2 | 0.0 | 328.4 | 23.1 | +715.9 | 0.0 | 302.1 |
| HIS TURN DENIED | 0.7 | +21.9 | 50.0 | 0.0 | 1.3 | +54.2 | 109.6 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 38.0 | - | - | - | - |
| HOLDER ASSIGNMENT | 13.7 | +1401.7 | 0.0 | 38.0 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.0 | +356.6 | 0.0 | 7.9 |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.9 | -74.6 | 57.9 | 20.4 | 1.6 | -97.6 | 113.9 | 0.0 |
| IDLE COST | 8.3 | -89.0 | 0.0 | 82.4 | 7.1 | -100.2 | 0.0 | 164.3 |
| KEEP FALLS | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +7.9 | 0.0 | 0.0 | 0.7 | +42.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.9 | +0.0 | 0.0 | 76.4 | 1.3 | +0.0 | 44.3 | 0.0 |
| LONE WIZARD KEPT IN | 1.4 | +88.3 | 0.0 | 0.0 | 0.3 | +37.0 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +2.7 | 7.9 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +16.5 | 0.0 | 64.1 | 1.0 | +38.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.1 | +5.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +43.9 | 0.0 | 11.6 | 2.0 | +117.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +20.4 | 0.0 | 0.0 | 0.3 | +5.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +57.1 | 0.0 | 131.1 | 1.7 | +27.0 | 0.0 | 9.3 |
| MISSILES IN THE MOVE | 5.9 | +289.3 | 0.0 | 46.9 | 3.6 | +66.3 | 0.0 | 77.1 |
| MISSILES NEXT TURN | 6.6 | +172.9 | 0.0 | 46.9 | 4.7 | +50.4 | 0.0 | 77.1 |
| MODEL FACING | - | - | - | - | 1.0 | +268.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.6 | +16.2 | 0.0 | 0.0 | 0.6 | +7.2 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 3.1 | -63.1 | 0.0 | 18.6 | 0.7 | -28.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +267.5 | 0.0 | 116.0 | 1.9 | +270.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +15.7 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +193.5 | 0.0 | 9.3 | 7.4 | +299.9 | 0.0 | 15.7 |
| NEXT CHARGE BY LIST | 4.3 | -91.9 | 0.0 | 83.9 | 2.3 | -62.7 | 12.1 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 15.7 | -818.4 | 48.6 | 81.9 |
| NO DOUBLE ROUNDS | 1.6 | -60.3 | 37.9 | 42.7 | 1.4 | -35.2 | 158.1 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 24.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.3 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.1 | -93.1 | 0.0 | 0.0 | 0.1 | -3.0 | 0.0 | 7.9 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 107.7 | 1.9 | +0.0 | 0.0 | 5.4 |
| ONE FIGHT FORMULA | 5.0 | -73.9 | 0.0 | 147.6 | 2.7 | -68.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.6 | +110.9 | 0.0 | 25.0 | 3.3 | +10.1 | 0.0 | 7.9 |
| ONE TARGET A SHOOTER | 16.9 | +327.4 | 0.0 | 329.4 | 21.9 | +501.5 | 0.0 | 317.1 |
| OPENS UP | 0.6 | +56.6 | 29.3 | 0.0 | 0.3 | +5.0 | 12.1 | 0.0 |
| OVERRUNS AWAY | 0.6 | +43.9 | 20.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 3.6 | +102.7 | 0.0 | 88.7 | 3.9 | +111.1 | 0.0 | 7.9 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +21.9 | 0.0 | 0.0 |
| PLAN RESULT | 36.4 | +901.9 | 512.9 | 717.3 | 45.0 | +708.5 | 167.3 | 789.1 |
| QUARTER ODDS | 8.4 | +827.4 | 329.3 | 24.3 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.0 | +11.0 | 0.0 | 48.6 | 3.4 | +52.8 | 0.0 | 161.4 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.0 | 0.0 | 24.3 | 0.6 | -5.6 | 0.0 | 7.9 |
| REDIRECT COUNTER | 2.1 | +50.9 | 0.0 | 48.0 | 1.0 | +43.0 | 0.0 | 17.1 |
| REDIRECT WEIGHED | 0.1 | +7.8 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -48.5 | 0.0 | 7.4 | 0.4 | -8.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +41.5 | 0.0 | 0.0 | 0.7 | +43.2 | 0.0 | 16.0 |
| RISK BY ARC | 2.4 | -33.8 | 67.1 | 42.7 | 1.4 | +14.2 | 158.1 | 0.0 |
| RISK BY HIS FIGURE | 11.0 | -93.3 | 0.0 | 336.4 | 11.9 | -186.2 | 0.0 | 125.4 |
| RUN DOWN | 1.4 | -11.0 | 37.9 | 20.4 | 1.1 | -10.8 | 89.6 | 0.0 |
| SCOUT SPOT | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.1 | -22.9 | 0.0 | 0.0 | 0.1 | -1.9 | 0.0 | 0.0 |
| SEARCH SPOT | 3.7 | +153.7 | 0.0 | 7.9 | 6.1 | +275.2 | 0.0 | 65.4 |
| SELF MOVE SPELL | - | - | - | - | 0.9 | -1.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +2.3 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +83.9 | 44.3 | 0.0 | 1.0 | +26.0 | 35.3 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -4.3 | 41.4 | 13.0 | 0.1 | -0.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 9.9 | -55.5 | 0.0 | 234.7 | 14.6 | +16.2 | 0.0 | 344.7 |
| SHOTS IN THE MOVE | 10.9 | +406.2 | 0.0 | 292.1 | 17.1 | +304.6 | 0.0 | 88.1 |
| SPELL SETS UP CHARGE | 0.1 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.9 | +5.6 | 0.0 | 0.0 | 1.6 | +22.3 | 77.1 | 77.1 |
| SPELLS IN THE FIGHT | 0.1 | -0.6 | 0.0 | 0.0 | 0.1 | -7.6 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -1.2 | 0.0 | 13.0 | 0.6 | -5.1 | 53.6 | 0.0 |
| STANDS FOR A REASON | 0.4 | +0.0 | 0.0 | 11.6 | 0.6 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 15.9 | +0.0 | 1017.1 | 270.7 | 17.4 | +0.0 | 163.6 | 173.6 |
| STAY WORTH | 14.7 | +19.8 | 922.1 | 315.0 | 17.3 | -114.4 | 64.0 | 189.6 |
| STUCK PIVOT | - | - | - | - | 0.9 | +0.0 | 0.0 | 60.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 7.9 | 22.3 | 0.9 | +0.0 | 122.9 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 88.7 | 3.4 | +0.0 | 0.0 | 7.9 |
| THE PROMISE ADDS | 0.1 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 9.3 | 0.4 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.1 | +20.4 | 0.0 | 0.0 | 0.9 | +92.6 | 71.7 | 0.0 |
| TIME ON OUR SIDE | 16.3 | +315.1 | 0.0 | 395.1 | 18.1 | +253.0 | 0.0 | 9.3 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 108.1 | 1.1 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 44.3 | 0.0 | 0.4 | +0.0 | 68.6 | 0.0 |
| WHO HITS BACK | 0.6 | +78.0 | 0.0 | 13.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.1 | +13.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +2.4 | 9.3 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.4 | -3.5 | 57.9 | 7.4 | 0.9 | +1.1 | 80.9 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +76.7 | 0.0 | 0.0 | 0.9 | +46.4 | 0.0 | 0.0 |

### Rule changes: h6-mine-0333a16-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 294 | 294 | 99 | 14.14 | +1435 | +14.5 |
| HOLDER ASSIGNMENT | 96 | 96 | 90 | 12.86 | +4632 | +51.5 |
| DEPLOY BY FIGURES | 121 | 121 | 80 | 11.43 | +1749 | +21.9 |
| FIVE ACTION | 652 | 651 | 65 | 9.29 | +1856 | +28.6 |
| ONE TARGET A SHOOTER | 271 | 271 | 64 | 9.14 | +616 | +9.6 |
| SEARCH SPOT | 69 | 69 | 64 | 9.14 | +3002 | +46.9 |
| PATHS CROSS | 52 | 52 | 52 | 7.43 | +1496 | +28.8 |
| TIME ON OUR SIDE | 241 | 220 | 45 | 6.43 | +154 | +3.4 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 5.14 | +0 | +0.0 |
| SHOT RISK POINTS | 171 | 171 | 34 | 4.86 | +813 | +23.9 |
| ARTILLERY RE-ROLL WEIGHED | 25 | 25 | 25 | 3.57 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 34 | 34 | 23 | 3.29 | +1787 | +77.7 |
| RANDOM MOVE BY FIGURES | 31 | 31 | 22 | 3.14 | +446 | +20.3 |
| HARD STAY DROPPED | 17 | 17 | 17 | 2.43 | +0 | +0.0 |
| IDLE COST | 108 | 91 | 17 | 2.43 | +144 | +8.5 |
| MARCH CHECK | 20 | 20 | 17 | 2.43 | +621 | +36.5 |
| SHOTS IN THE MOVE | 196 | 179 | 15 | 2.14 | +321 | +21.4 |
| ADVANCE LANE KEPT | 14 | 14 | 14 | 2.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 67 | 67 | 14 | 2.00 | -9 | -0.6 |
| COVER ONCE | 78 | 66 | 14 | 2.00 | +209 | +14.9 |
| FALLS SHORT | 165 | 141 | 14 | 2.00 | +257 | +18.3 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.71 | +877 | +73.1 |
| NEXT OBJECTIVE NEARER | 110 | 110 | 12 | 1.71 | +278 | +23.2 |
| FOUR ROUNDS | 32 | 31 | 10 | 1.43 | +337 | +33.7 |
| MISSILES IN THE MOVE | 66 | 40 | 10 | 1.43 | +420 | +42.0 |
| RESERVE FALL BACK | 10 | 10 | 10 | 1.43 | +593 | +59.3 |
| HOLDER AT DEPLOYMENT | 14 | 14 | 9 | 1.29 | +465 | +51.7 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 9 | 1.29 | +74 | +8.2 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| CHARGE LOSSES | 98 | 98 | 7 | 1.00 | +451 | +64.5 |
| LANE BY FIGURES | 7 | 7 | 7 | 1.00 | +351 | +50.1 |
| MANOEUVRE | 16 | 16 | 7 | 1.00 | +383 | +54.7 |
| MAX FOR POSITIONING | 46 | 44 | 7 | 1.00 | +52 | +7.4 |
| MODEL FACING | 7 | 7 | 7 | 1.00 | +1883 | +268.9 |
| QUARTER ODDS | 59 | 58 | 7 | 1.00 | +476 | +68.0 |
| RISK BY ARC | 27 | 26 | 7 | 1.00 | +213 | +30.4 |
| WOUNDS ON THE RANKS | 20 | 20 | 7 | 1.00 | +198 | +28.3 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 6 | 0.86 | +163 | +27.2 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| REDIRECT COUNTER | 22 | 17 | 6 | 0.86 | +237 | +39.6 |
| STUCK PIVOT | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.71 | -547 | -109.4 |
| FEATURE BUFFS | 26 | 26 | 5 | 0.71 | +156 | +31.1 |
| NEARER NOT NEEDED | 78 | 75 | 5 | 0.71 | +117 | +23.3 |
| TIED UP BY THE SUM | 7 | 6 | 5 | 0.71 | +192 | +38.3 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 0.57 | +0 | +0.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 0.57 | +0 | +0.0 |
| HIS TURN DENIED | 14 | 14 | 4 | 0.57 | +190 | +47.6 |
| WHO HITS BACK | 4 | 4 | 4 | 0.57 | +371 | +92.8 |
| BOMBING RUN | 3 | 3 | 3 | 0.43 | +60 | +19.9 |
| CHARGE NOW FIRST | 15 | 15 | 3 | 0.43 | -36 | -12.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 0.43 | +105 | +35.1 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.43 | +114 | +38.2 |
| NEXT CHARGE BY LIST | 46 | 46 | 3 | 0.43 | +0 | +0.1 |
| ONE OBJECTIVE FORMULA | 62 | 38 | 3 | 0.43 | +150 | +49.9 |
| OPENS UP | 6 | 6 | 3 | 0.43 | +254 | +84.7 |
| RISK BY HIS FIGURE | 160 | 160 | 3 | 0.43 | +78 | +26.0 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.43 | +0 | +0.0 |
| STAY WORTH | 224 | 216 | 3 | 0.43 | +24 | +8.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.29 | -19 | -9.6 |
| CHAFF PASSED | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| FIGHT TO THE END | 6 | 5 | 2 | 0.29 | +72 | +36.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.29 | +25 | +12.5 |
| OFF BEST | 2 | 2 | 2 | 0.29 | -672 | -336.0 |
| ONE FIGHT FORMULA | 54 | 28 | 2 | 0.29 | +7 | +3.5 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.29 | +7 | +3.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.29 | +153 | +76.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.29 | +4 | +2.0 |
| SUPPORT NARROWED | 11 | 11 | 2 | 0.29 | -43 | -21.7 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.14 | -331 | -331.1 |
| CAST JOB | 7 | 7 | 1 | 0.14 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.14 | -84 | -83.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.14 | +34 | +34.3 |
| GIVES UP | 2 | 2 | 1 | 0.14 | +5 | +5.0 |
| HIS MOVE AND SHOT | 22 | 22 | 1 | 0.14 | +0 | +0.0 |
| HONEST WORTH | 24 | 23 | 1 | 0.14 | +23 | +23.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| LONG SHOT | 1 | 1 | 1 | 0.14 | +10 | +10.4 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.14 | +39 | +39.1 |
| MISSILES NEXT TURN | 79 | 53 | 1 | 0.14 | +2 | +1.7 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.14 | +86 | +85.6 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.14 | +100 | +100.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.14 | -0 | -0.2 |
| SET UP TOGETHER | 3 | 3 | 1 | 0.14 | +8 | +8.5 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.14 | +14 | +13.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 18 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 63 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 30 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 42 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 41 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 42 | 42 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 98 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 21 | 20 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 33 | 33 | 0 | 0.00 | - | - |
| PLAN RESULT | 570 | trace | - | - | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 233 | 233 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 45 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 22 | 22 | 0 | 0.00 | - | - |
| WALK PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 16 | 15 | 0 | 0.00 | - | - |

### Off best figure: h6-mine-0333a16-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 19.8 |
| PATHS CROSS | rule | 0.14 | 0.57 | 9.9 |
| CHARGE NOT DECLARED | rule | 0.14 | 0.43 | 136.8 |
| CHARGE NOW FIRST | rule | 0.14 | 0.29 | 12.0 |
| BEST PRIZE | rule | - | 0.29 | 9.6 |
| SUPPORT NARROWED | rule | 0.14 | 0.14 | 21.7 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 9.7 |
| CARRIES OUT COUNTER | rule | 0.14 | - | 331.1 |
| CATCH ODDS | rule | 0.14 | - | 83.8 |
| JOB FIRST | gate | - | 0.14 | 20.6 |
| NO REASON | gate | 0.14 | - | 651.4 |
| RESERVE FALL BACK | rule | 0.14 | - | 12.6 |

### Plans: h6-mine-0333a16-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 36% | 132 | 104 | 79% |
| Mine | move | 26.1 | 95% | 1732 | 0 | 0% |
| Mine | shoot | 7.7 | 61% | 524 | 805 | 154% |
| Mine | support | 0.4 | 33% | 0 | 0 | - |
| Opponent | charge | 1.6 | 64% | 258 | 155 | 60% |
| Opponent | move | 33.4 | 92% | 1456 | 0 | 0% |
| Opponent | shoot | 9.4 | 68% | 161 | 554 | 345% |
| Opponent | support | 0.6 | 100% | 23 | 0 | 0% |

### Battle groups: h6-mine-0333a16-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 43% | 100% | 0% | - | 0% | 0% | 67% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-mine-0333a16-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 6 | 35 (6) | 0 | 35 | 40 | 50% | 2.7 | - | 35 (6) | - | 48 (4) | 0 (2) |
| Mine | Character | 25 | 21 (25) | 21 | 0 | 8 | 24% | 2.6 | 35 (11) | 17 (8) | 0 (4) | 14 (19) | 41 (4) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 67 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 7 | 8 (7) | 8 | 0 | 83 | 14% | 3.2 | - | 16 (4) | 0 (3) | 23 (2) | 0 (5) |
| Mine | Hammer | 16 | 33 (16) | 8 | 24 | 19 | 31% | 3.7 | 89 (3) | 22 (8) | 8 (5) | 43 (10) | 11 (6) |
| Mine | Holder | 11 | 79 (11) | 0 | 79 | 23 | 73% | 2.0 | 153 (2) | 46 (5) | 77 (4) | 66 (7) | 102 (4) |
| Mine | Shooter | 2 | 369 (2) | 0 | 369 | 50 | 0% | 1.5 | - | 554 (1) | 185 (1) | 369 (2) | - |
| Mine | War machine | 8 | 84 (8) | 84 | 0 | 31 | 0% | 1.4 | 64 (7) | - | 282 (1) | 282 (1) | 64 (7) |
| Mine | Wizard | 7 | 0 (7) | 0 | 0 | 14 | 29% | 3.8 | 0 (4) | 0 (1) | 0 (2) | 0 (2) | 0 (5) |
| Opponent | Chaff | 8 | 62 (8) | 5 | 57 | 50 | 38% | 2.4 | 35 (3) | 87 (4) | 0 (1) | 63 (7) | 55 (1) |
| Opponent | Character | 18 | 35 (18) | 35 | 0 | 17 | 22% | 2.5 | 29 (7) | 16 (7) | 68 (4) | 54 (8) | 10 (10) |
| Opponent | Clean-up | 6 | 73 (6) | 0 | 73 | 7 | 83% | 5.0 | - | 61 (5) | 237 (1) | 140 (4) | 28 (2) |
| Opponent | Fast | 1 | 232 (1) | 232 | 0 | 0 | 0% | 1.0 | - | 232 (1) | - | 232 (1) | - |
| Opponent | Fast Hammer | 1 | 5 (1) | 5 | 0 | 0 | 0% | 2.0 | - | 5 (1) | - | - | 5 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Hammer | 18 | 45 (18) | 26 | 20 | 35 | 28% | 3.1 | 0 (3) | 56 (13) | 25 (2) | 29 (12) | 79 (6) |
| Opponent | Holder | 10 | 102 (10) | 0 | 102 | 10 | 70% | 5.0 | 129 (6) | 36 (2) | 98 (2) | 114 (5) | 89 (5) |
| Opponent | Shooter | 10 | 35 (10) | 0 | 35 | 12 | 10% | 1.7 | 0 (2) | 39 (8) | - | 97 (4) | 0 (6) |
| Opponent | War machine | 10 | 0 (10) | 0 | 0 | 37 | 10% | 1.4 | - | 0 (4) | 0 (6) | 0 (1) | 0 (9) |
| Opponent | Wizard | 3 | 4 (3) | 4 | 0 | 0 | 33% | 2.0 | 0 (1) | 4 (2) | - | 0 (1) | 4 (2) |

### Charged fights: h6-mine-0333a16-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 112 | 16 | 1.2 | 1.2 | 13 | 21 | -8 | 2 of 5 | 2 of 5 | +65 | -26 |
| Mine | Chaos Dwarfs | 3 | 567 | 68 | 2.3 | 1.0 | 29 | 13 | +16 | 1 of 7 | 6 of 7 | - | +16 |
| **Mine** | all armies | 7 | 307 | 39 | 1.7 | 1.1 | 22 | 16 | +6 | 3 of 12 | 8 of 12 | +65 | +1 |
| Opponent | Chaos Dwarfs | 3 | 91 | 281 | 1.7 | 1.0 | 169 | 0 | +169 | 4 of 5 | 2 of 5 | - | +169 |
| Opponent | Dwarfen Mountain Holds | 1 | 139 | 0 | 1.0 | 2.0 | 0 | 185 | -185 | 1 of 1 | 1 of 1 | -185 | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 503 | 5.0 | 1.0 | 101 | 0 | +101 | 0 of 5 | 5 of 5 | - | +101 |
| Opponent | Skaven | 2 | 155 | 32 | 2.0 | 1.0 | 16 | 36 | -20 | 3 of 4 | 1 of 3 | - | -20 |
| **Opponent** | all armies | 7 | 103 | 202 | 2.1 | 1.1 | 94 | 22 | +72 | 8 of 15 | 9 of 14 | -185 | +90 |

### Effective charges: h6-mine-0333a16-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net -52) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +65) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 7 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +102) | 1 (net +0) | 2 (net -46) | 0 | 14% (1 of 7) |
| Opponent | Chaos Dwarfs | 5 | 2 (net +110) | 0 | 0 | 0 | 0 | 2 (net +312) | 1 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net -185) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 3 (net +140) | 0 | 2 | 0% (0 of 3) |
| Opponent | Skaven | 4 | 3 (net -48) | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: h6-mine-0333a16-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 195 | 312 | -35 | 0 | 35 | -35 | -17.8 |
| Mine | Effective (55-75%) | 2 | 266 | 87 | +0 | 4 | 13 | -9 | -3.2 |
| Mine | 76-89% | 3 | 254 | 88 | +68 | 78 | 0 | +78 | +30.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 190 | 118 | -9 | 69 | 44 | +25 | +13.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 92 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 12 | 230 | 152 | +6 | 38 | 22 | +16 | +6.8 |
| Opponent | Long shot (under 50%) | 5 | 219 | 303 | +15 | 59 | 83 | -25 | -11.3 |
| Opponent | 76-89% | 1 | 243 | 480 | -185 | 240 | 279 | -39 | -15.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 290 | 155 | +230 | 230 | 56 | +174 | +59.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 350 | 84 | +140 | 140 | 0 | +140 | +40.1 |
| Opponent | No odds | 3 | 246 | 131 | +27 | 27 | 47 | -20 | -8.0 |
| Opponent | All fights | 15 | 266 | 207 | +72 | 115 | 67 | +48 | +18.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-mine-0333a16-p1 | move | 40 | 7 (18%) | 7 (18%) | 3 (8%) | 30 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Elixir of Power | Opponent | L0219 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |

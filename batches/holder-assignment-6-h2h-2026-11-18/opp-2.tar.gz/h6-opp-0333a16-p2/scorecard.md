# Doctrine scorecard: h6-opp-0333a16-p2

### Scorecard: h6-opp-0333a16-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 2 | 5 | 2 | 2 | 0 | 0 | 0 | 282 |
| L0123 | 3 | 1 | Mine | yes | 4 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | yes | 3 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 6 | - | 2 | 3 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 7 | 4 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 4 | 3 | 0 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 110 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 470 |
| L0325 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 230 |
| L0325 | 1 | 1 | Opponent | no | 8 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 165 |
| L0427 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 1 | 1 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 95 |
| L0513 | 3 | 1 | Opponent | no | 8 | - | 0 | 1 | 1 | 0 | 0 | 232 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 95 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 2.9 | 2.4 | 1.5 | 1.7 | 0.0 | 0.0 | 0.0 | 95.1 |
| **Average** | | | Opponent | 14% | 4.4 | 2.8 | 1.2 | 2.1 | 0.3 | 0.0 | 0.0 | 131.9 |

### KPIs: h6-opp-0333a16-p2

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 10 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (12 of 37) | 21% (11 of 52) | 26% (23 of 89) |
| Winner chose to follow up after the loser gave ground |  | 40% (2 of 5); on the table 60% | 82% (9 of 11); on the table 82% | 69% (11 of 16); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 82% (9 of 11); on the table 82% | 85% (11 of 13); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 80% | 83% (20 of 24); on the table 83% | 79% (27 of 34); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 30% (41 of 138) | 33% (14 of 42) | 31% (55 of 180) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (41 of 114) | 44% (14 of 32) | 38% (55 of 146) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | - | 67% (8 of 12) |
| Points that never fought | lower | 60% (11685 of 19594) | 57% (11346 of 19995) | 58% (23031 of 39589) |
|   infantry points that never fought | lower | 60% (3380 of 5628) | 82% (2831 of 3462) | 68% (6211 of 9090) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (43 of 68) | 61% (46 of 76) | 62% (89 of 144) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.4 uses a game | 100% (3 of 3); 0.5 uses a game | 89% (8 of 9); 0.9 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.1 uses a game | 60% (3 of 5); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.5 uses a game | 20% (1 of 5); 0.1 uses a game | 46% (6 of 13); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (8680 of 14772) | 57% (9790 of 17127) | 58% (18470 of 31899) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.6 (47%) | 0.7 (25%) | 5.3 (42%) |
| MARCHED: its unit marched | 2.7 (28%) | 0.9 (32%) | 3.6 (29%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.9 (9%) | 0.4 (14%) | 1.3 (10%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| GONE: slain | 1.5 (15%) | 0.4 (14%) | 1.9 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 1.3 | 2.5 | 5.5 | 0.5 | 1.3 |
| not cast | 3.7 | 2.1 | 5.3 | 12.5 | 1.3 | 23.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (67%) | 0.3 (6%) | 5.3 (42%) | 0.5 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.6 (29%) | 0.1 (8%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.2 (10%) | 0.5 (9%) | 1.3 (10%) | 0.2 (15%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) | 0.2 (2%) | 0.2 (15%) | 0.7 (3%) |
| GONE: slain | 1.1 (30%) | 0.0 (0%) | 1.2 (23%) | 1.9 (15%) | 0.0 (0%) | 1.4 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (23%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (62%) | 0.1 (5%) | 3.3 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.9 a game | 0.4 a game | 1.6 a game |
| stood (cast and not dispelled) | 55% (16 of 29) | 50% (2 of 4) | 55% (18 of 33) |
| the unit moved after it | 69% (11 of 16) | 100% (2 of 2) | 72% (13 of 18) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 2) | 0% (0 of 18) |
| the enemy charged it first | 25% (4 of 16) | 0% (0 of 2) | 22% (4 of 18) |
| it fought by the end of its next turn | 12% (2 of 16) | 0% (0 of 2) | 11% (2 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 2) | 0% (0 of 18) |
| none of these (no charge, no fight, no charge escaped) | 75% (12 of 16) | 100% (2 of 2) | 78% (14 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (154 of 236) | 55% (108 of 197) | 61% (262 of 433) |
|   cavalry | 50% (6 of 12) | 60% (21 of 35) | 57% (27 of 47) |
|   character | 69% (25 of 36) | 11% (2 of 18) | 50% (27 of 54) |
|   chariot | 56% (27 of 48) | 76% (13 of 17) | 62% (40 of 65) |
|   infantry | 59% (24 of 41) | 71% (30 of 42) | 65% (54 of 83) |
|   war machine | 73% (72 of 99) | 49% (42 of 85) | 62% (114 of 184) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (29%) | 2.2 (25%) | 4.6 (27%) |
| CHARGED: it charged | 0.3 (4%) | 0.7 (8%) | 1.0 (6%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.3 (3%) | 0.6 (4%) |
| MOVED: a war machine that moved | 1.0 (12%) | 1.6 (18%) | 2.6 (15%) |
| NO TARGET IN RANGE | 2.0 (24%) | 1.0 (11%) | 3.0 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 2.2 (25%) | 3.4 (20%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.7 (9%) | 0.4 (4%) | 1.1 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.7 | 76% | 5.2 pts | 19 pts |
| character | 2.9 | 0.9 | 72% | 9.5 pts | 28 pts |
| chariot | 4.0 | 4.2 | 65% | 18.3 pts | 73 pts |
| infantry | 7.9 | 2.9 | 71% | 6.2 pts | 49 pts |
| war machine | 11.4 | 12.4 | 60% | 22.3 pts | 255 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.2 | 3.7 | 3.0 |
| Charges that made contact a game | 2.1 | 2.6 | 2.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 0.20 declared, 0.00 contact (5 units) | 0.27 declared, 0.18 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.40 declared, 0.40 contact (5 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.28 contact (67 units) | 0.51 declared, 0.36 contact (67 units) | 0.40 declared, 0.32 contact (134 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 31% (4 of 13) | 33% (2 of 6) | 100% (2 of 2) | 38% (8 of 21) |
| Character in a unit | 89% (16 of 18) | 75% (9 of 12) | - | 83% (25 of 30) |
| Character on its own | 89% (8 of 9) | 86% (6 of 7) | 45% (5 of 11) | 70% (19 of 27) |
| Chariot | 100% (1 of 1) | 70% (7 of 10) | - | 73% (8 of 11) |
| Infantry | 42% (5 of 12) | 33% (5 of 15) | 0% (0 of 2) | 34% (10 of 29) |
| Monster | 25% (1 of 4) | 100% (1 of 1) | - | 40% (2 of 5) |
| War Machines | 84% (16 of 19) | 50% (1 of 2) | - | 81% (17 of 21) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 28% (29 of 102) | 56% | 59% (13 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 2.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 57% (4 of 7); on the table 71% | 33% (12 of 36) | 55% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (1 of 1); on the table 100% | - | 76% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 0% (0 of 1); on the table 0% | 42% (5 of 12) | 75% | 57% (17 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 1 | 0% (0 of 2); on the table 0% | 33% (4 of 12) | 45% | 75% (6 of 8) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 100% | 62% (5 of 8) | 100% (1 of 1); 1.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 23% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 94% (15 of 16); on the table 94% | 42% (5 of 12) | 46% | 68% (13 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 35% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-opp-0333a16-p2, 10 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (8) | 38% (6) | 42% (14) |
| ...free all their last turn and able to turn (per game) | 0.60 | 0.40 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.20 | 0.10 | 0.30 |
| ...with the charger already in that arc before they moved (per game) | 0.40 | 0.20 | 0.60 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.10 | 0.00 | 0.10 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.10 | 0.10 | 0.20 |

### Quality by phase: h6-opp-0333a16-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 89% (17 of 19) | 53% (16 of 30) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (54 of 109) | 45% (36 of 80) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (2 of 6) |
| Strategy | Joined characters whose unit fought | 21% (6 of 28) | 31% (5 of 16) |
| Strategy | Lone characters that fought | 50% (10 of 20) | 62% (16 of 26) |
| Movement | Charges halted short of contact | 0.0 | 0.4 |
| Movement | Idle units | 1.7 | 2.1 |
| Movement | Points that never moved of their own | 95.1 | 131.9 |
| Movement | Fights charged into per game | 1.9 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 18, net -21 | 3 of 21, net -316 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 18, net +197 | 5 of 21, net +191 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 18, net +99 | 4 of 21, net +272 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 18, net +130 | 3 of 21, net +28 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (35 of 83) | 57% (40 of 70) |
| Shooting | Points destroyed by shooting units | 49.5 | 27.3 |
| Shooting | War machine shots | 7.2 | 4.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (35 of 72) | 43% (18 of 42) |
| Shooting | Points destroyed by war machines | 48.6 | 106.0 |
| Magic | Magic missiles cast | 2.8 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (8 of 28) | 38% (5 of 13) |
| Magic | Wounds caused by magic missiles | 6.6 | 1.2 |
| Magic | Wounds caused by other spells | 0.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 63.1 | 13.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.6 / 0.0 | 1.4 / 0.9 / 0.0 / 0.1 |
| Combat | Points destroyed in combat | 203.6 | 171.7 |
| Combat | Points run down | 22.1 | 134.8 |
| Combat | Net points per charged fight, damage counted | +75 | +121 |
| Combat | Net per 100 charger points, damage counted | +26.2 | +33.6 |
| Combat | First round won (charged fights) | 74% | 90% |
| Combat | Net points per charged fight | +74 | +97 |
| Combat | Net points per supported fight / lone fight | +0 / +83 | +352 / +37 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 19 | 7 of 21 |
| Game | Points lost | 478.9 | 520.8 |
| Game | VP from objectives | 577.0 | 875.0 |
| Game | Lone holders (player turns) | 2.9 | 4.4 |

- Mine won / drew / lost: 2 / 2 / 6 of 10 ended games (of 10); mean margin (Mine - Opponent) -275 VP
- The side that went first won 2 of 8 games with a winner
- Points traded per game (both sides' losses): 1000
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-opp-0333a16-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +29.9 | 0.0 | 0.0 | 0.2 | +28.0 | 0.0 | 36.9 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 26.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.9 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 58.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| BEST OVERALL | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.1 | -3.0 | 5.5 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -8.8 | 0.0 | 0.0 | 0.4 | -85.7 | 28.9 | 26.5 |
| BOMBING RUN | - | - | - | - | 0.1 | +1.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 32.8 | 11.0 | 0.8 | +0.0 | 31.9 | 12.5 |
| CANNON PLANNED TARGET | 6.3 | +264.1 | 171.5 | 58.5 | 3.5 | +124.4 | 334.5 | 33.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -2.9 | 21.9 | 0.0 |
| CAST JOB | 0.6 | +14.2 | 35.1 | 58.0 | 0.2 | +9.2 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.9 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.2 | +24.2 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.5 | +0.0 | 0.0 | 142.0 | 0.2 | +0.0 | 0.0 | 40.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +20.4 | 0.0 | 23.1 | 0.4 | +24.9 | 0.0 | 9.8 |
| CHAFF PASSED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.8 | -278.2 | 0.0 | 125.5 | 4.7 | -234.6 | 0.0 | 88.1 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 6.0 | 0.0 | 0.5 | +0.0 | 44.9 | 5.0 |
| CHARGE NOW FIRST | 1.2 | +0.0 | 119.4 | 5.2 | 1.5 | +0.0 | 92.0 | 5.0 |
| CHARGER SLAIN LOST | 0.4 | -10.6 | 0.0 | 13.7 | 0.1 | -4.3 | 0.0 | 5.0 |
| CHEAPEST HOLDER | 0.4 | -13.4 | 28.1 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 21.5 | 0.0 | 0.4 | +0.0 | 11.0 | 43.1 |
| CONVEYANCE SEARCH | 1.6 | +138.5 | 0.0 | 0.0 | 0.2 | +2.8 | 40.0 | 40.0 |
| COVER ONCE | 4.8 | -219.5 | 0.0 | 135.8 | 4.9 | -267.2 | 0.0 | 22.1 |
| DEPLOY BY FIGURES | 8.5 | -2.6 | 0.0 | 0.0 | 7.5 | -47.4 | 0.0 | 12.0 |
| EDGE GIVE GROUND | 0.1 | +0.1 | 16.5 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.4 | +10.6 | 139.9 | 14.9 | 2.1 | +0.0 | 129.6 | 74.6 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 10.5 | +205.5 | 0.0 | 192.3 | 12.4 | +163.7 | 0.0 | 110.6 |
| FEATURE BUFFS | 2.6 | +68.8 | 0.0 | 9.5 | 0.5 | +14.6 | 0.0 | 6.0 |
| FIGHT TO THE END | 1.0 | +31.8 | 95.9 | 6.5 | 1.1 | +25.5 | 71.3 | 43.1 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 12.0 | 0.0 |
| FIVE ACTION | 44.3 | +2314.3 | 497.2 | 623.1 | 48.1 | +3302.4 | 838.2 | 574.1 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 117.9 | 4.3 | +0.0 | 0.0 | 31.9 |
| FOLLOW UP WEIGHED | 0.2 | +119.9 | 0.0 | 0.0 | 0.4 | +80.5 | 0.0 | 5.0 |
| FOUR ROUNDS | 1.9 | +185.5 | 151.2 | 28.6 | 2.9 | +163.4 | 195.8 | 74.6 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.4 | 0.0 | 0.0 | 0.4 | -26.5 | 11.7 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -0.3 | 0.0 | 0.0 | 0.2 | -6.5 | 47.8 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.2 | 0.0 | 8.5 | - | - | - | - |
| GROUND FLIERS | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.9 | +16.0 | 25.4 | 0.0 | 0.9 | +48.4 | 75.0 | 0.0 |
| GUN MASK | 0.2 | +2.7 | 0.0 | 0.0 | 1.5 | +35.1 | 0.0 | 25.2 |
| HARD STAY DROPPED | 1.6 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.8 | +0.0 | 0.0 | 15.6 | 1.8 | +0.0 | 0.0 | 33.3 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 8.4 | - | - | - | - |
| HIS CHARGE DENIED | 0.7 | +8.8 | 10.5 | 8.5 | 0.4 | +10.0 | 16.2 | 0.0 |
| HIS CHARGE LIST | 3.1 | +0.0 | 0.0 | 68.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.8 | +0.0 | 0.0 | 80.9 | 3.6 | +0.0 | 0.0 | 7.0 |
| HIS MOVE AND SHOT | 0.9 | -9.1 | 0.0 | 5.5 | 1.2 | -36.3 | 0.0 | 38.1 |
| HIS RANDOM MOVE | - | - | - | - | 4.5 | +0.0 | 0.0 | 6.0 |
| HIS SHOT LIST | 18.2 | +834.8 | 0.0 | 268.2 | 25.1 | +1367.5 | 0.0 | 326.3 |
| HIS TURN DENIED | 0.7 | +20.1 | 128.9 | 8.4 | 1.2 | +42.5 | 108.6 | 69.6 |
| HOLD ODDS | - | - | - | - | 11.9 | +0.0 | 0.0 | 99.9 |
| HOLDER ASSIGNMENT | - | - | - | - | 13.6 | +1563.8 | 0.0 | 122.3 |
| HOLDER AT DEPLOYMENT | 1.0 | +177.4 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -47.2 | 151.2 | 6.5 | 2.8 | -133.8 | 195.8 | 48.1 |
| HUNT IN PAIRS | - | - | - | - | 0.4 | +30.6 | 0.0 | 36.9 |
| IDLE COST | 4.2 | -51.1 | 0.0 | 58.3 | 8.9 | -162.8 | 0.0 | 77.9 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +14.3 | 0.0 | 0.0 | 0.8 | +31.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.2 | +0.0 | 110.2 | 67.3 | 5.1 | +0.0 | 150.7 | 144.6 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +4.5 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.0 | +79.5 | 0.0 | 0.0 | 0.3 | +30.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +4.9 | 22.1 | 6.5 | 0.1 | +0.3 | 0.0 | 0.0 |
| LOST CHARGE | 0.2 | -0.3 | 6.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -6.5 | 0.0 | 6.5 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.5 | +39.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.6 | +18.2 | 0.0 | 103.6 | 1.1 | +40.8 | 0.0 | 35.8 |
| MARCH AT ESCAPER | 0.5 | +0.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +11.3 | 0.0 | 0.0 | 0.5 | +29.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +27.4 | 0.0 | 8.1 | 0.5 | +32.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +31.3 | 0.0 | 8.1 | 0.5 | -25.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +89.6 | 0.0 | 159.4 | 4.9 | +79.0 | 0.0 | 72.4 |
| MISSILES IN THE MOVE | 4.0 | +199.8 | 0.0 | 139.0 | 2.4 | +41.9 | 0.0 | 75.2 |
| MISSILES NEXT TURN | 4.6 | +149.8 | 0.0 | 114.9 | 3.4 | +26.0 | 0.0 | 115.2 |
| MOVE SPELL IN RANGE | 0.3 | +10.9 | 0.0 | 58.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -3.8 | 0.0 | 58.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 40.0 |
| MOVE TO CHARGE COMPUTED | 2.1 | +217.8 | 0.0 | 17.5 | 4.4 | +357.4 | 0.0 | 7.0 |
| MOVES UNITS SPELL | 0.2 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.6 | +180.0 | 0.0 | 82.6 | 6.7 | +260.5 | 0.0 | 111.5 |
| NEXT CHARGE BY LIST | 2.9 | -323.7 | 33.0 | 89.2 | 6.9 | -205.7 | 20.8 | 29.4 |
| NEXT OBJECTIVE NEARER | 5.6 | -248.9 | 0.0 | 117.1 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.2 | -56.7 | 108.7 | 20.2 | 2.1 | -38.9 | 103.0 | 74.6 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.2 | 0.0 | 0.0 | 0.8 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 1.1 | -19.1 | 0.0 | 11.7 | 0.8 | -18.6 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.7 | +0.0 | 0.0 | 79.5 | 1.7 | +0.0 | 0.0 | 57.9 |
| ONE FIGHT FORMULA | 3.7 | -67.8 | 0.0 | 113.0 | 5.3 | -123.8 | 0.0 | 16.4 |
| ONE OBJECTIVE FORMULA | 4.1 | -53.6 | 0.0 | 36.3 | 4.4 | +72.2 | 0.0 | 39.9 |
| ONE TARGET A SHOOTER | 14.9 | +436.0 | 0.0 | 215.1 | 15.0 | +465.3 | 0.0 | 210.7 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +46.5 | 29.7 | 0.0 |
| OVERRUNS AWAY | 0.2 | +0.9 | 22.1 | 0.0 | 0.5 | +87.7 | 43.6 | 0.0 |
| PATHS CROSS | 3.4 | +97.0 | 0.0 | 14.6 | 4.5 | +186.1 | 0.0 | 22.3 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -2.0 | 0.0 | 0.0 |
| PLAN RESULT | 40.0 | +643.2 | 439.8 | 652.9 | 43.3 | +638.8 | 391.4 | 923.0 |
| PURSUES BIG PREY | - | - | - | - | 0.2 | -53.5 | 0.0 | 0.0 |
| QUARTER ODDS | - | - | - | - | 7.9 | +997.7 | 246.6 | 113.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +65.9 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.0 | 0.0 | 8.5 | 0.3 | -12.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.5 | +150.4 | 0.0 | 77.9 | 1.1 | +23.6 | 0.0 | 15.8 |
| REDIRECT WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.4 | -48.8 | 0.0 | 0.0 | 0.5 | -6.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +14.7 | 0.0 | 0.0 | 0.5 | +21.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.4 | +50.5 | 118.4 | 28.6 | 1.6 | -43.3 | 116.5 | 5.0 |
| RISK BY HIS FIGURE | 12.3 | -236.5 | 0.0 | 203.8 | 10.4 | -73.8 | 0.0 | 183.7 |
| RUN DOWN | 0.8 | -6.4 | 128.9 | 0.0 | 2.4 | -17.0 | 147.9 | 31.5 |
| SAFER THAN THE JOB | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.1 | -8.0 | 18.6 | 0.0 | 0.2 | -1.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.7 | 0.0 | 0.0 | 0.4 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -12.5 | 0.0 | 3.6 |
| SEARCH SPOT | 5.2 | +229.9 | 0.0 | 15.8 | 5.3 | +372.8 | 0.0 | 15.1 |
| SET UP TOGETHER | 0.2 | +1.4 | 0.0 | 0.0 | 0.5 | +39.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +11.3 | 6.5 | 13.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.4 | +67.9 | 96.8 | 31.0 | 1.0 | +28.8 | 33.2 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -0.8 | 11.3 | 0.0 | 0.3 | -5.3 | 17.0 | 25.0 |
| SHOT RISK POINTS | 10.0 | +34.1 | 0.0 | 196.7 | 13.2 | +231.9 | 0.0 | 199.5 |
| SHOTS IN THE MOVE | 14.8 | +607.2 | 0.0 | 184.9 | 13.1 | +453.4 | 0.0 | 189.2 |
| SPELL SETS UP CHARGE | 0.3 | +142.8 | 0.0 | 0.0 | 0.1 | +2.9 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +5.1 | 6.5 | 71.0 | 1.2 | +11.2 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | 0.6 | -11.9 | 78.8 | 11.7 | 0.2 | -9.3 | 8.4 | 26.5 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.6 | 13.0 | 0.0 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.1 | +0.0 | 346.0 | 235.9 | 15.4 | +0.0 | 642.4 | 175.5 |
| STAY WORTH | 18.2 | +88.3 | 187.7 | 95.4 | 17.0 | +110.6 | 404.7 | 244.5 |
| SUPPORT NARROWED | 1.0 | +0.0 | 112.4 | 20.2 | 1.2 | +0.0 | 49.5 | 21.4 |
| SURE REACH TOGETHER | 0.3 | +6.7 | 0.0 | 0.0 | 1.0 | +12.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.4 | +0.0 | 0.0 | 28.6 | 4.7 | +0.0 | 0.0 | 22.3 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -10.5 | 0.0 | 7.0 |
| THE PROMISED MOVE | 0.1 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 25.5 |
| TIED UP BY THE SUM | 0.2 | +10.4 | 10.5 | 0.0 | 0.9 | +82.3 | 78.0 | 0.0 |
| TIME ON OUR SIDE | 19.6 | +313.8 | 0.0 | 220.7 | 14.2 | +243.1 | 0.0 | 241.0 |
| WAITS AGAIN | 0.4 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +10.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 16.5 | 6.5 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.4 | +41.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | -1.5 | 5.0 | 0.0 | 0.1 | +6.3 | 18.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +10.0 | 0.0 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.6 | -3.5 | 144.4 | 20.2 | 2.2 | -5.8 | 135.9 | 31.5 |
| WOUNDS ON THE RANKS | 1.6 | +90.3 | 0.0 | 61.1 | 1.3 | +68.2 | 0.0 | 6.8 |

### Rule changes: h6-opp-0333a16-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 136 | 136 | 127 | 12.70 | +8651 | +68.1 |
| HIS SHOT LIST | 433 | 433 | 116 | 11.60 | +2559 | +22.1 |
| DEPLOY BY FIGURES | 160 | 160 | 94 | 9.40 | +1443 | +15.4 |
| SEARCH SPOT | 105 | 105 | 94 | 9.40 | +6027 | +64.1 |
| LEGAL CHARGES ONLY | 93 | 93 | 93 | 9.30 | +0 | +0.0 |
| TIME ON OUR SIDE | 338 | 302 | 93 | 9.30 | +542 | +5.8 |
| ONE TARGET A SHOOTER | 299 | 299 | 85 | 8.50 | +941 | +11.1 |
| PATHS CROSS | 79 | 79 | 79 | 7.90 | +2831 | +35.8 |
| FIVE ACTION | 924 | 923 | 50 | 5.00 | +1916 | +38.3 |
| SHOT RISK POINTS | 232 | 232 | 48 | 4.80 | +1432 | +29.8 |
| ARTILLERY RE-ROLL WEIGHED | 39 | 39 | 39 | 3.90 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 65 | 65 | 36 | 3.60 | +1970 | +54.7 |
| HARD STAY DROPPED | 28 | 28 | 28 | 2.80 | +0 | +0.0 |
| MAX FOR POSITIONING | 102 | 100 | 25 | 2.50 | +108 | +4.3 |
| FOUR ROUNDS | 48 | 47 | 24 | 2.40 | +1238 | +51.6 |
| CANNON PLANNED TARGET | 98 | 98 | 23 | 2.30 | -133 | -5.8 |
| OFF BEST | 19 | 19 | 19 | 1.90 | -377 | -19.8 |
| COVER ONCE | 97 | 77 | 17 | 1.70 | +92 | +5.4 |
| CANNON SIGHT KEPT | 14 | 14 | 14 | 1.40 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 14 | 1.40 | +299 | +21.3 |
| FALLS SHORT | 229 | 187 | 13 | 1.30 | +80 | +6.1 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.30 | +1099 | +84.5 |
| RISK BY HIS FIGURE | 227 | 227 | 13 | 1.30 | +696 | +53.5 |
| CHARGE LOSSES | 105 | 105 | 12 | 1.20 | +782 | +65.1 |
| QUARTER ODDS | 79 | 79 | 12 | 1.20 | +1255 | +104.6 |
| WOUNDS ON THE RANKS | 29 | 29 | 12 | 1.20 | +381 | +31.8 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 1.10 | +0 | +0.0 |
| LANE BY FIGURES | 11 | 11 | 11 | 1.10 | +457 | +41.6 |
| MANOEUVRE | 27 | 27 | 11 | 1.10 | +600 | +54.6 |
| MISSILES IN THE MOVE | 64 | 48 | 11 | 1.10 | +318 | +28.9 |
| IDLE COST | 131 | 107 | 10 | 1.00 | +168 | +16.8 |
| NEXT CHARGE BY LIST | 98 | 98 | 10 | 1.00 | +267 | +26.7 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.90 | +0 | +0.0 |
| CHARGE NOW FIRST | 27 | 27 | 9 | 0.90 | -765 | -85.0 |
| NEXT OBJECTIVE NEARER | 56 | 56 | 9 | 0.90 | +207 | +23.0 |
| RESERVE FALL BACK | 9 | 9 | 9 | 0.90 | +363 | +40.3 |
| MARCH CHECK | 11 | 11 | 8 | 0.80 | +120 | +15.0 |
| ONE OBJECTIVE FORMULA | 85 | 71 | 8 | 0.80 | +263 | +32.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 0.80 | +659 | +82.4 |
| REDIRECT COUNTER | 36 | 33 | 8 | 0.80 | +719 | +89.9 |
| TIED UP BY THE SUM | 11 | 10 | 8 | 0.80 | +230 | +28.7 |
| COMBAT PIVOT | 7 | 7 | 7 | 0.70 | +0 | +0.0 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.70 | +0 | +0.0 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.70 | +404 | +57.8 |
| RISK BY ARC | 30 | 29 | 7 | 0.70 | +161 | +23.0 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 0.60 | +34 | +5.6 |
| CHARGE NOT DECLARED | 6 | 6 | 6 | 0.60 | -406 | -67.7 |
| FEATURE BUFFS | 31 | 31 | 6 | 0.60 | +107 | +17.8 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 0.60 | +2004 | +333.9 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.60 | +265 | +44.2 |
| SCOUT WAITS | 6 | 6 | 6 | 0.60 | +0 | +0.0 |
| SHOTS IN THE MOVE | 279 | 241 | 6 | 0.60 | +190 | +31.7 |
| CAST JOB | 8 | 8 | 5 | 0.50 | +35 | +6.9 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.50 | +0 | +0.0 |
| STAY WORTH | 352 | 318 | 5 | 0.50 | +20 | +4.0 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.40 | +579 | +144.9 |
| FIRE IN ORDER | 4 | 4 | 4 | 0.40 | +0 | +0.0 |
| HIS TURN DENIED | 19 | 19 | 4 | 0.40 | +111 | +27.7 |
| NEARER NOT NEEDED | 103 | 98 | 4 | 0.40 | +147 | +36.8 |
| ONE FIGHT FORMULA | 90 | 42 | 4 | 0.40 | +18 | +4.5 |
| OVERRUNS AWAY | 7 | 7 | 4 | 0.40 | +119 | +29.8 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 0.40 | +8 | +2.0 |
| SURE REACH TOGETHER | 13 | 13 | 4 | 0.40 | +5 | +1.3 |
| WHO HITS BACK | 4 | 4 | 4 | 0.40 | +268 | +67.0 |
| MISSILES NEXT TURN | 80 | 59 | 3 | 0.30 | +18 | +5.9 |
| OPENS UP | 3 | 3 | 3 | 0.30 | +173 | +57.8 |
| REFUSING RETIRES | 7 | 7 | 3 | 0.30 | -1 | -0.2 |
| CASTING BLOCK | 2 | 2 | 2 | 0.20 | +0 | +0.1 |
| CHAFF PASSED | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| FIGHT TO THE END | 21 | 21 | 2 | 0.20 | +31 | +15.4 |
| HIS MOVE AND SHOT | 21 | 21 | 2 | 0.20 | +27 | +13.5 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.20 | +110 | +55.1 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.20 | -534 | -267.2 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 8 | 8 | 2 | 0.20 | +6 | +3.0 |
| SUPPORT NARROWED | 22 | 22 | 2 | 0.20 | -7 | -3.5 |
| WAR ENGINE JOBS | 4 | 4 | 2 | 0.20 | -116 | -57.8 |
| BEST OVERALL | 1 | 1 | 1 | 0.10 | +7 | +6.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.10 | -30 | -30.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.10 | +17 | +17.2 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.10 | -29 | -28.7 |
| CHARGER SLAIN LOST | 5 | 5 | 1 | 0.10 | +27 | +26.9 |
| FRIEND SHOOTS FIRST | 7 | 7 | 1 | 0.10 | +10 | +10.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.10 | +26 | +25.7 |
| GUN MASK | 17 | 17 | 1 | 0.10 | +8 | +7.9 |
| HIS CHARGE DENIED | 11 | 11 | 1 | 0.10 | +36 | +36.1 |
| HONEST WORTH | 43 | 42 | 1 | 0.10 | +4 | +3.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.10 | +10 | +9.7 |
| LONG SHOT | 3 | 3 | 1 | 0.10 | +34 | +34.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.10 | -20 | -19.6 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.10 | +7 | +6.8 |
| THE PROMISE ADDS | 3 | 3 | 1 | 0.10 | +0 | +0.0 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.10 | +34 | +34.5 |
| WIDER SPREAD | 38 | 38 | 1 | 0.10 | +22 | +22.4 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 16 | 16 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARACTER GUNS | 3 | 3 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 35 | 34 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 93 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 28 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 36 | 36 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 47 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 64 | 64 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 45 | 45 | 0 | 0.00 | - | - |
| HOLD ODDS | 119 | 119 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 33 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 44 | 44 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 833 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 32 | 31 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 345 | 345 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 81 | not checked | - | - | - | - |
| THE PROMISED MOVE | 11 | not checked | - | - | - | - |
| WAITS AGAIN | 17 | 17 | 0 | 0.00 | - | - |
| WALK PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h6-opp-0333a16-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOW FIRST | rule | 0.40 | 0.50 | 85.0 |
| HOLDER ASSIGNMENT | rule | - | 0.90 | 19.3 |
| JOB FIRST | gate | 0.30 | 0.60 | 25.3 |
| PATHS CROSS | rule | 0.20 | 0.50 | 28.3 |
| CANNON PLANNED TARGET | rule | 0.50 | 0.10 | 27.9 |
| CHARGE NOT DECLARED | rule | 0.10 | 0.50 | 67.7 |
| FALLBACK | gate | 0.30 | - | 11.6 |
| AFTERMATH BAND | gate | 0.10 | 0.10 | 1.0 |
| FIGHT ORDER BAND | gate | 0.10 | 0.10 | 2.6 |
| PURSUES BIG PREY | rule | - | 0.20 | 267.2 |
| SUPPORT NARROWED | rule | 0.10 | 0.10 | 3.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.10 | - | 78.1 |
| BEST PRIZE | rule | - | 0.10 | 30.2 |
| CARRIES OUT SET-UP | rule | - | 0.10 | 28.7 |
| DEPLOY BY FIGURES | rule | - | 0.10 | 13.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.10 | - | 27.5 |
| PIVOT GUARDS FLANK | rule | - | 0.10 | 19.6 |
| RULE SWITCHED OFF | gate | 0.10 | - | 1.8 |
| WAR ENGINE JOBS | rule | 0.10 | - | 115.2 |

### Plans: h6-opp-0333a16-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 35% | 227 | 129 | 57% |
| Mine | join | 1.1 | 100% | 34 | 0 | 0% |
| Mine | move | 28.4 | 95% | 1441 | 0 | 0% |
| Mine | shoot | 8.7 | 52% | 390 | 514 | 132% |
| Mine | support | 0.1 | 0% | 0 | 0 | - |
| Opponent | charge | 2.5 | 72% | 299 | 203 | 68% |
| Opponent | join | 1.3 | 100% | 60 | 0 | 0% |
| Opponent | move | 32.5 | 95% | 1764 | 0 | 0% |
| Opponent | shoot | 6.7 | 66% | 391 | 436 | 111% |
| Opponent | support | 0.3 | 67% | 1 | 0 | 0% |

### Battle groups: h6-opp-0333a16-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.5 | 52% | 46% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.1 | 9% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-opp-0333a16-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 5 (9) | 0 | 5 | 46 | 67% | 2.0 | 0 (3) | 12 (3) | 0 (3) | 0 (5) | 10 (4) |
| Mine | Character | 43 | 33 (43) | 33 | 0 | 27 | 21% | 2.4 | 22 (12) | 23 (17) | 76 (8) | 30 (10) | 37 (27) |
| Mine | Clean-up | 12 | 86 (12) | 0 | 86 | 25 | 33% | 4.0 | 98 (4) | 106 (5) | 45 (3) | 111 (8) | 0 (4) |
| Mine | Fast Hammer | 4 | 18 (4) | 18 | 0 | 100 | 25% | 3.3 | 35 (2) | 0 (2) | - | 71 (1) | 0 (3) |
| Mine | Hammer | 26 | 45 (26) | 18 | 28 | 18 | 23% | 2.6 | 52 (5) | 47 (16) | 34 (5) | 36 (9) | 49 (17) |
| Mine | Holder | 9 | 74 (9) | 24 | 49 | 48 | 78% | 4.0 | 220 (1) | 73 (6) | 14 (2) | 153 (3) | 23 (6) |
| Mine | Shooter | 4 | 219 (4) | 23 | 196 | 50 | 0% | 2.0 | 231 (1) | 138 (2) | 369 (1) | 246 (3) | 138 (1) |
| Mine | War machine | 18 | 23 (18) | 23 | 0 | 30 | 0% | 1.1 | 42 (8) | 6 (7) | 0 (3) | 20 (2) | 23 (16) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 18 | 40% | 4.3 | 0 (1) | 0 (4) | - | - | 0 (5) |
| Opponent | Chaff | 17 | 123 (17) | 6 | 117 | 37 | 59% | 3.0 | 62 (5) | 229 (5) | 95 (7) | 153 (13) | 36 (4) |
| Opponent | Character | 34 | 31 (34) | 31 | 0 | 21 | 35% | 2.5 | 12 (13) | 49 (16) | 0 (4) | 32 (22) | 31 (11) |
| Opponent | Clean-up | 5 | 29 (5) | 9 | 20 | 41 | 40% | 2.0 | 76 (1) | 12 (4) | - | 36 (4) | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 17 | 49 (17) | 37 | 13 | 29 | 41% | 3.0 | 32 (8) | 61 (9) | - | 63 (11) | 29 (6) |
| Opponent | Hammer | 5 | 75 (5) | 27 | 48 | 18 | 60% | 2.0 | - | 93 (4) | 24 (1) | 75 (5) | - |
| Opponent | Holder | 6 | 94 (6) | 0 | 94 | 30 | 67% | 2.0 | - | 123 (5) | 0 (1) | - | 94 (6) |
| Opponent | Shooter | 11 | 62 (11) | 15 | 48 | 44 | 0% | 1.8 | 51 (4) | 127 (3) | 40 (4) | 99 (5) | 14 (6) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 39 (15) | 39 | 0 | 38 | 13% | 2.4 | 27 (5) | 73 (6) | 0 (4) | 19 (3) | 43 (12) |
| Opponent | Wizard | 8 | 0 (8) | 0 | 0 | 19 | 38% | 3.8 | 0 (3) | 0 (2) | 0 (2) | 0 (6) | 0 (1) |

### Charged fights: h6-opp-0333a16-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 126 | 96 | 1.5 | 1.0 | 64 | 14 | +50 | 1 of 6 | 2 of 6 | - | +50 |
| Mine | Chaos Dwarfs | 4 | 114 | 292 | 3.0 | 1.2 | 97 | 5 | +92 | 4 of 12 | 11 of 12 | +0 | +110 |
| Mine | Dwarfen Mountain Holds | 2 | 324 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 10 | 161 | 155 | 1.9 | 1.1 | 82 | 8 | +74 | 5 of 19 | 14 of 19 | +0 | +83 |
| Opponent | Empire of Man | 3 | 217 | 46 | 1.0 | 1.0 | 46 | 172 | -127 | 1 of 3 | 3 of 3 | - | -127 |
| Opponent | Grand Cathay | 1 | 580 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 182 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 927 | 4.0 | 1.2 | 232 | 108 | +124 | 3 of 4 | 3 of 4 | +540 | -15 |
| Opponent | Vampire Counts | 3 | 17 | 321 | 3.7 | 1.3 | 88 | 0 | +88 | 2 of 11 | 10 of 11 | +94 | +86 |
| Opponent | Warriors of Chaos | 1 | 0 | 962 | 3.0 | 1.3 | 321 | 0 | +321 | 1 of 3 | 3 of 3 | +677 | +142 |
| **Opponent** | all armies | 10 | 147 | 299 | 2.1 | 1.2 | 142 | 45 | +97 | 7 of 21 | 19 of 21 | +352 | +37 |

### Effective charges: h6-opp-0333a16-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net -21) | 0 | 0 | 0 | 0 | 1 (net +60) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 12 | 0 | 0 | 3 (net +197) | 5 (net -3) | 2 (net +99) | 2 (net +165) | 0 | 25% (3 of 12) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 3 | 1 (net -517) | 0 | 0 | 1 (net +52) | 0 | 1 (net +85) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net -431) | 0 | 2 (net +431) | 1 (net +65) | 0 | 0 | 0 | 50% (2 of 4) |
| Opponent | Vampire Counts | 11 | 1 (net +0) | 0 | 2 (net +0) | 3 (net +185) | 3 (net +137) | 2 (net +0) | 0 | 18% (2 of 11) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net +95) | 1 (net +190) | 1 (net +677) | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: h6-opp-0333a16-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 60 | 218 | -21 | 0 | 36 | -36 | -60.4 |
| Mine | Effective (55-75%) | 3 | 267 | 303 | +197 | 197 | 0 | +197 | +73.6 |
| Mine | 76-89% | 6 | 364 | 165 | -2 | 49 | 32 | +17 | +4.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 254 | 130 | +130 | 130 | 0 | +130 | +51.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 310 | 56 | +99 | 99 | 0 | +99 | +31.9 |
| Mine | No odds | 1 | 836 | 185 | +325 | 325 | 32 | +293 | +35.1 |
| Mine | All fights | 19 | 287 | 182 | +74 | 95 | 20 | +75 | +26.2 |
| Opponent | Long shot (under 50%) | 3 | 281 | 589 | -316 | 122 | 333 | -211 | -75.1 |
| Opponent | Effective (55-75%) | 5 | 452 | 283 | +191 | 191 | 13 | +178 | +39.5 |
| Opponent | 76-89% | 6 | 259 | 82 | +144 | 191 | 0 | +191 | +73.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 123 | 74 | +28 | 40 | 22 | +18 | +15.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 628 | 130 | +272 | 272 | 4 | +268 | +42.6 |
| Opponent | All fights | 21 | 359 | 210 | +97 | 175 | 55 | +121 | +33.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-opp-0333a16-p2 | move | 65 | 9 (14%) | 7 (11%) | 9 (14%) | 47 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

# Doctrine scorecard: h6-opp-0333a16-p1

### Scorecard: h6-opp-0333a16-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 445 |
| L0120 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 2 | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | yes | 4 | - | 0 | 5 | 1 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 7 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 3 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0219 | 3 | 1 | Opponent | yes | 9 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0304 | 4 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 0 | 0 | 0 | 112 |
| L0321 | 3 | 1 | Mine | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 85 |
| L0321 | 3 | 1 | Opponent | yes | 5 | 6 | 2 | 3 | 1 | 0 | 0 | 500 |
| L0406 | 4 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 435 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 6 | 3 | 0 | 0 | 0 | 65 |
| L0423 | 3 | 1 | Opponent | yes | 7 | 2 | 6 | 1 | 1 | 0 | 0 | 70 |
| L0510 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 350 |
| L0510 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L0525 | 3 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 596 |
| L0525 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 10% | 4.2 | 3.0 | 1.3 | 1.7 | 0.2 | 0.0 | 0.0 | 137.6 |
| **Average** | | | Opponent | 30% | 4.4 | 2.9 | 2.8 | 1.9 | 0.3 | 0.0 | 0.0 | 210.2 |

### KPIs: h6-opp-0333a16-p1

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 10 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (16 of 40) | 20% (9 of 45) | 29% (25 of 85) |
| Winner chose to follow up after the loser gave ground |  | 67% (8 of 12); on the table 67% | 83% (10 of 12); on the table 83% | 75% (18 of 24); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (5 of 5); on the table 100% | 100% (3 of 3); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 74% (14 of 19); on the table 74% | 88% (14 of 16); on the table 88% | 80% (28 of 35); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 34% (47 of 138) | 24% (19 of 78) | 31% (66 of 216) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (47 of 118) | 33% (19 of 58) | 38% (66 of 176) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 29% (2 of 7) | 56% (9 of 16) | 48% (11 of 23) |
| Points that never fought | lower | 47% (8892 of 18788) | 51% (10286 of 19993) | 49% (19178 of 38781) |
|   infantry points that never fought | lower | 58% (3181 of 5442) | 79% (3716 of 4683) | 68% (6897 of 10125) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (36 of 66) | 54% (43 of 79) | 54% (79 of 145) |
| Bound items with a magic missile used (at least once a game) |  | 67% (4 of 6); 1.0 uses a game | 33% (1 of 3); 0.1 uses a game | 56% (5 of 9); 0.6 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.6 uses a game | 40% (2 of 5); 0.2 uses a game | 62% (8 of 13); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (6583 of 14152) | 47% (8001 of 17156) | 47% (14584 of 31308) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.1 (45%) | 2.8 (47%) | 6.9 (46%) |
| MARCHED: its unit marched | 2.2 (24%) | 0.9 (15%) | 3.1 (21%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |
| IN COMBAT: engaged in combat | 0.9 (10%) | 1.7 (29%) | 2.6 (17%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.5 (5%) | 0.0 (0%) | 0.5 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (7%) | 0.2 (3%) | 0.8 (5%) |
| STUPIDITY: Stupidity | 0.5 (5%) | 0.0 (0%) | 0.5 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.4 | 0.8 | 2.5 | 6.6 | 0.7 | 1.6 |
| not cast | 2.4 | 1.0 | 5.3 | 15.0 | 2.9 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (50%) | 0.9 (17%) | 6.9 (46%) | 1.0 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.1 (21%) | 0.4 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.0 (0%) | 0.9 (17%) | 2.6 (17%) | 0.8 (28%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.1 (3%) | 0.6 (3%) |
| GONE: slain | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.1 (10%) | 0.5 (9%) | 0.8 (5%) | 0.2 (7%) | 1.5 (8%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.2 (4%) | 0.5 (3%) | 0.1 (3%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (75%) | 0.4 (40%) | 2.7 (51%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.5 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.7 a game | 1.5 a game |
| stood (cast and not dispelled) | 57% (13 of 23) | 33% (2 of 6) | 52% (15 of 29) |
| the unit moved after it | 85% (11 of 13) | 100% (2 of 2) | 87% (13 of 15) |
| it charged on its next turn | 0% (0 of 13) | 0% (0 of 2) | 0% (0 of 15) |
| the enemy charged it first | 15% (2 of 13) | 0% (0 of 2) | 13% (2 of 15) |
| it fought by the end of its next turn | 15% (2 of 13) | 0% (0 of 2) | 13% (2 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 13) | 0% (0 of 2) | 7% (1 of 15) |
| none of these (no charge, no fight, no charge escaped) | 77% (10 of 13) | 100% (2 of 2) | 80% (12 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (146 of 221) | 60% (127 of 211) | 63% (273 of 432) |
|   cavalry | 58% (7 of 12) | 50% (11 of 22) | 53% (18 of 34) |
|   character | 91% (29 of 32) | 44% (7 of 16) | 75% (36 of 48) |
|   chariot | 54% (19 of 35) | 54% (30 of 56) | 54% (49 of 91) |
|   infantry | 53% (25 of 47) | 57% (38 of 67) | 55% (63 of 114) |
|   monster | - | 100% (5 of 5) | 100% (5 of 5) |
|   war machine | 69% (66 of 95) | 80% (36 of 45) | 73% (102 of 140) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (29%) | 2.1 (25%) | 4.3 (27%) |
| CHARGED: it charged | 0.1 (1%) | 1.3 (15%) | 1.4 (9%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (12%) | 0.4 (5%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.4 (19%) | 0.1 (1%) | 1.5 (9%) |
| NO TARGET IN RANGE | 1.4 (19%) | 2.5 (30%) | 3.9 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.5 (7%) | 1.3 (15%) | 1.8 (11%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.7 (9%) | 0.4 (5%) | 1.1 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.9 | 0.6 | 68% | 7.2 pts | 14 pts |
| character | 4.0 | 2.0 | 72% | 5.8 pts | 23 pts |
| chariot | 5.1 | 7.8 | 35% | 23.9 pts | 122 pts |
| infantry | 9.2 | 3.5 | 71% | 7.2 pts | 66 pts |
| monster | 0.5 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 10.2 | 8.9 | 71% | 25.2 pts | 257 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 5.1 | 3.7 |
| Charges that made contact a game | 1.7 | 3.9 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.83 contact (6 units) | 1.20 declared, 1.10 contact (10 units) | 1.06 declared, 1.00 contact (16 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 4.00 declared, 3.00 contact (1 units) | 4.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.20 contact (61 units) | 0.45 declared, 0.32 contact (77 units) | 0.38 declared, 0.27 contact (138 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 33% (1 of 3) | - | 44% (4 of 9) |
| Character in a unit | 93% (13 of 14) | 75% (6 of 8) | - | 86% (19 of 22) |
| Character on its own | 75% (9 of 12) | 30% (3 of 10) | 18% (2 of 11) | 42% (14 of 33) |
| Chariot | 100% (3 of 3) | 42% (5 of 12) | - | 53% (8 of 15) |
| Infantry | 35% (8 of 23) | 27% (4 of 15) | - | 32% (12 of 38) |
| Monster | 80% (4 of 5) | 67% (2 of 3) | - | 75% (6 of 8) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 80% (12 of 15) | 100% (3 of 3) | - | 83% (15 of 18) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 30% (31 of 102) | 48% | 59% (13 of 22) | 67% (4 of 6); 2.5 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 7 | 69% (9 of 13); on the table 69% | 42% (25 of 60) | 52% | 46% (25 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 3 | 40% (2 of 5); on the table 40% | - | 51% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 23% (7 of 30) | 48% | 40% (4 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 8% (1 of 12) | 76% | 69% (11 of 16) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 20% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 61% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-opp-0333a16-p1, 10 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 36% (9) | 33% (4) | 35% (13) |
| ...free all their last turn and able to turn (per game) | 0.70 | 0.30 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.20 | 0.00 | 0.20 |
| ...with the charger already in that arc before they moved (per game) | 0.40 | 0.30 | 0.70 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.40 | 0.00 | 0.40 |

### Quality by phase: h6-opp-0333a16-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 1.9 |
| Strategy | Charge objectives carried out (made contact) | 73% (16 of 22) | 53% (23 of 43) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (41 of 115) | 59% (50 of 85) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (5 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 36% (9 of 25) | 20% (2 of 10) |
| Strategy | Lone characters that fought | 70% (16 of 23) | 83% (19 of 23) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.7 | 1.9 |
| Movement | Points that never moved of their own | 137.6 | 210.2 |
| Movement | Fights charged into per game | 1.8 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 18, net -52 | 11 of 28, net +106 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 18, net +140 | 2 of 28, net +142 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 18, net +41 | 2 of 28, net +128 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 18, net +128 | 5 of 28, net +85 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.1 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (29 of 81) | 49% (49 of 100) |
| Shooting | Points destroyed by shooting units | 81.4 | 29.6 |
| Shooting | War machine shots | 6.6 | 3.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (30 of 66) | 86% (31 of 36) |
| Shooting | Points destroyed by war machines | 74.6 | 6.5 |
| Magic | Magic missiles cast | 2.6 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (11 of 26) | 60% (6 of 10) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.7 |
| Magic | Wounds caused by other spells | 1.0 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 39.1 | 7.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.1 / 1.1 / 0.2 | 2.7 / 0.3 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 170.2 | 284.5 |
| Combat | Points run down | 5.5 | 75.2 |
| Combat | Net points per charged fight, damage counted | +110 | +134 |
| Combat | Net per 100 charger points, damage counted | +34.6 | +41.7 |
| Combat | First round won (charged fights) | 83% | 64% |
| Combat | Net points per charged fight | +79 | +130 |
| Combat | Net points per supported fight / lone fight | +126 / +73 | +104 / +132 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 18 | 17 of 33 |
| Game | Points lost | 576.2 | 550.6 |
| Game | VP from objectives | 626.0 | 792.0 |
| Game | Lone holders (player turns) | 4.2 | 4.4 |

- Mine won / drew / lost: 5 / 2 / 3 of 10 ended games (of 10); mean margin (Mine - Opponent) -202 VP
- The side that went first won 3 of 8 games with a winner
- Points traded per game (both sides' losses): 1127
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-opp-0333a16-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +88.9 | 0.0 | 28.9 | 0.3 | +76.1 | 0.0 | 18.3 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 70.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.9 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -6.7 | 21.9 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -7.9 | 23.5 | 0.0 | 0.4 | -37.9 | 28.9 | 0.0 |
| CANNON PLAN MISSED | 0.4 | +0.0 | 45.7 | 9.5 | 0.1 | +0.0 | 9.5 | 16.5 |
| CANNON PLANNED TARGET | 6.4 | +65.2 | 225.7 | 108.5 | 3.6 | +29.3 | 6.5 | 67.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.2 | +8.8 | 4.5 | 0.0 | 0.9 | +8.4 | 8.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 44.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.4 | +24.6 | 0.0 | 17.0 | 0.4 | +14.8 | 0.0 | 9.0 |
| CHAFF PASSED | 0.1 | -0.1 | 11.2 | 0.0 | 0.2 | +0.0 | 0.0 | 14.5 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.0 | -166.6 | 0.0 | 71.3 | 5.0 | -158.9 | 0.0 | 95.2 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 30.1 | 5.2 | 0.5 | +0.0 | 43.8 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 100.6 | 5.2 | 2.4 | +0.0 | 237.2 | 0.0 |
| CHARGER SLAIN LOST | 0.2 | -1.5 | 0.0 | 0.0 | 0.2 | -7.2 | 0.0 | 7.2 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 5.2 | 0.1 | +0.0 | 11.2 | 0.0 |
| CHEAPEST HOLDER | 0.3 | -10.8 | 11.2 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 34.0 | 0.7 | +0.0 | 12.0 | 21.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.8 | +142.8 | 54.4 | 44.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| COVER ONCE | 4.9 | -199.0 | 0.0 | 77.2 | 6.3 | -446.6 | 0.0 | 85.6 |
| DEPLOY BY FIGURES | 8.4 | +24.5 | 0.0 | 6.5 | 8.4 | +13.2 | 0.0 | 38.9 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +46.2 | 27.2 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.1 | 66.3 | 5.2 | 2.9 | +2.4 | 230.0 | 0.0 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.5 |
| FALLS SHORT | 6.4 | +115.9 | 0.0 | 62.5 | 15.3 | +195.0 | 0.0 | 93.4 |
| FEATURE BUFFS | 2.4 | +52.3 | 0.0 | 16.2 | 0.4 | +12.7 | 0.0 | 14.5 |
| FIGHT TO THE END | 0.9 | +57.7 | 79.6 | 0.0 | 1.2 | +119.8 | 134.5 | 0.0 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 43.9 | +2048.2 | 573.5 | 507.4 | 48.6 | +3335.5 | 390.2 | 357.6 |
| FLANK NOT WEIGHED | 3.1 | +0.0 | 0.0 | 102.4 | 4.4 | +0.0 | 0.0 | 43.6 |
| FOLLOW UP WEIGHED | 0.4 | +120.0 | 0.0 | 0.0 | 0.9 | +224.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.1 | +229.8 | 150.1 | 5.2 | 4.3 | +620.0 | 307.2 | 7.2 |
| FRIEND CHARGES FIRST | 0.2 | -2.5 | 0.0 | 0.0 | 0.1 | -16.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -9.8 | 0.0 | 0.0 | 0.2 | -5.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -4.2 | 13.6 | 0.0 | 0.1 | -1.3 | 9.5 | 0.0 |
| GROUND FLIERS | 0.1 | +4.2 | 0.0 | 21.9 | - | - | - | - |
| GUN FIGURES | 1.8 | +19.0 | 61.7 | 0.0 | 1.5 | +1.2 | 32.7 | 13.0 |
| GUN MASK | 0.3 | +9.0 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.9 | +0.0 | 0.0 | 0.0 | 1.9 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.6 | +0.0 | 0.0 | 49.8 | 2.0 | +0.0 | 0.0 | 27.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.2 | +5.3 | 19.5 | 0.0 | 0.2 | +8.3 | 8.5 | 0.0 |
| HIS CHARGE LIST | 2.2 | +0.0 | 0.0 | 14.7 | 0.8 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.4 | +0.0 | 0.0 | 27.2 | 3.0 | +0.0 | 0.0 | 16.7 |
| HIS MOVE AND SHOT | 2.7 | -42.8 | 0.0 | 64.1 | 1.2 | -36.0 | 0.0 | 11.1 |
| HIS RANDOM MOVE | 2.1 | +0.0 | 0.0 | 5.5 | 1.2 | +0.0 | 0.0 | 11.5 |
| HIS SHOT LIST | 16.6 | +429.3 | 0.0 | 216.5 | 22.3 | +815.9 | 0.0 | 221.6 |
| HIS TURN DENIED | 1.0 | +27.7 | 105.2 | 0.0 | 2.4 | +66.5 | 193.8 | 0.0 |
| HOLD ODDS | - | - | - | - | 14.1 | +0.0 | 0.0 | 36.1 |
| HOLDER ASSIGNMENT | - | - | - | - | 16.4 | +1525.4 | 0.0 | 32.6 |
| HOLDER AT DEPLOYMENT | 1.0 | +189.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -71.2 | 150.1 | 0.0 | 3.7 | -212.6 | 280.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +23.6 | 0.0 | 0.0 |
| IDLE COST | 5.6 | -54.4 | 0.0 | 67.3 | 11.5 | -155.4 | 0.0 | 67.9 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.9 | 18.3 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +5.4 | 0.0 | 0.0 | 0.9 | +29.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.2 | +0.0 | 124.0 | 110.1 | 4.2 | +0.0 | 107.8 | 123.0 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.0 | +61.8 | 0.0 | 11.5 | 0.3 | +32.6 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.3 | 0.0 | 0.0 | 0.4 | -0.7 | 0.0 | 7.2 |
| LOST CHARGE | 0.1 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -7.9 | 0.0 | 8.5 | - | - | - | - |
| MAKE SURE TOGETHER | 0.2 | +6.2 | 0.0 | 11.2 | - | - | - | - |
| MANOEUVRE | 1.0 | +12.5 | 0.0 | 61.3 | 1.6 | +15.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +11.5 | 0.0 | 0.0 | 0.3 | +15.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +24.5 | 0.0 | 0.0 | 0.4 | +11.1 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -15.9 | 0.0 | 0.0 | 0.7 | +47.5 | 0.0 | 32.9 |
| MAX FOR POSITIONING | 2.9 | +27.0 | 0.0 | 24.9 | 4.4 | +47.7 | 0.0 | 39.3 |
| MISSILES IN THE MOVE | 4.7 | +184.0 | 0.0 | 70.6 | 3.0 | +43.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.8 | +115.8 | 0.0 | 70.6 | 4.7 | +43.6 | 0.0 | 32.9 |
| MODEL FACING | - | - | - | - | 0.7 | +176.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.5 | +12.5 | 0.0 | 0.0 | 0.4 | +6.2 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.2 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.1 | -49.6 | 24.4 | 0.0 | 0.2 | -2.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 54.4 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.9 | +196.2 | 0.0 | 10.4 | 3.3 | +378.7 | 0.0 | 12.6 |
| MOVES UNITS SPELL | 0.2 | +11.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.6 | +188.3 | 0.0 | 128.7 | 6.3 | +257.8 | 0.0 | 21.1 |
| NEXT CHARGE BY LIST | 3.8 | -110.1 | 0.0 | 43.1 | 4.8 | -193.6 | 8.1 | 17.1 |
| NEXT OBJECTIVE NEARER | 6.5 | -290.0 | 37.7 | 101.5 | 0.1 | -0.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.4 | -65.7 | 89.0 | 5.2 | 3.5 | -147.3 | 266.6 | 0.0 |
| NO RALLY LEFT | 0.1 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.4 | +0.0 | 0.0 | 8.5 | - | - | - | - |
| NOT WORTH A CAST | 0.4 | -0.5 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -26.7 | 0.0 | 36.4 | 0.6 | -11.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 89.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -41.8 | 0.0 | 46.1 | 5.2 | -113.9 | 0.0 | 52.1 |
| ONE OBJECTIVE FORMULA | 3.6 | +52.9 | 0.0 | 51.2 | 5.0 | +94.9 | 0.0 | 20.5 |
| ONE TARGET A SHOOTER | 13.1 | +362.2 | 0.0 | 212.3 | 20.2 | +411.7 | 0.0 | 157.0 |
| OPENS UP | 0.6 | +22.0 | 48.8 | 0.0 | 0.4 | +14.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.0 | 17.1 | 0.0 | 0.4 | +16.3 | 38.4 | 0.0 |
| PATHS CROSS | 2.3 | +38.4 | 0.0 | 0.0 | 4.0 | +111.0 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +9.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -3.3 | 0.0 | 0.0 | 0.1 | -4.5 | 0.0 | 0.0 |
| PLAN RESULT | 39.2 | +656.4 | 411.0 | 644.7 | 43.3 | +517.0 | 252.8 | 688.3 |
| QUARTER ODDS | - | - | - | - | 7.8 | +971.3 | 59.6 | 24.4 |
| RANDOM MOVE BY FIGURES | 0.7 | +17.0 | 0.0 | 17.0 | 1.6 | +19.6 | 0.0 | 71.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -3.4 | 0.0 | 8.5 | 0.4 | -12.2 | 0.0 | 4.5 |
| REDIRECT COUNTER | 1.3 | +30.8 | 0.0 | 8.1 | 1.1 | +26.5 | 0.0 | 5.5 |
| REDIRECT WEIGHED | - | - | - | - | 0.4 | -3.0 | 9.5 | 6.0 |
| REFORMS TO MEET IT | 0.7 | -28.2 | 0.0 | 10.4 | 0.6 | -5.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +23.9 | 0.0 | 0.0 | 0.5 | +9.4 | 0.0 | 6.6 |
| RESTRAINS TO SHOOT | 0.1 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +7.1 | 150.1 | 5.2 | 1.6 | -40.6 | 151.5 | 0.0 |
| RISK BY HIS FIGURE | 11.5 | -76.8 | 0.0 | 255.9 | 10.6 | -61.7 | 0.0 | 128.9 |
| RUN DOWN | 0.8 | -11.6 | 40.0 | 0.0 | 1.9 | -20.6 | 212.0 | 0.0 |
| SCOUT SPOT | 0.2 | +2.4 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -16.0 | 0.0 | 0.0 | 0.1 | -7.0 | 0.0 | 0.0 |
| SEARCH SPOT | 6.7 | +234.7 | 0.0 | 26.3 | 5.4 | +188.4 | 0.0 | 22.2 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +10.0 | 0.0 | 11.2 | 0.4 | +18.1 | 0.0 | 12.6 |
| SET-UP ANY TARGET | 0.3 | +45.1 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +56.6 | 44.5 | 0.0 | 1.2 | +22.1 | 24.3 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.4 | 11.2 | 5.2 | - | - | - | - |
| SHOT RISK POINTS | 9.8 | -77.2 | 0.0 | 170.1 | 10.4 | +71.6 | 0.0 | 182.4 |
| SHOTS IN THE MOVE | 15.4 | +530.4 | 0.0 | 189.7 | 13.3 | +238.4 | 0.0 | 158.7 |
| SPELL SETS UP CHARGE | 0.3 | +45.1 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +5.1 | 0.0 | 0.0 | 1.6 | +14.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.4 | -4.3 | 37.2 | 0.0 | 0.5 | +2.6 | 9.5 | 7.2 |
| STAND AND SHOOT | 0.6 | -2.9 | 53.8 | 0.0 | 0.5 | -4.3 | 11.2 | 0.0 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 18.5 | +0.0 | 405.1 | 245.9 | 14.1 | +0.0 | 64.0 | 111.0 |
| STAY WORTH | 18.8 | -45.3 | 242.2 | 230.0 | 13.8 | +26.3 | 39.7 | 133.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.6 | +0.0 | 28.8 | 5.2 | 0.8 | +0.0 | 72.2 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +4.5 | 0.0 | 0.0 | 0.5 | +26.6 | 0.0 | 12.6 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 4.1 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.1 | -0.1 | 0.0 | 5.2 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 5.5 |
| TIED UP BY THE SUM | 0.4 | +50.2 | 24.3 | 0.0 | 0.7 | +63.9 | 28.6 | 0.0 |
| TIME ON OUR SIDE | 22.2 | +359.2 | 33.8 | 172.1 | 11.9 | +171.9 | 0.0 | 28.8 |
| WAITS AGAIN | 1.9 | +0.0 | 0.0 | 5.2 | 0.6 | +0.0 | 0.0 | 12.6 |
| WALK PROMISE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +32.8 | 0.0 | 0.0 | 0.2 | +59.5 | 36.7 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 44.5 | 0.0 | 0.5 | +0.0 | 9.5 | 0.0 |
| WHO HITS BACK | 0.4 | +204.7 | 0.0 | 0.0 | 0.1 | +19.5 | 0.0 | 21.0 |
| WHOLE FIGHT | 0.1 | +13.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.2 | +9.8 | 18.3 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.5 | -3.3 | 112.0 | 0.0 | 2.7 | -14.2 | 221.8 | 7.2 |
| WOUNDS ON THE RANKS | 1.9 | +115.9 | 0.0 | 54.4 | 0.7 | +19.2 | 0.0 | 16.7 |

### Rule changes: h6-opp-0333a16-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 164 | 164 | 152 | 15.20 | +6902 | +45.4 |
| SEARCH SPOT | 121 | 121 | 117 | 11.70 | +4231 | +36.2 |
| HIS SHOT LIST | 389 | 389 | 113 | 11.30 | +1542 | +13.6 |
| DEPLOY BY FIGURES | 168 | 168 | 99 | 9.90 | +2187 | +22.1 |
| ONE TARGET A SHOOTER | 333 | 333 | 91 | 9.10 | +852 | +9.4 |
| LEGAL CHARGES ONLY | 84 | 84 | 84 | 8.40 | +0 | +0.0 |
| TIME ON OUR SIDE | 341 | 308 | 69 | 6.90 | +242 | +3.5 |
| PATHS CROSS | 63 | 63 | 63 | 6.30 | +1493 | +23.7 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 4.30 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 62 | 62 | 42 | 4.20 | +1765 | +42.0 |
| FIVE ACTION | 925 | 925 | 40 | 4.00 | +1079 | +27.0 |
| FOUR ROUNDS | 64 | 64 | 40 | 4.00 | +2917 | +72.9 |
| SHOT RISK POINTS | 202 | 202 | 39 | 3.90 | +968 | +24.8 |
| HARD STAY DROPPED | 28 | 28 | 28 | 2.80 | +0 | +0.0 |
| IDLE COST | 171 | 137 | 25 | 2.50 | +157 | +6.3 |
| COVER ONCE | 112 | 96 | 22 | 2.20 | +257 | +11.7 |
| SHOTS IN THE MOVE | 287 | 260 | 21 | 2.10 | +775 | +36.9 |
| CANNON PLANNED TARGET | 100 | 100 | 18 | 1.80 | -161 | -9.0 |
| CANNON SIGHT KEPT | 18 | 18 | 18 | 1.80 | +0 | +0.0 |
| FALLS SHORT | 217 | 181 | 18 | 1.80 | +328 | +18.2 |
| MANOEUVRE | 26 | 26 | 17 | 1.70 | +277 | +16.3 |
| MISSILES IN THE MOVE | 77 | 63 | 17 | 1.70 | +512 | +30.1 |
| NEXT OBJECTIVE NEARER | 66 | 66 | 15 | 1.50 | +98 | +6.6 |
| COMBAT PIVOT | 14 | 14 | 14 | 1.40 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 13 | 13 | 13 | 1.30 | +3447 | +265.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.30 | +944 | +72.7 |
| MAX FOR POSITIONING | 73 | 72 | 13 | 1.30 | +44 | +3.4 |
| ONE OBJECTIVE FORMULA | 86 | 71 | 13 | 1.30 | +575 | +44.2 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 13 | 1.30 | +180 | +13.9 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.20 | +0 | +0.0 |
| LANE BY FIGURES | 12 | 12 | 12 | 1.20 | +344 | +28.7 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 11 | 1.10 | +366 | +33.2 |
| TIED UP BY THE SUM | 11 | 11 | 11 | 1.10 | +215 | +19.5 |
| NEARER NOT NEEDED | 99 | 95 | 10 | 1.00 | +382 | +38.2 |
| QUARTER ODDS | 78 | 78 | 10 | 1.00 | +1254 | +125.3 |
| CHARGE LOSSES | 100 | 100 | 9 | 0.90 | +510 | +56.7 |
| CHARGE NOT DECLARED | 9 | 9 | 9 | 0.90 | -1379 | -153.2 |
| CHARGE NOW FIRST | 37 | 37 | 9 | 0.90 | -1045 | -116.1 |
| RISK BY HIS FIGURE | 221 | 221 | 9 | 0.90 | +551 | +61.2 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.80 | +0 | +0.0 |
| OFF BEST | 8 | 8 | 8 | 0.80 | -384 | -48.1 |
| RESERVE FALL BACK | 8 | 8 | 8 | 0.80 | +333 | +41.7 |
| CHAFF IN THE MOVE | 8 | 8 | 7 | 0.70 | +0 | +0.0 |
| HIS TURN DENIED | 34 | 34 | 7 | 0.70 | +91 | +13.0 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.70 | +270 | +38.5 |
| MARCH CHECK | 11 | 11 | 7 | 0.70 | +156 | +22.3 |
| MODEL FACING | 7 | 7 | 7 | 0.70 | +1767 | +252.5 |
| NEXT CHARGE BY LIST | 86 | 86 | 7 | 0.70 | +91 | +13.0 |
| RISK BY ARC | 36 | 36 | 7 | 0.70 | +346 | +49.5 |
| SHOOTERS IN TWO RANKS | 7 | 7 | 7 | 0.70 | +17 | +2.4 |
| SURE REACH TOGETHER | 12 | 12 | 7 | 0.70 | +29 | +4.1 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.60 | +1650 | +275.0 |
| FEATURE BUFFS | 28 | 28 | 6 | 0.60 | +71 | +11.9 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.60 | +279 | +46.6 |
| OPENS UP | 10 | 10 | 6 | 0.60 | +61 | +10.2 |
| REDIRECT COUNTER | 24 | 19 | 6 | 0.60 | +161 | +26.8 |
| WOUNDS ON THE RANKS | 26 | 26 | 6 | 0.60 | +529 | +88.1 |
| FIGHT TO THE END | 21 | 21 | 5 | 0.50 | +422 | +84.3 |
| WHO HITS BACK | 5 | 5 | 5 | 0.50 | +1672 | +334.4 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.40 | +49 | +12.2 |
| SCOUT WAITS | 4 | 4 | 4 | 0.40 | +0 | +0.0 |
| STAY WORTH | 326 | 303 | 4 | 0.40 | +30 | +7.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.30 | -116 | -38.7 |
| CAST JOB | 21 | 21 | 3 | 0.30 | +9 | +3.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.30 | -1 | -0.2 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.30 | +114 | +38.2 |
| NO DOUBLE ROUNDS | 49 | 49 | 3 | 0.30 | +90 | +29.8 |
| OVERRUNS AWAY | 7 | 7 | 3 | 0.30 | +70 | +23.2 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.30 | -78 | -26.0 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| STUCK PIVOT | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| WAR ENGINE JOBS | 10 | 10 | 3 | 0.30 | -185 | -61.6 |
| CASTING BLOCK | 3 | 3 | 2 | 0.20 | +13 | +6.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.20 | +41 | +20.3 |
| HIS CHARGE DENIED | 4 | 4 | 2 | 0.20 | +41 | +20.4 |
| ONE FIGHT FORMULA | 85 | 42 | 2 | 0.20 | +2 | +1.0 |
| SET UP TOGETHER | 8 | 4 | 2 | 0.20 | +94 | +47.2 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.20 | +207 | +103.5 |
| BLOWS WHERE AIMED | 5 | 5 | 1 | 0.10 | +39 | +39.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.10 | +20 | +19.9 |
| FALLBACK BY WORTH | 3 | 3 | 1 | 0.10 | +0 | +0.3 |
| FRIEND CHARGES FIRST | 3 | 3 | 1 | 0.10 | +5 | +5.2 |
| HIS MOVE AND SHOT | 39 | 39 | 1 | 0.10 | +9 | +9.4 |
| HONEST WORTH | 54 | 54 | 1 | 0.10 | +53 | +52.8 |
| HUNT IN PAIRS | 7 | 4 | 1 | 0.10 | +28 | +28.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| MARCH ODDS | 1 | 1 | 1 | 0.10 | -0 | -0.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.10 | +40 | +39.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.10 | +99 | +99.0 |
| REFORMS TO MEET IT | 13 | 13 | 1 | 0.10 | +12 | +11.8 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.10 | -0 | -0.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.10 | +105 | +105.0 |
| RUN DOWN | 27 | 27 | 1 | 0.10 | +4 | +4.2 |
| SUPPORT NARROWED | 14 | 14 | 1 | 0.10 | -54 | -53.8 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.10 | +11 | +11.0 |
| WIDER SPREAD | 42 | 42 | 1 | 0.10 | +19 | +18.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 39 | 39 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 75 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 33 | not checked | - | - | - | - |
| GUN MASK | 4 | 4 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 36 | 36 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 54 | 54 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 141 | 141 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 95 | 71 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 40 | 40 | 0 | 0.00 | - | - |
| PLAN RESULT | 825 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 24 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 326 | 326 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 68 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| WAITS AGAIN | 25 | 25 | 0 | 0.00 | - | - |
| WALK PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h6-opp-0333a16-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.10 | 17.5 |
| CHARGE NOT DECLARED | rule | 0.40 | 0.50 | 153.2 |
| CHARGE NOW FIRST | rule | 0.20 | 0.70 | 116.1 |
| PATHS CROSS | rule | 0.70 | 0.10 | 33.9 |
| JOB FIRST | gate | 0.10 | 0.40 | 18.0 |
| BEST PRIZE | rule | - | 0.30 | 38.7 |
| PIVOT GUARDS FLANK | rule | 0.20 | 0.10 | 26.0 |
| WAR ENGINE JOBS | rule | 0.20 | 0.10 | 61.6 |
| CANNON PLANNED TARGET | rule | 0.10 | 0.10 | 80.7 |
| AFTERMATH BAND | gate | - | 0.10 | 3.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.10 | - | 254.1 |
| CHAFF PASSED | rule | 0.10 | - | 0.6 |
| NO REASON | gate | - | 0.10 | 37.0 |
| SUPPORT NARROWED | rule | 0.10 | - | 53.8 |

### Plans: h6-opp-0333a16-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 82% | 263 | 161 | 61% |
| Mine | join | 0.6 | 100% | 28 | 0 | 0% |
| Mine | move | 27.0 | 93% | 1359 | 0 | 0% |
| Mine | shoot | 9.8 | 52% | 275 | 495 | 180% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | charge | 3.0 | 57% | 710 | 242 | 34% |
| Opponent | join | 0.4 | 100% | 22 | 0 | 0% |
| Opponent | move | 32.6 | 92% | 1710 | 0 | 0% |
| Opponent | shoot | 6.9 | 58% | 181 | 275 | 152% |
| Opponent | support | 0.4 | 75% | 0 | 0 | - |

### Battle groups: h6-opp-0333a16-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 23% | 67% | 0% | - | 33% | 0% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 1.1 | 18% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-opp-0333a16-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 9 | 76 (9) | 9 | 66 | 49 | 56% | 2.5 | 80 (1) | 99 (6) | 0 (2) | 91 (6) | 34 (3) |
| Mine | Character | 41 | 29 (41) | 29 | 0 | 25 | 10% | 2.7 | 37 (6) | 23 (19) | 40 (12) | 19 (21) | 46 (16) |
| Mine | Clean-up | 7 | 61 (7) | 0 | 61 | 73 | 71% | 5.0 | 0 (1) | 85 (4) | 0 (2) | 133 (4) | 0 (3) |
| Mine | Fast Hammer | 7 | 0 (7) | 0 | 0 | 55 | 43% | 3.2 | - | 0 (3) | 0 (4) | 0 (2) | 0 (5) |
| Mine | Hammer | 23 | 41 (23) | 13 | 28 | 30 | 17% | 2.8 | 40 (4) | 54 (10) | 22 (9) | 37 (13) | 46 (10) |
| Mine | Holder | 11 | 59 (11) | 14 | 45 | 13 | 64% | 3.8 | 0 (1) | 62 (8) | 81 (2) | 90 (5) | 35 (6) |
| Mine | Shooter | 2 | 281 (2) | 50 | 231 | 0 | 0% | 2.5 | 100 (1) | 462 (1) | - | 281 (2) | - |
| Mine | War machine | 18 | 35 (18) | 35 | 0 | 42 | 0% | 1.2 | 33 (7) | 69 (7) | 0 (4) | 0 (3) | 42 (15) |
| Mine | Wizard | 7 | 7 (7) | 7 | 0 | 33 | 14% | 2.3 | 26 (2) | - | 0 (3) | 0 (2) | 18 (3) |
| Opponent | Chaff | 14 | 68 (14) | 0 | 68 | 47 | 50% | 2.3 | 103 (5) | 43 (3) | 43 (6) | 99 (6) | 44 (8) |
| Opponent | Character | 26 | 59 (26) | 59 | 0 | 11 | 27% | 2.6 | 37 (6) | 67 (9) | 87 (7) | 70 (10) | 57 (12) |
| Opponent | Clean-up | 12 | 61 (12) | 7 | 55 | 24 | 83% | 3.0 | 15 (5) | 83 (6) | 156 (1) | 91 (9) | 0 (3) |
| Opponent | Fast | 1 | 187 (1) | 187 | 0 | 0 | 0% | 1.0 | - | 187 (1) | - | 187 (1) | - |
| Opponent | Fast Hammer | 6 | 7 (6) | 1 | 7 | 65 | 33% | 1.8 | 0 (1) | 19 (2) | 0 (3) | 54 (1) | 1 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 17 | 41 (17) | 36 | 5 | 17 | 24% | 2.8 | 0 (3) | 49 (12) | 27 (2) | 6 (7) | 68 (10) |
| Opponent | Holder | 14 | 151 (14) | 0 | 151 | 16 | 71% | 2.5 | 158 (4) | 131 (8) | 207 (2) | 178 (7) | 113 (7) |
| Opponent | Shooter | 11 | 22 (11) | 0 | 22 | 53 | 18% | 2.2 | 0 (3) | 40 (5) | 0 (3) | 35 (6) | 0 (5) |
| Opponent | War machine | 12 | 4 (12) | 4 | 0 | 65 | 8% | 1.9 | 0 (3) | 0 (3) | 7 (6) | 0 (2) | 5 (10) |
| Opponent | Wizard | 7 | 25 (7) | 25 | 0 | 54 | 29% | 2.4 | 50 (3) | 0 (1) | - | 87 (2) | 0 (2) |

### Charged fights: h6-opp-0333a16-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 86 | 0 | 0.8 | 1.3 | 0 | 17 | -17 | 1 of 3 | 2 of 3 | -52 | +0 |
| Mine | Chaos Dwarfs | 4 | 194 | 367 | 3.8 | 1.1 | 98 | 0 | +98 | 5 of 15 | 13 of 15 | +303 | +83 |
| Mine | Dwarfen Mountain Holds | 2 | 415 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 10 | 195 | 147 | 1.8 | 1.1 | 82 | 3 | +79 | 6 of 18 | 15 of 18 | +126 | +73 |
| Opponent | Chaos Dwarfs | 3 | 99 | 780 | 3.3 | 1.0 | 234 | 0 | +234 | 7 of 10 | 8 of 10 | - | +234 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.5 | 56 | 58 | -2 | 1 of 2 | 2 of 2 | +112 | -115 |
| Opponent | Grand Cathay | 1 | 138 | 592 | 5.0 | 1.4 | 118 | 0 | +118 | 0 of 5 | 4 of 5 | +95 | +124 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 170 | 3.0 | 1.0 | 57 | 18 | +38 | 1 of 3 | 1 of 3 | - | +38 |
| Opponent | Skaven | 2 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 4 | 1 of 4 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 310 | 4.0 | 1.0 | 78 | 18 | +60 | 3 of 4 | 2 of 4 | - | +60 |
| Opponent | Vampire Counts | 1 | 0 | 1003 | 5.0 | 1.0 | 201 | 0 | +201 | 3 of 5 | 3 of 5 | - | +201 |
| **Opponent** | all armies | 10 | 43 | 453 | 3.3 | 1.1 | 137 | 7 | +130 | 17 of 33 | 21 of 33 | +104 | +132 |

### Effective charges: h6-opp-0333a16-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -52) | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 15 | 0 | 0 | 2 (net +210) | 5 (net +74) | 4 (net +41) | 4 (net +128) | 0 | 13% (2 of 15) |
| Opponent | Chaos Dwarfs | 10 | 3 (net +111) | 0 | 0 | 2 (net +579) | 2 (net +128) | 1 (net +230) | 2 | 0% (0 of 8) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +112) | 0 | 1 (net -115) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +190) | 4 (net +100) | 0 | 0 | 0 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Skaven | 4 | 3 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net -72) | 0 | 0 | 1 (net +0) | 0 | 1 (net +310) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 5 | 3 (net +303) | 0 | 1 (net +95) | 0 | 0 | 1 (net +0) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: h6-opp-0333a16-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 137 | 343 | -52 | 317 | 52 | +265 | +193.1 |
| Mine | Effective (55-75%) | 3 | 254 | 201 | +140 | 179 | 0 | +179 | +70.4 |
| Mine | 76-89% | 6 | 315 | 171 | +62 | 90 | 7 | +83 | +26.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 252 | 131 | +128 | 169 | 44 | +125 | +49.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 480 | 76 | +41 | 44 | 0 | +44 | +9.2 |
| Mine | All fights | 18 | 318 | 155 | +79 | 125 | 15 | +110 | +34.6 |
| Opponent | Long shot (under 50%) | 11 | 315 | 282 | +106 | 115 | 22 | +93 | +29.5 |
| Opponent | Effective (55-75%) | 2 | 230 | 95 | +142 | 142 | 0 | +142 | +62.1 |
| Opponent | 76-89% | 8 | 364 | 158 | +209 | 209 | 2 | +206 | +56.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 232 | 221 | +85 | 172 | 39 | +133 | +57.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 410 | 84 | +128 | 148 | 0 | +148 | +36.3 |
| Opponent | No odds | 5 | 361 | 190 | +96 | 122 | 21 | +101 | +27.9 |
| Opponent | All fights | 33 | 322 | 205 | +130 | 151 | 17 | +134 | +41.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-opp-0333a16-p1 | move | 58 | 18 (31%) | 12 (21%) | 8 (14%) | 32 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Opponent | L0510 |

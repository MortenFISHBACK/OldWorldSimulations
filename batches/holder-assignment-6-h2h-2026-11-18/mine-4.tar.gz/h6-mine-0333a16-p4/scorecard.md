# Doctrine scorecard: h6-mine-0333a16-p4

### Scorecard: h6-mine-0333a16-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 8 | 3 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 6 | 1 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 3 | 3 | 3 | 3 | 1 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 370 |
| L0316 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | yes | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 450 |
| L0333 | 3 | 1 | Opponent | yes | 3 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 17% | 3.7 | 4.0 | 0.8 | 2.0 | 0.3 | 0.0 | 0.0 | 193.3 |
| **Average** | | | Opponent | 33% | 1.5 | 2.5 | 2.7 | 2.3 | 0.7 | 0.0 | 0.0 | 101.7 |

### KPIs: h6-mine-0333a16-p4

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 6 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 39% (11 of 28) | 0% (0 of 28) | 20% (11 of 56) |
| Winner chose to follow up after the loser gave ground |  | 80% (8 of 10); on the table 80% | 100% (4 of 4); on the table 100% | 86% (12 of 14); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 86% (12 of 14); on the table 86% | 90% (9 of 10); on the table 90% | 88% (21 of 24); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 33% (40 of 120) | 8% (1 of 12) | 31% (41 of 132) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (40 of 88) | 11% (1 of 9) | 42% (41 of 97) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (3 of 4) | 71% (15 of 21) | 72% (18 of 25) |
| Points that never fought | lower | 34% (3999 of 11596) | 47% (5632 of 11998) | 41% (9631 of 23594) |
|   infantry points that never fought | lower | 40% (1488 of 3676) | 83% (2011 of 2410) | 57% (3499 of 6086) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (22 of 38) | 47% (21 of 45) | 52% (43 of 83) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 2.5 uses a game | 50% (2 of 4); 1.8 uses a game | 70% (7 of 10); 2.2 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game | 55% (6 of 11); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (3981 of 8400) | 41% (4422 of 10814) | 44% (8403 of 19214) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.5 (34%) | 0.8 (45%) | 5.3 (35%) |
| MARCHED: its unit marched | 2.5 (19%) | 0.5 (27%) | 3.0 (20%) |
| CHARGED: its unit charged | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 1.8 (14%) | 0.0 (0%) | 1.8 (12%) |
| GONE: slain | 2.2 (16%) | 0.5 (27%) | 2.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (10%) | 0.0 (0%) | 1.3 (9%) |
| STUPIDITY: Stupidity | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 5.8 | 3.5 | 6.8 | 0.8 |
| not cast | 7.2 | 4.5 | 15.2 | 13.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.2 (4%) | 5.3 (35%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.0 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (2%) | 1.0 (22%) | 1.8 (12%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.8 (12%) | 0.5 (11%) | 2.7 (18%) | 2.8 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.7 (15%) | 1.3 (9%) | 0.7 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (7%) | 0.3 (2%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.5 (77%) | 1.8 (41%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.8 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.8 a game | 1.2 a game | 2.0 a game |
| stood (cast and not dispelled) | 65% (11 of 17) | 0% (0 of 2) | 58% (11 of 19) |
| the unit moved after it | 82% (9 of 11) | - | 82% (9 of 11) |
| it charged on its next turn | 9% (1 of 11) | - | 9% (1 of 11) |
| the enemy charged it first | 45% (5 of 11) | - | 45% (5 of 11) |
| it fought by the end of its next turn | 9% (1 of 11) | - | 9% (1 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (1 of 11) | - | 9% (1 of 11) |
| none of these (no charge, no fight, no charge escaped) | 45% (5 of 11) | - | 45% (5 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 75% (62 of 83) | 46% (55 of 120) | 58% (117 of 203) |
|   cavalry | - | 52% (14 of 27) | 52% (14 of 27) |
|   character | - | 32% (10 of 31) | 32% (10 of 31) |
|   chariot | 75% (18 of 24) | 50% (2 of 4) | 71% (20 of 28) |
|   infantry | 80% (20 of 25) | 51% (18 of 35) | 63% (38 of 60) |
|   war machine | 71% (24 of 34) | 48% (11 of 23) | 61% (35 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (10%) | 3.3 (31%) | 3.7 (26%) |
| CHARGED: it charged | 0.2 (5%) | 1.7 (15%) | 1.8 (13%) |
| FLEEING: it fled or was fleeing | 0.3 (10%) | 0.2 (2%) | 0.5 (3%) |
| IN COMBAT: it fought this turn or the last | 0.5 (14%) | 0.0 (0%) | 0.5 (3%) |
| MOVED: a war machine that moved | 0.7 (19%) | 1.3 (12%) | 2.0 (14%) |
| NO TARGET IN RANGE | 0.3 (10%) | 2.5 (23%) | 2.8 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (5%) | 0.3 (3%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (19%) | 1.0 (9%) | 1.7 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| OTHER BAR | 0.3 (10%) | 0.3 (3%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.5 | 0.2 | 93% | 3.0 pts | 7 pts |
| character | 1.8 | 0.5 | 73% | 1.5 pts | 3 pts |
| chariot | 3.3 | 3.8 | 45% | 42.2 pts | 141 pts |
| infantry | 8.8 | 2.3 | 77% | 3.3 pts | 29 pts |
| war machine | 5.8 | 4.3 | 60% | 10.2 pts | 59 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 4.7 | 3.3 |
| Charges that made contact a game | 1.2 | 3.8 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.17 contact (41 units) | 0.60 declared, 0.49 contact (47 units) | 0.45 declared, 0.34 contact (88 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (3 of 9) | - | 100% (1 of 1) | 40% (4 of 10) |
| Character in a unit | 86% (6 of 7) | 40% (2 of 5) | - | 67% (8 of 12) |
| Character on its own | 100% (3 of 3) | 75% (6 of 8) | 22% (2 of 9) | 55% (11 of 20) |
| Chariot | 100% (1 of 1) | 0% (0 of 4) | - | 20% (1 of 5) |
| Infantry | 50% (2 of 4) | 27% (4 of 15) | - | 32% (6 of 19) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monstrous | 100% (3 of 3) | - | - | 100% (3 of 3) |
| War Machines | 83% (5 of 6) | 50% (1 of 2) | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (10 of 12); on the table 83% | 29% (30 of 102) | 23% | 59% (13 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 56% (10 of 18) | 56% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 44% | 43% (3 of 7) | 50% (1 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 50% (1 of 2); on the table 50% | - | 56% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (6 of 6); on the table 100% | - | 29% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 69% | 60% (6 of 10) | 50% (1 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-mine-0333a16-p4, 6 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (9) | 33% (1) | 45% (10) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.17 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.17 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.17 | 0.50 |

### Quality by phase: h6-mine-0333a16-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 38% (10 of 26) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (25 of 61) | 45% (9 of 20) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 76% (13 of 17) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 69% (9 of 13) | 67% (10 of 15) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 193.3 | 101.7 |
| Movement | Fights charged into per game | 1.0 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 8 of 21, net +99 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 4 of 21, net +216 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 3 of 21, net +27 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +0 | 3 of 21, net +141 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (15 of 38) | 50% (29 of 58) |
| Shooting | Points destroyed by shooting units | 98.3 | 0.0 |
| Shooting | War machine shots | 4.0 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 8% (2 of 24) | 27% (3 of 11) |
| Shooting | Points destroyed by war machines | 39.0 | 0.0 |
| Magic | Magic missiles cast | 3.5 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (6 of 21) | - |
| Magic | Wounds caused by magic missiles | 8.3 | 2.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 90.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.5 / 0.0 | 1.8 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 168.2 | 354.3 |
| Combat | Points run down | 0.0 | 36.8 |
| Combat | Net points per charged fight, damage counted | +77 | +71 |
| Combat | Net per 100 charger points, damage counted | +32.4 | +22.4 |
| Combat | First round won (charged fights) | 100% | 61% |
| Combat | Net points per charged fight | +61 | +109 |
| Combat | Net points per supported fight / lone fight | +0 / +73 | - / +109 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 8 of 23 |
| Game | Points lost | 538.2 | 460.3 |
| Game | VP from objectives | 681.7 | 700.0 |
| Game | Lone holders (player turns) | 3.7 | 1.5 |

- Mine won / drew / lost: 2 / 2 / 2 of 6 ended games (of 6); mean margin (Mine - Opponent) -144 VP
- The side that went first won 1 of 4 games with a winner
- Points traded per game (both sides' losses): 998
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-mine-0333a16-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +51.1 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 61.7 | - | - | - | - |
| BACKUP TARGETS | 0.2 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.5 | -34.1 | 22.8 | 130.3 |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | -190.1 | 53.7 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 41.8 | 0.0 |
| CANNON PLANNED TARGET | 3.2 | +46.0 | 0.0 | 98.3 | 1.3 | +13.4 | 0.0 | 33.3 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.2 | +0.0 | 84.2 | 0.0 | - | - | - | - |
| CAST JOB | 0.8 | +23.2 | 129.8 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +61.4 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +32.0 | 0.0 | 14.2 | 1.2 | +45.3 | 0.0 | 6.3 |
| CHAFF PASSED | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.8 | -136.2 | 0.0 | 37.0 | 4.2 | -217.0 | 0.0 | 158.3 |
| CHARGE NOT DECLARED | - | - | - | - | 1.3 | +0.0 | 109.7 | 15.5 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 130.0 | 0.0 | 2.3 | +0.0 | 185.5 | 50.5 |
| CHARGER SLAIN LOST | 0.3 | -9.2 | 0.0 | 0.0 | 0.3 | -0.7 | 18.3 | 46.2 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 19.2 |
| CHEAPEST HOLDER | - | - | - | - | 0.8 | -94.6 | 32.0 | 66.3 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 53.7 | 28.3 |
| CONVEYANCE SEARCH | 2.2 | +442.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.5 | -1163.7 | 0.0 | 70.3 | 3.2 | -149.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +62.8 | 0.0 | 0.0 | 7.8 | +10.1 | 0.0 | 13.2 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +18.8 | 38.3 | 17.3 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +2.9 | 22.8 | 0.0 | 2.5 | +0.4 | 157.0 | 63.5 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 14.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 6.2 | +89.0 | 0.0 | 22.2 | 17.5 | +244.8 | 0.0 | 109.8 |
| FEATURE BUFFS | 5.8 | +232.1 | 0.0 | 8.7 | 1.2 | +41.4 | 0.0 | 38.3 |
| FIGHT TO THE END | 0.5 | +1.0 | 22.8 | 0.0 | 1.8 | +89.3 | 138.7 | 17.3 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 42.7 | +3603.7 | 484.7 | 312.3 | 47.5 | +3453.3 | 310.2 | 664.0 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 80.3 | 5.7 | +0.0 | 0.0 | 10.5 |
| FOCUS FIRE | 0.2 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.8 | +44.7 | 0.0 | 0.0 | 0.5 | +147.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +71.6 | 107.0 | 0.0 | 4.3 | +457.2 | 268.3 | 112.2 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.2 | -18.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -10.8 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.2 | +3.9 | 0.0 | 33.2 |
| GROUND FLIERS | 0.2 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.8 | +63.2 | 133.2 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 1.7 | +52.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.7 | +0.0 | 0.0 | 52.8 | 2.7 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.2 | +3.3 | 0.0 | 0.0 | 0.3 | +9.0 | 8.7 | 0.0 |
| HIS CHARGE LIST | 3.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.2 | +0.0 | 0.0 | 8.7 | 4.8 | +0.0 | 0.0 | 46.2 |
| HIS MOVE AND SHOT | 0.8 | -18.0 | 0.0 | 28.0 | 2.3 | -141.2 | 0.0 | 152.3 |
| HIS RANDOM MOVE | 5.0 | +0.0 | 0.0 | 119.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.7 | +484.5 | 0.0 | 118.0 | 20.8 | +1142.1 | 0.0 | 273.5 |
| HIS TURN DENIED | 0.2 | +0.8 | 0.0 | 0.0 | 2.5 | +92.5 | 151.5 | 74.0 |
| HOLD ODDS | 17.8 | +0.0 | 0.0 | 33.2 | - | - | - | - |
| HOLDER ASSIGNMENT | 14.7 | +1568.9 | 0.0 | 15.8 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.7 | +256.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -12.5 | 107.0 | 0.0 | 3.8 | -240.2 | 268.3 | 96.7 |
| HORN WORTH | - | - | - | - | 0.2 | +3.3 | 0.0 | 84.2 |
| HUNT KEPT | - | - | - | - | 0.2 | +0.0 | 0.0 | 17.3 |
| HUNT RESULT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +60.6 | 0.0 | 17.3 |
| IDLE COST | 1.7 | -8.9 | 0.0 | 14.2 | 9.7 | -163.4 | 0.0 | 13.2 |
| KEEP FALLS | 0.2 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.2 | +34.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 150.7 | 0.0 | 5.3 | +0.0 | 53.7 | 92.2 |
| LONE WIZARD KEPT IN | 1.7 | +108.3 | 0.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +23.4 | 0.0 | 0.0 | 1.0 | +20.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +60.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +20.1 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 33.2 |
| MARCH CHECK | 1.3 | +104.1 | 0.0 | 0.0 | 1.2 | +70.4 | 0.0 | 33.2 |
| MARCH OVER CASTS | 0.5 | +1.0 | 0.0 | 0.0 | 0.2 | +16.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 8.0 | +108.1 | 0.0 | 31.5 | 6.5 | +53.7 | 0.0 | 75.8 |
| MISSILES IN THE MOVE | 7.2 | +439.4 | 0.0 | 27.7 | 1.8 | +15.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +316.0 | 0.0 | 27.7 | 2.3 | +18.1 | 0.0 | 33.2 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.2 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.8 | -93.5 | 0.0 | 80.8 | - | - | - | - |
| MOVE SPELL SPOT | 1.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +222.0 | 0.0 | 8.7 | 4.3 | +693.0 | 0.0 | 46.2 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | 0.2 | +1.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +257.6 | 0.0 | 0.0 | 5.3 | +256.3 | 0.0 | 22.8 |
| NEXT CHARGE BY LIST | 5.0 | -333.9 | 17.3 | 8.7 | 6.0 | -293.1 | 0.0 | 233.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 10.0 | -558.6 | 0.0 | 33.2 |
| NO DOUBLE ROUNDS | 1.2 | -45.3 | 107.0 | 0.0 | 3.8 | -108.0 | 254.2 | 107.2 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 14.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.5 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -2.5 | 0.0 | 0.0 | 0.7 | -5.7 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 6.2 | +0.0 | 0.0 | 40.2 | 1.7 | +0.0 | 0.0 | 5.0 |
| ONE FIGHT FORMULA | 5.5 | -63.4 | 0.0 | 8.7 | 6.5 | -182.3 | 0.0 | 65.3 |
| ONE OBJECTIVE FORMULA | 6.7 | +76.4 | 0.0 | 15.8 | 4.5 | +14.0 | 0.0 | 19.2 |
| ONE TARGET A SHOOTER | 12.3 | +232.6 | 0.0 | 98.5 | 19.7 | +759.2 | 0.0 | 374.5 |
| OPENS UP | - | - | - | - | 0.2 | +10.1 | 14.2 | 0.0 |
| OVERRUNS AWAY | 0.2 | +3.3 | 22.8 | 0.0 | 0.3 | +74.8 | 42.5 | 0.0 |
| PATHS CROSS | 2.7 | +91.2 | 0.0 | 0.0 | 5.3 | +300.9 | 0.0 | 23.8 |
| PIVOT GUARDS FLANK | 0.2 | -3.2 | 0.0 | 8.7 | 0.2 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 37.2 | +480.1 | 437.3 | 568.2 | 41.3 | +198.2 | 147.2 | 510.5 |
| QUARTER ODDS | 8.5 | +616.8 | 169.7 | 59.5 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +40.4 | 0.0 | 85.0 | 3.5 | +20.8 | 0.0 | 56.7 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.5 | 0.0 | 14.2 | 0.5 | -23.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +245.4 | 0.0 | 0.0 | 5.2 | +241.3 | 0.0 | 13.7 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | -19.9 | 32.0 | 168.3 |
| REFORMS TO MEET IT | 0.5 | -4.0 | 0.0 | 0.0 | 1.0 | -107.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.8 | +0.0 | 0.0 | 53.7 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +56.0 | 0.0 | 49.3 |
| RISK BY ARC | 0.8 | +12.3 | 22.8 | 0.0 | 2.2 | -63.1 | 218.0 | 101.7 |
| RISK BY HIS FIGURE | 16.5 | -116.4 | 0.0 | 177.2 | 14.8 | -130.9 | 0.0 | 225.5 |
| RUN DOWN | 0.8 | -5.7 | 22.8 | 0.0 | 3.2 | -25.4 | 197.5 | 96.7 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -0.6 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 4.2 | +194.2 | 0.0 | 15.8 | 8.7 | +285.5 | 0.0 | 150.8 |
| SELF MOVE SPELL | - | - | - | - | 1.0 | +55.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.2 | +9.0 | 0.0 | 45.8 |
| SET-UP ANY TARGET | 0.5 | +75.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +258.0 | 198.5 | 14.2 | 0.5 | +1.2 | 0.0 | 51.2 |
| SHOT OR CHARGE | 0.3 | -1.2 | 0.0 | 0.0 | 0.3 | -4.0 | 27.7 | 0.0 |
| SHOT RISK POINTS | 8.8 | +70.4 | 0.0 | 59.5 | 16.2 | +81.0 | 0.0 | 402.2 |
| SHOTS IN THE MOVE | 11.2 | +440.9 | 0.0 | 98.3 | 11.5 | +218.9 | 0.0 | 101.8 |
| SPELL SETS UP CHARGE | 0.5 | +75.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +9.6 | 0.0 | 59.2 | 2.2 | +25.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.2 | -1.9 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.2 | -0.4 | 0.0 | 0.0 | 0.2 | -1.2 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.5 | +0.0 | 0.0 | 33.2 |
| STANDS STILL | 18.2 | +0.0 | 377.7 | 163.5 | 9.7 | +0.0 | 41.8 | 147.5 |
| STAY WORTH | 8.5 | +50.0 | 48.8 | 0.0 | 12.3 | +101.4 | 28.3 | 117.2 |
| STOPS | - | - | - | - | 0.2 | +9.8 | 0.0 | 17.3 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.8 | +0.0 | 86.0 | 0.0 | 1.5 | +0.0 | 23.3 | 55.5 |
| SURE REACH TOGETHER | - | - | - | - | 0.8 | +3.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.5 | +0.0 | 0.0 | 0.0 | 5.5 | +0.0 | 0.0 | 23.8 |
| THE PROMISE ADDS | 0.3 | -9.8 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.2 | +6.2 | 22.8 | 0.0 | 0.8 | +94.4 | 93.5 | 33.2 |
| TIME ON OUR SIDE | 24.5 | +415.7 | 0.0 | 33.2 | 6.8 | +131.6 | 0.0 | 13.3 |
| WAITS AGAIN | 1.5 | +0.0 | 0.0 | 8.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +54.1 | 84.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 84.2 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +20.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | -3.8 | 84.2 | 0.0 | 0.3 | +3.5 | 0.0 | 5.0 |
| WHOLE FIGHT GAIN | 0.3 | +62.4 | 0.0 | 0.0 | - | - | - | - |
| WIDER SPREAD | 0.8 | -0.6 | 107.0 | 0.0 | 2.0 | -16.9 | 147.3 | 46.2 |
| WOUNDS ON THE RANKS | 2.8 | +80.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: h6-mine-0333a16-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 88 | 88 | 81 | 13.50 | +4537 | +56.0 |
| SEARCH SPOT | 77 | 77 | 69 | 11.50 | +2879 | +41.7 |
| HIS SHOT LIST | 219 | 219 | 66 | 11.00 | +1201 | +18.2 |
| DEPLOY BY FIGURES | 97 | 97 | 64 | 10.67 | +892 | +13.9 |
| ONE TARGET A SHOOTER | 192 | 192 | 62 | 10.33 | +533 | +8.6 |
| LEGAL CHARGES ONLY | 60 | 60 | 60 | 10.00 | +0 | +0.0 |
| FIVE ACTION | 541 | 541 | 49 | 8.17 | +1216 | +24.8 |
| PATHS CROSS | 48 | 48 | 48 | 8.00 | +2353 | +49.0 |
| SHOT RISK POINTS | 150 | 150 | 30 | 5.00 | +826 | +27.5 |
| TIME ON OUR SIDE | 188 | 157 | 28 | 4.67 | +237 | +8.5 |
| MAX FOR POSITIONING | 87 | 84 | 20 | 3.33 | +40 | +2.0 |
| MOVE TO CHARGE COMPUTED | 42 | 42 | 20 | 3.33 | +1696 | +84.8 |
| FOUR ROUNDS | 34 | 34 | 18 | 3.00 | +746 | +41.5 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 18 | 3.00 | +367 | +20.4 |
| COVER ONCE | 76 | 55 | 17 | 2.83 | +270 | +15.9 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 2.67 | +0 | +0.0 |
| REDIRECT COUNTER | 49 | 39 | 16 | 2.67 | +1231 | +77.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 2.33 | +0 | +0.0 |
| MANOEUVRE | 16 | 16 | 13 | 2.17 | +268 | +20.6 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 2.00 | +770 | +64.2 |
| MISSILES IN THE MOVE | 54 | 34 | 12 | 2.00 | +470 | +39.1 |
| NEXT OBJECTIVE NEARER | 60 | 60 | 11 | 1.83 | +89 | +8.1 |
| FEATURE BUFFS | 42 | 42 | 10 | 1.67 | +349 | +34.9 |
| MARCH CHECK | 15 | 15 | 10 | 1.67 | +259 | +25.9 |
| RESERVE FALL BACK | 10 | 10 | 10 | 1.67 | +336 | +33.6 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 1.50 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 9 | 1.50 | +669 | +74.3 |
| CANNON PLANNED TARGET | 27 | 27 | 8 | 1.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 1.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 1.33 | -1572 | -196.5 |
| FALLS SHORT | 142 | 118 | 8 | 1.33 | +6 | +0.8 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 1.33 | +1155 | +144.4 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 136 | 113 | 8 | 1.33 | +100 | +12.5 |
| CHAFF IN THE MOVE | 12 | 12 | 7 | 1.17 | +31 | +4.4 |
| LANE BY FIGURES | 7 | 7 | 7 | 1.17 | +209 | +29.8 |
| RISK BY HIS FIGURE | 188 | 188 | 7 | 1.17 | +222 | +31.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 1.00 | +0 | +0.0 |
| IDLE COST | 68 | 54 | 6 | 1.00 | +88 | +14.7 |
| NEXT CHARGE BY LIST | 66 | 66 | 6 | 1.00 | +22 | +3.7 |
| OFF BEST | 6 | 6 | 6 | 1.00 | -49 | -8.2 |
| RISK BY ARC | 18 | 18 | 6 | 1.00 | +63 | +10.5 |
| CHAFF PASSED | 5 | 5 | 5 | 0.83 | +0 | +0.0 |
| MISSILES NEXT TURN | 62 | 41 | 5 | 0.83 | +28 | +5.6 |
| NEARER NOT NEEDED | 62 | 59 | 5 | 0.83 | +205 | +41.0 |
| ONE OBJECTIVE FORMULA | 67 | 51 | 5 | 0.83 | +57 | +11.3 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 0.83 | +174 | +34.8 |
| CASTING BLOCK | 6 | 6 | 4 | 0.67 | +119 | +29.8 |
| CHARGE LOSSES | 54 | 54 | 4 | 0.67 | +81 | +20.2 |
| HIS TURN DENIED | 16 | 16 | 4 | 0.67 | +99 | +24.7 |
| QUARTER ODDS | 51 | 51 | 4 | 0.67 | +369 | +92.3 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.67 | +816 | +204.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 4 | 0.67 | +81 | +20.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.50 | -205 | -68.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 0.50 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.50 | +0 | +0.0 |
| GUN MASK | 10 | 10 | 3 | 0.50 | +37 | +12.3 |
| HIS MOVE AND SHOT | 19 | 19 | 3 | 0.50 | +45 | +15.1 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 3 | 0.50 | +118 | +39.5 |
| MARCH BY THE SUM | 3 | 3 | 3 | 0.50 | +125 | +41.7 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.50 | +118 | +39.2 |
| ONE FIGHT FORMULA | 72 | 39 | 3 | 0.50 | +6 | +2.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.33 | +307 | +153.3 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.33 | +15 | +7.6 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.33 | +179 | +89.5 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.33 | -23 | -11.4 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.33 | -0 | -0.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.33 | +2 | +1.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 14 | 14 | 2 | 0.33 | -8 | -3.8 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.33 | +114 | +56.9 |
| CAST JOB | 5 | 5 | 1 | 0.17 | +20 | +19.7 |
| CHARGE NOW FIRST | 16 | 16 | 1 | 0.17 | -69 | -69.4 |
| FALL BACK GOOD ORDER | 21 | 21 | 1 | 0.17 | +1 | +1.0 |
| FIGHT TO THE END | 14 | 14 | 1 | 0.17 | +106 | +106.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.17 | +9 | +9.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.17 | +23 | +23.1 |
| HONEST WORTH | 29 | 29 | 1 | 0.17 | +12 | +11.6 |
| HORN WORTH | 1 | 1 | 1 | 0.17 | +20 | +19.9 |
| KEEP FALLS | 1 | 1 | 1 | 0.17 | +10 | +10.5 |
| SCOUT WAITS | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| STAY WORTH | 125 | 112 | 1 | 0.17 | +5 | +5.3 |
| STOPS | 1 | 1 | 1 | 0.17 | +35 | +35.4 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| WAR ENGINE JOBS | 4 | 4 | 1 | 0.17 | -19 | -18.9 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.17 | +220 | +219.9 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 12 | trace | - | - | - | - |
| CHARACTER GUNS | 4 | 4 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 94 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 26 | 26 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 48 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 48 | 48 | 0 | 0.00 | - | - |
| HOLD ODDS | 107 | 107 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 30 | 30 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 47 | 47 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 471 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 24 | 24 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 7 | 6 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 167 | 167 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 54 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WALK PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: h6-mine-0333a16-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.83 | - | 22.3 |
| CHARGE NOT DECLARED | rule | - | 1.33 | 196.5 |
| PATHS CROSS | rule | 0.17 | 0.67 | 15.1 |
| BEST PRIZE | rule | - | 0.50 | 68.3 |
| JOB FIRST | gate | 0.17 | 0.33 | 10.7 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.17 | 11.4 |
| SUPPORT NARROWED | rule | 0.33 | - | 3.8 |
| AFTERMATH BAND | gate | - | 0.17 | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | - | 14.2 |
| CHARGE NOW FIRST | rule | - | 0.17 | 69.4 |
| FIGHT ORDER BAND | gate | - | 0.17 | 0.7 |
| WAR ENGINE JOBS | rule | 0.17 | - | 18.9 |

### Plans: h6-mine-0333a16-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 50% | 103 | 112 | 109% |
| Mine | move | 26.5 | 92% | 2243 | 0 | 0% |
| Mine | shoot | 9.3 | 54% | 602 | 368 | 61% |
| Mine | support | 0.3 | 50% | 0 | 0 | - |
| Opponent | charge | 3.0 | 50% | 681 | 169 | 25% |
| Opponent | join | 0.5 | 100% | 28 | 0 | 0% |
| Opponent | move | 35.0 | 95% | 2061 | 0 | 0% |
| Opponent | shoot | 2.5 | 27% | 90 | 30 | 33% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Packages: hunt the guns, h6-mine-0333a16-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 56 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 1.0 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 338 |

### Battle groups: h6-mine-0333a16-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 17% | 67% | 0% | - | 33% | 0% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 5.2 | 19% | 83% | 17% | 0% | 0% | 0% | 0% | 80% | 20% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-mine-0333a16-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 32 | 75% | 2.0 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Mine | Character | 24 | 15 (24) | 15 | 0 | 47 | 12% | 2.3 | 16 (8) | 32 (8) | 0 (1) | 52 (5) | 11 (12) |
| Mine | Clean-up | 2 | 16 (2) | 0 | 16 | 51 | 100% | - | 32 (1) | 0 (1) | - | 16 (2) | - |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 37 | 50% | 4.2 | 0 (1) | 0 (5) | 40 (4) | 27 (8) | 0 (2) |
| Mine | Hammer | 16 | 52 (16) | 31 | 21 | 18 | 12% | 2.6 | 65 (5) | 55 (8) | 21 (3) | 65 (10) | 30 (6) |
| Mine | Holder | 6 | 106 (6) | 0 | 106 | 17 | 67% | 5.5 | 179 (1) | 119 (4) | 0 (1) | 112 (4) | 93 (2) |
| Mine | Shooter | 4 | 173 (4) | 0 | 173 | 0 | 0% | 1.8 | - | 173 (4) | - | 69 (2) | 277 (2) |
| Mine | War machine | 8 | 29 (8) | 29 | 0 | 50 | 0% | 1.2 | 29 (8) | - | - | 0 (2) | 35 (6) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 0 | 50% | 4.3 | 0 (5) | 0 (1) | - | 0 (1) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 13 | 14 (13) | 0 | 14 | 40 | 38% | 3.9 | 0 (6) | 33 (3) | 19 (4) | 16 (11) | 0 (2) |
| Opponent | Character | 15 | 58 (15) | 58 | 0 | 23 | 20% | 1.9 | 44 (2) | 71 (6) | 57 (6) | 42 (9) | 89 (5) |
| Opponent | Clean-up | 3 | 71 (3) | 0 | 71 | 44 | 67% | 2.0 | 0 (1) | 84 (2) | - | 88 (2) | 28 (1) |
| Opponent | Fast Hammer | 8 | 41 (8) | 0 | 41 | 40 | 50% | 3.0 | 12 (3) | 175 (2) | 0 (3) | 49 (6) | 0 (2) |
| Opponent | Hammer | 9 | 20 (9) | 19 | 2 | 24 | 56% | 4.0 | 0 (1) | 25 (5) | 26 (3) | 20 (4) | 21 (5) |
| Opponent | Holder | 3 | 102 (3) | 17 | 85 | 0 | 67% | 6.0 | 73 (2) | 140 (1) | - | 102 (3) | - |
| Opponent | Shooter | 4 | 72 (4) | 0 | 72 | 0 | 0% | 1.8 | 33 (2) | 109 (2) | - | 36 (2) | 117 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 25 | 0% | 2.8 | 0 (2) | 0 (1) | 0 (1) | - | 0 (4) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: h6-mine-0333a16-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 136 | 0 | 1.0 | 1.2 | 0 | 0 | +0 | 2 of 4 | 4 of 4 | +0 | +0 |
| Mine | Chaos Dwarfs | 2 | 412 | 252 | 1.0 | 1.0 | 252 | 70 | +182 | 1 of 2 | 2 of 2 | - | +182 |
| **Mine** | all armies | 6 | 228 | 84 | 1.0 | 1.2 | 84 | 23 | +61 | 3 of 6 | 6 of 6 | +0 | +73 |
| Opponent | High Elf Realms | 1 | 0 | 355 | 4.0 | 1.0 | 89 | 0 | +89 | 2 of 4 | 2 of 4 | - | +89 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 462 | 3.5 | 1.0 | 132 | 0 | +132 | 0 of 7 | 7 of 7 | - | +132 |
| Opponent | Warriors of Chaos | 2 | 0 | 871 | 5.0 | 1.0 | 174 | 40 | +134 | 6 of 10 | 4 of 10 | - | +134 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 52 | -52 | 0 of 2 | 1 of 2 | - | -52 |
| **Opponent** | all armies | 6 | 0 | 503 | 3.8 | 1.0 | 131 | 22 | +109 | 8 of 23 | 14 of 23 | - | +109 |

### Effective charges: h6-mine-0333a16-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 1 (net +365) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 4 | 1 (net +355) | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +85) | 0 | 1 (net +230) | 2 (net +152) | 1 (net +81) | 1 (net +170) | 1 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 10 | 5 (net +91) | 0 | 2 (net +318) | 1 (net +0) | 0 | 2 (net +127) | 0 | 20% (2 of 10) |
| Opponent | Wood Elf Realms | 2 | 1 (net -104) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: h6-mine-0333a16-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 84 | 80 | +0 | 40 | 0 | +40 | +47.6 |
| Mine | 76-89% | 1 | 310 | 405 | +365 | 505 | 184 | +321 | +103.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 252 | 214 | +0 | 54 | 20 | +33 | +13.2 |
| Mine | No odds | 1 | 272 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 6 | 237 | 216 | +61 | 118 | 41 | +77 | +32.4 |
| Opponent | Long shot (under 50%) | 8 | 304 | 391 | +99 | 175 | 107 | +68 | +22.2 |
| Opponent | Effective (55-75%) | 4 | 349 | 240 | +216 | 253 | 140 | +113 | +32.3 |
| Opponent | 76-89% | 3 | 261 | 93 | +102 | 102 | 5 | +97 | +37.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 336 | 141 | +141 | 141 | 68 | +73 | +21.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 334 | 67 | +27 | 52 | 25 | +27 | +8.1 |
| Opponent | No odds | 2 | 340 | 96 | +26 | 26 | 0 | +26 | +7.6 |
| Opponent | All fights | 23 | 318 | 225 | +109 | 145 | 74 | +71 | +22.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-mine-0333a16-p4 | move | 46 | 10 (22%) | 8 (17%) | 2 (4%) | 34 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

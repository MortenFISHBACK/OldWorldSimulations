# Doctrine scorecard: h6-mine-0333a16-p3

### Scorecard: h6-mine-0333a16-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 6 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 3 | 1 | 4 | 1 | 0 | 0 | 255 |
| L0211 | 1 | 1 | Opponent | yes | 17 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Opponent | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 5 | - | 1 | 0 | 0 | 0 | 0 | 840 |
| L0330 | 6 | 1 | Opponent | no | 15 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 17 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 138 |
| L0518 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 6 | 4 | 0 | 1 | 0 | 0 | 0 | 472 |
| L0534 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 500 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 115 |
| L0621 | 3 | 1 | Opponent | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 500 |
| **Average** | | | Mine | 11% | 3.2 | 2.6 | 1.3 | 1.6 | 0.1 | 0.0 | 0.0 | 209.1 |
| **Average** | | | Opponent | 11% | 8.4 | 2.4 | 1.9 | 1.5 | 0.3 | 0.0 | 0.0 | 128.2 |

### KPIs: h6-mine-0333a16-p3

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (23 of 49) | 9% (5 of 54) | 27% (28 of 103) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | 89% (8 of 9); on the table 89% | 88% (14 of 16); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 100% | 40% (2 of 5); on the table 80% | 50% (4 of 8); on the table 88% |
| Winner chose to pursue after the loser fled |  | 75% (3 of 4); on the table 75% | 33% (1 of 3); on the table 33% | 57% (4 of 7); on the table 57% |
| Winner chose to follow up or pursue (all three) |  | 79% (11 of 14); on the table 86% | 65% (11 of 17); on the table 76% | 71% (22 of 31); on the table 81% |
| Magic missiles tried each own turn | 50%+ | 49% (68 of 138) | 36% (24 of 66) | 45% (92 of 204) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (68 of 126) | 42% (24 of 57) | 50% (92 of 183) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 36% (4 of 11) | 47% (9 of 19) |
| Points that never fought | lower | 59% (12615 of 21564) | 57% (12542 of 21994) | 58% (25157 of 43558) |
|   infantry points that never fought | lower | 62% (3987 of 6480) | 62% (1996 of 3231) | 62% (5983 of 9711) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (41 of 78) | 53% (44 of 83) | 53% (85 of 161) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.0 uses a game | 89% (8 of 9); 2.8 uses a game | 93% (14 of 15); 2.4 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.7 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.5 uses a game | 20% (1 of 5); 0.1 uses a game | 54% (7 of 13); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (7969 of 16262) | 50% (9855 of 19889) | 49% (17824 of 36151) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.6 (57%) | 0.8 (21%) | 4.5 (44%) |
| MARCHED: its unit marched | 1.3 (20%) | 1.3 (33%) | 2.5 (25%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.6 (10%) | 0.5 (12%) | 1.1 (11%) |
| REAR RANK: in a rear rank | 0.4 (6%) | 0.3 (7%) | 0.6 (6%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| GONE: slain | 0.5 (7%) | 0.2 (5%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 2.0 | 1.7 | 8.4 | 0.4 | 1.4 |
| not cast | 3.0 | 4.7 | 2.1 | 10.2 | 1.3 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.1 (44%) | 0.0 (0%) | 4.5 (44%) | 0.4 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (25%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.2 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.5 (18%) | 0.1 (2%) | 0.0 (0%) | 1.1 (11%) | 0.1 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.1 (23%) | 0.0 (0%) | 0.6 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.2 (6%) | 0.0 (0%) | 0.2 (9%) | 0.6 (6%) | 0.0 (0%) | 0.6 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (8%) | 0.0 (0%) | 0.0 (0%) | 0.4 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (76%) | 0.9 (19%) | 1.8 (87%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.2 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.6 a game | 1.2 a game |
| stood (cast and not dispelled) | 55% (11 of 20) | 0% (0 of 1) | 52% (11 of 21) |
| the unit moved after it | 73% (8 of 11) | - | 73% (8 of 11) |
| it charged on its next turn | 0% (0 of 11) | - | 0% (0 of 11) |
| the enemy charged it first | 18% (2 of 11) | - | 18% (2 of 11) |
| it fought by the end of its next turn | 18% (2 of 11) | - | 18% (2 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (1 of 11) | - | 9% (1 of 11) |
| none of these (no charge, no fight, no charge escaped) | 73% (8 of 11) | - | 73% (8 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (220 of 314) | 52% (97 of 188) | 63% (317 of 502) |
|   cavalry | 61% (11 of 18) | 44% (7 of 16) | 53% (18 of 34) |
|   character | 81% (38 of 47) | 34% (13 of 38) | 60% (51 of 85) |
|   chariot | 47% (18 of 38) | 48% (10 of 21) | 47% (28 of 59) |
|   infantry | 63% (40 of 63) | 56% (37 of 66) | 60% (77 of 129) |
|   monster | 100% (6 of 6) | 36% (4 of 11) | 59% (10 of 17) |
|   war machine | 75% (107 of 142) | 72% (26 of 36) | 75% (133 of 178) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (22%) | 2.9 (35%) | 4.8 (29%) |
| CHARGED: it charged | 0.2 (2%) | 1.3 (15%) | 1.5 (9%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.2 (2%) | 0.9 (5%) |
| MOVED: a war machine that moved | 1.5 (18%) | 0.6 (8%) | 2.2 (13%) |
| NO TARGET IN RANGE | 1.8 (21%) | 1.5 (18%) | 3.3 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (13%) | 0.8 (10%) | 1.9 (11%) |
| SHELTERED: the target was sheltered | 0.5 (5%) | 0.6 (8%) | 1.1 (6%) |
| OTHER BAR | 0.5 (6%) | 0.2 (2%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.5 | 77% | 3.4 pts | 7 pts |
| character | 5.4 | 3.0 | 66% | 10.5 pts | 57 pts |
| chariot | 2.5 | 2.6 | 46% | 22.6 pts | 58 pts |
| infantry | 12.2 | 3.5 | 78% | 6.3 pts | 76 pts |
| monster | 0.9 | 0.6 | 60% | 14.3 pts | 13 pts |
| war machine | 12.1 | 11.5 | 59% | 24.9 pts | 301 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.8 | 3.3 | 2.5 |
| Charges that made contact a game | 1.5 | 2.3 | 1.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.17 contact (6 units) | 1.00 declared, 0.50 contact (6 units) | 0.67 declared, 0.33 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.21 contact (72 units) | 0.38 declared, 0.28 contact (79 units) | 0.32 declared, 0.25 contact (151 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 31% (4 of 13) | - | 14% (1 of 7) | 25% (5 of 20) |
| Character in a unit | 81% (17 of 21) | 69% (11 of 16) | 0% (0 of 1) | 74% (28 of 38) |
| Character on its own | 100% (2 of 2) | 88% (7 of 8) | 43% (6 of 14) | 62% (15 of 24) |
| Chariot | 86% (6 of 7) | 75% (6 of 8) | - | 80% (12 of 15) |
| Infantry | 25% (5 of 20) | 20% (3 of 15) | - | 23% (8 of 35) |
| Monster | 40% (2 of 5) | 33% (1 of 3) | - | 38% (3 of 8) |
| Monstrous | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| War Machines | 71% (10 of 14) | 0% (0 of 2) | - | 62% (10 of 16) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | - | 54% (55 of 102) | 79% | 55% (12 of 22) | 100% (6 of 6); 5.5 uses a game | 100% (2 of 2); 2.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (9 of 12); on the table 83% | 36% (13 of 36) | 43% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 54% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | - | 44% (16 of 36) | 63% | 56% (9 of 16) | 75% (3 of 4); 5.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 57% (4 of 7); on the table 57% | 0% (0 of 6) | 39% | 40% (6 of 15) | 100% (3 of 3); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 82% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 4 | 100% (5 of 5); on the table 100% | 58% (7 of 12) | 47% | 61% (17 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 100% | - | 54% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-mine-0333a16-p3, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 39% (7) | 45% (5) | 41% (12) |
| ...free all their last turn and able to turn (per game) | 0.45 | 0.27 | 0.73 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.09 | 0.09 | 0.18 |
| ...with the charger already in that arc before they moved (per game) | 0.45 | 0.00 | 0.45 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.09 | 0.18 | 0.27 |

### Quality by phase: h6-mine-0333a16-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 80% (16 of 20) | 57% (17 of 30) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (72 of 176) | 50% (26 of 52) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 32% (12 of 37) | 33% (5 of 15) |
| Strategy | Lone characters that fought | 57% (8 of 14) | 61% (11 of 18) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.6 | 1.5 |
| Movement | Points that never moved of their own | 209.1 | 128.2 |
| Movement | Fights charged into per game | 1.5 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 16, net -21 | 2 of 21, net -239 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 16, net +395 | 4 of 21, net +40 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 16 | 2 of 21, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 16, net +14 | 5 of 21, net +181 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (37 of 120) | 48% (41 of 85) |
| Shooting | Points destroyed by shooting units | 117.0 | 10.6 |
| Shooting | War machine shots | 9.7 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (41 of 107) | 62% (16 of 26) |
| Shooting | Points destroyed by war machines | 144.9 | 34.1 |
| Magic | Magic missiles cast | 3.0 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (16 of 33) | 33% (5 of 15) |
| Magic | Wounds caused by magic missiles | 7.1 | 2.3 |
| Magic | Wounds caused by other spells | 0.4 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 73.1 | 26.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.1 / 0.7 / 0.3 | 0.7 / 0.8 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 130.5 | 256.1 |
| Combat | Points run down | 42.7 | 25.5 |
| Combat | Net points per charged fight, damage counted | +46 | +77 |
| Combat | Net per 100 charger points, damage counted | +28.4 | +23.5 |
| Combat | First round won (charged fights) | 50% | 72% |
| Combat | Net points per charged fight | +38 | +76 |
| Combat | Net points per supported fight / lone fight | - / +38 | - / +76 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 16 | 11 of 25 |
| Game | Points lost | 427.7 | 602.5 |
| Game | VP from objectives | 581.8 | 762.7 |
| Game | Lone holders (player turns) | 3.2 | 8.4 |

- Mine won / drew / lost: 2 / 5 / 4 of 11 ended games (of 11); mean margin (Mine - Opponent) +52 VP
- The side that went first won 3 of 6 games with a winner
- Points traded per game (both sides' losses): 1030
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-mine-0333a16-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +54.4 | 0.0 | 28.2 | 0.2 | +33.2 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 38.2 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.7 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.5 | 4.7 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -28.5 | 26.3 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +7.7 | 0.0 | 13.6 |
| CANNON PLAN MISSED | 2.4 | +0.0 | 160.4 | 17.3 | 0.5 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.6 | +204.1 | 481.1 | 55.5 | 1.8 | +22.3 | 28.2 | 0.0 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 40.2 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +18.5 | 53.9 | 30.9 | 0.5 | +6.5 | 5.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +36.9 | 37.3 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 35.9 |
| CHAFF IN THE MOVE | 0.6 | +29.5 | 0.0 | 20.5 | 0.8 | +38.2 | 0.0 | 22.4 |
| CHAFF PASSED | 0.3 | -2.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.0 | -200.6 | 0.0 | 171.4 | 5.8 | -328.7 | 0.0 | 207.3 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 15.5 | 0.0 | 0.8 | +0.0 | 59.5 | 9.9 |
| CHARGE NOW FIRST | 0.6 | +0.0 | 15.5 | 0.0 | 1.2 | +0.0 | 160.5 | 27.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.1 | -7.3 | 0.0 | 33.5 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -42.9 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 56.4 | 0.2 | +0.0 | 10.2 | 20.9 |
| CONVEYANCE SEARCH | 1.4 | +203.6 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| COVER ONCE | 6.1 | -400.0 | 0.0 | 43.1 | 3.8 | -169.4 | 0.0 | 94.1 |
| DEFENSIVE FLOOR | 0.1 | -6.9 | 0.0 | 7.4 | - | - | - | - |
| DEPLOY BY FIGURES | 8.5 | +60.6 | 0.0 | 13.6 | 7.3 | +26.4 | 0.0 | 13.2 |
| EDGE GIVE GROUND | 0.1 | +5.9 | 0.0 | 0.0 | 0.1 | +23.0 | 28.2 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +1.0 | 3.7 | 13.6 | 2.2 | +11.3 | 246.0 | 32.5 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 7.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 2.9 | +74.3 | 0.0 | 16.5 | 19.5 | +355.0 | 0.0 | 394.0 |
| FEATURE BUFFS | 2.2 | +77.3 | 0.0 | 13.4 | 0.8 | +16.6 | 0.0 | 0.0 |
| FIGHT LIFT | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +45.0 | 28.8 | 5.9 | 1.0 | +181.4 | 177.4 | 32.5 |
| FIRE IN ORDER | 0.4 | +0.0 | 31.9 | 5.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.5 | +3347.2 | 895.8 | 524.5 | 40.5 | +3090.9 | 322.8 | 815.6 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 37.1 | 4.3 | +0.0 | 0.0 | 95.5 |
| FOLLOW UP WEIGHED | 0.4 | +105.0 | 0.0 | 0.0 | 0.6 | +171.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.8 | +204.6 | 32.5 | 28.7 | 2.7 | +472.9 | 268.3 | 75.9 |
| FRIEND CHARGES FIRST | 0.3 | -13.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.6 | -31.6 | 0.0 | 0.0 | 0.5 | -2.6 | 0.0 | 73.7 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +4.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -4.4 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| GUN FIGURES | 1.5 | +19.0 | 36.3 | 84.5 | 0.2 | +5.5 | 5.9 | 5.9 |
| GUN MASK | 0.4 | +2.5 | 0.0 | 0.0 | 0.9 | +8.9 | 0.0 | 16.8 |
| HARD STAY DROPPED | 1.5 | +0.0 | 0.0 | 28.2 | 0.4 | +0.0 | 0.0 | 45.5 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 55.9 | 2.6 | +0.0 | 0.0 | 54.2 |
| HIS CHARGE DENIED | 0.2 | +5.0 | 0.0 | 5.9 | 0.4 | +10.6 | 5.9 | 0.0 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 10.2 | 2.4 | +0.0 | 0.0 | 63.0 |
| HIS LEGAL MOVES | 3.2 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 101.3 |
| HIS MOVE AND SHOT | 3.0 | -25.4 | 0.0 | 80.1 | 1.5 | -86.4 | 0.0 | 137.4 |
| HIS RANDOM MOVE | 3.0 | +0.0 | 0.0 | 45.1 | 1.2 | +0.0 | 0.0 | 55.4 |
| HIS SHOT LIST | 17.2 | +445.5 | 0.0 | 198.9 | 22.3 | +1351.5 | 0.0 | 561.7 |
| HIS TURN DENIED | 0.5 | +13.7 | 13.4 | 0.0 | 1.6 | +64.6 | 208.7 | 48.9 |
| HOLD ODDS | 13.4 | +0.0 | 0.0 | 68.9 | - | - | - | - |
| HOLDER ASSIGNMENT | 14.4 | +1590.6 | 0.0 | 91.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.5 | +232.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.4 | -32.2 | 32.5 | 5.9 | 2.5 | -115.0 | 259.6 | 75.9 |
| HUNT IN PAIRS | - | - | - | - | 0.2 | +3.7 | 0.0 | 0.0 |
| IDLE COST | 1.8 | -12.3 | 0.0 | 5.0 | 11.1 | -170.5 | 0.0 | 358.1 |
| KEEP FALLS | 0.2 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +9.5 | 0.0 | 0.0 | 0.6 | +24.4 | 0.0 | 40.2 |
| LEGAL CHARGES ONLY | 4.1 | +0.0 | 245.5 | 166.3 | 1.8 | +0.0 | 108.4 | 136.7 |
| LONE WIZARD KEPT IN | 0.9 | +77.0 | 0.0 | 0.0 | 0.3 | +35.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.2 | 0.0 | 7.4 | 0.2 | +0.6 | 7.7 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +10.1 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 27.0 |
| MANOEUVRE | 1.3 | -3.9 | 0.0 | 0.0 | 0.7 | +8.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.2 | +0.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.1 | +8.3 | 0.0 | 0.0 | 0.9 | +21.5 | 0.0 | 53.6 |
| MARCH CHECK | 0.8 | +61.0 | 0.0 | 0.0 | 2.7 | +165.6 | 0.0 | 53.6 |
| MARCH OVER CASTS | 0.5 | +24.1 | 0.0 | 0.0 | 1.1 | +20.0 | 0.0 | 85.5 |
| MAX FOR POSITIONING | 5.4 | +90.4 | 0.0 | 29.1 | 6.0 | +68.4 | 0.0 | 113.2 |
| MISSILES IN THE MOVE | 5.3 | +326.7 | 0.0 | 38.3 | 4.6 | +59.0 | 0.0 | 98.5 |
| MISSILES NEXT TURN | 5.1 | +212.1 | 0.0 | 30.5 | 5.6 | +47.2 | 0.0 | 192.4 |
| MODEL FACING | 0.8 | +262.6 | 0.0 | 5.5 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -68.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.8 | +324.1 | 0.0 | 0.0 | 3.4 | +579.7 | 0.0 | 144.1 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +309.9 | 0.0 | 42.4 | 2.8 | +209.7 | 0.0 | 29.1 |
| NEXT CHARGE BY LIST | 5.2 | -77.7 | 32.5 | 0.0 | 4.4 | -186.3 | 0.0 | 154.5 |
| NEXT OBJECTIVE NEARER | 0.2 | -3.3 | 0.0 | 0.0 | 7.3 | -395.4 | 0.0 | 65.0 |
| NO DOUBLE ROUNDS | 1.6 | -70.3 | 32.5 | 28.7 | 2.2 | -159.9 | 185.1 | 75.9 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 7.7 | 0.2 | +0.0 | 0.0 | 3.7 |
| NOT WORTH A CAST | 0.5 | -0.8 | 0.0 | 0.0 | 0.5 | -0.5 | 0.0 | 31.9 |
| OFF BEST | 0.3 | -4.9 | 0.0 | 5.9 | 0.3 | -17.4 | 0.0 | 5.0 |
| ONE CHARGE A CHARGER | 2.1 | +0.0 | 0.0 | 73.2 | 1.3 | +0.0 | 0.0 | 36.6 |
| ONE FIGHT FORMULA | 5.3 | -90.3 | 0.0 | 22.7 | 4.2 | -113.8 | 0.0 | 155.1 |
| ONE OBJECTIVE FORMULA | 6.8 | +157.4 | 0.0 | 61.5 | 4.5 | -91.1 | 0.0 | 59.2 |
| ONE TARGET A SHOOTER | 15.8 | +273.2 | 0.0 | 145.0 | 20.0 | +669.9 | 0.0 | 368.9 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.1 | +7.3 | 5.9 | 0.0 |
| OVERRUNS AWAY | 0.2 | +0.6 | 13.4 | 0.0 | 0.5 | +11.1 | 70.1 | 5.5 |
| PATHS CROSS | 2.9 | +270.8 | 0.0 | 3.7 | 3.8 | +121.6 | 0.0 | 46.4 |
| PIVOT GUARDS FLANK | 0.1 | -10.5 | 0.0 | 0.0 | 0.1 | -4.8 | 0.0 | 0.0 |
| PLAN RESULT | 41.9 | +1081.4 | 422.7 | 727.5 | 35.7 | +259.6 | 201.5 | 872.1 |
| QUARTER ODDS | 6.2 | +626.5 | 0.0 | 10.2 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +27.6 | 0.0 | 46.4 | 1.0 | +27.3 | 0.0 | 55.0 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -23.8 | 0.0 | 20.5 | 0.4 | -8.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +184.0 | 0.0 | 26.3 | 3.9 | +160.8 | 0.0 | 67.5 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -1.5 | 4.7 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -27.3 | 0.0 | 0.0 | 0.7 | -45.3 | 0.0 | 39.7 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.5 | +19.9 | 0.0 | 20.4 | 0.1 | +8.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.5 | +40.2 | 32.5 | 21.0 | 1.5 | -22.3 | 153.1 | 27.0 |
| RISK BY HIS FIGURE | 12.1 | -153.3 | 0.0 | 225.6 | 11.5 | -228.1 | 0.0 | 342.7 |
| RUN DOWN | 1.4 | -14.7 | 17.1 | 5.9 | 1.7 | -13.1 | 111.0 | 32.5 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -2.7 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.2 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -59.3 | 0.0 | 8.7 |
| SEARCH SPOT | 4.5 | +237.3 | 0.0 | 22.5 | 7.7 | +261.3 | 0.0 | 194.0 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +91.5 | 0.0 | 71.8 |
| SET UP TOGETHER | 0.6 | +11.7 | 0.0 | 0.0 | 0.5 | +0.7 | 0.0 | 27.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +59.4 | 0.0 | 0.0 | 0.5 | +9.2 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.2 | -0.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.0 | +71.3 | 0.0 | 139.3 | 12.7 | -67.4 | 0.0 | 389.5 |
| SHOTS IN THE MOVE | 18.7 | +866.9 | 0.0 | 273.4 | 10.8 | +234.4 | 0.0 | 163.5 |
| SPELL SETS UP CHARGE | 0.5 | +407.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.4 | +7.2 | 0.0 | 0.0 | 1.0 | +19.3 | 72.7 | 104.6 |
| SPELLS IN THE FIGHT | 0.1 | +4.6 | 0.0 | 0.0 | 0.2 | -0.9 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.5 | -6.1 | 13.4 | 0.0 | 0.6 | -9.8 | 70.1 | 15.4 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 36.4 |
| STANDS STILL | 23.5 | +0.0 | 863.3 | 246.3 | 7.8 | +0.0 | 54.5 | 41.8 |
| STAY WORTH | 25.7 | +208.1 | 658.4 | 157.8 | 13.1 | +122.0 | 54.5 | 221.9 |
| SUPPORT NARROWED | 0.5 | +0.0 | 3.7 | 5.9 | 0.5 | +0.0 | 36.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +3.2 | 0.0 | 5.9 | 0.4 | +2.6 | 0.0 | 27.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 3.7 | 4.2 | +0.0 | 0.0 | 46.4 |
| THE PROMISE ADDS | - | - | - | - | 0.1 | -5.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 33.5 |
| TIED UP BY THE SUM | 0.1 | +1.6 | 3.7 | 0.0 | 0.5 | +48.8 | 10.9 | 0.0 |
| TIME ON OUR SIDE | 29.5 | +512.1 | 3.7 | 383.0 | 3.4 | +75.4 | 0.0 | 82.7 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 26.7 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 22.9 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +22.8 | 0.0 | 5.9 | 0.1 | +7.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.1 | +5.0 | 5.9 | 0.0 |
| WIDER SPREAD | 1.1 | -2.1 | 32.5 | 5.9 | 1.9 | -8.3 | 223.4 | 32.5 |
| WOUNDS ON THE RANKS | 1.5 | +77.8 | 0.0 | 0.0 | 1.4 | +139.2 | 0.0 | 64.9 |

### Rule changes: h6-mine-0333a16-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 158 | 158 | 147 | 13.36 | +11612 | +79.0 |
| SEARCH SPOT | 135 | 135 | 123 | 11.18 | +5531 | +45.0 |
| HIS SHOT LIST | 434 | 434 | 121 | 11.00 | +2896 | +23.9 |
| DEPLOY BY FIGURES | 174 | 174 | 102 | 9.27 | +1386 | +13.6 |
| ONE TARGET A SHOOTER | 394 | 394 | 102 | 9.27 | +930 | +9.1 |
| PATHS CROSS | 74 | 74 | 74 | 6.73 | +4317 | +58.3 |
| FIVE ACTION | 967 | 967 | 73 | 6.64 | +3718 | +50.9 |
| LEGAL CHARGES ONLY | 65 | 65 | 65 | 5.91 | +0 | +0.0 |
| TIME ON OUR SIDE | 361 | 316 | 61 | 5.55 | +280 | +4.6 |
| MOVE TO CHARGE COMPUTED | 68 | 68 | 41 | 3.73 | +3412 | +83.2 |
| SHOT RISK POINTS | 250 | 250 | 40 | 3.64 | +1282 | +32.0 |
| ARTILLERY RE-ROLL WEIGHED | 36 | 36 | 36 | 3.27 | +0 | +0.0 |
| MARCH CHECK | 39 | 39 | 28 | 2.55 | +623 | +22.2 |
| FOUR ROUNDS | 50 | 50 | 27 | 2.45 | +2728 | +101.0 |
| CANNON SIGHT KEPT | 23 | 23 | 23 | 2.09 | +0 | +0.0 |
| MAX FOR POSITIONING | 125 | 125 | 23 | 2.09 | +46 | +2.0 |
| REDIRECT COUNTER | 68 | 60 | 22 | 2.00 | +1073 | +48.8 |
| CANNON PLANNED TARGET | 115 | 115 | 21 | 1.91 | -185 | -8.8 |
| HARD STAY DROPPED | 21 | 21 | 21 | 1.91 | +0 | +0.0 |
| COVER ONCE | 109 | 85 | 18 | 1.64 | +359 | +19.9 |
| IDLE COST | 142 | 119 | 18 | 1.64 | +152 | +8.5 |
| SHOTS IN THE MOVE | 325 | 283 | 16 | 1.45 | +472 | +29.5 |
| NEARER NOT NEEDED | 108 | 102 | 15 | 1.36 | +471 | +31.4 |
| CHARGE LOSSES | 130 | 130 | 14 | 1.27 | +1364 | +97.5 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.18 | +1236 | +95.0 |
| NEXT OBJECTIVE NEARER | 82 | 82 | 13 | 1.18 | +440 | +33.9 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 13 | 1.18 | +192 | +14.8 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.09 | +0 | +0.0 |
| MISSILES IN THE MOVE | 109 | 85 | 12 | 1.09 | +804 | +67.0 |
| NEXT CHARGE BY LIST | 105 | 105 | 12 | 1.09 | +109 | +9.1 |
| ONE OBJECTIVE FORMULA | 125 | 106 | 12 | 1.09 | +916 | +76.3 |
| RISK BY HIS FIGURE | 260 | 260 | 12 | 1.09 | +1535 | +127.9 |
| CHARGE NOT DECLARED | 11 | 11 | 11 | 1.00 | -2226 | -202.4 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 1.00 | +3044 | +276.7 |
| MARCH BY THE SUM | 11 | 11 | 11 | 1.00 | +328 | +29.8 |
| RISK BY ARC | 32 | 32 | 11 | 1.00 | +190 | +17.3 |
| FALLS SHORT | 247 | 219 | 10 | 0.91 | +70 | +7.0 |
| HOLDER AT DEPLOYMENT | 17 | 17 | 10 | 0.91 | +279 | +27.9 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.91 | +0 | +0.0 |
| LANE BY FIGURES | 10 | 10 | 10 | 0.91 | +374 | +37.4 |
| QUARTER ODDS | 68 | 68 | 10 | 0.91 | +982 | +98.2 |
| CHAFF IN THE MOVE | 16 | 14 | 9 | 0.82 | +0 | +0.0 |
| HIS TURN DENIED | 23 | 23 | 9 | 0.82 | +160 | +17.8 |
| MODEL FACING | 9 | 9 | 9 | 0.82 | +2889 | +321.0 |
| RANDOM MOVE BY FIGURES | 19 | 19 | 9 | 0.82 | +604 | +67.1 |
| STAY WORTH | 427 | 404 | 9 | 0.82 | +79 | +8.8 |
| FEATURE BUFFS | 33 | 33 | 8 | 0.73 | +160 | +20.0 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.73 | +14 | +1.8 |
| FIGHT TO THE END | 20 | 20 | 7 | 0.64 | +1066 | +152.3 |
| MANOEUVRE | 22 | 22 | 7 | 0.64 | +107 | +15.2 |
| CAST JOB | 13 | 13 | 6 | 0.55 | +27 | +4.5 |
| OFF BEST | 6 | 6 | 6 | 0.55 | -244 | -40.7 |
| RESERVE FALL BACK | 6 | 6 | 6 | 0.55 | +307 | +51.2 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 0.55 | +130 | +21.7 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 5 | 0.45 | +61 | +12.3 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| SCOUT WAITS | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 32 | 32 | 5 | 0.45 | +530 | +106.0 |
| CHAFF PASSED | 4 | 4 | 4 | 0.36 | -25 | -6.2 |
| CHARGE NOW FIRST | 20 | 20 | 4 | 0.36 | -55 | -13.8 |
| COMBAT PIVOT | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| ONE FIGHT FORMULA | 104 | 65 | 4 | 0.36 | +36 | +8.9 |
| SURE REACH TOGETHER | 7 | 7 | 4 | 0.36 | +8 | +2.1 |
| WHO HITS BACK | 4 | 4 | 4 | 0.36 | +206 | +51.5 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.27 | +963 | +321.1 |
| BOMBING RUN | 3 | 3 | 3 | 0.27 | +85 | +28.3 |
| HIS MOVE AND SHOT | 50 | 50 | 3 | 0.27 | +168 | +55.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +118 | +39.2 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 0.27 | -13 | -4.4 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.27 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.18 | +64 | +31.8 |
| GUN MASK | 14 | 14 | 2 | 0.18 | +56 | +28.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.18 | +63 | +31.5 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.18 | +41 | +20.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.18 | -168 | -84.1 |
| REFORMS TO MEET IT | 18 | 18 | 2 | 0.18 | +8 | +4.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.09 | -31 | -31.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.09 | +123 | +122.8 |
| HONEST WORTH | 43 | 43 | 1 | 0.09 | +29 | +29.3 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.09 | +7 | +7.1 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.09 | +0 | +0.0 |
| SET UP TOGETHER | 12 | 10 | 1 | 0.09 | +36 | +36.1 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.09 | +37 | +36.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 38 | 38 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 97 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 12 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 19 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 55 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 76 | 76 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 46 | 46 | 0 | 0.00 | - | - |
| HOLD ODDS | 147 | 147 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 118 | 86 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 42 | 42 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 37 | 37 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 854 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 10 | 10 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 34 | 34 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 12 | 12 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 345 | 345 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 10 | 10 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 82 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| WAITS AGAIN | 27 | 27 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 33 | 33 | 0 | 0.00 | - | - |

### Off best figure: h6-mine-0333a16-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.18 | 0.82 | 202.4 |
| HOLDER ASSIGNMENT | rule | 0.82 | - | 13.2 |
| PATHS CROSS | rule | 0.18 | 0.55 | 39.8 |
| CANNON PLANNED TARGET | rule | 0.45 | - | 59.6 |
| CHAFF PASSED | rule | 0.27 | 0.09 | 6.2 |
| CHARGE NOW FIRST | rule | 0.18 | 0.18 | 13.8 |
| JOB FIRST | gate | 0.18 | 0.09 | 22.2 |
| PIVOT GUARDS FLANK | rule | 0.09 | 0.09 | 84.1 |
| AFTERMATH BAND | gate | 0.09 | - | 1.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.09 | 175.7 |
| BEST PRIZE | rule | - | 0.09 | 31.0 |
| DEPLOY BY FIGURES | rule | - | 0.09 | 4.7 |
| REDIRECT WEIGHED | rule | - | 0.09 | 31.0 |
| RULE SWITCHED OFF | gate | - | 0.09 | 0.5 |
| WHO HITS BACK | rule | 0.09 | - | 1.6 |

### Plans: h6-mine-0333a16-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.4 | 53% | 179 | 97 | 54% |
| Mine | join | 0.6 | 100% | 22 | 0 | 0% |
| Mine | move | 26.1 | 94% | 1915 | 0 | 0% |
| Mine | shoot | 13.3 | 73% | 702 | 985 | 140% |
| Mine | support | 0.5 | 83% | 4 | 0 | 0% |
| Opponent | charge | 1.6 | 39% | 514 | 169 | 33% |
| Opponent | move | 29.1 | 92% | 2057 | 0 | 0% |
| Opponent | shoot | 3.8 | 50% | 139 | 91 | 65% |
| Opponent | support | 1.2 | 92% | 0 | 0 | - |

### Battle groups: h6-mine-0333a16-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 20% | 60% | 20% | 100% | 25% | 0% | 0% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 19% | 75% | 25% | 100% | 0% | 0% | 17% | 83% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-mine-0333a16-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 24 (9) | 14 | 10 | 58 | 56% | 2.8 | 30 (4) | 42 (2) | 0 (3) | 26 (8) | 0 (1) |
| Mine | Character | 43 | 20 (43) | 20 | 0 | 6 | 26% | 2.1 | 4 (9) | 25 (31) | 0 (3) | 23 (29) | 13 (14) |
| Mine | Clean-up | 8 | 47 (8) | 4 | 43 | 33 | 50% | 2.8 | 38 (1) | 74 (4) | 0 (3) | 83 (4) | 0 (4) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 25% | 3.3 | 0 (1) | - | 0 (3) | 0 (3) | 0 (1) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 26 | 48 (26) | 28 | 20 | 30 | 27% | 2.6 | 19 (9) | 51 (14) | 212 (3) | 59 (18) | 31 (8) |
| Mine | Holder | 13 | 65 (13) | 22 | 43 | 39 | 62% | 4.0 | 58 (3) | 15 (4) | 98 (6) | 71 (11) | 19 (2) |
| Mine | Shooter | 10 | 100 (10) | 44 | 56 | 21 | 10% | 1.6 | 41 (3) | 94 (6) | 549 (1) | 129 (6) | 43 (4) |
| Mine | War machine | 24 | 71 (24) | 71 | 0 | 19 | 4% | 1.1 | 101 (7) | 74 (11) | 25 (6) | 76 (7) | 69 (17) |
| Mine | Wizard | 8 | 20 (8) | 20 | 0 | 34 | 38% | 4.2 | - | 20 (8) | - | 0 (2) | 27 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 21 | 111 (21) | 14 | 97 | 36 | 48% | 4.2 | 162 (5) | 83 (9) | 109 (7) | 134 (16) | 20 (5) |
| Opponent | Character | 30 | 31 (30) | 31 | 0 | 29 | 37% | 1.7 | 41 (9) | 28 (16) | 16 (5) | 20 (16) | 46 (14) |
| Opponent | Clean-up | 2 | 80 (2) | 19 | 61 | 0 | 0% | 1.5 | 70 (1) | - | 91 (1) | 70 (1) | 91 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 48 (18) | 4 | 44 | 31 | 50% | 2.3 | 30 (4) | 47 (10) | 71 (4) | 58 (12) | 21 (6) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 55 | 50% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 15 | 31 (15) | 18 | 14 | 46 | 27% | 2.8 | - | 45 (6) | 20 (9) | 28 (7) | 34 (8) |
| Opponent | Holder | 7 | 105 (7) | 12 | 93 | 31 | 57% | 3.7 | 248 (2) | 108 (3) | 24 (2) | 121 (3) | 96 (4) |
| Opponent | Shooter | 10 | 77 (10) | 7 | 70 | 22 | 10% | 2.6 | 115 (3) | 78 (6) | 0 (1) | 82 (7) | 65 (3) |
| Opponent | War machine | 6 | 39 (6) | 39 | 0 | 0 | 0% | 1.3 | 0 (1) | 12 (4) | 155 (1) | - | 39 (6) |
| Opponent | Wizard | 3 | 16 (3) | 16 | 0 | 44 | 0% | 4.3 | 89 (1) | 0 (1) | 12 (1) | 16 (3) | - |

### Charged fights: h6-mine-0333a16-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 252 | 105 | 1.5 | 1.0 | 70 | 42 | +28 | 3 of 6 | 3 of 6 | - | +28 |
| Mine | Chaos Dwarfs | 4 | 398 | 141 | 1.8 | 1.0 | 81 | 18 | +63 | 4 of 7 | 3 of 7 | - | +63 |
| Mine | Dwarfen Mountain Holds | 3 | 362 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| **Mine** | all armies | 11 | 335 | 90 | 1.5 | 1.0 | 62 | 23 | +38 | 7 of 16 | 8 of 16 | - | +38 |
| Opponent | Grand Cathay | 2 | 256 | 0 | 1.5 | 1.0 | 0 | 123 | -123 | 2 of 3 | 2 of 3 | - | -123 |
| Opponent | High Elf Realms | 2 | 42 | 202 | 3.5 | 1.0 | 58 | 42 | +15 | 2 of 7 | 5 of 7 | - | +15 |
| Opponent | Ogre Kingdoms | 1 | 182 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Skaven | 1 | 0 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 0 of 1 | - | +186 |
| Opponent | Warriors of Chaos | 4 | 0 | 396 | 2.0 | 1.0 | 198 | 22 | +176 | 4 of 8 | 7 of 8 | - | +176 |
| Opponent | Wood Elf Realms | 1 | 0 | 707 | 5.0 | 1.0 | 141 | 22 | +120 | 2 of 5 | 4 of 5 | - | +120 |
| **Opponent** | all armies | 11 | 71 | 262 | 2.3 | 1.0 | 115 | 39 | +76 | 11 of 25 | 18 of 25 | - | +76 |

### Effective charges: h6-mine-0333a16-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net -26) | 0 | 0 | 1 (net +233) | 0 | 1 (net +41) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 7 | 1 (net +0) | 0 | 1 (net +395) | 5 (net +9) | 0 | 0 | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 3 | 1 (net -369) | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 7 | 0 | 0 | 1 (net +0) | 2 (net +6) | 1 (net +0) | 2 (net +48) | 1 | 17% (1 of 6) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 8 | 0 | 0 | 1 (net +65) | 3 (net +235) | 0 | 2 (net +312) | 2 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 5 | 1 (net -109) | 1 (net +427) | 2 (net +48) | 1 (net +185) | 0 | 0 | 0 | 40% (2 of 5) |

### Charged fights, damage counted: h6-mine-0333a16-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 80 | 402 | -21 | 49 | 63 | -15 | -18.1 |
| Mine | Effective (55-75%) | 1 | 480 | 395 | +395 | 395 | 0 | +395 | +82.3 |
| Mine | 76-89% | 7 | 224 | 177 | +40 | 71 | 21 | +50 | +22.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 54 | 66 | +14 | 29 | 7 | +22 | +41.4 |
| Mine | All fights | 16 | 163 | 240 | +38 | 77 | 30 | +46 | +28.4 |
| Opponent | Long shot (under 50%) | 2 | 239 | 280 | -239 | 83 | 239 | -156 | -65.1 |
| Opponent | 50-54% | 1 | 499 | 239 | +427 | 427 | 0 | +427 | +85.6 |
| Opponent | Effective (55-75%) | 4 | 187 | 92 | +40 | 60 | 10 | +50 | +26.6 |
| Opponent | 76-89% | 7 | 436 | 237 | +129 | 173 | 71 | +102 | +23.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 280 | 197 | +181 | 181 | 37 | +145 | +51.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 433 | 96 | +0 | 64 | 0 | +64 | +14.7 |
| Opponent | No odds | 4 | 284 | 157 | -4 | 64 | 52 | +12 | +4.2 |
| Opponent | All fights | 25 | 327 | 185 | +76 | 133 | 56 | +77 | +23.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-mine-0333a16-p3 | move | 69 | 18 (26%) | 17 (25%) | 6 (9%) | 45 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Charmed Shield | Opponent | L0534 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Periapt of Soul Exchange | Opponent | L0621 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |

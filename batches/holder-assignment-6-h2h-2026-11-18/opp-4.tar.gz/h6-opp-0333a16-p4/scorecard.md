# Doctrine scorecard: h6-opp-0333a16-p4

### Scorecard: h6-opp-0333a16-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 12 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 13 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 7 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 6 | 4 | 0 | 4 | 0 | 0 | 0 | 30 |
| L0216 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 230 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 4 | 1 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 340 |
| L0333 | 3 | 1 | Opponent | no | 3 | 2 | 1 | 4 | 0 | 0 | 0 | 19 |
| L0420 | 6 | 1 | Mine | no | 4 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Opponent | no | 11 | - | 0 | 1 | 1 | 0 | 0 | 485 |
| **Average** | | | Mine | 0% | 3.7 | 3.8 | 1.6 | 1.4 | 0.0 | 0.0 | 0.0 | 110.0 |
| **Average** | | | Opponent | 14% | 4.4 | 2.2 | 2.0 | 2.9 | 0.4 | 0.0 | 0.0 | 134.9 |

### KPIs: h6-opp-0333a16-p4

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 7 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (9 of 30) | 0% (0 of 35) | 14% (9 of 65) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | 88% (7 of 8); on the table 88% | 87% (13 of 15); on the table 87% |
| Winner chose to pursue after the loser fell back in good order |  | - | 80% (4 of 5); on the table 80% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 80% (8 of 10); on the table 90% | 86% (12 of 14); on the table 86% | 83% (20 of 24); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 41% (52 of 126) | 17% (3 of 18) | 38% (55 of 144) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (52 of 104) | 20% (3 of 15) | 46% (55 of 119) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 86% (6 of 7) | 64% (16 of 25) | 69% (22 of 32) |
| Points that never fought | lower | 46% (6203 of 13595) | 62% (8744 of 13997) | 54% (14947 of 27592) |
|   infantry points that never fought | lower | 51% (2087 of 4124) | 96% (3060 of 3186) | 70% (5147 of 7310) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (24 of 46) | 56% (29 of 52) | 54% (53 of 98) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 3.3 uses a game | 100% (4 of 4); 1.3 uses a game | 100% (10 of 10); 2.3 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.7 uses a game | 75% (3 of 4); 0.4 uses a game | 67% (8 of 12); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (4701 of 10334) | 56% (6955 of 12450) | 51% (11656 of 22784) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.4 (51%) | 1.0 (47%) | 6.4 (51%) |
| MARCHED: its unit marched | 1.6 (15%) | 0.6 (27%) | 2.1 (17%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.7 (16%) | 0.0 (0%) | 1.7 (13%) |
| GONE: slain | 1.4 (14%) | 0.4 (20%) | 1.9 (15%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (7%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.6 | 0.6 | 3.3 | 7.9 | 0.7 |
| not cast | 6.3 | 0.3 | 4.4 | 12.7 | 16.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 1.0 (23%) | 6.4 (51%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.0 (0%) | 0.7 (16%) | 1.7 (13%) | 0.0 (0%) |
| GONE: slain | 1.0 (16%) | 0.0 (0%) | 0.4 (10%) | 1.9 (15%) | 1.7 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.6 (9%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.6 (73%) | 0.3 (100%) | 2.3 (52%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.3 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.1 a game | 0.7 a game | 1.9 a game |
| stood (cast and not dispelled) | 82% (18 of 22) | 0% (0 of 2) | 75% (18 of 24) |
| the unit moved after it | 72% (13 of 18) | - | 72% (13 of 18) |
| it charged on its next turn | 0% (0 of 18) | - | 0% (0 of 18) |
| the enemy charged it first | 11% (2 of 18) | - | 11% (2 of 18) |
| it fought by the end of its next turn | 0% (0 of 18) | - | 0% (0 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (4 of 18) | - | 22% (4 of 18) |
| none of these (no charge, no fight, no charge escaped) | 67% (12 of 18) | - | 67% (12 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (63 of 103) | 41% (56 of 137) | 50% (119 of 240) |
|   cavalry | 67% (4 of 6) | 62% (18 of 29) | 63% (22 of 35) |
|   character | - | 19% (5 of 27) | 19% (5 of 27) |
|   chariot | 44% (16 of 36) | 0% (0 of 4) | 40% (16 of 40) |
|   infantry | 73% (16 of 22) | 42% (22 of 53) | 51% (38 of 75) |
|   war machine | 69% (27 of 39) | 46% (11 of 24) | 60% (38 of 63) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.9 (15%) | 2.4 (21%) | 3.3 (19%) |
| CHARGED: it charged | 0.6 (10%) | 1.7 (15%) | 2.3 (13%) |
| IN COMBAT: it fought this turn or the last | 0.4 (8%) | 0.1 (1%) | 0.6 (3%) |
| MOVED: a war machine that moved | 1.4 (25%) | 0.6 (5%) | 2.0 (12%) |
| NO TARGET IN RANGE | 1.4 (25%) | 3.3 (28%) | 4.7 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (2%) | 0.3 (2%) | 0.4 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 2.3 (20%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.6 (5%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.1 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.1 | 1.1 | 68% | 8.6 pts | 27 pts |
| character | 1.0 | 0.3 | 71% | 1.5 pts | 2 pts |
| chariot | 2.3 | 2.7 | 38% | 53.0 pts | 121 pts |
| infantry | 6.6 | 0.9 | 87% | 1.2 pts | 8 pts |
| war machine | 5.4 | 5.6 | 61% | 31.8 pts | 172 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 3.6 | 3.1 |
| Charges that made contact a game | 1.6 | 3.0 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 0.00 declared, 0.00 contact (2 units) | 0.17 declared, 0.17 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.21 contact (48 units) | 0.43 declared, 0.36 contact (58 units) | 0.41 declared, 0.29 contact (106 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 30% (3 of 10) | - | 100% (1 of 1) | 36% (4 of 11) |
| Character in a unit | 88% (7 of 8) | 67% (4 of 6) | - | 79% (11 of 14) |
| Character on its own | 67% (2 of 3) | 62% (5 of 8) | 45% (5 of 11) | 55% (12 of 22) |
| Chariot | 0% (0 of 1) | 33% (2 of 6) | - | 29% (2 of 7) |
| Infantry | 30% (3 of 10) | 33% (5 of 15) | - | 32% (8 of 25) |
| Monster | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Monstrous | 67% (2 of 3) | - | - | 67% (2 of 3) |
| War Machines | 100% (6 of 6) | 50% (1 of 2) | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (6 of 8); on the table 88% | 46% (47 of 102) | 30% | 55% (12 of 22) | 100% (6 of 6); 5.8 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 3 | 100% (2 of 2); on the table 100% | 21% (5 of 24) | 65% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 69% | 29% (2 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 83% (5 of 6); on the table 83% | - | 77% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 75% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (4 of 4); on the table 100% | - | 32% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 75% | 60% (6 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-opp-0333a16-p4, 7 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (8) | 44% (4) | 48% (12) |
| ...free all their last turn and able to turn (per game) | 0.71 | 0.14 | 0.86 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.14 | 0.29 |
| ...with the charger already in that arc before they moved (per game) | 0.71 | 0.00 | 0.71 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.43 | 0.14 | 0.57 |

### Quality by phase: h6-opp-0333a16-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.9 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 23% (3 of 13) | 45% (9 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (22 of 68) | 38% (10 of 26) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 63% (12 of 19) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 54% (7 of 13) | 60% (9 of 15) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.4 | 2.9 |
| Movement | Points that never moved of their own | 110.0 | 134.9 |
| Movement | Fights charged into per game | 1.3 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net -85 | 4 of 17, net +205 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +210 | 4 of 17, net +87 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 7, net +70 | 4 of 17, net +71 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +70 | 2 of 17, net +32 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.1 | 7.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (11 of 36) | 42% (22 of 53) |
| Shooting | Points destroyed by shooting units | 111.9 | 0.0 |
| Shooting | War machine shots | 3.9 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (8 of 27) | 64% (7 of 11) |
| Shooting | Points destroyed by war machines | 2.7 | 20.0 |
| Magic | Magic missiles cast | 4.9 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (12 of 34) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 9.4 | 0.9 |
| Magic | Wounds caused by other spells | 0.4 | - |
| Magic | Points destroyed by magic (all spells) | 100.6 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.0 / 0.3 / 0.0 | 1.4 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 100.7 | 281.3 |
| Combat | Points run down | 28.6 | 0.0 |
| Combat | Net points per charged fight, damage counted | +73 | +68 |
| Combat | Net per 100 charger points, damage counted | +20.5 | +23.0 |
| Combat | First round won (charged fights) | 78% | 55% |
| Combat | Net points per charged fight | +44 | +81 |
| Combat | Net points per supported fight / lone fight | +62 / +38 | +0 / +86 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 9 | 8 of 20 |
| Game | Points lost | 356.4 | 478.0 |
| Game | VP from objectives | 771.4 | 632.9 |
| Game | Lone holders (player turns) | 3.7 | 4.4 |

- Mine won / drew / lost: 3 / 4 / 0 of 7 ended games (of 7); mean margin (Mine - Opponent) +289 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 834
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-opp-0333a16-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +40.7 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 32.9 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -70.1 | 0.0 | 16.4 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 47.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.0 | +104.8 | 214.3 | 117.1 | 1.3 | +42.2 | 40.0 | 0.0 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 11.6 | 0.0 |
| CAST JOB | 0.3 | +6.3 | 14.9 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.6 | +144.6 | 209.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 56.4 |
| CHAFF IN THE MOVE | 1.1 | +48.7 | 0.0 | 0.0 | 0.3 | +4.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.3 | -251.3 | 0.0 | 9.3 | 5.6 | -231.8 | 0.0 | 187.3 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 9.0 |
| CHARGE NOW FIRST | 0.9 | +0.0 | 109.9 | 0.0 | 1.9 | +0.0 | 67.6 | 102.0 |
| CHARGER SLAIN LOST | 0.1 | -1.4 | 19.6 | 0.0 | - | - | - | - |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.1 | +0.0 | 0.0 | 16.4 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 12.1 | - | - | - | - |
| CHEAPEST HOLDER | 0.7 | -66.6 | 85.6 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.9 | +0.0 | 30.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 7.4 | 0.0 |
| CONVEYANCE SEARCH | 2.6 | +234.3 | 0.0 | 50.7 | - | - | - | - |
| COVER ONCE | 6.3 | -722.9 | 0.0 | 9.3 | 2.7 | -126.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.1 | +52.5 | 0.0 | 0.0 | 7.7 | +29.4 | 0.0 | 4.3 |
| ENGINEER BY LORE | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.1 | +3.4 | 99.4 | 0.0 | 2.3 | +2.3 | 61.9 | 120.0 |
| FALLBACK BY WORTH | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 5.6 | +100.7 | 0.0 | 7.4 | 19.6 | +243.6 | 0.0 | 218.4 |
| FEATURE BUFFS | 4.9 | +154.5 | 0.0 | 0.0 | 1.0 | +50.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.6 | +15.2 | 79.9 | 0.0 | 1.4 | +31.7 | 24.3 | 102.0 |
| FIRE IN ORDER | 0.1 | +0.0 | 29.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 44.4 | +3145.5 | 779.3 | 276.3 | 48.7 | +3064.5 | 141.9 | 627.9 |
| FLANK NOT WEIGHED | 8.4 | +0.0 | 0.0 | 7.4 | 5.0 | +0.0 | 0.0 | 100.4 |
| FOLLOW UP WEIGHED | 0.3 | +78.9 | 0.0 | 0.0 | 0.1 | +77.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +89.5 | 129.4 | 11.6 | 2.9 | +209.7 | 101.9 | 120.0 |
| FRIEND CHARGES FIRST | 0.3 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -13.3 | 0.0 | 0.0 | 0.3 | -13.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.4 | +29.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.7 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +66.2 | 97.0 | 0.0 | 0.9 | +0.2 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.1 | +4.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 42.9 | 2.4 | +0.0 | 0.0 | 49.6 |
| HIS CHARGE DENIED | 0.3 | +7.9 | 19.6 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 0.0 | 1.9 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 67.3 |
| HIS MOVE AND SHOT | 2.0 | -27.5 | 0.0 | 0.0 | 1.6 | -56.1 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 4.3 | +0.0 | 0.0 | 24.3 | 1.4 | +0.0 | 0.0 | 11.4 |
| HIS SHOT LIST | 15.7 | +493.5 | 0.0 | 66.1 | 23.6 | +1130.9 | 0.0 | 412.0 |
| HIS TURN DENIED | - | - | - | - | 1.6 | +205.0 | 25.0 | 120.0 |
| HOLD ODDS | - | - | - | - | 13.7 | +0.0 | 0.0 | 119.1 |
| HOLDER ASSIGNMENT | - | - | - | - | 15.7 | +1389.6 | 0.0 | 119.1 |
| HOLDER AT DEPLOYMENT | 1.4 | +217.3 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.6 | -34.8 | 139.9 | 0.0 | 2.6 | -150.0 | 77.6 | 111.0 |
| IDLE COST | 1.9 | -8.4 | 0.0 | 12.1 | 13.7 | -225.4 | 0.0 | 204.0 |
| KEEP FALLS | 0.1 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +5.2 | 0.0 | 0.0 | 1.0 | +33.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.1 | +0.0 | 93.7 | 49.3 | 5.3 | +0.0 | 75.7 | 44.3 |
| LONE WIZARD KEPT IN | 1.4 | +92.8 | 0.0 | 0.0 | 0.4 | +27.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +3.5 | 0.0 | 11.6 | 0.3 | -10.1 | 15.7 | 9.3 |
| LOST CHARGE | 0.3 | -0.2 | 49.9 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -5.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +45.3 | 0.0 | 0.0 | 1.1 | +11.0 | 0.0 | 49.6 |
| MARCH AT ESCAPER | 0.3 | +20.5 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.6 | +15.6 | 0.0 | 0.0 | 0.4 | +5.5 | 0.0 | 0.0 |
| MARCH CHECK | 1.1 | +83.7 | 0.0 | 0.0 | 1.1 | +43.8 | 0.0 | 56.9 |
| MARCH OVER CASTS | 0.4 | -10.5 | 0.0 | 0.0 | 0.7 | +146.2 | 0.0 | 56.4 |
| MAX FOR POSITIONING | 8.4 | +111.8 | 0.0 | 15.3 | 3.6 | +61.5 | 0.0 | 111.6 |
| MISSILES IN THE MOVE | 5.6 | +482.6 | 0.0 | 0.0 | 1.3 | +18.5 | 0.0 | 114.6 |
| MISSILES NEXT TURN | 7.0 | +359.1 | 0.0 | 0.0 | 3.0 | +17.3 | 0.0 | 199.4 |
| MOVE SPELL IN RANGE | 0.4 | +26.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.0 | -31.5 | 0.0 | 0.0 | 0.9 | -48.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +482.3 | 0.0 | 0.0 | 4.3 | +449.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +15.7 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.3 | +210.1 | 0.0 | 9.3 | 5.7 | +244.8 | 0.0 | 22.9 |
| NEEDED THERE | 0.1 | +67.0 | 30.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.0 | -440.7 | 14.9 | 0.0 | 6.4 | -186.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 5.0 | -187.5 | 0.0 | 35.3 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.4 | -25.8 | 69.4 | 11.6 | 2.6 | -57.5 | 66.0 | 120.0 |
| NOT TURNED | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 0.9 | -0.7 | 0.0 | 112.9 |
| OFF BEST | 0.1 | -2.0 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.6 | +0.0 | 0.0 | 15.3 | 1.4 | +0.0 | 0.0 | 31.3 |
| ONE FIGHT FORMULA | 5.0 | -94.3 | 0.0 | 0.0 | 5.7 | -135.0 | 0.0 | 219.3 |
| ONE OBJECTIVE FORMULA | 5.9 | +7.4 | 0.0 | 22.3 | 5.4 | +16.6 | 0.0 | 90.7 |
| ONE TARGET A SHOOTER | 12.4 | +184.0 | 0.0 | 54.4 | 19.6 | +574.9 | 0.0 | 153.1 |
| OPENS UP | - | - | - | - | 0.1 | +4.5 | 9.3 | 0.0 |
| OVERRUNS AWAY | 0.1 | +2.1 | 30.0 | 0.0 | 0.3 | +16.8 | 15.7 | 0.0 |
| PATHS CROSS | 2.9 | +134.4 | 0.0 | 7.9 | 4.0 | +196.7 | 0.0 | 28.4 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +9.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +851.2 | 593.6 | 339.0 | 42.3 | +156.1 | 32.1 | 802.7 |
| QUARTER ODDS | - | - | - | - | 7.4 | +732.8 | 15.7 | 97.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +36.3 | 0.0 | 48.6 | 3.6 | +64.4 | 0.0 | 54.3 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -11.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +113.2 | 0.0 | 20.0 | 3.6 | +133.0 | 0.0 | 74.7 |
| REDIRECT WEIGHED | 0.3 | +9.0 | 19.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.6 | -3.3 | 0.0 | 0.0 | 0.4 | -9.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +14.3 | 0.0 | 0.0 | 1.0 | +30.4 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +4.2 | 0.0 | 16.4 |
| RISK BY ARC | 1.1 | +28.8 | 99.4 | 11.6 | 2.4 | +58.4 | 101.9 | 111.0 |
| RISK BY HIS FIGURE | 14.4 | -217.4 | 0.0 | 70.3 | 10.0 | -147.1 | 0.0 | 274.1 |
| RUN DOWN | 1.1 | -13.2 | 39.4 | 0.0 | 2.1 | -11.7 | 77.6 | 103.6 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -7.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -19.5 | 0.0 | 2.7 |
| SEARCH SPOT | 6.0 | +264.4 | 0.0 | 9.3 | 5.6 | +164.9 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 0.4 | +48.2 | 0.0 | 112.9 |
| SET UP TOGETHER | - | - | - | - | 0.9 | +4.1 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.6 | +120.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.4 | +126.3 | 89.1 | 0.0 | 0.7 | +8.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -7.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 8.1 | +64.7 | 0.0 | 7.9 | 16.7 | +445.1 | 0.0 | 243.1 |
| SHOTS IN THE MOVE | 10.0 | +640.1 | 0.0 | 166.4 | 11.0 | +268.3 | 0.0 | 106.9 |
| SPELL SETS UP CHARGE | 0.9 | +221.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +28.5 | 0.0 | 101.4 | 3.1 | +57.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.1 | +0.4 | 30.0 | 0.0 | 0.1 | -1.7 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.4 | -3.0 | 18.6 | 9.0 |
| STANDS FOR A REASON | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 18.9 | +0.0 | 619.9 | 205.7 | 14.3 | +0.0 | 40.0 | 165.6 |
| STAY WORTH | 9.7 | +22.8 | 307.7 | 282.9 | 11.7 | +136.8 | 40.0 | 97.6 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 99.4 | 0.0 | 1.0 | +0.0 | 43.3 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.9 | +3.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.0 | +0.0 | 0.0 | 7.9 | 3.7 | +0.0 | 0.0 | 28.4 |
| THE PROMISE ADDS | 0.1 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.1 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 48.0 |
| TIED UP BY THE SUM | 0.6 | +45.3 | 49.9 | 0.0 | 1.0 | +79.9 | 52.6 | 0.0 |
| TIME ON OUR SIDE | 30.1 | +493.7 | 14.9 | 39.4 | 5.9 | +90.5 | 0.0 | 22.9 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +37.6 | 60.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 14.9 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +28.9 | 0.0 | 0.0 | 0.1 | +30.0 | 0.0 | 30.0 |
| WHOLE FIGHT | 0.4 | +5.2 | 90.0 | 0.0 | 0.3 | +12.4 | 35.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +11.4 | 0.0 | 11.6 | - | - | - | - |
| WIDER SPREAD | 1.1 | -5.8 | 159.4 | 0.0 | 2.0 | -15.0 | 71.7 | 25.4 |
| WOUNDS ON THE RANKS | 2.1 | +42.4 | 0.0 | 0.0 | 1.1 | +157.9 | 0.0 | 0.0 |

### Rule changes: h6-opp-0333a16-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 110 | 110 | 101 | 14.43 | +3402 | +33.7 |
| HIS SHOT LIST | 275 | 275 | 83 | 11.86 | +1917 | +23.1 |
| SEARCH SPOT | 81 | 81 | 77 | 11.00 | +3025 | +39.3 |
| LEGAL CHARGES ONLY | 66 | 66 | 66 | 9.43 | +0 | +0.0 |
| DEPLOY BY FIGURES | 111 | 111 | 63 | 9.00 | +723 | +11.5 |
| ONE TARGET A SHOOTER | 224 | 224 | 52 | 7.43 | +639 | +12.3 |
| PATHS CROSS | 48 | 48 | 48 | 6.86 | +2318 | +48.3 |
| TIME ON OUR SIDE | 252 | 214 | 42 | 6.00 | +137 | +3.3 |
| MAX FOR POSITIONING | 84 | 80 | 28 | 4.00 | +102 | +3.6 |
| FALLS SHORT | 176 | 162 | 26 | 3.71 | +64 | +2.5 |
| FIVE ACTION | 652 | 652 | 25 | 3.57 | +1283 | +51.3 |
| MOVE TO CHARGE COMPUTED | 49 | 49 | 25 | 3.57 | +2593 | +103.7 |
| SHOT RISK POINTS | 174 | 174 | 25 | 3.57 | +833 | +33.3 |
| RANDOM MOVE BY FIGURES | 32 | 32 | 22 | 3.14 | +705 | +32.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 2.43 | +0 | +0.0 |
| COVER ONCE | 63 | 47 | 15 | 2.14 | +271 | +18.1 |
| FOUR ROUNDS | 32 | 32 | 15 | 2.14 | +261 | +17.4 |
| SHOTS IN THE MOVE | 147 | 129 | 15 | 2.14 | +448 | +29.9 |
| MISSILES IN THE MOVE | 48 | 38 | 14 | 2.00 | +593 | +42.3 |
| REDIRECT COUNTER | 46 | 37 | 14 | 2.00 | +369 | +26.3 |
| IDLE COST | 109 | 92 | 13 | 1.86 | +122 | +9.4 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.86 | +841 | +64.7 |
| RISK BY ARC | 25 | 25 | 13 | 1.86 | +192 | +14.7 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 1.71 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 12 | 1.71 | +138 | +11.5 |
| COMBAT PIVOT | 11 | 11 | 11 | 1.57 | +0 | +0.0 |
| MANOEUVRE | 20 | 20 | 11 | 1.57 | +395 | +35.9 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 1.29 | +0 | +0.0 |
| LANE BY FIGURES | 9 | 9 | 9 | 1.29 | +273 | +30.4 |
| RESERVE FALL BACK | 9 | 9 | 9 | 1.29 | +313 | +34.8 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| CASTING BLOCK | 11 | 11 | 8 | 1.14 | +142 | +17.7 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| MARCH CHECK | 16 | 16 | 8 | 1.14 | +88 | +11.1 |
| MARCH BY THE SUM | 7 | 7 | 7 | 1.00 | +148 | +21.2 |
| NEARER NOT NEEDED | 70 | 64 | 7 | 1.00 | +239 | +34.2 |
| NEXT CHARGE BY LIST | 73 | 73 | 7 | 1.00 | +237 | +33.9 |
| TIED UP BY THE SUM | 11 | 11 | 7 | 1.00 | +79 | +11.2 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| CANNON PLANNED TARGET | 30 | 30 | 6 | 0.86 | +9 | +1.6 |
| CHAFF IN THE MOVE | 10 | 8 | 6 | 0.86 | +10 | +1.6 |
| FEATURE BUFFS | 41 | 41 | 6 | 0.86 | +230 | +38.3 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.86 | +405 | +67.5 |
| ONE OBJECTIVE FORMULA | 79 | 65 | 6 | 0.86 | +428 | +71.3 |
| QUARTER ODDS | 52 | 52 | 6 | 0.86 | +211 | +35.1 |
| CHARGE NOW FIRST | 19 | 19 | 5 | 0.71 | -204 | -40.9 |
| NEXT OBJECTIVE NEARER | 35 | 35 | 5 | 0.71 | +133 | +26.7 |
| RISK BY HIS FIGURE | 171 | 171 | 5 | 0.71 | +467 | +93.4 |
| STUCK PIVOT | 5 | 5 | 5 | 0.71 | +0 | +0.0 |
| CHARGE LOSSES | 83 | 83 | 4 | 0.57 | +389 | +97.3 |
| HIS TURN DENIED | 11 | 11 | 4 | 0.57 | +436 | +109.1 |
| MISSILES NEXT TURN | 70 | 52 | 4 | 0.57 | +57 | +14.3 |
| WHOLE FIGHT | 5 | 5 | 4 | 0.57 | +64 | +16.0 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 0.43 | -189 | -63.1 |
| FIGHT TO THE END | 14 | 14 | 3 | 0.43 | +53 | +17.8 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 0.43 | +1094 | +364.7 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.43 | +208 | +69.2 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.43 | +118 | +39.2 |
| OFF BEST | 3 | 3 | 3 | 0.43 | -17 | -5.6 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 0.43 | +63 | +21.0 |
| WHO HITS BACK | 3 | 3 | 3 | 0.43 | +223 | +74.5 |
| WOUNDS ON THE RANKS | 23 | 23 | 3 | 0.43 | +182 | +60.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.29 | +291 | +145.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.29 | +26 | +13.2 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.29 | +60 | +30.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.29 | -41 | -20.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.29 | +2 | +1.0 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.29 | +0 | +0.0 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.29 | +20 | +10.2 |
| CAST JOB | 2 | 2 | 1 | 0.14 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 24 | 24 | 1 | 0.14 | +19 | +19.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| GUN MASK | 1 | 1 | 1 | 0.14 | +28 | +27.9 |
| KEEP FALLS | 1 | 1 | 1 | 0.14 | +81 | +80.7 |
| LONG SHOT | 5 | 5 | 1 | 0.14 | +1 | +0.9 |
| NEEDED THERE | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| OPENS UP | 1 | 1 | 1 | 0.14 | +9 | +9.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.14 | +64 | +64.5 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.14 | -0 | -0.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.14 | +29 | +29.4 |
| RUN DOWN | 23 | 23 | 1 | 0.14 | +3 | +2.6 |
| SCOUT WAITS | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| SET UP TOGETHER | 6 | 4 | 1 | 0.14 | +8 | +8.3 |
| STAY WORTH | 150 | 138 | 1 | 0.14 | +43 | +43.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.14 | +4 | +4.4 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARACTER GUNS | 5 | 5 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 94 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 32 | 32 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 31 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 39 | 39 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 40 | 40 | 0 | 0.00 | - | - |
| HOLD ODDS | 96 | 96 | 0 | 0.00 | - | - |
| HONEST WORTH | 29 | 29 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 28 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 35 | 35 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 75 | 38 | 0 | 0.00 | - | - |
| PLAN RESULT | 567 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 34 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 232 | 232 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 14 | 14 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 54 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 8 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WALK PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WIDER SPREAD | 22 | 22 | 0 | 0.00 | - | - |

### Off best figure: h6-opp-0333a16-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.71 | 16.3 |
| CHARGE NOW FIRST | rule | 0.14 | 0.57 | 40.9 |
| CANNON PLANNED TARGET | rule | 0.43 | - | 2.9 |
| CHARGE NOT DECLARED | rule | 0.14 | 0.29 | 63.1 |
| PATHS CROSS | rule | 0.29 | 0.14 | 24.2 |
| FIGHT ORDER BAND | gate | - | 0.29 | 1.4 |
| PIVOT GUARDS FLANK | rule | - | 0.29 | 20.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | - | 14.0 |

### Plans: h6-opp-0333a16-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.9 | 85% | 204 | 307 | 151% |
| Mine | move | 28.7 | 98% | 2261 | 0 | 0% |
| Mine | shoot | 7.7 | 61% | 612 | 544 | 89% |
| Mine | support | 0.4 | 100% | 0 | 0 | - |
| Opponent | charge | 2.4 | 53% | 613 | 99 | 16% |
| Opponent | move | 36.6 | 94% | 1685 | 0 | 0% |
| Opponent | shoot | 2.9 | 35% | 169 | 57 | 34% |
| Opponent | support | 0.4 | 67% | 0 | 0 | - |

### Battle groups: h6-opp-0333a16-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 14% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.6 | 20% | 80% | 20% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-opp-0333a16-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 23 | 100% | - | 0 (1) | 0 (3) | 0 (1) | 0 (4) | 0 (1) |
| Mine | Character | 27 | 26 (27) | 26 | 0 | 30 | 22% | 2.3 | 9 (6) | 62 (8) | 16 (8) | 45 (13) | 11 (9) |
| Mine | Clean-up | 1 | 99 (1) | 0 | 99 | 100 | 0% | 2.0 | 99 (1) | - | - | 99 (1) | - |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 34 | 60% | 3.8 | 263 (1) | 0 (3) | 0 (6) | 24 (9) | 0 (1) |
| Mine | Hammer | 18 | 50 (18) | 33 | 16 | 5 | 17% | 2.7 | 47 (4) | 63 (9) | 27 (5) | 46 (8) | 53 (10) |
| Mine | Holder | 10 | 119 (10) | 0 | 119 | 0 | 90% | 5.0 | 100 (1) | 148 (6) | 70 (3) | 101 (5) | 139 (5) |
| Mine | Shooter | 5 | 97 (5) | 0 | 97 | 35 | 0% | 1.4 | - | 97 (5) | - | 62 (3) | 162 (2) |
| Mine | War machine | 8 | 2 (8) | 2 | 0 | 53 | 0% | 2.0 | 2 (7) | 0 (1) | - | 0 (2) | 2 (6) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 40% | 3.7 | 0 (4) | 0 (1) | - | 0 (3) | 0 (2) |
| Opponent | Chaff | 14 | 83 (14) | 13 | 70 | 30 | 57% | 2.3 | 79 (8) | 103 (4) | 0 (2) | 95 (13) | 0 (1) |
| Opponent | Character | 17 | 22 (17) | 22 | 0 | 27 | 24% | 2.2 | 28 (2) | 17 (8) | 28 (6) | 12 (8) | 33 (8) |
| Opponent | Clean-up | 6 | 49 (6) | 0 | 49 | 0 | 83% | 3.0 | 54 (2) | 27 (2) | 77 (2) | 97 (3) | 14 (3) |
| Opponent | Fast Hammer | 8 | 53 (8) | 25 | 28 | 40 | 62% | 2.0 | 65 (2) | 68 (4) | 0 (2) | 65 (6) | 0 (2) |
| Opponent | Hammer | 10 | 23 (10) | 18 | 5 | 37 | 40% | 4.3 | - | 28 (7) | 13 (3) | 8 (5) | 35 (5) |
| Opponent | Holder | 5 | 63 (5) | 0 | 63 | 19 | 60% | 5.0 | 0 (1) | 123 (3) | 0 (1) | 62 (4) | 65 (1) |
| Opponent | Shooter | 7 | 83 (7) | 0 | 83 | 29 | 0% | 2.7 | 124 (2) | 58 (1) | 57 (4) | 111 (4) | 59 (3) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 4 | 35 (4) | 35 | 0 | 0 | 25% | 1.0 | 70 (2) | - | 0 (2) | - | 35 (4) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 2.2 | - | 0 (2) | 0 (2) | - | 0 (4) |

### Charged fights: h6-opp-0333a16-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 176 | 77 | 1.0 | 1.2 | 77 | 84 | -6 | 3 of 4 | 3 of 4 | -85 | +20 |
| Mine | Chaos Dwarfs | 3 | 267 | 140 | 1.7 | 1.2 | 84 | 0 | +84 | 3 of 5 | 4 of 5 | +210 | +52 |
| **Mine** | all armies | 7 | 215 | 104 | 1.3 | 1.2 | 81 | 37 | +44 | 6 of 9 | 7 of 9 | +62 | +38 |
| Opponent | High Elf Realms | 1 | 0 | 690 | 5.0 | 1.0 | 138 | 23 | +115 | 4 of 5 | 1 of 5 | - | +115 |
| Opponent | Kingdom of Bretonnia | 2 | 70 | 109 | 2.5 | 1.0 | 44 | 0 | +44 | 0 of 5 | 4 of 5 | - | +44 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 393 | 3.5 | 1.0 | 112 | 9 | +103 | 3 of 7 | 4 of 7 | - | +103 |
| Opponent | Wood Elf Realms | 1 | 0 | 110 | 3.0 | 1.3 | 37 | 0 | +37 | 1 of 3 | 2 of 3 | +0 | +55 |
| **Opponent** | all armies | 7 | 20 | 258 | 2.9 | 1.1 | 90 | 9 | +81 | 8 of 20 | 11 of 20 | +0 | +86 |

### Effective charges: h6-opp-0333a16-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -85) | 0 | 0 | 0 | 0 | 1 (net +139) | 2 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net +210) | 0 | 3 (net +70) | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 5 | 2 (net +168) | 0 | 2 (net +120) | 0 | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 2 (net +0) | 3 (net +73) | 0 | 0 | 0% (0 of 5) |
| Opponent | Warriors of Chaos | 7 | 2 (net +243) | 0 | 2 (net +54) | 0 | 1 (net +65) | 1 (net +65) | 1 | 33% (2 of 6) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 1 (net +110) | 0 | 0 | 2 | 0% (0 of 1) |

### Charged fights, damage counted: h6-opp-0333a16-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 166 | 371 | -85 | 62 | 85 | -23 | -14.0 |
| Mine | Effective (55-75%) | 1 | 339 | 210 | +210 | 210 | 0 | +210 | +61.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 198 | 174 | +70 | 70 | 0 | +70 | +35.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 407 | 94 | +70 | 79 | 0 | +79 | +19.4 |
| Mine | No odds | 2 | 554 | 334 | -40 | 256 | 207 | +49 | +8.9 |
| Mine | All fights | 9 | 359 | 209 | +44 | 129 | 55 | +73 | +20.5 |
| Opponent | Long shot (under 50%) | 4 | 496 | 342 | +205 | 221 | 151 | +70 | +14.1 |
| Opponent | Effective (55-75%) | 4 | 202 | 284 | +87 | 145 | 44 | +101 | +49.7 |
| Opponent | 76-89% | 3 | 318 | 150 | +37 | 46 | 0 | +46 | +14.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 89 | 65 | +32 | 62 | 0 | +62 | +70.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 354 | 71 | +71 | 71 | 0 | +71 | +20.0 |
| Opponent | No odds | 3 | 191 | 162 | +0 | 44 | 0 | +44 | +23.1 |
| Opponent | All fights | 20 | 296 | 193 | +81 | 107 | 39 | +68 | +23.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-opp-0333a16-p4 | move | 54 | 10 (19%) | 8 (15%) | 7 (13%) | 37 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

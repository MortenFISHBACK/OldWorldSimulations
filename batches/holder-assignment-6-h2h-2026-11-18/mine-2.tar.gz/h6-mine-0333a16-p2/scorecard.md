# Doctrine scorecard: h6-mine-0333a16-p2

### Scorecard: h6-mine-0333a16-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 225 |
| L0123 | 3 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 150 |
| L0123 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 8 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0224 | 2 | 1 | Mine | - | - | 2 | 2 | 6 | 0 | 0 | 0 | 115 |
| L0224 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 385 |
| L0325 | 1 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 229 |
| L0325 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | yes | 8 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 65 |
| L0427 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 286 |
| L0513 | 3 | 1 | Opponent | no | 7 | 3 | 3 | 0 | 2 | 0 | 0 | 0 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 595 |
| L0530 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.1 | 2.0 | 1.0 | 2.4 | 0.0 | 0.0 | 0.0 | 166.5 |
| **Average** | | | Opponent | 29% | 2.3 | 3.0 | 1.7 | 1.7 | 0.2 | 0.0 | 0.0 | 61.0 |

### KPIs: h6-mine-0333a16-p2

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 10 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (11 of 38) | 21% (11 of 53) | 24% (22 of 91) |
| Winner chose to follow up after the loser gave ground |  | 100% (11 of 11); on the table 100% | 100% (5 of 5); on the table 100% | 100% (16 of 16); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 80% (4 of 5); on the table 80% | 71% (5 of 7); on the table 71% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 87% (13 of 15); on the table 87% | 92% (11 of 12); on the table 92% | 89% (24 of 27); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 47% (65 of 138) | 48% (20 of 42) | 47% (85 of 180) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (65 of 122) | 56% (20 of 36) | 54% (85 of 158) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 42% (5 of 12) | - | 42% (5 of 12) |
| Points that never fought | lower | 61% (12026 of 19594) | 60% (11941 of 19995) | 61% (23967 of 39589) |
|   infantry points that never fought | lower | 58% (3249 of 5628) | 83% (2884 of 3462) | 67% (6133 of 9090) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (42 of 68) | 55% (42 of 76) | 58% (84 of 144) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.1 uses a game | 100% (3 of 3); 0.7 uses a game | 100% (9 of 9); 1.4 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.1 uses a game | 60% (3 of 5); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.4 uses a game | 60% (3 of 5); 0.3 uses a game | 54% (7 of 13); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (8706 of 14772) | 52% (8978 of 17127) | 55% (17684 of 31899) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (30%) | 0.7 (32%) | 2.9 (31%) |
| MARCHED: its unit marched | 2.0 (27%) | 0.5 (23%) | 2.5 (26%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (9%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.4 (5%) | 0.4 (18%) | 0.8 (8%) |
| REAR RANK: in a rear rank | 1.0 (14%) | 0.0 (0%) | 1.0 (11%) |
| GONE: slain | 0.2 (3%) | 0.2 (9%) | 0.4 (4%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (14%) | 0.0 (0%) | 1.0 (11%) |
| STUPIDITY: Stupidity | 0.4 (5%) | 0.2 (9%) | 0.6 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.4 | 2.4 | 8.5 | 0.5 | 0.6 |
| not cast | 3.5 | 2.0 | 5.4 | 9.5 | 1.3 | 24.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (3%) | 1.6 (80%) | 1.2 (22%) | 2.9 (31%) | 0.3 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (26%) | 0.2 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.8 (8%) | 0.1 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (14%) | 0.0 (0%) | 0.0 (0%) | 1.0 (11%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.6 (17%) | 0.0 (0%) | 0.6 (11%) | 0.4 (4%) | 0.0 (0%) | 2.3 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 1.0 (19%) | 1.0 (11%) | 0.0 (0%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.6 (6%) | 0.0 (0%) | 0.8 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (10%) | 0.0 (0%) | 0.0 (0%) | 0.6 (46%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (66%) | 0.2 (10%) | 2.3 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.5 a game | 0.7 a game | 1.6 a game |
| stood (cast and not dispelled) | 72% (18 of 25) | 71% (5 of 7) | 72% (23 of 32) |
| the unit moved after it | 67% (12 of 18) | 100% (5 of 5) | 74% (17 of 23) |
| it charged on its next turn | 0% (0 of 18) | 0% (0 of 5) | 0% (0 of 23) |
| the enemy charged it first | 0% (0 of 18) | 0% (0 of 5) | 0% (0 of 23) |
| it fought by the end of its next turn | 0% (0 of 18) | 0% (0 of 5) | 0% (0 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 18) | 0% (0 of 5) | 9% (2 of 23) |
| none of these (no charge, no fight, no charge escaped) | 89% (16 of 18) | 100% (5 of 5) | 91% (21 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (141 of 227) | 53% (106 of 201) | 58% (247 of 428) |
|   cavalry | 55% (6 of 11) | 47% (15 of 32) | 49% (21 of 43) |
|   character | 79% (34 of 43) | 10% (2 of 21) | 56% (36 of 64) |
|   chariot | 51% (24 of 47) | 67% (8 of 12) | 54% (32 of 59) |
|   infantry | 67% (24 of 36) | 57% (29 of 51) | 61% (53 of 87) |
|   war machine | 59% (53 of 90) | 61% (52 of 85) | 60% (105 of 175) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (22%) | 1.8 (19%) | 3.7 (20%) |
| CHARGED: it charged | 0.3 (3%) | 0.7 (7%) | 1.0 (6%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.3 (3%) | 0.5 (3%) |
| IN COMBAT: it fought this turn or the last | 0.4 (5%) | 0.0 (0%) | 0.4 (2%) |
| MOVED: a war machine that moved | 2.4 (28%) | 2.0 (21%) | 4.4 (24%) |
| NO TARGET IN RANGE | 1.1 (13%) | 1.6 (17%) | 2.7 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.7 (7%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (17%) | 1.9 (20%) | 3.4 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.5 (6%) | 0.4 (4%) | 0.9 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.5 | 2.6 | 54% | 11.1 pts | 39 pts |
| character | 4.2 | 1.5 | 69% | 11.9 pts | 50 pts |
| chariot | 3.2 | 2.9 | 56% | 16.8 pts | 54 pts |
| infantry | 8.6 | 4.9 | 69% | 9.0 pts | 78 pts |
| war machine | 10.5 | 12.9 | 55% | 31.4 pts | 330 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.5 | 4.1 | 2.8 |
| Charges that made contact a game | 1.0 | 2.6 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.17 contact (6 units) | 1.00 declared, 0.67 contact (6 units) | 0.67 declared, 0.42 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (5 units) | 1.00 declared, 1.00 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.13 contact (67 units) | 0.42 declared, 0.24 contact (71 units) | 0.31 declared, 0.19 contact (138 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (7 of 13) | 17% (1 of 6) | 0% (0 of 2) | 38% (8 of 21) |
| Character in a unit | 69% (9 of 13) | 67% (6 of 9) | - | 68% (15 of 22) |
| Character on its own | 86% (12 of 14) | 70% (7 of 10) | 45% (5 of 11) | 69% (24 of 35) |
| Chariot | 100% (1 of 1) | 70% (7 of 10) | - | 73% (8 of 11) |
| Infantry | 25% (3 of 12) | 40% (6 of 15) | 50% (1 of 2) | 34% (10 of 29) |
| Monster | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| War Machines | 68% (13 of 19) | 100% (2 of 2) | - | 71% (15 of 21) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (5 of 6); on the table 83% | 50% (51 of 102) | 70% | 64% (14 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 2.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (7 of 7); on the table 100% | 39% (14 of 36) | 62% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 50% (1 of 2); on the table 50% | - | 43% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 86% | 60% (18 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | 100% (2 of 2); on the table 100% | 75% (9 of 12) | 44% | 50% (4 of 8) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 80% | 38% (3 of 8) | 100% (1 of 1); 3.0 uses a game | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 65% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 75% (3 of 4); on the table 75% | 33% (4 of 12) | 42% | 63% (12 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (4 of 4); on the table 100% | - | 22% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h6-mine-0333a16-p2, 10 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (8) | 57% (4) | 52% (12) |
| ...free all their last turn and able to turn (per game) | 0.70 | 0.40 | 1.10 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.10 | 0.00 | 0.10 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.20 | 0.70 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.30 | 0.10 | 0.40 |

### Quality by phase: h6-mine-0333a16-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 53% (8 of 15) | 49% (18 of 37) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (42 of 117) | 50% (43 of 86) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (3 of 6) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 43% (3 of 7) |
| Strategy | Joined characters whose unit fought | 27% (6 of 22) | 40% (6 of 15) |
| Strategy | Lone characters that fought | 50% (13 of 26) | 44% (12 of 27) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 2.4 | 1.7 |
| Movement | Points that never moved of their own | 166.5 | 61.0 |
| Movement | Fights charged into per game | 1.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 10, net +373 | 5 of 23, net +30 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 10 | 3 of 23, net +77 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 10, net +32 | 5 of 23, net +80 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 10, net +110 | 4 of 23, net +111 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 6.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (50 of 94) | 58% (36 of 62) |
| Shooting | Points destroyed by shooting units | 135.9 | 49.8 |
| Shooting | War machine shots | 5.3 | 5.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (30 of 53) | 54% (28 of 52) |
| Shooting | Points destroyed by war machines | 33.5 | 73.2 |
| Magic | Magic missiles cast | 3.7 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 51% (19 of 37) | 50% (7 of 14) |
| Magic | Wounds caused by magic missiles | 9.9 | 2.3 |
| Magic | Wounds caused by other spells | 0.3 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 90.7 | 40.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.3 / 0.1 | 1.7 / 1.1 / 0.1 / 0.4 |
| Combat | Points destroyed in combat | 149.1 | 219.6 |
| Combat | Points run down | 57.5 | 27.8 |
| Combat | Net points per charged fight, damage counted | +125 | +103 |
| Combat | Net per 100 charger points, damage counted | +50.6 | +33.4 |
| Combat | First round won (charged fights) | 100% | 70% |
| Combat | Net points per charged fight | +134 | +82 |
| Combat | Net points per supported fight / lone fight | - / +134 | +254 / +56 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 10 | 8 of 23 |
| Game | Points lost | 533.9 | 511.5 |
| Game | VP from objectives | 672.0 | 739.0 |
| Game | Lone holders (player turns) | 4.1 | 2.3 |

- Mine won / drew / lost: 5 / 1 / 4 of 10 ended games (of 10); mean margin (Mine - Opponent) -82 VP
- The side that went first won 5 of 9 games with a winner
- Points traded per game (both sides' losses): 1045
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-mine-0333a16-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 31.5 | 1.2 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.6 | 8.5 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -17.0 | 43.0 | 0.0 | 0.4 | -81.1 | 42.9 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.6 | 0.0 | 15.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 103.5 | 0.0 | 0.9 | +0.0 | 70.2 | 13.0 |
| CANNON PLANNED TARGET | 4.9 | +129.4 | 258.9 | 61.5 | 4.3 | +165.0 | 159.2 | 102.5 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.0 | 0.0 | 0.0 | 0.2 | +0.0 | 31.9 | 0.0 |
| CAST JOB | 1.0 | +16.7 | 52.8 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.6 | +61.5 | 20.2 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.8 | +0.0 | 0.0 | 22.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +7.4 | 0.0 | 8.1 | 0.2 | +7.7 | 0.0 | 15.0 |
| CHAFF PASSED | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -1.8 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.3 | -462.2 | 0.0 | 77.5 | 6.5 | -293.5 | 0.0 | 200.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 24.8 | 0.0 | 0.6 | +0.0 | 27.6 | 6.0 |
| CHARGE NOW FIRST | 0.9 | +0.0 | 109.2 | 0.0 | 0.7 | +0.0 | 63.0 | 0.0 |
| CHARGER SLAIN LOST | 0.1 | -0.1 | 9.8 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -4.6 | 6.5 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.9 | +176.4 | 0.0 | 57.5 | 0.4 | +16.3 | 0.0 | 0.0 |
| COVER ONCE | 6.6 | -316.2 | 0.0 | 129.4 | 5.7 | -260.5 | 0.0 | 48.5 |
| DEPLOY BY FIGURES | 8.5 | -11.1 | 0.0 | 5.5 | 7.5 | -71.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 100.9 | 0.0 | 2.3 | +0.2 | 160.9 | 4.5 |
| FALLBACK BY WORTH | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.5 | +177.3 | 0.0 | 124.6 | 15.5 | +206.5 | 0.0 | 39.4 |
| FEATURE BUFFS | 2.0 | +58.8 | 0.0 | 45.2 | 0.8 | +23.2 | 0.0 | 22.4 |
| FIGHT TO THE END | 0.3 | +0.5 | 48.3 | 0.0 | 0.7 | +23.7 | 93.8 | 15.1 |
| FIRE AND FLEE | - | - | - | - | 0.2 | +8.6 | 0.0 | 41.6 |
| FIRE IN ORDER | 0.4 | +0.0 | 16.2 | 42.3 | 0.3 | +0.0 | 11.0 | 34.9 |
| FIVE ACTION | 44.3 | +2645.4 | 942.2 | 493.9 | 48.6 | +3602.9 | 654.6 | 580.4 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 126.0 | 3.9 | +0.0 | 0.0 | 50.5 |
| FOLLOW UP WEIGHED | 0.6 | +23.4 | 0.0 | 0.0 | 0.8 | +50.4 | 0.0 | 22.1 |
| FOUR ROUNDS | 1.5 | +56.6 | 233.1 | 0.0 | 3.4 | +215.5 | 241.4 | 25.6 |
| FRIEND CHARGES FIRST | 0.1 | -3.8 | 0.0 | 0.0 | 0.2 | -33.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -1.5 | 0.0 | 0.0 | 0.2 | -14.2 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.5 | 7.5 | 0.0 | 0.2 | -0.4 | 23.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.2 | +2.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +1.8 | 74.9 | 31.0 | 0.8 | +6.1 | 17.8 | 26.5 |
| GUN MASK | 0.1 | +3.7 | 0.0 | 0.0 | 1.6 | +45.2 | 0.0 | 16.2 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 29.1 | 0.8 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.7 | +0.0 | 0.0 | 34.1 | 2.0 | +0.0 | 0.0 | 62.5 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 6.5 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +15.8 | 0.0 | 6.0 |
| HIS CHARGE LIST | 3.6 | +0.0 | 0.0 | 111.9 | 1.4 | +0.0 | 0.0 | 9.8 |
| HIS LEGAL MOVES | 2.2 | +0.0 | 0.0 | 0.0 | 5.2 | +0.0 | 0.0 | 64.4 |
| HIS MOVE AND SHOT | 1.8 | -25.5 | 0.0 | 52.8 | 1.4 | -32.0 | 0.0 | 25.2 |
| HIS RANDOM MOVE | - | - | - | - | 5.2 | +0.0 | 0.0 | 6.0 |
| HIS SHOT LIST | 16.9 | +967.5 | 0.0 | 177.7 | 20.2 | +1157.9 | 0.0 | 231.1 |
| HIS TURN DENIED | 0.7 | +44.3 | 104.8 | 0.0 | 1.5 | +72.7 | 160.6 | 19.6 |
| HOLD ODDS | 11.6 | +0.0 | 0.0 | 149.1 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.0 | +1245.9 | 0.0 | 144.8 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +175.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.4 | -44.9 | 211.0 | 0.0 | 2.8 | -104.8 | 176.1 | 10.5 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.5 |
| HUNT IN PAIRS | 0.2 | +2.8 | 0.0 | 0.0 | 1.6 | +65.4 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +27.8 | 9.5 | 9.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +39.6 | 20.5 | 4.5 |
| IDLE COST | 3.5 | -38.3 | 0.0 | 38.7 | 10.7 | -192.7 | 0.0 | 105.5 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +1.2 | 0.0 | 22.0 | - | - | - | - |
| LANE BY FIGURES | 0.2 | +2.6 | 0.0 | 0.0 | 0.8 | +34.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.5 | +0.0 | 88.2 | 119.5 | 3.0 | +0.0 | 56.5 | 153.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +73.9 | 0.0 | 0.0 | 0.4 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.5 | 22.1 | 0.0 | 0.1 | +4.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.5 | +44.4 | 0.0 | 0.0 | 1.1 | +20.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.4 | +35.8 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| MARCH CHECK | 1.6 | +161.1 | 0.0 | 35.3 | 0.9 | +66.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +11.9 | 0.0 | 8.1 | 0.6 | +15.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.5 | +116.4 | 0.0 | 53.7 | 4.1 | +95.1 | 0.0 | 8.6 |
| MISSILES IN THE MOVE | 5.1 | +235.1 | 0.0 | 41.8 | 2.6 | +38.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.7 | +166.8 | 0.0 | 49.9 | 3.5 | +33.8 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.5 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -31.4 | 0.0 | 71.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.3 | +331.4 | 0.0 | 0.0 | 3.7 | +732.3 | 0.0 | 18.6 |
| MOVES UNITS SPELL | 0.2 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +238.9 | 0.0 | 65.5 | 5.2 | +318.3 | 0.0 | 101.3 |
| NEXT CHARGE BY LIST | 4.0 | -56.1 | 18.6 | 22.3 | 6.0 | -166.2 | 5.5 | 53.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 9.6 | -659.7 | 23.0 | 85.0 |
| NO DOUBLE ROUNDS | 1.4 | -32.8 | 214.1 | 0.0 | 3.0 | -73.2 | 234.9 | 25.6 |
| NOT TURNED | 0.3 | +5.3 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | 1.6 | -1.1 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -15.3 | 0.0 | 0.0 | 0.7 | -20.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 1.8 | +0.0 | 0.0 | 21.7 | 1.4 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.9 | -117.5 | 0.0 | 126.7 | 4.3 | -158.1 | 0.0 | 49.2 |
| ONE OBJECTIVE FORMULA | 4.7 | +22.4 | 0.0 | 72.8 | 4.7 | +47.7 | 0.0 | 156.1 |
| ONE TARGET A SHOOTER | 13.6 | +557.2 | 0.0 | 170.4 | 20.5 | +602.8 | 0.0 | 210.1 |
| OPENS A LANE | 0.3 | +0.2 | 0.0 | 0.0 | 0.4 | +3.9 | 13.7 | 0.0 |
| OPENS UP | 0.2 | +12.7 | 7.5 | 0.0 | 0.1 | +5.1 | 11.0 | 0.0 |
| OVERRUNS AWAY | 0.1 | +5.4 | 0.0 | 0.0 | 0.2 | +34.6 | 29.5 | 0.0 |
| PATHS CROSS | 2.9 | +126.8 | 0.0 | 20.2 | 5.5 | +347.9 | 0.0 | 5.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.7 | +747.7 | 527.9 | 641.7 | 43.6 | +544.6 | 353.8 | 867.9 |
| QUARTER ODDS | 7.4 | +515.5 | 203.9 | 83.8 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.2 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -17.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.9 | +103.2 | 0.0 | 42.7 | 2.2 | +102.8 | 0.0 | 25.4 |
| REDIRECT WEIGHED | - | - | - | - | 0.4 | +0.2 | 16.6 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -39.0 | 0.0 | 0.0 | 0.4 | -44.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +40.3 | 0.0 | 0.0 | 0.5 | +13.2 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +3.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +28.4 | 138.8 | 0.0 | 1.7 | +6.8 | 147.9 | 4.5 |
| RISK BY HIS FIGURE | 11.9 | -392.2 | 0.0 | 271.1 | 10.1 | -130.9 | 0.0 | 148.2 |
| RUN DOWN | 0.8 | -9.8 | 114.6 | 0.0 | 2.5 | -19.4 | 184.2 | 21.1 |
| SCOUT SPOT | 0.2 | +0.6 | 0.0 | 5.5 | 0.4 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 5.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 4.5 |
| SEARCH SPOT | 4.5 | +194.2 | 0.0 | 51.6 | 6.1 | +249.4 | 0.0 | 111.5 |
| SET UP TOGETHER | - | - | - | - | 0.6 | +51.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.4 | +42.8 | 0.0 | 22.0 | 0.3 | +16.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.9 | +89.6 | 113.9 | 6.5 | 0.5 | +16.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.3 | 49.9 | 0.0 | 0.6 | -44.4 | 93.2 | 41.1 |
| SHOT RISK POINTS | 9.2 | +173.4 | 0.0 | 177.1 | 12.5 | +18.5 | 0.0 | 231.9 |
| SHOTS IN THE MOVE | 15.1 | +696.6 | 0.0 | 264.8 | 13.8 | +545.8 | 0.0 | 318.2 |
| SPELL SETS UP CHARGE | 0.6 | +178.6 | 0.0 | 22.0 | 0.3 | +16.0 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +5.9 | 6.5 | 71.0 | 0.6 | +11.9 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | 0.2 | +4.9 | 65.1 | 0.0 | 0.4 | +17.9 | 65.6 | 15.1 |
| STAND AND SHOOT | 0.4 | -12.4 | 67.7 | 0.0 | 0.8 | -7.7 | 101.0 | 15.1 |
| STANDS FOR A REASON | 0.3 | +0.0 | 16.4 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 22.0 | +0.0 | 692.7 | 218.4 | 14.1 | +0.0 | 365.8 | 207.8 |
| STAY WORTH | 16.8 | +117.8 | 361.4 | 113.4 | 17.7 | +234.8 | 242.8 | 369.5 |
| STOPS | - | - | - | - | 0.3 | +1.6 | 20.5 | 4.5 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 1.0 | +0.0 | 92.3 | 0.0 | 0.6 | +0.0 | 59.9 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +21.4 | 0.0 | 9.8 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 11.7 | 5.9 | +0.0 | 0.0 | 25.2 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -68.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.5 | +44.7 | 57.9 | 0.0 | 0.8 | +62.8 | 45.5 | 0.0 |
| TIME ON OUR SIDE | 24.3 | +338.7 | 59.3 | 211.6 | 11.9 | +208.3 | 0.0 | 207.8 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 0.8 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 18.6 |
| WALK PROMISE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.9 | +0.0 | 38.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.1 | +22.4 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.2 | +1.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +12.8 | 11.0 | 0.0 |
| WIDER SPREAD | 0.8 | -3.1 | 157.9 | 0.0 | 1.9 | -2.0 | 157.1 | 25.6 |
| WOUNDS ON THE RANKS | 1.6 | +153.1 | 0.0 | 52.8 | 2.8 | +113.2 | 0.0 | 113.6 |

### Rule changes: h6-mine-0333a16-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 120 | 120 | 111 | 11.10 | +6975 | +62.8 |
| HIS SHOT LIST | 371 | 371 | 102 | 10.20 | +3139 | +30.8 |
| SEARCH SPOT | 106 | 106 | 100 | 10.00 | +4436 | +44.4 |
| DEPLOY BY FIGURES | 160 | 160 | 98 | 9.80 | +1363 | +13.9 |
| PATHS CROSS | 84 | 84 | 84 | 8.40 | +4747 | +56.5 |
| ONE TARGET A SHOOTER | 341 | 341 | 83 | 8.30 | +1148 | +13.8 |
| TIME ON OUR SIDE | 362 | 327 | 78 | 7.80 | +230 | +3.0 |
| FIVE ACTION | 929 | 928 | 77 | 7.70 | +4353 | +56.5 |
| LEGAL CHARGES ONLY | 75 | 75 | 75 | 7.50 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 60 | 60 | 45 | 4.50 | +6014 | +133.6 |
| SHOT RISK POINTS | 217 | 217 | 42 | 4.20 | +2119 | +50.5 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 3.50 | +0 | +0.0 |
| MAX FOR POSITIONING | 106 | 105 | 28 | 2.80 | +85 | +3.0 |
| HARD STAY DROPPED | 26 | 26 | 26 | 2.60 | +0 | +0.0 |
| COVER ONCE | 123 | 95 | 24 | 2.40 | +396 | +16.5 |
| FOUR ROUNDS | 49 | 48 | 22 | 2.20 | +1013 | +46.0 |
| CANNON SIGHT KEPT | 17 | 17 | 17 | 1.70 | +0 | +0.0 |
| IDLE COST | 142 | 113 | 17 | 1.70 | +195 | +11.5 |
| MARCH CHECK | 25 | 25 | 17 | 1.70 | +460 | +27.1 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 1.60 | +0 | +0.0 |
| FALLS SHORT | 230 | 200 | 15 | 1.50 | +143 | +9.5 |
| FOLLOW UP WEIGHED | 14 | 14 | 14 | 1.40 | +739 | +52.8 |
| NEXT OBJECTIVE NEARER | 96 | 96 | 14 | 1.40 | +147 | +10.5 |
| CANNON PLANNED TARGET | 92 | 92 | 13 | 1.30 | -76 | -5.9 |
| RISK BY ARC | 28 | 27 | 13 | 1.30 | +217 | +16.7 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.20 | +1114 | +92.9 |
| MANOEUVRE | 26 | 26 | 12 | 1.20 | +657 | +54.8 |
| MISSILES IN THE MOVE | 77 | 53 | 12 | 1.20 | +421 | +35.1 |
| RESERVE FALL BACK | 12 | 12 | 12 | 1.20 | +535 | +44.6 |
| TIED UP BY THE SUM | 13 | 13 | 12 | 1.20 | +259 | +21.6 |
| WOUNDS ON THE RANKS | 44 | 44 | 12 | 1.20 | +718 | +59.8 |
| CHARGE LOSSES | 118 | 118 | 11 | 1.10 | +483 | +43.9 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 11 | 1.10 | +92 | +8.3 |
| SHOTS IN THE MOVE | 289 | 264 | 11 | 1.10 | +896 | +81.5 |
| LANE BY FIGURES | 10 | 10 | 10 | 1.00 | +369 | +36.9 |
| NEXT CHARGE BY LIST | 100 | 100 | 10 | 1.00 | +526 | +52.6 |
| OFF BEST | 10 | 10 | 10 | 1.00 | -362 | -36.2 |
| CHARGE NOT DECLARED | 9 | 9 | 9 | 0.90 | -672 | -74.7 |
| RISK BY HIS FIGURE | 220 | 220 | 9 | 0.90 | +745 | +82.8 |
| NEARER NOT NEEDED | 105 | 103 | 8 | 0.80 | +180 | +22.5 |
| QUARTER ODDS | 74 | 74 | 8 | 0.80 | +353 | +44.1 |
| REDIRECT COUNTER | 41 | 37 | 8 | 0.80 | +433 | +54.1 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.70 | +0 | +0.0 |
| FIRE IN ORDER | 7 | 7 | 7 | 0.70 | +0 | +0.0 |
| HIS TURN DENIED | 22 | 22 | 7 | 0.70 | +690 | +98.6 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.70 | +0 | +0.0 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.70 | +442 | +63.1 |
| ONE OBJECTIVE FORMULA | 94 | 76 | 7 | 0.70 | +238 | +34.0 |
| GUN MASK | 17 | 17 | 6 | 0.60 | +250 | +41.7 |
| SCOUT WAITS | 6 | 6 | 6 | 0.60 | +0 | +0.0 |
| STAY WORTH | 345 | 331 | 6 | 0.60 | +267 | +44.6 |
| CAST JOB | 11 | 11 | 5 | 0.50 | +30 | +5.9 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.50 | +0 | +0.0 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.50 | +0 | +0.0 |
| ONE FIGHT FORMULA | 92 | 53 | 5 | 0.50 | +13 | +2.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 5 | 0.50 | +74 | +14.7 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 0.50 | +13 | +2.6 |
| CASTING BLOCK | 6 | 6 | 4 | 0.40 | +210 | +52.4 |
| FEATURE BUFFS | 28 | 28 | 4 | 0.40 | +63 | +15.8 |
| HOLDER AT DEPLOYMENT | 9 | 9 | 4 | 0.40 | +333 | +83.2 |
| HUNT IN PAIRS | 18 | 9 | 4 | 0.40 | +53 | +13.2 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.40 | +206 | +51.5 |
| CHARGE NOW FIRST | 16 | 16 | 3 | 0.30 | -102 | -34.0 |
| HIS MOVE AND SHOT | 32 | 32 | 3 | 0.30 | +16 | +5.5 |
| MISSILES NEXT TURN | 92 | 61 | 3 | 0.30 | +5 | +1.6 |
| SURE REACH TOGETHER | 7 | 7 | 3 | 0.30 | +46 | +15.5 |
| WHOLE FIGHT GAIN | 3 | 3 | 3 | 0.30 | +28 | +9.4 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.20 | +22 | +11.1 |
| CHAFF PASSED | 2 | 2 | 2 | 0.20 | -28 | -13.8 |
| FALLBACK BY WORTH | 7 | 7 | 2 | 0.20 | +6 | +3.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.20 | +86 | +43.1 |
| HONEST WORTH | 42 | 41 | 2 | 0.20 | +36 | +17.9 |
| KEEP FALLS | 2 | 2 | 2 | 0.20 | +31 | +15.6 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.20 | +110 | +55.1 |
| OPENS UP | 3 | 3 | 2 | 0.20 | +43 | +21.5 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.20 | +108 | +54.2 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.20 | -0 | -0.2 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.20 | +236 | +117.9 |
| WIDER SPREAD | 27 | 27 | 2 | 0.20 | +3 | +1.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.10 | +26 | +26.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.10 | -6 | -5.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.10 | +26 | +26.0 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.10 | -10 | -10.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.10 | -7 | -7.1 |
| FIGHT TO THE END | 10 | 10 | 1 | 0.10 | +19 | +18.9 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.10 | +13 | +13.4 |
| LONG SHOT | 4 | 3 | 1 | 0.10 | +13 | +12.7 |
| MARCH ODDS | 1 | 1 | 1 | 0.10 | -44 | -44.5 |
| MOVE SPELL IN RANGE | 5 | 5 | 1 | 0.10 | +14 | +13.5 |
| OPENS A LANE | 7 | 3 | 1 | 0.10 | +3 | +3.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.10 | -2 | -1.6 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.10 | +35 | +35.5 |
| STOPS | 3 | 3 | 1 | 0.10 | +2 | +2.5 |
| WAR ENGINE JOBS | 9 | 9 | 1 | 0.10 | -5 | -4.6 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.10 | +1 | +0.9 |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 14 | 14 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 23 | trace | - | - | - | - |
| CHARACTER GUNS | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 23 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 33 | 32 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 87 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 25 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 37 | 37 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 50 | 50 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 74 | 74 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 52 | 52 | 0 | 0.00 | - | - |
| HOLD ODDS | 116 | 116 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 44 | 43 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 32 | 32 | 0 | 0.00 | - | - |
| PLAN RESULT | 833 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 33 | 33 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 6 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SHOT OR CHARGE | 9 | 9 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 12 | 12 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 361 | 361 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 16 | 16 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 89 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 13 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 26 | 26 | 0 | 0.00 | - | - |
| WALK PROMISE | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: h6-mine-0333a16-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.30 | 0.60 | 74.7 |
| HOLDER ASSIGNMENT | rule | 0.70 | - | 14.2 |
| JOB FIRST | gate | 0.10 | 0.60 | 42.8 |
| PATHS CROSS | rule | 0.10 | 0.60 | 25.6 |
| CHARGE NOW FIRST | rule | 0.20 | 0.10 | 34.0 |
| CANNON PLANNED TARGET | rule | 0.20 | - | 85.0 |
| CHAFF PASSED | rule | 0.10 | 0.10 | 13.8 |
| FALLBACK | gate | 0.10 | 0.10 | 2.9 |
| BEST PRIZE | rule | - | 0.10 | 5.6 |
| CARRIES OUT SET-UP | rule | 0.10 | - | 10.2 |
| CATCH ODDS | rule | 0.10 | - | 7.1 |
| DEPLOY BY FIGURES | rule | - | 0.10 | 13.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.10 | - | 56.5 |
| MARCH ODDS | rule | 0.10 | - | 44.5 |
| PIVOT GUARDS FLANK | rule | 0.10 | - | 1.6 |
| WAR ENGINE JOBS | rule | 0.10 | - | 4.6 |

### Plans: h6-mine-0333a16-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 83% | 213 | 95 | 45% |
| Mine | join | 1.2 | 100% | 55 | 0 | 0% |
| Mine | move | 27.0 | 92% | 1764 | 0 | 0% |
| Mine | shoot | 10.1 | 54% | 582 | 652 | 112% |
| Mine | support | 0.2 | 100% | 12 | 0 | 0% |
| Opponent | charge | 2.7 | 78% | 328 | 230 | 70% |
| Opponent | join | 1.1 | 100% | 50 | 0 | 0% |
| Opponent | move | 32.1 | 96% | 2006 | 0 | 0% |
| Opponent | shoot | 7.3 | 60% | 428 | 315 | 74% |
| Opponent | support | 0.4 | 75% | 0 | 0 | - |

### Packages: hunt the guns, h6-mine-0333a16-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 85 |
| Opponent | 0.3 | 3 | 0 | 67% | 67% | 0% | 2.0 | 132 | 93 | 67% | 34 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 121 | 70 | 50% | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 153 | 139 | 100% | 0 |

### Battle groups: h6-mine-0333a16-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 53% | 80% | 0% | - | 0% | 10% | 0% | 90% | 0% |
| Opponent | REDIRECT COUNTER | 2.2 | 18% | 75% | 25% | 0% | 33% | 0% | 33% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-mine-0333a16-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 8 (9) | 8 | 0 | 59 | 56% | 3.0 | 17 (4) | 0 (3) | 0 (2) | 13 (6) | 0 (3) |
| Mine | Character | 45 | 33 (45) | 33 | 0 | 26 | 18% | 2.4 | 36 (27) | 41 (8) | 44 (5) | 50 (24) | 21 (16) |
| Mine | Clean-up | 12 | 67 (12) | 17 | 49 | 17 | 75% | 2.7 | 89 (5) | 68 (4) | 34 (3) | 112 (6) | 20 (6) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 75 | 100% | - | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 27 | 48 (27) | 21 | 28 | 25 | 30% | 2.8 | 71 (8) | 47 (15) | 0 (4) | 73 (14) | 23 (13) |
| Mine | Holder | 9 | 174 (9) | 53 | 121 | 18 | 67% | 4.3 | 239 (4) | 182 (3) | 0 (1) | 205 (4) | 172 (4) |
| Mine | Shooter | 3 | 46 (3) | 0 | 46 | 100 | 0% | 1.3 | - | 69 (2) | 0 (1) | 69 (2) | 0 (1) |
| Mine | War machine | 18 | 16 (18) | 16 | 0 | 46 | 6% | 1.6 | 7 (9) | 34 (6) | 0 (3) | 0 (2) | 19 (16) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 36 | 67% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Chaff | 17 | 111 (17) | 26 | 85 | 39 | 47% | 2.3 | 129 (5) | 57 (5) | 136 (7) | 93 (14) | 189 (3) |
| Opponent | Character | 34 | 27 (34) | 27 | 0 | 20 | 44% | 2.9 | 25 (10) | 25 (13) | 41 (7) | 43 (16) | 14 (14) |
| Opponent | Clean-up | 6 | 30 (6) | 0 | 30 | 54 | 83% | 2.0 | 88 (1) | 25 (3) | 0 (2) | 46 (4) | 0 (2) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 17 | 41 (17) | 11 | 30 | 26 | 29% | 3.8 | 78 (8) | 21 (9) | - | 47 (11) | 32 (6) |
| Opponent | Hammer | 5 | 27 (5) | 0 | 27 | 18 | 40% | 4.0 | - | 28 (4) | 24 (1) | 28 (4) | 24 (1) |
| Opponent | Holder | 7 | 36 (7) | 0 | 36 | 0 | 71% | 5.0 | 0 (1) | 53 (5) | 0 (1) | - | 36 (7) |
| Opponent | Shooter | 9 | 129 (9) | 49 | 80 | 53 | 0% | 1.7 | 209 (5) | 80 (3) | 0 (1) | 157 (7) | 59 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 45 (15) | 45 | 0 | 47 | 0% | 1.9 | 44 (4) | 51 (10) | 0 (1) | 44 (2) | 46 (13) |
| Opponent | Wizard | 8 | 0 (8) | 0 | 0 | 32 | 50% | 1.8 | 0 (1) | 0 (4) | 0 (2) | 0 (4) | 0 (3) |

### Charged fights: h6-mine-0333a16-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 134 | 15 | 0.2 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| Mine | Chaos Dwarfs | 4 | 250 | 296 | 2.0 | 1.0 | 148 | 0 | +148 | 2 of 8 | 8 of 8 | - | +148 |
| Mine | Dwarfen Mountain Holds | 2 | 532 | 49 | 0.5 | 1.0 | 98 | 0 | +98 | 0 of 1 | 1 of 1 | - | +98 |
| **Mine** | all armies | 10 | 260 | 134 | 1.0 | 1.0 | 134 | 0 | +134 | 2 of 10 | 10 of 10 | - | +134 |
| Opponent | Empire of Man | 3 | 318 | 49 | 1.0 | 1.0 | 49 | 0 | +49 | 0 of 3 | 2 of 3 | - | +49 |
| Opponent | Grand Cathay | 1 | 177 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Opponent | High Elf Realms | 1 | 357 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 150 | 420 | 3.0 | 1.0 | 140 | 0 | +140 | 2 of 3 | 2 of 3 | - | +140 |
| Opponent | Vampire Counts | 3 | 0 | 309 | 3.0 | 1.2 | 103 | 20 | +83 | 3 of 9 | 7 of 9 | +237 | +39 |
| Opponent | Warriors of Chaos | 1 | 0 | 574 | 4.0 | 1.2 | 144 | 0 | +144 | 1 of 4 | 3 of 4 | +289 | +95 |
| **Opponent** | all armies | 10 | 164 | 207 | 2.3 | 1.1 | 90 | 8 | +82 | 8 of 23 | 16 of 23 | +254 | +56 |

### Effective charges: h6-mine-0333a16-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 8 | 2 (net +373) | 0 | 0 | 0 | 3 (net +32) | 3 (net +113) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +98) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 0 | 1 (net +65) | 2 (net +40) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +0) | 0 | 0 | 2 (net +210) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 9 | 1 (net -135) | 0 | 2 (net +115) | 1 (net -45) | 4 (net +84) | 1 (net +364) | 0 | 22% (2 of 9) |
| Opponent | Warriors of Chaos | 4 | 2 (net +142) | 0 | 0 | 1 (net +289) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: h6-mine-0333a16-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 302 | 276 | +373 | 373 | 0 | +373 | +123.5 |
| Mine | 76-89% | 1 | 52 | 60 | +60 | 60 | 0 | +60 | +115.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 205 | 128 | +110 | 110 | 11 | +98 | +47.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 329 | 90 | +32 | 32 | 16 | +16 | +4.9 |
| Mine | All fights | 10 | 246 | 139 | +134 | 134 | 9 | +125 | +50.6 |
| Opponent | Long shot (under 50%) | 5 | 120 | 342 | +30 | 123 | 48 | +75 | +62.2 |
| Opponent | Effective (55-75%) | 3 | 395 | 231 | +77 | 143 | 59 | +84 | +21.2 |
| Opponent | 76-89% | 6 | 394 | 169 | +111 | 142 | 18 | +124 | +31.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 325 | 149 | +111 | 202 | 30 | +173 | +53.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 336 | 80 | +80 | 80 | 16 | +64 | +19.0 |
| Opponent | All fights | 23 | 310 | 192 | +82 | 135 | 32 | +103 | +33.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-mine-0333a16-p2 | move | 55 | 7 (13%) | 5 (9%) | 5 (9%) | 43 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

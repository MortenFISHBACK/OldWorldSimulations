# Doctrine scorecard: h6-opp-0333a16-p3

### Scorecard: h6-opp-0333a16-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 170 |
| L0211 | 1 | 1 | Opponent | yes | 15 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | yes | 9 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 8 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0313 | 1 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0330 | 6 | 1 | Opponent | no | 14 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 40% | 4.4 | 3.3 | 1.2 | 2.0 | 0.0 | 0.0 | 0.0 | 98.3 |
| **Average** | | | Opponent | 40% | 9.4 | 2.2 | 1.2 | 0.7 | 0.0 | 0.0 | 0.0 | 11.7 |

### KPIs: h6-opp-0333a16-p3

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 6 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (9 of 28) | 7% (2 of 28) | 20% (11 of 56) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 100% | 100% (4 of 4); on the table 100% | 80% (4 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 33% | 50% (2 of 4); on the table 50% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 50% | - | 25% (1 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 33% (2 of 6); on the table 67% | 71% (5 of 7); on the table 71% | 54% (7 of 13); on the table 69% |
| Magic missiles tried each own turn | 50%+ | 41% (52 of 126) | 33% (18 of 54) | 39% (70 of 180) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (52 of 113) | 46% (18 of 39) | 46% (70 of 152) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (4 of 10) | - | 40% (4 of 10) |
| Points that never fought | lower | 52% (6031 of 11566) | 57% (6795 of 11998) | 54% (12826 of 23564) |
|   infantry points that never fought | lower | 58% (2133 of 3676) | 81% (1158 of 1428) | 64% (3291 of 5104) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (23 of 38) | 48% (21 of 44) | 54% (44 of 82) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 2.8 uses a game | 100% (5 of 5); 3.0 uses a game | 91% (10 of 11); 2.9 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 1.2 uses a game | 33% (1 of 3); 0.2 uses a game | 73% (8 of 11); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (4818 of 8400) | 45% (4989 of 11046) | 50% (9807 of 19446) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.8 (55%) | 0.8 (14%) | 7.7 (42%) |
| MARCHED: its unit marched | 2.2 (18%) | 2.5 (42%) | 4.7 (25%) |
| IN COMBAT: engaged in combat | 0.5 (4%) | 1.5 (25%) | 2.0 (11%) |
| REAR RANK: in a rear rank | 1.0 (8%) | 0.0 (0%) | 1.0 (5%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| GONE: slain | 1.7 (14%) | 0.7 (11%) | 2.3 (13%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (1%) | 0.0 (0%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 3.0 | 2.0 | 11.7 | 0.5 | 1.3 |
| not cast | 3.5 | 6.5 | 4.0 | 18.3 | 1.5 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.8 (59%) | 0.0 (0%) | 7.7 (42%) | 0.7 (44%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (25%) | 0.3 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.5 (8%) | 0.2 (4%) | 2.0 (11%) | 0.5 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 1.0 (25%) | 1.0 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.8 (24%) | 0.0 (0%) | 1.2 (29%) | 2.3 (13%) | 0.0 (0%) | 2.7 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (71%) | 1.7 (26%) | 1.7 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.8 a game | 0.2 a game | 1.5 a game |
| stood (cast and not dispelled) | 41% (7 of 17) | 100% (1 of 1) | 44% (8 of 18) |
| the unit moved after it | 29% (2 of 7) | 100% (1 of 1) | 38% (3 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it fought by the end of its next turn | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 71% (5 of 7) | 100% (1 of 1) | 75% (6 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (45 of 80) | 49% (39 of 79) | 53% (84 of 159) |
|   cavalry | - | 57% (4 of 7) | 57% (4 of 7) |
|   character | - | 10% (1 of 10) | 10% (1 of 10) |
|   chariot | 48% (10 of 21) | 60% (3 of 5) | 50% (13 of 26) |
|   infantry | 47% (9 of 19) | 67% (16 of 24) | 58% (25 of 43) |
|   war machine | 65% (26 of 40) | 45% (15 of 33) | 56% (41 of 73) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (17%) | 1.7 (25%) | 2.7 (21%) |
| CHARGED: it charged | 0.2 (3%) | 0.7 (10%) | 0.8 (7%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.3 (5%) | 0.7 (5%) |
| MOVED: a war machine that moved | 1.7 (29%) | 2.8 (42%) | 4.5 (36%) |
| NO TARGET IN RANGE | 1.5 (26%) | 1.0 (15%) | 2.5 (20%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (11%) | 0.0 (0%) | 0.7 (5%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| OTHER BAR | 0.5 (9%) | 0.0 (0%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.3 | 50% | 7.0 pts | 5 pts |
| character | 0.2 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.2 | 2.0 | 31% | 44.1 pts | 96 pts |
| infantry | 6.8 | 2.3 | 73% | 7.4 pts | 50 pts |
| war machine | 6.8 | 9.0 | 63% | 48.0 pts | 328 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.8 | 2.4 |
| Charges that made contact a game | 1.8 | 2.2 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.80 declared, 0.60 contact (5 units) | 0.44 declared, 0.33 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 3.00 contact (1 units) | 3.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.28 contact (39 units) | 0.34 declared, 0.24 contact (29 units) | 0.32 declared, 0.26 contact (68 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | 33% (2 of 6) | 36% (4 of 11) |
| Character in a unit | 82% (9 of 11) | 77% (10 of 13) | 50% (1 of 2) | 77% (20 of 26) |
| Character on its own | 0% (0 of 1) | 40% (2 of 5) | 25% (1 of 4) | 30% (3 of 10) |
| Chariot | 100% (2 of 2) | 75% (3 of 4) | - | 83% (5 of 6) |
| Infantry | 20% (1 of 5) | 11% (1 of 9) | - | 14% (2 of 14) |
| Monster | 0% (0 of 2) | 0% (0 of 1) | - | 0% (0 of 3) |
| War Machines | 80% (8 of 10) | 100% (2 of 2) | - | 83% (10 of 12) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 40% (2 of 5); on the table 60% | 41% (42 of 102) | 50% | 59% (13 of 22) | 83% (5 of 6); 4.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 2 | 0% (0 of 1); on the table 100% | 42% (10 of 24) | 56% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Grand Cathay | 2 | 50% (1 of 2); on the table 50% | 33% (12 of 36) | 52% | 50% (8 of 16) | 100% (4 of 4); 6.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 83% | 38% (3 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 80% (4 of 5); on the table 80% | 50% (6 of 12) | 51% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (h6-opp-0333a16-p3, 6 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (6) | 50% (4) | 56% (10) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.67 | 1.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.00 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.50 | 1.17 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 0.00 | 0.17 |

### Quality by phase: h6-opp-0333a16-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 92% (11 of 12) | 35% (6 of 17) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (21 of 66) | 44% (17 of 39) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 43% (3 of 7) |
| Strategy | Joined characters whose unit fought | 45% (10 of 22) | 36% (5 of 14) |
| Strategy | Lone characters that fought | 25% (2 of 8) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 0.7 |
| Movement | Points that never moved of their own | 98.3 | 11.7 |
| Movement | Fights charged into per game | 1.5 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 9, net -72 | 2 of 11, net -136 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 1 of 11, net +230 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 9 | 3 of 11, net +165 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 9, net +10 | 3 of 11, net +180 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.3 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 80% (16 of 20) | 38% (10 of 26) |
| Shooting | Points destroyed by shooting units | 66.7 | 14.2 |
| Shooting | War machine shots | 4.3 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (13 of 26) | 60% (9 of 15) |
| Shooting | Points destroyed by war machines | 49.5 | 51.7 |
| Magic | Magic missiles cast | 2.7 | 2.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (8 of 16) | 0% (0 of 13) |
| Magic | Wounds caused by magic missiles | 5.3 | 4.2 |
| Magic | Wounds caused by other spells | 0.8 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 31.8 | 91.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.0 / 0.5 / 0.0 | 0.2 / 1.7 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 75.2 | 273.0 |
| Combat | Points run down | 53.8 | 8.7 |
| Combat | Net points per charged fight, damage counted | +18 | +107 |
| Combat | Net per 100 charger points, damage counted | +6.7 | +29.5 |
| Combat | First round won (charged fights) | 56% | 83% |
| Combat | Net points per charged fight | -11 | +94 |
| Combat | Net points per supported fight / lone fight | -274 / +22 | +140 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 9 | 6 of 12 |
| Game | Points lost | 506.2 | 331.5 |
| Game | VP from objectives | 715.0 | 933.3 |
| Game | Lone holders (player turns) | 4.4 | 9.4 |

- Mine won / drew / lost: 1 / 2 / 3 of 6 ended games (of 6); mean margin (Mine - Opponent) -385 VP
- The side that went first won 2 of 4 games with a winner
- Points traded per game (both sides' losses): 838
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h6-opp-0333a16-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +5.5 | 0.0 | 0.0 | 0.3 | +84.2 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 76.7 | 0.8 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.7 | 0.0 | 10.8 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.2 | -3.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -2.9 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.5 | +15.0 | 0.0 | 50.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 182.8 | 38.3 | 0.2 | +0.0 | 38.3 | 0.0 |
| CANNON PLANNED TARGET | 3.8 | +10.5 | 182.8 | 138.3 | 2.3 | +44.8 | 52.5 | 0.0 |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.7 | +28.1 | 66.7 | 41.8 | 0.2 | +3.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.5 | +107.7 | 63.7 | 0.0 | 0.3 | +5.8 | 10.8 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 118.3 | 0.2 | +0.0 | 0.0 | 66.7 |
| CHAFF IN THE MOVE | 0.7 | +30.3 | 0.0 | 28.3 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.5 | -1.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.8 | -105.0 | 0.0 | 10.8 | 5.8 | -304.8 | 0.0 | 182.8 |
| CHARGE NOT DECLARED | 1.0 | +0.0 | 31.8 | 31.5 | 0.3 | +0.0 | 90.0 | 0.0 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 57.0 | 0.0 | 1.3 | +0.0 | 166.7 | 28.8 |
| CHARGER SLAIN LOST | 0.8 | -80.1 | 25.0 | 31.5 | - | - | - | - |
| CHEAP HELPER | 0.3 | +0.0 | 0.0 | 8.7 | - | - | - | - |
| CHEAPEST HOLDER | 0.3 | -4.8 | 25.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.3 | +589.8 | 0.0 | 59.2 | 0.2 | +66.6 | 66.7 | 66.7 |
| COVER ONCE | 4.8 | -678.4 | 0.0 | 140.3 | 5.2 | -201.7 | 0.0 | 104.5 |
| DEPLOY BY FIGURES | 7.7 | +61.9 | 0.0 | 0.0 | 5.8 | -31.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +5.1 | 38.3 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +10.7 | 6.8 | 27.7 | 1.8 | +13.5 | 158.3 | 28.8 |
| FALLBACK BY WORTH | 0.3 | +6.0 | 0.0 | 19.2 | - | - | - | - |
| FALLS SHORT | 7.5 | +157.0 | 0.0 | 46.7 | 13.2 | +285.1 | 0.0 | 246.2 |
| FEATURE BUFFS | 4.0 | +113.8 | 0.0 | 13.7 | 0.8 | +20.8 | 0.0 | 0.0 |
| FIGHT LIFT | 0.2 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +0.8 | 31.8 | 0.0 | 0.8 | +69.2 | 67.5 | 28.8 |
| FIRE IN ORDER | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 42.5 | +2106.1 | 910.7 | 531.8 | 35.2 | +3564.6 | 498.3 | 563.8 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 81.0 | 5.3 | +0.0 | 0.0 | 95.2 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +198.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +210.1 | 57.0 | 45.0 | 2.7 | +388.0 | 281.7 | 45.2 |
| FRIEND SHOOTS FIRST | 0.7 | -5.8 | 0.0 | 51.7 | 0.3 | -15.4 | 0.0 | 66.7 |
| GIVES UP | - | - | - | - | 0.5 | -11.2 | 0.0 | 0.0 |
| GROUND FLIERS | 0.2 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.7 | +1.3 | 0.0 | 51.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.3 | +19.4 | 0.0 | 50.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 3.0 | +0.0 | 0.0 | 13.5 | 1.7 | +0.0 | 0.0 | 105.5 |
| HELPER ALREADY ASKED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 13.5 | - | - | - | - |
| HIS CHARGE DENIED | 0.5 | +10.2 | 25.0 | 27.7 | 0.3 | +20.6 | 65.8 | 0.0 |
| HIS CHARGE LIST | 2.8 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 3.5 | +0.0 | 0.0 | 74.5 |
| HIS MOVE AND SHOT | 2.0 | -36.6 | 0.0 | 10.8 | 1.2 | -76.2 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 2.5 | +0.0 | 0.0 | 31.8 |
| HIS SHOT LIST | 15.8 | +462.0 | 0.0 | 44.3 | 17.5 | +712.3 | 0.0 | 324.3 |
| HIS TURN DENIED | 0.3 | +13.9 | 0.0 | 0.0 | 1.5 | +63.7 | 185.8 | 0.0 |
| HOLD ODDS | - | - | - | - | 14.8 | +0.0 | 0.0 | 34.8 |
| HOLDER ASSIGNMENT | - | - | - | - | 17.2 | +1627.1 | 0.0 | 34.8 |
| HOLDER AT DEPLOYMENT | 1.0 | +143.0 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -36.0 | 32.0 | 0.0 | 2.3 | -109.7 | 281.7 | 28.8 |
| IDLE COST | 2.5 | -18.8 | 0.0 | 10.8 | 5.3 | -172.8 | 0.0 | 197.7 |
| KEEP FALLS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 0.5 | +10.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.3 | +0.0 | 169.0 | 186.8 | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.7 | +141.1 | 0.0 | 0.0 | 0.3 | +35.6 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -11.7 | 0.0 | 13.5 | 0.2 | +0.1 | 0.0 | 28.8 |
| LOST CHARGE | - | - | - | - | 0.2 | -0.3 | 0.0 | 28.8 |
| MANOEUVRE | 1.3 | +20.7 | 0.0 | 0.0 | 1.2 | +13.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.8 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +11.3 | 0.0 | 0.0 | 0.8 | +16.7 | 0.0 | 0.0 |
| MARCH CHECK | 2.2 | +186.9 | 0.0 | 13.5 | 3.2 | +195.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +216.4 | 0.0 | 0.0 | 1.5 | -31.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.3 | +81.6 | 0.0 | 121.2 | 4.3 | +36.7 | 0.0 | 137.2 |
| MISSILES IN THE MOVE | 8.0 | +298.2 | 0.0 | 69.5 | 5.5 | +113.3 | 0.0 | 66.7 |
| MISSILES NEXT TURN | 9.0 | +203.6 | 0.0 | 55.3 | 6.7 | +77.7 | 0.0 | 133.3 |
| MOVE SPELL OUT OF RANGE | 1.0 | -197.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 66.7 |
| MOVE TO CHARGE COMPUTED | 2.7 | +290.6 | 0.0 | 74.5 | 3.0 | +510.6 | 0.0 | 190.7 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +351.6 | 0.0 | 31.7 | 6.2 | +262.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.8 | -158.4 | 0.0 | 74.5 | 5.5 | -353.5 | 0.0 | 250.5 |
| NEXT OBJECTIVE NEARER | 6.5 | -420.7 | 31.8 | 27.7 | 0.2 | -3.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -189.2 | 57.0 | 45.0 | 1.8 | -125.2 | 205.8 | 28.8 |
| NO RALLY LEFT | 0.2 | +47.3 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 14.2 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -1.9 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -7.1 | 0.0 | 5.0 | 0.3 | -7.5 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 94.2 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -66.6 | 0.0 | 22.2 | 4.2 | -172.5 | 0.0 | 234.2 |
| ONE OBJECTIVE FORMULA | 5.2 | -76.1 | 0.0 | 53.3 | 6.7 | +59.2 | 0.0 | 34.8 |
| ONE TARGET A SHOOTER | 17.2 | +356.0 | 0.0 | 156.7 | 14.2 | +334.0 | 0.0 | 190.8 |
| OPENS UP | - | - | - | - | 0.3 | +28.4 | 15.8 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +49.0 | 106.7 | 0.0 |
| PATHS CROSS | 3.2 | +111.4 | 0.0 | 123.7 | 2.7 | +57.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -3.4 | 0.0 | 51.7 | - | - | - | - |
| PLAN RESULT | 37.7 | +972.4 | 562.2 | 814.0 | 30.2 | +502.6 | 282.5 | 554.8 |
| PURSUES BIG PREY | 0.2 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | - | - | - | - | 6.2 | +732.0 | 51.7 | 52.7 |
| RANDOM MOVE BY FIGURES | 1.7 | +51.2 | 0.0 | 28.3 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.3 | -7.4 | 0.0 | 28.3 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +171.6 | 0.0 | 62.2 | 1.8 | +99.5 | 0.0 | 70.5 |
| REDIRECT WEIGHED | - | - | - | - | 0.2 | -3.5 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -49.5 | 0.0 | 22.8 | 0.2 | -103.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.2 | +2.7 | 0.0 | 0.0 | 0.3 | +19.2 | 0.0 | 25.0 |
| RISK BY ARC | 1.7 | +41.8 | 31.8 | 45.0 | 1.7 | -26.9 | 183.3 | 28.8 |
| RISK BY HIS FIGURE | 11.5 | -61.6 | 0.0 | 151.5 | 9.7 | -255.4 | 0.0 | 211.8 |
| RUN DOWN | 1.2 | -19.0 | 57.0 | 0.0 | 1.8 | -14.4 | 178.3 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -0.8 | 0.0 | 49.5 |
| SCOUT SPOT | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -68.9 | 0.0 | 5.0 | - | - | - | - |
| SEARCH SPOT | 3.8 | +151.3 | 0.0 | 37.5 | 3.0 | +120.1 | 0.0 | 25.2 |
| SHOOTER COUNTED ONCE | 0.2 | -1.0 | 0.0 | 5.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.3 | +43.0 | 41.5 | 0.0 | 0.3 | +2.6 | 5.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -2.9 | 0.0 | 14.2 | 0.5 | -53.6 | 76.7 | 0.0 |
| SHOT RISK POINTS | 9.5 | +84.7 | 0.0 | 25.0 | 9.5 | -268.3 | 0.0 | 299.5 |
| SHOTS IN THE MOVE | 10.0 | +302.0 | 0.0 | 269.2 | 9.7 | +365.0 | 0.0 | 223.7 |
| SPELL SETS UP CHARGE | 0.2 | +101.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.3 | +37.2 | 0.0 | 0.0 | 0.3 | +9.7 | 133.3 | 133.3 |
| SPELLS IN THE FIGHT | 0.2 | -0.2 | 25.2 | 0.0 | 0.2 | +1.3 | 14.2 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.2 | -0.7 | 10.8 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.7 | +0.0 | 853.7 | 324.5 | 10.2 | +0.0 | 193.3 | 107.5 |
| STAY WORTH | 11.5 | -169.6 | 390.7 | 98.3 | 12.0 | +163.9 | 188.3 | 340.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 31.8 | 14.2 | 1.0 | +0.0 | 65.0 | 28.8 |
| SURE REACH TOGETHER | 0.2 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 123.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -12.0 | 0.0 | 8.7 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 49.5 |
| TIED UP BY THE SUM | 0.3 | +16.5 | 32.0 | 0.0 | 0.3 | +47.1 | 25.0 | 0.0 |
| TIME ON OUR SIDE | 26.0 | +443.4 | 13.7 | 241.7 | 7.3 | +158.8 | 0.0 | 75.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 60.3 | 1.3 | +0.0 | 0.0 | 25.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 91.8 | 51.7 | 0.2 | +0.0 | 0.0 | 25.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +20.7 | 0.0 | 17.3 | 0.2 | +34.2 | 0.0 | 16.3 |
| WIDER SPREAD | 1.5 | +18.6 | 32.0 | 31.5 | 2.3 | -8.6 | 281.7 | 28.8 |
| WOUNDS ON THE RANKS | 1.5 | +41.9 | 0.0 | 0.0 | 2.5 | +108.1 | 0.0 | 0.0 |

### Rule changes: h6-opp-0333a16-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 103 | 103 | 97 | 16.17 | +5365 | +55.3 |
| DEPLOY BY FIGURES | 81 | 81 | 51 | 8.50 | +908 | +17.8 |
| LEGAL CHARGES ONLY | 48 | 48 | 48 | 8.00 | +0 | +0.0 |
| HIS SHOT LIST | 200 | 200 | 46 | 7.67 | +800 | +17.4 |
| ONE TARGET A SHOOTER | 188 | 188 | 40 | 6.67 | +377 | +9.4 |
| SEARCH SPOT | 41 | 41 | 37 | 6.17 | +1629 | +44.0 |
| TIME ON OUR SIDE | 200 | 168 | 36 | 6.00 | +181 | +5.0 |
| PATHS CROSS | 35 | 35 | 35 | 5.83 | +1015 | +29.0 |
| FIVE ACTION | 466 | 466 | 31 | 5.17 | +1343 | +43.3 |
| MARCH CHECK | 32 | 32 | 26 | 4.33 | +606 | +23.3 |
| FOUR ROUNDS | 28 | 28 | 22 | 3.67 | +1552 | +70.5 |
| MOVE TO CHARGE COMPUTED | 34 | 34 | 21 | 3.50 | +2069 | +98.5 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 3.00 | +0 | +0.0 |
| SHOT RISK POINTS | 114 | 114 | 18 | 3.00 | +420 | +23.3 |
| MISSILES IN THE MOVE | 81 | 66 | 15 | 2.50 | +582 | +38.8 |
| MAX FOR POSITIONING | 64 | 62 | 13 | 2.17 | +41 | +3.2 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 2.00 | +1060 | +88.4 |
| CASTING BLOCK | 11 | 11 | 11 | 1.83 | +224 | +20.4 |
| NEXT OBJECTIVE NEARER | 40 | 40 | 11 | 1.83 | +208 | +18.9 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 1.67 | +0 | +0.0 |
| COVER ONCE | 60 | 43 | 10 | 1.67 | +178 | +17.8 |
| MANOEUVRE | 15 | 15 | 10 | 1.67 | +205 | +20.5 |
| HARD STAY DROPPED | 9 | 9 | 9 | 1.50 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 9 | 1.50 | +76 | +8.4 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 1.33 | -1050 | -131.2 |
| REDIRECT COUNTER | 29 | 24 | 8 | 1.33 | +686 | +85.7 |
| SHOTS IN THE MOVE | 118 | 102 | 8 | 1.33 | +299 | +37.4 |
| FALLS SHORT | 124 | 109 | 7 | 1.17 | +116 | +16.6 |
| MARCH BY THE SUM | 7 | 7 | 7 | 1.17 | +168 | +24.0 |
| ONE OBJECTIVE FORMULA | 71 | 59 | 7 | 1.17 | +182 | +25.9 |
| RISK BY HIS FIGURE | 127 | 127 | 7 | 1.17 | +961 | +137.3 |
| CHARGE LOSSES | 64 | 64 | 6 | 1.00 | +742 | +123.7 |
| RISK BY ARC | 20 | 20 | 6 | 1.00 | +162 | +27.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.83 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 0.83 | +0 | +0.0 |
| NEARER NOT NEEDED | 67 | 63 | 5 | 0.83 | +136 | +27.2 |
| STAY WORTH | 141 | 132 | 5 | 0.83 | +62 | +12.5 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 0.67 | +1191 | +297.8 |
| NEXT CHARGE BY LIST | 56 | 56 | 4 | 0.67 | +66 | +16.4 |
| ONE FIGHT FORMULA | 51 | 28 | 4 | 0.67 | +24 | +5.9 |
| QUARTER ODDS | 37 | 37 | 4 | 0.67 | +376 | +94.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 0.67 | +307 | +76.7 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 0.67 | +109 | +27.3 |
| WOUNDS ON THE RANKS | 24 | 24 | 4 | 0.67 | +127 | +31.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 0.50 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.50 | +538 | +179.4 |
| BOMBING RUN | 3 | 3 | 3 | 0.50 | +90 | +30.0 |
| CANNON PLANNED TARGET | 37 | 37 | 3 | 0.50 | -3 | -1.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 0.50 | +4 | +1.3 |
| CHAFF PASSED | 3 | 3 | 3 | 0.50 | -7 | -2.3 |
| CHARGE NOW FIRST | 13 | 13 | 3 | 0.50 | -47 | -15.6 |
| FIGHT TO THE END | 9 | 9 | 3 | 0.50 | +344 | +114.6 |
| HIS TURN DENIED | 11 | 11 | 3 | 0.50 | +163 | +54.3 |
| HOLDER AT DEPLOYMENT | 6 | 6 | 3 | 0.50 | +154 | +51.2 |
| LANE BY FIGURES | 3 | 3 | 3 | 0.50 | +63 | +21.1 |
| OFF BEST | 3 | 3 | 3 | 0.50 | -88 | -29.2 |
| RESERVE FALL BACK | 3 | 3 | 3 | 0.50 | +131 | +43.7 |
| FALL BACK GOOD ORDER | 17 | 17 | 2 | 0.33 | +35 | +17.3 |
| FEATURE BUFFS | 29 | 29 | 2 | 0.33 | +11 | +5.7 |
| IDLE COST | 47 | 34 | 2 | 0.33 | +76 | +38.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.33 | +30 | +15.2 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.33 | +110 | +55.1 |
| OPENS UP | 2 | 2 | 2 | 0.33 | +138 | +68.8 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.33 | +92 | +45.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.33 | +19 | +9.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.17 | -21 | -20.9 |
| CAST JOB | 11 | 11 | 1 | 0.17 | +1 | +0.8 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.17 | +27 | +26.7 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.17 | +36 | +36.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| HIS MOVE AND SHOT | 19 | 19 | 1 | 0.17 | +1 | +0.7 |
| MISSILES NEXT TURN | 94 | 72 | 1 | 0.17 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.17 | +53 | +53.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.17 | -20 | -20.2 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.17 | -120 | -120.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.17 | +206 | +206.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.17 | -0 | -0.1 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 1 | 0.17 | +2 | +1.8 |
| SUPPORT NARROWED | 10 | 10 | 1 | 0.17 | -8 | -7.5 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.17 | +6 | +5.5 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.17 | +55 | +55.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 15 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 60 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 8 | 8 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 28 | 28 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 35 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HOLD ODDS | 89 | 89 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 20 | 0 | 0.00 | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 407 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 179 | 179 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 38 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WIDER SPREAD | 23 | 23 | 0 | 0.00 | - | - |

### Off best figure: h6-opp-0333a16-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 1.00 | 0.33 | 131.2 |
| PATHS CROSS | rule | 0.67 | 0.50 | 53.2 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 17.6 |
| CHARGE NOW FIRST | rule | 0.17 | 0.33 | 15.6 |
| CHAFF PASSED | rule | - | 0.33 | 3.4 |
| NO REASON | gate | - | 0.33 | 22.5 |
| BEST PRIZE | rule | - | 0.17 | 20.9 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 3.1 |
| DEPLOY BY FIGURES | rule | - | 0.17 | 4.7 |
| JOB FIRST | gate | 0.17 | - | 42.5 |
| PIVOT GUARDS FLANK | rule | 0.17 | - | 20.2 |
| PURSUES BIG PREY | rule | 0.17 | - | 120.0 |
| SUPPORT NARROWED | rule | - | 0.17 | 7.5 |

### Plans: h6-opp-0333a16-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 168 | 88 | 52% |
| Mine | move | 25.7 | 97% | 1698 | 0 | 0% |
| Mine | shoot | 9.5 | 54% | 395 | 884 | 224% |
| Mine | support | 0.8 | 80% | 11 | 0 | 0% |
| Opponent | charge | 2.0 | 67% | 481 | 247 | 51% |
| Opponent | move | 22.5 | 95% | 2029 | 0 | 0% |
| Opponent | shoot | 5.7 | 56% | 427 | 256 | 60% |

### Battle groups: h6-opp-0333a16-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 50% | 50% |
| Opponent | REDIRECT COUNTER | 1.8 | 18% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h6-opp-0333a16-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 21 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 22 | 6 (22) | 6 | 0 | 13 | 36% | 2.0 | 9 (4) | 0 (16) | - | 3 (11) | 0 (9) |
| Mine | Clean-up | 6 | 97 (6) | 97 | 0 | 33 | 33% | 3.0 | 13 (1) | 0 (2) | 190 (3) | 195 (3) | 0 (3) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 25% | 3.3 | - | - | 0 (4) | 0 (2) | 0 (2) |
| Mine | Hammer | 16 | 48 (16) | 24 | 24 | 23 | 25% | 2.2 | 56 (3) | 48 (11) | 0 (2) | 54 (11) | 37 (5) |
| Mine | Holder | 8 | 112 (8) | 0 | 112 | 27 | 88% | 3.0 | 0 (2) | 160 (5) | 95 (1) | 139 (3) | 94 (5) |
| Mine | Shooter | 4 | 85 (4) | 0 | 85 | 50 | 25% | 2.0 | 46 (1) | 146 (2) | 0 (1) | 67 (3) | 138 (1) |
| Mine | War machine | 8 | 51 (8) | 51 | 0 | 63 | 0% | 1.5 | 0 (2) | 72 (6) | - | 0 (2) | 72 (6) |
| Mine | Wizard | 8 | 0 (8) | 0 | 0 | 22 | 25% | 4.2 | 0 (1) | 0 (7) | - | 0 (3) | 0 (5) |
| Opponent | Chaff | 5 | 207 (5) | 0 | 207 | 52 | 60% | 4.0 | 471 (1) | 199 (2) | 0 (2) | 264 (4) | 61 (1) |
| Opponent | Character | 19 | 38 (19) | 38 | 0 | 14 | 32% | 2.2 | 31 (3) | 32 (11) | 51 (5) | 24 (13) | 67 (6) |
| Opponent | Clean-up | 2 | 88 (2) | 0 | 88 | 0 | 0% | 2.0 | - | 88 (2) | - | 53 (1) | 123 (1) |
| Opponent | Fast Hammer | 13 | 57 (13) | 13 | 44 | 16 | 54% | 2.7 | 55 (3) | 33 (6) | 94 (4) | 67 (9) | 31 (4) |
| Opponent | Hammer | 1 | 35 (1) | 0 | 35 | 100 | 0% | 2.0 | - | - | 35 (1) | 35 (1) | - |
| Opponent | Holder | 2 | 135 (2) | 0 | 135 | 0 | 100% | - | - | 135 (2) | - | 157 (1) | 75 (1) |
| Opponent | Shooter | 5 | 104 (5) | 48 | 56 | 23 | 0% | 2.6 | 55 (2) | 141 (3) | - | 141 (3) | 55 (2) |
| Opponent | War machine | 6 | 0 (6) | 0 | 0 | 41 | 0% | 2.3 | 0 (4) | 0 (2) | - | - | 0 (6) |
| Opponent | Wizard | 3 | 2 (3) | 2 | 0 | 0 | 0% | 2.0 | - | 0 (2) | 4 (1) | 2 (3) | - |

### Charged fights: h6-opp-0333a16-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 48 | 84 | 2.2 | 1.2 | 38 | 49 | -11 | 6 of 9 | 5 of 9 | -274 | +22 |
| Mine | Chaos Dwarfs | 2 | 348 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 6 | 148 | 56 | 1.5 | 1.2 | 38 | 49 | -11 | 6 of 9 | 5 of 9 | -274 | +22 |
| Opponent | Grand Cathay | 2 | 163 | 242 | 1.5 | 1.0 | 162 | 0 | +162 | 1 of 3 | 3 of 3 | - | +162 |
| Opponent | High Elf Realms | 1 | 225 | 230 | 1.0 | 1.0 | 230 | 0 | +230 | 0 of 1 | 1 of 1 | - | +230 |
| Opponent | Warriors of Chaos | 3 | 132 | 227 | 2.7 | 1.1 | 85 | 34 | +51 | 5 of 8 | 6 of 8 | +140 | +38 |
| **Opponent** | all armies | 6 | 158 | 232 | 2.0 | 1.1 | 116 | 23 | +94 | 6 of 12 | 10 of 12 | +140 | +89 |

### Effective charges: h6-opp-0333a16-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 4 (net -72) | 0 | 0 | 1 (net +147) | 0 | 4 (net +10) | 0 | 0% (0 of 9) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 1 (net +130) | 2 (net +178) | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 1 (net +230) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Warriors of Chaos | 8 | 2 (net -136) | 0 | 0 | 1 (net +0) | 1 (net +140) | 3 (net +180) | 1 | 0% (0 of 7) |

### Charged fights, damage counted: h6-opp-0333a16-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 94 | 374 | -72 | 62 | 116 | -55 | -58.5 |
| Mine | 76-89% | 1 | 52 | 97 | +147 | 147 | 0 | +147 | +282.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 512 | 248 | +10 | 75 | 16 | +59 | +11.6 |
| Mine | All fights | 9 | 275 | 287 | -11 | 77 | 59 | +18 | +6.7 |
| Opponent | Long shot (under 50%) | 2 | 136 | 314 | -136 | 0 | 136 | -136 | -100.0 |
| Opponent | Effective (55-75%) | 1 | 342 | 230 | +230 | 230 | 0 | +230 | +67.3 |
| Opponent | 76-89% | 2 | 356 | 316 | +65 | 176 | 0 | +176 | +49.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 419 | 271 | +180 | 210 | 0 | +210 | +50.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 501 | 97 | +165 | 178 | 62 | +116 | +23.2 |
| Opponent | No odds | 1 | 285 | 91 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 12 | 364 | 224 | +94 | 145 | 38 | +107 | +29.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h6-opp-0333a16-p3 | move | 36 | 10 (28%) | 6 (17%) | 5 (14%) | 21 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Elixir of Power | Opponent | L0111, L0211 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |

# Doctrine scorecard: dep-mine-13df7bd-p4

### Scorecard: dep-mine-13df7bd-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 2 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 5 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 254 |
| L0214 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 123 |
| L0230 | 2 | 1 | Mine | - | - | - | 4 | 5 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 879 |
| L0315 | 3 | 1 | Opponent | yes | 12 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 6 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 9 | 1 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 548 |
| L0520 | 4 | 1 | Opponent | yes | 2 | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 4 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 798 |
| L0624 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | yes | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 755 |
| L0729 | 3 | 1 | Opponent | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 605 |
| L0819 | 3 | 1 | Opponent | yes | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 891 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 224 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 107 |
| L1126 | 4 | 1 | Mine | no | 0 | 4 | 0 | 0 | 2 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 1 | 0 | 0 | 275 |
| L1314 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 479 |
| L1314 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 1 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 6 | - | 3 | 2 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | yes | 0 | 3 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 1 | 5 | 0 | 0 | 0 | 210 |
| L2123 | 5 | 1 | Mine | no | - | - | 0 | 4 | 0 | 0 | 0 | 592 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 1 | 5 | 1 | 1 | 3 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 2 | 3 | 1 | 0 | 1 | 0 | 0 | 153 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 60 |
| L2634 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 27 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 4 | 0 | 0 | 0 | 170 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 36% | 1.2 | 2.6 | 2.2 | 1.3 | 0.2 | 0.0 | 0.0 | 307.9 |
| **Average** | | | Opponent | 46% | 3.6 | 2.4 | 2.9 | 1.8 | 0.4 | 0.0 | 0.0 | 90.0 |

### KPIs: dep-mine-13df7bd-p4

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (46 of 178) | 0% (0 of 188) | 13% (46 of 366) |
| Winner chose to follow up after the loser gave ground |  | 96% (66 of 69); on the table 96% | 97% (37 of 38); on the table 97% | 96% (103 of 107); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 100% (14 of 14); on the table 100% | 95% (20 of 21); on the table 95% |
| Winner chose to pursue after the loser fled |  | 74% (14 of 19); on the table 79% | 87% (27 of 31); on the table 87% | 82% (41 of 50); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 91% (86 of 95); on the table 92% | 94% (78 of 83); on the table 94% | 92% (164 of 178); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 36% (97 of 272) | 36% (62 of 170) | 36% (159 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (97 of 198) | 43% (62 of 143) | 47% (159 of 341) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 54% (20 of 37) | 49% (33 of 67) | 51% (53 of 104) |
| Points that never fought | lower | 35% (23706 of 67942) | 33% (23882 of 71984) | 34% (47588 of 139926) |
|   infantry points that never fought | lower | 40% (6127 of 15347) | 58% (8033 of 13804) | 49% (14160 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (153 of 270) | 52% (146 of 280) | 54% (299 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.8 uses a game | 78% (7 of 9); 0.8 uses a game | 84% (26 of 31); 1.3 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.3 uses a game | 45% (9 of 20); 0.4 uses a game | 47% (17 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (28502 of 57750) | 47% (29624 of 63347) | 48% (58126 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (27%) | 1.2 (42%) | 2.6 (33%) |
| MARCHED: its unit marched | 1.1 (22%) | 0.6 (19%) | 1.6 (20%) |
| CHARGED: its unit charged | 0.2 (5%) | 0.1 (4%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.2 (26%) | 0.4 (13%) | 1.6 (21%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.3 (11%) | 0.4 (6%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.5 (11%) | 0.4 (12%) | 0.9 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.8 | 4.4 | 0.4 | 2.0 |
| not cast | 2.8 | 2.4 | 3.1 | 7.9 | 1.6 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (52%) | 0.2 (7%) | 2.6 (33%) | 0.5 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (20%) | 0.5 (32%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.4 (15%) | 0.6 (19%) | 1.6 (21%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.0 (0%) | 0.3 (9%) | 0.4 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) | 0.1 (5%) | 0.6 (3%) |
| GONE: slain | 0.8 (28%) | 0.3 (12%) | 0.5 (17%) | 0.9 (11%) | 0.0 (0%) | 2.5 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (11%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (60%) | 0.1 (5%) | 1.4 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.9 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 71% (30 of 42) | 62% (8 of 13) | 69% (38 of 55) |
| the unit moved after it | 77% (23 of 30) | 75% (6 of 8) | 76% (29 of 38) |
| it charged on its next turn | 7% (2 of 30) | 0% (0 of 8) | 5% (2 of 38) |
| the enemy charged it first | 20% (6 of 30) | 0% (0 of 8) | 16% (6 of 38) |
| it fought by the end of its next turn | 13% (4 of 30) | 0% (0 of 8) | 11% (4 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (7 of 30) | 12% (1 of 8) | 21% (8 of 38) |
| none of these (no charge, no fight, no charge escaped) | 53% (16 of 30) | 88% (7 of 8) | 61% (23 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (561 of 890) | 53% (291 of 552) | 59% (852 of 1442) |
|   cavalry | 64% (47 of 73) | 68% (83 of 122) | 67% (130 of 195) |
|   character | 43% (49 of 114) | 16% (21 of 131) | 29% (70 of 245) |
|   chariot | 60% (67 of 112) | 59% (13 of 22) | 60% (80 of 134) |
|   infantry | 54% (138 of 257) | 63% (142 of 225) | 58% (280 of 482) |
|   monster | 37% (16 of 43) | 35% (9 of 26) | 36% (25 of 69) |
|   war machine | 84% (244 of 291) | 88% (23 of 26) | 84% (267 of 317) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (24%) | 1.7 (23%) | 3.9 (24%) |
| CHARGED: it charged | 1.2 (13%) | 1.7 (23%) | 2.9 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.3 (4%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (21%) | 1.3 (18%) | 3.2 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.6 (9%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (22%) | 1.5 (20%) | 3.5 (21%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 2.1 | 75% | 6.2 pts | 38 pts |
| character | 2.2 | 0.4 | 85% | 5.3 pts | 12 pts |
| chariot | 2.2 | 1.5 | 65% | 14.6 pts | 33 pts |
| infantry | 11.6 | 4.4 | 73% | 10.2 pts | 118 pts |
| monster | 0.7 | 0.1 | 85% | 6.1 pts | 4 pts |
| war machine | 7.4 | 5.7 | 64% | 28.0 pts | 208 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.0 | 5.1 |
| Charges that made contact a game | 2.9 | 4.5 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.61 contact (18 units) | 0.65 declared, 0.53 contact (17 units) | 0.77 declared, 0.57 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.86 declared, 0.71 contact (7 units) | 1.17 declared, 0.75 contact (12 units) | 1.05 declared, 0.74 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.36 contact (249 units) | 0.64 declared, 0.48 contact (300 units) | 0.58 declared, 0.42 contact (549 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (40 of 81) | 44% (7 of 16) | 83% (5 of 6) | 50% (52 of 103) |
| Character in a unit | 78% (29 of 37) | 80% (16 of 20) | 100% (1 of 1) | 79% (46 of 58) |
| Character on its own | 82% (23 of 28) | 36% (8 of 22) | 22% (17 of 77) | 38% (48 of 127) |
| Chariot | 73% (11 of 15) | 83% (10 of 12) | - | 78% (21 of 27) |
| Infantry | 43% (36 of 83) | 44% (11 of 25) | 50% (3 of 6) | 44% (50 of 114) |
| Monster | 62% (21 of 34) | 50% (7 of 14) | - | 58% (28 of 48) |
| Monstrous | 79% (11 of 14) | 64% (9 of 14) | - | 71% (20 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 86% (12 of 14); on the table 93% | 40% (41 of 102) | 28% | 68% (15 of 22) | 67% (4 of 6); 4.2 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 80% (8 of 10); on the table 80% | 33% (8 of 24) | 25% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 69% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (6 of 8); on the table 75% | 56% (10 of 18) | 62% | 68% (42 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (13 of 13); on the table 100% | 38% (32 of 84) | 38% | 41% (15 of 37) | 100% (9 of 9); 8.2 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 91% (20 of 22); on the table 91% | 36% (13 of 36) | 27% | 41% (29 of 70) | 71% (5 of 7); 1.7 uses a game | 50% (15 of 30); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 14% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (7 of 7); on the table 100% | 100% (6 of 6) | 36% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 45% | 79% (11 of 14) | 100% (2 of 2); 3.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 31% (13 of 42) | 4% | 21% (5 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 100% (13 of 13); on the table 100% | 39% (16 of 41) | 41% | 60% (27 of 45) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 83% (5 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 95% (21 of 22); on the table 95% | 17% (1 of 6) | 24% | 15% (3 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (22 of 24); on the table 92% | 22% (13 of 59) | 22% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 91% (20 of 22); on the table 91% | 33% (4 of 12) | 33% | 53% (38 of 72) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 88% (7 of 8); on the table 88% | 33% (2 of 6) | 36% | 70% (39 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 39% (39) | 43% (29) | 41% (68) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.47 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.14 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.28 | 0.61 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.03 | 1.44 | 3.47 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.64 | 1.53 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.19 | 6.92 | 13.11 |

### Quality by phase: dep-mine-13df7bd-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (66 of 127) | 43% (80 of 187) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (146 of 368) | 49% (73 of 148) |
| Strategy | Close-in objectives charged next turn | 14% (22 of 152) | 16% (37 of 227) |
| Strategy | Support requests answered (helper made contact too) | 57% (8 of 14) | 29% (10 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 69% (9 of 13) | 50% (4 of 8) |
| Strategy | Joined characters whose unit fought | 43% (19 of 44) | 51% (18 of 35) |
| Strategy | Lone characters that fought | 75% (59 of 79) | 77% (62 of 81) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 307.9 | 90.0 |
| Movement | Fights charged into per game | 2.6 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 83, net +140 | 22 of 114, net +77 |
| Movement | Charges with odds: sweet spot (55-75%) | 24 of 83, net +49 | 23 of 114, net +45 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 83, net +60 | 7 of 114, net +121 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 83, net +79 | 34 of 114, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (140 of 351) | 41% (129 of 313) |
| Shooting | Points destroyed by shooting units | 59.4 | 23.6 |
| Shooting | War machine shots | 6.8 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (139 of 244) | 35% (8 of 23) |
| Shooting | Points destroyed by war machines | 42.8 | 7.8 |
| Magic | Magic missiles cast | 1.8 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (22 of 63) | 37% (15 of 41) |
| Magic | Wounds caused by magic missiles | 3.9 | 1.4 |
| Magic | Wounds caused by other spells | 1.4 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 82.9 | 26.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.8 / 0.2 | 1.9 / 0.5 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 309.6 | 430.5 |
| Combat | Points run down | 56.9 | 79.8 |
| Combat | Net points per charged fight, damage counted | +79 | +92 |
| Combat | Net per 100 charger points, damage counted | +25.9 | +30.3 |
| Combat | First round won (charged fights) | 74% | 75% |
| Combat | Net points per charged fight | +73 | +97 |
| Combat | Net points per supported fight / lone fight | +102 / +68 | +170 / +88 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 93 | 69 of 138 |
| Game | Points lost | 690.7 | 596.9 |
| Game | VP from objectives | 542.5 | 566.7 |
| Game | Lone holders (player turns) | 1.2 | 3.6 |

- Mine won / drew / lost: 15 / 3 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -165 VP
- The side that went first won 14 of 33 games with a winner
- Points traded per game (both sides' losses): 1288
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 7.8 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.1 | +5.8 | 0.0 | 18.9 | 1.2 | +8.2 | 0.0 | 0.0 |
| BEST FACING | 0.9 | +33.7 | 0.0 | 23.4 | 0.8 | +48.5 | 0.0 | 39.4 |
| BEST FIRST | 4.9 | +202.2 | 204.4 | 70.6 | 4.8 | +174.5 | 108.9 | 58.7 |
| BEST OVERALL | 0.5 | +35.1 | 0.0 | 2.9 | 0.5 | +29.0 | 0.0 | 8.7 |
| BEST PREY | 0.8 | +36.4 | 12.7 | 14.5 | 0.9 | +40.9 | 16.4 | 26.5 |
| BEST PRIZE | 0.1 | -10.3 | 0.0 | 0.0 | 0.1 | -5.2 | 0.0 | 3.5 |
| BIG CHARACTER SAFETY | 0.3 | -0.7 | 0.0 | 0.0 | 0.2 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 7.1 | 0.0 | 0.1 | +0.0 | 25.1 | 0.0 |
| BLOCKED WHEEL | 0.5 | +13.5 | 0.0 | 5.2 | 0.6 | +15.8 | 0.0 | 5.2 |
| BLOWS WHERE AIMED | 0.3 | -20.7 | 33.2 | 13.5 | 0.2 | -19.5 | 32.2 | 7.9 |
| BOMBING RUN | 0.1 | +1.9 | 3.1 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 59.3 | 9.6 | 0.1 | +0.0 | 3.2 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +105.1 | 175.0 | 83.3 | 0.5 | +23.7 | 15.4 | 8.9 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 11.0 | 0.0 | 0.0 | +0.0 | 5.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 6.5 | 12.2 | 0.1 | -0.2 | 0.0 | 1.7 |
| CAST JOB | 0.8 | +18.0 | 54.9 | 8.5 | 0.4 | +5.3 | 14.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +33.2 | 7.9 | 0.0 | 0.1 | +9.1 | 7.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 21.9 | 0.4 | +0.0 | 0.0 | 33.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -0.6 | 3.8 | 9.6 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 179.2 | 80.1 | 2.7 | +0.0 | 270.0 | 61.2 |
| CHARGE NOW WEIGHED | 0.6 | -19.3 | 16.1 | 30.6 | 0.7 | -35.2 | 31.5 | 8.5 |
| CHARGER SLAIN LOST | 0.5 | -12.6 | 39.1 | 25.3 | 0.7 | -25.7 | 35.9 | 23.9 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -1.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 5.7 | 0.0 | 0.1 | +0.0 | 18.4 | 3.2 |
| COMBAT PIVOT | 0.5 | +0.0 | 18.4 | 33.2 | 0.5 | +0.0 | 24.9 | 33.8 |
| CONVEYANCE SEARCH | 0.8 | +124.0 | 5.1 | 10.6 | 0.3 | +37.7 | 17.4 | 11.1 |
| COUNTER-CHARGE COVER | 8.6 | +650.3 | 0.0 | 151.0 | 8.4 | +760.6 | 0.0 | 136.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 7.7 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.8 | 7.9 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +23.6 | 0.0 | 26.4 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +11.0 | 35.0 | 5.7 | 0.4 | +15.0 | 60.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +139.2 | 0.0 | 70.0 | 1.4 | +101.7 | 0.0 | 81.5 |
| FALLBACK BY WORTH | 5.1 | +93.8 | 0.0 | 67.4 | 6.0 | +68.6 | 0.0 | 50.4 |
| FIGHT LIFT | 0.1 | +2.8 | 5.8 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +2.0 | 3.5 | 5.9 | 0.0 | +0.2 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.4 | +0.0 | 0.0 | 130.4 | 6.4 | +0.0 | 0.0 | 89.5 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +138.7 | 0.0 | 41.9 | 1.0 | +122.1 | 0.0 | 27.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.7 | 0.0 | 23.1 | 0.0 | +0.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -1.5 | 8.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 7.1 | 0.0 | 0.1 | +0.0 | 0.0 | 3.2 |
| HELPER UNSEEN | 0.4 | +0.0 | 48.8 | 4.2 | 0.4 | +0.0 | 31.4 | 5.9 |
| HILL BY ITS CHANCE | 0.4 | -40.7 | 0.0 | 0.0 | 0.8 | -69.3 | 0.0 | 8.7 |
| HOLDER AT DEPLOYMENT | 0.9 | +139.2 | 0.0 | 2.1 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.8 | -151.9 | 382.1 | 130.1 | 8.8 | -214.1 | 533.6 | 101.9 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.3 | 0.0 | 1.7 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.1 |
| HUNT IN PAIRS | 0.8 | +24.9 | 0.0 | 13.9 | 0.6 | +28.1 | 0.0 | 13.9 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.1 |
| HUNT THE GUNS | 0.0 | +16.7 | 0.0 | 0.0 | 0.1 | +41.6 | 0.0 | 4.9 |
| INVITES THE FIGHT | 1.7 | +27.5 | 48.0 | 26.8 | 1.9 | +33.3 | 45.4 | 13.6 |
| JOINT CHARGE PLAN | 0.1 | +4.3 | 0.0 | 0.0 | 0.2 | +12.2 | 15.8 | 5.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.4 | -25.3 | 30.7 | 4.7 |
| KEEP FALLS | 0.2 | +4.3 | 0.0 | 7.5 | 0.0 | +1.6 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +1.2 | 5.9 | 4.7 | 0.1 | +0.8 | 7.8 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 193.4 | 28.2 | 2.1 | +62.5 | 175.3 | 16.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +61.5 | 100.2 | 39.2 | 2.3 | +113.4 | 159.8 | 49.2 |
| KILLS COUNT NEXT TURN | 5.5 | +145.4 | 203.7 | 103.6 | 7.1 | +224.9 | 284.1 | 137.5 |
| LANE BY FIGURES | 0.8 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +19.6 | 2.1 | 12.9 | 0.2 | +5.1 | 1.2 | 8.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +0.9 | 29.0 | 0.0 | 0.5 | +0.9 | 26.1 | 1.8 |
| LOST CHARGE | 3.5 | -56.8 | 128.4 | 95.2 | 1.9 | -34.6 | 27.4 | 40.6 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | -2.1 | 0.0 | 1.2 |
| MAKE SURE TOGETHER | 0.4 | +9.7 | 6.8 | 3.1 | 0.7 | +48.3 | 26.1 | 12.1 |
| MANOEUVRE | 0.3 | +15.3 | 0.0 | 11.4 | 0.2 | +3.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +26.0 | 0.0 | 2.2 | 0.4 | +21.2 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +23.4 | 17.1 | 5.8 | 0.2 | +9.2 | 5.8 | 0.0 |
| MARCH OVER CASTS | 0.6 | +43.1 | 0.0 | 11.0 | 0.3 | +18.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +184.4 | 0.0 | 103.3 | 5.6 | +221.6 | 0.0 | 115.9 |
| MISSILES IN THE MOVE | 4.1 | +116.3 | 0.0 | 43.6 | 2.7 | +47.4 | 0.0 | 26.6 |
| MISSILES NEXT TURN | 4.8 | +91.2 | 0.0 | 55.7 | 3.2 | +31.7 | 0.0 | 32.5 |
| MODEL FACING | 0.4 | +104.2 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 16.6 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +17.8 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +8.5 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.7 | 0.0 | 0.0 | 0.2 | -7.1 | 6.9 | 2.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.9 | +176.2 | 127.1 | 48.9 | 3.4 | +263.7 | 176.1 | 24.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +12.7 | 5.4 | 0.0 |
| NOT NEEDED | 0.2 | -8.4 | 31.8 | 1.2 | 0.2 | -8.7 | 38.1 | 8.7 |
| NOT TURNED | 6.2 | +70.6 | 0.0 | 104.4 | 6.9 | +47.0 | 0.0 | 62.3 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 45.4 | 0.4 | -0.1 | 0.0 | 11.0 |
| OFF BEST | 16.1 | -828.7 | 5.7 | 288.1 | 15.6 | -870.0 | 15.1 | 230.8 |
| OPENS A LANE | 0.2 | +0.5 | 22.5 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +11.6 | 15.8 | 0.0 | 0.2 | +20.7 | 13.2 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +17.0 | 44.7 | 5.7 | 0.7 | +12.5 | 59.8 | 15.5 |
| PATHS CROSS | 2.3 | +152.2 | 0.0 | 22.6 | 3.1 | +240.3 | 0.0 | 31.8 |
| PERIAPT WORTH | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +10.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.3 | 0.0 | 8.6 | 0.1 | -4.9 | 0.0 | 0.0 |
| PLAN RESULT | 38.4 | +1260.5 | 1241.5 | 944.1 | 40.0 | +1017.9 | 1149.9 | 867.5 |
| PURSUES BIG PREY | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -6.5 | 0.0 | 5.4 |
| PURSUES ON | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.5 | 0.0 | 2.2 | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +30.5 | 0.0 | 37.9 | 1.9 | +32.1 | 0.0 | 64.6 |
| RANDOM MOVER NO PROMISE | 0.3 | -17.1 | 19.6 | 4.7 | 0.2 | -12.3 | 3.9 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.2 | 0.0 | 0.0 | 0.7 | -22.1 | 0.0 | 6.5 |
| REDIRECT COUNTER | 3.1 | +195.4 | 0.0 | 35.9 | 5.4 | +343.0 | 0.0 | 81.1 |
| REDIRECT WEIGHED | 0.4 | -5.2 | 7.1 | 6.9 | 0.3 | -1.4 | 5.2 | 13.1 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 13.9 | 0.3 | +0.0 | 0.0 | 21.9 |
| RESERVE FALL BACK | 0.7 | +18.4 | 0.0 | 5.6 | 0.6 | +26.2 | 0.0 | 5.6 |
| RESTRAINS TO SHOOT | 0.1 | +1.7 | 0.0 | 8.2 | 0.0 | +1.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.8 | +98.4 | 224.3 | 81.8 | 3.0 | +47.1 | 249.1 | 86.6 |
| SAFER THAN THE JOB | 0.9 | +50.8 | 0.0 | 12.2 | 0.6 | +26.2 | 0.0 | 12.7 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.8 | 0.0 | 0.0 | 0.2 | -18.9 | 0.0 | 2.8 |
| SEARCH SPOT | 3.0 | +158.4 | 0.0 | 43.6 | 3.0 | +128.6 | 0.0 | 34.5 |
| SELF MOVE SPELL | 0.1 | +32.6 | 0.0 | 21.9 | 0.4 | +20.4 | 0.0 | 21.9 |
| SET UP TOGETHER | 0.6 | +27.5 | 6.8 | 3.1 | 1.3 | +97.8 | 41.7 | 16.1 |
| SET-UP ANY TARGET | 0.2 | +40.5 | 0.0 | 10.6 | 0.2 | +29.7 | 6.3 | 0.0 |
| SET-UP MISSED | 0.2 | +23.7 | 0.0 | 10.6 | 0.0 | +7.0 | 16.6 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 1.2 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +30.8 | 40.8 | 5.9 | 0.6 | +20.6 | 14.9 | 7.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 67.6 | 18.4 | 0.1 | +0.0 | 8.4 | 0.0 |
| SHOTS IN THE MOVE | 13.8 | +459.3 | 0.0 | 236.9 | 7.4 | +190.2 | 0.0 | 132.6 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +82.5 | 0.0 | 10.6 | 0.2 | +29.7 | 6.3 | 0.0 |
| SPELL WORTH | 1.2 | +19.2 | 23.6 | 15.0 | 2.5 | +44.8 | 22.2 | 22.2 |
| SPELLS IN THE FIGHT | 0.7 | +2.3 | 40.5 | 30.8 | 1.0 | +1.4 | 107.9 | 36.2 |
| STABLE ROLE | 11.5 | +0.0 | 303.7 | 235.8 | 10.6 | +0.0 | 296.6 | 179.1 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +16.0 | 0.0 | 1.4 | 0.4 | +27.3 | 0.0 | 22.3 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 6.1 | -50.2 | 283.9 | 92.7 | 8.2 | -53.0 | 309.4 | 109.5 |
| SUPPORTS | 4.3 | +53.6 | 150.6 | 47.2 | 5.6 | +53.0 | 153.9 | 51.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.2 | 19.1 | 0.0 | 0.2 | -3.3 | 3.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -1.0 | 1.7 | 4.9 | 0.2 | -1.8 | 0.0 | 0.8 |
| THROUGH LINE OF FIRE | 0.3 | +20.1 | 0.0 | 8.4 | 0.2 | +24.0 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -12.6 | 20.8 | 5.7 | 0.2 | -14.3 | 19.2 | 1.9 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | 0.3 | +2.2 | 15.8 | 0.0 |
| WAIT AFTER COSTS | 6.7 | -286.2 | 237.1 | 93.9 | 7.2 | -324.0 | 260.3 | 67.1 |
| WALKS TO THE FIGHT | 1.6 | +30.6 | 13.6 | 10.1 | 0.6 | +9.3 | 2.1 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 9.4 | 17.5 | 0.1 | +0.0 | 2.2 | 10.1 |
| WEARS DOWN | 1.2 | +41.9 | 98.6 | 38.3 | 1.6 | +44.4 | 155.2 | 36.0 |
| WHO HITS BACK | 0.3 | +19.2 | 0.0 | 20.7 | 0.2 | +10.1 | 0.0 | 21.5 |
| WHOLE FIGHT | 0.3 | +20.6 | 46.2 | 0.0 | 0.5 | +27.6 | 70.1 | 4.2 |
| WHOLE FIGHT GAIN | 0.4 | +40.8 | 40.1 | 0.0 | 0.8 | +58.0 | 41.6 | 8.5 |
| WIDER SPREAD | 2.6 | -7.3 | 195.9 | 69.1 | 3.5 | -6.4 | 354.4 | 87.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 5.1 | 3.1 |

### Rule changes: dep-mine-13df7bd-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1141 | 1141 | 1141 | 31.69 | -61152 | -53.6 |
| BEST FIRST | 349 | 349 | 349 | 9.69 | +13561 | +38.9 |
| SEARCH SPOT | 215 | 215 | 213 | 5.92 | +10351 | +48.6 |
| PATHS CROSS | 195 | 195 | 195 | 5.42 | +14130 | +72.5 |
| DEPLOY BY FIGURES | 298 | 298 | 179 | 4.97 | +1965 | +11.0 |
| COUNTER-CHARGE COVER | 613 | 345 | 160 | 4.44 | +9862 | +61.6 |
| MOVE TO CHARGE | 228 | 228 | 149 | 4.14 | +6109 | +41.0 |
| KILLS COUNT NEXT TURN | 455 | 455 | 145 | 4.03 | +4357 | +30.0 |
| FACES THE THREAT | 125 | 125 | 125 | 3.47 | +8672 | +69.4 |
| SUPPORTS | 357 | 357 | 125 | 3.47 | +1033 | +8.3 |
| FALLBACK BY WORTH | 402 | 402 | 117 | 3.25 | +5847 | +50.0 |
| WAIT AFTER COSTS | 498 | 498 | 79 | 2.19 | +1134 | +14.4 |
| ADVANCE LANE KEPT | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +9391 | +125.2 |
| REDIRECT COUNTER | 305 | 177 | 67 | 1.86 | +3692 | +55.1 |
| SHOTS IN THE MOVE | 763 | 507 | 64 | 1.78 | +1204 | +18.8 |
| BEST FACING | 60 | 60 | 60 | 1.67 | +2961 | +49.4 |
| MAX FOR POSITIONING | 393 | 224 | 60 | 1.67 | +807 | +13.5 |
| SAFER THAN THE JOB | 55 | 55 | 55 | 1.53 | +2774 | +50.4 |
| RANDOM MOVE BY FIGURES | 104 | 104 | 53 | 1.47 | +2253 | +42.5 |
| WALKS TO THE FIGHT | 80 | 80 | 51 | 1.42 | +634 | +12.4 |
| CHARGE NOW WEIGHED | 48 | 48 | 48 | 1.33 | +1518 | +31.6 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1606 | +35.7 |
| MARCH CHECK | 46 | 45 | 42 | 1.17 | +2000 | +47.6 |
| BLOCKED WHEEL | 40 | 40 | 40 | 1.11 | +1053 | +26.3 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +2307 | +64.1 |
| MISSILES IN THE MOVE | 243 | 139 | 36 | 1.00 | +899 | +25.0 |
| RISK BY ARC | 208 | 203 | 36 | 1.00 | +1229 | +34.1 |
| CANNON PLANNED TARGET | 209 | 209 | 35 | 0.97 | +116 | +3.3 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 129 | 129 | 35 | 0.97 | +1582 | +45.2 |
| CHARGE NOW FIRST | 176 | 176 | 34 | 0.94 | -2029 | -59.7 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +1560 | +48.7 |
| LANE BY FIGURES | 30 | 30 | 30 | 0.83 | +971 | +32.4 |
| KEEPS ITS TARGET | 128 | 128 | 29 | 0.81 | +500 | +17.2 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| SHOOTS FROM THE BEST SPOT | 59 | 59 | 27 | 0.75 | +832 | +30.8 |
| INVITES THE FIGHT | 129 | 129 | 26 | 0.72 | +338 | +13.0 |
| MOVE AND CAST | 26 | 26 | 26 | 0.72 | +1203 | +46.3 |
| SET UP TOGETHER | 69 | 55 | 26 | 0.72 | +2009 | +77.3 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +873 | +34.9 |
| CAST JOB | 41 | 41 | 23 | 0.64 | +309 | +13.4 |
| HONEST WORTH | 598 | 596 | 22 | 0.61 | +185 | +8.4 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 43 | 40 | 22 | 0.61 | +1298 | +59.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +1587 | +75.6 |
| BEST PREY | 63 | 63 | 20 | 0.56 | +481 | +24.0 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -30 | -1.6 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.53 | +46 | +2.4 |
| WEARS DOWN | 99 | 93 | 19 | 0.53 | +628 | +33.0 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +211 | +11.7 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +657 | +38.7 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -45 | -2.8 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +620 | +38.7 |
| CASTING BLOCK | 16 | 16 | 15 | 0.42 | +609 | +40.6 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MODEL FACING | 14 | 14 | 14 | 0.39 | +3752 | +268.0 |
| SURE CHARGE BEATS ADVANCE | 13 | 13 | 13 | 0.36 | -235 | -18.1 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 28 | 28 | 12 | 0.33 | -173 | -14.4 |
| HOLDER AT DEPLOYMENT | 31 | 31 | 11 | 0.31 | +357 | +32.5 |
| MAKE SURE TOGETHER | 41 | 29 | 11 | 0.31 | +626 | +56.9 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +495 | +49.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 192 | 192 | 9 | 0.25 | +200 | +22.3 |
| OPENS UP | 14 | 14 | 9 | 0.25 | +438 | +48.6 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 516 | 516 | 9 | 0.25 | -57 | -6.3 |
| HUNT IN PAIRS | 50 | 29 | 8 | 0.22 | +152 | +19.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +339 | +48.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| MISSILES NEXT TURN | 288 | 168 | 6 | 0.17 | +14 | +2.3 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +559 | +93.2 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -239 | -39.8 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +340 | +56.6 |
| REFUSING RETIRES | 23 | 23 | 6 | 0.17 | -1 | -0.2 |
| WHOLE FIGHT | 27 | 25 | 6 | 0.17 | +343 | +57.1 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -560 | -112.0 |
| LONG SHOT | 31 | 30 | 5 | 0.14 | +14 | +2.9 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +108 | +21.7 |
| SPELLS IN THE FIGHT | 62 | 57 | 5 | 0.14 | +185 | +37.0 |
| OVERRUNS AWAY | 42 | 41 | 4 | 0.11 | +242 | +60.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -295 | -73.7 |
| WIDER SPREAD | 220 | 212 | 4 | 0.11 | +16 | +4.0 |
| BACKUP TARGETS | 83 | 42 | 3 | 0.08 | +10 | +3.2 |
| EDGE GIVE GROUND | 17 | 17 | 3 | 0.08 | +309 | +102.9 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +48 | +16.0 |
| JOINT CHARGE PLAN | 8 | 8 | 3 | 0.08 | +219 | +73.0 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 34 | 34 | 3 | 0.08 | +87 | +29.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +70 | +34.8 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +78 | +39.1 |
| HILL BY ITS CHANCE | 44 | 44 | 2 | 0.06 | +106 | +52.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PURSUES ON | 2 | 2 | 2 | 0.06 | +100 | +49.9 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +52 | +26.1 |
| SURE REACH TOGETHER | 20 | 17 | 2 | 0.06 | +5 | +2.5 |
| CARRIES OUT SET-UP | 7 | 7 | 1 | 0.03 | -6 | -5.6 |
| CHARGER SLAIN LOST | 44 | 40 | 1 | 0.03 | +34 | +34.3 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -71 | -71.2 |
| DEFENSIVE ARMY | 6 | 6 | 1 | 0.03 | -34 | -33.9 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +36 | +36.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +5 | +5.2 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -154 | -153.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 19 | 19 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 11 | 11 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 40 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 463 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 29 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 16 | 12 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 10 | 10 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 13 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 27 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 472 | 472 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 4 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2820 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 7 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 133 | not checked | - | - | - | - |
| STABLE ROLE | 794 | 792 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 14 | 14 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.14 | 13.64 | 54.8 |
| FALLBACK | gate | 0.58 | 0.89 | 41.3 |
| TURN GATE | gate | 0.81 | 0.64 | 50.6 |
| CHARGE NOW FIRST | rule | 0.36 | 0.58 | 59.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.22 | 18.1 |
| WAR ENGINE JOBS | rule | 0.33 | - | 14.4 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.14 | 5.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.14 | 45.0 |
| PATHS CROSS | rule | 0.17 | 0.11 | 21.3 |
| FIGHT ORDER BAND | gate | 0.11 | 0.14 | 1.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.17 | 49.6 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.11 | 25.5 |
| SUPPORT NARROWED | rule | 0.06 | 0.17 | 7.1 |
| CHAFF PASSED | rule | 0.14 | 0.06 | 4.3 |
| PURSUES BIG PREY | rule | 0.03 | 0.14 | 39.8 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 3.9 |
| BEST PRIZE | rule | 0.06 | 0.08 | 112.0 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 73.7 |
| AFTERMATH BAND | gate | 0.08 | - | 3.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 193.4 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 11.2 |
| MARCH ODDS | rule | 0.03 | 0.03 | 47.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 172.3 |
| SAFER THAN THE JOB | rule | 0.06 | - | 1.6 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 8.1 |
| BLOCKED WHEEL | rule | 0.03 | - | 3.9 |
| CANNON PLANNED TARGET | rule | 0.03 | - | 51.9 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 5.6 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 71.2 |
| DEFENSIVE ARMY | rule | 0.03 | - | 33.9 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.7 |
| LONG SHOT | rule | 0.03 | - | 27.1 |
| NO REASON | gate | 0.03 | - | 13.2 |
| REFUSING RETIRES | rule | - | 0.03 | 0.6 |
| RULE SWITCHED OFF | gate | - | 0.03 | 5.7 |
| WHO HITS BACK | rule | 0.03 | - | 3.8 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 153.6 |

### Plans: dep-mine-13df7bd-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.7 | 15% | 384 | 347 | 90% |
| Mine | charge | 3.0 | 59% | 207 | 258 | 125% |
| Mine | close in | 4.2 | 30% | 151 | 143 | 94% |
| Mine | hold | 4.9 | 35% | 306 | 0 | 0% |
| Mine | join | 0.3 | 100% | 8 | 0 | 0% |
| Mine | shoot | 8.7 | 55% | 253 | 513 | 203% |
| Mine | support | 4.6 | 92% | 33 | 0 | 0% |
| Opponent | advance | 14.1 | 14% | 453 | 232 | 51% |
| Opponent | charge | 4.6 | 54% | 394 | 446 | 113% |
| Opponent | close in | 6.3 | 26% | 325 | 165 | 51% |
| Opponent | hold | 4.6 | 32% | 275 | 0 | 0% |
| Opponent | join | 0.8 | 86% | 39 | 0 | 0% |
| Opponent | shoot | 3.4 | 46% | 88 | 177 | 200% |
| Opponent | support | 6.3 | 90% | 33 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 601 | 0 | 0% | 8 |
| Opponent | 0.1 | 5 | 0 | 0% | 0% | 0% | - | 300 | 0 | 0% | 51 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 601 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 3 | 0 | 0% | 0% | 0% | - | 229 | 0 | 0% | 8 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 57 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 334 | 0 | 0% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 476 | 0 | 0% | 15 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |

### Battle groups: dep-mine-13df7bd-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.6 | 20% | 55% | 5% | 67% | 34% | 8% | 14% | 44% | 0% |
| Mine | REDIRECT COUNTER | 3.1 | 35% | 45% | 18% | 14% | 29% | 0% | 10% | 55% | 6% |
| Opponent | COUNTER-CHARGE COVER | 8.4 | 13% | 62% | 20% | 50% | 34% | 3% | 16% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 5.4 | 22% | 74% | 16% | 14% | 22% | 0% | 17% | 61% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 38 | 75% | 5.0 | 0 (3) | 0 (1) | - | - | 0 (4) |
| Mine | Chaff | 31 | 82 (31) | 24 | 59 | 53 | 39% | 2.6 | 71 (12) | 108 (13) | 56 (6) | 111 (23) | 7 (8) |
| Mine | Character | 105 | 48 (105) | 48 | 0 | 28 | 17% | 2.4 | 55 (44) | 42 (39) | 56 (12) | 47 (54) | 54 (41) |
| Mine | Clean-up | 29 | 33 (29) | 16 | 16 | 33 | 41% | 3.3 | 41 (13) | 30 (13) | 18 (3) | 45 (18) | 17 (11) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 55 (4) | 55 | 0 | 46 | 25% | 1.7 | 103 (2) | 0 (2) | - | 55 (4) | - |
| Mine | Fast Hammer | 39 | 51 (39) | 32 | 19 | 38 | 21% | 2.9 | 41 (20) | 73 (14) | 26 (5) | 76 (20) | 24 (19) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 2.7 | 0 (3) | 0 (1) | - | - | 0 (4) |
| Mine | Hammer | 63 | 27 (63) | 18 | 9 | 42 | 13% | 2.5 | 20 (27) | 37 (30) | 12 (6) | 36 (32) | 19 (31) |
| Mine | Holder | 30 | 108 (30) | 8 | 99 | 46 | 30% | 3.1 | 53 (10) | 145 (15) | 69 (5) | 136 (15) | 80 (15) |
| Mine | Shooter | 35 | 50 (35) | 19 | 31 | 55 | 6% | 1.7 | 49 (12) | 59 (15) | 29 (8) | 49 (23) | 51 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 27 (56) | 27 | 0 | 40 | 4% | 1.4 | 13 (27) | 41 (28) | 0 (1) | 26 (11) | 27 (45) |
| Mine | Wizard | 18 | 3 (18) | 3 | 0 | 19 | 6% | 2.2 | 35 (2) | 0 (9) | 0 (4) | 0 (3) | 5 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 74 | 45 (74) | 9 | 37 | 46 | 35% | 3.0 | 52 (32) | 59 (13) | 31 (29) | 53 (58) | 13 (16) |
| Opponent | Character | 97 | 51 (97) | 51 | 0 | 21 | 24% | 2.5 | 66 (38) | 38 (48) | 80 (5) | 61 (52) | 42 (39) |
| Opponent | Clean-up | 15 | 78 (15) | 45 | 33 | 30 | 27% | 3.4 | 60 (4) | 63 (9) | 165 (2) | 65 (9) | 87 (6) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 56 | 35 (56) | 22 | 14 | 35 | 20% | 3.2 | 37 (21) | 30 (24) | 44 (11) | 37 (39) | 31 (17) |
| Opponent | Fragile | 17 | 20 (17) | 20 | 0 | 51 | 12% | 2.3 | 0 (5) | 0 (8) | 82 (4) | 29 (12) | 0 (5) |
| Opponent | Hammer | 64 | 44 (64) | 30 | 14 | 40 | 30% | 3.5 | 18 (20) | 57 (37) | 8 (7) | 46 (39) | 42 (25) |
| Opponent | Holder | 29 | 51 (29) | 15 | 36 | 25 | 48% | 3.9 | 37 (9) | 70 (14) | 0 (5) | 65 (17) | 37 (11) |
| Opponent | Shooter | 35 | 87 (35) | 25 | 62 | 48 | 0% | 1.6 | 64 (11) | 103 (21) | 55 (3) | 104 (19) | 69 (16) |
| Opponent | Support | 6 | 103 (6) | 103 | 0 | 18 | 33% | 4.5 | 161 (4) | 0 (1) | 0 (1) | 211 (3) | 0 (3) |
| Opponent | War machine | 6 | 43 (6) | 43 | 0 | 50 | 0% | 1.0 | 25 (4) | 82 (2) | - | 25 (4) | 82 (2) |
| Opponent | Wizard | 19 | 26 (19) | 26 | 0 | 35 | 5% | 2.2 | 21 (11) | 42 (3) | 0 (2) | 1 (9) | 64 (7) |

### Charged fights: dep-mine-13df7bd-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 109 | 66 | 1.2 | 1.0 | 53 | 17 | +36 | 0 of 5 | 5 of 5 | - | +36 |
| Mine | Chaos Dwarfs | 4 | 183 | 178 | 2.2 | 1.0 | 79 | 0 | +79 | 2 of 9 | 7 of 9 | - | +79 |
| Mine | Dwarfen Mountain Holds | 3 | 241 | 32 | 1.7 | 1.0 | 19 | 0 | +19 | 0 of 5 | 2 of 5 | - | +19 |
| Mine | Empire of Man | 5 | 339 | 157 | 1.4 | 1.1 | 112 | 43 | +69 | 0 of 7 | 7 of 7 | +95 | +65 |
| Mine | Grand Cathay | 4 | 348 | 153 | 2.2 | 1.2 | 68 | 0 | +68 | 2 of 9 | 7 of 9 | +160 | +42 |
| Mine | High Elf Realms | 4 | 199 | 474 | 4.2 | 1.1 | 111 | 86 | +26 | 6 of 17 | 12 of 17 | +0 | +27 |
| Mine | Kingdom of Bretonnia | 1 | 55 | 355 | 3.0 | 1.7 | 118 | 0 | +118 | 2 of 3 | 2 of 3 | +0 | +178 |
| Mine | Lizardmen | 1 | 0 | 545 | 5.0 | 2.0 | 109 | 35 | +74 | 3 of 5 | 4 of 5 | +20 | +155 |
| Mine | Ogre Kingdoms | 2 | 127 | 180 | 2.0 | 1.0 | 90 | 81 | +9 | 1 of 4 | 3 of 4 | - | +9 |
| Mine | Skaven | 2 | 68 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 118 | 1320 | 5.5 | 1.3 | 240 | 29 | +211 | 4 of 11 | 7 of 11 | +178 | +218 |
| Mine | Vampire Counts | 2 | 106 | 407 | 4.5 | 1.1 | 90 | 5 | +85 | 4 of 9 | 6 of 9 | +500 | +34 |
| Mine | Warriors of Chaos | 2 | 0 | 358 | 4.0 | 1.2 | 90 | 36 | +53 | 3 of 8 | 6 of 8 | +0 | +71 |
| **Mine** | all armies | 36 | 185 | 272 | 2.6 | 1.2 | 105 | 32 | +73 | 28 of 93 | 69 of 93 | +102 | +68 |
| Opponent | Empire of Man | 1 | 460 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 140 | 510 | 4.8 | 1.1 | 106 | 26 | +81 | 15 of 24 | 13 of 24 | -143 | +101 |
| Opponent | Lizardmen | 2 | 0 | 432 | 4.5 | 1.1 | 96 | 0 | +96 | 7 of 9 | 8 of 9 | +0 | +108 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 529 | 4.3 | 1.0 | 122 | 27 | +95 | 6 of 13 | 10 of 13 | - | +95 |
| Opponent | Skaven | 4 | 150 | 110 | 2.5 | 1.0 | 44 | 0 | +44 | 4 of 10 | 9 of 10 | - | +44 |
| Opponent | Tomb Kings of Khemri | 2 | 108 | 977 | 5.5 | 1.6 | 178 | 24 | +154 | 4 of 11 | 10 of 11 | +320 | +15 |
| Opponent | Vampire Counts | 6 | 0 | 610 | 4.0 | 1.1 | 153 | 39 | +113 | 15 of 24 | 20 of 24 | +366 | +77 |
| Opponent | Warriors of Chaos | 7 | 0 | 437 | 3.1 | 1.1 | 139 | 8 | +131 | 8 of 22 | 17 of 22 | +155 | +129 |
| Opponent | Wood Elf Realms | 6 | 19 | 359 | 4.2 | 1.1 | 86 | 20 | +66 | 10 of 25 | 17 of 25 | +1 | +75 |
| **Opponent** | all armies | 36 | 58 | 452 | 3.8 | 1.1 | 118 | 21 | +97 | 69 of 138 | 104 of 138 | +170 | +88 |

### Effective charges: dep-mine-13df7bd-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -85) | 0 | 0 | 2 (net +84) | 0 | 1 (net +0) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 9 | 0 | 1 (net +599) | 2 (net +0) | 1 (net +0) | 1 (net +115) | 2 (net +0) | 2 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 2 (net +0) | 0 | 1 (net +35) | 1 (net +60) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 7 | 0 | 0 | 1 (net +0) | 2 (net +48) | 0 | 4 (net +98) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 9 | 0 | 0 | 5 (net +85) | 1 (net +0) | 0 | 3 (net +62) | 0 | 56% (5 of 9) |
| Mine | High Elf Realms | 17 | 3 (net +161) | 0 | 3 (net +42) | 5 (net +111) | 2 (net +60) | 3 (net -122) | 1 | 19% (3 of 16) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +210) | 1 | 50% (1 of 2) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net -175) | 1 (net +235) | 0 | 2 (net +28) | 1 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 4 | 1 (net -90) | 0 | 2 (net +0) | 0 | 0 | 1 (net +125) | 0 | 50% (2 of 4) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 3 (net +425) | 0 | 3 (net +131) | 2 (net -76) | 1 (net +54) | 2 (net +374) | 0 | 27% (3 of 11) |
| Mine | Vampire Counts | 9 | 2 (net -22) | 0 | 2 (net +250) | 2 (net +22) | 0 | 0 | 3 | 33% (2 of 6) |
| Mine | Warriors of Chaos | 8 | 0 | 0 | 1 (net -85) | 2 (net +142) | 2 (net +49) | 2 (net +166) | 1 | 14% (1 of 7) |
| Opponent | High Elf Realms | 24 | 5 (net +66) | 0 | 5 (net +1) | 3 (net +223) | 1 (net +0) | 7 (net +111) | 3 | 24% (5 of 21) |
| Opponent | Lizardmen | 9 | 2 (net +155) | 0 | 1 (net +0) | 3 (net +85) | 0 | 0 | 3 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 13 | 1 (net -350) | 0 | 1 (net +265) | 0 | 1 (net +40) | 3 (net +233) | 7 | 17% (1 of 6) |
| Opponent | Skaven | 10 | 2 (net +54) | 2 (net +40) | 0 | 1 (net +0) | 0 | 4 (net +64) | 1 | 0% (0 of 9) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net +572) | 0 | 1 (net -70) | 4 (net +252) | 2 (net +188) | 3 (net -65) | 0 | 9% (1 of 11) |
| Opponent | Vampire Counts | 24 | 4 (net +146) | 1 (net +328) | 6 (net -11) | 6 (net +132) | 0 | 5 (net +121) | 2 | 27% (6 of 22) |
| Opponent | Warriors of Chaos | 22 | 1 (net +0) | 0 | 5 (net +148) | 3 (net +59) | 2 (net +188) | 7 (net +145) | 4 | 28% (5 of 18) |
| Opponent | Wood Elf Realms | 25 | 6 (net +24) | 2 (net +196) | 4 (net +41) | 3 (net +122) | 1 (net +60) | 5 (net +128) | 4 | 19% (4 of 21) |

### Charged fights, damage counted: dep-mine-13df7bd-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 266 | 227 | +140 | 210 | 26 | +184 | +69.1 |
| Mine | 50-54% | 1 | 339 | 499 | +599 | 599 | 0 | +599 | +176.7 |
| Mine | Effective (55-75%) | 24 | 328 | 241 | +49 | 128 | 80 | +48 | +14.5 |
| Mine | 76-89% | 18 | 284 | 143 | +68 | 109 | 46 | +63 | +22.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 280 | 164 | +79 | 118 | 39 | +79 | +28.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 347 | 76 | +60 | 60 | 0 | +60 | +17.4 |
| Mine | No odds | 10 | 354 | 208 | +8 | 95 | 69 | +26 | +7.5 |
| Mine | All fights | 93 | 305 | 189 | +73 | 128 | 49 | +79 | +25.9 |
| Opponent | Long shot (under 50%) | 22 | 303 | 288 | +77 | 144 | 107 | +37 | +12.3 |
| Opponent | 50-54% | 5 | 373 | 298 | +160 | 183 | 25 | +158 | +42.4 |
| Opponent | Effective (55-75%) | 23 | 291 | 240 | +45 | 120 | 57 | +63 | +21.5 |
| Opponent | 76-89% | 23 | 250 | 207 | +142 | 144 | 17 | +127 | +50.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 330 | 193 | +112 | 158 | 33 | +124 | +37.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 508 | 104 | +121 | 128 | 2 | +126 | +24.9 |
| Opponent | No odds | 24 | 252 | 225 | +83 | 113 | 46 | +67 | +26.5 |
| Opponent | All fights | 138 | 303 | 223 | +97 | 139 | 47 | +92 | +30.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p4 | move | 467 | 113 (24%) | 81 (17%) | 46 (10%) | 308 (66%) |
| dep-mine-13df7bd-p4 | objective | 379 | 59 (16%) | 47 (12%) | 40 (11%) | 280 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

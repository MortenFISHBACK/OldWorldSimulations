# Doctrine scorecard: dep-mine-13df7bd-p5

### Scorecard: dep-mine-13df7bd-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0104 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0104 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 5 | - | 1 | 1 | 1 | 0 | 0 | 420 |
| L0204 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0220 | 4 | 1 | Mine | no | 2 | 3 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0220 | 4 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 1 | 0 | 0 | 420 |
| L0305 | 5 | 1 | Mine | no | - | - | 0 | 4 | 0 | 0 | 0 | 675 |
| L0305 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0321 | 3 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0321 | 3 | 1 | Opponent | yes | 15 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L0407 | 5 | 1 | Mine | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 609 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0510 | 6 | 1 | Opponent | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L0526 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0526 | 4 | 1 | Opponent | no | 6 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0614 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0614 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 798 |
| L0630 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0719 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 375 |
| L0719 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0735 | 3 | 1 | Mine | no | 4 | 1 | 1 | 1 | 1 | 0 | 0 | 497 |
| L0735 | 3 | 1 | Opponent | yes | 5 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0825 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 989 |
| L0825 | 3 | 1 | Opponent | yes | 7 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0915 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 668 |
| L0915 | 3 | 1 | Opponent | yes | 16 | 2 | 2 | 1 | 2 | 0 | 0 | 0 |
| L0932 | 2 | 1 | Mine | - | - | 2 | 0 | 1 | 1 | 0 | 0 | 560 |
| L0932 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 340 |
| L1024 | 4 | 1 | Mine | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1024 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1116 | 6 | 1 | Mine | no | 1 | 5 | 2 | 0 | 0 | 0 | 0 | 563 |
| L1116 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 2 | 0 | 0 | 0 | 200 |
| L1133 | 5 | 1 | Mine | no | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1133 | 5 | 1 | Opponent | no | - | 4 | 1 | 3 | 0 | 0 | 0 | 144 |
| L1226 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 2 | 0 | 0 | 165 |
| L1226 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1321 | 1 | 1 | Mine | no | 5 | 2 | 6 | 0 | 1 | 0 | 0 | 140 |
| L1321 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 2 | 0 | 0 | 0 | 500 |
| L1416 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1416 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1433 | 5 | 1 | Mine | yes | - | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1433 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 613 |
| L1529 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1529 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1627 | 1 | 1 | Mine | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1627 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 190 |
| L1725 | 3 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 98 |
| L1725 | 3 | 1 | Opponent | no | 5 | 1 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1825 | 1 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L1825 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1925 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1925 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2027 | 5 | 1 | Mine | no | - | - | 0 | 6 | 1 | 0 | 0 | 420 |
| L2027 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L2129 | 5 | 1 | Mine | yes | - | - | 2 | 2 | 0 | 0 | 0 | 145 |
| L2129 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2233 | 1 | 1 | Mine | yes | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2233 | 1 | 1 | Opponent | no | 0 | 1 | 8 | 2 | 0 | 0 | 0 | 236 |
| L2426 | 2 | 1 | Mine | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 343 |
| L2426 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2533 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 153 |
| L2533 | 1 | 1 | Opponent | no | 1 | 3 | 3 | 3 | 0 | 0 | 0 | 144 |
| L2733 | 3 | 1 | Mine | no | 6 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2733 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 144 |
| L3031 | 1 | 1 | Mine | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L3031 | 1 | 1 | Opponent | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 340 |
| **Average** | | | Mine | 23% | 1.6 | 2.3 | 2.2 | 1.2 | 0.3 | 0.0 | 0.0 | 302.4 |
| **Average** | | | Opponent | 35% | 4.0 | 2.4 | 2.1 | 2.0 | 0.3 | 0.0 | 0.0 | 168.0 |

### KPIs: dep-mine-13df7bd-p5

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 176) | 9% (16 of 172) | 18% (64 of 348) |
| Winner chose to follow up after the loser gave ground |  | 96% (51 of 53); on the table 96% | 97% (71 of 73); on the table 97% | 97% (122 of 126); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 78% | 100% (13 of 13); on the table 100% | 91% (20 of 22); on the table 91% |
| Winner chose to pursue after the loser fled |  | 72% (18 of 25); on the table 76% | 69% (20 of 29); on the table 79% | 70% (38 of 54); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 87% (76 of 87); on the table 89% | 90% (104 of 115); on the table 93% | 89% (180 of 202); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 29% (97 of 336) | 40% (77 of 192) | 33% (174 of 528) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (97 of 222) | 55% (77 of 141) | 48% (174 of 363) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 72% (18 of 25) | 37% (22 of 59) | 48% (40 of 84) |
| Points that never fought | lower | 38% (26992 of 70841) | 39% (27856 of 71983) | 38% (54848 of 142824) |
|   infantry points that never fought | lower | 53% (8354 of 15898) | 61% (9674 of 15955) | 57% (18028 of 31853) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (173 of 282) | 51% (142 of 276) | 56% (315 of 558) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.6 uses a game | 89% (16 of 18); 1.6 uses a game | 92% (35 of 38); 1.6 uses a game |
| Bound items with another spell used |  | 42% (8 of 19); 0.5 uses a game | 25% (2 of 8); 0.1 uses a game | 37% (10 of 27); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 40% (6 of 15); 0.2 uses a game | 54% (19 of 35); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33396 of 59757) | 45% (28552 of 63684) | 50% (61948 of 123441) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (29%) | 1.2 (37%) | 3.1 (32%) |
| MARCHED: its unit marched | 0.8 (11%) | 0.5 (17%) | 1.3 (13%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (3%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.6 (24%) | 0.6 (18%) | 2.2 (22%) |
| REAR RANK: in a rear rank | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.4 (21%) | 0.8 (23%) | 2.1 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.6 | 1.2 | 1.6 | 4.8 | 0.6 | 2.4 |
| not cast | 3.8 | 2.0 | 4.7 | 9.8 | 2.7 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (31%) | 0.4 (9%) | 3.1 (32%) | 0.8 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (13%) | 0.3 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.4 (21%) | 0.9 (18%) | 2.2 (22%) | 0.4 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.2 (8%) | 0.5 (11%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.9 (25%) | 0.6 (28%) | 0.9 (18%) | 2.1 (21%) | 0.8 (28%) | 4.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (8%) | 0.0 (1%) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (53%) | 0.1 (4%) | 1.9 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.8 a game | 0.8 a game |
| stood (cast and not dispelled) | 48% (12 of 25) | 62% (13 of 21) | 54% (25 of 46) |
| the unit moved after it | 92% (11 of 12) | 85% (11 of 13) | 88% (22 of 25) |
| it charged on its next turn | 0% (0 of 12) | 15% (2 of 13) | 8% (2 of 25) |
| the enemy charged it first | 17% (2 of 12) | 15% (2 of 13) | 16% (4 of 25) |
| it fought by the end of its next turn | 17% (2 of 12) | 8% (1 of 13) | 12% (3 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 12) | 8% (1 of 13) | 8% (2 of 25) |
| none of these (no charge, no fight, no charge escaped) | 67% (8 of 12) | 62% (8 of 13) | 64% (16 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (543 of 842) | 56% (274 of 493) | 61% (817 of 1335) |
|   cavalry | 53% (35 of 66) | 51% (59 of 115) | 52% (94 of 181) |
|   character | 49% (57 of 117) | 40% (29 of 72) | 46% (86 of 189) |
|   chariot | 49% (45 of 91) | 35% (14 of 40) | 45% (59 of 131) |
|   infantry | 60% (153 of 256) | 58% (111 of 192) | 59% (264 of 448) |
|   monster | 42% (15 of 36) | - | 42% (15 of 36) |
|   war machine | 86% (238 of 276) | 82% (61 of 74) | 85% (299 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (26%) | 2.2 (37%) | 4.4 (31%) |
| CHARGED: it charged | 1.0 (12%) | 1.3 (21%) | 2.3 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.4 (6%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.4 (17%) | 1.0 (16%) | 2.4 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.2 (4%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 0.6 (11%) | 2.1 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.2 (3%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.6 (7%) | 0.1 (1%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.5 | 0.6 | 84% | 4.1 pts | 14 pts |
| character | 2.6 | 0.8 | 78% | 6.9 pts | 18 pts |
| chariot | 1.6 | 1.2 | 61% | 16.2 pts | 27 pts |
| infantry | 11.1 | 4.9 | 71% | 11.8 pts | 131 pts |
| monster | 0.5 | 0.1 | 82% | 2.0 pts | 1 pts |
| war machine | 8.3 | 5.4 | 71% | 23.9 pts | 198 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.1 | 4.7 |
| Charges that made contact a game | 3.3 | 3.7 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.74 declared, 0.61 contact (23 units) | 0.43 declared, 0.33 contact (21 units) | 0.59 declared, 0.48 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.62 declared, 0.38 contact (8 units) | 1.14 declared, 1.00 contact (14 units) | 0.95 declared, 0.77 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.42 contact (240 units) | 0.59 declared, 0.42 contact (268 units) | 0.57 declared, 0.42 contact (508 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (30 of 70) | 57% (13 of 23) | 43% (3 of 7) | 46% (46 of 100) |
| Character in a unit | 83% (29 of 35) | 80% (12 of 15) | 0% (0 of 3) | 77% (41 of 53) |
| Character on its own | 87% (40 of 46) | 54% (20 of 37) | 29% (20 of 68) | 53% (80 of 151) |
| Chariot | 79% (11 of 14) | 47% (7 of 15) | - | 62% (18 of 29) |
| Infantry | 55% (42 of 76) | 51% (25 of 49) | 25% (1 of 4) | 53% (68 of 129) |
| Monster | 55% (11 of 20) | 50% (6 of 12) | - | 53% (17 of 32) |
| Monstrous | 50% (4 of 8) | 91% (10 of 11) | - | 74% (14 of 19) |
| War Machines | 72% (31 of 43) | 0% (0 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (6 of 6); on the table 100% | 29% (31 of 108) | 40% | 59% (13 of 22) | 83% (5 of 6); 3.8 uses a game | 50% (1 of 2); 0.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 6 | 89% (8 of 9); on the table 89% | 29% (12 of 42) | 49% | 48% (23 of 48) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 80% (4 of 5); on the table 80% | - | 71% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 82% (9 of 11); on the table 82% | 64% (23 of 36) | 30% | 70% (45 of 64) | 0.0 uses a game | 67% (2 of 3); 0.8 uses a game | 75% (3 of 4); 0.5 uses a game |
| Grand Cathay | 5 | 91% (10 of 11); on the table 91% | 36% (41 of 114) | 50% | 51% (23 of 45) | 100% (11 of 11); 6.8 uses a game | 0% (0 of 2); 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 84% (21 of 25); on the table 84% | 12% (3 of 24) | 32% | 39% (19 of 49) | 100% (5 of 5); 3.2 uses a game | 35% (7 of 20); 2.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (6 of 6); on the table 100% | - | 49% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (9 of 9); on the table 100% | - | 38% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 50% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 11% (2 of 18) | 3% | 88% (14 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 6 | 92% (11 of 12); on the table 100% | 33% (16 of 48) | 43% | 56% (27 of 48) | 67% (2 of 3); 1.0 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 2 | 90% (9 of 10); on the table 90% | 33% (2 of 6) | 31% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 13 | 100% (50 of 50); on the table 100% | 33% (34 of 102) | 38% | 57% (44 of 77) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 62% (15 of 24); on the table 75% | 50% (3 of 6) | 31% | 50% (22 of 44) | 100% (1 of 1); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 6 | 90% (19 of 21); on the table 90% | 29% (7 of 24) | 16% | 52% (32 of 62) | 91% (10 of 11); 5.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p5, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (34) | 53% (41) | 51% (75) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.67 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.28 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.47 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 0.97 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.69 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.83 | 5.39 | 11.22 |

### Quality by phase: dep-mine-13df7bd-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.2 |
| Strategy | Charge objectives carried out (made contact) | 58% (73 of 125) | 44% (68 of 156) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (123 of 367) | 48% (97 of 202) |
| Strategy | Close-in objectives charged next turn | 13% (19 of 149) | 12% (25 of 216) |
| Strategy | Support requests answered (helper made contact too) | 62% (10 of 16) | 59% (20 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (5 of 9) | 14% (1 of 7) |
| Strategy | Joined characters whose unit fought | 35% (17 of 48) | 30% (10 of 33) |
| Strategy | Lone characters that fought | 76% (72 of 95) | 76% (73 of 96) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.2 | 2.0 |
| Movement | Points that never moved of their own | 302.4 | 168.0 |
| Movement | Fights charged into per game | 2.8 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 91, net -19 | 13 of 86, net +109 |
| Movement | Charges with odds: sweet spot (55-75%) | 22 of 91, net +55 | 8 of 86, net +26 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 91, net +132 | 11 of 86, net +106 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 91, net +130 | 32 of 86, net +167 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 6.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (167 of 334) | 42% (101 of 238) |
| Shooting | Points destroyed by shooting units | 63.9 | 43.8 |
| Shooting | War machine shots | 6.6 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (123 of 238) | 31% (19 of 61) |
| Shooting | Points destroyed by war machines | 107.4 | 38.6 |
| Magic | Magic missiles cast | 1.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 18% (11 of 62) | 42% (20 of 48) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.7 |
| Magic | Wounds caused by other spells | 1.3 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 98.0 | 74.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.8 / 0.1 | 2.5 / 0.3 / 0.8 / 0.3 |
| Combat | Points destroyed in combat | 297.6 | 400.1 |
| Combat | Points run down | 94.5 | 170.3 |
| Combat | Net points per charged fight, damage counted | +85 | +112 |
| Combat | Net per 100 charger points, damage counted | +30.1 | +34.2 |
| Combat | First round won (charged fights) | 68% | 86% |
| Combat | Net points per charged fight | +84 | +115 |
| Combat | Net points per supported fight / lone fight | +172 / +66 | +150 / +105 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 100 | 42 of 105 |
| Game | Points lost | 819.3 | 706.9 |
| Game | VP from objectives | 473.1 | 633.1 |
| Game | Lone holders (player turns) | 1.6 | 4.0 |

- Mine won / drew / lost: 9 / 9 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -244 VP
- The side that went first won 17 of 27 games with a winner
- Points traded per game (both sides' losses): 1526
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 16.7 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.2 | +7.4 | 0.0 | 10.5 | 0.6 | +3.8 | 0.0 | 27.4 |
| BEST FACING | 0.8 | +40.2 | 0.0 | 53.0 | 0.4 | +18.0 | 0.0 | 27.1 |
| BEST FIRST | 4.6 | +192.5 | 135.8 | 75.9 | 4.4 | +173.7 | 141.9 | 29.1 |
| BEST OVERALL | 0.8 | +57.5 | 0.0 | 31.7 | 0.5 | +31.3 | 0.0 | 5.7 |
| BEST PREY | 0.7 | +49.7 | 49.2 | 14.5 | 0.8 | +40.6 | 10.7 | 3.5 |
| BEST PRIZE | - | - | - | - | 0.1 | -4.2 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 13.9 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 1.8 | 0.1 | +0.0 | 5.8 | 0.0 |
| BLOCKED WHEEL | 0.4 | +24.3 | 0.0 | 11.1 | 0.4 | +2.8 | 0.0 | 4.9 |
| BLOWS WHERE AIMED | 0.3 | -22.4 | 29.6 | 0.0 | 0.1 | -10.4 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 4.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 114.3 | 8.2 | 0.1 | +0.0 | 27.6 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +222.3 | 391.3 | 80.1 | 1.6 | +71.1 | 116.1 | 23.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.1 | -3.3 | 0.0 | 6.3 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | +0.0 | 38.1 | 0.0 | 0.1 | -6.2 | 4.3 | 1.7 |
| CAST JOB | 0.6 | +22.5 | 23.3 | 36.9 | 0.6 | +12.0 | 22.5 | 17.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +21.8 | 39.9 | 0.0 | 0.1 | +4.3 | 16.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 0.0 | 6.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.8 | 0.0 | 2.7 | 0.1 | -0.1 | 0.0 | 10.6 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 216.8 | 67.1 | 2.5 | +0.0 | 294.9 | 36.1 |
| CHARGE NOW WEIGHED | 0.7 | -40.2 | 32.7 | 16.2 | 0.4 | -34.2 | 11.7 | 2.5 |
| CHARGER SLAIN LOST | 0.5 | -12.9 | 42.2 | 17.8 | 0.5 | -11.7 | 52.9 | 22.5 |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.3 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 6.7 | 2.9 | 0.1 | +0.0 | 1.8 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 16.3 | 14.2 | 0.4 | +0.0 | 54.2 | 11.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +79.7 | 22.8 | 20.3 | 0.3 | +8.4 | 3.1 | 0.0 |
| COUNTER-CHARGE COVER | 10.1 | +944.5 | 0.0 | 248.4 | 6.8 | +525.9 | 0.0 | 200.3 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 74.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.6 | 11.1 | 2.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.1 | -10.5 | 0.0 | 9.9 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +2.7 | 5.5 | 1.2 |
| ELIXIR WORTH | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +134.9 | 0.0 | 64.8 | 1.0 | +90.8 | 0.0 | 55.2 |
| FALLBACK BY WORTH | 4.8 | +73.9 | 0.0 | 81.3 | 6.1 | +85.9 | 0.0 | 55.3 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 11.0 |
| FIRE AND FLEE | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 199.2 | 5.2 | +0.0 | 0.0 | 133.2 |
| FOLLOW UP WEIGHED | 1.2 | +178.4 | 0.0 | 91.9 | 1.4 | +175.1 | 0.0 | 5.8 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.5 | 0.0 | 7.1 | 0.1 | +4.7 | 0.0 | 15.2 |
| GIVES UP | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 6.3 | 3.1 | 0.1 | +0.0 | 21.2 | 9.4 |
| HELPER UNSEEN | 0.3 | +0.0 | 28.8 | 16.1 | 0.3 | +0.0 | 18.5 | 1.7 |
| HILL BY ITS CHANCE | 0.2 | -17.9 | 0.0 | 3.9 | 0.5 | -60.1 | 0.0 | 3.4 |
| HOLDER AT DEPLOYMENT | 0.9 | +139.2 | 0.0 | 3.1 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.6 | -133.8 | 319.9 | 162.9 | 8.1 | -181.7 | 590.5 | 148.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +6.5 | 0.0 | 9.3 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 4.6 | 4.1 |
| HUNT IN PAIRS | 0.3 | +8.6 | 0.0 | 18.6 | 0.6 | +22.4 | 0.0 | 15.1 |
| HUNT KEPT | - | - | - | - | 0.1 | +2.1 | 0.0 | 4.4 |
| HUNT RESULT | 0.1 | +14.8 | 0.0 | 0.0 | 0.1 | +1.8 | 8.1 | 4.1 |
| HUNT THE GUNS | 0.1 | +17.5 | 13.9 | 0.0 | 0.2 | +60.9 | 3.5 | 7.3 |
| INVITES THE FIGHT | 1.8 | +26.9 | 89.6 | 48.6 | 1.6 | +20.5 | 74.4 | 24.6 |
| JOINT CHARGE PLAN | 0.2 | +8.4 | 0.0 | 0.0 | 0.3 | +18.1 | 0.0 | 4.5 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.1 | 14.6 | 4.7 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 7.5 | - | - | - | - |
| KEEPS ITS TARGET | 1.7 | +50.8 | 134.6 | 44.1 | 1.7 | +50.8 | 221.8 | 19.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +76.7 | 64.9 | 48.8 | 2.0 | +136.0 | 230.3 | 30.4 |
| KILLS COUNT NEXT TURN | 4.7 | +156.4 | 174.5 | 132.3 | 6.6 | +220.5 | 285.8 | 132.1 |
| LANE BY FIGURES | 0.7 | +25.5 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.6 | +38.5 | 3.9 | 6.5 | 0.3 | +16.9 | 7.9 | 25.8 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 2.6 | 0.0 | 0.4 | +0.0 | 6.0 | 16.4 |
| LONE WIZARD KEPT IN | 0.6 | +33.4 | 0.0 | 0.0 | 0.2 | +19.2 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -2.6 | 30.5 | 13.6 | 0.4 | +0.7 | 26.4 | 25.2 |
| LOST CHARGE | 2.9 | -46.8 | 101.9 | 73.8 | 2.3 | -29.5 | 55.1 | 54.2 |
| LURE BY WHAT IT DRAWS | 0.1 | -2.6 | 0.0 | 0.0 | 0.1 | -9.5 | 0.0 | 4.0 |
| MAKE SURE TOGETHER | 0.8 | +93.4 | 41.5 | 6.5 | 0.8 | +51.4 | 23.3 | 43.5 |
| MANOEUVRE | 0.1 | +2.7 | 0.0 | 0.0 | 0.2 | +3.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +49.2 | 0.0 | 13.4 | 0.6 | +13.5 | 0.0 | 16.0 |
| MARCH ODDS | 0.2 | +21.4 | 9.4 | 0.0 | 0.2 | +8.2 | 13.7 | 0.0 |
| MARCH OVER CASTS | 0.4 | +17.8 | 0.0 | 0.0 | 0.3 | +15.5 | 0.0 | 16.9 |
| MAX FOR POSITIONING | 5.0 | +195.6 | 0.0 | 128.0 | 4.2 | +140.3 | 0.0 | 107.9 |
| MISSILES IN THE MOVE | 3.8 | +106.6 | 0.0 | 75.8 | 3.9 | +55.3 | 0.0 | 113.0 |
| MISSILES NEXT TURN | 4.7 | +77.3 | 0.0 | 75.8 | 4.5 | +44.2 | 0.0 | 130.2 |
| MODEL FACING | 0.4 | +118.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 10.9 | 6.5 | 0.5 | +0.0 | 6.2 | 13.9 |
| MOVE AND CAST | 0.3 | +20.6 | 0.0 | 4.7 | 0.4 | +8.9 | 0.0 | 19.4 |
| MOVE SPELL IN RANGE | 0.3 | +11.7 | 0.0 | 10.6 | 0.2 | +3.8 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -25.9 | 0.0 | 16.0 | 0.4 | -13.9 | 7.6 | 19.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.7 | +212.2 | 83.6 | 61.9 | 4.3 | +303.0 | 193.7 | 98.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +14.9 | 0.0 | 0.0 | 0.0 | +1.6 | 7.4 | 0.0 |
| NOT NEEDED | 0.1 | -5.6 | 13.4 | 1.7 | 0.3 | -9.2 | 51.4 | 9.6 |
| NOT TURNED | 5.8 | +145.6 | 0.0 | 186.3 | 5.4 | +70.8 | 0.0 | 109.8 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 14.4 | 0.6 | -0.6 | 0.0 | 36.6 |
| OFF BEST | 15.1 | -784.8 | 10.1 | 290.9 | 15.6 | -866.8 | 8.9 | 275.8 |
| OPENS A LANE | 0.2 | +13.3 | 13.6 | 0.0 | 0.1 | +0.1 | 3.2 | 12.1 |
| OPENS UP | 0.1 | +7.1 | 3.2 | 0.0 | 0.1 | +5.2 | 3.2 | 0.0 |
| OVERRUNS AWAY | 0.4 | +7.9 | 60.1 | 0.0 | 0.5 | +8.2 | 53.8 | 22.3 |
| PATHS CROSS | 2.0 | +135.6 | 0.0 | 16.4 | 2.5 | +165.1 | 0.0 | 31.2 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | 0.1 | +7.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.2 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 2.9 |
| PLAN RESULT | 37.6 | +1404.1 | 1784.2 | 1142.5 | 39.8 | +1256.5 | 1530.1 | 901.2 |
| PURSUES BIG PREY | 0.1 | -4.5 | 0.0 | 0.0 | 0.1 | -3.8 | 0.0 | 7.1 |
| PURSUES ON | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +13.5 | 0.0 | 13.5 | 1.6 | +15.3 | 0.0 | 47.4 |
| RANDOM MOVER NO PROMISE | 0.2 | -12.2 | 0.0 | 0.0 | 0.5 | -29.0 | 22.0 | 14.2 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.3 | 0.0 | 0.0 | 0.7 | -20.6 | 0.0 | 16.0 |
| REDIRECT COUNTER | 2.4 | +143.4 | 0.0 | 42.3 | 3.6 | +270.6 | 0.0 | 52.6 |
| REDIRECT WEIGHED | 0.1 | +1.2 | 2.9 | 7.7 | 0.4 | -1.0 | 3.5 | 7.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 28.1 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +20.8 | 0.0 | 16.8 | 0.8 | +29.5 | 0.0 | 9.3 |
| RESTRAINS TO SHOOT | 0.1 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.5 | +84.5 | 204.3 | 63.6 | 2.2 | +60.3 | 260.1 | 66.8 |
| SAFER THAN THE JOB | 0.9 | +53.1 | 0.0 | 6.5 | 0.7 | +36.7 | 0.0 | 13.2 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 2.1 | 0.1 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 2.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.5 | 0.0 | 1.2 | 0.6 | -39.3 | 0.0 | 4.7 |
| SEARCH SPOT | 2.3 | +116.2 | 0.0 | 56.7 | 2.5 | +144.9 | 0.0 | 32.0 |
| SELF MOVE SPELL | 0.2 | +18.9 | 0.0 | 0.0 | 0.2 | +70.0 | 0.0 | 40.1 |
| SET UP TOGETHER | 1.1 | +126.2 | 51.0 | 6.5 | 2.0 | +230.0 | 38.0 | 79.6 |
| SET-UP ANY TARGET | 0.3 | +52.2 | 19.5 | 20.3 | 0.1 | +13.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +2.9 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +21.7 | 29.7 | 5.1 | 1.0 | +15.2 | 37.8 | 19.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.7 | +0.0 | 146.5 | 17.6 | 0.2 | +0.0 | 34.8 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +742.7 | 0.0 | 266.7 | 7.3 | +256.6 | 0.0 | 171.1 |
| SPELL SETS UP CHARGE | 0.4 | +91.4 | 19.5 | 20.3 | 0.1 | +13.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +19.6 | 88.4 | 73.4 | 2.8 | +57.2 | 99.4 | 110.3 |
| SPELLS IN THE FIGHT | 0.8 | +5.6 | 64.0 | 26.0 | 0.6 | -3.5 | 100.0 | 14.4 |
| STABLE ROLE | 10.6 | +0.0 | 386.5 | 198.8 | 11.0 | +0.0 | 398.9 | 208.9 |
| STANDS TO CAST | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +0.5 | 13.9 | 0.0 | 0.1 | +2.2 | 3.5 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +28.8 | 0.0 | 25.4 | 0.4 | +23.6 | 0.0 | 18.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.9 | -47.3 | 455.6 | 114.5 | 5.8 | -37.9 | 316.2 | 103.9 |
| SUPPORTS | 4.0 | +48.8 | 262.8 | 52.1 | 3.7 | +47.8 | 132.1 | 59.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.1 | 1.7 | 13.1 | 0.1 | -3.6 | 17.0 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -0.8 | 7.6 | 4.2 | 0.6 | -0.2 | 8.5 | 20.1 |
| THROUGH LINE OF FIRE | 0.4 | +8.6 | 0.0 | 7.0 | 0.4 | +13.6 | 0.0 | 3.1 |
| TURN WORTH | 0.2 | -19.4 | 19.8 | 0.0 | 0.1 | -7.6 | 12.8 | 0.0 |
| TWO OR MORE ARRIVE | 0.6 | +9.0 | 30.4 | 6.5 | 0.6 | +6.8 | 9.0 | 18.4 |
| WAIT AFTER COSTS | 6.1 | -296.2 | 232.3 | 139.2 | 7.5 | -326.5 | 346.1 | 172.2 |
| WALKS TO THE FIGHT | 1.1 | +16.2 | 27.4 | 28.4 | 0.8 | +12.4 | 30.8 | 19.2 |
| WAR ENGINE CHARGES | 0.1 | +4.6 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 21.0 | 6.9 | 0.2 | +0.0 | 5.2 | 12.6 |
| WEARS DOWN | 1.3 | +61.4 | 132.9 | 32.4 | 0.8 | +24.8 | 116.1 | 16.0 |
| WHO HITS BACK | 0.4 | +25.8 | 0.0 | 34.1 | 0.2 | +12.2 | 0.0 | 13.1 |
| WHOLE FIGHT | 0.2 | +14.5 | 18.7 | 8.3 | 0.2 | +2.0 | 35.4 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +20.3 | 33.6 | 4.4 | 1.0 | +88.6 | 133.6 | 51.1 |
| WIDER SPREAD | 2.2 | -7.0 | 156.7 | 67.9 | 2.8 | -3.7 | 283.7 | 33.8 |

### Rule changes: dep-mine-13df7bd-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1106 | 1106 | 1106 | 30.72 | -59456 | -53.8 |
| BEST FIRST | 325 | 325 | 325 | 9.03 | +13180 | +40.6 |
| DEPLOY BY FIGURES | 290 | 290 | 179 | 4.97 | +2180 | +12.2 |
| SEARCH SPOT | 174 | 174 | 171 | 4.75 | +9412 | +55.0 |
| PATHS CROSS | 160 | 160 | 160 | 4.44 | +10822 | +67.6 |
| COUNTER-CHARGE COVER | 605 | 348 | 143 | 3.97 | +9894 | +69.2 |
| MOVE TO CHARGE | 253 | 253 | 121 | 3.36 | +6288 | +52.0 |
| KILLS COUNT NEXT TURN | 406 | 406 | 118 | 3.28 | +3675 | +31.1 |
| SUPPORTS | 276 | 276 | 98 | 2.72 | +1105 | +11.3 |
| FACES THE THREAT | 96 | 96 | 96 | 2.67 | +8125 | +84.6 |
| FOLLOW UP WEIGHED | 94 | 94 | 94 | 2.61 | +12727 | +135.4 |
| FALLBACK BY WORTH | 390 | 390 | 91 | 2.53 | +5755 | +63.2 |
| ARTILLERY RE-ROLL WEIGHED | 78 | 78 | 78 | 2.17 | +0 | +0.0 |
| ADVANCE LANE KEPT | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 758 | 503 | 61 | 1.69 | +3084 | +50.6 |
| WAIT AFTER COSTS | 491 | 491 | 61 | 1.69 | +1146 | +18.8 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +3232 | +56.7 |
| SET UP TOGETHER | 113 | 100 | 57 | 1.58 | +4728 | +82.9 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| MARCH CHECK | 49 | 47 | 46 | 1.28 | +3033 | +65.9 |
| RESERVE FALL BACK | 46 | 46 | 46 | 1.28 | +1810 | +39.3 |
| BEST FACING | 44 | 44 | 44 | 1.22 | +2097 | +47.7 |
| BEST OVERALL | 44 | 44 | 44 | 1.22 | +3196 | +72.6 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +3380 | +80.5 |
| WALKS TO THE FIGHT | 71 | 71 | 41 | 1.14 | +473 | +11.5 |
| RANDOM MOVE BY FIGURES | 84 | 84 | 40 | 1.11 | +1040 | +26.0 |
| KILLS COUNT | 123 | 120 | 38 | 1.06 | +1259 | +33.1 |
| MISSILES IN THE MOVE | 280 | 169 | 37 | 1.03 | +1003 | +27.1 |
| MAX FOR POSITIONING | 330 | 173 | 35 | 0.97 | +449 | +12.8 |
| REDIRECT COUNTER | 216 | 105 | 34 | 0.94 | +2513 | +73.9 |
| RISK BY ARC | 172 | 166 | 34 | 0.94 | +1126 | +33.1 |
| SHOT REPLANNED | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| CHARGE NOW FIRST | 169 | 169 | 32 | 0.89 | -2192 | -68.5 |
| SHOOTS FROM THE BEST SPOT | 68 | 68 | 32 | 0.89 | +446 | +13.9 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +976 | +32.5 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1888 | +62.9 |
| CAST JOB | 44 | 44 | 29 | 0.81 | +466 | +16.1 |
| HOLDS AMBUSHERS | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.81 | +1894 | +65.3 |
| WHOLE FIGHT GAIN | 48 | 46 | 29 | 0.81 | +1254 | +43.2 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1059 | +39.2 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +799 | +30.7 |
| CANNON PLANNED TARGET | 249 | 249 | 25 | 0.69 | -1084 | -43.4 |
| LANE BY FIGURES | 25 | 25 | 25 | 0.69 | +919 | +36.8 |
| HONEST WORTH | 531 | 527 | 24 | 0.67 | +163 | +6.8 |
| INVITES THE FIGHT | 123 | 123 | 23 | 0.64 | +227 | +9.9 |
| MAKE SURE TOGETHER | 56 | 44 | 23 | 0.64 | +1908 | +82.9 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +42 | +2.1 |
| KEEPS ITS TARGET | 122 | 121 | 19 | 0.53 | +350 | +18.4 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +777 | +40.9 |
| BEST PREY | 53 | 53 | 18 | 0.50 | +643 | +35.7 |
| CASTS FROM BEHIND | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 32 | 32 | 18 | 0.50 | +932 | +51.8 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +732 | +40.6 |
| MARCH ODDS | 18 | 18 | 17 | 0.47 | +160 | +9.4 |
| SCOUT WAITS | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WEARS DOWN | 77 | 76 | 16 | 0.44 | +471 | +29.4 |
| MODEL FACING | 14 | 14 | 14 | 0.39 | +4275 | +305.3 |
| CASTER AWAY FROM SCREEN | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 12 | 0.33 | +602 | +50.1 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -31 | -2.6 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | +4 | +0.4 |
| SUPPORT NARROWED | 424 | 424 | 10 | 0.28 | -77 | -7.7 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +330 | +36.7 |
| MANOEUVRE | 10 | 10 | 9 | 0.25 | +216 | +24.0 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -91 | -10.1 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -298 | -37.3 |
| REFUSING RETIRES | 21 | 21 | 8 | 0.22 | -1 | -0.2 |
| WAR ENGINE JOBS | 24 | 24 | 8 | 0.22 | -237 | -29.7 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| LOST CHARGE | 187 | 187 | 7 | 0.19 | +110 | +15.8 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -170 | -24.4 |
| HUNT IN PAIRS | 30 | 16 | 6 | 0.17 | +122 | +20.4 |
| MISSILES NEXT TURN | 332 | 193 | 6 | 0.17 | +62 | +10.3 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +133 | +22.2 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +93 | +18.6 |
| LONE WIZARD HOLDS BACK | 24 | 24 | 5 | 0.14 | -367 | -73.3 |
| BACKUP TARGETS | 63 | 32 | 4 | 0.11 | +7 | +1.8 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 33 | 32 | 4 | 0.11 | +160 | +39.9 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +386 | +96.4 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +170 | +42.5 |
| SURE REACH TOGETHER | 39 | 28 | 4 | 0.11 | +64 | +16.0 |
| WHOLE FIGHT | 14 | 13 | 4 | 0.11 | +413 | +103.3 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -376 | -125.2 |
| JOINT CHARGE PLAN | 16 | 16 | 3 | 0.08 | +313 | +104.4 |
| OPENS UP | 4 | 4 | 3 | 0.08 | +155 | +51.7 |
| SPELLS IN THE FIGHT | 51 | 49 | 3 | 0.08 | +59 | +19.6 |
| STUCK PIVOT | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 13 | 13 | 2 | 0.06 | -222 | -110.8 |
| DEFENSIVE ARMY | 21 | 21 | 2 | 0.06 | -70 | -35.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +54 | +26.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +23 | +11.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 33 | 32 | 2 | 0.06 | +1 | +0.6 |
| OPENS A LANE | 10 | 10 | 2 | 0.06 | +4 | +2.2 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +165 | +82.3 |
| BLOWS WHERE AIMED | 14 | 14 | 1 | 0.03 | +56 | +56.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +30 | +30.2 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -118 | -118.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -53 | -52.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +13 | +12.8 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.03 | +22 | +21.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +8 | +7.7 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +50 | +50.2 |
| MOVE SPELL IN RANGE | 20 | 10 | 1 | 0.03 | +4 | +3.8 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +30 | +30.4 |
| REDIRECT BY WHAT IT STOPS | 37 | 37 | 1 | 0.03 | +6 | +6.0 |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 1 | 0.03 | +24 | +24.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -24 | -23.5 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +3 | +3.3 |
| TWO OR MORE ARRIVE | 42 | 41 | 1 | 0.03 | +19 | +19.2 |
| WIDER SPREAD | 182 | 176 | 1 | 0.03 | +4 | +4.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 37 | 32 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 411 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 26 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 33 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 24 | 24 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 23 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 404 | 404 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| PLAN RESULT | 2783 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 146 | not checked | - | - | - | - |
| STABLE ROLE | 776 | 774 | 0 | 0.00 | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.64 | 14.11 | 53.7 |
| FALLBACK | gate | 0.47 | 0.86 | 62.3 |
| TURN GATE | gate | 0.56 | 0.39 | 48.5 |
| CHARGE NOW FIRST | rule | 0.42 | 0.44 | 70.7 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.03 | 103.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.14 | 10.1 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.03 | 75.9 |
| PURSUES BIG PREY | rule | 0.08 | 0.14 | 37.3 |
| SUPPORT NARROWED | rule | 0.03 | 0.19 | 9.6 |
| WAR ENGINE JOBS | rule | 0.19 | 0.03 | 29.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.11 | 24.4 |
| PATHS CROSS | rule | 0.14 | 0.03 | 33.3 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 92.0 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.03 | 6.2 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 6.3 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 52.3 |
| BEST PRIZE | rule | - | 0.08 | 125.2 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 122.2 |
| MARCH ODDS | rule | 0.03 | 0.06 | 8.7 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 6.3 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.06 | 5.7 |
| BLOCKED WHEEL | rule | 0.06 | - | 1.3 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 110.8 |
| DEFENSIVE ARMY | rule | - | 0.06 | 35.0 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 1.7 |
| NO REASON | gate | 0.06 | - | 17.3 |
| REFUSING RETIRES | rule | - | 0.06 | 0.7 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 118.3 |
| CATCH ODDS | rule | 0.03 | - | 52.6 |
| FACES THE THREAT | rule | 0.03 | - | 4.1 |
| FIGHT ORDER BAND | gate | - | 0.03 | 3.4 |
| STANDS TO CAST | rule | 0.03 | - | 23.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 8.3 |
| WHO HITS BACK | rule | - | 0.03 | 4.8 |

### Plans: dep-mine-13df7bd-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 16% | 452 | 310 | 69% |
| Mine | charge | 3.1 | 61% | 270 | 284 | 105% |
| Mine | close in | 4.1 | 22% | 295 | 113 | 38% |
| Mine | hold | 4.4 | 30% | 296 | 0 | 0% |
| Mine | join | 0.9 | 97% | 25 | 0 | 0% |
| Mine | shoot | 8.9 | 55% | 371 | 701 | 189% |
| Mine | support | 4.3 | 90% | 33 | 0 | 0% |
| Opponent | advance | 14.0 | 17% | 307 | 363 | 118% |
| Opponent | charge | 3.9 | 65% | 276 | 425 | 154% |
| Opponent | close in | 5.9 | 22% | 402 | 178 | 44% |
| Opponent | hold | 5.2 | 36% | 375 | 0 | 0% |
| Opponent | join | 1.2 | 96% | 58 | 0 | 0% |
| Opponent | shoot | 4.7 | 52% | 137 | 289 | 212% |
| Opponent | support | 4.9 | 89% | 38 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p5

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 315 | 266 | 50% | 39 |
| Opponent | 0.2 | 6 | 1 | 0% | 0% | 40% | - | 396 | 13 | 0% | 109 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 159 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 544 | 533 | 100% | 89 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 412 | 0 | 0% | 146 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 92 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 87 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 100% | - | 366 | 48 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 374 | 0 | 0% | 45 |
| Warriors of Chaos | 0.2 | 1 | 0 | 0% | 0% | 100% | - | 460 | 16 | 0% | 80 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 369 | 0 | 0% | 142 |

### Battle groups: dep-mine-13df7bd-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.1 | 19% | 57% | 12% | 50% | 25% | 8% | 18% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 25% | 68% | 9% | 0% | 15% | 0% | 5% | 75% | 5% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 20% | 78% | 14% | 14% | 36% | 7% | 21% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 16% | 67% | 0% | - | 24% | 0% | 5% | 67% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 28 | 0% | 4.4 | 0 (4) | 0 (1) | - | 0 (2) | 0 (3) |
| Mine | Chaff | 32 | 72 (32) | 7 | 65 | 59 | 25% | 2.9 | 18 (18) | 140 (10) | 145 (4) | 102 (24) | 0 (8) |
| Mine | Character | 125 | 48 (125) | 48 | 0 | 40 | 18% | 2.4 | 57 (47) | 60 (41) | 20 (21) | 51 (74) | 52 (35) |
| Mine | Clean-up | 20 | 77 (20) | 25 | 52 | 12 | 55% | 3.7 | 31 (6) | 97 (11) | 88 (3) | 81 (14) | 70 (6) |
| Mine | Fast | 4 | 122 (4) | 122 | 0 | 50 | 0% | 2.0 | - | 122 (4) | - | 122 (4) | - |
| Mine | Fast Hammer | 51 | 50 (51) | 40 | 11 | 54 | 16% | 2.9 | 60 (30) | 44 (14) | 22 (7) | 44 (38) | 67 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 3.6 | 0 (3) | 0 (2) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 57 | 27 (57) | 18 | 10 | 53 | 23% | 2.0 | 16 (26) | 42 (23) | 21 (8) | 26 (40) | 31 (17) |
| Mine | Holder | 22 | 19 (22) | 1 | 18 | 37 | 55% | 4.8 | 19 (7) | 13 (14) | 117 (1) | 22 (11) | 16 (11) |
| Mine | Shooter | 41 | 48 (41) | 23 | 25 | 50 | 5% | 1.5 | 36 (13) | 63 (18) | 41 (10) | 55 (27) | 36 (14) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 58 | 56 (58) | 56 | 0 | 43 | 2% | 1.3 | 53 (17) | 66 (32) | 26 (9) | 57 (9) | 55 (49) |
| Mine | Wizard | 18 | 8 (18) | 8 | 0 | 20 | 22% | 2.4 | 16 (7) | 0 (4) | 0 (4) | 0 (7) | 14 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 76 | 42 (76) | 11 | 30 | 48 | 55% | 2.7 | 44 (27) | 15 (17) | 54 (32) | 49 (44) | 33 (32) |
| Opponent | Character | 104 | 50 (104) | 50 | 0 | 35 | 19% | 2.3 | 52 (35) | 62 (45) | 12 (9) | 55 (50) | 52 (39) |
| Opponent | Clean-up | 25 | 63 (25) | 21 | 42 | 34 | 56% | 2.8 | 117 (5) | 58 (16) | 20 (4) | 70 (17) | 53 (8) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 49 | 41 (49) | 28 | 14 | 41 | 22% | 2.7 | 35 (24) | 69 (16) | 12 (9) | 39 (31) | 45 (18) |
| Opponent | Fragile | 11 | 22 (11) | 22 | 0 | 56 | 27% | 2.5 | 0 (1) | 39 (6) | 0 (4) | 35 (7) | 0 (4) |
| Opponent | Hammer | 51 | 65 (51) | 53 | 12 | 36 | 18% | 3.1 | 48 (11) | 62 (32) | 120 (8) | 74 (32) | 49 (19) |
| Opponent | Holder | 33 | 91 (33) | 4 | 86 | 19 | 67% | 3.7 | 106 (8) | 88 (18) | 108 (6) | 122 (19) | 62 (13) |
| Opponent | Shooter | 18 | 68 (18) | 31 | 36 | 63 | 0% | 1.3 | 35 (8) | 94 (10) | - | 28 (10) | 123 (8) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |
| Opponent | War machine | 14 | 88 (14) | 88 | 0 | 32 | 0% | 1.2 | 116 (1) | 88 (11) | 75 (2) | 61 (4) | 97 (10) |
| Opponent | Wizard | 25 | 7 (25) | 7 | 0 | 52 | 8% | 2.1 | 18 (10) | 0 (7) | 0 (4) | 8 (9) | 10 (12) |

### Charged fights: dep-mine-13df7bd-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 215 | 154 | 1.5 | 1.3 | 103 | 23 | +80 | 3 of 6 | 3 of 6 | +95 | +72 |
| Mine | Chaos Dwarfs | 4 | 331 | 259 | 2.5 | 1.2 | 104 | 12 | +91 | 6 of 10 | 8 of 10 | -29 | +121 |
| Mine | Dwarfen Mountain Holds | 4 | 534 | 31 | 1.0 | 1.2 | 31 | 68 | -37 | 1 of 4 | 2 of 4 | -105 | -14 |
| Mine | Empire of Man | 5 | 287 | 393 | 2.2 | 1.2 | 179 | 38 | +141 | 5 of 11 | 8 of 11 | +570 | +45 |
| Mine | Grand Cathay | 4 | 562 | 150 | 3.8 | 1.1 | 40 | 16 | +24 | 7 of 15 | 9 of 14 | +0 | +26 |
| Mine | High Elf Realms | 4 | 269 | 456 | 4.8 | 1.2 | 96 | 48 | +48 | 5 of 19 | 11 of 19 | +218 | +28 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 436 | 4.0 | 1.2 | 109 | 0 | +109 | 1 of 4 | 4 of 4 | +190 | +82 |
| Mine | Lizardmen | 1 | 45 | 1105 | 4.0 | 1.2 | 276 | 0 | +276 | 2 of 4 | 4 of 4 | +153 | +317 |
| Mine | Ogre Kingdoms | 1 | 254 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 1 of 3 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 299 | 3.0 | 1.3 | 100 | 195 | -95 | 1 of 3 | 2 of 3 | +254 | -270 |
| Mine | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 145 | -145 | 1 of 1 | 0 of 1 | - | -145 |
| Mine | Tomb Kings of Khemri | 1 | 317 | 870 | 4.0 | 1.0 | 218 | 0 | +218 | 0 of 4 | 3 of 4 | - | +218 |
| Mine | Vampire Counts | 3 | 0 | 681 | 4.3 | 1.4 | 157 | 24 | +133 | 1 of 13 | 10 of 13 | +183 | +111 |
| Mine | Warriors of Chaos | 1 | 0 | 608 | 3.0 | 1.0 | 203 | 0 | +203 | 1 of 3 | 2 of 3 | - | +203 |
| **Mine** | all armies | 36 | 269 | 320 | 2.8 | 1.2 | 115 | 31 | +84 | 35 of 100 | 67 of 99 | +172 | +66 |
| Opponent | Chaos Dwarfs | 2 | 152 | 156 | 3.0 | 1.2 | 52 | 11 | +41 | 2 of 6 | 5 of 6 | -65 | +62 |
| Opponent | Dwarfen Mountain Holds | 1 | 335 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 620 | 124 | 3.0 | 1.0 | 41 | 0 | +41 | 1 of 3 | 2 of 3 | - | +41 |
| Opponent | Grand Cathay | 1 | 350 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 2 | 228 | 678 | 6.0 | 1.2 | 113 | 33 | +80 | 7 of 12 | 10 of 12 | +19 | +101 |
| Opponent | Kingdom of Bretonnia | 2 | 75 | 264 | 3.0 | 1.2 | 88 | 0 | +88 | 3 of 6 | 5 of 6 | +151 | +75 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 235 | 1.0 | 1.0 | 235 | 0 | +235 | 0 of 1 | 0 of 1 | - | +235 |
| Opponent | Skaven | 4 | 88 | 138 | 0.8 | 1.0 | 184 | 0 | +184 | 1 of 3 | 2 of 3 | - | +184 |
| Opponent | Tomb Kings of Khemri | 1 | 139 | 310 | 3.0 | 1.3 | 103 | 0 | +103 | 3 of 3 | 3 of 3 | +310 | +0 |
| Opponent | Vampire Counts | 10 | 135 | 642 | 3.2 | 1.3 | 201 | 38 | +163 | 12 of 32 | 27 of 32 | +216 | +142 |
| Opponent | Warriors of Chaos | 5 | 13 | 535 | 3.4 | 1.4 | 157 | 20 | +137 | 8 of 17 | 16 of 17 | +160 | +125 |
| Opponent | Wood Elf Realms | 6 | 256 | 393 | 3.7 | 1.2 | 107 | 34 | +74 | 5 of 22 | 20 of 22 | +97 | +68 |
| **Opponent** | all armies | 36 | 157 | 413 | 2.9 | 1.3 | 142 | 26 | +115 | 42 of 105 | 90 of 105 | +150 | +105 |

### Effective charges: dep-mine-13df7bd-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net -85) | 0 | 2 (net +6) | 1 (net +242) | 0 | 1 (net +0) | 1 | 40% (2 of 5) |
| Mine | Chaos Dwarfs | 10 | 1 (net +526) | 0 | 2 (net +0) | 2 (net +98) | 2 (net +1) | 3 (net +63) | 0 | 20% (2 of 10) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net -135) | 1 (net +0) | 1 (net +123) | 0 | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 11 | 2 (net -94) | 1 (net +1140) | 0 | 5 (net +108) | 2 (net +28) | 1 (net +0) | 0 | 0% (0 of 11) |
| Mine | Grand Cathay | 15 | 3 (net +0) | 1 (net +385) | 4 (net -31) | 3 (net +0) | 0 | 2 (net +0) | 2 | 31% (4 of 13) |
| Mine | High Elf Realms | 19 | 4 (net -49) | 0 | 6 (net +0) | 3 (net +89) | 1 (net +232) | 3 (net +86) | 2 | 35% (6 of 17) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 2 (net +125) | 2 (net +93) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 1 (net +268) | 1 (net +153) | 0 | 1 (net +75) | 1 (net +609) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 1 (net -540) | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +290) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 13 | 1 (net -50) | 2 (net -52) | 4 (net +138) | 1 (net +258) | 4 (net +242) | 1 (net +104) | 0 | 31% (4 of 13) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +492) | 2 (net +58) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Chaos Dwarfs | 6 | 0 | 0 | 2 (net -32) | 1 (net +170) | 2 (net +71) | 0 | 1 | 40% (2 of 5) |
| Opponent | Empire of Man | 3 | 1 (net +0) | 0 | 0 | 1 (net +124) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | High Elf Realms | 12 | 0 | 0 | 0 | 2 (net +60) | 3 (net +97) | 4 (net +26) | 3 | 0% (0 of 9) |
| Opponent | Kingdom of Bretonnia | 6 | 0 | 0 | 1 (net +143) | 1 (net +151) | 0 | 2 (net +116) | 2 | 25% (1 of 4) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 1 (net +467) | 0 | 1 (net +85) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +310) | 0 | 33% (1 of 3) |
| Opponent | Vampire Counts | 32 | 8 (net +177) | 0 | 2 (net +126) | 9 (net +44) | 2 (net +0) | 11 (net +287) | 0 | 6% (2 of 32) |
| Opponent | Warriors of Chaos | 17 | 0 | 0 | 1 (net -270) | 2 (net +248) | 3 (net +220) | 8 (net +148) | 3 | 7% (1 of 14) |
| Opponent | Wood Elf Realms | 22 | 3 (net +3) | 0 | 1 (net +145) | 4 (net +120) | 1 (net +77) | 5 (net +58) | 8 | 7% (1 of 14) |

### Charged fights, damage counted: dep-mine-13df7bd-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 196 | 296 | -19 | 70 | 103 | -33 | -16.7 |
| Mine | 50-54% | 6 | 321 | 228 | +281 | 323 | 45 | +278 | +86.6 |
| Mine | Effective (55-75%) | 22 | 216 | 189 | +55 | 98 | 37 | +62 | +28.6 |
| Mine | 76-89% | 20 | 285 | 216 | +54 | 140 | 70 | +70 | +24.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 284 | 199 | +130 | 155 | 17 | +139 | +48.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 435 | 101 | +132 | 150 | 29 | +122 | +28.0 |
| Mine | No odds | 9 | 341 | 214 | +96 | 158 | 76 | +81 | +23.9 |
| Mine | All fights | 100 | 282 | 205 | +84 | 137 | 52 | +85 | +30.1 |
| Opponent | Long shot (under 50%) | 13 | 307 | 206 | +109 | 209 | 133 | +76 | +24.7 |
| Opponent | Effective (55-75%) | 8 | 272 | 220 | +26 | 127 | 71 | +56 | +20.5 |
| Opponent | 76-89% | 22 | 294 | 175 | +109 | 155 | 56 | +99 | +33.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 383 | 232 | +167 | 205 | 37 | +167 | +43.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 583 | 139 | +106 | 132 | 42 | +90 | +15.5 |
| Opponent | No odds | 19 | 155 | 129 | +82 | 104 | 12 | +93 | +59.8 |
| Opponent | All fights | 105 | 326 | 187 | +115 | 163 | 52 | +112 | +34.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p5 | move | 401 | 91 (23%) | 64 (16%) | 46 (11%) | 264 (66%) |
| dep-mine-13df7bd-p5 | objective | 365 | 44 (12%) | 32 (9%) | 54 (15%) | 267 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0104, L0120, L2426, L2533, L2733 |
| Charmed Shield | Opponent | L0526, L0825, L1024, L1226, L1627, L1725, L1825, L1925, L2027, L2426 |
| Clockwork Compass | Mine | L1226 |
| Elixir of Power | Mine | L1116, L1133, L1925 |
| Elixir of Power | Opponent | L0719 |
| Fistful of Laurels | Mine | L1825 |
| Horn of the Wild Hunt | Opponent | L1133, L1433, L2233, L2533, L2733 |
| Invocation of Nehek | Mine | L2426, L2533, L2733 |
| Invocation of Nehek | Opponent | L0825, L1024, L1627, L1725, L1825, L1925, L2027 |
| Opal Amulet | Mine | L1416, L1433 |
| Opal Amulet | Opponent | L0614 |
| Periapt of Soul Exchange | Mine | L2027, L2129 |
| Periapt of Soul Exchange | Opponent | L0120, L0220, L0321, L1321 |
| Ring of Doom | Mine | L0204, L0220, L1116, L1133, L1226, L1529 |
| Ring of Doom | Opponent | L0915, L1133, L1433, L2233, L2533, L2733, L3031 |
| Ring of Jet | Mine | L1024, L1116, L1133, L1226 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Mine | L1321 |
| Storm Daemon (Renegade 2.0) | Mine | L2129 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321, L1321 |
| Twice-Blessed Armour | Mine | L0719, L0735, L1024 |
| Twice-Blessed Armour | Opponent | L0407, L0510 |
| Witch Hunter's Ward | Mine | L0719, L0735, L0825 |
| Witch Hunter's Ward | Opponent | L0407 |

# Doctrine scorecard: dep-opp-13df7bd-p7

### Scorecard: dep-opp-13df7bd-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0112 | 4 | 1 | Mine | yes | 10 | - | 0 | 2 | 1 | 0 | 0 | 65 |
| L0112 | 4 | 1 | Opponent | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 498 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0212 | 2 | 1 | Mine | - | - | 3 | 0 | 2 | 1 | 0 | 0 | 170 |
| L0212 | 2 | 1 | Opponent | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0228 | 6 | 1 | Mine | yes | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0313 | 1 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0329 | 5 | 1 | Mine | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 590 |
| L0329 | 5 | 1 | Opponent | yes | - | 3 | 1 | 5 | 1 | 0 | 0 | 170 |
| L0415 | 1 | 1 | Mine | no | 10 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Opponent | no | 5 | 1 | 3 | 4 | 0 | 0 | 0 | 170 |
| L0518 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 548 |
| L0518 | 2 | 1 | Opponent | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 234 |
| L0535 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 731 |
| L0535 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0622 | 4 | 1 | Mine | no | 1 | 6 | 1 | 0 | 1 | 0 | 0 | 926 |
| L0622 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 55 |
| L0711 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0711 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 2 | 0 | 0 | 480 |
| L0727 | 1 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0727 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 60 |
| L0817 | 1 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 605 |
| L0817 | 1 | 1 | Opponent | no | 11 | 3 | 0 | 1 | 1 | 0 | 0 | 0 |
| L0833 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 515 |
| L0833 | 5 | 1 | Opponent | no | - | 3 | 0 | 5 | 0 | 0 | 0 | 236 |
| L0924 | 6 | 1 | Mine | no | 1 | 6 | 1 | 0 | 1 | 0 | 0 | 742 |
| L0924 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 60 |
| L1015 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1015 | 1 | 1 | Opponent | no | 1 | 3 | 4 | 1 | 1 | 0 | 0 | 199 |
| L1032 | 6 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1032 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 340 |
| L1124 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1124 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 0 | 0 | 0 | 60 |
| L1218 | 6 | 1 | Mine | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1218 | 6 | 1 | Opponent | no | 0 | - | 6 | 1 | 2 | 0 | 0 | 40 |
| L1234 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1234 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1329 | 3 | 1 | Mine | no | 5 | 3 | 1 | 0 | 1 | 0 | 0 | 317 |
| L1329 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 292 |
| L1424 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1424 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 235 |
| L1521 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 199 |
| L1521 | 3 | 1 | Opponent | no | 6 | - | 1 | 4 | 0 | 0 | 0 | 500 |
| L1618 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 307 |
| L1618 | 4 | 1 | Opponent | no | 2 | 6 | 4 | 0 | 2 | 0 | 0 | 556 |
| L1635 | 3 | 1 | Mine | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 307 |
| L1635 | 3 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 158 |
| L1734 | 6 | 1 | Mine | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1734 | 6 | 1 | Opponent | no | 3 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1833 | 3 | 1 | Mine | yes | 8 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1833 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 108 |
| L1934 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 1 | 0 | 0 | 255 |
| L1934 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2035 | 1 | 1 | Mine | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 420 |
| L2035 | 1 | 1 | Opponent | no | 1 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2225 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2225 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2329 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 185 |
| L2329 | 1 | 1 | Opponent | no | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 170 |
| L2435 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2435 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 1 | 0 | 0 | 0 |
| L2632 | 4 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2632 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 477 |
| L2834 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2834 | 2 | 1 | Opponent | - | - | 1 | 4 | 5 | 0 | 0 | 0 | 0 |
| L3135 | 3 | 1 | Mine | no | 5 | 2 | 2 | 1 | 2 | 0 | 0 | 314 |
| L3135 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 110 |
| **Average** | | | Mine | 24% | 3.5 | 2.5 | 2.1 | 0.9 | 0.3 | 0.0 | 0.0 | 300.3 |
| **Average** | | | Opponent | 10% | 2.5 | 2.3 | 2.8 | 1.7 | 0.4 | 0.0 | 0.0 | 157.7 |

### KPIs: dep-opp-13df7bd-p7

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (43 of 175) | 1% (2 of 188) | 12% (45 of 363) |
| Winner chose to follow up after the loser gave ground |  | 98% (53 of 54); on the table 98% | 98% (45 of 46); on the table 98% | 98% (98 of 100); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (12 of 15); on the table 80% | 93% (13 of 14); on the table 93% | 86% (25 of 29); on the table 86% |
| Winner chose to pursue after the loser fled |  | 83% (34 of 41); on the table 85% | 81% (29 of 36); on the table 86% | 82% (63 of 77); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 90% (99 of 110); on the table 91% | 91% (87 of 96); on the table 93% | 90% (186 of 206); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 37% (127 of 342) | 35% (54 of 156) | 36% (181 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (127 of 259) | 47% (54 of 116) | 48% (181 of 375) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 54% (14 of 26) | 43% (18 of 42) | 47% (32 of 68) |
| Points that never fought | lower | 36% (25408 of 71555) | 39% (28103 of 71977) | 37% (53511 of 143532) |
|   infantry points that never fought | lower | 47% (7104 of 15035) | 52% (7230 of 13842) | 50% (14334 of 28877) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (150 of 282) | 61% (178 of 294) | 57% (328 of 576) |
| Bound items with a magic missile used (at least once a game) |  | 91% (21 of 23); 1.7 uses a game | 81% (21 of 26); 1.6 uses a game | 86% (42 of 49); 1.6 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.3 uses a game | 50% (1 of 2); 0.1 uses a game | 56% (9 of 16); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (13 of 21); 0.4 uses a game | 40% (4 of 10); 0.1 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (30071 of 61235) | 55% (36383 of 65839) | 52% (66454 of 127074) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (32%) | 0.6 (22%) | 2.5 (28%) |
| MARCHED: its unit marched | 1.5 (25%) | 0.5 (18%) | 2.0 (22%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (8%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.3 (12%) | 1.6 (18%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |
| NO CASTS LEFT: every cast used on other spells | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| GONE: slain | 0.9 (15%) | 0.7 (24%) | 1.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.8 | 2.2 | 1.9 | 5.0 | 0.4 | 1.8 |
| not cast | 3.9 | 4.1 | 2.7 | 8.8 | 2.1 | 20.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (46%) | 0.1 (3%) | 2.5 (28%) | 0.2 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.5 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (1%) | 0.4 (15%) | 1.6 (18%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.6 (13%) | 0.1 (5%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (3%) | 0.1 (1%) | 0.0 (1%) | 0.3 (1%) |
| GONE: slain | 1.4 (36%) | 0.7 (17%) | 0.9 (34%) | 1.6 (18%) | 0.2 (8%) | 3.8 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.3 (16%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (4%) | 0.3 (7%) | 0.0 (0%) | 0.1 (1%) | 0.4 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (44%) | 0.5 (12%) | 1.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.8 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.1 a game | 1.0 a game |
| stood (cast and not dispelled) | 72% (23 of 32) | 69% (20 of 29) | 70% (43 of 61) |
| the unit moved after it | 83% (19 of 23) | 45% (9 of 20) | 65% (28 of 43) |
| it charged on its next turn | 9% (2 of 23) | 0% (0 of 20) | 5% (2 of 43) |
| the enemy charged it first | 13% (3 of 23) | 5% (1 of 20) | 9% (4 of 43) |
| it fought by the end of its next turn | 4% (1 of 23) | 5% (1 of 20) | 5% (2 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 26% (6 of 23) | 10% (2 of 20) | 19% (8 of 43) |
| none of these (no charge, no fight, no charge escaped) | 52% (12 of 23) | 85% (17 of 20) | 67% (29 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (550 of 803) | 55% (374 of 681) | 62% (924 of 1484) |
|   cavalry | 60% (50 of 84) | 61% (94 of 153) | 61% (144 of 237) |
|   character | 38% (29 of 77) | 30% (46 of 151) | 33% (75 of 228) |
|   chariot | 55% (51 of 92) | 62% (30 of 48) | 58% (81 of 140) |
|   infantry | 60% (137 of 227) | 60% (164 of 274) | 60% (301 of 501) |
|   monster | 50% (15 of 30) | 59% (16 of 27) | 54% (31 of 57) |
|   war machine | 91% (268 of 293) | 86% (24 of 28) | 91% (292 of 321) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (29%) | 2.4 (28%) | 4.4 (28%) |
| CHARGED: it charged | 0.8 (12%) | 2.1 (25%) | 3.0 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.2 (3%) | 1.0 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.4 (21%) | 1.7 (20%) | 3.2 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (6%) | 0.5 (6%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.9 (13%) | 1.1 (13%) | 2.1 (13%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.2 | 86% | 5.1 pts | 32 pts |
| character | 2.5 | 0.6 | 82% | 5.3 pts | 13 pts |
| chariot | 2.3 | 1.2 | 73% | 19.8 pts | 45 pts |
| infantry | 12.1 | 3.2 | 80% | 7.1 pts | 86 pts |
| monster | 0.9 | 0.2 | 82% | 4.0 pts | 4 pts |
| war machine | 8.1 | 7.5 | 55% | 30.2 pts | 245 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.8 | 4.9 |
| Charges that made contact a game | 3.3 | 4.1 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.80 declared, 0.68 contact (25 units) | 0.69 declared, 0.46 contact (13 units) | 0.76 declared, 0.61 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.40 declared, 0.20 contact (5 units) | 1.22 declared, 1.00 contact (9 units) | 0.93 declared, 0.71 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.43 contact (233 units) | 0.63 declared, 0.44 contact (301 units) | 0.58 declared, 0.44 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (46 of 82) | 61% (11 of 18) | 58% (7 of 12) | 57% (64 of 112) |
| Character in a unit | 83% (19 of 23) | 56% (10 of 18) | 80% (4 of 5) | 72% (33 of 46) |
| Character on its own | 85% (29 of 34) | 51% (24 of 47) | 31% (22 of 71) | 49% (75 of 152) |
| Chariot | 65% (11 of 17) | 73% (8 of 11) | - | 68% (19 of 28) |
| Infantry | 49% (41 of 83) | 58% (22 of 38) | 33% (1 of 3) | 52% (64 of 124) |
| Monster | 70% (19 of 27) | 57% (4 of 7) | - | 68% (23 of 34) |
| Monstrous | 65% (15 of 23) | 67% (8 of 12) | - | 66% (23 of 35) |
| War Machines | 58% (25 of 43) | 100% (2 of 2) | - | 60% (27 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 38% (39 of 102) | 44% | 50% (11 of 22) | 83% (5 of 6); 3.0 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (5 of 6); on the table 100% | 53% (16 of 30) | 47% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 80% (4 of 5); on the table 80% | - | 31% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 100% (8 of 8); on the table 100% | 42% (5 of 12) | 55% | 54% (28 of 52) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 75% (3 of 4); 0.6 uses a game |
| Grand Cathay | 8 | 93% (25 of 27); on the table 93% | 37% (66 of 180) | 43% | 51% (37 of 72) | 95% (19 of 20); 7.4 uses a game | 50% (1 of 2); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 6 | 93% (14 of 15); on the table 100% | 29% (7 of 24) | 41% | 57% (26 of 46) | 100% (8 of 8); 4.0 uses a game | 40% (4 of 10); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 92% (11 of 12); on the table 92% | - | 34% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 2 | 100% (2 of 2); on the table 100% | - | 53% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 90% (18 of 20); on the table 90% | 17% (4 of 24) | 38% | 57% (16 of 28) | 75% (3 of 4); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 3% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 71% (5 of 7); on the table 71% | 25% (3 of 12) | 30% | 62% (10 of 16) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 3 | 92% (11 of 12); on the table 92% | - | 20% | 53% (8 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 85% (17 of 20); on the table 85% | 35% (17 of 48) | 22% | 60% (27 of 45) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 89% (17 of 19); on the table 89% | 42% (10 of 24) | 36% | 54% (42 of 78) | 100% (1 of 1); 0.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 11 | 90% (35 of 39); on the table 92% | 47% (14 of 30) | 37% | 63% (71 of 112) | 56% (5 of 9); 1.4 uses a game | 0.0 uses a game | 33% (2 of 6); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p7, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (41) | 41% (28) | 45% (69) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.61 | 1.39 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.14 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.36 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.22 | 1.94 | 4.17 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.31 | 0.78 | 2.08 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.56 | 6.75 | 12.31 |

### Quality by phase: dep-opp-13df7bd-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 63% (83 of 132) | 43% (73 of 170) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (161 of 387) | 45% (88 of 194) |
| Strategy | Close-in objectives charged next turn | 18% (26 of 148) | 18% (39 of 211) |
| Strategy | Support requests answered (helper made contact too) | 77% (10 of 13) | 79% (22 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 48% (10 of 21) | 50% (12 of 24) |
| Strategy | Joined characters whose unit fought | 53% (25 of 47) | 29% (6 of 21) |
| Strategy | Lone characters that fought | 79% (77 of 97) | 71% (59 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 300.3 | 157.7 |
| Movement | Fights charged into per game | 2.9 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 92, net +83 | 14 of 104, net +61 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 92, net +122 | 23 of 104, net +71 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 92, net +69 | 7 of 104, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 92, net +152 | 29 of 104, net +133 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (138 of 316) | 47% (186 of 396) |
| Shooting | Points destroyed by shooting units | 49.6 | 31.7 |
| Shooting | War machine shots | 7.4 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (136 of 268) | 71% (17 of 24) |
| Shooting | Points destroyed by war machines | 116.4 | 8.2 |
| Magic | Magic missiles cast | 2.4 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (28 of 86) | 43% (20 of 46) |
| Magic | Wounds caused by magic missiles | 4.7 | 1.8 |
| Magic | Wounds caused by other spells | 1.6 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 89.9 | 38.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.6 / 1.0 / 0.1 | 1.6 / 0.8 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 346.3 | 430.8 |
| Combat | Points run down | 64.4 | 85.5 |
| Combat | Net points per charged fight, damage counted | +92 | +94 |
| Combat | Net per 100 charger points, damage counted | +34.2 | +30.3 |
| Combat | First round won (charged fights) | 82% | 66% |
| Combat | Net points per charged fight | +94 | +99 |
| Combat | Net points per supported fight / lone fight | +133 / +89 | +106 / +98 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 105 | 51 of 122 |
| Game | Points lost | 691.8 | 758.6 |
| Game | VP from objectives | 582.5 | 505.3 |
| Game | Lone holders (player turns) | 3.5 | 2.5 |

- Mine won / drew / lost: 15 / 7 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +151 VP
- The side that went first won 15 of 29 games with a winner
- Points traded per game (both sides' losses): 1450
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-opp-13df7bd-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 3.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +6.5 | 0.0 | 2.5 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 15.7 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 1.1 | +8.2 | 0.0 | 28.2 | 0.6 | +4.5 | 0.0 | 23.6 |
| BEST FACING | 1.2 | +49.1 | 0.0 | 31.7 | 0.9 | +41.9 | 0.0 | 25.0 |
| BEST FIRST | 5.1 | +206.3 | 192.4 | 171.4 | 3.7 | +120.8 | 140.5 | 93.7 |
| BEST OVERALL | 0.8 | +86.0 | 0.0 | 21.2 | 0.9 | +59.0 | 0.0 | 76.8 |
| BEST PREY | 0.9 | +49.9 | 12.6 | 40.0 | 1.2 | +91.7 | 39.6 | 16.0 |
| BEST PRIZE | 0.0 | -3.1 | 0.8 | 0.0 | 0.1 | -2.6 | 1.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.2 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 26.9 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 7.6 | 0.0 | 0.0 | +0.0 | 0.0 | 3.9 |
| BLOCKED WHEEL | 0.5 | +8.0 | 0.0 | 0.0 | 0.6 | +16.6 | 0.0 | 9.4 |
| BLOWS WHERE AIMED | 0.2 | -9.4 | 27.8 | 6.3 | 0.2 | -25.1 | 11.7 | 6.0 |
| BOMBING RUN | 0.0 | +2.2 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 49.6 | 1.9 | - | - | - | - |
| CANNON PLANNED TARGET | 6.1 | +213.4 | 451.1 | 81.1 | 0.4 | +4.0 | 3.1 | 18.3 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 4.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -5.8 | 9.1 | 7.2 | 0.1 | -2.5 | 13.2 | 0.0 |
| CAST JOB | 1.0 | +39.4 | 101.1 | 12.4 | 0.4 | +9.0 | 15.9 | 4.7 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +22.8 | 17.8 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 14.3 | 0.6 | +0.0 | 0.0 | 29.3 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 14.8 | 10.6 | 0.1 | -0.7 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +3.2 | 11.9 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.3 | +0.0 | 175.9 | 51.6 | 2.3 | +0.0 | 311.1 | 77.9 |
| CHARGE NOW WEIGHED | 0.6 | -42.2 | 29.9 | 40.3 | 0.8 | -61.4 | 29.8 | 39.8 |
| CHARGER SLAIN LOST | 0.4 | -10.7 | 43.1 | 19.1 | 0.5 | -13.4 | 39.4 | 9.5 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.3 | 0.0 | 26.1 | 0.1 | -1.0 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 1.8 | 3.4 | 0.1 | +0.0 | 5.4 | 1.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 29.7 | 42.5 | 0.3 | +0.0 | 20.6 | 16.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 2.0 |
| CONVEYANCE SEARCH | 0.6 | +131.8 | 2.5 | 8.9 | 0.8 | +82.0 | 21.3 | 24.2 |
| COUNTER-CHARGE COVER | 9.8 | +920.1 | 0.0 | 175.6 | 6.7 | +562.0 | 0.0 | 179.1 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | - | - | - | - | 8.2 | +46.8 | 0.0 | 32.1 |
| EDGE GIVE GROUND | 0.3 | +13.0 | 25.5 | 4.9 | 0.2 | +5.3 | 26.3 | 6.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +219.6 | 0.0 | 77.8 | 1.9 | +169.7 | 0.0 | 57.5 |
| FALLBACK BY WORTH | 5.1 | +96.3 | 0.0 | 53.3 | 5.3 | +63.2 | 0.0 | 56.1 |
| FIGHT LIFT | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +1.2 | 0.0 | 0.0 | 0.1 | +2.5 | 4.9 | 0.0 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 128.9 | 6.3 | +0.0 | 0.0 | 95.5 |
| FOCUS FIRE | 0.0 | +0.6 | 1.2 | 0.0 | 0.0 | +0.2 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +152.6 | 0.0 | 8.4 | 0.9 | +122.0 | 0.0 | 17.1 |
| FRIENDS SHOTS CHECKED | 0.4 | +13.8 | 0.0 | 0.0 | 0.1 | +7.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 9.0 | 0.0 | 0.1 | -2.0 | 7.1 | 3.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 1.1 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 9.6 | 7.2 | 0.1 | +0.0 | 5.8 | 6.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 27.8 | 2.4 | 0.4 | +0.0 | 25.8 | 7.2 |
| HILL BY ITS CHANCE | 0.3 | -10.8 | 0.0 | 1.5 | 0.5 | -55.9 | 0.0 | 3.1 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +184.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.6 | -137.9 | 425.7 | 94.4 | 8.3 | -186.0 | 526.6 | 213.6 |
| HORN WORTH | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +9.5 | 13.8 | 0.0 | 0.2 | +6.9 | 4.6 | 5.7 |
| HUNT DROPPED | 0.1 | +0.0 | 9.2 | 3.4 | 0.1 | +0.0 | 0.0 | 4.9 |
| HUNT IN PAIRS | 0.1 | +1.0 | 0.0 | 0.0 | 0.5 | +30.0 | 0.0 | 5.4 |
| HUNT KEPT | 0.2 | +4.2 | 13.8 | 0.0 | 0.0 | +0.0 | 0.0 | 2.5 |
| HUNT RESULT | 0.1 | +8.9 | 9.2 | 3.4 | 0.2 | +15.4 | 4.6 | 8.1 |
| HUNT THE GUNS | 0.1 | +53.6 | 4.6 | 3.1 | 0.2 | +95.1 | 9.2 | 5.7 |
| INVITES THE FIGHT | 1.9 | +39.2 | 142.6 | 19.2 | 1.1 | +19.5 | 49.8 | 15.4 |
| JOINT CHARGE PLAN | 0.1 | +5.0 | 0.0 | 0.0 | 0.1 | +5.6 | 0.0 | 5.2 |
| JOINT KNOWS CHALLENGE | 0.2 | -4.7 | 19.3 | 3.8 | 0.2 | -8.7 | 0.0 | 7.7 |
| KEEP FALLS | 0.2 | +3.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.1 | 3.8 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.1 | +61.7 | 145.8 | 25.1 | 1.9 | +58.3 | 172.1 | 41.5 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +73.8 | 121.0 | 23.8 | 1.9 | +124.9 | 253.9 | 41.2 |
| KILLS COUNT NEXT TURN | 5.1 | +115.0 | 222.3 | 86.7 | 7.3 | +276.6 | 222.2 | 151.9 |
| LANE BY FIGURES | - | - | - | - | 1.0 | +43.9 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.4 | +27.6 | 8.1 | 16.2 | 0.2 | +5.9 | 0.0 | 24.9 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 5.4 | 0.1 | +0.0 | 8.3 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +36.8 | 0.0 | 0.0 | 0.1 | +11.6 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +0.5 | 7.6 | 30.4 | 0.7 | +0.8 | 58.1 | 9.4 |
| LOST CHARGE | 3.2 | -52.4 | 216.1 | 51.4 | 2.2 | -43.9 | 88.2 | 68.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -12.7 | 0.0 | 5.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +33.8 | 18.9 | 16.5 | 0.7 | +61.3 | 0.0 | 17.8 |
| MANOEUVRE | 0.2 | +9.0 | 0.0 | 2.5 | 0.2 | +1.8 | 0.0 | 7.6 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +42.4 | 0.0 | 0.0 | 0.4 | +24.9 | 0.0 | 11.0 |
| MARCH ODDS | 0.3 | +18.1 | 20.1 | 0.0 | 0.2 | +17.9 | 5.1 | 14.0 |
| MARCH OVER CASTS | 0.5 | +43.4 | 0.0 | 42.1 | 0.6 | +53.7 | 0.0 | 11.0 |
| MAX FOR POSITIONING | 5.2 | +187.5 | 0.0 | 92.9 | 4.6 | +154.2 | 0.0 | 102.2 |
| MISSILES IN THE MOVE | 4.6 | +211.4 | 0.0 | 76.8 | 3.1 | +48.2 | 0.0 | 125.5 |
| MISSILES NEXT TURN | 5.6 | +141.2 | 0.0 | 137.2 | 3.7 | +33.0 | 0.0 | 147.6 |
| MODEL FACING | 0.2 | +36.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 16.6 | 16.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +36.4 | 0.0 | 2.2 | 0.4 | +7.7 | 0.0 | 7.4 |
| MOVE SPELL IN RANGE | 0.2 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -11.2 | 0.0 | 9.9 | 0.2 | -2.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 2.9 | +122.7 | 117.5 | 70.4 | 3.5 | +273.8 | 123.1 | 104.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 9.1 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +10.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.2 | 0.0 | 4.9 |
| NOT NEEDED | 0.1 | -3.9 | 10.6 | 6.1 | 0.4 | -15.2 | 58.9 | 3.6 |
| NOT TURNED | 5.6 | +94.9 | 0.0 | 131.2 | 6.8 | +118.0 | 0.0 | 135.2 |
| NOT WORTH A CAST | 0.7 | -0.6 | 0.0 | 23.8 | 0.4 | -0.5 | 0.0 | 7.6 |
| OFF BEST | 15.8 | -884.6 | 0.0 | 274.1 | 16.0 | -946.7 | 0.0 | 356.0 |
| OPENS A LANE | 0.2 | +1.6 | 17.6 | 0.0 | 0.0 | +0.2 | 1.8 | 0.0 |
| OPENS UP | 0.2 | +11.8 | 11.2 | 0.0 | 0.2 | +19.7 | 11.7 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +1.5 | 0.0 | 9.6 |
| OVERRUNS AWAY | 0.4 | +14.2 | 28.0 | 5.4 | 0.5 | +10.9 | 58.5 | 0.0 |
| PATHS CROSS | 2.1 | +118.8 | 0.0 | 20.4 | 2.8 | +196.4 | 0.0 | 32.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.2 | -5.2 | 0.0 | 14.3 | 0.1 | -0.8 | 0.0 | 9.4 |
| PLAN RESULT | 37.6 | +1678.0 | 1440.4 | 941.6 | 38.9 | +1075.7 | 1368.7 | 1119.1 |
| PURSUES BIG PREY | 0.1 | -15.2 | 0.0 | 4.9 | 0.2 | -14.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 0.0 | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.9 | 0.0 | 3.1 | 0.1 | +12.2 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +9.9 | 0.0 | 18.9 | 1.2 | +11.9 | 0.0 | 58.6 |
| RANDOM MOVER NO PROMISE | 0.3 | -14.8 | 6.2 | 0.0 | 0.3 | -9.9 | 6.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.0 | 0.0 | 2.3 | 1.1 | -6.1 | 0.0 | 7.3 |
| REDIRECT COUNTER | 1.6 | +146.0 | 0.0 | 34.6 | 5.8 | +412.8 | 0.0 | 80.3 |
| REDIRECT WEIGHED | 0.1 | -3.1 | 0.8 | 4.9 | 0.2 | +1.5 | 7.6 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +22.2 | 0.0 | 14.7 | 0.7 | +25.6 | 0.0 | 14.6 |
| RESTRAINS TO SHOOT | 0.1 | +2.9 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +130.9 | 188.5 | 56.9 | 3.0 | +70.1 | 328.9 | 73.2 |
| SAFER THAN THE JOB | 1.3 | +94.9 | 0.0 | 22.4 | 0.8 | +47.2 | 0.0 | 55.9 |
| SCOUT SPOT | 0.4 | +0.8 | 0.0 | 0.9 | 0.2 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.2 | 0.0 | 0.0 | 0.5 | -31.8 | 0.0 | 2.2 |
| SEARCH SPOT | 2.8 | +150.5 | 0.0 | 49.1 | 2.7 | +123.3 | 0.0 | 22.0 |
| SECOND HUNTER | 0.1 | -1.7 | 4.6 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.1 | +0.7 | 0.0 | 20.0 | 0.3 | +66.0 | 0.0 | 21.9 |
| SET UP TOGETHER | 1.4 | +94.2 | 32.4 | 58.2 | 1.3 | +106.6 | 13.9 | 45.7 |
| SET-UP ANY TARGET | 0.3 | +69.6 | 2.5 | 3.6 | 0.3 | +20.9 | 21.3 | 24.2 |
| SET-UP MISSED | 0.1 | +12.3 | 0.0 | 0.0 | 0.1 | +15.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +51.4 | 102.6 | 14.6 | 1.0 | +34.9 | 59.4 | 26.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 39.7 | 4.6 | 0.2 | +0.0 | 21.7 | 2.0 |
| SHOTS IN THE MOVE | 13.9 | +594.3 | 0.0 | 229.1 | 9.4 | +242.0 | 0.0 | 187.3 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 2.5 | 0.0 | 0.1 | -3.4 | 0.0 | 0.0 |
| SPELL OFF EDGE | 0.0 | +2.9 | 4.7 | 9.9 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +132.5 | 2.5 | 6.2 | 0.3 | +38.9 | 21.3 | 24.2 |
| SPELL WORTH | 1.1 | +25.7 | 136.0 | 116.3 | 2.1 | +44.0 | 81.2 | 78.2 |
| SPELLS IN THE FIGHT | 0.4 | +2.5 | 25.9 | 7.0 | 0.7 | -14.1 | 122.5 | 34.2 |
| STABLE ROLE | 10.6 | +0.0 | 511.4 | 148.2 | 9.8 | +0.0 | 292.0 | 222.5 |
| STANDS TO CAST | 0.1 | +5.9 | 3.1 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +0.1 | 0.0 | 3.1 | 0.1 | +1.9 | 4.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +25.5 | 0.0 | 22.6 | 0.6 | +23.3 | 0.0 | 29.7 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.1 | -43.8 | 185.0 | 87.3 | 7.2 | -56.7 | 333.7 | 101.4 |
| SUPPORTS | 3.3 | +56.1 | 65.1 | 46.8 | 5.3 | +58.4 | 151.1 | 51.7 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -2.9 | 17.0 | 0.0 | 0.1 | -1.3 | 5.4 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +3.0 | 3.4 | 17.6 | 0.6 | +1.8 | 19.1 | 33.8 |
| THROUGH LINE OF FIRE | 0.5 | +32.2 | 0.0 | 12.6 | 0.2 | +11.9 | 0.0 | 2.5 |
| TURN WORTH | 0.3 | -19.2 | 26.5 | 4.9 | 0.2 | -16.2 | 22.2 | 5.7 |
| TWO OR MORE ARRIVE | 0.4 | +2.4 | 18.1 | 14.5 | 0.3 | +2.1 | 0.0 | 5.4 |
| WAIT AFTER COSTS | 6.4 | -311.9 | 314.5 | 98.8 | 6.8 | -313.0 | 242.9 | 175.7 |
| WALKS TO THE FIGHT | 1.2 | +24.0 | 33.5 | 3.0 | 1.1 | +20.0 | 23.1 | 27.2 |
| WAR ENGINE CHARGES | 0.0 | +4.5 | 5.8 | 0.0 | 0.0 | +0.7 | 2.8 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 41.3 | 13.3 | 0.3 | +0.0 | 1.7 | 11.2 |
| WEARS DOWN | 1.1 | +40.8 | 90.6 | 32.2 | 1.2 | +32.3 | 109.0 | 37.3 |
| WHO HITS BACK | 0.3 | +27.7 | 0.0 | 6.3 | 0.2 | +15.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +3.1 | 11.9 | 1.1 | 0.4 | +29.4 | 54.8 | 3.2 |
| WHOLE FIGHT GAIN | 0.4 | +33.7 | 37.3 | 14.7 | 0.7 | +44.7 | 62.9 | 13.6 |
| WIDER SPREAD | 2.5 | -5.6 | 192.8 | 47.7 | 3.2 | -7.1 | 358.9 | 71.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 6.1 | 16.6 |

### Rule changes: dep-opp-13df7bd-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1146 | 1146 | 1146 | 31.83 | -65926 | -57.5 |
| BEST FIRST | 318 | 318 | 318 | 8.83 | +11778 | +37.0 |
| SEARCH SPOT | 195 | 195 | 194 | 5.39 | +9861 | +50.8 |
| COUNTER-CHARGE COVER | 595 | 316 | 179 | 4.97 | +12357 | +69.0 |
| PATHS CROSS | 176 | 176 | 176 | 4.89 | +11346 | +64.5 |
| DEPLOY BY FIGURES | 297 | 297 | 167 | 4.64 | +1835 | +11.0 |
| FACES THE THREAT | 150 | 150 | 150 | 4.17 | +14014 | +93.4 |
| KILLS COUNT NEXT TURN | 449 | 449 | 145 | 4.03 | +3181 | +21.9 |
| MOVE TO CHARGE | 231 | 231 | 120 | 3.33 | +4851 | +40.4 |
| SUPPORTS | 309 | 309 | 104 | 2.89 | +1184 | +11.4 |
| FALLBACK BY WORTH | 377 | 377 | 92 | 2.56 | +5740 | +62.4 |
| SHOTS IN THE MOVE | 838 | 549 | 77 | 2.14 | +1787 | +23.2 |
| BEST FACING | 76 | 76 | 76 | 2.11 | +3276 | +43.1 |
| SAFER THAN THE JOB | 75 | 75 | 75 | 2.08 | +5115 | +68.2 |
| ARTILLERY RE-ROLL WEIGHED | 73 | 73 | 73 | 2.03 | +0 | +0.0 |
| WAIT AFTER COSTS | 476 | 476 | 72 | 2.00 | +1622 | +22.5 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +9885 | +139.2 |
| CANNON SIGHT KEPT | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| BEST OVERALL | 61 | 61 | 61 | 1.69 | +5222 | +85.6 |
| REDIRECT COUNTER | 265 | 152 | 57 | 1.58 | +5280 | +92.6 |
| MAX FOR POSITIONING | 351 | 202 | 56 | 1.56 | +732 | +13.1 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| SET UP TOGETHER | 97 | 88 | 55 | 1.53 | +3051 | +55.5 |
| RISK BY ARC | 203 | 192 | 50 | 1.39 | +1656 | +33.1 |
| CHARGE NOW WEIGHED | 47 | 47 | 47 | 1.31 | +3058 | +65.1 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1721 | +36.6 |
| WALKS TO THE FIGHT | 83 | 83 | 46 | 1.28 | +645 | +14.0 |
| SHOOTS FROM THE BEST SPOT | 79 | 79 | 43 | 1.19 | +1528 | +35.5 |
| CANNON PLANNED TARGET | 232 | 232 | 41 | 1.14 | -1022 | -24.9 |
| KILLS COUNT | 133 | 128 | 41 | 1.14 | +2831 | +69.1 |
| MISSILES IN THE MOVE | 277 | 155 | 41 | 1.14 | +1651 | +40.3 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +885 | +22.7 |
| LANE BY FIGURES | 36 | 36 | 36 | 1.00 | +1581 | +43.9 |
| MARCH CHECK | 42 | 39 | 36 | 1.00 | +2716 | +75.5 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +1756 | +50.2 |
| CHARGE NOW FIRST | 166 | 166 | 33 | 0.92 | -1208 | -36.6 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 68 | 68 | 32 | 0.89 | +786 | +24.6 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1587 | +54.7 |
| KEEPS ITS TARGET | 144 | 140 | 28 | 0.78 | +372 | +13.3 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1590 | +56.8 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| INVITES THE FIGHT | 108 | 108 | 27 | 0.75 | +421 | +15.6 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 25 | 25 | 25 | 0.69 | +1743 | +69.7 |
| BEST PREY | 75 | 75 | 23 | 0.64 | +1280 | +55.6 |
| CAST JOB | 49 | 49 | 23 | 0.64 | +756 | +32.9 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.61 | +42 | +1.9 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +176 | +8.4 |
| HONEST WORTH | 570 | 564 | 20 | 0.56 | +186 | +9.3 |
| MAKE SURE TOGETHER | 49 | 33 | 20 | 0.56 | +1287 | +64.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1191 | +59.5 |
| WHOLE FIGHT GAIN | 39 | 36 | 20 | 0.56 | +1064 | +53.2 |
| SHOT REPLANNED | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +757 | +42.1 |
| HOLDER AT DEPLOYMENT | 39 | 39 | 18 | 0.50 | +944 | +52.5 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | +28 | +1.7 |
| WEARS DOWN | 83 | 80 | 17 | 0.47 | +764 | +45.0 |
| MANOEUVRE | 16 | 16 | 16 | 0.44 | +389 | +24.3 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -29 | -2.1 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.36 | +620 | +47.7 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -1078 | -107.8 |
| WHOLE FIGHT | 19 | 19 | 10 | 0.28 | +569 | +56.9 |
| LOST CHARGE | 195 | 194 | 9 | 0.25 | +176 | +19.5 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +1321 | +146.8 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -215 | -23.9 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -154 | -17.1 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| KEEP FALLS | 8 | 8 | 8 | 0.22 | +417 | +52.2 |
| CARRIES OUT SET-UP | 14 | 14 | 7 | 0.19 | -297 | -42.4 |
| CASTING BLOCK | 13 | 13 | 7 | 0.19 | +372 | +53.1 |
| OPENS UP | 15 | 15 | 7 | 0.19 | +326 | +46.6 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +136 | +22.7 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +120 | +19.9 |
| REFUSING RETIRES | 16 | 16 | 6 | 0.17 | -1 | -0.2 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +151 | +25.2 |
| LONG SHOT | 40 | 39 | 5 | 0.14 | +122 | +24.5 |
| OVERRUNS AWAY | 30 | 30 | 5 | 0.14 | +221 | +44.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| WAR ENGINE JOBS | 27 | 27 | 5 | 0.14 | -368 | -73.5 |
| WIDER SPREAD | 204 | 195 | 5 | 0.14 | +48 | +9.6 |
| EDGE GIVE GROUND | 20 | 20 | 4 | 0.11 | +136 | +34.1 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +132 | +32.9 |
| HUNT IN PAIRS | 22 | 12 | 4 | 0.11 | +112 | +28.0 |
| MISSILES NEXT TURN | 334 | 168 | 4 | 0.11 | +67 | +16.8 |
| REDIRECT BY WHAT IT STOPS | 43 | 43 | 4 | 0.11 | +267 | +66.8 |
| BACKUP TARGETS | 64 | 26 | 3 | 0.08 | +29 | +9.8 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -205 | -68.3 |
| SPELLS IN THE FIGHT | 39 | 37 | 3 | 0.08 | +42 | +14.0 |
| SUPPORT NARROWED | 441 | 441 | 3 | 0.08 | -26 | -8.8 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +29 | +14.6 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +58 | +28.9 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +108 | +54.2 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +251 | +125.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +10 | +4.9 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +57 | +28.7 |
| STUCK PIVOT | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| SURE REACH TOGETHER | 47 | 37 | 2 | 0.06 | +0 | +0.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +80 | +80.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -3 | -3.1 |
| CHARGER SLAIN LOST | 33 | 30 | 1 | 0.03 | +6 | +6.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| HUNT ADVANCE | 17 | 17 | 1 | 0.03 | +3 | +3.3 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 5 | 5 | 1 | 0.03 | -18 | -17.7 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +101 | +101.3 |
| SCREEN BY WHAT IT SAVES | 20 | 20 | 1 | 0.03 | +11 | +10.8 |
| STOPS | 4 | 3 | 1 | 0.03 | +14 | +13.9 |
| TWO OR MORE ARRIVE | 26 | 24 | 1 | 0.03 | +1 | +1.3 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -12 | -12.1 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 13 | 13 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 50 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 432 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 24 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 29 | 29 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 13 | 11 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 443 | 443 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 5 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2753 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 4 | not checked | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 115 | not checked | - | - | - | - |
| STABLE ROLE | 734 | 731 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.22 | 13.72 | 60.2 |
| FALLBACK | gate | 0.69 | 0.92 | 49.6 |
| TURN GATE | gate | 0.50 | 0.92 | 24.6 |
| CHARGE NOW FIRST | rule | 0.67 | 0.25 | 36.6 |
| PATHS CROSS | rule | 0.19 | 0.14 | 31.4 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 124.6 |
| PURSUES BIG PREY | rule | 0.11 | 0.17 | 107.8 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 23.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.06 | 19.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.14 | 53.7 |
| CARRIES OUT SET-UP | rule | 0.11 | 0.08 | 42.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.08 | 56.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.11 | 51.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 8.8 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 17.8 |
| AFTERMATH BAND | gate | 0.06 | 0.08 | 2.5 |
| CHAFF PASSED | rule | 0.03 | 0.11 | 5.7 |
| WAR ENGINE JOBS | rule | 0.14 | - | 73.5 |
| BEST PRIZE | rule | 0.03 | 0.06 | 68.3 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 26.9 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 2.0 |
| MOVE AND CAST | rule | 0.06 | 0.03 | 68.8 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 6.1 |
| SUPPORT NARROWED | rule | - | 0.08 | 8.8 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 18.2 |
| WHO HITS BACK | rule | 0.03 | 0.06 | 2.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 86.0 |
| RULE SWITCHED OFF | gate | 0.06 | - | 20.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 16.2 |
| BLOCKED WHEEL | rule | 0.03 | - | 0.6 |
| CATCH ODDS | rule | - | 0.03 | 3.1 |
| FACES THE THREAT | rule | 0.03 | - | 1.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 17.7 |
| MARCH ODDS | rule | - | 0.03 | 13.3 |
| STANDS TO CAST | rule | 0.03 | - | 1.1 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 12.1 |

### Plans: dep-opp-13df7bd-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.7 | 19% | 549 | 499 | 91% |
| Mine | charge | 3.1 | 59% | 234 | 278 | 118% |
| Mine | close in | 4.1 | 29% | 172 | 121 | 70% |
| Mine | hold | 4.4 | 42% | 299 | 0 | 0% |
| Mine | join | 0.6 | 100% | 29 | 0 | 0% |
| Mine | shoot | 9.2 | 62% | 298 | 781 | 262% |
| Mine | support | 3.6 | 88% | 36 | 0 | 0% |
| Opponent | advance | 13.0 | 17% | 405 | 303 | 75% |
| Opponent | charge | 4.0 | 61% | 370 | 435 | 118% |
| Opponent | close in | 5.8 | 26% | 318 | 123 | 39% |
| Opponent | hold | 4.4 | 50% | 312 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 27 | 0 | 0% |
| Opponent | shoot | 4.5 | 57% | 78 | 216 | 277% |
| Opponent | support | 6.6 | 90% | 51 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 3.0 | 386 | 64 | 20% | 3 |
| Opponent | 0.2 | 9 | 2 | 14% | 14% | 0% | 2.0 | 364 | 79 | 14% | 137 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 33% | 33% | 0% | 3.0 | 425 | 107 | 33% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 434 | 0 | 0% | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 541 | 0 | 0% | 96 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 338 |
| Ogre Kingdoms | 0.5 | 2 | 1 | 100% | 100% | 0% | 2.0 | 633 | 555 | 100% | 117 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 65 |
| Vampire Counts | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 68 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 155 | 0 | 0% | 123 |
| Wood Elf Realms | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 215 | 0 | 0% | 56 |

### Battle groups: dep-opp-13df7bd-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.8 | 21% | 55% | 7% | 20% | 36% | 6% | 10% | 48% | 0% |
| Mine | REDIRECT COUNTER | 1.6 | 40% | 39% | 9% | 0% | 10% | 5% | 10% | 76% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 15% | 72% | 11% | 50% | 12% | 9% | 12% | 66% | 0% |
| Opponent | REDIRECT COUNTER | 5.8 | 19% | 88% | 22% | 0% | 16% | 0% | 19% | 55% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 102 (1) | 102 | 0 | 0 | 0% | 3.0 | 102 (1) | - | - | 102 (1) | - |
| Mine | Chaff | 35 | 44 (35) | 17 | 27 | 72 | 31% | 2.2 | 58 (20) | 0 (5) | 40 (10) | 38 (29) | 77 (6) |
| Mine | Character | 126 | 46 (126) | 46 | 0 | 31 | 19% | 2.5 | 64 (32) | 42 (69) | 54 (14) | 62 (74) | 26 (41) |
| Mine | Clean-up | 25 | 103 (25) | 46 | 57 | 39 | 24% | 3.2 | 78 (4) | 85 (17) | 235 (4) | 109 (20) | 84 (5) |
| Mine | Fast Hammer | 43 | 37 (43) | 24 | 13 | 45 | 21% | 2.5 | 48 (20) | 30 (13) | 27 (10) | 40 (34) | 24 (9) |
| Mine | Fragile | 3 | 65 (3) | 65 | 0 | 100 | 0% | 2.3 | - | 0 (2) | 194 (1) | 65 (3) | - |
| Mine | Hammer | 54 | 35 (54) | 19 | 16 | 30 | 17% | 2.7 | 8 (11) | 41 (38) | 53 (5) | 36 (33) | 33 (21) |
| Mine | Holder | 34 | 73 (34) | 11 | 62 | 28 | 38% | 3.0 | 47 (8) | 71 (17) | 118 (7) | 99 (20) | 25 (12) |
| Mine | Shooter | 27 | 110 (27) | 45 | 65 | 59 | 0% | 1.8 | 86 (8) | 99 (17) | 293 (2) | 144 (16) | 71 (11) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 30 | 60% | 4.5 | 0 (1) | 0 (3) | 0 (1) | - | 0 (5) |
| Mine | War machine | 57 | 70 (57) | 70 | 0 | 36 | 2% | 1.0 | 97 (13) | 53 (34) | 95 (10) | 49 (14) | 76 (43) |
| Mine | Wizard | 18 | 1 (18) | 1 | 0 | 71 | 17% | 1.6 | 0 (1) | 3 (8) | - | 0 (2) | 3 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 78 | 75 (78) | 18 | 57 | 43 | 36% | 2.5 | 8 (26) | 157 (27) | 46 (25) | 90 (65) | 7 (13) |
| Opponent | Character | 91 | 53 (91) | 52 | 1 | 31 | 16% | 2.0 | 52 (24) | 52 (36) | 65 (22) | 56 (50) | 55 (32) |
| Opponent | Clean-up | 13 | 30 (13) | 12 | 18 | 27 | 31% | 1.9 | 69 (5) | 10 (6) | 0 (2) | 64 (6) | 4 (7) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 52 | 25 (52) | 12 | 14 | 50 | 27% | 2.7 | 15 (17) | 31 (24) | 25 (11) | 41 (24) | 11 (28) |
| Opponent | Fragile | 9 | 12 (9) | 12 | 0 | 38 | 56% | 1.5 | - | 21 (5) | 0 (4) | 0 (5) | 26 (4) |
| Opponent | Hammer | 73 | 37 (73) | 33 | 4 | 57 | 26% | 2.5 | 32 (20) | 57 (29) | 11 (24) | 19 (42) | 59 (31) |
| Opponent | Holder | 27 | 59 (27) | 16 | 43 | 45 | 26% | 3.2 | 44 (7) | 77 (16) | 23 (4) | 89 (15) | 30 (12) |
| Opponent | Shooter | 33 | 53 (33) | 13 | 40 | 36 | 0% | 1.8 | 33 (11) | 67 (17) | 52 (5) | 64 (20) | 35 (13) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 8 | 10 (8) | 10 | 0 | 73 | 25% | 1.7 | 0 (5) | 157 (1) | 0 (2) | - | 10 (8) |
| Opponent | Wizard | 13 | 16 (13) | 16 | 0 | 26 | 31% | 1.0 | 0 (4) | 30 (3) | 3 (4) | 2 (5) | 29 (6) |

### Charged fights: dep-opp-13df7bd-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 76 | 182 | 1.8 | 1.6 | 104 | 20 | +84 | 1 of 7 | 5 of 7 | +73 | +93 |
| Mine | Chaos Dwarfs | 4 | 581 | 128 | 2.5 | 1.0 | 51 | 18 | +33 | 2 of 10 | 8 of 10 | - | +33 |
| Mine | Dwarfen Mountain Holds | 3 | 247 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 3 | 3 of 3 | - | +66 |
| Mine | Empire of Man | 5 | 445 | 246 | 1.4 | 1.0 | 176 | 0 | +176 | 4 of 7 | 3 of 7 | - | +176 |
| Mine | Grand Cathay | 5 | 564 | 440 | 3.8 | 1.1 | 116 | 9 | +107 | 4 of 19 | 18 of 19 | +0 | +113 |
| Mine | High Elf Realms | 3 | 119 | 337 | 3.3 | 1.0 | 101 | 0 | +101 | 4 of 10 | 9 of 10 | - | +101 |
| Mine | Kingdom of Bretonnia | 2 | 117 | 862 | 5.5 | 1.3 | 157 | 7 | +149 | 4 of 11 | 9 of 11 | +376 | +99 |
| Mine | Lizardmen | 1 | 136 | 182 | 2.0 | 1.0 | 91 | 0 | +91 | 0 of 2 | 2 of 2 | - | +91 |
| Mine | Ogre Kingdoms | 1 | 0 | 991 | 7.0 | 1.1 | 142 | 76 | +66 | 1 of 7 | 6 of 7 | +109 | +59 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 454 | 5.0 | 1.0 | 91 | 197 | -106 | 2 of 5 | 5 of 5 | - | -106 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 35 | -35 | 0 of 1 | 0 of 1 | - | -35 |
| Mine | Tomb Kings of Khemri | 2 | 22 | 766 | 4.0 | 1.5 | 191 | 57 | +134 | 4 of 8 | 6 of 8 | +106 | +152 |
| Mine | Vampire Counts | 2 | 15 | 671 | 5.5 | 1.2 | 122 | 8 | +114 | 4 of 11 | 10 of 11 | +99 | +118 |
| Mine | Warriors of Chaos | 2 | 0 | 278 | 2.0 | 1.0 | 139 | 29 | +110 | 0 of 4 | 2 of 4 | - | +110 |
| **Mine** | all armies | 36 | 256 | 352 | 2.9 | 1.1 | 121 | 26 | +94 | 30 of 105 | 86 of 105 | +133 | +89 |
| Opponent | Grand Cathay | 3 | 98 | 454 | 3.3 | 1.3 | 136 | 42 | +94 | 4 of 10 | 9 of 10 | -61 | +133 |
| Opponent | High Elf Realms | 3 | 37 | 365 | 3.0 | 1.2 | 122 | 23 | +98 | 2 of 9 | 7 of 9 | -30 | +135 |
| Opponent | Lizardmen | 1 | 0 | 619 | 2.0 | 1.0 | 310 | 0 | +310 | 2 of 2 | 2 of 2 | - | +310 |
| Opponent | Ogre Kingdoms | 3 | 200 | 252 | 4.3 | 1.2 | 58 | 17 | +41 | 4 of 13 | 6 of 13 | +281 | -2 |
| Opponent | Skaven | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 165 | 982 | 3.0 | 1.3 | 327 | 65 | +262 | 3 of 3 | 1 of 3 | +368 | +210 |
| Opponent | Vampire Counts | 5 | 64 | 240 | 4.4 | 1.2 | 55 | 46 | +9 | 10 of 22 | 14 of 22 | +67 | -4 |
| Opponent | Warriors of Chaos | 8 | 0 | 551 | 2.6 | 1.1 | 210 | 48 | +162 | 9 of 21 | 18 of 21 | +201 | +155 |
| Opponent | Wood Elf Realms | 11 | 116 | 498 | 3.8 | 1.2 | 130 | 17 | +113 | 17 of 42 | 24 of 42 | +86 | +119 |
| **Opponent** | all armies | 36 | 79 | 442 | 3.4 | 1.2 | 130 | 31 | +99 | 51 of 122 | 81 of 122 | +106 | +98 |

### Effective charges: dep-opp-13df7bd-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net -137) | 0 | 0 | 3 (net +147) | 0 | 3 (net +95) | 0 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 10 | 1 (net +0) | 0 | 1 (net -185) | 1 (net +0) | 0 | 7 (net +73) | 0 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 2 (net +72) | 1 (net +55) | 0 | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 7 | 4 (net +166) | 0 | 0 | 2 (net +192) | 0 | 1 (net +186) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 19 | 0 | 1 (net +185) | 4 (net +146) | 6 (net +93) | 1 (net +0) | 6 (net +108) | 1 | 22% (4 of 18) |
| Mine | High Elf Realms | 10 | 0 | 1 (net +0) | 3 (net +109) | 3 (net +0) | 1 (net +0) | 2 (net +342) | 0 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 11 | 2 (net -40) | 0 | 1 (net +251) | 3 (net +47) | 1 (net +114) | 3 (net +395) | 1 | 10% (1 of 10) |
| Mine | Ogre Kingdoms | 7 | 2 (net +118) | 0 | 2 (net +64) | 1 (net -157) | 0 | 0 | 2 | 40% (2 of 5) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -35) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 3 (net +131) | 0 | 3 (net +193) | 1 (net +30) | 0 | 1 (net +75) | 0 | 38% (3 of 8) |
| Mine | Vampire Counts | 11 | 0 | 1 (net -40) | 1 (net -45) | 3 (net +134) | 2 (net +122) | 3 (net +186) | 1 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 4 | 0 | 1 (net +0) | 2 (net +220) | 0 | 0 | 0 | 1 | 67% (2 of 3) |
| Opponent | Grand Cathay | 10 | 0 | 0 | 2 (net +228) | 5 (net +81) | 0 | 3 (net +27) | 0 | 20% (2 of 10) |
| Opponent | High Elf Realms | 9 | 0 | 0 | 4 (net +49) | 1 (net +580) | 1 (net +110) | 2 (net +0) | 1 | 50% (4 of 8) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 2 (net +310) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 13 | 1 (net +0) | 0 | 2 (net +50) | 0 | 1 (net +65) | 1 (net +497) | 8 | 40% (2 of 5) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 2 (net +300) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 22 | 4 (net -139) | 1 (net +315) | 2 (net +31) | 6 (net -28) | 2 (net +80) | 5 (net +66) | 2 | 10% (2 of 20) |
| Opponent | Warriors of Chaos | 21 | 0 | 0 | 6 (net +83) | 5 (net +296) | 2 (net +30) | 7 (net +161) | 1 | 30% (6 of 20) |
| Opponent | Wood Elf Realms | 42 | 9 (net +156) | 2 (net +196) | 7 (net +45) | 7 (net +159) | 1 (net +34) | 11 (net +164) | 5 | 19% (7 of 37) |

### Charged fights, damage counted: dep-opp-13df7bd-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 293 | 308 | +83 | 169 | 102 | +67 | +22.9 |
| Mine | 50-54% | 4 | 206 | 259 | +36 | 95 | 92 | +3 | +1.6 |
| Mine | Effective (55-75%) | 17 | 238 | 196 | +122 | 143 | 36 | +107 | +44.8 |
| Mine | 76-89% | 25 | 263 | 153 | +78 | 104 | 20 | +84 | +31.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 279 | 158 | +152 | 175 | 21 | +154 | +55.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 378 | 91 | +69 | 77 | 2 | +74 | +19.7 |
| Mine | No odds | 13 | 253 | 122 | +10 | 102 | 78 | +24 | +9.3 |
| Mine | All fights | 105 | 270 | 177 | +94 | 134 | 42 | +92 | +34.2 |
| Opponent | Long shot (under 50%) | 14 | 208 | 265 | +61 | 134 | 88 | +45 | +21.9 |
| Opponent | 50-54% | 3 | 493 | 257 | +236 | 236 | 0 | +236 | +47.8 |
| Opponent | Effective (55-75%) | 23 | 296 | 177 | +71 | 106 | 44 | +62 | +20.8 |
| Opponent | 76-89% | 28 | 358 | 248 | +166 | 224 | 72 | +152 | +42.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 354 | 201 | +133 | 192 | 59 | +133 | +37.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 359 | 81 | +61 | 69 | 1 | +68 | +19.0 |
| Opponent | No odds | 18 | 223 | 186 | +1 | 44 | 34 | +10 | +4.5 |
| Opponent | All fights | 122 | 312 | 207 | +99 | 149 | 54 | +94 | +30.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p7 | move | 482 | 94 (20%) | 72 (15%) | 39 (8%) | 349 (72%) |
| dep-opp-13df7bd-p7 | objective | 359 | 65 (18%) | 51 (14%) | 32 (9%) | 262 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0112, L0128, L2435, L2632 |
| Charmed Shield | Opponent | L0727, L0924, L1124, L1234, L1424, L1734, L1934, L2225, L2834 |
| Clockwork Compass | Mine | L1218, L1234 |
| Clockwork Compass | Opponent | L0112, L0212 |
| Elixir of Power | Mine | L1124, L1934 |
| Elixir of Power | Opponent | L0711 |
| Fistful of Laurels | Mine | L1833 |
| Fistful of Laurels | Opponent | L0518, L1218, L1618 |
| Horn of the Wild Hunt | Opponent | L0833, L1833 |
| Invocation of Nehek | Mine | L2435 |
| Invocation of Nehek | Opponent | L0727, L0924, L1124, L1424, L2225 |
| Opal Amulet | Mine | L1424 |
| Periapt of Soul Exchange | Mine | L2035 |
| Periapt of Soul Exchange | Opponent | L1521 |
| Ring of Doom | Mine | L0212, L0228, L1124, L1218, L1234, L1521, L3135 |
| Ring of Doom | Opponent | L0112, L0212, L0415, L0711, L0833, L1015, L1833 |
| Ring of Jet | Mine | L1015, L1032, L1124, L1218, L1234 |
| Ring of Jet | Opponent | L0112, L0212, L0711 |
| Standard of the Fell Warrior | Mine | L1329 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L1521 |
| Twice-Blessed Armour | Mine | L0711, L0727, L1015, L1032 |
| Witch Hunter's Ward | Mine | L0711, L0727, L0817, L0833 |

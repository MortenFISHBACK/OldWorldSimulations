# Doctrine scorecard: dep-opp-13df7bd-p6

### Scorecard: dep-opp-13df7bd-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 3 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0124 | 4 | 1 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0124 | 4 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Mine | no | 3 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0224 | 2 | 1 | Mine | - | - | 3 | 5 | 3 | 0 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 129 |
| L0309 | 3 | 1 | Mine | no | 7 | 2 | 3 | 0 | 0 | 0 | 0 | 770 |
| L0309 | 3 | 1 | Opponent | no | 2 | 5 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0325 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0325 | 1 | 1 | Opponent | no | 11 | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 14 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 427 |
| L0427 | 1 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 2 | 1 | 2 | 2 | 0 | 0 | 0 | 60 |
| L0514 | 4 | 1 | Mine | no | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 1177 |
| L0514 | 4 | 1 | Opponent | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1104 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 929 |
| L0618 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0635 | 5 | 1 | Mine | no | - | 4 | 2 | 3 | 0 | 0 | 0 | 615 |
| L0635 | 5 | 1 | Opponent | no | - | 5 | 1 | 4 | 1 | 0 | 0 | 254 |
| L0723 | 3 | 1 | Mine | no | 4 | 5 | 2 | 1 | 1 | 0 | 0 | 452 |
| L0723 | 3 | 1 | Opponent | no | 3 | 1 | 4 | 2 | 2 | 0 | 0 | 0 |
| L0813 | 3 | 1 | Mine | no | 1 | 5 | 3 | 0 | 1 | 0 | 0 | 560 |
| L0813 | 3 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 140 |
| L0829 | 1 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 515 |
| L0829 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0920 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0920 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 2 | 0 | 0 | 420 |
| L1011 | 3 | 1 | Mine | yes | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1011 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1028 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1028 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1120 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1120 | 4 | 1 | Opponent | no | 1 | - | 1 | 4 | 2 | 0 | 0 | 485 |
| L1214 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1214 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 1 | Mine | no | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L1230 | 6 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1325 | 5 | 1 | Mine | yes | - | 5 | 3 | 2 | 0 | 0 | 0 | 140 |
| L1325 | 5 | 1 | Opponent | yes | - | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1420 | 4 | 1 | Mine | yes | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 123 |
| L1420 | 4 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 402 |
| L1517 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1517 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 175 |
| L1533 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 426 |
| L1631 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1631 | 5 | 1 | Opponent | yes | - | 6 | 3 | 1 | 1 | 0 | 0 | 170 |
| L1729 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 405 |
| L1729 | 1 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 122 |
| L1829 | 5 | 1 | Mine | no | - | 5 | 2 | 3 | 1 | 0 | 0 | 419 |
| L1829 | 5 | 1 | Opponent | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L1929 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1929 | 3 | 1 | Opponent | no | 4 | 1 | 4 | 0 | 0 | 0 | 0 | 170 |
| L2031 | 3 | 1 | Mine | no | 3 | 4 | 2 | 1 | 2 | 0 | 0 | 210 |
| L2031 | 3 | 1 | Opponent | no | 2 | 3 | 6 | 0 | 1 | 0 | 0 | 562 |
| L2134 | 4 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 210 |
| L2134 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2325 | 3 | 1 | Mine | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2325 | 3 | 1 | Opponent | no | 2 | 5 | 1 | 3 | 1 | 0 | 0 | 0 |
| L2431 | 1 | 1 | Mine | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2431 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Mine | no | 7 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Opponent | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2830 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2830 | 4 | 1 | Opponent | no | 2 | 1 | 4 | 2 | 0 | 0 | 0 | 70 |
| L3035 | 5 | 1 | Mine | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3035 | 5 | 1 | Opponent | no | - | - | 2 | 3 | 0 | 0 | 0 | 274 |
| **Average** | | | Mine | 19% | 3.1 | 2.8 | 2.2 | 1.1 | 0.3 | 0.0 | 0.0 | 298.3 |
| **Average** | | | Opponent | 16% | 2.6 | 2.6 | 2.2 | 1.9 | 0.5 | 0.0 | 0.0 | 179.2 |

### KPIs: dep-opp-13df7bd-p6

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (47 of 178) | 12% (22 of 186) | 19% (69 of 364) |
| Winner chose to follow up after the loser gave ground |  | 98% (65 of 66); on the table 100% | 100% (44 of 44); on the table 100% | 99% (109 of 110); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 94% (16 of 17); on the table 94% | 92% (22 of 24); on the table 92% |
| Winner chose to pursue after the loser fled |  | 70% (16 of 23); on the table 74% | 92% (24 of 26); on the table 96% | 82% (40 of 49); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 91% (87 of 96); on the table 93% | 97% (84 of 87); on the table 98% | 93% (171 of 183); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 30% (92 of 310) | 35% (65 of 186) | 32% (157 of 496) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (92 of 226) | 50% (59 of 118) | 44% (151 of 344) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (17 of 30) | 41% (26 of 63) | 46% (43 of 93) |
| Points that never fought | lower | 37% (26182 of 70457) | 40% (29131 of 71981) | 39% (55313 of 142438) |
|   infantry points that never fought | lower | 41% (6490 of 15655) | 58% (8179 of 14129) | 49% (14669 of 29784) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (144 of 275) | 59% (172 of 290) | 56% (316 of 565) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.6 uses a game | 85% (11 of 13); 1.1 uses a game | 89% (34 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 54% (7 of 13); 0.4 uses a game | 36% (5 of 14); 0.2 uses a game | 44% (12 of 27); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (13 of 21); 0.4 uses a game | 50% (6 of 12); 0.2 uses a game | 58% (19 of 33); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28580 of 60045) | 54% (35048 of 64650) | 51% (63628 of 124695) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (33%) | 0.6 (17%) | 2.6 (27%) |
| MARCHED: its unit marched | 1.4 (23%) | 0.5 (16%) | 1.9 (20%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (28%) | 0.5 (15%) | 2.2 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| GONE: slain | 0.7 (11%) | 1.1 (32%) | 1.8 (19%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.4 | 1.6 | 1.6 | 4.4 | 0.6 | 2.0 |
| not cast | 3.6 | 2.4 | 4.3 | 9.4 | 2.4 | 21.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (46%) | 0.2 (4%) | 2.6 (27%) | 0.7 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (20%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (11%) | 0.7 (17%) | 2.2 (23%) | 0.6 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.6 (16%) | 0.2 (7%) | 0.5 (12%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.0 (28%) | 0.4 (18%) | 0.8 (18%) | 1.8 (19%) | 0.3 (12%) | 4.2 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.1 (5%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (11%) | 0.0 (1%) | 0.1 (1%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (45%) | 0.1 (5%) | 1.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.8 a game | 0.9 a game |
| stood (cast and not dispelled) | 62% (16 of 26) | 50% (14 of 28) | 56% (30 of 54) |
| the unit moved after it | 62% (10 of 16) | 64% (9 of 14) | 63% (19 of 30) |
| it charged on its next turn | 6% (1 of 16) | 0% (0 of 14) | 3% (1 of 30) |
| the enemy charged it first | 12% (2 of 16) | 21% (3 of 14) | 17% (5 of 30) |
| it fought by the end of its next turn | 0% (0 of 16) | 14% (2 of 14) | 7% (2 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (3 of 16) | 7% (1 of 14) | 13% (4 of 30) |
| none of these (no charge, no fight, no charge escaped) | 69% (11 of 16) | 71% (10 of 14) | 70% (21 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (547 of 833) | 58% (317 of 545) | 63% (864 of 1378) |
|   cavalry | 64% (42 of 66) | 67% (81 of 121) | 66% (123 of 187) |
|   character | 56% (55 of 99) | 33% (28 of 86) | 45% (83 of 185) |
|   chariot | 40% (36 of 89) | 67% (20 of 30) | 47% (56 of 119) |
|   infantry | 60% (145 of 242) | 59% (107 of 180) | 60% (252 of 422) |
|   monster | 48% (19 of 40) | 41% (11 of 27) | 45% (30 of 67) |
|   war machine | 84% (250 of 297) | 69% (70 of 101) | 80% (320 of 398) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (32%) | 1.6 (25%) | 4.1 (29%) |
| CHARGED: it charged | 1.1 (13%) | 1.0 (16%) | 2.1 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (6%) | 0.4 (6%) | 0.8 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.5 (19%) | 1.5 (24%) | 3.1 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.4 (6%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (19%) | 1.0 (15%) | 2.4 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| OTHER BAR | 0.4 (5%) | 0.3 (4%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.2 | 80% | 5.0 pts | 26 pts |
| character | 2.7 | 0.7 | 79% | 8.0 pts | 21 pts |
| chariot | 1.6 | 0.9 | 70% | 11.4 pts | 18 pts |
| infantry | 10.3 | 4.9 | 72% | 11.6 pts | 119 pts |
| monster | 1.1 | 0.2 | 84% | 2.2 pts | 2 pts |
| war machine | 9.1 | 7.9 | 62% | 26.3 pts | 239 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 4.5 | 4.3 |
| Charges that made contact a game | 3.1 | 3.2 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.72 contact (18 units) | 0.39 declared, 0.28 contact (18 units) | 0.69 declared, 0.50 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.50 contact (6 units) | 0.92 declared, 0.58 contact (12 units) | 0.89 declared, 0.56 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.41 contact (229 units) | 0.58 declared, 0.42 contact (250 units) | 0.57 declared, 0.41 contact (479 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (37 of 69) | 54% (14 of 26) | 33% (4 of 12) | 51% (55 of 107) |
| Character in a unit | 71% (17 of 24) | 57% (12 of 21) | 75% (3 of 4) | 65% (32 of 49) |
| Character on its own | 80% (39 of 49) | 42% (15 of 36) | 37% (24 of 65) | 52% (78 of 150) |
| Chariot | 67% (8 of 12) | 64% (9 of 14) | - | 65% (17 of 26) |
| Infantry | 54% (46 of 85) | 32% (11 of 34) | 40% (2 of 5) | 48% (59 of 124) |
| Monster | 56% (14 of 25) | 73% (11 of 15) | - | 62% (25 of 40) |
| Monstrous | 100% (7 of 7) | 56% (5 of 9) | - | 75% (12 of 16) |
| War Machines | 71% (36 of 51) | 100% (2 of 2) | - | 72% (38 of 53) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 93% (13 of 14); on the table 100% | 18% (18 of 102) | 28% | 45% (10 of 22) | 100% (6 of 6); 2.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (9 of 9); on the table 100% | 42% (10 of 24) | 56% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 100% (8 of 8); on the table 100% | - | 48% | 68% (23 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 91% (10 of 11); on the table 100% | 39% (14 of 36) | 44% | 64% (47 of 74) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
| Grand Cathay | 7 | 92% (12 of 13); on the table 92% | 37% (50 of 136) | 44% | 42% (24 of 57) | 88% (14 of 16); 6.7 uses a game | 0% (0 of 2); 0.0 uses a game | 29% (2 of 7); 0.3 uses a game |
| High Elf Realms | 7 | 100% (15 of 15); on the table 100% | 25% (9 of 36) | 39% | 46% (26 of 57) | 100% (6 of 6); 2.4 uses a game | 41% (9 of 22); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 60% (3 of 5); on the table 60% | - | 33% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | 100% (6 of 6) | 50% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 59% | 71% (10 of 14) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 5 | 69% (9 of 13); on the table 77% | 33% (10 of 30) | 39% | 49% (18 of 37) | 100% (1 of 1); 0.2 uses a game | 0.0 uses a game | 80% (4 of 5); 0.8 uses a game |
| Tomb Kings of Khemri | 2 | 100% (11 of 11); on the table 100% | - | 44% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (30 of 30); on the table 100% | 35% (17 of 48) | 27% | 52% (26 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 14 | 92% (35 of 38); on the table 92% | 38% (16 of 42) | 28% | 61% (66 of 108) | 100% (3 of 3); 0.5 uses a game | 0.0 uses a game | 100% (4 of 4); 0.3 uses a game |
| Wood Elf Realms | 4 | 100% (7 of 7); on the table 100% | 28% (5 of 18) | 58% | 71% (30 of 42) | 50% (2 of 4); 2.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p6, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (41) | 34% (23) | 46% (64) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.44 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.06 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.25 | 0.61 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.83 | 3.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.72 | 1.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.97 | 5.50 | 10.47 |

### Quality by phase: dep-opp-13df7bd-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.9 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 59% (70 of 118) | 46% (61 of 133) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (167 of 391) | 45% (86 of 191) |
| Strategy | Close-in objectives charged next turn | 22% (39 of 176) | 13% (28 of 212) |
| Strategy | Support requests answered (helper made contact too) | 68% (15 of 22) | 44% (8 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (4 of 10) | 18% (2 of 11) |
| Strategy | Joined characters whose unit fought | 65% (30 of 46) | 37% (11 of 30) |
| Strategy | Lone characters that fought | 74% (67 of 90) | 74% (71 of 96) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 298.3 | 179.2 |
| Movement | Fights charged into per game | 2.6 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 82, net +196 | 17 of 86, net +14 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 82, net +13 | 11 of 86, net +40 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 82, net +78 | 7 of 86, net +124 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 82, net +150 | 26 of 86, net +130 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 7.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (162 of 323) | 41% (114 of 281) |
| Shooting | Points destroyed by shooting units | 87.2 | 24.5 |
| Shooting | War machine shots | 6.9 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (119 of 250) | 57% (44 of 77) |
| Shooting | Points destroyed by war machines | 124.4 | 30.6 |
| Magic | Magic missiles cast | 1.7 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (25 of 62) | 40% (18 of 45) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.6 |
| Magic | Wounds caused by other spells | 2.1 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 77.6 | 42.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 1.0 / 0.3 | 1.3 / 0.6 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 337.5 | 361.6 |
| Combat | Points run down | 100.7 | 120.0 |
| Combat | Net points per charged fight, damage counted | +115 | +101 |
| Combat | Net per 100 charger points, damage counted | +36.8 | +35.4 |
| Combat | First round won (charged fights) | 82% | 71% |
| Combat | Net points per charged fight | +102 | +98 |
| Combat | Net points per supported fight / lone fight | +148 / +91 | +300 / +61 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 93 | 48 of 96 |
| Game | Points lost | 639.2 | 804.2 |
| Game | VP from objectives | 571.1 | 611.7 |
| Game | Lone holders (player turns) | 3.1 | 2.6 |

- Mine won / drew / lost: 22 / 3 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +122 VP
- The side that went first won 19 of 33 games with a winner
- Points traded per game (both sides' losses): 1443
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-opp-13df7bd-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 4.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 20.4 | 0.7 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.4 | +9.1 | 0.0 | 40.7 | 0.8 | +9.1 | 0.0 | 36.1 |
| BEST FACING | 0.6 | +39.7 | 0.0 | 22.8 | 1.0 | +33.4 | 0.0 | 39.4 |
| BEST FIRST | 3.9 | +148.2 | 176.6 | 132.3 | 3.8 | +144.3 | 220.7 | 43.2 |
| BEST OVERALL | 0.7 | +59.0 | 0.0 | 32.6 | 0.6 | +38.3 | 0.0 | 22.9 |
| BEST PREY | 0.8 | +48.5 | 31.6 | 12.7 | 0.9 | +32.5 | 3.1 | 15.1 |
| BEST PRIZE | 0.1 | -13.2 | 8.4 | 16.1 | 0.1 | -4.5 | 8.1 | 15.1 |
| BIG CHARACTER SAFETY | 0.2 | +0.2 | 0.0 | 21.2 | 0.2 | -0.3 | 0.0 | 10.2 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 6.3 | 0.0 | 0.1 | +0.0 | 15.1 | 0.0 |
| BLOCKED WHEEL | 0.6 | +17.8 | 0.0 | 8.6 | 0.4 | +5.2 | 0.0 | 4.2 |
| BLOWS WHERE AIMED | 0.4 | -22.3 | 49.2 | 14.4 | 0.3 | -43.9 | 64.5 | 0.0 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 91.1 | 21.8 | 0.2 | +0.0 | 31.7 | 0.0 |
| CANNON PLANNED TARGET | 5.5 | +235.2 | 630.7 | 60.1 | 1.6 | +100.9 | 108.9 | 14.2 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | -0.3 | 9.4 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -0.2 | 39.1 | 5.8 | 0.1 | -8.8 | 24.1 | 13.1 |
| CAST JOB | 0.9 | +22.4 | 104.8 | 15.0 | 0.4 | +11.5 | 26.4 | 45.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +12.3 | 3.1 | 0.0 | 0.1 | +1.8 | 3.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 19.6 | 0.4 | +0.0 | 0.0 | 26.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.3 | 11.0 | 0.0 | 0.2 | -1.7 | 14.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 221.6 | 56.5 | 2.3 | +0.0 | 267.8 | 50.9 |
| CHARGE NOW WEIGHED | 0.8 | -51.8 | 48.2 | 37.1 | 0.6 | -54.5 | 21.9 | 13.9 |
| CHARGER SLAIN LOST | 0.4 | -20.4 | 38.5 | 5.6 | 0.3 | -5.4 | 68.8 | 4.7 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.0 | +0.0 | 0.0 | 13.1 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 11.1 | 0.0 | 0.1 | +0.0 | 16.2 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 5.9 | 33.3 | 0.3 | +0.0 | 19.9 | 31.9 |
| CONVEYANCE SEARCH | 0.5 | +77.3 | 21.1 | 21.1 | 0.6 | +122.1 | 17.4 | 13.1 |
| COUNTER-CHARGE COVER | 8.1 | +612.5 | 0.0 | 214.3 | 7.7 | +831.7 | 0.0 | 222.9 |
| DEFENSIVE ARMY | 0.2 | -0.4 | 7.1 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 8.0 |
| DEPLOY BY FIGURES | - | - | - | - | 7.2 | +78.4 | 0.0 | 14.4 |
| EDGE GIVE GROUND | 0.2 | +7.0 | 43.6 | 16.1 | 0.2 | +4.0 | 6.9 | 0.8 |
| ELIXIR WORTH | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +161.2 | 0.0 | 87.9 | 1.8 | +108.8 | 0.0 | 73.6 |
| FALLBACK BY WORTH | 4.2 | +32.2 | 0.0 | 53.5 | 4.7 | +55.2 | 0.0 | 53.4 |
| FIGHT LIFT | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.0 | 4.6 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 141.4 | 5.8 | +0.0 | 0.0 | 181.3 |
| FOLLOW UP WEIGHED | 1.1 | +159.4 | 0.0 | 28.6 | 1.0 | +143.7 | 0.0 | 3.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +24.4 | 0.0 | 0.0 | 0.2 | +13.7 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.5 | 1.9 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.3 | 8.6 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +0.3 | 0.0 | 7.5 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 11.1 | 0.0 | 0.1 | +0.0 | 24.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 13.9 | 14.9 | 0.2 | +0.0 | 8.0 | 2.8 |
| HILL BY ITS CHANCE | 0.2 | -32.1 | 0.0 | 0.0 | 0.6 | -57.6 | 0.0 | 6.5 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.8 | +147.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -163.8 | 563.2 | 218.1 | 8.0 | -148.9 | 470.8 | 258.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +3.9 | 0.0 | 3.1 | 0.1 | +0.7 | 3.5 | 3.2 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| HUNT IN PAIRS | 1.1 | +72.9 | 0.0 | 38.4 | 0.1 | +8.4 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 3.8 | 0.1 | +3.5 | 3.5 | 3.2 |
| HUNT THE GUNS | 0.1 | +38.6 | 0.0 | 3.1 | 0.1 | +17.3 | 6.9 | 3.2 |
| INVITES THE FIGHT | 1.4 | +16.2 | 46.2 | 24.7 | 1.4 | +24.1 | 50.5 | 16.8 |
| JOINT CHARGE PLAN | 0.4 | +46.7 | 32.2 | 9.3 | 0.2 | +17.8 | 8.0 | 5.1 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.8 | 17.6 | 6.5 | 0.0 | -0.6 | 8.0 | 2.7 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +55.0 | 210.4 | 74.2 | 2.1 | +62.5 | 171.8 | 55.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +81.3 | 133.5 | 8.9 | 1.7 | +95.3 | 181.7 | 49.6 |
| KILLS COUNT NEXT TURN | 5.7 | +168.6 | 372.1 | 157.3 | 6.7 | +238.8 | 239.9 | 183.6 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +32.6 | 0.0 | 13.7 |
| LONE CHARACTER SAFE SPOT | 0.5 | +19.2 | 12.2 | 0.0 | 0.3 | +2.6 | 3.5 | 5.3 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 7.0 | 0.0 | 0.4 | +0.0 | 8.4 | 5.4 |
| LONE WIZARD KEPT IN | 0.5 | +34.4 | 0.0 | 0.0 | 0.3 | +23.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.1 | 30.6 | 4.1 | 0.4 | -1.4 | 20.3 | 16.4 |
| LOST CHARGE | 2.5 | -38.0 | 168.0 | 45.5 | 2.1 | -42.2 | 92.9 | 85.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.2 | 0.0 | 2.1 | 0.1 | -10.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +72.3 | 75.5 | 15.3 | 1.3 | +215.1 | 75.7 | 47.4 |
| MANOEUVRE | 0.2 | +17.0 | 0.0 | 3.4 | 0.1 | +3.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +29.4 | 0.0 | 16.4 | 0.4 | +37.3 | 0.0 | 9.7 |
| MARCH ODDS | 0.3 | +12.5 | 23.3 | 4.6 | 0.2 | +19.3 | 1.7 | 25.2 |
| MARCH OVER CASTS | 0.8 | +53.6 | 0.0 | 63.7 | 0.4 | +25.2 | 0.0 | 23.3 |
| MAX FOR POSITIONING | 5.1 | +189.6 | 0.0 | 141.9 | 5.1 | +214.6 | 0.0 | 145.9 |
| MISSILES IN THE MOVE | 4.1 | +108.5 | 0.0 | 106.4 | 3.1 | +64.9 | 0.0 | 120.0 |
| MISSILES NEXT TURN | 5.1 | +85.2 | 0.0 | 153.4 | 3.6 | +48.4 | 0.0 | 145.7 |
| MODEL FACING | 0.3 | +84.2 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 35.1 | 10.2 | 0.1 | +0.0 | 8.0 | 13.9 |
| MOVE AND CAST | 0.5 | +16.6 | 0.0 | 21.2 | 0.3 | +11.2 | 0.0 | 15.0 |
| MOVE SPELL IN RANGE | 0.1 | +3.8 | 0.0 | 10.6 | 0.1 | +3.8 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -11.6 | 8.0 | 16.1 | 0.1 | -0.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 26.1 |
| MOVE TO CHARGE | 3.1 | +292.7 | 223.7 | 112.1 | 4.3 | +441.7 | 205.6 | 136.7 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +2.8 | 1.4 | 0.0 | 0.1 | +24.7 | 17.7 | 0.0 |
| NO RALLY LEFT | 0.0 | +9.8 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 4.2 |
| NOT NEEDED | 0.1 | -3.8 | 3.8 | 7.9 | 0.3 | -8.2 | 15.9 | 6.5 |
| NOT TURNED | 5.0 | +95.2 | 0.0 | 108.8 | 5.5 | +67.7 | 0.0 | 150.1 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 10.7 |
| OFF BEST | 15.2 | -800.6 | 11.1 | 280.7 | 14.0 | -826.3 | 11.7 | 337.8 |
| OPENS A LANE | 0.1 | +6.1 | 7.2 | 2.9 | - | - | - | - |
| OPENS UP | 0.1 | +5.1 | 2.4 | 0.0 | 0.1 | +11.6 | 4.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +6.2 | 47.0 | 33.1 | 0.6 | +11.9 | 60.5 | 28.2 |
| PATHS CROSS | 2.0 | +128.0 | 0.0 | 51.0 | 2.5 | +150.6 | 0.0 | 58.1 |
| PERIAPT WORTH | 0.1 | +5.0 | 0.0 | 15.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.5 | 0.0 | 6.5 | 0.1 | -0.8 | 0.0 | 7.0 |
| PLAN RESULT | 37.5 | +1637.2 | 1851.6 | 942.9 | 35.8 | +1275.0 | 1344.2 | 1119.3 |
| PURSUES BIG PREY | 0.1 | -6.3 | 0.0 | 4.2 | 0.1 | -8.9 | 0.0 | 18.6 |
| PURSUES ON | 0.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | +6.6 | 0.0 | 3.1 |
| RANDOM MOVE BY FIGURES | 0.8 | +11.7 | 0.0 | 13.9 | 1.8 | +24.5 | 0.0 | 37.5 |
| RANDOM MOVER NO PROMISE | 0.2 | -15.9 | 7.0 | 0.0 | 0.4 | -21.8 | 0.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -9.0 | 0.0 | 4.6 | 0.5 | -9.3 | 0.0 | 8.0 |
| REDIRECT COUNTER | 1.8 | +152.8 | 0.0 | 46.9 | 3.8 | +301.7 | 0.0 | 66.0 |
| REDIRECT WEIGHED | 0.2 | +2.8 | 4.7 | 0.0 | 0.3 | -0.6 | 14.7 | 15.9 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 6.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.1 | +5.5 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 10.4 |
| RESTRAINS TO SHOOT | 0.1 | +5.8 | 0.0 | 10.2 | - | - | - | - |
| RISK BY ARC | 2.2 | +76.2 | 253.2 | 85.8 | 2.4 | +42.7 | 248.3 | 77.5 |
| SAFER THAN THE JOB | 0.8 | +58.1 | 0.0 | 7.0 | 0.7 | +42.2 | 0.0 | 28.1 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.8 | 0.0 | 0.0 | 0.4 | -13.6 | 0.0 | 2.2 |
| SEARCH SPOT | 1.8 | +90.5 | 0.0 | 36.1 | 2.4 | +144.0 | 0.0 | 32.4 |
| SECOND HUNTER | 0.0 | -0.6 | 0.0 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +39.4 | 0.0 | 40.1 | - | - | - | - |
| SET UP TOGETHER | 1.7 | +152.0 | 75.5 | 39.4 | 2.3 | +348.3 | 114.0 | 80.6 |
| SET-UP ANY TARGET | 0.2 | +33.6 | 21.1 | 21.1 | 0.1 | +21.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +21.6 | 0.0 | 0.0 | 0.1 | +9.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +33.5 | 71.9 | 18.5 | 0.8 | +21.2 | 30.2 | 2.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 153.6 | 8.7 | 0.3 | +0.0 | 62.4 | 19.6 |
| SHOTS IN THE MOVE | 14.2 | +671.9 | 0.0 | 200.1 | 8.1 | +312.5 | 0.0 | 133.1 |
| SPELL SETS UP CHARGE | 0.3 | +69.9 | 21.1 | 21.1 | 0.2 | +73.2 | 13.1 | 13.1 |
| SPELL WORTH | 1.2 | +20.8 | 43.8 | 43.8 | 1.5 | +31.1 | 145.8 | 139.3 |
| SPELLS IN THE FIGHT | 0.5 | +4.8 | 93.0 | 22.7 | 0.4 | -0.6 | 104.9 | 4.0 |
| STABLE ROLE | 11.8 | +0.0 | 478.7 | 156.1 | 9.3 | +0.0 | 310.3 | 154.4 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 0.0 | 0.1 | +7.7 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +2.9 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.0 | +1.2 | 3.5 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +38.5 | 0.0 | 39.7 | 0.6 | +27.1 | 0.0 | 22.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.9 | -42.5 | 290.8 | 116.2 | 6.9 | -45.2 | 401.7 | 91.6 |
| SUPPORTS | 3.5 | +45.8 | 129.6 | 45.0 | 4.6 | +46.1 | 170.5 | 67.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.4 | 4.1 | 4.2 | 0.1 | -2.9 | 3.9 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -4.3 | 7.9 | 12.2 | 0.8 | +3.9 | 0.0 | 24.5 |
| THROUGH LINE OF FIRE | 0.3 | +8.7 | 0.0 | 2.5 | 0.2 | +3.6 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -5.5 | 11.3 | 1.5 | 0.3 | -17.1 | 20.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.5 | +4.3 | 18.4 | 9.6 | 0.6 | +3.8 | 24.1 | 21.2 |
| WAIT AFTER COSTS | 6.9 | -280.3 | 423.1 | 181.6 | 7.5 | -419.8 | 313.7 | 218.9 |
| WALKS TO THE FIGHT | 1.5 | +32.0 | 68.9 | 13.2 | 1.0 | +20.8 | 26.2 | 26.2 |
| WAR ENGINE CHARGES | 0.1 | +9.4 | 6.1 | 12.8 | 0.1 | +4.8 | 1.8 | 5.1 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 41.4 | 10.0 | 0.2 | +0.0 | 21.5 | 0.0 |
| WEARS DOWN | 1.2 | +54.7 | 171.2 | 80.1 | 1.1 | +51.1 | 122.6 | 27.8 |
| WHO HITS BACK | 0.2 | +22.6 | 0.0 | 5.5 | 0.3 | +17.4 | 0.0 | 8.4 |
| WHOLE FIGHT | 0.1 | -0.2 | 2.9 | 0.0 | 0.4 | +18.3 | 75.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +30.1 | 80.9 | 12.2 | 0.5 | +40.4 | 71.8 | 9.5 |
| WIDER SPREAD | 2.1 | -2.8 | 214.6 | 45.7 | 2.4 | -4.8 | 272.1 | 37.5 |

### Rule changes: dep-opp-13df7bd-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1053 | 1053 | 1053 | 29.25 | -58571 | -55.6 |
| BEST FIRST | 278 | 278 | 278 | 7.72 | +10531 | +37.9 |
| DEPLOY BY FIGURES | 259 | 259 | 166 | 4.61 | +2020 | +12.2 |
| PATHS CROSS | 164 | 164 | 164 | 4.56 | +10030 | +61.2 |
| COUNTER-CHARGE COVER | 569 | 339 | 159 | 4.42 | +9453 | +59.5 |
| MOVE TO CHARGE | 266 | 266 | 151 | 4.19 | +10071 | +66.7 |
| SEARCH SPOT | 151 | 151 | 150 | 4.17 | +8446 | +56.3 |
| FACES THE THREAT | 138 | 138 | 138 | 3.83 | +9720 | +70.4 |
| KILLS COUNT NEXT TURN | 446 | 446 | 133 | 3.69 | +3189 | +24.0 |
| SUPPORTS | 293 | 293 | 122 | 3.39 | +941 | +7.7 |
| ARTILLERY RE-ROLL WEIGHED | 87 | 87 | 87 | 2.42 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +10912 | +143.6 |
| ADVANCE LANE KEPT | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 803 | 575 | 62 | 1.72 | +2437 | +39.3 |
| WAIT AFTER COSTS | 519 | 519 | 62 | 1.72 | +1190 | +19.2 |
| BEST FACING | 59 | 59 | 59 | 1.64 | +2632 | +44.6 |
| SET UP TOGETHER | 145 | 122 | 59 | 1.64 | +6932 | +117.5 |
| WALKS TO THE FIGHT | 91 | 91 | 59 | 1.64 | +796 | +13.5 |
| SAFER THAN THE JOB | 56 | 56 | 56 | 1.56 | +3611 | +64.5 |
| FALLBACK BY WORTH | 323 | 323 | 53 | 1.47 | +3145 | +59.3 |
| CHARGE NOW WEIGHED | 52 | 52 | 52 | 1.44 | +5263 | +101.2 |
| MAX FOR POSITIONING | 367 | 219 | 52 | 1.44 | +768 | +14.8 |
| BEST OVERALL | 46 | 46 | 46 | 1.28 | +3502 | +76.1 |
| REDIRECT COUNTER | 198 | 100 | 46 | 1.28 | +4297 | +93.4 |
| STOPS SHORT OF THE FLANK | 45 | 45 | 45 | 1.25 | +2361 | +52.5 |
| CANNON SIGHT KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 93 | 93 | 43 | 1.19 | +1305 | +30.4 |
| CANNON PLANNED TARGET | 254 | 254 | 41 | 1.14 | +250 | +6.1 |
| SHOOTS FROM THE BEST SPOT | 71 | 71 | 39 | 1.08 | +805 | +20.7 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +829 | +22.4 |
| MISSILES IN THE MOVE | 259 | 148 | 36 | 1.00 | +720 | +20.0 |
| MAKE SURE TOGETHER | 78 | 58 | 35 | 0.97 | +3271 | +93.5 |
| SHOT REPLANNED | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| MARCH CHECK | 38 | 35 | 33 | 0.92 | +2029 | +61.5 |
| RISK BY ARC | 166 | 159 | 32 | 0.89 | +1144 | +35.8 |
| CAST JOB | 46 | 46 | 29 | 0.81 | +556 | +19.2 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.81 | +2080 | +71.7 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1002 | +34.6 |
| CHARGE NOW FIRST | 146 | 146 | 28 | 0.78 | -1904 | -68.0 |
| LANE BY FIGURES | 25 | 25 | 25 | 0.69 | +1173 | +46.9 |
| KEEPS ITS TARGET | 141 | 139 | 24 | 0.67 | +425 | +17.7 |
| KILLS COUNT | 105 | 102 | 23 | 0.64 | +1144 | +49.7 |
| BEST PREY | 59 | 59 | 20 | 0.56 | +672 | +33.6 |
| HONEST WORTH | 566 | 559 | 20 | 0.56 | +163 | +8.2 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +44 | +2.2 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1030 | +51.5 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -73 | -3.9 |
| INVITES THE FIGHT | 100 | 100 | 19 | 0.53 | +207 | +10.9 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +217 | +11.4 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +573 | +30.2 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.53 | +443 | +23.3 |
| SCOUT WAITS | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 30 | 30 | 17 | 0.47 | +856 | +50.3 |
| RESERVE FALL BACK | 17 | 17 | 17 | 0.47 | +626 | +36.9 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -4 | -0.2 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +1372 | +85.7 |
| HUNT IN PAIRS | 46 | 28 | 16 | 0.44 | +607 | +37.9 |
| WHOLE FIGHT GAIN | 35 | 33 | 16 | 0.44 | +926 | +57.9 |
| MANOEUVRE | 14 | 14 | 13 | 0.36 | +752 | +57.9 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +3032 | +275.7 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| WEARS DOWN | 83 | 80 | 10 | 0.28 | +332 | +33.2 |
| LOST CHARGE | 167 | 167 | 9 | 0.25 | +321 | +35.7 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -653 | -81.6 |
| JOINT CHARGE PLAN | 20 | 20 | 8 | 0.22 | +1054 | +131.7 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 8 | 0.22 | -244 | -30.5 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -546 | -68.2 |
| BACKUP TARGETS | 78 | 45 | 7 | 0.19 | +27 | +3.8 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -301 | -42.9 |
| CASTING BLOCK | 8 | 8 | 6 | 0.17 | +132 | +22.1 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -119 | -19.8 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| EDGE GIVE GROUND | 16 | 16 | 5 | 0.14 | +57 | +11.3 |
| MOVES UNITS SPELL | 5 | 5 | 5 | 0.14 | +129 | +25.8 |
| OPENS UP | 8 | 8 | 5 | 0.14 | +122 | +24.5 |
| OVERRUNS AWAY | 35 | 34 | 5 | 0.14 | +112 | +22.4 |
| REFUSING RETIRES | 24 | 24 | 5 | 0.14 | -1 | -0.2 |
| SUPPORT NARROWED | 423 | 423 | 5 | 0.14 | -18 | -3.7 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +424 | +106.0 |
| WHOLE FIGHT | 18 | 17 | 4 | 0.11 | +166 | +41.5 |
| DEFENSIVE ARMY | 7 | 7 | 3 | 0.08 | -44 | -14.8 |
| OPENS A LANE | 4 | 4 | 3 | 0.08 | +68 | +22.6 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 3 | 0.08 | +88 | +29.5 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -53 | -17.8 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +114 | +37.8 |
| WAR ENGINE JOBS | 27 | 27 | 3 | 0.08 | -102 | -34.2 |
| BLOWS WHERE AIMED | 25 | 24 | 2 | 0.06 | +102 | +51.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +51 | +25.7 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -324 | -162.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -77 | -38.4 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +13 | +6.7 |
| HUNT ADVANCE | 6 | 6 | 2 | 0.06 | +70 | +35.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +58 | +29.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +324 | +162.1 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +209 | +104.6 |
| SPELLS IN THE FIGHT | 34 | 33 | 2 | 0.06 | +86 | +43.2 |
| SURE REACH TOGETHER | 49 | 37 | 2 | 0.06 | +126 | +62.9 |
| WIDER SPREAD | 162 | 155 | 2 | 0.06 | +0 | +0.0 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -9 | -9.4 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -163 | -162.6 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +6 | +5.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +25 | +24.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +15 | +15.2 |
| MISSILES NEXT TURN | 315 | 171 | 1 | 0.03 | +0 | +0.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +86 | +86.1 |
| REDIRECT BY WHAT IT STOPS | 26 | 26 | 1 | 0.03 | +14 | +14.2 |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 1 | 0.03 | +34 | +33.6 |
| STOPS | 1 | 1 | 1 | 0.03 | +39 | +38.7 |
| WAR ENGINE CHARGES | 7 | 7 | 1 | 0.03 | +21 | +21.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 41 | 41 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 28 | 25 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 388 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 14 | 13 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 29 | 29 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| LONG SHOT | 27 | 25 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 41 | 41 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 377 | 377 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| PLAN RESULT | 2637 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 99 | not checked | - | - | - | - |
| STABLE ROLE | 760 | 758 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 39 | 27 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.89 | 12.22 | 57.7 |
| FALLBACK | gate | 0.67 | 0.61 | 53.1 |
| TURN GATE | gate | 0.28 | 0.69 | 29.7 |
| CHARGE NOW FIRST | rule | 0.31 | 0.47 | 68.0 |
| AFTERMATH BAND | gate | 0.06 | 0.25 | 2.7 |
| CHAFF PASSED | rule | 0.08 | 0.17 | 8.1 |
| BEST PRIZE | rule | 0.08 | 0.14 | 81.6 |
| PATHS CROSS | rule | 0.11 | 0.11 | 55.2 |
| PURSUES BIG PREY | rule | 0.08 | 0.14 | 68.2 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.06 | 17.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.06 | 61.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.11 | 42.9 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.06 | 39.8 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 19.8 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 60.3 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.06 | 6.3 |
| SUPPORT NARROWED | rule | 0.03 | 0.08 | 4.5 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 52.6 |
| DEFENSIVE ARMY | rule | 0.08 | - | 14.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.6 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 81.3 |
| RULE SWITCHED OFF | gate | 0.08 | - | 3.3 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 7.3 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 24.7 |
| WAR ENGINE JOBS | rule | 0.06 | 0.03 | 34.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 10.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 162.0 |
| CATCH ODDS | rule | - | 0.06 | 38.4 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 9.2 |
| MARCH ODDS | rule | 0.03 | 0.03 | 86.2 |
| REDIRECT WEIGHED | rule | - | 0.06 | 72.9 |
| STANDS TO CAST | rule | - | 0.06 | 26.8 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 9.4 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 162.6 |
| FACES THE THREAT | rule | 0.03 | - | 5.0 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 2.9 |
| MOVE AND CAST | rule | - | 0.03 | 1.2 |
| SAFER THAN THE JOB | rule | - | 0.03 | 4.6 |

### Plans: dep-opp-13df7bd-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 15% | 353 | 341 | 97% |
| Mine | charge | 2.7 | 67% | 217 | 334 | 154% |
| Mine | close in | 4.8 | 31% | 306 | 145 | 47% |
| Mine | hold | 4.6 | 41% | 281 | 0 | 0% |
| Mine | join | 0.4 | 100% | 6 | 0 | 0% |
| Mine | shoot | 9.1 | 62% | 389 | 816 | 210% |
| Mine | support | 3.8 | 89% | 33 | 0 | 0% |
| Opponent | advance | 12.0 | 16% | 349 | 345 | 99% |
| Opponent | charge | 3.4 | 65% | 322 | 390 | 121% |
| Opponent | close in | 5.9 | 25% | 509 | 185 | 36% |
| Opponent | hold | 3.9 | 42% | 264 | 0 | 0% |
| Opponent | join | 1.1 | 95% | 38 | 0 | 0% |
| Opponent | shoot | 4.2 | 65% | 170 | 357 | 210% |
| Opponent | support | 5.2 | 87% | 36 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p6

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 348 | 0 | 0% | 32 |
| Opponent | 0.1 | 3 | 0 | 33% | 33% | 0% | 2.0 | 207 | 42 | 0% | 125 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 0% | 0% | 0% | - | 371 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 222 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 280 | 0 | 0% | 62 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 310 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 212 |
| Tomb Kings of Khemri | 1.0 | 2 | 0 | 50% | 50% | 0% | 2.0 | 255 | 62 | 0% | 168 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 112 | 0 | 0% | 9 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 64 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 206 |

### Battle groups: dep-opp-13df7bd-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.1 | 21% | 55% | 10% | 33% | 41% | 6% | 4% | 50% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 24% | 60% | 7% | 0% | 7% | 0% | 7% | 86% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 17% | 63% | 7% | 33% | 37% | 7% | 9% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 19% | 85% | 15% | 25% | 23% | 0% | 5% | 64% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 69 | 20% | 3.8 | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 34 | 22 (34) | 4 | 18 | 55 | 47% | 2.8 | 11 (14) | 20 (11) | 41 (9) | 29 (20) | 13 (14) |
| Mine | Character | 120 | 51 (120) | 51 | 0 | 34 | 16% | 2.3 | 65 (40) | 47 (61) | 6 (7) | 53 (72) | 53 (36) |
| Mine | Clean-up | 28 | 87 (28) | 38 | 49 | 28 | 32% | 3.4 | 62 (8) | 102 (15) | 103 (5) | 108 (16) | 66 (12) |
| Mine | Fast Hammer | 39 | 48 (39) | 35 | 13 | 46 | 15% | 2.7 | 53 (18) | 31 (12) | 63 (9) | 53 (26) | 36 (13) |
| Mine | Fragile | 6 | 31 (6) | 31 | 0 | 47 | 33% | 1.8 | 0 (1) | 59 (3) | 0 (2) | 44 (4) | 0 (2) |
| Mine | Hammer | 55 | 41 (55) | 31 | 10 | 35 | 13% | 2.9 | 4 (11) | 52 (38) | 53 (6) | 35 (35) | 51 (20) |
| Mine | Holder | 25 | 86 (25) | 10 | 76 | 7 | 48% | 3.3 | 118 (5) | 94 (14) | 40 (5) | 118 (13) | 52 (11) |
| Mine | Shooter | 39 | 63 (39) | 24 | 39 | 33 | 8% | 1.7 | 35 (13) | 88 (22) | 11 (4) | 90 (25) | 20 (14) |
| Mine | War machine | 56 | 66 (56) | 66 | 0 | 30 | 4% | 1.1 | 68 (16) | 72 (31) | 46 (9) | 32 (14) | 77 (42) |
| Mine | Wizard | 16 | 5 (16) | 5 | 0 | 33 | 25% | 2.8 | 12 (5) | 6 (5) | 0 (2) | 0 (3) | 10 (9) |
| Opponent | Chaff | 58 | 77 (58) | 12 | 65 | 53 | 55% | 2.4 | 3 (17) | 127 (24) | 73 (17) | 80 (40) | 72 (18) |
| Opponent | Character | 102 | 47 (102) | 47 | 0 | 39 | 21% | 2.7 | 49 (41) | 43 (30) | 61 (18) | 48 (59) | 52 (30) |
| Opponent | Clean-up | 28 | 25 (28) | 2 | 23 | 47 | 57% | 2.4 | 26 (6) | 32 (16) | 10 (6) | 38 (17) | 11 (11) |
| Opponent | Early | 1 | 26 (1) | 26 | 0 | 0 | 0% | 6.0 | - | 26 (1) | - | 26 (1) | - |
| Opponent | Fast | 1 | 43 (1) | 43 | 0 | 100 | 0% | 3.0 | - | 43 (1) | - | 43 (1) | - |
| Opponent | Fast Hammer | 53 | 52 (53) | 36 | 15 | 53 | 25% | 2.8 | 39 (26) | 88 (19) | 7 (8) | 46 (33) | 63 (20) |
| Opponent | Fragile | 9 | 36 (9) | 36 | 0 | 89 | 44% | 2.2 | 0 (2) | 0 (2) | 64 (5) | 0 (7) | 160 (2) |
| Opponent | Hammer | 55 | 25 (55) | 18 | 7 | 33 | 25% | 2.5 | 14 (23) | 33 (25) | 22 (7) | 26 (32) | 24 (23) |
| Opponent | Holder | 32 | 80 (32) | 7 | 73 | 45 | 38% | 3.4 | 86 (8) | 98 (15) | 43 (9) | 100 (19) | 51 (13) |
| Opponent | Shooter | 22 | 85 (22) | 39 | 45 | 37 | 5% | 1.3 | 114 (8) | 76 (13) | 0 (1) | 119 (11) | 57 (11) |
| Opponent | Support | 4 | 57 (4) | 57 | 0 | 73 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | War machine | 17 | 52 (17) | 52 | 0 | 18 | 6% | 1.9 | 86 (9) | 27 (4) | 0 (4) | 26 (3) | 57 (14) |
| Opponent | Wizard | 24 | 9 (24) | 9 | 0 | 70 | 17% | 2.4 | 0 (10) | 16 (4) | 0 (2) | 0 (6) | 9 (10) |

### Charged fights: dep-opp-13df7bd-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 89 | 570 | 3.0 | 1.0 | 190 | 19 | +171 | 7 of 12 | 11 of 12 | - | +171 |
| Mine | Chaos Dwarfs | 4 | 314 | 37 | 2.0 | 1.0 | 19 | 39 | -20 | 5 of 8 | 5 of 8 | - | -20 |
| Mine | Dwarfen Mountain Holds | 4 | 848 | 100 | 1.5 | 1.3 | 67 | 16 | +51 | 1 of 6 | 5 of 6 | +82 | +36 |
| Mine | Empire of Man | 4 | 417 | 68 | 1.2 | 1.0 | 54 | 0 | +54 | 3 of 5 | 4 of 5 | - | +54 |
| Mine | Grand Cathay | 5 | 442 | 555 | 2.8 | 1.3 | 198 | 17 | +181 | 6 of 14 | 13 of 14 | +58 | +231 |
| Mine | High Elf Realms | 4 | 251 | 486 | 3.2 | 1.2 | 150 | 31 | +118 | 5 of 13 | 9 of 13 | +240 | +96 |
| Mine | Kingdom of Bretonnia | 1 | 116 | 430 | 4.0 | 1.0 | 108 | 0 | +108 | 0 of 4 | 4 of 4 | - | +108 |
| Mine | Lizardmen | 1 | 30 | 412 | 3.0 | 1.3 | 137 | 47 | +90 | 0 of 3 | 3 of 3 | -141 | +206 |
| Mine | Ogre Kingdoms | 1 | 0 | 122 | 3.0 | 1.0 | 41 | 78 | -37 | 0 of 3 | 2 of 3 | - | -37 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 532 | 6.0 | 1.0 | 89 | 18 | +70 | 0 of 6 | 4 of 6 | - | +70 |
| Mine | Skaven | 2 | 166 | 223 | 1.5 | 1.0 | 149 | 131 | +18 | 1 of 3 | 2 of 3 | - | +18 |
| Mine | Tomb Kings of Khemri | 1 | 45 | 1080 | 4.0 | 2.5 | 270 | 0 | +270 | 2 of 4 | 4 of 4 | +270 | - |
| Mine | Vampire Counts | 2 | 0 | 470 | 4.0 | 1.5 | 118 | 19 | +98 | 4 of 8 | 6 of 8 | +201 | +37 |
| Mine | Warriors of Chaos | 2 | 0 | 130 | 2.0 | 1.2 | 65 | 71 | -6 | 2 of 4 | 4 of 4 | +102 | -42 |
| **Mine** | all armies | 36 | 289 | 334 | 2.6 | 1.2 | 129 | 28 | +102 | 36 of 93 | 76 of 93 | +148 | +91 |
| Opponent | Empire of Man | 3 | 63 | 0 | 1.0 | 1.0 | 0 | 179 | -179 | 1 of 3 | 2 of 3 | - | -179 |
| Opponent | Grand Cathay | 2 | 592 | 217 | 1.5 | 1.3 | 145 | 99 | +46 | 1 of 3 | 3 of 3 | +65 | +36 |
| Opponent | High Elf Realms | 3 | 230 | 543 | 3.0 | 1.2 | 181 | 86 | +95 | 8 of 9 | 3 of 9 | +427 | +54 |
| Opponent | Lizardmen | 1 | 60 | 0 | 1.0 | 1.0 | 0 | 282 | -282 | 1 of 1 | 1 of 1 | - | -282 |
| Opponent | Ogre Kingdoms | 1 | 60 | 128 | 1.0 | 2.0 | 128 | 0 | +128 | 1 of 1 | 1 of 1 | +128 | - |
| Opponent | Skaven | 3 | 69 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1751 | 5.0 | 1.2 | 350 | 0 | +350 | 3 of 5 | 5 of 5 | +189 | +390 |
| Opponent | Vampire Counts | 6 | 0 | 218 | 3.0 | 1.2 | 72 | 93 | -21 | 8 of 18 | 13 of 18 | +52 | -36 |
| Opponent | Warriors of Chaos | 12 | 0 | 571 | 3.6 | 1.1 | 159 | 19 | +141 | 20 of 43 | 31 of 43 | +440 | +92 |
| Opponent | Wood Elf Realms | 4 | 279 | 436 | 2.8 | 1.2 | 159 | 2 | +156 | 4 of 11 | 8 of 11 | +448 | +91 |
| **Opponent** | all armies | 36 | 97 | 385 | 2.7 | 1.2 | 144 | 46 | +98 | 48 of 96 | 68 of 96 | +300 | +61 |

### Effective charges: dep-opp-13df7bd-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 3 (net +91) | 1 (net +0) | 1 (net +60) | 2 (net +265) | 0 | 3 (net +229) | 2 | 10% (1 of 10) |
| Mine | Chaos Dwarfs | 8 | 3 (net +0) | 1 (net +0) | 0 | 2 (net -155) | 1 (net +45) | 1 (net +104) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -95) | 0 | 2 (net +20) | 1 (net +123) | 0 | 2 (net +119) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +60) | 2 (net +105) | 0 | 20% (1 of 5) |
| Mine | Grand Cathay | 14 | 1 (net +1158) | 0 | 3 (net +0) | 5 (net +97) | 0 | 4 (net +224) | 1 | 23% (3 of 13) |
| Mine | High Elf Realms | 13 | 1 (net +268) | 0 | 5 (net +25) | 1 (net +192) | 3 (net +58) | 3 (net +259) | 0 | 38% (5 of 13) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +116) | 0 | 2 (net +72) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 3 | 0 | 0 | 1 (net -141) | 0 | 1 (net +85) | 0 | 1 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +122) | 1 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +122) | 1 (net +205) | 0 | 0 | 4 | 50% (1 of 2) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net -197) | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net +666) | 0 | 0 | 1 (net +211) | 2 (net +102) | 0 | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 8 | 3 (net +156) | 1 (net -45) | 0 | 2 (net +0) | 1 (net +111) | 1 (net +251) | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 1 (net +0) | 1 (net +158) | 1 (net +102) | 1 (net -285) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 3 | 1 (net -310) | 0 | 0 | 1 (net -227) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +0) | 1 (net +65) | 0 | 1 (net +73) | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 9 | 2 (net -76) | 0 | 2 (net +358) | 2 (net +312) | 0 | 1 (net -295) | 2 | 29% (2 of 7) |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +128) | 0 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 1 (net +519) | 1 (net +0) | 2 (net +522) | 1 (net +189) | 0 | 0 | 20% (1 of 5) |
| Opponent | Vampire Counts | 18 | 2 (net +0) | 0 | 3 (net -104) | 7 (net +10) | 2 (net +32) | 4 (net -50) | 0 | 17% (3 of 18) |
| Opponent | Warriors of Chaos | 43 | 8 (net +90) | 2 (net +395) | 4 (net +8) | 4 (net +264) | 4 (net +153) | 16 (net +174) | 5 | 11% (4 of 38) |
| Opponent | Wood Elf Realms | 11 | 2 (net -14) | 1 (net +362) | 0 | 4 (net +46) | 0 | 2 (net +448) | 2 | 0% (0 of 9) |

### Charged fights, damage counted: dep-opp-13df7bd-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 338 | 360 | +196 | 271 | 40 | +232 | +68.6 |
| Mine | 50-54% | 3 | 136 | 228 | -15 | 32 | 24 | +8 | +6.1 |
| Mine | Effective (55-75%) | 16 | 249 | 196 | +13 | 48 | 61 | -13 | -5.4 |
| Mine | 76-89% | 18 | 315 | 210 | +84 | 163 | 47 | +117 | +37.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 314 | 219 | +150 | 205 | 31 | +174 | +55.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 426 | 89 | +78 | 97 | 17 | +79 | +18.6 |
| Mine | No odds | 11 | 304 | 156 | +101 | 180 | 81 | +99 | +32.4 |
| Mine | All fights | 93 | 312 | 213 | +102 | 160 | 45 | +115 | +36.8 |
| Opponent | Long shot (under 50%) | 17 | 180 | 277 | +14 | 81 | 85 | -4 | -2.4 |
| Opponent | 50-54% | 4 | 362 | 273 | +418 | 418 | 7 | +411 | +113.4 |
| Opponent | Effective (55-75%) | 11 | 272 | 270 | +40 | 159 | 123 | +36 | +13.4 |
| Opponent | 76-89% | 21 | 266 | 186 | +134 | 158 | 23 | +135 | +50.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 334 | 200 | +130 | 221 | 73 | +149 | +44.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 565 | 112 | +124 | 124 | 15 | +109 | +19.2 |
| Opponent | No odds | 10 | 178 | 226 | +5 | 99 | 68 | +31 | +17.5 |
| Opponent | All fights | 96 | 286 | 218 | +98 | 164 | 62 | +101 | +35.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p6 | move | 460 | 85 (18%) | 62 (13%) | 46 (10%) | 329 (72%) |
| dep-opp-13df7bd-p6 | objective | 388 | 67 (17%) | 59 (15%) | 33 (9%) | 288 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0124, L2431, L2628 |
| Charmed Shield | Opponent | L0124, L0224, L0325, L0427, L1325, L2134, L2325 |
| Clockwork Compass | Mine | L1214, L1230 |
| Elixir of Power | Mine | L1120, L1929 |
| Elixir of Power | Opponent | L0411, L1011 |
| Fistful of Laurels | Mine | L1829 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Mine | L2431 |
| Invocation of Nehek | Opponent | L0124, L0224, L0325, L0427, L1325, L2325 |
| Opal Amulet | Mine | L1420 |
| Opal Amulet | Opponent | L0514, L1214 |
| Periapt of Soul Exchange | Mine | L2031, L2134 |
| Periapt of Soul Exchange | Opponent | L0920, L1120, L1420 |
| Ring of Doom | Mine | L0208, L0224, L1120, L1214, L1230, L1517, L1533 |
| Ring of Doom | Opponent | L0411, L1011, L1533, L1631, L2031, L2431 |
| Ring of Jet | Mine | L1011, L1028, L1120, L1214, L1230 |
| Ring of Jet | Opponent | L0411, L1011 |
| Standard of the Fell Warrior | Mine | L1325 |
| Standard of the Fell Warrior | Opponent | L0813 |
| Storm Daemon (Renegade 2.0) | Mine | L2134 |
| Twice-Blessed Armour | Mine | L0723, L1011, L1028 |
| Witch Hunter's Ward | Mine | L0723, L0813, L0829 |
| Witch Hunter's Ward | Opponent | L0108, L0208 |

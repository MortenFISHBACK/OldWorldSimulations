# Doctrine scorecard: dep-mine-13df7bd-p3

### Scorecard: dep-mine-13df7bd-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 11 | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 6 | 0 | 3 | 0 | 0 | 0 | 30 |
| L0226 | 4 | 1 | Opponent | no | 8 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 6 | 1 | 3 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | no | - | - | 0 | 0 | 0 | 0 | 0 | 577 |
| L0327 | 3 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 681 |
| L0327 | 3 | 1 | Opponent | no | 10 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 1 | 2 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0533 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Mine | yes | 12 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 2 | 3 | 1 | 1 | 1 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 677 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 195 |
| L1013 | 5 | 1 | Mine | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 4 | 2 | 3 | 1 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 2 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 5 | 0 | 0 | 0 | 30 |
| L1327 | 1 | 1 | Mine | no | 11 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 7 | 1 | 2 | 4 | 1 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 5 | 1 | 1 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 421 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 2 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 0 | 4 | 2 | 0 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 2 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 1 | 7 | 0 | 0 | 0 | 0 | 49 |
| L1731 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 4 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 40 |
| L1831 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 11 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 3 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 4 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | yes | 6 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 144 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 329 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 4 | - | 1 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 3 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 568 |
| **Average** | | | Mine | 31% | 3.3 | 2.9 | 2.0 | 1.0 | 0.4 | 0.0 | 0.0 | 261.4 |
| **Average** | | | Opponent | 22% | 2.6 | 2.5 | 2.8 | 1.7 | 0.5 | 0.0 | 0.0 | 158.6 |

### KPIs: dep-mine-13df7bd-p3

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (43 of 174) | 8% (14 of 175) | 16% (57 of 349) |
| Winner chose to follow up after the loser gave ground |  | 95% (57 of 60); on the table 97% | 100% (42 of 42); on the table 100% | 97% (99 of 102); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 89% (16 of 18); on the table 89% | 90% (27 of 30); on the table 90% |
| Winner chose to pursue after the loser fled |  | 65% (17 of 26); on the table 73% | 62% (21 of 34); on the table 71% | 63% (38 of 60); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 87% (85 of 98); on the table 90% | 84% (79 of 94); on the table 87% | 85% (164 of 192); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 39% (134 of 342) | 35% (68 of 192) | 38% (202 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (122 of 232) | 47% (62 of 133) | 50% (184 of 365) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (14 of 28) | 49% (31 of 63) | 49% (45 of 91) |
| Points that never fought | lower | 36% (24681 of 68801) | 40% (29134 of 71990) | 38% (53815 of 140791) |
|   infantry points that never fought | lower | 40% (5639 of 14174) | 55% (7791 of 14220) | 47% (13430 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (159 of 272) | 59% (167 of 285) | 59% (326 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 84% (21 of 25); 1.6 uses a game | 100% (24 of 24); 2.1 uses a game | 92% (45 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.3 uses a game | 17% (1 of 6); 0.2 uses a game | 35% (7 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 43% (6 of 14); 0.2 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32412 of 59391) | 54% (34387 of 64043) | 54% (66799 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (24%) | 1.0 (29%) | 2.4 (26%) |
| MARCHED: its unit marched | 1.3 (23%) | 0.9 (25%) | 2.2 (24%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.1 (20%) | 0.5 (14%) | 1.6 (17%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) |
| GONE: slain | 1.4 (25%) | 0.8 (24%) | 2.3 (25%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.2 | 2.1 | 5.6 | 0.8 | 1.9 |
| not cast | 4.1 | 1.4 | 4.1 | 9.2 | 2.4 | 18.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.6 (44%) | 0.2 (5%) | 2.4 (26%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (24%) | 0.4 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (8%) | 0.7 (16%) | 1.6 (17%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (6%) | 0.3 (1%) |
| GONE: slain | 1.0 (23%) | 0.3 (21%) | 1.0 (25%) | 2.3 (25%) | 0.4 (17%) | 2.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.1 (4%) | 0.1 (1%) | 0.2 (2%) | 0.1 (5%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (10%) | 0.0 (0%) | 0.1 (1%) | 0.8 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (55%) | 0.2 (13%) | 1.7 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.8 a game | 1.1 a game |
| stood (cast and not dispelled) | 64% (28 of 44) | 52% (11 of 21) | 60% (39 of 65) |
| the unit moved after it | 68% (19 of 28) | 91% (10 of 11) | 74% (29 of 39) |
| it charged on its next turn | 7% (2 of 28) | 0% (0 of 11) | 5% (2 of 39) |
| the enemy charged it first | 11% (3 of 28) | 0% (0 of 11) | 8% (3 of 39) |
| it fought by the end of its next turn | 7% (2 of 28) | 0% (0 of 11) | 5% (2 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (6 of 28) | 36% (4 of 11) | 26% (10 of 39) |
| none of these (no charge, no fight, no charge escaped) | 61% (17 of 28) | 64% (7 of 11) | 62% (24 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (500 of 781) | 58% (376 of 644) | 61% (876 of 1425) |
|   cavalry | 62% (45 of 72) | 57% (72 of 127) | 59% (117 of 199) |
|   character | 52% (47 of 90) | 25% (34 of 134) | 36% (81 of 224) |
|   chariot | 49% (49 of 99) | 70% (21 of 30) | 54% (70 of 129) |
|   infantry | 50% (102 of 202) | 68% (183 of 268) | 61% (285 of 470) |
|   monster | 55% (21 of 38) | 75% (3 of 4) | 57% (24 of 42) |
|   war machine | 84% (236 of 280) | 78% (63 of 81) | 83% (299 of 361) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (32%) | 1.6 (22%) | 4.1 (27%) |
| CHARGED: it charged | 1.0 (13%) | 2.0 (27%) | 3.0 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.6 (9%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.3 (17%) | 1.1 (15%) | 2.4 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 1.3 (18%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.2 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.1 | 82% | 5.3 pts | 27 pts |
| character | 2.7 | 0.8 | 84% | 5.6 pts | 15 pts |
| chariot | 2.0 | 1.0 | 69% | 10.5 pts | 21 pts |
| infantry | 12.2 | 4.2 | 76% | 8.4 pts | 103 pts |
| monster | 0.8 | 0.2 | 79% | 9.4 pts | 7 pts |
| war machine | 8.4 | 7.5 | 59% | 28.0 pts | 236 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 5.4 | 4.5 |
| Charges that made contact a game | 2.7 | 4.1 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.56 declared, 0.44 contact (27 units) | 0.53 declared, 0.41 contact (17 units) | 0.55 declared, 0.43 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 0.50 declared, 0.25 contact (8 units) | 0.55 declared, 0.27 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.36 contact (232 units) | 0.69 declared, 0.53 contact (262 units) | 0.60 declared, 0.45 contact (494 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (37 of 77) | 47% (7 of 15) | 60% (6 of 10) | 49% (50 of 102) |
| Character in a unit | 88% (35 of 40) | 59% (10 of 17) | 60% (3 of 5) | 77% (48 of 62) |
| Character on its own | 81% (30 of 37) | 67% (26 of 39) | 34% (24 of 70) | 55% (80 of 146) |
| Chariot | 64% (7 of 11) | 50% (6 of 12) | - | 57% (13 of 23) |
| Infantry | 57% (40 of 70) | 52% (22 of 42) | 40% (2 of 5) | 55% (64 of 117) |
| Monster | 65% (22 of 34) | 29% (2 of 7) | - | 59% (24 of 41) |
| Monstrous | 80% (8 of 10) | 55% (6 of 11) | - | 67% (14 of 21) |
| War Machines | 77% (33 of 43) | 0% (0 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (1 of 2); on the table 50% | 34% (33 of 96) | 30% | 55% (12 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (5 of 5); on the table 100% | 64% (23 of 36) | 58% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (6 of 9); on the table 78% | - | 49% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (17 of 19); on the table 95% | 60% (18 of 30) | 37% | 64% (38 of 59) | 0.0 uses a game | 50% (1 of 2); 1.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 94% (15 of 16); on the table 94% | 36% (70 of 192) | 44% | 54% (40 of 74) | 89% (16 of 18); 5.4 uses a game | 50% (2 of 4); 0.4 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 90% (18 of 20); on the table 90% | 36% (15 of 42) | 39% | 52% (28 of 54) | 100% (9 of 9); 4.6 uses a game | 17% (2 of 12); 0.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (1 of 1); on the table 100% | - | 49% | 61% (11 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | 17% (1 of 6) | 46% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 100% | 50% (3 of 6) | 59% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (12 of 12); on the table 100% | 0% (0 of 12) | 3% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 50% (1 of 2); on the table 50% | 50% (6 of 12) | 50% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (15 of 15); on the table 100% | 0% (0 of 6) | 38% | 54% (14 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (24 of 26); on the table 96% | 33% (18 of 54) | 48% | 61% (28 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 79% (34 of 43); on the table 81% | 43% (13 of 30) | 18% | 52% (50 of 96) | 75% (3 of 4); 0.9 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 57% (8 of 14); on the table 64% | 17% (2 of 12) | 40% | 68% (42 of 62) | 100% (11 of 11); 4.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (42) | 56% (40) | 54% (82) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.83 | 1.64 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.56 | 1.08 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.25 | 1.58 | 3.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.81 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.64 | 6.19 | 11.83 |

### Quality by phase: dep-mine-13df7bd-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 62% (66 of 107) | 43% (71 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (156 of 362) | 51% (114 of 223) |
| Strategy | Close-in objectives charged next turn | 16% (25 of 157) | 17% (37 of 224) |
| Strategy | Support requests answered (helper made contact too) | 64% (7 of 11) | 44% (11 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (4 of 11) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 62% (24 of 39) | 46% (21 of 46) |
| Strategy | Lone characters that fought | 70% (67 of 96) | 73% (64 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 261.4 | 158.6 |
| Movement | Fights charged into per game | 2.5 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 75, net +120 | 17 of 90, net +175 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 75, net +47 | 20 of 90, net +74 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 75, net +159 | 6 of 90, net +143 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 75, net +115 | 22 of 90, net +202 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.1 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (124 of 292) | 49% (182 of 372) |
| Shooting | Points destroyed by shooting units | 80.7 | 33.4 |
| Shooting | War machine shots | 6.6 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (120 of 236) | 46% (31 of 67) |
| Shooting | Points destroyed by war machines | 94.3 | 10.2 |
| Magic | Magic missiles cast | 2.5 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (34 of 89) | 34% (14 of 41) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.6 |
| Magic | Wounds caused by other spells | 1.4 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 75.4 | 43.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.9 / 0.2 | 1.8 / 0.3 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 276.3 | 409.4 |
| Combat | Points run down | 84.7 | 110.3 |
| Combat | Net points per charged fight, damage counted | +98 | +118 |
| Combat | Net per 100 charger points, damage counted | +33.0 | +43.6 |
| Combat | First round won (charged fights) | 84% | 72% |
| Combat | Net points per charged fight | +85 | +112 |
| Combat | Net points per supported fight / lone fight | +114 / +80 | +108 / +112 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 89 | 57 of 123 |
| Game | Points lost | 745.1 | 683.9 |
| Game | VP from objectives | 515.3 | 585.3 |
| Game | Lone holders (player turns) | 3.3 | 2.6 |

- Mine won / drew / lost: 14 / 5 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -156 VP
- The side that went first won 18 of 31 games with a winner
- Points traded per game (both sides' losses): 1429
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 15.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +7.5 | 0.0 | 40.5 | 1.2 | +10.8 | 0.0 | 22.9 |
| BEST FACING | 0.8 | +28.1 | 0.0 | 42.6 | 0.6 | +22.9 | 0.0 | 26.9 |
| BEST FIRST | 5.2 | +226.0 | 117.4 | 117.1 | 4.4 | +198.8 | 149.5 | 58.4 |
| BEST OVERALL | 0.8 | +43.6 | 0.0 | 33.2 | 0.4 | +31.5 | 0.0 | 13.6 |
| BEST PREY | 0.8 | +46.3 | 1.1 | 6.4 | 0.8 | +43.2 | 39.5 | 10.6 |
| BEST PRIZE | 0.1 | +5.3 | 9.1 | 0.0 | 0.1 | -4.1 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.5 | -0.4 | 0.0 | 0.0 | 0.2 | -1.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.8 | 0.0 | 0.1 | +0.0 | 6.5 | 0.0 |
| BLOCKED WHEEL | 0.2 | +2.0 | 0.0 | 0.0 | 0.4 | +2.7 | 0.0 | 6.3 |
| BLOWS WHERE AIMED | 0.2 | -35.2 | 50.6 | 0.0 | 0.4 | -78.0 | 71.9 | 19.8 |
| BOMBING RUN | 0.0 | +0.6 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 92.0 | 23.2 | 0.1 | +0.0 | 10.0 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +127.1 | 460.7 | 88.2 | 1.1 | +64.6 | 38.0 | 18.1 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 3.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -4.5 | 7.2 | 0.0 | 0.1 | -0.9 | 8.6 | 17.9 |
| CARRIES OUT SET-UP | 0.2 | -5.9 | 34.6 | 0.0 | 0.1 | +0.0 | 32.6 | 16.6 |
| CAST JOB | 0.8 | +28.3 | 95.4 | 15.6 | 0.9 | +13.7 | 11.9 | 20.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +11.8 | 24.3 | 4.8 | 0.1 | +1.1 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 30.7 | 0.4 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 6.6 | 0.0 | +0.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.2 | 3.0 | 1.7 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 199.9 | 43.5 | 2.7 | +0.0 | 315.3 | 91.4 |
| CHARGE NOW WEIGHED | 0.6 | -66.4 | 2.1 | 57.8 | 0.6 | -48.2 | 18.3 | 26.4 |
| CHARGER SLAIN LOST | 0.3 | -11.2 | 36.8 | 8.8 | 0.7 | -21.5 | 45.8 | 8.8 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -2.2 | 0.0 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 41.4 | 0.4 | +0.0 | 28.5 | 22.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +96.7 | 20.7 | 12.5 | 0.4 | +36.8 | 8.3 | 11.8 |
| COUNTER-CHARGE COVER | 10.5 | +907.4 | 0.0 | 251.3 | 8.3 | +769.9 | 0.0 | 157.6 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 3.1 | 0.1 | +0.0 | 0.0 | 6.6 |
| DEPLOY BY FIGURES | 7.6 | +17.9 | 0.0 | 5.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +7.4 | 29.5 | 0.0 | 0.3 | +4.4 | 11.5 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.9 | 0.0 | 8.2 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +175.6 | 0.0 | 119.4 | 1.6 | +151.3 | 0.0 | 44.5 |
| FALLBACK BY WORTH | 4.8 | +79.3 | 0.0 | 80.1 | 5.9 | +84.6 | 0.0 | 65.4 |
| FIGHT LIFT | 0.1 | +0.5 | 3.2 | 11.0 | 0.1 | +0.8 | 6.4 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 171.5 | 6.1 | +0.0 | 0.0 | 147.4 |
| FOCUS FIRE | 0.0 | +0.0 | 1.4 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +157.0 | 0.0 | 84.2 | 0.9 | +119.1 | 0.0 | 9.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +17.7 | 0.0 | 24.2 | 0.1 | +2.6 | 0.0 | 3.2 |
| GIVES UP | 0.0 | -0.2 | 7.6 | 3.2 | 0.1 | -0.2 | 11.7 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 2.7 | 0.0 | 0.1 | -0.8 | 0.0 | 2.3 |
| GROUND FLIERS | 0.1 | +0.9 | 0.0 | 4.8 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 4.9 | 1.2 | 0.0 | +0.0 | 3.1 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 18.4 | 1.2 | 0.2 | +0.0 | 15.5 | 3.2 |
| HILL BY ITS CHANCE | 0.3 | -47.2 | 0.0 | 0.0 | 0.5 | -48.8 | 0.0 | 8.8 |
| HOLDER AT DEPLOYMENT | 0.9 | +144.1 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -124.3 | 414.1 | 124.1 | 8.5 | -211.1 | 546.4 | 249.6 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +10.5 | 0.0 | 4.3 | 0.2 | +7.7 | 3.5 | 2.7 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 10.4 | 2.7 |
| HUNT IN PAIRS | 0.6 | +18.0 | 0.0 | 16.1 | 0.5 | +35.4 | 0.0 | 13.9 |
| HUNT KEPT | 0.2 | +5.5 | 0.0 | 4.3 | 0.1 | +1.2 | 7.8 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +10.6 | 10.4 | 8.6 |
| HUNT THE GUNS | 0.1 | +32.6 | 0.0 | 1.4 | 0.4 | +121.2 | 10.6 | 5.9 |
| INVITES THE FIGHT | 1.6 | +38.4 | 69.4 | 6.1 | 1.1 | +21.7 | 8.9 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +0.2 | 0.0 | 3.2 | 0.3 | +17.8 | 16.1 | 7.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.9 | 0.0 | 3.2 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.4 | 7.6 | 0.0 | 0.1 | +0.2 | 1.1 | 9.4 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 127.9 | 51.0 | 2.0 | +59.2 | 216.9 | 59.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +66.5 | 113.6 | 38.9 | 1.9 | +96.2 | 206.5 | 36.8 |
| KILLS COUNT NEXT TURN | 5.1 | +173.6 | 135.6 | 173.2 | 7.2 | +240.7 | 290.3 | 171.5 |
| LANE BY FIGURES | 0.9 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.2 | +10.5 | 0.0 | 0.0 | 0.2 | +10.8 | 44.1 | 8.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 19.1 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.6 | 15.8 | 9.6 | 0.4 | +0.2 | 11.1 | 0.0 |
| LOST CHARGE | 3.2 | -65.4 | 100.2 | 92.1 | 2.8 | -58.5 | 89.2 | 77.4 |
| LURE BY WHAT IT DRAWS | 0.1 | -0.2 | 0.0 | 4.7 | 0.1 | -7.5 | 0.0 | 2.2 |
| MAKE SURE TOGETHER | 0.6 | +26.1 | 25.6 | 7.7 | 1.2 | +146.5 | 56.1 | 64.9 |
| MANOEUVRE | 0.3 | +8.8 | 0.0 | 4.0 | 0.1 | +2.5 | 0.0 | 2.0 |
| MARCH AT ESCAPER | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +33.7 | 0.0 | 27.7 | 0.8 | +27.5 | 0.0 | 3.0 |
| MARCH ODDS | 0.1 | +5.7 | 0.0 | 11.0 | 0.3 | +24.8 | 23.6 | 12.1 |
| MARCH OVER CASTS | 0.8 | +63.8 | 0.0 | 39.1 | 0.6 | +66.4 | 0.0 | 11.8 |
| MAX FOR POSITIONING | 5.3 | +206.8 | 0.0 | 124.9 | 5.1 | +203.4 | 0.0 | 107.4 |
| MISSILES IN THE MOVE | 4.6 | +151.2 | 0.0 | 133.1 | 4.0 | +67.7 | 0.0 | 66.0 |
| MISSILES NEXT TURN | 5.7 | +106.2 | 0.0 | 163.1 | 5.0 | +48.9 | 0.0 | 88.0 |
| MODEL FACING | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 20.3 | 16.1 | 0.3 | +0.0 | 0.0 | 27.8 |
| MOVE AND CAST | 0.6 | +23.8 | 0.0 | 12.7 | 0.6 | +26.9 | 0.0 | 5.4 |
| MOVE SPELL IN RANGE | 0.3 | +10.7 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.2 | 0.0 | 44.7 | 0.3 | -6.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +242.6 | 117.0 | 77.3 | 4.6 | +423.5 | 176.2 | 150.8 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -7.6 | 18.6 | 0.0 | 0.2 | -14.7 | 28.0 | 1.2 |
| NOT TURNED | 5.6 | +159.5 | 0.0 | 108.8 | 6.2 | +71.8 | 0.0 | 129.9 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 47.2 | 0.6 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 16.1 | -807.5 | 0.0 | 316.7 | 15.1 | -829.9 | 10.3 | 287.1 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.9 | 20.6 | 0.0 |
| OPENS UP | 0.3 | +27.0 | 13.5 | 0.0 | 0.2 | +10.9 | 10.8 | 0.0 |
| OVERRUN THREAT | 0.0 | +1.7 | 0.0 | 4.9 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +6.6 | 60.1 | 11.0 | 0.5 | +6.5 | 48.7 | 37.4 |
| PATHS CROSS | 2.4 | +163.7 | 0.0 | 19.6 | 2.9 | +197.3 | 0.0 | 56.1 |
| PERIAPT WORTH | 0.0 | +3.0 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -4.4 | 0.0 | 8.6 | 0.2 | -1.1 | 0.0 | 2.7 |
| PLAN RESULT | 36.8 | +1439.1 | 1245.9 | 996.8 | 37.6 | +1225.3 | 1368.0 | 990.3 |
| PURSUES BIG PREY | 0.2 | -8.4 | 0.0 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +2.8 | 0.0 | 32.8 | 1.8 | +24.8 | 0.0 | 65.8 |
| RANDOM MOVER NO PROMISE | 0.2 | -13.1 | 8.7 | 15.3 | 0.6 | -23.1 | 6.2 | 16.4 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -4.4 | 0.0 | 5.7 | 0.8 | -18.3 | 0.0 | 13.5 |
| REDIRECT COUNTER | 2.5 | +209.3 | 0.0 | 39.9 | 3.8 | +257.4 | 0.0 | 60.4 |
| REDIRECT WEIGHED | 0.2 | +6.2 | 12.0 | 0.0 | 0.3 | +8.1 | 9.7 | 1.2 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 11.3 | 0.4 | +0.0 | 0.0 | 33.3 |
| RESERVE FALL BACK | 0.5 | +11.1 | 0.0 | 33.2 | 1.0 | +46.7 | 0.0 | 14.0 |
| RESTRAINS TO SHOOT | 0.1 | +5.5 | 0.0 | 1.7 | 0.1 | +3.7 | 0.0 | 24.0 |
| RISK BY ARC | 2.2 | +82.0 | 239.4 | 71.8 | 2.9 | +88.6 | 268.1 | 76.4 |
| SAFE SURE CHARGE | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +50.7 | 0.0 | 17.5 | 0.8 | +63.3 | 0.0 | 22.3 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.4 | 0.0 | 1.0 | 0.2 | -15.0 | 0.0 | 1.1 |
| SEARCH SPOT | 2.4 | +136.6 | 0.0 | 21.0 | 3.1 | +185.4 | 0.0 | 15.0 |
| SECOND HUNTER | 0.0 | -0.5 | 0.0 | 1.4 | 0.0 | -0.2 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +54.6 | 0.0 | 52.9 | 0.2 | +66.0 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.0 | +61.8 | 25.6 | 38.5 | 2.3 | +247.8 | 56.1 | 91.7 |
| SET-UP ANY TARGET | 0.4 | +73.5 | 20.7 | 2.6 | 0.1 | +8.7 | 3.0 | 6.5 |
| SET-UP MISSED | 0.1 | +9.3 | 5.1 | 0.0 | 0.0 | +4.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.5 | 0.0 | 1.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +45.3 | 37.2 | 30.0 | 0.8 | +22.5 | 28.4 | 14.3 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 98.1 | 11.1 | 0.4 | +0.0 | 43.4 | 0.0 |
| SHOTS IN THE MOVE | 13.4 | +455.3 | 0.0 | 234.4 | 9.8 | +305.7 | 0.0 | 110.8 |
| SPELL CATCH ODDS | 0.2 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.5 | +87.3 | 20.7 | 2.6 | 0.1 | +8.7 | 3.0 | 6.5 |
| SPELL WORTH | 1.2 | +18.1 | 72.9 | 66.3 | 2.3 | +32.1 | 105.4 | 86.9 |
| SPELLS IN THE FIGHT | 0.4 | +2.6 | 63.4 | 24.7 | 0.6 | -13.2 | 86.3 | 48.0 |
| STABLE ROLE | 9.7 | +0.0 | 261.3 | 162.1 | 9.0 | +0.0 | 391.5 | 166.3 |
| STANDS TO CAST | 0.1 | +4.4 | 0.0 | 12.9 | 0.0 | +0.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 4.8 | 0.1 | +6.6 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.2 | +15.0 | 7.1 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.9 | +24.8 | 0.0 | 27.0 | 0.3 | +14.6 | 0.0 | 7.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.6 | -36.3 | 235.6 | 88.8 | 6.3 | -44.2 | 306.1 | 70.9 |
| SUPPORTS | 3.2 | +41.6 | 115.9 | 54.8 | 4.0 | +44.2 | 146.0 | 25.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.8 | 4.8 | 0.0 | 0.1 | -3.9 | 4.6 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +4.3 | 0.0 | 25.1 | 0.8 | -7.5 | 10.9 | 8.4 |
| THROUGH LINE OF FIRE | 0.4 | +10.0 | 0.0 | 0.0 | 0.2 | +7.1 | 0.0 | 23.6 |
| TURN WORTH | 0.3 | -24.4 | 35.9 | 5.2 | 0.3 | -19.2 | 14.9 | 14.3 |
| TWO OR MORE ARRIVE | 0.3 | +0.5 | 5.9 | 7.0 | 0.8 | +4.0 | 35.4 | 38.1 |
| WAIT AFTER COSTS | 6.4 | -353.2 | 216.9 | 122.5 | 7.2 | -385.4 | 251.9 | 204.2 |
| WALKS TO THE FIGHT | 1.3 | +25.8 | 31.8 | 25.7 | 0.7 | +8.9 | 6.9 | 42.8 |
| WAR ENGINE CHARGES | 0.1 | +9.3 | 1.9 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 28.4 | 12.4 | 0.1 | +0.0 | 2.4 | 3.8 |
| WEARS DOWN | 0.8 | +47.1 | 137.5 | 21.8 | 1.1 | +43.1 | 113.0 | 66.2 |
| WHO HITS BACK | 0.2 | +13.8 | 0.0 | 4.9 | 0.2 | +38.0 | 0.0 | 3.2 |
| WHOLE FIGHT | 0.1 | +1.8 | 21.3 | 0.0 | 0.3 | +12.7 | 48.2 | 6.2 |
| WHOLE FIGHT GAIN | 0.3 | +23.9 | 17.4 | 7.3 | 0.6 | +29.6 | 32.4 | 7.7 |
| WIDER SPREAD | 1.9 | -8.5 | 203.2 | 63.8 | 3.1 | -9.4 | 295.3 | 66.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: dep-mine-13df7bd-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1124 | 1124 | 1124 | 31.22 | -58946 | -52.4 |
| BEST FIRST | 345 | 345 | 345 | 9.58 | +15295 | +44.3 |
| SEARCH SPOT | 195 | 195 | 194 | 5.39 | +11632 | +60.0 |
| PATHS CROSS | 189 | 189 | 189 | 5.25 | +12995 | +68.8 |
| MOVE TO CHARGE | 285 | 285 | 173 | 4.81 | +9609 | +55.5 |
| DEPLOY BY FIGURES | 273 | 273 | 166 | 4.61 | +2366 | +14.3 |
| COUNTER-CHARGE COVER | 676 | 371 | 156 | 4.33 | +10816 | +69.3 |
| FACES THE THREAT | 138 | 138 | 138 | 3.83 | +11767 | +85.3 |
| KILLS COUNT NEXT TURN | 444 | 444 | 136 | 3.78 | +3631 | +26.7 |
| SUPPORTS | 260 | 260 | 96 | 2.67 | +1059 | +11.0 |
| FALLBACK BY WORTH | 386 | 386 | 94 | 2.61 | +5900 | +62.8 |
| FOLLOW UP WEIGHED | 74 | 74 | 74 | 2.06 | +9938 | +134.3 |
| ARTILLERY RE-ROLL WEIGHED | 73 | 73 | 73 | 2.03 | +0 | +0.0 |
| SET UP TOGETHER | 121 | 100 | 63 | 1.75 | +5026 | +79.8 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +4106 | +66.2 |
| ADVANCE LANE KEPT | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| SHOTS IN THE MOVE | 836 | 569 | 57 | 1.58 | +1741 | +30.5 |
| RESERVE FALL BACK | 55 | 55 | 55 | 1.53 | +2080 | +37.8 |
| CANNON SIGHT KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| BEST FACING | 52 | 52 | 52 | 1.44 | +1837 | +35.3 |
| REDIRECT COUNTER | 229 | 115 | 48 | 1.33 | +4390 | +91.5 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +3742 | +83.2 |
| RANDOM MOVE BY FIGURES | 91 | 91 | 45 | 1.25 | +996 | +22.1 |
| WAIT AFTER COSTS | 492 | 492 | 45 | 1.25 | +1224 | +27.2 |
| MARCH CHECK | 53 | 49 | 44 | 1.22 | +2194 | +49.9 |
| MOVE AND CAST | 44 | 44 | 44 | 1.22 | +1823 | +41.4 |
| STOPS SHORT OF THE FLANK | 43 | 43 | 43 | 1.19 | +1419 | +33.0 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +2706 | +64.4 |
| CHARGE NOW FIRST | 163 | 163 | 40 | 1.11 | -3750 | -93.8 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RISK BY ARC | 183 | 173 | 37 | 1.03 | +828 | +22.4 |
| MAX FOR POSITIONING | 374 | 202 | 36 | 1.00 | +567 | +15.7 |
| SHOOTS FROM THE BEST SPOT | 70 | 70 | 36 | 1.00 | +758 | +21.1 |
| SHOT REPLANNED | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| CANNON PLANNED TARGET | 236 | 236 | 32 | 0.89 | +17 | +0.5 |
| WALKS TO THE FIGHT | 71 | 71 | 32 | 0.89 | +470 | +14.7 |
| LANE BY FIGURES | 31 | 31 | 31 | 0.86 | +1067 | +34.4 |
| CAST JOB | 61 | 61 | 30 | 0.83 | +729 | +24.3 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| MISSILES IN THE MOVE | 311 | 173 | 29 | 0.81 | +501 | +17.3 |
| MAKE SURE TOGETHER | 63 | 46 | 28 | 0.78 | +2468 | +88.2 |
| KILLS COUNT | 118 | 113 | 27 | 0.75 | +1411 | +52.2 |
| HONEST WORTH | 560 | 554 | 25 | 0.69 | +271 | +10.8 |
| INVITES THE FIGHT | 95 | 95 | 25 | 0.69 | +345 | +13.8 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 24 | 24 | 24 | 0.67 | -67 | -2.8 |
| KEEPS ITS TARGET | 123 | 120 | 24 | 0.67 | +365 | +15.2 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +168 | +7.3 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.61 | +53 | +2.4 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +659 | +31.4 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +616 | +30.8 |
| BEST PREY | 56 | 56 | 17 | 0.47 | +782 | +46.0 |
| WHOLE FIGHT GAIN | 30 | 27 | 17 | 0.47 | +669 | +39.3 |
| MARCH ODDS | 16 | 16 | 15 | 0.42 | +240 | +16.0 |
| OPENS UP | 16 | 16 | 14 | 0.39 | +451 | +32.2 |
| WEARS DOWN | 70 | 68 | 14 | 0.39 | +479 | +34.2 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1385 | +98.9 |
| CASTER AWAY FROM SCREEN | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 31 | 31 | 13 | 0.36 | +589 | +45.3 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -11 | -0.9 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +733 | +66.6 |
| MANOEUVRE | 14 | 14 | 11 | 0.31 | +407 | +37.0 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.31 | -196 | -17.8 |
| LONE WIZARD HOLDS BACK | 21 | 21 | 10 | 0.28 | -163 | -16.3 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 219 | 219 | 9 | 0.25 | +140 | +15.6 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -398 | -44.2 |
| REFUSING RETIRES | 31 | 31 | 9 | 0.25 | -3 | -0.3 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +332 | +36.9 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 393 | 393 | 8 | 0.22 | -42 | -5.2 |
| HUNT IN PAIRS | 41 | 19 | 7 | 0.19 | +267 | +38.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| STOPS | 9 | 9 | 7 | 0.19 | +327 | +46.8 |
| SURE REACH TOGETHER | 42 | 32 | 7 | 0.19 | +110 | +15.7 |
| CASTING BLOCK | 9 | 9 | 6 | 0.17 | +274 | +45.7 |
| MISSILES NEXT TURN | 386 | 207 | 6 | 0.17 | +59 | +9.8 |
| OVERRUNS AWAY | 35 | 33 | 6 | 0.17 | +55 | +9.2 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +160 | +32.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -206 | -41.1 |
| WIDER SPREAD | 183 | 175 | 5 | 0.14 | +15 | +3.1 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -291 | -72.8 |
| HORN WORTH | 4 | 4 | 4 | 0.11 | +72 | +18.0 |
| WAR ENGINE JOBS | 22 | 22 | 4 | 0.11 | -173 | -43.2 |
| CARRIES OUT SET-UP | 12 | 12 | 3 | 0.08 | -212 | -70.8 |
| EDGE GIVE GROUND | 18 | 18 | 3 | 0.08 | +77 | +25.5 |
| JOINT CHARGE PLAN | 13 | 13 | 3 | 0.08 | +212 | +70.6 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +16 | +5.5 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +238 | +79.4 |
| BACKUP TARGETS | 90 | 42 | 2 | 0.06 | +9 | +4.5 |
| CARRIES OUT COUNTER | 4 | 4 | 2 | 0.06 | -193 | -96.6 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +47 | +23.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +32 | +15.8 |
| HILL BY ITS CHANCE | 29 | 29 | 2 | 0.06 | +80 | +40.2 |
| LONG SHOT | 24 | 24 | 2 | 0.06 | +34 | +17.1 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +230 | +115.1 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +35 | +17.4 |
| REDIRECT BY WHAT IT STOPS | 42 | 42 | 2 | 0.06 | +168 | +84.2 |
| SPELLS IN THE FIGHT | 36 | 32 | 2 | 0.06 | +2 | +0.8 |
| BLOWS WHERE AIMED | 22 | 22 | 1 | 0.03 | +4 | +3.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +22 | +22.1 |
| CHARGER SLAIN LOST | 35 | 32 | 1 | 0.03 | +4 | +3.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -30 | -30.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 14 | 14 | 1 | 0.03 | -2 | -2.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +33 | +33.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MODEL FACING | 1 | 1 | 1 | 0.03 | +105 | +105.0 |
| MOVE SPELL IN RANGE | 10 | 6 | 1 | 0.03 | +13 | +13.4 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +50 | +50.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -5 | -5.0 |
| TWO OR MORE ARRIVE | 41 | 31 | 1 | 0.03 | +17 | +16.6 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +7 | +6.8 |
| WHOLE FIGHT | 17 | 16 | 1 | 0.03 | +43 | +42.9 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -36 | -36.5 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 44 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 45 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 446 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 16 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 14 | 14 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 12 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 49 | 49 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 22 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 426 | 426 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2678 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 18 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 6 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 128 | not checked | - | - | - | - |
| STABLE ROLE | 673 | 673 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 20 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.31 | 12.97 | 53.5 |
| FALLBACK | gate | 0.78 | 0.81 | 50.6 |
| TURN GATE | gate | 0.61 | 0.81 | 39.9 |
| CHARGE NOW FIRST | rule | 0.44 | 0.67 | 93.8 |
| BIG CHARACTER SAFETY | rule | 0.22 | 0.14 | 8.1 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.19 | 39.4 |
| AFTERMATH BAND | gate | 0.11 | 0.19 | 2.2 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.19 | 17.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.14 | 52.6 |
| PURSUES BIG PREY | rule | 0.19 | 0.06 | 44.2 |
| PATHS CROSS | rule | 0.08 | 0.14 | 33.2 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 5.9 |
| SUPPORT REQUEST | gate | 0.03 | 0.17 | 88.1 |
| STOPS SHORT OF THE FLANK | rule | 0.17 | - | 6.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 73.7 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 2.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.14 | 32.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.06 | 41.1 |
| BEST PRIZE | rule | 0.06 | 0.06 | 72.8 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 6.5 |
| SAFER THAN THE JOB | rule | 0.06 | 0.06 | 9.1 |
| WAR ENGINE JOBS | rule | 0.08 | 0.03 | 43.2 |
| CARRIES OUT SET-UP | rule | 0.08 | - | 70.8 |
| FACES THE THREAT | rule | - | 0.08 | 9.4 |
| FALLBACK BY WORTH | rule | 0.03 | 0.06 | 57.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.06 | 14.7 |
| CANNON PLANNED TARGET | rule | 0.06 | - | 27.8 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 96.6 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 30.4 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.2 |
| FIGHT ORDER BAND | gate | 0.03 | - | 0.7 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 5.0 |
| MARCH ODDS | rule | - | 0.03 | 6.3 |
| REDIRECT WEIGHED | rule | 0.03 | - | 35.0 |
| REFUSING RETIRES | rule | 0.03 | - | 1.0 |
| SAFE SURE CHARGE | rule | 0.03 | - | 5.0 |
| STANDS TO CAST | rule | - | 0.03 | 12.2 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 36.5 |

### Plans: dep-mine-13df7bd-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 15% | 484 | 330 | 68% |
| Mine | charge | 2.6 | 71% | 192 | 267 | 139% |
| Mine | close in | 4.4 | 27% | 241 | 130 | 54% |
| Mine | hold | 5.0 | 30% | 300 | 0 | 0% |
| Mine | join | 0.2 | 83% | 9 | 0 | 0% |
| Mine | shoot | 8.6 | 66% | 203 | 712 | 350% |
| Mine | support | 3.8 | 88% | 34 | 0 | 0% |
| Opponent | advance | 12.1 | 17% | 304 | 329 | 108% |
| Opponent | charge | 4.1 | 55% | 349 | 426 | 122% |
| Opponent | close in | 6.2 | 25% | 448 | 211 | 47% |
| Opponent | hold | 4.2 | 22% | 259 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 28 | 0 | 0% |
| Opponent | shoot | 5.1 | 57% | 166 | 266 | 160% |
| Opponent | support | 4.8 | 90% | 42 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 2 | 0% | 0% | 0% | - | 392 | 0 | 0% | 10 |
| Opponent | 0.4 | 14 | 2 | 8% | 8% | 0% | 2.0 | 332 | 32 | 8% | 106 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 2 | 0% | 0% | 0% | - | 392 | 0 | 0% | 68 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 96 |
| High Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 541 | 190 | 50% | 73 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 309 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 210 |
| Tomb Kings of Khemri | 0.8 | 5 | 0 | 0% | 0% | 0% | - | 320 | 0 | 0% | 77 |
| Vampire Counts | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 99 | 0 | 0% | 6 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 368 | 0 | 0% | 29 |
| Wood Elf Realms | 0.5 | 3 | 1 | 0% | 0% | 0% | - | 235 | 0 | 0% | 64 |

### Battle groups: dep-mine-13df7bd-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.5 | 24% | 46% | 9% | 12% | 30% | 20% | 13% | 36% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 22% | 75% | 0% | - | 5% | 5% | 10% | 70% | 10% |
| Opponent | COUNTER-CHARGE COVER | 8.3 | 15% | 61% | 20% | 67% | 37% | 9% | 9% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 25% | 66% | 17% | 33% | 3% | 0% | 3% | 86% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 32 | 85 (32) | 28 | 57 | 41 | 41% | 2.6 | 98 (13) | 65 (11) | 78 (8) | 95 (27) | 23 (5) |
| Mine | Character | 116 | 45 (116) | 45 | 0 | 38 | 19% | 2.3 | 38 (50) | 67 (41) | 30 (10) | 47 (61) | 48 (40) |
| Mine | Clean-up | 18 | 59 (18) | 21 | 38 | 49 | 44% | 2.7 | 90 (6) | 43 (11) | 0 (1) | 72 (14) | 32 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 35 (44) | 21 | 14 | 46 | 18% | 3.3 | 27 (23) | 49 (16) | 30 (5) | 23 (27) | 60 (17) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.7 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Mine | Hammer | 52 | 37 (52) | 24 | 13 | 38 | 19% | 2.5 | 38 (26) | 32 (22) | 57 (4) | 52 (30) | 18 (22) |
| Mine | Holder | 27 | 47 (27) | 13 | 34 | 46 | 37% | 3.4 | 66 (8) | 33 (14) | 64 (5) | 40 (17) | 63 (10) |
| Mine | Shooter | 37 | 79 (37) | 30 | 48 | 47 | 3% | 1.9 | 70 (8) | 84 (25) | 62 (4) | 86 (26) | 64 (11) |
| Mine | Support | 4 | 151 (4) | 151 | 0 | 0 | 0% | 3.0 | 241 (1) | 86 (3) | - | 151 (4) | - |
| Mine | War machine | 52 | 59 (52) | 59 | 0 | 39 | 2% | 1.3 | 60 (24) | 40 (25) | 201 (3) | 60 (19) | 58 (33) |
| Mine | Wizard | 19 | 9 (19) | 9 | 0 | 41 | 5% | 2.2 | 7 (7) | 8 (3) | 31 (3) | 9 (6) | 16 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 69 | 42 (69) | 9 | 33 | 52 | 45% | 2.7 | 65 (30) | 79 (12) | 3 (27) | 46 (48) | 33 (21) |
| Opponent | Character | 102 | 52 (102) | 52 | 0 | 26 | 19% | 2.3 | 54 (37) | 58 (54) | 12 (7) | 47 (56) | 61 (42) |
| Opponent | Clean-up | 11 | 53 (11) | 8 | 45 | 29 | 36% | 3.4 | 0 (2) | 51 (7) | 114 (2) | 78 (7) | 23 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 49 (60) | 30 | 18 | 42 | 28% | 2.6 | 30 (31) | 63 (20) | 82 (9) | 47 (33) | 50 (27) |
| Opponent | Fragile | 3 | 115 (3) | 115 | 0 | 0 | 0% | 3.0 | - | 162 (1) | 92 (2) | 173 (2) | 0 (1) |
| Opponent | Hammer | 50 | 41 (50) | 31 | 10 | 51 | 24% | 3.2 | 0 (14) | 52 (34) | 28 (2) | 56 (29) | 21 (21) |
| Opponent | Holder | 37 | 61 (37) | 8 | 54 | 33 | 41% | 2.9 | 45 (11) | 80 (17) | 43 (8) | 69 (24) | 52 (12) |
| Opponent | Shooter | 29 | 62 (29) | 28 | 34 | 37 | 0% | 1.5 | 24 (7) | 69 (20) | 188 (2) | 89 (15) | 43 (14) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 83 | 50% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 17 | 18 (17) | 18 | 0 | 40 | 12% | 1.3 | 0 (4) | 20 (9) | 26 (4) | 0 (5) | 23 (12) |
| Opponent | Wizard | 32 | 9 (32) | 9 | 0 | 45 | 16% | 2.2 | 5 (11) | 16 (11) | 17 (4) | 23 (10) | 2 (16) |

### Charged fights: dep-mine-13df7bd-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 231 | 10 | 0.8 | 1.3 | 13 | 0 | +13 | 0 of 3 | 3 of 3 | +40 | +0 |
| Mine | Chaos Dwarfs | 4 | 336 | 213 | 1.8 | 1.1 | 122 | 0 | +122 | 1 of 7 | 6 of 7 | +619 | +39 |
| Mine | Dwarfen Mountain Holds | 3 | 510 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Empire of Man | 5 | 302 | 207 | 2.0 | 1.1 | 103 | 57 | +46 | 3 of 10 | 10 of 10 | -189 | +73 |
| Mine | Grand Cathay | 5 | 466 | 380 | 2.8 | 1.3 | 136 | 12 | +124 | 5 of 14 | 13 of 14 | +170 | +105 |
| Mine | High Elf Realms | 4 | 176 | 660 | 4.0 | 1.2 | 165 | 49 | +116 | 10 of 16 | 14 of 16 | +98 | +118 |
| Mine | Kingdom of Bretonnia | 1 | 128 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Lizardmen | 1 | 348 | 1029 | 5.0 | 1.0 | 206 | 37 | +169 | 1 of 5 | 4 of 5 | - | +169 |
| Mine | Ogre Kingdoms | 1 | 195 | 251 | 3.0 | 1.0 | 84 | 11 | +72 | 2 of 3 | 1 of 3 | - | +72 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 411 | 5.0 | 1.2 | 82 | 52 | +30 | 1 of 5 | 5 of 5 | -261 | +103 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 420 | 4.5 | 1.2 | 93 | 57 | +37 | 1 of 9 | 7 of 9 | +196 | -9 |
| Mine | Vampire Counts | 2 | 0 | 344 | 4.0 | 1.1 | 86 | 12 | +74 | 1 of 8 | 6 of 8 | +0 | +84 |
| Mine | Warriors of Chaos | 2 | 0 | 240 | 3.5 | 1.0 | 68 | 0 | +68 | 2 of 7 | 5 of 7 | - | +68 |
| **Mine** | all armies | 36 | 250 | 282 | 2.5 | 1.2 | 114 | 29 | +85 | 27 of 89 | 75 of 89 | +114 | +80 |
| Opponent | Empire of Man | 1 | 189 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 3 | 164 | 336 | 2.0 | 1.2 | 168 | 72 | +96 | 2 of 6 | 5 of 6 | +65 | +102 |
| Opponent | High Elf Realms | 3 | 123 | 448 | 2.3 | 1.0 | 192 | 0 | +192 | 4 of 7 | 5 of 7 | - | +192 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 0 of 2 | - | +0 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 362 | 5.0 | 1.0 | 72 | 22 | +50 | 0 of 5 | 3 of 5 | - | +50 |
| Opponent | Skaven | 1 | 330 | 60 | 2.0 | 1.0 | 30 | 0 | +30 | 1 of 2 | 0 of 2 | - | +30 |
| Opponent | Tomb Kings of Khemri | 4 | 75 | 685 | 3.8 | 1.3 | 183 | 0 | +183 | 6 of 15 | 13 of 15 | +285 | +157 |
| Opponent | Vampire Counts | 6 | 14 | 464 | 3.5 | 1.1 | 132 | 66 | +67 | 8 of 21 | 16 of 21 | -580 | +135 |
| Opponent | Warriors of Chaos | 9 | 64 | 742 | 4.0 | 1.2 | 186 | 17 | +169 | 21 of 36 | 29 of 36 | +137 | +176 |
| Opponent | Wood Elf Realms | 6 | 117 | 406 | 4.5 | 1.1 | 90 | 42 | +48 | 11 of 27 | 17 of 27 | +334 | +12 |
| **Opponent** | all armies | 36 | 87 | 484 | 3.4 | 1.1 | 142 | 30 | +112 | 57 of 123 | 89 of 123 | +108 | +112 |

### Effective charges: dep-mine-13df7bd-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +40) | 2 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 1 (net +0) | 2 (net +35) | 1 (net +619) | 2 (net +0) | 1 | 17% (1 of 6) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 10 | 1 (net +482) | 0 | 1 (net -380) | 5 (net +110) | 0 | 3 (net -63) | 0 | 10% (1 of 10) |
| Mine | Grand Cathay | 14 | 1 (net +0) | 1 (net +277) | 4 (net +71) | 1 (net +0) | 0 | 7 (net +167) | 0 | 29% (4 of 14) |
| Mine | High Elf Realms | 16 | 1 (net +326) | 1 (net +0) | 4 (net +48) | 2 (net +15) | 1 (net +55) | 5 (net +158) | 2 | 29% (4 of 14) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +743) | 1 (net +0) | 0 | 0 | 3 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 1 (net +251) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +139) | 1 (net +137) | 0 | 0 | 3 | 50% (1 of 2) |
| Mine | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 4 (net -67) | 2 (net +198) | 3 (net +67) | 0 | 0 | 44% (4 of 9) |
| Mine | Vampire Counts | 8 | 2 (net -50) | 0 | 0 | 0 | 1 (net +80) | 4 (net +152) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 7 | 1 (net +0) | 2 (net +0) | 1 (net +137) | 1 (net +0) | 0 | 1 (net +342) | 1 | 17% (1 of 6) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 6 | 1 (net -434) | 0 | 2 (net +406) | 1 (net +55) | 1 (net +65) | 1 (net +77) | 0 | 33% (2 of 6) |
| Opponent | High Elf Realms | 7 | 1 (net +0) | 3 (net +339) | 2 (net +0) | 0 | 0 | 1 (net +327) | 0 | 29% (2 of 7) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 4 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +60) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net +780) | 0 | 4 (net +102) | 4 (net +55) | 0 | 1 (net +0) | 4 | 36% (4 of 11) |
| Opponent | Vampire Counts | 21 | 6 (net +274) | 1 (net -40) | 3 (net -312) | 3 (net -77) | 3 (net +219) | 4 (net +92) | 1 | 15% (3 of 20) |
| Opponent | Warriors of Chaos | 36 | 3 (net +0) | 0 | 6 (net +218) | 8 (net +152) | 2 (net +68) | 11 (net +310) | 6 | 20% (6 of 30) |
| Opponent | Wood Elf Realms | 27 | 2 (net +78) | 0 | 2 (net -52) | 4 (net +264) | 0 | 3 (net +90) | 16 | 18% (2 of 11) |

### Charged fights, damage counted: dep-mine-13df7bd-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 185 | 259 | +120 | 157 | 12 | +144 | +78.0 |
| Mine | 50-54% | 4 | 188 | 172 | +69 | 73 | 2 | +71 | +37.9 |
| Mine | Effective (55-75%) | 18 | 366 | 226 | +47 | 152 | 87 | +65 | +17.6 |
| Mine | 76-89% | 15 | 236 | 153 | +79 | 127 | 20 | +107 | +45.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 255 | 161 | +115 | 145 | 24 | +121 | +47.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 459 | 86 | +159 | 159 | 0 | +159 | +34.7 |
| Mine | No odds | 14 | 369 | 158 | +40 | 100 | 55 | +46 | +12.4 |
| Mine | All fights | 89 | 297 | 177 | +85 | 135 | 37 | +98 | +33.0 |
| Opponent | Long shot (under 50%) | 17 | 265 | 293 | +175 | 246 | 46 | +200 | +75.5 |
| Opponent | 50-54% | 4 | 207 | 167 | +244 | 263 | 67 | +196 | +94.6 |
| Opponent | Effective (55-75%) | 20 | 273 | 278 | +74 | 169 | 79 | +90 | +33.1 |
| Opponent | 76-89% | 21 | 362 | 219 | +113 | 162 | 61 | +101 | +28.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 374 | 222 | +202 | 242 | 34 | +208 | +55.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 360 | 82 | +143 | 160 | 9 | +151 | +41.9 |
| Opponent | No odds | 33 | 140 | 195 | +19 | 84 | 55 | +29 | +20.5 |
| Opponent | All fights | 123 | 272 | 224 | +112 | 171 | 53 | +118 | +43.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p3 | move | 476 | 82 (17%) | 64 (13%) | 51 (11%) | 343 (72%) |
| dep-mine-13df7bd-p3 | objective | 381 | 62 (16%) | 47 (12%) | 38 (10%) | 281 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: dep-mine-13df7bd-p1

### Scorecard: dep-mine-13df7bd-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 4 | 3 | 0 | 0 | 1 | 0 | 0 | 142 |
| L0102 | 6 | 1 | Opponent | no | 1 | 1 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 2 | 5 | 1 | 4 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 7 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 5 | 0 | 5 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 200 |
| L0235 | 1 | 1 | Opponent | no | 14 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | - | 0 | 0 | 1 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 3 | 0 | 0 | 0 | 55 |
| L0405 | 3 | 1 | Mine | no | 5 | 2 | 3 | 3 | 2 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 666 |
| L0421 | 1 | 1 | Mine | no | 7 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 1 | 0 | 1 | 0 | 0 | 675 |
| L0612 | 6 | 1 | Opponent | no | 6 | 4 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 5 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 10 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 295 |
| L0717 | 3 | 1 | Opponent | no | 6 | - | 1 | 2 | 1 | 0 | 0 | 350 |
| L0733 | 1 | 1 | Mine | no | 9 | 6 | 1 | 0 | 2 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 13 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 3 | 0 | 0 | 245 |
| L0913 | 1 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 789 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 145 |
| L1114 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 859 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 2 | 0 | 0 | 0 | 0 | 480 |
| L1131 | 3 | 1 | Opponent | no | 2 | 6 | 1 | 2 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 524 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | no | 1 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | yes | 1 | - | 3 | 0 | 2 | 0 | 0 | 651 |
| L1527 | 3 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 12 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | no | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 7 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 251 |
| L2025 | 3 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 9 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 2 | 0 | 0 | 144 |
| L2231 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 3 | 0 | 0 | 314 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 2 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 5 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 2.7 | 2.5 | 2.3 | 1.2 | 0.4 | 0.0 | 0.0 | 285.7 |
| **Average** | | | Opponent | 21% | 3.6 | 2.8 | 2.7 | 1.8 | 0.4 | 0.0 | 0.0 | 134.7 |

### KPIs: dep-mine-13df7bd-p1

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 176) | 3% (6 of 180) | 15% (54 of 356) |
| Winner chose to follow up after the loser gave ground |  | 100% (52 of 52); on the table 100% | 100% (72 of 72); on the table 100% | 100% (124 of 124); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 60% (3 of 5); on the table 60% | 94% (17 of 18); on the table 94% | 87% (20 of 23); on the table 87% |
| Winner chose to pursue after the loser fled |  | 74% (17 of 23); on the table 78% | 81% (25 of 31); on the table 87% | 78% (42 of 54); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 90% (72 of 80); on the table 91% | 94% (114 of 121); on the table 96% | 93% (186 of 201); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 28% (91 of 330) | 31% (66 of 210) | 29% (157 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (91 of 234) | 42% (60 of 144) | 40% (151 of 378) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 69% (22 of 32) | 63% (40 of 63) | 65% (62 of 95) |
| Points that never fought | lower | 43% (30813 of 71484) | 44% (31523 of 71889) | 43% (62336 of 143373) |
|   infantry points that never fought | lower | 53% (8960 of 16863) | 66% (8800 of 13348) | 59% (17760 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (160 of 279) | 60% (177 of 295) | 59% (337 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.8 uses a game | 75% (15 of 20); 1.3 uses a game | 86% (36 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.3 uses a game | 50% (4 of 8); 0.2 uses a game | 46% (11 of 24); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 58% (7 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31784 of 59666) | 55% (34682 of 62699) | 54% (66466 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (33%) | 1.6 (39%) | 3.7 (35%) |
| MARCHED: its unit marched | 1.1 (17%) | 0.5 (12%) | 1.6 (15%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.1 (2%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.4 (21%) | 0.5 (13%) | 1.9 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.8 (12%) | 0.7 (18%) | 1.5 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.4 (10%) | 0.8 (7%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.1 | 1.1 | 4.4 | 0.6 | 1.5 |
| not cast | 4.1 | 3.2 | 3.6 | 10.6 | 1.8 | 22.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (51%) | 0.3 (8%) | 3.7 (35%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (15%) | 0.2 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (7%) | 0.4 (12%) | 1.9 (18%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.3 (10%) | 0.4 (12%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (5%) | 0.2 (5%) | 0.2 (2%) | 0.2 (9%) | 0.6 (3%) |
| GONE: slain | 1.1 (26%) | 0.4 (14%) | 0.7 (20%) | 1.5 (14%) | 0.1 (5%) | 2.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (3%) | 0.2 (7%) | 0.8 (7%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.6 (33%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (54%) | 0.2 (5%) | 1.1 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.5 a game | 0.6 a game |
| stood (cast and not dispelled) | 64% (16 of 25) | 79% (11 of 14) | 69% (27 of 39) |
| the unit moved after it | 62% (10 of 16) | 64% (7 of 11) | 63% (17 of 27) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 11) | 0% (0 of 27) |
| the enemy charged it first | 6% (1 of 16) | 9% (1 of 11) | 7% (2 of 27) |
| it fought by the end of its next turn | 19% (3 of 16) | 9% (1 of 11) | 15% (4 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (4 of 16) | 0% (0 of 11) | 15% (4 of 27) |
| none of these (no charge, no fight, no charge escaped) | 56% (9 of 16) | 91% (10 of 11) | 70% (19 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (552 of 919) | 61% (384 of 629) | 60% (936 of 1548) |
|   cavalry | 48% (41 of 86) | 65% (95 of 147) | 58% (136 of 233) |
|   character | 44% (41 of 93) | 33% (37 of 113) | 38% (78 of 206) |
|   chariot | 52% (42 of 81) | 66% (27 of 41) | 57% (69 of 122) |
|   infantry | 58% (186 of 321) | 67% (167 of 249) | 62% (353 of 570) |
|   monster | 52% (24 of 46) | 62% (13 of 21) | 55% (37 of 67) |
|   war machine | 75% (218 of 292) | 78% (45 of 58) | 75% (263 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (29%) | 1.8 (26%) | 4.8 (28%) |
| CHARGED: it charged | 0.9 (9%) | 1.3 (20%) | 2.3 (13%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.2 (2%) | 0.8 (4%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.7 (17%) | 1.0 (15%) | 2.7 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.7 (11%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (23%) | 1.1 (17%) | 3.5 (21%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.4 (6%) | 0.6 (3%) |
| OTHER BAR | 0.3 (3%) | 0.2 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.0 | 88% | 4.7 pts | 25 pts |
| character | 2.5 | 0.6 | 79% | 8.1 pts | 20 pts |
| chariot | 1.9 | 1.2 | 67% | 13.2 pts | 26 pts |
| infantry | 14.0 | 5.2 | 76% | 10.1 pts | 142 pts |
| monster | 1.1 | 0.2 | 82% | 4.4 pts | 5 pts |
| war machine | 7.3 | 5.1 | 64% | 24.5 pts | 179 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.5 | 4.9 | 4.2 |
| Charges that made contact a game | 2.7 | 3.4 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.67 contact (21 units) | 0.31 declared, 0.12 contact (16 units) | 0.59 declared, 0.43 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.43 contact (7 units) | 1.00 declared, 0.86 contact (7 units) | 0.79 declared, 0.64 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.32 contact (254 units) | 0.59 declared, 0.42 contact (276 units) | 0.51 declared, 0.37 contact (530 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (31 of 70) | 48% (10 of 21) | 50% (4 of 8) | 45% (45 of 99) |
| Character in a unit | 90% (38 of 42) | 73% (19 of 26) | 75% (3 of 4) | 83% (60 of 72) |
| Character on its own | 73% (33 of 45) | 59% (20 of 34) | 32% (20 of 62) | 52% (73 of 141) |
| Chariot | 69% (11 of 16) | 70% (7 of 10) | - | 69% (18 of 26) |
| Infantry | 61% (54 of 89) | 47% (17 of 36) | 0% (0 of 2) | 56% (71 of 127) |
| Monster | 56% (18 of 32) | 50% (5 of 10) | - | 55% (23 of 42) |
| Monstrous | 73% (8 of 11) | 64% (9 of 14) | - | 68% (17 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 87% (13 of 15); on the table 87% | 31% (43 of 138) | 52% | 64% (21 of 33) | 100% (9 of 9); 4.3 uses a game | 67% (2 of 3); 0.8 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (3 of 3); on the table 100% | 21% (5 of 24) | 40% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 83% (5 of 6); on the table 100% | - | 70% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 82% (9 of 11); on the table 82% | 31% (11 of 36) | 55% | 59% (38 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (13 of 13); on the table 100% | 29% (31 of 108) | 42% | 48% (21 of 44) | 92% (11 of 12); 6.2 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 93% (27 of 29); on the table 97% | 20% (6 of 30) | 27% | 51% (25 of 49) | 80% (4 of 5); 2.2 uses a game | 44% (8 of 18); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 43% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (1 of 1); on the table 100% | - | 59% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 55% | 71% (15 of 21) | 100% (3 of 3); 3.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 25% (9 of 36) | 17% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 91% (10 of 11); on the table 100% | 13% (4 of 30) | 40% | 50% (17 of 34) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 95% (21 of 22); on the table 95% | 0% (0 of 12) | 36% | 30% (9 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (31 of 33); on the table 94% | 44% (24 of 54) | 41% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 93% (27 of 29); on the table 93% | 40% (12 of 30) | 37% | 68% (50 of 74) | 100% (4 of 4); 1.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 88% (15 of 17); on the table 88% | 40% (12 of 30) | 46% | 61% (40 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (40) | 42% (27) | 47% (67) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.42 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.08 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.28 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.22 | 3.17 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.92 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.44 | 5.86 | 12.31 |

### Quality by phase: dep-mine-13df7bd-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (61 of 115) | 52% (77 of 148) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (167 of 352) | 46% (96 of 209) |
| Strategy | Close-in objectives charged next turn | 9% (14 of 152) | 12% (27 of 220) |
| Strategy | Support requests answered (helper made contact too) | 50% (6 of 12) | 60% (9 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 2) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 29% (2 of 7) | 56% (5 of 9) |
| Strategy | Joined characters whose unit fought | 25% (16 of 63) | 35% (15 of 43) |
| Strategy | Lone characters that fought | 75% (62 of 83) | 75% (70 of 93) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 285.7 | 134.7 |
| Movement | Fights charged into per game | 2.5 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 79, net -54 | 12 of 97, net -10 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 79, net +57 | 10 of 97, net +148 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 79, net +81 | 8 of 97, net +44 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 79, net +112 | 27 of 97, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (177 of 365) | 45% (170 of 378) |
| Shooting | Points destroyed by shooting units | 83.3 | 60.4 |
| Shooting | War machine shots | 6.1 | 1.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (129 of 218) | 33% (15 of 45) |
| Shooting | Points destroyed by war machines | 67.5 | 23.4 |
| Magic | Magic missiles cast | 1.6 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 24% (14 of 58) | 41% (17 of 41) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.2 |
| Magic | Wounds caused by other spells | 1.4 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 63.7 | 27.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.2 / 0.6 / 0.2 | 1.6 / 0.3 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 344.2 | 378.5 |
| Combat | Points run down | 32.1 | 91.0 |
| Combat | Net points per charged fight, damage counted | +68 | +113 |
| Combat | Net per 100 charger points, damage counted | +25.8 | +45.4 |
| Combat | First round won (charged fights) | 67% | 80% |
| Combat | Net points per charged fight | +69 | +118 |
| Combat | Net points per supported fight / lone fight | -13 / +77 | +115 / +118 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 90 | 44 of 112 |
| Game | Points lost | 730.3 | 682.1 |
| Game | VP from objectives | 529.7 | 699.2 |
| Game | Lone holders (player turns) | 2.7 | 3.6 |

- Mine won / drew / lost: 10 / 8 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -245 VP
- The side that went first won 13 of 28 games with a winner
- Points traded per game (both sides' losses): 1412
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 7.1 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +6.3 | 0.0 | 37.6 | 1.2 | +9.5 | 0.0 | 69.6 |
| BEST FACING | 1.0 | +44.2 | 0.0 | 22.6 | 0.5 | +14.3 | 0.0 | 38.4 |
| BEST FIRST | 4.8 | +198.5 | 139.9 | 86.4 | 4.5 | +185.7 | 211.3 | 61.3 |
| BEST OVERALL | 1.0 | +92.0 | 0.0 | 20.6 | 0.6 | +36.7 | 0.0 | 21.9 |
| BEST PREY | 0.9 | +58.5 | 30.5 | 10.7 | 0.8 | +42.4 | 21.2 | 15.3 |
| BEST PRIZE | 0.1 | -5.1 | 5.3 | 10.4 | 0.1 | -3.4 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.3 | 0.0 | 22.4 | 0.1 | -0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 9.6 | 0.0 |
| BLOCKED WHEEL | 0.3 | +6.8 | 0.0 | 0.0 | 0.4 | +6.7 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -16.2 | 6.5 | 0.0 | 0.2 | -29.7 | 30.8 | 5.4 |
| BOMBING RUN | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 42.0 | 13.8 | 0.2 | +0.0 | 23.8 | 0.0 |
| CANNON PLANNED TARGET | 4.4 | +109.7 | 204.4 | 86.5 | 1.1 | +55.8 | 106.6 | 12.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | -1.5 | 0.0 | 3.5 |
| CARRIES OUT SET-UP | 0.1 | -7.2 | 7.4 | 9.6 | 0.1 | -5.8 | 17.8 | 0.0 |
| CAST JOB | 0.6 | +13.4 | 17.2 | 9.4 | 0.5 | +8.3 | 45.5 | 27.4 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +61.4 | 43.4 | 18.5 | 0.1 | +4.0 | 17.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 34.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.8 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 3.5 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.1 | +0.6 | 9.9 | 0.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 211.8 | 108.4 | 2.1 | +0.0 | 230.2 | 52.1 |
| CHARGE NOW WEIGHED | 0.5 | -32.3 | 6.1 | 25.3 | 0.5 | -47.3 | 20.6 | 40.4 |
| CHARGER SLAIN LOST | 0.3 | -4.3 | 5.1 | 7.9 | 0.4 | -12.8 | 25.3 | 23.3 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -1.2 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 2.3 | 2.7 |
| COMBAT PIVOT | 0.5 | +0.0 | 10.2 | 51.0 | 0.4 | +0.0 | 33.7 | 22.5 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 5.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +179.1 | 0.0 | 9.9 | 0.2 | +15.8 | 0.0 | 7.6 |
| COUNTER-CHARGE COVER | 9.7 | +1029.3 | 0.0 | 202.3 | 7.6 | +693.4 | 0.0 | 231.9 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 3.5 |
| DEPLOY BY FIGURES | 8.1 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.6 | 4.4 | 0.0 | 0.2 | +5.3 | 33.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +159.1 | 0.0 | 50.1 | 1.2 | +106.7 | 0.0 | 60.8 |
| FALLBACK BY WORTH | 5.1 | +98.0 | 0.0 | 86.9 | 5.6 | +39.6 | 0.0 | 66.6 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.5 | +0.0 | 0.0 | 159.8 | 5.7 | +0.0 | 0.0 | 162.9 |
| FOCUS FIRE | 0.0 | +0.8 | 3.2 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +130.4 | 0.0 | 27.1 | 1.2 | +161.3 | 0.0 | 9.4 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.6 | 0.0 | 0.0 | 0.2 | +2.3 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.1 | 13.1 | 0.0 | 0.1 | -1.0 | 14.7 | 6.7 |
| GIVES UP ITS SCREEN | 0.1 | -0.1 | 4.0 | 2.8 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 16.0 | 0.2 | +0.0 | 0.0 | 5.4 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -16.5 | 0.0 | 0.0 |
| HOLDER AT DEPLOYMENT | 1.1 | +198.8 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -130.0 | 344.3 | 226.3 | 9.1 | -173.8 | 492.3 | 204.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +2.5 | 3.5 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.4 | +16.0 | 0.0 | 11.2 | 0.6 | +24.5 | 0.0 | 18.2 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT THE GUNS | 0.0 | +6.2 | 0.0 | 0.0 | 0.1 | +16.0 | 3.5 | 0.0 |
| INVITES THE FIGHT | 1.7 | +35.9 | 44.2 | 72.4 | 1.5 | +19.5 | 52.8 | 37.0 |
| JOINT CHARGE PLAN | 0.1 | +5.6 | 0.0 | 0.0 | 0.2 | +27.4 | 13.6 | 5.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.0 | -0.2 | 4.8 | 0.0 |
| KEEP FALLS | 0.0 | +0.1 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.5 | 3.2 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +47.5 | 127.5 | 43.9 | 1.6 | +46.7 | 120.1 | 17.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +71.2 | 101.1 | 46.3 | 1.8 | +85.0 | 102.9 | 72.0 |
| KILLS COUNT NEXT TURN | 4.8 | +128.6 | 141.4 | 94.2 | 7.3 | +223.9 | 260.9 | 168.3 |
| LANE BY FIGURES | 0.8 | +26.1 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +7.7 | 4.2 | 0.0 | 0.5 | +20.2 | 13.7 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 12.4 | 6.5 |
| LONE WIZARD KEPT IN | 0.7 | +49.0 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -3.6 | 25.6 | 21.6 | 0.6 | +2.6 | 37.4 | 4.3 |
| LOST CHARGE | 2.1 | -27.7 | 63.4 | 113.6 | 2.8 | -38.1 | 102.2 | 43.6 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -2.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +74.2 | 2.1 | 62.6 | 1.0 | +100.1 | 77.8 | 12.7 |
| MANOEUVRE | 0.2 | +8.2 | 0.0 | 0.0 | 0.3 | +11.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +23.6 | 0.0 | 10.6 | 0.4 | +8.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +16.7 | 7.4 | 12.1 | 0.2 | +15.4 | 9.1 | 0.0 |
| MARCH OVER CASTS | 0.7 | +41.0 | 0.0 | 20.8 | 0.4 | +17.4 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 4.5 | +168.1 | 0.0 | 103.1 | 5.2 | +199.2 | 0.0 | 187.4 |
| MISSILES IN THE MOVE | 3.6 | +143.5 | 0.0 | 90.1 | 3.4 | +54.2 | 0.0 | 99.9 |
| MISSILES NEXT TURN | 4.4 | +99.5 | 0.0 | 117.4 | 4.3 | +38.0 | 0.0 | 111.7 |
| MODEL FACING | 0.3 | +137.9 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 16.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +7.7 | 0.0 | 4.7 | 0.2 | +9.4 | 0.0 | 12.4 |
| MOVE SPELL IN RANGE | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -18.6 | 3.6 | 45.7 | 0.1 | -1.5 | 3.5 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 26.9 |
| MOVE TO CHARGE | 2.5 | +206.8 | 50.4 | 95.0 | 4.3 | +272.2 | 188.2 | 62.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +0.5 | 6.5 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.1 | 0.0 | 2.1 | 0.0 | +0.7 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -15.2 | 21.2 | 18.2 | 0.2 | -8.6 | 19.5 | 0.0 |
| NOT TURNED | 6.4 | +93.3 | 0.0 | 141.4 | 5.9 | +67.4 | 0.0 | 133.4 |
| NOT WORTH A CAST | 0.9 | -3.1 | 0.0 | 36.0 | 0.3 | -0.3 | 0.0 | 15.0 |
| OFF BEST | 15.9 | -861.2 | 0.0 | 299.1 | 16.4 | -893.5 | 2.3 | 349.3 |
| OPENS A LANE | 0.2 | +0.6 | 31.2 | 0.0 | 0.0 | +0.1 | 1.5 | 0.0 |
| OPENS UP | 0.1 | +15.3 | 7.1 | 12.1 | 0.2 | +11.3 | 8.8 | 0.0 |
| OVERRUN THREAT | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +31.2 | 67.8 | 20.4 | 0.3 | +5.4 | 13.3 | 1.9 |
| PATHS CROSS | 2.1 | +139.3 | 0.0 | 45.1 | 2.4 | +185.8 | 0.0 | 76.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.0 | 0.0 | 4.9 | 0.1 | -0.7 | 0.0 | 0.0 |
| PLAN RESULT | 36.9 | +1263.5 | 1150.1 | 985.8 | 38.5 | +1303.5 | 1333.8 | 810.8 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -9.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +12.5 | 0.0 | 12.8 | 1.8 | +30.7 | 0.0 | 51.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.4 | 8.3 | 4.7 | 0.4 | -17.1 | 11.9 | 14.2 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.2 | 0.0 | 4.2 | 0.5 | -4.0 | 0.0 | 8.9 |
| REDIRECT COUNTER | 2.4 | +188.6 | 0.0 | 39.0 | 3.7 | +282.5 | 0.0 | 52.0 |
| REDIRECT WEIGHED | 0.2 | -2.3 | 6.0 | 23.2 | 0.4 | +9.9 | 13.9 | 16.1 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 9.6 | 0.3 | +0.0 | 0.0 | 15.2 |
| RESERVE FALL BACK | 0.3 | +7.3 | 0.0 | 3.7 | 0.6 | +34.5 | 0.0 | 13.0 |
| RESTRAINS TO SHOOT | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +5.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +108.0 | 211.0 | 98.4 | 2.4 | +77.0 | 158.6 | 65.1 |
| SAFER THAN THE JOB | 0.9 | +66.4 | 0.0 | 12.6 | 0.9 | +59.8 | 0.0 | 44.3 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 5.1 | 0.3 | +0.7 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 5.1 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -15.6 | 0.0 | 0.0 | 0.2 | -4.1 | 0.0 | 6.1 |
| SEARCH SPOT | 2.8 | +117.8 | 0.0 | 51.4 | 2.7 | +127.1 | 0.0 | 22.1 |
| SELF MOVE SPELL | 0.2 | +12.4 | 0.0 | 29.1 | 0.3 | +10.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +100.1 | 2.1 | 83.5 | 2.0 | +202.6 | 88.1 | 27.7 |
| SET-UP ANY TARGET | 0.2 | +16.8 | 0.0 | 0.0 | 0.1 | +8.8 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +2.0 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +1.0 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +59.8 | 74.9 | 9.5 | 0.8 | +17.4 | 30.9 | 10.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 133.0 | 19.7 | 0.2 | +0.0 | 41.4 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +552.6 | 0.0 | 233.4 | 9.3 | +329.4 | 0.0 | 93.3 |
| SPELL SETS UP CHARGE | 0.3 | +116.9 | 0.0 | 0.0 | 0.1 | +14.8 | 0.0 | 7.6 |
| SPELL WORTH | 0.7 | +12.6 | 56.7 | 56.7 | 1.8 | +38.5 | 54.7 | 61.7 |
| SPELLS IN THE FIGHT | 0.6 | -0.5 | 60.3 | 38.0 | 0.4 | -5.5 | 55.7 | 17.3 |
| STABLE ROLE | 10.6 | +0.0 | 406.9 | 206.8 | 11.3 | +0.0 | 331.9 | 150.2 |
| STAY WEIGHED | 0.1 | +6.9 | 0.0 | 18.5 | 0.0 | +0.3 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +17.6 | 0.0 | 12.9 | 0.4 | +16.2 | 0.0 | 15.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 1.7 |
| SUPPORT NARROWED | 5.5 | -46.2 | 230.8 | 104.3 | 6.0 | -40.3 | 384.6 | 124.8 |
| SUPPORTS | 3.9 | +48.1 | 137.6 | 41.0 | 3.7 | +40.4 | 149.5 | 58.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.8 | 10.5 | 11.0 | 0.3 | -6.3 | 19.5 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -0.7 | 6.0 | 24.2 | 0.9 | -14.3 | 43.5 | 7.3 |
| THROUGH LINE OF FIRE | 0.4 | +15.6 | 0.0 | 10.6 | 0.2 | +10.3 | 0.0 | 5.1 |
| TURN WORTH | 0.3 | -19.4 | 19.0 | 1.4 | 0.2 | -12.6 | 14.6 | 3.2 |
| TWO OR MORE ARRIVE | 0.3 | +4.5 | 2.1 | 4.6 | 0.5 | +4.0 | 59.8 | 12.7 |
| WAIT AFTER COSTS | 6.4 | -319.7 | 202.5 | 223.4 | 7.6 | -384.2 | 318.7 | 177.9 |
| WALKS TO THE FIGHT | 1.5 | +31.2 | 52.5 | 53.2 | 0.9 | +23.4 | 42.9 | 24.3 |
| WAR ENGINE CHARGES | 0.1 | +5.9 | 1.7 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 40.0 | 14.3 | 0.2 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 1.0 | +40.7 | 96.3 | 27.6 | 1.2 | +29.5 | 113.8 | 14.4 |
| WHO HITS BACK | 0.3 | +17.6 | 0.0 | 25.3 | 0.2 | +18.6 | 0.0 | 3.5 |
| WHOLE FIGHT | 0.2 | +5.4 | 34.0 | 1.2 | 0.3 | +10.6 | 37.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +27.0 | 5.4 | 11.6 | 0.2 | +17.2 | 14.8 | 0.0 |
| WIDER SPREAD | 2.2 | -8.3 | 173.5 | 62.0 | 3.1 | -6.4 | 253.8 | 78.2 |

### Rule changes: dep-mine-13df7bd-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1161 | 1161 | 1161 | 32.25 | -63169 | -54.4 |
| BEST FIRST | 333 | 333 | 333 | 9.25 | +13833 | +41.5 |
| SEARCH SPOT | 197 | 197 | 195 | 5.42 | +8817 | +45.2 |
| DEPLOY BY FIGURES | 290 | 290 | 184 | 5.11 | +2016 | +11.0 |
| COUNTER-CHARGE COVER | 621 | 340 | 178 | 4.94 | +12875 | +72.3 |
| PATHS CROSS | 163 | 163 | 163 | 4.53 | +11702 | +71.8 |
| MOVE TO CHARGE | 244 | 244 | 137 | 3.81 | +5815 | +42.4 |
| KILLS COUNT NEXT TURN | 433 | 433 | 129 | 3.58 | +2849 | +22.1 |
| FACES THE THREAT | 114 | 114 | 114 | 3.17 | +9570 | +83.9 |
| SUPPORTS | 274 | 274 | 95 | 2.64 | +919 | +9.7 |
| FOLLOW UP WEIGHED | 80 | 80 | 80 | 2.22 | +10501 | +131.3 |
| FALLBACK BY WORTH | 385 | 385 | 76 | 2.11 | +4954 | +65.2 |
| SHOTS IN THE MOVE | 851 | 552 | 74 | 2.06 | +3249 | +43.9 |
| WAIT AFTER COSTS | 501 | 501 | 65 | 1.81 | +1026 | +15.8 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +4541 | +71.0 |
| RANDOM MOVE BY FIGURES | 95 | 95 | 62 | 1.72 | +1554 | +25.1 |
| ADVANCE LANE KEPT | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| CANNON SIGHT KEPT | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| BEST OVERALL | 58 | 58 | 58 | 1.61 | +4633 | +79.9 |
| REDIRECT COUNTER | 220 | 124 | 57 | 1.58 | +4505 | +79.0 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| BEST FACING | 52 | 52 | 52 | 1.44 | +2104 | +40.5 |
| CANNON PLANNED TARGET | 199 | 199 | 47 | 1.31 | -1751 | -37.3 |
| MAX FOR POSITIONING | 350 | 196 | 46 | 1.28 | +468 | +10.2 |
| WALKS TO THE FIGHT | 87 | 87 | 46 | 1.28 | +867 | +18.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SET UP TOGETHER | 116 | 97 | 43 | 1.19 | +3732 | +86.8 |
| RISK BY ARC | 170 | 164 | 40 | 1.11 | +1598 | +39.9 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2771 | +79.2 |
| MARCH CHECK | 38 | 35 | 35 | 0.97 | +1783 | +50.9 |
| MISSILES IN THE MOVE | 255 | 149 | 35 | 0.97 | +988 | +28.2 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2643 | +77.7 |
| RESERVE FALL BACK | 33 | 33 | 33 | 0.92 | +1505 | +45.6 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| KILLS COUNT | 112 | 109 | 29 | 0.81 | +1345 | +46.4 |
| SHOOTS FROM THE BEST SPOT | 62 | 62 | 29 | 0.81 | +1286 | +44.4 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +485 | +18.0 |
| LANE BY FIGURES | 27 | 27 | 27 | 0.75 | +939 | +34.8 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 26 | 26 | 26 | 0.72 | +1217 | +46.8 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +62 | +2.5 |
| BEST PREY | 60 | 60 | 24 | 0.67 | +1000 | +41.7 |
| CHARGE NOW FIRST | 162 | 162 | 24 | 0.67 | -2801 | -116.7 |
| INVITES THE FIGHT | 113 | 113 | 24 | 0.67 | +364 | +15.2 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +934 | +40.6 |
| HOLDER AT DEPLOYMENT | 41 | 41 | 22 | 0.61 | +879 | +40.0 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +998 | +45.4 |
| HONEST WORTH | 581 | 578 | 21 | 0.58 | +128 | +6.1 |
| WHO HITS BACK | 21 | 21 | 21 | 0.58 | +812 | +38.6 |
| KEEPS ITS TARGET | 113 | 111 | 20 | 0.56 | +346 | +17.3 |
| MAKE SURE TOGETHER | 67 | 42 | 19 | 0.53 | +1184 | +62.3 |
| MANOEUVRE | 19 | 19 | 17 | 0.47 | +701 | +41.2 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +617 | +36.3 |
| CASTING BLOCK | 26 | 26 | 16 | 0.44 | +919 | +57.5 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +305 | +19.1 |
| CAST JOB | 39 | 39 | 15 | 0.42 | +222 | +14.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -9 | -0.7 |
| SURE CHARGE BEATS ADVANCE | 14 | 14 | 14 | 0.39 | -291 | -20.8 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -16 | -1.3 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +4963 | +413.6 |
| WEARS DOWN | 79 | 76 | 12 | 0.33 | +353 | +29.4 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +287 | +26.1 |
| WHOLE FIGHT GAIN | 18 | 16 | 11 | 0.31 | +722 | +65.7 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| HUNT IN PAIRS | 36 | 19 | 9 | 0.25 | +423 | +47.0 |
| WAR ENGINE JOBS | 24 | 24 | 9 | 0.25 | -946 | -105.1 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -61 | -7.7 |
| REFUSING RETIRES | 24 | 24 | 8 | 0.22 | -2 | -0.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -368 | -61.3 |
| OPENS UP | 11 | 11 | 6 | 0.17 | +260 | +43.3 |
| SUPPORT NARROWED | 415 | 415 | 6 | 0.17 | -124 | -20.6 |
| SURE REACH TOGETHER | 54 | 47 | 6 | 0.17 | +112 | +18.8 |
| LOST CHARGE | 177 | 175 | 5 | 0.14 | +107 | +21.4 |
| MISSILES NEXT TURN | 315 | 174 | 5 | 0.14 | +85 | +17.0 |
| BACKUP TARGETS | 74 | 39 | 4 | 0.11 | +11 | +2.9 |
| JOINT CHARGE PLAN | 10 | 10 | 4 | 0.11 | +473 | +118.3 |
| LONG SHOT | 39 | 38 | 4 | 0.11 | +12 | +2.9 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +29 | +7.3 |
| OVERRUNS AWAY | 29 | 28 | 4 | 0.11 | +114 | +28.4 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +200 | +50.0 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +259 | +64.9 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| WHOLE FIGHT | 20 | 20 | 3 | 0.08 | +100 | +33.4 |
| WIDER SPREAD | 190 | 184 | 3 | 0.08 | +35 | +11.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +108 | +54.1 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -466 | -232.8 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -147 | -73.6 |
| EDGE GIVE GROUND | 9 | 9 | 2 | 0.06 | +34 | +17.2 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +76 | +38.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -349 | -174.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +41 | +20.4 |
| SPELLS IN THE FIGHT | 36 | 35 | 2 | 0.06 | +7 | +3.5 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -53 | -52.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -5 | -5.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +11.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +30 | +30.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +14.4 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +22 | +22.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +9 | +8.9 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 9 | 3 | 1 | 0.03 | +2 | +2.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +124 | +123.8 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| TWO OR MORE ARRIVE | 30 | 24 | 1 | 0.03 | +19 | +19.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 14 | 13 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 24 | 21 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 13 | 13 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 439 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 10 | 8 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 443 | 443 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2712 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 25 | 25 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 790 | 786 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.17 | 14.47 | 55.7 |
| TURN GATE | gate | 0.89 | 0.53 | 36.1 |
| FALLBACK | gate | 0.56 | 0.69 | 45.2 |
| CHARGE NOW FIRST | rule | 0.39 | 0.28 | 116.7 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.19 | 112.4 |
| PATHS CROSS | rule | 0.19 | 0.19 | 36.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.33 | 93.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.28 | 22.4 |
| WAR ENGINE JOBS | rule | 0.22 | 0.03 | 105.1 |
| AFTERMATH BAND | gate | 0.14 | 0.08 | 2.7 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 7.7 |
| BEST PRIZE | rule | 0.11 | 0.06 | 61.3 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 5.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 33.1 |
| SUPPORT NARROWED | rule | 0.08 | 0.06 | 24.8 |
| SUPPORT REQUEST | gate | 0.03 | 0.11 | 113.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 19.1 |
| CHAFF PASSED | rule | 0.03 | 0.08 | 2.2 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 5.7 |
| FIGHT ORDER BAND | gate | - | 0.08 | 1.3 |
| MARCH ODDS | rule | 0.03 | 0.06 | 32.8 |
| BLOCKED WHEEL | rule | 0.06 | - | 15.5 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 232.8 |
| CHARIOT NO STATIC JOB | rule | 0.03 | 0.03 | 73.6 |
| DEPLOY BY FIGURES | rule | 0.06 | - | 12.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 2.9 |
| PURSUES BIG PREY | rule | - | 0.06 | 174.3 |
| REDIRECT WEIGHED | rule | 0.06 | - | 89.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 3.5 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 52.9 |
| CATCH ODDS | rule | - | 0.03 | 5.1 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.0 |
| LONG SHOT | rule | - | 0.03 | 25.0 |
| MOVE AND CAST | rule | 0.03 | - | 91.6 |
| REFUSING RETIRES | rule | 0.03 | - | 0.8 |
| RULE SWITCHED OFF | gate | - | 0.03 | 22.1 |
| SAFER THAN THE JOB | rule | 0.03 | - | 10.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 31.4 |
| WHO HITS BACK | rule | 0.03 | - | 3.2 |

### Plans: dep-mine-13df7bd-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 17% | 461 | 326 | 71% |
| Mine | charge | 2.6 | 57% | 239 | 230 | 96% |
| Mine | close in | 4.2 | 25% | 213 | 125 | 59% |
| Mine | hold | 5.4 | 38% | 306 | 0 | 0% |
| Mine | join | 0.5 | 100% | 15 | 0 | 0% |
| Mine | shoot | 8.3 | 59% | 323 | 582 | 180% |
| Mine | support | 4.2 | 94% | 32 | 0 | 0% |
| Opponent | advance | 14.2 | 19% | 475 | 448 | 94% |
| Opponent | charge | 3.4 | 59% | 274 | 303 | 111% |
| Opponent | close in | 6.1 | 19% | 413 | 206 | 50% |
| Opponent | hold | 4.4 | 41% | 292 | 0 | 0% |
| Opponent | join | 1.2 | 98% | 70 | 0 | 0% |
| Opponent | shoot | 4.9 | 53% | 145 | 349 | 241% |
| Opponent | support | 4.2 | 87% | 32 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 224 | 0 | 0% | 21 |
| Opponent | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 288 | 0 | 0% | 74 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 252 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 120 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 235 | 0 | 0% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 17 |

### Battle groups: dep-mine-13df7bd-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.7 | 18% | 60% | 10% | 50% | 39% | 7% | 9% | 46% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 31% | 52% | 19% | 0% | 18% | 9% | 5% | 68% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 16% | 58% | 11% | 40% | 42% | 2% | 2% | 52% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 17% | 82% | 18% | 0% | 28% | 0% | 6% | 61% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 3.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Mine | Chaff | 37 | 44 (37) | 21 | 24 | 64 | 49% | 2.3 | 19 (14) | 89 (16) | 15 (7) | 34 (29) | 80 (8) |
| Mine | Character | 124 | 43 (124) | 43 | 0 | 41 | 19% | 2.5 | 47 (52) | 36 (39) | 67 (15) | 56 (57) | 35 (49) |
| Mine | Clean-up | 21 | 54 (21) | 25 | 29 | 31 | 24% | 3.3 | 47 (11) | 66 (9) | 0 (1) | 59 (12) | 49 (9) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 87 | 0% | 2.5 | 67 (1) | 0 (1) | 0 (2) | 0 (3) | 67 (1) |
| Mine | Fast Hammer | 40 | 43 (40) | 27 | 17 | 47 | 25% | 3.0 | 40 (15) | 67 (16) | 21 (9) | 38 (23) | 50 (17) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 20 | 0% | 2.6 | 35 (2) | 0 (3) | - | 35 (2) | 0 (3) |
| Mine | Hammer | 60 | 36 (60) | 23 | 12 | 41 | 23% | 2.6 | 16 (23) | 51 (30) | 37 (7) | 44 (41) | 19 (19) |
| Mine | Holder | 27 | 64 (27) | 10 | 54 | 33 | 26% | 3.7 | 94 (9) | 59 (16) | 0 (2) | 79 (14) | 47 (13) |
| Mine | Shooter | 44 | 123 (44) | 45 | 78 | 26 | 2% | 1.7 | 55 (13) | 139 (25) | 246 (6) | 124 (30) | 122 (14) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 80% | 4.0 | 0 (2) | - | - | 0 (2) | - |
| Mine | War machine | 56 | 41 (56) | 41 | 0 | 39 | 7% | 1.3 | 32 (27) | 45 (21) | 62 (8) | 16 (9) | 46 (47) |
| Mine | Wizard | 22 | 24 (22) | 24 | 0 | 27 | 18% | 2.5 | 41 (11) | 0 (5) | 0 (2) | 10 (7) | 34 (11) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 69 | 54 (69) | 12 | 42 | 42 | 45% | 2.7 | 54 (27) | 39 (15) | 62 (27) | 74 (49) | 13 (20) |
| Opponent | Character | 114 | 56 (114) | 56 | 0 | 34 | 23% | 2.5 | 73 (33) | 50 (59) | 40 (6) | 52 (60) | 67 (38) |
| Opponent | Clean-up | 16 | 57 (16) | 48 | 8 | 40 | 25% | 2.4 | 75 (6) | 52 (9) | 0 (1) | 72 (13) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 57 | 58 (57) | 43 | 15 | 51 | 25% | 2.7 | 69 (19) | 48 (27) | 62 (11) | 52 (41) | 71 (16) |
| Opponent | Fragile | 10 | 30 (10) | 30 | 0 | 43 | 20% | 1.9 | 0 (4) | 0 (3) | 95 (3) | 38 (8) | 0 (2) |
| Opponent | Hammer | 64 | 31 (64) | 21 | 10 | 36 | 33% | 2.5 | 72 (11) | 28 (43) | 8 (10) | 31 (43) | 32 (21) |
| Opponent | Holder | 40 | 73 (40) | 9 | 63 | 20 | 45% | 3.6 | 73 (8) | 100 (19) | 35 (11) | 105 (19) | 48 (19) |
| Opponent | Shooter | 29 | 66 (29) | 27 | 39 | 28 | 3% | 1.4 | 33 (5) | 77 (19) | 49 (5) | 94 (15) | 35 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 52 (13) | 52 | 0 | 43 | 23% | 1.1 | 62 (3) | 67 (7) | 0 (3) | 0 (2) | 60 (11) |
| Opponent | Wizard | 22 | 3 (22) | 3 | 0 | 31 | 9% | 1.9 | 7 (8) | 0 (4) | 0 (5) | 2 (7) | 5 (10) |

### Charged fights: dep-mine-13df7bd-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 230 | 78 | 1.0 | 1.2 | 78 | 27 | +51 | 0 of 5 | 3 of 5 | +44 | +53 |
| Mine | Chaos Dwarfs | 3 | 260 | 303 | 1.7 | 1.0 | 182 | 116 | +66 | 3 of 5 | 2 of 5 | - | +66 |
| Mine | Dwarfen Mountain Holds | 4 | 284 | 25 | 1.0 | 1.0 | 25 | 24 | +2 | 0 of 4 | 1 of 4 | - | +2 |
| Mine | Empire of Man | 5 | 335 | 101 | 1.8 | 1.1 | 56 | 0 | +56 | 1 of 9 | 6 of 9 | +83 | +53 |
| Mine | Grand Cathay | 4 | 455 | 321 | 2.5 | 1.1 | 128 | 64 | +64 | 5 of 10 | 8 of 10 | -294 | +104 |
| Mine | High Elf Realms | 4 | 104 | 538 | 3.8 | 1.1 | 144 | 53 | +91 | 7 of 15 | 12 of 15 | +25 | +101 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1026 | 5.0 | 1.0 | 205 | 0 | +205 | 3 of 5 | 4 of 5 | - | +205 |
| Mine | Lizardmen | 1 | 0 | 261 | 2.0 | 1.5 | 130 | 92 | +38 | 1 of 2 | 2 of 2 | +10 | +66 |
| Mine | Ogre Kingdoms | 1 | 195 | 0 | 2.0 | 1.0 | 0 | 45 | -45 | 2 of 2 | 0 of 2 | - | -45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 590 | 6.0 | 1.0 | 98 | 90 | +9 | 3 of 6 | 4 of 6 | - | +9 |
| Mine | Skaven | 2 | 60 | 170 | 2.0 | 1.0 | 85 | 63 | +22 | 0 of 4 | 3 of 4 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 216 | 854 | 3.5 | 1.0 | 244 | 89 | +155 | 2 of 7 | 6 of 7 | - | +155 |
| Mine | Vampire Counts | 2 | 0 | 574 | 6.5 | 1.2 | 88 | 58 | +30 | 7 of 13 | 7 of 13 | +0 | +36 |
| Mine | Warriors of Chaos | 1 | 0 | 469 | 3.0 | 1.0 | 156 | 0 | +156 | 1 of 3 | 2 of 3 | - | +156 |
| **Mine** | all armies | 36 | 215 | 302 | 2.5 | 1.1 | 121 | 52 | +69 | 35 of 90 | 60 of 90 | -13 | +77 |
| Opponent | Beastmen Brayherds | 1 | 0 | 497 | 5.0 | 1.4 | 99 | 27 | +72 | 2 of 5 | 4 of 5 | +109 | +47 |
| Opponent | Dwarfen Mountain Holds | 1 | 1067 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | +0 | +0 |
| Opponent | Empire of Man | 1 | 95 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 180 | 105 | 3.0 | 1.3 | 35 | 0 | +35 | 1 of 3 | 3 of 3 | +105 | +0 |
| Opponent | High Elf Realms | 2 | 145 | 1058 | 6.0 | 1.1 | 176 | 0 | +176 | 5 of 12 | 11 of 12 | +171 | +177 |
| Opponent | Lizardmen | 1 | 281 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 2 | 96 | 106 | 2.0 | 1.0 | 53 | 17 | +36 | 0 of 4 | 3 of 4 | - | +36 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1281 | 3.5 | 1.0 | 366 | 22 | +344 | 3 of 7 | 6 of 7 | - | +344 |
| Opponent | Skaven | 2 | 84 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 61 | 1088 | 4.8 | 1.2 | 229 | 63 | +166 | 10 of 19 | 14 of 19 | +250 | +156 |
| Opponent | Vampire Counts | 6 | 20 | 443 | 3.7 | 1.1 | 121 | 22 | +99 | 8 of 22 | 17 of 22 | +77 | +101 |
| Opponent | Warriors of Chaos | 7 | 37 | 215 | 1.7 | 1.0 | 126 | 14 | +112 | 5 of 12 | 11 of 12 | - | +112 |
| Opponent | Wood Elf Realms | 6 | 186 | 386 | 4.2 | 1.0 | 93 | 37 | +55 | 9 of 25 | 19 of 25 | +0 | +58 |
| **Opponent** | all armies | 36 | 111 | 454 | 3.1 | 1.1 | 146 | 28 | +118 | 44 of 112 | 90 of 112 | +115 | +118 |

### Effective charges: dep-mine-13df7bd-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +125) | 1 (net +0) | 0 | 1 (net +44) | 0 | 2 (net +44) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 5 | 2 (net -70) | 0 | 0 | 1 (net +0) | 0 | 2 (net +234) | 0 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net -48) | 0 | 1 (net +60) | 1 (net +41) | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 9 | 1 (net +0) | 1 (net +141) | 0 | 2 (net +92) | 2 (net +42) | 3 (net +33) | 0 | 0% (0 of 9) |
| Mine | Grand Cathay | 10 | 1 (net -294) | 0 | 2 (net -5) | 5 (net +77) | 0 | 1 (net +470) | 1 | 22% (2 of 9) |
| Mine | High Elf Realms | 15 | 2 (net +16) | 1 (net +446) | 2 (net +332) | 4 (net -74) | 0 | 4 (net +28) | 2 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 0 | 0 | 2 (net +364) | 1 (net +45) | 1 (net +254) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 0 | 1 (net +10) | 1 (net +66) | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 6 | 1 (net +325) | 1 (net +0) | 0 | 0 | 1 (net +265) | 0 | 3 | 0% (0 of 3) |
| Mine | Skaven | 4 | 0 | 0 | 1 (net -251) | 0 | 0 | 2 (net +170) | 1 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 1 (net -134) | 0 | 3 (net +182) | 0 | 1 (net +125) | 2 | 0% (0 of 5) |
| Mine | Vampire Counts | 13 | 3 (net -236) | 2 (net +409) | 2 (net +0) | 5 (net +57) | 0 | 1 (net +0) | 0 | 15% (2 of 13) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 2 (net +54) | 0 | 0 | 0 | 1 | 100% (2 of 2) |
| Opponent | Beastmen Brayherds | 5 | 1 (net -52) | 0 | 1 (net +65) | 2 (net +174) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +105) | 0 | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 12 | 1 (net +217) | 0 | 1 (net +0) | 3 (net +273) | 2 (net +86) | 4 (net +202) | 1 | 9% (1 of 11) |
| Opponent | Ogre Kingdoms | 4 | 0 | 0 | 0 | 2 (net +68) | 1 (net +77) | 0 | 1 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 2 (net +344) | 0 | 0 | 5 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 1 (net +160) | 2 (net -13) | 1 (net +102) | 10 (net +189) | 0 | 4 (net +190) | 1 | 6% (1 of 18) |
| Opponent | Vampire Counts | 22 | 4 (net -84) | 0 | 2 (net +102) | 7 (net +168) | 2 (net +0) | 7 (net +161) | 0 | 9% (2 of 22) |
| Opponent | Warriors of Chaos | 12 | 1 (net +0) | 0 | 0 | 4 (net +56) | 0 | 4 (net +80) | 3 | 0% (0 of 9) |
| Opponent | Wood Elf Realms | 25 | 3 (net -34) | 1 (net +373) | 4 (net +278) | 6 (net +25) | 2 (net +0) | 5 (net -43) | 4 | 19% (4 of 21) |

### Charged fights, damage counted: dep-mine-13df7bd-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 271 | 222 | -54 | 140 | 189 | -49 | -18.2 |
| Mine | 50-54% | 7 | 291 | 216 | +182 | 332 | 133 | +199 | +68.5 |
| Mine | Effective (55-75%) | 10 | 259 | 253 | +57 | 124 | 61 | +63 | +24.3 |
| Mine | 76-89% | 25 | 254 | 182 | +77 | 116 | 28 | +88 | +34.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 208 | 164 | +112 | 145 | 41 | +104 | +49.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 381 | 93 | +81 | 118 | 89 | +28 | +7.5 |
| Mine | No odds | 11 | 289 | 212 | +71 | 128 | 80 | +48 | +16.5 |
| Mine | All fights | 90 | 262 | 194 | +69 | 145 | 77 | +68 | +25.8 |
| Opponent | Long shot (under 50%) | 12 | 164 | 268 | -10 | 93 | 81 | +13 | +7.7 |
| Opponent | 50-54% | 3 | 457 | 378 | +116 | 259 | 144 | +116 | +25.3 |
| Opponent | Effective (55-75%) | 10 | 280 | 209 | +148 | 165 | 71 | +95 | +33.8 |
| Opponent | 76-89% | 37 | 244 | 155 | +147 | 163 | 20 | +143 | +58.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 244 | 195 | +104 | 159 | 57 | +102 | +41.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 349 | 85 | +44 | 71 | 15 | +56 | +16.0 |
| Opponent | No odds | 15 | 227 | 200 | +192 | 250 | 67 | +183 | +80.5 |
| Opponent | All fights | 112 | 250 | 188 | +118 | 162 | 49 | +113 | +45.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p1 | move | 446 | 88 (20%) | 61 (14%) | 47 (11%) | 311 (70%) |
| dep-mine-13df7bd-p1 | objective | 372 | 41 (11%) | 32 (9%) | 50 (13%) | 281 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: dep-mine-13df7bd-p2

### Scorecard: dep-mine-13df7bd-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 4 | 3 | 3 | 2 | 0 | 0 | 0 | 249 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 0 | 1 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 5 | 0 | 1 | 1 | 0 | 0 | 801 |
| L0222 | 6 | 1 | Mine | no | 5 | 3 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 5 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | yes | 6 | 2 | 2 | 1 | 1 | 0 | 0 | 295 |
| L0323 | 5 | 1 | Mine | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 2 | 1 | 1 | 0 | 0 | 136 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 4 | 4 | 0 | 0 | 0 | 0 | 0 | 681 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 1010 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 3 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 1 | 3 | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0528 | 6 | 1 | Opponent | no | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 111 |
| L0616 | 4 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 929 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | no | 2 | 3 | 0 | 5 | 0 | 0 | 0 | 410 |
| L0810 | 6 | 1 | Mine | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 12 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 21 | 2 | 0 | 1 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 628 |
| L0934 | 4 | 1 | Opponent | no | 8 | 2 | 3 | 6 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 2 | 4 | 2 | 0 | 2 | 0 | 0 | 492 |
| L1026 | 6 | 1 | Opponent | no | 9 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 0 | 0 | 0 | 275 |
| L1135 | 1 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 114 |
| L1228 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 462 |
| L1323 | 3 | 1 | Mine | no | 9 | 2 | 6 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 2 | 0 | 0 | 251 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | yes | 12 | 1 | 1 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 1 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 490 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 455 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 6 | 0 | 0 | 0 | 0 | 377 |
| L2131 | 1 | 1 | Mine | yes | 0 | - | 3 | 3 | 1 | 0 | 0 | 495 |
| L2131 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 5 | 1 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Opponent | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | no | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 109 |
| **Average** | | | Mine | 33% | 2.5 | 2.3 | 2.3 | 1.1 | 0.2 | 0.0 | 0.0 | 337.7 |
| **Average** | | | Opponent | 20% | 4.0 | 2.8 | 2.3 | 1.6 | 0.4 | 0.0 | 0.0 | 184.6 |

### KPIs: dep-mine-13df7bd-p2

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (49 of 178) | 10% (19 of 183) | 19% (68 of 361) |
| Winner chose to follow up after the loser gave ground |  | 99% (67 of 68); on the table 99% | 100% (52 of 52); on the table 100% | 99% (119 of 120); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 89% | 75% (12 of 16); on the table 75% | 76% (19 of 25); on the table 80% |
| Winner chose to pursue after the loser fled |  | 70% (16 of 23); on the table 70% | 80% (28 of 35); on the table 86% | 76% (44 of 58); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 90% (90 of 100); on the table 91% | 89% (92 of 103); on the table 91% | 90% (182 of 203); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 35% (121 of 342) | 42% (65 of 156) | 37% (186 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (121 of 262) | 56% (59 of 105) | 49% (180 of 367) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (13 of 21) | 57% (33 of 58) | 58% (46 of 79) |
| Points that never fought | lower | 36% (25451 of 71583) | 43% (31111 of 71989) | 39% (56562 of 143572) |
|   infantry points that never fought | lower | 50% (8156 of 16324) | 58% (8077 of 14029) | 53% (16233 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (165 of 284) | 64% (189 of 297) | 61% (354 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 78% (14 of 18); 1.2 uses a game | 84% (32 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.8 uses a game | 50% (1 of 2); 0.0 uses a game | 65% (13 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31631 of 60231) | 60% (38274 of 63281) | 57% (69905 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (29%) | 0.7 (26%) | 2.5 (29%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.3 (11%) | 1.6 (19%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.0 (1%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 1.4 (23%) | 0.3 (12%) | 1.7 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.6 (10%) | 0.6 (25%) | 1.3 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (9%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (9%) | 0.4 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.6 | 1.5 | 5.2 | 0.4 | 1.6 |
| not cast | 3.7 | 3.3 | 3.5 | 8.7 | 1.9 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.4 (42%) | 0.2 (7%) | 2.5 (29%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (19%) | 0.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (7%) | 0.4 (11%) | 1.7 (20%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (13%) | 0.4 (13%) | 0.4 (13%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.2 (5%) | 0.2 (5%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (15%) | 0.3 (9%) | 0.5 (14%) | 1.3 (15%) | 0.5 (28%) | 3.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.3 (9%) | 0.1 (4%) | 0.4 (4%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.4 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (59%) | 0.4 (11%) | 1.5 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.8 a game | 0.8 a game |
| stood (cast and not dispelled) | 69% (20 of 29) | 54% (15 of 28) | 61% (35 of 57) |
| the unit moved after it | 60% (12 of 20) | 80% (12 of 15) | 69% (24 of 35) |
| it charged on its next turn | 10% (2 of 20) | 7% (1 of 15) | 9% (3 of 35) |
| the enemy charged it first | 15% (3 of 20) | 0% (0 of 15) | 9% (3 of 35) |
| it fought by the end of its next turn | 5% (1 of 20) | 0% (0 of 15) | 3% (1 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (4 of 20) | 20% (3 of 15) | 20% (7 of 35) |
| none of these (no charge, no fight, no charge escaped) | 55% (11 of 20) | 80% (12 of 15) | 66% (23 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (581 of 871) | 57% (453 of 788) | 62% (1034 of 1659) |
|   cavalry | 58% (49 of 85) | 64% (109 of 169) | 62% (158 of 254) |
|   character | 59% (61 of 104) | 34% (37 of 108) | 46% (98 of 212) |
|   chariot | 55% (63 of 114) | 74% (35 of 47) | 61% (98 of 161) |
|   infantry | 62% (167 of 268) | 56% (161 of 289) | 59% (328 of 557) |
|   monster | 47% (16 of 34) | 58% (21 of 36) | 53% (37 of 70) |
|   war machine | 85% (225 of 266) | 65% (90 of 139) | 78% (315 of 405) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (24%) | 2.4 (26%) | 4.3 (25%) |
| CHARGED: it charged | 1.4 (18%) | 1.3 (14%) | 2.8 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.2 (16%) | 2.5 (27%) | 3.7 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (8%) | 0.4 (4%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 1.3 (14%) | 2.6 (15%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (2%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.5 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.7 | 81% | 4.5 pts | 31 pts |
| character | 2.8 | 0.8 | 80% | 6.4 pts | 18 pts |
| chariot | 2.8 | 1.7 | 63% | 12.0 pts | 33 pts |
| infantry | 13.0 | 5.2 | 72% | 9.6 pts | 125 pts |
| monster | 1.3 | 0.4 | 70% | 14.2 pts | 19 pts |
| war machine | 8.8 | 7.6 | 63% | 24.5 pts | 215 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 5.5 | 5.2 |
| Charges that made contact a game | 3.6 | 4.0 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.88 contact (24 units) | 0.17 declared, 0.17 contact (12 units) | 0.72 declared, 0.64 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (8 units) | 0.92 declared, 0.62 contact (13 units) | 0.95 declared, 0.67 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.42 contact (247 units) | 0.63 declared, 0.46 contact (290 units) | 0.62 declared, 0.44 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (40 of 73) | 56% (10 of 18) | 42% (5 of 12) | 53% (55 of 103) |
| Character in a unit | 94% (31 of 33) | 73% (11 of 15) | 33% (1 of 3) | 84% (43 of 51) |
| Character on its own | 79% (31 of 39) | 67% (26 of 39) | 35% (22 of 63) | 56% (79 of 141) |
| Chariot | 71% (12 of 17) | 54% (7 of 13) | - | 63% (19 of 30) |
| Infantry | 63% (59 of 94) | 50% (17 of 34) | 67% (2 of 3) | 60% (78 of 131) |
| Monster | 55% (16 of 29) | 67% (6 of 9) | - | 58% (22 of 38) |
| Monstrous | 36% (5 of 14) | 79% (11 of 14) | - | 57% (16 of 28) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (9 of 9); on the table 100% | 38% (39 of 102) | 55% | 59% (13 of 22) | 83% (5 of 6); 4.5 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (18 of 18); on the table 100% | 53% (19 of 36) | 34% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 33% (1 of 3); on the table 33% | - | 56% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 85% (11 of 13); on the table 85% | 38% (18 of 48) | 48% | 62% (47 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 100% (22 of 22); on the table 100% | 33% (45 of 138) | 51% | 61% (33 of 54) | 93% (13 of 14); 6.5 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 64% (7 of 11); on the table 73% | 17% (3 of 18) | 27% | 36% (12 of 33) | 100% (3 of 3); 2.2 uses a game | 57% (8 of 14); 5.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 80% (4 of 5); on the table 80% | - | 44% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (7 of 7); on the table 100% | - | 19% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 92% (12 of 13); on the table 92% | 0% (0 of 18) | 48% | 82% (23 of 28) | 100% (4 of 4); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 3% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 100% (2 of 2); on the table 100% | 44% (8 of 18) | 29% | 56% (14 of 25) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 100% (14 of 14); on the table 100% | - | 52% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 88% (37 of 42); on the table 90% | 36% (24 of 66) | 21% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 85% (28 of 33); on the table 88% | 67% (12 of 18) | 29% | 58% (42 of 73) | 50% (1 of 2); 0.4 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 86% (6 of 7); on the table 86% | 58% (14 of 24) | 42% | 68% (53 of 78) | 57% (4 of 7); 2.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (47) | 49% (36) | 51% (83) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.69 | 1.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.11 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.72 | 0.36 | 1.08 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.92 | 2.19 | 4.11 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.33 | 1.03 | 2.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 5.67 | 11.25 |

### Quality by phase: dep-mine-13df7bd-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 51% (74 of 146) | 49% (81 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (148 of 388) | 56% (138 of 248) |
| Strategy | Close-in objectives charged next turn | 14% (19 of 135) | 14% (27 of 198) |
| Strategy | Support requests answered (helper made contact too) | 54% (13 of 24) | 62% (21 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 47% (8 of 17) | 82% (9 of 11) |
| Strategy | Joined characters whose unit fought | 33% (16 of 48) | 36% (12 of 33) |
| Strategy | Lone characters that fought | 79% (77 of 97) | 71% (64 of 90) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 337.7 | 184.6 |
| Movement | Fights charged into per game | 3.1 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 94, net +151 | 16 of 109, net +2 |
| Movement | Charges with odds: sweet spot (55-75%) | 22 of 94, net +26 | 21 of 109, net +116 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 94, net +91 | 6 of 109, net +37 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 94, net +112 | 32 of 109, net +90 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 11.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (164 of 396) | 54% (215 of 401) |
| Shooting | Points destroyed by shooting units | 120.1 | 47.2 |
| Shooting | War machine shots | 6.2 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (132 of 225) | 50% (45 of 90) |
| Shooting | Points destroyed by war machines | 83.3 | 29.5 |
| Magic | Magic missiles cast | 2.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (23 of 74) | 44% (19 of 43) |
| Magic | Wounds caused by magic missiles | 5.0 | 1.4 |
| Magic | Wounds caused by other spells | 1.8 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 76.8 | 14.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.6 / 0.8 / 0.1 | 2.1 / 0.3 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 301.0 | 301.4 |
| Combat | Points run down | 94.9 | 142.9 |
| Combat | Net points per charged fight, damage counted | +81 | +88 |
| Combat | Net per 100 charger points, damage counted | +29.4 | +38.8 |
| Combat | First round won (charged fights) | 72% | 71% |
| Combat | Net points per charged fight | +83 | +81 |
| Combat | Net points per supported fight / lone fight | +196 / +63 | +93 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 37 of 113 | 48 of 122 |
| Game | Points lost | 705.3 | 792.9 |
| Game | VP from objectives | 602.8 | 521.9 |
| Game | Lone holders (player turns) | 2.5 | 4.0 |

- Mine won / drew / lost: 18 / 5 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +187 VP
- The side that went first won 16 of 31 games with a winner
- Points traded per game (both sides' losses): 1498
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +4.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.6 | 0.0 | 13.7 | 1.1 | +10.9 | 0.0 | 41.4 |
| BEST FACING | 0.8 | +30.2 | 0.0 | 40.6 | 1.2 | +54.9 | 0.0 | 56.5 |
| BEST FIRST | 4.8 | +211.4 | 223.8 | 74.7 | 4.9 | +212.7 | 176.8 | 101.5 |
| BEST OVERALL | 0.6 | +42.3 | 0.0 | 36.2 | 0.7 | +52.5 | 0.0 | 26.8 |
| BEST PREY | 1.0 | +56.3 | 13.3 | 24.2 | 0.9 | +59.8 | 15.0 | 53.2 |
| BEST PRIZE | 0.1 | -2.0 | 0.0 | 1.4 | 0.0 | +1.3 | 3.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.2 | 0.0 | 11.1 | 0.3 | -0.2 | 0.0 | 24.1 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 8.5 | 0.0 |
| BLOCKED WHEEL | 0.3 | +9.3 | 0.0 | 2.9 | 0.4 | +2.0 | 0.0 | 13.1 |
| BLOWS WHERE AIMED | 0.4 | -17.0 | 43.0 | 9.2 | 0.2 | -30.7 | 17.3 | 15.1 |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 157.4 | 12.4 | 0.2 | +0.0 | 12.6 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +148.9 | 410.2 | 113.5 | 1.9 | +76.6 | 127.3 | 10.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 4.6 | 0.6 | +0.0 | 0.0 | 13.4 |
| CARRIES OUT COUNTER | 0.0 | -1.4 | 0.0 | 0.0 | 0.1 | +2.6 | 7.2 | 6.2 |
| CARRIES OUT SET-UP | 0.1 | -1.6 | 4.8 | 3.2 | 0.1 | -0.7 | 6.4 | 7.2 |
| CAST JOB | 0.9 | +23.9 | 57.9 | 24.2 | 0.5 | +13.0 | 23.0 | 15.8 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 3.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +46.8 | 30.0 | 10.2 | 0.2 | +9.4 | 6.3 | 4.4 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 56.4 | 0.4 | +0.0 | 0.0 | 12.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.0 | 7.1 | 0.0 | 0.1 | -0.0 | 9.4 | 2.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 239.7 | 25.2 | 2.4 | +0.0 | 237.2 | 99.4 |
| CHARGE NOW WEIGHED | 0.5 | -39.5 | 39.6 | 5.9 | 0.5 | -45.9 | 3.8 | 60.2 |
| CHARGER SLAIN LOST | 0.6 | -19.6 | 80.7 | 26.4 | 0.8 | -10.0 | 53.3 | 35.0 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.2 | +0.0 | 25.7 | 0.0 | 0.2 | +0.0 | 14.0 | 11.1 |
| COMBAT PIVOT | 0.5 | +0.0 | 43.2 | 33.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +90.9 | 52.8 | 42.0 | 0.6 | +58.5 | 20.9 | 19.7 |
| COUNTER-CHARGE COVER | 10.7 | +944.4 | 0.0 | 213.4 | 7.6 | +719.9 | 0.0 | 176.5 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 52.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.9 | +13.0 | 0.0 | 8.6 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +9.7 | 24.1 | 1.4 | 0.4 | +16.8 | 18.4 | 23.0 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +154.4 | 0.0 | 82.1 | 2.2 | +188.0 | 0.0 | 86.2 |
| FALLBACK BY WORTH | 4.2 | +78.4 | 0.0 | 53.6 | 5.8 | +57.6 | 0.0 | 46.7 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +2.0 | 0.0 | 5.5 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 189.7 | 5.9 | +0.0 | 0.0 | 218.6 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.1 | 0.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +109.2 | 0.0 | 29.5 | 1.1 | +147.6 | 0.0 | 57.1 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.3 | 0.0 | 8.7 | 0.1 | +5.2 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.2 | 12.2 | 0.0 | 0.1 | -1.5 | 0.0 | 3.2 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 2.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 5.1 | 1.2 |
| HELPER UNSEEN | 0.4 | +0.0 | 67.0 | 5.5 | 0.3 | +0.0 | 22.9 | 1.2 |
| HILL BY ITS CHANCE | 0.2 | -26.1 | 0.0 | 3.6 | 0.6 | -70.8 | 0.0 | 1.1 |
| HOLDER AT DEPLOYMENT | 1.0 | +170.1 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -126.6 | 375.3 | 79.7 | 8.6 | -162.8 | 551.0 | 302.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.9 | 0.0 | 5.2 | 0.3 | +3.5 | 5.8 | 1.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 1.4 | 0.2 | +0.0 | 11.7 | 4.0 |
| HUNT IN PAIRS | 0.1 | +5.7 | 0.0 | 0.0 | 0.4 | +22.6 | 0.0 | 36.2 |
| HUNT KEPT | 0.1 | +0.0 | 10.5 | 2.4 | 0.2 | +3.5 | 15.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.4 | 0.4 | +49.5 | 23.2 | 5.9 |
| HUNT THE GUNS | 0.1 | +33.9 | 10.5 | 6.7 | 0.4 | +143.6 | 30.7 | 3.8 |
| INVITES THE FIGHT | 2.2 | +30.4 | 62.8 | 51.8 | 1.5 | +31.1 | 71.1 | 22.8 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +12.7 | 8.3 | 6.0 |
| JOINT KNOWS CHALLENGE | 0.2 | -2.8 | 51.1 | 4.9 | 0.1 | -6.7 | 18.8 | 5.2 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.3 | 2.4 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.8 | 125.6 | 11.2 | 1.8 | +55.0 | 207.9 | 65.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +84.5 | 121.6 | 18.2 | 1.9 | +54.7 | 143.5 | 93.9 |
| KILLS COUNT NEXT TURN | 4.2 | +129.0 | 152.1 | 74.0 | 7.1 | +224.1 | 301.4 | 225.6 |
| LANE BY FIGURES | 0.7 | +38.3 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +9.1 | 22.4 | 0.0 | 0.2 | +8.5 | 7.6 | 28.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 5.9 | 0.3 | +0.0 | 0.0 | 21.4 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 3.6 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -2.2 | 23.2 | 3.2 | 0.7 | +2.6 | 40.0 | 18.1 |
| LOST CHARGE | 3.6 | -66.3 | 145.3 | 66.7 | 2.8 | -46.7 | 93.8 | 103.1 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -19.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +31.5 | 10.2 | 17.2 | 0.8 | +31.4 | 22.9 | 14.8 |
| MANOEUVRE | 0.2 | +12.7 | 0.0 | 1.1 | 0.2 | +4.2 | 0.0 | 5.4 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +22.3 | 0.0 | 0.0 | 0.5 | +33.1 | 0.0 | 14.2 |
| MARCH ODDS | 0.3 | +34.7 | 22.8 | 0.0 | 0.2 | +7.6 | 4.6 | 10.6 |
| MARCH OVER CASTS | 0.4 | +24.5 | 0.0 | 0.0 | 0.2 | +13.9 | 0.0 | 4.6 |
| MAX FOR POSITIONING | 4.9 | +160.2 | 0.0 | 73.5 | 5.1 | +182.3 | 0.0 | 146.5 |
| MISSILES IN THE MOVE | 4.5 | +131.0 | 0.0 | 90.2 | 3.1 | +72.2 | 0.0 | 143.5 |
| MISSILES NEXT TURN | 5.0 | +77.4 | 0.0 | 93.3 | 3.4 | +42.7 | 0.0 | 143.5 |
| MODEL FACING | 0.2 | +42.4 | 0.0 | 3.3 | 0.1 | +8.2 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 20.9 | 13.9 | 0.4 | +0.0 | 0.0 | 15.9 |
| MOVE AND CAST | 0.3 | +8.6 | 0.0 | 2.4 | 0.4 | +8.5 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.2 | +8.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.1 | -5.6 | 7.0 | 0.0 | 0.1 | -2.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 17.8 |
| MOVE TO CHARGE | 2.6 | +112.2 | 108.8 | 51.6 | 4.1 | +190.2 | 220.0 | 153.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +8.9 | 8.2 | 13.9 | 0.0 | +7.1 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.3 | 0.0 | 3.5 | - | - | - | - |
| NOT NEEDED | 0.2 | -7.2 | 15.8 | 1.4 | 0.4 | -11.8 | 38.3 | 0.8 |
| NOT TURNED | 5.6 | +95.0 | 0.0 | 122.6 | 5.7 | +128.9 | 0.0 | 143.3 |
| NOT WORTH A CAST | 0.8 | -0.8 | 0.0 | 19.7 | 0.5 | -0.3 | 0.0 | 9.8 |
| OFF BEST | 15.8 | -805.4 | 5.1 | 280.2 | 16.2 | -846.5 | 3.8 | 388.3 |
| OPENS A LANE | 0.3 | +5.5 | 45.1 | 2.6 | 0.1 | +0.2 | 11.5 | 0.0 |
| OPENS UP | 0.1 | +9.8 | 10.8 | 0.0 | 0.2 | +16.1 | 15.3 | 0.0 |
| OVERRUNS AWAY | 0.2 | +1.7 | 17.5 | 5.5 | 0.3 | +7.5 | 36.4 | 9.2 |
| PATHS CROSS | 1.6 | +83.6 | 0.0 | 3.5 | 3.1 | +207.0 | 0.0 | 71.7 |
| PERIAPT WORTH | 0.1 | +6.2 | 0.0 | 15.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -5.4 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 0.0 |
| PLAN RESULT | 37.9 | +1679.9 | 1615.4 | 908.8 | 40.6 | +1126.3 | 1568.9 | 1129.8 |
| PURSUES BIG PREY | 0.1 | -5.7 | 0.0 | 0.0 | 0.1 | -12.4 | 0.0 | 24.4 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +12.8 | 0.0 | 29.2 | 1.6 | +27.5 | 0.0 | 43.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.6 | 3.4 | 5.8 | 0.3 | -8.9 | 14.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.9 | 0.0 | 3.3 | 0.3 | -11.9 | 0.0 | 7.2 |
| REDIRECT COUNTER | 2.6 | +190.9 | 0.0 | 37.0 | 4.0 | +352.6 | 0.0 | 57.5 |
| REDIRECT WEIGHED | 0.3 | +1.1 | 0.0 | 14.0 | 0.4 | +16.3 | 14.9 | 4.7 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.0 | 0.4 | +0.0 | 0.0 | 10.5 |
| RESERVE FALL BACK | 0.4 | +13.4 | 0.0 | 13.1 | 1.2 | +45.9 | 0.0 | 20.3 |
| RESTRAINS TO SHOOT | 0.2 | +5.3 | 0.0 | 4.9 | 0.1 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +112.5 | 228.7 | 37.4 | 3.0 | +91.4 | 270.0 | 130.5 |
| SAFER THAN THE JOB | 1.3 | +84.4 | 0.0 | 14.5 | 1.0 | +63.3 | 0.0 | 31.7 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +1.6 | 0.0 | 2.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 2.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.9 | 0.0 | 0.8 | 0.3 | -15.8 | 0.0 | 0.8 |
| SEARCH SPOT | 2.9 | +118.0 | 0.0 | 42.8 | 3.0 | +128.1 | 0.0 | 36.1 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 1.4 | 0.1 | -0.2 | 12.6 | 0.0 |
| SELF MOVE SPELL | 0.2 | +14.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +40.8 | 31.1 | 39.6 | 1.5 | +75.2 | 71.3 | 32.8 |
| SET-UP ANY TARGET | 0.1 | +11.3 | 0.0 | 0.0 | 0.1 | +21.4 | 3.2 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +3.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.0 | 0.0 | 0.8 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.4 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +18.8 | 69.4 | 8.6 | 0.8 | +24.7 | 18.0 | 9.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 1.1 | +0.0 | 232.6 | 21.6 | 0.3 | +0.0 | 26.8 | 6.6 |
| SHOTS IN THE MOVE | 14.9 | +640.5 | 0.0 | 257.6 | 12.0 | +453.5 | 0.0 | 203.9 |
| SPELL OFF EDGE | 0.0 | +2.0 | 3.2 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +67.0 | 0.0 | 0.0 | 0.2 | +35.4 | 20.9 | 12.1 |
| SPELL WORTH | 0.8 | +15.7 | 49.2 | 49.2 | 1.6 | +20.0 | 90.8 | 90.8 |
| SPELLS IN THE FIGHT | 0.6 | +8.0 | 75.2 | 13.9 | 0.9 | -11.5 | 98.9 | 38.1 |
| STABLE ROLE | 11.4 | +0.0 | 403.2 | 131.6 | 11.1 | +0.0 | 335.7 | 237.4 |
| STANDS TO CAST | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 4.4 |
| STAY WEIGHED | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.4 | 10.5 | 3.8 | 0.3 | +9.8 | 36.4 | 1.9 |
| STOPS SHORT OF THE FLANK | 0.6 | +33.4 | 0.0 | 25.2 | 0.5 | +23.5 | 0.0 | 17.3 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.2 | -53.8 | 232.1 | 85.6 | 6.6 | -51.6 | 413.2 | 96.5 |
| SUPPORTS | 3.9 | +54.1 | 73.2 | 50.5 | 4.4 | +57.7 | 235.1 | 50.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -6.8 | 6.2 | 0.0 | 0.1 | -7.7 | 22.6 | 5.2 |
| SURE REACH TOGETHER | 0.3 | -0.0 | 9.6 | 13.9 | 0.6 | -7.9 | 41.1 | 12.2 |
| THROUGH LINE OF FIRE | 0.3 | +3.7 | 0.0 | 12.2 | 0.3 | +23.3 | 0.0 | 5.6 |
| TURN WORTH | 0.2 | -17.7 | 22.8 | 4.4 | 0.1 | -8.2 | 7.5 | 3.4 |
| TWO OR MORE ARRIVE | 0.2 | +3.0 | 9.6 | 13.9 | 0.2 | +1.2 | 16.7 | 0.0 |
| WAIT AFTER COSTS | 6.3 | -292.3 | 225.1 | 107.3 | 7.9 | -376.7 | 378.3 | 236.1 |
| WALKS TO THE FIGHT | 1.3 | +31.4 | 36.9 | 4.0 | 1.4 | +21.7 | 37.2 | 23.5 |
| WAR ENGINE CHARGES | 0.2 | +19.4 | 7.4 | 6.2 | 0.1 | +4.9 | 0.0 | 7.5 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 4.6 | 14.3 | 0.2 | +0.0 | 11.5 | 14.0 |
| WEARS DOWN | 1.2 | +46.4 | 123.7 | 13.5 | 1.4 | +45.1 | 166.5 | 51.6 |
| WHO HITS BACK | 0.2 | +28.8 | 0.0 | 27.7 | 0.2 | +18.1 | 0.0 | 5.2 |
| WHOLE FIGHT | 0.3 | +2.1 | 46.6 | 2.6 | 0.3 | +3.4 | 36.2 | 3.5 |
| WHOLE FIGHT GAIN | 0.4 | +29.7 | 42.1 | 3.6 | 0.7 | +54.2 | 58.0 | 8.3 |
| WIDER SPREAD | 2.4 | -5.7 | 195.7 | 56.4 | 3.3 | -5.6 | 310.0 | 88.0 |

### Rule changes: dep-mine-13df7bd-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1152 | 1152 | 1152 | 32.00 | -59469 | -51.6 |
| BEST FIRST | 348 | 348 | 348 | 9.67 | +15267 | +43.9 |
| SEARCH SPOT | 211 | 211 | 209 | 5.81 | +8862 | +42.4 |
| COUNTER-CHARGE COVER | 657 | 374 | 181 | 5.03 | +12276 | +67.8 |
| PATHS CROSS | 170 | 170 | 170 | 4.72 | +10464 | +61.6 |
| DEPLOY BY FIGURES | 286 | 286 | 160 | 4.44 | +2061 | +12.9 |
| FACES THE THREAT | 148 | 148 | 148 | 4.11 | +12326 | +83.3 |
| KILLS COUNT NEXT TURN | 407 | 407 | 126 | 3.50 | +4178 | +33.2 |
| SUPPORTS | 299 | 299 | 122 | 3.39 | +1363 | +11.2 |
| MOVE TO CHARGE | 244 | 244 | 120 | 3.33 | +2663 | +22.2 |
| FALLBACK BY WORTH | 361 | 361 | 90 | 2.50 | +4897 | +54.4 |
| SHOTS IN THE MOVE | 968 | 629 | 89 | 2.47 | +3290 | +37.0 |
| SAFER THAN THE JOB | 85 | 85 | 85 | 2.36 | +5320 | +62.6 |
| BEST FACING | 72 | 72 | 72 | 2.00 | +3062 | +42.5 |
| WAIT AFTER COSTS | 514 | 514 | 72 | 2.00 | +1456 | +20.2 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +9242 | +133.9 |
| ADVANCE LANE KEPT | 66 | 66 | 66 | 1.83 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 63 | 63 | 63 | 1.75 | +0 | +0.0 |
| RESERVE FALL BACK | 58 | 58 | 58 | 1.61 | +2134 | +36.8 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| MAX FOR POSITIONING | 361 | 203 | 57 | 1.58 | +795 | +13.9 |
| REDIRECT COUNTER | 237 | 126 | 54 | 1.50 | +3351 | +62.1 |
| MISSILES IN THE MOVE | 273 | 173 | 52 | 1.44 | +1176 | +22.6 |
| WALKS TO THE FIGHT | 98 | 98 | 52 | 1.44 | +671 | +12.9 |
| CANNON PLANNED TARGET | 239 | 239 | 51 | 1.42 | -268 | -5.3 |
| SHOT REPLANNED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| BEST OVERALL | 48 | 48 | 48 | 1.33 | +3413 | +71.1 |
| RANDOM MOVE BY FIGURES | 79 | 79 | 46 | 1.28 | +1450 | +31.5 |
| RISK BY ARC | 203 | 194 | 44 | 1.22 | +1386 | +31.5 |
| CHARGE NOW FIRST | 167 | 167 | 42 | 1.17 | -2533 | -60.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 38 | 38 | 38 | 1.06 | +2050 | +54.0 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +1434 | +38.7 |
| MARCH CHECK | 36 | 34 | 34 | 0.94 | +1562 | +45.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| KILLS COUNT | 132 | 129 | 30 | 0.83 | +1267 | +42.2 |
| HONEST WORTH | 575 | 571 | 29 | 0.81 | +180 | +6.2 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +969 | +35.9 |
| SHOOTERS IN TWO RANKS | 27 | 27 | 27 | 0.75 | +58 | +2.1 |
| SHOOTS FROM THE BEST SPOT | 58 | 58 | 27 | 0.75 | +654 | +24.2 |
| BEST PREY | 70 | 70 | 26 | 0.72 | +937 | +36.0 |
| MOVE AND CAST | 26 | 26 | 26 | 0.72 | +616 | +23.7 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +410 | +16.4 |
| COMBAT PIVOT | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| LANE BY FIGURES | 25 | 25 | 25 | 0.69 | +1380 | +55.2 |
| SET UP TOGETHER | 79 | 63 | 25 | 0.69 | +1273 | +50.9 |
| CASTING BLOCK | 31 | 31 | 24 | 0.67 | +1010 | +42.1 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +971 | +42.2 |
| WHOLE FIGHT GAIN | 42 | 41 | 22 | 0.61 | +837 | +38.0 |
| CAST JOB | 48 | 48 | 21 | 0.58 | +454 | +21.6 |
| CASTER AWAY FROM SCREEN | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| KEEPS ITS TARGET | 121 | 119 | 19 | 0.53 | +350 | +18.4 |
| INVITES THE FIGHT | 132 | 132 | 18 | 0.50 | +310 | +17.2 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +291 | +17.1 |
| HOLDER AT DEPLOYMENT | 36 | 36 | 16 | 0.44 | +577 | +36.1 |
| MANOEUVRE | 16 | 16 | 16 | 0.44 | +606 | +37.9 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1234 | +77.1 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| LOST CHARGE | 229 | 228 | 14 | 0.39 | +403 | +28.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -12 | -1.0 |
| MODEL FACING | 13 | 13 | 13 | 0.36 | +1821 | +140.1 |
| WEARS DOWN | 94 | 92 | 12 | 0.33 | +418 | +34.9 |
| MAKE SURE TOGETHER | 41 | 23 | 10 | 0.28 | +521 | +52.1 |
| REFUSING RETIRES | 21 | 21 | 10 | 0.28 | -3 | -0.3 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -520 | -52.0 |
| OPENS UP | 12 | 12 | 9 | 0.25 | +437 | +48.5 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -2 | -0.2 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +299 | +37.3 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -238 | -34.0 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -652 | -93.1 |
| WAR ENGINE JOBS | 30 | 30 | 7 | 0.19 | -253 | -36.2 |
| EDGE GIVE GROUND | 23 | 23 | 6 | 0.17 | +307 | +51.2 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +273 | +45.5 |
| MISSILES NEXT TURN | 302 | 184 | 6 | 0.17 | +26 | +4.2 |
| SUPPORT NARROWED | 460 | 460 | 6 | 0.17 | -73 | -12.1 |
| BACKUP TARGETS | 75 | 36 | 5 | 0.14 | +63 | +12.6 |
| HUNT IN PAIRS | 17 | 9 | 5 | 0.14 | +204 | +40.8 |
| SPELLS IN THE FIGHT | 56 | 50 | 5 | 0.14 | +40 | +8.1 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -78 | -19.5 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +71 | +17.8 |
| JOINT CHARGE PLAN | 5 | 5 | 4 | 0.11 | +275 | +68.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 5 | 4 | 4 | 0.11 | +0 | +0.0 |
| STOPS | 13 | 13 | 4 | 0.11 | +87 | +21.6 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CARRIES OUT COUNTER | 5 | 5 | 3 | 0.08 | +44 | +14.8 |
| DEFENSIVE ARMY | 14 | 14 | 3 | 0.08 | -136 | -45.5 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 3 | 0.08 | -22 | -7.5 |
| LONG SHOT | 41 | 39 | 3 | 0.08 | +51 | +17.0 |
| OVERRUNS AWAY | 21 | 20 | 3 | 0.08 | +100 | +33.4 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +347 | +115.6 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -35 | -11.6 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +88 | +29.2 |
| WIDER SPREAD | 206 | 199 | 3 | 0.08 | +9 | +3.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -85 | -42.3 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -93 | -46.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +40 | +20.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +40 | +19.8 |
| SURE REACH TOGETHER | 34 | 27 | 2 | 0.06 | +15 | +7.6 |
| WAR ENGINE CHARGES | 10 | 10 | 2 | 0.06 | +215 | +107.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +13 | +13.1 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -162 | -162.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +4 | +4.4 |
| HUNT ADVANCE | 14 | 14 | 1 | 0.03 | +4 | +4.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +14 | +14.4 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +95 | +94.6 |
| WHOLE FIGHT | 20 | 20 | 1 | 0.03 | +72 | +71.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 22 | 21 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 45 | 45 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 49 | 47 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 13 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 44 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 437 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 30 | 30 | 0 | 0.00 | - | - |
| HUNT DROPPED | 9 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 18 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 10 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 405 | 405 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| OPENS A LANE | 14 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2829 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 87 | not checked | - | - | - | - |
| STABLE ROLE | 809 | 808 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 15 | 15 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.11 | 14.50 | 53.1 |
| FALLBACK | gate | 0.75 | 0.69 | 34.4 |
| TURN GATE | gate | 0.53 | 0.67 | 43.4 |
| CHARGE NOW FIRST | rule | 0.58 | 0.58 | 60.3 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.08 | 28.8 |
| AFTERMATH BAND | gate | 0.17 | 0.08 | 2.6 |
| PATHS CROSS | rule | 0.06 | 0.19 | 28.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.11 | 57.7 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.14 | 40.8 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 34.0 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 93.1 |
| WAR ENGINE JOBS | rule | 0.17 | 0.03 | 36.2 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.14 | 9.5 |
| BLOCKED WHEEL | rule | 0.06 | 0.11 | 11.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.03 | 69.8 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 12.1 |
| THROUGH LINE OF FIRE | rule | 0.14 | 0.03 | 17.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.08 | 79.9 |
| BEST PRIZE | rule | 0.08 | 0.03 | 19.5 |
| DEFENSIVE ARMY | rule | 0.08 | - | 45.5 |
| FIGHT ORDER BAND | gate | - | 0.08 | 1.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 7.5 |
| REFUSING RETIRES | rule | 0.03 | 0.06 | 0.7 |
| SAFER THAN THE JOB | rule | - | 0.08 | 12.1 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 36.8 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 42.3 |
| CATCH ODDS | rule | - | 0.06 | 46.6 |
| NO REASON | gate | 0.06 | - | 103.0 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 7.0 |
| STANDS TO CAST | rule | - | 0.06 | 18.7 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 4.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 38.1 |
| CHAFF PASSED | rule | - | 0.03 | 1.4 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 162.3 |
| FACES THE THREAT | rule | 0.03 | - | 12.1 |
| LONG SHOT | rule | 0.03 | - | 2.2 |
| MARCH ODDS | rule | - | 0.03 | 13.7 |
| RULE SWITCHED OFF | gate | - | 0.03 | 4.7 |
| WHO HITS BACK | rule | - | 0.03 | 4.6 |

### Plans: dep-mine-13df7bd-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 20% | 458 | 365 | 80% |
| Mine | charge | 3.6 | 56% | 282 | 299 | 106% |
| Mine | close in | 3.7 | 26% | 177 | 128 | 72% |
| Mine | hold | 4.8 | 46% | 309 | 0 | 0% |
| Mine | join | 0.6 | 90% | 23 | 0 | 0% |
| Mine | shoot | 9.3 | 64% | 270 | 888 | 329% |
| Mine | support | 4.2 | 93% | 35 | 0 | 0% |
| Opponent | advance | 15.2 | 14% | 444 | 321 | 72% |
| Opponent | charge | 4.1 | 56% | 252 | 310 | 123% |
| Opponent | close in | 5.4 | 26% | 272 | 179 | 66% |
| Opponent | hold | 4.8 | 36% | 367 | 0 | 0% |
| Opponent | join | 0.6 | 96% | 31 | 0 | 0% |
| Opponent | shoot | 5.7 | 57% | 180 | 316 | 175% |
| Opponent | support | 4.8 | 90% | 45 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 1 | 0% | 0% | 0% | - | 201 | 0 | 0% | 38 |
| Opponent | 0.4 | 16 | 2 | 36% | 29% | 7% | 2.5 | 341 | 127 | 29% | 88 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 201 | 0 | 0% | 103 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 82 |
| Dwarfen Mountain Holds | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 57 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 106 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 2.0 | 8 | 1 | 57% | 57% | 14% | 2.5 | 462 | 255 | 57% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Tomb Kings of Khemri | 1.0 | 5 | 1 | 0% | 0% | 0% | - | 99 | 0 | 0% | 14 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 8 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 546 | 0 | 0% | 104 |
| Wood Elf Realms | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 226 | 0 | 0% | 71 |

### Battle groups: dep-mine-13df7bd-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.7 | 20% | 64% | 14% | 9% | 36% | 10% | 18% | 36% | 0% |
| Mine | REDIRECT COUNTER | 2.6 | 18% | 71% | 35% | 17% | 45% | 0% | 9% | 45% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 23% | 66% | 16% | 50% | 31% | 19% | 7% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 27% | 74% | 18% | 29% | 6% | 3% | 22% | 69% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 49 (5) | 49 | 0 | 68 | 20% | 3.5 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 35 | 89 (35) | 31 | 58 | 53 | 31% | 2.7 | 70 (20) | 133 (12) | 49 (3) | 107 (25) | 44 (10) |
| Mine | Character | 124 | 50 (124) | 50 | 0 | 29 | 15% | 2.5 | 50 (36) | 55 (62) | 63 (10) | 51 (64) | 58 (44) |
| Mine | Clean-up | 20 | 46 (20) | 9 | 37 | 35 | 40% | 4.0 | 34 (4) | 4 (10) | 109 (6) | 62 (14) | 17 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 49 | 57 (49) | 33 | 23 | 36 | 14% | 3.4 | 65 (23) | 55 (17) | 39 (9) | 62 (32) | 49 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.2 | 0 (2) | 0 (2) | 0 (1) | 0 (4) | 0 (1) |
| Mine | Hammer | 57 | 44 (57) | 34 | 10 | 48 | 19% | 2.3 | 25 (16) | 57 (34) | 14 (7) | 54 (34) | 31 (23) |
| Mine | Holder | 29 | 44 (29) | 2 | 42 | 17 | 41% | 3.2 | 18 (12) | 66 (14) | 12 (3) | 56 (19) | 17 (10) |
| Mine | Shooter | 39 | 111 (39) | 66 | 45 | 40 | 5% | 1.4 | 112 (12) | 110 (19) | 110 (8) | 110 (29) | 113 (10) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 44 (59) | 44 | 0 | 59 | 3% | 1.3 | 55 (15) | 52 (32) | 12 (12) | 35 (8) | 45 (51) |
| Mine | Wizard | 21 | 18 (21) | 18 | 0 | 33 | 19% | 2.9 | 28 (12) | 0 (5) | 0 (1) | 95 (4) | 0 (14) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 50% | 6.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 75 | 108 (75) | 49 | 59 | 54 | 35% | 2.6 | 92 (31) | 139 (16) | 101 (28) | 141 (54) | 29 (21) |
| Opponent | Character | 97 | 37 (97) | 37 | 0 | 41 | 16% | 2.6 | 35 (38) | 52 (39) | 0 (6) | 36 (55) | 45 (28) |
| Opponent | Clean-up | 18 | 40 (18) | 20 | 20 | 48 | 17% | 2.7 | 75 (4) | 29 (14) | - | 45 (12) | 32 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 51 | 53 (51) | 46 | 7 | 49 | 20% | 2.5 | 36 (23) | 87 (17) | 27 (11) | 61 (30) | 40 (21) |
| Opponent | Fragile | 5 | 16 (5) | 16 | 0 | 61 | 60% | 2.5 | - | 26 (3) | 0 (1) | 24 (3) | 0 (1) |
| Opponent | Hammer | 70 | 22 (70) | 18 | 4 | 45 | 26% | 3.3 | 22 (17) | 20 (41) | 31 (12) | 21 (40) | 23 (30) |
| Opponent | Holder | 34 | 61 (34) | 6 | 55 | 21 | 50% | 3.2 | 73 (5) | 64 (21) | 53 (7) | 57 (23) | 79 (10) |
| Opponent | Infantry | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Shooter | 32 | 66 (32) | 28 | 38 | 39 | 0% | 1.8 | 50 (10) | 85 (18) | 6 (4) | 94 (22) | 19 (10) |
| Opponent | Support | 3 | 28 (3) | 28 | 0 | 0 | 67% | 3.0 | 37 (2) | - | 0 (1) | 0 (1) | 37 (2) |
| Opponent | War machine | 24 | 48 (24) | 48 | 0 | 13 | 8% | 1.7 | 58 (6) | 50 (14) | 32 (4) | 90 (3) | 42 (21) |
| Opponent | Wizard | 26 | 17 (26) | 17 | 0 | 53 | 8% | 1.9 | 0 (8) | 54 (9) | 5 (5) | 38 (9) | 2 (13) |

### Charged fights: dep-mine-13df7bd-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 152 | 151 | 1.0 | 1.0 | 151 | 116 | +36 | 2 of 4 | 3 of 4 | - | +36 |
| Mine | Chaos Dwarfs | 4 | 208 | 331 | 3.0 | 1.1 | 110 | 52 | +59 | 7 of 12 | 10 of 12 | +45 | +60 |
| Mine | Dwarfen Mountain Holds | 4 | 688 | 233 | 2.5 | 1.3 | 93 | 62 | +31 | 6 of 10 | 4 of 10 | +181 | -33 |
| Mine | Empire of Man | 5 | 685 | 283 | 1.0 | 1.4 | 283 | 25 | +258 | 4 of 5 | 4 of 5 | +540 | +188 |
| Mine | Grand Cathay | 4 | 157 | 462 | 2.8 | 1.3 | 168 | 20 | +148 | 5 of 11 | 10 of 11 | +367 | +66 |
| Mine | High Elf Realms | 4 | 224 | 446 | 4.5 | 1.1 | 99 | 41 | +58 | 5 of 18 | 15 of 18 | +92 | +54 |
| Mine | Kingdom of Bretonnia | 1 | 170 | 532 | 4.0 | 1.2 | 133 | 0 | +133 | 1 of 4 | 3 of 4 | +0 | +177 |
| Mine | Lizardmen | 1 | 281 | 1158 | 6.0 | 1.3 | 193 | 47 | +146 | 1 of 6 | 5 of 6 | +300 | +69 |
| Mine | Ogre Kingdoms | 1 | 75 | 186 | 4.0 | 1.0 | 46 | 17 | +30 | 1 of 4 | 1 of 4 | - | +30 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1417 | 8.0 | 1.0 | 177 | 26 | +151 | 1 of 8 | 6 of 8 | - | +151 |
| Mine | Skaven | 2 | 100 | 102 | 1.0 | 1.0 | 102 | 19 | +84 | 0 of 2 | 0 of 2 | - | +84 |
| Mine | Tomb Kings of Khemri | 1 | 102 | 265 | 4.0 | 1.2 | 66 | 32 | +34 | 0 of 4 | 2 of 4 | +140 | -1 |
| Mine | Vampire Counts | 3 | 42 | 394 | 7.0 | 1.1 | 56 | 8 | +48 | 3 of 21 | 15 of 21 | -30 | +56 |
| Mine | Warriors of Chaos | 1 | 0 | 236 | 4.0 | 1.2 | 59 | 0 | +59 | 1 of 4 | 3 of 4 | +236 | +0 |
| **Mine** | all armies | 36 | 280 | 364 | 3.1 | 1.2 | 116 | 33 | +83 | 37 of 113 | 81 of 113 | +196 | +63 |
| Opponent | Dwarfen Mountain Holds | 2 | 206 | 28 | 1.5 | 1.3 | 18 | 40 | -22 | 1 of 3 | 0 of 3 | -60 | -2 |
| Opponent | Empire of Man | 2 | 164 | 182 | 3.0 | 1.2 | 61 | 63 | -3 | 3 of 6 | 4 of 6 | +0 | -3 |
| Opponent | Grand Cathay | 2 | 192 | 240 | 2.5 | 1.2 | 96 | 27 | +69 | 3 of 5 | 3 of 5 | +289 | +14 |
| Opponent | Kingdom of Bretonnia | 1 | 400 | 120 | 3.0 | 1.0 | 40 | 0 | +40 | 2 of 3 | 1 of 3 | - | +40 |
| Opponent | Ogre Kingdoms | 3 | 50 | 319 | 3.3 | 1.2 | 96 | 97 | -1 | 4 of 10 | 4 of 10 | +114 | -30 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 181 | 637 | 3.2 | 1.1 | 196 | 0 | +196 | 4 of 13 | 11 of 13 | +110 | +203 |
| Opponent | Vampire Counts | 6 | 62 | 573 | 4.3 | 1.3 | 132 | 13 | +119 | 9 of 26 | 20 of 26 | +96 | +128 |
| Opponent | Warriors of Chaos | 8 | 16 | 419 | 3.2 | 1.3 | 129 | 34 | +95 | 14 of 26 | 21 of 26 | +102 | +93 |
| Opponent | Wood Elf Realms | 7 | 56 | 310 | 4.1 | 1.1 | 75 | 29 | +46 | 7 of 29 | 22 of 29 | +49 | +46 |
| **Opponent** | all armies | 36 | 91 | 375 | 3.4 | 1.2 | 111 | 30 | +81 | 48 of 122 | 87 of 122 | +93 | +78 |

### Effective charges: dep-mine-13df7bd-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 1 (net +122) | 1 (net +55) | 0 | 1 (net +428) | 1 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 12 | 1 (net +466) | 1 (net -310) | 2 (net -155) | 4 (net +78) | 0 | 3 (net +119) | 1 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 10 | 1 (net +931) | 0 | 3 (net -164) | 3 (net -43) | 0 | 1 (net +0) | 2 | 38% (3 of 8) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 1 (net +85) | 2 (net +342) | 0 | 1 (net +522) | 0 | 20% (1 of 5) |
| Mine | Grand Cathay | 11 | 1 (net -217) | 0 | 2 (net +495) | 4 (net +38) | 2 (net +76) | 2 (net +278) | 0 | 18% (2 of 11) |
| Mine | High Elf Realms | 18 | 2 (net +92) | 0 | 3 (net -245) | 3 (net +251) | 4 (net +118) | 3 (net +85) | 3 | 20% (3 of 15) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 3 (net +137) | 0 | 0 | 0 | 1 | 100% (3 of 3) |
| Mine | Lizardmen | 6 | 1 (net +233) | 0 | 1 (net +0) | 2 (net +159) | 2 (net +162) | 0 | 0 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +59) | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 8 | 1 (net +131) | 0 | 1 (net +250) | 1 (net +186) | 1 (net +54) | 1 (net +45) | 3 | 20% (1 of 5) |
| Mine | Skaven | 2 | 0 | 0 | 1 (net +167) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net -127) | 0 | 0 | 1 (net +0) | 2 | 50% (1 of 2) |
| Mine | Vampire Counts | 21 | 2 (net -34) | 3 (net +238) | 2 (net +102) | 4 (net +16) | 2 (net +0) | 4 (net -11) | 4 | 12% (2 of 17) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +118) | 1 | 33% (1 of 3) |
| Opponent | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 0 | 1 (net +55) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Empire of Man | 6 | 2 (net -190) | 0 | 1 (net +0) | 1 (net +364) | 1 (net +0) | 1 (net +0) | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 2 (net +192) | 3 (net -13) | 0 | 0 | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +0) | 0 | 0 | 1 (net +120) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 10 | 5 (net -66) | 0 | 1 (net +0) | 0 | 0 | 1 (net +227) | 3 | 14% (1 of 7) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 2 (net +434) | 0 | 2 (net +158) | 3 (net +136) | 1 (net +85) | 3 (net +222) | 2 | 18% (2 of 11) |
| Opponent | Vampire Counts | 26 | 2 (net -116) | 1 (net +0) | 6 (net +198) | 10 (net +192) | 1 (net +0) | 5 (net +15) | 1 | 24% (6 of 25) |
| Opponent | Warriors of Chaos | 26 | 2 (net +150) | 1 (net -116) | 6 (net +64) | 2 (net -34) | 2 (net +42) | 12 (net +142) | 1 | 24% (6 of 25) |
| Opponent | Wood Elf Realms | 29 | 1 (net -125) | 1 (net +246) | 3 (net +55) | 10 (net +42) | 1 (net +52) | 8 (net +25) | 5 | 12% (3 of 24) |

### Charged fights, damage counted: dep-mine-13df7bd-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 246 | 290 | +151 | 182 | 43 | +139 | +56.6 |
| Mine | 50-54% | 4 | 222 | 290 | +101 | 178 | 78 | +101 | +45.3 |
| Mine | Effective (55-75%) | 22 | 302 | 218 | +26 | 150 | 107 | +43 | +14.2 |
| Mine | 76-89% | 24 | 308 | 220 | +100 | 132 | 48 | +84 | +27.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 188 | 151 | +112 | 126 | 12 | +114 | +60.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 374 | 76 | +91 | 100 | 9 | +91 | +24.2 |
| Mine | No odds | 19 | 277 | 165 | +48 | 94 | 54 | +40 | +14.6 |
| Mine | All fights | 113 | 276 | 192 | +83 | 131 | 50 | +81 | +29.4 |
| Opponent | Long shot (under 50%) | 16 | 206 | 229 | +2 | 143 | 136 | +7 | +3.4 |
| Opponent | 50-54% | 3 | 239 | 290 | +43 | 145 | 71 | +75 | +31.2 |
| Opponent | Effective (55-75%) | 21 | 281 | 203 | +116 | 159 | 48 | +111 | +39.4 |
| Opponent | 76-89% | 31 | 203 | 177 | +103 | 138 | 29 | +109 | +53.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 219 | 182 | +90 | 141 | 26 | +115 | +52.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 397 | 83 | +37 | 70 | 21 | +50 | +12.5 |
| Opponent | No odds | 13 | 172 | 188 | +72 | 91 | 30 | +61 | +35.6 |
| Opponent | All fights | 122 | 228 | 189 | +81 | 135 | 46 | +88 | +38.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p2 | move | 461 | 100 (22%) | 74 (16%) | 50 (11%) | 311 (67%) |
| dep-mine-13df7bd-p2 | objective | 333 | 46 (14%) | 33 (10%) | 48 (14%) | 239 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

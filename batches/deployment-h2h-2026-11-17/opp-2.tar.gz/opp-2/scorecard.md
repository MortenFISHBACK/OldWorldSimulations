# Doctrine scorecard: dep-opp-13df7bd-p2

### Scorecard: dep-opp-13df7bd-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | 5 | 2 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 743 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 801 |
| L0222 | 6 | 1 | Mine | no | 7 | 5 | 1 | 4 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 497 |
| L0323 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 66 |
| L0409 | 1 | 1 | Mine | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 112 |
| L0409 | 1 | 1 | Opponent | no | 2 | 4 | 0 | 0 | 0 | 0 | 0 | 769 |
| L0425 | 5 | 1 | Mine | yes | - | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 147 |
| L0512 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 803 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 498 |
| L0528 | 6 | 1 | Opponent | yes | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 4 | 1 | 1 | 0 | 0 | 1179 |
| L0616 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 2 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 250 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 5 | 0 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 807 |
| L0810 | 6 | 1 | Opponent | no | 14 | 2 | 3 | 0 | 0 | 0 | 0 | 492 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 5 | - | 2 | 3 | 0 | 0 | 0 | 74 |
| L0934 | 4 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 1134 |
| L0934 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 10 | 3 | 5 | 0 | 0 | 0 | 0 | 60 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 5 | 1 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | yes | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 1 | 3 | 0 | 1 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 3 | 1 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 5 | 1 | 0 | 0 | 0 | 0 | 147 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 3 | 4 | 4 | 0 | 0 | 0 | 0 | 234 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 3 | 0 | 0 | 0 | 60 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 9 | 0 | 0 | 0 | 0 | 235 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 346 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 10 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 4 | - | 2 | 3 | 0 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 484 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 158 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 10 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 3 | 1 | 4 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 27% | 2.2 | 3.1 | 2.3 | 1.2 | 0.2 | 0.0 | 0.0 | 325.8 |
| **Average** | | | Opponent | 30% | 3.1 | 2.6 | 2.7 | 1.6 | 0.2 | 0.0 | 0.0 | 170.5 |

### KPIs: dep-opp-13df7bd-p2

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (44 of 177) | 14% (25 of 183) | 19% (69 of 360) |
| Winner chose to follow up after the loser gave ground |  | 95% (38 of 40); on the table 98% | 100% (53 of 53); on the table 100% | 98% (91 of 93); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (6 of 6); on the table 100% | 83% (10 of 12); on the table 83% | 89% (16 of 18); on the table 89% |
| Winner chose to pursue after the loser fled |  | 61% (19 of 31); on the table 65% | 63% (22 of 35); on the table 74% | 62% (41 of 66); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 82% (63 of 77); on the table 84% | 85% (85 of 100); on the table 89% | 84% (148 of 177); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 33% (114 of 342) | 31% (48 of 156) | 33% (162 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (114 of 237) | 41% (48 of 116) | 46% (162 of 353) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 72% (18 of 25) | 55% (32 of 58) | 60% (50 of 83) |
| Points that never fought | lower | 37% (26258 of 71583) | 42% (29978 of 71989) | 39% (56236 of 143572) |
|   infantry points that never fought | lower | 45% (7416 of 16324) | 57% (7965 of 14029) | 51% (15381 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (164 of 284) | 59% (176 of 297) | 59% (340 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.5 uses a game | 78% (14 of 18); 1.2 uses a game | 84% (32 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 0.8 uses a game | 50% (1 of 2); 0.1 uses a game | 60% (12 of 20); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 29% (2 of 7); 0.1 uses a game | 56% (15 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (31346 of 60231) | 56% (35263 of 63281) | 54% (66609 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (31%) | 1.1 (38%) | 3.1 (33%) |
| MARCHED: its unit marched | 1.1 (17%) | 0.4 (13%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.5 (16%) | 1.8 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.1 (17%) | 0.4 (15%) | 1.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (5%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 1.4 | 4.5 | 0.6 | 1.8 |
| not cast | 3.9 | 3.2 | 3.6 | 9.3 | 1.8 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (44%) | 0.3 (8%) | 3.1 (33%) | 0.4 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.2 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (8%) | 0.3 (8%) | 1.8 (19%) | 0.2 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.4 (14%) | 0.3 (8%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (25%) | 0.4 (11%) | 1.0 (27%) | 1.5 (16%) | 0.4 (24%) | 3.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (5%) | 0.2 (6%) | 0.6 (6%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.5 (27%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (62%) | 0.2 (6%) | 1.4 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.6 a game | 0.7 a game |
| stood (cast and not dispelled) | 63% (17 of 27) | 65% (15 of 23) | 64% (32 of 50) |
| the unit moved after it | 47% (8 of 17) | 53% (8 of 15) | 50% (16 of 32) |
| it charged on its next turn | 6% (1 of 17) | 0% (0 of 15) | 3% (1 of 32) |
| the enemy charged it first | 12% (2 of 17) | 20% (3 of 15) | 16% (5 of 32) |
| it fought by the end of its next turn | 6% (1 of 17) | 7% (1 of 15) | 6% (2 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 24% (4 of 17) | 7% (1 of 15) | 16% (5 of 32) |
| none of these (no charge, no fight, no charge escaped) | 59% (10 of 17) | 73% (11 of 15) | 66% (21 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (579 of 887) | 61% (494 of 808) | 63% (1073 of 1695) |
|   cavalry | 56% (39 of 70) | 69% (121 of 176) | 65% (160 of 246) |
|   character | 61% (67 of 109) | 33% (33 of 99) | 48% (100 of 208) |
|   chariot | 53% (59 of 111) | 72% (39 of 54) | 59% (98 of 165) |
|   infantry | 58% (162 of 281) | 57% (174 of 304) | 57% (336 of 585) |
|   monster | 58% (22 of 38) | 77% (34 of 44) | 68% (56 of 82) |
|   war machine | 83% (230 of 278) | 71% (93 of 131) | 79% (323 of 409) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (23%) | 1.8 (21%) | 3.8 (22%) |
| CHARGED: it charged | 1.1 (13%) | 1.4 (17%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.4 (5%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.9 (22%) | 2.3 (26%) | 4.2 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.4 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.2 (13%) | 2.6 (15%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.3 (4%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (2%) | 0.5 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.1 | 1.5 | 82% | 5.6 pts | 40 pts |
| character | 3.0 | 1.0 | 74% | 11.0 pts | 33 pts |
| chariot | 2.7 | 1.8 | 66% | 17.4 pts | 47 pts |
| infantry | 13.4 | 5.2 | 74% | 8.8 pts | 119 pts |
| monster | 1.8 | 0.4 | 85% | 4.0 pts | 7 pts |
| war machine | 9.0 | 6.2 | 68% | 21.8 pts | 196 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.3 | 4.6 |
| Charges that made contact a game | 2.8 | 4.2 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.62 declared, 0.42 contact (26 units) | 0.67 declared, 0.58 contact (12 units) | 0.63 declared, 0.47 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (6 units) | 1.25 declared, 1.00 contact (12 units) | 1.06 declared, 0.78 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.35 contact (251 units) | 0.60 declared, 0.47 contact (284 units) | 0.54 declared, 0.42 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (38 of 73) | 67% (12 of 18) | 42% (5 of 12) | 53% (55 of 103) |
| Character in a unit | 86% (32 of 37) | 60% (12 of 20) | 40% (2 of 5) | 74% (46 of 62) |
| Character on its own | 74% (26 of 35) | 50% (17 of 34) | 41% (25 of 61) | 52% (68 of 130) |
| Chariot | 76% (13 of 17) | 31% (4 of 13) | - | 57% (17 of 30) |
| Infantry | 53% (50 of 94) | 53% (18 of 34) | 67% (2 of 3) | 53% (70 of 131) |
| Monster | 52% (15 of 29) | 67% (6 of 9) | - | 55% (21 of 38) |
| Monstrous | 71% (10 of 14) | 71% (10 of 14) | - | 71% (20 of 28) |
| War Machines | 74% (42 of 57) | 50% (1 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (4 of 5); on the table 80% | 32% (33 of 102) | 17% | 41% (9 of 22) | 100% (6 of 6); 4.8 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 42% (15 of 36) | 38% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 91% (10 of 11); on the table 91% | - | 56% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 73% (8 of 11); on the table 82% | 42% (20 of 48) | 55% | 67% (51 of 76) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 72% (13 of 18); on the table 72% | 37% (51 of 138) | 49% | 56% (30 of 54) | 93% (13 of 14); 6.0 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 67% (8 of 12); on the table 67% | 11% (2 of 18) | 19% | 48% (16 of 33) | 100% (3 of 3); 3.0 uses a game | 50% (7 of 14); 5.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (3 of 3); on the table 100% | - | 63% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (5 of 5); on the table 100% | 17% (3 of 18) | 52% | 75% (21 of 28) | 75% (3 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 13% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 70% (7 of 10); on the table 90% | 28% (5 of 18) | 30% | 56% (14 of 25) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 90% (9 of 10); on the table 90% | - | 46% | 20% (5 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 76% (26 of 34); on the table 85% | 26% (17 of 66) | 33% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 96% (24 of 25); on the table 96% | 39% (7 of 18) | 21% | 52% (38 of 73) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 89% (17 of 19); on the table 89% | 38% (9 of 24) | 44% | 68% (53 of 78) | 57% (4 of 7); 2.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 39% (31) | 49% (34) | 44% (65) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.78 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.08 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.47 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 1.67 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.17 | 1.14 | 2.31 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.94 | 5.22 | 11.17 |

### Quality by phase: dep-opp-13df7bd-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 54% (66 of 122) | 53% (89 of 169) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (146 of 365) | 54% (143 of 263) |
| Strategy | Close-in objectives charged next turn | 10% (12 of 118) | 17% (38 of 221) |
| Strategy | Support requests answered (helper made contact too) | 50% (9 of 18) | 34% (10 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 53% (10 of 19) | 45% (5 of 11) |
| Strategy | Joined characters whose unit fought | 54% (29 of 54) | 44% (19 of 43) |
| Strategy | Lone characters that fought | 69% (63 of 91) | 71% (57 of 80) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.2 | 1.6 |
| Movement | Points that never moved of their own | 325.8 | 170.5 |
| Movement | Fights charged into per game | 2.6 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 78, net +75 | 20 of 115, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 78, net +108 | 19 of 115, net +30 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 78, net +25 | 9 of 115, net +158 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 78, net +52 | 28 of 115, net +155 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 12.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (174 of 389) | 48% (213 of 440) |
| Shooting | Points destroyed by shooting units | 72.3 | 62.2 |
| Shooting | War machine shots | 6.4 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (146 of 230) | 52% (48 of 93) |
| Shooting | Points destroyed by war machines | 57.1 | 43.0 |
| Magic | Magic missiles cast | 1.8 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (21 of 63) | 63% (19 of 30) |
| Magic | Wounds caused by magic missiles | 4.1 | 0.9 |
| Magic | Wounds caused by other spells | 2.0 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 86.2 | 34.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.6 / 0.7 / 0.2 | 2.1 / 0.3 / 0.4 / 0.3 |
| Combat | Points destroyed in combat | 307.7 | 380.9 |
| Combat | Points run down | 54.3 | 49.1 |
| Combat | Net points per charged fight, damage counted | +84 | +82 |
| Combat | Net per 100 charger points, damage counted | +33.4 | +29.8 |
| Combat | First round won (charged fights) | 76% | 71% |
| Combat | Net points per charged fight | +72 | +82 |
| Combat | Net points per supported fight / lone fight | +63 / +73 | +166 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 92 | 43 of 128 |
| Game | Points lost | 721.4 | 644.9 |
| Game | VP from objectives | 564.7 | 660.6 |
| Game | Lone holders (player turns) | 2.2 | 3.1 |

- Mine won / drew / lost: 14 / 5 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -110 VP
- The side that went first won 12 of 31 games with a winner
- Points traded per game (both sides' losses): 1366
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: dep-opp-13df7bd-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 7.1 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 18.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +8.0 | 0.0 | 34.3 | 0.6 | +3.7 | 0.0 | 19.6 |
| BEST FACING | 0.9 | +51.3 | 0.0 | 65.1 | 0.8 | +40.0 | 0.0 | 19.0 |
| BEST FIRST | 5.1 | +250.3 | 206.0 | 113.4 | 4.4 | +156.1 | 209.8 | 141.9 |
| BEST OVERALL | 0.7 | +47.7 | 0.0 | 23.5 | 0.8 | +82.3 | 0.0 | 8.2 |
| BEST PREY | 0.8 | +31.6 | 13.8 | 26.2 | 0.6 | +25.9 | 27.5 | 18.6 |
| BEST PRIZE | 0.1 | -10.4 | 1.1 | 13.9 | 0.1 | +4.2 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.1 | 0.0 | 36.7 | 0.2 | +0.2 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 13.4 | 7.0 |
| BLOCKED WHEEL | 0.3 | -4.0 | 0.0 | 4.0 | 0.7 | +5.2 | 0.0 | 12.8 |
| BLOWS WHERE AIMED | 0.2 | +1.5 | 0.0 | 7.5 | 0.3 | -33.0 | 68.9 | 17.4 |
| BOMBING RUN | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 18.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 106.1 | 20.3 | 0.1 | +0.0 | 11.0 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +222.3 | 373.0 | 120.8 | 1.8 | +52.7 | 116.2 | 17.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 8.2 | 0.0 | 0.1 | -4.9 | 17.9 | 12.0 |
| CAST JOB | 0.8 | +9.0 | 8.2 | 23.8 | 0.3 | +8.4 | 36.6 | 28.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +15.6 | 17.5 | 8.9 | 0.3 | +10.7 | 15.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 39.3 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.2 | 13.1 | 0.0 | 0.3 | +0.0 | 0.0 | 1.8 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 153.0 | 75.4 | 2.7 | +0.0 | 283.8 | 186.2 |
| CHARGE NOW WEIGHED | 0.9 | -73.3 | 34.4 | 26.6 | 0.5 | -60.0 | 4.4 | 5.2 |
| CHARGER SLAIN LOST | 0.6 | -16.9 | 51.1 | 34.8 | 0.8 | -29.0 | 83.9 | 25.7 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.2 | +0.0 | 3.1 | 2.7 | 0.1 | +0.0 | 10.1 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 14.2 | 21.7 | 0.4 | +0.0 | 23.8 | 24.0 |
| CONVEYANCE SEARCH | 0.5 | +130.4 | 22.8 | 29.6 | 0.6 | +41.4 | 6.1 | 15.2 |
| COUNTER-CHARGE COVER | 10.9 | +1082.8 | 0.0 | 290.8 | 8.3 | +743.7 | 0.0 | 146.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.4 | 4.0 | 0.0 | 0.1 | +0.7 | 1.5 | 0.0 |
| DEPLOY BY FIGURES | - | - | - | - | 8.1 | +65.6 | 0.0 | 21.8 |
| EDGE GIVE GROUND | 0.1 | +2.5 | 15.1 | 7.1 | 0.4 | +19.9 | 54.7 | 3.5 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +124.9 | 0.0 | 108.7 | 1.7 | +194.4 | 0.0 | 37.8 |
| FALLBACK BY WORTH | 4.8 | +63.0 | 0.0 | 55.9 | 5.6 | +54.1 | 0.0 | 42.4 |
| FIRE AND FLEE | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 162.7 | 5.5 | +0.0 | 0.0 | 143.6 |
| FOCUS FIRE | 0.0 | +0.7 | 0.0 | 5.9 | 0.0 | +0.5 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +79.3 | 0.0 | 27.1 | 0.9 | +137.2 | 0.0 | 30.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +7.7 | 0.0 | 4.6 | 0.2 | +13.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.8 | 13.7 | 0.0 | - | - | - | - |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -8.1 | 5.5 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 11.8 | 0.0 | 0.1 | +0.0 | 26.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 23.0 | 23.0 | 0.3 | +0.0 | 31.6 | 18.6 |
| HILL BY ITS CHANCE | 0.2 | -17.2 | 0.0 | 0.0 | 0.7 | -78.1 | 0.0 | 2.2 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +145.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.6 | -95.1 | 309.1 | 129.2 | 9.4 | -195.4 | 531.0 | 249.6 |
| HUNT ADVANCE | 0.2 | +4.3 | 0.0 | 7.6 | 0.2 | +3.8 | 6.9 | 6.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 6.1 | 0.1 | +0.0 | 5.8 | 1.9 |
| HUNT IN PAIRS | 0.4 | +11.9 | 0.0 | 25.5 | 0.5 | +54.6 | 0.0 | 12.5 |
| HUNT KEPT | 0.1 | +2.4 | 0.0 | 6.2 | 0.1 | +3.7 | 9.2 | 0.0 |
| HUNT RESULT | 0.2 | +3.4 | 0.0 | 6.1 | 0.4 | +67.1 | 15.0 | 8.1 |
| HUNT THE GUNS | 0.2 | +46.6 | 3.3 | 2.9 | 0.4 | +153.6 | 18.5 | 10.1 |
| INVITES THE FIGHT | 1.7 | +36.1 | 51.1 | 33.4 | 0.8 | +14.8 | 35.6 | 1.4 |
| JOINT CHARGE PLAN | 0.0 | +1.1 | 0.0 | 0.0 | 0.2 | +11.0 | 0.0 | 6.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.3 | 0.0 | 0.0 | 0.2 | -6.9 | 13.6 | 26.2 |
| KEEP FALLS | 0.1 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.7 | 0.0 | 12.3 | 0.1 | +1.2 | 6.4 | 0.0 |
| KEEPS ITS TARGET | 1.2 | +35.8 | 96.4 | 28.2 | 2.6 | +76.7 | 228.9 | 66.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +84.8 | 161.6 | 47.3 | 1.9 | +89.5 | 162.3 | 77.1 |
| KILLS COUNT NEXT TURN | 4.2 | +114.3 | 136.3 | 106.1 | 7.0 | +237.1 | 263.1 | 141.5 |
| LANE BY FIGURES | - | - | - | - | 1.0 | +44.1 | 0.0 | 13.7 |
| LONE CHARACTER SAFE SPOT | 0.5 | +25.8 | 9.1 | 1.2 | 0.1 | +1.2 | 13.4 | 10.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 14.6 | 19.4 | 0.2 | +0.0 | 0.0 | 7.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -1.3 | 17.3 | 2.7 | 0.5 | +1.8 | 43.7 | 0.0 |
| LOST CHARGE | 2.8 | -55.7 | 109.5 | 105.5 | 2.5 | -42.7 | 22.5 | 56.4 |
| LURE BY WHAT IT DRAWS | 0.0 | -10.0 | 0.0 | 2.1 | 0.2 | -5.4 | 0.0 | 0.8 |
| MAKE SURE TOGETHER | 0.3 | +16.4 | 5.7 | 1.4 | 1.6 | +85.7 | 8.1 | 43.1 |
| MANOEUVRE | 0.2 | +13.8 | 0.0 | 0.0 | 0.2 | +10.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +9.7 | 0.0 | 8.1 | 0.4 | +12.1 | 0.0 | 14.6 |
| MARCH ODDS | 0.4 | +13.5 | 20.8 | 4.6 | 0.2 | +9.5 | 12.1 | 0.0 |
| MARCH OVER CASTS | 0.4 | +42.0 | 0.0 | 25.0 | 0.4 | +37.0 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 5.3 | +180.5 | 0.0 | 180.9 | 4.8 | +161.3 | 0.0 | 119.3 |
| MISSILES IN THE MOVE | 3.9 | +89.5 | 0.0 | 91.9 | 2.9 | +52.2 | 0.0 | 71.2 |
| MISSILES NEXT TURN | 4.5 | +58.1 | 0.0 | 135.0 | 3.6 | +42.8 | 0.0 | 101.5 |
| MODEL FACING | 0.3 | +79.2 | 0.0 | 3.3 | 0.2 | +51.7 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 13.9 | 0.3 | +0.0 | 0.0 | 10.2 |
| MOVE AND CAST | 0.4 | +16.9 | 0.0 | 0.0 | 0.4 | +15.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.0 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -10.3 | 4.5 | 2.6 | 0.3 | -11.4 | 5.1 | 7.6 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 11.1 | - | - | - | - |
| MOVE TO CHARGE | 2.1 | +135.2 | 69.9 | 40.4 | 4.4 | +271.2 | 176.1 | 101.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +14.5 | 8.1 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.5 | 0.0 | 3.2 | 0.1 | +6.5 | 0.0 | 8.2 |
| NOT NEEDED | 0.2 | -13.5 | 30.3 | 1.5 | 0.2 | -11.3 | 32.9 | 2.4 |
| NOT TURNED | 5.9 | +99.2 | 0.0 | 129.0 | 5.2 | +109.3 | 0.0 | 98.4 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 12.2 | 0.5 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 16.7 | -915.3 | 0.0 | 366.6 | 16.0 | -831.3 | 34.7 | 343.9 |
| OPENS A LANE | 0.2 | +1.1 | 15.9 | 6.5 | 0.0 | +0.5 | 1.5 | 0.0 |
| OPENS UP | 0.1 | +8.6 | 9.2 | 0.0 | 0.1 | +12.0 | 8.4 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.2 | +2.6 | 17.4 | 6.5 | 0.8 | +18.5 | 76.1 | 19.3 |
| PATHS CROSS | 2.0 | +119.8 | 0.0 | 23.6 | 2.8 | +136.2 | 0.0 | 59.9 |
| PERIAPT WORTH | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +1.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.6 | 0.0 | 15.0 | 0.2 | -12.0 | 0.0 | 13.1 |
| PLAN RESULT | 37.8 | +1507.4 | 1246.1 | 972.1 | 41.7 | +1187.3 | 1382.8 | 934.7 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -7.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +15.4 | 0.0 | 28.8 | 1.6 | +26.8 | 0.0 | 17.5 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.1 | 0.0 | 20.0 | 0.2 | -10.3 | 5.8 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.3 | 0.0 | 3.2 | 0.4 | -8.0 | 0.0 | 6.8 |
| REDIRECT COUNTER | 2.3 | +169.9 | 0.0 | 44.8 | 4.1 | +360.3 | 0.0 | 51.8 |
| REDIRECT WEIGHED | 0.3 | +13.2 | 11.0 | 0.0 | 0.3 | +13.9 | 12.8 | 28.4 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 10.9 | 0.4 | +0.0 | 0.0 | 14.2 |
| RESERVE FALL BACK | 0.3 | +7.7 | 0.0 | 2.0 | 1.2 | +57.5 | 0.0 | 13.4 |
| RESTRAINS TO SHOOT | 0.2 | +3.5 | 0.0 | 8.6 | 0.1 | +2.5 | 0.0 | 17.4 |
| RISK BY ARC | 2.1 | +79.5 | 165.7 | 77.8 | 2.7 | +60.0 | 256.0 | 94.8 |
| SAFE SURE CHARGE | 0.1 | -1.6 | 1.7 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.2 | +77.0 | 0.0 | 31.8 | 1.1 | +71.4 | 0.0 | 15.5 |
| SCOUT SPOT | 0.3 | +1.0 | 0.0 | 0.0 | 0.5 | +2.5 | 0.0 | 0.9 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.0 | 0.0 | 0.0 | 0.3 | -20.6 | 0.0 | 1.2 |
| SEARCH SPOT | 2.7 | +118.4 | 0.0 | 46.5 | 3.0 | +143.8 | 0.0 | 31.8 |
| SECOND HUNTER | 0.1 | -0.5 | 0.0 | 2.9 | 0.1 | -0.7 | 8.1 | 2.7 |
| SELF MOVE SPELL | 0.2 | +7.9 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +38.2 | 5.7 | 4.9 | 2.7 | +184.3 | 57.2 | 83.9 |
| SET-UP ANY TARGET | 0.2 | +25.9 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.4 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +33.0 | 49.8 | 0.0 | 0.9 | +30.9 | 39.3 | 15.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 138.8 | 22.1 | 0.8 | +0.0 | 133.8 | 1.8 |
| SHOTS IN THE MOVE | 14.1 | +672.8 | 0.0 | 277.4 | 12.9 | +370.5 | 0.0 | 159.7 |
| SPELL CATCH ODDS | 0.0 | -0.4 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +100.1 | 13.9 | 13.9 | 0.1 | +1.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +13.6 | 48.3 | 52.8 | 1.8 | +23.2 | 67.0 | 48.6 |
| SPELLS IN THE FIGHT | 0.4 | +2.5 | 48.8 | 3.4 | 0.8 | -17.9 | 94.8 | 28.9 |
| STABLE ROLE | 11.7 | +0.0 | 331.8 | 169.6 | 11.7 | +0.0 | 362.7 | 223.1 |
| STANDS TO CAST | 0.0 | +2.1 | 0.0 | 11.1 | 0.1 | +3.6 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +2.3 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| STOPS | 0.1 | +1.9 | 3.3 | 1.4 | 0.3 | +11.5 | 20.7 | 3.1 |
| STOPS SHORT OF THE FLANK | 0.4 | +27.7 | 0.0 | 23.8 | 0.3 | +12.9 | 0.0 | 21.9 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.4 | -52.1 | 286.4 | 111.9 | 7.4 | -67.7 | 350.2 | 128.0 |
| SUPPORTS | 3.8 | +53.7 | 136.8 | 66.6 | 5.4 | +68.8 | 191.5 | 68.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.8 | 9.6 | 0.0 | 0.2 | -6.0 | 11.8 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -1.0 | 5.7 | 1.4 | 0.9 | +1.9 | 0.0 | 39.0 |
| THROUGH LINE OF FIRE | 0.4 | +13.1 | 0.0 | 1.4 | 0.3 | +19.3 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -13.8 | 19.7 | 0.0 | 0.2 | -12.2 | 10.3 | 11.1 |
| TWO OR MORE ARRIVE | 0.1 | +0.9 | 5.7 | 0.0 | 0.6 | +3.6 | 0.0 | 18.5 |
| WAIT AFTER COSTS | 5.7 | -274.1 | 174.9 | 105.5 | 7.6 | -367.3 | 292.9 | 125.5 |
| WALKS TO THE FIGHT | 1.3 | +21.6 | 33.9 | 22.1 | 1.6 | +30.4 | 37.4 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +28.4 | 47.7 | 0.0 | 0.1 | +6.6 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 53.2 | 10.3 | 0.2 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 0.8 | +31.5 | 76.6 | 29.8 | 1.5 | +47.7 | 171.5 | 89.2 |
| WHO HITS BACK | 0.3 | +14.6 | 0.0 | 4.5 | 0.1 | +11.3 | 0.0 | 7.0 |
| WHOLE FIGHT | 0.1 | -0.3 | 22.4 | 0.0 | 0.3 | +23.2 | 39.3 | 2.4 |
| WHOLE FIGHT GAIN | 0.4 | +36.6 | 33.2 | 6.5 | 0.5 | +53.9 | 69.6 | 8.6 |
| WIDER SPREAD | 2.3 | -6.8 | 218.2 | 68.4 | 3.6 | -4.6 | 338.0 | 105.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: dep-opp-13df7bd-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1176 | 1176 | 1176 | 32.67 | -62879 | -53.5 |
| BEST FIRST | 343 | 343 | 343 | 9.53 | +14630 | +42.7 |
| SEARCH SPOT | 205 | 205 | 205 | 5.69 | +9439 | +46.0 |
| DEPLOY BY FIGURES | 292 | 292 | 182 | 5.06 | +2341 | +12.9 |
| COUNTER-CHARGE COVER | 693 | 389 | 179 | 4.97 | +13185 | +73.7 |
| PATHS CROSS | 171 | 171 | 171 | 4.75 | +9214 | +53.9 |
| KILLS COUNT NEXT TURN | 403 | 402 | 137 | 3.81 | +4235 | +30.9 |
| SUPPORTS | 332 | 332 | 131 | 3.64 | +1269 | +9.7 |
| MOVE TO CHARGE | 235 | 234 | 124 | 3.44 | +4813 | +38.8 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +11494 | +98.2 |
| SAFER THAN THE JOB | 83 | 83 | 83 | 2.31 | +5345 | +64.4 |
| ADVANCE LANE KEPT | 77 | 77 | 77 | 2.14 | +0 | +0.0 |
| FALLBACK BY WORTH | 375 | 375 | 76 | 2.11 | +4215 | +55.5 |
| SHOTS IN THE MOVE | 972 | 599 | 68 | 1.89 | +2269 | +33.4 |
| WAIT AFTER COSTS | 476 | 475 | 64 | 1.78 | +1121 | +17.5 |
| CANNON SIGHT KEPT | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| BEST FACING | 60 | 60 | 60 | 1.67 | +3288 | +54.8 |
| SET UP TOGETHER | 119 | 100 | 58 | 1.61 | +3746 | +64.6 |
| FOLLOW UP WEIGHED | 56 | 56 | 56 | 1.56 | +7795 | +139.2 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| BEST OVERALL | 55 | 55 | 55 | 1.53 | +4677 | +85.0 |
| RESERVE FALL BACK | 53 | 53 | 53 | 1.47 | +2347 | +44.3 |
| WALKS TO THE FIGHT | 106 | 106 | 53 | 1.47 | +953 | +18.0 |
| CHARGE NOW WEIGHED | 51 | 51 | 51 | 1.42 | +3510 | +68.8 |
| MAX FOR POSITIONING | 366 | 210 | 50 | 1.39 | +645 | +12.9 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 50 | 1.39 | +1519 | +30.4 |
| SHOT REPLANNED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| CANNON PLANNED TARGET | 243 | 243 | 46 | 1.28 | -475 | -10.3 |
| REDIRECT COUNTER | 230 | 125 | 44 | 1.22 | +3181 | +72.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 69 | 69 | 39 | 1.08 | +1023 | +26.2 |
| RISK BY ARC | 172 | 170 | 38 | 1.06 | +986 | +25.9 |
| KILLS COUNT | 131 | 131 | 37 | 1.03 | +1130 | +30.5 |
| BLOCKED WHEEL | 36 | 36 | 36 | 1.00 | +42 | +1.2 |
| LANE BY FIGURES | 35 | 35 | 35 | 0.97 | +1587 | +45.3 |
| MISSILES IN THE MOVE | 246 | 141 | 35 | 0.97 | +420 | +12.0 |
| MARCH CHECK | 37 | 34 | 34 | 0.94 | +1276 | +37.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARGE NOW FIRST | 167 | 167 | 30 | 0.83 | -1504 | -50.1 |
| SHOOTERS IN TWO RANKS | 28 | 28 | 28 | 0.78 | +63 | +2.2 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| KEEPS ITS TARGET | 135 | 133 | 27 | 0.75 | +415 | +15.4 |
| MOVE AND CAST | 26 | 26 | 26 | 0.72 | +1171 | +45.0 |
| STOPS SHORT OF THE FLANK | 26 | 26 | 26 | 0.72 | +1463 | +56.3 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +1165 | +48.5 |
| MAKE SURE TOGETHER | 69 | 44 | 22 | 0.61 | +1318 | +59.9 |
| HONEST WORTH | 573 | 568 | 21 | 0.58 | +168 | +8.0 |
| INVITES THE FIGHT | 92 | 92 | 21 | 0.58 | +283 | +13.5 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1131 | +53.9 |
| WHOLE FIGHT GAIN | 33 | 32 | 21 | 0.58 | +1219 | +58.0 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +182 | +9.6 |
| HOLDER AT DEPLOYMENT | 33 | 33 | 18 | 0.50 | +861 | +47.8 |
| MODEL FACING | 18 | 18 | 18 | 0.50 | +4712 | +261.8 |
| BEST PREY | 51 | 51 | 16 | 0.44 | +526 | +32.9 |
| CAST JOB | 40 | 40 | 16 | 0.44 | +165 | +10.3 |
| CASTING BLOCK | 21 | 21 | 16 | 0.44 | +244 | +15.2 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -6 | -0.4 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +777 | +48.5 |
| WEARS DOWN | 83 | 81 | 16 | 0.44 | +441 | +27.6 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +569 | +35.6 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MANOEUVRE | 14 | 14 | 14 | 0.39 | +865 | +61.8 |
| PIVOT GUARDS FLANK | 14 | 14 | 14 | 0.39 | -561 | -40.1 |
| REFUSING RETIRES | 24 | 24 | 14 | 0.39 | +1 | +0.1 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | +8 | +0.6 |
| HUNT IN PAIRS | 34 | 23 | 13 | 0.36 | +868 | +66.7 |
| SURE CHARGE BEATS ADVANCE | 12 | 12 | 12 | 0.33 | -389 | -32.4 |
| WAR ENGINE JOBS | 31 | 31 | 11 | 0.31 | -280 | -25.4 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +216 | +21.6 |
| LOST CHARGE | 190 | 190 | 9 | 0.25 | +200 | +22.2 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 10 | 9 | 7 | 0.19 | +202 | +28.9 |
| SUPPORT NARROWED | 461 | 461 | 7 | 0.19 | -133 | -19.0 |
| WAR ENGINE CHARGES | 12 | 12 | 7 | 0.19 | +426 | +60.9 |
| WHOLE FIGHT | 16 | 16 | 7 | 0.19 | +360 | +51.4 |
| BACKUP TARGETS | 60 | 32 | 6 | 0.17 | +9 | +1.6 |
| MISSILES NEXT TURN | 293 | 170 | 6 | 0.17 | +25 | +4.1 |
| WIDER SPREAD | 211 | 203 | 6 | 0.17 | +29 | +4.9 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.1 |
| EDGE GIVE GROUND | 19 | 19 | 5 | 0.14 | +183 | +36.7 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +243 | +48.7 |
| OVERRUNS AWAY | 38 | 38 | 5 | 0.14 | +59 | +11.9 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -266 | -53.2 |
| SPELLS IN THE FIGHT | 43 | 42 | 5 | 0.14 | +95 | +18.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -498 | -124.6 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| HUNT ADVANCE | 12 | 12 | 4 | 0.11 | +26 | +6.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +123 | +30.8 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -2 | -0.5 |
| SURE REACH TOGETHER | 45 | 31 | 4 | 0.11 | +69 | +17.2 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +39 | +12.9 |
| LONG SHOT | 37 | 37 | 3 | 0.08 | +46 | +15.3 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +164 | +54.5 |
| STOPS | 13 | 13 | 3 | 0.08 | +74 | +24.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +45 | +22.7 |
| CHARGER SLAIN LOST | 47 | 46 | 2 | 0.06 | +49 | +24.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +44 | +21.8 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 2 | 0.06 | -12 | -6.2 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +125 | +62.6 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -58 | -29.0 |
| BLOWS WHERE AIMED | 18 | 16 | 1 | 0.03 | +128 | +127.5 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -3 | -3.4 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.03 | -175 | -175.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -17 | -17.4 |
| DEFENSIVE ARMY | 5 | 5 | 1 | 0.03 | -13 | -13.0 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +4 | +4.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +4 | +3.9 |
| JOINT CHARGE PLAN | 10 | 10 | 1 | 0.03 | +20 | +20.3 |
| OPENS A LANE | 7 | 4 | 1 | 0.03 | +7 | +7.0 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +95 | +94.9 |
| REDIRECT BY WHAT IT STOPS | 19 | 19 | 1 | 0.03 | +115 | +115.3 |
| TURN WORTH | 13 | 13 | 1 | 0.03 | +23 | +22.9 |
| TWO OR MORE ARRIVE | 27 | 23 | 1 | 0.03 | +8 | +8.1 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -18 | -18.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 30 | 30 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 11 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 40 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 423 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 33 | 33 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 20 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 8 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 402 | 402 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2861 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SECOND HUNTER | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 90 | not checked | - | - | - | - |
| STABLE ROLE | 842 | 840 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.14 | 14.00 | 55.4 |
| FALLBACK | gate | 0.72 | 0.81 | 39.0 |
| TURN GATE | gate | 0.36 | 0.56 | 42.0 |
| CHARGE NOW FIRST | rule | 0.42 | 0.39 | 51.9 |
| PATHS CROSS | rule | 0.17 | 0.22 | 43.8 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.25 | 40.1 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.14 | 49.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.17 | 35.3 |
| WAR ENGINE JOBS | rule | 0.22 | 0.08 | 25.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.11 | 52.4 |
| AFTERMATH BAND | gate | 0.17 | 0.08 | 1.7 |
| BLOCKED WHEEL | rule | 0.08 | 0.17 | 45.2 |
| CHARGE NOW WEIGHED | rule | 0.19 | 0.06 | 21.0 |
| NO REASON | gate | - | 0.19 | 8.4 |
| SUPPORT NARROWED | rule | 0.17 | 0.03 | 19.0 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 5.8 |
| MARCH ODDS | rule | 0.08 | 0.08 | 11.0 |
| SUPPORT REQUEST | gate | - | 0.17 | 103.1 |
| FIGHT ORDER BAND | gate | 0.11 | 0.03 | 2.6 |
| PURSUES BIG PREY | rule | - | 0.14 | 53.2 |
| BEST PRIZE | rule | 0.06 | 0.06 | 124.6 |
| CHAFF PASSED | rule | 0.08 | - | 2.0 |
| REFUSING RETIRES | rule | 0.06 | 0.03 | 0.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 6.9 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 45.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 20.9 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 2.9 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 6.3 |
| SAFE SURE CHARGE | rule | 0.06 | - | 29.0 |
| STANDS TO CAST | rule | - | 0.06 | 39.7 |
| WHO HITS BACK | rule | 0.06 | - | 3.4 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 3.4 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 175.1 |
| CATCH ODDS | rule | - | 0.03 | 17.4 |
| DEFENSIVE ARMY | rule | 0.03 | - | 13.0 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 0.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 12.5 |
| LONG SHOT | rule | 0.03 | - | 10.8 |
| REDIRECT WEIGHED | rule | - | 0.03 | 94.8 |
| SAFER THAN THE JOB | rule | 0.03 | - | 1.8 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 18.5 |

### Plans: dep-opp-13df7bd-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.1 | 15% | 486 | 336 | 69% |
| Mine | charge | 2.9 | 50% | 176 | 220 | 125% |
| Mine | close in | 3.3 | 25% | 170 | 137 | 81% |
| Mine | hold | 4.9 | 37% | 357 | 0 | 0% |
| Mine | join | 0.8 | 90% | 23 | 0 | 0% |
| Mine | shoot | 8.7 | 68% | 301 | 814 | 271% |
| Mine | support | 4.0 | 88% | 36 | 0 | 0% |
| Opponent | advance | 13.5 | 15% | 325 | 248 | 76% |
| Opponent | charge | 4.1 | 58% | 363 | 406 | 112% |
| Opponent | close in | 6.1 | 24% | 366 | 135 | 37% |
| Opponent | hold | 5.0 | 48% | 374 | 0 | 0% |
| Opponent | join | 1.0 | 97% | 37 | 0 | 0% |
| Opponent | shoot | 5.9 | 65% | 121 | 399 | 330% |
| Opponent | support | 6.0 | 92% | 55 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 17% | 17% | 0% | 2.0 | 280 | 20 | 17% | 55 |
| Opponent | 0.4 | 14 | 0 | 36% | 43% | 7% | 2.3 | 395 | 173 | 43% | 71 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 20% | 20% | 0% | 2.0 | 287 | 24 | 20% | 123 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 230 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 75 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 245 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 100% | 100% | 0% | 2.5 | 560 | 444 | 100% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Tomb Kings of Khemri | 0.4 | 2 | 0 | 0% | 0% | 0% | - | 154 | 0 | 0% | 28 |
| Vampire Counts | 0.3 | 3 | 0 | 0% | 0% | 33% | - | 405 | 2 | 0% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 465 | 0 | 0% | 29 |
| Wood Elf Realms | 0.6 | 4 | 0 | 25% | 50% | 0% | 2.0 | 325 | 159 | 50% | 88 |

### Battle groups: dep-opp-13df7bd-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.9 | 23% | 58% | 8% | 57% | 45% | 14% | 8% | 32% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 24% | 65% | 10% | 0% | 22% | 0% | 6% | 72% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.3 | 16% | 50% | 15% | 14% | 29% | 17% | 10% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 25% | 59% | 8% | 33% | 29% | 0% | 0% | 71% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 51 | 20% | 6.0 | 0 (1) | 0 (4) | - | - | 0 (5) |
| Mine | Chaff | 37 | 42 (37) | 8 | 34 | 70 | 32% | 3.1 | 88 (13) | 19 (16) | 29 (8) | 62 (21) | 18 (16) |
| Mine | Character | 123 | 39 (123) | 39 | 0 | 29 | 17% | 2.5 | 47 (36) | 36 (60) | 38 (13) | 52 (55) | 28 (54) |
| Mine | Clean-up | 18 | 87 (18) | 45 | 42 | 24 | 39% | 2.4 | 208 (5) | 44 (8) | 43 (5) | 101 (13) | 56 (5) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 47 | 50 (47) | 25 | 25 | 64 | 26% | 2.6 | 33 (21) | 90 (17) | 33 (9) | 51 (32) | 47 (15) |
| Mine | Fragile | 5 | 9 (5) | 9 | 0 | 60 | 0% | 1.2 | - | 0 (3) | 23 (2) | 9 (5) | - |
| Mine | Hammer | 56 | 37 (56) | 28 | 9 | 30 | 20% | 2.4 | 20 (14) | 43 (33) | 44 (9) | 37 (33) | 38 (23) |
| Mine | Holder | 29 | 52 (29) | 1 | 50 | 32 | 34% | 3.6 | 32 (11) | 83 (11) | 24 (7) | 73 (20) | 3 (9) |
| Mine | Shooter | 42 | 89 (42) | 35 | 54 | 35 | 5% | 1.6 | 62 (5) | 94 (31) | 86 (6) | 105 (24) | 68 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 36 (59) | 36 | 0 | 55 | 2% | 1.3 | 7 (12) | 45 (36) | 33 (11) | 18 (11) | 40 (48) |
| Mine | Wizard | 22 | 1 (22) | 1 | 0 | 53 | 23% | 2.3 | 0 (9) | 0 (6) | 6 (3) | 3 (6) | 0 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 111 (76) | 25 | 86 | 41 | 33% | 2.7 | 133 (25) | 108 (32) | 88 (19) | 121 (63) | 48 (13) |
| Opponent | Character | 96 | 53 (96) | 53 | 0 | 38 | 18% | 2.4 | 65 (34) | 41 (38) | 68 (18) | 58 (57) | 52 (33) |
| Opponent | Clean-up | 21 | 20 (21) | 3 | 17 | 65 | 24% | 2.6 | 31 (7) | 18 (10) | 0 (4) | 20 (16) | 21 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 6.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 47 | 26 (47) | 22 | 4 | 38 | 19% | 2.5 | 24 (18) | 26 (21) | 30 (8) | 31 (23) | 20 (24) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 80% | 1.0 | 0 (1) | 0 (1) | 0 (3) | 0 (3) | 0 (2) |
| Opponent | Hammer | 70 | 26 (70) | 21 | 6 | 32 | 30% | 2.7 | 40 (20) | 27 (37) | 3 (13) | 30 (41) | 22 (29) |
| Opponent | Holder | 35 | 73 (35) | 5 | 68 | 13 | 29% | 3.5 | 45 (7) | 71 (21) | 132 (6) | 84 (23) | 55 (11) |
| Opponent | Shooter | 32 | 96 (32) | 41 | 56 | 28 | 3% | 1.5 | 121 (9) | 103 (19) | 6 (4) | 116 (20) | 70 (12) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 70 (24) | 70 | 0 | 22 | 4% | 1.3 | 58 (7) | 104 (10) | 38 (7) | 0 (3) | 80 (21) |
| Opponent | Wizard | 27 | 7 (27) | 7 | 0 | 19 | 7% | 1.9 | 0 (13) | 0 (10) | 9 (1) | 1 (13) | 0 (11) |

### Charged fights: dep-opp-13df7bd-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 49 | 171 | 1.2 | 1.2 | 137 | 0 | +137 | 4 of 5 | 5 of 5 | +0 | +171 |
| Mine | Chaos Dwarfs | 4 | 207 | 484 | 3.0 | 1.1 | 161 | 5 | +156 | 6 of 12 | 10 of 12 | +254 | +147 |
| Mine | Dwarfen Mountain Holds | 4 | 388 | 28 | 2.2 | 1.1 | 12 | 33 | -21 | 1 of 9 | 6 of 9 | +0 | -23 |
| Mine | Empire of Man | 5 | 425 | 18 | 1.2 | 1.0 | 15 | 45 | -30 | 3 of 6 | 4 of 6 | - | -30 |
| Mine | Grand Cathay | 4 | 298 | 207 | 3.0 | 1.0 | 69 | 18 | +51 | 2 of 12 | 11 of 12 | - | +51 |
| Mine | High Elf Realms | 4 | 203 | 418 | 4.0 | 1.2 | 105 | 31 | +74 | 9 of 16 | 13 of 16 | +78 | +73 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1569 | 4.0 | 1.0 | 392 | 0 | +392 | 2 of 4 | 4 of 4 | - | +392 |
| Mine | Lizardmen | 1 | 45 | 308 | 2.0 | 1.0 | 154 | 0 | +154 | 1 of 2 | 1 of 2 | - | +154 |
| Mine | Ogre Kingdoms | 1 | 422 | 60 | 3.0 | 1.0 | 20 | 0 | +20 | 0 of 3 | 2 of 3 | - | +20 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 391 | 5.0 | 1.0 | 78 | 42 | +36 | 1 of 5 | 4 of 5 | - | +36 |
| Mine | Skaven | 2 | 0 | 130 | 2.5 | 1.2 | 52 | 84 | -32 | 3 of 5 | 2 of 5 | +116 | -69 |
| Mine | Tomb Kings of Khemri | 1 | 240 | 534 | 4.0 | 1.0 | 134 | 30 | +103 | 1 of 4 | 2 of 4 | - | +103 |
| Mine | Vampire Counts | 3 | 68 | 141 | 2.3 | 1.3 | 60 | 6 | +54 | 0 of 7 | 6 of 7 | +63 | +50 |
| Mine | Warriors of Chaos | 1 | 144 | 0 | 2.0 | 1.5 | 0 | 49 | -49 | 0 of 2 | 0 of 2 | -98 | +0 |
| **Mine** | all armies | 36 | 216 | 246 | 2.6 | 1.1 | 96 | 24 | +72 | 33 of 92 | 70 of 92 | +63 | +73 |
| Opponent | Dwarfen Mountain Holds | 2 | 274 | 42 | 2.0 | 1.2 | 21 | 15 | +6 | 1 of 4 | 3 of 4 | -60 | +28 |
| Opponent | Empire of Man | 2 | 614 | 383 | 4.5 | 1.3 | 85 | 12 | +73 | 1 of 9 | 7 of 9 | +160 | +48 |
| Opponent | Grand Cathay | 2 | 286 | 322 | 3.0 | 1.2 | 107 | 0 | +107 | 2 of 6 | 5 of 6 | +138 | +101 |
| Opponent | Kingdom of Bretonnia | 1 | 270 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | Ogre Kingdoms | 3 | 83 | 295 | 4.7 | 1.1 | 63 | 11 | +52 | 4 of 14 | 6 of 14 | +0 | +56 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 188 | 731 | 3.8 | 1.4 | 195 | 136 | +59 | 7 of 15 | 11 of 15 | +140 | +30 |
| Opponent | Vampire Counts | 6 | 63 | 641 | 4.0 | 1.3 | 160 | 12 | +149 | 8 of 24 | 20 of 24 | +232 | +107 |
| Opponent | Warriors of Chaos | 8 | 0 | 280 | 2.5 | 1.1 | 112 | 61 | +51 | 10 of 20 | 12 of 20 | +152 | +33 |
| Opponent | Wood Elf Realms | 7 | 148 | 576 | 4.7 | 1.1 | 122 | 32 | +90 | 10 of 33 | 24 of 33 | +190 | +84 |
| **Opponent** | all armies | 36 | 140 | 428 | 3.6 | 1.2 | 120 | 38 | +82 | 43 of 128 | 91 of 128 | +166 | +65 |

### Effective charges: dep-opp-13df7bd-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 1 (net +0) | 1 (net +120) | 0 | 3 (net +188) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 12 | 1 (net +509) | 0 | 1 (net +540) | 6 (net +111) | 0 | 4 (net +39) | 0 | 8% (1 of 12) |
| Mine | Dwarfen Mountain Holds | 9 | 1 (net +0) | 0 | 2 (net -30) | 1 (net +0) | 0 | 4 (net -2) | 1 | 25% (2 of 8) |
| Mine | Empire of Man | 6 | 1 (net -81) | 0 | 0 | 2 (net -94) | 0 | 2 (net +46) | 1 | 0% (0 of 5) |
| Mine | Grand Cathay | 12 | 1 (net -217) | 0 | 2 (net +117) | 3 (net +91) | 2 (net +20) | 4 (net +70) | 0 | 17% (2 of 12) |
| Mine | High Elf Realms | 16 | 0 | 0 | 3 (net -51) | 2 (net +320) | 0 | 6 (net +13) | 5 | 27% (3 of 11) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 3 (net +455) | 1 (net +205) | 0 | 0 | 0 | 75% (3 of 4) |
| Mine | Lizardmen | 2 | 1 (net +233) | 0 | 0 | 1 (net +75) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 1 (net +236) | 4 | 0% (0 of 1) |
| Mine | Skaven | 5 | 2 (net -105) | 0 | 2 (net -33) | 0 | 0 | 1 (net +116) | 0 | 40% (2 of 5) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net +432) | 0 | 2 (net -10) | 0 | 0 | 0 | 1 | 67% (2 of 3) |
| Mine | Vampire Counts | 7 | 2 (net +40) | 0 | 0 | 3 (net +99) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net -98) | 0 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 4 | 1 (net -60) | 0 | 1 (net +0) | 1 (net +85) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 9 | 0 | 0 | 2 (net +0) | 5 (net +131) | 0 | 1 (net +0) | 1 | 25% (2 of 8) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 0 | 5 (net +88) | 0 | 1 (net +202) | 0 | 0% (0 of 6) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 2 (net +0) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Ogre Kingdoms | 14 | 4 (net +114) | 0 | 1 (net +0) | 3 (net +128) | 0 | 1 (net +45) | 5 | 11% (1 of 9) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 5 (net -62) | 0 | 2 (net +115) | 4 (net +80) | 1 (net +162) | 1 (net +400) | 2 | 15% (2 of 13) |
| Opponent | Vampire Counts | 24 | 3 (net -27) | 1 (net -45) | 5 (net +237) | 8 (net +146) | 4 (net +157) | 3 (net +240) | 0 | 21% (5 of 24) |
| Opponent | Warriors of Chaos | 20 | 2 (net -15) | 0 | 5 (net -147) | 4 (net +0) | 0 | 6 (net +188) | 3 | 29% (5 of 17) |
| Opponent | Wood Elf Realms | 33 | 5 (net +7) | 1 (net +186) | 1 (net -102) | 7 (net +55) | 4 (net +159) | 13 (net +141) | 2 | 3% (1 of 31) |

### Charged fights, damage counted: dep-opp-13df7bd-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 168 | 248 | +75 | 174 | 72 | +101 | +60.3 |
| Mine | Effective (55-75%) | 17 | 250 | 209 | +108 | 152 | 58 | +94 | +37.6 |
| Mine | 76-89% | 20 | 266 | 187 | +104 | 128 | 31 | +97 | +36.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 269 | 161 | +52 | 107 | 22 | +85 | +31.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 396 | 96 | +25 | 34 | 0 | +34 | +8.5 |
| Mine | No odds | 14 | 214 | 152 | +32 | 94 | 42 | +52 | +24.2 |
| Mine | All fights | 92 | 251 | 181 | +72 | 122 | 38 | +84 | +33.4 |
| Opponent | Long shot (under 50%) | 20 | 290 | 276 | +0 | 140 | 138 | +2 | +0.8 |
| Opponent | 50-54% | 2 | 74 | 144 | +70 | 93 | 22 | +70 | +95.9 |
| Opponent | Effective (55-75%) | 19 | 241 | 197 | +30 | 92 | 70 | +22 | +9.0 |
| Opponent | 76-89% | 37 | 273 | 165 | +93 | 150 | 52 | +98 | +36.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 266 | 184 | +155 | 172 | 17 | +155 | +58.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 491 | 118 | +158 | 165 | 7 | +158 | +32.1 |
| Opponent | No odds | 13 | 203 | 214 | +45 | 101 | 65 | +37 | +18.0 |
| Opponent | All fights | 128 | 274 | 192 | +82 | 140 | 58 | +82 | +29.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p2 | move | 454 | 91 (20%) | 77 (17%) | 45 (10%) | 318 (70%) |
| dep-opp-13df7bd-p2 | objective | 339 | 50 (15%) | 40 (12%) | 38 (11%) | 251 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

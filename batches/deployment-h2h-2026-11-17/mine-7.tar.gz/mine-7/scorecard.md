# Doctrine scorecard: dep-mine-13df7bd-p7

### Scorecard: dep-mine-13df7bd-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0112 | 4 | 1 | Mine | yes | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0112 | 4 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L0128 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0212 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0212 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0228 | 6 | 1 | Mine | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0313 | 1 | 1 | Opponent | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0329 | 5 | 1 | Mine | no | - | 4 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0329 | 5 | 1 | Opponent | yes | - | 2 | 4 | 6 | 1 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 112 |
| L0415 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 881 |
| L0518 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 370 |
| L0535 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 666 |
| L0535 | 1 | 1 | Opponent | yes | 6 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0622 | 4 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 1014 |
| L0622 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 2 | 0 | 0 | 297 |
| L0711 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 558 |
| L0711 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 427 |
| L0727 | 1 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0727 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0817 | 1 | 1 | Mine | no | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 769 |
| L0817 | 1 | 1 | Opponent | yes | 2 | 3 | 2 | 1 | 4 | 0 | 0 | 0 |
| L0833 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0833 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0924 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 524 |
| L0924 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1015 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 456 |
| L1015 | 1 | 1 | Opponent | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1032 | 6 | 1 | Mine | no | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1032 | 6 | 1 | Opponent | no | 4 | 3 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1124 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 2 | 0 | 0 | 330 |
| L1124 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1218 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 1 | 0 | 0 | 330 |
| L1218 | 6 | 1 | Opponent | no | 4 | 4 | 5 | 3 | 2 | 0 | 0 | 470 |
| L1234 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 697 |
| L1234 | 4 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 1 | 0 | 0 | 216 |
| L1329 | 3 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1329 | 3 | 1 | Opponent | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 170 |
| L1424 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1424 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1521 | 3 | 1 | Mine | no | 4 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1521 | 3 | 1 | Opponent | no | 1 | - | 1 | 4 | 0 | 0 | 0 | 355 |
| L1618 | 4 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1618 | 4 | 1 | Opponent | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L1635 | 3 | 1 | Mine | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 200 |
| L1635 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1734 | 6 | 1 | Mine | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1734 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1833 | 3 | 1 | Mine | no | 5 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1833 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1934 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1934 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2035 | 1 | 1 | Mine | no | 3 | - | 3 | 3 | 1 | 0 | 0 | 0 |
| L2035 | 1 | 1 | Opponent | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2225 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2225 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2329 | 1 | 1 | Mine | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 60 |
| L2329 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L2435 | 5 | 1 | Mine | yes | - | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2435 | 5 | 1 | Opponent | no | - | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L2632 | 4 | 1 | Mine | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 60 |
| L2632 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L2834 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2834 | 2 | 1 | Opponent | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L3135 | 3 | 1 | Mine | no | 4 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L3135 | 3 | 1 | Opponent | no | 1 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 2.4 | 2.6 | 2.2 | 1.2 | 0.3 | 0.0 | 0.0 | 285.6 |
| **Average** | | | Opponent | 17% | 2.3 | 2.4 | 2.9 | 1.7 | 0.4 | 0.0 | 0.0 | 109.0 |

### KPIs: dep-mine-13df7bd-p7

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (50 of 177) | 1% (1 of 182) | 14% (51 of 359) |
| Winner chose to follow up after the loser gave ground |  | 96% (46 of 48); on the table 96% | 98% (49 of 50); on the table 98% | 97% (95 of 98); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (12 of 15); on the table 87% | 100% (18 of 18); on the table 100% | 91% (30 of 33); on the table 94% |
| Winner chose to pursue after the loser fled |  | 72% (21 of 29); on the table 79% | 69% (29 of 42); on the table 76% | 70% (50 of 71); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 86% (79 of 92); on the table 89% | 87% (96 of 110); on the table 90% | 87% (175 of 202); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 36% (122 of 342) | 35% (55 of 156) | 36% (177 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (122 of 245) | 43% (55 of 129) | 47% (177 of 374) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (17 of 32) | 51% (25 of 49) | 52% (42 of 81) |
| Points that never fought | lower | 39% (27661 of 71555) | 40% (28920 of 71977) | 39% (56581 of 143532) |
|   infantry points that never fought | lower | 49% (7316 of 15035) | 57% (7869 of 13842) | 53% (15185 of 28877) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (150 of 282) | 62% (181 of 294) | 57% (331 of 576) |
| Bound items with a magic missile used (at least once a game) |  | 91% (21 of 23); 2.1 uses a game | 85% (22 of 26); 2.0 uses a game | 88% (43 of 49); 2.0 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.5 uses a game | 100% (2 of 2); 0.1 uses a game | 62% (10 of 16); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (13 of 21); 0.4 uses a game | 40% (4 of 10); 0.1 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (30145 of 61235) | 57% (37281 of 65839) | 53% (67426 of 127074) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (20%) | 0.8 (28%) | 2.0 (23%) |
| MARCHED: its unit marched | 1.7 (28%) | 0.6 (22%) | 2.3 (26%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.4 (14%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.4 (14%) | 0.5 (6%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.1 (18%) | 0.2 (9%) | 1.4 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 2.1 | 1.9 | 4.9 | 0.6 | 1.5 |
| not cast | 3.2 | 4.2 | 2.8 | 8.9 | 1.8 | 21.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (40%) | 0.1 (2%) | 2.0 (23%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (26%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.5 (12%) | 0.4 (16%) | 1.8 (20%) | 0.2 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (12%) | 0.6 (14%) | 0.4 (14%) | 0.5 (6%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.2 (5%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.8 (4%) |
| GONE: slain | 0.8 (23%) | 0.7 (16%) | 0.6 (23%) | 1.4 (15%) | 0.1 (3%) | 3.0 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.2 (5%) | 0.2 (8%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.5 (27%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (52%) | 0.2 (5%) | 0.9 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.6 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 1.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 59% (16 of 27) | 68% (19 of 28) | 64% (35 of 55) |
| the unit moved after it | 81% (13 of 16) | 53% (10 of 19) | 66% (23 of 35) |
| it charged on its next turn | 6% (1 of 16) | 0% (0 of 19) | 3% (1 of 35) |
| the enemy charged it first | 25% (4 of 16) | 11% (2 of 19) | 17% (6 of 35) |
| it fought by the end of its next turn | 0% (0 of 16) | 0% (0 of 19) | 0% (0 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 16) | 11% (2 of 19) | 11% (4 of 35) |
| none of these (no charge, no fight, no charge escaped) | 56% (9 of 16) | 79% (15 of 19) | 69% (24 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (547 of 847) | 55% (381 of 692) | 60% (928 of 1539) |
|   cavalry | 63% (52 of 82) | 66% (112 of 169) | 65% (164 of 251) |
|   character | 45% (41 of 92) | 24% (35 of 144) | 32% (76 of 236) |
|   chariot | 43% (41 of 95) | 78% (31 of 40) | 53% (72 of 135) |
|   infantry | 56% (131 of 233) | 58% (157 of 272) | 57% (288 of 505) |
|   monster | 52% (17 of 33) | 64% (18 of 28) | 57% (35 of 61) |
|   war machine | 85% (265 of 312) | 72% (28 of 39) | 83% (293 of 351) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (29%) | 2.4 (28%) | 4.8 (28%) |
| CHARGED: it charged | 1.2 (14%) | 2.2 (26%) | 3.4 (20%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.3 (4%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.3 (16%) | 1.3 (15%) | 2.6 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (5%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (14%) | 1.4 (17%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (1%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.5 | 81% | 4.5 pts | 33 pts |
| character | 2.4 | 0.4 | 87% | 4.0 pts | 10 pts |
| chariot | 2.0 | 1.4 | 71% | 16.7 pts | 33 pts |
| infantry | 11.5 | 3.9 | 75% | 8.3 pts | 96 pts |
| monster | 1.1 | 0.2 | 87% | 4.6 pts | 5 pts |
| war machine | 8.1 | 7.5 | 59% | 31.9 pts | 259 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.9 | 4.9 |
| Charges that made contact a game | 2.9 | 4.2 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.48 contact (23 units) | 0.46 declared, 0.38 contact (13 units) | 0.58 declared, 0.44 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.17 declared, 0.00 contact (6 units) | 0.73 declared, 0.55 contact (11 units) | 0.53 declared, 0.35 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.39 contact (237 units) | 0.66 declared, 0.47 contact (299 units) | 0.60 declared, 0.43 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (40 of 82) | 78% (14 of 18) | 33% (4 of 12) | 52% (58 of 112) |
| Character in a unit | 83% (24 of 29) | 60% (12 of 20) | 50% (2 of 4) | 72% (38 of 53) |
| Character on its own | 75% (21 of 28) | 56% (25 of 45) | 40% (29 of 72) | 52% (75 of 145) |
| Chariot | 82% (14 of 17) | 45% (5 of 11) | - | 68% (19 of 28) |
| Infantry | 52% (43 of 83) | 42% (16 of 38) | 67% (2 of 3) | 49% (61 of 124) |
| Monster | 74% (20 of 27) | 57% (4 of 7) | - | 71% (24 of 34) |
| Monstrous | 83% (19 of 23) | 58% (7 of 12) | - | 74% (26 of 35) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (4 of 4); on the table 100% | 30% (31 of 102) | 42% | 64% (14 of 22) | 83% (5 of 6); 4.0 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 71% (5 of 7); on the table 71% | 47% (14 of 30) | 47% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 48% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 71% (5 of 7); on the table 100% | 67% (8 of 12) | 57% | 58% (30 of 52) | 0.0 uses a game | 50% (1 of 2); 1.4 uses a game | 75% (3 of 4); 0.6 uses a game |
| Grand Cathay | 8 | 87% (26 of 30); on the table 90% | 42% (76 of 180) | 39% | 53% (38 of 72) | 95% (19 of 20); 8.4 uses a game | 50% (1 of 2); 0.1 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 6 | 92% (12 of 13); on the table 92% | 21% (5 of 24) | 40% | 41% (19 of 46) | 88% (7 of 8); 3.7 uses a game | 60% (6 of 10); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 83% (5 of 6); on the table 83% | - | 38% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 2 | 92% (12 of 13); on the table 92% | - | 42% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 67% (10 of 15); on the table 73% | 0% (0 of 24) | 42% | 64% (18 of 28) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 0% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 88% (7 of 8); on the table 88% | 17% (2 of 12) | 29% | 50% (8 of 16) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 92% (11 of 12); on the table 92% | - | 31% | 53% (8 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 89% (24 of 27); on the table 93% | 31% (15 of 48) | 37% | 71% (32 of 45) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 93% (27 of 29); on the table 97% | 29% (7 of 24) | 33% | 53% (41 of 78) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 11 | 92% (22 of 24); on the table 92% | 50% (15 of 30) | 40% | 64% (72 of 112) | 67% (6 of 9); 2.2 uses a game | 0.0 uses a game | 50% (3 of 6); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p7, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (46) | 33% (16) | 43% (62) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.33 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.03 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.28 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.06 | 1.58 | 3.64 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.17 | 0.89 | 2.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.83 | 5.94 | 11.78 |

### Quality by phase: dep-mine-13df7bd-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.4 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 52% (62 of 119) | 46% (84 of 181) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (168 of 376) | 38% (84 of 220) |
| Strategy | Close-in objectives charged next turn | 14% (23 of 165) | 14% (31 of 214) |
| Strategy | Support requests answered (helper made contact too) | 64% (9 of 14) | 48% (14 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 43% (9 of 21) | 65% (11 of 17) |
| Strategy | Joined characters whose unit fought | 47% (21 of 45) | 45% (13 of 29) |
| Strategy | Lone characters that fought | 75% (74 of 99) | 69% (52 of 75) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 285.6 | 109.0 |
| Movement | Fights charged into per game | 2.4 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 75, net +342 | 21 of 108, net +53 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 75, net +105 | 15 of 108, net +97 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 75, net +113 | 13 of 108, net +73 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 75, net +123 | 31 of 108, net +132 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.4 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (126 of 304) | 46% (182 of 394) |
| Shooting | Points destroyed by shooting units | 43.4 | 35.9 |
| Shooting | War machine shots | 7.4 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (129 of 265) | 25% (7 of 28) |
| Shooting | Points destroyed by war machines | 133.9 | 10.7 |
| Magic | Magic missiles cast | 2.1 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (32 of 75) | 51% (18 of 35) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.5 |
| Magic | Wounds caused by other spells | 1.6 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 124.6 | 20.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.6 / 0.7 / 0.1 | 1.6 / 0.5 / 0.4 / 0.3 |
| Combat | Points destroyed in combat | 268.0 | 368.5 |
| Combat | Points run down | 56.4 | 82.8 |
| Combat | Net points per charged fight, damage counted | +101 | +110 |
| Combat | Net per 100 charger points, damage counted | +33.4 | +37.4 |
| Combat | First round won (charged fights) | 79% | 74% |
| Combat | Net points per charged fight | +97 | +100 |
| Combat | Net points per supported fight / lone fight | +124 / +92 | +164 / +85 |
| Combat | Charged fights on a top-3 enemy unit | 19 of 87 | 61 of 126 |
| Game | Points lost | 585.6 | 685.6 |
| Game | VP from objectives | 648.1 | 538.3 |
| Game | Lone holders (player turns) | 2.4 | 2.3 |

- Mine won / drew / lost: 20 / 6 / 10 of 36 ended games (of 36); mean margin (Mine - Opponent) +211 VP
- The side that went first won 17 of 30 games with a winner
- Points traded per game (both sides' losses): 1271
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 2.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 5.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +9.4 | 0.0 | 28.7 | 0.7 | +9.2 | 0.0 | 23.6 |
| BEST FACING | 0.9 | +44.7 | 0.0 | 11.7 | 0.7 | +50.8 | 0.0 | 27.1 |
| BEST FIRST | 4.7 | +245.6 | 151.2 | 66.4 | 3.5 | +151.2 | 115.0 | 97.6 |
| BEST OVERALL | 0.8 | +62.3 | 0.0 | 37.6 | 0.6 | +41.2 | 0.0 | 36.5 |
| BEST PREY | 0.6 | +36.9 | 25.9 | 21.2 | 1.0 | +51.8 | 17.1 | 13.9 |
| BEST PRIZE | 0.0 | -0.8 | 0.0 | 0.0 | 0.1 | -5.8 | 4.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 0.0 | 0.2 | -0.6 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 13.1 | 0.0 | 0.2 | +0.0 | 5.8 | 0.0 |
| BLOCKED WHEEL | 0.3 | +6.8 | 0.0 | 20.4 | 0.4 | +7.3 | 0.0 | 6.5 |
| BLOWS WHERE AIMED | 0.1 | -4.1 | 16.5 | 0.0 | 0.4 | -70.7 | 58.5 | 4.9 |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 108.1 | 10.4 | 0.0 | +0.0 | 2.4 | 0.0 |
| CANNON PLANNED TARGET | 5.8 | +262.3 | 609.2 | 41.7 | 0.6 | +24.2 | 17.5 | 9.2 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 3.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -0.5 | 0.0 | 3.5 |
| CARRIES OUT SET-UP | 0.2 | +0.0 | 22.3 | 4.2 | 0.2 | -0.9 | 33.8 | 13.1 |
| CAST JOB | 0.9 | +46.2 | 119.4 | 6.9 | 0.4 | +7.7 | 7.1 | 4.8 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +38.0 | 41.4 | 10.3 | 0.3 | +10.7 | 12.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 19.7 | 0.6 | +0.0 | 0.0 | 46.8 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 2.9 | 0.0 | -0.1 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 274.8 | 48.4 | 3.0 | +0.0 | 214.8 | 87.4 |
| CHARGE NOW WEIGHED | 0.6 | -82.4 | 28.3 | 5.7 | 0.8 | -76.6 | 30.0 | 67.2 |
| CHARGER SLAIN LOST | 0.4 | -17.6 | 27.3 | 22.1 | 0.6 | -18.6 | 57.3 | 25.7 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 2.4 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.3 | 12.9 | 0.0 | 0.1 | -1.0 | 0.0 | 28.1 |
| CHEAP HELPER | 0.1 | +0.0 | 3.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.8 |
| COMBAT PIVOT | 0.6 | +0.0 | 20.2 | 36.2 | 0.3 | +0.0 | 38.9 | 4.7 |
| CONVEYANCE SEARCH | 0.5 | +88.1 | 13.0 | 32.2 | 0.6 | +75.5 | 13.1 | 33.7 |
| COUNTER-CHARGE COVER | 9.4 | +846.4 | 0.0 | 118.5 | 8.1 | +815.5 | 0.0 | 178.4 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 73.7 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +1.5 | 12.9 | 0.0 | 0.1 | +3.9 | 0.0 | 6.9 |
| DEPLOY BY FIGURES | 7.7 | +16.0 | 0.0 | 11.8 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.6 | 10.1 | 0.0 | 0.2 | +3.9 | 14.3 | 15.8 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +168.4 | 0.0 | 39.2 | 1.6 | +143.6 | 0.0 | 84.6 |
| FALLBACK BY WORTH | 4.6 | +48.6 | 0.0 | 84.2 | 5.6 | +54.5 | 0.0 | 19.5 |
| FIGHT LIFT | 0.1 | +0.4 | 6.8 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 100.3 | 5.8 | +0.0 | 0.0 | 139.9 |
| FOCUS FIRE | 0.1 | +1.8 | 1.2 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.8 | +113.5 | 0.0 | 27.5 | 1.0 | +155.3 | 0.0 | 16.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.1 | 0.0 | 8.0 | 0.4 | +25.8 | 0.0 | 24.6 |
| GATEWAY ESCAPE | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.3 | 0.0 | 10.6 | 0.1 | -2.0 | 2.6 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -1.0 | 12.5 | 3.3 | 0.0 | -0.1 | 1.7 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 13.4 | 0.0 | 0.1 | +0.0 | 8.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 14.8 | 0.9 | 0.4 | +0.0 | 33.2 | 3.6 |
| HILL BY ITS CHANCE | 0.3 | -27.0 | 0.0 | 9.8 | 0.7 | -62.5 | 0.0 | 4.4 |
| HOLDER AT DEPLOYMENT | 1.0 | +175.5 | 0.0 | 3.1 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.9 | -120.7 | 501.6 | 94.6 | 8.4 | -198.8 | 414.8 | 245.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +8.0 | 19.6 | 0.0 | 0.1 | +2.3 | 3.5 | 2.5 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.4 | 0.1 | +0.0 | 3.5 | 5.8 |
| HUNT IN PAIRS | 0.4 | +20.8 | 0.0 | 0.0 | 0.4 | +15.4 | 0.0 | 5.1 |
| HUNT KEPT | 0.1 | +2.7 | 9.2 | 0.0 | 0.0 | +0.2 | 0.0 | 0.8 |
| HUNT RESULT | 0.1 | +31.4 | 0.0 | 2.4 | 0.1 | +0.0 | 3.5 | 6.5 |
| HUNT THE GUNS | 0.2 | +74.0 | 19.6 | 0.0 | 0.1 | +37.3 | 3.5 | 5.4 |
| INVITES THE FIGHT | 2.1 | +47.0 | 85.5 | 2.6 | 0.9 | +12.4 | 24.7 | 17.8 |
| JOINT CHARGE PLAN | 0.0 | +0.5 | 0.0 | 0.0 | 0.2 | +2.7 | 11.3 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -5.0 | 0.0 | 0.0 | 0.2 | -1.8 | 31.0 | 0.0 |
| KEEP FALLS | 0.2 | +1.0 | 0.0 | 6.6 | 0.0 | +0.6 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.4 | 3.1 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.7 | +51.7 | 161.7 | 30.6 | 2.1 | +63.3 | 117.3 | 57.5 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +65.0 | 129.9 | 20.5 | 2.1 | +116.0 | 152.5 | 58.8 |
| KILLS COUNT NEXT TURN | 5.4 | +148.3 | 247.2 | 53.3 | 7.4 | +250.6 | 223.6 | 173.9 |
| LANE BY FIGURES | 0.8 | +38.4 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.6 | +43.4 | 7.8 | 3.1 | 0.3 | +7.4 | 22.9 | 44.7 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 13.1 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +36.8 | 0.0 | 0.0 | 0.1 | +11.6 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.0 | 18.8 | 0.0 | 0.6 | +0.5 | 33.2 | 4.7 |
| LOST CHARGE | 3.2 | -54.9 | 147.0 | 36.6 | 2.3 | -32.7 | 80.4 | 83.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -22.8 | 0.0 | 1.5 |
| MAKE SURE TOGETHER | 1.0 | +140.1 | 56.9 | 16.5 | 0.8 | +60.4 | 11.3 | 27.6 |
| MANOEUVRE | 0.2 | +2.2 | 0.0 | 1.1 | 0.3 | +4.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +7.4 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +40.4 | 0.0 | 11.3 | 0.6 | +36.5 | 0.0 | 15.0 |
| MARCH ODDS | 0.6 | +39.9 | 51.4 | 4.6 | 0.4 | +27.7 | 0.0 | 23.2 |
| MARCH OVER CASTS | 0.7 | +41.2 | 0.0 | 0.0 | 0.5 | +31.4 | 0.0 | 20.5 |
| MAX FOR POSITIONING | 5.2 | +172.9 | 0.0 | 64.2 | 5.4 | +197.8 | 0.0 | 132.5 |
| MISSILES IN THE MOVE | 4.6 | +190.7 | 0.0 | 94.4 | 3.7 | +55.8 | 0.0 | 95.4 |
| MISSILES NEXT TURN | 5.5 | +133.6 | 0.0 | 109.4 | 4.2 | +41.4 | 0.0 | 121.5 |
| MODEL FACING | 0.2 | +59.1 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 8.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +9.0 | 0.0 | 2.4 | 0.4 | +14.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +3.6 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.2 | -22.0 | 0.0 | 29.6 | 0.2 | -3.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 26.1 |
| MOVE TO CHARGE | 3.0 | +251.0 | 187.4 | 22.8 | 4.5 | +367.3 | 129.5 | 104.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +6.2 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.7 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -8.2 | 33.0 | 8.2 | 0.3 | -9.9 | 15.6 | 3.5 |
| NOT TURNED | 5.8 | +88.7 | 0.0 | 74.4 | 5.9 | +105.1 | 0.0 | 111.4 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 21.1 | 0.3 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 18.1 | -1085.5 | 9.0 | 235.1 | 15.9 | -888.2 | 8.0 | 293.7 |
| OPENS A LANE | 0.4 | +1.0 | 162.6 | 4.6 | 0.1 | +0.2 | 7.9 | 0.0 |
| OPENS UP | 0.1 | +14.6 | 8.8 | 5.4 | 0.3 | +35.5 | 22.6 | 0.0 |
| OVERRUNS AWAY | 0.4 | +6.0 | 30.2 | 6.5 | 0.6 | +8.6 | 58.6 | 21.1 |
| PATHS CROSS | 2.0 | +129.7 | 0.0 | 43.8 | 2.9 | +139.0 | 0.0 | 48.8 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | 0.0 | +2.1 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.9 | 0.0 | 11.5 | 0.1 | -3.4 | 0.0 | 0.0 |
| PLAN RESULT | 37.8 | +1651.3 | 1587.3 | 725.4 | 39.6 | +939.5 | 1119.1 | 1114.8 |
| PURSUES BIG PREY | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -18.5 | 0.0 | 5.4 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 5.5 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.2 | +18.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +18.1 | 0.0 | 18.9 | 1.4 | +12.1 | 0.0 | 38.6 |
| RANDOM MOVER NO PROMISE | 0.3 | -15.0 | 9.2 | 0.0 | 0.5 | -11.6 | 0.0 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.3 | 0.0 | 3.3 | 0.6 | -6.4 | 0.0 | 9.3 |
| REDIRECT COUNTER | 2.8 | +238.7 | 0.0 | 33.1 | 5.2 | +458.2 | 0.0 | 70.8 |
| REDIRECT WEIGHED | 0.1 | +1.0 | 1.6 | 0.9 | 0.4 | +2.7 | 13.5 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 22.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +6.3 | 0.0 | 10.3 | 0.9 | +36.6 | 0.0 | 11.3 |
| RESTRAINS TO SHOOT | 0.2 | +10.8 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +70.7 | 204.0 | 61.3 | 3.1 | +97.3 | 219.6 | 119.9 |
| SAFER THAN THE JOB | 1.2 | +81.9 | 0.0 | 29.3 | 0.9 | +62.0 | 0.0 | 43.7 |
| SCOUT SPOT | 0.4 | +1.6 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 2.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 2.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.9 | 0.0 | 0.8 | 0.3 | -18.0 | 0.0 | 1.8 |
| SEARCH SPOT | 2.8 | +175.3 | 0.0 | 35.7 | 3.3 | +178.1 | 0.0 | 47.6 |
| SELF MOVE SPELL | 0.2 | +9.3 | 0.0 | 18.1 | 0.2 | +62.1 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.5 | +178.0 | 65.9 | 24.4 | 2.1 | +170.7 | 42.0 | 31.1 |
| SET-UP ANY TARGET | 0.2 | +28.1 | 2.6 | 0.0 | 0.2 | +31.9 | 13.1 | 26.1 |
| SET-UP MISSED | - | - | - | - | 0.1 | +17.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +32.6 | 52.0 | 6.5 | 1.4 | +57.9 | 24.1 | 10.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 3.8 | - | - | - | - |
| SHOT REPLANNED | 0.7 | +0.0 | 99.1 | 14.8 | 0.2 | +0.0 | 15.6 | 2.0 |
| SHOTS IN THE MOVE | 13.8 | +701.7 | 0.0 | 156.1 | 10.3 | +287.0 | 0.0 | 183.3 |
| SPELL SETS UP CHARGE | 0.2 | +61.0 | 2.6 | 2.6 | 0.3 | +52.6 | 13.1 | 26.1 |
| SPELL WORTH | 1.3 | +27.7 | 53.4 | 56.5 | 2.1 | +41.4 | 148.9 | 142.9 |
| SPELLS IN THE FIGHT | 0.6 | -3.3 | 120.1 | 10.6 | 0.7 | -10.0 | 61.3 | 32.7 |
| STABLE ROLE | 10.3 | +0.0 | 276.1 | 124.8 | 9.9 | +0.0 | 282.3 | 175.5 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +4.7 | 9.2 | 0.0 | 0.1 | +4.7 | 0.0 | 3.6 |
| STOPS SHORT OF THE FLANK | 0.5 | +25.0 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 11.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 8.0 | 0.0 |
| SUPPORT NARROWED | 6.1 | -60.3 | 293.2 | 83.2 | 8.2 | -62.9 | 306.8 | 123.2 |
| SUPPORTS | 4.3 | +67.5 | 139.0 | 54.3 | 5.7 | +62.9 | 192.4 | 65.1 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -17.6 | 1.1 | 1.7 | 0.1 | -3.2 | 4.7 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +11.0 | 0.0 | 0.0 | 0.5 | +1.4 | 0.0 | 2.5 |
| THROUGH LINE OF FIRE | 0.3 | +4.2 | 0.0 | 1.4 | 0.2 | +11.6 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -12.4 | 21.1 | 9.4 | 0.3 | -28.0 | 23.6 | 4.2 |
| TWO OR MORE ARRIVE | 0.5 | +6.2 | 42.4 | 7.0 | 0.6 | +10.6 | 0.0 | 12.1 |
| WAIT AFTER COSTS | 6.8 | -361.8 | 320.8 | 50.0 | 7.2 | -341.8 | 223.2 | 201.9 |
| WALKS TO THE FIGHT | 1.0 | +21.5 | 15.5 | 19.0 | 0.9 | +12.3 | 16.5 | 38.2 |
| WAR ENGINE CHARGES | 0.1 | +10.6 | 18.6 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 29.6 | 0.0 | 0.3 | +0.0 | 13.0 | 10.3 |
| WEARS DOWN | 1.0 | +41.8 | 125.4 | 44.4 | 1.5 | +70.3 | 96.2 | 46.6 |
| WHO HITS BACK | 0.2 | +27.4 | 0.0 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +0.8 | 27.7 | 0.0 | 0.3 | +9.6 | 27.3 | 6.6 |
| WHOLE FIGHT GAIN | 0.4 | +38.2 | 28.7 | 10.8 | 0.8 | +64.4 | 55.4 | 18.2 |
| WIDER SPREAD | 2.1 | -7.0 | 279.9 | 71.1 | 3.6 | -5.9 | 277.7 | 91.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: dep-mine-13df7bd-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1225 | 1225 | 1225 | 34.03 | -71058 | -58.0 |
| BEST FIRST | 296 | 296 | 296 | 8.22 | +14283 | +48.3 |
| SEARCH SPOT | 219 | 219 | 218 | 6.06 | +12727 | +58.4 |
| DEPLOY BY FIGURES | 276 | 276 | 184 | 5.11 | +2369 | +12.9 |
| COUNTER-CHARGE COVER | 631 | 355 | 182 | 5.06 | +11066 | +60.8 |
| PATHS CROSS | 176 | 176 | 176 | 4.89 | +9673 | +55.0 |
| MOVE TO CHARGE | 270 | 270 | 161 | 4.47 | +10398 | +64.6 |
| KILLS COUNT NEXT TURN | 461 | 461 | 148 | 4.11 | +4166 | +28.1 |
| SUPPORTS | 361 | 361 | 138 | 3.83 | +1455 | +10.5 |
| FACES THE THREAT | 131 | 131 | 131 | 3.64 | +11232 | +85.7 |
| WAIT AFTER COSTS | 502 | 502 | 80 | 2.22 | +1630 | +20.4 |
| ADVANCE LANE KEPT | 79 | 79 | 79 | 2.19 | +0 | +0.0 |
| SHOTS IN THE MOVE | 866 | 556 | 76 | 2.11 | +2009 | +26.4 |
| SAFER THAN THE JOB | 74 | 74 | 74 | 2.06 | +5183 | +70.0 |
| FALLBACK BY WORTH | 368 | 368 | 73 | 2.03 | +3709 | +50.8 |
| REDIRECT COUNTER | 289 | 174 | 68 | 1.89 | +5409 | +79.5 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +9679 | +148.9 |
| SET UP TOGETHER | 129 | 111 | 65 | 1.81 | +6134 | +94.4 |
| ARTILLERY RE-ROLL WEIGHED | 63 | 63 | 63 | 1.75 | +0 | +0.0 |
| BEST FACING | 59 | 59 | 59 | 1.64 | +3435 | +58.2 |
| CANNON SIGHT KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| CHARGE NOW FIRST | 188 | 188 | 51 | 1.42 | -2804 | -55.0 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +3725 | +76.0 |
| CHARGE NOW WEIGHED | 48 | 48 | 48 | 1.33 | +5158 | +107.5 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1545 | +34.3 |
| MAX FOR POSITIONING | 384 | 216 | 43 | 1.19 | +563 | +13.1 |
| RANDOM MOVE BY FIGURES | 81 | 81 | 42 | 1.17 | +1087 | +25.9 |
| RISK BY ARC | 189 | 184 | 41 | 1.14 | +1230 | +30.0 |
| SHOOTS FROM THE BEST SPOT | 78 | 78 | 40 | 1.11 | +1277 | +31.9 |
| KILLS COUNT | 128 | 126 | 38 | 1.06 | +2350 | +61.8 |
| MARCH CHECK | 40 | 39 | 37 | 1.03 | +2715 | +73.4 |
| WALKS TO THE FIGHT | 68 | 68 | 37 | 1.03 | +400 | +10.8 |
| MARCH ODDS | 35 | 35 | 34 | 0.94 | +835 | +24.5 |
| CANNON PLANNED TARGET | 230 | 230 | 33 | 0.92 | -344 | -10.4 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LANE BY FIGURES | 30 | 30 | 30 | 0.83 | +1383 | +46.1 |
| MAKE SURE TOGETHER | 64 | 49 | 29 | 0.81 | +2961 | +102.1 |
| CAST JOB | 47 | 47 | 28 | 0.78 | +760 | +27.1 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1401 | +51.9 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +505 | +19.4 |
| MISSILES IN THE MOVE | 299 | 170 | 26 | 0.72 | +729 | +28.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 25 | 25 | 25 | 0.69 | +1743 | +69.7 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1257 | +52.4 |
| HONEST WORTH | 551 | 547 | 24 | 0.67 | +116 | +4.8 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +853 | +35.5 |
| KEEPS ITS TARGET | 138 | 137 | 22 | 0.61 | +327 | +14.9 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.61 | +42 | +1.9 |
| WHOLE FIGHT GAIN | 41 | 38 | 21 | 0.58 | +1348 | +64.2 |
| INVITES THE FIGHT | 109 | 109 | 20 | 0.56 | +373 | +18.7 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +221 | +11.6 |
| BEST PREY | 58 | 58 | 18 | 0.50 | +908 | +50.4 |
| CASTING BLOCK | 27 | 27 | 18 | 0.50 | +769 | +42.7 |
| MANOEUVRE | 18 | 18 | 18 | 0.50 | +230 | +12.8 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +569 | +31.6 |
| WEARS DOWN | 88 | 84 | 18 | 0.50 | +513 | +28.5 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -35 | -2.1 |
| LOST CHARGE | 198 | 197 | 14 | 0.39 | +702 | +50.1 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 36 | 36 | 12 | 0.33 | +573 | +47.7 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +464 | +42.1 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| WAR ENGINE JOBS | 31 | 31 | 11 | 0.31 | -643 | -58.4 |
| OPENS UP | 17 | 17 | 10 | 0.28 | +446 | +44.6 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -229 | -22.9 |
| REFUSING RETIRES | 26 | 26 | 10 | 0.28 | -2 | -0.2 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -749 | -74.9 |
| WHO HITS BACK | 10 | 10 | 10 | 0.28 | +752 | +75.2 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +2127 | +236.3 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -696 | -87.0 |
| SUPPORT NARROWED | 513 | 513 | 8 | 0.22 | -88 | -10.9 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +398 | +56.8 |
| CHAFF PASSED | 6 | 6 | 6 | 0.17 | -6 | -1.0 |
| HUNT IN PAIRS | 29 | 13 | 6 | 0.17 | +255 | +42.5 |
| MISSILES NEXT TURN | 349 | 197 | 6 | 0.17 | +40 | +6.7 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +136 | +22.7 |
| OVERRUNS AWAY | 35 | 33 | 6 | 0.17 | +177 | +29.5 |
| SURE REACH TOGETHER | 40 | 30 | 6 | 0.17 | +17 | +2.8 |
| BACKUP TARGETS | 67 | 29 | 5 | 0.14 | +36 | +7.2 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 5 | 0.14 | +371 | +74.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -801 | -200.2 |
| DEFENSIVE ARMY | 17 | 17 | 3 | 0.08 | -39 | -13.1 |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 3 | 0.08 | +98 | +32.7 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +122 | +40.8 |
| WAR ENGINE CHARGES | 3 | 3 | 3 | 0.08 | +239 | +79.6 |
| EDGE GIVE GROUND | 12 | 12 | 2 | 0.06 | +66 | +33.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +20 | +9.8 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +65 | +32.3 |
| HUNT ADVANCE | 6 | 6 | 2 | 0.06 | +175 | +87.5 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 2 | 0.06 | -11 | -5.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +199 | +99.3 |
| SPELLS IN THE FIGHT | 49 | 47 | 2 | 0.06 | +9 | +4.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -107 | -53.5 |
| WIDER SPREAD | 204 | 196 | 2 | 0.06 | +6 | +2.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +13.8 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -17 | -16.9 |
| CARRIES OUT SET-UP | 14 | 14 | 1 | 0.03 | -33 | -33.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -2.2 |
| DEFENSIVE FLOOR | 5 | 5 | 1 | 0.03 | +44 | +43.7 |
| HILL BY ITS CHANCE | 36 | 36 | 1 | 0.03 | +65 | +64.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| KEEPS ITS PREY | 6 | 6 | 1 | 0.03 | +4 | +4.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 34 | 33 | 1 | 0.03 | +7 | +6.8 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +10 | +10.0 |
| STOPS | 8 | 8 | 1 | 0.03 | +109 | +108.6 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +2 | +2.1 |
| WHOLE FIGHT | 15 | 14 | 1 | 0.03 | +19 | +18.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 18 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 30 | 30 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 36 | 33 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 430 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 2 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 9 | 9 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 11 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 424 | 424 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| OPENS A LANE | 18 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 2788 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 121 | not checked | - | - | - | - |
| STABLE ROLE | 730 | 727 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 37 | 35 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.19 | 14.06 | 60.2 |
| FALLBACK | gate | 0.89 | 0.92 | 42.7 |
| CHARGE NOW FIRST | rule | 0.86 | 0.56 | 55.0 |
| TURN GATE | gate | 0.56 | 0.53 | 43.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.19 | 58.6 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.03 | 39.6 |
| PATHS CROSS | rule | 0.19 | 0.14 | 20.5 |
| WAR ENGINE JOBS | rule | 0.17 | 0.14 | 58.4 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.08 | 22.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.11 | 74.9 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.14 | 7.9 |
| PURSUES BIG PREY | rule | 0.06 | 0.17 | 87.0 |
| SUPPORT NARROWED | rule | 0.14 | 0.08 | 10.9 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.3 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 28.3 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 33.6 |
| BEST PRIZE | rule | 0.03 | 0.08 | 200.2 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 6.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 26.1 |
| CHAFF PASSED | rule | 0.06 | 0.03 | 2.0 |
| DEFENSIVE ARMY | rule | 0.08 | - | 13.1 |
| SAFER THAN THE JOB | rule | - | 0.08 | 10.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 7.6 |
| DEPLOY BY FIGURES | rule | 0.06 | - | 8.6 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 8.0 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 1.9 |
| REDIRECT WEIGHED | rule | - | 0.06 | 377.3 |
| STANDS TO CAST | rule | - | 0.06 | 53.5 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 26.7 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 16.9 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 33.1 |
| CATCH ODDS | rule | - | 0.03 | 2.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 10.9 |
| MARCH ODDS | rule | - | 0.03 | 18.3 |
| NO REASON | gate | 0.03 | - | 6.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 1.6 |
| WHO HITS BACK | rule | - | 0.03 | 0.6 |

### Plans: dep-mine-13df7bd-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 15% | 518 | 334 | 64% |
| Mine | charge | 2.6 | 54% | 238 | 260 | 109% |
| Mine | close in | 4.6 | 25% | 251 | 141 | 56% |
| Mine | hold | 5.0 | 48% | 297 | 0 | 0% |
| Mine | join | 0.2 | 89% | 9 | 0 | 0% |
| Mine | shoot | 8.7 | 70% | 338 | 917 | 271% |
| Mine | support | 4.5 | 89% | 45 | 0 | 0% |
| Opponent | advance | 12.9 | 13% | 291 | 255 | 88% |
| Opponent | charge | 4.5 | 54% | 393 | 367 | 93% |
| Opponent | close in | 5.9 | 22% | 373 | 130 | 35% |
| Opponent | hold | 4.3 | 42% | 311 | 0 | 0% |
| Opponent | join | 0.4 | 94% | 21 | 0 | 0% |
| Opponent | shoot | 5.1 | 46% | 114 | 189 | 166% |
| Opponent | support | 6.4 | 90% | 47 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 1 | 0% | 40% | 0% | 2.0 | 478 | 226 | 40% | 11 |
| Opponent | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 336 | 0 | 0% | 140 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 1 | 0% | 0% | 0% | - | 391 | 0 | 0% | 68 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 665 | 582 | 100% | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 552 | 548 | 100% | 116 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 268 |
| Ogre Kingdoms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 196 | 0 | 0% | 234 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 154 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.3 | 3 | 0 | 0% | 0% | 0% | - | 382 | 0 | 0% | 91 |

### Battle groups: dep-mine-13df7bd-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.4 | 24% | 41% | 2% | 0% | 46% | 5% | 13% | 37% | 0% |
| Mine | REDIRECT COUNTER | 2.8 | 28% | 61% | 7% | 50% | 27% | 4% | 4% | 65% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 16% | 72% | 20% | 67% | 27% | 14% | 22% | 38% | 0% |
| Opponent | REDIRECT COUNTER | 5.2 | 17% | 75% | 12% | 0% | 18% | 0% | 21% | 61% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 35 | 73 (35) | 9 | 64 | 59 | 31% | 2.4 | 66 (16) | 83 (15) | 67 (4) | 66 (26) | 95 (9) |
| Mine | Character | 126 | 41 (126) | 41 | 0 | 32 | 18% | 2.3 | 42 (43) | 32 (54) | 70 (16) | 43 (67) | 44 (46) |
| Mine | Clean-up | 25 | 67 (25) | 34 | 33 | 40 | 24% | 3.0 | 32 (14) | 107 (8) | 83 (3) | 77 (19) | 28 (6) |
| Mine | Fast Hammer | 44 | 36 (44) | 13 | 23 | 33 | 27% | 2.7 | 37 (18) | 39 (24) | 0 (2) | 33 (28) | 41 (16) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Hammer | 54 | 46 (54) | 31 | 15 | 28 | 19% | 2.5 | 51 (20) | 39 (27) | 56 (7) | 50 (37) | 38 (17) |
| Mine | Holder | 33 | 82 (33) | 11 | 71 | 23 | 36% | 3.7 | 62 (11) | 113 (16) | 34 (6) | 102 (20) | 47 (13) |
| Mine | Shooter | 27 | 75 (27) | 23 | 52 | 46 | 0% | 1.8 | 69 (13) | 112 (11) | 0 (3) | 93 (20) | 32 (7) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (3) | 0 (1) | - | 0 (5) |
| Mine | War machine | 57 | 71 (57) | 71 | 0 | 25 | 2% | 1.1 | 51 (26) | 73 (22) | 126 (9) | 59 (14) | 75 (43) |
| Mine | Wizard | 18 | 20 (18) | 20 | 0 | 48 | 17% | 2.1 | 0 (6) | 68 (7) | - | 0 (1) | 36 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 79 | 44 (79) | 7 | 37 | 44 | 47% | 3.0 | 76 (33) | 36 (17) | 9 (29) | 61 (58) | 0 (21) |
| Opponent | Character | 91 | 48 (91) | 48 | 0 | 32 | 12% | 2.2 | 47 (34) | 53 (45) | 56 (7) | 55 (58) | 44 (28) |
| Opponent | Clean-up | 14 | 38 (14) | 6 | 32 | 33 | 21% | 1.9 | 15 (5) | 58 (8) | 19 (1) | 60 (9) | 9 (5) |
| Opponent | Early | 2 | 211 (2) | 211 | 0 | 50 | 0% | 5.0 | - | 421 (1) | 0 (1) | - | 211 (2) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 50 | 33 (50) | 13 | 20 | 37 | 20% | 2.7 | 29 (23) | 35 (12) | 38 (15) | 32 (26) | 34 (24) |
| Opponent | Fragile | 9 | 54 (9) | 54 | 0 | 47 | 22% | 2.9 | 0 (1) | 60 (8) | - | 102 (5) | 0 (4) |
| Opponent | Hammer | 73 | 29 (73) | 17 | 12 | 53 | 27% | 2.6 | 21 (22) | 38 (38) | 0 (13) | 29 (47) | 27 (26) |
| Opponent | Holder | 28 | 59 (28) | 16 | 43 | 23 | 36% | 3.1 | 154 (4) | 50 (19) | 34 (5) | 68 (19) | 37 (9) |
| Opponent | Shooter | 32 | 67 (32) | 21 | 46 | 27 | 0% | 1.6 | 6 (6) | 76 (23) | 149 (3) | 94 (16) | 40 (16) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 8 | 34 (8) | 34 | 0 | 44 | 12% | 1.7 | 0 (1) | 17 (5) | 82 (2) | - | 34 (8) |
| Opponent | Wizard | 13 | 4 (13) | 4 | 0 | 18 | 31% | 2.0 | 0 (4) | 7 (7) | 0 (1) | 0 (5) | 12 (7) |

### Charged fights: dep-mine-13df7bd-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 127 | 71 | 1.2 | 1.0 | 57 | 10 | +47 | 0 of 5 | 2 of 5 | - | +47 |
| Mine | Chaos Dwarfs | 4 | 307 | 138 | 1.2 | 1.0 | 110 | 0 | +110 | 0 of 5 | 5 of 5 | - | +110 |
| Mine | Dwarfen Mountain Holds | 3 | 628 | 24 | 0.3 | 1.0 | 72 | 0 | +72 | 0 of 1 | 1 of 1 | - | +72 |
| Mine | Empire of Man | 5 | 457 | 185 | 1.6 | 1.2 | 116 | 33 | +82 | 1 of 8 | 7 of 8 | +196 | +44 |
| Mine | Grand Cathay | 5 | 666 | 236 | 2.6 | 1.2 | 91 | 0 | +91 | 5 of 13 | 12 of 13 | +62 | +100 |
| Mine | High Elf Realms | 3 | 283 | 669 | 5.0 | 1.1 | 134 | 4 | +130 | 4 of 15 | 9 of 15 | +142 | +128 |
| Mine | Kingdom of Bretonnia | 2 | 260 | 804 | 3.0 | 1.3 | 268 | 0 | +268 | 3 of 6 | 6 of 6 | +702 | +181 |
| Mine | Lizardmen | 1 | 27 | 307 | 3.0 | 1.0 | 102 | 0 | +102 | 2 of 3 | 3 of 3 | - | +102 |
| Mine | Ogre Kingdoms | 1 | 128 | 104 | 6.0 | 1.3 | 17 | 67 | -50 | 0 of 6 | 3 of 6 | -58 | -46 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 331 | 6.0 | 1.2 | 55 | 9 | +46 | 1 of 6 | 4 of 6 | +0 | +55 |
| Mine | Skaven | 1 | 0 | 110 | 1.0 | 1.0 | 110 | 0 | +110 | 0 of 1 | 1 of 1 | - | +110 |
| Mine | Tomb Kings of Khemri | 2 | 22 | 823 | 4.5 | 1.1 | 183 | 35 | +148 | 3 of 9 | 7 of 9 | +323 | +126 |
| Mine | Vampire Counts | 2 | 32 | 146 | 3.5 | 1.3 | 42 | 6 | +36 | 0 of 7 | 7 of 7 | -20 | +58 |
| Mine | Warriors of Chaos | 2 | 0 | 120 | 1.0 | 1.5 | 120 | 0 | +120 | 0 of 2 | 2 of 2 | +125 | +114 |
| **Mine** | all armies | 36 | 302 | 268 | 2.4 | 1.2 | 111 | 14 | +97 | 19 of 87 | 69 of 87 | +124 | +92 |
| Opponent | Grand Cathay | 3 | 181 | 340 | 3.3 | 1.1 | 102 | 0 | +102 | 3 of 10 | 8 of 10 | +0 | +113 |
| Opponent | High Elf Realms | 3 | 37 | 223 | 3.0 | 1.2 | 74 | 17 | +57 | 2 of 9 | 9 of 9 | +32 | +65 |
| Opponent | Lizardmen | 1 | 135 | 214 | 4.0 | 1.0 | 54 | 35 | +18 | 2 of 4 | 3 of 4 | - | +18 |
| Opponent | Ogre Kingdoms | 3 | 69 | 391 | 4.0 | 1.2 | 98 | 10 | +88 | 10 of 12 | 7 of 12 | +338 | +37 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 112 | -112 | 1 of 1 | 1 of 1 | - | -112 |
| Opponent | Tomb Kings of Khemri | 1 | 285 | 799 | 3.0 | 1.7 | 266 | 0 | +266 | 3 of 3 | 3 of 3 | +306 | +186 |
| Opponent | Vampire Counts | 5 | 0 | 360 | 2.8 | 1.4 | 129 | 12 | +117 | 8 of 14 | 14 of 14 | +22 | +170 |
| Opponent | Warriors of Chaos | 8 | 37 | 561 | 3.5 | 1.1 | 160 | 25 | +135 | 11 of 28 | 22 of 28 | +235 | +124 |
| Opponent | Wood Elf Realms | 11 | 75 | 546 | 4.1 | 1.2 | 134 | 49 | +84 | 21 of 45 | 26 of 45 | +196 | +56 |
| **Opponent** | all armies | 36 | 67 | 449 | 3.5 | 1.2 | 128 | 29 | +100 | 61 of 126 | 93 of 126 | +164 | +85 |

### Effective charges: dep-mine-13df7bd-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 1 (net +0) | 2 (net -26) | 1 (net +244) | 1 (net +41) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net +177) | 0 | 0 | 4 (net +94) | 0 | 20% (1 of 5) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +72) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 8 | 0 | 0 | 3 (net +43) | 2 (net +54) | 1 (net +60) | 2 (net +182) | 0 | 38% (3 of 8) |
| Mine | Grand Cathay | 13 | 2 (net +0) | 0 | 4 (net +116) | 3 (net +178) | 0 | 2 (net +92) | 2 | 36% (4 of 11) |
| Mine | High Elf Realms | 15 | 0 | 1 (net +0) | 0 | 6 (net +59) | 0 | 7 (net +227) | 1 | 0% (0 of 14) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +702) | 0 | 1 (net +479) | 0 | 1 (net +40) | 3 (net +129) | 0 | 17% (1 of 6) |
| Mine | Lizardmen | 3 | 0 | 0 | 1 (net +0) | 1 (net +216) | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +35) | 2 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 0 | 1 (net +160) | 5 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +110) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +666) | 0 | 2 (net +61) | 2 (net +24) | 1 (net +85) | 3 (net +136) | 0 | 22% (2 of 9) |
| Mine | Vampire Counts | 7 | 0 | 1 (net +30) | 0 | 0 | 1 (net +137) | 4 (net +21) | 1 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +125) | 0 | 1 (net +114) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 10 | 2 (net +322) | 0 | 0 | 3 (net +57) | 3 (net +47) | 2 (net +32) | 0 | 0% (0 of 10) |
| Opponent | High Elf Realms | 9 | 1 (net +0) | 0 | 0 | 0 | 2 (net +32) | 4 (net +97) | 2 | 0% (0 of 7) |
| Opponent | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 12 | 0 | 0 | 2 (net +338) | 2 (net +59) | 0 | 1 (net +0) | 7 | 40% (2 of 5) |
| Opponent | Skaven | 1 | 1 (net -112) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +613) | 0 | 0 | 1 (net +186) | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 14 | 0 | 0 | 4 (net +27) | 4 (net +0) | 1 (net +0) | 5 (net +306) | 0 | 29% (4 of 14) |
| Opponent | Warriors of Chaos | 28 | 2 (net -240) | 0 | 3 (net +103) | 6 (net +273) | 5 (net +112) | 10 (net +110) | 2 | 12% (3 of 26) |
| Opponent | Wood Elf Realms | 45 | 13 (net +35) | 3 (net +295) | 6 (net +60) | 9 (net +59) | 1 (net +185) | 8 (net +126) | 5 | 15% (6 of 40) |

### Charged fights, damage counted: dep-mine-13df7bd-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 495 | 310 | +342 | 384 | 39 | +345 | +69.7 |
| Mine | 50-54% | 2 | 94 | 132 | +15 | 15 | 0 | +15 | +16.0 |
| Mine | Effective (55-75%) | 13 | 312 | 252 | +105 | 135 | 36 | +100 | +32.0 |
| Mine | 76-89% | 19 | 227 | 134 | +74 | 102 | 40 | +62 | +27.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 326 | 185 | +123 | 157 | 9 | +148 | +45.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 441 | 103 | +113 | 113 | 6 | +108 | +24.4 |
| Mine | No odds | 12 | 262 | 136 | -16 | 37 | 67 | -30 | -11.3 |
| Mine | All fights | 87 | 302 | 177 | +97 | 130 | 29 | +101 | +33.4 |
| Opponent | Long shot (under 50%) | 21 | 263 | 308 | +53 | 134 | 104 | +30 | +11.3 |
| Opponent | 50-54% | 3 | 534 | 228 | +295 | 402 | 35 | +367 | +68.7 |
| Opponent | Effective (55-75%) | 15 | 286 | 246 | +97 | 211 | 81 | +130 | +45.4 |
| Opponent | 76-89% | 25 | 290 | 195 | +106 | 134 | 34 | +99 | +34.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 317 | 214 | +132 | 188 | 31 | +158 | +49.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 420 | 108 | +73 | 116 | 25 | +91 | +21.7 |
| Opponent | No odds | 18 | 174 | 206 | +79 | 136 | 46 | +90 | +51.7 |
| Opponent | All fights | 126 | 294 | 218 | +100 | 161 | 51 | +110 | +37.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p7 | move | 462 | 92 (20%) | 71 (15%) | 51 (11%) | 319 (69%) |
| dep-mine-13df7bd-p7 | objective | 379 | 54 (14%) | 43 (11%) | 41 (11%) | 284 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0112, L0128, L2435, L2632 |
| Charmed Shield | Opponent | L0727, L0924, L1124, L1234, L1424, L1734, L1934, L2225, L2834 |
| Clockwork Compass | Mine | L1218, L1234 |
| Clockwork Compass | Opponent | L0112, L0212 |
| Elixir of Power | Mine | L1124, L1934 |
| Elixir of Power | Opponent | L0711 |
| Fistful of Laurels | Mine | L1833 |
| Fistful of Laurels | Opponent | L0518, L1218, L1618 |
| Horn of the Wild Hunt | Opponent | L0833, L1833 |
| Invocation of Nehek | Mine | L2435 |
| Invocation of Nehek | Opponent | L0727, L0924, L1124, L1424, L2225 |
| Opal Amulet | Mine | L1424 |
| Periapt of Soul Exchange | Mine | L2035 |
| Periapt of Soul Exchange | Opponent | L1521 |
| Ring of Doom | Mine | L0212, L0228, L1124, L1218, L1234, L1521, L3135 |
| Ring of Doom | Opponent | L0112, L0212, L0415, L0711, L0833, L1015, L1833 |
| Ring of Jet | Mine | L1015, L1032, L1124, L1218, L1234 |
| Ring of Jet | Opponent | L0112, L0212, L0711 |
| Standard of the Fell Warrior | Mine | L1329 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L1521 |
| Twice-Blessed Armour | Mine | L0711, L0727, L1015, L1032 |
| Witch Hunter's Ward | Mine | L0711, L0727, L0817, L0833 |

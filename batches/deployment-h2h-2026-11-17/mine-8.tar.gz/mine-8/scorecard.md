# Doctrine scorecard: dep-mine-13df7bd-p8

### Scorecard: dep-mine-13df7bd-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0116 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0116 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 1 | 0 | 0 | 200 |
| L0132 | 6 | 1 | Mine | no | 4 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 5 | 2 | 6 | 4 | 0 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Mine | no | 1 | 6 | 1 | 4 | 0 | 0 | 0 | 255 |
| L0216 | 6 | 1 | Opponent | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 260 |
| L0233 | 5 | 1 | Mine | yes | - | 4 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0233 | 5 | 1 | Opponent | no | - | 3 | 0 | 2 | 0 | 0 | 0 | 334 |
| L0317 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0317 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 2 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0334 | 4 | 1 | Opponent | no | 7 | 2 | 4 | 3 | 0 | 0 | 0 | 267 |
| L0419 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0419 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0506 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 686 |
| L0506 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 615 |
| L0522 | 6 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 1343 |
| L0522 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0610 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0610 | 4 | 1 | Opponent | no | 2 | 4 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0626 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0715 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0731 | 5 | 1 | Mine | no | - | 4 | 3 | 2 | 0 | 0 | 0 | 609 |
| L0731 | 5 | 1 | Opponent | no | - | 2 | 1 | 3 | 1 | 0 | 0 | 170 |
| L0821 | 5 | 1 | Mine | yes | - | 1 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0821 | 5 | 1 | Opponent | no | - | - | 1 | 7 | 2 | 0 | 0 | 355 |
| L0911 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L0911 | 5 | 1 | Opponent | yes | - | 5 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0928 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0928 | 4 | 1 | Opponent | no | 11 | 2 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1019 | 5 | 1 | Mine | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 330 |
| L1019 | 5 | 1 | Opponent | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 382 |
| L1112 | 2 | 1 | Mine | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 501 |
| L1112 | 2 | 1 | Opponent | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1128 | 6 | 1 | Mine | no | 2 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1128 | 6 | 1 | Opponent | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1222 | 4 | 1 | Mine | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1222 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1317 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1317 | 3 | 1 | Opponent | no | 2 | 3 | 1 | 0 | 3 | 0 | 0 | 49 |
| L1333 | 1 | 1 | Mine | no | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 140 |
| L1333 | 1 | 1 | Opponent | no | 5 | 1 | 4 | 4 | 0 | 0 | 0 | 458 |
| L1429 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1429 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Mine | no | 3 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1623 | 3 | 1 | Mine | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1623 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1721 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1721 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 145 |
| L1821 | 3 | 1 | Mine | no | 9 | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1821 | 3 | 1 | Opponent | yes | 1 | 4 | 2 | 3 | 1 | 0 | 0 | 500 |
| L1921 | 1 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1921 | 1 | 1 | Opponent | no | 1 | 1 | 2 | 2 | 0 | 0 | 0 | 355 |
| L2023 | 1 | 1 | Mine | no | 1 | - | 2 | 1 | 0 | 0 | 0 | 210 |
| L2023 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2125 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 500 |
| L2125 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2229 | 3 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2229 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2333 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 2 | 0 | 0 | 66 |
| L2333 | 5 | 1 | Opponent | no | - | 1 | 3 | 2 | 0 | 0 | 0 | 549 |
| L2529 | 3 | 1 | Mine | no | 2 | 2 | 0 | 3 | 1 | 0 | 0 | 85 |
| L2529 | 3 | 1 | Opponent | no | 9 | 3 | 4 | 3 | 0 | 0 | 0 | 170 |
| L2728 | 4 | 1 | Mine | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 250 |
| L2728 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2932 | 4 | 1 | Mine | no | 9 | 2 | 6 | 0 | 1 | 0 | 0 | 292 |
| L2932 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L3334 | 4 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 849 |
| L3334 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 767 |
| **Average** | | | Mine | 22% | 2.7 | 2.6 | 2.3 | 1.2 | 0.2 | 0.0 | 0.0 | 327.4 |
| **Average** | | | Opponent | 16% | 3.2 | 2.4 | 2.4 | 2.0 | 0.4 | 0.0 | 0.0 | 199.6 |

### KPIs: dep-mine-13df7bd-p8

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (44 of 178) | 2% (4 of 168) | 14% (48 of 346) |
| Winner chose to follow up after the loser gave ground |  | 93% (54 of 58); on the table 97% | 94% (48 of 51); on the table 94% | 94% (102 of 109); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (8 of 10); on the table 80% | 100% (13 of 13); on the table 100% | 91% (21 of 23); on the table 91% |
| Winner chose to pursue after the loser fled |  | 64% (9 of 14); on the table 64% | 84% (16 of 19); on the table 84% | 76% (25 of 33); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 87% (71 of 82); on the table 89% | 93% (77 of 83); on the table 93% | 90% (148 of 165); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 36% (108 of 298) | 34% (56 of 164) | 35% (164 of 462) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (108 of 244) | 46% (56 of 121) | 45% (164 of 365) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (17 of 24) | 54% (41 of 76) | 58% (58 of 100) |
| Points that never fought | lower | 42% (29095 of 69031) | 41% (29355 of 71983) | 41% (58450 of 141014) |
|   infantry points that never fought | lower | 49% (7627 of 15539) | 59% (8472 of 14377) | 54% (16099 of 29916) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (160 of 273) | 58% (160 of 275) | 58% (320 of 548) |
| Bound items with a magic missile used (at least once a game) |  | 91% (21 of 23); 2.1 uses a game | 95% (19 of 20); 1.7 uses a game | 93% (40 of 43); 1.9 uses a game |
| Bound items with another spell used |  | 47% (7 of 15); 0.4 uses a game | 0% (0 of 1); 0.0 uses a game | 44% (7 of 16); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 50% (8 of 16); 0.2 uses a game | 47% (17 of 36); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (31365 of 57598) | 51% (32239 of 63116) | 53% (63604 of 120714) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (38%) | 0.6 (21%) | 2.7 (32%) |
| MARCHED: its unit marched | 1.2 (24%) | 0.8 (26%) | 2.0 (24%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.2 (8%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 0.9 (17%) | 0.7 (24%) | 1.6 (20%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (6%) | 0.4 (14%) | 0.8 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.4 | 1.3 | 4.6 | 0.4 | 1.5 |
| not cast | 4.6 | 2.1 | 3.7 | 8.3 | 2.0 | 19.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (41%) | 0.1 (4%) | 2.7 (32%) | 0.4 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (24%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (11%) | 0.7 (20%) | 1.6 (20%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (9%) | 0.2 (8%) | 0.3 (9%) | 0.2 (3%) | 0.2 (10%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 1.0 (22%) | 0.1 (7%) | 0.5 (14%) | 0.8 (9%) | 0.1 (4%) | 2.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (10%) | 0.1 (7%) | 0.1 (2%) | 0.3 (3%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (16%) | 0.0 (1%) | 0.1 (1%) | 0.4 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (53%) | 0.1 (7%) | 1.9 (51%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 79% (27 of 34) | 46% (6 of 13) | 70% (33 of 47) |
| the unit moved after it | 67% (18 of 27) | 100% (6 of 6) | 73% (24 of 33) |
| it charged on its next turn | 4% (1 of 27) | 33% (2 of 6) | 9% (3 of 33) |
| the enemy charged it first | 22% (6 of 27) | 0% (0 of 6) | 18% (6 of 33) |
| it fought by the end of its next turn | 7% (2 of 27) | 0% (0 of 6) | 6% (2 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (3 of 27) | 17% (1 of 6) | 12% (4 of 33) |
| none of these (no charge, no fight, no charge escaped) | 63% (17 of 27) | 50% (3 of 6) | 61% (20 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (618 of 949) | 56% (357 of 638) | 61% (975 of 1587) |
|   cavalry | 65% (55 of 85) | 57% (67 of 117) | 60% (122 of 202) |
|   character | 56% (59 of 105) | 22% (21 of 94) | 40% (80 of 199) |
|   chariot | 45% (37 of 82) | 77% (30 of 39) | 55% (67 of 121) |
|   infantry | 58% (187 of 320) | 63% (176 of 280) | 60% (363 of 600) |
|   monster | 48% (21 of 44) | 50% (15 of 30) | 49% (36 of 74) |
|   war machine | 83% (259 of 313) | 62% (48 of 78) | 79% (307 of 391) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (28%) | 1.4 (19%) | 4.1 (24%) |
| CHARGED: it charged | 1.1 (12%) | 1.3 (17%) | 2.4 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.4 (6%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (18%) | 2.0 (26%) | 3.6 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.6 (7%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (20%) | 1.3 (17%) | 3.1 (18%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.4 (5%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.2 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.5 | 77% | 5.3 pts | 25 pts |
| character | 2.6 | 0.8 | 81% | 5.2 pts | 14 pts |
| chariot | 1.9 | 0.6 | 79% | 7.7 pts | 15 pts |
| infantry | 15.7 | 6.2 | 72% | 9.1 pts | 142 pts |
| monster | 1.1 | 0.3 | 76% | 9.1 pts | 10 pts |
| war machine | 8.6 | 6.6 | 65% | 23.8 pts | 204 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 4.5 | 4.3 |
| Charges that made contact a game | 2.8 | 3.2 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.53 declared, 0.26 contact (19 units) | 0.75 declared, 0.33 contact (12 units) | 0.61 declared, 0.29 contact (31 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.92 declared, 0.50 contact (12 units) | 1.00 declared, 0.88 contact (8 units) | 0.95 declared, 0.65 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.38 contact (240 units) | 0.53 declared, 0.39 contact (273 units) | 0.53 declared, 0.38 contact (513 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (26 of 53) | 81% (17 of 21) | 67% (8 of 12) | 59% (51 of 86) |
| Character in a unit | 82% (31 of 38) | 56% (9 of 16) | 67% (2 of 3) | 74% (42 of 57) |
| Character on its own | 89% (33 of 37) | 49% (17 of 35) | 32% (24 of 74) | 51% (74 of 146) |
| Chariot | 84% (16 of 19) | 33% (3 of 9) | - | 68% (19 of 28) |
| Infantry | 55% (40 of 73) | 38% (16 of 42) | 50% (1 of 2) | 49% (57 of 117) |
| Monster | 59% (22 of 37) | 62% (5 of 8) | - | 60% (27 of 45) |
| Monstrous | 80% (8 of 10) | 73% (8 of 11) | - | 76% (16 of 21) |
| War Machines | 70% (32 of 46) | 100% (2 of 2) | - | 71% (34 of 48) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 71% (12 of 17); on the table 71% | 41% (42 of 102) | 28% | 32% (7 of 22) | 100% (6 of 6); 5.5 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 3 | 50% (1 of 2); on the table 50% | 33% (10 of 30) | 29% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (9 of 9); on the table 100% | - | 58% | 65% (26 of 40) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 50% (4 of 8); on the table 75% | 42% (10 of 24) | 72% | 69% (37 of 54) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 7 | 100% (9 of 9); on the table 100% | 38% (57 of 150) | 62% | 53% (31 of 58) | 94% (15 of 16); 6.9 uses a game | 0% (0 of 2); 0.0 uses a game | 43% (3 of 7); 0.4 uses a game |
| High Elf Realms | 5 | 92% (11 of 12); on the table 92% | 17% (2 of 12) | 30% | 46% (18 of 39) | 83% (5 of 6); 4.2 uses a game | 40% (4 of 10); 1.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (5 of 5); on the table 100% | - | 46% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 3 | 100% (6 of 6); on the table 100% | - | 38% | 48% (10 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | - | 43% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (4 of 4); on the table 100% | 6% (1 of 18) | 11% | 83% (20 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 100% (25 of 25); on the table 100% | 33% (18 of 54) | 43% | 67% (35 of 52) | 100% (5 of 5); 1.7 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 6 | 85% (11 of 13); on the table 85% | - | 35% | 53% (16 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 100% (12 of 12); on the table 100% | 50% (18 of 36) | 31% | 69% (20 of 29) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 92% (24 of 26); on the table 92% | 25% (6 of 24) | 36% | 49% (37 of 76) | 100% (1 of 1); 0.4 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 6 | 86% (12 of 14); on the table 86% | 0% (0 of 12) | 42% | 63% (34 of 54) | 88% (7 of 8); 5.0 uses a game | 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p8, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (31) | 50% (32) | 47% (63) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.50 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.19 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.31 | 0.64 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.44 | 3.14 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.47 | 1.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.94 | 5.89 | 10.83 |

### Quality by phase: dep-mine-13df7bd-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.2 |
| Strategy | Charge objectives carried out (made contact) | 47% (64 of 135) | 42% (56 of 134) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (207 of 439) | 42% (79 of 189) |
| Strategy | Close-in objectives charged next turn | 15% (25 of 168) | 13% (26 of 204) |
| Strategy | Support requests answered (helper made contact too) | 38% (6 of 16) | 41% (11 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 46% (6 of 13) | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 44% (23 of 52) | 33% (11 of 33) |
| Strategy | Lone characters that fought | 74% (65 of 88) | 76% (68 of 89) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.2 | 2.0 |
| Movement | Points that never moved of their own | 327.4 | 199.6 |
| Movement | Fights charged into per game | 2.6 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 84, net -61 | 14 of 73, net +158 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 84, net +18 | 14 of 73, net +26 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 84, net +56 | 6 of 73, net -16 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 84, net +76 | 18 of 73, net +97 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 10.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (165 of 388) | 36% (132 of 364) |
| Shooting | Points destroyed by shooting units | 77.6 | 20.9 |
| Shooting | War machine shots | 7.2 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (113 of 259) | 33% (16 of 49) |
| Shooting | Points destroyed by war machines | 72.6 | 5.0 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (29 of 67) | 32% (13 of 41) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.1 |
| Magic | Wounds caused by other spells | 1.2 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 84.2 | 27.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.5 / 0.1 | 1.8 / 0.2 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 335.8 | 441.1 |
| Combat | Points run down | 63.9 | 103.6 |
| Combat | Net points per charged fight, damage counted | +47 | +82 |
| Combat | Net per 100 charger points, damage counted | +17.7 | +26.2 |
| Combat | First round won (charged fights) | 77% | 78% |
| Combat | Net points per charged fight | +40 | +87 |
| Combat | Net points per supported fight / lone fight | +39 / +40 | +52 / +91 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 95 | 44 of 99 |
| Game | Points lost | 723.4 | 723.0 |
| Game | VP from objectives | 585.6 | 565.6 |
| Game | Lone holders (player turns) | 2.7 | 3.2 |

- Mine won / drew / lost: 12 / 10 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +10 VP
- The side that went first won 9 of 26 games with a winner
- Points traded per game (both sides' losses): 1446
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-mine-13df7bd-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 6.2 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 32.4 | 0.1 | +0.0 | 0.0 | 9.2 |
| BACKUP TARGETS | 0.7 | +5.2 | 0.0 | 15.1 | 0.8 | +7.6 | 0.0 | 16.1 |
| BEST FACING | 0.6 | +17.6 | 0.0 | 19.9 | 0.8 | +36.8 | 0.0 | 28.8 |
| BEST FIRST | 3.7 | +136.0 | 66.4 | 81.0 | 3.7 | +149.7 | 133.9 | 107.0 |
| BEST OVERALL | 0.8 | +56.8 | 0.0 | 43.1 | 0.7 | +31.6 | 0.0 | 51.3 |
| BEST PREY | 0.8 | +49.2 | 24.2 | 4.2 | 0.9 | +40.3 | 19.7 | 21.1 |
| BEST PRIZE | 0.1 | -2.4 | 5.4 | 7.1 | 0.0 | +0.1 | 3.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.1 | 0.0 | 0.1 | +0.0 | 14.2 | 0.0 |
| BLOCKED WHEEL | 0.4 | +5.6 | 0.0 | 0.0 | 0.4 | +1.0 | 0.0 | 5.4 |
| BLOWS WHERE AIMED | 0.3 | -17.8 | 33.0 | 0.0 | 0.2 | -52.8 | 18.1 | 9.5 |
| BOMBING RUN | 0.1 | +7.3 | 0.0 | 0.0 | 0.0 | +0.5 | 6.3 | 4.2 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 95.8 | 4.6 | 0.2 | +0.0 | 7.1 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +134.9 | 341.0 | 71.0 | 1.1 | +45.5 | 32.6 | 22.9 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.6 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 7.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 1.1 | 7.1 | 0.1 | -1.2 | 21.4 | 0.0 |
| CAST JOB | 1.2 | +28.9 | 83.1 | 37.1 | 0.4 | +10.8 | 10.7 | 39.5 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +79.6 | 17.2 | 0.0 | 0.1 | +6.7 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 22.2 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.0 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.9 | 24.9 | 1.5 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 232.9 | 47.6 | 2.1 | +0.0 | 238.8 | 44.3 |
| CHARGE NOW WEIGHED | 0.8 | -50.4 | 42.9 | 18.9 | 0.7 | -57.6 | 5.1 | 33.9 |
| CHARGER SLAIN LOST | 0.5 | -15.4 | 49.6 | 21.8 | 0.6 | -10.8 | 65.9 | 25.8 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.1 | 11.6 | 22.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 11.3 | 0.0 | 0.2 | +0.0 | 9.6 | 2.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 31.0 | 46.4 | 0.2 | +0.0 | 15.0 | 1.9 |
| CONVEYANCE SEARCH | 0.9 | +173.6 | 31.9 | 11.1 | 0.1 | +6.3 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.4 | +866.5 | 0.0 | 167.3 | 7.3 | +747.1 | 0.0 | 168.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 23.1 | 2.5 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +9.4 | 0.0 | 12.7 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.0 | 21.8 | 9.6 | 0.1 | +1.2 | 12.2 | 2.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +125.1 | 0.0 | 67.6 | 1.4 | +115.8 | 0.0 | 72.1 |
| FALLBACK BY WORTH | 4.8 | +100.9 | 0.0 | 47.2 | 5.5 | +41.9 | 0.0 | 60.5 |
| FIGHT LIFT | 0.2 | +2.6 | 23.6 | 0.0 | 0.1 | +1.2 | 16.2 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.2 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 136.1 | 6.2 | +0.0 | 0.0 | 146.9 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.4 | 0.0 | 1.7 |
| FOLLOW UP WEIGHED | 0.8 | +108.7 | 0.0 | 33.0 | 1.0 | +154.1 | 0.0 | 36.1 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.2 | 0.0 | 8.2 | 0.1 | +7.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.4 | 3.8 | 0.0 | 0.1 | -1.2 | 16.0 | 5.4 |
| GROUND FLIERS | 0.1 | +1.8 | 0.0 | 6.6 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 13.8 | 0.0 | 0.1 | +0.0 | 3.1 | 1.7 |
| HELPER UNSEEN | 0.2 | +0.0 | 19.4 | 9.9 | 0.2 | +0.0 | 26.8 | 8.3 |
| HILL BY ITS CHANCE | 0.2 | -8.3 | 0.0 | 0.0 | 0.3 | -29.3 | 0.0 | 4.4 |
| HOLDER AT DEPLOYMENT | 0.8 | +157.6 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.1 | -147.6 | 338.1 | 105.9 | 7.7 | -203.2 | 388.6 | 182.4 |
| HORN WORTH | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +3.3 | 0.0 | 4.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 4.6 | 6.0 |
| HUNT IN PAIRS | 0.4 | +27.5 | 0.0 | 0.0 | 0.5 | +26.5 | 0.0 | 28.2 |
| HUNT KEPT | - | - | - | - | 0.2 | +6.4 | 0.0 | 9.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +2.4 | 4.6 | 14.2 |
| HUNT THE GUNS | 0.0 | +6.2 | 0.0 | 0.0 | 0.2 | +55.7 | 0.0 | 2.0 |
| INVITES THE FIGHT | 1.3 | +21.2 | 30.2 | 1.4 | 1.4 | +29.1 | 71.1 | 32.9 |
| JOINT CHARGE PLAN | 0.1 | +7.9 | 9.5 | 0.0 | 0.2 | +1.6 | 0.0 | 5.8 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.4 | 8.1 | 0.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 118.2 | 33.5 | 1.8 | +52.5 | 137.5 | 41.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +73.3 | 133.1 | 31.2 | 1.4 | +70.6 | 128.5 | 38.6 |
| KILLS COUNT NEXT TURN | 5.1 | +177.2 | 139.7 | 123.0 | 6.5 | +201.1 | 146.5 | 148.8 |
| LANE BY FIGURES | 0.7 | +24.2 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +5.6 | 21.9 | 12.9 | 0.2 | +4.8 | 9.9 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +41.4 | 0.0 | 0.0 | 0.4 | +30.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.2 | 18.1 | 6.6 | 0.5 | +0.2 | 7.1 | 5.6 |
| LOST CHARGE | 2.1 | -36.7 | 44.4 | 78.8 | 2.0 | -22.1 | 54.2 | 49.8 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.3 | 0.0 | 1.9 | 0.1 | -4.0 | 0.0 | 1.2 |
| MAKE SURE TOGETHER | 0.7 | +75.1 | 28.2 | 35.8 | 0.9 | +87.8 | 0.0 | 10.9 |
| MANOEUVRE | 0.2 | +5.9 | 0.0 | 0.0 | 0.2 | +2.6 | 0.0 | 5.7 |
| MARCH AT ESCAPER | 0.2 | +1.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +15.5 | 0.0 | 0.0 | 0.5 | +23.9 | 0.0 | 5.5 |
| MARCH ODDS | 0.4 | +21.5 | 9.9 | 0.0 | 0.2 | +12.8 | 6.2 | 0.0 |
| MARCH OVER CASTS | 0.6 | +31.3 | 0.0 | 26.1 | 0.5 | +11.8 | 0.0 | 6.5 |
| MAX FOR POSITIONING | 4.0 | +155.9 | 0.0 | 96.6 | 5.1 | +193.1 | 0.0 | 118.1 |
| MISSILES IN THE MOVE | 4.7 | +158.8 | 0.0 | 64.1 | 3.1 | +50.4 | 0.0 | 105.9 |
| MISSILES NEXT TURN | 5.6 | +97.0 | 0.0 | 114.0 | 4.0 | +34.0 | 0.0 | 103.2 |
| MODEL FACING | 0.4 | +81.0 | 0.0 | 1.7 | 0.1 | +26.1 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.5 | 21.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +23.7 | 0.0 | 5.4 | 0.4 | +23.6 | 0.0 | 3.0 |
| MOVE SPELL IN RANGE | 0.2 | +10.1 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -23.5 | 0.0 | 0.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +289.1 | 100.8 | 41.5 | 4.3 | +292.6 | 104.6 | 107.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +15.9 | 0.0 | 0.0 | 0.1 | +13.5 | 14.1 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +3.9 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -3.7 | 14.0 | 0.0 | 0.2 | -10.3 | 49.2 | 1.8 |
| NOT TURNED | 4.9 | +110.1 | 0.0 | 76.1 | 5.9 | +49.3 | 0.0 | 95.7 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 46.7 | 0.6 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -729.6 | 0.0 | 199.9 | 15.3 | -825.3 | 18.9 | 307.3 |
| OPENS A LANE | 0.1 | +1.9 | 1.1 | 0.0 | 0.1 | +0.2 | 15.5 | 0.0 |
| OPENS UP | 0.1 | +5.9 | 3.8 | 0.0 | 0.2 | +16.1 | 4.8 | 0.0 |
| OVERRUN THREAT | 0.0 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +7.1 | 35.3 | 9.6 | 0.3 | +8.1 | 35.0 | 2.8 |
| PATHS CROSS | 1.8 | +103.5 | 0.0 | 20.8 | 2.4 | +175.8 | 0.0 | 10.6 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 15.0 | 0.1 | +7.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 0.8 | 0.2 | -3.7 | 0.0 | 0.0 |
| PLAN RESULT | 38.5 | +1437.8 | 1245.6 | 935.4 | 35.8 | +1008.8 | 1101.8 | 907.0 |
| PURSUES BIG PREY | 0.0 | -0.6 | 0.0 | 0.0 | 0.2 | -6.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +17.4 | 0.0 | 28.1 | 2.1 | +43.5 | 0.0 | 69.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -9.2 | 10.3 | 9.4 | 0.6 | -40.2 | 4.9 | 9.9 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.1 | 0.0 | 2.0 | 0.6 | -8.1 | 0.0 | 13.3 |
| REDIRECT COUNTER | 2.1 | +203.7 | 0.0 | 33.7 | 3.5 | +187.0 | 0.0 | 79.6 |
| REDIRECT WEIGHED | 0.2 | +3.3 | 8.4 | 14.7 | 0.5 | +11.6 | 23.5 | 4.6 |
| REFUSING RETIRES | 0.6 | +0.0 | 0.0 | 28.5 | 0.4 | +0.0 | 0.0 | 24.3 |
| RESERVE FALL BACK | 0.4 | +15.0 | 0.0 | 9.4 | 1.0 | +34.2 | 0.0 | 24.1 |
| RESTRAINS TO SHOOT | 0.1 | +3.2 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +107.6 | 202.8 | 64.5 | 2.0 | +65.9 | 208.4 | 41.9 |
| SAFE SURE CHARGE | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +72.5 | 0.0 | 8.0 | 0.5 | +16.8 | 0.0 | 15.2 |
| SCOUT SPOT | 0.4 | +1.5 | 0.0 | 0.9 | 0.2 | +1.1 | 0.0 | 1.8 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.2 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.5 | 0.0 | 0.0 | 0.2 | -12.4 | 0.0 | 3.7 |
| SEARCH SPOT | 2.2 | +111.0 | 0.0 | 66.8 | 2.1 | +99.1 | 0.0 | 17.9 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.3 | +0.3 | 0.0 | 0.0 | 0.2 | +63.1 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.2 | +147.5 | 40.8 | 35.8 | 2.2 | +231.9 | 7.6 | 56.4 |
| SET-UP ANY TARGET | 0.3 | +45.4 | 26.7 | 11.1 | 0.1 | +18.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +1.0 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +29.4 | 59.4 | 10.1 | 1.1 | +22.1 | 37.3 | 15.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 149.8 | 3.0 | 0.3 | +0.0 | 23.2 | 0.0 |
| SHOTS IN THE MOVE | 15.6 | +543.8 | 0.0 | 192.7 | 8.6 | +210.9 | 0.0 | 113.4 |
| SPELL CATCH ODDS | 0.0 | -0.8 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +137.1 | 26.7 | 11.1 | 0.1 | +18.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.6 | +24.1 | 147.2 | 135.1 | 1.1 | +28.1 | 87.0 | 60.0 |
| SPELLS IN THE FIGHT | 0.5 | +4.7 | 42.3 | 0.0 | 0.4 | -4.4 | 47.7 | 24.1 |
| STABLE ROLE | 10.7 | +0.0 | 244.5 | 184.9 | 8.9 | +0.0 | 187.3 | 165.1 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.9 | 0.0 | 9.5 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +7.1 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +7.5 | 0.0 | 5.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +11.8 | 0.0 | 16.3 | 0.6 | +30.1 | 0.0 | 23.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 14.6 |
| SUPPORT NARROWED | 4.9 | -27.4 | 214.9 | 78.1 | 5.8 | -39.3 | 320.4 | 102.8 |
| SUPPORTS | 3.0 | +29.5 | 95.9 | 50.9 | 4.0 | +39.3 | 149.2 | 57.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.6 | 3.0 | 4.2 | 0.2 | -7.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -1.9 | 0.0 | 0.0 | 0.6 | +6.8 | 11.2 | 23.8 |
| THROUGH LINE OF FIRE | 0.4 | +10.7 | 0.0 | 0.0 | 0.2 | +9.8 | 0.0 | 1.9 |
| TURN WORTH | 0.3 | -18.9 | 25.2 | 5.2 | 0.0 | -1.8 | 5.4 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +7.5 | 18.7 | 11.1 | 0.5 | +4.2 | 0.0 | 12.4 |
| WAIT AFTER COSTS | 7.0 | -317.7 | 193.2 | 96.5 | 7.2 | -382.8 | 249.8 | 165.7 |
| WALKS TO THE FIGHT | 1.9 | +27.9 | 44.8 | 13.7 | 0.8 | +9.6 | 11.1 | 14.7 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 4.0 | 12.9 | 0.1 | +0.0 | 10.0 | 12.4 |
| WEARS DOWN | 1.1 | +32.9 | 111.6 | 29.8 | 0.8 | +24.5 | 114.9 | 28.2 |
| WHO HITS BACK | 0.3 | +30.9 | 0.0 | 27.9 | 0.1 | +2.8 | 0.0 | 9.9 |
| WHOLE FIGHT | 0.3 | +15.6 | 31.4 | 3.1 | 0.2 | +12.9 | 38.3 | 1.8 |
| WHOLE FIGHT GAIN | 0.4 | +22.7 | 42.5 | 11.9 | 0.4 | +26.7 | 36.9 | 4.0 |
| WIDER SPREAD | 2.5 | -5.8 | 197.9 | 32.5 | 2.5 | -5.8 | 282.9 | 51.4 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 1.4 |

### Rule changes: dep-mine-13df7bd-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1112 | 1112 | 1112 | 30.89 | -55976 | -50.3 |
| BEST FIRST | 265 | 265 | 265 | 7.36 | +10286 | +38.8 |
| DEPLOY BY FIGURES | 287 | 287 | 167 | 4.64 | +1919 | +11.5 |
| SEARCH SPOT | 157 | 157 | 156 | 4.33 | +7562 | +48.5 |
| PATHS CROSS | 151 | 151 | 151 | 4.19 | +10053 | +66.6 |
| MOVE TO CHARGE | 265 | 265 | 147 | 4.08 | +6873 | +46.8 |
| COUNTER-CHARGE COVER | 566 | 290 | 136 | 3.78 | +11389 | +83.7 |
| KILLS COUNT NEXT TURN | 417 | 417 | 122 | 3.39 | +3793 | +31.1 |
| FACES THE THREAT | 113 | 113 | 113 | 3.14 | +8672 | +76.7 |
| SUPPORTS | 253 | 253 | 92 | 2.56 | +572 | +6.2 |
| FALLBACK BY WORTH | 372 | 372 | 75 | 2.08 | +5144 | +68.6 |
| SET UP TOGETHER | 123 | 108 | 73 | 2.03 | +5865 | +80.3 |
| SHOTS IN THE MOVE | 870 | 569 | 71 | 1.97 | +1251 | +17.6 |
| WAIT AFTER COSTS | 509 | 509 | 71 | 1.97 | +1419 | +20.0 |
| FOLLOW UP WEIGHED | 67 | 67 | 67 | 1.86 | +9463 | +141.2 |
| ARTILLERY RE-ROLL WEIGHED | 63 | 63 | 63 | 1.75 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 100 | 100 | 58 | 1.61 | +2194 | +37.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CANNON SIGHT KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| BEST OVERALL | 53 | 53 | 53 | 1.47 | +3183 | +60.0 |
| CHARGE NOW WEIGHED | 53 | 53 | 53 | 1.47 | +4054 | +76.5 |
| BEST FACING | 50 | 50 | 50 | 1.39 | +1959 | +39.2 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1770 | +35.4 |
| WALKS TO THE FIGHT | 95 | 95 | 50 | 1.39 | +681 | +13.6 |
| SAFER THAN THE JOB | 49 | 49 | 49 | 1.36 | +3214 | +65.6 |
| CHARGE NOW FIRST | 163 | 163 | 48 | 1.33 | -2903 | -60.5 |
| CANNON PLANNED TARGET | 231 | 231 | 44 | 1.22 | -264 | -6.0 |
| REDIRECT COUNTER | 202 | 102 | 43 | 1.19 | +3161 | +73.5 |
| RISK BY ARC | 153 | 145 | 39 | 1.08 | +985 | +25.3 |
| HOLDS AMBUSHERS | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| SHOT REPLANNED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| MAX FOR POSITIONING | 326 | 171 | 36 | 1.00 | +541 | +15.0 |
| MISSILES IN THE MOVE | 278 | 154 | 36 | 1.00 | +418 | +11.6 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +1507 | +43.1 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2583 | +76.0 |
| SHOOTS FROM THE BEST SPOT | 82 | 82 | 34 | 0.94 | +783 | +23.0 |
| MARCH CHECK | 35 | 34 | 32 | 0.89 | +1095 | +34.2 |
| HONEST WORTH | 568 | 564 | 29 | 0.81 | +271 | +9.4 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1701 | +58.7 |
| CAST JOB | 59 | 59 | 28 | 0.78 | +642 | +22.9 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +1557 | +57.7 |
| BEST PREY | 59 | 59 | 26 | 0.72 | +1822 | +70.1 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +238 | +9.1 |
| KILLS COUNT | 114 | 112 | 26 | 0.72 | +1266 | +48.7 |
| LANE BY FIGURES | 25 | 25 | 25 | 0.69 | +872 | +34.9 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +67 | +2.7 |
| KEEPS ITS TARGET | 116 | 114 | 24 | 0.67 | +371 | +15.5 |
| SCOUT WAITS | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| MARCH ODDS | 22 | 22 | 21 | 0.58 | +81 | +3.8 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +736 | +35.1 |
| CASTING BLOCK | 21 | 21 | 20 | 0.56 | +1597 | +79.8 |
| MAKE SURE TOGETHER | 57 | 37 | 20 | 0.56 | +1745 | +87.2 |
| WHOLE FIGHT GAIN | 32 | 30 | 19 | 0.53 | +679 | +35.7 |
| INVITES THE FIGHT | 99 | 99 | 18 | 0.50 | +260 | +14.5 |
| MODEL FACING | 17 | 17 | 17 | 0.47 | +3854 | +226.7 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 29 | 29 | 15 | 0.42 | +669 | +44.6 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +779 | +52.0 |
| HUNT IN PAIRS | 35 | 21 | 14 | 0.39 | +654 | +46.7 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +623 | +51.9 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -37 | -3.4 |
| MANOEUVRE | 12 | 12 | 11 | 0.31 | +306 | +27.9 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -476 | -43.3 |
| WEARS DOWN | 68 | 63 | 11 | 0.31 | +271 | +24.7 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -20 | -2.0 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -192 | -19.2 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| REFUSING RETIRES | 36 | 36 | 9 | 0.25 | -4 | -0.5 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -270 | -33.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +168 | +24.0 |
| WAR ENGINE JOBS | 23 | 23 | 7 | 0.19 | -301 | -43.0 |
| WHOLE FIGHT | 18 | 18 | 7 | 0.19 | +471 | +67.3 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -131 | -21.9 |
| MISSILES NEXT TURN | 344 | 180 | 6 | 0.17 | +1 | +0.1 |
| OPENS UP | 11 | 11 | 6 | 0.17 | +340 | +56.7 |
| LONG SHOT | 32 | 31 | 5 | 0.14 | +135 | +27.0 |
| LOST CHARGE | 147 | 144 | 5 | 0.14 | +482 | +96.5 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +281 | +70.3 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +378 | +94.6 |
| WIDER SPREAD | 179 | 173 | 4 | 0.11 | +9 | +2.4 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +301 | +100.4 |
| STOPS | 5 | 5 | 3 | 0.08 | +24 | +8.1 |
| SURE REACH TOGETHER | 39 | 29 | 3 | 0.08 | +4 | +1.2 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -42 | -20.8 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -8 | -4.1 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +51 | +25.4 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +35 | +17.6 |
| HUNT ADVANCE | 7 | 7 | 2 | 0.06 | +16 | +8.2 |
| JOINT CHARGE PLAN | 11 | 11 | 2 | 0.06 | +83 | +41.4 |
| OPENS A LANE | 7 | 5 | 2 | 0.06 | +27 | +13.3 |
| OVERRUNS AWAY | 25 | 23 | 2 | 0.06 | +65 | +32.3 |
| REDIRECT BY WHAT IT STOPS | 33 | 33 | 2 | 0.06 | +49 | +24.7 |
| SPELLS IN THE FIGHT | 35 | 33 | 2 | 0.06 | +24 | +12.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +260 | +130.1 |
| BACKUP TARGETS | 56 | 25 | 1 | 0.03 | +1 | +0.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +13 | +12.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +8 | +7.6 |
| HILL BY ITS CHANCE | 17 | 17 | 1 | 0.03 | +59 | +59.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +32 | +31.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +82 | +81.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +33 | +33.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -16 | -16.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -28 | -27.6 |
| SUPPORT NARROWED | 383 | 383 | 1 | 0.03 | -29 | -28.5 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -78 | -78.3 |
| ALREADY CARRIED | 10 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 20 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 39 | 35 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 10 | 10 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 12 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 406 | not checked | - | - | - | - |
| GIVES UP | 8 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 16 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 11 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 32 | 32 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 12 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 390 | 390 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2677 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 25 | 25 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 97 | not checked | - | - | - | - |
| STABLE ROLE | 706 | 703 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 30 | 27 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 13.47 | 51.5 |
| CHARGE NOW FIRST | rule | 0.64 | 0.69 | 60.5 |
| TURN GATE | gate | 0.50 | 0.81 | 38.9 |
| FALLBACK | gate | 0.56 | 0.64 | 49.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.19 | 43.3 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.17 | 19.2 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.03 | 65.2 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 74.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.19 | 33.7 |
| CHAFF PASSED | rule | 0.14 | 0.06 | 5.3 |
| PATHS CROSS | rule | 0.11 | 0.08 | 36.3 |
| WAR ENGINE JOBS | rule | 0.17 | 0.03 | 43.0 |
| BEST PRIZE | rule | 0.14 | 0.03 | 21.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.06 | 35.1 |
| AFTERMATH BAND | gate | 0.06 | 0.08 | 1.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 12.9 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.03 | 25.2 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 6.7 |
| NO REASON | gate | 0.11 | - | 13.9 |
| REFUSING RETIRES | rule | 0.11 | - | 0.9 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 42.6 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 44.0 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 8.3 |
| MARCH ODDS | rule | 0.03 | 0.06 | 26.1 |
| REDIRECT WEIGHED | rule | 0.06 | 0.03 | 21.8 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 20.8 |
| CATCH ODDS | rule | 0.06 | - | 4.1 |
| FIGHT ORDER BAND | gate | - | 0.06 | 1.8 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.1 |
| RULE SWITCHED OFF | gate | - | 0.06 | 53.4 |
| LONG SHOT | rule | - | 0.03 | 19.9 |
| SAFE SURE CHARGE | rule | 0.03 | - | 16.3 |
| STANDS TO CAST | rule | - | 0.03 | 27.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 1.9 |
| SUPPORT NARROWED | rule | 0.03 | - | 28.5 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 78.3 |

### Plans: dep-mine-13df7bd-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.3 | 17% | 360 | 267 | 74% |
| Mine | charge | 3.4 | 57% | 274 | 271 | 99% |
| Mine | close in | 4.7 | 25% | 295 | 137 | 46% |
| Mine | hold | 4.9 | 37% | 295 | 0 | 0% |
| Mine | join | 0.5 | 89% | 14 | 0 | 0% |
| Mine | shoot | 10.4 | 66% | 309 | 764 | 248% |
| Mine | support | 3.4 | 89% | 20 | 0 | 0% |
| Opponent | advance | 12.6 | 13% | 325 | 291 | 90% |
| Opponent | charge | 3.4 | 61% | 285 | 364 | 128% |
| Opponent | close in | 5.6 | 23% | 405 | 137 | 34% |
| Opponent | hold | 4.8 | 34% | 307 | 0 | 0% |
| Opponent | join | 0.4 | 100% | 18 | 0 | 0% |
| Opponent | shoot | 4.4 | 54% | 70 | 216 | 307% |
| Opponent | support | 4.7 | 82% | 31 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p8

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 223 | 0 | 0% | 7 |
| Opponent | 0.2 | 6 | 0 | 0% | 0% | 17% | - | 334 | 14 | 0% | 85 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 223 | 0 | 0% | 55 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 109 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 142 |
| Tomb Kings of Khemri | 0.7 | 4 | 0 | 0% | 0% | 0% | - | 314 | 0 | 0% | 24 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 100% | - | 645 | 87 | 0% | 29 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 105 | 0 | 0% | 0 |

### Battle groups: dep-mine-13df7bd-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.4 | 19% | 54% | 7% | 50% | 38% | 9% | 8% | 45% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 18% | 79% | 7% | 0% | 31% | 0% | 8% | 62% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 21% | 57% | 17% | 22% | 31% | 7% | 11% | 51% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 27% | 59% | 12% | 0% | 30% | 0% | 17% | 53% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Mine | Chaff | 33 | 134 (33) | 60 | 74 | 52 | 45% | 2.1 | 212 (16) | 67 (13) | 0 (4) | 114 (24) | 185 (9) |
| Mine | Character | 121 | 47 (121) | 47 | 0 | 38 | 17% | 2.3 | 52 (49) | 56 (47) | 23 (11) | 60 (55) | 39 (52) |
| Mine | Clean-up | 25 | 33 (25) | 5 | 28 | 31 | 48% | 3.3 | 22 (8) | 42 (15) | 0 (2) | 62 (14) | 4 (11) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 47 | 0% | 1.7 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 49 | 30 (49) | 21 | 9 | 48 | 24% | 2.9 | 33 (19) | 42 (21) | 0 (9) | 17 (32) | 54 (17) |
| Mine | Fragile | 5 | 20 (5) | 20 | 0 | 0 | 0% | 2.2 | - | 0 (3) | 51 (2) | 25 (4) | 0 (1) |
| Mine | Hammer | 54 | 32 (54) | 25 | 8 | 40 | 17% | 2.4 | 26 (25) | 46 (22) | 10 (7) | 35 (35) | 27 (19) |
| Mine | Holder | 21 | 63 (21) | 5 | 58 | 48 | 43% | 2.7 | 40 (4) | 90 (12) | 32 (5) | 68 (13) | 50 (8) |
| Mine | Shooter | 41 | 75 (41) | 41 | 35 | 28 | 2% | 1.8 | 43 (12) | 90 (25) | 88 (4) | 100 (23) | 45 (18) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 0 | 25% | 4.0 | - | 0 (3) | 0 (1) | 0 (1) | 0 (3) |
| Mine | War machine | 58 | 45 (58) | 45 | 0 | 32 | 2% | 1.4 | 57 (17) | 42 (34) | 30 (7) | 57 (15) | 40 (43) |
| Mine | Wizard | 19 | 9 (19) | 9 | 0 | 31 | 16% | 2.4 | 30 (6) | 2 (6) | 0 (3) | 16 (8) | 5 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 66 | 39 (66) | 22 | 17 | 57 | 47% | 2.7 | 53 (25) | 0 (8) | 38 (33) | 36 (47) | 45 (19) |
| Opponent | Character | 96 | 56 (96) | 56 | 0 | 28 | 24% | 2.3 | 75 (34) | 48 (47) | 6 (3) | 47 (48) | 69 (36) |
| Opponent | Clean-up | 22 | 18 (22) | 17 | 1 | 47 | 36% | 3.3 | 0 (7) | 29 (12) | 12 (3) | 13 (16) | 31 (6) |
| Opponent | Fast | 4 | 41 (4) | 41 | 0 | 100 | 0% | 1.5 | - | 41 (4) | - | 0 (3) | 111 (1) |
| Opponent | Fast Hammer | 44 | 30 (44) | 18 | 12 | 47 | 39% | 2.6 | 16 (19) | 41 (15) | 37 (10) | 27 (31) | 38 (13) |
| Opponent | Fragile | 15 | 41 (15) | 41 | 0 | 76 | 33% | 2.0 | 108 (6) | 0 (6) | 0 (3) | 0 (2) | 47 (13) |
| Opponent | Hammer | 53 | 42 (53) | 25 | 17 | 49 | 21% | 3.0 | 26 (21) | 60 (25) | 16 (7) | 36 (28) | 50 (25) |
| Opponent | Holder | 37 | 78 (37) | 6 | 71 | 32 | 49% | 2.3 | 66 (8) | 107 (19) | 24 (8) | 80 (20) | 84 (15) |
| Opponent | Shooter | 32 | 92 (32) | 15 | 78 | 30 | 6% | 1.7 | 31 (9) | 113 (22) | 301 (1) | 81 (18) | 104 (14) |
| Opponent | Support | 5 | 0 (5) | 0 | 0 | 41 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | War machine | 16 | 12 (16) | 12 | 0 | 39 | 6% | 1.7 | 0 (4) | 6 (10) | 62 (2) | 21 (6) | 7 (10) |
| Opponent | Wizard | 27 | 16 (27) | 16 | 0 | 43 | 11% | 2.3 | 13 (10) | 29 (6) | 3 (4) | 13 (14) | 23 (6) |

### Charged fights: dep-mine-13df7bd-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 209 | 123 | 1.2 | 1.0 | 99 | 0 | +99 | 0 of 5 | 5 of 5 | - | +99 |
| Mine | Chaos Dwarfs | 3 | 144 | 167 | 1.3 | 1.0 | 125 | 0 | +125 | 1 of 4 | 2 of 4 | - | +125 |
| Mine | Dwarfen Mountain Holds | 4 | 263 | 36 | 1.5 | 1.2 | 24 | 38 | -14 | 1 of 6 | 4 of 6 | -165 | +16 |
| Mine | Empire of Man | 5 | 615 | 111 | 1.8 | 1.0 | 61 | 63 | -1 | 3 of 9 | 8 of 9 | - | -1 |
| Mine | Grand Cathay | 4 | 465 | 258 | 2.0 | 1.0 | 129 | 0 | +129 | 2 of 8 | 8 of 8 | - | +129 |
| Mine | High Elf Realms | 4 | 133 | 464 | 4.8 | 1.1 | 98 | 37 | +61 | 3 of 19 | 14 of 19 | +85 | +58 |
| Mine | Kingdom of Bretonnia | 1 | 70 | 196 | 4.0 | 1.0 | 49 | 0 | +49 | 1 of 4 | 4 of 4 | - | +49 |
| Mine | Lizardmen | 1 | 165 | 895 | 5.0 | 1.2 | 179 | 0 | +179 | 2 of 5 | 4 of 5 | +210 | +171 |
| Mine | Ogre Kingdoms | 1 | 65 | 290 | 4.0 | 1.0 | 72 | 22 | +50 | 1 of 4 | 3 of 4 | - | +50 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 500 | 5.0 | 1.2 | 100 | 11 | +89 | 2 of 5 | 4 of 5 | +145 | +75 |
| Mine | Skaven | 2 | 33 | 185 | 2.0 | 1.0 | 92 | 0 | +92 | 0 of 4 | 4 of 4 | - | +92 |
| Mine | Tomb Kings of Khemri | 2 | 19 | 133 | 2.5 | 1.4 | 53 | 166 | -112 | 2 of 5 | 2 of 5 | +0 | -187 |
| Mine | Vampire Counts | 2 | 15 | 158 | 3.5 | 1.1 | 45 | 202 | -157 | 5 of 7 | 2 of 7 | -49 | -175 |
| Mine | Warriors of Chaos | 1 | 0 | 305 | 5.0 | 1.0 | 61 | 0 | +61 | 4 of 5 | 4 of 5 | - | +61 |
| Mine | Wood Elf Realms | 1 | 216 | 278 | 5.0 | 1.0 | 56 | 59 | -3 | 1 of 5 | 5 of 5 | - | -3 |
| **Mine** | all armies | 36 | 234 | 222 | 2.6 | 1.1 | 84 | 44 | +40 | 28 of 95 | 73 of 95 | +39 | +40 |
| Opponent | Dwarfen Mountain Holds | 1 | 160 | 138 | 2.0 | 1.0 | 69 | 0 | +69 | 1 of 2 | 2 of 2 | - | +69 |
| Opponent | Grand Cathay | 3 | 42 | 247 | 3.0 | 1.2 | 82 | 0 | +82 | 3 of 9 | 7 of 9 | +95 | +81 |
| Opponent | High Elf Realms | 1 | 0 | 651 | 3.0 | 1.7 | 217 | 0 | +217 | 1 of 3 | 3 of 3 | +0 | +326 |
| Opponent | Kingdom of Bretonnia | 2 | 42 | 111 | 3.0 | 1.0 | 37 | 108 | -71 | 2 of 6 | 4 of 6 | - | -71 |
| Opponent | Lizardmen | 2 | 230 | 853 | 4.0 | 1.0 | 213 | 68 | +145 | 3 of 8 | 5 of 8 | - | +145 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 472 | 4.5 | 1.1 | 105 | 58 | +47 | 7 of 9 | 6 of 9 | +135 | +36 |
| Opponent | Skaven | 4 | 0 | 25 | 1.8 | 1.6 | 14 | 69 | -54 | 0 of 7 | 7 of 7 | +0 | -76 |
| Opponent | Tomb Kings of Khemri | 4 | 52 | 638 | 3.8 | 1.3 | 170 | 76 | +94 | 6 of 15 | 10 of 15 | +86 | +98 |
| Opponent | Vampire Counts | 3 | 0 | 438 | 2.0 | 1.2 | 219 | 8 | +210 | 5 of 6 | 4 of 6 | +0 | +253 |
| Opponent | Warriors of Chaos | 9 | 39 | 380 | 2.0 | 1.1 | 190 | 31 | +159 | 11 of 18 | 16 of 18 | +0 | +169 |
| Opponent | Wood Elf Realms | 5 | 106 | 412 | 3.2 | 1.0 | 129 | 81 | +48 | 5 of 16 | 13 of 16 | - | +48 |
| **Opponent** | all armies | 36 | 53 | 385 | 2.8 | 1.2 | 140 | 53 | +87 | 44 of 99 | 77 of 99 | +52 | +91 |

### Effective charges: dep-mine-13df7bd-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 2 (net +40) | 0 | 3 (net +138) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 4 | 1 (net +326) | 0 | 0 | 1 (net +0) | 0 | 2 (net +88) | 0 | 0% (0 of 4) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 2 (net -115) | 0 | 1 (net +60) | 2 (net +42) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 9 | 1 (net -265) | 0 | 4 (net +75) | 2 (net +0) | 0 | 2 (net -22) | 0 | 44% (4 of 9) |
| Mine | Grand Cathay | 8 | 0 | 1 (net +0) | 2 (net +218) | 1 (net +165) | 1 (net +0) | 2 (net +214) | 1 | 29% (2 of 7) |
| Mine | High Elf Realms | 19 | 1 (net +268) | 1 (net +0) | 3 (net -101) | 5 (net +32) | 3 (net +17) | 4 (net +194) | 2 | 18% (3 of 17) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 3 (net +65) | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 5 | 0 | 1 (net +0) | 1 (net +145) | 1 (net +210) | 0 | 0 | 2 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 4 | 1 (net +145) | 0 | 0 | 0 | 0 | 1 (net +145) | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 1 (net +145) | 2 (net +72) | 2 | 0% (0 of 3) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 2 (net +118) | 0 | 2 (net +68) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 5 | 2 (net -26) | 0 | 0 | 0 | 0 | 3 (net -170) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 7 | 4 (net -290) | 0 | 0 | 2 (net -24) | 1 (net +111) | 0 | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 5 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +85) | 0 | 1 (net +135) | 0 | 20% (1 of 5) |
| Mine | Wood Elf Realms | 5 | 0 | 0 | 1 (net -104) | 1 (net +0) | 0 | 1 (net +91) | 2 | 33% (1 of 3) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 2 (net +69) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 9 | 2 (net +0) | 0 | 1 (net +95) | 1 (net +105) | 1 (net +0) | 2 (net +168) | 2 | 14% (1 of 7) |
| Opponent | High Elf Realms | 3 | 0 | 1 (net +526) | 0 | 2 (net +62) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 6 | 2 (net -193) | 0 | 0 | 0 | 2 (net -90) | 0 | 2 | 0% (0 of 4) |
| Opponent | Lizardmen | 8 | 1 (net +813) | 0 | 0 | 1 (net -405) | 0 | 1 (net +400) | 5 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 9 | 0 | 0 | 3 (net +132) | 0 | 0 | 1 (net -365) | 5 | 75% (3 of 4) |
| Opponent | Skaven | 7 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 5 (net -76) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net +611) | 0 | 4 (net -116) | 3 (net +71) | 0 | 3 (net +149) | 3 | 33% (4 of 12) |
| Opponent | Vampire Counts | 6 | 2 (net +386) | 0 | 1 (net +0) | 0 | 0 | 2 (net +270) | 1 | 20% (1 of 5) |
| Opponent | Warriors of Chaos | 18 | 4 (net -31) | 1 (net +666) | 2 (net +98) | 4 (net +310) | 2 (net +88) | 4 (net +194) | 1 | 12% (2 of 17) |
| Opponent | Wood Elf Realms | 16 | 1 (net -91) | 0 | 2 (net +76) | 5 (net +152) | 1 (net -91) | 0 | 7 | 22% (2 of 9) |

### Charged fights, damage counted: dep-mine-13df7bd-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 281 | 347 | -61 | 113 | 135 | -22 | -8.0 |
| Mine | 50-54% | 3 | 190 | 260 | +0 | 28 | 25 | +2 | +1.3 |
| Mine | Effective (55-75%) | 14 | 217 | 192 | +18 | 94 | 104 | -10 | -4.6 |
| Mine | 76-89% | 19 | 254 | 146 | +51 | 102 | 61 | +41 | +16.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 259 | 175 | +76 | 139 | 44 | +96 | +36.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 389 | 92 | +56 | 75 | 1 | +74 | +19.0 |
| Mine | No odds | 11 | 241 | 197 | +73 | 111 | 35 | +76 | +31.5 |
| Mine | All fights | 95 | 264 | 190 | +40 | 108 | 62 | +47 | +17.7 |
| Opponent | Long shot (under 50%) | 14 | 313 | 309 | +158 | 250 | 108 | +142 | +45.4 |
| Opponent | 50-54% | 2 | 496 | 293 | +596 | 596 | 0 | +596 | +120.3 |
| Opponent | Effective (55-75%) | 14 | 303 | 193 | +26 | 115 | 103 | +12 | +4.0 |
| Opponent | 76-89% | 19 | 381 | 189 | +114 | 146 | 46 | +100 | +26.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 321 | 245 | +97 | 185 | 98 | +86 | +27.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 392 | 101 | -16 | 51 | 72 | -22 | -5.5 |
| Opponent | No odds | 26 | 234 | 221 | +39 | 128 | 71 | +57 | +24.1 |
| Opponent | All fights | 99 | 314 | 222 | +87 | 162 | 80 | +82 | +26.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p8 | move | 423 | 86 (20%) | 54 (13%) | 51 (12%) | 286 (68%) |
| dep-mine-13df7bd-p8 | objective | 372 | 51 (14%) | 43 (12%) | 52 (14%) | 269 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0116, L0132, L2529, L2728 |
| Charmed Shield | Opponent | L0334, L0626, L1525, L2125, L3334 |
| Clockwork Compass | Mine | L1222 |
| Clockwork Compass | Opponent | L1112 |
| Elixir of Power | Mine | L1112, L1128, L1921 |
| Elixir of Power | Opponent | L0419, L0911, L1019 |
| Fistful of Laurels | Mine | L1821 |
| Horn of the Wild Hunt | Mine | L3334 |
| Horn of the Wild Hunt | Opponent | L0233, L1333, L2333 |
| Invocation of Nehek | Mine | L2529, L2728 |
| Invocation of Nehek | Opponent | L1525, L2125 |
| Opal Amulet | Mine | L1429 |
| Periapt of Soul Exchange | Mine | L2023, L2125 |
| Periapt of Soul Exchange | Opponent | L0821, L1721, L1821, L1921 |
| Ring of Doom | Mine | L0216, L0233, L1112, L1128, L1222, L1525, L3334 |
| Ring of Doom | Opponent | L0233, L0715, L0731, L0911, L1112, L1333, L2333 |
| Ring of Jet | Mine | L1019, L1112, L1128, L1222 |
| Ring of Jet | Opponent | L0610, L0911, L1112 |
| Standard of the Fell Warrior | Mine | L1317, L1333 |
| Storm Daemon (Renegade 2.0) | Mine | L2125 |
| Storm Daemon (Renegade 2.0) | Opponent | L0821, L1721, L1821, L1921 |
| Twice-Blessed Armour | Mine | L0715, L0731, L1019 |
| Twice-Blessed Armour | Opponent | L0610 |
| Witch Hunter's Ward | Mine | L0715, L0731, L0821 |

# Doctrine scorecard: dep-opp-13df7bd-p3

### Scorecard: dep-opp-13df7bd-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 55 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 132 |
| L0126 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 2 | 4 | 1 | 0 | 0 | 200 |
| L0210 | 6 | 1 | Opponent | no | 10 | 1 | 1 | 0 | 1 | 0 | 0 | 492 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Opponent | no | 4 | 3 | 1 | 2 | 0 | 0 | 0 | 60 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 0 | 1 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 7 | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | no | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 6 | 0 | 2 | 0 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 6 | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 7 | 6 | 2 | 2 | 0 | 0 | 0 | 477 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | 2 | 1 | 3 | 0 | 0 | 0 | 19 |
| L0620 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 685 |
| L0725 | 5 | 1 | Mine | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | 6 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 6 | 2 | 1 | 0 | 0 | 0 | 724 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | yes | 1 | - | 0 | 0 | 2 | 0 | 0 | 757 |
| L0922 | 4 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 641 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 456 |
| L1013 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 2 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 70 |
| L1122 | 6 | 1 | Mine | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 4 | 1 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 7 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 2 | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 4 | 1 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 1 | 0 | 0 | 274 |
| L1633 | 1 | 1 | Mine | yes | 2 | 3 | 1 | 0 | 1 | 0 | 0 | 475 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 1 | 0 | 0 | 405 |
| L1731 | 3 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 6 | 3 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 4 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 315 |
| L2223 | 3 | 1 | Opponent | no | 9 | 2 | 5 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 5 | - | 0 | 0 | 1 | 0 | 0 | 583 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 2 | 1 | 0 | 1 | 4 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 25% | 3.3 | 2.7 | 1.7 | 1.1 | 0.4 | 0.0 | 0.0 | 281.6 |
| **Average** | | | Opponent | 25% | 2.9 | 2.4 | 2.6 | 1.9 | 0.4 | 0.0 | 0.0 | 178.9 |

### KPIs: dep-opp-13df7bd-p3

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 170) | 9% (16 of 175) | 16% (54 of 345) |
| Winner chose to follow up after the loser gave ground |  | 100% (50 of 50); on the table 100% | 100% (53 of 53); on the table 100% | 100% (103 of 103); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 100% | 89% (8 of 9); on the table 89% | 87% (13 of 15); on the table 93% |
| Winner chose to pursue after the loser fled |  | 84% (16 of 19); on the table 84% | 72% (21 of 29); on the table 72% | 77% (37 of 48); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 95% (71 of 75); on the table 96% | 90% (82 of 91); on the table 90% | 92% (153 of 166); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% (112 of 342) | 36% (69 of 192) | 34% (181 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (112 of 251) | 47% (69 of 148) | 45% (181 of 399) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 72% (13 of 18) | 53% (35 of 66) | 57% (48 of 84) |
| Points that never fought | lower | 43% (29615 of 68801) | 41% (29566 of 71990) | 42% (59181 of 140791) |
|   infantry points that never fought | lower | 55% (7857 of 14174) | 57% (8170 of 14220) | 56% (16027 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (172 of 272) | 58% (166 of 285) | 61% (338 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 2.0 uses a game | 92% (22 of 24); 1.8 uses a game | 94% (46 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 0.1 uses a game | 17% (1 of 6); 0.0 uses a game | 25% (5 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 70% (14 of 20); 0.4 uses a game | 36% (5 of 14); 0.1 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (35162 of 59391) | 52% (33270 of 64043) | 55% (68432 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (27%) | 0.9 (26%) | 2.6 (27%) |
| MARCHED: its unit marched | 1.6 (25%) | 1.1 (33%) | 2.7 (28%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.9 (15%) | 0.6 (17%) | 1.5 (16%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| FLEEING: fleeing | 0.4 (6%) | 0.0 (1%) | 0.4 (4%) |
| GONE: slain | 1.1 (17%) | 0.5 (15%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.1 | 2.2 | 5.0 | 0.8 | 1.3 |
| not cast | 3.9 | 1.5 | 4.0 | 9.8 | 2.5 | 19.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (48%) | 0.2 (6%) | 2.6 (27%) | 0.4 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (28%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (6%) | 0.6 (14%) | 1.5 (16%) | 0.4 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (6%) | 0.1 (2%) | 0.4 (4%) | 0.1 (4%) | 0.8 (4%) |
| GONE: slain | 0.6 (15%) | 0.3 (20%) | 0.8 (20%) | 1.6 (16%) | 0.4 (18%) | 3.2 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (4%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (7%) | 0.0 (1%) | 0.1 (1%) | 0.7 (27%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (64%) | 0.1 (9%) | 1.9 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.9 a game | 1.1 a game |
| stood (cast and not dispelled) | 67% (26 of 39) | 58% (15 of 26) | 63% (41 of 65) |
| the unit moved after it | 77% (20 of 26) | 73% (11 of 15) | 76% (31 of 41) |
| it charged on its next turn | 0% (0 of 26) | 0% (0 of 15) | 0% (0 of 41) |
| the enemy charged it first | 15% (4 of 26) | 0% (0 of 15) | 10% (4 of 41) |
| it fought by the end of its next turn | 15% (4 of 26) | 0% (0 of 15) | 10% (4 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (5 of 26) | 0% (0 of 15) | 12% (5 of 41) |
| none of these (no charge, no fight, no charge escaped) | 65% (17 of 26) | 100% (15 of 15) | 78% (32 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (503 of 761) | 58% (377 of 648) | 62% (880 of 1409) |
|   cavalry | 72% (41 of 57) | 62% (74 of 119) | 65% (115 of 176) |
|   character | 56% (60 of 107) | 25% (34 of 135) | 39% (94 of 242) |
|   chariot | 49% (43 of 87) | 66% (19 of 29) | 53% (62 of 116) |
|   infantry | 58% (117 of 202) | 66% (179 of 273) | 62% (296 of 475) |
|   monster | 34% (11 of 32) | 33% (1 of 3) | 34% (12 of 35) |
|   war machine | 84% (231 of 276) | 79% (70 of 89) | 82% (301 of 365) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (30%) | 1.7 (23%) | 3.9 (26%) |
| CHARGED: it charged | 0.8 (11%) | 1.7 (23%) | 2.5 (17%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (12%) | 0.4 (6%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.2 (17%) | 0.9 (13%) | 2.2 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.7 (9%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (16%) | 1.6 (21%) | 2.7 (18%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (3%) | 0.4 (2%) |
| OTHER BAR | 0.5 (7%) | 0.1 (1%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 1.0 | 82% | 5.5 pts | 25 pts |
| character | 3.0 | 0.8 | 81% | 4.8 pts | 15 pts |
| chariot | 1.7 | 1.1 | 68% | 17.7 pts | 31 pts |
| infantry | 12.5 | 5.1 | 74% | 10.1 pts | 126 pts |
| monster | 0.4 | 0.0 | 93% | 2.8 pts | 1 pts |
| war machine | 8.8 | 7.4 | 62% | 25.1 pts | 221 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 5.3 | 4.2 |
| Charges that made contact a game | 2.1 | 3.7 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.46 declared, 0.35 contact (26 units) | 0.38 declared, 0.25 contact (16 units) | 0.43 declared, 0.31 contact (42 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 0.33 contact (3 units) | 0.80 declared, 0.50 contact (10 units) | 0.92 declared, 0.46 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.30 contact (223 units) | 0.65 declared, 0.46 contact (269 units) | 0.56 declared, 0.39 contact (492 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (47 of 77) | 60% (9 of 15) | 50% (5 of 10) | 60% (61 of 102) |
| Character in a unit | 85% (33 of 39) | 84% (16 of 19) | 50% (3 of 6) | 81% (52 of 64) |
| Character on its own | 84% (32 of 38) | 57% (21 of 37) | 32% (22 of 69) | 52% (75 of 144) |
| Chariot | 64% (7 of 11) | 67% (8 of 12) | - | 65% (15 of 23) |
| Infantry | 66% (46 of 70) | 45% (19 of 42) | 60% (3 of 5) | 58% (68 of 117) |
| Monster | 62% (21 of 34) | 43% (3 of 7) | - | 59% (24 of 41) |
| Monstrous | 70% (7 of 10) | 64% (7 of 11) | - | 67% (14 of 21) |
| War Machines | 63% (27 of 43) | 100% (2 of 2) | - | 64% (29 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 23% (22 of 96) | 48% | 73% (16 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 39% (14 of 36) | 49% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | - | - | 77% | 83% (20 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 92% | 57% (17 of 30) | 44% | 66% (39 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 100% (7 of 7); on the table 100% | 38% (73 of 192) | 61% | 51% (38 of 74) | 94% (17 of 18); 6.8 uses a game | 0% (0 of 4); 0.0 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 88% (21 of 24); on the table 88% | 33% (14 of 42) | 39% | 48% (26 of 54) | 100% (9 of 9); 4.0 uses a game | 25% (3 of 12); 0.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (13 of 13); on the table 100% | - | 41% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 83% (5 of 6) | 42% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 17% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 8% (1 of 12) | 1% | 94% (15 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 70% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 100% (13 of 13); on the table 100% | 17% (1 of 6) | 30% | 46% (12 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (28 of 29); on the table 97% | 35% (19 of 54) | 35% | 61% (28 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 84% (31 of 37); on the table 84% | 40% (12 of 30) | 27% | 57% (55 of 96) | 100% (4 of 4); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 75% (3 of 4); on the table 75% | 0% (0 of 12) | 47% | 63% (39 of 62) | 91% (10 of 11); 5.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (41) | 47% (25) | 49% (66) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.47 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.08 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.33 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.83 | 1.25 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.03 | 0.69 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.36 | 4.94 | 11.31 |

### Quality by phase: dep-opp-13df7bd-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 48% (44 of 91) | 44% (75 of 172) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (151 of 368) | 50% (121 of 240) |
| Strategy | Close-in objectives charged next turn | 14% (22 of 161) | 14% (27 of 199) |
| Strategy | Support requests answered (helper made contact too) | 62% (8 of 13) | 50% (16 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (2 of 10) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 46% (22 of 48) | 40% (19 of 47) |
| Strategy | Lone characters that fought | 66% (57 of 87) | 76% (66 of 87) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 281.6 | 178.9 |
| Movement | Fights charged into per game | 1.9 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 62, net +32 | 14 of 90, net +142 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 62, net -1 | 21 of 90, net +136 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 62, net +93 | 11 of 90, net +46 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 62, net +110 | 21 of 90, net +78 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.2 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (127 of 295) | 45% (159 of 352) |
| Shooting | Points destroyed by shooting units | 64.3 | 55.6 |
| Shooting | War machine shots | 6.4 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (116 of 231) | 41% (35 of 86) |
| Shooting | Points destroyed by war machines | 88.4 | 26.1 |
| Magic | Magic missiles cast | 1.9 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (28 of 70) | 33% (15 of 45) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.9 |
| Magic | Wounds caused by other spells | 1.6 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 68.6 | 37.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.3 / 0.8 / 0.1 | 2.0 / 0.2 / 0.1 / 0.4 |
| Combat | Points destroyed in combat | 275.6 | 416.8 |
| Combat | Points run down | 66.0 | 106.1 |
| Combat | Net points per charged fight, damage counted | +47 | +93 |
| Combat | Net per 100 charger points, damage counted | +16.0 | +30.9 |
| Combat | First round won (charged fights) | 70% | 75% |
| Combat | Net points per charged fight | +58 | +91 |
| Combat | Net points per supported fight / lone fight | +110 / +51 | +91 / +91 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 70 | 58 of 109 |
| Game | Points lost | 731.8 | 568.9 |
| Game | VP from objectives | 509.7 | 646.4 |
| Game | Lone holders (player turns) | 3.3 | 2.9 |

- Mine won / drew / lost: 8 / 8 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -319 VP
- The side that went first won 11 of 28 games with a winner
- Points traded per game (both sides' losses): 1301
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-opp-13df7bd-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 14.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +6.3 | 0.0 | 54.6 | 1.1 | +10.0 | 0.0 | 5.2 |
| BEST FACING | 0.8 | +35.8 | 0.0 | 35.9 | 0.4 | +12.8 | 0.0 | 28.2 |
| BEST FIRST | 4.5 | +177.4 | 154.7 | 110.0 | 3.8 | +160.8 | 128.4 | 98.9 |
| BEST OVERALL | 0.7 | +43.9 | 0.0 | 39.3 | 0.5 | +53.8 | 0.0 | 30.4 |
| BEST PREY | 0.7 | +39.0 | 32.9 | 3.8 | 0.6 | +17.9 | 23.1 | 10.9 |
| BEST PRIZE | 0.1 | -9.2 | 7.5 | 10.3 | 0.1 | -2.3 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 10.2 | 0.2 | -1.6 | 0.0 | 34.4 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 1.7 | 0.2 | +0.0 | 18.3 | 0.0 |
| BLOCKED WHEEL | 0.4 | +5.8 | 0.0 | 3.1 | 0.6 | +4.6 | 0.0 | 4.0 |
| BLOWS WHERE AIMED | 0.2 | -8.9 | 24.4 | 12.9 | 0.2 | -47.0 | 61.4 | 10.8 |
| BOMBING RUN | 0.0 | +0.8 | 5.4 | 4.2 | 0.0 | +1.6 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 130.2 | 7.4 | 0.3 | +0.0 | 51.8 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +183.2 | 299.8 | 56.4 | 1.6 | +87.4 | 72.4 | 10.4 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 9.6 | 0.0 | -2.0 | 1.7 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 10.9 | 3.2 | 0.0 | +0.0 | 10.3 | 0.0 |
| CAST JOB | 0.8 | +30.0 | 62.4 | 20.2 | 0.8 | +15.5 | 65.5 | 15.7 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +44.7 | 20.5 | 10.3 | 0.1 | +0.1 | 4.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 19.7 | 0.6 | +0.0 | 0.0 | 22.2 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.8 | 10.3 | 11.2 | 0.1 | -0.4 | 8.8 | 3.9 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 146.4 | 84.7 | 2.1 | +0.0 | 254.9 | 39.2 |
| CHARGE NOW WEIGHED | 0.6 | -54.8 | 19.1 | 23.9 | 0.5 | -61.4 | 7.5 | 27.9 |
| CHARGER SLAIN LOST | 0.3 | -6.8 | 39.0 | 19.6 | 1.0 | -29.4 | 121.9 | 13.5 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -0.6 | 0.0 | 22.2 |
| CHEAP HELPER | 0.1 | +0.0 | 1.2 | 0.0 | 0.1 | +0.0 | 19.3 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 37.8 | 29.7 | 0.3 | +0.0 | 16.7 | 16.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +72.7 | 0.0 | 0.0 | 0.4 | +39.8 | 26.6 | 29.8 |
| COUNTER-CHARGE COVER | 9.5 | +819.8 | 0.0 | 276.0 | 7.1 | +704.0 | 0.0 | 163.5 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | - | - | - | - | 7.5 | +60.5 | 0.0 | 10.2 |
| EDGE GIVE GROUND | 0.1 | +0.4 | 9.2 | 0.0 | 0.1 | +1.7 | 13.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +138.1 | 0.0 | 57.6 | 1.2 | +108.3 | 0.0 | 57.4 |
| FALLBACK BY WORTH | 5.0 | +70.7 | 0.0 | 82.4 | 5.9 | +79.5 | 0.0 | 77.0 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.6 | 2.9 | 3.9 | 0.0 | +0.4 | 3.2 | 3.9 |
| FLANK NOT WEIGHED | 6.8 | +0.0 | 0.0 | 190.6 | 4.8 | +0.0 | 0.0 | 163.6 |
| FOCUS FIRE | - | - | - | - | 0.1 | +2.2 | 6.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +154.4 | 0.0 | 69.1 | 1.2 | +170.2 | 0.0 | 33.3 |
| FRIENDS SHOTS CHECKED | 0.4 | +23.1 | 0.0 | 21.4 | 0.1 | +6.6 | 0.0 | 7.7 |
| GIVES UP | - | - | - | - | 0.1 | -1.2 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.3 | 15.1 | 1.2 |
| GROUND FLIERS | 0.1 | +1.8 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 10.9 | 0.0 | 0.0 | +0.0 | 6.3 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 12.3 | 1.7 | 0.2 | +0.0 | 39.0 | 4.0 |
| HILL BY ITS CHANCE | 0.3 | -47.1 | 0.0 | 1.8 | 0.3 | -19.2 | 0.0 | 1.0 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +149.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.7 | -114.4 | 289.5 | 185.9 | 7.9 | -174.4 | 482.7 | 120.4 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +3.7 | 9.2 | 1.4 | 0.2 | +4.7 | 10.4 | 4.7 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 24.3 | 0.0 |
| HUNT IN PAIRS | 0.4 | +12.1 | 0.0 | 10.2 | 0.6 | +42.3 | 0.0 | 17.6 |
| HUNT KEPT | 0.1 | +2.1 | 4.6 | 0.0 | 0.1 | +0.9 | 3.5 | 0.0 |
| HUNT RESULT | 0.1 | +21.8 | 0.0 | 1.4 | 0.3 | +24.4 | 24.3 | 4.7 |
| HUNT THE GUNS | 0.1 | +43.9 | 9.2 | 1.4 | 0.3 | +125.4 | 34.6 | 6.0 |
| INVITES THE FIGHT | 1.6 | +37.7 | 116.5 | 15.5 | 1.3 | +22.8 | 15.8 | 15.5 |
| JOINT CHARGE PLAN | 0.1 | +4.4 | 0.0 | 0.0 | 0.1 | +3.7 | 10.3 | 4.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -6.4 | 20.2 | 8.6 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +38.3 | 92.1 | 42.4 | 2.0 | +60.8 | 221.3 | 25.0 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +86.7 | 118.7 | 47.0 | 1.8 | +71.0 | 162.4 | 17.3 |
| KILLS COUNT NEXT TURN | 5.1 | +156.4 | 151.3 | 140.2 | 6.5 | +184.7 | 298.0 | 105.4 |
| LANE BY FIGURES | - | - | - | - | 1.1 | +45.8 | 0.0 | 7.7 |
| LONE CHARACTER SAFE SPOT | 0.3 | +1.8 | 2.9 | 3.9 | 0.2 | +5.8 | 4.6 | 12.3 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 13.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.1 | 19.1 | 9.6 | 0.3 | +0.6 | 36.4 | 1.2 |
| LOST CHARGE | 2.7 | -46.3 | 108.6 | 87.1 | 2.4 | -43.3 | 119.1 | 47.0 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -3.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +132.6 | 57.9 | 15.5 | 1.0 | +60.0 | 20.0 | 30.5 |
| MANOEUVRE | 0.1 | +7.2 | 0.0 | 2.2 | 0.2 | +7.6 | 0.0 | 11.5 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +11.7 | 0.0 | 0.0 | 0.9 | +53.0 | 0.0 | 11.1 |
| MARCH ODDS | 0.4 | +23.3 | 15.8 | 10.9 | 0.3 | +13.6 | 1.8 | 7.0 |
| MARCH OVER CASTS | 0.8 | +62.7 | 0.0 | 29.2 | 0.6 | +28.0 | 0.0 | 11.1 |
| MAX FOR POSITIONING | 4.8 | +166.6 | 0.0 | 217.8 | 4.6 | +202.9 | 0.0 | 98.4 |
| MISSILES IN THE MOVE | 4.4 | +173.4 | 0.0 | 119.2 | 4.2 | +69.8 | 0.0 | 111.3 |
| MISSILES NEXT TURN | 5.4 | +99.3 | 0.0 | 176.0 | 5.3 | +51.3 | 0.0 | 120.4 |
| MODEL FACING | 0.1 | +41.9 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 7.7 | 32.8 | 0.3 | +0.0 | 20.7 | 0.0 |
| MOVE AND CAST | 0.5 | +12.3 | 0.0 | 9.9 | 0.4 | +16.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +10.4 | 0.0 | 10.6 | 0.1 | +1.9 | 0.0 | 14.1 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 3.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.2 | -6.3 | 0.0 | 20.4 | 0.3 | -9.8 | 2.9 | 14.1 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 22.2 |
| MOVE TO CHARGE | 3.2 | +284.6 | 124.1 | 103.1 | 4.0 | +264.6 | 215.6 | 103.9 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +10.6 | 7.4 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.8 | 0.0 | 4.2 | - | - | - | - |
| NOT NEEDED | 0.1 | -6.9 | 25.8 | 0.0 | 0.3 | -12.3 | 30.9 | 8.1 |
| NOT TURNED | 6.4 | +89.4 | 0.0 | 150.2 | 4.9 | +41.7 | 0.0 | 103.1 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 31.0 | 0.9 | -1.2 | 0.0 | 0.0 |
| OFF BEST | 15.5 | -899.7 | 7.1 | 329.2 | 15.2 | -810.0 | 23.7 | 203.1 |
| OPENS A LANE | 0.1 | +0.5 | 13.4 | 0.0 | 0.2 | +0.8 | 10.3 | 0.0 |
| OPENS UP | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +8.6 | 1.5 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +7.6 | 19.4 | 8.8 | 0.3 | +9.9 | 42.1 | 0.5 |
| PATHS CROSS | 2.2 | +147.3 | 0.0 | 62.6 | 2.4 | +169.2 | 0.0 | 12.3 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.6 | 0.0 | 1.5 | 0.1 | -1.0 | 0.0 | 9.1 |
| PLAN RESULT | 35.6 | +1233.0 | 1192.1 | 970.9 | 39.2 | +1513.3 | 1591.9 | 783.9 |
| PURSUES BIG PREY | 0.1 | -3.7 | 0.0 | 0.0 | 0.1 | -4.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +14.7 | 0.0 | 26.9 | 1.8 | +21.6 | 0.0 | 43.6 |
| RANDOM MOVER NO PROMISE | 0.0 | -0.5 | 0.0 | 0.0 | 0.5 | -23.2 | 28.1 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.4 | 0.0 | 1.1 | 0.7 | -21.6 | 0.0 | 1.6 |
| REDIRECT COUNTER | 2.2 | +125.7 | 0.0 | 49.3 | 4.2 | +467.2 | 0.0 | 46.8 |
| REDIRECT WEIGHED | 0.2 | -0.3 | 6.9 | 3.2 | 0.3 | +1.4 | 5.9 | 5.8 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 27.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +14.7 | 0.0 | 14.4 | 0.9 | +31.5 | 0.0 | 13.4 |
| RESTRAINS TO SHOOT | 0.1 | +1.1 | 0.0 | 10.3 | - | - | - | - |
| RISK BY ARC | 1.6 | +65.3 | 141.0 | 52.9 | 2.6 | +56.2 | 303.5 | 35.0 |
| SAFE SURE CHARGE | 0.0 | -0.3 | 5.2 | 0.0 | 0.0 | -1.1 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.0 | +68.3 | 0.0 | 41.7 | 0.7 | +72.6 | 0.0 | 54.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.1 | 0.0 | 0.0 | 0.4 | -24.6 | 0.0 | 0.5 |
| SEARCH SPOT | 2.3 | +91.0 | 0.0 | 35.2 | 2.9 | +154.7 | 0.0 | 46.1 |
| SECOND HUNTER | 0.0 | -0.2 | 4.6 | 0.0 | 0.1 | -0.8 | 17.4 | 0.0 |
| SELF MOVE SPELL | 0.4 | +57.6 | 0.0 | 18.1 | 0.2 | +48.1 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.8 | +191.7 | 57.9 | 78.5 | 1.7 | +120.9 | 51.0 | 31.6 |
| SET-UP ANY TARGET | 0.4 | +47.7 | 0.0 | 0.0 | 0.2 | +41.1 | 22.2 | 29.8 |
| SET-UP MISSED | 0.1 | +9.0 | 0.0 | 0.0 | 0.1 | +2.0 | 3.9 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +48.9 | 62.1 | 11.9 | 1.0 | +10.0 | 27.5 | 18.5 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.7 | +0.0 | 102.2 | 0.0 | 0.4 | +0.0 | 66.1 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +493.4 | 0.0 | 173.8 | 10.1 | +329.1 | 0.0 | 124.0 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 10.3 | 9.9 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +100.1 | 0.0 | 0.0 | 0.2 | +41.1 | 22.2 | 29.8 |
| SPELL WORTH | 1.4 | +20.5 | 61.5 | 61.5 | 2.6 | +35.0 | 65.1 | 52.1 |
| SPELLS IN THE FIGHT | 0.4 | +1.1 | 78.7 | 18.2 | 0.7 | -19.6 | 146.5 | 23.9 |
| STABLE ROLE | 11.3 | +0.0 | 375.0 | 135.1 | 8.2 | +0.0 | 310.8 | 185.3 |
| STANDS TO CAST | 0.1 | +5.6 | 4.7 | 10.2 | - | - | - | - |
| STAY WEIGHED | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +2.1 | 4.6 | 0.0 | 0.2 | +5.0 | 27.6 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.7 | +41.1 | 0.0 | 38.8 | 0.6 | +30.6 | 0.0 | 39.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.0 | -37.7 | 217.8 | 92.8 | 6.4 | -48.2 | 325.7 | 85.2 |
| SUPPORTS | 3.5 | +40.1 | 115.4 | 50.4 | 4.4 | +48.8 | 92.6 | 49.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.1 | 2.9 | 0.0 | 0.1 | -4.5 | 5.8 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +5.3 | 6.5 | 17.4 | 0.7 | -1.5 | 20.6 | 0.0 |
| THROUGH LINE OF FIRE | 0.4 | +27.4 | 0.0 | 6.6 | 0.2 | +8.6 | 0.0 | 4.9 |
| TURN WORTH | 0.2 | -14.0 | 21.7 | 12.2 | 0.3 | -21.4 | 33.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.6 | +6.8 | 17.4 | 27.3 | 0.5 | +4.3 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.7 | -370.1 | 299.3 | 151.8 | 7.1 | -345.3 | 300.1 | 136.2 |
| WALKS TO THE FIGHT | 1.4 | +38.4 | 34.0 | 21.2 | 1.1 | +21.4 | 24.2 | 12.8 |
| WAR ENGINE CHARGES | 0.1 | +7.2 | 0.0 | 8.6 | 0.1 | +1.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 63.5 | 9.3 | 0.3 | +0.0 | 7.1 | 0.0 |
| WEARS DOWN | 0.8 | +49.6 | 73.3 | 43.2 | 1.3 | +55.6 | 168.5 | 31.3 |
| WHO HITS BACK | 0.1 | +18.1 | 0.0 | 3.2 | 0.2 | +13.2 | 0.0 | 6.5 |
| WHOLE FIGHT | 0.2 | -12.3 | 16.8 | 21.7 | 0.5 | +30.2 | 81.4 | 1.9 |
| WHOLE FIGHT GAIN | 0.2 | +27.1 | 29.6 | 0.0 | 0.6 | +38.6 | 50.2 | 16.3 |
| WIDER SPREAD | 1.6 | -9.5 | 176.1 | 64.6 | 3.1 | -5.0 | 322.3 | 49.2 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 10.9 | 0.0 | - | - | - | - |

### Rule changes: dep-opp-13df7bd-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1106 | 1106 | 1106 | 30.72 | -61547 | -55.6 |
| BEST FIRST | 299 | 299 | 299 | 8.31 | +12174 | +40.7 |
| SEARCH SPOT | 185 | 185 | 185 | 5.14 | +8847 | +47.8 |
| DEPLOY BY FIGURES | 270 | 270 | 167 | 4.64 | +2095 | +12.5 |
| PATHS CROSS | 165 | 165 | 165 | 4.58 | +11394 | +69.1 |
| MOVE TO CHARGE | 259 | 259 | 155 | 4.31 | +8147 | +52.6 |
| COUNTER-CHARGE COVER | 600 | 331 | 152 | 4.22 | +9939 | +65.4 |
| KILLS COUNT NEXT TURN | 418 | 418 | 123 | 3.42 | +2822 | +22.9 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +8870 | +79.9 |
| SUPPORTS | 284 | 284 | 102 | 2.83 | +837 | +8.2 |
| FALLBACK BY WORTH | 393 | 393 | 87 | 2.42 | +5407 | +62.1 |
| FOLLOW UP WEIGHED | 79 | 79 | 79 | 2.19 | +11685 | +147.9 |
| ADVANCE LANE KEPT | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +5072 | +81.8 |
| CANNON SIGHT KEPT | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| SET UP TOGETHER | 125 | 105 | 59 | 1.64 | +3608 | +61.1 |
| WAIT AFTER COSTS | 496 | 496 | 57 | 1.58 | +904 | +15.9 |
| WALKS TO THE FIGHT | 90 | 90 | 56 | 1.56 | +835 | +14.9 |
| SHOTS IN THE MOVE | 819 | 557 | 54 | 1.50 | +938 | +17.4 |
| MAX FOR POSITIONING | 341 | 195 | 53 | 1.47 | +626 | +11.8 |
| CANNON PLANNED TARGET | 251 | 251 | 52 | 1.44 | +352 | +6.8 |
| REDIRECT COUNTER | 229 | 127 | 50 | 1.39 | +3871 | +77.4 |
| MARCH CHECK | 53 | 51 | 48 | 1.33 | +2958 | +61.6 |
| RANDOM MOVE BY FIGURES | 84 | 84 | 48 | 1.33 | +1308 | +27.3 |
| BEST OVERALL | 44 | 44 | 44 | 1.22 | +3517 | +79.9 |
| MISSILES IN THE MOVE | 312 | 176 | 44 | 1.22 | +1432 | +32.5 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1663 | +37.8 |
| STOPS SHORT OF THE FLANK | 44 | 44 | 44 | 1.22 | +2582 | +58.7 |
| BEST FACING | 43 | 43 | 43 | 1.19 | +1748 | +40.6 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +3553 | +86.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| LANE BY FIGURES | 39 | 39 | 39 | 1.08 | +1648 | +42.3 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +375 | +11.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MOVE AND CAST | 33 | 33 | 33 | 0.92 | +1039 | +31.5 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| HONEST WORTH | 525 | 522 | 32 | 0.89 | +278 | +8.7 |
| KILLS COUNT | 107 | 105 | 32 | 0.89 | +1374 | +42.9 |
| SHOOTS FROM THE BEST SPOT | 71 | 71 | 32 | 0.89 | +932 | +29.1 |
| CAST JOB | 56 | 56 | 31 | 0.86 | +673 | +21.7 |
| MAKE SURE TOGETHER | 70 | 45 | 29 | 0.81 | +1958 | +67.5 |
| CHARGE NOW FIRST | 137 | 137 | 28 | 0.78 | -1182 | -42.2 |
| RISK BY ARC | 154 | 152 | 27 | 0.75 | +852 | +31.5 |
| INVITES THE FIGHT | 104 | 104 | 26 | 0.72 | +360 | +13.8 |
| MARCH ODDS | 25 | 25 | 25 | 0.69 | +453 | +18.1 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.61 | +53 | +2.4 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +1295 | +58.9 |
| BEST PREY | 47 | 47 | 19 | 0.53 | +636 | +33.5 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +1324 | +69.7 |
| HOLDER AT DEPLOYMENT | 32 | 32 | 18 | 0.50 | +872 | +48.5 |
| KEEPS ITS TARGET | 119 | 119 | 18 | 0.50 | +344 | +19.1 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -74 | -4.4 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +1069 | +71.3 |
| CASTING BLOCK | 15 | 15 | 14 | 0.39 | +1177 | +84.1 |
| WHOLE FIGHT GAIN | 27 | 24 | 14 | 0.39 | +564 | +40.3 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -41 | -3.2 |
| WEARS DOWN | 76 | 75 | 13 | 0.36 | +565 | +43.5 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +570 | +51.8 |
| HUNT IN PAIRS | 38 | 22 | 10 | 0.28 | +328 | +32.8 |
| MANOEUVRE | 12 | 12 | 10 | 0.28 | +532 | +53.2 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 384 | 200 | 9 | 0.25 | +12 | +1.4 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 410 | 410 | 8 | 0.22 | -98 | -12.2 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -236 | -29.5 |
| SURE REACH TOGETHER | 48 | 37 | 8 | 0.22 | +119 | +14.9 |
| WAR ENGINE JOBS | 32 | 32 | 8 | 0.22 | -198 | -24.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -58 | -8.3 |
| LOST CHARGE | 183 | 182 | 6 | 0.17 | +82 | +13.7 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -300 | -50.0 |
| WHOLE FIGHT | 24 | 23 | 6 | 0.17 | +252 | +41.9 |
| WIDER SPREAD | 168 | 165 | 6 | 0.17 | +11 | +1.9 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -414 | -82.7 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 5 | 0.14 | -62 | -12.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BACKUP TARGETS | 81 | 37 | 4 | 0.11 | +6 | +1.6 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +195 | +48.7 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1510 | +377.5 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -3 | -0.8 |
| STOPS | 8 | 8 | 4 | 0.11 | +41 | +10.2 |
| TWO OR MORE ARRIVE | 39 | 30 | 4 | 0.11 | +22 | +5.4 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +36 | +12.1 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +81 | +27.0 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +71 | +23.6 |
| LONG SHOT | 20 | 19 | 3 | 0.08 | +50 | +16.7 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| OPENS UP | 5 | 5 | 3 | 0.08 | +82 | +27.5 |
| OVERRUNS AWAY | 23 | 22 | 3 | 0.08 | +47 | +15.6 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +115 | +38.3 |
| REDIRECT BY WHAT IT STOPS | 32 | 32 | 3 | 0.08 | +207 | +69.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +84 | +42.0 |
| CHARGER SLAIN LOST | 46 | 44 | 2 | 0.06 | +99 | +49.7 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +3 | +1.5 |
| HUNT ADVANCE | 10 | 10 | 2 | 0.06 | +46 | +22.9 |
| JOINT CHARGE PLAN | 9 | 9 | 2 | 0.06 | +83 | +41.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +21 | +10.6 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +41 | +20.6 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -127 | -63.6 |
| SPELLS IN THE FIGHT | 39 | 36 | 2 | 0.06 | +17 | +8.6 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +60 | +29.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -74 | -73.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +20 | +19.8 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +122 | +121.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +176 | +176.4 |
| REFUSING RETIRES | 17 | 17 | 1 | 0.03 | -0 | -0.5 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 46 | 46 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 49 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 44 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 415 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 5 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 12 | 11 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 21 | 21 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 15 | trace | - | - | - | - |
| HUNT THE GUNS | 16 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 50 | 50 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 27 | 27 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 407 | 407 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 3 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2694 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 32 | not checked | - | - | - | - |
| SPELL WORTH | 143 | not checked | - | - | - | - |
| STABLE ROLE | 701 | 700 | 0 | 0.00 | - | - |
| TURN WORTH | 21 | 21 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.61 | 13.28 | 56.9 |
| FALLBACK | gate | 0.81 | 1.03 | 55.3 |
| TURN GATE | gate | 0.69 | 0.69 | 34.9 |
| CHARGE NOW FIRST | rule | 0.31 | 0.47 | 42.2 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.17 | 10.3 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 31.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.06 | 97.2 |
| PATHS CROSS | rule | 0.14 | 0.08 | 22.8 |
| SUPPORT NARROWED | rule | 0.11 | 0.11 | 12.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.14 | 29.5 |
| WAR ENGINE JOBS | rule | 0.11 | 0.11 | 24.8 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.11 | 8.3 |
| SUPPORT REQUEST | gate | 0.06 | 0.14 | 41.8 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 6.8 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 50.0 |
| BEST PRIZE | rule | 0.08 | 0.06 | 82.7 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 40.1 |
| MARCH ODDS | rule | 0.06 | 0.06 | 8.3 |
| STOPS SHORT OF THE FLANK | rule | - | 0.11 | 4.5 |
| AFTERMATH BAND | gate | 0.06 | 0.03 | 2.6 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 72.7 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.3 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 20.7 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 9.0 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 9.6 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 23.9 |
| FOLLOW UP WEIGHED | rule | 0.06 | - | 4.0 |
| SAFE SURE CHARGE | rule | 0.03 | 0.03 | 63.6 |
| STANDS TO CAST | rule | 0.06 | - | 30.1 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 73.6 |
| DEPLOY BY FIGURES | rule | - | 0.03 | 7.7 |
| REDIRECT WEIGHED | rule | - | 0.03 | 56.1 |
| RULE SWITCHED OFF | gate | 0.03 | - | 2.5 |

### Plans: dep-opp-13df7bd-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.4 | 13% | 425 | 315 | 74% |
| Mine | charge | 2.2 | 64% | 211 | 235 | 111% |
| Mine | close in | 4.5 | 22% | 324 | 130 | 40% |
| Mine | hold | 4.7 | 30% | 311 | 0 | 0% |
| Mine | join | 0.4 | 87% | 17 | 0 | 0% |
| Mine | shoot | 8.6 | 58% | 241 | 554 | 230% |
| Mine | support | 3.8 | 93% | 34 | 0 | 0% |
| Opponent | advance | 13.2 | 17% | 366 | 395 | 108% |
| Opponent | charge | 4.2 | 64% | 342 | 536 | 156% |
| Opponent | close in | 5.5 | 23% | 276 | 141 | 51% |
| Opponent | hold | 4.8 | 38% | 288 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 24 | 0 | 0% |
| Opponent | shoot | 5.5 | 65% | 134 | 445 | 333% |
| Opponent | support | 5.2 | 93% | 35 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.5 | 395 | 196 | 50% | 39 |
| Opponent | 0.3 | 12 | 1 | 18% | 27% | 0% | 2.3 | 391 | 80 | 27% | 99 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 25% | 50% | 0% | 2.5 | 395 | 196 | 50% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 142 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 27 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 276 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| Tomb Kings of Khemri | 1.7 | 10 | 1 | 22% | 33% | 0% | 2.3 | 352 | 98 | 33% | 12 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 478 | 0 | 0% | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 659 | 0 | 0% | 109 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |

### Battle groups: dep-opp-13df7bd-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.5 | 20% | 46% | 7% | 20% | 20% | 25% | 8% | 48% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 25% | 80% | 10% | 50% | 22% | 0% | 6% | 67% | 6% |
| Opponent | COUNTER-CHARGE COVER | 7.1 | 16% | 60% | 17% | 57% | 29% | 6% | 31% | 34% | 0% |
| Opponent | REDIRECT COUNTER | 4.2 | 13% | 68% | 11% | 0% | 12% | 0% | 24% | 65% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 31 | 51 (31) | 14 | 37 | 57 | 23% | 2.8 | 63 (20) | 0 (3) | 50 (8) | 70 (23) | 0 (8) |
| Mine | Character | 118 | 40 (118) | 40 | 0 | 37 | 22% | 2.5 | 63 (33) | 32 (63) | 44 (10) | 41 (58) | 47 (48) |
| Mine | Clean-up | 22 | 83 (22) | 40 | 43 | 17 | 41% | 3.0 | 111 (4) | 81 (16) | 0 (2) | 135 (11) | 46 (11) |
| Mine | Fast Hammer | 43 | 21 (43) | 8 | 13 | 62 | 33% | 2.9 | 14 (17) | 30 (18) | 14 (8) | 26 (29) | 13 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 53 | 38 (53) | 27 | 11 | 38 | 15% | 2.8 | 38 (13) | 42 (36) | 3 (4) | 36 (40) | 45 (13) |
| Mine | Holder | 25 | 32 (25) | 0 | 32 | 14 | 56% | 2.7 | 35 (7) | 41 (11) | 6 (6) | 69 (11) | 0 (13) |
| Mine | Shooter | 37 | 47 (37) | 14 | 33 | 46 | 3% | 1.8 | 29 (9) | 56 (26) | 0 (2) | 45 (23) | 48 (14) |
| Mine | Support | 4 | 23 (4) | 23 | 0 | 19 | 0% | 2.8 | - | 23 (4) | - | 28 (3) | 0 (1) |
| Mine | War machine | 52 | 55 (52) | 55 | 0 | 28 | 2% | 1.2 | 19 (15) | 77 (34) | 0 (3) | 53 (15) | 56 (37) |
| Mine | Wizard | 17 | 7 (17) | 7 | 0 | 36 | 6% | 2.2 | 7 (8) | 11 (6) | 0 (1) | 14 (6) | 5 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 80 (66) | 16 | 64 | 42 | 53% | 2.5 | 19 (20) | 128 (29) | 69 (17) | 96 (52) | 16 (14) |
| Opponent | Character | 102 | 55 (102) | 55 | 0 | 24 | 18% | 2.3 | 69 (35) | 37 (44) | 71 (19) | 60 (65) | 51 (33) |
| Opponent | Clean-up | 12 | 40 (12) | 6 | 34 | 38 | 42% | 3.6 | 29 (6) | 50 (4) | 44 (2) | 55 (7) | 21 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 62 | 51 (62) | 26 | 25 | 43 | 24% | 3.1 | 49 (26) | 51 (24) | 54 (12) | 56 (35) | 45 (27) |
| Opponent | Fragile | 3 | 31 (3) | 31 | 0 | 0 | 0% | 3.7 | - | 92 (1) | 0 (2) | 46 (2) | 0 (1) |
| Opponent | Hammer | 50 | 45 (50) | 24 | 21 | 39 | 30% | 2.6 | 7 (15) | 59 (28) | 55 (7) | 57 (33) | 21 (17) |
| Opponent | Holder | 42 | 66 (42) | 18 | 48 | 14 | 40% | 2.4 | 37 (10) | 94 (16) | 63 (16) | 98 (29) | 9 (13) |
| Opponent | Shooter | 24 | 56 (24) | 28 | 28 | 32 | 0% | 1.2 | 70 (11) | 45 (13) | - | 68 (16) | 35 (8) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 4.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 69 (17) | 69 | 0 | 23 | 6% | 1.4 | 31 (5) | 32 (7) | 164 (5) | 23 (4) | 82 (13) |
| Opponent | Wizard | 32 | 7 (32) | 7 | 0 | 30 | 12% | 2.2 | 14 (9) | 5 (13) | 0 (2) | 6 (11) | 12 (13) |

### Charged fights: dep-opp-13df7bd-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 78 | 103 | 1.5 | 1.2 | 69 | 0 | +69 | 0 of 6 | 5 of 6 | +40 | +74 |
| Mine | Chaos Dwarfs | 4 | 250 | 339 | 2.2 | 1.0 | 151 | 94 | +56 | 5 of 9 | 7 of 9 | - | +56 |
| Mine | Dwarfen Mountain Holds | 3 | 357 | 12 | 0.7 | 1.0 | 18 | 30 | -12 | 1 of 2 | 1 of 2 | - | -12 |
| Mine | Empire of Man | 5 | 221 | 71 | 1.6 | 1.0 | 44 | 0 | +44 | 5 of 8 | 5 of 8 | - | +44 |
| Mine | Grand Cathay | 5 | 739 | 158 | 1.8 | 1.0 | 88 | 0 | +88 | 1 of 9 | 6 of 9 | - | +88 |
| Mine | High Elf Realms | 4 | 173 | 740 | 3.2 | 1.4 | 228 | 45 | +182 | 6 of 13 | 11 of 13 | +450 | +102 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 614 | 2.0 | 1.0 | 307 | 236 | +72 | 1 of 2 | 2 of 2 | - | +72 |
| Mine | Lizardmen | 1 | 0 | 456 | 3.0 | 1.0 | 152 | 0 | +152 | 0 of 3 | 3 of 3 | - | +152 |
| Mine | Ogre Kingdoms | 1 | 0 | 682 | 5.0 | 1.0 | 136 | 157 | -21 | 4 of 5 | 2 of 5 | - | -21 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 460 | -460 | 1 of 1 | 0 of 1 | - | -460 |
| Mine | Skaven | 1 | 0 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| Mine | Tomb Kings of Khemri | 2 | 35 | 243 | 3.0 | 1.5 | 81 | 100 | -19 | 2 of 6 | 5 of 6 | -180 | +142 |
| Mine | Vampire Counts | 2 | 0 | 182 | 2.0 | 1.0 | 91 | 190 | -99 | 1 of 4 | 1 of 4 | - | -99 |
| Mine | Warriors of Chaos | 2 | 0 | 72 | 0.5 | 2.0 | 144 | 116 | +28 | 0 of 1 | 0 of 1 | +28 | - |
| **Mine** | all armies | 36 | 221 | 243 | 1.9 | 1.1 | 125 | 67 | +58 | 27 of 70 | 49 of 70 | +110 | +51 |
| Opponent | Empire of Man | 1 | 807 | 0 | 1.0 | 1.0 | 0 | 265 | -265 | 1 of 1 | 0 of 1 | - | -265 |
| Opponent | Grand Cathay | 3 | 187 | 107 | 1.7 | 1.2 | 64 | 87 | -23 | 0 of 5 | 5 of 5 | +0 | -28 |
| Opponent | High Elf Realms | 3 | 199 | 239 | 1.3 | 1.0 | 179 | 0 | +179 | 1 of 4 | 3 of 4 | - | +179 |
| Opponent | Kingdom of Bretonnia | 2 | 156 | 217 | 2.0 | 1.5 | 108 | 0 | +108 | 3 of 4 | 4 of 4 | +217 | +0 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 115 | 4.0 | 1.0 | 29 | 80 | -52 | 2 of 4 | 2 of 4 | - | -52 |
| Opponent | Skaven | 1 | 165 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 212 | 828 | 5.8 | 1.2 | 144 | 51 | +93 | 14 of 23 | 17 of 23 | -77 | +129 |
| Opponent | Vampire Counts | 6 | 0 | 316 | 3.5 | 1.1 | 90 | 30 | +60 | 13 of 21 | 16 of 21 | +0 | +66 |
| Opponent | Warriors of Chaos | 9 | 5 | 595 | 3.4 | 1.3 | 173 | 12 | +161 | 18 of 31 | 26 of 31 | +163 | +161 |
| Opponent | Wood Elf Realms | 6 | 157 | 263 | 2.7 | 1.2 | 98 | 37 | +61 | 6 of 16 | 9 of 16 | +130 | +46 |
| **Opponent** | all armies | 36 | 119 | 381 | 3.0 | 1.2 | 126 | 35 | +91 | 58 of 109 | 82 of 109 | +91 | +91 |

### Effective charges: dep-opp-13df7bd-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +0) | 0 | 1 (net +165) | 3 (net +69) | 1 (net +40) | 0 | 0 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 4 (net -102) | 1 (net +0) | 1 (net +50) | 2 (net +356) | 1 | 50% (4 of 8) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net -25) | 1 | 0% (0 of 1) |
| Mine | Empire of Man | 8 | 3 (net +84) | 0 | 1 (net +0) | 2 (net +0) | 0 | 2 (net +52) | 0 | 12% (1 of 8) |
| Mine | Grand Cathay | 9 | 1 (net +0) | 1 (net +315) | 0 | 2 (net +0) | 0 | 4 (net +119) | 1 | 0% (0 of 8) |
| Mine | High Elf Realms | 13 | 0 | 2 (net +128) | 2 (net +104) | 4 (net +285) | 3 (net +136) | 1 (net +235) | 1 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 2 (net +72) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +116) | 0 | 1 (net +170) | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 2 (net +244) | 0 | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +104) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +0) | 3 (net -73) | 1 (net +60) | 1 (net +45) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 4 | 1 (net -60) | 0 | 0 | 1 (net -280) | 0 | 2 (net -28) | 0 | 0% (0 of 4) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1 (net +28) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Empire of Man | 1 | 1 (net -265) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +0) | 1 (net -264) | 2 (net +32) | 1 (net +85) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 4 | 0 | 1 (net +270) | 0 | 0 | 1 (net +65) | 1 (net +167) | 1 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 1 (net +434) | 0 | 0 | 2 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 23 | 2 (net +108) | 0 | 7 (net +67) | 7 (net +126) | 3 (net +35) | 3 (net +123) | 1 | 32% (7 of 22) |
| Opponent | Vampire Counts | 21 | 4 (net +104) | 0 | 2 (net +46) | 4 (net +42) | 3 (net +69) | 6 (net +41) | 2 | 11% (2 of 19) |
| Opponent | Warriors of Chaos | 31 | 5 (net +288) | 2 (net +0) | 8 (net +188) | 5 (net +274) | 1 (net +0) | 7 (net +92) | 3 | 29% (8 of 28) |
| Opponent | Wood Elf Realms | 16 | 1 (net +170) | 1 (net +116) | 2 (net +177) | 1 (net +210) | 1 (net +60) | 1 (net +120) | 9 | 29% (2 of 7) |

### Charged fights, damage counted: dep-opp-13df7bd-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 156 | 228 | +32 | 81 | 53 | +29 | +18.3 |
| Mine | 50-54% | 3 | 292 | 268 | +190 | 190 | 26 | +164 | +56.3 |
| Mine | Effective (55-75%) | 10 | 347 | 286 | -1 | 185 | 166 | +19 | +5.6 |
| Mine | 76-89% | 21 | 338 | 194 | +76 | 166 | 121 | +45 | +13.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 217 | 169 | +110 | 133 | 34 | +99 | +45.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 421 | 93 | +93 | 93 | 4 | +89 | +21.1 |
| Mine | No odds | 8 | 280 | 270 | -76 | 104 | 182 | -78 | -27.8 |
| Mine | All fights | 70 | 295 | 207 | +58 | 142 | 95 | +47 | +16.0 |
| Opponent | Long shot (under 50%) | 14 | 238 | 343 | +142 | 234 | 80 | +154 | +65.0 |
| Opponent | 50-54% | 4 | 368 | 288 | +96 | 96 | 92 | +4 | +1.2 |
| Opponent | Effective (55-75%) | 21 | 356 | 318 | +136 | 218 | 89 | +129 | +36.3 |
| Opponent | 76-89% | 19 | 286 | 230 | +125 | 164 | 31 | +133 | +46.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 350 | 223 | +78 | 130 | 29 | +101 | +28.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 387 | 66 | +46 | 48 | 11 | +37 | +9.5 |
| Opponent | No odds | 19 | 189 | 224 | +12 | 79 | 67 | +12 | +6.1 |
| Opponent | All fights | 109 | 302 | 245 | +91 | 148 | 55 | +93 | +30.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p3 | move | 455 | 93 (20%) | 62 (14%) | 42 (9%) | 320 (70%) |
| dep-opp-13df7bd-p3 | objective | 360 | 49 (14%) | 36 (10%) | 38 (11%) | 273 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

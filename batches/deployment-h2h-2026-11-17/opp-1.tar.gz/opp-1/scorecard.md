# Doctrine scorecard: dep-opp-13df7bd-p1

### Scorecard: dep-opp-13df7bd-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 0 | 4 | 0 | 1 | 1 | 0 | 0 | 142 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 117 |
| L0135 | 3 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 5 | 3 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 6 | 0 | 1 | 2 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 7 | 1 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 5 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 0 | 3 | 6 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 2 | 0 | 0 | 330 |
| L0405 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 124 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1177 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 633 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 560 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 1258 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 111 |
| L0717 | 3 | 1 | Mine | yes | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 558 |
| L0733 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 8 | 4 | 1 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 668 |
| L0930 | 6 | 1 | Opponent | no | 13 | 2 | 4 | 2 | 0 | 0 | 0 | 98 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 8 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 541 |
| L1114 | 4 | 1 | Mine | no | 4 | 2 | 2 | 0 | 2 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 151 |
| L1131 | 3 | 1 | Mine | no | 4 | - | 3 | 0 | 2 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 12 | 1 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 60 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 3 | 5 | 1 | 3 | 0 | 0 | 0 | 863 |
| L1431 | 3 | 1 | Mine | no | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 535 |
| L1527 | 3 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 250 |
| L1625 | 5 | 1 | Mine | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 2 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 5 | 0 | 1 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 66 |
| L2025 | 3 | 1 | Mine | yes | 0 | - | 1 | 2 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 3 | 4 | 1 | 1 | 0 | 0 | 340 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 317 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 0 | 0 | 0 | 480 |
| L2531 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 2 | 2 | 6 | 5 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 1 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 7 | 6 | 2 | 1 | 0 | 0 | 0 | 251 |
| **Average** | | | Mine | 26% | 2.7 | 2.3 | 2.7 | 1.1 | 0.3 | 0.0 | 0.0 | 325.1 |
| **Average** | | | Opponent | 15% | 2.3 | 2.6 | 2.1 | 1.4 | 0.5 | 0.0 | 0.0 | 193.3 |

### KPIs: dep-opp-13df7bd-p1

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 180) | 3% (6 of 183) | 15% (54 of 363) |
| Winner chose to follow up after the loser gave ground |  | 98% (61 of 62); on the table 98% | 97% (33 of 34); on the table 97% | 98% (94 of 96); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (14 of 14); on the table 100% | 91% (20 of 22); on the table 95% | 94% (34 of 36); on the table 97% |
| Winner chose to pursue after the loser fled |  | 79% (22 of 28); on the table 86% | 76% (19 of 25); on the table 80% | 77% (41 of 53); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 93% (97 of 104); on the table 95% | 89% (72 of 81); on the table 91% | 91% (169 of 185); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 28% (92 of 330) | 33% (69 of 210) | 30% (161 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (92 of 216) | 45% (69 of 154) | 44% (161 of 370) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (24 of 41) | 51% (26 of 51) | 54% (50 of 92) |
| Points that never fought | lower | 37% (26621 of 71484) | 37% (26709 of 71889) | 37% (53330 of 143373) |
|   infantry points that never fought | lower | 50% (8490 of 16863) | 46% (6091 of 13348) | 48% (14581 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (135 of 279) | 64% (188 of 295) | 56% (323 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.4 uses a game | 80% (16 of 20); 1.5 uses a game | 83% (35 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 75% (9 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (25535 of 59666) | 62% (38617 of 62699) | 52% (64152 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (28%) | 1.2 (32%) | 3.1 (30%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.5 (13%) | 1.4 (13%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.2 (18%) | 0.6 (16%) | 1.8 (17%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.4 (10%) | 0.6 (5%) |
| FLEEING: fleeing | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| GONE: slain | 1.3 (20%) | 0.7 (17%) | 2.0 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.2 (4%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.3 | 1.2 | 4.5 | 0.5 | 1.8 |
| not cast | 3.9 | 2.9 | 3.4 | 10.5 | 1.8 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (34%) | 0.3 (8%) | 3.1 (30%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (13%) | 0.2 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (10%) | 0.6 (16%) | 1.8 (17%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.3 (12%) | 0.6 (18%) | 0.6 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (1%) | 0.0 (1%) | 0.3 (3%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 0.9 (23%) | 0.7 (25%) | 0.8 (23%) | 2.0 (19%) | 0.2 (9%) | 3.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.3 (10%) | 0.1 (4%) | 0.6 (6%) | 0.1 (8%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (7%) | 0.0 (1%) | 0.1 (1%) | 0.6 (34%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (52%) | 0.1 (2%) | 1.0 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.4 a game | 0.7 a game |
| stood (cast and not dispelled) | 79% (23 of 29) | 71% (10 of 14) | 77% (33 of 43) |
| the unit moved after it | 87% (20 of 23) | 80% (8 of 10) | 85% (28 of 33) |
| it charged on its next turn | 4% (1 of 23) | 0% (0 of 10) | 3% (1 of 33) |
| the enemy charged it first | 13% (3 of 23) | 20% (2 of 10) | 15% (5 of 33) |
| it fought by the end of its next turn | 13% (3 of 23) | 10% (1 of 10) | 12% (4 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (3 of 23) | 0% (0 of 10) | 9% (3 of 33) |
| none of these (no charge, no fight, no charge escaped) | 70% (16 of 23) | 80% (8 of 10) | 73% (24 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (581 of 934) | 59% (358 of 608) | 61% (939 of 1542) |
|   cavalry | 49% (40 of 82) | 70% (94 of 134) | 62% (134 of 216) |
|   character | 50% (69 of 137) | 33% (37 of 112) | 43% (106 of 249) |
|   chariot | 51% (48 of 94) | 58% (21 of 36) | 53% (69 of 130) |
|   infantry | 58% (177 of 305) | 61% (150 of 244) | 60% (327 of 549) |
|   monster | 51% (22 of 43) | 52% (17 of 33) | 51% (39 of 76) |
|   war machine | 82% (225 of 273) | 80% (39 of 49) | 82% (264 of 322) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.9 (29%) | 1.5 (21%) | 4.4 (26%) |
| CHARGED: it charged | 1.0 (10%) | 1.1 (16%) | 2.1 (12%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.1 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.6 (8%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (19%) | 1.5 (22%) | 3.4 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.2 (4%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (19%) | 1.3 (19%) | 3.1 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.3 (4%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.6 | 77% | 5.8 pts | 30 pts |
| character | 3.3 | 1.0 | 80% | 6.0 pts | 20 pts |
| chariot | 1.9 | 1.1 | 74% | 10.2 pts | 19 pts |
| infantry | 13.2 | 4.4 | 75% | 8.9 pts | 117 pts |
| monster | 1.2 | 0.2 | 83% | 3.6 pts | 4 pts |
| war machine | 7.3 | 4.9 | 66% | 20.6 pts | 151 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.9 | 5.3 |
| Charges that made contact a game | 3.3 | 3.7 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.52 contact (21 units) | 0.50 declared, 0.36 contact (14 units) | 0.60 declared, 0.46 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.38 contact (8 units) | 1.50 declared, 1.00 contact (8 units) | 1.12 declared, 0.69 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.42 contact (251 units) | 0.68 declared, 0.43 contact (283 units) | 0.64 declared, 0.43 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (36 of 70) | 62% (13 of 21) | 50% (4 of 8) | 54% (53 of 99) |
| Character in a unit | 81% (26 of 32) | 67% (16 of 24) | 100% (3 of 3) | 76% (45 of 59) |
| Character on its own | 89% (49 of 55) | 44% (16 of 36) | 37% (23 of 63) | 57% (88 of 154) |
| Chariot | 44% (7 of 16) | 50% (5 of 10) | - | 46% (12 of 26) |
| Infantry | 49% (44 of 89) | 42% (15 of 36) | 50% (1 of 2) | 47% (60 of 127) |
| Monster | 50% (16 of 32) | 70% (7 of 10) | - | 55% (23 of 42) |
| Monstrous | 73% (8 of 11) | 50% (7 of 14) | - | 60% (15 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 100% (13 of 13); on the table 100% | 19% (26 of 138) | 21% | 39% (13 of 33) | 89% (8 of 9); 4.0 uses a game | 67% (2 of 3); 0.7 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (14 of 14); on the table 100% | 17% (4 of 24) | 36% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | - | - | 68% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 90% (9 of 10); on the table 90% | 56% (20 of 36) | 59% | 56% (36 of 64) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 94% (15 of 16); on the table 100% | 33% (36 of 108) | 32% | 45% (20 of 44) | 92% (11 of 12); 5.8 uses a game | 100% (1 of 1); 0.4 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 90% (26 of 29); on the table 93% | 13% (4 of 30) | 25% | 41% (20 of 49) | 100% (5 of 5); 2.5 uses a game | 50% (9 of 18); 3.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 83% (5 of 6); on the table 100% | - | 42% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 89% (8 of 9); on the table 89% | 0% (0 of 12) | 45% | 48% (10 of 21) | 100% (3 of 3); 2.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 19% (7 of 36) | 5% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (8 of 8); on the table 100% | 43% (13 of 30) | 31% | 56% (19 of 34) | 67% (2 of 3); 2.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 82% (14 of 17); on the table 82% | 0% (0 of 12) | 35% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (17 of 19); on the table 95% | 44% (24 of 54) | 31% | 58% (29 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 86% (19 of 22); on the table 86% | 37% (11 of 30) | 40% | 76% (56 of 74) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 92% (11 of 12); on the table 92% | 53% (16 of 30) | 42% | 64% (42 of 66) | 33% (2 of 6); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (34) | 38% (28) | 43% (62) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.39 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.08 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.28 | 0.25 | 0.53 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.25 | 1.75 | 4.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.06 | 0.86 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.61 | 5.72 | 11.33 |

### Quality by phase: dep-opp-13df7bd-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 54% (76 of 141) | 40% (76 of 192) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (186 of 387) | 54% (95 of 176) |
| Strategy | Close-in objectives charged next turn | 15% (19 of 125) | 17% (38 of 228) |
| Strategy | Support requests answered (helper made contact too) | 45% (10 of 22) | 43% (18 of 42) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 75% (3 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 59% (10 of 17) |
| Strategy | Joined characters whose unit fought | 45% (25 of 55) | 44% (15 of 34) |
| Strategy | Lone characters that fought | 77% (70 of 91) | 72% (73 of 102) |
| Movement | Charges halted short of contact | 0.3 | 0.2 |
| Movement | Idle units | 1.1 | 1.4 |
| Movement | Points that never moved of their own | 325.1 | 193.3 |
| Movement | Fights charged into per game | 3.0 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 18 of 97, net +104 | 12 of 82, net -34 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 97, net +123 | 20 of 82, net +106 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 97, net +84 | 5 of 82, net +82 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 97, net +132 | 25 of 82, net +188 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (179 of 376) | 45% (161 of 359) |
| Shooting | Points destroyed by shooting units | 75.8 | 43.6 |
| Shooting | War machine shots | 6.2 | 1.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (93 of 225) | 44% (17 of 39) |
| Shooting | Points destroyed by war machines | 89.8 | 8.2 |
| Magic | Magic missiles cast | 1.8 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (25 of 65) | 42% (18 of 43) |
| Magic | Wounds caused by magic missiles | 3.4 | 1.6 |
| Magic | Wounds caused by other spells | 1.2 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 64.6 | 21.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.4 / 0.5 / 0.2 | 1.6 / 0.5 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 434.7 | 275.2 |
| Combat | Points run down | 38.2 | 197.5 |
| Combat | Net points per charged fight, damage counted | +127 | +86 |
| Combat | Net per 100 charger points, damage counted | +47.7 | +31.8 |
| Combat | First round won (charged fights) | 75% | 71% |
| Combat | Net points per charged fight | +116 | +77 |
| Combat | Net points per supported fight / lone fight | +248 / +100 | +176 / +48 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 108 | 45 of 105 |
| Game | Points lost | 633.2 | 840.8 |
| Game | VP from objectives | 655.3 | 581.4 |
| Game | Lone holders (player turns) | 2.7 | 2.3 |

- Mine won / drew / lost: 18 / 3 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +285 VP
- The side that went first won 15 of 33 games with a winner
- Points traded per game (both sides' losses): 1474
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-opp-13df7bd-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 3.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 10.3 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 8.8 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.1 | +8.4 | 0.0 | 19.4 | 0.9 | +7.4 | 0.0 | 24.5 |
| BEST FACING | 0.9 | +34.6 | 0.0 | 18.6 | 0.9 | +54.8 | 0.0 | 32.2 |
| BEST FIRST | 5.1 | +240.3 | 225.9 | 82.4 | 4.3 | +173.5 | 98.9 | 85.9 |
| BEST OVERALL | 0.8 | +42.2 | 0.0 | 23.4 | 0.6 | +32.8 | 0.0 | 13.6 |
| BEST PREY | 1.1 | +52.9 | 31.2 | 11.1 | 0.8 | +57.0 | 31.3 | 8.4 |
| BEST PRIZE | 0.0 | +0.8 | 2.6 | 0.0 | 0.1 | +1.4 | 5.5 | 6.0 |
| BIG CHARACTER SAFETY | 0.4 | -3.5 | 0.0 | 15.0 | 0.2 | -0.9 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 20.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +5.5 | 0.0 | 3.8 | 0.5 | +10.0 | 0.0 | 3.9 |
| BLOWS WHERE AIMED | 0.2 | -18.3 | 37.5 | 8.6 | 0.5 | -36.1 | 123.4 | 20.0 |
| BOMBING RUN | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 109.3 | 10.7 | 0.1 | +0.0 | 14.8 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +181.5 | 322.6 | 59.6 | 0.9 | +14.3 | 52.3 | 15.8 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 6.4 | 0.3 | +0.0 | 0.0 | 2.6 |
| CARRIES OUT COUNTER | 0.1 | -0.7 | 6.9 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -6.9 | 18.9 | 0.0 | 0.2 | -2.3 | 39.8 | 4.5 |
| CAST JOB | 0.8 | +29.8 | 71.1 | 19.6 | 0.4 | +7.0 | 14.2 | 1.7 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +78.6 | 40.5 | 10.3 | 0.1 | +4.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 44.8 | 0.3 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.2 | -0.5 | 9.4 | 7.6 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 193.8 | 10.9 | 2.3 | +0.0 | 281.9 | 56.2 |
| CHARGE NOW WEIGHED | 0.6 | -52.7 | 35.1 | 11.1 | 0.6 | -89.2 | 21.2 | 15.8 |
| CHARGER SLAIN LOST | 0.5 | -14.3 | 65.0 | 16.8 | 0.8 | -26.6 | 97.4 | 35.0 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.2 | 0.0 | 11.1 | 0.1 | -0.8 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.7 | 3.1 | 0.2 | +0.0 | 11.9 | 3.4 |
| COMBAT PIVOT | 0.5 | +0.0 | 30.5 | 9.3 | 0.3 | +0.0 | 32.6 | 35.2 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +67.9 | 42.1 | 34.4 | 0.3 | +98.0 | 7.1 | 22.8 |
| COUNTER-CHARGE COVER | 10.3 | +1009.7 | 0.0 | 200.8 | 7.6 | +659.3 | 0.0 | 224.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 13.7 | 5.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | - | - | - | - | 7.6 | +80.8 | 0.0 | 29.4 |
| EDGE GIVE GROUND | 0.2 | +1.6 | 3.9 | 0.0 | 0.2 | +6.0 | 41.6 | 5.4 |
| ELIXIR WORTH | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +152.8 | 0.0 | 71.5 | 1.8 | +158.4 | 0.0 | 71.3 |
| FALLBACK BY WORTH | 5.4 | +82.9 | 0.0 | 31.1 | 6.2 | +84.7 | 0.0 | 63.5 |
| FIGHT LIFT | 0.1 | +2.6 | 0.0 | 9.9 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.4 | 6.7 | 5.1 | 0.1 | +0.4 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 6.4 | +0.0 | 0.0 | 121.4 | 5.8 | +0.0 | 0.0 | 149.9 |
| FOLLOW UP WEIGHED | 1.1 | +134.1 | 0.0 | 22.9 | 0.6 | +85.2 | 0.0 | 21.2 |
| FRIENDS SHOTS CHECKED | 0.4 | +43.1 | 0.0 | 4.2 | 0.2 | +11.1 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -1.5 | 32.8 | 9.6 | 0.1 | -1.7 | 10.5 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 6.4 | 0.9 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 31.1 | 9.2 |
| HELPER UNSEEN | 0.5 | +0.0 | 27.9 | 7.1 | 0.6 | +0.0 | 73.6 | 15.2 |
| HILL BY ITS CHANCE | - | - | - | - | 0.3 | -27.0 | 0.0 | 0.0 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.2 | +190.1 | 0.0 | 6.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.8 | -136.5 | 338.3 | 43.8 | 9.5 | -168.0 | 523.5 | 242.8 |
| HUNT ADVANCE | 0.1 | +0.3 | 10.6 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +12.0 | 0.0 | 22.6 | 0.6 | +32.8 | 0.0 | 17.4 |
| HUNT KEPT | 0.0 | +0.1 | 5.3 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +5.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +5.8 | 5.3 | 0.0 | 0.1 | +53.7 | 15.1 | 3.4 |
| INVITES THE FIGHT | 1.7 | +35.4 | 83.3 | 42.1 | 1.3 | +16.0 | 36.2 | 21.1 |
| JOINT CHARGE PLAN | 0.1 | +2.0 | 0.0 | 0.0 | 0.4 | +27.1 | 4.9 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.2 | 9.5 | 3.1 | 0.1 | -6.2 | 26.3 | 0.0 |
| KEEP FALLS | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 3.2 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.3 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 108.6 | 13.5 | 2.3 | +69.2 | 199.2 | 61.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +55.7 | 139.8 | 16.7 | 2.0 | +87.7 | 137.9 | 56.3 |
| KILLS COUNT NEXT TURN | 4.8 | +139.1 | 175.5 | 62.1 | 6.2 | +262.0 | 287.3 | 108.2 |
| LANE BY FIGURES | - | - | - | - | 0.8 | +47.1 | 0.0 | 32.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +7.8 | 5.6 | 2.0 | 0.6 | +6.7 | 11.3 | 12.3 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.7 | +0.0 | 17.9 | 16.0 |
| LONE WIZARD KEPT IN | 0.7 | +50.4 | 0.0 | 3.6 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.7 | 16.6 | 0.0 | 0.8 | +3.7 | 50.5 | 16.1 |
| LOST CHARGE | 3.2 | -52.3 | 77.4 | 66.4 | 2.9 | -48.7 | 132.8 | 75.8 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.5 | 0.0 | 0.0 | 0.1 | -5.8 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.6 | +46.4 | 30.0 | 0.0 | 0.9 | +80.7 | 32.4 | 12.2 |
| MANOEUVRE | 0.2 | +3.6 | 0.0 | 5.1 | 0.1 | +1.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 15.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +24.9 | 0.0 | 53.0 | 0.4 | +14.5 | 0.0 | 16.5 |
| MARCH ODDS | 0.5 | +24.6 | 13.8 | 0.0 | 0.4 | +23.9 | 10.4 | 0.0 |
| MARCH OVER CASTS | 0.6 | +15.8 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 5.3 |
| MAX FOR POSITIONING | 4.6 | +199.8 | 0.0 | 92.6 | 5.4 | +220.7 | 0.0 | 156.1 |
| MISSILES IN THE MOVE | 3.8 | +181.0 | 0.0 | 165.9 | 3.8 | +67.7 | 0.0 | 124.0 |
| MISSILES NEXT TURN | 4.4 | +115.1 | 0.0 | 154.8 | 4.2 | +42.3 | 0.0 | 127.9 |
| MODEL FACING | 0.2 | +82.0 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 7.0 | 0.0 | 0.2 | +0.0 | 8.3 | 13.9 |
| MOVE AND CAST | 0.2 | +7.9 | 0.0 | 4.5 | 0.4 | +9.4 | 0.0 | 12.8 |
| MOVE SPELL IN RANGE | 0.1 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -23.9 | 0.0 | 23.3 | 0.1 | -1.9 | 0.0 | 22.8 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 32.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.1 | +221.6 | 79.1 | 3.9 | 4.6 | +433.5 | 225.1 | 123.9 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +2.2 | 0.0 | 0.0 | 0.1 | +14.0 | 11.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +5.5 | 0.0 | 11.1 | 0.1 | +5.6 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -12.3 | 23.8 | 3.1 | 0.7 | -51.9 | 96.8 | 21.3 |
| NOT TURNED | 5.6 | +125.4 | 0.0 | 70.9 | 5.7 | +61.6 | 0.0 | 117.7 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 49.4 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.4 | -860.7 | 0.5 | 222.6 | 17.3 | -887.9 | 41.9 | 309.8 |
| OPENS A LANE | 0.2 | +1.6 | 18.5 | 6.5 | 0.1 | +0.1 | 1.2 | 0.0 |
| OPENS UP | 0.4 | +26.5 | 17.3 | 0.0 | 0.2 | +9.5 | 9.7 | 0.0 |
| OVERRUNS AWAY | 0.2 | +1.9 | 18.4 | 0.0 | 0.4 | +3.7 | 37.6 | 30.9 |
| PATHS CROSS | 2.3 | +107.3 | 0.0 | 14.5 | 3.0 | +199.8 | 0.0 | 55.7 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 10.5 | 0.1 | -7.7 | 0.0 | 1.4 |
| PLAN RESULT | 37.7 | +1523.7 | 1623.4 | 771.8 | 40.2 | +1114.8 | 1525.7 | 1062.3 |
| PURSUES BIG PREY | 0.1 | -7.6 | 0.0 | 0.0 | 0.2 | -30.7 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +15.1 | 0.0 | 24.4 | 1.4 | +17.6 | 0.0 | 77.6 |
| RANDOM MOVER NO PROMISE | 0.4 | -22.9 | 7.6 | 4.7 | 0.3 | -7.3 | 12.3 | 14.2 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -4.0 | 0.0 | 0.0 | 0.4 | +28.9 | 0.0 | 5.1 |
| REDIRECT COUNTER | 2.1 | +172.9 | 0.0 | 24.3 | 4.2 | +246.3 | 0.0 | 68.6 |
| REDIRECT WEIGHED | 0.2 | +0.8 | 2.6 | 0.0 | 0.7 | +11.5 | 22.4 | 31.6 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 28.5 |
| RESERVE FALL BACK | 0.4 | +12.8 | 0.0 | 3.8 | 0.8 | +36.4 | 0.0 | 18.0 |
| RESTRAINS TO SHOOT | 0.1 | +0.7 | 0.0 | 3.1 | 0.0 | +0.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +70.8 | 239.5 | 28.5 | 3.4 | +68.8 | 333.3 | 129.7 |
| SAFER THAN THE JOB | 1.1 | +46.6 | 0.0 | 34.1 | 0.9 | +47.5 | 0.0 | 36.4 |
| SCOUT SPOT | 0.4 | +0.8 | 0.0 | 3.4 | 0.3 | +0.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 3.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.5 | 0.0 | 2.2 | 0.4 | -8.2 | 0.0 | 1.2 |
| SEARCH SPOT | 2.7 | +123.9 | 0.0 | 36.4 | 3.1 | +168.3 | 0.0 | 64.7 |
| SELF MOVE SPELL | 0.2 | +21.8 | 0.0 | 18.1 | 0.1 | -0.1 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.9 | +100.8 | 37.0 | 0.0 | 2.2 | +229.3 | 54.7 | 13.1 |
| SET-UP ANY TARGET | 0.3 | +36.2 | 31.8 | 14.7 | 0.2 | +28.0 | 3.2 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +0.7 | 4.4 | 7.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +1.0 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +61.1 | 150.2 | 16.0 | 0.8 | +19.4 | 28.7 | 36.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 199.2 | 2.9 | 0.2 | +0.0 | 16.7 | 6.5 |
| SHOTS IN THE MOVE | 14.4 | +601.5 | 0.0 | 248.9 | 9.1 | +204.9 | 0.0 | 160.8 |
| SPELL SETS UP CHARGE | 0.4 | +58.9 | 31.8 | 14.7 | 0.2 | +72.4 | 3.2 | 7.6 |
| SPELL WORTH | 0.9 | +15.2 | 39.9 | 47.1 | 1.9 | +35.2 | 85.9 | 85.9 |
| SPELLS IN THE FIGHT | 0.5 | -4.8 | 57.1 | 21.0 | 0.9 | -8.3 | 134.1 | 34.1 |
| STABLE ROLE | 11.6 | +0.0 | 494.4 | 110.2 | 11.2 | +0.0 | 424.7 | 147.0 |
| STANDS TO CAST | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +1.9 | 15.1 | 3.4 |
| STOPS SHORT OF THE FLANK | 0.7 | +25.3 | 0.0 | 22.0 | 0.5 | +41.3 | 0.0 | 17.9 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.7 | -48.7 | 337.0 | 72.3 | 8.0 | -55.1 | 529.8 | 129.3 |
| SUPPORTS | 3.6 | +48.7 | 163.5 | 57.4 | 5.3 | +55.1 | 268.1 | 68.9 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -10.2 | 4.1 | 0.0 | 0.2 | -9.0 | 32.9 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +1.1 | 0.0 | 0.0 | 1.0 | +14.8 | 1.8 | 7.5 |
| THROUGH LINE OF FIRE | 0.4 | +11.4 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -27.3 | 27.7 | 3.1 | 0.1 | -4.0 | 3.8 | 1.9 |
| TWO OR MORE ARRIVE | 0.2 | +1.3 | 37.0 | 0.0 | 0.4 | +3.6 | 22.7 | 4.0 |
| WAIT AFTER COSTS | 5.8 | -288.6 | 243.1 | 78.3 | 7.7 | -417.9 | 304.9 | 172.4 |
| WALKS TO THE FIGHT | 1.6 | +40.0 | 46.7 | 4.2 | 1.0 | +21.0 | 14.7 | 23.2 |
| WAR ENGINE CHARGES | 0.1 | +16.6 | 16.2 | 0.0 | 0.1 | +8.9 | 10.3 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 37.3 | 6.9 | 0.4 | +0.0 | 27.4 | 17.4 |
| WEARS DOWN | 1.1 | +62.9 | 98.2 | 11.8 | 1.9 | +71.2 | 258.9 | 76.9 |
| WHO HITS BACK | 0.2 | +22.2 | 0.0 | 0.0 | 0.2 | +14.7 | 0.0 | 13.7 |
| WHOLE FIGHT | 0.3 | -4.1 | 46.7 | 0.0 | 0.3 | +5.8 | 44.9 | 2.9 |
| WHOLE FIGHT GAIN | 0.5 | +35.2 | 41.4 | 13.6 | 0.9 | +107.2 | 93.7 | 19.5 |
| WIDER SPREAD | 2.5 | -7.0 | 228.8 | 41.3 | 3.9 | -4.1 | 417.9 | 100.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: dep-opp-13df7bd-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1142 | 1142 | 1142 | 31.72 | -62952 | -55.1 |
| BEST FIRST | 340 | 340 | 340 | 9.44 | +14897 | +43.8 |
| SEARCH SPOT | 209 | 209 | 209 | 5.81 | +10521 | +50.3 |
| PATHS CROSS | 192 | 192 | 192 | 5.33 | +11055 | +57.6 |
| COUNTER-CHARGE COVER | 645 | 357 | 179 | 4.97 | +11193 | +62.5 |
| DEPLOY BY FIGURES | 273 | 273 | 162 | 4.50 | +2225 | +13.7 |
| FACES THE THREAT | 144 | 144 | 144 | 4.00 | +11202 | +77.8 |
| MOVE TO CHARGE | 242 | 242 | 144 | 4.00 | +11240 | +78.1 |
| SUPPORTS | 319 | 319 | 125 | 3.47 | +1403 | +11.2 |
| KILLS COUNT NEXT TURN | 397 | 397 | 115 | 3.19 | +3011 | +26.2 |
| FALLBACK BY WORTH | 417 | 417 | 114 | 3.17 | +6034 | +52.9 |
| ADVANCE LANE KEPT | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| WAIT AFTER COSTS | 485 | 485 | 74 | 2.06 | +1241 | +16.8 |
| SAFER THAN THE JOB | 69 | 69 | 69 | 1.92 | +3387 | +49.1 |
| SHOTS IN THE MOVE | 849 | 544 | 66 | 1.83 | +1865 | +28.3 |
| WALKS TO THE FIGHT | 91 | 91 | 65 | 1.81 | +1159 | +17.8 |
| BEST FACING | 63 | 63 | 63 | 1.75 | +3217 | +51.1 |
| FOLLOW UP WEIGHED | 62 | 62 | 62 | 1.72 | +7895 | +127.3 |
| REDIRECT COUNTER | 228 | 128 | 57 | 1.58 | +4108 | +72.1 |
| CANNON SIGHT KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 92 | 92 | 50 | 1.39 | +1178 | +23.6 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +2697 | +55.0 |
| MAX FOR POSITIONING | 363 | 200 | 49 | 1.36 | +465 | +9.5 |
| SET UP TOGETHER | 111 | 97 | 49 | 1.36 | +3661 | +74.7 |
| CANNON PLANNED TARGET | 203 | 203 | 48 | 1.33 | -273 | -5.7 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 45 | 1.25 | +1534 | +34.1 |
| CHARGE NOW WEIGHED | 44 | 44 | 44 | 1.22 | +4697 | +106.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1773 | +41.2 |
| STOPS SHORT OF THE FLANK | 43 | 43 | 43 | 1.19 | +2397 | +55.7 |
| ARTILLERY RE-ROLL WEIGHED | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| MARCH CHECK | 42 | 41 | 41 | 1.14 | +2207 | +53.8 |
| MISSILES IN THE MOVE | 273 | 161 | 40 | 1.11 | +1124 | +28.1 |
| CHARGE NOW FIRST | 173 | 173 | 39 | 1.08 | -2411 | -61.8 |
| KILLS COUNT | 138 | 136 | 35 | 0.97 | +1378 | +39.4 |
| LONE WIZARD KEPT IN | 35 | 35 | 35 | 0.97 | +2696 | +77.0 |
| REDIRECT WEIGHED | 34 | 34 | 34 | 0.94 | +1187 | +34.9 |
| RISK BY ARC | 214 | 205 | 34 | 0.94 | +961 | +28.3 |
| HONEST WORTH | 585 | 582 | 33 | 0.92 | +231 | +7.0 |
| BEST PREY | 67 | 67 | 31 | 0.86 | +1374 | +44.3 |
| SHOT REPLANNED | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| INVITES THE FIGHT | 108 | 108 | 30 | 0.83 | +387 | +12.9 |
| MARCH ODDS | 31 | 31 | 30 | 0.83 | +435 | +14.5 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LANE BY FIGURES | 29 | 29 | 29 | 0.81 | +1695 | +58.5 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +556 | +19.8 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 52 | 46 | 26 | 0.72 | +1333 | +51.3 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +624 | +26.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +57 | +2.4 |
| BIG CHARACTER SAFETY | 23 | 23 | 23 | 0.64 | -160 | -6.9 |
| CAST JOB | 40 | 40 | 23 | 0.64 | +343 | +14.9 |
| FRIENDS SHOTS CHECKED | 22 | 22 | 22 | 0.61 | +1952 | +88.7 |
| CASTER AWAY FROM SCREEN | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 44 | 44 | 21 | 0.58 | +800 | +38.1 |
| KEEPS ITS TARGET | 134 | 131 | 20 | 0.56 | +336 | +16.8 |
| MAKE SURE TOGETHER | 53 | 39 | 19 | 0.53 | +1131 | +59.5 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -25 | -1.5 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +492 | +30.7 |
| WEARS DOWN | 108 | 103 | 16 | 0.44 | +882 | +55.1 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +961 | +64.1 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| LOST CHARGE | 221 | 219 | 14 | 0.39 | +195 | +13.9 |
| OPENS UP | 20 | 20 | 14 | 0.39 | +448 | +32.0 |
| SUPPORT NARROWED | 491 | 491 | 14 | 0.39 | -352 | -25.1 |
| SURE CHARGE BEATS ADVANCE | 14 | 14 | 14 | 0.39 | -691 | -49.4 |
| CASTING BLOCK | 19 | 19 | 13 | 0.36 | +933 | +71.8 |
| MANOEUVRE | 12 | 12 | 11 | 0.31 | +190 | +17.3 |
| PURSUES BIG PREY | 11 | 11 | 11 | 0.31 | -1380 | -125.5 |
| WAR ENGINE JOBS | 40 | 40 | 10 | 0.28 | -727 | -72.7 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 26 | 26 | 7 | 0.19 | -350 | -50.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -307 | -43.9 |
| SURE REACH TOGETHER | 49 | 31 | 7 | 0.19 | +133 | +19.0 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +2952 | +492.0 |
| REFUSING RETIRES | 23 | 23 | 6 | 0.17 | -3 | -0.4 |
| BACKUP TARGETS | 73 | 40 | 5 | 0.14 | +38 | +7.5 |
| DEFENSIVE ARMY | 14 | 14 | 5 | 0.14 | -82 | -16.3 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +66 | +13.1 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +149 | +29.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -121 | -30.2 |
| CARRIES OUT SET-UP | 13 | 13 | 4 | 0.11 | -329 | -82.3 |
| HUNT IN PAIRS | 26 | 10 | 4 | 0.11 | +73 | +18.3 |
| JOINT CHARGE PLAN | 17 | 17 | 4 | 0.11 | +220 | +55.0 |
| REDIRECT BY WHAT IT STOPS | 26 | 26 | 4 | 0.11 | +535 | +133.8 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +67 | +22.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +197 | +65.8 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +34 | +11.2 |
| SPELLS IN THE FIGHT | 51 | 48 | 3 | 0.08 | +73 | +24.4 |
| STUCK PIVOT | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| WAR ENGINE CHARGES | 6 | 6 | 3 | 0.08 | +272 | +90.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +98 | +48.8 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -23 | -11.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MISSILES NEXT TURN | 309 | 170 | 2 | 0.06 | +42 | +21.2 |
| OVERRUNS AWAY | 24 | 24 | 2 | 0.06 | +1 | +0.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +153 | +76.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -20 | -10.2 |
| STOPS | 3 | 3 | 2 | 0.06 | +55 | +27.4 |
| TWO OR MORE ARRIVE | 24 | 23 | 2 | 0.06 | +7 | +3.7 |
| WHOLE FIGHT | 23 | 22 | 2 | 0.06 | +56 | +28.0 |
| WIDER SPREAD | 232 | 220 | 2 | 0.06 | +9 | +4.6 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -25 | -25.1 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -30 | -29.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 15 | 15 | 1 | 0.03 | +2 | +1.9 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +3 | +2.8 |
| LONG SHOT | 36 | 36 | 1 | 0.03 | +9 | +9.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +131 | +130.7 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +80 | +80.4 |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 1 | 0.03 | +4 | +3.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +95 | +95.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -362 | -362.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 26 | 23 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 47 | 41 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 439 | not checked | - | - | - | - |
| GIVES UP | 13 | 10 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 9 | not checked | - | - | - | - |
| HELPER UNSEEN | 38 | 35 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 11 | 11 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 20 | not checked | - | - | - | - |
| NOT NEEDED | 31 | 31 | 0 | 0.00 | - | - |
| NOT TURNED | 408 | 408 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2802 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 26 | 26 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 11 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 101 | not checked | - | - | - | - |
| STABLE ROLE | 822 | 821 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.83 | 14.86 | 56.7 |
| FALLBACK | gate | 0.64 | 0.78 | 49.4 |
| TURN GATE | gate | 0.53 | 0.83 | 33.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.39 | 63.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.33 | 79.5 |
| BIG CHARACTER SAFETY | rule | 0.31 | 0.11 | 11.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.19 | 49.4 |
| SUPPORT NARROWED | rule | 0.31 | 0.06 | 27.1 |
| PATHS CROSS | rule | 0.17 | 0.14 | 53.1 |
| PURSUES BIG PREY | rule | 0.08 | 0.22 | 125.5 |
| WAR ENGINE JOBS | rule | 0.22 | 0.06 | 72.7 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 44.1 |
| STOPS SHORT OF THE FLANK | rule | 0.17 | 0.08 | 10.5 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 98.6 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.7 |
| CHAFF PASSED | rule | 0.08 | 0.14 | 3.1 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.11 | 43.9 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.11 | 17.1 |
| DEFENSIVE ARMY | rule | - | 0.14 | 16.3 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 1.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.14 | 70.1 |
| MARCH ODDS | rule | 0.06 | 0.08 | 8.4 |
| NO REASON | gate | - | 0.14 | 6.9 |
| SAFER THAN THE JOB | rule | 0.11 | 0.03 | 12.3 |
| BEST PRIZE | rule | 0.03 | 0.08 | 30.2 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.06 | 82.3 |
| THROUGH LINE OF FIRE | rule | 0.11 | - | 19.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 36.7 |
| BLOCKED WHEEL | rule | 0.06 | - | 68.9 |
| CATCH ODDS | rule | 0.06 | - | 11.6 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 10.4 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 2.8 |
| REFUSING RETIRES | rule | 0.06 | - | 0.9 |
| STANDS TO CAST | rule | 0.03 | 0.03 | 10.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 25.1 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 29.8 |
| FACES THE THREAT | rule | 0.03 | - | 21.3 |
| FALLBACK BY WORTH | rule | - | 0.03 | 37.8 |
| REDIRECT WEIGHED | rule | 0.03 | - | 76.5 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 362.2 |

### Plans: dep-opp-13df7bd-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.5 | 13% | 435 | 352 | 81% |
| Mine | charge | 3.2 | 59% | 272 | 291 | 107% |
| Mine | close in | 3.4 | 29% | 231 | 137 | 59% |
| Mine | hold | 4.8 | 40% | 283 | 0 | 0% |
| Mine | join | 0.5 | 100% | 20 | 0 | 0% |
| Mine | shoot | 9.3 | 65% | 396 | 743 | 188% |
| Mine | support | 3.9 | 92% | 35 | 0 | 0% |
| Opponent | advance | 12.1 | 14% | 317 | 265 | 84% |
| Opponent | charge | 4.7 | 59% | 381 | 473 | 124% |
| Opponent | close in | 6.2 | 28% | 475 | 190 | 40% |
| Opponent | hold | 5.4 | 45% | 339 | 0 | 0% |
| Opponent | join | 1.5 | 98% | 77 | 0 | 0% |
| Opponent | shoot | 4.1 | 55% | 69 | 187 | 272% |
| Opponent | support | 6.0 | 91% | 63 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 100% | 0% | 3.0 | 209 | 200 | 100% | 21 |
| Opponent | 0.1 | 5 | 2 | 0% | 0% | 0% | - | 430 | 0 | 0% | 105 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 217 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 100% | 0% | 3.0 | 209 | 200 | 100% | 157 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 388 | 0 | 0% | 50 |
| Wood Elf Realms | 0.3 | 2 | 1 | 0% | 0% | 0% | - | 514 | 0 | 0% | 45 |

### Battle groups: dep-opp-13df7bd-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.3 | 24% | 48% | 16% | 50% | 34% | 11% | 14% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 22% | 76% | 35% | 17% | 45% | 0% | 9% | 45% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 18% | 48% | 8% | 0% | 33% | 9% | 4% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 4.2 | 25% | 84% | 16% | 17% | 9% | 3% | 6% | 69% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 0 | 33% | 5.5 | 0 (1) | 73 (1) | 0 (1) | 73 (1) | 0 (2) |
| Mine | Chaff | 38 | 28 (38) | 13 | 15 | 43 | 45% | 2.6 | 48 (17) | 17 (12) | 0 (9) | 47 (23) | 3 (15) |
| Mine | Character | 124 | 52 (124) | 52 | 0 | 29 | 15% | 2.5 | 61 (35) | 58 (60) | 29 (9) | 61 (60) | 53 (44) |
| Mine | Clean-up | 22 | 65 (22) | 31 | 34 | 43 | 14% | 3.1 | 39 (8) | 82 (11) | 99 (3) | 59 (16) | 80 (6) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 53 | 0% | 1.0 | - | 0 (2) | 0 (1) | 0 (3) | - |
| Mine | Fast Hammer | 42 | 37 (42) | 22 | 15 | 42 | 26% | 3.0 | 68 (17) | 18 (12) | 12 (13) | 49 (31) | 12 (11) |
| Mine | Fragile | 5 | 43 (5) | 43 | 0 | 40 | 0% | 2.0 | 69 (1) | 49 (3) | 0 (1) | 69 (1) | 37 (4) |
| Mine | Hammer | 58 | 45 (58) | 31 | 14 | 38 | 16% | 2.7 | 23 (9) | 56 (40) | 16 (9) | 47 (33) | 43 (25) |
| Mine | Holder | 26 | 107 (26) | 24 | 83 | 12 | 42% | 3.4 | 67 (7) | 120 (14) | 147 (5) | 156 (10) | 78 (16) |
| Mine | Shooter | 44 | 108 (44) | 54 | 54 | 34 | 9% | 1.6 | 143 (4) | 107 (32) | 93 (8) | 121 (25) | 92 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 3.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 57 (56) | 57 | 0 | 41 | 7% | 1.3 | 78 (13) | 47 (37) | 77 (6) | 66 (12) | 55 (44) |
| Mine | Wizard | 22 | 13 (22) | 13 | 0 | 33 | 18% | 2.2 | 20 (6) | 22 (8) | 0 (4) | 33 (9) | 0 (9) |
| Opponent | Blocker | 1 | 33 (1) | 33 | 0 | 100 | 0% | 3.0 | - | - | 33 (1) | 33 (1) | - |
| Opponent | Chaff | 67 | 102 (67) | 17 | 84 | 57 | 31% | 3.2 | 58 (23) | 186 (26) | 37 (18) | 117 (49) | 56 (18) |
| Opponent | Character | 114 | 36 (114) | 36 | 0 | 39 | 26% | 2.6 | 24 (28) | 38 (55) | 72 (16) | 31 (60) | 52 (39) |
| Opponent | Clean-up | 16 | 23 (16) | 20 | 3 | 56 | 19% | 2.8 | 0 (5) | 37 (8) | 23 (3) | 32 (11) | 11 (5) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 57 | 47 (57) | 28 | 18 | 56 | 33% | 2.5 | 38 (19) | 53 (31) | 51 (7) | 38 (36) | 62 (21) |
| Opponent | Fragile | 10 | 56 (10) | 56 | 0 | 40 | 30% | 2.9 | 238 (2) | 0 (2) | 0 (6) | 112 (5) | 0 (5) |
| Opponent | Hammer | 65 | 43 (65) | 38 | 5 | 49 | 22% | 2.9 | 30 (23) | 54 (30) | 43 (12) | 36 (38) | 55 (27) |
| Opponent | Holder | 40 | 68 (40) | 4 | 63 | 30 | 38% | 3.5 | 20 (10) | 114 (18) | 31 (12) | 88 (20) | 50 (20) |
| Opponent | Shooter | 30 | 54 (30) | 13 | 41 | 45 | 7% | 1.4 | 77 (12) | 52 (10) | 26 (8) | 75 (17) | 21 (13) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 53 (13) | 53 | 0 | 61 | 15% | 1.3 | 0 (7) | 49 (3) | 196 (3) | 233 (2) | 24 (11) |
| Opponent | Wizard | 22 | 8 (22) | 8 | 0 | 44 | 5% | 2.1 | 0 (8) | 17 (10) | 0 (1) | 14 (11) | 0 (8) |

### Charged fights: dep-opp-13df7bd-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 104 | 48 | 2.0 | 1.1 | 24 | 22 | +2 | 1 of 10 | 5 of 10 | +102 | -9 |
| Mine | Chaos Dwarfs | 3 | 213 | 742 | 4.3 | 1.2 | 171 | 9 | +163 | 7 of 13 | 12 of 13 | +340 | +109 |
| Mine | Dwarfen Mountain Holds | 4 | 429 | 160 | 1.2 | 1.0 | 128 | 28 | +101 | 2 of 5 | 2 of 5 | - | +101 |
| Mine | Empire of Man | 5 | 454 | 200 | 2.4 | 1.0 | 83 | 33 | +50 | 2 of 12 | 9 of 12 | - | +50 |
| Mine | Grand Cathay | 4 | 360 | 488 | 4.0 | 1.0 | 122 | 46 | +76 | 8 of 16 | 11 of 16 | - | +76 |
| Mine | High Elf Realms | 4 | 54 | 1077 | 5.0 | 1.1 | 215 | 15 | +201 | 8 of 20 | 15 of 20 | +218 | +199 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1222 | 5.0 | 1.4 | 244 | 0 | +244 | 3 of 5 | 5 of 5 | +417 | +129 |
| Mine | Lizardmen | 1 | 626 | 66 | 2.0 | 1.0 | 33 | 0 | +33 | 0 of 2 | 2 of 2 | - | +33 |
| Mine | Ogre Kingdoms | 1 | 265 | 66 | 5.0 | 1.0 | 13 | 7 | +6 | 0 of 5 | 2 of 5 | - | +6 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 395 | 4.0 | 1.2 | 99 | 118 | -19 | 2 of 4 | 3 of 4 | -472 | +132 |
| Mine | Skaven | 2 | 45 | 313 | 1.5 | 1.0 | 209 | 0 | +209 | 1 of 3 | 3 of 3 | - | +209 |
| Mine | Tomb Kings of Khemri | 2 | 228 | 887 | 3.5 | 1.3 | 253 | 28 | +226 | 2 of 7 | 6 of 7 | +529 | +104 |
| Mine | Vampire Counts | 2 | 0 | 142 | 1.5 | 1.3 | 95 | 0 | +95 | 2 of 3 | 3 of 3 | +0 | +142 |
| Mine | Warriors of Chaos | 1 | 54 | 366 | 3.0 | 1.0 | 122 | 0 | +122 | 0 of 3 | 3 of 3 | - | +122 |
| **Mine** | all armies | 36 | 230 | 421 | 3.0 | 1.1 | 140 | 24 | +116 | 38 of 108 | 81 of 108 | +248 | +100 |
| Opponent | Beastmen Brayherds | 1 | 0 | 1159 | 4.0 | 1.8 | 290 | 68 | +221 | 2 of 4 | 3 of 4 | +372 | +71 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.5 | 56 | 0 | +56 | 0 of 2 | 1 of 2 | +0 | +112 |
| Opponent | Empire of Man | 1 | 424 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 1 | 355 | 728 | 3.0 | 1.7 | 243 | 0 | +243 | 2 of 3 | 3 of 3 | +0 | +364 |
| Opponent | High Elf Realms | 2 | 324 | 465 | 4.0 | 1.4 | 116 | 0 | +116 | 2 of 8 | 6 of 8 | +253 | +34 |
| Opponent | Lizardmen | 1 | 0 | 250 | 2.0 | 1.0 | 125 | 0 | +125 | 0 of 2 | 2 of 2 | - | +125 |
| Opponent | Ogre Kingdoms | 2 | 68 | 458 | 3.0 | 1.7 | 153 | 47 | +106 | 2 of 6 | 3 of 6 | +444 | -63 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 281 | 5.0 | 1.0 | 56 | 154 | -98 | 4 of 10 | 5 of 10 | - | -98 |
| Opponent | Skaven | 2 | 188 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 11 | 967 | 3.5 | 1.3 | 276 | 10 | +266 | 7 of 14 | 13 of 14 | +170 | +305 |
| Opponent | Vampire Counts | 6 | 20 | 468 | 4.0 | 1.3 | 117 | 50 | +66 | 11 of 24 | 16 of 23 | +172 | +23 |
| Opponent | Warriors of Chaos | 7 | 0 | 102 | 2.0 | 1.1 | 51 | 44 | +6 | 9 of 14 | 9 of 14 | +0 | +8 |
| Opponent | Wood Elf Realms | 6 | 91 | 165 | 2.8 | 1.2 | 58 | 49 | +9 | 6 of 17 | 12 of 17 | -20 | +13 |
| **Opponent** | all armies | 36 | 74 | 362 | 2.9 | 1.3 | 124 | 47 | +77 | 45 of 105 | 74 of 104 | +176 | +48 |

### Effective charges: dep-opp-13df7bd-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 3 (net -28) | 0 | 2 (net +28) | 2 (net -26) | 1 (net +102) | 2 (net +0) | 0 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 13 | 4 (net +273) | 0 | 0 | 0 | 3 (net +102) | 4 (net +118) | 2 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 5 | 2 (net +0) | 0 | 1 (net +111) | 0 | 0 | 2 (net +196) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 12 | 1 (net -110) | 1 (net +505) | 1 (net +0) | 2 (net +42) | 1 (net +66) | 4 (net +70) | 2 | 10% (1 of 10) |
| Mine | Grand Cathay | 16 | 2 (net -320) | 1 (net +328) | 6 (net +102) | 2 (net +270) | 1 (net +41) | 4 (net +83) | 0 | 38% (6 of 16) |
| Mine | High Elf Realms | 20 | 3 (net +30) | 0 | 6 (net +272) | 3 (net +79) | 0 | 7 (net +223) | 1 | 32% (6 of 19) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +268) | 0 | 0 | 1 (net +580) | 2 (net +60) | 1 (net +254) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +33) | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 1 (net +66) | 0 | 1 (net +0) | 3 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +325) | 0 | 0 | 0 | 0 | 0 | 3 | 0% (0 of 1) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net +186) | 0 | 2 (net +220) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +938) | 0 | 1 (net -195) | 0 | 1 (net +120) | 4 (net +179) | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 3 | 0 | 1 (net +0) | 0 | 1 (net +285) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +0) | 1 (net +251) | 0 | 1 (net +115) | 0 | 33% (1 of 3) |
| Opponent | Beastmen Brayherds | 4 | 1 (net +26) | 0 | 2 (net +71) | 0 | 0 | 1 (net +717) | 0 | 50% (2 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 3 | 1 (net +0) | 0 | 1 (net +613) | 1 (net +115) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 8 | 0 | 0 | 0 | 6 (net +148) | 0 | 1 (net +45) | 1 | 0% (0 of 7) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 2 (net +125) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 6 | 1 (net -34) | 0 | 0 | 0 | 1 (net +65) | 1 (net +822) | 3 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net -200) | 0 | 2 (net +145) | 0 | 0 | 0 | 6 | 50% (2 of 4) |
| Opponent | Tomb Kings of Khemri | 14 | 1 (net +102) | 0 | 3 (net +524) | 2 (net +378) | 0 | 4 (net +241) | 4 | 30% (3 of 10) |
| Opponent | Vampire Counts | 24 | 1 (net +0) | 0 | 5 (net +47) | 5 (net -33) | 3 (net +115) | 7 (net +171) | 3 | 24% (5 of 21) |
| Opponent | Warriors of Chaos | 14 | 1 (net +0) | 0 | 2 (net +0) | 1 (net -260) | 1 (net +0) | 4 (net +96) | 5 | 22% (2 of 9) |
| Opponent | Wood Elf Realms | 17 | 3 (net -35) | 0 | 4 (net -181) | 3 (net +176) | 0 | 6 (net +77) | 1 | 25% (4 of 16) |

### Charged fights, damage counted: dep-opp-13df7bd-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 18 | 287 | 241 | +104 | 192 | 74 | +118 | +41.2 |
| Mine | 50-54% | 3 | 423 | 210 | +278 | 278 | 0 | +278 | +65.6 |
| Mine | Effective (55-75%) | 18 | 239 | 193 | +123 | 166 | 41 | +125 | +52.0 |
| Mine | 76-89% | 14 | 228 | 164 | +155 | 165 | 5 | +160 | +70.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 253 | 177 | +132 | 183 | 22 | +161 | +63.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 384 | 79 | +84 | 100 | 19 | +80 | +20.9 |
| Mine | No odds | 11 | 230 | 171 | +7 | 81 | 88 | -6 | -2.8 |
| Mine | All fights | 108 | 267 | 181 | +116 | 164 | 37 | +127 | +47.7 |
| Opponent | Long shot (under 50%) | 12 | 196 | 248 | -34 | 52 | 67 | -15 | -7.5 |
| Opponent | Effective (55-75%) | 20 | 257 | 256 | +106 | 202 | 61 | +141 | +54.8 |
| Opponent | 76-89% | 20 | 311 | 175 | +106 | 196 | 108 | +88 | +28.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 308 | 196 | +188 | 211 | 27 | +184 | +59.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 390 | 96 | +82 | 112 | 32 | +81 | +20.7 |
| Opponent | No odds | 23 | 213 | 241 | -35 | 75 | 93 | -18 | -8.5 |
| Opponent | All fights | 105 | 269 | 214 | +77 | 154 | 68 | +86 | +31.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p1 | move | 453 | 101 (22%) | 73 (16%) | 50 (11%) | 302 (67%) |
| dep-opp-13df7bd-p1 | objective | 353 | 57 (16%) | 40 (11%) | 42 (12%) | 254 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

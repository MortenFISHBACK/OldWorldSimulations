# Doctrine scorecard: dep-mine-13df7bd-p6

### Scorecard: dep-mine-13df7bd-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 2 | 4 | 1 | 2 | 0 | 0 | 0 | 120 |
| L0108 | 6 | 1 | Opponent | yes | 2 | 3 | 1 | 2 | 1 | 0 | 0 | 515 |
| L0124 | 4 | 1 | Mine | yes | 10 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0124 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Mine | no | 0 | - | 2 | 5 | 1 | 0 | 0 | 170 |
| L0208 | 4 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0224 | 2 | 1 | Mine | - | - | 3 | 4 | 3 | 1 | 0 | 0 | 170 |
| L0224 | 2 | 1 | Opponent | - | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0309 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 760 |
| L0309 | 3 | 1 | Opponent | yes | 5 | 5 | 0 | 2 | 0 | 0 | 0 | 420 |
| L0325 | 1 | 1 | Mine | no | 4 | 5 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0325 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 0 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L0427 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 4 | 1 | 0 | 0 | 186 |
| L0514 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 974 |
| L0514 | 4 | 1 | Opponent | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0530 | 2 | 1 | Mine | - | - | - | 2 | 0 | 0 | 0 | 0 | 763 |
| L0530 | 2 | 1 | Opponent | - | - | 3 | 2 | 5 | 1 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 798 |
| L0618 | 6 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 68 |
| L0635 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 615 |
| L0635 | 5 | 1 | Opponent | yes | - | 1 | 2 | 5 | 0 | 0 | 0 | 265 |
| L0723 | 3 | 1 | Mine | yes | 3 | 6 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0723 | 3 | 1 | Opponent | no | 6 | 1 | 4 | 3 | 2 | 0 | 0 | 70 |
| L0813 | 3 | 1 | Mine | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 807 |
| L0813 | 3 | 1 | Opponent | yes | 8 | - | 0 | 1 | 1 | 0 | 0 | 370 |
| L0829 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 707 |
| L0829 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 122 |
| L0920 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 564 |
| L0920 | 2 | 1 | Opponent | - | - | - | 0 | 7 | 0 | 0 | 0 | 210 |
| L1011 | 3 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 165 |
| L1011 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1028 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1028 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1120 | 4 | 1 | Mine | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1120 | 4 | 1 | Opponent | no | 0 | - | 1 | 2 | 2 | 0 | 0 | 685 |
| L1214 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 2 | 0 | 0 | 330 |
| L1214 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 1 | Mine | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1230 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1325 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1325 | 5 | 1 | Opponent | yes | - | 1 | 3 | 5 | 0 | 0 | 0 | 147 |
| L1420 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1420 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 1057 |
| L1517 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1517 | 5 | 1 | Opponent | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 98 |
| L1533 | 3 | 1 | Mine | yes | 7 | 3 | 3 | 1 | 0 | 0 | 0 | 126 |
| L1533 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 236 |
| L1631 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L1631 | 5 | 1 | Opponent | yes | - | - | 3 | 1 | 0 | 0 | 0 | 340 |
| L1729 | 1 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 49 |
| L1729 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Mine | yes | - | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 170 |
| L1929 | 3 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1929 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2031 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 420 |
| L2031 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 340 |
| L2134 | 4 | 1 | Mine | no | 3 | - | 1 | 5 | 0 | 0 | 0 | 145 |
| L2134 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 107 |
| L2325 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2325 | 3 | 1 | Opponent | no | 8 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2431 | 1 | 1 | Mine | no | 3 | 5 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2431 | 1 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2628 | 6 | 1 | Mine | no | 8 | 1 | 1 | 0 | 0 | 0 | 0 | 60 |
| L2628 | 6 | 1 | Opponent | no | 1 | - | 0 | 1 | 2 | 0 | 0 | 0 |
| L2830 | 4 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 238 |
| L2830 | 4 | 1 | Opponent | yes | 11 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L3035 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 198 |
| L3035 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 2.6 | 3.1 | 2.0 | 1.0 | 0.3 | 0.0 | 0.0 | 295.4 |
| **Average** | | | Opponent | 32% | 2.5 | 2.3 | 2.1 | 1.9 | 0.5 | 0.0 | 0.0 | 190.0 |

### KPIs: dep-mine-13df7bd-p6

Rules off - Opponent only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 178) | 9% (16 of 185) | 19% (69 of 363) |
| Winner chose to follow up after the loser gave ground |  | 100% (66 of 66); on the table 100% | 97% (62 of 64); on the table 97% | 98% (128 of 130); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (11 of 11); on the table 100% | 82% (9 of 11); on the table 82% | 91% (20 of 22); on the table 91% |
| Winner chose to pursue after the loser fled |  | 85% (17 of 20); on the table 85% | 53% (20 of 38); on the table 66% | 64% (37 of 58); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 97% (94 of 97); on the table 97% | 81% (91 of 113); on the table 85% | 88% (185 of 210); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 32% (98 of 310) | 33% (62 of 187) | 32% (160 of 497) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (98 of 223) | 53% (62 of 117) | 47% (160 of 340) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (11 of 21) | 45% (30 of 66) | 47% (41 of 87) |
| Points that never fought | lower | 47% (33072 of 70457) | 43% (30700 of 71981) | 45% (63772 of 142438) |
|   infantry points that never fought | lower | 58% (9049 of 15655) | 55% (7772 of 14129) | 56% (16821 of 29784) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (160 of 275) | 65% (189 of 290) | 62% (349 of 565) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.9 uses a game | 85% (11 of 13); 1.2 uses a game | 87% (33 of 38); 1.6 uses a game |
| Bound items with another spell used |  | 69% (9 of 13); 0.4 uses a game | 36% (5 of 14); 0.2 uses a game | 52% (14 of 27); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 48% (10 of 21); 0.3 uses a game | 33% (4 of 12); 0.1 uses a game | 42% (14 of 33); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32431 of 60045) | 61% (39229 of 64650) | 57% (71660 of 124695) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (29%) | 1.0 (29%) | 2.7 (29%) |
| MARCHED: its unit marched | 1.4 (24%) | 0.3 (8%) | 1.7 (18%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.4 (25%) | 0.5 (14%) | 1.9 (21%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| GONE: slain | 0.6 (11%) | 1.1 (33%) | 1.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.2 | 1.9 | 4.4 | 0.6 | 2.1 |
| not cast | 3.7 | 2.7 | 4.0 | 9.4 | 2.4 | 21.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (33%) | 0.2 (6%) | 2.7 (29%) | 0.5 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.4 (16%) | 0.6 (15%) | 1.9 (21%) | 0.8 (31%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.1 (3%) | 0.3 (8%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (3%) | 0.1 (1%) | 0.3 (4%) | 0.2 (7%) | 0.9 (4%) |
| GONE: slain | 0.9 (25%) | 0.6 (23%) | 0.7 (18%) | 1.8 (19%) | 0.3 (11%) | 3.9 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.2 (6%) | 0.1 (2%) | 0.3 (3%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (45%) | 0.2 (7%) | 1.9 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 56% (19 of 34) | 70% (19 of 27) | 62% (38 of 61) |
| the unit moved after it | 58% (11 of 19) | 53% (10 of 19) | 55% (21 of 38) |
| it charged on its next turn | 5% (1 of 19) | 0% (0 of 19) | 3% (1 of 38) |
| the enemy charged it first | 11% (2 of 19) | 5% (1 of 19) | 8% (3 of 38) |
| it fought by the end of its next turn | 5% (1 of 19) | 0% (0 of 19) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 19) | 5% (1 of 19) | 8% (3 of 38) |
| none of these (no charge, no fight, no charge escaped) | 74% (14 of 19) | 89% (17 of 19) | 82% (31 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (572 of 891) | 56% (309 of 555) | 61% (881 of 1446) |
|   cavalry | 54% (44 of 81) | 52% (64 of 122) | 53% (108 of 203) |
|   character | 55% (59 of 108) | 17% (14 of 81) | 39% (73 of 189) |
|   chariot | 54% (52 of 96) | 82% (31 of 38) | 62% (83 of 134) |
|   infantry | 61% (153 of 249) | 65% (118 of 182) | 63% (271 of 431) |
|   monster | 64% (25 of 39) | 30% (9 of 30) | 49% (34 of 69) |
|   war machine | 75% (239 of 318) | 72% (73 of 102) | 74% (312 of 420) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (31%) | 1.5 (22%) | 4.2 (27%) |
| CHARGED: it charged | 0.8 (9%) | 1.1 (15%) | 1.8 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.2 (3%) | 0.8 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.1 (23%) | 1.8 (26%) | 3.9 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.4 (5%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.3 (19%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| OTHER BAR | 0.5 (6%) | 0.3 (5%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 1.6 | 74% | 9.2 pts | 42 pts |
| character | 2.3 | 0.8 | 76% | 7.6 pts | 18 pts |
| chariot | 2.4 | 1.4 | 66% | 9.5 pts | 23 pts |
| infantry | 11.3 | 4.5 | 72% | 10.5 pts | 119 pts |
| monster | 1.2 | 0.3 | 82% | 8.7 pts | 11 pts |
| war machine | 8.9 | 7.3 | 62% | 18.4 pts | 164 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 4.2 | 4.0 |
| Charges that made contact a game | 3.1 | 2.9 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.90 declared, 0.80 contact (20 units) | 0.45 declared, 0.35 contact (20 units) | 0.68 declared, 0.57 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.83 contact (6 units) | 1.08 declared, 0.85 contact (13 units) | 1.05 declared, 0.84 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.39 contact (233 units) | 0.51 declared, 0.34 contact (253 units) | 0.50 declared, 0.36 contact (486 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (36 of 69) | 65% (17 of 26) | 50% (6 of 12) | 55% (59 of 107) |
| Character in a unit | 100% (37 of 37) | 83% (20 of 24) | 71% (5 of 7) | 91% (62 of 68) |
| Character on its own | 83% (30 of 36) | 58% (19 of 33) | 35% (22 of 62) | 54% (71 of 131) |
| Chariot | 92% (11 of 12) | 64% (9 of 14) | - | 77% (20 of 26) |
| Infantry | 53% (45 of 85) | 53% (18 of 34) | 20% (1 of 5) | 52% (64 of 124) |
| Monster | 64% (16 of 25) | 53% (8 of 15) | - | 60% (24 of 40) |
| Monstrous | 57% (4 of 7) | 78% (7 of 9) | - | 69% (11 of 16) |
| War Machines | 71% (36 of 51) | 100% (2 of 2) | - | 72% (38 of 53) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (11 of 12); on the table 92% | 31% (32 of 102) | 55% | 64% (14 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 1.5 uses a game | 50% (3 of 6); 0.8 uses a game |
| Chaos Dwarfs | 4 | 60% (3 of 5); on the table 60% | 54% (13 of 24) | 53% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 100% (2 of 2); on the table 100% | - | 65% | 74% (25 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 67% (2 of 3); on the table 67% | 53% (19 of 36) | 71% | 57% (42 of 74) | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game | 60% (3 of 5); 0.4 uses a game |
| Grand Cathay | 7 | 100% (18 of 18); on the table 100% | 22% (30 of 137) | 37% | 56% (32 of 57) | 94% (15 of 16); 8.1 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 7); 0.0 uses a game |
| High Elf Realms | 7 | 97% (34 of 35); on the table 97% | 19% (7 of 36) | 38% | 51% (29 of 57) | 100% (6 of 6); 3.3 uses a game | 45% (10 of 22); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 64% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | 50% (3 of 6) | 38% | 86% (12 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 74% | 100% (14 of 14) | 100% (2 of 2); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 12% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 5 | 75% (12 of 16); on the table 94% | 23% (7 of 30) | 35% | 59% (22 of 37) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| Tomb Kings of Khemri | 2 | 100% (3 of 3); on the table 100% | - | 54% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (30 of 30); on the table 100% | 38% (18 of 48) | 32% | 58% (29 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 14 | 77% (49 of 64); on the table 80% | 48% (20 of 42) | 36% | 65% (70 of 108) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 100% (4 of 4); 0.3 uses a game |
| Wood Elf Realms | 4 | 91% (10 of 11); on the table 91% | 50% (9 of 18) | 40% | 67% (28 of 42) | 50% (2 of 4); 1.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-mine-13df7bd-p6, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (32) | 46% (33) | 49% (65) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.56 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.14 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.36 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.11 | 2.86 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.06 | 0.92 | 1.97 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.97 | 5.47 | 10.44 |

### Quality by phase: dep-mine-13df7bd-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.1 |
| Strategy | Charge objectives carried out (made contact) | 55% (67 of 122) | 49% (65 of 134) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (173 of 387) | 55% (115 of 209) |
| Strategy | Close-in objectives charged next turn | 11% (17 of 148) | 15% (28 of 186) |
| Strategy | Support requests answered (helper made contact too) | 61% (11 of 18) | 43% (10 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 43% (3 of 7) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 33% (18 of 54) | 30% (13 of 44) |
| Strategy | Lone characters that fought | 70% (57 of 82) | 72% (59 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 295.4 | 190.0 |
| Movement | Fights charged into per game | 2.6 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 80, net +173 | 14 of 80, net +147 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 80, net +128 | 21 of 80, net +96 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 80, net +104 | 12 of 80, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 80, net +87 | 12 of 80, net +54 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 7.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (155 of 363) | 46% (122 of 268) |
| Shooting | Points destroyed by shooting units | 101.4 | 48.8 |
| Shooting | War machine shots | 6.6 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (107 of 239) | 41% (33 of 81) |
| Shooting | Points destroyed by war machines | 35.4 | 25.4 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (20 of 56) | 43% (19 of 44) |
| Magic | Wounds caused by magic missiles | 3.4 | 1.8 |
| Magic | Wounds caused by other spells | 1.7 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 130.9 | 22.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.2 / 1.0 / 0.1 | 1.3 / 0.4 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 275.4 | 333.8 |
| Combat | Points run down | 45.8 | 78.3 |
| Combat | Net points per charged fight, damage counted | +93 | +125 |
| Combat | Net per 100 charger points, damage counted | +31.5 | +39.4 |
| Combat | First round won (charged fights) | 71% | 69% |
| Combat | Net points per charged fight | +98 | +112 |
| Combat | Net points per supported fight / lone fight | +163 / +85 | +207 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 93 | 42 of 84 |
| Game | Points lost | 587.1 | 696.3 |
| Game | VP from objectives | 663.6 | 528.3 |
| Game | Lone holders (player turns) | 2.6 | 2.5 |

- Mine won / drew / lost: 17 / 8 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +232 VP
- The side that went first won 16 of 28 games with a winner
- Points traded per game (both sides' losses): 1283
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: dep-mine-13df7bd-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 8.0 | 0.9 | +0.0 | 0.0 | 3.9 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 16.2 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +5.4 | 0.0 | 68.7 | 1.0 | +9.0 | 0.0 | 57.6 |
| BEST FACING | 0.5 | +31.6 | 0.0 | 8.5 | 0.5 | +15.6 | 0.0 | 26.0 |
| BEST FIRST | 4.5 | +179.6 | 153.5 | 104.7 | 4.3 | +158.6 | 160.7 | 36.3 |
| BEST OVERALL | 0.6 | +32.1 | 0.0 | 21.4 | 0.6 | +23.4 | 0.0 | 26.0 |
| BEST PREY | 0.5 | +26.4 | 19.7 | 19.9 | 0.6 | +23.8 | 0.0 | 5.8 |
| BEST PRIZE | - | - | - | - | 0.1 | -3.8 | 1.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 25.5 | 0.2 | -1.7 | 0.0 | 27.3 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 12.1 | 4.0 |
| BLOCKED WHEEL | 0.2 | +4.5 | 0.0 | 13.4 | 0.5 | +6.4 | 0.0 | 9.8 |
| BLOWS WHERE AIMED | 0.4 | -20.9 | 38.4 | 22.3 | 0.3 | -32.3 | 80.9 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 93.1 | 3.5 | 0.2 | +0.0 | 29.6 | 0.0 |
| CANNON PLANNED TARGET | 5.5 | +134.8 | 362.5 | 44.7 | 1.7 | +41.8 | 131.2 | 16.1 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 2.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.0 |
| CAST JOB | 0.8 | +24.7 | 59.0 | 0.0 | 0.7 | +11.1 | 54.9 | 15.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +24.6 | 17.3 | 0.0 | 0.2 | +4.5 | 19.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 25.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -0.8 | 5.1 | 2.3 | 0.2 | -0.2 | 3.2 | 0.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 237.8 | 51.0 | 1.8 | +0.0 | 201.6 | 32.6 |
| CHARGE NOW WEIGHED | 0.6 | -45.4 | 9.0 | 27.2 | 0.8 | -103.8 | 38.1 | 37.8 |
| CHARGER SLAIN LOST | 0.6 | -16.9 | 46.9 | 37.4 | 0.4 | -7.5 | 46.8 | 38.6 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.6 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 2.4 | 1.8 | 0.1 | +0.0 | 5.6 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 31.8 | 31.1 | 0.3 | +0.0 | 28.5 | 34.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +213.4 | 35.8 | 26.9 | 0.4 | +31.1 | 18.9 | 13.9 |
| COUNTER-CHARGE COVER | 8.1 | +586.2 | 0.0 | 142.2 | 7.7 | +793.3 | 0.0 | 197.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 7.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +7.3 | 27.7 | 0.0 |
| DEPLOY BY FIGURES | 7.9 | +10.3 | 0.0 | 19.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +8.4 | 14.1 | 7.9 | 0.1 | +9.8 | 38.3 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +158.4 | 0.0 | 55.6 | 1.1 | +79.0 | 0.0 | 38.1 |
| FALLBACK BY WORTH | 4.7 | +58.3 | 0.0 | 54.1 | 5.5 | +63.8 | 0.0 | 62.1 |
| FIGHT LIFT | 0.1 | +1.3 | 2.2 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 195.0 | 5.3 | +0.0 | 0.0 | 171.6 |
| FOLLOW UP WEIGHED | 0.9 | +127.6 | 0.0 | 56.0 | 0.9 | +129.9 | 0.0 | 53.6 |
| FRIENDS SHOTS CHECKED | 0.1 | +10.2 | 0.0 | 17.8 | 0.1 | +4.0 | 0.0 | 2.8 |
| GIVES UP | 0.1 | -0.9 | 10.7 | 7.9 | 0.1 | -2.3 | 10.6 | 0.0 |
| GROUND FLIERS | 0.0 | +0.4 | 0.0 | 7.5 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 13.0 | 3.4 | 0.1 | +0.0 | 6.5 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 71.6 | 1.4 | 0.1 | +0.0 | 3.1 | 4.0 |
| HILL BY ITS CHANCE | 0.5 | -31.4 | 0.0 | 0.0 | 0.4 | -43.4 | 0.0 | 6.8 |
| HOLDER AT DEPLOYMENT | 1.0 | +182.5 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.2 | -134.4 | 550.4 | 132.8 | 6.9 | -147.7 | 378.8 | 149.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.2 | 2.4 | 3.8 | 0.1 | +2.6 | 0.0 | 2.7 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.6 | +25.5 | 0.0 | 6.5 | 0.2 | +7.8 | 0.0 | 14.4 |
| HUNT RESULT | 0.1 | +2.5 | 0.0 | 3.8 | 0.1 | +0.0 | 0.0 | 2.7 |
| HUNT THE GUNS | 0.1 | +26.6 | 12.6 | 3.8 | 0.1 | +19.4 | 0.0 | 2.7 |
| INVITES THE FIGHT | 1.9 | +33.0 | 106.9 | 33.1 | 1.0 | +15.8 | 9.0 | 6.7 |
| JOINT CHARGE PLAN | 0.1 | +6.0 | 0.0 | 0.0 | 0.1 | +19.5 | 0.0 | 7.9 |
| JOINT KNOWS CHALLENGE | 0.2 | -2.8 | 56.8 | 3.4 | 0.0 | -0.3 | 5.1 | 12.9 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.2 | +35.0 | 135.2 | 41.8 | 1.5 | +45.0 | 136.9 | 15.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +66.9 | 103.6 | 17.4 | 1.7 | +77.0 | 148.6 | 38.7 |
| KILLS COUNT NEXT TURN | 4.2 | +140.3 | 218.4 | 124.9 | 6.5 | +214.7 | 149.9 | 131.3 |
| LANE BY FIGURES | 0.7 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.2 | +7.2 | 8.7 | 6.9 | 0.3 | +8.0 | 0.0 | 1.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 13.1 | 5.9 |
| LONE WIZARD KEPT IN | 0.5 | +34.4 | 0.0 | 0.0 | 0.3 | +23.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +7.2 | 26.9 | 3.6 | 0.3 | +1.1 | 15.4 | 2.9 |
| LOST CHARGE | 2.7 | -42.6 | 167.9 | 118.7 | 2.4 | -44.5 | 68.5 | 81.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.2 | 0.0 | 0.0 | 0.1 | -6.6 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +57.1 | 11.7 | 27.1 | 0.6 | +68.3 | 24.9 | 33.7 |
| MANOEUVRE | 0.2 | +4.9 | 0.0 | 1.4 | 0.3 | +7.1 | 0.0 | 5.5 |
| MARCH AT ESCAPER | 0.2 | +0.9 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +26.1 | 0.0 | 0.0 | 0.3 | +10.0 | 0.0 | 16.2 |
| MARCH ODDS | 0.3 | +28.4 | 9.0 | 34.5 | 0.3 | +17.3 | 14.3 | 6.5 |
| MARCH OVER CASTS | 0.8 | +61.8 | 0.0 | 39.3 | 0.4 | +29.0 | 0.0 | 5.9 |
| MAX FOR POSITIONING | 4.4 | +159.1 | 0.0 | 120.9 | 4.8 | +225.5 | 0.0 | 130.7 |
| MISSILES IN THE MOVE | 4.3 | +140.0 | 0.0 | 92.1 | 3.1 | +61.9 | 0.0 | 65.9 |
| MISSILES NEXT TURN | 5.2 | +99.8 | 0.0 | 128.8 | 3.5 | +40.8 | 0.0 | 94.8 |
| MODEL FACING | 0.2 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 7.9 | 43.1 | 0.1 | +0.0 | 0.0 | 13.9 |
| MOVE AND CAST | 0.4 | +21.6 | 0.0 | 10.5 | 0.3 | +8.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -10.0 | 16.9 | 24.7 | 0.3 | -7.8 | 6.2 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 30.0 |
| MOVE TO CHARGE | 3.0 | +189.2 | 175.1 | 76.1 | 3.8 | +336.4 | 87.1 | 62.4 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +5.1 | 3.3 | 0.0 | 0.0 | +1.9 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +0.6 | 0.0 | 12.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -10.4 | 41.5 | 3.4 | 0.4 | -28.3 | 50.9 | 3.1 |
| NOT TURNED | 5.0 | +84.8 | 0.0 | 157.7 | 5.5 | +92.2 | 0.0 | 129.1 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 16.1 | -750.1 | 2.1 | 340.9 | 14.4 | -820.6 | 16.1 | 202.3 |
| OPENS A LANE | 0.1 | +0.1 | 5.7 | 0.0 | 0.1 | +0.3 | 25.8 | 0.0 |
| OPENS UP | 0.0 | +0.4 | 1.8 | 0.0 | 0.1 | +11.5 | 2.6 | 0.0 |
| OVERRUNS AWAY | 0.4 | +8.6 | 53.2 | 31.2 | 0.4 | +9.9 | 58.2 | 38.7 |
| PATHS CROSS | 1.8 | +139.2 | 0.0 | 25.3 | 2.2 | +143.0 | 0.0 | 32.0 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -6.1 | 0.0 | 2.4 | 0.1 | -1.4 | 0.0 | 7.5 |
| PLAN RESULT | 37.1 | +1427.3 | 1456.6 | 811.6 | 35.2 | +1206.0 | 1324.2 | 936.1 |
| PURSUES BIG PREY | 0.0 | -1.1 | 0.0 | 0.0 | 0.1 | -6.4 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 2.3 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +12.1 | 0.0 | 33.2 | 1.8 | +29.5 | 0.0 | 42.2 |
| RANDOM MOVER NO PROMISE | 0.2 | -9.7 | 4.4 | 17.5 | 0.5 | -32.5 | 33.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.9 | 0.0 | 0.0 | 0.5 | -6.5 | 0.0 | 7.8 |
| REDIRECT COUNTER | 1.9 | +145.6 | 0.0 | 27.8 | 3.1 | +314.1 | 0.0 | 52.1 |
| REDIRECT WEIGHED | 0.3 | +3.5 | 4.2 | 4.0 | 0.4 | -3.7 | 0.0 | 2.7 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 24.0 | 0.2 | +0.0 | 0.0 | 17.1 |
| RESERVE FALL BACK | 0.4 | +17.1 | 0.0 | 4.4 | 0.3 | +11.1 | 0.0 | 1.8 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +3.6 | 0.0 | 5.9 |
| RISK BY ARC | 2.4 | +126.6 | 293.2 | 72.8 | 1.8 | +49.6 | 147.1 | 85.5 |
| SAFER THAN THE JOB | 1.1 | +56.4 | 0.0 | 36.0 | 0.9 | +51.2 | 0.0 | 45.6 |
| SCOUT SPOT | 0.3 | +0.5 | 0.0 | 1.5 | 0.2 | +0.5 | 0.0 | 0.9 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.2 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.0 | -0.8 | 0.0 | 0.0 | 0.2 | -8.2 | 0.0 | 3.0 |
| SEARCH SPOT | 2.6 | +139.2 | 0.0 | 29.6 | 2.4 | +111.2 | 0.0 | 24.7 |
| SELF MOVE SPELL | 0.4 | +92.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.2 | +86.1 | 18.6 | 55.4 | 1.5 | +194.2 | 32.9 | 41.1 |
| SET-UP ANY TARGET | 0.5 | +91.2 | 35.8 | 7.2 | 0.2 | +19.4 | 5.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +6.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 1.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +55.9 | 63.2 | 42.2 | 1.0 | +39.8 | 45.2 | 3.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 120.9 | 5.1 | 0.3 | +0.0 | 38.8 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +570.2 | 0.0 | 130.5 | 8.6 | +273.5 | 0.0 | 103.4 |
| SPELL SETS UP CHARGE | 0.7 | +206.9 | 35.8 | 7.2 | 0.2 | +19.4 | 5.0 | 0.0 |
| SPELL WORTH | 1.3 | +24.3 | 92.0 | 80.2 | 1.3 | +17.8 | 62.8 | 57.1 |
| SPELLS IN THE FIGHT | 0.7 | +5.6 | 114.0 | 34.4 | 0.4 | +0.9 | 61.9 | 35.5 |
| STABLE ROLE | 11.5 | +0.0 | 491.8 | 133.8 | 9.2 | +0.0 | 273.2 | 141.3 |
| STANDS TO CAST | 0.1 | +5.3 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +8.4 | 0.0 | 1.7 | - | - | - | - |
| STOPS | 0.0 | +0.2 | 10.2 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.6 | +38.4 | 0.0 | 27.1 | 0.4 | +16.1 | 0.0 | 27.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 4.8 | -42.8 | 283.5 | 90.9 | 5.3 | -40.5 | 252.8 | 63.3 |
| SUPPORTS | 3.3 | +45.0 | 140.1 | 43.0 | 3.8 | +43.2 | 108.1 | 46.8 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -5.3 | 30.2 | 0.0 | 0.2 | -3.2 | 13.7 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +4.2 | 7.0 | 7.8 | 0.4 | +7.5 | 0.0 | 13.9 |
| THROUGH LINE OF FIRE | 0.5 | +35.1 | 0.0 | 3.2 | 0.2 | +0.2 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -8.1 | 9.3 | 0.9 | 0.1 | -5.8 | 9.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +3.8 | 0.0 | 28.1 | 0.5 | +5.1 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.6 | -302.0 | 353.9 | 119.7 | 6.4 | -367.2 | 148.6 | 137.8 |
| WALKS TO THE FIGHT | 1.4 | +19.8 | 57.5 | 5.1 | 0.9 | +12.9 | 9.4 | 21.1 |
| WAR ENGINE CHARGES | 0.1 | +3.7 | 9.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 62.4 | 15.6 | 0.2 | +0.0 | 0.0 | 5.1 |
| WEARS DOWN | 1.2 | +41.8 | 166.8 | 59.2 | 1.1 | +48.6 | 137.6 | 29.8 |
| WHO HITS BACK | 0.2 | +25.4 | 0.0 | 0.0 | 0.2 | +17.5 | 0.0 | 10.2 |
| WHOLE FIGHT | 0.3 | +31.3 | 83.6 | 0.0 | 0.2 | +9.7 | 46.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +29.6 | 50.7 | 7.3 | 0.6 | +66.5 | 43.1 | 12.5 |
| WIDER SPREAD | 2.2 | -6.3 | 239.8 | 81.6 | 2.4 | -3.9 | 285.3 | 63.9 |

### Rule changes: dep-mine-13df7bd-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1098 | 1098 | 1098 | 30.50 | -56546 | -51.5 |
| BEST FIRST | 319 | 319 | 319 | 8.86 | +12175 | +38.2 |
| DEPLOY BY FIGURES | 283 | 283 | 184 | 5.11 | +2800 | +15.2 |
| SEARCH SPOT | 178 | 178 | 176 | 4.89 | +9014 | +51.2 |
| MOVE TO CHARGE | 244 | 244 | 144 | 4.00 | +6345 | +44.1 |
| PATHS CROSS | 144 | 144 | 144 | 4.00 | +10157 | +70.5 |
| COUNTER-CHARGE COVER | 567 | 309 | 134 | 3.72 | +9912 | +74.0 |
| FACES THE THREAT | 103 | 103 | 103 | 2.86 | +8546 | +83.0 |
| KILLS COUNT NEXT TURN | 386 | 386 | 103 | 2.86 | +2766 | +26.9 |
| SUPPORTS | 254 | 254 | 98 | 2.72 | +974 | +9.9 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| FALLBACK BY WORTH | 369 | 369 | 75 | 2.08 | +4395 | +58.6 |
| SAFER THAN THE JOB | 71 | 71 | 71 | 1.97 | +3875 | +54.6 |
| SHOTS IN THE MOVE | 840 | 545 | 66 | 1.83 | +1491 | +22.6 |
| ADVANCE LANE KEPT | 64 | 64 | 64 | 1.78 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 63 | 63 | 63 | 1.75 | +9273 | +147.2 |
| WAIT AFTER COSTS | 469 | 469 | 62 | 1.72 | +1233 | +19.9 |
| MAX FOR POSITIONING | 331 | 190 | 51 | 1.42 | +783 | +15.4 |
| CANNON SIGHT KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 49 | 49 | 49 | 1.36 | +3945 | +80.5 |
| SET UP TOGETHER | 96 | 86 | 46 | 1.28 | +3597 | +78.2 |
| SHOOTS FROM THE BEST SPOT | 79 | 79 | 44 | 1.22 | +1164 | +26.4 |
| RANDOM MOVE BY FIGURES | 87 | 87 | 41 | 1.14 | +1499 | +36.6 |
| BEST OVERALL | 40 | 40 | 40 | 1.11 | +1999 | +50.0 |
| REDIRECT COUNTER | 180 | 91 | 39 | 1.08 | +2423 | +62.1 |
| CANNON PLANNED TARGET | 257 | 257 | 37 | 1.03 | -27 | -0.7 |
| WALKS TO THE FIGHT | 82 | 82 | 37 | 1.03 | +322 | +8.7 |
| SHOT REPLANNED | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| BEST FACING | 35 | 35 | 35 | 0.97 | +1702 | +48.6 |
| MISSILES IN THE MOVE | 267 | 162 | 35 | 0.97 | +942 | +26.9 |
| RISK BY ARC | 151 | 146 | 35 | 0.97 | +1025 | +29.3 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1961 | +59.4 |
| KILLS COUNT | 109 | 106 | 32 | 0.89 | +1266 | +39.6 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.81 | +2080 | +71.7 |
| CHARGE NOW FIRST | 131 | 131 | 28 | 0.78 | -1950 | -69.6 |
| MARCH CHECK | 33 | 31 | 28 | 0.78 | +1280 | +45.7 |
| CAST JOB | 51 | 51 | 27 | 0.75 | +678 | +25.1 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1078 | +39.9 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +393 | +15.1 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +1269 | +48.8 |
| COMBAT PIVOT | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| LANE BY FIGURES | 24 | 24 | 24 | 0.67 | +962 | +40.1 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +1310 | +54.6 |
| RESERVE FALL BACK | 24 | 24 | 24 | 0.67 | +1017 | +42.4 |
| MAKE SURE TOGETHER | 48 | 37 | 21 | 0.58 | +1268 | +60.4 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +390 | +18.6 |
| INVITES THE FIGHT | 107 | 107 | 20 | 0.56 | +214 | +10.7 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +44 | +2.2 |
| WHOLE FIGHT GAIN | 40 | 36 | 20 | 0.56 | +1006 | +50.3 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -38 | -2.0 |
| WEARS DOWN | 82 | 81 | 19 | 0.53 | +673 | +35.4 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| HONEST WORTH | 509 | 506 | 18 | 0.50 | +136 | +7.6 |
| SCOUT WAITS | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -74 | -5.2 |
| MANOEUVRE | 19 | 19 | 14 | 0.39 | +430 | +30.7 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1066 | +76.1 |
| BEST PREY | 39 | 39 | 13 | 0.36 | +390 | +30.0 |
| SURE CHARGE BEATS ADVANCE | 13 | 13 | 13 | 0.36 | -308 | -23.7 |
| HOLDER AT DEPLOYMENT | 35 | 35 | 12 | 0.33 | +602 | +50.2 |
| WAR ENGINE JOBS | 29 | 29 | 12 | 0.33 | -440 | -36.6 |
| CASTING BLOCK | 16 | 16 | 11 | 0.31 | +614 | +55.8 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| KEEPS ITS TARGET | 96 | 96 | 11 | 0.31 | +187 | +17.0 |
| LOST CHARGE | 185 | 185 | 11 | 0.31 | +91 | +8.3 |
| MISSILES NEXT TURN | 312 | 179 | 10 | 0.28 | +89 | +8.9 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +511 | +56.7 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +848 | +94.2 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -272 | -38.8 |
| REFUSING RETIRES | 22 | 22 | 7 | 0.19 | -2 | -0.2 |
| WHOLE FIGHT | 20 | 20 | 7 | 0.19 | +639 | +91.3 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| EDGE GIVE GROUND | 10 | 10 | 5 | 0.14 | +365 | +73.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +161 | +32.3 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 5 | 0.14 | -299 | -59.8 |
| MOVES UNITS SPELL | 5 | 5 | 5 | 0.14 | +129 | +25.8 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +302 | +60.4 |
| BACKUP TARGETS | 71 | 32 | 4 | 0.11 | +3 | +0.7 |
| HUNT IN PAIRS | 28 | 16 | 4 | 0.11 | +266 | +66.5 |
| JOINT CHARGE PLAN | 8 | 8 | 4 | 0.11 | +529 | +132.2 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 29 | 27 | 4 | 0.11 | +179 | +44.7 |
| WIDER SPREAD | 165 | 156 | 4 | 0.11 | +20 | +5.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +18 | +5.9 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -268 | -89.4 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +128 | +42.6 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +31 | +10.5 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -138 | -69.2 |
| DEFENSIVE ARMY | 8 | 8 | 2 | 0.06 | -70 | -34.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 26 | 25 | 2 | 0.06 | +83 | +41.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +94 | +46.8 |
| OPENS UP | 4 | 4 | 2 | 0.06 | +82 | +40.9 |
| SURE REACH TOGETHER | 33 | 23 | 2 | 0.06 | +114 | +57.0 |
| TWO OR MORE ARRIVE | 34 | 32 | 2 | 0.06 | +7 | +3.3 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.06 | +90 | +44.8 |
| BLOWS WHERE AIMED | 24 | 23 | 1 | 0.03 | +10 | +9.7 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -3 | -2.8 |
| CHARGER SLAIN LOST | 33 | 31 | 1 | 0.03 | +36 | +36.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -90 | -90.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +98 | +98.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +11 | +11.1 |
| HILL BY ITS CHANCE | 30 | 30 | 1 | 0.03 | +5 | +4.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +9 | +9.1 |
| HUNT ADVANCE | 5 | 5 | 1 | 0.03 | +3 | +2.7 |
| MOVE SPELL IN RANGE | 9 | 6 | 1 | 0.03 | +16 | +16.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +122 | +121.5 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +14 | +13.6 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +70 | +69.5 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 1 | 0.03 | +34 | +33.5 |
| SPELLS IN THE FIGHT | 39 | 38 | 1 | 0.03 | +73 | +72.6 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 43 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 365 | not checked | - | - | - | - |
| GIVES UP | 10 | 10 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 376 | 376 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2603 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 24 | 24 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 31 | not checked | - | - | - | - |
| SPELL WORTH | 93 | not checked | - | - | - | - |
| STABLE ROLE | 745 | 743 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 363 | 363 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: dep-mine-13df7bd-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.69 | 12.39 | 53.8 |
| TURN GATE | gate | 0.67 | 0.78 | 29.9 |
| FALLBACK | gate | 0.50 | 0.86 | 28.1 |
| CHARGE NOW FIRST | rule | 0.31 | 0.47 | 69.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.17 | 25.6 |
| WAR ENGINE JOBS | rule | 0.19 | 0.11 | 39.9 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 53.8 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.14 | 11.7 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.14 | 51.3 |
| PATHS CROSS | rule | 0.06 | 0.17 | 15.8 |
| AFTERMATH BAND | gate | 0.08 | 0.11 | 2.8 |
| CHAFF PASSED | rule | 0.14 | 0.06 | 5.5 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 38.8 |
| CANNON PLANNED TARGET | rule | 0.08 | 0.06 | 90.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.08 | 137.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 74.7 |
| MARCH ODDS | rule | 0.06 | 0.06 | 18.8 |
| SAFER THAN THE JOB | rule | 0.06 | 0.06 | 10.9 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 12.4 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.06 | 38.9 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 89.4 |
| BEST PRIZE | rule | - | 0.06 | 69.2 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 19.7 |
| DEFENSIVE ARMY | rule | 0.06 | - | 34.9 |
| CATCH ODDS | rule | - | 0.03 | 2.8 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 90.4 |
| DEPLOY BY FIGURES | rule | 0.03 | - | 14.7 |
| FIGHT ORDER BAND | gate | 0.03 | - | 0.9 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 4.5 |
| LONG SHOT | rule | - | 0.03 | 1.5 |
| MOVE AND CAST | rule | 0.03 | - | 1.4 |
| REDIRECT WEIGHED | rule | - | 0.03 | 6.1 |
| STANDS TO CAST | rule | - | 0.03 | 5.1 |

### Plans: dep-mine-13df7bd-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 18% | 351 | 334 | 95% |
| Mine | charge | 2.7 | 58% | 225 | 290 | 129% |
| Mine | close in | 4.1 | 35% | 238 | 170 | 71% |
| Mine | hold | 5.3 | 51% | 315 | 0 | 0% |
| Mine | join | 0.4 | 77% | 22 | 0 | 0% |
| Mine | shoot | 8.9 | 61% | 375 | 633 | 169% |
| Mine | support | 3.5 | 89% | 28 | 0 | 0% |
| Opponent | advance | 12.9 | 13% | 385 | 357 | 93% |
| Opponent | charge | 3.1 | 52% | 285 | 331 | 116% |
| Opponent | close in | 5.2 | 25% | 405 | 144 | 36% |
| Opponent | hold | 3.5 | 37% | 215 | 0 | 0% |
| Opponent | join | 1.3 | 94% | 49 | 0 | 0% |
| Opponent | shoot | 4.9 | 56% | 124 | 375 | 302% |
| Opponent | support | 4.4 | 85% | 35 | 0 | 0% |

### Packages: hunt the guns, dep-mine-13df7bd-p6

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 0% | 33% | 0% | 2.0 | 193 | 30 | 33% | 41 |
| Opponent | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 349 | 0 | 0% | 57 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 245 | 0 | 0% | 124 |
| Chaos Dwarfs | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 132 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Tomb Kings of Khemri | 0.5 | 1 | 0 | 0% | 100% | 0% | 2.0 | 90 | 89 | 100% | 168 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 349 | 0 | 0% | 40 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |

### Battle groups: dep-mine-13df7bd-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.1 | 19% | 41% | 11% | 17% | 35% | 6% | 2% | 56% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 29% | 80% | 10% | 50% | 11% | 0% | 11% | 72% | 6% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 16% | 68% | 7% | 67% | 46% | 10% | 7% | 37% | 0% |
| Opponent | REDIRECT COUNTER | 3.1 | 20% | 68% | 5% | 0% | 10% | 0% | 5% | 86% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-mine-13df7bd-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 55 | 0% | 4.2 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |
| Mine | Chaff | 33 | 78 (33) | 16 | 62 | 50 | 33% | 2.6 | 32 (15) | 117 (14) | 100 (4) | 79 (27) | 72 (6) |
| Mine | Character | 120 | 44 (120) | 44 | 0 | 34 | 26% | 2.4 | 42 (45) | 52 (45) | 39 (19) | 52 (66) | 35 (43) |
| Mine | Clean-up | 28 | 80 (28) | 29 | 51 | 14 | 50% | 3.4 | 28 (12) | 132 (12) | 159 (4) | 80 (22) | 78 (6) |
| Mine | Fast | 1 | 180 (1) | 180 | 0 | 0 | 0% | 2.0 | - | 180 (1) | - | - | 180 (1) |
| Mine | Fast Hammer | 40 | 42 (40) | 30 | 12 | 50 | 18% | 2.7 | 66 (19) | 23 (16) | 28 (5) | 47 (25) | 34 (15) |
| Mine | Fragile | 6 | 0 (6) | 0 | 0 | 82 | 33% | 2.2 | 0 (4) | 0 (2) | - | 0 (2) | 0 (4) |
| Mine | Hammer | 53 | 41 (53) | 29 | 13 | 32 | 25% | 2.5 | 35 (16) | 41 (25) | 52 (12) | 51 (34) | 27 (19) |
| Mine | Holder | 25 | 106 (25) | 10 | 96 | 4 | 44% | 3.4 | 110 (10) | 111 (14) | 0 (1) | 128 (19) | 46 (6) |
| Mine | Shooter | 40 | 96 (40) | 30 | 66 | 35 | 2% | 2.1 | 22 (13) | 168 (21) | 20 (6) | 127 (25) | 56 (15) |
| Mine | War machine | 56 | 30 (56) | 30 | 0 | 13 | 5% | 1.2 | 19 (30) | 63 (12) | 27 (14) | 6 (12) | 36 (44) |
| Mine | Wizard | 16 | 19 (16) | 19 | 0 | 25 | 19% | 2.2 | 13 (6) | 31 (7) | 0 (1) | 31 (9) | 0 (5) |
| Opponent | Chaff | 60 | 45 (60) | 12 | 33 | 55 | 43% | 3.1 | 36 (22) | 69 (11) | 36 (27) | 61 (41) | 3 (19) |
| Opponent | Character | 102 | 38 (102) | 38 | 0 | 29 | 30% | 2.4 | 55 (47) | 22 (41) | 7 (5) | 41 (59) | 38 (34) |
| Opponent | Clean-up | 28 | 46 (28) | 18 | 28 | 45 | 50% | 3.1 | 87 (6) | 40 (18) | 31 (4) | 43 (19) | 50 (9) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 50 | 38 (50) | 26 | 12 | 43 | 38% | 2.9 | 26 (24) | 41 (17) | 75 (9) | 20 (33) | 82 (17) |
| Opponent | Fragile | 9 | 26 (9) | 26 | 0 | 89 | 22% | 1.3 | 232 (1) | 0 (5) | 0 (3) | 0 (7) | 116 (2) |
| Opponent | Hammer | 56 | 42 (56) | 32 | 10 | 36 | 25% | 2.7 | 16 (16) | 61 (33) | 9 (7) | 33 (26) | 50 (30) |
| Opponent | Holder | 31 | 72 (31) | 9 | 63 | 31 | 42% | 3.6 | 103 (5) | 73 (19) | 55 (6) | 86 (18) | 56 (12) |
| Opponent | Shooter | 23 | 43 (23) | 24 | 19 | 35 | 4% | 1.3 | 38 (5) | 46 (17) | 0 (1) | 45 (10) | 42 (13) |
| Opponent | Support | 4 | 19 (4) | 19 | 0 | 73 | 25% | 2.0 | - | 0 (1) | 26 (3) | 0 (1) | 26 (3) |
| Opponent | War machine | 17 | 67 (17) | 67 | 0 | 13 | 6% | 1.4 | 80 (9) | 52 (7) | 62 (1) | 113 (3) | 59 (14) |
| Opponent | Wizard | 24 | 0 (24) | 0 | 0 | 57 | 12% | 2.0 | 0 (5) | 0 (8) | 0 (5) | 0 (5) | 0 (13) |

### Charged fights: dep-mine-13df7bd-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 109 | 325 | 2.0 | 1.1 | 162 | 13 | +150 | 3 of 8 | 6 of 8 | +60 | +162 |
| Mine | Chaos Dwarfs | 4 | 160 | 540 | 3.2 | 1.2 | 166 | 26 | +140 | 8 of 13 | 10 of 13 | +402 | +92 |
| Mine | Dwarfen Mountain Holds | 4 | 428 | 74 | 1.0 | 1.8 | 74 | 72 | +1 | 0 of 4 | 2 of 4 | -112 | +114 |
| Mine | Empire of Man | 4 | 709 | 32 | 1.0 | 1.0 | 32 | 0 | +32 | 0 of 4 | 2 of 4 | - | +32 |
| Mine | Grand Cathay | 5 | 426 | 488 | 3.4 | 1.1 | 144 | 26 | +118 | 11 of 17 | 11 of 17 | +0 | +126 |
| Mine | High Elf Realms | 4 | 194 | 587 | 3.2 | 1.4 | 181 | 9 | +172 | 3 of 13 | 11 of 13 | +391 | +106 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 456 | 2.0 | 1.0 | 228 | 236 | -8 | 0 of 2 | 2 of 2 | - | -8 |
| Mine | Lizardmen | 1 | 465 | 122 | 1.0 | 1.0 | 122 | 0 | +122 | 0 of 1 | 1 of 1 | - | +122 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 194 | -194 | 1 of 2 | 0 of 2 | - | -194 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 237 | 7.0 | 1.1 | 34 | 0 | +34 | 2 of 7 | 4 of 7 | +85 | +25 |
| Mine | Skaven | 2 | 0 | 94 | 2.0 | 1.0 | 47 | 52 | -6 | 1 of 4 | 3 of 4 | - | -6 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 1082 | 7.0 | 1.1 | 155 | 0 | +155 | 2 of 7 | 6 of 7 | +0 | +180 |
| Mine | Vampire Counts | 2 | 178 | 370 | 4.0 | 1.6 | 92 | 5 | +88 | 4 of 8 | 6 of 8 | +136 | +39 |
| Mine | Warriors of Chaos | 2 | 142 | 0 | 1.5 | 1.0 | 0 | 0 | +0 | 1 of 3 | 2 of 3 | - | +0 |
| **Mine** | all armies | 36 | 268 | 319 | 2.6 | 1.2 | 124 | 26 | +98 | 36 of 93 | 66 of 93 | +163 | +85 |
| Opponent | Empire of Man | 3 | 326 | 125 | 1.0 | 1.3 | 125 | 88 | +37 | 2 of 3 | 2 of 3 | +65 | +22 |
| Opponent | Grand Cathay | 2 | 184 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 3 | 193 | 446 | 2.0 | 1.3 | 223 | 24 | +199 | 5 of 6 | 5 of 6 | +69 | +264 |
| Opponent | Lizardmen | 1 | 60 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Skaven | 3 | 50 | 312 | 0.7 | 1.5 | 468 | 0 | +468 | 2 of 2 | 1 of 2 | +937 | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 189 | 1.0 | 1.0 | 189 | 0 | +189 | 1 of 1 | 1 of 1 | - | +189 |
| Opponent | Vampire Counts | 6 | 0 | 300 | 3.2 | 1.1 | 95 | 69 | +26 | 7 of 19 | 12 of 19 | -385 | +48 |
| Opponent | Warriors of Chaos | 12 | 8 | 466 | 2.8 | 1.3 | 165 | 17 | +148 | 18 of 34 | 25 of 34 | +238 | +115 |
| Opponent | Wood Elf Realms | 4 | 302 | 480 | 4.0 | 1.2 | 120 | 28 | +92 | 6 of 16 | 10 of 16 | +208 | +76 |
| **Opponent** | all armies | 36 | 97 | 338 | 2.3 | 1.2 | 145 | 33 | +112 | 42 of 84 | 58 of 84 | +207 | +90 |

### Effective charges: dep-mine-13df7bd-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 2 (net +62) | 0 | 2 (net +0) | 1 (net +60) | 0 | 1 (net +0) | 2 | 33% (2 of 6) |
| Mine | Chaos Dwarfs | 13 | 2 (net +184) | 0 | 2 (net +327) | 2 (net -74) | 3 (net +88) | 3 (net +150) | 1 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 2 (net +114) | 0 | 1 (net -225) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +60) | 1 (net +66) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 17 | 3 (net +167) | 0 | 3 (net +186) | 5 (net +57) | 1 (net +0) | 3 (net +172) | 2 | 20% (3 of 15) |
| Mine | High Elf Realms | 13 | 0 | 0 | 2 (net +403) | 3 (net -17) | 3 (net +216) | 4 (net +135) | 1 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +116) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Lizardmen | 1 | 0 | 0 | 0 | 0 | 1 (net +122) | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +122) | 2 (net +58) | 0 | 0 | 4 | 33% (1 of 3) |
| Mine | Skaven | 4 | 0 | 0 | 1 (net -210) | 0 | 0 | 3 (net +62) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +666) | 0 | 1 (net +0) | 1 (net +85) | 2 (net +22) | 2 (net +143) | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 8 | 4 (net +146) | 0 | 2 (net +58) | 2 (net +0) | 0 | 0 | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 3 | 2 (net +22) | 0 | 0 | 0 | 1 (net +65) | 0 | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 6 | 2 (net +146) | 0 | 3 (net +256) | 0 | 0 | 1 (net +138) | 0 | 50% (3 of 6) |
| Opponent | Lizardmen | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 1 (net +0) | 1 (net +937) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 0 | 0 | 1 (net +189) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 19 | 3 (net +189) | 3 (net -23) | 4 (net +24) | 5 (net +57) | 3 (net +0) | 1 (net -393) | 0 | 21% (4 of 19) |
| Opponent | Warriors of Chaos | 34 | 6 (net +193) | 1 (net +0) | 5 (net +240) | 8 (net +204) | 5 (net +104) | 6 (net +133) | 3 | 16% (5 of 31) |
| Opponent | Wood Elf Realms | 16 | 1 (net +0) | 1 (net +811) | 7 (net -8) | 0 | 3 (net +208) | 3 (net +33) | 1 | 47% (7 of 15) |

### Charged fights, damage counted: dep-mine-13df7bd-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 259 | 301 | +173 | 184 | 24 | +159 | +61.7 |
| Mine | Effective (55-75%) | 16 | 384 | 254 | +128 | 182 | 82 | +101 | +26.2 |
| Mine | 76-89% | 19 | 198 | 168 | +36 | 73 | 38 | +35 | +17.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 255 | 166 | +87 | 120 | 15 | +105 | +41.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 432 | 102 | +104 | 143 | 39 | +104 | +24.1 |
| Mine | No odds | 13 | 309 | 271 | +90 | 166 | 95 | +71 | +23.0 |
| Mine | All fights | 93 | 294 | 208 | +98 | 139 | 46 | +93 | +31.5 |
| Opponent | Long shot (under 50%) | 14 | 212 | 338 | +147 | 193 | 54 | +139 | +65.8 |
| Opponent | 50-54% | 5 | 351 | 231 | +149 | 340 | 79 | +261 | +74.5 |
| Opponent | Effective (55-75%) | 21 | 279 | 265 | +96 | 143 | 60 | +84 | +30.0 |
| Opponent | 76-89% | 16 | 356 | 213 | +190 | 221 | 29 | +192 | +53.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 326 | 279 | +54 | 143 | 66 | +77 | +23.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 507 | 108 | +100 | 129 | 17 | +112 | +22.0 |
| Opponent | No odds | 4 | 111 | 216 | -72 | 115 | 72 | +43 | +38.2 |
| Opponent | All fights | 84 | 318 | 242 | +112 | 175 | 49 | +125 | +39.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-mine-13df7bd-p6 | move | 403 | 74 (18%) | 56 (14%) | 40 (10%) | 289 (72%) |
| dep-mine-13df7bd-p6 | objective | 334 | 45 (13%) | 33 (10%) | 38 (11%) | 251 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0124, L2431, L2628 |
| Charmed Shield | Opponent | L0124, L0224, L0325, L0427, L1325, L2134, L2325 |
| Clockwork Compass | Mine | L1214, L1230 |
| Elixir of Power | Mine | L1120, L1929 |
| Elixir of Power | Opponent | L0411, L1011 |
| Fistful of Laurels | Mine | L1829 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Mine | L2431 |
| Invocation of Nehek | Opponent | L0124, L0224, L0325, L0427, L1325, L2325 |
| Opal Amulet | Mine | L1420 |
| Opal Amulet | Opponent | L0514, L1214 |
| Periapt of Soul Exchange | Mine | L2031, L2134 |
| Periapt of Soul Exchange | Opponent | L0920, L1120, L1420 |
| Ring of Doom | Mine | L0208, L0224, L1120, L1214, L1230, L1517, L1533 |
| Ring of Doom | Opponent | L0411, L1011, L1533, L1631, L2031, L2431 |
| Ring of Jet | Mine | L1011, L1028, L1120, L1214, L1230 |
| Ring of Jet | Opponent | L0411, L1011 |
| Standard of the Fell Warrior | Mine | L1325 |
| Standard of the Fell Warrior | Opponent | L0813 |
| Storm Daemon (Renegade 2.0) | Mine | L2134 |
| Twice-Blessed Armour | Mine | L0723, L1011, L1028 |
| Witch Hunter's Ward | Mine | L0723, L0813, L0829 |
| Witch Hunter's Ward | Opponent | L0108, L0208 |

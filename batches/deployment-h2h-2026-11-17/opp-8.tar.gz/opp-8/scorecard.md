# Doctrine scorecard: dep-opp-13df7bd-p8

### Scorecard: dep-opp-13df7bd-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0116 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 322 |
| L0116 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 200 |
| L0132 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 382 |
| L0132 | 6 | 1 | Opponent | no | 14 | 2 | 6 | 2 | 1 | 0 | 0 | 477 |
| L0216 | 6 | 1 | Mine | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 255 |
| L0216 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L0233 | 5 | 1 | Mine | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 200 |
| L0233 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0317 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 1 | 0 | 0 | 675 |
| L0317 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0334 | 4 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 163 |
| L0419 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0419 | 5 | 1 | Opponent | yes | - | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L0506 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0506 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 1 | 0 | 0 | 743 |
| L0522 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 986 |
| L0522 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 72 |
| L0610 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 615 |
| L0610 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 492 |
| L0626 | 2 | 1 | Mine | - | - | 6 | 0 | 0 | 0 | 0 | 0 | 801 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0715 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 115 |
| L0731 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0731 | 5 | 1 | Opponent | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0821 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0821 | 5 | 1 | Opponent | yes | - | - | 1 | 7 | 1 | 0 | 0 | 290 |
| L0911 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 713 |
| L0911 | 5 | 1 | Opponent | yes | - | 5 | 0 | 1 | 1 | 0 | 0 | 330 |
| L0928 | 4 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 602 |
| L0928 | 4 | 1 | Opponent | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1019 | 5 | 1 | Mine | yes | - | 2 | 8 | 0 | 0 | 0 | 0 | 465 |
| L1019 | 5 | 1 | Opponent | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 255 |
| L1112 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1112 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 330 |
| L1128 | 6 | 1 | Mine | no | 4 | 3 | 0 | 0 | 0 | 0 | 0 | 427 |
| L1128 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1222 | 4 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1222 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 55 |
| L1317 | 3 | 1 | Mine | yes | 5 | 3 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1317 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 3 | 0 | 0 | 0 |
| L1333 | 1 | 1 | Mine | no | 7 | 4 | 1 | 1 | 1 | 0 | 0 | 140 |
| L1333 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 104 |
| L1429 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 123 |
| L1429 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1525 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Opponent | no | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 68 |
| L1623 | 3 | 1 | Mine | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 414 |
| L1623 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1721 | 5 | 1 | Mine | yes | - | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1721 | 5 | 1 | Opponent | yes | - | - | 1 | 3 | 0 | 0 | 0 | 500 |
| L1821 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1821 | 3 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 1 | 0 | 0 | 500 |
| L1921 | 1 | 1 | Mine | no | 4 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1921 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 157 |
| L2023 | 1 | 1 | Mine | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 210 |
| L2023 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 60 |
| L2125 | 1 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L2125 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2229 | 3 | 1 | Mine | no | 4 | 2 | 2 | 1 | 2 | 0 | 0 | 170 |
| L2229 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2333 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2333 | 5 | 1 | Opponent | no | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2529 | 3 | 1 | Mine | no | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2529 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2728 | 4 | 1 | Mine | yes | 0 | 2 | 2 | 5 | 1 | 0 | 0 | 0 |
| L2728 | 4 | 1 | Opponent | no | 3 | 6 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2932 | 4 | 1 | Mine | no | 2 | 3 | 1 | 0 | 1 | 0 | 0 | 170 |
| L2932 | 4 | 1 | Opponent | no | 11 | 1 | 3 | 1 | 1 | 0 | 0 | 170 |
| L3334 | 4 | 1 | Mine | no | 4 | 2 | 1 | 3 | 0 | 0 | 0 | 208 |
| L3334 | 4 | 1 | Opponent | no | 2 | 3 | 0 | 3 | 0 | 0 | 0 | 713 |
| **Average** | | | Mine | 34% | 2.6 | 2.5 | 2.0 | 1.2 | 0.3 | 0.0 | 0.0 | 329.2 |
| **Average** | | | Opponent | 25% | 3.2 | 2.5 | 2.1 | 1.9 | 0.4 | 0.0 | 0.0 | 175.9 |

### KPIs: dep-opp-13df7bd-p8

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (47 of 176) | 3% (5 of 174) | 15% (52 of 350) |
| Winner chose to follow up after the loser gave ground |  | 98% (44 of 45); on the table 98% | 96% (44 of 46); on the table 98% | 97% (88 of 91); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (13 of 14); on the table 93% | 100% (9 of 9); on the table 100% | 96% (22 of 23); on the table 96% |
| Winner chose to pursue after the loser fled |  | 70% (14 of 20); on the table 75% | 67% (18 of 27); on the table 74% | 68% (32 of 47); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 90% (71 of 79); on the table 91% | 87% (71 of 82); on the table 90% | 88% (142 of 161); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 25% (76 of 299) | 37% (60 of 163) | 29% (136 of 462) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (76 of 214) | 50% (60 of 121) | 41% (136 of 335) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (13 of 23) | 57% (50 of 88) | 57% (63 of 111) |
| Points that never fought | lower | 41% (27981 of 69031) | 42% (30380 of 71983) | 41% (58361 of 141014) |
|   infantry points that never fought | lower | 51% (7849 of 15539) | 66% (9450 of 14377) | 58% (17299 of 29916) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (166 of 273) | 59% (161 of 275) | 60% (327 of 548) |
| Bound items with a magic missile used (at least once a game) |  | 87% (20 of 23); 1.9 uses a game | 90% (18 of 20); 1.5 uses a game | 88% (38 of 43); 1.7 uses a game |
| Bound items with another spell used |  | 67% (10 of 15); 0.4 uses a game | 100% (1 of 1); 0.0 uses a game | 69% (11 of 16); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 38% (6 of 16); 0.2 uses a game | 42% (15 of 36); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31913 of 57598) | 55% (34530 of 63116) | 55% (66443 of 120714) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (26%) | 0.6 (20%) | 2.2 (24%) |
| MARCHED: its unit marched | 1.2 (19%) | 0.8 (26%) | 1.9 (21%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.3 (10%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 0.7 (12%) | 0.6 (19%) | 1.3 (14%) |
| REAR RANK: in a rear rank | 0.6 (10%) | 0.0 (0%) | 0.6 (7%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| GONE: slain | 1.2 (19%) | 0.4 (14%) | 1.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (4%) | 0.4 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.2 | 1.4 | 3.8 | 0.5 | 1.5 |
| not cast | 5.2 | 2.3 | 3.6 | 9.1 | 2.0 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.9 (39%) | 0.3 (8%) | 2.2 (24%) | 0.3 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (21%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (10%) | 0.4 (12%) | 1.3 (14%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (7%) | 0.2 (7%) | 0.8 (22%) | 0.6 (7%) | 0.2 (8%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 1.5 (29%) | 0.5 (21%) | 0.6 (16%) | 1.6 (17%) | 0.4 (19%) | 2.6 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (8%) | 0.0 (1%) | 0.1 (3%) | 0.4 (5%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (4%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.4 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (45%) | 0.1 (4%) | 1.3 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 69% (18 of 26) | 53% (8 of 15) | 63% (26 of 41) |
| the unit moved after it | 78% (14 of 18) | 100% (8 of 8) | 85% (22 of 26) |
| it charged on its next turn | 11% (2 of 18) | 25% (2 of 8) | 15% (4 of 26) |
| the enemy charged it first | 11% (2 of 18) | 0% (0 of 8) | 8% (2 of 26) |
| it fought by the end of its next turn | 6% (1 of 18) | 0% (0 of 8) | 4% (1 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 18) | 25% (2 of 8) | 8% (2 of 26) |
| none of these (no charge, no fight, no charge escaped) | 78% (14 of 18) | 75% (6 of 8) | 77% (20 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (571 of 891) | 58% (379 of 656) | 61% (950 of 1547) |
|   cavalry | 55% (48 of 88) | 60% (78 of 129) | 58% (126 of 217) |
|   character | 55% (49 of 89) | 17% (16 of 94) | 36% (65 of 183) |
|   chariot | 49% (45 of 91) | 80% (37 of 46) | 60% (82 of 137) |
|   infantry | 60% (175 of 290) | 64% (188 of 293) | 62% (363 of 583) |
|   monster | 50% (22 of 44) | 32% (7 of 22) | 44% (29 of 66) |
|   war machine | 80% (232 of 289) | 74% (53 of 72) | 79% (285 of 361) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 1.7 (22%) | 4.1 (25%) |
| CHARGED: it charged | 0.7 (8%) | 1.4 (18%) | 2.1 (13%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.3 (4%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 2.0 (22%) | 2.2 (29%) | 4.2 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.4 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.4 (18%) | 2.8 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.0 | 82% | 3.4 pts | 16 pts |
| character | 2.3 | 0.6 | 78% | 5.9 pts | 14 pts |
| chariot | 2.3 | 0.8 | 80% | 9.6 pts | 22 pts |
| infantry | 15.5 | 6.0 | 73% | 9.7 pts | 151 pts |
| monster | 1.0 | 0.2 | 83% | 5.5 pts | 5 pts |
| war machine | 7.9 | 6.9 | 62% | 24.8 pts | 197 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.0 | 4.4 |
| Charges that made contact a game | 2.5 | 3.1 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.47 contact (17 units) | 0.73 declared, 0.55 contact (11 units) | 0.71 declared, 0.50 contact (28 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.14 contact (7 units) | 1.38 declared, 1.12 contact (8 units) | 1.00 declared, 0.67 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.35 contact (236 units) | 0.59 declared, 0.36 contact (271 units) | 0.55 declared, 0.36 contact (507 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (28 of 53) | 52% (11 of 21) | 58% (7 of 12) | 53% (46 of 86) |
| Character in a unit | 88% (35 of 40) | 60% (9 of 15) | 50% (2 of 4) | 78% (46 of 59) |
| Character on its own | 91% (32 of 35) | 64% (23 of 36) | 38% (28 of 73) | 58% (83 of 144) |
| Chariot | 53% (10 of 19) | 67% (6 of 9) | - | 57% (16 of 28) |
| Infantry | 60% (44 of 73) | 55% (23 of 42) | 100% (2 of 2) | 59% (69 of 117) |
| Monster | 51% (19 of 37) | 50% (4 of 8) | - | 51% (23 of 45) |
| Monstrous | 60% (6 of 10) | 64% (7 of 11) | - | 62% (13 of 21) |
| War Machines | 65% (30 of 46) | 50% (1 of 2) | - | 65% (31 of 48) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 11% (11 of 102) | 35% | 77% (17 of 22) | 83% (5 of 6); 3.0 uses a game | 50% (1 of 2); 0.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 3 | 100% (6 of 6); on the table 100% | 53% (16 of 30) | 36% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 67% (2 of 3); on the table 67% | - | 42% | 75% (30 of 40) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 50% (3 of 6); on the table 50% | 12% (3 of 24) | 68% | 67% (36 of 54) | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 7 | 67% (6 of 9); on the table 67% | 30% (45 of 150) | 51% | 57% (33 of 58) | 81% (13 of 16); 4.4 uses a game | 100% (2 of 2); 0.3 uses a game | 29% (2 of 7); 0.3 uses a game |
| High Elf Realms | 5 | 79% (15 of 19); on the table 89% | 33% (4 of 12) | 29% | 38% (15 of 39) | 100% (6 of 6); 6.0 uses a game | 60% (6 of 10); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (12 of 12); on the table 100% | - | 43% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 3 | 80% (4 of 5); on the table 80% | - | 62% | 76% (16 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | - | 29% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 17% (3 of 18) | 11% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 89% (8 of 9); on the table 89% | 33% (18 of 54) | 57% | 67% (35 of 52) | 100% (5 of 5); 1.8 uses a game | 0.0 uses a game | 33% (2 of 6); 0.3 uses a game |
| Tomb Kings of Khemri | 6 | 88% (14 of 16); on the table 94% | - | 43% | 40% (12 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 83% (10 of 12); on the table 92% | 47% (17 of 36) | 27% | 62% (18 of 29) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 97% (33 of 34); on the table 97% | 50% (12 of 24) | 29% | 46% (35 of 76) | 100% (1 of 1); 0.6 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 6 | 83% (5 of 6); on the table 83% | 58% (7 of 12) | 47% | 69% (37 of 54) | 88% (7 of 8); 4.7 uses a game | 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p8, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (31) | 38% (23) | 43% (54) |
| ...free all their last turn and able to turn (per game) | 0.44 | 0.42 | 0.86 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.28 | 0.39 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.44 | 3.42 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.61 | 0.75 | 1.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.28 | 5.69 | 10.97 |

### Quality by phase: dep-opp-13df7bd-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.9 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 50% (60 of 120) | 35% (54 of 156) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (188 of 401) | 55% (114 of 209) |
| Strategy | Close-in objectives charged next turn | 12% (21 of 176) | 18% (32 of 181) |
| Strategy | Support requests answered (helper made contact too) | 50% (8 of 16) | 29% (10 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (4 of 8) | 64% (9 of 14) |
| Strategy | Joined characters whose unit fought | 51% (26 of 51) | 40% (14 of 35) |
| Strategy | Lone characters that fought | 70% (62 of 89) | 70% (61 of 87) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 329.2 | 175.9 |
| Movement | Fights charged into per game | 2.2 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 69, net +62 | 18 of 78, net +40 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 69, net +137 | 20 of 78, net +110 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 69, net +78 | 3 of 78, net +5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 69, net +148 | 20 of 78, net +201 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (168 of 366) | 39% (149 of 382) |
| Shooting | Points destroyed by shooting units | 60.1 | 52.9 |
| Shooting | War machine shots | 6.4 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (87 of 232) | 19% (10 of 54) |
| Shooting | Points destroyed by war machines | 116.1 | 11.4 |
| Magic | Magic missiles cast | 1.3 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (20 of 46) | 28% (11 of 39) |
| Magic | Wounds caused by magic missiles | 2.1 | 2.2 |
| Magic | Wounds caused by other spells | 1.1 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 47.5 | 28.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.3 / 0.3 / 0.0 | 1.6 / 0.4 / 0.7 / 0.2 |
| Combat | Points destroyed in combat | 301.8 | 395.2 |
| Combat | Points run down | 79.1 | 90.6 |
| Combat | Net points per charged fight, damage counted | +67 | +93 |
| Combat | Net per 100 charger points, damage counted | +26.3 | +33.2 |
| Combat | First round won (charged fights) | 69% | 67% |
| Combat | Net points per charged fight | +86 | +93 |
| Combat | Net points per supported fight / lone fight | +95 / +84 | +158 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 78 | 49 of 96 |
| Game | Points lost | 720.4 | 706.2 |
| Game | VP from objectives | 571.9 | 645.8 |
| Game | Lone holders (player turns) | 2.6 | 3.2 |

- Mine won / drew / lost: 11 / 9 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -80 VP
- The side that went first won 10 of 27 games with a winner
- Points traded per game (both sides' losses): 1427
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: dep-opp-13df7bd-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 39.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +6.4 | 0.0 | 33.4 | 0.8 | +7.1 | 0.0 | 8.5 |
| BEST FACING | 1.0 | +69.3 | 0.0 | 44.1 | 0.6 | +28.9 | 0.0 | 5.9 |
| BEST FIRST | 5.1 | +185.5 | 181.1 | 93.0 | 4.7 | +181.6 | 138.8 | 116.9 |
| BEST OVERALL | 0.5 | +59.1 | 0.0 | 33.0 | 0.5 | +35.1 | 0.0 | 48.8 |
| BEST PREY | 1.0 | +62.7 | 40.7 | 12.2 | 0.9 | +30.4 | 36.4 | 17.3 |
| BEST PRIZE | 0.1 | +1.4 | 5.8 | 0.0 | 0.2 | -3.0 | 6.9 | 5.4 |
| BIG CHARACTER SAFETY | 0.2 | -1.9 | 0.0 | 11.1 | 0.3 | +1.1 | 0.0 | 11.2 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 1.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | -1.0 | 0.0 | 0.0 | 0.6 | +6.6 | 0.0 | 7.1 |
| BLOWS WHERE AIMED | 0.2 | -23.6 | 17.2 | 3.2 | 0.4 | -76.3 | 69.7 | 13.1 |
| BOMBING RUN | 0.1 | +1.2 | 1.1 | 4.2 | 0.0 | +1.6 | 3.6 | 2.9 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 56.8 | 6.9 | 0.1 | +0.0 | 4.0 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +157.8 | 292.1 | 105.0 | 1.0 | +33.5 | 21.0 | 24.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.7 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 12.0 | 0.0 | 0.0 | +0.0 | 10.6 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.4 | 25.9 | 4.2 | 0.3 | -1.5 | 45.1 | 12.0 |
| CAST JOB | 1.0 | +24.4 | 56.1 | 19.7 | 0.3 | +6.5 | 11.8 | 21.3 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +14.9 | 2.9 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 27.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.0 | 0.0 | 6.1 | 0.0 | +0.4 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -1.4 | 8.7 | 6.5 | 0.1 | -0.1 | 0.0 | 4.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 173.5 | 42.0 | 2.3 | +0.0 | 248.7 | 27.8 |
| CHARGE NOW WEIGHED | 0.6 | -51.1 | 15.2 | 6.3 | 0.6 | -58.5 | 9.2 | 14.8 |
| CHARGER SLAIN LOST | 0.4 | -6.1 | 32.2 | 15.8 | 0.7 | -9.7 | 34.2 | 6.0 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.7 | 0.0 | 22.2 | 0.1 | -1.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 5.4 | 0.2 | +0.0 | 8.4 | 9.7 |
| COMBAT PIVOT | 0.5 | +0.0 | 15.9 | 43.0 | 0.3 | +0.0 | 14.2 | 23.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.4 | +98.3 | 0.0 | 13.5 | 0.3 | +5.0 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 9.2 | +687.7 | 0.0 | 180.8 | 7.5 | +644.9 | 0.0 | 198.1 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 21.0 | 2.1 | 0.1 | +0.0 | 0.0 | 3.3 |
| DEFENSIVE FLOOR | 0.1 | +3.3 | 13.7 | 1.5 | - | - | - | - |
| DEPLOY BY FIGURES | - | - | - | - | 7.6 | +68.6 | 0.0 | 25.6 |
| EDGE GIVE GROUND | 0.3 | +29.0 | 20.6 | 4.2 | 0.1 | +1.5 | 14.3 | 0.0 |
| ELIXIR WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +177.3 | 0.0 | 66.6 | 1.4 | +103.4 | 0.0 | 34.4 |
| FALLBACK BY WORTH | 5.9 | +55.7 | 0.0 | 70.3 | 5.5 | +59.3 | 0.0 | 96.1 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 6.5 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 148.3 | 5.4 | +0.0 | 0.0 | 135.4 |
| FOLLOW UP WEIGHED | 0.8 | +106.1 | 0.0 | 39.0 | 0.8 | +133.7 | 0.0 | 17.7 |
| FRIENDS SHOTS CHECKED | 0.1 | +9.7 | 0.0 | 8.4 | 0.2 | +15.4 | 0.0 | 5.4 |
| GIVES UP | 0.1 | -1.2 | 18.3 | 0.0 | 0.1 | -1.4 | 12.6 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -1.2 | 0.8 | 0.0 | 0.0 | -0.0 | 0.0 | 0.8 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 10.4 | 0.0 | 0.1 | +0.0 | 3.1 | 7.5 |
| HELPER UNSEEN | 0.2 | +0.0 | 23.5 | 1.7 | 0.5 | +0.0 | 37.5 | 15.2 |
| HILL BY ITS CHANCE | 0.1 | -6.3 | 0.0 | 6.5 | 0.2 | -27.7 | 0.0 | 0.0 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +165.8 | 0.0 | 3.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -135.0 | 386.2 | 119.1 | 7.4 | -191.5 | 537.2 | 124.4 |
| HORN WORTH | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 14.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 4.6 | 0.8 |
| HUNT IN PAIRS | 0.3 | +17.2 | 0.0 | 0.0 | 0.9 | +59.0 | 0.0 | 11.2 |
| HUNT KEPT | - | - | - | - | 0.1 | +3.2 | 6.1 | 0.0 |
| HUNT RESULT | 0.1 | +5.1 | 0.0 | 1.4 | 0.2 | +23.4 | 4.6 | 1.5 |
| HUNT THE GUNS | 0.1 | +15.4 | 2.8 | 0.0 | 0.2 | +78.3 | 10.3 | 0.8 |
| INVITES THE FIGHT | 1.0 | +21.7 | 44.3 | 8.6 | 1.2 | +20.8 | 53.4 | 24.5 |
| JOINT CHARGE PLAN | 0.2 | +2.0 | 19.8 | 0.0 | 0.2 | +4.3 | 43.0 | 5.4 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.7 | 9.1 | 0.0 | 0.1 | -3.9 | 21.4 | 0.0 |
| KEEP FALLS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.7 | 4.5 | 5.8 |
| KEEPS ITS TARGET | 2.1 | +61.7 | 165.0 | 35.6 | 1.6 | +49.2 | 187.6 | 14.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.4 | +62.1 | 85.6 | 31.2 | 1.8 | +107.7 | 177.7 | 4.7 |
| KILLS COUNT NEXT TURN | 5.7 | +178.0 | 202.1 | 88.8 | 4.9 | +162.7 | 267.6 | 96.6 |
| LANE BY FIGURES | - | - | - | - | 1.0 | +41.3 | 0.0 | 16.6 |
| LONE CHARACTER SAFE SPOT | 0.4 | +36.8 | 0.0 | 11.7 | 0.3 | +17.0 | 7.6 | 21.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 11.1 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +43.0 | 0.0 | 0.0 | 0.4 | +30.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -6.1 | 36.6 | 13.2 | 0.3 | +0.3 | 6.7 | 4.1 |
| LOST CHARGE | 2.3 | -36.0 | 97.8 | 63.0 | 1.9 | -30.2 | 77.3 | 45.3 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.5 | 0.0 | 0.0 | 0.1 | -9.8 | 0.0 | 0.5 |
| MAKE SURE TOGETHER | 0.8 | +69.8 | 6.6 | 8.8 | 0.9 | +38.9 | 104.4 | 15.4 |
| MANOEUVRE | 0.1 | +5.7 | 0.0 | 0.0 | 0.2 | +6.0 | 0.0 | 10.7 |
| MARCH AT ESCAPER | 0.1 | +2.4 | 0.0 | 15.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +30.5 | 0.0 | 0.0 | 0.6 | +22.6 | 0.0 | 26.6 |
| MARCH ODDS | 0.3 | +25.4 | 2.7 | 17.2 | 0.5 | +28.5 | 15.5 | 15.0 |
| MARCH OVER CASTS | 0.5 | +28.2 | 0.0 | 17.4 | 0.6 | +36.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +177.3 | 0.0 | 68.9 | 5.0 | +234.4 | 0.0 | 83.8 |
| MISSILES IN THE MOVE | 4.2 | +101.5 | 0.0 | 101.9 | 3.2 | +42.5 | 0.0 | 75.2 |
| MISSILES NEXT TURN | 4.9 | +75.7 | 0.0 | 112.4 | 3.9 | +32.7 | 0.0 | 94.9 |
| MODEL FACING | 0.3 | +109.1 | 0.0 | 1.7 | 0.1 | +17.5 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 4.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +8.0 | 0.0 | 0.0 | 0.2 | +9.1 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.2 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.2 | -9.3 | 6.8 | 0.0 | 0.1 | -1.4 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 13.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.6 | +332.4 | 164.2 | 44.9 | 3.6 | +219.8 | 279.8 | 77.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +7.9 | 7.8 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.9 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -4.4 | 12.5 | 0.0 | 0.3 | -18.4 | 32.6 | 2.7 |
| NOT TURNED | 5.3 | +68.5 | 0.0 | 90.3 | 5.7 | +84.2 | 0.0 | 93.1 |
| NOT WORTH A CAST | 0.8 | -0.4 | 0.0 | 55.8 | 0.6 | -0.6 | 0.0 | 1.7 |
| OFF BEST | 15.0 | -700.7 | 16.7 | 291.2 | 13.9 | -721.6 | 17.9 | 213.9 |
| OPENS A LANE | 0.1 | +0.5 | 13.0 | 0.0 | 0.1 | +0.3 | 8.7 | 0.0 |
| OPENS UP | 0.1 | +4.5 | 2.2 | 10.6 | 0.2 | +18.2 | 13.5 | 13.7 |
| OVERRUNS AWAY | 0.3 | +13.2 | 30.9 | 15.1 | 0.4 | +8.6 | 33.5 | 20.5 |
| PATHS CROSS | 2.6 | +147.0 | 0.0 | 41.4 | 2.7 | +173.0 | 0.0 | 27.1 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +6.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.5 | 0.0 | 3.4 | 0.0 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +1466.8 | 1121.1 | 910.3 | 36.8 | +983.0 | 1209.0 | 858.4 |
| PURSUES BIG PREY | 0.1 | -2.0 | 0.0 | 0.0 | 0.1 | -5.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.7 | 0.0 | 3.1 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +16.0 | 0.0 | 21.1 | 2.4 | +24.9 | 0.0 | 70.4 |
| RANDOM MOVER NO PROMISE | 0.1 | -5.7 | 11.1 | 5.8 | 0.5 | -21.4 | 16.9 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -1.6 | 0.0 | 2.3 | 0.5 | -22.5 | 0.0 | 11.2 |
| REDIRECT COUNTER | 2.1 | +131.6 | 0.0 | 32.0 | 3.4 | +332.1 | 0.0 | 57.9 |
| REDIRECT WEIGHED | 0.3 | +1.8 | 4.0 | 10.6 | 0.5 | +0.0 | 9.8 | 12.7 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 10.1 | 0.4 | +0.0 | 0.0 | 27.2 |
| RESERVE FALL BACK | 0.4 | +5.0 | 0.0 | 9.6 | 1.0 | +35.5 | 0.0 | 16.8 |
| RESTRAINS TO SHOOT | 0.1 | +3.7 | 0.0 | 4.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +91.2 | 171.6 | 49.8 | 2.5 | +57.9 | 204.4 | 55.5 |
| SAFER THAN THE JOB | 0.6 | +53.8 | 0.0 | 32.6 | 0.8 | +54.6 | 0.0 | 20.3 |
| SCOUT SPOT | 0.4 | +1.1 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -8.5 | 0.0 | 2.8 | 0.3 | -13.6 | 0.0 | 5.2 |
| SEARCH SPOT | 2.8 | +130.1 | 0.0 | 62.1 | 3.1 | +149.7 | 0.0 | 72.4 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.7 | 3.1 | 0.8 |
| SELF MOVE SPELL | 0.2 | +6.1 | 0.0 | 0.0 | 0.4 | +47.7 | 0.0 | 9.1 |
| SET UP TOGETHER | 2.0 | +194.2 | 62.2 | 30.1 | 2.0 | +159.7 | 165.7 | 35.2 |
| SET-UP ANY TARGET | 0.2 | +57.7 | 0.0 | 3.6 | 0.2 | +25.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +3.4 | 7.4 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.5 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +35.8 | 30.3 | 45.4 | 1.1 | +41.9 | 44.5 | 17.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 86.3 | 3.5 | 0.1 | +0.0 | 19.6 | 3.0 |
| SHOTS IN THE MOVE | 15.2 | +583.8 | 0.0 | 263.4 | 9.0 | +273.2 | 0.0 | 121.1 |
| SPELL SETS UP CHARGE | 0.4 | +104.5 | 0.0 | 3.6 | 0.2 | +25.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +17.2 | 90.2 | 94.5 | 1.0 | +16.7 | 66.3 | 63.7 |
| SPELLS IN THE FIGHT | 0.5 | +2.7 | 50.4 | 18.9 | 0.7 | -4.1 | 67.0 | 8.4 |
| STABLE ROLE | 10.6 | +0.0 | 373.1 | 176.7 | 10.0 | +0.0 | 238.7 | 194.4 |
| STANDS TO CAST | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +4.0 | 0.0 | 0.0 |
| STOPS | 0.1 | +3.3 | 2.8 | 0.0 | 0.2 | +8.3 | 13.3 | 0.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +29.7 | 0.0 | 23.2 | 0.3 | +19.0 | 0.0 | 25.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 5.2 | -28.9 | 275.2 | 59.3 | 6.3 | -41.7 | 355.0 | 77.8 |
| SUPPORTS | 3.2 | +28.9 | 113.2 | 28.2 | 4.6 | +43.8 | 218.1 | 58.5 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -8.1 | 10.2 | 15.0 |
| SURE REACH TOGETHER | 0.4 | +16.1 | 0.0 | 0.0 | 0.4 | +2.9 | 10.8 | 2.9 |
| THROUGH LINE OF FIRE | 0.5 | +14.3 | 0.0 | 10.1 | 0.1 | +4.3 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -3.9 | 6.5 | 0.0 | 0.1 | -4.6 | 4.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.8 | +6.1 | 51.8 | 0.0 | 0.5 | +4.9 | 48.2 | 5.4 |
| WAIT AFTER COSTS | 6.8 | -355.4 | 224.8 | 119.3 | 6.2 | -343.2 | 363.9 | 132.0 |
| WALKS TO THE FIGHT | 1.8 | +33.0 | 19.8 | 33.7 | 0.9 | +17.6 | 26.0 | 23.0 |
| WAR ENGINE CHARGES | 0.1 | +5.4 | 7.7 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 23.7 | 9.3 | 0.3 | +0.0 | 0.0 | 14.3 |
| WEARS DOWN | 1.1 | +42.4 | 130.2 | 12.8 | 0.8 | +20.7 | 81.3 | 4.9 |
| WHO HITS BACK | 0.3 | +23.7 | 0.0 | 18.4 | 0.1 | +7.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +5.8 | 41.4 | 2.5 | 0.4 | +12.3 | 36.1 | 7.1 |
| WHOLE FIGHT GAIN | 0.3 | +17.0 | 45.3 | 2.3 | 0.9 | +76.7 | 31.8 | 15.9 |
| WIDER SPREAD | 2.4 | -4.1 | 205.7 | 46.6 | 3.0 | -2.7 | 277.1 | 46.5 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 8.0 | 0.0 |

### Rule changes: dep-opp-13df7bd-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1041 | 1041 | 1041 | 28.92 | -51200 | -49.2 |
| BEST FIRST | 350 | 350 | 350 | 9.72 | +13217 | +37.8 |
| SEARCH SPOT | 212 | 212 | 208 | 5.78 | +10077 | +48.4 |
| PATHS CROSS | 192 | 192 | 192 | 5.33 | +11518 | +60.0 |
| COUNTER-CHARGE COVER | 604 | 334 | 160 | 4.44 | +8994 | +56.2 |
| DEPLOY BY FIGURES | 274 | 274 | 160 | 4.44 | +1718 | +10.7 |
| FACES THE THREAT | 123 | 123 | 123 | 3.42 | +10106 | +82.2 |
| MOVE TO CHARGE | 260 | 260 | 117 | 3.25 | +7450 | +63.7 |
| KILLS COUNT NEXT TURN | 382 | 382 | 101 | 2.81 | +2360 | +23.4 |
| SUPPORTS | 280 | 280 | 89 | 2.47 | +712 | +8.0 |
| FALLBACK BY WORTH | 408 | 408 | 88 | 2.44 | +4139 | +47.0 |
| SET UP TOGETHER | 144 | 133 | 76 | 2.11 | +5257 | +69.2 |
| SHOTS IN THE MOVE | 871 | 568 | 72 | 2.00 | +1778 | +24.7 |
| RANDOM MOVE BY FIGURES | 111 | 111 | 63 | 1.75 | +1474 | +23.4 |
| ADVANCE LANE KEPT | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| BEST FACING | 58 | 58 | 58 | 1.61 | +3533 | +60.9 |
| CANNON SIGHT KEPT | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 57 | 57 | 57 | 1.58 | +8633 | +151.5 |
| ARTILLERY RE-ROLL WEIGHED | 53 | 53 | 53 | 1.47 | +0 | +0.0 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1459 | +29.2 |
| SAFER THAN THE JOB | 49 | 49 | 49 | 1.36 | +3901 | +79.6 |
| WAIT AFTER COSTS | 471 | 471 | 49 | 1.36 | +987 | +20.1 |
| CANNON PLANNED TARGET | 231 | 231 | 48 | 1.33 | -48 | -1.0 |
| WALKS TO THE FIGHT | 98 | 98 | 47 | 1.31 | +831 | +17.7 |
| REDIRECT COUNTER | 200 | 125 | 46 | 1.28 | +4222 | +91.8 |
| MARCH CHECK | 45 | 44 | 44 | 1.22 | +2146 | +48.8 |
| MAX FOR POSITIONING | 356 | 199 | 42 | 1.17 | +479 | +11.4 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +3560 | +86.8 |
| BLOCKED WHEEL | 40 | 40 | 40 | 1.11 | +202 | +5.0 |
| HOLDS AMBUSHERS | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| RISK BY ARC | 168 | 162 | 38 | 1.06 | +1402 | +36.9 |
| CHARGE NOW FIRST | 155 | 155 | 37 | 1.03 | -2465 | -66.6 |
| SHOOTS FROM THE BEST SPOT | 80 | 80 | 37 | 1.03 | +883 | +23.9 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +3389 | +94.1 |
| LANE BY FIGURES | 36 | 36 | 36 | 1.00 | +1485 | +41.3 |
| LONE WIZARD KEPT IN | 36 | 36 | 36 | 1.00 | +2639 | +73.3 |
| KILLS COUNT | 113 | 111 | 33 | 0.92 | +1758 | +53.3 |
| MARCH ODDS | 31 | 31 | 31 | 0.86 | +215 | +6.9 |
| REDIRECT WEIGHED | 31 | 31 | 31 | 0.86 | +1161 | +37.5 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| KEEPS ITS TARGET | 133 | 131 | 27 | 0.75 | +396 | +14.7 |
| MISSILES IN THE MOVE | 267 | 156 | 27 | 0.75 | +243 | +9.0 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1756 | +65.0 |
| CAST JOB | 49 | 49 | 25 | 0.69 | +343 | +13.7 |
| SHOT REPLANNED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 44 | 41 | 25 | 0.69 | +845 | +33.8 |
| SCOUT WAITS | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +62 | +2.6 |
| HONEST WORTH | 536 | 532 | 22 | 0.61 | +230 | +10.4 |
| BIG CHARACTER SAFETY | 20 | 20 | 20 | 0.56 | -28 | -1.4 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +614 | +30.7 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +671 | +33.6 |
| BEST PREY | 68 | 68 | 19 | 0.53 | +466 | +24.5 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -51 | -2.7 |
| MAKE SURE TOGETHER | 61 | 45 | 18 | 0.50 | +1181 | +65.6 |
| HOLDER AT DEPLOYMENT | 33 | 33 | 16 | 0.44 | +791 | +49.4 |
| INVITES THE FIGHT | 78 | 78 | 16 | 0.44 | +336 | +21.0 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +843 | +56.2 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HUNT IN PAIRS | 43 | 22 | 14 | 0.39 | +773 | +55.2 |
| MODEL FACING | 14 | 14 | 14 | 0.39 | +4558 | +325.5 |
| WEARS DOWN | 70 | 67 | 14 | 0.39 | +361 | +25.8 |
| MANOEUVRE | 14 | 14 | 13 | 0.36 | +422 | +32.4 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +904 | +75.3 |
| WHOLE FIGHT | 25 | 25 | 12 | 0.33 | +692 | +57.7 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -311 | -34.6 |
| OPENS UP | 11 | 11 | 9 | 0.25 | +437 | +48.5 |
| WIDER SPREAD | 193 | 183 | 9 | 0.25 | +46 | +5.1 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BACKUP TARGETS | 58 | 28 | 7 | 0.19 | +55 | +7.8 |
| LOST CHARGE | 149 | 148 | 7 | 0.19 | +221 | +31.6 |
| MISSILES NEXT TURN | 320 | 192 | 7 | 0.19 | +39 | +5.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -96 | -13.8 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -274 | -39.2 |
| SUPPORT NARROWED | 414 | 414 | 7 | 0.19 | -85 | -12.2 |
| SURE REACH TOGETHER | 27 | 17 | 7 | 0.19 | +103 | +14.7 |
| CASTING BLOCK | 6 | 6 | 6 | 0.17 | +196 | +32.6 |
| REFUSING RETIRES | 24 | 24 | 6 | 0.17 | -2 | -0.2 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -313 | -52.1 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +156 | +31.2 |
| STOPS | 10 | 10 | 5 | 0.14 | +160 | +31.9 |
| EDGE GIVE GROUND | 16 | 16 | 4 | 0.11 | +352 | +88.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +101 | +33.7 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +86 | +28.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +88 | +29.3 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 23 | 22 | 3 | 0.08 | +205 | +68.5 |
| SPELLS IN THE FIGHT | 42 | 41 | 3 | 0.08 | +28 | +9.4 |
| TWO OR MORE ARRIVE | 49 | 42 | 3 | 0.08 | +39 | +13.1 |
| WAR ENGINE JOBS | 23 | 23 | 3 | 0.08 | -222 | -74.2 |
| CARRIES OUT SET-UP | 15 | 15 | 2 | 0.06 | -105 | -52.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -42 | -21.2 |
| CHARGER SLAIN LOST | 40 | 38 | 2 | 0.06 | +17 | +8.7 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +96 | +47.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +127 | +63.6 |
| HUNT ADVANCE | 3 | 3 | 2 | 0.06 | +15 | +7.3 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 2 | 0.06 | -44 | -22.0 |
| LONG SHOT | 30 | 30 | 2 | 0.06 | +2 | +0.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +245 | +122.7 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +137 | +68.4 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -89 | -44.6 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -7 | -6.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| JOINT CHARGE PLAN | 18 | 18 | 1 | 0.03 | +1 | +1.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +16 | +15.5 |
| OPENS A LANE | 8 | 5 | 1 | 0.03 | +0 | +0.1 |
| REDIRECT BY WHAT IT STOPS | 31 | 31 | 1 | 0.03 | +38 | +38.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 22 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 13 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 13 | 13 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 395 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 26 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 10 | 10 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 24 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 395 | 395 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 47 | not checked | - | - | - | - |
| PLAN RESULT | 2738 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 75 | not checked | - | - | - | - |
| STABLE ROLE | 742 | 737 | 0 | 0.00 | - | - |
| TURN WORTH | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.97 | 12.39 | 50.4 |
| FALLBACK | gate | 0.94 | 0.67 | 46.5 |
| TURN GATE | gate | 0.61 | 0.50 | 29.7 |
| CHARGE NOW FIRST | rule | 0.36 | 0.67 | 66.6 |
| PATHS CROSS | rule | 0.36 | 0.11 | 37.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.22 | 0.14 | 51.6 |
| BLOCKED WHEEL | rule | 0.17 | 0.14 | 18.4 |
| BEST PRIZE | rule | 0.08 | 0.17 | 34.6 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.08 | 10.0 |
| CHAFF PASSED | rule | 0.19 | 0.03 | 6.2 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.03 | 37.0 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.03 | 13.8 |
| PURSUES BIG PREY | rule | 0.08 | 0.11 | 39.2 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 2.4 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 14.1 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 81.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.14 | 52.1 |
| FACES THE THREAT | rule | 0.06 | 0.06 | 8.7 |
| MARCH ODDS | rule | - | 0.11 | 38.0 |
| REDIRECT WEIGHED | rule | 0.06 | 0.06 | 50.2 |
| THROUGH LINE OF FIRE | rule | 0.11 | - | 42.4 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.06 | 54.6 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 14.9 |
| WAR ENGINE JOBS | rule | 0.06 | 0.03 | 74.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 52.4 |
| CATCH ODDS | rule | - | 0.06 | 21.2 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 13.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 2.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 22.0 |
| RULE SWITCHED OFF | gate | 0.06 | - | 41.2 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 5.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 12.7 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 6.6 |
| FALLBACK BY WORTH | rule | 0.03 | - | 94.9 |
| FIGHT ORDER BAND | gate | - | 0.03 | 0.7 |
| LONG SHOT | rule | - | 0.03 | 1.7 |
| MOVE AND CAST | rule | - | 0.03 | 5.2 |
| NO REASON | gate | - | 0.03 | 6.7 |
| STANDS TO CAST | rule | - | 0.03 | 90.1 |

### Plans: dep-opp-13df7bd-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 14% | 385 | 344 | 89% |
| Mine | charge | 3.1 | 56% | 258 | 275 | 107% |
| Mine | close in | 4.9 | 19% | 347 | 131 | 38% |
| Mine | hold | 4.5 | 33% | 236 | 0 | 0% |
| Mine | join | 0.7 | 100% | 18 | 0 | 0% |
| Mine | shoot | 9.7 | 63% | 300 | 717 | 239% |
| Mine | support | 3.6 | 92% | 21 | 0 | 0% |
| Opponent | advance | 12.2 | 12% | 275 | 253 | 92% |
| Opponent | charge | 3.8 | 53% | 308 | 367 | 119% |
| Opponent | close in | 5.0 | 27% | 289 | 131 | 45% |
| Opponent | hold | 4.9 | 47% | 329 | 0 | 0% |
| Opponent | join | 0.5 | 100% | 19 | 0 | 0% |
| Opponent | shoot | 4.9 | 50% | 119 | 233 | 195% |
| Opponent | support | 5.3 | 86% | 26 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p8

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 277 | 92 | 50% | 16 |
| Opponent | 0.2 | 9 | 0 | 44% | 44% | 0% | 2.5 | 313 | 94 | 44% | 129 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 50% | 0% | 2.0 | 277 | 92 | 50% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 362 | 308 | 100% | 137 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 119 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 252 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 632 | 0 | 0% | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 152 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 285 | 69 | 33% | 68 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 393 | 0 | 0% | 125 |
| Wood Elf Realms | 0.5 | 3 | 0 | 67% | 67% | 0% | 3.0 | 193 | 109 | 67% | 9 |

### Battle groups: dep-opp-13df7bd-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 18% | 51% | 13% | 0% | 32% | 15% | 9% | 43% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 17% | 38% | 8% | 0% | 0% | 0% | 17% | 75% | 8% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 17% | 61% | 7% | 67% | 35% | 14% | 5% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 26% | 72% | 19% | 33% | 15% | 4% | 12% | 69% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Mine | Chaff | 33 | 62 (33) | 5 | 57 | 49 | 42% | 2.6 | 141 (10) | 33 (12) | 33 (11) | 62 (22) | 62 (11) |
| Mine | Character | 118 | 44 (118) | 44 | 0 | 38 | 17% | 2.6 | 62 (40) | 46 (45) | 17 (11) | 57 (57) | 39 (39) |
| Mine | Clean-up | 25 | 30 (25) | 17 | 13 | 37 | 40% | 3.3 | 32 (9) | 31 (13) | 14 (3) | 37 (17) | 20 (8) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.7 | - | 0 (3) | - | 0 (3) | - |
| Mine | Fast Hammer | 49 | 58 (49) | 47 | 10 | 40 | 18% | 3.3 | 50 (21) | 66 (19) | 60 (9) | 59 (31) | 56 (18) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 40% | 1.7 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 56 | 38 (56) | 25 | 13 | 41 | 23% | 2.5 | 35 (14) | 46 (34) | 7 (8) | 42 (34) | 33 (22) |
| Mine | Holder | 20 | 70 (20) | 22 | 49 | 42 | 40% | 2.5 | 37 (3) | 62 (9) | 92 (8) | 65 (9) | 75 (11) |
| Mine | Shooter | 40 | 65 (40) | 21 | 43 | 37 | 5% | 1.8 | 39 (10) | 79 (24) | 40 (6) | 72 (25) | 52 (15) |
| Mine | Support | 4 | 2 (4) | 2 | 0 | 0 | 0% | 3.5 | - | 2 (4) | - | - | 2 (4) |
| Mine | War machine | 58 | 68 (58) | 68 | 0 | 49 | 2% | 1.2 | 105 (11) | 66 (41) | 0 (6) | 52 (19) | 75 (39) |
| Mine | Wizard | 22 | 16 (22) | 16 | 0 | 6 | 45% | 2.9 | 2 (10) | 42 (6) | 0 (4) | 37 (10) | 0 (10) |
| Opponent | Blocker | 2 | 34 (2) | 34 | 0 | 30 | 50% | 5.0 | 49 (1) | - | - | 49 (1) | - |
| Opponent | Chaff | 65 | 59 (65) | 24 | 35 | 44 | 37% | 2.9 | 40 (20) | 98 (23) | 29 (22) | 59 (45) | 59 (20) |
| Opponent | Character | 96 | 53 (96) | 53 | 0 | 31 | 25% | 2.7 | 55 (30) | 56 (44) | 71 (10) | 63 (47) | 51 (37) |
| Opponent | Clean-up | 24 | 45 (24) | 9 | 36 | 34 | 42% | 3.4 | 43 (11) | 53 (12) | 0 (1) | 59 (18) | 15 (6) |
| Opponent | Fast | 4 | 26 (4) | 26 | 0 | 79 | 25% | 1.0 | 0 (1) | - | 32 (3) | 61 (2) | 0 (2) |
| Opponent | Fast Hammer | 44 | 37 (44) | 23 | 14 | 43 | 30% | 2.8 | 25 (15) | 46 (25) | 17 (4) | 32 (27) | 45 (17) |
| Opponent | Fragile | 15 | 41 (15) | 41 | 0 | 63 | 33% | 2.6 | 50 (8) | 0 (4) | 70 (3) | 0 (6) | 67 (9) |
| Opponent | Hammer | 53 | 42 (53) | 31 | 11 | 49 | 34% | 2.4 | 24 (20) | 49 (26) | 81 (7) | 49 (33) | 33 (20) |
| Opponent | Holder | 37 | 78 (37) | 7 | 71 | 19 | 43% | 3.1 | 65 (11) | 92 (17) | 66 (9) | 90 (24) | 54 (13) |
| Opponent | Shooter | 31 | 89 (31) | 31 | 58 | 33 | 3% | 1.6 | 74 (12) | 78 (17) | 281 (2) | 94 (19) | 81 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 16 | 29 (16) | 29 | 0 | 55 | 6% | 1.3 | 37 (3) | 30 (5) | 25 (8) | 21 (6) | 33 (10) |
| Opponent | Wizard | 27 | 1 (27) | 1 | 0 | 52 | 4% | 2.1 | 0 (6) | 0 (8) | 13 (2) | 0 (4) | 3 (12) |

### Charged fights: dep-opp-13df7bd-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 5 | 206 | 2.0 | 1.6 | 103 | 21 | +82 | 1 of 8 | 8 of 8 | +30 | +113 |
| Mine | Chaos Dwarfs | 3 | 193 | 163 | 1.3 | 1.2 | 122 | 238 | -116 | 3 of 4 | 2 of 4 | +255 | -239 |
| Mine | Dwarfen Mountain Holds | 4 | 197 | 21 | 1.2 | 1.2 | 17 | 0 | +17 | 3 of 5 | 3 of 5 | +0 | +21 |
| Mine | Empire of Man | 5 | 542 | 171 | 1.4 | 1.1 | 122 | 16 | +106 | 2 of 7 | 4 of 7 | +0 | +124 |
| Mine | Grand Cathay | 4 | 407 | 182 | 2.8 | 1.1 | 66 | 20 | +46 | 5 of 11 | 6 of 11 | +0 | +51 |
| Mine | High Elf Realms | 4 | 290 | 379 | 3.2 | 1.2 | 117 | 20 | +96 | 3 of 13 | 9 of 13 | +171 | +74 |
| Mine | Kingdom of Bretonnia | 1 | 335 | 1037 | 2.0 | 1.0 | 518 | 0 | +518 | 1 of 2 | 2 of 2 | - | +518 |
| Mine | Lizardmen | 1 | 185 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | +0 | - |
| Mine | Ogre Kingdoms | 1 | 0 | 410 | 6.0 | 1.0 | 68 | 56 | +12 | 2 of 6 | 5 of 6 | - | +12 |
| Mine | Orc & Goblin Tribes | 1 | 65 | 936 | 5.0 | 1.0 | 187 | 0 | +187 | 2 of 5 | 4 of 5 | - | +187 |
| Mine | Skaven | 2 | 25 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 34 | 1047 | 3.0 | 1.3 | 349 | 39 | +310 | 2 of 6 | 5 of 6 | +373 | +298 |
| Mine | Vampire Counts | 2 | 0 | 334 | 3.0 | 1.2 | 111 | 126 | -15 | 4 of 6 | 3 of 6 | +0 | -18 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Wood Elf Realms | 1 | 468 | 206 | 3.0 | 1.0 | 69 | 35 | +34 | 0 of 3 | 2 of 3 | - | +34 |
| **Mine** | all armies | 36 | 224 | 273 | 2.2 | 1.2 | 126 | 40 | +86 | 29 of 78 | 54 of 78 | +95 | +84 |
| Opponent | Dwarfen Mountain Holds | 1 | 190 | 138 | 4.0 | 1.0 | 34 | 0 | +34 | 1 of 4 | 2 of 4 | - | +34 |
| Opponent | Grand Cathay | 3 | 135 | 305 | 3.3 | 1.2 | 92 | 20 | +71 | 7 of 10 | 5 of 10 | +139 | +54 |
| Opponent | High Elf Realms | 1 | 189 | 490 | 3.0 | 1.0 | 163 | 0 | +163 | 3 of 3 | 3 of 3 | - | +163 |
| Opponent | Kingdom of Bretonnia | 2 | 94 | 561 | 2.0 | 1.2 | 280 | 69 | +212 | 2 of 4 | 3 of 4 | +952 | -35 |
| Opponent | Lizardmen | 2 | 0 | 228 | 3.0 | 1.0 | 76 | 8 | +68 | 1 of 6 | 4 of 6 | - | +68 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 150 | 3.5 | 1.0 | 43 | 194 | -151 | 5 of 7 | 3 of 7 | - | -151 |
| Opponent | Skaven | 4 | 200 | 0 | 0.8 | 1.7 | 0 | 14 | -14 | 1 of 3 | 1 of 3 | -20 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 108 | 655 | 2.5 | 1.4 | 262 | 20 | +242 | 4 of 10 | 6 of 10 | +228 | +252 |
| Opponent | Vampire Counts | 3 | 43 | 669 | 4.3 | 1.2 | 154 | 77 | +78 | 7 of 13 | 11 of 13 | -240 | +135 |
| Opponent | Warriors of Chaos | 9 | 24 | 386 | 2.4 | 1.1 | 158 | 14 | +144 | 11 of 22 | 15 of 22 | +197 | +136 |
| Opponent | Wood Elf Realms | 5 | 160 | 347 | 2.8 | 1.0 | 124 | 65 | +58 | 7 of 14 | 11 of 14 | - | +58 |
| **Opponent** | all armies | 36 | 93 | 368 | 2.7 | 1.1 | 138 | 45 | +93 | 49 of 96 | 64 of 96 | +158 | +82 |

### Effective charges: dep-opp-13df7bd-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net +100) | 0 | 1 (net +0) | 5 (net +60) | 0 | 1 (net +258) | 0 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 1 (net +0) | 2 (net -359) | 0 | 1 (net +255) | 0 | 25% (1 of 4) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +42) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 7 | 2 (net +354) | 0 | 1 (net -110) | 2 (net +72) | 0 | 2 (net +0) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 11 | 1 (net +156) | 2 (net +158) | 3 (net +13) | 3 (net +0) | 1 (net +0) | 0 | 1 | 30% (3 of 10) |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 3 (net +172) | 3 (net +2) | 3 (net +130) | 2 (net +170) | 1 | 25% (3 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +971) | 1 (net +66) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Lizardmen | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 1 (net +0) | 3 (net -23) | 0 | 1 (net +0) | 1 | 20% (1 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +685) | 3 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 2 (net +318) | 3 (net +368) | 0 | 1 (net +122) | 0 | 33% (2 of 6) |
| Mine | Vampire Counts | 6 | 2 (net -203) | 0 | 1 (net +0) | 2 (net +102) | 0 | 1 (net +111) | 0 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +65) | 1 | 0% (0 of 3) |
| Opponent | Grand Cathay | 10 | 2 (net +0) | 0 | 4 (net +68) | 2 (net +144) | 0 | 1 (net +150) | 1 | 44% (4 of 9) |
| Opponent | High Elf Realms | 3 | 1 (net +0) | 0 | 0 | 1 (net +110) | 0 | 1 (net +380) | 0 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net -275) | 0 | 1 (net +952) | 1 (net +0) | 0 | 1 (net +170) | 0 | 25% (1 of 4) |
| Opponent | Lizardmen | 6 | 1 (net +347) | 0 | 1 (net +110) | 3 (net +0) | 0 | 0 | 1 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net -1190) | 0 | 1 (net +0) | 0 | 0 | 1 (net +112) | 4 | 33% (1 of 3) |
| Opponent | Skaven | 3 | 2 (net -20) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 10 | 1 (net +717) | 1 (net +100) | 3 (net +0) | 1 (net +165) | 1 (net +195) | 1 (net +540) | 2 | 38% (3 of 8) |
| Opponent | Vampire Counts | 13 | 1 (net +544) | 1 (net +0) | 3 (net +20) | 2 (net -104) | 1 (net -211) | 5 (net +165) | 0 | 23% (3 of 13) |
| Opponent | Warriors of Chaos | 22 | 6 (net +104) | 0 | 4 (net +44) | 3 (net +219) | 1 (net +30) | 6 (net +281) | 2 | 20% (4 of 20) |
| Opponent | Wood Elf Realms | 14 | 1 (net +0) | 0 | 3 (net +208) | 1 (net +110) | 0 | 2 (net +42) | 7 | 43% (3 of 7) |

### Charged fights, damage counted: dep-opp-13df7bd-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 145 | 308 | +62 | 171 | 105 | +66 | +45.6 |
| Mine | 50-54% | 2 | 270 | 256 | +158 | 184 | 0 | +184 | +68.1 |
| Mine | Effective (55-75%) | 15 | 315 | 271 | +137 | 210 | 113 | +97 | +30.9 |
| Mine | 76-89% | 26 | 201 | 160 | +43 | 120 | 81 | +38 | +19.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 313 | 209 | +148 | 153 | 37 | +116 | +37.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 587 | 126 | +78 | 120 | 87 | +33 | +5.6 |
| Mine | No odds | 9 | 160 | 121 | +55 | 80 | 51 | +29 | +18.3 |
| Mine | All fights | 78 | 256 | 202 | +86 | 145 | 78 | +67 | +26.3 |
| Opponent | Long shot (under 50%) | 18 | 238 | 293 | +40 | 179 | 152 | +27 | +11.5 |
| Opponent | 50-54% | 2 | 171 | 180 | +50 | 211 | 0 | +211 | +123.6 |
| Opponent | Effective (55-75%) | 20 | 378 | 221 | +110 | 167 | 78 | +89 | +23.5 |
| Opponent | 76-89% | 15 | 296 | 154 | +75 | 130 | 40 | +90 | +30.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 296 | 215 | +201 | 210 | 15 | +195 | +65.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 466 | 118 | +5 | 108 | 91 | +17 | +3.5 |
| Opponent | No odds | 18 | 165 | 216 | +42 | 130 | 78 | +52 | +31.6 |
| Opponent | All fights | 96 | 280 | 218 | +93 | 165 | 72 | +93 | +33.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p8 | move | 435 | 94 (22%) | 62 (14%) | 50 (11%) | 291 (67%) |
| dep-opp-13df7bd-p8 | objective | 357 | 53 (15%) | 36 (10%) | 50 (14%) | 254 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0116, L0132, L2529, L2728 |
| Charmed Shield | Opponent | L0334, L0626, L1525, L2125, L3334 |
| Clockwork Compass | Mine | L1222 |
| Clockwork Compass | Opponent | L1112 |
| Elixir of Power | Mine | L1112, L1128, L1921 |
| Elixir of Power | Opponent | L0419, L0911, L1019 |
| Fistful of Laurels | Mine | L1821 |
| Horn of the Wild Hunt | Mine | L3334 |
| Horn of the Wild Hunt | Opponent | L0233, L1333, L2333 |
| Invocation of Nehek | Mine | L2529, L2728 |
| Invocation of Nehek | Opponent | L1525, L2125 |
| Opal Amulet | Mine | L1429 |
| Periapt of Soul Exchange | Mine | L2023, L2125 |
| Periapt of Soul Exchange | Opponent | L0821, L1721, L1821, L1921 |
| Ring of Doom | Mine | L0216, L0233, L1112, L1128, L1222, L1525, L3334 |
| Ring of Doom | Opponent | L0233, L0715, L0731, L0911, L1112, L1333, L2333 |
| Ring of Jet | Mine | L1019, L1112, L1128, L1222 |
| Ring of Jet | Opponent | L0610, L0911, L1112 |
| Standard of the Fell Warrior | Mine | L1317, L1333 |
| Storm Daemon (Renegade 2.0) | Mine | L2125 |
| Storm Daemon (Renegade 2.0) | Opponent | L0821, L1721, L1821, L1921 |
| Twice-Blessed Armour | Mine | L0715, L0731, L1019 |
| Twice-Blessed Armour | Opponent | L0610 |
| Witch Hunter's Ward | Mine | L0715, L0731, L0821 |

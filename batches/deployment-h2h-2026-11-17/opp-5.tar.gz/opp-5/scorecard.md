# Doctrine scorecard: dep-opp-13df7bd-p5

### Scorecard: dep-opp-13df7bd-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0104 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0104 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Mine | no | 11 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 0 | 6 | 2 | 4 | 1 | 0 | 0 | 420 |
| L0204 | 6 | 1 | Mine | no | 10 | - | 0 | 3 | 0 | 0 | 0 | 200 |
| L0204 | 6 | 1 | Opponent | no | 3 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0220 | 4 | 1 | Mine | no | 2 | 2 | 1 | 3 | 1 | 0 | 0 | 170 |
| L0220 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 210 |
| L0305 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0305 | 5 | 1 | Opponent | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 548 |
| L0321 | 3 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 760 |
| L0321 | 3 | 1 | Opponent | no | 1 | - | 1 | 4 | 2 | 0 | 0 | 500 |
| L0407 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0423 | 3 | 1 | Mine | yes | 9 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 72 |
| L0510 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0510 | 6 | 1 | Opponent | no | 13 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L0526 | 4 | 1 | Mine | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 1104 |
| L0526 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 60 |
| L0614 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 1 | 0 | 0 | 798 |
| L0614 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 0 | - | 4 | 1 | 0 | 0 | 0 | 984 |
| L0630 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0719 | 5 | 1 | Mine | no | - | 1 | 4 | 0 | 1 | 0 | 0 | 420 |
| L0719 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0735 | 3 | 1 | Mine | yes | 4 | 4 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0735 | 3 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 2 | 0 | 0 | 0 |
| L0825 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0825 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0915 | 3 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 785 |
| L0915 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0932 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0932 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L1024 | 4 | 1 | Mine | no | 2 | 5 | 1 | 0 | 0 | 0 | 0 | 456 |
| L1024 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 1 | 0 | 0 | 60 |
| L1116 | 6 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1116 | 6 | 1 | Opponent | no | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1133 | 5 | 1 | Mine | no | - | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1133 | 5 | 1 | Opponent | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 19 |
| L1226 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1226 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1321 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1321 | 1 | 1 | Opponent | no | 8 | - | 0 | 4 | 1 | 0 | 0 | 553 |
| L1416 | 6 | 1 | Mine | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1416 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 200 |
| L1433 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1433 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 163 |
| L1529 | 5 | 1 | Mine | no | - | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1529 | 5 | 1 | Opponent | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 170 |
| L1627 | 1 | 1 | Mine | yes | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1627 | 1 | 1 | Opponent | no | 4 | 1 | 9 | 2 | 0 | 0 | 0 | 0 |
| L1725 | 3 | 1 | Mine | yes | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1725 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1825 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 531 |
| L1825 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 153 |
| L1925 | 5 | 1 | Mine | yes | - | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1925 | 5 | 1 | Opponent | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L2027 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L2027 | 5 | 1 | Opponent | yes | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L2129 | 5 | 1 | Mine | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 705 |
| L2129 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 85 |
| L2233 | 1 | 1 | Mine | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2233 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 144 |
| L2426 | 2 | 1 | Mine | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2426 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2533 | 1 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2533 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 19 |
| L2733 | 3 | 1 | Mine | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2733 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 208 |
| L3031 | 1 | 1 | Mine | no | 11 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3031 | 1 | 1 | Opponent | yes | 6 | - | 1 | 3 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 32% | 3.0 | 2.6 | 1.9 | 1.1 | 0.2 | 0.0 | 0.0 | 310.3 |
| **Average** | | | Opponent | 29% | 3.0 | 2.3 | 2.8 | 2.1 | 0.3 | 0.0 | 0.0 | 135.4 |

### KPIs: dep-opp-13df7bd-p5

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (56 of 177) | 11% (19 of 178) | 21% (75 of 355) |
| Winner chose to follow up after the loser gave ground |  | 96% (54 of 56); on the table 96% | 98% (55 of 56); on the table 98% | 97% (109 of 112); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | 100% (9 of 9); on the table 100% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fled |  | 85% (11 of 13); on the table 85% | 63% (27 of 43); on the table 72% | 68% (38 of 56); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 93% (67 of 72); on the table 93% | 84% (91 of 108); on the table 88% | 88% (158 of 180); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 37% (124 of 336) | 41% (79 of 192) | 38% (203 of 528) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (124 of 240) | 52% (79 of 152) | 52% (203 of 392) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (16 of 29) | 54% (39 of 72) | 54% (55 of 101) |
| Points that never fought | lower | 40% (28282 of 70841) | 44% (31625 of 71983) | 42% (59907 of 142824) |
|   infantry points that never fought | lower | 46% (7300 of 15898) | 61% (9664 of 15955) | 53% (16964 of 31853) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (171 of 282) | 59% (162 of 276) | 60% (333 of 558) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.5 uses a game | 89% (16 of 18); 1.7 uses a game | 89% (34 of 38); 1.6 uses a game |
| Bound items with another spell used |  | 37% (7 of 19); 0.4 uses a game | 38% (3 of 8); 0.2 uses a game | 37% (10 of 27); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 40% (6 of 15); 0.2 uses a game | 46% (16 of 35); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (33789 of 59757) | 53% (33493 of 63684) | 55% (67282 of 123441) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (31%) | 1.1 (36%) | 3.0 (33%) |
| MARCHED: its unit marched | 1.2 (20%) | 0.7 (21%) | 1.8 (20%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (2%) | 0.1 (2%) |
| IN COMBAT: engaged in combat | 1.6 (28%) | 0.4 (12%) | 2.0 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.2 (6%) | 0.4 (5%) |
| GONE: slain | 0.8 (14%) | 0.5 (17%) | 1.3 (15%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.0 | 1.9 | 5.6 | 0.9 | 2.0 |
| not cast | 4.4 | 2.1 | 4.4 | 9.0 | 2.4 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (32%) | 0.3 (7%) | 3.0 (33%) | 0.5 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (20%) | 0.3 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (7%) | 1.1 (25%) | 2.0 (22%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.1 (3%) | 0.2 (5%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (5%) | 0.1 (2%) | 0.4 (5%) | 0.1 (5%) | 0.5 (2%) |
| GONE: slain | 1.0 (23%) | 0.6 (30%) | 0.4 (9%) | 1.3 (15%) | 0.4 (19%) | 2.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (5%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.3 (14%) | 0.0 (0%) | 0.1 (1%) | 0.6 (24%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (57%) | 0.1 (4%) | 2.2 (49%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.9 a game | 1.0 a game |
| stood (cast and not dispelled) | 76% (25 of 33) | 38% (10 of 26) | 59% (35 of 59) |
| the unit moved after it | 92% (23 of 25) | 80% (8 of 10) | 89% (31 of 35) |
| it charged on its next turn | 8% (2 of 25) | 10% (1 of 10) | 9% (3 of 35) |
| the enemy charged it first | 20% (5 of 25) | 0% (0 of 10) | 14% (5 of 35) |
| it fought by the end of its next turn | 8% (2 of 25) | 0% (0 of 10) | 6% (2 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 25) | 10% (1 of 10) | 3% (1 of 35) |
| none of these (no charge, no fight, no charge escaped) | 76% (19 of 25) | 80% (8 of 10) | 77% (27 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (593 of 859) | 58% (282 of 489) | 65% (875 of 1348) |
|   cavalry | 58% (35 of 60) | 52% (56 of 108) | 54% (91 of 168) |
|   character | 60% (67 of 111) | 49% (43 of 87) | 56% (110 of 198) |
|   chariot | 67% (63 of 94) | 30% (12 of 40) | 56% (75 of 134) |
|   infantry | 60% (157 of 260) | 58% (108 of 187) | 59% (265 of 447) |
|   monster | 45% (19 of 42) | - | 45% (19 of 42) |
|   war machine | 86% (252 of 292) | 94% (63 of 67) | 88% (315 of 359) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (28%) | 1.9 (33%) | 4.0 (30%) |
| CHARGED: it charged | 0.7 (10%) | 1.1 (19%) | 1.8 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.8 (13%) | 1.6 (12%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.7 (10%) | 0.8 (13%) | 1.5 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (9%) | 0.2 (4%) | 0.9 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (20%) | 0.8 (14%) | 2.3 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.6 (9%) | 0.1 (1%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.9 | 80% | 5.9 pts | 19 pts |
| character | 3.3 | 0.8 | 82% | 7.8 pts | 26 pts |
| chariot | 2.1 | 1.0 | 73% | 8.7 pts | 18 pts |
| infantry | 11.5 | 3.8 | 76% | 9.6 pts | 111 pts |
| monster | 0.6 | 0.1 | 83% | 4.4 pts | 3 pts |
| war machine | 8.8 | 6.7 | 67% | 27.1 pts | 237 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.4 | 5.5 | 4.5 |
| Charges that made contact a game | 2.7 | 3.7 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.54 declared, 0.46 contact (24 units) | 0.50 declared, 0.35 contact (20 units) | 0.52 declared, 0.41 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.75 contact (8 units) | 1.46 declared, 1.23 contact (13 units) | 1.19 declared, 1.05 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.33 contact (243 units) | 0.62 declared, 0.40 contact (274 units) | 0.53 declared, 0.37 contact (517 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (42 of 70) | 57% (13 of 23) | 43% (3 of 7) | 58% (58 of 100) |
| Character in a unit | 80% (37 of 46) | 78% (18 of 23) | 40% (2 of 5) | 77% (57 of 74) |
| Character on its own | 80% (28 of 35) | 59% (17 of 29) | 35% (23 of 66) | 52% (68 of 130) |
| Chariot | 64% (9 of 14) | 60% (9 of 15) | - | 62% (18 of 29) |
| Infantry | 57% (43 of 76) | 47% (23 of 49) | 75% (3 of 4) | 53% (69 of 129) |
| Monster | 70% (14 of 20) | 58% (7 of 12) | - | 66% (21 of 32) |
| Monstrous | 50% (4 of 8) | 82% (9 of 11) | - | 68% (13 of 19) |
| War Machines | 63% (27 of 43) | 100% (2 of 2) | - | 64% (29 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 91% (10 of 11); on the table 91% | 36% (39 of 108) | 24% | 41% (9 of 22) | 83% (5 of 6); 4.0 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 6 | 70% (7 of 10); on the table 70% | 38% (16 of 42) | 61% | 50% (24 of 48) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (6 of 6); on the table 100% | - | 69% | 73% (30 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (5 of 5); on the table 100% | 47% (17 of 36) | 41% | 72% (46 of 64) | 0.0 uses a game | 100% (3 of 3); 1.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (11 of 11); on the table 100% | 43% (49 of 114) | 48% | 56% (25 of 45) | 91% (10 of 11); 7.4 uses a game | 50% (1 of 2); 0.4 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 92% (11 of 12); on the table 92% | 25% (6 of 24) | 39% | 53% (26 of 49) | 100% (5 of 5); 2.7 uses a game | 25% (5 of 20); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (1 of 1); on the table 100% | - | 35% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | - | 36% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | - | 19% | 86% (6 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 44% (8 of 18) | 16% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 6 | 86% (12 of 14); on the table 100% | 33% (16 of 48) | 44% | 65% (31 of 48) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 50% (3 of 6); 0.5 uses a game |
| Tomb Kings of Khemri | 2 | 70% (7 of 10); on the table 70% | 0% (0 of 6) | 24% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 13 | 90% (38 of 42); on the table 93% | 43% (44 of 102) | 39% | 60% (46 of 77) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 73% (16 of 22); on the table 77% | 33% (2 of 6) | 36% | 57% (25 of 44) | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 6 | 92% (23 of 25); on the table 92% | 25% (6 of 24) | 42% | 65% (40 of 62) | 82% (9 of 11); 5.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p5, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (32) | 53% (37) | 46% (69) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.67 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.22 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.39 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 1.03 | 2.81 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.78 | 1.42 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.53 | 6.64 | 13.17 |

### Quality by phase: dep-opp-13df7bd-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.9 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 50% (56 of 112) | 45% (77 of 171) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (144 of 382) | 52% (97 of 187) |
| Strategy | Close-in objectives charged next turn | 11% (18 of 163) | 18% (38 of 217) |
| Strategy | Support requests answered (helper made contact too) | 60% (9 of 15) | 39% (11 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 5) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 53% (29 of 55) | 34% (16 of 47) |
| Strategy | Lone characters that fought | 80% (70 of 88) | 76% (62 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 2.1 |
| Movement | Points that never moved of their own | 310.3 | 135.4 |
| Movement | Fights charged into per game | 2.4 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 77, net -55 | 23 of 96, net +14 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 77, net -15 | 16 of 96, net +205 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 77, net +25 | 7 of 96, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 77, net +33 | 34 of 96, net +82 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 6.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (195 of 367) | 55% (129 of 233) |
| Shooting | Points destroyed by shooting units | 61.5 | 22.1 |
| Shooting | War machine shots | 7.0 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (157 of 252) | 51% (32 of 63) |
| Shooting | Points destroyed by war machines | 116.3 | 16.9 |
| Magic | Magic missiles cast | 2.0 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (24 of 71) | 39% (22 of 56) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.6 |
| Magic | Wounds caused by other spells | 1.2 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 34.6 | 62.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.1 / 0.9 / 0.2 | 2.3 / 0.2 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 221.5 | 355.0 |
| Combat | Points run down | 46.9 | 181.9 |
| Combat | Net points per charged fight, damage counted | +13 | +100 |
| Combat | Net per 100 charger points, damage counted | +4.9 | +34.1 |
| Combat | First round won (charged fights) | 59% | 75% |
| Combat | Net points per charged fight | +16 | +96 |
| Combat | Net points per supported fight / lone fight | +2 / +18 | +166 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 86 | 47 of 113 |
| Game | Points lost | 729.2 | 508.4 |
| Game | VP from objectives | 522.8 | 663.3 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 10 / 10 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -372 VP
- The side that went first won 17 of 26 games with a winner
- Points traded per game (both sides' losses): 1238
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-opp-13df7bd-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 15.3 | 0.2 | +0.0 | 0.0 | 7.9 |
| BACKUP TARGETS | 1.1 | +8.1 | 0.0 | 32.5 | 0.8 | +9.9 | 0.0 | 27.2 |
| BEST FACING | 0.8 | +35.1 | 0.0 | 26.4 | 0.4 | +9.9 | 0.0 | 5.2 |
| BEST FIRST | 4.5 | +205.5 | 106.8 | 115.7 | 5.1 | +184.4 | 224.6 | 14.6 |
| BEST OVERALL | 0.5 | +42.8 | 0.0 | 14.6 | 0.5 | +36.7 | 0.0 | 8.0 |
| BEST PREY | 0.6 | +23.5 | 3.1 | 6.6 | 1.0 | +50.7 | 18.6 | 10.0 |
| BEST PRIZE | 0.1 | -3.0 | 0.0 | 3.8 | 0.1 | -0.2 | 4.6 | 7.7 |
| BIG CHARACTER SAFETY | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | -1.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +6.7 | 0.0 | 2.9 | 0.3 | +15.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -53.9 | 21.5 | 18.7 | 0.3 | -48.0 | 29.1 | 31.6 |
| BOMBING RUN | 0.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 30.1 | 6.5 | 0.2 | +0.0 | 10.7 | 5.6 |
| CANNON PLANNED TARGET | 5.7 | +182.7 | 378.8 | 73.6 | 1.6 | +53.5 | 52.5 | 30.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 2.9 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.6 | 6.2 | 5.4 | 0.1 | +0.0 | 8.0 | 4.9 |
| CAST JOB | 0.7 | +14.6 | 60.9 | 16.9 | 0.5 | +8.4 | 12.3 | 6.2 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +56.2 | 39.7 | 0.0 | 0.2 | +8.1 | 13.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 10.5 | 0.4 | +0.0 | 0.0 | 10.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.5 | 0.0 | 8.2 | 0.0 | +0.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -1.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 134.9 | 108.3 | 2.6 | +0.0 | 319.6 | 40.7 |
| CHARGE NOW WEIGHED | 0.8 | -53.7 | 11.8 | 13.4 | 0.6 | -39.6 | 0.0 | 13.3 |
| CHARGER SLAIN LOST | 0.5 | -15.9 | 21.1 | 15.4 | 0.6 | -7.3 | 64.5 | 17.8 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 4.7 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.2 | -2.4 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.1 | 1.8 | 0.1 | +0.0 | 10.6 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 4.4 | 47.5 | 0.4 | +0.0 | 43.5 | 25.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +108.1 | 6.5 | 10.2 | 0.4 | +32.2 | 0.0 | 10.6 |
| COUNTER-CHARGE COVER | 10.2 | +853.2 | 0.0 | 179.6 | 7.5 | +758.7 | 0.0 | 130.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 11.7 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | - | - | - | - | 7.7 | +65.4 | 0.0 | 20.1 |
| EDGE GIVE GROUND | 0.1 | +0.7 | 2.8 | 0.0 | 0.1 | +3.1 | 13.0 | 4.7 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +139.4 | 0.0 | 90.9 | 1.0 | +74.6 | 0.0 | 12.9 |
| FALLBACK BY WORTH | 4.7 | +70.2 | 0.0 | 49.2 | 6.8 | +66.2 | 0.0 | 117.2 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.2 | 5.4 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.2 | 0.0 | 3.1 | - | - | - | - |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 100.6 | 5.9 | +0.0 | 0.0 | 103.0 |
| FOCUS FIRE | 0.0 | +1.1 | 1.2 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +138.8 | 0.0 | 37.5 | 0.8 | +117.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +3.6 | 0.0 | 14.5 | 0.1 | +7.0 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 5.9 | 4.1 | 0.1 | -1.6 | 16.8 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.4 | 4.9 |
| HELPER UNSEEN | 0.1 | +0.0 | 1.2 | 18.2 | 0.4 | +0.0 | 36.1 | 7.1 |
| HILL BY ITS CHANCE | 0.3 | -28.7 | 0.0 | 1.8 | 0.4 | -50.1 | 0.0 | 1.7 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.2 | +186.9 | 0.0 | 1.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -148.1 | 247.3 | 208.2 | 8.3 | -209.3 | 499.2 | 128.6 |
| HORN WORTH | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.9 | 0.1 | +2.2 | 0.0 | 2.9 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.7 |
| HUNT IN PAIRS | 0.4 | +12.5 | 0.0 | 10.2 | 0.5 | +36.2 | 0.0 | 15.1 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 4.6 |
| HUNT THE GUNS | 0.0 | +2.4 | 0.0 | 0.9 | 0.1 | +30.0 | 0.0 | 2.9 |
| INVITES THE FIGHT | 1.8 | +31.2 | 63.4 | 29.4 | 1.2 | +20.9 | 22.8 | 3.1 |
| JOINT CHARGE PLAN | 0.1 | +5.1 | 0.0 | 5.2 | 0.1 | +12.4 | 0.0 | 3.1 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -7.2 | 16.1 | 3.1 |
| KEEP FALLS | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.2 | 3.1 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.0 | +60.0 | 80.2 | 74.0 | 1.8 | +54.2 | 153.1 | 20.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +71.5 | 105.5 | 44.8 | 1.8 | +109.0 | 198.1 | 39.5 |
| KILLS COUNT NEXT TURN | 4.8 | +168.0 | 38.7 | 92.8 | 6.9 | +237.7 | 210.9 | 149.1 |
| LANE BY FIGURES | - | - | - | - | 0.9 | +41.4 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.5 | +17.9 | 2.1 | 0.0 | 0.4 | +8.1 | 9.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 1.7 | 1.7 | 0.3 | +0.0 | 22.1 | 11.7 |
| LONE WIZARD KEPT IN | 0.6 | +32.3 | 0.0 | 0.0 | 0.2 | +19.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -2.6 | 6.3 | 3.4 | 0.3 | +3.7 | 25.8 | 3.6 |
| LOST CHARGE | 2.6 | -52.1 | 153.4 | 56.9 | 2.1 | -30.8 | 63.3 | 21.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -14.9 | 0.0 | 0.0 | 0.1 | -17.6 | 0.0 | 0.5 |
| MAKE SURE TOGETHER | 0.9 | +107.3 | 0.0 | 17.2 | 0.6 | +71.6 | 13.3 | 18.1 |
| MANOEUVRE | 0.2 | +5.0 | 0.0 | 4.2 | 0.1 | +7.0 | 0.0 | 1.1 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +6.0 | 0.0 | 10.6 | 0.7 | +26.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.4 | +24.8 | 4.6 | 23.3 | 0.3 | +11.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +34.4 | 0.0 | 17.4 | 0.4 | +12.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.6 | +177.1 | 0.0 | 111.9 | 4.4 | +147.0 | 0.0 | 83.3 |
| MISSILES IN THE MOVE | 4.2 | +132.0 | 0.0 | 87.2 | 4.3 | +61.3 | 0.0 | 54.4 |
| MISSILES NEXT TURN | 5.0 | +78.7 | 0.0 | 115.2 | 5.0 | +44.3 | 0.0 | 69.4 |
| MODEL FACING | 0.3 | +101.5 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 31.6 | 0.7 | +0.0 | 0.0 | 22.6 |
| MOVE AND CAST | 0.2 | +11.2 | 0.0 | 0.0 | 0.4 | +18.8 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +7.8 | 0.0 | 0.0 | 0.2 | +4.2 | 0.0 | 10.6 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -18.8 | 3.4 | 21.1 | 0.5 | -21.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 10.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +243.3 | 22.9 | 75.4 | 4.4 | +284.7 | 83.9 | 143.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +21.2 | 4.7 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -3.8 | 20.7 | 0.0 | 0.3 | -13.9 | 40.8 | 4.6 |
| NOT TURNED | 6.5 | +75.9 | 0.0 | 84.6 | 6.6 | +81.1 | 0.0 | 108.8 |
| NOT WORTH A CAST | 0.4 | -15.0 | 0.0 | 1.7 | 0.7 | -3.2 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -831.7 | 0.0 | 263.2 | 14.2 | -805.0 | 19.2 | 170.6 |
| OPENS A LANE | 0.2 | +0.8 | 18.6 | 15.1 | - | - | - | - |
| OPENS UP | 0.2 | +14.3 | 12.4 | 0.0 | 0.2 | +11.6 | 5.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +4.5 | 29.5 | 13.0 | 0.5 | +5.9 | 59.2 | 5.2 |
| PATHS CROSS | 2.4 | +128.3 | 0.0 | 33.7 | 2.4 | +152.7 | 0.0 | 26.8 |
| PERIAPT WORTH | 0.0 | +3.6 | 0.0 | 15.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -7.2 | 0.0 | 30.0 | 0.1 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 37.5 | +1262.9 | 1270.6 | 1045.4 | 39.7 | +1159.7 | 1243.4 | 747.2 |
| PURSUES BIG PREY | 0.1 | -8.5 | 0.0 | 0.0 | 0.1 | -2.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +8.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +11.4 | 0.0 | 5.8 | 2.0 | +21.4 | 0.0 | 29.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.4 | 3.1 | 0.0 | 0.5 | -42.1 | 0.0 | 5.8 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -3.7 | 0.0 | 4.6 | 0.4 | -11.5 | 0.0 | 8.9 |
| REDIRECT COUNTER | 2.1 | +114.0 | 0.0 | 48.6 | 3.5 | +298.2 | 0.0 | 57.5 |
| REDIRECT WEIGHED | 0.2 | +0.4 | 0.0 | 7.5 | 0.5 | +7.7 | 12.6 | 10.6 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 16.9 | 0.7 | +0.0 | 0.0 | 21.0 |
| RESERVE FALL BACK | 0.2 | +9.4 | 0.0 | 11.0 | 0.8 | +52.1 | 0.0 | 2.9 |
| RESTRAINS TO SHOOT | 0.0 | +1.1 | 0.0 | 9.6 | 0.1 | +2.5 | 0.0 | 3.4 |
| RISK BY ARC | 2.1 | +80.3 | 133.7 | 102.2 | 2.6 | +72.6 | 265.8 | 64.1 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.6 | +43.1 | 0.0 | 25.0 | 0.8 | +43.7 | 0.0 | 32.2 |
| SCOUT SPOT | 0.3 | +1.1 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -2.9 | 0.0 | 0.0 | 0.4 | -21.3 | 0.0 | 2.5 |
| SEARCH SPOT | 2.2 | +108.1 | 0.0 | 21.9 | 2.8 | +138.7 | 0.0 | 80.9 |
| SELF MOVE SPELL | 0.3 | +30.5 | 0.0 | 11.0 | 0.2 | +60.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.4 | +157.2 | 0.0 | 17.2 | 1.7 | +220.3 | 30.9 | 39.9 |
| SET-UP ANY TARGET | 0.5 | +122.2 | 0.0 | 0.0 | 0.1 | +14.9 | 0.0 | 10.6 |
| SET-UP MISSED | - | - | - | - | 0.1 | +11.7 | 10.6 | 10.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +34.8 | 26.8 | 0.0 | 0.4 | +6.8 | 19.1 | 3.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 79.9 | 0.0 | 0.1 | +0.0 | 19.8 | 0.0 |
| SHOTS IN THE MOVE | 14.8 | +638.8 | 0.0 | 194.9 | 6.9 | +245.4 | 0.0 | 96.1 |
| SPELL SETS UP CHARGE | 0.6 | +143.1 | 6.5 | 10.2 | 0.1 | +14.9 | 0.0 | 10.6 |
| SPELL WORTH | 1.0 | +15.4 | 69.2 | 69.2 | 2.7 | +51.2 | 65.8 | 60.4 |
| SPELLS IN THE FIGHT | 0.6 | -0.4 | 67.4 | 52.2 | 0.8 | -2.7 | 144.2 | 29.6 |
| STABLE ROLE | 11.0 | +0.0 | 284.0 | 141.0 | 10.9 | +0.0 | 327.4 | 123.8 |
| STANDS TO CAST | 0.1 | +5.6 | 6.5 | 8.2 | - | - | - | - |
| STAY WEIGHED | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +2.7 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +16.8 | 0.0 | 0.0 | 0.5 | +28.0 | 0.0 | 4.5 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.8 | -51.9 | 255.3 | 96.7 | 6.3 | -48.8 | 209.1 | 76.1 |
| SUPPORTS | 4.2 | +63.6 | 160.2 | 37.6 | 4.2 | +52.6 | 68.7 | 47.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.4 | 1.8 | 9.8 | 0.1 | -3.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +5.2 | 0.0 | 24.1 | 0.6 | +3.1 | 0.0 | 15.7 |
| THROUGH LINE OF FIRE | 0.2 | +12.4 | 0.0 | 0.0 | 0.1 | +18.9 | 0.0 | 3.5 |
| TURN WORTH | 0.2 | -7.8 | 8.7 | 2.4 | 0.4 | -27.5 | 31.6 | 11.1 |
| TWO OR MORE ARRIVE | 0.5 | +4.9 | 0.0 | 0.0 | 0.4 | +1.6 | 9.4 | 16.4 |
| WAIT AFTER COSTS | 7.3 | -355.0 | 173.2 | 138.2 | 7.1 | -336.0 | 196.2 | 159.4 |
| WALKS TO THE FIGHT | 1.5 | +41.2 | 81.8 | 6.5 | 0.9 | +22.3 | 27.2 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +3.1 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 49.6 | 2.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.1 | +48.6 | 40.4 | 74.8 | 0.9 | +30.5 | 86.2 | 35.2 |
| WHO HITS BACK | 0.3 | +22.8 | 0.0 | 18.5 | 0.2 | +4.5 | 0.0 | 2.7 |
| WHOLE FIGHT | 0.1 | +0.9 | 2.9 | 4.1 | 0.6 | +21.4 | 54.7 | 9.9 |
| WHOLE FIGHT GAIN | 0.2 | +8.9 | 17.3 | 2.2 | 0.6 | +40.6 | 78.6 | 8.9 |
| WIDER SPREAD | 2.0 | -6.8 | 146.4 | 80.5 | 3.0 | -3.2 | 338.7 | 55.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: dep-opp-13df7bd-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1093 | 1093 | 1093 | 30.36 | -58924 | -53.9 |
| BEST FIRST | 345 | 345 | 345 | 9.58 | +14038 | +40.7 |
| SEARCH SPOT | 182 | 182 | 181 | 5.03 | +8885 | +49.1 |
| PATHS CROSS | 172 | 172 | 172 | 4.78 | +10118 | +58.8 |
| DEPLOY BY FIGURES | 277 | 277 | 169 | 4.69 | +1676 | +9.9 |
| COUNTER-CHARGE COVER | 636 | 364 | 168 | 4.67 | +10804 | +64.3 |
| MOVE TO CHARGE | 277 | 277 | 141 | 3.92 | +6364 | +45.1 |
| KILLS COUNT NEXT TURN | 419 | 419 | 124 | 3.44 | +3791 | +30.6 |
| SUPPORTS | 303 | 303 | 117 | 3.25 | +1584 | +13.5 |
| FACES THE THREAT | 101 | 101 | 101 | 2.81 | +7704 | +76.3 |
| FALLBACK BY WORTH | 414 | 414 | 80 | 2.22 | +4909 | +61.4 |
| ADVANCE LANE KEPT | 76 | 76 | 76 | 2.11 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| WAIT AFTER COSTS | 520 | 520 | 65 | 1.81 | +1151 | +17.7 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +9240 | +144.4 |
| SET UP TOGETHER | 113 | 97 | 63 | 1.75 | +5542 | +88.0 |
| SHOTS IN THE MOVE | 783 | 536 | 60 | 1.67 | +1819 | +30.3 |
| CANNON SIGHT KEPT | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 101 | 101 | 55 | 1.53 | +1180 | +21.5 |
| CHARGE NOW WEIGHED | 51 | 51 | 51 | 1.42 | +4785 | +93.8 |
| SAFER THAN THE JOB | 51 | 51 | 51 | 1.42 | +3123 | +61.2 |
| WALKS TO THE FIGHT | 87 | 87 | 51 | 1.42 | +984 | +19.3 |
| REDIRECT COUNTER | 199 | 101 | 42 | 1.17 | +2262 | +53.9 |
| BEST FACING | 41 | 41 | 41 | 1.14 | +1620 | +39.5 |
| MAX FOR POSITIONING | 324 | 181 | 41 | 1.14 | +515 | +12.6 |
| RISK BY ARC | 169 | 165 | 39 | 1.08 | +1241 | +31.8 |
| BEST OVERALL | 38 | 38 | 38 | 1.06 | +2862 | +75.3 |
| CANNON PLANNED TARGET | 260 | 260 | 37 | 1.03 | -513 | -13.9 |
| RESERVE FALL BACK | 37 | 37 | 37 | 1.03 | +2215 | +59.9 |
| CHARGE NOW FIRST | 166 | 166 | 36 | 1.00 | -2314 | -64.3 |
| KILLS COUNT | 108 | 107 | 34 | 0.94 | +1652 | +48.6 |
| MISSILES IN THE MOVE | 306 | 167 | 33 | 0.92 | +838 | +25.4 |
| HONEST WORTH | 566 | 562 | 32 | 0.89 | +307 | +9.6 |
| LANE BY FIGURES | 32 | 32 | 32 | 0.89 | +1492 | +46.6 |
| MARCH CHECK | 38 | 36 | 32 | 0.89 | +1234 | +38.6 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +1612 | +50.4 |
| HOLDS AMBUSHERS | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| KEEPS ITS TARGET | 137 | 136 | 28 | 0.78 | +521 | +18.6 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1856 | +66.3 |
| MARCH ODDS | 28 | 28 | 28 | 0.78 | +282 | +10.1 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +786 | +30.2 |
| CAST JOB | 43 | 43 | 26 | 0.72 | +322 | +12.4 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MAKE SURE TOGETHER | 55 | 42 | 26 | 0.72 | +2667 | +102.6 |
| SHOOTS FROM THE BEST SPOT | 48 | 48 | 24 | 0.67 | +635 | +26.5 |
| CASTING BLOCK | 32 | 32 | 23 | 0.64 | +1015 | +44.1 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +1079 | +46.9 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +1103 | +48.0 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| INVITES THE FIGHT | 110 | 110 | 20 | 0.56 | +304 | +15.2 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +42 | +2.1 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CASTS FROM BEHIND | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| WEARS DOWN | 72 | 69 | 18 | 0.50 | +659 | +36.6 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +417 | +23.1 |
| BEST PREY | 57 | 57 | 17 | 0.47 | +648 | +38.1 |
| HOLDER AT DEPLOYMENT | 43 | 43 | 17 | 0.47 | +487 | +28.7 |
| SCOUT WAITS | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -39 | -2.4 |
| REFUSING RETIRES | 38 | 38 | 16 | 0.44 | -1 | -0.1 |
| WHOLE FIGHT GAIN | 31 | 29 | 15 | 0.42 | +511 | +34.1 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -61 | -4.4 |
| SUPPORT NARROWED | 435 | 435 | 14 | 0.39 | -224 | -16.0 |
| PIVOT GUARDS FLANK | 13 | 13 | 13 | 0.36 | -280 | -21.5 |
| WAR ENGINE JOBS | 40 | 40 | 12 | 0.33 | -381 | -31.7 |
| OPENS UP | 13 | 13 | 11 | 0.31 | +296 | +26.9 |
| HUNT IN PAIRS | 30 | 19 | 10 | 0.28 | +259 | +25.9 |
| MANOEUVRE | 13 | 13 | 10 | 0.28 | +431 | +43.1 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +3652 | +365.2 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.28 | +1127 | +112.7 |
| SURE REACH TOGETHER | 45 | 32 | 8 | 0.22 | +23 | +2.9 |
| MISSILES NEXT TURN | 358 | 184 | 7 | 0.19 | +10 | +1.4 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -194 | -27.6 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -268 | -44.7 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +382 | +63.7 |
| LOST CHARGE | 171 | 171 | 6 | 0.17 | +85 | +14.1 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +133 | +22.2 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -406 | -81.3 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +80 | +19.9 |
| OVERRUNS AWAY | 32 | 31 | 4 | 0.11 | +65 | +16.2 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +132 | +32.9 |
| SPELLS IN THE FIGHT | 51 | 51 | 4 | 0.11 | +91 | +22.7 |
| WHOLE FIGHT | 25 | 25 | 4 | 0.11 | +121 | +30.2 |
| BACKUP TARGETS | 69 | 33 | 3 | 0.08 | +48 | +16.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +372 | +124.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +146 | +48.6 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +63 | +21.0 |
| WIDER SPREAD | 182 | 178 | 3 | 0.08 | +14 | +4.5 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -48 | -24.1 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +13 | +6.7 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +254 | +127.2 |
| JOINT KNOWS CHALLENGE | 4 | 3 | 2 | 0.06 | +140 | +70.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 2 | 0.06 | -88 | -44.2 |
| MOVE SPELL IN RANGE | 14 | 8 | 2 | 0.06 | +5 | +2.6 |
| REDIRECT BY WHAT IT STOPS | 30 | 30 | 2 | 0.06 | +56 | +28.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +5 | +2.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +88 | +87.8 |
| CARRIES OUT SET-UP | 8 | 8 | 1 | 0.03 | -22 | -21.7 |
| CHARGER SLAIN LOST | 38 | 37 | 1 | 0.03 | +62 | +61.6 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -51 | -50.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 11 | 11 | 1 | 0.03 | -10 | -10.2 |
| EDGE GIVE GROUND | 6 | 6 | 1 | 0.03 | +22 | +22.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +16 | +15.7 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +5 | +5.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +39 | +38.8 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +63 | +63.0 |
| LONG SHOT | 23 | 23 | 1 | 0.03 | +0 | +0.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -10 | -9.6 |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 1 | 0.03 | +34 | +33.5 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +26 | +25.8 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -181 | -181.3 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 20 | 18 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 428 | not checked | - | - | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 25 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 29 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 40 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 474 | 474 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2778 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 133 | not checked | - | - | - | - |
| STABLE ROLE | 790 | 786 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 20 | 20 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 33 | 32 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.22 | 12.03 | 56.1 |
| FALLBACK | gate | 0.67 | 0.89 | 50.3 |
| TURN GATE | gate | 0.81 | 0.69 | 40.2 |
| CHARGE NOW FIRST | rule | 0.58 | 0.42 | 64.3 |
| SUPPORT NARROWED | rule | 0.25 | 0.14 | 16.0 |
| PIVOT GUARDS FLANK | rule | 0.28 | 0.08 | 21.5 |
| PATHS CROSS | rule | 0.17 | 0.17 | 32.5 |
| WAR ENGINE JOBS | rule | 0.28 | 0.06 | 31.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.11 | 48.1 |
| CHAFF PASSED | rule | 0.25 | - | 4.2 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.14 | 9.6 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 86.8 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 3.7 |
| BEST PRIZE | rule | 0.08 | 0.08 | 44.7 |
| DEPLOY BY FIGURES | rule | - | 0.17 | 13.9 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 2.2 |
| SUPPORT REQUEST | gate | 0.03 | 0.14 | 29.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.08 | 32.2 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 81.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 30.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 9.5 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 18.3 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.06 | 22.2 |
| NO REASON | gate | - | 0.08 | 18.6 |
| REFUSING RETIRES | rule | 0.06 | 0.03 | 1.1 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 12.4 |
| CATCH ODDS | rule | 0.03 | 0.03 | 24.1 |
| MARCH ODDS | rule | - | 0.06 | 16.3 |
| RULE SWITCHED OFF | gate | 0.06 | - | 21.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 21.7 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 50.7 |
| DEFENSIVE ARMY | rule | 0.03 | - | 10.2 |
| FACES THE THREAT | rule | 0.03 | - | 1.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 80.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 88.5 |
| REDIRECT WEIGHED | rule | 0.03 | - | 43.4 |
| SAFE SURE CHARGE | rule | - | 0.03 | 9.6 |
| STANDS TO CAST | rule | 0.03 | - | 30.5 |
| WHO HITS BACK | rule | - | 0.03 | 4.4 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 181.3 |

### Plans: dep-opp-13df7bd-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.3 | 16% | 443 | 352 | 79% |
| Mine | charge | 2.7 | 52% | 213 | 166 | 78% |
| Mine | close in | 4.5 | 20% | 313 | 69 | 22% |
| Mine | hold | 4.5 | 36% | 307 | 0 | 0% |
| Mine | join | 0.8 | 100% | 21 | 0 | 0% |
| Mine | shoot | 9.0 | 57% | 316 | 679 | 215% |
| Mine | support | 4.8 | 91% | 54 | 0 | 0% |
| Opponent | advance | 14.8 | 16% | 399 | 360 | 90% |
| Opponent | charge | 3.9 | 56% | 305 | 377 | 124% |
| Opponent | close in | 6.0 | 22% | 399 | 165 | 41% |
| Opponent | hold | 4.9 | 39% | 329 | 0 | 0% |
| Opponent | join | 1.2 | 100% | 54 | 0 | 0% |
| Opponent | shoot | 4.1 | 56% | 121 | 258 | 213% |
| Opponent | support | 4.8 | 91% | 41 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p5

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 87 | 0 | 0% | 17 |
| Opponent | 0.1 | 3 | 0 | 0% | 0% | 0% | - | 360 | 0 | 0% | 124 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 87 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 148 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 513 | 0 | 0% | 78 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 147 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 283 | 0 | 0% | 100 |

### Battle groups: dep-opp-13df7bd-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.2 | 19% | 54% | 8% | 67% | 32% | 11% | 11% | 46% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 32% | 50% | 17% | 25% | 10% | 5% | 20% | 60% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 14% | 71% | 18% | 43% | 42% | 13% | 0% | 45% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 18% | 68% | 23% | 100% | 24% | 0% | 0% | 76% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 0 | 80% | 4.0 | - | 0 (5) | - | - | 0 (5) |
| Mine | Chaff | 32 | 27 (32) | 0 | 27 | 64 | 44% | 2.6 | 4 (12) | 60 (11) | 21 (9) | 33 (22) | 14 (10) |
| Mine | Character | 125 | 33 (125) | 33 | 0 | 44 | 15% | 2.4 | 35 (44) | 34 (60) | 35 (11) | 37 (65) | 32 (50) |
| Mine | Clean-up | 20 | 45 (20) | 7 | 38 | 40 | 25% | 3.5 | 5 (5) | 63 (12) | 10 (3) | 46 (12) | 44 (8) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 25 | 25% | 1.0 | 0 (1) | 0 (1) | 0 (2) | 0 (4) | - |
| Mine | Fast Hammer | 53 | 23 (53) | 9 | 14 | 36 | 32% | 2.8 | 18 (25) | 21 (18) | 42 (10) | 23 (33) | 23 (20) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 40% | 2.3 | 0 (3) | 35 (2) | - | 0 (1) | 17 (4) |
| Mine | Hammer | 57 | 34 (57) | 17 | 16 | 40 | 16% | 2.4 | 36 (13) | 36 (37) | 17 (7) | 34 (39) | 33 (18) |
| Mine | Holder | 21 | 65 (21) | 12 | 52 | 25 | 48% | 5.5 | 49 (10) | 99 (8) | 32 (3) | 74 (9) | 57 (12) |
| Mine | Shooter | 40 | 60 (40) | 28 | 32 | 36 | 0% | 1.4 | 51 (8) | 72 (24) | 31 (8) | 60 (26) | 61 (14) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 58 | 63 (58) | 63 | 0 | 41 | 0% | 1.2 | 71 (20) | 56 (29) | 70 (9) | 45 (12) | 68 (46) |
| Mine | Wizard | 18 | 0 (18) | 0 | 0 | 14 | 17% | 2.4 | 0 (10) | 0 (4) | 0 (2) | 0 (5) | 0 (11) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 75 | 83 (75) | 16 | 67 | 51 | 53% | 2.8 | 60 (29) | 116 (28) | 60 (18) | 85 (59) | 76 (16) |
| Opponent | Character | 104 | 61 (104) | 60 | 1 | 27 | 15% | 2.3 | 72 (47) | 50 (33) | 66 (17) | 55 (56) | 73 (41) |
| Opponent | Clean-up | 25 | 48 (25) | 20 | 28 | 29 | 48% | 3.8 | 4 (10) | 83 (13) | 20 (2) | 62 (15) | 32 (10) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 50 | 40 (50) | 25 | 15 | 28 | 28% | 2.8 | 35 (19) | 43 (22) | 42 (9) | 56 (29) | 20 (21) |
| Opponent | Fragile | 11 | 0 (11) | 0 | 0 | 72 | 36% | 2.3 | 0 (2) | 0 (6) | 0 (2) | 0 (6) | 0 (4) |
| Opponent | Hammer | 52 | 31 (52) | 20 | 11 | 22 | 37% | 3.3 | 14 (16) | 37 (27) | 43 (9) | 22 (29) | 42 (23) |
| Opponent | Holder | 31 | 68 (31) | 6 | 62 | 8 | 52% | 3.5 | 87 (11) | 52 (13) | 89 (7) | 83 (23) | 23 (8) |
| Opponent | Shooter | 19 | 61 (19) | 28 | 33 | 14 | 0% | 1.5 | 60 (10) | 71 (8) | 0 (1) | 88 (13) | 10 (6) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 49 | 75% | 6.0 | - | 0 (2) | 0 (2) | - | 0 (4) |
| Opponent | War machine | 14 | 39 (14) | 39 | 0 | 55 | 0% | 1.1 | 0 (4) | 66 (6) | 36 (4) | 67 (6) | 20 (8) |
| Opponent | Wizard | 25 | 9 (25) | 9 | 0 | 26 | 16% | 1.9 | 3 (12) | 24 (8) | 0 (2) | 20 (12) | 0 (10) |

### Charged fights: dep-opp-13df7bd-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 102 | 280 | 2.0 | 1.2 | 140 | 71 | +69 | 2 of 8 | 5 of 8 | -8 | +95 |
| Mine | Chaos Dwarfs | 4 | 404 | 330 | 1.5 | 1.0 | 220 | 56 | +163 | 3 of 6 | 4 of 6 | - | +163 |
| Mine | Dwarfen Mountain Holds | 4 | 404 | 36 | 1.8 | 1.1 | 20 | 138 | -118 | 1 of 7 | 6 of 7 | -907 | +14 |
| Mine | Empire of Man | 5 | 419 | 62 | 1.4 | 1.1 | 44 | 56 | -12 | 3 of 7 | 4 of 7 | +140 | -37 |
| Mine | Grand Cathay | 4 | 288 | 175 | 2.2 | 1.1 | 78 | 26 | +52 | 2 of 9 | 6 of 9 | +264 | +26 |
| Mine | High Elf Realms | 4 | 156 | 412 | 3.2 | 1.2 | 127 | 73 | +54 | 6 of 13 | 8 of 13 | +286 | +12 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 419 | 3.0 | 1.0 | 140 | 0 | +140 | 1 of 3 | 1 of 3 | - | +140 |
| Mine | Lizardmen | 1 | 45 | 547 | 5.0 | 1.0 | 109 | 28 | +81 | 2 of 5 | 4 of 5 | - | +81 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 85 | -85 | 0 of 4 | 3 of 4 | - | -85 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 510 | 6.0 | 1.2 | 85 | 77 | +8 | 5 of 6 | 3 of 6 | +45 | +1 |
| Mine | Skaven | 2 | 22 | 0 | 1.5 | 1.0 | 0 | 96 | -96 | 2 of 3 | 0 of 3 | - | -96 |
| Mine | Tomb Kings of Khemri | 1 | 19 | 334 | 3.0 | 1.3 | 111 | 130 | -19 | 0 of 3 | 2 of 3 | -246 | +95 |
| Mine | Vampire Counts | 3 | 6 | 106 | 3.0 | 1.2 | 35 | 50 | -15 | 1 of 9 | 5 of 9 | +85 | -43 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 160 | -160 | 3 of 3 | 0 of 3 | - | -160 |
| **Mine** | all armies | 36 | 212 | 205 | 2.4 | 1.1 | 86 | 70 | +16 | 31 of 86 | 51 of 86 | +2 | +18 |
| Opponent | Chaos Dwarfs | 2 | 0 | 0 | 2.0 | 1.2 | 0 | 0 | +0 | 2 of 4 | 3 of 4 | +0 | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 420 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 0 | 236 | 3.0 | 1.3 | 79 | 0 | +79 | 0 of 3 | 3 of 3 | +124 | +56 |
| Opponent | Grand Cathay | 1 | 190 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 2 | 135 | 488 | 2.0 | 1.0 | 244 | 0 | +244 | 2 of 4 | 2 of 4 | - | +244 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 368 | 3.0 | 1.3 | 123 | 0 | +123 | 1 of 6 | 6 of 6 | +147 | +118 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 663 | 4.0 | 1.0 | 166 | 0 | +166 | 3 of 4 | 3 of 4 | - | +166 |
| Opponent | Skaven | 4 | 128 | 42 | 1.5 | 1.0 | 28 | 6 | +22 | 3 of 6 | 2 of 6 | - | +22 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 744 | 4.0 | 1.5 | 186 | 0 | +186 | 3 of 4 | 3 of 4 | +310 | +145 |
| Opponent | Vampire Counts | 10 | 85 | 518 | 4.2 | 1.2 | 123 | 30 | +93 | 15 of 42 | 31 of 42 | +163 | +80 |
| Opponent | Warriors of Chaos | 5 | 70 | 542 | 3.4 | 1.2 | 159 | 14 | +146 | 9 of 17 | 14 of 17 | +179 | +139 |
| Opponent | Wood Elf Realms | 6 | 179 | 372 | 3.8 | 1.1 | 97 | 55 | +42 | 9 of 23 | 18 of 23 | +189 | +20 |
| **Opponent** | all armies | 36 | 102 | 379 | 3.1 | 1.2 | 121 | 25 | +96 | 47 of 113 | 85 of 113 | +166 | +84 |

### Effective charges: dep-opp-13df7bd-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 2 (net -40) | 0 | 0 | 0 | 0 | 3 (net +158) | 3 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 6 | 1 (net +476) | 0 | 3 (net +92) | 0 | 1 (net +60) | 1 (net +168) | 0 | 50% (3 of 6) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 3 (net +33) | 2 (net -30) | 0 | 2 (net -431) | 0 | 43% (3 of 7) |
| Mine | Empire of Man | 7 | 3 (net -112) | 1 (net +0) | 0 | 0 | 0 | 3 (net +85) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 9 | 1 (net +0) | 0 | 2 (net -66) | 5 (net +65) | 0 | 1 (net +277) | 0 | 22% (2 of 9) |
| Mine | High Elf Realms | 13 | 2 (net -174) | 0 | 3 (net -128) | 4 (net +333) | 1 (net +0) | 2 (net +0) | 1 | 25% (3 of 12) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +233) | 0 | 0 | 1 (net +0) | 0 | 1 (net +186) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 5 | 0 | 0 | 2 (net +64) | 1 (net +211) | 0 | 2 (net +34) | 0 | 40% (2 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 1 (net -301) | 1 (net +0) | 1 (net -40) | 0 | 25% (1 of 4) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +0) | 0 | 1 (net +45) | 0 | 4 | 50% (1 of 2) |
| Mine | Skaven | 3 | 0 | 0 | 1 (net -222) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 2 (net -28) | 1 (net +0) | 0 | 0 | 0 | 67% (2 of 3) |
| Mine | Vampire Counts | 9 | 4 (net -87) | 1 (net +0) | 0 | 1 (net +110) | 2 (net +22) | 1 (net +60) | 0 | 0% (0 of 9) |
| Mine | Warriors of Chaos | 3 | 2 (net -240) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Chaos Dwarfs | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +118) | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 4 | 1 (net +516) | 0 | 1 (net +233) | 0 | 0 | 2 (net +114) | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 6 | 0 | 1 (net +165) | 2 (net +150) | 1 (net +0) | 1 (net +147) | 1 (net +123) | 0 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 4 | 1 (net +238) | 0 | 1 (net +425) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Opponent | Skaven | 6 | 4 (net -9) | 0 | 0 | 0 | 1 (net +77) | 1 (net +91) | 0 | 0% (0 of 6) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +310) | 1 (net +310) | 1 (net +124) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 42 | 11 (net -13) | 0 | 7 (net +240) | 7 (net +180) | 3 (net -75) | 11 (net +94) | 3 | 18% (7 of 39) |
| Opponent | Warriors of Chaos | 17 | 1 (net +0) | 1 (net +559) | 3 (net +210) | 2 (net +180) | 1 (net +210) | 9 (net +80) | 0 | 18% (3 of 17) |
| Opponent | Wood Elf Realms | 23 | 4 (net -62) | 2 (net -270) | 1 (net +0) | 1 (net +75) | 0 | 4 (net +56) | 11 | 8% (1 of 12) |

### Charged fights, damage counted: dep-opp-13df7bd-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 204 | 229 | -55 | 68 | 135 | -68 | -33.3 |
| Mine | 50-54% | 2 | 330 | 172 | +0 | 53 | 47 | +6 | +1.7 |
| Mine | Effective (55-75%) | 19 | 295 | 255 | -15 | 99 | 110 | -10 | -3.4 |
| Mine | 76-89% | 16 | 307 | 173 | +101 | 124 | 41 | +83 | +27.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 237 | 223 | +33 | 114 | 99 | +16 | +6.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 356 | 54 | +25 | 31 | 10 | +22 | +6.1 |
| Mine | No odds | 9 | 258 | 264 | +22 | 176 | 105 | +71 | +27.7 |
| Mine | All fights | 86 | 269 | 213 | +16 | 103 | 90 | +13 | +4.9 |
| Opponent | Long shot (under 50%) | 23 | 217 | 258 | +14 | 75 | 57 | +18 | +8.1 |
| Opponent | 50-54% | 4 | 374 | 306 | +46 | 181 | 199 | -18 | -4.9 |
| Opponent | Effective (55-75%) | 16 | 370 | 278 | +205 | 229 | 31 | +197 | +53.3 |
| Opponent | 76-89% | 12 | 390 | 209 | +167 | 182 | 9 | +174 | +44.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 270 | 170 | +82 | 123 | 29 | +94 | +34.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 606 | 97 | +74 | 144 | 75 | +69 | +11.4 |
| Opponent | No odds | 17 | 144 | 163 | +103 | 138 | 21 | +117 | +81.3 |
| Opponent | All fights | 113 | 292 | 207 | +96 | 140 | 40 | +100 | +34.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p5 | move | 424 | 75 (18%) | 57 (13%) | 44 (10%) | 305 (72%) |
| dep-opp-13df7bd-p5 | objective | 380 | 56 (15%) | 36 (9%) | 41 (11%) | 283 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0104, L0120, L2426, L2533, L2733 |
| Charmed Shield | Opponent | L0526, L0825, L1024, L1226, L1627, L1725, L1825, L1925, L2027, L2426 |
| Clockwork Compass | Mine | L1226 |
| Elixir of Power | Mine | L1116, L1133, L1925 |
| Elixir of Power | Opponent | L0719 |
| Fistful of Laurels | Mine | L1825 |
| Horn of the Wild Hunt | Opponent | L1133, L1433, L2233, L2533, L2733 |
| Invocation of Nehek | Mine | L2426, L2533, L2733 |
| Invocation of Nehek | Opponent | L0825, L1024, L1627, L1725, L1825, L1925, L2027 |
| Opal Amulet | Mine | L1416, L1433 |
| Opal Amulet | Opponent | L0614 |
| Periapt of Soul Exchange | Mine | L2027, L2129 |
| Periapt of Soul Exchange | Opponent | L0120, L0220, L0321, L1321 |
| Ring of Doom | Mine | L0204, L0220, L1116, L1133, L1226, L1529 |
| Ring of Doom | Opponent | L0915, L1133, L1433, L2233, L2533, L2733, L3031 |
| Ring of Jet | Mine | L1024, L1116, L1133, L1226 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Mine | L1321 |
| Storm Daemon (Renegade 2.0) | Mine | L2129 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321, L1321 |
| Twice-Blessed Armour | Mine | L0719, L0735, L1024 |
| Twice-Blessed Armour | Opponent | L0407, L0510 |
| Witch Hunter's Ward | Mine | L0719, L0735, L0825 |
| Witch Hunter's Ward | Opponent | L0407 |
